package cn.cool.cherish.value.impl;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.value.树何何何友树树何友何;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友树何树友友何树友友 extends 树何何何友树树何友何<String> implements  {
   private static final Pattern 树何树树树树友树何何;
   private static String[] 树何何树友友树何友友;
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final long f;
   private static final Object[] i = new Object[12];
   private static final String[] j = new String[12];
   private static int _何大伟230622198107200054 _;

   public 友树何树友友何树友友(String name, String value) {
      super(name, "", value);
   }

   public 友树何树友友何树友友(String name, String cnName, String value) {
      super(name, cnName, "L");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-664840821759147059L, 6087958615570571052L, MethodHandles.lookup().lookupClass()).a(235206964314179L);
      // $VF: monitorexit
      b = var10000;
      long var14 = b ^ 40867259208520L;
      a();
      c<"p">(null, 2601039776453887384L, var14);
      Cipher var5;
      Cipher var18 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(var14 << var6 * 8 >>> 56);
      }

      var18.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[5];
      int var10 = 0;
      String var9 = "ùä}0\u0090ü>¼|\u009b\u0001Ø³\u0097\u008b{\u0018ÌH¸@VX$Ã?Zò3»Í®¦l×æ\t\u0007\u008dV\u0012(cÙwÙ\u0085\u001f\u00ad\u0097Vø\u0002CùL\u009a,C¸\"uIõ¹X.\u0084ðY2ÕVi+r$Ö\u008a;\u0002[";
      byte var11 = 82;
      char var8 = 16;
      int var17 = -1;

      label37:
      while (true) {
         String var19 = var9.substring(++var17, var17 + var8);
         byte var10001 = -1;

         while (true) {
            String var27 = a(var5.doFinal(var19.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var12[var10++] = var27;
                  if ((var17 += var8) >= var11) {
                     c = var12;
                     d = new String[5];
                     Cipher var0;
                     Cipher var21 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var14 << var1 * 8 >>> 56);
                     }

                     var21.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-123, 56, -21, -102, 16, 79, -47, 20});
                     long var31 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     f = var31;
                     树何树树树树友树何何 = Pattern.compile(a<"t">(32722, 2164138330545298125L ^ var14));
                     return;
                  }

                  var8 = var9.charAt(var17);
                  break;
               default:
                  var12[var10++] = var27;
                  if ((var17 += var8) < var11) {
                     var8 = var9.charAt(var17);
                     continue label37;
                  }

                  var9 = "M\u000eê¶xmb\u0012YÝ½0\u0012b[K\u0010k%:ì \u009f\u00adB·Ú¨\u0098`\u007f¼-";
                  var11 = 33;
                  var8 = 16;
                  var17 = -1;
            }

            var19 = var9.substring(++var17, var17 + var8);
            var10001 = 0;
         }
      }
   }

   public static void J(String[] var0) {
      树何何树友友树何友友 = var0;
   }

   @Override
   public void Z(JsonElement element) {
      long a = b ^ 50798838649079L;
      c<"p">(7469155095917847076L, a);
      if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
         String jsonValue = element.getAsString();
         String decodedValue = j(jsonValue);
         this.g(decodedValue);
      }
   }

   public boolean V() {
      long a = b ^ 21345515842282L;
      c<"p">(6753985086533883961L, a);
      String val = this.getValue();
      return val == null || val.isEmpty();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 6;
               case 1 -> 1;
               case 2 -> 17;
               case 3 -> 60;
               case 4 -> 8;
               case 5 -> 52;
               case 6 -> 19;
               case 7 -> 16;
               case 8 -> 3;
               case 9 -> 39;
               case 10 -> 12;
               case 11 -> 48;
               case 12 -> 40;
               case 13 -> 26;
               case 14 -> 5;
               case 15 -> 42;
               case 16 -> 59;
               case 17 -> 32;
               case 18 -> 10;
               case 19 -> 28;
               case 20 -> 36;
               case 21 -> 34;
               case 22 -> 33;
               case 23 -> 46;
               case 24 -> 30;
               case 25 -> 54;
               case 26 -> 37;
               case 27 -> 7;
               case 28 -> 43;
               case 29 -> 31;
               case 30 -> 11;
               case 31 -> 61;
               case 32 -> 45;
               case 33 -> 50;
               case 34 -> 44;
               case 35 -> 56;
               case 36 -> 63;
               case 37 -> 15;
               case 38 -> 0;
               case 39 -> 9;
               case 40 -> 38;
               case 41 -> 58;
               case 42 -> 22;
               case 43 -> 41;
               case 44 -> 55;
               case 45 -> 13;
               case 46 -> 23;
               case 47 -> 20;
               case 48 -> 2;
               case 49 -> 51;
               case 50 -> 14;
               case 51 -> 4;
               case 52 -> 18;
               case 53 -> 25;
               case 54 -> 62;
               case 55 -> 57;
               case 56 -> 24;
               case 57 -> 35;
               case 58 -> 47;
               case 59 -> 27;
               case 60 -> 21;
               case 61 -> 53;
               case 62 -> 29;
               default -> 49;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'J' && var8 != 254 && var8 != 244 && var8 != 165) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'K') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'p') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'J') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 254) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static String s(String input) {
      long a = b ^ 29553292660745L;
      c<"p">(2835561528940438234L, a);
      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/impl/友树何树友友何树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public int c() {
      long a = b ^ 29547602762055L;
      c<"p">(3321387204279610260L, a);
      String val = this.getValue();
      return val != null ? val.length() : 0;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static boolean f(String input) {
      long a = b ^ 47471514372990L;
      c<"p">(-4886755361257637459L, a);
      if (input == null) {
         return false;
      } else {
         char[] var4 = input.toCharArray();
         int var5 = var4.length;
         int var6 = 0;
         if (0 < var5) {
            char c = var4[0];
            if (c >= 19968 && c <= (int)f) {
               return true;
            }

            var6++;
         }

         return false;
      }
   }

   public static String[] l() {
      return 树何何树友友树何友友;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      i[0] = "\u001a\u0019\u000e+m$\u0015YC g9\u0010\u0004Hft*\u0015\u0002Efk&\t\u001b\u000e厃栓伞桨厼叫伝栓厀厲";
      i[1] = "oTI]g'd[X\u0012\u0000%aPGs<?JS}S<%aFzD*.uAVS'";
      i[2] = "\u0016\u007f\u001a8$\u0014\u0019?W3.\t\u001cb\\u=\u001a\u0019dQu\"\u0016\u0005}\u001a\u0019$\u0014\u0019tU5\u001d\u001a\u0019dQ";
      i[3] = "\u001f#z*,Ij\u0003q%=\u0006\u0017\u001bb\"4O\u007f";
      i[4] = "\u0001EC8RD\u001fMYw\u000eT\fAMw,P\u001fPP+\u0012";
      i[5] = "/2z\u001a\u001fdZ\u0012q\u0015\u000e+'\nb\u0012\u0007bO";
      i[6] = void.class;
      j[6] = "java/lang/Void";
      i[7] = "y\u001d(!SFr\u00129n2Hy\u0019=4";
      i[8] = "6.s*\u0003-+ yR桿伌桌桗栘桋厥案伈伓\u0001h\u0014 8\u007fy4[>1";
      i[9] = "$3HESs9=B=_\u000f<b\u0002SS5=2F=M>\u007f=_\u0007Ln;S";
      i[10] = "]v\fh.r\u001ca\u001euD\u0017d#\u0018i(+\u001dt\u0010{6J";
      i[11] = "x(50F\u001ee&?Hab ,+$B\u001bw$9:#^r!-\"Z\u001e`2wH";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/impl/友树何树友友何树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @Override
   public void a(JsonObject object) {
      long a = b ^ 57802128069514L;
      c<"p">(7267365440090759513L, a);
      String value = this.getValue();
      object.addProperty(this.v(), s(value));
      object.addProperty(this.v(), (String)null);
   }

   private static IndexOutOfBoundsException a(IndexOutOfBoundsException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16647;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/value/impl/友树何树友友何树友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static String j(String input) {
      long a = b ^ 50287038663143L;
      c<"p">(9130986067658505012L, a);
      return null;
   }

   public char z(int i) {
      long a = b ^ 104528743045064L;
      c<"p">(-2262858845781367525L, a);
      String val = this.getValue();
      if (i >= 0 && i < val.length()) {
         return val.charAt(i);
      } else {
         throw new IndexOutOfBoundsException(a<"t">(14105, 2463922618463983239L ^ a) + i + a<"t">(32010, 1677590240042605718L ^ a) + 0);
      }
   }

   public int A() {
      long a = b ^ 76332329581638L;
      c<"p">(5410705119356604053L, a);
      String val = this.getValue();
      return val == null ? 0 : val.getBytes(StandardCharsets.UTF_8).length;
   }

   public void Q() {
      this.g("");
   }

   public String O() {
      return s(this.getValue());
   }

   public boolean K() {
      return f(this.getValue());
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖黑水";
   }
}
