package cn.cool.cherish.value.impl;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.value.树何何树何友树何何树;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何何何友友何树何何何 extends 树何何树何友树何何树<String> implements  {
   private static final Pattern 何树树何何友友何树何;
   private static int[] 树何友何树何树树树何;
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final long f;
   private static final Object[] i = new Object[12];
   private static final String[] j = new String[12];
   private static int _何炜霖大狗叫 _;

   public 何何何友友何树何何何(String name, String value) {
      super("Server Name", "", "Cherish.top");
   }

   public 何何何友友何树何何何(String name, String cnName, String value) {
      super(name, cnName, value);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5372268208374671908L, -1975599618330247115L, MethodHandles.lookup().lookupClass()).a(42190366089379L);
      // $VF: monitorexit
      b = var10000;
      a();
      int[] var15 = new int[2];
      U(var15);
      Cipher var5;
      Cipher var16 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(92783317779268L << var6 * 8 >>> 56);
      }

      var16.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[5];
      int var10 = 0;
      String var9 = "Ënòª¢\\\u0017Ò\u007fýð\u0084 ù¯æ\u008d\u00ad¶ÏÖ\u0097\u0096\u0001ß¹\u0083dôlô¬åõ\u008d©µbÖÿ\u0010Êö5;ÒæÓ)j\u0003\f:ñÊ\u00adÿ\u0010«2\u0088Þ\u0095¸bÄ\u0013rY$\u0094_\u0093\u0092";
      byte var11 = 74;
      char var8 = '(';
      int var14 = -1;

      label37:
      while (true) {
         String var17 = var9.substring(++var14, var14 + var8);
         byte var10001 = -1;

         while (true) {
            String var25 = a(var5.doFinal(var17.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var12[var10++] = var25;
                  if ((var14 += var8) >= var11) {
                     c = var12;
                     d = new String[5];
                     Cipher var0;
                     Cipher var19 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(92783317779268L << var1 * 8 >>> 56);
                     }

                     var19.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-33, -93, 72, 11, 43, 47, -124, 94});
                     long var29 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     f = var29;
                     何树树何何友友何树何 = Pattern.compile("\\\\u([0-9a-fA-F]{4})");
                     return;
                  }

                  var8 = var9.charAt(var14);
                  break;
               default:
                  var12[var10++] = var25;
                  if ((var14 += var8) < var11) {
                     var8 = var9.charAt(var14);
                     continue label37;
                  }

                  var9 = "Hº?$&u\u0093\u0011Û\u0015d~\u008d\"V\u0013\u0018!ê¾Iû\ne'.N\u0011ØÇõ$\u001cÙ£ÁOXÚÅó";
                  var11 = 41;
                  var8 = 16;
                  var14 = -1;
            }

            var17 = var9.substring(++var14, var14 + var8);
            var10001 = 0;
         }
      }
   }

   @Override
   public void C(JsonElement element) {
      BooleanValue.F();
      if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
         String jsonValue = element.getAsString();
         String decodedValue = e(jsonValue);
         this.G(decodedValue);
      }
   }

   public int F() {
      BooleanValue.F();
      String val = this.getValue();
      return val == null ? 0 : val.getBytes(StandardCharsets.UTF_8).length;
   }

   public char I(int i) {
      BooleanValue.F();
      String val = this.getValue();
      if (i >= 0 && i < val.length()) {
         return val.charAt(i);
      } else {
         boolean var10004 = false;
         throw new IndexOutOfBoundsException("Index: " + i + "" + 0);
      }
   }

   public String e() {
      return z(this.getValue());
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 55;
               case 1 -> 41;
               case 2 -> 40;
               case 3 -> 11;
               case 4 -> 6;
               case 5 -> 26;
               case 6 -> 39;
               case 7 -> 0;
               case 8 -> 32;
               case 9 -> 42;
               case 10 -> 22;
               case 11 -> 12;
               case 12 -> 36;
               case 13 -> 52;
               case 14 -> 33;
               case 15 -> 18;
               case 16 -> 9;
               case 17 -> 7;
               case 18 -> 37;
               case 19 -> 5;
               case 20 -> 56;
               case 21 -> 17;
               case 22 -> 38;
               case 23 -> 25;
               case 24 -> 43;
               case 25 -> 59;
               case 26 -> 49;
               case 27 -> 53;
               case 28 -> 27;
               case 29 -> 10;
               case 30 -> 62;
               case 31 -> 14;
               case 32 -> 8;
               case 33 -> 15;
               case 34 -> 60;
               case 35 -> 44;
               case 36 -> 21;
               case 37 -> 29;
               case 38 -> 2;
               case 39 -> 61;
               case 40 -> 47;
               case 41 -> 19;
               case 42 -> 28;
               case 43 -> 46;
               case 44 -> 58;
               case 45 -> 1;
               case 46 -> 13;
               case 47 -> 4;
               case 48 -> 45;
               case 49 -> 54;
               case 50 -> 34;
               case 51 -> 24;
               case 52 -> 35;
               case 53 -> 51;
               case 54 -> 30;
               case 55 -> 23;
               case 56 -> 48;
               case 57 -> 63;
               case 58 -> 16;
               case 59 -> 57;
               case 60 -> 20;
               case 61 -> 50;
               case 62 -> 3;
               default -> 31;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static String e(String input) {
      BooleanValue.F();
      return null;
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 224 && var8 != 'x' && var8 != 'V' && var8 != 'm') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 251) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'F') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 224) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'x') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'V') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/impl/何何何友友何树何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public void l() {
      this.G("");
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      i[0] = "Hf\u0000!\u000e\\G&M*\u0004AB{Fl\u0017RG}Kl\b^[d\u0000众伴佦叠參佻桓伴佦佾";
      i[1] = "J~\u0001i\b\u0012Aq\u0010&o\u0010Dz\u000fGS\noy5gS\u0010Dl2pE\u001bPk\u001egH";
      i[2] = "TL`Pm([\f-[g5^Q&\u001dt&[W+\u001dk*GN`qm([G/]T&[W+";
      i[3] = "\u000f%";
      i[4] = "62\u001e\u001dTz(:\u0004R\bj;6\u0010R*n('\r\u000e\u0014";
      i[5] = " &";
      i[6] = void.class;
      j[6] = "java/lang/Void";
      i[7] = "{SSVDSp\\B\u0019%]{WFC";
      i[8] = "0`'rQ\thqz\u001d佮桮桉佁优叞台伪桉佁E&\u000e\bib)pK\u00120";
      i[9] = "\u0011O\u0018\u0017.\u001eI^Ex%`H\u000fA\u0011\"X\u001b\r\u0010\u0014LYM\b\u0013\u0016t\nOY\u0016x";
      i[10] = "5\u0004\u0006\u0004%\u00003L\b\u0019E+\u000f\u0006\u0006\u0007}\u0004pX\n\u0005xe";
      i[11] = "W\rthCJ\u000f\u001c)\u0007|4\f\u0003n?@KR\u000fl:!\bY\u001cg{NM\u0007\u001d{\u0007";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/impl/何何何友友何树何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static IndexOutOfBoundsException a(IndexOutOfBoundsException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2459;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/value/impl/何何何友友何树何何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public int t() {
      BooleanValue.F();
      String val = this.getValue();
      return val != null ? val.length() : 0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static boolean v(String input) {
      BooleanValue.F();
      if (input == null) {
         return false;
      } else {
         char[] var4 = input.toCharArray();
         int var5 = var4.length;
         int var6 = 0;
         if (0 < var5) {
            char c = var4[0];
            if (c >= 19968 && c <= '\u9fff') {
               return true;
            }

            var6++;
         }

         return false;
      }
   }

   public static void U(int[] var0) {
      树何友何树何树树树何 = var0;
   }

   public static String z(String input) {
      BooleanValue.F();
      return null;
   }

   public boolean y() {
      return v(this.getValue());
   }

   @Override
   public void L(JsonObject object) {
      BooleanValue.F();
      String value = this.getValue();
      object.addProperty(this.r(), z(value));
      object.addProperty(this.r(), (String)null);
   }

   public boolean P() {
      BooleanValue.F();
      String val = this.getValue();
      return val == null || val.isEmpty();
   }

   public static int[] H() {
      return 树何友何树何树树树何;
   }

   private static String HE_SHU_YOU() {
      return "职业技术教育中心学校";
   }
}
