package cn.cool.cherish.value.impl;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.value.树何何树何友树何何树;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class NumberValue extends 树何何树何友树何何树<Number> implements  {
   private final Number 友何何友何何何树友友;
   private final Number 树树友友友树何何树何;
   private final Number 何树友何树何友友树树;
   public float 树树何树何树何树友何;
   public boolean 何友何友友友树友树树;
   private static boolean 友树友何何何树何树树;
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[22];
   private static final String[] i = new String[22];
   private static String HE_WEI_LIN;

   public NumberValue(String name, Number value, Number minValue, Number maxValue, Number step) {
      super(name, "", value);
      this.友何何友何何何树友友 = maxValue;
      this.树树友友友树何何树何 = minValue;
      this.何树友何树何友友树树 = step;
      this.S(value);
   }

   public NumberValue(String name, String cnName, Number value, Number minValue, Number maxValue, Number step) {
      super(name, cnName, value);
      this.友何何友何何何树友友 = maxValue;
      this.树树友友友树何何树何 = minValue;
      this.何树友何树何友友树树 = step;
      this.S(value);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-311709314333579656L, -2193077379897042092L, MethodHandles.lookup().lookupClass()).a(226287662634517L);
      // $VF: monitorexit
      b = var10000;
      b();
      x(true);
      Cipher var0;
      Cipher var9 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(120631613606147L << var1 * 8 >>> 56);
      }

      var9.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[2];
      int var5 = 0;
      char var3 = 16;
      int var2 = -1;

      while (true) {
         String var11 = a(
               var0.doFinal(
                  "1´\u0006\u0090ü\u008fKÒK\u0015gWv\u0093-â\u0010\u0091ÃB÷¾\u0002¢:W\u001dw%Y ï\u0017".substring(++var2, var2 + var3).getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var11;
         if ((var2 += var3) >= 33) {
            c = var7;
            d = new String[2];
            return;
         }

         var3 = "1´\u0006\u0090ü\u008fKÒK\u0015gWv\u0093-â\u0010\u0091ÃB÷¾\u0002¢:W\u001dw%Y ï\u0017".charAt(var2);
      }
   }

   @Override
   public void C(JsonElement element) {
      BooleanValue.F();
      if (this.何树友何树何友友树树.doubleValue() < 0.001) {
         Double number = element.getAsDouble();
         this.S(number);
      }

      Float number = element.getAsFloat();
      this.S(number);
   }

   public void S(Number value) {
      double doubleValue = value.doubleValue();
      double min = this.树树友友友树何何树何.doubleValue();
      BooleanValue.F();
      double max = this.友何何友何何何树友友.doubleValue();
      doubleValue = Math.max(min, Math.min(max, doubleValue));
      double stepValue = this.何树友何树何友友树树.doubleValue();
      if (stepValue > 0.0) {
         double deltaFromMin = doubleValue - min;
         int stepCount = (int)Math.round(deltaFromMin / stepValue);
         doubleValue = min + stepCount * stepValue;
         doubleValue = Math.max(min, Math.min(max, doubleValue));
      }

      if (value instanceof Double) {
         Double.valueOf(doubleValue);
      }

      if (value instanceof Float) {
         Float.valueOf((float)doubleValue);
      }

      if (value instanceof Long) {
         Long.valueOf((long)doubleValue);
      }

      if (value instanceof Integer) {
         Integer.valueOf((int)doubleValue);
      }

      if (value instanceof Short) {
         Short.valueOf((short)doubleValue);
      }

      if (value instanceof Byte) {
         Byte.valueOf((byte)doubleValue);
      }

      Number newValue = doubleValue;
      super.G(newValue);
      if (Module.Z() == null) {
         BooleanValue.R(new int[2]);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 20;
               case 1 -> 52;
               case 2 -> 26;
               case 3 -> 30;
               case 4 -> 49;
               case 5 -> 50;
               case 6 -> 46;
               case 7 -> 34;
               case 8 -> 8;
               case 9 -> 35;
               case 10 -> 58;
               case 11 -> 13;
               case 12 -> 62;
               case 13 -> 14;
               case 14 -> 17;
               case 15 -> 6;
               case 16 -> 3;
               case 17 -> 44;
               case 18 -> 56;
               case 19 -> 36;
               case 20 -> 59;
               case 21 -> 0;
               case 22 -> 24;
               case 23 -> 2;
               case 24 -> 55;
               case 25 -> 43;
               case 26 -> 47;
               case 27 -> 19;
               case 28 -> 32;
               case 29 -> 61;
               case 30 -> 37;
               case 31 -> 23;
               case 32 -> 4;
               case 33 -> 15;
               case 34 -> 12;
               case 35 -> 38;
               case 36 -> 51;
               case 37 -> 16;
               case 38 -> 54;
               case 39 -> 41;
               case 40 -> 9;
               case 41 -> 7;
               case 42 -> 22;
               case 43 -> 39;
               case 44 -> 33;
               case 45 -> 48;
               case 46 -> 11;
               case 47 -> 18;
               case 48 -> 60;
               case 49 -> 29;
               case 50 -> 25;
               case 51 -> 40;
               case 52 -> 42;
               case 53 -> 27;
               case 54 -> 10;
               case 55 -> 45;
               case 56 -> 1;
               case 57 -> 57;
               case 58 -> 28;
               case 59 -> 53;
               case 60 -> 63;
               case 61 -> 21;
               case 62 -> 5;
               default -> 31;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static boolean i() {
      a();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static void b() {
      f[0] = "\fA\u000bA\u0012b\u0003\u0001FJ\u0018\u007f\u0006\\M\f\u000bl\u0003Z@\f\u0014`\u001fC\u000bl\b`\rJWt\u001ca\u001aJ";
      f[1] = "\u0016V\u0014SD\u0013\u001dY\u0005\u001c$\n\u0011U\u0007@";
      f[2] = "+6\u000fPO= 9\u001e\u001f3$/#\u0010\\\u0004\u001494\u001cA\u00158.9";
      f[3] = "Fk;kNpI+v`DmLv}&W~Ipp&HrUi;JNpI`tfw~Ipp";
      f[4] = "7G";
      f[5] = "57^I\u0014d:w\u0013B\u001ey?*\u0018\u0004\u0016d2,\u001cOUF9=\u0005F\u001e";
      f[6] = "qHk\u000f\u001eSEkdOSXOva\u0012X\u001eGkl\u0014\\U\u0004Ig\u0005E\\O?";
      f[7] = "7p";
      f[8] = void.class;
      i[8] = "java/lang/Void";
      f[9] = float.class;
      i[9] = "java/lang/Float";
      f[10] = boolean.class;
      i[10] = "java/lang/Boolean";
      f[11] = "d\u001c\u0004)5Fo\u0013\u0015fTHd\u0018\u0011<";
      f[12] = "~B\u0016\u0000Q6|P\u0017:栣栓厁叼厾栣佧佗桛佢}ABg)\u000f\u0013\u0000\u000bh";
      f[13] = "es\u0004U/ ga\u0005o桝栅伄栗伲桶伙栅厚体oQ>! s^\u0010\u007fg2";
      f[14] = "AU'\u0011\u001dSK^gJ,cz\u001b{\u000e\u0013L\u0016\u001dg\u0012P1";
      f[15] = "/7a\u0007a`-%`=c\\)rlWr b$x\u0005\nf+,`Ev-}82=";
      f[16] = "#\u0011\u007f~\u0005c`Dz&?M\u0019\u0010*f\u0004xdN!%^\u0003";
      f[17] = "n:\rgYLl(\f]佯厳伏厄厥厞栫厳桋桞fcCM,(\u001d;X\t*";
      f[18] = "a*ni-+\"\u007fk1\u0017\u0011[+;q,0&u02vKe))u)r?)3?\u0017";
      f[19] = "r,P\\rrp>Qf叚伓伓厒佦伻佄桗厍厒;\u001da#%aU\\(,";
      f[20] = ";w\u0011BId9e\u0010xRX9{G\u0006M#a`\u0003\u0000\"f8u\u0001F\u001b<8oKx";
      f[21] = "@(?]#lB:>g伕桉县伈桍伺压厓桥桌T\u001c0=\u0017e:]y2";
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 228 && var8 != 206 && var8 != 223 && var8 != 'Z') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 224) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'w') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 228) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 206) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static void x(boolean var0) {
      友树友何何何树何树树 = var0;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/impl/NumberValue" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/impl/NumberValue" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static boolean a() {
      return 友树友何何何树何树树;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12280;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/value/impl/NumberValue", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public Number o() {
      return this.树树友友友树何何树何;
   }

   public float t() {
      return this.树树何树何树何树友何;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public boolean y() {
      return this.何友何友友友树友树树;
   }

   public Number A() {
      return this.友何何友何何何树友友;
   }

   public Number X() {
      return this.何树友何树何友友树树;
   }

   @Override
   public void L(JsonObject object) {
      BooleanValue.F();
      Number value = this.getValue();
      if (this.何树友何树何友友树树.doubleValue() < 0.001) {
         object.addProperty(this.r(), value.doubleValue());
      }

      if (this.何树友何树何友友树树.doubleValue() < 0.01) {
         object.addProperty(this.r(), Float.valueOf(String.format("%.3f", value.floatValue())));
      }

      object.addProperty(this.r(), Float.valueOf(String.format("%.2f", value.floatValue())));
   }

   private static String HE_SHU_YOU() {
      return "何炜霖黑水";
   }
}
