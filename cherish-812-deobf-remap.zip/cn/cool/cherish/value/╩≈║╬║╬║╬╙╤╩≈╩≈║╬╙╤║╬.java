package cn.cool.cherish.value;

import cn.cool.cherish.module.何友友树友何友何何何;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.function.Supplier;

public abstract class 树何何何友树树何友何<T> implements  {
   private final String 树友友友何友树友何树;
   private final String 树友树友何友何友树友;
   private Supplier<Boolean> 树友何何何何树树何友;
   private final float 友友何友树友友何友何;
   private final float 树树友友树树何友友树;
   private final float 树何友友树树何友友树;
   private T 友何何树何树树树树友;
   private static boolean 树友何友树友友何友何;
   private static final long a;
   private static final Object[] g = new Object[17];
   private static final String[] h = new String[17];
   private static String HE_SHU_YOU;

   public 树何何何友树树何友何(String name, String cnName, T value) {
      long a = 树何何何友树树何友何.a ^ 59661932041053L;
      super();
      b<"y">(this, () -> true, 5576103939929287568L, a);
      this.友友何友树友友何友何 = 22.0F;
      this.树树友友树树何友友树 = 0.0F;
      this.树何友友树树何友友树 = 0.0F;
      this.树友友友何友树友何树 = name;
      this.树友树友何友何友树友 = "";
      b<"y">(this, value, 5576447958301487948L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-3584989228957282237L, 7447893885283084241L, MethodHandles.lookup().lookupClass()).a(185644047933041L);
      // $VF: monitorexit
      a = var10000;
      long var0 = a ^ 97554678135030L;
      d();
      if (b<"s">(-1817021568352730468L, var0)) {
         b<"s">(true, -1816774634237350522L, var0);
      }
   }

   public float S() {
      return 0.0F;
   }

   public abstract void Z(JsonElement var1);

   public float V() {
      return 0.0F;
   }

   public T getValue() {
      long a = 树何何何友树树何友何.a ^ 2071244340038L;
      return (T)b<"p">(this, 2700104232732678999L, a);
   }

   public <V extends 树何何何友树树何友何<T>> V i(Supplier<Boolean> condition) {
      long a = 树何何何友树树何友何.a ^ 15787484015939L;
      b<"y">(this, condition, 3709968722174170510L, a);
      return (V)this;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/树何何何友树树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = g[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = g[var4];
      if (var5 instanceof String) {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         g[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public boolean n() {
      long a = 树何何何友树树何友何.a ^ 112756186163077L;
      b<"s">(8771774806155550191L, a);
      boolean var10000 = !(Boolean)b<"p">(this, 8771354231002898248L, a).get();
      b<"s">(!b<"s">(8771604202386460711L, a), 8771606119004777160L, a);
      return var10000;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = g[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         g[var4] = var21;
         return var21;
      }
   }

   private static void d() {
      g[0] = "^\brD\u0010(QH?O\u001a5T\u00154\t\t&Q\u00139\t桮伒佨伳厗栶桮伒叶伳";
      g[1] = "C$kY\u000e^H+z\u0016oPC ~L";
      g[2] = boolean.class;
      h[2] = "java/lang/Boolean";
      g[3] = void.class;
      h[3] = "java/lang/Void";
      g[4] = "vMoTT\rhEu\u001b\u001c\rrOm\\\u0015\u00162\u007flE\n\u0014uIk";
      g[5] = "\u0018Bgv\u007fX\u0017\u0002*}uE\u0012_!;}X\u001fY%p>z\u0014H<yu";
      g[6] = "%G{Up|.Hj\u001a\fe!RdY;U7EhD*y H";
      g[7] = "\u00052\u0011=-\u001d\u000e=\u0000rP\u0005\u001d:\t;";
      g[8] = "v?H~[%g1\u0011\u0006栣叞栁厒伫叅佧叞栁厒v;Ssr)\fw\u000bps";
      g[9] = ",\u0001\u001bR\u007f\t=\u000fB*标史伟伲佸佷标栨伟厬%\u0011&\\\u007f\u0011\u001dI!M8";
      g[10] = "@\u0011\u0011M;}B\u001eEBXW{Z\u001e\u001aat\u0006\bAI6\u0014";
      g[11] = ".)\u001eo\u0015\u0003?'G\u0017(;y$\u001e.\u0014F+{Myt\u0001/$OyDZ?'X\u0017";
      g[12] = "\u0003\u0010*%mS\u0012\u001es]栕厨厮厽佉厞栕厨估桧\u0014`e\u0005\u0007\u0006n,=\u0006\u0006";
      g[13] = "!\u001c3\\a5#\u0013gS\u0002\u0015\u001aW<\u000b;<g\u0005cXl\\ \u0001<Zll{\u0011?M\u0002";
      g[14] = "\u000eg&xV_\u001fi\u007f\u0000叴伺伽栐佅栙栮桾桹及\u0018pN\u0017[ny8\r\u0005";
      g[15] = "]R<\u000e[qL\\evUI\n_<OZ4X\u0000o\u0018:";
      g[16] = "\u007fwaPU\u001fny8(^'-u:HU\u0016t&eM4\u001b}|?I\u0005B.#:(";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (h[var4] != null) {
         return var4;
      } else {
         Object var5 = g[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 17;
               case 2 -> 13;
               case 3 -> 5;
               case 4 -> 9;
               case 5 -> 39;
               case 6 -> 34;
               case 7 -> 8;
               case 8 -> 45;
               case 9 -> 53;
               case 10 -> 54;
               case 11 -> 4;
               case 12 -> 40;
               case 13 -> 21;
               case 14 -> 52;
               case 15 -> 25;
               case 16 -> 55;
               case 17 -> 31;
               case 18 -> 57;
               case 19 -> 49;
               case 20 -> 33;
               case 21 -> 41;
               case 22 -> 43;
               case 23 -> 28;
               case 24 -> 23;
               case 25 -> 56;
               case 26 -> 14;
               case 27 -> 0;
               case 28 -> 51;
               case 29 -> 44;
               case 30 -> 6;
               case 31 -> 48;
               case 32 -> 50;
               case 33 -> 2;
               case 34 -> 61;
               case 35 -> 10;
               case 36 -> 60;
               case 37 -> 62;
               case 38 -> 46;
               case 39 -> 15;
               case 40 -> 3;
               case 41 -> 11;
               case 42 -> 29;
               case 43 -> 36;
               case 44 -> 12;
               case 45 -> 32;
               case 46 -> 20;
               case 47 -> 63;
               case 48 -> 7;
               case 49 -> 22;
               case 50 -> 19;
               case 51 -> 42;
               case 52 -> 16;
               case 53 -> 38;
               case 54 -> 58;
               case 55 -> 27;
               case 56 -> 47;
               case 57 -> 26;
               case 58 -> 35;
               case 59 -> 1;
               case 60 -> 18;
               case 61 -> 24;
               case 62 -> 59;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            h[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public abstract void a(JsonObject var1);

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'p' && var8 != 'y' && var8 != 231 && var8 != 186) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'm') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 's') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'p') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'y') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 231) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public void g(T value) {
      long a = 树何何何友树树何友何.a ^ 51045237179299L;
      b<"y">(this, value, -7089336581433203790L, a);
   }

   public static boolean g() {
      X();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw b(var0);
      }
   }

   public String v() {
      long a = 树何何何友树树何友何.a ^ 103979380107491L;
      return b<"p">(this, -5269924795884883918L, a);
   }

   public Supplier<Boolean> v() {
      long a = 树何何何友树树何友何.a ^ 65623691706848L;
      return b<"p">(this, 2296625878378314029L, a);
   }

   public static boolean X() {
      return 树友何友树友友何友何;
   }

   public String W() {
      long a = 树何何何友树树何友何.a ^ 44790435020293L;
      return b<"p">(this, -6901141649623051149L, a);
   }

   public static void T(boolean var0) {
      树友何友树友友何友何 = var0;
   }

   public float O() {
      return 22.0F;
   }

   private static String HE_SHU_YOU() {
      return "何炜霖国企变私企";
   }
}
