package cn.cool.cherish;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.render.友何树何何友友树友友;
import cn.cool.cherish.ui.何树友友何友友何树树;
import cn.cool.cherish.ui.树友何何何树友树何友;
import cn.cool.cherish.utils.client.ClientUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.glfw.GLFW;

public class 友树树友何树友何友友 extends 何何何何何何何友树友 implements 何树友 {
   private final Map<Integer, String> 树友何树友何树树友树 = new HashMap<>();
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[17];
   private static final String[] i = new String[17];
   private static int _何炜霖国企变私企 _;

   public 友树树友何树友何友友() {
      super("binds", "bs");
      友树友友何树何何树树.B();
      Field[] var4 = GLFW.class.getFields();
      int var5 = var4.length;
      int var6 = 0;
      if (0 < var5) {
         Field field = var4[0];
         if (Modifier.isStatic(field.getModifiers()) && field.getName().startsWith("GLFW_KEY_")) {
            field.setAccessible(true);

            try {
               int keyCode = (Integer)field.get(null);
               String keyName = field.getName().substring(9).toLowerCase();
               this.树友何树友何树树友树.put(keyCode, keyName);
            } catch (IllegalAccessException var10) {
               var10.printStackTrace();
            }
         }

         var6++;
      }

      if (Module.Z() == null) {
         友树友友何树何何树树.r(new Module[4]);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(4002177379375220409L, -7713156909544712503L, MethodHandles.lookup().lookupClass()).a(155511630274022L);
      // $VF: monitorexit
      b = var10000;
      b();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(45713834176835L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[11];
      int var7 = 0;
      String var6 = "º¨\u001c¯>\u0092\u0085+P±Û\\ \u008a¯ª c}%þOAv¶.Â\u0080×\"'\u0013ÓzýnK0üÚ\fÑ¥\u008fW\u0018ôA\u0090\u0010É\u0011\u0002\u0086y\u0080\u000f\u0089öÊ\u0086\u008cJ©Å.\u0010öÖÚ\u0089ÞNwçE\u0011©M$åå\u001a\u0010içK\u0002£¢\u0005[\u009cÓX\\~\u000eÆx @R\u0090Æ¨ ÙÈ\u001a&ÿmÓu¦«ó\u009f\u0002B\u009c°\u001cï\u0012h¨\u00072Æ\u0090g\u0010cq³\u0099é!jÃ-L\u001cÚ\u0095\u0099rÌ Ê-:N\f\u0004È.¸GjÔ\u0011'¥&ÿ\u008f½qF\u0092Éa/\u009a´\u000e\u000b5Ú\u00ad0¦Gç¢=»e7$\n¨Fs\u009aÆF!h#17Í\u0013\b\u001eVÐ£\u009aÌ\u009fé1½¡ËB!kf\u000eO(\\µ¾\u0013ù";
      short var8 = 232;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     d = new String[11];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "cWe¾k¤\u001d\u009a`\\£é@ÖïÌ\u0010þG\u009c\bØh(÷îÊ\u0092\u008d\u00183ç+";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 24;
               case 1 -> 48;
               case 2 -> 53;
               case 3 -> 16;
               case 4 -> 0;
               case 5 -> 17;
               case 6 -> 30;
               case 7 -> 32;
               case 8 -> 37;
               case 9 -> 31;
               case 10 -> 47;
               case 11 -> 18;
               case 12 -> 2;
               case 13 -> 14;
               case 14 -> 50;
               case 15 -> 8;
               case 16 -> 10;
               case 17 -> 6;
               case 18 -> 60;
               case 19 -> 28;
               case 20 -> 46;
               case 21 -> 34;
               case 22 -> 13;
               case 23 -> 62;
               case 24 -> 27;
               case 25 -> 22;
               case 26 -> 43;
               case 27 -> 40;
               case 28 -> 20;
               case 29 -> 9;
               case 30 -> 42;
               case 31 -> 52;
               case 32 -> 12;
               case 33 -> 54;
               case 34 -> 38;
               case 35 -> 55;
               case 36 -> 7;
               case 37 -> 63;
               case 38 -> 29;
               case 39 -> 33;
               case 40 -> 25;
               case 41 -> 5;
               case 42 -> 59;
               case 43 -> 61;
               case 44 -> 19;
               case 45 -> 35;
               case 46 -> 51;
               case 47 -> 36;
               case 48 -> 1;
               case 49 -> 3;
               case 50 -> 23;
               case 51 -> 49;
               case 52 -> 4;
               case 53 -> 45;
               case 54 -> 44;
               case 55 -> 15;
               case 56 -> 39;
               case 57 -> 11;
               case 58 -> 26;
               case 59 -> 56;
               case 60 -> 41;
               case 61 -> 21;
               case 62 -> 58;
               default -> 57;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   @Override
   public void i(String[] params) {
      友树友友何树何何树树.B();
      if (params.length >= 1 && params[0].equalsIgnoreCase("clear")) {
         Iterator var13 = Cherish.instance.getModuleManager().p().iterator();
         if (var13.hasNext()) {
            Module module = (Module)var13.next();
            if (!(module instanceof 友何树何何友友树友友)) {
               module.g(-1);
            }
         }

         树友何何何树友树何友.E(何树友友何友友何树树.树树友树友友友何何树, "Binds", "Removed all binds.", 5.0F);
      } else {
         ClientUtils.P(125527250587045L, "=== Binds ===");
         Collection<Module> modules = Cherish.instance.getModuleManager().p();
         boolean foundBinds = false;
         Iterator var9 = modules.iterator();
         if (var9.hasNext()) {
            Module module = (Module)var9.next();
            int key = module.r();
            if (key != -1 && key != 0) {
               String keyName = this.树友何树友何树树友树.getOrDefault(key, "key_" + key);
               ClientUtils.P(125527250587045L, "> " + module.A() + ": " + keyName);
               foundBinds = true;
            }
         }

         if (!foundBinds) {
            ClientUtils.P(125527250587045L, "No binds found.");
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 223 && var8 != 's' && var8 != 'C' && var8 != 'z') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 249) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 196) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 223) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 's') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'C') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void b() {
      h[0] = "\u0015zmxU%\u001a: s_8\u001fg+5叱桛厽叟伖栊佯伟桧栅";
      h[1] = "z9\u007fp\r\u000bN\u001ap0@\u0000D\u0007umKFL\u001axkO\r\u000f8szV\u0004DN";
      h[2] = "\u007f[TYH:p\u001b\u0019RB'uF\u0012\u0014召桄栍叾伯栫召伀受叾";
      h[3] = "K\u001f\u001f=SMU\u0017\u0005r0YQ";
      h[4] = "*Qg5\u0007\u0013%\u0011*>\r\u000e L!x\u001d\u0015g佪桘厝厣伩厂叴伜桇桹";
      h[5] = "\t\f3\u0002`\u0014\u0002\u0003\"M\u000b\u0000\u0000\b5\u0017'\u0017\r";
      h[6] = "|2\u0016z\u0010SH\u0011\u0019:]XB\f\u001cgV\u001eJ\u0011\u0011aRU\t3\u001apK\\BE";
      h[7] = void.class;
      i[7] = "java/lang/Void";
      h[8] = "\u00039?.Nh\fyr%Du\t$ycLh\u0004\"}(\u000fJ\u000f3d!D";
      h[9] = "Z\u0007\u0018}Vnn$\u0017=\u001bed9\u0012`\u0010#l$\u001ff\u0014h/\u0006\u0014w\radp";
      h[10] = ":o^]8z1`O\u0012Yt:kKH";
      h[11] = "dKK\u001e\u0003H!L\u0002g\t-`\u0016\u0019\f\u0015\u0017aIN[s\u0010e\t\u0011^\u000b\\5B\fg";
      h[12] = ")M\tw`\u0015/\u0000T.\u0001}\u0017CR\u007fjI-B\r(=/";
      h[13] = "b\u000f;z,7'\br\u0003\u0016RfRih:hg\r>?\\";
      h[14] = "|/QN\u001b_?>\u0013Q\u007fDEn\u000f\u001d\u0000D$3V\u001e\u0002-~3T_\u0016L#jW]\u007f";
      h[15] = "Z\u001b\u0001?XE\u0019\nC <栮厠似栠厒佡栮桺厢栠Q\u0006W\u000e\nX,\u0001LS\u0013";
      h[16] = "hv\u0017o\u000b:mqGia桉桊叙栵叓厢厓伎佇栵\u0010Z<heFz_;8c";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友树树友何树友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23741;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/友树树友何树友何友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友树树友何树友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static String HE_DA_WEI() {
      return "解放村多种2队1144号";
   }
}
