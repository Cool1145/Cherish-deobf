package cn.cool.cherish.utils.helper;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.unsafe.UnsafeUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 友树何何树友何友树友 implements 何树友 {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[13];
   private static final String[] f = new String[13];
   private static String HE_WEI_LIN;

   private 友树何何树友何友树友(long a) {
      a = 友树何何树友何友树友.a ^ a;
      super();
      throw new UnsupportedOperationException(a<"v">(6856, 7578397737257463696L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-6273150778699749351L, -3496709416528728308L, MethodHandles.lookup().lookupClass()).a(124931333264058L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 46613508840062L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 'P';
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "Þ e\u0005zG\u008a\\\u0016\u0096m´WîAüBÇ,\u001aF.YÝ\u0017\u000bÛä¥Åü\u0089í<\u008cV¤\u001bhi\u0012d`^\u0083\u0006B¿\tÀÞáø¨¥\u0080\u0015\u0010ù*µoøÌúx\u008aâ\f\u0090\u0019r;¦\u001c\u0081¸\u0093\u0096¯Pßª\u0012\t(¡ZªËÆ\u008e·\u0012éãof\u00815[ÕØ#\u0090©M\n,{\u0013yÌ\u0083¬\u0014\u0083_\u0017\u009eÐÜVª\"á¶\"Ó/Æ»ú¿r7ÂØ`âe±!Q¨½º<Òõ_\u007fÎy\u0097°Î\nú4\r"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 161) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "Þ e\u0005zG\u008a\\\u0016\u0096m´WîAüBÇ,\u001aF.YÝ\u0017\u000bÛä¥Åü\u0089í<\u008cV¤\u001bhi\u0012d`^\u0083\u0006B¿\tÀÞáø¨¥\u0080\u0015\u0010ù*µoøÌúx\u008aâ\f\u0090\u0019r;¦\u001c\u0081¸\u0093\u0096¯Pßª\u0012\t(¡ZªËÆ\u008e·\u0012éãof\u00815[ÕØ#\u0090©M\n,{\u0013yÌ\u0083¬\u0014\u0083_\u0017\u009eÐÜVª\"á¶\"Ó/Æ»ú¿r7ÂØ`âe±!Q¨½º<Òõ_\u007fÎy\u0097°Î\nú4\r"
            .charAt(var4);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/helper/友树何何树友何友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'n' && var8 != 'A' && var8 != 194 && var8 != 206) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 164) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'F') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'n') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'A') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16173;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/helper/友树何何树友何友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/helper/友树何何树友何友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 22;
               case 1 -> 38;
               case 2 -> 28;
               case 3 -> 16;
               case 4 -> 44;
               case 5 -> 41;
               case 6 -> 29;
               case 7 -> 43;
               case 8 -> 56;
               case 9 -> 11;
               case 10 -> 45;
               case 11 -> 57;
               case 12 -> 27;
               case 13 -> 6;
               case 14 -> 48;
               case 15 -> 15;
               case 16 -> 51;
               case 17 -> 58;
               case 18 -> 37;
               case 19 -> 20;
               case 20 -> 54;
               case 21 -> 23;
               case 22 -> 59;
               case 23 -> 39;
               case 24 -> 8;
               case 25 -> 12;
               case 26 -> 9;
               case 27 -> 17;
               case 28 -> 35;
               case 29 -> 42;
               case 30 -> 34;
               case 31 -> 18;
               case 32 -> 49;
               case 33 -> 2;
               case 34 -> 7;
               case 35 -> 46;
               case 36 -> 32;
               case 37 -> 33;
               case 38 -> 55;
               case 39 -> 13;
               case 40 -> 26;
               case 41 -> 40;
               case 42 -> 14;
               case 43 -> 31;
               case 44 -> 62;
               case 45 -> 3;
               case 46 -> 63;
               case 47 -> 4;
               case 48 -> 24;
               case 49 -> 0;
               case 50 -> 1;
               case 51 -> 52;
               case 52 -> 25;
               case 53 -> 47;
               case 54 -> 60;
               case 55 -> 30;
               case 56 -> 5;
               case 57 -> 36;
               case 58 -> 53;
               case 59 -> 50;
               case 60 -> 61;
               case 61 -> 10;
               case 62 -> 21;
               default -> 19;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      e[0] = "h\u00116v\u0018QgQ{}\u0012Lb\fp;\u0002Jb\u0013k;\u001f[g\u000f}gYld\u000bya\u001eQe";
      e[1] = ":x\u000b4\u0011\u000b\u000e[\u0004t\\\u0000\u0004F\u0001)WF\f[\f/S\rOy\u0007>J\u0004\u0004\u000f";
      e[2] = void.class;
      f[2] = "java/lang/Void";
      e[3] = "\u0017\u0007\u0003\u0007QE\u0018GN\f[X\u001d\u001aEJSE\u0010\u001cA\u0001\u0010g\u001b\rX\b[";
      e[4] = boolean.class;
      f[4] = "java/lang/Boolean";
      e[5] = "yr4\bEgv2y\u0003OzsorE_|spiEBmvl\u007f\u0019\u0004參栋佉住桺叡佝发栍发";
      e[6] = "\u00060ysg\\\r?h<\fH\u000f4\u007ff _\u0002";
      e[7] = "H3\u001b\u0018\u001b8|\u0010\u0014XV3v\r\u0011\u0005]u~\u0010\u001c\u0003Y>=2\u0017\u0012@7vD";
      e[8] = "DZ\u001doC\"OU\f \",D^\bz";
      e[9] = "chQdD\u000bcnF\u0002dr4:\\?\u0018\u001fgbWd#H30Z\u007fC\u000fe4R\u0002";
      e[10] = "0WtZA_j\u001a}\u0014,V\u000b\u0017u]R]m\u0014-]\u0012?7NiZNY4\u0016i\u001a,";
      e[11] = "\tvC\u0013\u00145\tpTu-L^$NHH!\r|E\u0013s";
      e[12] = "T^ML\fq\u0007\rTUwgn\u000fLKG;\u001eH[]\u0019\n";
   }

   public static Field w(long a, Class fieldNames, String... a) {
      a = 友树何何树友何友树友.a ^ a;
      long ax = a ^ 37805459508334L;
      Module[] axx = b<"F">(-1306418488649303254L, (long)a);
      String[] var10000 = a;
      if (a >= 0L) {
         if (a == null) {
            throw new IllegalArgumentException(a<"v">(7216, 3232214933253344961L ^ a));
         }

         var10000 = a;
      }

      if (var10000.length != 0) {
         Exception failed = null;
         Class<?> currentClass = fieldNames;

         label78:
         while (true) {
            Class var17 = currentClass;

            label75:
            while (var17 != null) {
               String[] var10 = a;
               int var11 = ((Object[])a).length;
               int var12 = 0;

               label72: {
                  while (true) {
                     if (var12 < var11) {
                        String fieldName = var10[var12];
                        var18 = axx;
                        if (a <= 0L) {
                           break label72;
                        }

                        if (axx == null) {
                           break;
                        }

                        Module[] var19 = axx;
                        if (a > 0L) {
                           label59:
                           if (axx == null) {
                              try {
                                 Field f = currentClass.getDeclaredField(fieldName);
                                 f.setAccessible(true);
                                 var20 = f;
                                 if (a >= 0L) {
                                    if ((f.getModifiers() & 16) != 0) {
                                       long var10001 = UnsafeUtils.r(new Object[0]);
                                       Object[] var10004 = new Object[]{null, null, f.getModifiers() & -17};
                                       var10004[1] = var10001;
                                       var10004[0] = f;
                                       UnsafeUtils.M(var10004);
                                    }

                                    var20 = f;
                                 }
                              } catch (Exception var15) {
                                 failed = var15;
                                 break label59;
                              }

                              byte var21 = b<"F">(-1306225121863845647L, (long)a);
                              if (a > 0L) {
                                 if (var21 != 0) {
                                    return var20;
                                 }

                                 var21 = 3;
                              }

                              b<"F">(new Module[var21], -1306594696100679086L, (long)a);
                              return var20;
                           }

                           var12++;
                           var19 = axx;
                        }

                        if (var19 != null) {
                           continue;
                        }
                     }

                     var17 = currentClass.getSuperclass();
                     if (a < 0L) {
                        continue label75;
                     }

                     currentClass = var17;
                     break;
                  }

                  var18 = axx;
               }

               if (var18 != null) {
                  continue label78;
               }
               break;
            }

            throw new 友树何何树友何友树友.友友何友何友友树友何(failed, ax);
         }
      } else {
         throw new IllegalArgumentException(a<"v">(7216, 3232214933253344961L ^ a));
      }
   }

   private static String HE_JIAN_GUO() {
      return "何树友被何大伟克制了";
   }

   public static class 友友何友何友友树友何 extends RuntimeException implements 何树友 {
      private static final long serialVersionUID = 1L;
      private static final long a;
      private static final String b;
      private static String HE_DA_WEI;

      public 友友何友何友友树友何(Exception e, long a) {
         long var10000 = 友树何何树友何友树友.友友何友何友友树友何.a ^ a;
         super(b, e);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-5922159389787520799L, -117237956147244210L, MethodHandles.lookup().lookupClass()).a(238717644206656L);
         // $VF: monitorexit
         a = var10000;
         long var0 = a ^ 103132680654994L;
         Cipher var2;
         Cipher var4 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var3 = 1; var3 < 8; var3++) {
            var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
         }

         var4.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String var5 = a(var2.doFinal(">(çX}\u00036\u0084\tÆÈ\u001e¯\u0003\u0084HFæ\u001e\nl\u0017·A".getBytes("ISO-8859-1"))).intern();
         byte var10001 = -1;
         b = var5;
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static String HE_DA_WEI() {
         return "何炜霖230622200409390090";
      }
   }
}
