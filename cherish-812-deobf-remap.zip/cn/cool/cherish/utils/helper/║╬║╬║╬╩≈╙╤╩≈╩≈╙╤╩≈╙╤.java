package cn.cool.cherish.utils.helper;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 何何何树友树树友树友 implements 何树友 {
   public double 何树何何树何友何何何;
   public double 树友何何树友树友友友;
   public double 树友树树友何友友友友;
   private static final long a;
   private static final Object[] b = new Object[11];
   private static final String[] c = new String[11];
   private static int _何炜霖大狗叫 _;

   public 何何何树友树树友树友(int a, double x, byte a, int a, double y, double z) {
      long ax = ((long)a << 32 | (long)a << 56 >>> 32 | (long)a << 40 >>> 40) ^ 20512589905891L;
      super();
      a<"ã">(this, x, -7662462815893769652L, ax);
      a<"ã">(this, y, -7662381969408719292L, ax);
      a<"ã">(this, z, -7662035631695546917L, ax);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (cn.cool.cherish.module.何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = cn.cool.cherish.module.何树何何树何友何何何.a(615688722266566416L, -5013461223011966172L, MethodHandles.lookup().lookupClass()).a(257891088536309L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   @Override
   public boolean equals(Object obj) {
      Rotation.E();
      if (obj instanceof 何何何树友树树友树友) {
         ;
      }

      return false;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public double x(long a) {
      a = 20512589905891L ^ a;
      return Math.sqrt(
         a<"w">(this, -5601803486224575065L, (long)a) * a<"w">(this, -5601803486224575065L, (long)a)
            + a<"w">(this, -5601681958481419857L, (long)a) * a<"w">(this, -5601681958481419857L, (long)a)
            + a<"w">(this, -5601940334982491600L, (long)a) * a<"w">(this, -5601940334982491600L, (long)a)
      );
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public 何何何树友树树友树友 l(long a, double var3) {
      a = 20512589905891L ^ a;
      long var10001 = a ^ 34626197486634L;
      int ax = (int)((a ^ 34626197486634L) >>> 32);
      int axx = (int)((a ^ 34626197486634L) << 32 >>> 56);
      int var8 = (int)(var10001 << 40 >>> 40);
      return new 何何何树友树树友树友(
         ax,
         a<"w">(this, -7610947634700603003L, (long)a) * var3,
         (byte)axx,
         var8,
         a<"w">(this, -7610856957370956403L, (long)a) * var3,
         a<"w">(this, -7609967461181966830L, (long)a) * var3
      );
   }

   public double d(long a) {
      a = 20512589905891L ^ a;
      return a<"w">(this, -4505592112520473963L, (long)a);
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 22;
               case 1 -> 23;
               case 2 -> 53;
               case 3 -> 19;
               case 4 -> 21;
               case 5 -> 11;
               case 6 -> 49;
               case 7 -> 27;
               case 8 -> 50;
               case 9 -> 56;
               case 10 -> 26;
               case 11 -> 9;
               case 12 -> 20;
               case 13 -> 37;
               case 14 -> 8;
               case 15 -> 1;
               case 16 -> 57;
               case 17 -> 31;
               case 18 -> 55;
               case 19 -> 63;
               case 20 -> 60;
               case 21 -> 43;
               case 22 -> 39;
               case 23 -> 58;
               case 24 -> 30;
               case 25 -> 35;
               case 26 -> 17;
               case 27 -> 5;
               case 28 -> 15;
               case 29 -> 29;
               case 30 -> 6;
               case 31 -> 45;
               case 32 -> 38;
               case 33 -> 10;
               case 34 -> 34;
               case 35 -> 33;
               case 36 -> 54;
               case 37 -> 7;
               case 38 -> 12;
               case 39 -> 2;
               case 40 -> 40;
               case 41 -> 52;
               case 42 -> 32;
               case 43 -> 44;
               case 44 -> 42;
               case 45 -> 28;
               case 46 -> 59;
               case 47 -> 16;
               case 48 -> 62;
               case 49 -> 0;
               case 50 -> 51;
               case 51 -> 25;
               case 52 -> 36;
               case 53 -> 18;
               case 54 -> 46;
               case 55 -> 24;
               case 56 -> 41;
               case 57 -> 4;
               case 58 -> 48;
               case 59 -> 61;
               case 60 -> 13;
               case 61 -> 3;
               case 62 -> 47;
               default -> 14;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "QT/uL[^\u0014b~FF[Ii8V@[Vr8KQ^Jdd\r佡佧佯栐叝栲栥叹栫及";
      b[1] = double.class;
      c[1] = "java/lang/Double";
      b[2] = "\u00130O!i3\u001cp\u0002*c.\u0019-\tls(\u00192\u0012ln9\u001c.\u00040(\u000e\u001f*\u00006o3\u001e";
      b[3] = "wr\u0011e\")\u0002R\u001aj3f\u007fJ\tm:/\u0017";
      b[4] = "@Z,%c\u001dKU=j\u001f\u0004DO3)(4RX?49\u0018EU";
      b[5] = "3\tiMrj8\u0006x\u0002\u0013d3\r|X";
      b[6] = "\u0003I\u0003\u0005%6[JQ~标厍桸栳厮伣叝厍厢叩mGt#\u0006R\b\u000f~+\u0013";
      b[7] = "\u0011@\u0003[81Y\u0000\nME\u0012+BV\u000f#e\u001b\u0011H@!_";
      b[8] = "u\r]F}\u0016-\u000e\u000f=伛桷佊伳株你厅伳佊伳3\u0004,\u0003p\u0016VL&\u000be";
      b[9] = "cuF\u0007NC;v\u0014|\u001c;:,\u0018\u0003HA:&Y\u0005u\u0000;&WA\u000f\u00001gQ|";
      b[10] = ";!L\u000f6=c\"\u001et栔历伄伟栻厷栔历厚厁\"Mg(>:G\u0005m +";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/helper/何何何树友树树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'w' && var8 != 227 && var8 != 'p' && var8 != 244) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'A') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 195) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'w') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 227) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'p') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public void p(double a, long var3) {
      var3 = 20512589905891L ^ var3;
      a<"ã">(this, (double)a, -7323732224711063119L, var3);
   }

   public double g(long a) {
      a = 20512589905891L ^ a;
      return a<"w">(this, -7746331042995457010L, (long)a);
   }

   public 何何何树友树树友树友 w(long a, 何何何树友树树友树友 var3) {
      a = 20512589905891L ^ a;
      long ax = a ^ 88373990963867L;
      return this.W(
         -a<"w">(var3, 2987358101529398928L, (long)a), ax, -a<"w">(var3, 2987448706179119768L, (long)a), -a<"w">(var3, 2987777468887075079L, (long)a)
      );
   }

   public 何何何树友树树友树友 r(long a, double var3, double var5, double var7) {
      long ax = 20512589905891L ^ a ^ 22638504568595L;
      return this.W(-var3, ax, -var5, -var7);
   }

   public double E(何何何树友树树友树友 a, long vector3d) {
      vector3d = 20512589905891L ^ vector3d;
      return Math.sqrt(
         Math.pow(a<"w">(a, 5407784112793709801L, (long)vector3d) - a<"w">(this, 5407784112793709801L, (long)vector3d), 2.0)
            + Math.pow(a<"w">(a, 5407970373949708513L, (long)vector3d) - a<"w">(this, 5407970373949708513L, (long)vector3d), 2.0)
            + Math.pow(a<"w">(a, 5408756516313656190L, (long)vector3d) - a<"w">(this, 5408756516313656190L, (long)vector3d), 2.0)
      );
   }

   public void N(double a, long var3) {
      var3 = 20512589905891L ^ var3;
      a<"ã">(this, (double)a, 3882260523609953681L, var3);
   }

   public double N(long a) {
      a = 20512589905891L ^ a;
      return a<"w">(this, -4632666069775542192L, (long)a);
   }

   public 何何何树友树树友树友 W(double a, long var3, double var5, double var7) {
      var3 = 20512589905891L ^ var3;
      long var10001 = var3 ^ 31435618387527L;
      int ax = (int)((var3 ^ 31435618387527L) >>> 32);
      int axx = (int)((var3 ^ 31435618387527L) << 32 >>> 56);
      int var12 = (int)(var10001 << 40 >>> 40);
      return new 何何何树友树树友树友(
         ax,
         a<"w">(this, -1437360102108607512L, var3) + a,
         (byte)axx,
         var12,
         a<"w">(this, -1437266193823727648L, var3) + var5,
         a<"w">(this, -1436941846623630209L, var3) + var7
      );
   }

   public void K(double a, long var3) {
      var3 = 20512589905891L ^ var3;
      a<"ã">(this, (double)a, 1921738703394749774L, var3);
   }

   private static String HE_JIAN_GUO() {
      return "解放村多种2队1144号";
   }

   public 何何何树友树树友树友 G(何何何树友树树友树友 a, long vector) {
      vector = 20512589905891L ^ vector;
      long ax = vector ^ 48155745015340L;
      return this.W(
         a<"w">(a, -4196719396916403673L, (long)vector), ax, a<"w">(a, -4196519871694744017L, (long)vector), a<"w">(a, -4196848617217333840L, (long)vector)
      );
   }
}
