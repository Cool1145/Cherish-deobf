package cn.cool.cherish.utils.player;

import cn.cool.cherish.module.何友友树友何友何何何;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public enum RotationUtils$何友树何树树友何何何 implements  {
   何何何友树树树友树友,
   何友何友友友树友树树,
   树何树何友友树友树何,
   树树友树树何何何树树,
   树友何友友友友树树何,
   树友树友树友树何树树,
   何友树友树何友树树树,
   何友何何何友友何何友,
   友友友树友何友树友树;

   private static final long a;
   private static final Object[] b = new Object[13];
   private static final String[] c = new String[13];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // $VF: Failed to inline enum fields
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(5840548135220848375L, -1935637175279655279L, MethodHandles.lookup().lookupClass()).a(46985992121524L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 115608854423027L;
      long var11 = var9 ^ 97203263584597L;
      a();
      Cipher var1;
      Cipher var15 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var0 = new String[9];
      int var6 = 0;
      String var5 = "98\nkPCÙö\u0010]Û:w\u008c>ïNµÁ\u00061\u0012î;\u0095\u00101ÊVÈ´¨.*<s\u00ad\fnq¥Ø\b\u0003\u0092\u0016\u0016Ã\u0099\u0083{\u00101ÊVÈ´¨.*\u0004J½¾]¬z\u001d\u0010]Û:w\u008c>ïNg´'ö¨_\u008fP\u0010]Û:w\u008c>ïNº\u008bØ\u001f\u0098\u0088Þ>";
      byte var7 = 102;
      char var4 = '\b';
      int var14 = -1;

      label28:
      while (true) {
         String var16 = var5.substring(++var14, var14 + var4);
         byte var10001 = -1;

         while (true) {
            String var22 = a(var1.doFinal(var16.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var0[var6++] = var22;
                  if ((var14 += var4) >= var7) {
                     何何何友树树树友树友 = new RotationUtils$何友树何树树友何何何();
                     何友何友友友树友树树 = new RotationUtils$何友树何树树友何何何();
                     树何树何友友树友树何 = new RotationUtils$何友树何树树友何何何();
                     树树友树树何何何树树 = new RotationUtils$何友树何树树友何何何();
                     树友何友友友友树树何 = new RotationUtils$何友树何树树友何何何();
                     树友树友树友树何树树 = new RotationUtils$何友树何树树友何何何();
                     何友树友树何友树树树 = new RotationUtils$何友树何树树友何何何();
                     何友何何何友友何何友 = new RotationUtils$何友树何树树友何何何();
                     友友友树友何友树友树 = new RotationUtils$何友树何树树友何何何();
                     return;
                  }

                  var4 = var5.charAt(var14);
                  break;
               default:
                  var0[var6++] = var22;
                  if ((var14 += var4) < var7) {
                     var4 = var5.charAt(var14);
                     continue label28;
                  }

                  var5 = "ÂÍ4´\u0083°\u0003Ò\u00101ÊVÈ´¨.*dÊ\u0087é{IúZ";
                  var7 = 25;
                  var4 = '\b';
                  var14 = -1;
            }

            var16 = var5.substring(++var14, var14 + var4);
            var10001 = 0;
         }
      }
   }

   public static RotationUtils$何友树何树树友何何何 I(String a) {
      return Enum.valueOf(RotationUtils$何友树何树树友何何何.class, a);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'h' && var8 != 223 && var8 != 's' && var8 != 234) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'z') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 165) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'h') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 's') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 54;
               case 1 -> 24;
               case 2 -> 7;
               case 3 -> 61;
               case 4 -> 17;
               case 5 -> 51;
               case 6 -> 44;
               case 7 -> 36;
               case 8 -> 14;
               case 9 -> 46;
               case 10 -> 26;
               case 11 -> 6;
               case 12 -> 38;
               case 13 -> 5;
               case 14 -> 35;
               case 15 -> 28;
               case 16 -> 27;
               case 17 -> 3;
               case 18 -> 2;
               case 19 -> 60;
               case 20 -> 0;
               case 21 -> 58;
               case 22 -> 39;
               case 23 -> 4;
               case 24 -> 30;
               case 25 -> 11;
               case 26 -> 62;
               case 27 -> 20;
               case 28 -> 25;
               case 29 -> 41;
               case 30 -> 15;
               case 31 -> 10;
               case 32 -> 22;
               case 33 -> 56;
               case 34 -> 45;
               case 35 -> 31;
               case 36 -> 12;
               case 37 -> 43;
               case 38 -> 40;
               case 39 -> 32;
               case 40 -> 19;
               case 41 -> 13;
               case 42 -> 59;
               case 43 -> 57;
               case 44 -> 8;
               case 45 -> 16;
               case 46 -> 48;
               case 47 -> 18;
               case 48 -> 9;
               case 49 -> 52;
               case 50 -> 23;
               case 51 -> 21;
               case 52 -> 53;
               case 53 -> 49;
               case 54 -> 34;
               case 55 -> 33;
               case 56 -> 29;
               case 57 -> 37;
               case 58 -> 42;
               case 59 -> 1;
               case 60 -> 50;
               case 61 -> 63;
               case 62 -> 55;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "^rcH\r\u0019Q2.C\u0007\u0004To%\u0005\u0017\u0002Tp>\u0005\u0012\u001a\\e(YL$Rh,_\u000b\u0019SI9B\u000e\u0005\u0019佉历栺伷桧栬受优佾伷";
      b[1] = "pWuv\u00012Dtz6L9Ni\u007fkG\u007f^o\u007ft\\\u007f[wwaJ#\u0005IylN%BtxM[8Gh2位古桀佾栊标叓佺伄佾 ";
      b[2] = "3\u0005~yOx8\no6.v3\u0001kl";
      b[3] = "\u001a5o4\u0001sM/mR校叚根厒栕厑校佄根案\fh\\zFhf?Fx";
      b[4] = " >}FI\u0013w$\u007f 桩厺佇厙叝口厳桠栃伇\u001e\u001a\u0014\u001a|ctM\u000e\u0018";
      b[5] = "*\b(MkQ}\u0012*+伏佦位厯桒栲桋司栉厯K\u00116XvU!F,Z";
      b[6] = "\u0014kUT\f~CqW2栬栍叭栖栯佯佨佉样栖6\bQwH6\\_Ku";
      b[7] = "uq\u0007\n~g\"k\u0005l厄収厌栌厧伱厄栔厌栌dV#n),\u000e\u00019l";
      b[8] = "{Z\rkY?,@\u000f\r伽厖伜叽厭収桹厖桘栧n7\u00046'\u0007\u0004`\u001e4";
      b[9] = "$G=S_|s]?5桿佋标佾厝叶桿叕标佾^\u000f\u0002ux\u001a4X\u0018w";
      b[10] = "_m\u0012\u0001\u001dH\bw\u0010g佹叡桼及桨伺叧栻桼栐q]@A\u00030\u001b\nZC";
      b[11] = "E\u0003\u001f]8\u001b\u0012\u0019\u001d;作厲伢伺县栢参厲厼桾|\u0002j\u0003A\u0001\u001fE<\u001a\u0005";
      b[12] = "\u0005x\u001flk.Rb\u001d\n伏厇佢佁伡叉厑伙佢叟|06'Y%\u0016g,%";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/RotationUtils$何友树何树树友何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static RotationUtils$何友树何树树友何何何[] Q(long var0) {
      var0 = a ^ var0;
      return (RotationUtils$何友树何树树友何何何[])a<"s">(-4289210840215203487L, var0).clone();
   }

   private static String HE_DA_WEI() {
      return "何大伟：我要教育何炜霖";
   }
}
