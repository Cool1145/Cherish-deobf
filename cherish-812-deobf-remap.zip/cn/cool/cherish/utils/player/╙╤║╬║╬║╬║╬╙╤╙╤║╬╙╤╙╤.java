package cn.cool.cherish.utils.player;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public final class 友何何何何友友何友友 implements IWrapper, 何树友 {
   private static final long a;
   private static final Object[] b = new Object[28];
   private static final String[] c = new String[28];
   private static int _何建国230622195906030014 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3171932099145340439L, 8918189970366363102L, MethodHandles.lookup().lookupClass()).a(154599120790466L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public static boolean F(Direction a, BlockPos strict, long facing, boolean a) {
      facing = 51481420545339L ^ facing;
      boolean var10000 = a<"Ð">(-2658162130172864712L, (long)facing);
      HitResult hitResult = a<"N">(mc, -2657472038070850244L, (long)facing);
      int ax = var10000;
      if (hitResult != null && hitResult.getType() == a<"u">(-2658861827216656782L, (long)facing)) {
         BlockHitResult blockHitResult = (BlockHitResult)hitResult;
         var10000 = blockHitResult.getBlockPos().equals(strict);
         boolean var10001 = ax;
         if (facing > 0L) {
            if (ax) {
               if (!var10000) {
                  return false;
               }

               var10000 = (boolean)a;
            }

            var10001 = ax;
         }

         return !var10001 ? var10000 : !var10000 || blockHitResult.getDirection() == a;
      } else {
         return false;
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 32;
               case 1 -> 19;
               case 2 -> 25;
               case 3 -> 10;
               case 4 -> 45;
               case 5 -> 63;
               case 6 -> 13;
               case 7 -> 49;
               case 8 -> 3;
               case 9 -> 28;
               case 10 -> 40;
               case 11 -> 38;
               case 12 -> 27;
               case 13 -> 35;
               case 14 -> 21;
               case 15 -> 44;
               case 16 -> 17;
               case 17 -> 56;
               case 18 -> 55;
               case 19 -> 12;
               case 20 -> 59;
               case 21 -> 60;
               case 22 -> 14;
               case 23 -> 43;
               case 24 -> 34;
               case 25 -> 6;
               case 26 -> 53;
               case 27 -> 8;
               case 28 -> 57;
               case 29 -> 0;
               case 30 -> 46;
               case 31 -> 18;
               case 32 -> 15;
               case 33 -> 20;
               case 34 -> 1;
               case 35 -> 37;
               case 36 -> 24;
               case 37 -> 52;
               case 38 -> 39;
               case 39 -> 23;
               case 40 -> 22;
               case 41 -> 58;
               case 42 -> 61;
               case 43 -> 29;
               case 44 -> 47;
               case 45 -> 50;
               case 46 -> 4;
               case 47 -> 9;
               case 48 -> 33;
               case 49 -> 62;
               case 50 -> 7;
               case 51 -> 2;
               case 52 -> 54;
               case 53 -> 5;
               case 54 -> 30;
               case 55 -> 41;
               case 56 -> 26;
               case 57 -> 16;
               case 58 -> 11;
               case 59 -> 51;
               case 60 -> 36;
               case 61 -> 48;
               case 62 -> 31;
               default -> 42;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'N' && var8 != 'd' && var8 != 'u' && var8 != 'T') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'I') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 208) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'N') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'd') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public static HitResult b(long a, Rotation var2, double filterEntity, float a, Entity var6, Entity targetEntity, boolean expand) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent.toJava(AssignmentExprent.java:154)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:258)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: invokestatic cn/cool/cherish/utils/player/RotationUtils.q ()Z
      // 003: istore 12
      // 005: getstatic cn/cool/cherish/utils/player/友何何何何友友何友友.mc Lnet/minecraft/client/Minecraft;
      // 008: getfield net/minecraft/client/Minecraft.level Lnet/minecraft/client/multiplayer/ClientLevel;
      // 00b: ifnonnull 010
      // 00e: aconst_null
      // 00f: areturn
      // 010: getstatic cn/cool/cherish/utils/player/友何何何何友友何友友.mc Lnet/minecraft/client/Minecraft;
      // 013: invokevirtual net/minecraft/client/Minecraft.getFrameTime ()F
      // 016: fstore 13
      // 018: aload 6
      // 01a: fload 13
      // 01c: invokevirtual net/minecraft/world/entity/Entity.getEyePosition (F)Lnet/minecraft/world/phys/Vec3;
      // 01f: astore 14
      // 021: aload 2
      // 022: ldc2_w 50307048148560
      // 025: invokestatic cn/cool/cherish/utils/player/RotationUtils.e (Lcn/cool/cherish/utils/helper/Rotation;J)Lnet/minecraft/world/phys/Vec3;
      // 028: astore 15
      // 02a: aload 14
      // 02c: aload 15
      // 02e: getfield net/minecraft/world/phys/Vec3.x D
      // 031: dload 3
      // 032: dmul
      // 033: aload 15
      // 035: getfield net/minecraft/world/phys/Vec3.y D
      // 038: dload 3
      // 039: dmul
      // 03a: aload 15
      // 03c: getfield net/minecraft/world/phys/Vec3.z D
      // 03f: dload 3
      // 040: dmul
      // 041: invokevirtual net/minecraft/world/phys/Vec3.add (DDD)Lnet/minecraft/world/phys/Vec3;
      // 044: astore 16
      // 046: getstatic cn/cool/cherish/utils/player/友何何何何友友何友友.mc Lnet/minecraft/client/Minecraft;
      // 049: getfield net/minecraft/client/Minecraft.level Lnet/minecraft/client/multiplayer/ClientLevel;
      // 04c: new net/minecraft/world/level/ClipContext
      // 04f: dup
      // 050: aload 14
      // 052: aload 16
      // 054: getstatic net/minecraft/world/level/ClipContext$Block.OUTLINE Lnet/minecraft/world/level/ClipContext$Block;
      // 057: getstatic net/minecraft/world/level/ClipContext$Fluid.NONE Lnet/minecraft/world/level/ClipContext$Fluid;
      // 05a: aload 6
      // 05c: invokespecial net/minecraft/world/level/ClipContext.<init> (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/level/ClipContext$Block;Lnet/minecraft/world/level/ClipContext$Fluid;Lnet/minecraft/world/entity/Entity;)V
      // 05f: invokevirtual net/minecraft/client/multiplayer/ClientLevel.clip (Lnet/minecraft/world/level/ClipContext;)Lnet/minecraft/world/phys/BlockHitResult;
      // 062: astore 17
      // 064: aload 17
      // 066: invokevirtual net/minecraft/world/phys/BlockHitResult.getType ()Lnet/minecraft/world/phys/HitResult$Type;
      // 069: getstatic net/minecraft/world/phys/HitResult$Type.BLOCK Lnet/minecraft/world/phys/HitResult$Type;
      // 06c: if_acmpne 07c
      // 06f: aload 14
      // 071: aload 17
      // 073: invokevirtual net/minecraft/world/phys/BlockHitResult.getLocation ()Lnet/minecraft/world/phys/Vec3;
      // 076: invokevirtual net/minecraft/world/phys/Vec3.distanceTo (Lnet/minecraft/world/phys/Vec3;)D
      // 079: goto 07d
      // 07c: dload 3
      // 07d: dstore 18
      // 07f: dload 3
      // 080: dload 18
      // 082: invokestatic java/lang/Math.min (DD)D
      // 085: dconst_0
      // 086: dadd
      // 087: dstore 20
      // 089: new net/minecraft/world/phys/AABB
      // 08c: dup
      // 08d: aload 14
      // 08f: getfield net/minecraft/world/phys/Vec3.x D
      // 092: dload 20
      // 094: dsub
      // 095: aload 14
      // 097: getfield net/minecraft/world/phys/Vec3.y D
      // 09a: dload 20
      // 09c: dsub
      // 09d: aload 14
      // 09f: getfield net/minecraft/world/phys/Vec3.z D
      // 0a2: dload 20
      // 0a4: dsub
      // 0a5: aload 14
      // 0a7: getfield net/minecraft/world/phys/Vec3.x D
      // 0aa: dload 20
      // 0ac: dadd
      // 0ad: aload 14
      // 0af: getfield net/minecraft/world/phys/Vec3.y D
      // 0b2: dload 20
      // 0b4: dadd
      // 0b5: aload 14
      // 0b7: getfield net/minecraft/world/phys/Vec3.z D
      // 0ba: dload 20
      // 0bc: dadd
      // 0bd: invokespecial net/minecraft/world/phys/AABB.<init> (DDDDDD)V
      // 0c0: astore 22
      // 0c2: getstatic cn/cool/cherish/utils/player/友何何何何友友何友友.mc Lnet/minecraft/client/Minecraft;
      // 0c5: getfield net/minecraft/client/Minecraft.level Lnet/minecraft/client/multiplayer/ClientLevel;
      // 0c8: ldc_w net/minecraft/world/entity/Entity
      // 0cb: aload 22
      // 0cd: aload 6
      // 0cf: aload 7
      // 0d1: invokedynamic test (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;)Ljava/util/function/Predicate; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ (Ljava/lang/Object;)Z, cn/cool/cherish/utils/player/友何何何何友友何友友.j (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;)Z, (Lnet/minecraft/world/entity/Entity;)Z ]
      // 0d6: invokevirtual net/minecraft/client/multiplayer/ClientLevel.getEntitiesOfClass (Ljava/lang/Class;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;)Ljava/util/List;
      // 0d9: astore 23
      // 0db: aconst_null
      // 0dc: astore 24
      // 0de: aconst_null
      // 0df: astore 25
      // 0e1: dload 3
      // 0e2: dload 18
      // 0e4: invokestatic java/lang/Math.min (DD)D
      // 0e7: dstore 26
      // 0e9: dload 26
      // 0eb: dload 26
      // 0ed: dmul
      // 0ee: dstore 26
      // 0f0: aload 23
      // 0f2: invokeinterface java/util/List.iterator ()Ljava/util/Iterator; 1
      // 0f7: astore 28
      // 0f9: aload 28
      // 0fb: invokeinterface java/util/Iterator.hasNext ()Z 1
      // 100: ifeq 194
      // 103: aload 28
      // 105: invokeinterface java/util/Iterator.next ()Ljava/lang/Object; 1
      // 10a: checkcast net/minecraft/world/entity/Entity
      // 10d: astore 29
      // 10f: aload 29
      // 111: invokevirtual net/minecraft/world/entity/Entity.getBoundingBox ()Lnet/minecraft/world/phys/AABB;
      // 114: fload 5
      // 116: f2d
      // 117: invokevirtual net/minecraft/world/phys/AABB.inflate (D)Lnet/minecraft/world/phys/AABB;
      // 11a: astore 30
      // 11c: aload 30
      // 11e: aload 14
      // 120: aload 16
      // 122: invokevirtual net/minecraft/world/phys/AABB.clip (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)Ljava/util/Optional;
      // 125: astore 31
      // 127: aload 31
      // 129: invokevirtual java/util/Optional.isPresent ()Z
      // 12c: ifeq 18f
      // 12f: aload 31
      // 131: invokevirtual java/util/Optional.get ()Ljava/lang/Object;
      // 134: checkcast net/minecraft/world/phys/Vec3
      // 137: astore 32
      // 139: aload 14
      // 13b: aload 32
      // 13d: invokevirtual net/minecraft/world/phys/Vec3.distanceToSqr (Lnet/minecraft/world/phys/Vec3;)D
      // 140: dstore 33
      // 142: dload 33
      // 144: dload 26
      // 146: dcmpg
      // 147: ifge 18f
      // 14a: bipush 1
      // 14b: istore 35
      // 14d: iload 8
      // 14f: ifne 17e
      // 152: getstatic cn/cool/cherish/utils/player/友何何何何友友何友友.mc Lnet/minecraft/client/Minecraft;
      // 155: getfield net/minecraft/client/Minecraft.level Lnet/minecraft/client/multiplayer/ClientLevel;
      // 158: new net/minecraft/world/level/ClipContext
      // 15b: dup
      // 15c: aload 14
      // 15e: aload 32
      // 160: getstatic net/minecraft/world/level/ClipContext$Block.OUTLINE Lnet/minecraft/world/level/ClipContext$Block;
      // 163: getstatic net/minecraft/world/level/ClipContext$Fluid.NONE Lnet/minecraft/world/level/ClipContext$Fluid;
      // 166: aload 6
      // 168: invokespecial net/minecraft/world/level/ClipContext.<init> (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/level/ClipContext$Block;Lnet/minecraft/world/level/ClipContext$Fluid;Lnet/minecraft/world/entity/Entity;)V
      // 16b: invokevirtual net/minecraft/client/multiplayer/ClientLevel.clip (Lnet/minecraft/world/level/ClipContext;)Lnet/minecraft/world/phys/BlockHitResult;
      // 16e: astore 36
      // 170: aload 36
      // 172: invokevirtual net/minecraft/world/phys/BlockHitResult.getType ()Lnet/minecraft/world/phys/HitResult$Type;
      // 175: getstatic net/minecraft/world/phys/HitResult$Type.BLOCK Lnet/minecraft/world/phys/HitResult$Type;
      // 178: if_acmpne 17e
      // 17b: bipush 0
      // 17c: istore 35
      // 17e: iload 35
      // 180: ifeq 18f
      // 183: dload 33
      // 185: dstore 26
      // 187: aload 29
      // 189: astore 24
      // 18b: aload 32
      // 18d: astore 25
      // 18f: iload 12
      // 191: ifne 0f9
      // 194: aload 24
      // 196: ifnull 1a5
      // 199: new net/minecraft/world/phys/EntityHitResult
      // 19c: dup
      // 19d: aload 24
      // 19f: aload 25
      // 1a1: invokespecial net/minecraft/world/phys/EntityHitResult.<init> (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/Vec3;)V
      // 1a4: areturn
      // 1a5: iload 8
      // 1a7: ifne 1b2
      // 1aa: aload 17
      // 1ac: ifnull 1b2
      // 1af: aload 17
      // 1b1: areturn
      // 1b2: getstatic cn/cool/cherish/utils/player/友何何何何友友何友友.mc Lnet/minecraft/client/Minecraft;
      // 1b5: getfield net/minecraft/client/Minecraft.level Lnet/minecraft/client/multiplayer/ClientLevel;
      // 1b8: new net/minecraft/world/level/ClipContext
      // 1bb: dup
      // 1bc: aload 14
      // 1be: aload 16
      // 1c0: getstatic net/minecraft/world/level/ClipContext$Block.OUTLINE Lnet/minecraft/world/level/ClipContext$Block;
      // 1c3: getstatic net/minecraft/world/level/ClipContext$Fluid.NONE Lnet/minecraft/world/level/ClipContext$Fluid;
      // 1c6: aload 6
      // 1c8: invokespecial net/minecraft/world/level/ClipContext.<init> (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/level/ClipContext$Block;Lnet/minecraft/world/level/ClipContext$Fluid;Lnet/minecraft/world/entity/Entity;)V
      // 1cb: invokevirtual net/minecraft/client/multiplayer/ClientLevel.clip (Lnet/minecraft/world/level/ClipContext;)Lnet/minecraft/world/phys/BlockHitResult;
      // 1ce: areturn
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   public static HitResult h(Rotation a, double range, float a, Entity var4, long expand, Entity filterEntity) {
      long ax = (long)(51481420545339L ^ expand ^ 36427991560389L);
      return b(ax, a, range, (float)a, var4, filterEntity, false);
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      b[0] = "|\\SBcU|\\D\u001eoZf\u0017P\u0003|Pv\u0017W\u0004wO<oB\u000f=";
      b[1] = double.class;
      c[1] = "java/lang/Double";
      b[2] = "M*r*:\rM*ev6\u0002Waqk%\bGaja!\u0001OaEh>\u0014` hp2\u001cWkDh8\u0007H";
      b[3] = "PN-<T$_\u000e`7^9ZSkqN?ZLpqK'RYf-\u0015厀佦併佖伊台厀佦叫又";
      b[4] = "}\th\ft\u0005v\u0006yC\b\u001cy\u001cw\u0000?,o\u000b{\u001d.\u0000x\u0006";
      b[5] = "Z.\\ZB-Un\u0011QH0P3\u001a\u0017X6P,\u0001\u0017].X9\u0017K\u0003\u0010V4\u0013MD-W\u0015\u0006PA1";
      b[6] = boolean.class;
      c[6] = "java/lang/Boolean";
      b[7] = "\u0007Jjhp\u0001\u0007J}4|\u000e\u001d\u0001i)o\u0004\r\u0001r#k\r\u0005\u0001]*t\u0018*@p2x\u0010\u001d\u000bX*h\u0001\r";
      b[8] = "ma&tNKma1(BDw*%5QNg*\"2ZQ-L;.qGpq>.\u0007vzt7";
      b[9] = "LwX\u000b\njLwOW\u0006eV<[J\u0015oF<IK\u0013jVk\u0002`\twKfUv\u0002oGqXJ\u0015";
      b[10] = "(o\u0001\\\u001eF6g\u001b\u0013VF,m\u0003T_]l^\u0005XTZ!o\u0003X";
      b[11] = "\u0004b\u0002c|y\u0004b\u0015?pv\u001e)\u0015\"cuDC\u001f?ts\u001en\u0019#";
      b[12] = "Jr}1/\u001bJrjm#\u0014P9js+\u0017Jc'R+\u001cAt{~$\u0006";
      b[13] = "T<[\u0015i\u0010T<LIe\u001fNwXTv\u0015^w_S}\n\u0014\u0011FOV\u001cI,CO";
      b[14] = "(P,I\u001a(#_=\u0006{&(T9\\";
      b[15] = "\u001f\u0003/M7\u000e\u001b\\{T]!e~\u0001o]U\u001b\\+F8QD\b2";
      b[16] = "Z\u0006%\u007faG\t\u0019v\u001dqo\u0007Xz\".o7[z}xR]\u0013?#!";
      b[17] = ")B[ByEz]\b imt\u001c\u0004\u0010>mD\u001f\u0004@`P.WA\u001e9";
      b[18] = "tdN)i\u001f3?\u00015W3\u0010_7\n\u00119M:\u0014v5J&}O9)";
      b[19] = "H(i\u001f_YD;i\u0010&\u000e/i-F\u0019_/X%B\\\u0000@?t\u0003^\u000b";
      b[20] = "\u0015\u000e\u0003+\u001cpH\u0016\u0007(~c/^\u0017t@h\u0017Y\bq\u0017\n\u0015\u001a\t*\u001c2\u0012\u0005\f}~";
      b[21] = "Y`pF&;\t#u\u0018X\u001b>\u00191^&'\u0018da\u001d#y";
      b[22] = "QlB#\fG\u0012vT2tdj)[*N\u0019\u0013rTiJ#";
      b[23] = "Es\u0003\u0013\u0002\u0006\u0019g\f\u001c}\u0004,'E\u001eEZ,\u001dB\u001b\u0011\u0006\nv\f\u001aD\u0005";
      b[24] = "NT\u001bg/q\u001dKH\u0005?Y\u0013\nD5iY#\tDe6dIA\u0001;o";
      b[25] = "H\u001c&\f\u0011\u0007\u000b\u00060\u001di\u001asY?\u0005SY\n\u00020FWc";
      b[26] = "+\u0004+3#4}H sY\bQ\u007f\u001fNdsoD(42?d\u0004";
      b[27] = "e.zD+\u0018aq.]A8\u001aOD%\u007fG>uu@{\u0018jl";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/友何何何何友友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static boolean j(long a) {
      a = 51481420545339L ^ a;
      a<"Ð">(221730419533058014L, (long)a);
      HitResult movingObjectPosition = a<"N">(mc, 221472630251337008L, (long)a);
      return movingObjectPosition == null ? false : movingObjectPosition.getType() == a<"u">(222299452268703358L, (long)a);
   }

   public static HitResult u(long a, Rotation expand, double range, float a) {
      long ax = 51481420545339L ^ a ^ 67786663750247L;
      return b(ax, expand, range, 0.0F, mc.player, null, false);
   }

   public static boolean E(long a, Rotation rotation, BlockPos data, Direction a, boolean var5) {
      a = 51481420545339L ^ a;
      long ax = a ^ 3558348663914L;
      int axx = a<"Ð">(-6756411613566407144L, (long)a);
      if (mc.player != null && mc.level != null) {
         Vec3 eyesPosition = mc.player.getEyePosition(1.0F);
         Vec3 rotationVec = RotationUtils.e(rotation, ax);
         Vec3 vector = eyesPosition.add(
            a<"N">(rotationVec, -6755894650703773593L, (long)a) * 5.0,
            a<"N">(rotationVec, -6756515719259760488L, (long)a) * 5.0,
            a<"N">(rotationVec, -6755834646930772742L, (long)a) * 5.0
         );
         BlockHitResult rayTrace = mc.level
            .clip(new ClipContext(eyesPosition, vector, a<"u">(-6755814051484816381L, (long)a), a<"u">(-6756358291960035088L, (long)a), mc.player));
         if (rayTrace.getType() != a<"u">(-6756264350082394324L, (long)a)) {
            boolean var10000 = data.equals(rayTrace.getBlockPos());
            boolean var10001 = axx;
            if (a > 0L) {
               if (axx) {
                  if (!var10000) {
                     return false;
                  }

                  var10000 = var5;
               }

               var10001 = axx;
            }

            if (!var10001) {
               return var10000;
            }

            if (!var10000 || a.equals(rayTrace.getDirection())) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static HitResult Y(Rotation a, long a, double range) {
      long ax = 51481420545339L ^ a ^ 20502051046889L;
      return u(ax, a, range, 0.0F);
   }

   public static EntityHitResult L(Rotation a, double rotation, long var3) {
      var3 = 51481420545339L ^ var3;
      long ax = var3 ^ 111443362878897L;
      a<"Ð">(-4294396947527333821L, var3);
      HitResult hitResult = Y(a, ax, (double)rotation);
      if (hitResult == null) {
         return null;
      } else {
         return !(hitResult instanceof EntityHitResult) ? null : (EntityHitResult)hitResult;
      }
   }

   public static boolean W(Rotation a, long facing, Direction pos, BlockPos a, boolean var5) {
      facing = 51481420545339L ^ facing;
      long ax = facing ^ 7967780404809L;
      long axx = facing ^ 34859577894004L;
      boolean var10000 = a<"Ð">(6237285710358911659L, (long)facing);
      HitResult hitResult = 友树友友树何树友树友.T(4.5, a.getYaw(), a.l(ax), axx);
      int axxx = var10000;
      if (hitResult != null && hitResult.getType() == a<"u">(6236032684155550689L, (long)facing)) {
         BlockHitResult blockHitResult = (BlockHitResult)hitResult;
         var10000 = blockHitResult.getBlockPos().equals(a);
         boolean var10001 = axxx;
         if (facing >= 0L) {
            if (axxx) {
               if (!var10000) {
                  return false;
               }

               var10000 = var5;
            }

            var10001 = axxx;
         }

         return !var10001 ? var10000 : !var10000 || blockHitResult.getDirection() == pos;
      } else {
         return false;
      }
   }

   public static Boolean W(long a, Rotation var2, BlockPos pos, Direction rotation) {
      long ax = 51481420545339L ^ a ^ 110544756797284L;
      return W(var2, ax, rotation, pos, true);
   }

   public static Boolean K(Rotation a, BlockPos a, long var2) {
      var2 = 51481420545339L ^ var2;
      long ax = var2 ^ 85581161329053L;
      return W(a, ax, a<"u">(-7338010930853028311L, var2), a, false);
   }

   private static String HE_DA_WEI() {
      return "解放村多种2队1144号";
   }
}
