package cn.cool.cherish.utils.player;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public final class 何树何树友树树友树友 implements IWrapper, 何树友 {
   private static final long a;
   private static final Object[] b = new Object[27];
   private static final String[] c = new String[27];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-8013213200056861345L, -2858769608132005735L, MethodHandles.lookup().lookupClass()).a(42482995754619L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public static boolean F(Rotation a, BlockPos a, Direction var2, long rotation, boolean direction) {
      rotation = 何树何树友树树友树友.a ^ rotation;
      long ax = rotation ^ 17563149891263L;
      int[] axx = a<"j">(7715080280165014776L, (long)rotation);
      if (mc.player != null && mc.level != null) {
         Vec3 eyesPosition = mc.player.getEyePosition(1.0F);
         Vec3 rotationVec = RotationUtils.l(new Object[]{a, ax});
         Vec3 vector = eyesPosition.add(
            a<"p">(rotationVec, 7715090497166825492L, (long)rotation) * 5.0,
            a<"p">(rotationVec, 7714844864757630684L, (long)rotation) * 5.0,
            a<"p">(rotationVec, 7714754597259765047L, (long)rotation) * 5.0
         );
         BlockHitResult rayTrace = mc.level
            .clip(new ClipContext(eyesPosition, vector, a<"á">(7716875820410404172L, (long)rotation), a<"á">(7715288069324980878L, (long)rotation), mc.player));
         if (rayTrace.getType() != a<"á">(7714884804925010135L, (long)rotation)) {
            boolean var10000 = a.equals(rayTrace.getBlockPos());
            int[] var10001 = axx;
            if (rotation > 0L) {
               if (axx == null) {
                  if (!var10000) {
                     return false;
                  }

                  var10000 = (boolean)direction;
               }

               var10001 = axx;
            }

            if (var10001 != null) {
               return var10000;
            }

            if (!var10000 || var2.equals(rayTrace.getDirection())) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static HitResult I(long a, Rotation range, double var3) {
      long ax = 何树何树友树树友树友.a ^ a ^ 79573462179367L;
      return R(range, ax, var3, 0.0F);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 12;
               case 1 -> 62;
               case 2 -> 58;
               case 3 -> 32;
               case 4 -> 0;
               case 5 -> 3;
               case 6 -> 49;
               case 7 -> 36;
               case 8 -> 52;
               case 9 -> 8;
               case 10 -> 9;
               case 11 -> 53;
               case 12 -> 18;
               case 13 -> 51;
               case 14 -> 33;
               case 15 -> 42;
               case 16 -> 29;
               case 17 -> 39;
               case 18 -> 38;
               case 19 -> 60;
               case 20 -> 56;
               case 21 -> 44;
               case 22 -> 61;
               case 23 -> 37;
               case 24 -> 7;
               case 25 -> 16;
               case 26 -> 22;
               case 27 -> 59;
               case 28 -> 35;
               case 29 -> 55;
               case 30 -> 41;
               case 31 -> 43;
               case 32 -> 63;
               case 33 -> 15;
               case 34 -> 20;
               case 35 -> 24;
               case 36 -> 25;
               case 37 -> 5;
               case 38 -> 47;
               case 39 -> 40;
               case 40 -> 2;
               case 41 -> 13;
               case 42 -> 1;
               case 43 -> 50;
               case 44 -> 28;
               case 45 -> 57;
               case 46 -> 10;
               case 47 -> 6;
               case 48 -> 11;
               case 49 -> 14;
               case 50 -> 31;
               case 51 -> 17;
               case 52 -> 23;
               case 53 -> 30;
               case 54 -> 48;
               case 55 -> 26;
               case 56 -> 4;
               case 57 -> 21;
               case 58 -> 19;
               case 59 -> 34;
               case 60 -> 45;
               case 61 -> 46;
               case 62 -> 27;
               default -> 54;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'p' && var8 != 's' && var8 != 225 && var8 != 'X') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 200) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'j') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'p') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 's') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 225) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static HitResult s(Rotation a, long throughWalls, double var3, float var5, Entity rotation, Entity expand, boolean filterEntity) {
      throughWalls = (boolean)(何树何树友树树友树友.a ^ throughWalls);
      long ax = throughWalls ^ 57037099198429L;
      a<"j">(8823471436084366746L, (long)throughWalls);
      if (mc.level == null) {
         return null;
      } else {
         float partialTicks = mc.getFrameTime();
         Vec3 eyePosition = rotation.getEyePosition(partialTicks);
         Vec3 lookVector = RotationUtils.l(new Object[]{a, ax});
         Vec3 targetVec = eyePosition.add(
            a<"p">(lookVector, 8823604764003060086L, (long)throughWalls) * 4.5,
            a<"p">(lookVector, 8823289035580905406L, (long)throughWalls) * var3,
            a<"p">(lookVector, 8823233677602124885L, (long)throughWalls) * var3
         );
         BlockHitResult blockHit = mc.level
            .clip(
               new ClipContext(
                  eyePosition, targetVec, a<"á">(8824211427953404974L, (long)throughWalls), a<"á">(8822562364062356460L, (long)throughWalls), rotation
               )
            );
         double blockDistance = blockHit.getType() == a<"á">(8823608764962195014L, (long)throughWalls) ? eyePosition.distanceTo(blockHit.getLocation()) : var3;
         double expandedRange = Math.min(var3, blockDistance) + 0.0;
         AABB searchBox = new AABB(
            a<"p">(eyePosition, 8823604764003060086L, (long)throughWalls) - expandedRange,
            a<"p">(eyePosition, 8823289035580905406L, (long)throughWalls) - expandedRange,
            a<"p">(eyePosition, 8823233677602124885L, (long)throughWalls) - expandedRange,
            a<"p">(eyePosition, 8823604764003060086L, (long)throughWalls) + expandedRange,
            a<"p">(eyePosition, 8823289035580905406L, (long)throughWalls) + expandedRange,
            a<"p">(eyePosition, 8823233677602124885L, (long)throughWalls) + expandedRange
         );
         List<Entity> entities = mc.level.getEntitiesOfClass(Entity.class, searchBox, ex -> {
            long axx = 何树何树友树树友树友.a ^ 24828329453964L;
            a<"j">(-7513556838696902573L, axx);
            return ex != rotation && (expand == null || ex == expand) && a<"á">(-7513783271475560041L, axx).test(ex) && ex.isPickable();
         });
         Entity pointedEntity = null;
         Vec3 hitVec = null;
         double closestDistance = Math.min(var3, blockDistance);
         closestDistance *= closestDistance;
         Iterator var28 = entities.iterator();
         Entity var10000;
         if (var28.hasNext()) {
            var10000 = (Entity)var28.next();
         } else {
            var10000 = pointedEntity;
            if (throughWalls >= 0L) {
               if (pointedEntity != null) {
                  return new EntityHitResult(pointedEntity, hitVec);
               }

               return !filterEntity && blockHit != null
                  ? blockHit
                  : mc.level
                     .clip(
                        new ClipContext(
                           eyePosition, targetVec, a<"á">(8824211427953404974L, (long)throughWalls), a<"á">(8822562364062356460L, (long)throughWalls), rotation
                        )
                     );
            }
         }

         while (true) {
            Entity e = var10000;
            AABB entityBox = e.getBoundingBox().inflate(var5);
            Optional<Vec3> intercept = entityBox.clip(eyePosition, targetVec);
            var39 = intercept.isPresent();
            if (throughWalls <= 0L) {
               break;
            }

            if (var39) {
               Vec3 interceptPoint = intercept.get();
               double distSq = eyePosition.distanceToSqr(interceptPoint);
               if (distSq < closestDistance) {
                  boolean canHit = true;
                  if (!filterEntity) {
                     BlockHitResult wallCheck = mc.level
                        .clip(
                           new ClipContext(
                              eyePosition,
                              interceptPoint,
                              a<"á">(8824211427953404974L, (long)throughWalls),
                              a<"á">(8822562364062356460L, (long)throughWalls),
                              rotation
                           )
                        );
                     if (wallCheck.getType() == a<"á">(8823608764962195014L, (long)throughWalls)) {
                        canHit = false;
                     }
                  }

                  if (canHit) {
                     closestDistance = distSq;
                     pointedEntity = e;
                     hitVec = interceptPoint;
                  }
               }
            }

            var10000 = pointedEntity;
            if (throughWalls >= 0L) {
               if (pointedEntity != null) {
                  return new EntityHitResult(pointedEntity, hitVec);
               }

               var39 = (boolean)filterEntity;
               break;
            }
         }

         return !var39 && blockHit != null
            ? blockHit
            : mc.level
               .clip(
                  new ClipContext(
                     eyePosition, targetVec, a<"á">(8824211427953404974L, (long)throughWalls), a<"á">(8822562364062356460L, (long)throughWalls), rotation
                  )
               );
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static boolean d(long a, Direction pos, BlockPos strict, boolean a) {
      a = 何树何树友树树友树友.a ^ a;
      int[] var10000 = a<"j">(5966785486163305767L, (long)a);
      HitResult hitResult = a<"p">(mc, 5966758482197506955L, (long)a);
      int[] ax = var10000;
      if (hitResult != null && hitResult.getType() == a<"á">(5966920002911956731L, (long)a)) {
         BlockHitResult blockHitResult = (BlockHitResult)hitResult;
         boolean var10 = blockHitResult.getBlockPos().equals(strict);
         int[] var10001 = ax;
         if (a >= 0L) {
            if (ax == null) {
               if (!var10) {
                  return false;
               }

               var10 = (boolean)a;
            }

            var10001 = ax;
         }

         return var10001 != null ? var10 : !var10 || blockHitResult.getDirection() == pos;
      } else {
         return false;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/何树何树友树树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "\u0019E\u0017\f=`\u0016\u0005Z\u00077}\u0013XQA'{\u0013GJA\"c\u001bR\\\u001d|佚桫佾栨厤桃栞厱栺史";
      b[1] = "ILZ>\t^BCKquGMYE2Bw[NI/S[LC";
      b[2] = "\u0011\u007f|B=j\u0011\u007fk\u001e1e\u000b4\u007f\u0003\"o\u001b4x\u0004)pQRa\u0018\u0002f\fod\u0018tW\u0006jm";
      b[3] = "6`\u0019`cy6`\u000e<ov,+\u001a!||<+\u0001+xu4+.\"g`\u001bj\u0003:kh,!+\"{y<";
      b[4] = "M\u0007ly@*M\u0007{%L%WLo8_/GLt2[&OL[;D3`\rv#H;WFZ;B H";
      b[5] = "'\u000f\u0017[YW'\u000f\u0000\u0007UX=D\u0014\u001aFR-D\u0013\u001dMMg<\u0006\u0016\u0007";
      b[6] = double.class;
      c[6] = "java/lang/Double";
      b[7] = "rg`_QH}'-T[Uxz&\u0012KSxe=\u0012NKpp+N\u0010u~}/HWH\u007f\\:URT";
      b[8] = "t;";
      b[9] = "h\u0001\u0013\u001e\u0019Gh\u0001\u0004B\u0015HrJ\u0004_\u0006K( \u000eB\u0011Mr\r\b^";
      b[10] = "0\u0019(j|j0\u0019?6pe*R++co:R9*ej*\u0005r\u0001\u007fw7\b%\u0017to;\u001f(+c";
      b[11] = "=BViN\u0000#JL&\u0006\u00009@Ta\u000f\u001bysRm\u0004\u001c4BTm";
      b[12] = ":{_6<&:{Hj0) 0Ht8*:j\u0005U8!1}Yy7;";
      b[13] = "L\u000fQ\u0019&YL\u000fFE*VVDRX9\\FDU_2C\f\"LC\u0019UQ\u001fIC";
      b[14] = "\u0004Q\u007f+=\r\u000f^nd\\\u0003\u0004Uj>";
      b[15] = "F\u0006Q\fJx\u0006MRK)\u0002 kg2o\b}\f\u0012\u0001V&@LY\u0002\u0011";
      b[16] = "nSZDhE5@\u0003 {*qCKFxOu@N mCvLYEi@s*";
      b[17] = "&po\u0013\u001f\rt%'\u001c~\u001bMx'LNLMH!\t\u0015\u001akwpK\u0014I";
      b[18] = "o\\A\u00008N=\t\t\u000fYX\u0004T\t_i\u000e\u0004d\u000f\u001a2Y\"[^X3\n";
      b[19] = "ez|\u0000/Nf1,S\u0015d\u001dZ\u001do,Zfn|\u0000/\u00116=";
      b[20] = "=\u0017i`]|b\u0003yl0`Z@/6\u000f1Zq'iTd5\u0014fhQ|";
      b[21] = "/S\u000ef\u001c\nqB[p`+\u0012\u0004Ri[\u0014,H\u0012{Zm";
      b[22] = "m\u000bk4^!?^#;?7\u0006\u0003#k\u0000h\u00063%.T6 \ftlUe";
      b[23] = "6}\u007f\u0010Q|56/CkYKA\u000e<k*t<*E\u0004)?ly";
      b[24] = "c6l'*\u001f$67\"\u0016+\u001e\t\u001b\u0019,\u0014cqjkk\u00148t";
      b[25] = "9\u000b9H\u0001JxW'R?n_n|RDL9\u0017=\u000eZV";
      b[26] = "\u0019\n<\u0018\u001e\u0002YQzZ{\tq[~^CWqay\u0013\u001c\u000e]\f'\u0019F\u001d";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public static Boolean o(long a, Rotation var2, BlockPos pos) {
      a = 何树何树友树树友树友.a ^ a;
      long ax = a ^ 41569993850068L;
      return P(var2, ax, a<"á">(-2602139640056809797L, (long)a), pos, false);
   }

   public static Boolean t(Rotation a, BlockPos pos, Direction facing, long a) {
      long ax = 何树何树友树树友树友.a ^ a ^ 20560445322509L;
      return P(a, ax, facing, pos, true);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static EntityHitResult E(long a, Rotation var2, double a) {
      a = 何树何树友树树友树友.a ^ a;
      long ax = a ^ 103226293173837L;
      a<"j">(-2868477705643364392L, (long)a);
      HitResult hitResult = I(ax, var2, (double)a);
      if (hitResult == null) {
         return null;
      } else {
         return !(hitResult instanceof EntityHitResult) ? null : (EntityHitResult)hitResult;
      }
   }

   public static boolean N(long a) {
      a = 何树何树友树树友树友.a ^ a;
      a<"j">(-5476008961272806424L, (long)a);
      HitResult movingObjectPosition = a<"p">(mc, -5476053700375179964L, (long)a);
      return movingObjectPosition == null ? false : movingObjectPosition.getType() == a<"á">(-5475872242246121420L, (long)a);
   }

   public static boolean P(Rotation a, long facing, Direction var3, BlockPos strict, boolean rotation) {
      facing = 何树何树友树树友树友.a ^ facing;
      long ax = facing ^ 40168514396745L;
      long axx = facing ^ 46634321802295L;
      int[] var10000 = a<"j">(-2808153937687941394L, (long)facing);
      HitResult hitResult = 树友友何树友树树树何.q(4.5, a.getYaw(), axx, a.J(new Object[]{ax}));
      int[] axxx = var10000;
      if (hitResult != null && hitResult.getType() == a<"á">(-2808017222990305998L, (long)facing)) {
         BlockHitResult blockHitResult = (BlockHitResult)hitResult;
         boolean var15 = blockHitResult.getBlockPos().equals(strict);
         int[] var10001 = axxx;
         if (facing > 0L) {
            if (axxx == null) {
               if (!var15) {
                  return false;
               }

               var15 = (boolean)rotation;
            }

            var10001 = axxx;
         }

         return var10001 != null ? var15 : !var15 || blockHitResult.getDirection() == var3;
      } else {
         return false;
      }
   }

   public static HitResult R(Rotation a, long expand, double a, float range) {
      long ax = (long)(何树何树友树树友树友.a ^ expand ^ 74507270077467L);
      return s(a, ax, (double)a, 0.0F, mc.player, null, false);
   }

   public static HitResult Q(Rotation a, double expand, float range, Entity var4, long filterEntity, Entity var7) {
      long ax = 何树何树友树树友树友.a ^ filterEntity ^ 37251512073559L;
      return s(a, ax, (double)expand, (float)range, var4, var7, false);
   }

   private static String HE_DA_WEI() {
      return "何大伟：我要教育何炜霖";
   }
}
