package cn.cool.cherish.utils.player;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.helper.何何何树友树树友树友;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.platform.InputConstants.Key;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class 友树友友树何树友树友 implements IWrapper, 何树友 {
   private static String[] 树何何何何何树友树友;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[33];
   private static final String[] e = new String[33];
   private static int _解放村多种2队1144号 _;

   private 友树友友树何树友树友(long a) {
      long var10000 = 91424490921566L ^ a;
      super();
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-1875670302507992053L, -559709130125134519L, MethodHandles.lookup().lookupClass()).a(189804847304742L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (T() == null) {
         T(new String[1]);
      }

      Cipher var0;
      Cipher var2 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(4362782236869L << var1 * 8 >>> 56);
      }

      var2.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var3 = b(
            var0.doFinal(
               "]\u0002öéO9Î\u008a\u0087©¨A\u0014\u0098n\u0095Y\u0083¨R\u007f[%½\t\u0007GPhA\u009c\u00848\u008ar!\u008fî\u001eL\u0018F\u0018pO\u0013\u001a\u009bêå`\u00ad\u009f.Îd"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      byte var10001 = -1;
      b = var3;
   }

   public static boolean J(long a) {
      boolean var10000 = RotationUtils.q();
      int i = 0;
      int ax = var10000;
      var10000 = mc.level.getCollisions(mc.player, mc.player.getBoundingBox().move(0.0, 0.0, 0.0)).iterator().hasNext();
      if (ax) {
         if (!ax) {
            return var10000;
         }

         if (var10000) {
            return false;
         }

         i++;
         var10000 = true;
      }

      return var10000;
   }

   public static boolean S(long var0) {
      long var3 = 91424490921566L ^ var0 ^ 1989041772446L;
      return k(mc.player.getX(), mc.player.getY(), var3, mc.player.getZ());
   }

   public static boolean V(long var0) {
      var0 = 91424490921566L ^ var0;
      return a<"Q">(mc.player.getAbilities(), -509936704078271656L, var0);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 8;
               case 1 -> 45;
               case 2 -> 34;
               case 3 -> 14;
               case 4 -> 41;
               case 5 -> 62;
               case 6 -> 5;
               case 7 -> 17;
               case 8 -> 27;
               case 9 -> 37;
               case 10 -> 59;
               case 11 -> 2;
               case 12 -> 31;
               case 13 -> 32;
               case 14 -> 19;
               case 15 -> 13;
               case 16 -> 36;
               case 17 -> 44;
               case 18 -> 6;
               case 19 -> 7;
               case 20 -> 46;
               case 21 -> 24;
               case 22 -> 52;
               case 23 -> 22;
               case 24 -> 3;
               case 25 -> 21;
               case 26 -> 9;
               case 27 -> 26;
               case 28 -> 29;
               case 29 -> 51;
               case 30 -> 11;
               case 31 -> 57;
               case 32 -> 23;
               case 33 -> 61;
               case 34 -> 35;
               case 35 -> 10;
               case 36 -> 16;
               case 37 -> 18;
               case 38 -> 60;
               case 39 -> 25;
               case 40 -> 39;
               case 41 -> 28;
               case 42 -> 63;
               case 43 -> 33;
               case 44 -> 48;
               case 45 -> 15;
               case 46 -> 47;
               case 47 -> 54;
               case 48 -> 0;
               case 49 -> 12;
               case 50 -> 40;
               case 51 -> 53;
               case 52 -> 4;
               case 53 -> 20;
               case 54 -> 55;
               case 55 -> 50;
               case 56 -> 49;
               case 57 -> 1;
               case 58 -> 56;
               case 59 -> 43;
               case 60 -> 38;
               case 61 -> 58;
               case 62 -> 30;
               default -> 42;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'Q' && var8 != 'x' && var8 != 162 && var8 != 207) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == '$') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 238) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'Q') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'x') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 162) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static Block b(Player a, long a) {
      return g(85526755286720L, BlockPos.containing(a.getX(), a.getY() - 1.0, a.getZ()));
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static Block s(double a, double var2, double var4, long var6) {
      long ax = 91424490921566L ^ var6 ^ 138778535351927L;
      return g(ax, BlockPos.containing((double)a, var2, var4));
   }

   public static boolean c(long a) {
      int ax = RotationUtils.O();
      if (mc.player != null && mc.level != null) {
         Vec3 playerPos = mc.player.position();
         BlockPos centralPointBehind = new BlockPos(
            (int)Math.floor(playerPos.x + Math.sin(Math.toRadians(mc.player.getYRot())) * 0.8),
            (int)Math.floor(playerPos.y),
            (int)Math.floor(playerPos.z + -Math.cos(Math.toRadians(mc.player.getYRot())) * 0.8)
         );
         if (mc.level.getBlockState(centralPointBehind).is(Blocks.LAVA)) {
            return false;
         } else {
            BlockPos pos = centralPointBehind.below();
            BlockState state = mc.level.getBlockState(pos);
            int var10000 = state.is(Blocks.LAVA);
            if (!ax) {
               if (var10000) {
                  return false;
               }

               var10000 = state.isAir();
            }

            if (!ax) {
               if (var10000) {
                  var10000 = pos.getY();
                  if (!ax) {
                     if (var10000 < mc.level.getMinBuildHeight()) {
                        return false;
                     }

                     var10000 = mc.level.getBlockState(pos.below()).isAir();
                  }

                  if (ax) {
                     return (boolean)var10000;
                  }

                  if (var10000 != 0) {
                     var10000 = pos.below().getY();
                     if (!ax) {
                        if (var10000 < mc.level.getMinBuildHeight()) {
                           return (boolean)0;
                        }

                        var10000 = mc.level.getBlockState(pos.below().below()).isAir();
                     }

                     if (ax) {
                        return (boolean)var10000;
                     }

                     if (var10000 == 0) {
                        return (boolean)1;
                     }

                     return (boolean)0;
                  }
               }

               var10000 = 1;
            }

            return (boolean)var10000;
         }
      } else {
         return true;
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/友树友友树何树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      c[0] = "H*\b\u0001\u0013QGjE\n\u0019LB7NL\tJB(UL\fRJ=C\u0010R叵栺厏叭桳伩栯叠桕叭";
      c[1] = " yj^\u0012\u000e+v{\u0011i\f9mlOS\u0010>}xpL\u00078yhVS\f\u000f`\u007fZL\u0016#wr";
      c[2] = "UC,F6zZ\u0003aM<g_^j\u000b,a_Aq\u000b)yWTgWwGYYcQ0zXxvL5f";
      c[3] = boolean.class;
      e[3] = "java/lang/Boolean";
      c[4] = "_rQ>3Y_rFb?VE9R\u007f,\\U9@~*YEn\u000b`2QHrW>\u001fRX{Ld7UB";
      c[5] = "}_Vyw!}_A%{.g\u0014U8h$w\u0014R?c;=lG4)";
      c[6] = double.class;
      e[6] = "java/lang/Double";
      c[7] = "t\u0003%\u0010Svt\u00032L_ynH&QLs~H=[HzvH3RQ|qH\u0013RQ|q\u0015";
      c[8] = "[\u000eTq,/[\u000eC-  AEW03*QEL:7#YEB3.%^Eb3.%^";
      c[9] = "\n_6{B[\n_!'NT\u0010\u00145:]^\u0000\u0014.0YW\b\u0014\u00019FB'U,!JJ\u0010\u001e\u00009@Q\u000f";
      c[10] = " `,6\u0004( `;j\b':+/w\u001b-*+4}\u001f$\"+\u001bt\u00001\rj6l\f9:!\u001et\u001c(*";
      c[11] = "./\u0017\u000e\u0003b./\u0000R\u000fm4d\u0000L\u0007n.>Mo\u001e\u007f)%\rS";
      c[12] = "`'h\u0012\u000bN`'\u007fN\u0007Azl\u007fP\u000fB`62w\u0003^C#lL\u000fIi";
      c[13] = "k#m\u0003a\u001fk#z_m\u0010qhzAe\u0013k27`e\u0018`%kLj\u0002";
      c[14] = "\u001cm\u0016\u0000V<iM\u001d\u000fGs\u0014U\u000e\bN:|";
      c[15] = void.class;
      e[15] = "java/lang/Void";
      c[16] = " tG(\u0002\u0002UTL'\u0013M(L_ \u001a\u0004@";
      c[17] = "x;9<:}s4(s[sx?,)";
      c[18] = "db2@V\u00144n/&Ykr=0LL\u0014?gm&LRcn!Y\u0001\b>\u0004";
      c[19] = "\u0018\u001c\u0000\u000fa9A\u0016]\b\f7\u007f\u001d\u0006L=g\u007f,\f\u001eh;VT\u0007O5#";
      c[20] = "C\u0016FR\u0015\nG\u001cR\u0007|Y/W\u0012^C\u0006/g\u0014\u000f\rZ\u0007\u000eV\u000eEN";
      c[21] = "`\u0002HAwid\b\\\u0014\u001e:\fC\u001cM.m\fs\u001a\u001co9$\u001aX\u001d'-";
      c[22] = "8\u0005**dPj\u0014|l\u0019y[%W\u0010_s\u0006GohbCh\u0015~>$";
      c[23] = "<`CUKTll^3q+<hQ\\GOm9\u0011J-B7oPWOM-bQ3";
      c[24] = "-%XMgNlfO\u001cY{\u0014dF\u0016=Ejo\u0012\u0019g<";
      c[25] = "\u001ea\u0004?\b7Nm\u0019Y2H\u001ei\u00166\u0004,O8V n";
      c[26] = "J\u001bb\fLj\u0013\u0011?\u000b!d-\u001adO\u00107-+n\u001dEh\u0004SeL\u0018p";
      c[27] = "]o^g\f\u0004\f2]if\u0001;e\u0006.XQ;T\u000f&Z\u0014\u00014V,\u0007\u0013";
      c[28] = "F=?,#\u0014\u001d/ez\u001eD+t>'%\u0014+O9xtN\u000512,{\u0014";
      c[29] = "(4$\u001d\u007fl,>0H\u0016?Dup\u0011&iDEv@g<l,4A/(";
      c[30] = "#\"uf\u0018\u0007zcj1&\rHo&n\u0017ZHS)`_\u0012d8x/\u001f\u001d";
      c[31] = "\u0005\u0003Dh\u000eTD@S90_<BZ3T_BI\u000e<\u000e&";
      c[32] = "%~[\u0000\u007f<~'\u0013\u0005C\u0006]\u0001ff|yj!\u0017\u001a' \"$";
   }

   public static boolean m(long var0) {
      var0 = 91424490921566L ^ var0;
      a<"î">(8977043531987915719L, var0);
      return mc.player.isInWater() || mc.player.isInLava();
   }

   public static Block o(double a, double var2, double var4) {
      return mc.level.getBlockState(new BlockPos((int)a, (int)var2, (int)var4)).getBlock();
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static boolean k(double a, double var2, long var4, double var6) {
      var4 = 91424490921566L ^ var4;
      boolean var10000 = a<"î">(-4982275746074049906L, var4);
      int i = (int)var2;
      int ax = var10000;
      if (i <= -1 && var4 >= 0L) {
         var10000 = true;
      } else {
         while (true) {
            var10000 = mc.level.getBlockState(new BlockPos((int)a, i, (int)var6)).isAir();
            boolean var10001 = ax;
            if (var4 > 0L) {
               if (ax) {
                  break;
               }

               var10001 = ax;
            }

            if (var10001) {
               return var10000;
            }

            if (!var10000) {
               return false;
            }

            i--;
            if (var4 >= 0L) {
               var10000 = true;
               break;
            }
         }
      }

      return var10000;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static int g(long a, LivingEntity a) {
      RotationUtils.O();
      int totalArmor = 0;
      Iterator var6 = a.getArmorSlots().iterator();
      if (var6.hasNext()) {
         ItemStack armorItem = (ItemStack)var6.next();
         if (armorItem.getItem() instanceof ArmorItem armor) {
            totalArmor = 0 + armor.getDefense();
         }
      }

      return totalArmor;
   }

   public static Block g(long a, BlockPos var2) {
      RotationUtils.q();
      return mc.level != null && mc.player != null ? mc.level.getBlockState(var2).getBlock() : null;
   }

   public static BlockHitResult g(Level a, BlockPos endVec, Vec3 world, Vec3 pos) {
      BlockState blockState = a.getBlockState(endVec);
      VoxelShape shape = blockState.getCollisionShape(a, endVec);
      return a.clipWithInteractionOverride(world, pos, endVec, shape, blockState);
   }

   public static boolean r(long a, double a, boolean height) {
      a = 91424490921566L ^ a;
      int ax = a<"î">(4461892021069861560L, (long)a);
      if (height) {
         AABB bb = mc.player.getBoundingBox().move(0.0, (double)(-a), 0.0);
         return !mc.level.getEntityCollisions(mc.player, bb).isEmpty();
      } else {
         int offset = 0;

         while (offset < a) {
            BlockPos pos = new BlockPos((int)mc.player.getX(), (int)(mc.player.getY() - offset), (int)mc.player.getZ());
            BlockState blockState = mc.level.getBlockState(pos);
            boolean var10000 = ax;
            if (a > 0L) {
               if (ax) {
                  if (blockState.isCollisionShapeFullBlock(mc.level, pos)) {
                     return true;
                  }

                  offset++;
               }

               var10000 = ax;
            }

            if (!var10000) {
               break;
            }
         }

         return false;
      }
   }

   public static void P(int a, boolean button, long state) {
      int ax = RotationUtils.O();
      Key keyBind = mc.options.keyAttack.getKey();
      Key var10000 = keyBind;
      if (!ax) {
         KeyMapping.set(keyBind, true);
         var10000 = keyBind;
      }

      KeyMapping.click(var10000);
   }

   public static Block H(long a, 何何何树友树树友树友 a) {
      long var10000 = 91424490921566L ^ a;
      long ax = 91424490921566L ^ a ^ 25072155759821L;
      long axx = 91424490921566L ^ a ^ 52181705458288L;
      long axxx = var10000 ^ 93301181753785L;
      long axxxx = var10000 ^ 5448105393341L;
      return s(a.N(axx), a.d(axxxx), a.g(axxx), ax);
   }

   public static String[] T() {
      return 树何何何何何树友树友;
   }

   public static void T(String[] var0) {
      树何何何何何树友树友 = var0;
   }

   public static HitResult T(double a, float blockReachDistance, float var3, long a) {
      RotationUtils.q();
      if (mc.player != null && mc.level != null) {
         Vec3 vec3 = mc.player.getEyePosition(1.0F);
         Vec3 vec31 = RotationUtils.e(new Rotation(21273681362686L, (float)blockReachDistance, 90.0F), 50307048148560L);
         Vec3 vec32 = vec3.add(vec31.x * 4.5, vec31.y * a, vec31.z * a);
         return mc.level.clip(new ClipContext(vec3, vec32, net.minecraft.world.level.ClipContext.Block.OUTLINE, Fluid.NONE, mc.player));
      } else {
         return null;
      }
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖230622200409390090";
   }

   public static Block O(double a, double var2, double var4, long var6) {
      Vec3 playerPos = mc.player.position();
      return o(playerPos.x + 0.0, playerPos.y + var2, playerPos.z + 0.0);
   }
}
