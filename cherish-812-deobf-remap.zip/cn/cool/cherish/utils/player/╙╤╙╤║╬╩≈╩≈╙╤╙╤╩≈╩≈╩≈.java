package cn.cool.cherish.utils.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.player.树友何何友何树何树友;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.phys.Vec3;

public final class 友友何树树友友树树树 implements IWrapper, 何树友 {
   public static final double 树友何何何友树何树树 = 0.221;
   public static final double 何友何树树何何友何树 = 1.3F;
   public static final double 友友树友树友友何树树 = 0.3F;
   public static final double 友友何何树友树何友友 = 0.4751131221719457;
   public static final double 友友何何友何树何何友 = 0.5203620003898759;
   public static final double[] 树树何树何友何何树树;
   private static int 何友何友友树友友何何;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[38];
   private static final String[] e = new String[38];
   private static String HE_WEI_LIN;

   private 友友何树树友友树树树(long a) {
      long var10000 = 113617036606694L ^ a;
      super();
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(1319277134426481527L, -3636503779525148532L, MethodHandles.lookup().lookupClass()).a(11426418677462L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (B() == 0) {
         b(35);
      }

      Cipher var0;
      Cipher var2 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(40885085092031L << var1 * 8 >>> 56);
      }

      var2.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var3 = b(
            var0.doFinal(
               "áþ,\u0093½C;[\u0081^O\u0082ñ|+s]\u008a¹îT\u001cS\u000bMýq\u0091ÑJó\u0088\u008b\u000eUØ1È\u0085ç\u0091y;J\u0087GpÖT\u001e_\u0006\u0088|p\u001c"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      byte var10001 = -1;
      b = var3;
      树树何树何友何何树树 = new double[]{1.0, 1.4304347400741908, 1.7347825295420372, 1.9217390955733897};
   }

   public static double B(long a, float var2, double moveStrafing, double a) {
      boolean ax;
      float forward;
      int var10000;
      label35: {
         label38: {
            ax = RotationUtils.q();
            var2 += 180.0F;
            forward = 1.0F;
            double var11;
            var10000 = (var11 = moveStrafing - 0.0) == 0.0 ? 0 : (var11 < 0.0 ? -1 : 1);
            if (ax) {
               if (var10000 < 0) {
                  forward = -0.5F;
                  if (ax) {
                     break label38;
                  }
               }

               double var12;
               var10000 = (var12 = moveStrafing - 0.0) == 0.0 ? 0 : (var12 < 0.0 ? -1 : 1);
            }

            if (!ax) {
               break label35;
            }

            if (var10000 > 0) {
               forward = 0.5F;
            }
         }

         double var13;
         var10000 = (var13 = -1.0 - 0.0) == 0.0 ? 0 : (var13 < 0.0 ? -1 : 1);
      }

      if (ax) {
         if (var10000 > 0) {
            var2 -= 90.0F * forward;
         }

         double var14;
         var10000 = (var14 = a - 0.0) == 0.0 ? 0 : (var14 < 0.0 ? -1 : 1);
      }

      if (var10000 < 0) {
         var2 += 90.0F * forward;
      }

      return Math.toRadians(var2);
   }

   public static int B() {
      z();

      try {
         return 58;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   public static double F(int a, int a, int a) {
      long ax = ((long)a << 48 | (long)a << 48 >>> 16 | (long)a << 32 >>> 32) ^ 113617036606694L;
      int var10000 = a<"Ù">(-4631205029072780019L, ax);
      float rotationYaw = mc.player.getYRot();
      int axx = (boolean)var10000;
      if (a<"ã">(a<"ã">(mc.player, -4631372151205372816L, ax), -4632867422196916837L, ax) < 0.0F) {
         rotationYaw += 180.0F;
      }

      float forward = 1.0F;
      float var10;
      var10000 = (var10 = a<"ã">(a<"ã">(mc.player, -4631372151205372816L, ax), -4632867422196916837L, ax) - 0.0F) == 0.0F ? 0 : (var10 < 0.0F ? -1 : 1);
      if (!axx) {
         if (var10000 < 0) {
            forward = -0.5F;
         }

         float var11;
         var10000 = (var11 = a<"ã">(a<"ã">(mc.player, -4631372151205372816L, ax), -4632867422196916837L, ax) - 0.0F) == 0.0F ? 0 : (var11 < 0.0F ? -1 : 1);
      }

      if (!axx) {
         if (var10000 > 0) {
            forward = 0.5F;
         }

         float var12;
         var10000 = (var12 = a<"ã">(a<"ã">(mc.player, -4631372151205372816L, ax), -4631109605821517445L, ax) - 0.0F) == 0.0F ? 0 : (var12 < 0.0F ? -1 : 1);
      }

      if (!axx) {
         if (var10000 > 0) {
            rotationYaw -= 90.0F * forward;
         }

         float var13;
         var10000 = (var13 = a<"ã">(a<"ã">(mc.player, -4631372151205372816L, ax), -4631109605821517445L, ax) - 0.0F) == 0.0F ? 0 : (var13 < 0.0F ? -1 : 1);
      }

      if (var10000 < 0) {
         rotationYaw += 90.0F * forward;
      }

      return Math.toRadians(rotationYaw);
   }

   public static boolean I(long var0) {
      RotationUtils.q();
      return mc.player != null && mc.level != null && (mc.player.input.forwardImpulse != 0.0 || mc.player.input.leftImpulse != 0.0);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 23;
               case 1 -> 63;
               case 2 -> 50;
               case 3 -> 39;
               case 4 -> 43;
               case 5 -> 61;
               case 6 -> 17;
               case 7 -> 19;
               case 8 -> 0;
               case 9 -> 24;
               case 10 -> 9;
               case 11 -> 49;
               case 12 -> 6;
               case 13 -> 18;
               case 14 -> 40;
               case 15 -> 45;
               case 16 -> 54;
               case 17 -> 15;
               case 18 -> 36;
               case 19 -> 22;
               case 20 -> 16;
               case 21 -> 52;
               case 22 -> 27;
               case 23 -> 56;
               case 24 -> 57;
               case 25 -> 26;
               case 26 -> 10;
               case 27 -> 58;
               case 28 -> 59;
               case 29 -> 60;
               case 30 -> 12;
               case 31 -> 33;
               case 32 -> 8;
               case 33 -> 13;
               case 34 -> 51;
               case 35 -> 20;
               case 36 -> 3;
               case 37 -> 21;
               case 38 -> 32;
               case 39 -> 35;
               case 40 -> 55;
               case 41 -> 31;
               case 42 -> 1;
               case 43 -> 28;
               case 44 -> 4;
               case 45 -> 62;
               case 46 -> 30;
               case 47 -> 47;
               case 48 -> 11;
               case 49 -> 42;
               case 50 -> 48;
               case 51 -> 7;
               case 52 -> 25;
               case 53 -> 38;
               case 54 -> 53;
               case 55 -> 37;
               case 56 -> 46;
               case 57 -> 2;
               case 58 -> 29;
               case 59 -> 14;
               case 60 -> 44;
               case 61 -> 5;
               case 62 -> 41;
               default -> 34;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static double e(long a) {
      a = 113617036606694L ^ a;
      int var10000 = a<"Ù">(4790304846150894948L, (long)a);
      float rotationYaw = mc.player.getYRot();
      int ax = (boolean)var10000;
      if (a<"ã">(a<"ã">(mc.player, 4788567474030748094L, (long)a), 4790379258061709397L, (long)a) < 0.0F) {
         rotationYaw += 180.0F;
      }

      float forward;
      boolean var10001;
      label52: {
         label51: {
            label56: {
               forward = 1.0F;
               float var9;
               var10000 = (var9 = a<"ã">(a<"ã">(mc.player, 4788567474030748094L, (long)a), 4790379258061709397L, (long)a) - 0.0F) == 0.0F
                  ? 0
                  : (var9 < 0.0F ? -1 : 1);
               var10001 = ax;
               if (a > 0L) {
                  if (ax) {
                     if (var10000 < 0) {
                        var8 = -0.5F;
                        if (a <= 0L) {
                           break label56;
                        }

                        forward = -0.5F;
                     }

                     float var10;
                     var10000 = (var10 = a<"ã">(a<"ã">(mc.player, 4788567474030748094L, (long)a), 4790379258061709397L, (long)a) - 0.0F) == 0.0F
                        ? 0
                        : (var10 < 0.0F ? -1 : 1);
                  }

                  var10001 = ax;
               }

               if (a < 0L) {
                  break label52;
               }

               if (!var10001) {
                  break label51;
               }

               if (var10000 > 0) {
                  forward = 0.5F;
               }

               var8 = a<"ã">(a<"ã">(mc.player, 4788567474030748094L, (long)a), 4788621042417929397L, (long)a);
            }

            float var11;
            var10000 = (var11 = var8 - 0.0F) == 0.0F ? 0 : (var11 < 0.0F ? -1 : 1);
         }

         var10001 = ax;
      }

      if (var10001) {
         if (var10000 > 0) {
            rotationYaw -= 90.0F * forward;
         }

         float var12;
         var10000 = (var12 = a<"ã">(a<"ã">(mc.player, 4788567474030748094L, (long)a), 4788621042417929397L, (long)a) - 0.0F) == 0.0F
            ? 0
            : (var12 < 0.0F ? -1 : 1);
      }

      if (var10000 < 0) {
         rotationYaw += 90.0F * forward;
      }

      return Math.toRadians(rotationYaw);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 227 && var8 != 201 && var8 != 'u' && var8 != 206) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 170) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 217) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 227) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 201) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public static void b(int var0) {
      何友何友友树友友何何 = var0;
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public static boolean n(long a, boolean a) {
      a = 113617036606694L ^ a;
      long ax = a ^ 134897582780376L;
      a<"Ù">(-74687321090816959L, (long)a);
      return T(ax);
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      c[0] = "5\rz\u001a&>5\rmF*1/Fy[9;?FkR-28\u001c y$5\u001e\u000ehQ(#(";
      c[1] = "8j\u001aH\u001es8j\r\u0014\u0012|\"!\u0019\t\u0001v2!\u000b\u0000\u0015\u007f5{@+\u001cx\u0013i\b\u0003\u0010n";
      c[2] = "*I'\u0017>J*I0K2E0\u00020U:F*X}I?B=I!\u0017\u001fL'M?i?B=I!";
      c[3] = "W|A~6JW|V\":EM7V<2FWm\u001b 7B@|G~\u0012MIlA";
      c[4] = "08\u0015K6\u0015?xX@<\b:%S\u0006,\u000e::H\u0006)\u00162/^Zw(<\"Z\\0\u0015=\u0003OA5\t";
      c[5] = boolean.class;
      e[5] = "java/lang/Boolean";
      c[6] = "\u001b\\pR6Q\u0014\u001c=Y<L\u0011A6\u001f,J\u0011^-\u001f)R\u0019K;Cw叵厳佧桏栠厒叵桩栣桏";
      c[7] = "'\u0015\u0013$'\u001d,\u001a\u0002kL\t.\u0011\u00151`\u001e#";
      c[8] = "Vsmf86Vsz:49L8n''3\\8|&!6Lo789>Askf\u0014=Qzp<<:K";
      c[9] = float.class;
      e[9] = "java/lang/Float";
      c[10] = "0|#\u0015,80|4I 7*7 T3=:7'S8\"pO2Xr";
      c[11] = double.class;
      e[11] = "java/lang/Double";
      c[12] = int.class;
      e[12] = "java/lang/Integer";
      c[13] = void.class;
      e[13] = "java/lang/Void";
      c[14] = ",Umr\u001dH,Uz.\u0011G6\u001ez0\u0019D,D7\u0011\u0019O'Sk=\u0016U";
      c[15] = "yr\u001alaqyr\r0m~c9\r.e}yc@\r|l~x\u00001";
      c[16] = "h\rA_:jh\rV\u00036erFV\u001d>fh\u001c\u001b:2zK\tE\u0001>ma";
      c[17] = "A\u0015";
      c[18] = "/D\u001d17|$K\f~Vr/@\b$";
      c[19] = "\u007f-\u0006S2=- \u000e1-U--Y\b{U\u0014c\u0019\u000erzm~\u001bX";
      c[20] = "\u0007bZ \t3UoRB\u0016[Ub\u0006sF[l,E}It\u00151G+";
      c[21] = "RR/\u000158\u001cV/AVh:\tgAi7:9b\u00029:\u0015_2\u0005+o";
      c[22] = "\u0017\u007f\"/zzY{\"o\u0019*\u007f$jo)}\u007f\u0014o,vxPr?+d-";
      c[23] = "CE8\u00029'N\u001dl@I\u0010\u007f\u0013~^7$@\u0012<\u0003sZ";
      c[24] = "wx=`*+.wbl\u0012y\u0019>:6,.~P\u0002<wm1wf8mq,";
      c[25] = ")R\u00014:S$\nUvJD\u0015\u0004Gh4P*\u0005\u00055p.$\n]ap\u0013i\u000fA3J";
      c[26] = "m/e!S-.}6/hSV)/+\u0016klj.'\u0013\u0014";
      c[27] = "qB In,uX<T\u001e&\u001c\u001eb\u0006#vupZ\bf4p\u001f&Zqq$";
      c[28] = ";\u0003$7K\u001fi\u000e,UTwi\u0003xd\u0005wPM;j\u000bX)P9<";
      c[29] = "\u0015XyD\rQ\u0018^5\u001ef\u0003+\u00052\u0016XS+4b^\u0001\u000b\u0011^7KX\u0006";
      c[30] = "<q\u007fo<b1)+-Lv\u0000*u30a})\u007f=s\u001f='&,2b>-(oL";
      c[31] = "vV7\u000302.W(\u0006J6\u001fShIqf\u001fhn\u0003#&7R-\u0002/#";
      c[32] = "\u001ct\u0013NyEE{LBA\u0017r2\u001d\u0018\u007fCr\u000b\u0017S(\u0007Z1TR$\u0002";
      c[33] = "\f9 &\u0012rB= fq\"dbhfAtdRm%\u001epK4=\"\f%";
      c[34] = "Sw,MH\u007fWm0P8u>+n\u0002\u0005%VEV\f@gR**^W\"\u0006";
      c[35] = "^\fRQ0:\u001d^\u0001_\u000bze\n\u0018[u|_I\u0019Wp\u0003";
      c[36] = "%-sL%\"p8*AH&\u001bl.\u0012yq\u001b]~K61 /o\u0013:'";
      c[37] = "\t4\b'\u001cz\u0004l\\el栞栬伏栫佅厯佚佨桋栫\u0018\u00077\u000f/\u000e)\u0000a\t?";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/友友何树树友友树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static void a(long var0) {
      RotationUtils.q();
      if (mc.player != null) {
         mc.player.setDeltaMovement(0.0, 0.0, 0.0);
      }
   }

   public static float p(long var0) {
      var0 = 113617036606694L ^ var0;
      a<"Ù">(-2837007130593747010L, var0);
      return mc.player != null && mc.level != null
         ? (float)Math.sqrt(
            a<"ã">(mc.player.getDeltaMovement(), -2833531949830951760L, var0) * a<"ã">(mc.player.getDeltaMovement(), -2833531949830951760L, var0)
               + a<"ã">(mc.player.getDeltaMovement(), -2833455533823213373L, var0) * a<"ã">(mc.player.getDeltaMovement(), -2833455533823213373L, var0)
         )
         : 0.0F;
   }

   public static double p(float a, float inputStrafe, long inputForward) {
      int var10000 = RotationUtils.q();
      float rotationYaw = mc.player.getYRot();
      int ax = (boolean)var10000;
      if (a < 0.0F) {
         rotationYaw += 180.0F;
      }

      float forward = 1.0F;
      float var9;
      var10000 = (var9 = a - 0.0F) == 0.0F ? 0 : (var9 < 0.0F ? -1 : 1);
      if (ax) {
         if (var10000 < 0) {
            forward = -0.5F;
         }

         float var10;
         var10000 = (var10 = a - 0.0F) == 0.0F ? 0 : (var10 < 0.0F ? -1 : 1);
      }

      if (ax) {
         if (var10000 > 0) {
            forward = 0.5F;
         }

         float var11;
         var10000 = (var11 = inputStrafe - 0.0F) == 0.0F ? 0 : (var11 < 0.0F ? -1 : 1);
      }

      if (ax) {
         if (var10000 > 0) {
            rotationYaw -= 70.0F * forward;
         }

         float var12;
         var10000 = (var12 = inputStrafe - 0.0F) == 0.0F ? 0 : (var12 < 0.0F ? -1 : 1);
      }

      if (var10000 < 0) {
         rotationYaw += 70.0F * forward;
      }

      return Math.toRadians(rotationYaw);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static int z() {
      return 何友何友友树友友何何;
   }

   public static double A(long var0) {
      var0 = 113617036606694L ^ var0;
      return Math.hypot(a<"ã">(mc.player.getDeltaMovement(), -8347291145684355019L, var0), a<"ã">(mc.player.getDeltaMovement(), -8347219127588809658L, var0));
   }

   public static void Y(double a, long speed, boolean a) {
      speed = 113617036606694L ^ speed;
      long ax = (long)(speed ^ 5615816889616L);
      long var10001 = (long)(speed ^ 58266986192171L);
      int axx = (int)((speed ^ 58266986192171L) >>> 48);
      int axxx = (int)((speed ^ 58266986192171L) << 16 >>> 48);
      int axxxx = (int)(var10001 << 32 >>> 32);
      a<"Ù">(6807177899792508096L, (long)speed);
      if (I(ax) || !a) {
         double yaw = F((char)axx, (char)axxx, axxxx);
         Vec3 currentMovement = mc.player.getDeltaMovement();
         double newMotionX = -Math.sin(yaw) * a;
         double newMotionZ = Math.cos(yaw) * a;
         mc.player.setDeltaMovement(newMotionX, a<"ã">(currentMovement, 6807527286043761317L, (long)speed), newMotionZ);
      }
   }

   public static void L(long var0) {
      RotationUtils.O();
      if (mc.player.isSprinting()) {
         mc.player.setSprinting(false);
      }

      try {
         KeyMapping.set(mc.options.keySprint.getKey(), false);
         mc.options.keySprint.setDown(false);
      } catch (Exception var2) {
      }
   }

   public static double M(long a) {
      double horizontalDistance;
      boolean useBaseModifiers;
      label46: {
         boolean var10000 = RotationUtils.O();
         useBaseModifiers = false;
         int ax = var10000;
         if (mc.player.isInWaterOrBubble()) {
            horizontalDistance = 0.105;
            if (!ax) {
               break label46;
            }
         }

         if (友树友友树何树友树友.m(136823318274765L)) {
            horizontalDistance = 0.11500000208616258;
            int depthStriderLevel = H(new Object[0]);
            if (depthStriderLevel > 0) {
               horizontalDistance = 0.11500000208616258 * 树树何树何友何何树树[depthStriderLevel];
               useBaseModifiers = true;
            }

            if (!ax) {
               break label46;
            }
         }

         if (mc.player.isCrouching()) {
            horizontalDistance = 0.0663000026345253;
            if (!ax) {
               break label46;
            }
         }

         horizontalDistance = 0.221;
         useBaseModifiers = true;
      }

      if (useBaseModifiers) {
         if (n(97347782869526L, false)) {
            horizontalDistance *= 1.3F;
         }

         MobEffectInstance speedEffect = mc.player.getEffect(MobEffects.MOVEMENT_SPEED);
         if (speedEffect != null && speedEffect.getDuration() > 0 && !Cherish.instance.getModuleManager().getModule(树友何何友何树何树友.class).isEnabled()) {
            double var14 = horizontalDistance * (1.0 + 0.2 * (speedEffect.getAmplifier() + 1));
         }

         mc.player.getEffect(MobEffects.MOVEMENT_SLOWDOWN);
         horizontalDistance = 0.29;
      }

      return horizontalDistance;
   }

   public static void W(long a, double var2) {
      if (I(112951582722913L)) {
         double yaw = F(0, 22367, 1227998042);
         mc.player.setDeltaMovement(-Math.sin(yaw) * 0.6, mc.player.getDeltaMovement().y, Math.cos(yaw) * var2);
      }
   }

   public static double H(double a, double var2, double var4) {
      return Math.max((double)a, Math.min(var2, var4));
   }

   public static int H(Object[] var0) {
      return EnchantmentHelper.getDepthStrider(mc.player);
   }

   public static boolean T(long var0) {
      var0 = 113617036606694L ^ var0;
      a<"Ù">(3298572256125741784L, var0);
      return Math.abs(a<"ã">(a<"ã">(mc.player, 3298919308677795330L, var0), 3298514624652480489L, var0)) >= 0.8F
         || Math.abs(a<"ã">(a<"ã">(mc.player, 3298919308677795330L, var0), 3299146669973922569L, var0)) >= 0.8F;
   }

   public static void T(long a, double var2, Entity var4) {
      a = 113617036606694L ^ a;
      long ax = a ^ 37075506995060L;
      long axx = a ^ 131338757319297L;
      if (I(ax)) {
         double yaw = e(axx);
         double motionY = a<"ã">(var4.getDeltaMovement(), -7774033895082487615L, (long)a);
         var4.setDeltaMovement(-Mth.sin((float)yaw) * var2, motionY, Mth.cos((float)yaw) * var2);
      }
   }

   private static String HE_SHU_YOU() {
      return "何建国230622195906030014";
   }

   public static void Q(long var0) {
      T(35559133210867L, A(134982036943051L), mc.player);
   }
}
