package cn.cool.cherish.utils;

import cn.cool.cherish.module.何树何何树何友何何何;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public final class 何友友树何何何何何友 extends ArrayList<树树友友树何友友何树> implements  {
   private static final long a;
   private static final Object[] b = new Object[6];
   private static final String[] c = new String[6];
   private static int _何大伟为什么要诈骗何炜霖 _;

   public 何友友树何何何何何友(long a) {
      a = 92446311044333L ^ a;
      super();
      this.add(a<"G">(3609574191519528611L, a));
      this.add(a<"G">(3609148311165601117L, a));
      this.add(a<"G">(3609527443182298185L, a));
      this.add(a<"G">(3609081470304347490L, a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-9218928104172055595L, -6241703314120019026L, MethodHandles.lookup().lookupClass()).a(158294818095000L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 240 && var8 != 'W' && var8 != 'G' && var8 != 219) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 217) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 220) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 240) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'W') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'G') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/何友友树何何何何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "k7/VbPdwb]hMa*i\u001bxKa5r\u001b栜栮參厒栐你叆叴佝案";
      b[1] = "cju\f\u001eBhedC\u007fLcn`\u0019";
      b[2] = "\u001e\u001eL$\u0011^\u0018E\b\\厽根厺口史企厽口厺佽1;@]\u0001OO=\u001b\u0019";
      b[3] = "Q[2m6\nW\u0000v\u0015桀伩佫厦厌栌伄厷佫桼Org\tN\n1t<M";
      b[4] = ")Afum'/\u001a\"\r佟伄桗厼栂栔佟伄桗厼\u001bj<$6\u0010elg`";
      b[5] = ".\u000fL\u0000\u0005H(T\bx厩栯伔史佬伥桳叵伔佬1\u001fTK1^O\u0019\u000f\u000f";
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 7;
               case 1 -> 4;
               case 2 -> 36;
               case 3 -> 19;
               case 4 -> 13;
               case 5 -> 25;
               case 6 -> 44;
               case 7 -> 24;
               case 8 -> 14;
               case 9 -> 27;
               case 10 -> 9;
               case 11 -> 31;
               case 12 -> 42;
               case 13 -> 0;
               case 14 -> 57;
               case 15 -> 58;
               case 16 -> 28;
               case 17 -> 12;
               case 18 -> 33;
               case 19 -> 26;
               case 20 -> 37;
               case 21 -> 21;
               case 22 -> 1;
               case 23 -> 61;
               case 24 -> 43;
               case 25 -> 18;
               case 26 -> 15;
               case 27 -> 2;
               case 28 -> 39;
               case 29 -> 20;
               case 30 -> 11;
               case 31 -> 17;
               case 32 -> 49;
               case 33 -> 50;
               case 34 -> 63;
               case 35 -> 45;
               case 36 -> 6;
               case 37 -> 53;
               case 38 -> 10;
               case 39 -> 54;
               case 40 -> 55;
               case 41 -> 40;
               case 42 -> 46;
               case 43 -> 29;
               case 44 -> 8;
               case 45 -> 23;
               case 46 -> 62;
               case 47 -> 16;
               case 48 -> 59;
               case 49 -> 22;
               case 50 -> 56;
               case 51 -> 41;
               case 52 -> 48;
               case 53 -> 30;
               case 54 -> 35;
               case 55 -> 3;
               case 56 -> 60;
               case 57 -> 38;
               case 58 -> 5;
               case 59 -> 51;
               case 60 -> 47;
               case 61 -> 34;
               case 62 -> 32;
               default -> 52;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String HE_DA_WEI() {
      return "何大伟：我要教育何炜霖";
   }
}
