package cn.cool.cherish.utils;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

public class 友树友树树何树何树何 implements 何树友 {
   public 友树友何友何友树何友 树友树树何何何友树友;
   public int 友友何树何树树友友树;
   public int 友何树友何树何何友树;
   public 树树何何何何何何何友 何树树友友友友友树何;
   public 树树友友树何友友何树 何何树何树何树友树友;
   public Set<Long> 友友何何何树何何树友;
   public Set<Long> 树何何何何友何友何树;
   private static final long a;
   private static final Object[] b = new Object[23];
   private static final String[] c = new String[23];
   private static String HE_WEI_LIN;

   public 友树友树树何树何树何(long a, 友树友何友何友树何友 var1, int var2, 树树何何何何何何何友 var3, 树树友友树何友友何树 var4) {
      a = 102136597401056L ^ a;
      super();
      a<"h">(this, 0, -5104558715762433956L, a);
      a<"i">(-5104388418350027012L, a);
      a<"h">(this, 1, -5102610911532288525L, a);
      a<"h">(this, new HashSet(), -5104440040035432620L, a);
      a<"h">(this, new HashSet(), -5102833839999489343L, a);
      a<"h">(this, var1, -5104644393814775946L, a);
      a<"h">(this, a<"ò">(this, -5102610911532288525L, a) + var2, -5102610911532288525L, a);
      a<"h">(this, var3, -5104758513006778578L, a);
      a<"h">(this, var4, -5104490572777568113L, a);
      if (a<"i">(-5102724313057879101L, a) == null) {
         a<"i">(false, -5104787320019015414L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(649578493463608445L, -6558067075515891161L, MethodHandles.lookup().lookupClass()).a(230300502974881L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 242 && var8 != 'h' && var8 != 'z' && var8 != 'J') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 240) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'i') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 242) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'h') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'z') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友树友树树何树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "90OikU6p\u0002baH3-\t$qN32\u0012$叏栫厑桏桰佟栕佯桋伋";
      b[1] = "\u0000l!zc[\u001ed;5\u001eK\u001e";
      b[2] = int.class;
      c[2] = "java/lang/Integer";
      b[3] = "\n#h\u001c\fa\u0005c%\u0017\u0006|\u0000>.Q\u0016z\u0000!5Q厨栟厢优厍伪厨栟似历";
      b[4] = boolean.class;
      c[4] = "java/lang/Boolean";
      b[5] = void.class;
      c[5] = "java/lang/Void";
      b[6] = "k5[0#\u0006du\u0016;)\u001ba(\u001d}9\u001da7\u0006}桝桸佝伎传伆伙似佝厐";
      b[7] = "\fbCm/`\u0003\"\u000ef%}\u0006\u007f\u0005 5{\u0006`\u001e 桑栞厤叇桼佛压叄伺栝";
      b[8] = "\u0017(3\u0019\"\u0015\u0018h~\u0012(\b\u001d5uT \u0015\u00103q\u001fc7\u001b\"h\u0016(";
      b[9] = "\u001c\f\"\u000e3U(/-N~^\"2(\u0013u\u0018*/%\u0015qSi\r.\u0004hZ\"{";
      b[10] = "g''?\u0010nl(6plwc283[Gu%4.Jkb(";
      b[11] = "cpZ\u001e\f@h\u007fKQmNctO\u000b";
      b[12] = ".OLV\u0014\u000frQ\u000bo桠佢佌佷伩厬伤叼佌栳tVCD-S\tU\u0010@r";
      b[13] = "\u0003BAUYe\u0006\u0019RB \b=FWAJ&T\u0013^YFZ";
      b[14] = "'\u0010BI^j{\u000e\u0005pZZ'M\u0005K\n*\u007f\u0012\u0010L3e \nAIC=\u007f\u001fFp";
      b[15] = "\u000ehoJ>\u0019Rv(s厐佴栨収伊桪伎佴史栔WIkCZi4\u0012+\u0018H";
      b[16] = "~<=\u0006m9=nk\u001c\u000fLDl7\u0005s8$0gC2\u0005\u007f%x\u0017l\u007f~(|\b\u000f";
      b[17] = "%\u0010h\u0003JMy\u000e/:佺桤栃厶厓叹古厾栃伨P\u0006AB'\n3^Z\u0012e";
      b[18] = ")!SJPku?\u0014s栤厘栏桝伶伮你厘栏厇kIV`i&W\n\u00046s";
      b[19] = "t\u0015(nju(\u000boW叄历伖桩位桎栞历厈桩\u0010m?/ \u0014s6\u007ft2";
      b[20] = "Aa|\t]@\u001d\u007f;0佭伭桧余桝佭栩厳桧叇D\r^A\u001bv8\u000fB\u0013F";
      b[21] = "\u000e*/\u00190iR4h 厞厚佬伒佊根伀伄栨厌\u0017\u0019g\"\r6j\u001a4&R";
      b[22] = "Arb)Ju\u0002 43(%{\"h*Tt\u001b~8l\u0015I";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 12;
               case 1 -> 54;
               case 2 -> 53;
               case 3 -> 31;
               case 4 -> 22;
               case 5 -> 24;
               case 6 -> 42;
               case 7 -> 34;
               case 8 -> 36;
               case 9 -> 43;
               case 10 -> 55;
               case 11 -> 60;
               case 12 -> 48;
               case 13 -> 25;
               case 14 -> 32;
               case 15 -> 18;
               case 16 -> 30;
               case 17 -> 8;
               case 18 -> 57;
               case 19 -> 10;
               case 20 -> 13;
               case 21 -> 26;
               case 22 -> 19;
               case 23 -> 5;
               case 24 -> 6;
               case 25 -> 40;
               case 26 -> 29;
               case 27 -> 58;
               case 28 -> 39;
               case 29 -> 28;
               case 30 -> 3;
               case 31 -> 41;
               case 32 -> 15;
               case 33 -> 11;
               case 34 -> 14;
               case 35 -> 17;
               case 36 -> 1;
               case 37 -> 4;
               case 38 -> 37;
               case 39 -> 50;
               case 40 -> 52;
               case 41 -> 51;
               case 42 -> 9;
               case 43 -> 23;
               case 44 -> 46;
               case 45 -> 27;
               case 46 -> 7;
               case 47 -> 61;
               case 48 -> 59;
               case 49 -> 47;
               case 50 -> 33;
               case 51 -> 2;
               case 52 -> 0;
               case 53 -> 16;
               case 54 -> 63;
               case 55 -> 56;
               case 56 -> 38;
               case 57 -> 35;
               case 58 -> 21;
               case 59 -> 20;
               case 60 -> 62;
               case 61 -> 49;
               case 62 -> 44;
               default -> 45;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String HE_DA_WEI() {
      return "何大伟：我要教育何炜霖";
   }
}
