package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何树何树何何友友树友 implements 何树友 {
   public static final float 树树树何树树何何树友 = (float) Math.PI;
   public static final float 何何何树何友何何何友 = (float) (Math.PI / 2);
   public static final float 树树树友友友树何友友 = (float) (Math.PI / 4);
   public static final float 树树树树树何何树何友 = (float) (Math.PI * 2);
   private static final float 树何友树何何树友何何 = -0.5F;
   private static final float 友树何友友树何何何树 = 1.5F;
   private static final float 何何友何树友友何何友 = -1.5F;
   private static final float 何何何何树树树何何友 = 0.5F;
   private static final float 树何树友友友何何友友 = 1.0F;
   private static final float 树树友树树树树何何何 = -2.5F;
   private static final float 友何何树友友何树友树 = 2.0F;
   private static final float 何友树友友树何何树何 = -0.5F;
   private static final float 友树友何树何树友何何 = -0.5F;
   private static final float 友何何树友友何树友何 = 0.0F;
   private static final float 树何友友友何何何树友 = 0.5F;
   private static final float 树何树树树友树何树何 = 0.0F;
   private static final float 树友树树何何何友树树 = 0.0F;
   private static final float 何树树何树树友何何友 = 1.0F;
   private static final float 树树友何何何树树友友 = 0.0F;
   private static final float 树友何何树树友友树树 = 0.0F;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[15];
   private static final String[] f = new String[15];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(7379528408863917251L, -6997179515515643423L, MethodHandles.lookup().lookupClass()).a(223731953652421L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(69391654638026L << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = '0';
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "¬Ö\u0086Ð¥}t\u008cÆPJa\u0082à¸pæ\u0005k\u0088fâè\u0098£ n)ùøH\u007fö\u008bÊ>Gá\u0088¥¶\u0090&\u0092pQà}0\u0083º´\u0013á\u0081ºPCá\bjö\u0019\u0015bõ»,ÎÀ¥!\u0088\u0010i\u0097\u001e®÷Q'ÜÂ¢/¾\u00ad1°\u0098~îZ\u009eåò\u0089"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 97) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "¬Ö\u0086Ð¥}t\u008cÆPJa\u0082à¸pæ\u0005k\u0088fâè\u0098£ n)ùøH\u007fö\u008bÊ>Gá\u0088¥¶\u0090&\u0092pQà}0\u0083º´\u0013á\u0081ºPCá\bjö\u0019\u0015bõ»,ÎÀ¥!\u0088\u0010i\u0097\u001e®÷Q'ÜÂ¢/¾\u00ad1°\u0098~îZ\u009eåò\u0089"
            .charAt(var4);
      }
   }

   public static int B(int a, long numKnots, int yknots, int[] x, int[] a) {
      numKnots = (int)(113665361135551L ^ numKnots);
      int var10000 = b<"J">(4167378163671122533L, (long)numKnots);
      int numSpans = yknots - 3;
      int ax = var10000;
      if (numSpans < 1) {
         throw new IllegalArgumentException(a<"j">(3933, 3551213422488381523L ^ numKnots));
      } else {
         int span;
         int var10001;
         int var10002;
         label97: {
            label96: {
               label105: {
                  span = 0;
                  if (0 < numSpans) {
                     do {
                        var10000 = ((Object[])x)[span + 1];
                        var10001 = (int)a;
                        var10002 = ax;
                        if (numKnots <= 0L) {
                           break label97;
                        }

                        if (ax == 0) {
                           break label96;
                        }

                        if (var10000 > a) {
                           var10000 = ax;
                           if (numKnots < 0L) {
                              break label105;
                           }

                           if (ax != 0) {
                              break;
                           }
                        }

                        span++;
                     } while (numKnots < 0L);
                  }

                  var10000 = span;
               }

               var10001 = yknots - 3;
            }

            var10002 = ax;
         }

         if (var10002 != 0) {
            if (var10000 > var10001) {
               span = yknots - 3;
            }

            var10000 = (int)a;
            var10001 = ((Object[])x)[span];
         }

         float t = (float)(var10000 - var10001) / (((Object[])x)[span + 1] - ((Object[])x)[span]);
         if (--span < 0) {
            span = 0;
            t = 0.0F;
         }

         int v = 0;
         int i = 0;

         while (true) {
            if (i < 4) {
               int shift = i * 8;
               float k0 = ((Object[])a)[span] >> shift & 255;
               float k1 = ((Object[])a)[span + 1] >> shift & 255;
               float k2 = ((Object[])a)[span + 2] >> shift & 255;
               float k3 = ((Object[])a)[span + 3] >> shift & 255;
               float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
               float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
               float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
               float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
               int n = (int)(((c3 * t + c2) * t + c1) * t + c0);
               var10000 = n;
               var10001 = ax;
               if (numKnots >= 0L) {
                  if (ax == 0) {
                     break;
                  }

                  var10001 = ax;
               }

               label70: {
                  label69: {
                     label68: {
                        if (numKnots > 0L) {
                           if (var10001 != 0) {
                              if (n < 0) {
                                 n = 0;
                                 var10000 = ax;
                                 if (numKnots < 0L) {
                                    break label69;
                                 }

                                 if (ax != 0) {
                                    break label68;
                                 }
                              }

                              var10000 = n;
                           }

                           if (numKnots <= 0L) {
                              break label70;
                           }

                           var10001 = 255;
                        }

                        if (var10000 > var10001) {
                           n = 255;
                        }
                     }

                     var10000 = v;
                  }

                  v = var10000 | n << shift;
                  i++;
                  var10000 = ax;
               }

               if (var10000 != 0) {
                  continue;
               }
            }

            var10000 = v;
            break;
         }

         return var10000;
      }
   }

   public static float B(float a, float b) {
      return a / ((1.0F / b - 2.0F) * (1.0F - a) + 1.0F);
   }

   public static float C(float a, float b, float a, long var3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:284)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: ldc2_w 113665361135551
      // 03: lload 3
      // 04: lxor
      // 05: lstore 3
      // 06: ldc2_w 59538729530865696
      // 09: lload 3
      // 0a: invokedynamic J (JJ)I bsm=cn/cool/cherish/utils/render/何树何树何何友友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: pop
      // 10: fload 0
      // 11: fconst_0
      // 12: fcmpg
      // 13: ifge 1a
      // 16: fload 1
      // 17: goto 25
      // 1a: fload 0
      // 1b: fconst_1
      // 1c: fcmpl
      // 1d: ifle 24
      // 20: fload 2
      // 21: goto 25
      // 24: fload 0
      // 25: freturn
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static void D(int[] a, long offset, int[] source, int out, int a, int var6, float[] stride) {
      offset = (int)(113665361135551L ^ offset);
      int destIndex = (int)a;
      int lastIndex = a.length;
      float[] in = new float[out + 2];
      int var10000 = b<"J">(-6048619713017817154L, (long)offset);
      int i = 0;
      int ax = var10000;
      int j = 0;

      while (true) {
         label92:
         if (j < out) {
            label97: {
               float var47;
               var10000 = (var47 = ((Object[])stride)[i + 1] - j) == 0.0F ? 0 : (var47 < 0.0F ? -1 : 1);
               if (offset > 0L) {
                  if (var10000 >= 0) {
                     break label97;
                  }

                  i++;
                  var10000 = ax;
               }

               if (offset <= 0L) {
                  if (var10000 != 0) {
                     continue;
                  }
                  break label92;
               }

               if (var10000 == 0) {
                  if (ax != 0) {
                     continue;
                  }
                  break label92;
               }

               if (offset <= 0L) {
                  j++;
                  if (ax != 0) {
                     continue;
                  }
                  break label92;
               }
            }

            in[j] = i + (j - ((Object[])stride)[i]) / (((Object[])stride)[i + 1] - ((Object[])stride)[i]);
            j++;
            if (ax != 0) {
               continue;
            }
         }

         do {
            in[out] = out;
            in[out + 1] = out;
            if (offset >= 0L) {
               float inSegment = 1.0F;
               float outSegment = in[1];
               float sizfac = outSegment;
               float bSum = 0.0F;
               float gSum = 0.0F;
               float rSum = 0.0F;
               float aSum = 0.0F;
               int rgb = (int)a[a];
               int axx = rgb >> 24 & 0xFF;
               int r = rgb >> 16 & 0xFF;
               int g = rgb >> 8 & 0xFF;
               int b = rgb & 0xFF;
               int srcIndex = (int)(a + var6);
               rgb = (int)a[srcIndex];
               int nextA = rgb >> 24 & 0xFF;
               int nextR = rgb >> 16 & 0xFF;
               int nextG = rgb >> 8 & 0xFF;
               int nextB = rgb & 0xFF;
               srcIndex += var6;
               i = 1;

               while (i <= out) {
                  label48: {
                     label47: {
                        float aIntensity = inSegment * axx + (1.0F - inSegment) * nextA;
                        float rIntensity = inSegment * r + (1.0F - inSegment) * nextR;
                        float gIntensity = inSegment * g + (1.0F - inSegment) * nextG;
                        float bIntensity = inSegment * b + (1.0F - inSegment) * nextB;
                        float var45 = inSegment;
                        float var10001 = outSegment;
                        if (offset > 0L) {
                           if (inSegment < outSegment) {
                              aSum += aIntensity * inSegment;
                              rSum += rIntensity * inSegment;
                              gSum += gIntensity * inSegment;
                              bSum += bIntensity * inSegment;
                              outSegment -= inSegment;
                              inSegment = 1.0F;
                              axx = nextA;
                              r = nextR;
                              g = nextG;
                              b = nextB;
                              var10000 = srcIndex;
                              if (offset > 0L) {
                                 if (srcIndex < lastIndex) {
                                    rgb = (int)a[srcIndex];
                                 }

                                 nextA = rgb >> 24 & 0xFF;
                                 nextR = rgb >> 16 & 0xFF;
                                 nextG = rgb >> 8 & 0xFF;
                                 nextB = rgb & 0xFF;
                                 srcIndex += var6;
                                 var10000 = ax;
                              }

                              if (offset < 0L) {
                                 break label48;
                              }

                              if (var10000 != 0) {
                                 break label47;
                              }
                           }

                           aSum += aIntensity * outSegment;
                           rSum += rIntensity * outSegment;
                           gSum += gIntensity * outSegment;
                           bSum += bIntensity * outSegment;
                           source[destIndex] = (int)Math.min(aSum / sizfac, 255.0F) << 24
                              | (int)Math.min(rSum / sizfac, 255.0F) << 16
                              | (int)Math.min(gSum / sizfac, 255.0F) << 8
                              | (int)Math.min(bSum / sizfac, 255.0F);
                           destIndex += var6;
                           bSum = 0.0F;
                           gSum = 0.0F;
                           rSum = 0.0F;
                           aSum = 0.0F;
                           inSegment -= outSegment;
                           var45 = in[i + 1];
                           var10001 = in[i];
                        }

                        outSegment = var45 - var10001;
                        sizfac = outSegment;
                        i++;
                     }

                     var10000 = ax;
                  }

                  if (var10000 == 0) {
                     break;
                  }
               }

               return;
            }

            j++;
         } while (ax != 0);
      }
   }

   public static float I(float a, long numKnots, int a, int[] var4, int[] xknots) {
      numKnots = (int)(113665361135551L ^ numKnots);
      int var10000 = b<"J">(2970833740160848522L, (long)numKnots);
      int numSpans = (int)(a - 3);
      int ax = var10000;
      if (numSpans < 1) {
         throw new IllegalArgumentException(a<"j">(3933, 3551215974929332412L ^ numKnots));
      } else {
         int span;
         label50: {
            label54: {
               int var10001;
               label55: {
                  label47: {
                     span = 0;
                     if (0 < numSpans) {
                        do {
                           float var24;
                           var10000 = (var24 = var4[span + 1] - a) == 0.0F ? 0 : (var24 < 0.0F ? -1 : 1);
                           var10001 = ax;
                           if (numKnots < 0L) {
                              break label55;
                           }

                           if (ax == 0) {
                              break label47;
                           }

                           if (var10000 > 0) {
                           }

                           span++;
                        } while (numKnots <= 0L);
                     }

                     var10000 = span;
                  }

                  if (numKnots <= 0L) {
                     break label54;
                  }

                  var10001 = (int)(a - 3);
               }

               if (var10000 <= var10001) {
                  break label50;
               }

               var10000 = (int)(a - 3);
            }

            span = var10000;
         }

         float t = (a - var4[span]) / (var4[span + 1] - var4[span]);
         if (--span < 0) {
            span = 0;
            t = 0.0F;
         }

         float k0 = xknots[span];
         float k1 = xknots[span + 1];
         float k2 = xknots[span + 2];
         float k3 = xknots[span + 3];
         float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
         float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
         float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
         float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
         float var23 = ((c3 * t + c2) * t + c1) * t + c0;
         if (numKnots > 0L && b<"J">(2970745907562159278L, (long)numKnots) == null) {
            b<"J">(++ax, 2970898381175359176L, (long)numKnots);
         }

         return var23;
      }
   }

   public static void e(long a, int[] var2, int length, int p) {
      int var10000 = 何何友何友何树树树友.j();
      p += 0;
      int ax = var10000;
      int i = length;

      while (i < p) {
         int rgb = var2[i];
         int axx = rgb >> 24 & 0xFF;
         int r = rgb >> 16 & 0xFF;
         int g = rgb >> 8 & 0xFF;
         int b = rgb & 0xFF;
         if (ax != 0) {
            if (axx != 255) {
               float f = 255.0F / axx;
               r = (int)(r * f);
               g = (int)(g * f);
               b = (int)(b * f);
               var10000 = r;
               short var10001 = 255;
               if (ax != 0) {
                  if (r > 255) {
                     r = 255;
                  }

                  var10000 = g;
                  var10001 = 255;
               }

               label43: {
                  label56: {
                     if (ax != 0) {
                        if (var10000 > var10001) {
                           g = 255;
                        }

                        var10000 = b;
                        if (ax == 0) {
                           break label56;
                        }

                        var10001 = 255;
                     }

                     if (var10000 <= var10001) {
                        break label43;
                     }

                     var10000 = 255;
                  }

                  b = var10000;
               }

               var2[i] = axx << 24 | r << 16 | g << 8 | b;
            }

            i++;
         }

         if (ax == 0) {
            break;
         }
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   public static float b(float a, long a, float a) {
      a = 113665361135551L ^ a;
      b<"J">(2631160079569296496L, (long)a);
      return a < a ? 0.0F : 1.0F;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何树何树何何友友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static float h(float a, int a, long var2, float[] x) {
      var2 = 113665361135551L ^ var2;
      long ax = var2 ^ 95117987647577L;
      int var10000 = b<"J">(-2939495957060146044L, var2);
      int numSpans = (int)(a - 3);
      int axx = var10000;
      if (numSpans < 1) {
         throw new IllegalArgumentException(a<"j">(3933, 3551125236859078322L ^ var2));
      } else {
         int span;
         label24: {
            a = C((float)a, 0.0F, 1.0F, ax) * numSpans;
            span = (int)a;
            var10000 = axx;
            if (var2 > 0L) {
               if (axx == 0) {
                  break label24;
               }

               var10000 = span;
            }

            if (var10000 > a - 4) {
               span = (int)(a - 4);
            }

            a -= span;
         }

         float k0 = ((Object[])x)[span];
         float k1 = ((Object[])x)[span + 1];
         float k2 = ((Object[])x)[span + 2];
         float k3 = ((Object[])x)[span + 3];
         float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
         float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
         float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
         float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
         return ((c3 * a + c2) * a + c1) * a + c0;
      }
   }

   public static void l(int[] a, int a, int var2, long p) {
      何何友何友何树树树友.q();
      var2 += 0;
      if (a < var2) {
         int rgb = (int)a[a];
         int ax = rgb >> 24 & 0xFF;
         int r = rgb >> 16 & 0xFF;
         int g = rgb >> 8 & 0xFF;
         int b = rgb & 0xFF;
         float f = ax * 0.003921569F;
         r = (int)(r * f);
         g = (int)(g * f);
         b = (int)(b * f);
         a[a] = ax << 24 | r << 16 | g << 8 | b;
         int i = (int)(a + 1);
      }
   }

   public static float d(float a, float a, long var2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: ldc2_w 113665361135551
      // 03: lload 2
      // 04: lxor
      // 05: lstore 2
      // 06: ldc2_w 6379345624497201975
      // 09: lload 2
      // 0a: invokedynamic J (JJ)I bsm=cn/cool/cherish/utils/render/何树何树何何友友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: fload 0
      // 10: fconst_1
      // 11: fdiv
      // 12: f2i
      // 13: istore 6
      // 15: fload 0
      // 16: iload 6
      // 18: i2f
      // 19: fload 1
      // 1a: fmul
      // 1b: fsub
      // 1c: fstore 0
      // 1d: pop
      // 1e: fload 0
      // 1f: fconst_0
      // 20: fcmpg
      // 21: ifge 28
      // 24: fload 0
      // 25: fload 1
      // 26: fadd
      // 27: freturn
      // 28: fload 0
      // 29: freturn
   }

   public static int d(int a, int a, long a) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: ldc2_w 113665361135551
      // 03: lload 2
      // 04: lxor
      // 05: lstore 2
      // 06: ldc2_w -2260377844572661678
      // 09: lload 2
      // 0a: invokedynamic J (JJ)I bsm=cn/cool/cherish/utils/render/何树何树何何友友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: iload 0
      // 10: iload 1
      // 11: idiv
      // 12: istore 6
      // 14: pop
      // 15: iload 0
      // 16: iload 6
      // 18: iload 1
      // 19: imul
      // 1a: isub
      // 1b: istore 0
      // 1c: iload 0
      // 1d: ifge 24
      // 20: iload 0
      // 21: iload 1
      // 22: iadd
      // 23: ireturn
      // 24: iload 0
      // 25: ireturn
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 4;
               case 1 -> 2;
               case 2 -> 48;
               case 3 -> 9;
               case 4 -> 43;
               case 5 -> 15;
               case 6 -> 10;
               case 7 -> 54;
               case 8 -> 22;
               case 9 -> 28;
               case 10 -> 42;
               case 11 -> 25;
               case 12 -> 49;
               case 13 -> 7;
               case 14 -> 27;
               case 15 -> 24;
               case 16 -> 34;
               case 17 -> 26;
               case 18 -> 55;
               case 19 -> 18;
               case 20 -> 63;
               case 21 -> 52;
               case 22 -> 13;
               case 23 -> 33;
               case 24 -> 6;
               case 25 -> 5;
               case 26 -> 17;
               case 27 -> 37;
               case 28 -> 41;
               case 29 -> 11;
               case 30 -> 19;
               case 31 -> 62;
               case 32 -> 38;
               case 33 -> 35;
               case 34 -> 39;
               case 35 -> 58;
               case 36 -> 14;
               case 37 -> 53;
               case 38 -> 23;
               case 39 -> 0;
               case 40 -> 36;
               case 41 -> 12;
               case 42 -> 29;
               case 43 -> 45;
               case 44 -> 8;
               case 45 -> 40;
               case 46 -> 21;
               case 47 -> 44;
               case 48 -> 20;
               case 49 -> 60;
               case 50 -> 3;
               case 51 -> 51;
               case 52 -> 32;
               case 53 -> 56;
               case 54 -> 30;
               case 55 -> 50;
               case 56 -> 57;
               case 57 -> 47;
               case 58 -> 61;
               case 59 -> 59;
               case 60 -> 16;
               case 61 -> 31;
               case 62 -> 1;
               default -> 46;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何树何树何何友友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24280;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/render/何树何树何何友友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[KE+óòÎÞÛÀÁÁÊ(\u0085L\u0011Ø\u0004çÛ©#\u0081», Ö")[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'A' && var8 != 'm' && var8 != 'r' && var8 != 'u') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 165) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'J') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'A') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'm') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'r') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void a() {
      e[0] = "H_v\"Q(G\u001f;)[5BB0oK3B]+oL\"EU=3\u0010伒佾叺伍厊佫桖栺栠厓";
      e[1] = int.class;
      f[1] = "java/lang/Integer";
      e[2] = "\u0017w\u0019a\u001a\u001d\u00187Tj\u0010\u0000\u001dj_,\u0000\u0006\u001duD,\u0007\u0017\u001a}Rp[伧桥佌栦佗传厹县栈叼";
      e[3] = "O|\u0000{\u0000$Ds\u00114g$Ix\u0011{B\tWz\u0003wK&QX\u000eyK8Qt\u0019t";
      e[4] = "\u0012}/\u0003Z\u0001\u001d=b\bP\u001c\u0018`iNX\u0001\u0015fm\u0005\u001b#\u001ewt\fP";
      e[5] = "x\u0002\u0004.gAL!\u000bn*JF<\u000e3!\fN!\u00035%G\r\u0003\b$<NFu";
      e[6] = "j\u001a\u0013>\b\u001f^9\u001c~E\u0014T$\u0019#NR\\9\u0014%J\u0019\u001f\u001b\u001f4S\u0010Tm";
      e[7] = void.class;
      f[7] = "java/lang/Void";
      e[8] = "E_N[02NP_\u0014Q<E[[N";
      e[9] = "((\u001er\u0000\u0011.c\u0007`?8\u0012e\u00152P\u001ave\u0017=\u000fj";
      e[10] = "&+ ^X~|oA\u000f3}.l-]N4x4?b\u000e-7?!\u0012Z5t A";
      e[11] = "p\u000b\u0010\u001e+1*Oq@@2xL\u001d\u001d={.\u0014\u000f\"";
      e[12] = "Cl\u001cIYaE'\u0005[fDy!\u0017\t\tj\u001d!\u0015\u0006V\u001aDt\u0005X\u0006j\u0010lFGf";
      e[13] = "\u0006\u000e}\u0019?\u001eWM`R\u0002J<\rb\u001fo@CQj\u001dr#\u0006O&Na\\ZG$S\u0002";
      e[14] = "f/{t(x<k\u001a1C{nhvw>280dH";
   }

   private static IllegalArgumentException a(IllegalArgumentException var0) {
      return var0;
   }

   public static float m(float a) {
      return 1.0F - (float)Math.sqrt(1.0F - a * a);
   }

   public static float p(long a, float b, float a) {
      a = 113665361135551L ^ a;
      b<"J">(-6275831257425194153L, (long)a);
      float c = (1.0F / a - 2.0F) * (1.0F - 2.0F * b);
      return b < 0.5 ? b / (c + 1.0F) : (c - b) / (c - 1.0F);
   }

   public static float t(float a) {
      a = 1.0F - a;
      return (float)Math.sqrt(1.0F - a * a);
   }

   public static float g(float a, long x) {
      x = 113665361135551L ^ x;
      long ax = (long)(x ^ 68362145040740L);
      b<"J">(1611659254437031598L, (long)x);
      float r = d((float)a, 1.0F, ax);
      return 2.0F * (r < 0.5 ? r : 1.0F - r);
   }

   public static double v(long a, double var2, double var4) {
      a = 113665361135551L ^ a;
      b<"J">(-6486610040334066102L, (long)a);
      int n = (int)(var2 / var4);
      var2 -= n * var4;
      return var2 < 0.0 ? var2 + var4 : var2;
   }

   public static float q(float a, long a, float x, float a) {
      a = 113665361135551L ^ a;
      b<"J">(2313641611716172008L, (long)a);
      return !(a < a) && !(a >= x) ? 1.0F : 0.0F;
   }

   public static float U(float a, float x, float a2, long a, float b1, float a1) {
      a = 113665361135551L ^ a;
      b<"J">(975855012332926522L, a);
      if (!(a1 < a)) {
         float var12;
         int var10000 = (var12 = a1 - b1) == 0.0F ? 0 : (var12 < 0.0F ? -1 : 1);
         if (a >= 0L) {
            if (var10000 >= 0) {
               return 0.0F;
            }

            if (a < 0L) {
               return a1;
            }

            float var13;
            var10000 = (var13 = a1 - x) == 0.0F ? 0 : (var13 < 0.0F ? -1 : 1);
         }

         if (var10000 >= 0) {
            float var11 = a1;
            if (a >= 0L) {
               float var10001 = a2;
               if (a >= 0L) {
                  if (a1 < a2) {
                     return 1.0F;
                  }

                  a1 = (a1 - a2) / (b1 - a2);
                  var11 = 1.0F;
                  var10001 = a1 * a1;
               }

               var11 -= var10001 * (3.0F - 2.0F * a1);
            }

            return var11;
         } else {
            a1 = (a1 - a) / (x - a);
            return a1 * a1 * (3.0F - 2.0F * a1);
         }
      } else {
         return 0.0F;
      }
   }

   public static int z(float a, int t, int b) {
      return (int)(t + a * (b - t));
   }

   public static int E(float a, int rgb2, int t) {
      int a1 = rgb2 >> 24 & 0xFF;
      int r1 = rgb2 >> 16 & 0xFF;
      int g1 = rgb2 >> 8 & 0xFF;
      int b1 = rgb2 & 0xFF;
      int a2 = (int)(t >> 24 & 255);
      int r2 = (int)(t >> 16 & 255);
      int g2 = (int)(t >> 8 & 255);
      int b2 = (int)(t & 255);
      a1 = z((float)a, a1, a2);
      r1 = z((float)a, r1, r2);
      g1 = z((float)a, g1, g2);
      b1 = z((float)a, b1, b2);
      return a1 << 24 | r1 << 16 | g1 << 8 | b1;
   }

   public static float E(float a, long a, float a, float b) {
      a = 113665361135551L ^ a;
      b<"J">(3234016242429482833L, a);
      if (b < a) {
         return 0.0F;
      } else {
         float var10000 = b;
         if (a > 0L) {
            if (b >= a) {
               return 1.0F;
            }

            b = (b - a) / (a - a);
            var10000 = b * b * (3.0F - 2.0F * b);
         }

         return var10000;
      }
   }

   public static int X(int a, int a, long x, int var4) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent.toJava(AssignmentExprent.java:154)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:258)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: ldc2_w 113665361135551
      // 03: lload 2
      // 04: lxor
      // 05: lstore 2
      // 06: ldc2_w 5445661801706762274
      // 09: lload 2
      // 0a: invokedynamic J (JJ)I bsm=cn/cool/cherish/utils/render/何树何树何何友友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: istore 6
      // 11: iload 0
      // 12: iload 1
      // 13: if_icmpge 1a
      // 16: iload 1
      // 17: goto 31
      // 1a: iload 0
      // 1b: iload 6
      // 1d: lload 2
      // 1e: lconst_0
      // 1f: lcmp
      // 20: ifle 28
      // 23: ifeq 2d
      // 26: iload 4
      // 28: if_icmple 30
      // 2b: iload 4
      // 2d: goto 31
      // 30: iload 0
      // 31: ireturn
   }

   public static int M(long a, float x, float se, int ne, int y, int nw, int a) {
      a = 113665361135551L ^ a;
      b<"J">(-9047299769671288383L, (long)a);
      int a0 = ne >> 24 & 0xFF;
      int r0 = ne >> 16 & 0xFF;
      int g0 = ne >> 8 & 0xFF;
      int b0 = ne & 0xFF;
      int a1 = (int)(y >> 24 & 255);
      int r1 = (int)(y >> 16 & 255);
      int g1 = (int)(y >> 8 & 255);
      int b1 = (int)(y & 255);
      int a2 = nw >> 24 & 0xFF;
      int r2 = nw >> 16 & 0xFF;
      int g2 = nw >> 8 & 0xFF;
      int b2 = nw & 0xFF;
      int a3 = (int)(a >> 24 & 255);
      int r3 = (int)(a >> 16 & 255);
      int g3 = (int)(a >> 8 & 255);
      int b3 = (int)(a & 255);
      float cx = 1.0F - x;
      float cy = 1.0F - se;
      float m0 = cx * a0 + x * a1;
      float m1 = cx * a2 + x * a3;
      int ax = (int)(cy * m0 + se * m1);
      m0 = cx * r0 + x * r1;
      m1 = cx * r2 + x * r3;
      int r = (int)(cy * m0 + se * m1);
      m0 = cx * g0 + x * g1;
      m1 = cx * g2 + x * g3;
      int g = (int)(cy * m0 + se * m1);
      m0 = cx * b0 + x * b1;
      m1 = cx * b2 + x * b3;
      int b = (int)(cy * m0 + se * m1);
      int var10000 = ax << 24 | r << 16 | g << 8 | b;
      b<"J">(new Module[2], -9047602730287169937L, (long)a);
      return var10000;
   }

   public static int N(int a) {
      int r = a >> 16 & 0xFF;
      int g = a >> 8 & 0xFF;
      int b = a & 255;
      return (int)(r * 0.299F + g * 0.587F + b * 0.114F);
   }

   public static float P(float a, float a, float t) {
      return a + a * (t - a);
   }

   private static String HE_WEI_LIN() {
      return "职业技术教育中心学校";
   }

   public static int Q(float a, long a, int x, int[] numKnots) {
      a = 113665361135551L ^ a;
      long ax = a ^ 24645254642116L;
      int var10000 = b<"J">(-4708241683592247717L, a);
      int numSpans = (int)(x - 3);
      int axx = var10000;
      if (numSpans < 1) {
         throw new IllegalArgumentException(a<"j">(16136, 2558929543117397883L ^ a));
      } else {
         int span;
         label72: {
            a = C((float)a, 0.0F, 1.0F, ax) * numSpans;
            span = (int)a;
            var10000 = span;
            int var10001 = axx;
            if (a > 0L) {
               if (axx != 0) {
                  break label72;
               }

               var10001 = (int)(x - 4);
            }

            if (span > var10001) {
               span = (int)(x - 4);
            }

            a -= span;
            var10000 = 0;
         }

         int v = var10000;
         int i = 0;

         while (true) {
            if (i < 4) {
               int shift = i * 8;
               float k0 = ((Object[])numKnots)[span] >> shift & 0xFF;
               float k1 = ((Object[])numKnots)[span + 1] >> shift & 0xFF;
               float k2 = ((Object[])numKnots)[span + 2] >> shift & 0xFF;
               float k3 = ((Object[])numKnots)[span + 3] >> shift & 0xFF;
               float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
               float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
               float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
               float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
               int n = (int)(((c3 * a + c2) * a + c1) * a + c0);
               var10000 = n;
               int var28 = axx;
               if (a >= 0L) {
                  if (axx != 0) {
                     break;
                  }

                  var28 = axx;
               }

               label56: {
                  label55: {
                     label54: {
                        if (a >= 0L) {
                           if (var28 == 0) {
                              if (n < 0) {
                                 n = 0;
                                 var10000 = axx;
                                 if (a <= 0L) {
                                    break label55;
                                 }

                                 if (axx == 0) {
                                    break label54;
                                 }
                              }

                              var10000 = n;
                           }

                           if (a < 0L) {
                              break label56;
                           }

                           var28 = 255;
                        }

                        if (var10000 > var28) {
                           n = 255;
                        }
                     }

                     var10000 = v;
                  }

                  v = var10000 | n << shift;
                  i++;
                  var10000 = axx;
               }

               if (var10000 == 0) {
                  continue;
               }
            }

            var10000 = v;
            break;
         }

         return var10000;
      }
   }
}
