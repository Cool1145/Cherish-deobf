package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.友树树何何树树何何树;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.LivingEntity;

public final class 树树何友友友友何树友 implements 何树友 {
   public static final Map<String, Color> 树何友友何友何友何友;
   public static final Map<String, Color> 友树友友友何何何友友;
   public static final Map<Color, String> 友树友友何树何何树树;
   private static int[] 何何友友何友何树树何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long e;
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[10];
   private static final String[] j = new String[10];
   private static String HE_DA_WEI;

   private 树树何友友友友何树友(long a) {
      a = 树树何友友友友何树友.a ^ a;
      super();
      throw new UnsupportedOperationException(a<"y">(30203, 6553454453423744665L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(4296922702051953120L, 6244257467171294630L, MethodHandles.lookup().lookupClass()).a(217712516659892L);
      // $VF: monitorexit
      a = var10000;
      long var25 = a ^ 14194836805890L;
      long var27 = var25 ^ 41536457576996L;
      long var29 = var25 ^ 50000708865061L;
      int var31 = (int)((var25 ^ 82024685207906L) >>> 48);
      long var32 = (var25 ^ 82024685207906L) << 16 >>> 16;
      a();
      c<"Y">(null, 3031818172208980298L, var25);
      Cipher var16;
      Cipher var35 = var16 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var25 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var17 = 1; var17 < 8; var17++) {
         var10003[var17] = (byte)(var25 << var17 * 8 >>> 56);
      }

      var35.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var23 = new String[2];
      int var21 = 0;
      char var19 = 24;
      int var18 = -1;

      while (true) {
         String var42 = a(
               var16.doFinal(
                  "\u008fõ\u0095=ÚßDÍ{â\u00ad\u008at\u000b\"dï\u001d\u0001-\u0081b\u008f\u000eP²\u0089N\bý¹Í\u0005\u008a>Î\u008a\fKê\u0096î%\b\u0017M`áö\u009eì'À\u000eËC\u0004Eú\u00947\u0015¹7\u001e\u0086V\u009f%O\u0017²jIøÝo\u001e9\u0005Ê;\u0006÷:Êt@cZ\u0001eC]\u009erÈpGj°\u0092ä¼\u001e"
                     .substring(++var18, var18 + var19)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         int var10001 = -1;
         var23[var21++] = var42;
         if ((var18 += var19) >= 105) {
            b = var23;
            c = new String[2];
            Cipher var11;
            Cipher var36 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)(var25 >>> 56), 0, 0, 0, 0, 0, 0, 0};

            for (int var12 = 1; var12 < 8; var12++) {
               var10003[var12] = (byte)(var25 << var12 * 8 >>> 56);
            }

            var36.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            byte[] var15 = var11.doFinal(new byte[]{-57, 27, -28, 5, -77, 79, -78, 55});
            long var45 = (var15[0] & 255L) << 56
               | (var15[1] & 255L) << 48
               | (var15[2] & 255L) << 40
               | (var15[3] & 255L) << 32
               | (var15[4] & 255L) << 24
               | (var15[5] & 255L) << 16
               | (var15[6] & 255L) << 8
               | var15[7] & 255L;
            var10001 = (byte)-1;
            e = var45;
            h = new HashMap(13);
            Cipher var0;
            Cipher var37 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)(var25 >>> 56), 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(var25 << var1 * 8 >>> 56);
            }

            var37.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[3];
            int var3 = 0;
            byte var2 = 0;

            do {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = "I§3\u0000+0¼ÌCòÒ<sn´¾\u001egB1X4}â".substring(var10001, var2).getBytes("ISO-8859-1");
               var10001 = var3++;
               long var8 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               byte[] var10 = var0.doFinal(
                  new byte[]{
                     (byte)(var8 >>> 56),
                     (byte)(var8 >>> 48),
                     (byte)(var8 >>> 40),
                     (byte)(var8 >>> 32),
                     (byte)(var8 >>> 24),
                     (byte)(var8 >>> 16),
                     (byte)(var8 >>> 8),
                     (byte)var8
                  }
               );
               long var10004 = (var10[0] & 255L) << 56
                  | (var10[1] & 255L) << 48
                  | (var10[2] & 255L) << 40
                  | (var10[3] & 255L) << 32
                  | (var10[4] & 255L) << 24
                  | (var10[5] & 255L) << 16
                  | (var10[6] & 255L) << 8
                  | var10[7] & 255L;
               byte var49 = -1;
               var6[var10001] = var10004;
            } while (var2 < 24);

            f = var6;
            g = new Long[3];
            树何友友何友何友何友 = new 树树何友友友友何树友$树何友树树树友何树何((char)var31, var32);
            友树友友友何何何友友 = new 树树何友友友友何树友$何树何友树树友何友友(var27);
            友树友友何树何何树树 = new 树树何友友友友何树友$友友树树何树树何友友(var29);
            return;
         }

         var19 = "\u008fõ\u0095=ÚßDÍ{â\u00ad\u008at\u000b\"dï\u001d\u0001-\u0081b\u008f\u000eP²\u0089N\bý¹Í\u0005\u008a>Î\u008a\fKê\u0096î%\b\u0017M`áö\u009eì'À\u000eËC\u0004Eú\u00947\u0015¹7\u001e\u0086V\u009f%O\u0017²jIøÝo\u001e9\u0005Ê;\u0006÷:Êt@cZ\u0001eC]\u009erÈpGj°\u0092ä¼\u001e"
            .charAt(var18);
      }
   }

   public static int C(int a) {
      return a >> 24 & 0xFF;
   }

   public static int F(int a) {
      return a & 0xFF;
   }

   public static int J(int a, long green, int blue, int a) {
      long ax = 树树何友友友友何树友.a ^ green ^ 119335552752692L;
      return i((int)a, blue, (int)a, 255, ax);
   }

   public static void Z(int[] var0) {
      何何友友何友何树树何 = var0;
   }

   public static int i(int a, int alpha, int red, int green, long blue) {
      long ax = 树树何友友友友何树友.a ^ blue ^ 33887424087766L;
      int color = 友树树何何树树何何树.C(ax, 255, 0, 255) << 24;
      color |= 友树树何何树树何何树.C(ax, (int)a, 0, 255) << 16;
      color |= 友树树何何树树何何树.C(ax, alpha, 0, 255) << 8;
      return color | 友树树何何树树何何树.C(ax, red, 0, 255);
   }

   public static int b(int a, int b, int a, int g) {
      return (g & 0xFF) << 24 | (a & 0xFF) << 16 | (b & 0xFF) << 8 | a & 0xFF;
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25811;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public static Color x(Color a, Color color1, float amount) {
      amount = Math.min(1.0F, Math.max(0.0F, 0.65F));
      return new Color(
         E(a.getRed(), color1.getRed(), amount),
         E(a.getGreen(), color1.getGreen(), amount),
         E(a.getBlue(), color1.getBlue(), amount),
         E(a.getAlpha(), color1.getAlpha(), amount)
      );
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static int d(int a, float alpha) {
      int r = a >> 16 & 0xFF;
      int g = a >> 8 & 0xFF;
      int b = a & 255;
      int ax = (int)(alpha * 255.0F);
      return ax << 24 | r << 16 | g << 8 | b;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5486;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'r' && var8 != 208 && var8 != 'J' && var8 != 'e') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 245) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Y') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'r') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 208) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'J') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void a() {
      i[0] = "#@%CYL,\u0000hHSQ)]c\u000eCW)Bx\u000eDF.JnR\u0018q%@oEDv4GgS";
      i[1] = boolean.class;
      j[1] = "java/lang/Boolean";
      i[2] = "\u0001J4-nf\u000e\ny&d{\u000bWr`t}\u000bHi`sl\f@\u007f</栘桳佱发厅及参伷栵发";
      i[3] = "2^1Z(\u00079Q \u0015S\u0005+J7Ki\u0019,Z#tv\u000e*^3Ri\u0005\u001dG$^v\u001f1P)";
      i[4] = "u ";
      i[5] = void.class;
      j[5] = "java/lang/Void";
      i[6] = "Bw\u00056Y\u0014Ix\u0014y8\u001aBs\u0010#";
      i[7] = "\u000b5R\u000144EcTs*\tM`S\u00139b\t%Ws";
      i[8] = "^H\u0015\u0015@TY\u001fA\u001fxog\u001e\u001a\u0018\u0019]VG\u0013\u001f\u001c=\\TO\u0013\u0007@\u000eAJOx";
      i[9] = "N\"\u0019QXIIuM[`IwuD\u0003\r\u001bF1\u001c_\u000e M,\u001eW[\u0011\ttBT`";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 25;
               case 1 -> 37;
               case 2 -> 21;
               case 3 -> 54;
               case 4 -> 29;
               case 5 -> 24;
               case 6 -> 31;
               case 7 -> 32;
               case 8 -> 2;
               case 9 -> 38;
               case 10 -> 28;
               case 11 -> 13;
               case 12 -> 10;
               case 13 -> 17;
               case 14 -> 60;
               case 15 -> 46;
               case 16 -> 18;
               case 17 -> 22;
               case 18 -> 61;
               case 19 -> 41;
               case 20 -> 57;
               case 21 -> 45;
               case 22 -> 1;
               case 23 -> 30;
               case 24 -> 23;
               case 25 -> 5;
               case 26 -> 34;
               case 27 -> 59;
               case 28 -> 56;
               case 29 -> 49;
               case 30 -> 52;
               case 31 -> 4;
               case 32 -> 53;
               case 33 -> 62;
               case 34 -> 35;
               case 35 -> 36;
               case 36 -> 14;
               case 37 -> 20;
               case 38 -> 0;
               case 39 -> 27;
               case 40 -> 58;
               case 41 -> 50;
               case 42 -> 63;
               case 43 -> 3;
               case 44 -> 16;
               case 45 -> 11;
               case 46 -> 6;
               case 47 -> 42;
               case 48 -> 39;
               case 49 -> 48;
               case 50 -> 51;
               case 51 -> 7;
               case 52 -> 12;
               case 53 -> 8;
               case 54 -> 19;
               case 55 -> 43;
               case 56 -> 33;
               case 57 -> 47;
               case 58 -> 55;
               case 59 -> 44;
               case 60 -> 9;
               case 61 -> 15;
               case 62 -> 40;
               default -> 26;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static int m(int a, float color) {
      Color old = new Color((int)a);
      color = (int)Math.min(1.0F, Math.max(0.0F, (float)color));
      return z(old, (float)color).getRGB();
   }

   public static int p(int a, long a) {
      long var10000 = 树树何友友友友何树友.a ^ a;
      return a & (int)e | Math.max(a >> 16 & 215, 0) << 16 | Math.max(a >> 8 & 215, 0) << 8 | Math.max(a & 215, 0);
   }

   public static Color k(LivingEntity a, long a) {
      a = 树树何友友友友何树友.a ^ a;
      c<"Y">(7724977867520508348L, a);
      Color healthColor = new Color(0, 165, 0);
      if (a.getHealth() < a.getMaxHealth() / 1.5) {
         healthColor = new Color(200, 200, 0);
      }

      if (a.getHealth() < a.getMaxHealth() / 2.5) {
         healthColor = new Color(200, 155, 0);
      }

      if (a.getHealth() < a.getMaxHealth() / 4.0F) {
         healthColor = new Color(120, 0, 0);
      }

      return healthColor;
   }

   public static int g(int a, int g, int r, int a) {
      return (a & 0xFF) << 24 | (a & 0xFF) << 16 | (g & 0xFF) << 8 | r & 0xFF;
   }

   public static Color U(Color a, Color color1, float color2) {
      color2 = Math.max(0.0F, Math.min(1.0F, (float)color2));
      int r = (int)(a.getRed() + (color1.getRed() - a.getRed()) * color2);
      int g = (int)(a.getGreen() + (color1.getGreen() - a.getGreen()) * color2);
      int b = (int)(a.getBlue() + (color1.getBlue() - a.getBlue()) * color2);
      int ax = (int)(a.getAlpha() + (color1.getAlpha() - a.getAlpha()) * color2);
      return new Color(r, g, b, ax);
   }

   public static Color z(Color a, float color) {
      color = Math.min(1.0F, Math.max(0.0F, (float)color));
      return new Color(a.getRed(), a.getGreen(), a.getBlue(), (int)(a.getAlpha() * color));
   }

   public static int w(int a) {
      return a >> 16 & 0xFF;
   }

   public static Color w(long a, int speed, int a) {
      a = 树树何友友友友何树友.a ^ a;
      int angle = (int)((System.currentTimeMillis() / 10L + 1L) % b<"l">(12397, 429456205022131190L ^ a));
      float hue = angle / 360.0F;
      return new Color(Color.HSBtoRGB(hue, 0.7F, 1.0F));
   }

   public static int E(int a, int oldValue, double interpolationValue) {
      return R(a, oldValue, (float)interpolationValue).intValue();
   }

   public static String L(String a, long a) {
      a = 树树何友友友友何树友.a ^ a;
      c<"Y">(-7413847558330813548L, a);
      return a == null ? "" : a.replaceAll(a<"y">(8333, 2519198872449821950L ^ a), "");
   }

   public static int H(int a) {
      return a >> 8 & 0xFF;
   }

   public static Double R(double a, double var2, double var4) {
      return a + (var2 - a) * var4;
   }

   public static int R(Color a, long secondColor, Color var3, float speed, int var5, long alpha, double index, double a) {
      secondColor = 树树何友友友友何树友.a ^ secondColor;
      long now = (long)(index * System.currentTimeMillis() + var5 * alpha);
      float redDiff = (float)((a.getRed() - var3.getRed()) / speed);
      float greenDiff = (float)((a.getGreen() - var3.getGreen()) / speed);
      float blueDiff = (float)((a.getBlue() - var3.getBlue()) / speed);
      int red = Math.round(var3.getRed() + redDiff * (float)(now % (long)speed));
      int green = Math.round(var3.getGreen() + greenDiff * (float)(now % (long)speed));
      c<"Y">(-1241417982264671155L, (long)secondColor);
      int blue = Math.round(var3.getBlue() + blueDiff * (float)(now % (long)speed));
      float redInverseDiff = (float)((var3.getRed() - a.getRed()) / speed);
      float greenInverseDiff = (float)((var3.getGreen() - a.getGreen()) / speed);
      float blueInverseDiff = (float)((var3.getBlue() - a.getBlue()) / speed);
      int inverseRed = Math.round(a.getRed() + redInverseDiff * (float)(now % (long)speed));
      int inverseGreen = Math.round(a.getGreen() + greenInverseDiff * (float)(now % (long)speed));
      int inverseBlue = Math.round(a.getBlue() + blueInverseDiff * (float)(now % (long)speed));
      return now % ((long)speed * b<"l">(24061, 388630986284259306L ^ secondColor)) < (long)speed
         ? new Color(inverseRed, inverseGreen, inverseBlue, (int)a).getRGB()
         : new Color(red, green, blue, (int)a).getRGB();
   }

   public static int[] Q() {
      return 何何友友何友何树树何;
   }

   public static Color O(int a, long alpha, int index, Color a, float var5) {
      alpha = 树树何友友友友何树友.a ^ alpha;
      float[] hsb = Color.RGBtoHSB(a.getRed(), a.getGreen(), a.getBlue(), null);
      c<"Y">(8400040323015810586L, (long)alpha);
      int angle = (int)((System.currentTimeMillis() / a + index) % b<"l">(13871, (long)(6242486799737366126L ^ alpha)));
      angle = (angle > 180 ? 360 - angle : angle) + 180;
      Color colorHSB = new Color(Color.HSBtoRGB(hsb[0], hsb[1], angle / 360.0F));
      return new Color(colorHSB.getRed(), colorHSB.getGreen(), colorHSB.getBlue(), Math.max(0, Math.min(255, (int)(var5 * 255.0F))));
   }

   private static String LIU_YA_FENG() {
      return "何大伟230622198107200054";
   }
}
