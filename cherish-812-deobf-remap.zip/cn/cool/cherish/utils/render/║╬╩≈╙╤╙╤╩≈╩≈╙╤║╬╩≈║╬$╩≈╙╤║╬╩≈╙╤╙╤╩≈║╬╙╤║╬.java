package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何树何何树何友何何何;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

class 何树友友树树友何树何$树友何树友友树何友何 extends HashMap<String, Color> implements  {
   private static final long a;
   private static final long[] b;
   private static final Integer[] c;
   private static final Map d = new HashMap(13);
   private static String HE_WEI_LIN;

   何树友友树树友何树何$树友何树友友树何友何(long a) {
      this.put("c", new Color(a<"k">(12603, 4416149008020498976L)));
      this.put("e", new Color(a<"k">(21173, 3983725255630162341L)));
      this.put("a", new Color(a<"k">(6433, 2324117405835346489L)));
      this.put("9", new Color(a<"k">(23248, 2638103340247515596L)));
      this.put("b", new Color(a<"k">(24664, 8481609027151936326L)));
      this.put("d", new Color(a<"k">(22969, 2988169537886683816L)));
      this.put("f", new Color(a<"k">(26030, 7977482944092815028L)));
      this.put("8", new Color(a<"k">(29193, 1901928698192767254L)));
      this.put("4", new Color(a<"k">(14688, 3054039479871169149L)));
      this.put("6", new Color(a<"k">(13148, 2670979917762390091L)));
      this.put("2", new Color(a<"k">(4392, 2642619856374811198L)));
      this.put("1", new Color(170));
      this.put("3", new Color(a<"k">(30010, 22980285553159721L)));
      this.put("5", new Color(a<"k">(8222, 1467635863242537735L)));
      this.put("7", new Color(a<"k">(11604, 4795450014963332678L)));
      this.put("0", new Color(0));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(4170787329507928475L, -8974113939195176497L, MethodHandles.lookup().lookupClass()).a(268976480984047L);
      // $VF: monitorexit
      a = var10000;
      Cipher var2;
      Cipher var14 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(74413564436360L << var3 * 8 >>> 56);
      }

      var14.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[14];
      int var5 = 0;
      String var6 = "tÈN\u000b\u00addí\u00111Îâ\u00895|¡ZÐRì½âQ¬\u009f\u0095Íw\"GyÄÜNÁµEE\u0091\u0017gç£ÏÝn¿!\u009d\u001eñç=/Å\u0095pí¨.\u008eM\u009a9[\u0084\u0015ÅÍZ¤þ\r\u000f'ÍÒ\u0014öXA\u0019Å|\u0091u\u000f\\·\u0083Ø»Y\u0097\u008cÒÉ";
      byte var7 = 96;
      byte var4 = 0;

      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var15 = var8;
         var10001 = var5++;
         long var18 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte var20 = -1;

         while (true) {
            long var10 = var18;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var22 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var20) {
               case 0:
                  var15[var10001] = var22;
                  if (var4 >= var7) {
                     b = var8;
                     c = new Integer[14];
                     return;
                  }
                  break;
               default:
                  var15[var10001] = var22;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "\u001eÒ?\u008c\u001aHÑ®j\u000eSGtA\u0098\u0010";
                  var7 = 16;
                  var4 = 0;
            }

            byte var17 = var4;
            var4 += 8;
            var9 = var6.substring(var17, var4).getBytes("ISO-8859-1");
            var15 = var8;
            var10001 = var5++;
            var18 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var20 = 0;
         }
      }
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何树友友树树友何树何$树友何树友友树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 23322;
      if (c[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = b[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])d.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/render/何树友友树树友何树何$树友何树友友树何友何", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         c[var3] = var15;
      }

      return c[var3];
   }

   private static String HE_DA_WEI() {
      return "行走的50万——何炜霖";
   }
}
