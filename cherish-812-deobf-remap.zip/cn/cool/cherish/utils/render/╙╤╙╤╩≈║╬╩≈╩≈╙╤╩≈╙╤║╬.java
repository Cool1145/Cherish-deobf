package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

public final class 友友树何树树友树友何 implements IWrapper, 何树友 {
   private static final Matrix4f 友何树树友友树友友树;
   private static final Matrix4f 何树友何树树树友友友;
   private static final Matrix4f 树树友何何何友树树友;
   private static boolean 友友何何友友树何何友;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[69];
   private static final String[] e = new String[69];
   private static String HE_DA_WEI;

   private 友友树何树树友树友何(long a) {
      long var10000 = 友友树何树树友树友何.a ^ a;
      super();
      throw new UnsupportedOperationException(b);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1255764020732457478L, 724491505985022095L, MethodHandles.lookup().lookupClass()).a(226213352431965L);
      // $VF: monitorexit
      a = var10000;
      long var3 = a ^ 39244164493273L;
      a();
      if (a<"O">(8789170413269337552L, var3)) {
         a<"O">(true, 8788925439963544991L, var3);
      }

      Cipher var0;
      Cipher var5 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var3 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var3 << var1 * 8 >>> 56);
      }

      var5.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var6 = b(
            var0.doFinal(
               "·s_&ØÌqWS\u000fW°Y\u009b\u0001\u0015\u000fôMD\u009a÷\u0013\u0088²\u0087\u0004\u0082\u008e\u0011\u0011Õ¥.\u0005 ØÞ¤ºvu\u0002ÂT\u008d=z\u001b\t\u0097¡T²¨V"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      byte var10001 = -1;
      b = var6;
      友何树树友友树友友树 = new Matrix4f();
      何树友何树树树友友友 = new Matrix4f();
      树树友何何何友树树友 = new Matrix4f();
   }

   public static boolean F(long a, Entity var2) {
      a = 友友树何树树友树友何.a ^ a;
      long ax = a ^ 128945918420989L;
      int var10000 = a<"O">(8371035304889822366L, (long)a);
      Vector4f pos = o(ax, var2);
      int axx = (boolean)var10000;
      if (a<"N">(pos, 8372899996106468021L, (long)a) != Float.MAX_VALUE) {
         float var10;
         var10000 = (var10 = a<"N">(pos, 8368867143688172008L, (long)a) - (Float.MAX_VALUE)) == 0.0F ? 0 : (var10 < 0.0F ? -1 : 1);
         boolean var10001 = axx;
         if (a >= 0L) {
            if (!axx) {
               if (!var10000) {
                  return (boolean)0;
               }

               float var11;
               var10000 = (var11 = a<"N">(pos, 8370871220861444823L, (long)a) - -1.0F) == 0.0F ? 0 : (var11 < 0.0F ? -1 : 1);
            }

            var10001 = axx;
         }

         if (a > 0L) {
            if (!var10001) {
               if (!var10000) {
                  return (boolean)0;
               }

               float var12;
               var10000 = (var12 = a<"N">(pos, 8369132569380867888L, (long)a) - -1.0F) == 0.0F ? 0 : (var12 < 0.0F ? -1 : 1);
            }

            var10001 = axx;
         }

         if (var10001) {
            return (boolean)var10000;
         }

         if (var10000) {
            return (boolean)1;
         }
      }

      return (boolean)0;
   }

   public static Vector3f J(float a, float a, float var2, float scaleFactor, long z) {
      z = 友友树何树树友树友何.a ^ z;
      Camera camera = a<"N">(mc, -1546258369042171902L, (long)z).getMainCamera();
      a<"O">(-1542579920845914750L, (long)z);
      int displayHeight = mc.getWindow().getHeight();
      Vec3 cameraPos = camera.getPosition();
      double deltaX = a - a<"N">(cameraPos, -1545505190029181223L, (long)z);
      double deltaY = a - a<"N">(cameraPos, -1546720367592765046L, (long)z);
      double deltaZ = var2 - a<"N">(cameraPos, -1545040027208371751L, (long)z);
      Vector4f transformed = new Vector4f((float)deltaX, (float)deltaY, (float)deltaZ, 1.0F).mul(a<"ñ">(-1545961186126891074L, (long)z));
      Matrix4f matrix = new Matrix4f(a<"ñ">(-1542628830068988068L, (long)z));
      matrix.mul(a<"ñ">(-1548771916732768090L, (long)z));
      Vector3f screenCoords = new Vector3f();
      matrix.project(transformed.x(), transformed.y(), transformed.z(), new int[]{0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight()}, screenCoords);
      return a<"N">(screenCoords, -1545849013392049859L, (long)z) > 1.0F
         ? null
         : new Vector3f(
            a<"N">(screenCoords, -1546864199505356458L, (long)z) / scaleFactor,
            (displayHeight - a<"N">(screenCoords, -1546163126463701000L, (long)z)) / scaleFactor,
            a<"N">(screenCoords, -1545849013392049859L, (long)z)
         );
   }

   public static void Z(long a, PoseStack outline, AABB aabb, boolean alpha, int a, float var6) {
      a = 友友树何树树友树友何.a ^ a;
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      boolean var10000 = a<"O">(7322530627862311563L, (long)a);
      RenderSystem.disableDepthTest();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      int ax = var10000;
      float axx = (a >> 24 & 255) / 255.0F * 1.0F;
      float r = (a >> 16 & 255) / 255.0F;
      float g = (a >> 8 & 255) / 255.0F;
      float b = (a & 255) / 255.0F;
      float minX = (float)a<"N">(aabb, 7314083031264556791L, (long)a);
      float minY = (float)a<"N">(aabb, 7314585169281621115L, (long)a);
      float minZ = (float)a<"N">(aabb, 7315686887766024029L, (long)a);
      float maxX = (float)a<"N">(aabb, 7315808558495768140L, (long)a);
      float maxY = (float)a<"N">(aabb, 7314045104799998936L, (long)a);
      float maxZ = (float)a<"N">(aabb, 7316476382528933542L, (long)a);
      Tesselator tesselator = Tesselator.getInstance();
      BufferBuilder bufferBuilder = tesselator.getBuilder();
      Matrix4f matrix = outline.last().pose();
      RenderSystem.lineWidth(2.0F);
      bufferBuilder.begin(a<"ñ">(7316242888504666114L, (long)a), a<"ñ">(7316592776546632286L, (long)a));
      i(bufferBuilder, matrix, minX, minY, minZ, maxX, minY, minZ, r, g, b, axx);
      i(bufferBuilder, matrix, maxX, minY, minZ, maxX, minY, maxZ, r, g, b, axx);
      i(bufferBuilder, matrix, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, axx);
      i(bufferBuilder, matrix, minX, minY, maxZ, minX, minY, minZ, r, g, b, axx);
      i(bufferBuilder, matrix, minX, maxY, minZ, maxX, maxY, minZ, r, g, b, axx);
      i(bufferBuilder, matrix, maxX, maxY, minZ, maxX, maxY, maxZ, r, g, b, axx);
      i(bufferBuilder, matrix, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, axx);
      i(bufferBuilder, matrix, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, axx);
      i(bufferBuilder, matrix, minX, minY, minZ, minX, maxY, minZ, r, g, b, axx);
      i(bufferBuilder, matrix, maxX, minY, minZ, maxX, maxY, minZ, r, g, b, axx);
      i(bufferBuilder, matrix, maxX, minY, maxZ, maxX, maxY, maxZ, r, g, b, axx);
      i(bufferBuilder, matrix, minX, minY, maxZ, minX, maxY, maxZ, r, g, b, axx);
      tesselator.end();
      var10000 = ax;
      if (a >= 0L) {
         if (!ax) {
            bufferBuilder.begin(a<"ñ">(7313928177273655449L, (long)a), a<"ñ">(7316592776546632286L, (long)a));
            L(bufferBuilder, matrix, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, axx);
            L(bufferBuilder, matrix, minX, maxY, minZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, r, g, b, axx);
            L(bufferBuilder, matrix, minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ, maxX, minY, minZ, r, g, b, axx);
            L(bufferBuilder, matrix, minX, minY, maxZ, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, axx);
            L(bufferBuilder, matrix, minX, minY, minZ, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, axx);
            L(bufferBuilder, matrix, maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ, r, g, b, axx);
            tesselator.end();
         }

         RenderSystem.enableDepthTest();
         RenderSystem.disableBlend();
         RenderSystem.lineWidth(1.0F);
         var10000 = a<"O">(7315478542933693012L, (long)a);
      }

      if (a > 0L) {
         if (!var10000) {
            return;
         }

         var10000 = ax;
      }

      a<"O">(!var10000, 7315446962438910425L, (long)a);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 45;
               case 2 -> 14;
               case 3 -> 44;
               case 4 -> 1;
               case 5 -> 15;
               case 6 -> 36;
               case 7 -> 9;
               case 8 -> 22;
               case 9 -> 18;
               case 10 -> 41;
               case 11 -> 55;
               case 12 -> 56;
               case 13 -> 29;
               case 14 -> 50;
               case 15 -> 2;
               case 16 -> 7;
               case 17 -> 48;
               case 18 -> 38;
               case 19 -> 0;
               case 20 -> 11;
               case 21 -> 6;
               case 22 -> 61;
               case 23 -> 19;
               case 24 -> 35;
               case 25 -> 59;
               case 26 -> 21;
               case 27 -> 17;
               case 28 -> 24;
               case 29 -> 8;
               case 30 -> 4;
               case 31 -> 32;
               case 32 -> 28;
               case 33 -> 54;
               case 34 -> 26;
               case 35 -> 30;
               case 36 -> 60;
               case 37 -> 49;
               case 38 -> 40;
               case 39 -> 27;
               case 40 -> 23;
               case 41 -> 3;
               case 42 -> 58;
               case 43 -> 51;
               case 44 -> 34;
               case 45 -> 20;
               case 46 -> 63;
               case 47 -> 10;
               case 48 -> 31;
               case 49 -> 43;
               case 50 -> 33;
               case 51 -> 37;
               case 52 -> 52;
               case 53 -> 53;
               case 54 -> 13;
               case 55 -> 16;
               case 56 -> 57;
               case 57 -> 5;
               case 58 -> 46;
               case 59 -> 39;
               case 60 -> 62;
               case 61 -> 25;
               case 62 -> 12;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static void e(long var0) {
      var0 = a ^ var0;
      a<"ñ">(-3795826394438975115L, var0).set(RenderSystem.getModelViewMatrix());
      a<"ñ">(-3799816097778825585L, var0).set(RenderSystem.getProjectionMatrix());
   }

   public static void i(BufferBuilder a, Matrix4f x2, float matrix, float x1, float y1, float a, float z1, float g, float z2, float b, float buffer, float r) {
      a.vertex(x2, (float)matrix, x1, y1).color(z2, b, (float)buffer, r).endVertex();
      a.vertex(x2, a, z1, g).color(z2, b, (float)buffer, r).endVertex();
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'N' && var8 != 192 && var8 != 241 && var8 != 'H') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 181) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'O') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'N') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 192) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 241) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      c[0] = "S\u001c':\t\u001dZ\u0012$sJ\u0010\\\u00120qW\u0016\u001e\u0005/f\u0010\u0017H]\u001cq\u0016\u0006U\u000b\f{\u0016\u001fQ\u0007nY\u000b\u0016U";
      c[1] = ",u~vt\u0005,ui*x\n6>}7k\u0000&>z0`\u001flQK\u001a[";
      c[2] = double.class;
      e[2] = "java/lang/Double";
      c[3] = "\u0001)A\"a\u0011\b'Bk\"\u001c\u000e'Vi?\u001aL0I~x\u001b\u001ahhij\u001f\u0017*XZi\f\u0016#TJc\f\u000f'X";
      c[4] = "jD&zU\u0012cJ%3\u0016\u001feJ11\u000b\u0019'].&L\u0018q\u0005\u001d1J\tlS\r;J\u0010h_";
      c[5] = ">\u0015)\u0014`i1Ud\u001fjt4\boYbi9\u000ek\u0012!K2\u001fr\u001bj";
      c[6] = boolean.class;
      e[6] = "java/lang/Boolean";
      c[7] = "3W:sPF<\u0017wxZ[9J|>J]9Ug>ML>]qb\u0011叢厛栨佁栁栮叢桁史佁";
      c[8] = ")MDjxA\"BU%\u0003C0YB{9_7IVD&H1MFb9C\u0006TQn&Y*C\\";
      c[9] = void.class;
      e[9] = "java/lang/Void";
      c[10] = "t\u00053Duh{E~O\u007fu~\u0018u\tos~\u0007n\thby\u000fxU4Ur\u0005yBhRc\u0002qT";
      c[11] = "9M\u0003\u0006{\u0005;SJ~t\t\"P\u0016\u001cw";
      c[12] = float.class;
      e[12] = "java/lang/Float";
      c[13] = "\\x4x\u0014?^f}\u0000\u001b3Ge!e\u0018";
      c[14] = "S\nA\u0016CGS\nVJOHIAVTGKS\u001b\u001bJK@Y\nG]\\\u0000X\u0001AQZW\u0013*[LGZD=PVJKO+\\K^OI\f]]\\";
      c[15] = "<FeVxm<Fr\ntb&\rr\u0014|a<W?;ti7Qp";
      c[16] = "\u0004=1$\"\u0011\u0004=&x.\u001e\u001ev2e=\u0014\u000ev d;\u0011\u001e!kO!\f\u0003,<";
      c[17] = "?t4\u0007sD?t#[\u007fK%?7FlA5?%GjD%hnYrL(t2\u0007NA0h%[";
      c[18] = "R\u0017l*\u001e>P\t%I\u0015%O\fs0\u0012";
      c[19] = "*\u000f5lla*\u000f\"0`n0D\".hm*\u001eo\u000fhf!\t3#g|";
      c[20] = "Y\u0010\u0007!\u0010\u0019Y\u0010\u0010}\u001c\u0016C[\u0010c\u0014\u0015Y\u0001]}\u0018\u001eS\u0010\u0001j\u000f^p\u0014\u001ej/\u0015Y\u0011\u0016}\u0018\u0002";
      c[21] = "B'\u000e{}$B'\u0019'q+Xl\r:b!Hl\n=i>\u0002\u0014\u001f6#";
      c[22] = ";A\u0000k\u00137;A\u00177\u001f8!\n\u0003*\f21\n\u0011+\n7!]Z\t\u0017(<J\u0013\u0000\u0010*<P\r";
      c[23] = int.class;
      e[23] = "java/lang/Integer";
      c[24] = "+I\fb#, F\u001d-B\"+M\u0019w";
      c[25] = "Ho5K#u\u001bq'PFtw\"/N|cFx:O:";
      c[26] = "z|<\u0001\u0012\u0015=,9Wk伥桞叓佞桾桲桡厄叓叀g\u0000\u0005'h|\f[\u0012~s";
      c[27] = "b'\\\"\u001c\u0006l!SM4$A\u0016u\u001a<(M\u0006aM\u0011\u0005m$^\"\u001f\u0003b";
      c[28] = "'uW4Psd%Nu:bI)\f\u007f\u000b7I\u0019\u000f!Xn\"'\f$\u0005g";
      c[29] = "lh\u0007[=\u0014?v\u0015@X\u001bS%\u001d^b\u0002b\u007f\b_$";
      c[30] = "w3}B@\r,mgC;R\u001ag0\u001c\u0002\u0001\u001aW6GZQ|3<\\TU";
      c[31] = "<3Fk\t0{cC=p4\u0001b\bh\u001b,o-Bk\u0012]<.\u001cf\u00013sd\u001fop";
      c[32] = "lO.JPA~\u001d2@0@QJo\u0000\r\u0010QsgTRL:MdQ\u000fE";
      c[33] = "H=G\u001eLB]eFJ/It<\tE\u0012\u001at\u0005\u0001\u0011ME\u001f;\u0002\u0014\u0010L";
      c[34] = "{x\u0004gZt8(\u001d&0e\u0015$_,\u00012\u0015\u0014\\rRi~*_w\u000f`";
      c[35] = "rIA@6E1\u0019X\u0001\\T\u001c\u0015\u001a\u000bm\u0002\u001c%\u0019U>Xw\u001b\u001aPcQ";
      c[36] = "s\u0003\u0000Tv\u001b \u001d\u0012O\u0013\u0019LN\u001aQ)\r}\u0014\u000fPo";
      c[37] = "\u001a\u007f8\u0002\"\u0018K*%\u0013@F$-cC{\u0015CCZ\u00160\u0012\u001e(\"\u0012yT\u000e";
      c[38] = "\u0017I\u0014*%*X\u0017\u000f&\u001by(\u001b\u001d% uWE\u0011.q\u0016";
      c[39] = "r[j?5\u0011g\u0001y<\tOH\r r9\u0018H=#*kC#\u0003 /6J";
      c[40] = "t|\u0004f_ua$\u00052<~H}J=\u0001.HDBi^r#zAl\u0003{";
      c[41] = "'&\u0002t<\u00062|\u0011w\u0000X\u001dpH9?\u0007\u001d@KabTv~Hd?]";
      c[42] = "\r(\u001b \bi\u001fz\u0007*hh0-ZeY<0\u0014R>\nd[*Q;Wm";
      c[43] = "-zG1\u0010!?([;p \u0010\u007f\u0006{Ms\u0010F\u000e/\u0012,{x\r*O%";
      c[44] = "\u000e<1\u000e;m\u0005=8_\u0002g?1\"\u00078s\u000ek7\u0006~";
      c[45] = "Ug^/8\u0012G5B%X\u0013hb\u001fjiEh[\u00171:\u001f\u0003e\u00144g\u0016";
      c[46] = "$N\u0006\"'Z|\u0016S7Yw\u001f\u0015P9bW`K\\234";
      c[47] = "S\t\"d\\-\u001cW9hbMl[+kYr\u0013\u0005'`\b\u0011R\u000bx|\u0000s\u0000X{bb";
      c[48] = "Eh\u000e\u00157&\u001d0[\u0000I\u0001~3X\u000er+\u0001mT\u0005#H@c\u000b\u0019+*\u00120\b\u0007I";
      c[49] = "\u0013zf\u0015\f|\u001d|iz$^0KO-,R<[W!4I;N\u0000\u0013\u0004u\u0015ro\u001d\u0002z";
      c[50] = "VFy8ct\u0011\u0016|n\u001a栀桲叩伛伃佇叚桲栳厅^qd\u000bR95*sRI";
      c[51] = "Z^\u0011}XK\u0019\u000e\b<2Z4\u0002J6\u0002\u000542IhPV_\fJm\r_";
      c[52] = "\u0018Hr|9l\n\u001anvYm%M36d?%t;b;aNJ8gfh";
      c[53] = "j&[I[2d T&c\u0007B\u0003{i{\u0010T\u0011a|~\u0005\u0003#Q@P9l-WO";
      c[54] = "lOt\u0005_?oPzTc-W\u001c=Q]xW-h\u0016Yy:\u0017{\u000b\ny";
      c[55] = "S\u0015\u0019i\u0007;X\u0014\u00108>2b\u0018\n`\u0004%SB\u001faB";
      c[56] = "\b\u0007CO0n\u0006\u0001L \r\\('~ =m\u0007\u0004AO3k\b";
      c[57] = "\u000f\u001a&$)bHJ#rPu2Jp(klM\u0014|#:\u000f";
      c[58] = "\u0010\bx\u0006\u0017?SXaG}.~T#MMp~d \u0013\u001f\"\u0015Z#\u0016B+";
      c[59] = "X?u4\u0011J\u001bolu{[6c.\u007fJ\u000f6S-!\u0019W]m.$D^";
      c[60] = "^} \u001aY\tL/<\u00109\bcxa_\b_cAi\u0004[\u0004\b\u007fj\u0001\u0006\r";
      c[61] = "n{\r m6ez\u0004qT>_v\u001e)n(n,\u000b((";
      c[62] = "}\r{]=I:]~\u000bDF@]-Q\u007fG?\u0003!Z.$~\r~F&F,^}XD";
      c[63] = "zr\u0005\u0001\u0015Po(\u0016\u0002)\u000e@$OL\u0019X@\u0014L\u0014K\u0002+*O\u0011\u0016\u000b";
      c[64] = "\u0014\u000e,>hjK\u001dl#\u0014t-M,n-$-w{=$~\u001cO%0mb";
      c[65] = "\t\bHM\u001aNNXM\u001bc叠佩桽桮叨厠栺号厧桮+\b^T\u001c\b@SI\r\u0007";
      c[66] = "|I\u0006^0i3\u0017\u001dR\u000e\tC\u001b\u000fQ56<E\u0003ZdU";
      c[67] = ";\u0007\f\u0005{\bh\u0019\u001e\u001e\u001e\b\u0004J\u0016\u0000$\u001e5\u0010\u0003\u0001b";
      c[68] = "R\bTF\\ GPU\u0012?+n\t\u001a\u001d\u0002yn0\u0012I]'\u0005\u000e\u0011L\u0000.";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/友友树何树树友树友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static void a(long a, PoseStack b, AABB g, float a, float var5, float poseStack, float bb) {
      a = 友友树何树树友树友何.a ^ a;
      Matrix4f matrix = b.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(a<"ñ">(3483779651629628882L, (long)a), a<"ñ">(3483984407106295694L, (long)a));
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      a<"O">(3483419552861874402L, (long)a);
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483201643495066253L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3483149594323667868L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3482121935373814187L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      buffer.vertex(
            matrix,
            (float)a<"N">(g, 3481437292125365031L, (long)a),
            (float)a<"N">(g, 3481544483724310024L, (long)a),
            (float)a<"N">(g, 3483819665455471478L, (long)a)
         )
         .color((float)a, var5, (float)poseStack, (float)bb)
         .endVertex();
      BufferUploader.drawWithShader(buffer.end());
      a<"O">(!a<"O">(3482857011289016196L, (long)a), 3481879886147372851L, (long)a);
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   public static void m(long a, PoseStack a, Entity var3, int poseStack, float color) {
      a = 友友树何树树友树友何.a ^ a;
      long ax = a ^ 92368735310243L;
      EntityRenderDispatcher renderManager = mc.getEntityRenderDispatcher();
      Camera camera = a<"N">(renderManager, -5198834016869661805L, (long)a);
      double partialTicks = mc.getFrameTime();
      double x = a<"N">(var3, -5199369246444266328L, (long)a)
         + (var3.getX() - a<"N">(var3, -5199369246444266328L, (long)a)) * partialTicks
         - camera.getPosition().x();
      double y = a<"N">(var3, -5198152785221855032L, (long)a)
         + (var3.getY() - a<"N">(var3, -5198152785221855032L, (long)a)) * partialTicks
         - camera.getPosition().y();
      double z = a<"N">(var3, -5198871923217253991L, (long)a)
         + (var3.getZ() - a<"N">(var3, -5198871923217253991L, (long)a)) * partialTicks
         - camera.getPosition().z();
      AABB bb = var3.getBoundingBox().move(-var3.getX(), -var3.getY(), -var3.getZ());
      float axx = (poseStack >> 24 & 0xFF) / 255.0F;
      float r = (poseStack >> 16 & 0xFF) / 255.0F;
      float g = (poseStack >> 8 & 0xFF) / 255.0F;
      float b = (poseStack & 255) / 255.0F;
      a.pushPose();
      a.translate(x, y, z);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      RenderSystem.lineWidth((float)color);
      RenderSystem.disableDepthTest();
      a(ax, a, bb, r, g, b, axx);
      RenderSystem.enableDepthTest();
      RenderSystem.lineWidth(1.0F);
      RenderSystem.disableBlend();
      a.popPose();
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static Vector4f o(long a, Entity var2) {
      a = 友友树何树树友树友何.a ^ a;
      long ax = a ^ 54906825156491L;
      long axx = a ^ 36082494486872L;
      int var10000 = a<"O">(5041968386676104525L, (long)a);
      AABB bb = X(var2, ax);
      int axxx = (boolean)var10000;
      List<Vector3f> vectors = Arrays.asList(
         new Vector3f(
            (float)a<"N">(bb, 5043944643046233736L, (long)a),
            (float)a<"N">(bb, 5043406352016358404L, (long)a),
            (float)a<"N">(bb, 5042322224241704738L, (long)a)
         ),
         new Vector3f(
            (float)a<"N">(bb, 5043944643046233736L, (long)a),
            (float)a<"N">(bb, 5043981466115294119L, (long)a),
            (float)a<"N">(bb, 5042322224241704738L, (long)a)
         ),
         new Vector3f(
            (float)a<"N">(bb, 5042235193899499059L, (long)a),
            (float)a<"N">(bb, 5043406352016358404L, (long)a),
            (float)a<"N">(bb, 5042322224241704738L, (long)a)
         ),
         new Vector3f(
            (float)a<"N">(bb, 5042235193899499059L, (long)a),
            (float)a<"N">(bb, 5043981466115294119L, (long)a),
            (float)a<"N">(bb, 5042322224241704738L, (long)a)
         ),
         new Vector3f(
            (float)a<"N">(bb, 5043944643046233736L, (long)a),
            (float)a<"N">(bb, 5043406352016358404L, (long)a),
            (float)a<"N">(bb, 5041286855074590425L, (long)a)
         ),
         new Vector3f(
            (float)a<"N">(bb, 5043944643046233736L, (long)a),
            (float)a<"N">(bb, 5043981466115294119L, (long)a),
            (float)a<"N">(bb, 5041286855074590425L, (long)a)
         ),
         new Vector3f(
            (float)a<"N">(bb, 5042235193899499059L, (long)a),
            (float)a<"N">(bb, 5043406352016358404L, (long)a),
            (float)a<"N">(bb, 5041286855074590425L, (long)a)
         ),
         new Vector3f(
            (float)a<"N">(bb, 5042235193899499059L, (long)a),
            (float)a<"N">(bb, 5043981466115294119L, (long)a),
            (float)a<"N">(bb, 5041286855074590425L, (long)a)
         )
      );
      Vector4f entityPos = new Vector4f(Float.MAX_VALUE, Float.MAX_VALUE, -1.0F, -1.0F);
      double guiScale = mc.getWindow().getGuiScale();
      Iterator var14 = vectors.iterator();

      label53:
      while (true) {
         Object var18;
         if (var14.hasNext()) {
            var18 = var14.next();
         } else {
            var18 = entityPos;
            if (a > 0L) {
               return entityPos;
            }
         }

         do {
            label55: {
               Vector3f vector3f = (Vector3f)var18;
               vector3f = J(
                  a<"N">(vector3f, 5043597728915486240L, (long)a),
                  a<"N">(vector3f, 5043176752480612494L, (long)a),
                  a<"N">(vector3f, 5042361280563729995L, (long)a),
                  (float)guiScale,
                  axx
               );
               Vector3f var19 = vector3f;
               if (a >= 0L) {
                  if (vector3f == null) {
                     if (!axxx) {
                        continue label53;
                     }
                     break label55;
                  }

                  var19 = vector3f;
               }

               double var21;
               var10000 = (var21 = a<"N">(var19, 5042361280563729995L, (long)a) - 0.0) == 0.0 ? 0 : (var21 < 0.0 ? -1 : 1);
               if (a > 0L) {
                  if (var10000 < 0) {
                     if (!axxx) {
                        continue label53;
                     }
                     break label55;
                  }

                  double var22;
                  var10000 = (var22 = a<"N">(vector3f, 5042361280563729995L, (long)a) - 1.0) == 0.0 ? 0 : (var22 < 0.0 ? -1 : 1);
               }

               if (a > 0L) {
                  if (var10000 < 0) {
                     a<"À">(
                        entityPos,
                        Math.min(a<"N">(vector3f, 5043597728915486240L, (long)a), a<"N">(entityPos, 5035530044956056422L, (long)a)),
                        5035530044956056422L,
                        (long)a
                     );
                     a<"À">(
                        entityPos,
                        Math.min(a<"N">(vector3f, 5043176752480612494L, (long)a), a<"N">(entityPos, 5041638604604604475L, (long)a)),
                        5041638604604604475L,
                        (long)a
                     );
                     a<"À">(
                        entityPos,
                        Math.max(a<"N">(vector3f, 5043597728915486240L, (long)a), a<"N">(entityPos, 5041780661654819588L, (long)a)),
                        5041780661654819588L,
                        (long)a
                     );
                     a<"À">(
                        entityPos,
                        Math.max(a<"N">(vector3f, 5043176752480612494L, (long)a), a<"N">(entityPos, 5041338260785954531L, (long)a)),
                        5041338260785954531L,
                        (long)a
                     );
                  }

                  if (!axxx) {
                     continue label53;
                  }
               } else if (var10000 == 0) {
                  continue label53;
               }
            }

            var18 = entityPos;
         } while (!(a > 0L));

         return entityPos;
      }
   }

   public static void p(
      PoseStack a,
      int height,
      int textureWidth,
      int textureHeight,
      int poseStack,
      float yPos,
      float xPos,
      Entity entity,
      ResourceLocation c,
      boolean c1,
      long width,
      Color var12,
      Color c2,
      Color texture,
      Color rotate
   ) {
      width = (int)(友友树何树树友树友何.a ^ width);
      long ax = width ^ 77751248029367L;
      a<"O">(2501907795240974861L, (long)width);
      EntityRenderDispatcher renderManager = mc.getEntityRenderDispatcher();
      Quaternionf cameraRotation = a<"N">(renderManager, 2501889013162628849L, (long)width).rotation();
      double x = a<"N">(entity, 2502409278822795722L, (long)width)
         + (entity.getX() - a<"N">(entity, 2502409278822795722L, (long)width)) * mc.getFrameTime()
         - a<"N">(renderManager, 2501889013162628849L, (long)width).getPosition().x();
      double y = a<"N">(entity, 2503444326565170602L, (long)width)
         + 1.0
         + (entity.getY() + 1.0 - (a<"N">(entity, 2503444326565170602L, (long)width) + 1.0)) * mc.getFrameTime()
         - a<"N">(renderManager, 2501889013162628849L, (long)width).getPosition().y();
      double z = a<"N">(entity, 2502755968344173819L, (long)width)
         + (entity.getZ() - a<"N">(entity, 2502755968344173819L, (long)width)) * mc.getFrameTime()
         - a<"N">(renderManager, 2501889013162628849L, (long)width).getPosition().z();
      a.pushPose();
      a.translate(x, y, z);
      a.mulPose(cameraRotation);
      if (c1) {
         float angle = (float)(Math.sin(System.currentTimeMillis() / 800.0) * 360.0);
         a.mulPose(new Quaternionf().rotationAxis((float)Math.toRadians(angle), 0.0F, 0.0F, 1.0F));
      }

      a.scale(0.03F, 0.03F, 0.03F);
      RenderSystem.enableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShaderTexture(0, c);
      RenderSystem.texParameter(3553, 10241, 9729);
      RenderSystem.texParameter(3553, 10240, 9729);
      Object[] var10015 = new Object[]{null, null, null, null, null, null, null, null, null, Float.valueOf((float)xPos), var12, c2, texture, rotate};
      var10015[8] = Float.valueOf((float)yPos);
      var10015[7] = Integer.valueOf((int)poseStack);
      var10015[6] = Integer.valueOf((int)textureHeight);
      var10015[5] = 0.0F;
      var10015[4] = 0.0F;
      var10015[3] = Integer.valueOf((int)textureWidth);
      var10015[2] = height;
      var10015[1] = a;
      var10015[0] = ax;
      RenderUtils.L(var10015);
      RenderSystem.disableBlend();
      RenderSystem.enableDepthTest();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      a.popPose();
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void j(boolean var0) {
      友友何何友友树何何友 = var0;
   }

   public static void q(PoseStack a, long a) {
      a = 友友树何树树友树友何.a ^ a;
      a<"ñ">(-8976347619260359080L, a).set(a.last().pose());
   }

   public static boolean r() {
      G();

      try {
         return true;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   public static void y(long a, PoseStack step, Entity matrix, float delta, float a) {
      a = 友友树何树树友树友何.a ^ a;
      Camera camera = a<"N">(mc.getEntityRenderDispatcher(), 7682436545927618260L, (long)a);
      int var10000 = a<"O">(7682453197430075944L, (long)a);
      Vec3 cameraPos = camera.getPosition();
      double prevSinAnim = Math.abs(1.0 + Math.sin(a - 0.45F)) / 2.0;
      double sinAnim = Math.abs(1.0 + Math.sin(a)) / 2.0;
      double x = a<"N">(matrix, 7681173579256649505L, (long)a) + (matrix.getX() - a<"N">(matrix, 7681173579256649505L, (long)a)) * delta - cameraPos.x();
      double y = a<"N">(matrix, 7682817070721886279L, (long)a)
         + (matrix.getY() - a<"N">(matrix, 7682817070721886279L, (long)a)) * delta
         - cameraPos.y()
         + prevSinAnim * matrix.getBbHeight();
      int ax = (byte)var10000;
      double z = a<"N">(matrix, 7682069752992715466L, (long)a) + (matrix.getZ() - a<"N">(matrix, 7682069752992715466L, (long)a)) * delta - cameraPos.z();
      double nextY = a<"N">(matrix, 7682817070721886279L, (long)a)
         + (matrix.getY() - a<"N">(matrix, 7682817070721886279L, (long)a)) * delta
         - cameraPos.y()
         + sinAnim * matrix.getBbHeight();
      step.pushPose();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      bufferBuilder.begin(a<"ñ">(7681247954028255505L, (long)a), a<"ñ">(7679623084005608772L, (long)a));
      int count = 1;
      int i = 0;

      do {
         var10000 = ax;
         if (a > 0L) {
            if (ax != 0) {
               break;
            }

            var10000 = count % 2;
         }

         label23: {
            if (var10000 == 0) {
               var30 = HUD.instance.getColor(1);
               if (a <= 0L) {
                  break label23;
               }
            }

            var30 = HUD.instance.getColor(4);
         }

         Color color = var30;
         float cos = (float)(
            x
               + Math.cos(i * 6.28 / 360.0)
                  * (
                     a<"N">(matrix.getBoundingBox(), 7682221513443643734L, (long)a)
                        - a<"N">(matrix.getBoundingBox(), 7681616078156823021L, (long)a)
                        + (a<"N">(matrix.getBoundingBox(), 7679510777461932476L, (long)a) - a<"N">(matrix.getBoundingBox(), 7682235700985319495L, (long)a))
                  )
                  * 0.5
         );
         float sin = (float)(
            z
               + Math.sin(i * 6.28 / 360.0)
                  * (
                     a<"N">(matrix.getBoundingBox(), 7682221513443643734L, (long)a)
                        - a<"N">(matrix.getBoundingBox(), 7681616078156823021L, (long)a)
                        + (a<"N">(matrix.getBoundingBox(), 7679510777461932476L, (long)a) - a<"N">(matrix.getBoundingBox(), 7682235700985319495L, (long)a))
                  )
                  * 0.5
         );
         bufferBuilder.vertex(step.last().pose(), cos, (float)nextY, sin).color(color.getRGB()).endVertex();
         bufferBuilder.vertex(step.last().pose(), cos, (float)y, sin).color(树树何友友友友何树友.z(color, 0.0F).getRGB()).endVertex();
         count++;
         i += 8;
         BufferUploader.drawWithShader(bufferBuilder.end());
         RenderSystem.enableCull();
         RenderSystem.disableDepthTest();
         RenderSystem.disableBlend();
         step.popPose();
      } while (a < 0L);
   }

   public static void A(PoseStack a, AABB a, boolean var2, int outline, long color) {
      long ax = 友友树何树树友树友何.a ^ color ^ 47655368609658L;
      Z(ax, a, a, var2, outline, 1.0F);
   }

   public static AABB X(Entity a, long a) {
      a = 友友树何树树友树友何.a ^ a;
      float ticks = mc.getFrameTime();
      Vec3 pos = new Vec3(
         Mth.lerp(ticks, a<"N">(a, -839591211507922463L, a), a.getX()),
         Mth.lerp(ticks, a<"N">(a, -837959827285215609L, a), a.getY()),
         Mth.lerp(ticks, a<"N">(a, -838761154496574454L, a), a.getZ())
      );
      return a.getBoundingBox().move(pos.subtract(a.position()));
   }

   public static void L(
      BufferBuilder a,
      Matrix4f x2,
      float y3,
      float matrix,
      float y1,
      float x4,
      float x1,
      float g,
      float a,
      float z1,
      float b,
      float buffer,
      float z4,
      float x3,
      float y4,
      float y2,
      float z3,
      float z2
   ) {
      a.vertex(x2, y3, (float)matrix, y1).color(y4, y2, z3, z2).endVertex();
      a.vertex(x2, x4, x1, g).color(y4, y2, z3, z2).endVertex();
      a.vertex(x2, a, z1, b).color(y4, y2, z3, z2).endVertex();
      a.vertex(x2, (float)buffer, z4, x3).color(y4, y2, z3, z2).endVertex();
   }

   public static void M(PoseStack a, Entity radius, double var2, int var4, float color, Color accuracy, long poseStack, float entity) {
      poseStack = 友友树何树树友树友何.a ^ poseStack;
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableDepthTest();
      RenderSystem.disableCull();
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      RenderSystem.lineWidth(2.0F);
      double x = Mth.lerp(color, a<"N">(radius, -9175962695971476520L, (long)poseStack), radius.getX())
         - a<"N">(a<"N">(mc.getEntityRenderDispatcher(), -9175442413710248733L, (long)poseStack).getPosition(), -9175727516676926211L, (long)poseStack);
      boolean var10000 = a<"O">(-9172811012952533082L, (long)poseStack);
      double y = Mth.lerp(color, a<"N">(radius, -9174892191126917192L, (long)poseStack), radius.getY())
         - a<"N">(a<"N">(mc.getEntityRenderDispatcher(), -9175442413710248733L, (long)poseStack).getPosition(), -9174688673357241426L, (long)poseStack);
      double z = Mth.lerp(color, a<"N">(radius, -9175615594134171927L, (long)poseStack), radius.getZ())
         - a<"N">(a<"N">(mc.getEntityRenderDispatcher(), -9175442413710248733L, (long)poseStack).getPosition(), -9175260704829842435L, (long)poseStack);
      Tesselator tesselator = Tesselator.getInstance();
      BufferBuilder buffer = tesselator.getBuilder();
      int steps = Math.max(1, (int)entity * 5);
      float stepSize = entity * 0.001F;
      int ax = var10000;
      int step = 0;

      while (true) {
         if (step < steps) {
            float adjustedRadius = (float)var2 + step * stepSize;
            buffer.begin(a<"ñ">(-9174022252799493613L, (long)poseStack), a<"ñ">(-9177007377486272653L, (long)poseStack));
            if (poseStack <= 0L) {
               break;
            }

            double angle = Math.toRadians(0.0);
            double xOffset = adjustedRadius * Math.cos(angle);
            double zOffset = adjustedRadius * Math.sin(angle);
            buffer.vertex(a.last().pose(), (float)(x + xOffset), (float)y, (float)(z + zOffset)).color(accuracy.getRGB()).endVertex();

            label32: {
               while (true) {
                  var10000 = ax;
                  if (poseStack <= 0L) {
                     break label32;
                  }

                  if (!ax) {
                     break;
                  }

                  if (poseStack > 0L) {
                     tesselator.end();
                     step++;
                     break;
                  }
               }

               var10000 = ax;
            }

            if (var10000) {
               continue;
            }
         }

         if (poseStack >= 0L) {
            GL11.glDisable(2848);
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
            RenderSystem.lineWidth(1.0F);
         }
         break;
      }
   }

   public static boolean G() {
      return 友友何何友友树何何友;
   }

   public static Vector3f K(Player a, long partialTick, float a) {
      partialTick = 友友树何树树友树友何.a ^ partialTick;
      long ax = (long)(partialTick ^ 22155469267474L);
      double x = Mth.lerp(a, a<"N">(a, 6821310309255129668L, (long)partialTick), a.getX());
      double y = Mth.lerp(a, a<"N">(a, 6823917508210081140L, (long)partialTick), a.getY()) + a.getBbHeight() + 0.5;
      double z = Mth.lerp(a, a<"N">(a, 6823253069913043449L, (long)partialTick), a.getZ());
      return J((float)x, (float)y, (float)z, (float)mc.getWindow().getGuiScale(), ax);
   }

   private static String HE_SHU_YOU() {
      return "职业技术教育中心学校";
   }
}
