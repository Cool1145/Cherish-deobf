package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.image.BufferedImage;
import java.awt.image.Kernel;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树友树何友树树何何友 extends 何树友友何何友何友友 implements 何树友 {
   protected float 树树何树何友何何树树;
   protected Kernel 友何友树友树树何树何;
   private static final long c;
   private static final String e;
   private static final Object[] j = new Object[18];
   private static final String[] k = new String[18];
   private static String LIU_YA_FENG;

   public 树友树何友树树何何友(long a) {
      long var10001 = c ^ a ^ 118854070575002L;
      int ax = (int)((c ^ a ^ 118854070575002L) >>> 48);
      int axx = (int)((c ^ a ^ 118854070575002L) << 16 >>> 48);
      int var5 = (int)(var10001 << 32 >>> 32);
      this((char)ax, (char)axx, 2.0F, var5);
   }

   public 树友树何友树树何何友(char a, char a, float radius, int a) {
      long var10000 = ((long)a << 48 | (long)a << 48 >>> 16 | (long)a << 32 >>> 32) ^ c;
      long ax = ((long)a << 48 | (long)a << 48 >>> 16 | (long)a << 32 >>> 32) ^ c ^ 55306574826231L;
      long var10001 = ((long)a << 48 | (long)a << 48 >>> 16 | (long)a << 32 >>> 32) ^ c ^ 116233836707014L;
      int axx = (int)((var10000 ^ 116233836707014L) >>> 48);
      long axxx = var10001 << 16 >>> 16;
      super((char)axx, axxx);
      this.S(ax, radius);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2686073138470423615L, -7848712488524205351L, MethodHandles.lookup().lookupClass()).a(179146328163683L);
      // $VF: monitorexit
      c = var10000;
      c();
      long var0 = c ^ 28974440698147L;
      Cipher var2;
      Cipher var4 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var4.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var5 = b(var2.doFinal("÷\u0080_\u0098âbã}Ó\u0014\u007fQ:À(Ü<NKe¼\u0005(9".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      e = var5;
   }

   @Override
   public String toString() {
      long var10000 = c ^ 6295937030192L;
      return e;
   }

   public void S(long a, float a) {
      a = c ^ a;
      long ax = a ^ 111383248300068L;
      c<"î">(this, (float)a, -8308594325813149127L, (long)a);
      c<"î">(this, X(ax, (float)a), -8308815945068545553L, (long)a);
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 31;
               case 1 -> 42;
               case 2 -> 1;
               case 3 -> 34;
               case 4 -> 22;
               case 5 -> 4;
               case 6 -> 30;
               case 7 -> 19;
               case 8 -> 47;
               case 9 -> 63;
               case 10 -> 15;
               case 11 -> 57;
               case 12 -> 16;
               case 13 -> 37;
               case 14 -> 48;
               case 15 -> 56;
               case 16 -> 41;
               case 17 -> 8;
               case 18 -> 21;
               case 19 -> 62;
               case 20 -> 39;
               case 21 -> 44;
               case 22 -> 55;
               case 23 -> 50;
               case 24 -> 54;
               case 25 -> 26;
               case 26 -> 25;
               case 27 -> 10;
               case 28 -> 11;
               case 29 -> 12;
               case 30 -> 18;
               case 31 -> 28;
               case 32 -> 9;
               case 33 -> 14;
               case 34 -> 5;
               case 35 -> 45;
               case 36 -> 61;
               case 37 -> 33;
               case 38 -> 27;
               case 39 -> 53;
               case 40 -> 59;
               case 41 -> 36;
               case 42 -> 52;
               case 43 -> 51;
               case 44 -> 35;
               case 45 -> 23;
               case 46 -> 43;
               case 47 -> 20;
               case 48 -> 38;
               case 49 -> 3;
               case 50 -> 40;
               case 51 -> 46;
               case 52 -> 32;
               case 53 -> 6;
               case 54 -> 2;
               case 55 -> 49;
               case 56 -> 17;
               case 57 -> 29;
               case 58 -> 0;
               case 59 -> 13;
               case 60 -> 24;
               case 61 -> 60;
               case 62 -> 7;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               if (var10 < 0) {
                  var10 += 128;
               }

               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var15 = var7[var13 % var7.length];
               if (var15 == 0) {
                  break;
               }

               var12[var13] = (char)(var12[var13] ^ var15);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static void c() {
      j[0] = "\u000eK\u0017&\u0001j\u0001\u000bZ-\u000bw\u0004VQk\u001bq\u0004IJk\u001c`\u0003A\\7@栔厦栴佬厎桿栔伸佰史";
      j[1] = "_Un|\\AB@6t\u001fARQ6V\u0017R[Qt";
      j[2] = float.class;
      k[2] = "java/lang/Float";
      j[3] = "\u0001\rL\u000f`5\u000eM\u0001\u0004j(\u000b\u0010\nBz.\u000b\u000f\u0011B}?\f\u0007\u0007\u001e!伏厩伶厩桽叄伏伷伶伷";
      j[4] = boolean.class;
      k[4] = "java/lang/Boolean";
      j[5] = "m$4FeIbdyMoTg9r\u000b\u007fRg&i\u000bxC`.\u007fW$佳栟厁发佰佟叭佛厁发";
      j[6] = int.class;
      k[6] = "java/lang/Integer";
      j[7] = "e\u0002\u0001(\u0005Cn\r\u0010gyZa\u0017\u001e$Njw\u0000\u00129_F`\r";
      j[8] = "\u0000[EW\n-\u000bTT\u0018k#\u0000_PB";
      j[9] = "\u001a\fbr=`\u0013@w\u0003厕伅叨栫又栚桏伅栲佯\u000b:f6R\fu}01I";
      j[10] = "{9-\u001b\u0001\u007fru8j桳桞众栞伙厩伷会桓栞DS\u0005y(x\u007fRV+(";
      j[11] = "I\u001f\u0015<%n\u0017\u001f_#N发厶另厦休伓栋伨格桼Lu}NW^|u/\u0012]";
      j[12] = "\u0014?TF:!\u0013iL\u0006S\u0001.hIC!f\u001eh\u001b\u001f+]";
      j[13] = "\u0019\u000fqdSF\u001eYi$:t#XlaH\u0001\u0013X>=B:";
      j[14] = "$(G](dz(\rBC叛佅发叴叮厀栁佅住佪-\u007fcvt\rN*gu#";
      j[15] = "\u0011/]Ne9O/\u0017Q\u000e桜叮取佰佣反历佰取栴>2>Cs\u0017]g:@$";
      j[16] = "*'\u0007*X(#k\u0012[Z\u0010&rU'\u0002){c\u001383-p\"\u0012j\npad\r[";
      j[17] = "U\u001eq3zz\u000b\u001e;,\u0011叅伴佹作桚叒栟桰叧作C*iRV:s*;\u000e\\";
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         MethodHandle var9;
         if (var8 != 203 && var8 != 238 && var8 != 'm' && var8 != 217) {
            var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 253) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'f') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 203) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 238) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'm') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName())
            .append(" : ")
            .append(var10 != null ? var10.toString() : (var11 != null ? var11.toString() : " null "))
            .append(" : ")
            .append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/树友树何友树树何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      Method var5 = e(var0, var1, var2, var3, var4);
      if (var5 != null) {
         return var5;
      } else {
         Class[] var6 = var0.getInterfaces();
         if (var6 != null) {
            for (int var7 = 0; var7 < var6.length; var7++) {
               var5 = f(var6[var7], var1, var2, var3, var4);
               if (var5 != null) {
                  return var5;
               }
            }
         }

         return null;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      Field var3 = e(var0, var1, var2);
      if (var3 != null) {
         return var3;
      } else {
         Class[] var4 = var0.getInterfaces();
         if (var4 != null) {
            for (int var5 = 0; var5 < var4.length; var5++) {
               var3 = f(var4[var5], var1, var2);
               if (var3 != null) {
                  return var3;
               }
            }
         }

         return null;
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Class var23 = var8;

         while (true) {
            Method var25 = e(var23, var10, var15, var13, var14);
            if (var25 != null) {
               j[var4] = var25;
               return var25;
            }

            if (var23.getName().equals("java.lang.Object")) {
               break;
            }

            if ((var23 = var23.getSuperclass()) == null) {
               j(599021711878640L, 0L);
               break;
            }
         }

         var23 = var8;

         while (true) {
            Class[] var26;
            if ((var26 = var23.getInterfaces()) != null) {
               for (int var18 = 0; var18 < var26.length; var18++) {
                  Method var19 = f(var26[var18], var10, var15, var13, var14);
                  if (var19 != null) {
                     j[var4] = var19;
                     return var19;
                  }
               }
            }

            if (var23.getName().equals("java.lang.Object")) {
               StringBuffer var27 = new StringBuffer();
               var27.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
               int var28 = 0;

               while (var28 < var13) {
                  var27.append(var14[var28].getName());
                  if (++var28 < var13) {
                     var27.append(", ");
                  }
               }

               var27.append(')');
               throw new RuntimeException(var27.toString());
            }

            if ((var23 = var23.getSuperclass()) == null) {
               var23 = j(599021711878640L, 0L);
            }
         }
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   @Override
   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
      long a;
      long ax;
      boolean axx;
      int width;
      int height;
      label68: {
         a = c ^ 86781404901830L;
         ax = a ^ 77519114246632L;
         boolean var10000 = c<"f">(-6366591794637225363L, a);
         width = src.getWidth();
         axx = var10000;
         height = src.getHeight();
         BufferedImage var20 = dst;
         if (!axx) {
            if (dst != null) {
               break label68;
            }

            var20 = this.createCompatibleDestImage(src, null);
         }

         dst = var20;
      }

      int[] inPixels = new int[width * height];
      int[] outPixels = new int[width * height];
      src.getRGB(0, 0, width, height, inPixels, 0, width);
      if (!axx) {
         if (c<"Ë">(this, -6366792782395807444L, a) > 0.0F) {
            Kernel var21;
            boolean var10005;
            boolean var10006;
            label58: {
               label72: {
                  var21 = c<"Ë">(this, -6366879161687715078L, a);
                  var10005 = c<"Ë">(this, -6366704188200386170L, a);
                  var10006 = c<"Ë">(this, -6366704188200386170L, a);
                  if (!axx) {
                     if (!var10006) {
                        break label72;
                     }

                     var10006 = c<"Ë">(this, -6367412454212958317L, a);
                  }

                  if (axx) {
                     break label58;
                  }

                  if (var10006) {
                     var10006 = true;
                     break label58;
                  }
               }

               var10006 = false;
            }

            label47: {
               label73: {
                  int axxx = c<"m">(-6366475049694835912L, a);
                  int axxxx = var10006;
                  int axxxxx = var10005;
                  r(var21, inPixels, outPixels, ax, width, height, axxxxx, axxxx, false, axxx);
                  var21 = c<"Ë">(this, -6366879161687715078L, a);
                  var10005 = c<"Ë">(this, -6366704188200386170L, a);
                  var10006 = c<"Ë">(this, -6366704188200386170L, a);
                  if (!axx) {
                     if (!var10006) {
                        break label73;
                     }

                     var10006 = c<"Ë">(this, -6367412454212958317L, a);
                  }

                  if (axx) {
                     break label47;
                  }

                  if (var10006) {
                     var10006 = true;
                     break label47;
                  }
               }

               var10006 = false;
            }

            int var18 = c<"m">(-6366475049694835912L, a);
            int axxxxxx = var10006;
            int var19 = var10005;
            r(var21, outPixels, inPixels, ax, height, width, var19, false, axxxxxx, var18);
         }

         dst.setRGB(0, 0, width, height, inPixels, 0, width);
      }

      return dst;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Field)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Class var12 = var8;

         while (true) {
            Field var13 = e(var12, var10, var11);
            if (var13 != null) {
               j[var4] = var13;
               return var13;
            }

            Class[] var14 = var12.getInterfaces();
            if (var14 != null) {
               for (int var15 = 0; var15 < var14.length; var15++) {
                  var13 = f(var14[var15], var10, var11);
                  if (var13 != null) {
                     j[var4] = var13;
                     return var13;
                  }
               }
            }

            if (var12.getName().equals("java.lang.Object")) {
               StringBuffer var19 = new StringBuffer();
               var19.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
               throw new RuntimeException(var19.toString());
            }

            var12 = var12.getSuperclass();
            if (var12 == null) {
               var12 = j(599021711878640L, 0L);
            }
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void r(
      Kernel param0, int[] param1, int[] param2, long param3, int param5, int param6, boolean param7, boolean param8, boolean param9, int param10
   ) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:166)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/utils/render/树友树何友树树何何友.c J
      // 003: lload 3
      // 004: lxor
      // 005: lstore 3
      // 006: lload 3
      // 007: dup2
      // 008: ldc2_w 128721317981166
      // 00b: lxor
      // 00c: lstore 12
      // 00e: pop2
      // 00f: ldc2_w 7506764240121859557
      // 012: lload 3
      // 013: invokedynamic f (JJ)Z bsm=cn/cool/cherish/utils/render/树友树何友树树何何友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 018: aload 0
      // 019: aconst_null
      // 01a: invokevirtual java/awt/image/Kernel.getKernelData ([F)[F
      // 01d: astore 15
      // 01f: istore 14
      // 021: aload 0
      // 022: invokevirtual java/awt/image/Kernel.getWidth ()I
      // 025: istore 16
      // 027: iload 16
      // 029: bipush 2
      // 02a: idiv
      // 02b: istore 17
      // 02d: bipush 0
      // 02e: istore 18
      // 030: iload 18
      // 032: iload 6
      // 034: if_icmpge 2ee
      // 037: iload 18
      // 039: istore 19
      // 03b: iload 18
      // 03d: iload 5
      // 03f: imul
      // 040: istore 20
      // 042: bipush 0
      // 043: istore 21
      // 045: iload 21
      // 047: iload 5
      // 049: if_icmpge 2e0
      // 04c: fconst_0
      // 04d: fstore 22
      // 04f: fconst_0
      // 050: fstore 23
      // 052: fconst_0
      // 053: fstore 24
      // 055: fconst_0
      // 056: fstore 25
      // 058: iload 17
      // 05a: istore 26
      // 05c: iload 17
      // 05e: ineg
      // 05f: iload 14
      // 061: ifne 032
      // 064: istore 27
      // 066: iload 27
      // 068: iload 17
      // 06a: if_icmpgt 20b
      // 06d: aload 15
      // 06f: iload 26
      // 071: iload 27
      // 073: iadd
      // 074: faload
      // 075: fstore 28
      // 077: iload 14
      // 079: lload 3
      // 07a: lconst_0
      // 07b: lcmp
      // 07c: iflt 208
      // 07f: ifne 206
      // 082: fload 28
      // 084: fconst_0
      // 085: fcmpl
      // 086: iload 14
      // 088: lload 3
      // 089: lconst_0
      // 08a: lcmp
      // 08b: ifle 215
      // 08e: ifne 213
      // 091: goto 094
      // 094: ifeq 203
      // 097: goto 09a
      // 09a: iload 21
      // 09c: iload 27
      // 09e: iadd
      // 09f: istore 29
      // 0a1: iload 29
      // 0a3: iload 14
      // 0a5: lload 3
      // 0a6: lconst_0
      // 0a7: lcmp
      // 0a8: ifle 110
      // 0ab: ifne 10e
      // 0ae: ifge 109
      // 0b1: goto 0b4
      // 0b4: iload 10
      // 0b6: ldc2_w 7506810768493872304
      // 0b9: lload 3
      // 0ba: invokedynamic m (JJ)I bsm=cn/cool/cherish/utils/render/树友树何友树树何何友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bf: iload 14
      // 0c1: ifne 0f1
      // 0c4: goto 0c7
      // 0c7: if_icmpne 0db
      // 0ca: goto 0cd
      // 0cd: bipush 0
      // 0ce: istore 29
      // 0d0: iload 14
      // 0d2: lload 3
      // 0d3: lconst_0
      // 0d4: lcmp
      // 0d5: ifle 0dd
      // 0d8: ifeq 16e
      // 0db: iload 10
      // 0dd: iload 14
      // 0df: ifne 175
      // 0e2: goto 0e5
      // 0e5: ldc2_w 7506921203979005690
      // 0e8: lload 3
      // 0e9: invokedynamic m (JJ)I bsm=cn/cool/cherish/utils/render/树友树何友树树何何友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ee: goto 0f1
      // 0f1: if_icmpne 16e
      // 0f4: iload 21
      // 0f6: iload 5
      // 0f8: iadd
      // 0f9: iload 5
      // 0fb: irem
      // 0fc: istore 29
      // 0fe: iload 14
      // 100: lload 3
      // 101: lconst_0
      // 102: lcmp
      // 103: iflt 10b
      // 106: ifeq 16e
      // 109: iload 29
      // 10b: goto 10e
      // 10e: iload 14
      // 110: lload 3
      // 111: lconst_0
      // 112: lcmp
      // 113: ifle 11b
      // 116: ifne 175
      // 119: iload 5
      // 11b: if_icmplt 16e
      // 11e: goto 121
      // 121: iload 10
      // 123: ldc2_w 7506810768493872304
      // 126: lload 3
      // 127: invokedynamic m (JJ)I bsm=cn/cool/cherish/utils/render/树友树何友树树何何友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 12c: iload 14
      // 12e: ifne 161
      // 131: goto 134
      // 134: if_icmpne 14b
      // 137: goto 13a
      // 13a: iload 5
      // 13c: bipush 1
      // 13d: isub
      // 13e: istore 29
      // 140: iload 14
      // 142: lload 3
      // 143: lconst_0
      // 144: lcmp
      // 145: ifle 14d
      // 148: ifeq 16e
      // 14b: iload 10
      // 14d: iload 14
      // 14f: ifne 175
      // 152: goto 155
      // 155: ldc2_w 7506921203979005690
      // 158: lload 3
      // 159: invokedynamic m (JJ)I bsm=cn/cool/cherish/utils/render/树友树何友树树何何友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 15e: goto 161
      // 161: if_icmpne 16e
      // 164: iload 21
      // 166: iload 5
      // 168: iadd
      // 169: iload 5
      // 16b: irem
      // 16c: istore 29
      // 16e: aload 1
      // 16f: iload 20
      // 171: iload 29
      // 173: iadd
      // 174: iaload
      // 175: istore 30
      // 177: iload 30
      // 179: bipush 24
      // 17b: ishr
      // 17c: sipush 255
      // 17f: iand
      // 180: istore 31
      // 182: iload 30
      // 184: bipush 16
      // 186: ishr
      // 187: sipush 255
      // 18a: iand
      // 18b: istore 32
      // 18d: iload 30
      // 18f: bipush 8
      // 191: ishr
      // 192: sipush 255
      // 195: iand
      // 196: istore 33
      // 198: iload 30
      // 19a: sipush 255
      // 19d: iand
      // 19e: istore 34
      // 1a0: iload 14
      // 1a2: lload 3
      // 1a3: lconst_0
      // 1a4: lcmp
      // 1a5: ifle 1ad
      // 1a8: ifne 1f8
      // 1ab: iload 8
      // 1ad: ifeq 1d7
      // 1b0: goto 1b3
      // 1b3: iload 31
      // 1b5: i2f
      // 1b6: ldc_w 0.003921569
      // 1b9: fmul
      // 1ba: fstore 35
      // 1bc: iload 32
      // 1be: i2f
      // 1bf: fload 35
      // 1c1: fmul
      // 1c2: f2i
      // 1c3: istore 32
      // 1c5: iload 33
      // 1c7: i2f
      // 1c8: fload 35
      // 1ca: fmul
      // 1cb: f2i
      // 1cc: istore 33
      // 1ce: iload 34
      // 1d0: i2f
      // 1d1: fload 35
      // 1d3: fmul
      // 1d4: f2i
      // 1d5: istore 34
      // 1d7: fload 25
      // 1d9: fload 28
      // 1db: iload 31
      // 1dd: i2f
      // 1de: fmul
      // 1df: fadd
      // 1e0: fstore 25
      // 1e2: fload 22
      // 1e4: fload 28
      // 1e6: iload 32
      // 1e8: i2f
      // 1e9: fmul
      // 1ea: fadd
      // 1eb: fstore 22
      // 1ed: fload 23
      // 1ef: fload 28
      // 1f1: iload 33
      // 1f3: i2f
      // 1f4: fmul
      // 1f5: fadd
      // 1f6: fstore 23
      // 1f8: fload 24
      // 1fa: fload 28
      // 1fc: iload 34
      // 1fe: i2f
      // 1ff: fmul
      // 200: fadd
      // 201: fstore 24
      // 203: iinc 27 1
      // 206: iload 14
      // 208: ifeq 066
      // 20b: lload 3
      // 20c: lconst_0
      // 20d: lcmp
      // 20e: iflt 28c
      // 211: iload 9
      // 213: iload 14
      // 215: ifne 269
      // 218: ifeq 267
      // 21b: goto 21e
      // 21e: fload 25
      // 220: fconst_0
      // 221: fcmpl
      // 222: iload 14
      // 224: ifne 269
      // 227: goto 22a
      // 22a: ifeq 267
      // 22d: goto 230
      // 230: fload 25
      // 232: ldc_w 255.0
      // 235: fcmpl
      // 236: iload 14
      // 238: lload 3
      // 239: lconst_0
      // 23a: lcmp
      // 23b: ifle 26b
      // 23e: ifne 269
      // 241: goto 244
      // 244: ifeq 267
      // 247: goto 24a
      // 24a: ldc_w 255.0
      // 24d: fload 25
      // 24f: fdiv
      // 250: fstore 27
      // 252: fload 22
      // 254: fload 27
      // 256: fmul
      // 257: fstore 22
      // 259: fload 23
      // 25b: fload 27
      // 25d: fmul
      // 25e: fstore 23
      // 260: fload 24
      // 262: fload 27
      // 264: fmul
      // 265: fstore 24
      // 267: iload 7
      // 269: iload 14
      // 26b: ifne 284
      // 26e: ifeq 287
      // 271: goto 274
      // 274: fload 25
      // 276: f2d
      // 277: ldc2_w 0.5
      // 27a: dadd
      // 27b: d2i
      // 27c: lload 12
      // 27e: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 281: goto 284
      // 284: goto 28a
      // 287: sipush 255
      // 28a: istore 27
      // 28c: fload 22
      // 28e: f2d
      // 28f: ldc2_w 0.5
      // 292: dadd
      // 293: d2i
      // 294: lload 12
      // 296: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 299: istore 28
      // 29b: fload 23
      // 29d: f2d
      // 29e: ldc2_w 0.5
      // 2a1: dadd
      // 2a2: d2i
      // 2a3: lload 12
      // 2a5: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 2a8: istore 29
      // 2aa: fload 24
      // 2ac: f2d
      // 2ad: ldc2_w 0.5
      // 2b0: dadd
      // 2b1: d2i
      // 2b2: lload 12
      // 2b4: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 2b7: istore 30
      // 2b9: aload 2
      // 2ba: iload 19
      // 2bc: iload 27
      // 2be: bipush 24
      // 2c0: ishl
      // 2c1: iload 28
      // 2c3: bipush 16
      // 2c5: ishl
      // 2c6: ior
      // 2c7: iload 29
      // 2c9: bipush 8
      // 2cb: ishl
      // 2cc: ior
      // 2cd: iload 30
      // 2cf: ior
      // 2d0: iastore
      // 2d1: iload 19
      // 2d3: iload 6
      // 2d5: iadd
      // 2d6: istore 19
      // 2d8: iinc 21 1
      // 2db: iload 14
      // 2dd: ifeq 045
      // 2e0: iinc 18 1
      // 2e3: iload 14
      // 2e5: lload 3
      // 2e6: lconst_0
      // 2e7: lcmp
      // 2e8: ifle 032
      // 2eb: ifeq 030
      // 2ee: lload 3
      // 2ef: lconst_0
      // 2f0: lcmp
      // 2f1: ifle 037
      // 2f4: return
   }

   public static Kernel X(long param0, float param2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: Could not find destination nodes for stat id {Do}:33 from source 30_tail
      //   at org.jetbrains.java.decompiler.modules.decompiler.flow.FlattenStatementsHelper.setEdges(FlattenStatementsHelper.java:563)
      //   at org.jetbrains.java.decompiler.modules.decompiler.flow.FlattenStatementsHelper.buildDirectGraph(FlattenStatementsHelper.java:50)
      //   at org.jetbrains.java.decompiler.modules.decompiler.sforms.SFormsConstructor.splitVariables(SFormsConstructor.java:72)
      //   at org.jetbrains.java.decompiler.modules.decompiler.StackVarsProcessor.simplifyStackVars(StackVarsProcessor.java:52)
      //   at org.jetbrains.java.decompiler.modules.decompiler.StackVarsProcessor.simplifyStackVars(StackVarsProcessor.java:40)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:299)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/utils/render/树友树何友树树何何友.c J
      // 03: lload 0
      // 04: lxor
      // 05: lstore 0
      // 06: fload 2
      // 07: f2d
      // 08: invokestatic java/lang/Math.ceil (D)D
      // 0b: d2i
      // 0c: istore 5
      // 0e: iload 5
      // 10: bipush 2
      // 11: imul
      // 12: bipush 1
      // 13: iadd
      // 14: istore 6
      // 16: ldc2_w 3671659989403733508
      // 19: lload 0
      // 1a: invokedynamic f (JJ)Z bsm=cn/cool/cherish/utils/render/树友树何友树树何何友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f: iload 6
      // 21: newarray 6
      // 23: astore 7
      // 25: fload 2
      // 26: ldc_w 3.0
      // 29: fdiv
      // 2a: fstore 8
      // 2c: fconst_2
      // 2d: fload 8
      // 2f: fmul
      // 30: fload 8
      // 32: fmul
      // 33: fstore 9
      // 35: ldc_w 6.2831855
      // 38: fload 8
      // 3a: fmul
      // 3b: fstore 10
      // 3d: fload 10
      // 3f: f2d
      // 40: invokestatic java/lang/Math.sqrt (D)D
      // 43: d2f
      // 44: fstore 11
      // 46: istore 4
      // 48: fload 2
      // 49: fload 2
      // 4a: fmul
      // 4b: fstore 12
      // 4d: fconst_0
      // 4e: fstore 13
      // 50: bipush 0
      // 51: istore 14
      // 53: iload 5
      // 55: ineg
      // 56: istore 15
      // 58: iload 15
      // 5a: iload 5
      // 5c: if_icmpgt c4
      // 5f: iload 15
      // 61: iload 15
      // 63: imul
      // 64: i2f
      // 65: fstore 16
      // 67: iload 4
      // 69: lload 0
      // 6a: lconst_0
      // 6b: lcmp
      // 6c: iflt 90
      // 6f: ifeq 8e
      // 72: fload 16
      // 74: fload 12
      // 76: fcmpl
      // 77: iload 4
      // 79: ifeq cb
      // 7c: goto 7f
      // 7f: ifle 99
      // 82: goto 85
      // 85: aload 7
      // 87: iload 14
      // 89: fconst_0
      // 8a: fastore
      // 8b: goto 8e
      // 8e: iload 4
      // 90: lload 0
      // 91: lconst_0
      // 92: lcmp
      // 93: ifle c1
      // 96: ifne af
      // 99: aload 7
      // 9b: iload 14
      // 9d: fload 16
      // 9f: fneg
      // a0: fload 9
      // a2: fdiv
      // a3: f2d
      // a4: invokestatic java/lang/Math.exp (D)D
      // a7: d2f
      // a8: fload 11
      // aa: fdiv
      // ab: fastore
      // ac: goto af
      // af: fload 13
      // b1: aload 7
      // b3: iload 14
      // b5: faload
      // b6: fadd
      // b7: fstore 13
      // b9: iinc 14 1
      // bc: iinc 15 1
      // bf: iload 4
      // c1: ifne 58
      // c4: lload 0
      // c5: lconst_0
      // c6: lcmp
      // c7: ifle cd
      // ca: bipush 0
      // cb: istore 15
      // cd: iload 15
      // cf: iload 6
      // d1: if_icmpge e6
      // d4: aload 7
      // d6: iload 15
      // d8: dup2
      // d9: faload
      // da: fload 13
      // dc: fdiv
      // dd: fastore
      // de: iinc 15 1
      // e1: iload 4
      // e3: ifne cd
      // e6: lload 0
      // e7: lconst_0
      // e8: lcmp
      // e9: iflt e1
      // ec: new java/awt/image/Kernel
      // ef: dup
      // f0: iload 6
      // f2: bipush 1
      // f3: aload 7
      // f5: invokespecial java/awt/image/Kernel.<init> (II[F)V
      // f8: areturn
   }

   public float M(long a) {
      a = c ^ a;
      return c<"Ë">(this, -2247308852783829433L, (long)a);
   }

   private static String HE_WEI_LIN() {
      return "何建国230622195906030014";
   }
}
