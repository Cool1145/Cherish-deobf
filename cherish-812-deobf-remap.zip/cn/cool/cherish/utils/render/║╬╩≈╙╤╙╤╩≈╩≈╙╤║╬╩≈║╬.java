package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.友友友树何友树友树友;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.LivingEntity;

public final class 何树友友树树友何树何 implements 何树友 {
   public static final Map<String, Color> 树友何何何树何树友友;
   public static final Map<String, Color> 友树友何友友友何何友;
   public static final Map<Color, String> 何树何何树何树树树树;
   private static String[] 何树树树友何树树友树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long e;
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[11];
   private static final String[] j = new String[11];
   private static String HE_JIAN_GUO;

   private 何树友友树树友何树何(long a) {
      a = 54959447591749L ^ a;
      super();
      throw new UnsupportedOperationException(a<"c">(12886, 5885323738614680110L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(9188053167356394511L, 711649081828829017L, MethodHandles.lookup().lookupClass()).a(31780159912264L);
      // $VF: monitorexit
      a = var10000;
      a();
      String[] var25 = new String[4];
      D(var25);
      Cipher var16;
      Cipher var26 = var16 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var17 = 1; var17 < 8; var17++) {
         var10003[var17] = (byte)(65384317829059L << var17 * 8 >>> 56);
      }

      var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var23 = new String[2];
      int var21 = 0;
      char var19 = 'X';
      int var18 = -1;

      while (true) {
         String var33 = a(
               var16.doFinal(
                  "\u0089lmî³¹Õt\u0000mh¼\u0018È£J£\u008fG«øÅ\u001e\u008adÑ\u007f\u0083X}ÞÉ#\u0015\u001a\u0095\u009d+ýmÎ\u0097¼ó¸Ç§\t£\nµµO\têN\rr7\u00ad7\u007fÛ\u0094\u0087\u0007|¹\u0012<:vì@\u0002~D<\u0081\u00adÐ<+´p\u000fìñ\u0018R e\u0086dLÂM^\u008b\u009f\u001c\u000b{÷½þø\n\u001fµ}V´"
                     .substring(++var18, var18 + var19)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         int var10001 = -1;
         var23[var21++] = var33;
         if ((var18 += var19) >= 113) {
            b = var23;
            c = new String[2];
            Cipher var11;
            Cipher var27 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

            for (int var12 = 1; var12 < 8; var12++) {
               var10003[var12] = (byte)(65384317829059L << var12 * 8 >>> 56);
            }

            var27.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            byte[] var15 = var11.doFinal(new byte[]{7, -20, 101, -64, 86, 36, 56, 65});
            long var36 = (var15[0] & 255L) << 56
               | (var15[1] & 255L) << 48
               | (var15[2] & 255L) << 40
               | (var15[3] & 255L) << 32
               | (var15[4] & 255L) << 24
               | (var15[5] & 255L) << 16
               | (var15[6] & 255L) << 8
               | var15[7] & 255L;
            var10001 = (byte)-1;
            e = var36;
            h = new HashMap(13);
            Cipher var0;
            Cipher var28 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(65384317829059L << var1 * 8 >>> 56);
            }

            var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[3];
            int var3 = 0;
            byte var2 = 0;

            do {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = "×U\u0082\nÿ¦¾ ÛøÞÉ_\u0097\u0013\u0092h\u008aeF¹\u0092\"l".substring(var10001, var2).getBytes("ISO-8859-1");
               var10001 = var3++;
               long var8 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               byte[] var10 = var0.doFinal(
                  new byte[]{
                     (byte)(var8 >>> 56),
                     (byte)(var8 >>> 48),
                     (byte)(var8 >>> 40),
                     (byte)(var8 >>> 32),
                     (byte)(var8 >>> 24),
                     (byte)(var8 >>> 16),
                     (byte)(var8 >>> 8),
                     (byte)var8
                  }
               );
               long var10004 = (var10[0] & 255L) << 56
                  | (var10[1] & 255L) << 48
                  | (var10[2] & 255L) << 40
                  | (var10[3] & 255L) << 32
                  | (var10[4] & 255L) << 24
                  | (var10[5] & 255L) << 16
                  | (var10[6] & 255L) << 8
                  | var10[7] & 255L;
               byte var40 = -1;
               var6[var10001] = var10004;
            } while (var2 < 24);

            f = var6;
            g = new Long[3];
            树友何何何树何树友友 = new 何树友友树树友何树何$友树树友何何友友友何(113555528465669L);
            友树友何友友友何何友 = new 何树友友树树友何树何$树友何树友友树何友何(82655444834588L);
            何树何何树何树树树树 = new 何树友友树树友何树何$树友树树友何树友何树(123704904263660L);
            return;
         }

         var19 = "\u0089lmî³¹Õt\u0000mh¼\u0018È£J£\u008fG«øÅ\u001e\u008adÑ\u007f\u0083X}ÞÉ#\u0015\u001a\u0095\u009d+ýmÎ\u0097¼ó¸Ç§\t£\nµµO\têN\rr7\u00ad7\u007fÛ\u0094\u0087\u0007|¹\u0012<:vì@\u0002~D<\u0081\u00adÐ<+´p\u000fìñ\u0018R e\u0086dLÂM^\u008b\u009f\u001c\u000b{÷½þø\n\u001fµ}V´"
            .charAt(var18);
      }
   }

   public static String[] B() {
      return 何树树树友何树树友树;
   }

   public static int C(long a, int blue, int red, int a) {
      long ax = 54959447591749L ^ a ^ 45322641017209L;
      return b(blue, red, ax, (int)a, 255);
   }

   public static int D(int a, long color) {
      long var10000 = 54959447591749L ^ color;
      return a & 0xFF000000 | Math.max(a >> 16 & 215, 0) << 16 | Math.max(a >> 8 & 215, 0) << 8 | Math.max(a & 215, 0);
   }

   public static void D(String[] var0) {
      何树树树友何树树友树 = var0;
   }

   public static Color F(int a, int index, Color a, long var3, float speed) {
      c<"þ">(-5199455078455555112L, 40088659343318L);
      float[] hsb = Color.RGBtoHSB(a.getRed(), a.getGreen(), a.getBlue(), null);
      int angle = (int)((System.currentTimeMillis() / 5L + index) % b<"i">(30556, 1778994922925698556L));
      angle = (angle > 180 ? 360 - angle : angle) + 180;
      Color colorHSB = new Color(Color.HSBtoRGB(hsb[0], hsb[1], angle / 360.0F));
      return new Color(colorHSB.getRed(), colorHSB.getGreen(), colorHSB.getBlue(), Math.max(0, Math.min(255, 255)));
   }

   public static Color S(Color a, Color factor, float color2) {
      color2 = Math.max(0.0F, Math.min(1.0F, (float)color2));
      int r = (int)(a.getRed() + (factor.getRed() - a.getRed()) * color2);
      int g = (int)(a.getGreen() + (factor.getGreen() - a.getGreen()) * color2);
      int b = (int)(a.getBlue() + (factor.getBlue() - a.getBlue()) * color2);
      int ax = (int)(a.getAlpha() + (factor.getAlpha() - a.getAlpha()) * color2);
      return new Color(r, g, b, ax);
   }

   public static int S(int a, float color) {
      int r = a >> 16 & 0xFF;
      int g = a >> 8 & 0xFF;
      int b = a & 255;
      int ax = (int)(color * 255.0F);
      return ax << 24 | r << 16 | g << 8 | b;
   }

   public static int Z(int a, int a, int r, int g) {
      return (g & 0xFF) << 24 | (a & 0xFF) << 16 | (a & 0xFF) << 8 | r & 0xFF;
   }

   public static Color V(LivingEntity a, long target) {
      RenderUtils.a();
      Color healthColor = new Color(0, 165, 0);
      if (a.getHealth() < a.getMaxHealth() / 1.5) {
         healthColor = new Color(200, 200, 0);
      }

      if (a.getHealth() < a.getMaxHealth() / 2.5) {
         healthColor = new Color(200, 155, 0);
      }

      if (a.getHealth() < a.getMaxHealth() / 4.0F) {
         healthColor = new Color(120, 0, 0);
      }

      return healthColor;
   }

   public static int e(int a, int g, int r, int b) {
      return (b & 0xFF) << 24 | (a & 0xFF) << 16 | (g & 0xFF) << 8 | r & 0xFF;
   }

   public static Double i(double a, double var2, double var4) {
      return a + (var2 - a) * var4;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 23202;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/render/何树友友树树友何树何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何树友友树树友何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static int b(int a, int red, long alpha, int a, int var5) {
      long ax = 54959447591749L ^ alpha ^ 59328031210313L;
      int color = 友友友树何友树友树友.L(255, 0, ax, 255) << 24;
      return color | 友友友树何友树友树友.L((int)a, 0, ax, 255) << 16 | 友友友树何友树友树友.L(red, 0, ax, 255) << 8 | 友友友树何友树友树友.L((int)a, 0, ax, 255);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何树友友树树友何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static int h(int a, int interpolationValue, double var2) {
      return i(a, interpolationValue, (float)var2).intValue();
   }

   public static int l(int a) {
      return a >> 16 & 0xFF;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 29;
               case 1 -> 22;
               case 2 -> 5;
               case 3 -> 4;
               case 4 -> 0;
               case 5 -> 56;
               case 6 -> 26;
               case 7 -> 31;
               case 8 -> 50;
               case 9 -> 40;
               case 10 -> 13;
               case 11 -> 30;
               case 12 -> 35;
               case 13 -> 27;
               case 14 -> 1;
               case 15 -> 61;
               case 16 -> 45;
               case 17 -> 28;
               case 18 -> 33;
               case 19 -> 49;
               case 20 -> 23;
               case 21 -> 15;
               case 22 -> 46;
               case 23 -> 36;
               case 24 -> 63;
               case 25 -> 17;
               case 26 -> 48;
               case 27 -> 8;
               case 28 -> 18;
               case 29 -> 53;
               case 30 -> 32;
               case 31 -> 51;
               case 32 -> 25;
               case 33 -> 21;
               case 34 -> 55;
               case 35 -> 54;
               case 36 -> 2;
               case 37 -> 3;
               case 38 -> 47;
               case 39 -> 9;
               case 40 -> 57;
               case 41 -> 7;
               case 42 -> 43;
               case 43 -> 6;
               case 44 -> 39;
               case 45 -> 59;
               case 46 -> 34;
               case 47 -> 62;
               case 48 -> 12;
               case 49 -> 60;
               case 50 -> 38;
               case 51 -> 16;
               case 52 -> 19;
               case 53 -> 14;
               case 54 -> 58;
               case 55 -> 10;
               case 56 -> 44;
               case 57 -> 24;
               case 58 -> 42;
               case 59 -> 41;
               case 60 -> 37;
               case 61 -> 52;
               case 62 -> 20;
               default -> 11;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static void a() {
      i[0] = "P\u0018-N\u001aV_X`E\u0010KZ\u0005k\u0003\u0000MZ\u001ap\u0003\u0007\\]\u0012f_[kV\u0018gH\u0007lG\u001fo^";
      i[1] = int.class;
      j[1] = "java/lang/Integer";
      i[2] = "S$7h\u0010x\\dzc\u001aeY9q%\ncY&j%\rr^.|yQ佂校厁叒栚桮叜佥桛佌";
      i[3] = "G\fz[@bL\u0003k\u0014;`^\u0018|J\u0001|Y\bhu\u001ek_\fxS\u0001`h\u0015o_\u001ezD\u0002b";
      i[4] = "\u0010\u000ey\rT\u0014e.r\u0002E[\u00186a\u0005L\u0012p";
      i[5] = void.class;
      j[5] = "java/lang/Void";
      i[6] = "_S2p\u0004\u0012T\\#?e\u001c_W'e";
      i[7] = "\\\u0005o# cBEb_\u0011RNG4a!4\u0003\u00161_";
      i[8] = "O\tvBEpM\f}A|evT\u007f\u0001EsO\u000bi\u0000C\fL\n\"\u0001\u00035\u0013\u001c#\u0007|";
      i[9] = "-6o\u0005a{/3d\u0006XK\u0014j?\u0004b~e0s\u0007c\u0007(ml\u0005'7)hbGX";
      i[10] = "R\u001d\u0018DUVL]\u00158Pg@_C\u0006T\u0001\r\u000eF8";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'K' && var8 != 'C' && var8 != '$' && var8 != 'f') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'p') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 254) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'K') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'C') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27531;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/render/何树友友树树友何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何树友友树树友何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static Color p(Color a, Color amount, float color1) {
      color1 = Math.min(1.0F, Math.max(0.0F, 0.65F));
      return new Color(
         h(a.getRed(), amount.getRed(), color1),
         h(a.getGreen(), amount.getGreen(), color1),
         h(a.getBlue(), amount.getBlue(), color1),
         h(a.getAlpha(), amount.getAlpha(), color1)
      );
   }

   public static Color t(long a, int speed, int a) {
      int angle = (int)((System.currentTimeMillis() / 10L + 1L) % b<"i">(5481, 1553463808096817099L));
      float hue = angle / 360.0F;
      return new Color(Color.HSBtoRGB(hue, 0.7F, 1.0F));
   }

   public static int g(Color a, long secondColor, Color index, float timePerIndex, int var5, long speed, double alpha, double time) {
      c<"þ">(1178493016184777813L, 51083514351707L);
      long now = (long)(2.0 * System.currentTimeMillis() + var5 * 75L);
      float redDiff = (a.getRed() - index.getRed()) / 2000.0F;
      float greenDiff = (a.getGreen() - index.getGreen()) / timePerIndex;
      float blueDiff = (a.getBlue() - index.getBlue()) / timePerIndex;
      int red = Math.round(index.getRed() + redDiff * (float)(now % (long)timePerIndex));
      int green = Math.round(index.getGreen() + greenDiff * (float)(now % (long)timePerIndex));
      int blue = Math.round(index.getBlue() + blueDiff * (float)(now % (long)timePerIndex));
      float redInverseDiff = (index.getRed() - a.getRed()) / timePerIndex;
      float greenInverseDiff = (index.getGreen() - a.getGreen()) / timePerIndex;
      float blueInverseDiff = (index.getBlue() - a.getBlue()) / timePerIndex;
      int inverseRed = Math.round(a.getRed() + redInverseDiff * (float)(now % (long)timePerIndex));
      int inverseGreen = Math.round(a.getGreen() + greenInverseDiff * (float)(now % (long)timePerIndex));
      int inverseBlue = Math.round(a.getBlue() + blueInverseDiff * (float)(now % (long)timePerIndex));
      return now % ((long)timePerIndex * b<"i">(4434, 2155246378424617969L)) < (long)timePerIndex
         ? new Color(inverseRed, inverseGreen, inverseBlue, 255).getRGB()
         : new Color(red, green, blue, (int)time).getRGB();
   }

   public static Color j(Color a, float color) {
      color = Math.min(1.0F, Math.max(0.0F, (float)color));
      return new Color(a.getRed(), a.getGreen(), a.getBlue(), (int)(a.getAlpha() * color));
   }

   public static int z(int a) {
      return a >> 24 & 0xFF;
   }

   public static int y(int a) {
      return a >> 8 & 0xFF;
   }

   public static int N(int a) {
      return a & 0xFF;
   }

   public static String N(String a, long a) {
      c<"þ">(1307432586266275371L, 26732571202085L);
      return a == null ? "" : a.replaceAll("§[0-9a-fk-or]", "");
   }

   private static String HE_SHU_YOU() {
      return "何建国230622195906030014";
   }

   public static int O(int a, float color) {
      Color old = new Color((int)a);
      color = (int)Math.min(1.0F, Math.max(0.0F, (float)color));
      return j(old, (float)color).getRGB();
   }
}
