package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D.Double;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.Kernel;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何树友友何何友何友友 extends 何树友友何何何何何树 implements 何树友 {
   public static int 树何树树树何树友树何;
   public static int 友何友友友友树何何何;
   public static int 树友友何何友友何友树;
   protected Kernel 友友友树何友树友树友;
   protected boolean 友友友友何何树何树树;
   protected boolean 友何何何树友树树友何;
   private int 何树何友何何友树友树;
   private static final long b;
   private static final String d;
   private static final Object[] h = new Object[17];
   private static final String[] i = new String[17];
   private static int _何大伟为什么要诈骗何炜霖 _;

   public 何树友友何何友何友友(int a, int a, Kernel kernel, char a) {
      long ax = ((long)a << 32 | (long)a << 48 >>> 32 | (long)a << 48 >>> 48) ^ b;
      super();
      b<"ã">(this, null, -5941189557145063146L, ax);
      b<"ã">(this, true, -5941036311027477468L, ax);
      b<"ã">(this, true, -5941614786286550442L, ax);
      b<"ã">(this, b<"Õ">(-5941337413380103280L, ax), -5941129472611523586L, ax);
      b<"ã">(this, kernel, -5941189557145063146L, ax);
   }

   public 何树友友何何友何友友(int rows, long a, int cols, float[] matrix) {
      long var10001 = b ^ a ^ 136111447439373L;
      int ax = (int)((b ^ a ^ 136111447439373L) >>> 32);
      int axx = (int)((b ^ a ^ 136111447439373L) << 32 >>> 48);
      int axxx = (int)(var10001 << 48 >>> 48);
      Kernel var9 = new Kernel(cols, rows, matrix);
      this(ax, axx, var9, (char)axxx);
   }

   public 何树友友何何友何友友(float[] matrix, long a) {
      long var10001 = b ^ a ^ 28763016814846L;
      int ax = (int)((b ^ a ^ 28763016814846L) >>> 32);
      int axx = (int)((b ^ a ^ 28763016814846L) << 32 >>> 48);
      int axxx = (int)(var10001 << 48 >>> 48);
      Kernel var7 = new Kernel(3, 3, matrix);
      this(ax, axx, var7, (char)axxx);
   }

   public 何树友友何何友何友友(char a, long a) {
      long ax = ((long)a << 48 | a << 16 >>> 16) ^ b ^ 27330570936326L;
      this(new float[9], ax);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-1229745249810865361L, 8413843186277893144L, MethodHandles.lookup().lookupClass()).a(233926983063087L);
      // $VF: monitorexit
      b = var10000;
      long var10 = b ^ 72469940810375L;
      b();
      Cipher var7;
      Cipher var12 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var10 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(var10 << var8 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var15 = a(var7.doFinal("g@\u0003Ï\u007fp÷twëò\u008d\u0016ZëÒô\u008d\u0099\u0000¹Ä(Ï".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      d = var15;
      Cipher var2;
      Cipher var13 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)(var10 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var10 << var3 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var6 = var2.doFinal(new byte[]{-105, 102, 24, 108, 122, -96, 37, 72});
      long var17 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      var10001 = -1;
      long var0 = var17;
      b<"b">(0, -932060245884321644L, var10);
      b<"b">(1, -931930813348840179L, var10);
      b<"b">((int)var0, -931830533978482199L, var10);
   }

   @Override
   public String toString() {
      long var10000 = b ^ 65777355272670L;
      return d;
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   // $VF: Irreducible bytecode has more than 5 nodes in sequence and was not entirely decomposed
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public static void D(Kernel a, int[] width, long height, int[] outPixels, int a, int var6, boolean inPixels, int edgeAction) {
      height = (int)(何树友友何何友何友友.b ^ height);
      long ax = height ^ 15457174962559L;
      int index = 0;
      float[] matrix = a.getKernelData(null);
      int rows = a.getHeight();
      int var10000 = b<"á">(-4414350178837899870L, (long)height);
      int rows2 = rows / 2;
      int axx = (byte)var10000;
      int y = 0;

      while (true) {
         while (y < var6 || height < 0L) {
            do {
               int x = 0;
               if (0 < a) {
                  float r = 0.0F;
                  float g = 0.0F;
                  float b = 0.0F;
                  float axxx = 0.0F;
                  int row = -rows2;

                  label191: {
                     int var10001;
                     while (true) {
                        if (row <= rows2) {
                           int iy = y + row;
                           var10000 = iy;
                           var10001 = axx;
                           if (height < 0L) {
                              break;
                           }

                           if (axx == 0) {
                              var10001 = axx;
                              break;
                           }

                           int ioffset;
                           label194: {
                              var10001 = axx;
                              if (height > 0L) {
                                 if (axx != 0 && height > 0L) {
                                    if (iy < 0) {
                                       var10000 = edgeAction;
                                       var10001 = b<"Õ">(-4414561511052751712L, (long)height);
                                       byte var10002 = axx;
                                       if (height > 0L) {
                                          if (axx != 0) {
                                             if (edgeAction == var10001) {
                                                ioffset = 0;
                                                var10000 = axx;
                                                if (height >= 0L) {
                                                   if (axx != 0) {
                                                      break label194;
                                                   }

                                                   var10000 = edgeAction;
                                                }
                                             } else {
                                                var10000 = edgeAction;
                                             }

                                             var10001 = b<"Õ">(-4414592520645334972L, (long)height);
                                             var10002 = axx;
                                          } else {
                                             var10002 = axx;
                                          }
                                       }

                                       if (var10002 != 0) {
                                          if (var10000 == var10001) {
                                             ioffset = (int)((y + var6) % var6 * a);
                                             var10000 = axx;
                                             if (height > 0L) {
                                                if (axx != 0) {
                                                   break label194;
                                                }

                                                var10000 = iy;
                                                var10001 = (int)a;
                                             } else {
                                                var10001 = (int)a;
                                             }
                                          } else {
                                             var10000 = iy;
                                             var10001 = (int)a;
                                          }
                                       }

                                       ioffset = var10000 * var10001;
                                       var10000 = axx;
                                       if (height > 0L) {
                                          if (axx != 0) {
                                             break label194;
                                          }

                                          var10000 = iy;
                                       }
                                    } else {
                                       var10000 = iy;
                                    }
                                 }

                                 if (height <= 0L) {
                                    ioffset = var10000;
                                    break label194;
                                 }

                                 var10001 = var6;
                              }

                              if (var10000 >= var10001) {
                                 var10000 = edgeAction;
                                 var10001 = b<"Õ">(-4414561511052751712L, (long)height);
                                 byte var43 = axx;
                                 if (height > 0L) {
                                    if (axx != 0) {
                                       if (edgeAction == var10001) {
                                          ioffset = (int)((var6 - 1) * a);
                                          var10000 = axx;
                                          if (height >= 0L) {
                                             if (axx != 0) {
                                                break label194;
                                             }

                                             var10000 = edgeAction;
                                          }
                                       } else {
                                          var10000 = edgeAction;
                                       }

                                       var10001 = b<"Õ">(-4414592520645334972L, (long)height);
                                       var43 = axx;
                                    } else {
                                       var43 = axx;
                                    }
                                 }

                                 if (var43 != 0) {
                                    if (var10000 == var10001) {
                                       ioffset = (int)((y + var6) % var6 * a);
                                       var10000 = axx;
                                       if (height > 0L) {
                                          if (axx != 0) {
                                             break label194;
                                          }

                                          var10000 = iy;
                                          var10001 = (int)a;
                                       } else {
                                          var10001 = (int)a;
                                       }
                                    } else {
                                       var10000 = iy;
                                       var10001 = (int)a;
                                    }
                                 }

                                 ioffset = var10000 * var10001;
                                 var10000 = axx;
                                 if (height >= 0L) {
                                    if (axx != 0) {
                                       break label194;
                                    }

                                    var10000 = iy;
                                 }
                              } else {
                                 var10000 = iy;
                              }

                              ioffset = (int)(var10000 * a);
                           }

                           float f = matrix[row + rows2];
                           byte var38 = axx;
                           if (height > 0L) {
                              if (axx != 0) {
                                 if (f != 0.0F) {
                                    int rgb = ((Object[])width)[ioffset + 0];
                                    axxx += f * (rgb >> 24 & 0xFF);
                                    r += f * (rgb >> 16 & 0xFF);
                                    g += f * (rgb >> 8 & 0xFF);
                                    b += f * (rgb & 0xFF);
                                 }

                                 row++;
                              }

                              var38 = axx;
                           }

                           if (var38 != 0) {
                              continue;
                           }
                        }

                        if (height < 0L) {
                           break label191;
                        }

                        var10000 = (int)inPixels;
                        var10001 = axx;
                        break;
                     }

                     if (var10001 != 0) {
                        var10000 = var10000 != 0 ? 何友何友树友何何何何.w((int)(axxx + 0.5), ax) : 255;
                     }

                     row = var10000;
                  }

                  int ir = 何友何友树友何何何何.w((int)(r + 0.5), ax);
                  int ig = 何友何友树友何何何何.w((int)(g + 0.5), ax);
                  int ib = 何友何友树友何何何何.w((int)(b + 0.5), ax);
                  outPixels[index++] = row << 24 | ir << 16 | ig << 8 | ib;
                  x++;
               }

               y++;
            } while (height < 0L || axx != 0 || height < 0L);

            return;
         }

         return;
      }
   }

   public void F(long a, int var3) {
      a = b ^ a;
      b<"ã">(this, var3, 7042125853883838408L, (long)a);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 16;
               case 1 -> 19;
               case 2 -> 29;
               case 3 -> 12;
               case 4 -> 38;
               case 5 -> 4;
               case 6 -> 52;
               case 7 -> 44;
               case 8 -> 18;
               case 9 -> 10;
               case 10 -> 33;
               case 11 -> 9;
               case 12 -> 62;
               case 13 -> 41;
               case 14 -> 55;
               case 15 -> 14;
               case 16 -> 23;
               case 17 -> 26;
               case 18 -> 43;
               case 19 -> 36;
               case 20 -> 40;
               case 21 -> 60;
               case 22 -> 6;
               case 23 -> 45;
               case 24 -> 7;
               case 25 -> 42;
               case 26 -> 59;
               case 27 -> 15;
               case 28 -> 49;
               case 29 -> 13;
               case 30 -> 58;
               case 31 -> 54;
               case 32 -> 51;
               case 33 -> 32;
               case 34 -> 1;
               case 35 -> 11;
               case 36 -> 20;
               case 37 -> 17;
               case 38 -> 35;
               case 39 -> 2;
               case 40 -> 56;
               case 41 -> 0;
               case 42 -> 8;
               case 43 -> 34;
               case 44 -> 28;
               case 45 -> 53;
               case 46 -> 63;
               case 47 -> 39;
               case 48 -> 21;
               case 49 -> 31;
               case 50 -> 24;
               case 51 -> 5;
               case 52 -> 3;
               case 53 -> 25;
               case 54 -> 61;
               case 55 -> 30;
               case 56 -> 57;
               case 57 -> 46;
               case 58 -> 22;
               case 59 -> 50;
               case 60 -> 48;
               case 61 -> 37;
               case 62 -> 47;
               default -> 27;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void b() {
      h[0] = "{\t1\u001222tI|\u00198/q\u0014w_()q\u000bl_/8v\u0003z\u0003s伈栉厬叔伤伈厖位厬叔";
      h[1] = boolean.class;
      i[1] = "java/lang/Boolean";
      h[2] = int.class;
      i[2] = "java/lang/Integer";
      h[3] = "\b\\I+K@\u0003SXd7Y\fIV'\u0000i\u001a^Z:\u0011E\rS";
      h[4] = "\u0017p@&~J\u00180\r-tW\u001dm\u0006kdQ\u001dr\u001dkc@\u001az\u000b7?佰县佋厥桔叚佰伡佋伻";
      h[5] = "b{O\u0011\n\\\u007fn\u0017\u0019I\\o\u007f\u0017;AOf\u007fU";
      h[6] = "h\u001f&5HIc\u00107z)Gh\u001b3 ";
      h[7] = "\u0011 \u0017\u00136B\u0014m\b)ds\u00159RS?\u0015\u0014.\f\u0018\u000fIDn\u0014\u0019iHS0_)";
      h[8] = "\u0011\u0011jp\u0004T\u0014\\uJ叾厦召厠低众栤伸栶桺\u00138\fZ\u001f\u000fq'\u0006\f";
      h[9] = "8\u0012i%Kbi\u000b<~/B\u0003\t7$\u001fra\u0016=r/";
      h[10] = " {l/gL%6s\u0015桇传标栐栌佈桇厾标佔\u0015,=\rr{~-#\u001da";
      h[11] = "\u0017\u0003\u0001\"|kF\u001aTy\u0018Y,\u0018_#({N\u0007Uu\u0018";
      h[12] = "0\u0000\u001fX;45M\u0000b叁佘反厱厥厡栛佘体伯f[aub\u0000\rZ\u007feq";
      h[13] = "QI9Q\nXT\u0004&k株厪厬佦伝厨台伴厬栢@RP\u0019\u0003I+SN\t\u0010";
      h[14] = "\u007f]LV\b z\u0010Sl史叒厂栶佨厯栨叒桘召5WO}}BY\u0017\nm3";
      h[15] = "h{9QOjm6&k伫桂伋及伝伶厵桂厕栐@R\u0015+:{+S\u000b;)";
      h[16] = "!)C\u0014dv$d\\.厞会佂伆栣叭桄桞叜伆:\\lx/7XCf.";
   }

   public void b(long a, boolean var3) {
      a = b ^ a;
      b<"ã">(this, var3, 767673849347057018L, (long)a);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何树友友何何友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 205 && var8 != 227 && var8 != 213 && var8 != 'b') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'M') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 225) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 205) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 227) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public void x(boolean a, long useAlpha) {
      useAlpha = (boolean)(b ^ useAlpha);
      b<"ã">(this, (boolean)a, 4460033764335027276L, (long)useAlpha);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static RuntimeException c(RuntimeException var0) {
      return var0;
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   // $VF: Irreducible bytecode has more than 5 nodes in sequence and was not entirely decomposed
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public static void n(Kernel a, int[] kernel, int[] height, int edgeAction, int a, boolean var5, long alpha, int inPixels) {
      alpha = (boolean)(何树友友何何友何友友.b ^ alpha);
      long ax = alpha ^ 62767166094177L;
      int index = 0;
      float[] matrix = a.getKernelData(null);
      int var10000 = b<"á">(-530539655781650500L, (long)alpha);
      int cols = a.getWidth();
      int cols2 = cols / 2;
      int axx = (byte)var10000;
      int y = 0;

      while (true) {
         while (y < a || alpha <= 0L) {
            do {
               int ioffset = y * edgeAction;
               int x = 0;
               if (0 < edgeAction) {
                  float r = 0.0F;
                  float g = 0.0F;
                  float b = 0.0F;
                  float axxx = 0.0F;
                  int moffset = cols2;
                  int col = -cols2;

                  label151: {
                     int var10001;
                     while (true) {
                        if (col <= cols2) {
                           float f = matrix[moffset + col];
                           int var35 = axx;
                           if (alpha > 0L) {
                              if (axx != 0) {
                                 float var42;
                                 var10000 = (var42 = f - 0.0F) == 0.0F ? 0 : (var42 < 0.0F ? -1 : 1);
                                 var10001 = axx;
                                 if (alpha <= 0L) {
                                    break;
                                 }

                                 if (axx == 0) {
                                    var10001 = axx;
                                    break;
                                 }

                                 if (var10000 == 0) {
                                    col++;
                                    var35 = axx;
                                 } else {
                                    label129: {
                                       int ix;
                                       label155: {
                                          ix = 0 + col;
                                          var35 = ix;
                                          var10001 = axx;
                                          if (alpha >= 0L) {
                                             if (axx != 0) {
                                                if (ix < 0) {
                                                   if (inPixels == b<"Õ">(-530751128672274754L, (long)alpha)) {
                                                      ix = 0;
                                                      var35 = axx;
                                                      if (alpha > 0L) {
                                                         if (axx != 0) {
                                                            break label155;
                                                         }

                                                         var35 = (int)inPixels;
                                                      }
                                                   } else {
                                                      var35 = (int)inPixels;
                                                   }

                                                   if (var35 != b<"Õ">(-530861372098375078L, (long)alpha)) {
                                                      break label155;
                                                   }

                                                   ix = (0 + edgeAction) % edgeAction;
                                                   var35 = axx;
                                                   if (alpha > 0L) {
                                                      if (axx != 0) {
                                                         break label155;
                                                      }

                                                      var35 = ix;
                                                      var10001 = axx;
                                                   } else {
                                                      var10001 = axx;
                                                   }
                                                } else {
                                                   var35 = ix;
                                                   var10001 = axx;
                                                }
                                             } else {
                                                var10001 = axx;
                                             }
                                          }

                                          if (alpha > 0L) {
                                             if (var10001 == 0) {
                                                break label129;
                                             }

                                             var10001 = edgeAction;
                                          }

                                          label112:
                                          if (var35 >= var10001) {
                                             if (inPixels == b<"Õ">(-530751128672274754L, (long)alpha)) {
                                                ix = edgeAction - 1;
                                                var35 = axx;
                                                if (alpha >= 0L) {
                                                   if (axx != 0) {
                                                      break label112;
                                                   }

                                                   var35 = (int)inPixels;
                                                }
                                             } else {
                                                var35 = (int)inPixels;
                                             }

                                             if (var35 == b<"Õ">(-530861372098375078L, (long)alpha)) {
                                                ix = (0 + edgeAction) % edgeAction;
                                             }
                                          }
                                       }

                                       var35 = (int)((Object[])kernel)[ioffset + ix];
                                    }

                                    int rgb = var35;
                                    axxx += f * (rgb >> 24 & 0xFF);
                                    r += f * (rgb >> 16 & 0xFF);
                                    g += f * (rgb >> 8 & 0xFF);
                                    b += f * (rgb & 0xFF);
                                    col++;
                                    var35 = axx;
                                 }
                              } else {
                                 var35 = axx;
                              }
                           }

                           if (var35 != 0) {
                              continue;
                           }
                        }

                        if (alpha < 0L) {
                           break label151;
                        }

                        var10000 = var5;
                        var10001 = axx;
                        break;
                     }

                     if (var10001 != 0) {
                        var10000 = var10000 != 0 ? 何友何友树友何何何何.w((int)(axxx + 0.5), ax) : 255;
                     }

                     col = var10000;
                  }

                  int ir = 何友何友树友何何何何.w((int)(r + 0.5), ax);
                  int ig = 何友何友树友何何何何.w((int)(g + 0.5), ax);
                  int ib = 何友何友树友何何何何.w((int)(b + 0.5), ax);
                  ((Object[])height)[index++] = col << 24 | ir << 16 | ig << 8 | ib;
                  x++;
               }

               y++;
            } while (alpha <= 0L || axx != 0 || alpha <= 0L);

            return;
         }

         return;
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void l(Kernel a, int[] inPixels, int[] edgeAction, int height, int a, long var5, boolean outPixels, int kernel) {
      var5 = b ^ var5;
      long ax = var5 ^ 37759463588156L;
      long axx = var5 ^ 23431037139746L;
      long axxx = var5 ^ 63134719025021L;
      b<"á">(4038312844860415184L, var5);
      if (a.getHeight() == 1) {
         n(a, inPixels, (int[])edgeAction, height, (int)a, true, ax, (int)kernel);
      }

      if (a.getWidth() == 1) {
         D(a, inPixels, axx, (int[])edgeAction, height, (int)a, (boolean)outPixels, (int)kernel);
      }

      q(a, axxx, inPixels, (int[])edgeAction, height, (int)a, (boolean)outPixels, (int)kernel);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
      long a = b ^ 65150080036339L;
      long ax = a ^ 126754971417441L;
      long axx = a ^ 19144184705924L;
      long axxx = a ^ 49469295353808L;
      long axxxx = a ^ 36883792827899L;
      long axxxxx = a ^ 49205532556299L;
      b<"á">(7810410682223229819L, a);
      int width = src.getWidth();
      int height = src.getHeight();
      if (dst == null) {
         dst = this.createCompatibleDestImage(src, null);
      }

      int[] inPixels = new int[width * height];
      int[] outPixels = new int[width * height];
      Object[] var10009 = new Object[]{null, null, null, null, null, height, inPixels};
      var10009[4] = width;
      var10009[3] = 0;
      var10009[2] = 0;
      var10009[1] = axxxxx;
      var10009[0] = src;
      this.K(var10009);
      if (b<"Í">(this, 7809913246814454719L, a)) {
         友树树树树何何友何友.W(inPixels, axx, 0, inPixels.length);
      }

      l(
         b<"Í">(this, 7810897616271274239L, a),
         inPixels,
         outPixels,
         width,
         height,
         axxxx,
         b<"Í">(this, 7810495881866794445L, a),
         b<"Í">(this, 7810816615451337239L, a)
      );
      if (b<"Í">(this, 7809913246814454719L, a)) {
         友树树树树何何友何友.E(outPixels, 0, outPixels.length, ax);
      }

      var10009 = new Object[]{null, null, null, null, null, axxx, outPixels};
      var10009[4] = height;
      var10009[3] = width;
      var10009[2] = 0;
      var10009[1] = 0;
      var10009[0] = dst;
      this.E(var10009);
      return dst;
   }

   public Kernel k(long a) {
      a = b ^ a;
      return b<"Í">(this, 8485851198975600985L, (long)a);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static void q(Kernel a, long width, int[] height, int[] edgeAction, int alpha, int kernel, boolean outPixels, int a) {
      width = (int)(何树友友何何友何友友.b ^ width);
      long ax = width ^ 37564375983392L;
      int var10000 = b<"á">(-1809675483598585288L, (long)width);
      int index = 0;
      float[] matrix = a.getKernelData(null);
      int rows = a.getHeight();
      int cols = a.getWidth();
      int rows2 = rows / 2;
      int cols2 = cols / 2;
      int axx = (byte)var10000;
      int y = 0;

      label245:
      while (true) {
         var10000 = y;

         label243:
         while (true) {
            int x;
            int var10001;
            if (var10000 < kernel) {
               x = 0;
               var10000 = 0;
               var10001 = alpha;
            } else {
               if (width > 0L) {
                  return;
               }

               x = 0;
               var10000 = 0;
               var10001 = alpha;
            }

            label241:
            while (true) {
               if (var10000 >= var10001) {
                  y++;
                  var10000 = axx;
                  if (width <= 0L) {
                     break;
                  }

                  if (axx == 0) {
                     continue label245;
                  }
               } else {
                  float r = 0.0F;
                  float g = 0.0F;
                  float b = 0.0F;
                  float axxx = 0.0F;
                  int row = -rows2;
                  var10000 = row;
                  var10001 = rows2;

                  while (true) {
                     if (var10000 <= var10001) {
                        int iy = y + row;
                        var10000 = 0;
                        var10001 = iy;
                        byte var10002 = axx;

                        label230:
                        while (true) {
                           if (var10002 != 0) {
                              continue label241;
                           }

                           var10002 = axx;
                           if (width >= 0L) {
                              int ioffset;
                              int moffset;
                              int col;
                              label252: {
                                 label253: {
                                    if (axx == 0) {
                                       if (var10000 <= var10001) {
                                          var10000 = iy;
                                          var10001 = (int)kernel;
                                          var10002 = axx;
                                          if (width >= 0L) {
                                             if (axx == 0) {
                                                if (iy < kernel) {
                                                   ioffset = iy * alpha;
                                                   if (width < 0L) {
                                                      moffset = axx;
                                                      col = -cols2;
                                                      break label252;
                                                   }

                                                   if (axx == 0) {
                                                      break label253;
                                                   }

                                                   var10000 = (int)a;
                                                   var10001 = b<"Õ">(-1809462346629519105L, (long)width);
                                                   var10002 = axx;
                                                } else {
                                                   var10000 = (int)a;
                                                   var10001 = b<"Õ">(-1809462346629519105L, (long)width);
                                                   var10002 = axx;
                                                }
                                             } else {
                                                var10002 = axx;
                                             }
                                          }
                                       } else {
                                          var10000 = (int)a;
                                          var10001 = b<"Õ">(-1809462346629519105L, (long)width);
                                          var10002 = axx;
                                       }
                                    } else {
                                       var10002 = axx;
                                    }

                                    if (width >= 0L) {
                                       if (var10002 == 0) {
                                          if (var10000 == var10001) {
                                             ioffset = y * alpha;
                                             if (width < 0L) {
                                                moffset = axx;
                                                col = -cols2;
                                                break label252;
                                             }

                                             if (axx == 0) {
                                                break label253;
                                             }

                                             var10000 = (int)a;
                                             var10001 = b<"Õ">(-1809572555284837349L, (long)width);
                                             var10002 = axx;
                                          } else {
                                             var10000 = (int)a;
                                             var10001 = b<"Õ">(-1809572555284837349L, (long)width);
                                             var10002 = axx;
                                          }
                                       } else {
                                          var10002 = axx;
                                       }
                                    }

                                    if (var10002 == 0) {
                                       if (var10000 != var10001) {
                                          break;
                                       }

                                       ioffset = (iy + kernel) % kernel * alpha;
                                    } else {
                                       ioffset = var10000 * var10001;
                                    }
                                 }

                                 moffset = cols * (row + rows2) + cols2;
                                 col = -cols2;
                              }

                              while (true) {
                                 if (col > cols2) {
                                    break label230;
                                 }

                                 float f = matrix[moffset + col];
                                 int var42 = axx;
                                 if (width > 0L) {
                                    if (axx == 0) {
                                       float var49;
                                       var10000 = (var49 = f - 0.0F) == 0.0F ? 0 : (var49 < 0.0F ? -1 : 1);
                                       if (width < 0L) {
                                          var10001 = iy;
                                          var10002 = axx;
                                          break;
                                       }

                                       label221:
                                       if (var10000 != 0) {
                                          int ix;
                                          label259: {
                                             ix = 0 + col;
                                             var42 = 0;
                                             var10001 = ix;
                                             var10002 = axx;
                                             if (width > 0L) {
                                                if (axx == 0) {
                                                   if (0 <= ix) {
                                                      if (ix < alpha) {
                                                         break label259;
                                                      }

                                                      var42 = (int)a;
                                                      var10001 = b<"Õ">(-1809462346629519105L, (long)width);
                                                      var10002 = axx;
                                                   } else {
                                                      var42 = (int)a;
                                                      var10001 = b<"Õ">(-1809462346629519105L, (long)width);
                                                      var10002 = axx;
                                                   }
                                                } else {
                                                   var10002 = axx;
                                                }
                                             }

                                             if (width >= 0L) {
                                                if (var10002 == 0) {
                                                   if (var42 == var10001) {
                                                      ix = 0;
                                                      var42 = axx;
                                                      if (width >= 0L) {
                                                         if (axx == 0) {
                                                            break label259;
                                                         }

                                                         var42 = (int)a;
                                                         var10001 = b<"Õ">(-1809572555284837349L, (long)width);
                                                         var10002 = axx;
                                                      } else {
                                                         var10001 = b<"Õ">(-1809572555284837349L, (long)width);
                                                         var10002 = axx;
                                                      }
                                                   } else {
                                                      var42 = (int)a;
                                                      var10001 = b<"Õ">(-1809572555284837349L, (long)width);
                                                      var10002 = axx;
                                                   }
                                                } else {
                                                   var10002 = axx;
                                                }
                                             }

                                             if (var10002 == 0) {
                                                if (var42 != var10001) {
                                                   col++;
                                                   var42 = axx;
                                                   break label221;
                                                }

                                                ix = (0 + alpha) % alpha;
                                             } else {
                                                ix = var42 % var10001;
                                             }
                                          }

                                          int rgb = ((Object[])height)[ioffset + ix];
                                          axxx += f * (rgb >> 24 & 0xFF);
                                          r += f * (rgb >> 16 & 0xFF);
                                          g += f * (rgb >> 8 & 0xFF);
                                          b += f * (rgb & 0xFF);
                                          col++;
                                          var42 = axx;
                                       } else {
                                          col++;
                                          var42 = axx;
                                       }
                                    } else {
                                       var42 = axx;
                                    }
                                 }

                                 if (var42 != 0) {
                                    break label230;
                                 }
                              }
                           }
                        }

                        row++;
                        var10000 = axx;
                        if (width <= 0L) {
                           var10001 = rows2;
                           continue;
                        }

                        if (axx == 0) {
                           var10000 = row;
                           var10001 = rows2;
                           continue;
                        }
                     }

                     var10000 = (int)outPixels;
                     var10001 = axx;
                     if (width > 0L) {
                        if (axx == 0) {
                           var10000 = outPixels != 0 ? 何友何友树友何何何何.w((int)(axxx + 0.5), ax) : 255;
                        }

                        row = var10000;
                        int ir = 何友何友树友何何何何.w((int)(r + 0.5), ax);
                        int ig = 何友何友树友何何何何.w((int)(g + 0.5), ax);
                        int ib = 何友何友树友何何何何.w((int)(b + 0.5), ax);
                        ((Object[])edgeAction)[index++] = row << 24 | ir << 16 | ig << 8 | ib;
                        x++;
                        y++;
                        var10000 = axx;
                        if (width <= 0L) {
                           continue label243;
                        }

                        if (axx == 0) {
                           continue label245;
                        }
                        break;
                     }
                  }
               }

               if (width > 0L) {
                  return;
               }

               x = 0;
               var10000 = 0;
               var10001 = alpha;
            }
         }
      }
   }

   public boolean r(long a) {
      a = b ^ a;
      return b<"Í">(this, 1645810164977645834L, (long)a);
   }

   public boolean y(long a) {
      a = b ^ a;
      return b<"Í">(this, -3039048352289461126L, (long)a);
   }

   public static void y(Kernel a, int[] a, int[] var2, int outPixels, int inPixels, long kernel, int edgeAction) {
      long ax = b ^ kernel ^ 62733887413565L;
      l(a, (int[])a, var2, (int)outPixels, (int)inPixels, ax, true, edgeAction);
   }

   public int R(long a) {
      a = b ^ a;
      return b<"Í">(this, -4105170904341902987L, (long)a);
   }

   @Override
   public Rectangle2D getBounds2D(BufferedImage src) {
      return new Rectangle(0, 0, src.getWidth(), src.getHeight());
   }

   public void K(Kernel a, long a) {
      a = b ^ a;
      b<"ã">(this, a, -6567427621915805631L, a);
   }

   @Override
   public Point2D getPoint2D(Point2D srcPt, Point2D dstPt) {
      long a = b ^ 86845452281028L;
      b<"á">(-6533648970106486391L, a);
      if (dstPt == null) {
         dstPt = new Double();
      }

      dstPt.setLocation(srcPt.getX(), srcPt.getY());
      return dstPt;
   }

   @Override
   public BufferedImage createCompatibleDestImage(BufferedImage src, ColorModel dstCM) {
      long a = b ^ 139892887783945L;
      b<"á">(-3774470200006124415L, a);
      if (dstCM == null) {
         dstCM = src.getColorModel();
      }

      return new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(src.getWidth(), src.getHeight()), dstCM.isAlphaPremultiplied(), null);
   }

   @Override
   public RenderingHints getRenderingHints() {
      return null;
   }

   private static String LIU_YA_FENG() {
      return "何大伟：我要教育何炜霖";
   }
}
