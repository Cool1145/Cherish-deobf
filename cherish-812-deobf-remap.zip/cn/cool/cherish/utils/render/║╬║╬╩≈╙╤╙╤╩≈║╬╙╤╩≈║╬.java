package cn.cool.cherish.utils.render;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public class 何何树友友树何友树何 implements IWrapper, 何树友 {
   private static Matrix4f 树树友友友树何何何友;
   private static Matrix4f 友树树友友友何何树何;
   private static final long a;
   private static final Object[] b = new Object[19];
   private static final String[] c = new String[19];
   private static int _刘凤楠230622109211173513 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-1261486331675758171L, -4355100452306097721L, MethodHandles.lookup().lookupClass()).a(177948026064437L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   private static boolean e(float a, long projMatrix, float modelMatrix, float a, float[] var5, float[] objx, int[] objz, float[] viewport) {
      projMatrix = (float[])(8067056739345L ^ projMatrix);
      long ax = (long)(projMatrix ^ 31242093992558L);
      a<"S">(-5367745787700000896L, (long)projMatrix);
      float[] inVec = new float[]{(float)a, (float)modelMatrix, (float)a, 1.0F};
      float[] outVec = new float[4];
      R(var5, inVec, outVec, ax);
      R((float[])objx, outVec, inVec, ax);
      if (inVec[3] == 0.0F) {
         return false;
      } else {
         float w = 1.0F / inVec[3];
         inVec[0] *= w;
         inVec[1] *= w;
         inVec[2] *= w;
         inVec[0] = inVec[0] * 0.5F + 0.5F;
         inVec[1] = inVec[1] * 0.5F + 0.5F;
         inVec[2] = inVec[2] * 0.5F + 0.5F;
         viewport[0] = (int)(inVec[0] * ((Object[])objz)[2] + ((Object[])objz)[0]);
         viewport[1] = (int)(inVec[1] * ((Object[])objz)[3] + ((Object[])objz)[1]);
         viewport[2] = (int)inVec[2];
         return true;
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 38;
               case 2 -> 60;
               case 3 -> 2;
               case 4 -> 3;
               case 5 -> 24;
               case 6 -> 6;
               case 7 -> 54;
               case 8 -> 45;
               case 9 -> 22;
               case 10 -> 25;
               case 11 -> 11;
               case 12 -> 13;
               case 13 -> 32;
               case 14 -> 33;
               case 15 -> 28;
               case 16 -> 36;
               case 17 -> 7;
               case 18 -> 14;
               case 19 -> 1;
               case 20 -> 39;
               case 21 -> 40;
               case 22 -> 46;
               case 23 -> 15;
               case 24 -> 9;
               case 25 -> 52;
               case 26 -> 17;
               case 27 -> 58;
               case 28 -> 26;
               case 29 -> 21;
               case 30 -> 31;
               case 31 -> 29;
               case 32 -> 41;
               case 33 -> 27;
               case 34 -> 50;
               case 35 -> 5;
               case 36 -> 34;
               case 37 -> 59;
               case 38 -> 0;
               case 39 -> 37;
               case 40 -> 12;
               case 41 -> 8;
               case 42 -> 57;
               case 43 -> 63;
               case 44 -> 48;
               case 45 -> 56;
               case 46 -> 35;
               case 47 -> 10;
               case 48 -> 43;
               case 49 -> 44;
               case 50 -> 61;
               case 51 -> 4;
               case 52 -> 18;
               case 53 -> 16;
               case 54 -> 53;
               case 55 -> 51;
               case 56 -> 55;
               case 57 -> 49;
               case 58 -> 23;
               case 59 -> 30;
               case 60 -> 62;
               case 61 -> 20;
               case 62 -> 19;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 224 && var8 != 'a' && var8 != 194 && var8 != 'm') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 251) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'S') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 224) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'a') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static float[] f(Matrix4f a) {
      return new float[]{
         a.m00(), a.m10(), a.m20(), a.m30(), a.m01(), a.m11(), a.m21(), a.m31(), a.m02(), a.m12(), a.m22(), a.m32(), a.m03(), a.m13(), a.m23(), a.m33()
      };
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何何树友友树何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "%\u0004=T'z*Dp_-g/\u0019{\u0019=a/\u0006`\u0019:p(\u000evEfG#\u0004wR:@2\u0003\u007fD";
      b[1] = int.class;
      c[1] = "java/lang/Integer";
      b[2] = "A8JGJ|Nx\u0007L@aK%\f\nPgK:\u0017\nWvL2\u0001V\u000b但佷桇厯可栴但叩桇伱";
      b[3] = "X.zs'-Z03\u0010,6E5ei+";
      b[4] = "MXaz7{FWp5\\oD\\gopxI";
      b[5] = ",\n\\d\u0010V,\nK8\u001cY6AK&\u0014Z,\u001b\u0006\u0007\u0014Q'\fZ+\u001bK";
      b[6] = ".Q\u001d\u0004\u0018V.Q\nX\u0014Y4\u001a\nF\u001cZ.@GX\u0010Q$Q\u001bO\u0007\u0011\u0007U\u0004O'Z.P\fX\u0010M";
      b[7] = "\f[K@Fl\f[\\\u001cJc\u0016\u0010H\u0001Yi\u0006\u0010O\u0006RvLhZ\r\u0018";
      b[8] = double.class;
      c[8] = "java/lang/Double";
      b[9] = "\fjL\u0005tC\u0007e]J\u0015M\fnY\u0010";
      b[10] = "\u001dx\u0017'\u0010\u0015\u001e}S6o厺栾桘厨厉厬伤佺桘伶JU\u0016A~Q0\u0016CDp";
      b[11] = "72-YG9?2afdXx$-\u0014\u00054~{lf";
      b[12] = "\u0000@q\u0006@m\u0003E5\u0017?h:B<\tR0\u0003\u000brQF\u0001\u0001Ho\u0006\u000e8H\u00067\u0012?";
      b[13] = "pk\u0004\u0001F\",>P\u001fzp\u001a4TSE/\u001a\u0004PU\u0014\u007f28\u0007\u0014\u001cs";
      b[14] = "Q\n#\u0000j]\t\u000b5\u0004\u0014I=Xf\\*\u001c=ic\u001eyJ\u0014\u0018'ThU";
      b[15] = "\u0001e\u0004W\u0015(\teHh\u0002INs\u0004\u001aW%H,Eh";
      b[16] = "X`\u000699\f\u00045R'\u0005^2?Vk5\t2\u000fRmkQ\u001a3\u0005,c]";
      b[17] = "DY./\u0003\u0002G\\j>|桷桧厣厑厁桥伳伣伽厑BF\u0001\u0018_h8\u0005T\u001dQ";
      b[18] = "%O)\u0004Q\u0000y\u001a}\u001amRO\u0010yV]\u0004O }P\u0003]g\u001c*\u0011\u000bQ";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   public static void k(Object[] var0) {
      Cherish.instance.getEventManager().register(new 何何树友友树何友树何());
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static Vec2 E(long a, Vec3 var2) {
      a = 8067056739345L ^ a;
      long ax = a ^ 83014779931776L;
      a<"S">(-7128728519371414333L, (long)a);
      if (a<"Â">(-7127453447612962827L, (long)a) != null && a<"Â">(-7128955519051225873L, (long)a) != null) {
         int[] viewport = new int[]{0, 0, mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight()};
         float[] win_pos = new float[3];
         e(
            (float)a<"à">(var2, -7128877405998277193L, (long)a),
            ax,
            (float)a<"à">(var2, -7127286010308652034L, (long)a),
            (float)a<"à">(var2, -7127396125940722516L, (long)a),
            f(a<"Â">(-7127453447612962827L, (long)a)),
            f(a<"Â">(-7128955519051225873L, (long)a)),
            viewport,
            win_pos
         );
         return null;
      } else {
         return null;
      }
   }

   @EventTarget
   public void A(Render3DEvent event) {
      if (event.poseStack() != null && mc.gameRenderer != null) {
         try {
            树树友友友树何何何友 = event.matrix4f();
            友树树友友友何何树何 = new Matrix4f(mc.gameRenderer.getProjectionMatrix(event.partialTick()));
         } catch (Exception var4) {
         }
      }
   }

   private static void R(float[] a, float[] a, float[] var2, long out) {
      out = (float[])(8067056739345L ^ out);
      a<"S">(-8358684464209350099L, (long)out);
      int i = 0;
      var2[0] = (float)(((Object[])a)[0] * a[0] + ((Object[])a)[1] * a[1] + ((Object[])a)[2] * a[2] + ((Object[])a)[3] * a[3]);
      i++;

      while (out <= 0L) {
      }
   }

   private static String HE_DA_WEI() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
