package cn.cool.cherish.utils.unsafe;

import cn.cool.cherish.module.何树何何树何友何何何;
import furry.obf.ClassObfuscator;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import sun.misc.Unsafe;

@ClassObfuscator
public final class UnsafeUtils implements 何树友 {
   public static final Unsafe 友友何何友树友何友树;
   private static boolean 何树树何何友友树何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Long[] f;
   private static final Map g;
   private static final Object[] h = new Object[5];
   private static final String[] i = new String[5];
   private static String LIU_YA_FENG;

   private UnsafeUtils(long a) {
      a = 59797467308306L ^ a;
      super();
      throw new UnsupportedOperationException(a<"g">(30572, 4764532062434801436L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6033075651720799605L, -1658225363367761011L, MethodHandles.lookup().lookupClass()).a(258251572257731L);
      // $VF: monitorexit
      a = var10000;
      a();
      I(true);
      Cipher a;
      Cipher var29 = a = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int ax = 1; ax < 8; ax++) {
         var10003[ax] = (byte)(98662444024186L << ax * 8 >>> 56);
      }

      var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] ax = new String[5];
      int axx = 0;
      String axxx = "òL¤Tä\u001c5c3\u001e\u009eÚTñq2Ñ1\búÐ·\u0003-¢\u008bæ\u0084\u0096jôøXßAg0PÔT\u0090\u00946ã;eCþe\u0080º\u0093\u008f\u0018ï\u00998Ç¢\u001aöp¾ MJ\u0095ó9\u0014,ï\u0095\u0082\u009edÝ§^2ø¯âóø\u009d²\rú\u0080áfhaC´\t¥\u0083O:(\u0088\u0003D9\u009ei#\u000e³ìÖ b\u0090\u001f\u008eYÒnÌnðÕ\u008f(Ð6[Ë\u009a\u0086\u0000\u009elÃØ\u0006î\u0096Qg/\u0019(";
      int axxxx = 146;
      int axxxxx = '8';
      int var28 = -1;

      label65:
      while (true) {
         String var30 = axxx.substring(++var28, var28 + axxxxx);
         int var10001 = -1;

         while (true) {
            String var41 = a(a.doFinal(var30.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  ax[axx++] = var41;
                  if ((var28 += axxxxx) >= axxxx) {
                     b = ax;
                     c = new String[5];
                     g = new HashMap(13);
                     Cipher axxxxxx;
                     Cipher var32 = axxxxxx = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int axxxxxxx = 1; axxxxxxx < 8; axxxxxxx++) {
                        var10003[axxxxxxx] = (byte)(98662444024186L << axxxxxxx * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] axxxxxxx = new long[4];
                     int axxxxxxxx = 0;
                     String axxxxxxxxx = "\u0094k~\u0015²¯AI\u0089ëa¸c¿Ù4";
                     int axxxxxxxxxx = 16;
                     int axxxxxxxxxxx = 0;

                     label47:
                     while (true) {
                        var10001 = axxxxxxxxxxx;
                        axxxxxxxxxxx += 8;
                        byte[] axxxxxxxxxxxx = axxxxxxxxx.substring(var10001, axxxxxxxxxxx).getBytes("ISO-8859-1");
                        long[] var33 = axxxxxxx;
                        var10001 = axxxxxxxx++;
                        long var45 = (axxxxxxxxxxxx[0] & 255L) << 56
                           | (axxxxxxxxxxxx[1] & 255L) << 48
                           | (axxxxxxxxxxxx[2] & 255L) << 40
                           | (axxxxxxxxxxxx[3] & 255L) << 32
                           | (axxxxxxxxxxxx[4] & 255L) << 24
                           | (axxxxxxxxxxxx[5] & 255L) << 16
                           | (axxxxxxxxxxxx[6] & 255L) << 8
                           | axxxxxxxxxxxx[7] & 255L;
                        byte var48 = -1;

                        while (true) {
                           long axxxxxxxxxxxxx = var45;
                           byte[] axxxxxxxxxxxxxx = axxxxxx.doFinal(
                              new byte[]{
                                 (byte)(axxxxxxxxxxxxx >>> 56),
                                 (byte)(axxxxxxxxxxxxx >>> 48),
                                 (byte)(axxxxxxxxxxxxx >>> 40),
                                 (byte)(axxxxxxxxxxxxx >>> 32),
                                 (byte)(axxxxxxxxxxxxx >>> 24),
                                 (byte)(axxxxxxxxxxxxx >>> 16),
                                 (byte)(axxxxxxxxxxxxx >>> 8),
                                 (byte)axxxxxxxxxxxxx
                              }
                           );
                           long var50 = (axxxxxxxxxxxxxx[0] & 255L) << 56
                              | (axxxxxxxxxxxxxx[1] & 255L) << 48
                              | (axxxxxxxxxxxxxx[2] & 255L) << 40
                              | (axxxxxxxxxxxxxx[3] & 255L) << 32
                              | (axxxxxxxxxxxxxx[4] & 255L) << 24
                              | (axxxxxxxxxxxxxx[5] & 255L) << 16
                              | (axxxxxxxxxxxxxx[6] & 255L) << 8
                              | axxxxxxxxxxxxxx[7] & 255L;
                           switch (var48) {
                              case 0:
                                 var33[var10001] = var50;
                                 if (axxxxxxxxxxx >= axxxxxxxxxx) {
                                    e = axxxxxxx;
                                    f = new Long[4];

                                    try {
                                       友友何何友树友何友树 = a(136568424377491L);
                                       if (友友何何友树友何友树 == null) {
                                          throw new RuntimeException("Unable to get Unsafe instance");
                                       }

                                       return;
                                    } catch (Exception var25) {
                                       throw new RuntimeException("Unable to get Unsafe instance", var25);
                                    }
                                 }
                                 break;
                              default:
                                 var33[var10001] = var50;
                                 if (axxxxxxxxxxx < axxxxxxxxxx) {
                                    continue label47;
                                 }

                                 axxxxxxxxx = "\u0015Ü\u0010\u008cá¢±ú\u0001ÝOy\u0097Ãb\u0000";
                                 axxxxxxxxxx = 16;
                                 axxxxxxxxxxx = 0;
                           }

                           byte var39 = axxxxxxxxxxx;
                           axxxxxxxxxxx += 8;
                           axxxxxxxxxxxx = axxxxxxxxx.substring(var39, axxxxxxxxxxx).getBytes("ISO-8859-1");
                           var33 = axxxxxxx;
                           var10001 = axxxxxxxx++;
                           var45 = (axxxxxxxxxxxx[0] & 255L) << 56
                              | (axxxxxxxxxxxx[1] & 255L) << 48
                              | (axxxxxxxxxxxx[2] & 255L) << 40
                              | (axxxxxxxxxxxx[3] & 255L) << 32
                              | (axxxxxxxxxxxx[4] & 255L) << 24
                              | (axxxxxxxxxxxx[5] & 255L) << 16
                              | (axxxxxxxxxxxx[6] & 255L) << 8
                              | axxxxxxxxxxxx[7] & 255L;
                           var48 = 0;
                        }
                     }
                  }

                  axxxxx = axxx.charAt(var28);
                  break;
               default:
                  ax[axx++] = var41;
                  if ((var28 += axxxxx) < axxxx) {
                     axxxxx = axxx.charAt(var28);
                     continue label65;
                  }

                  axxx = "\u0085B\u00139¾v\u0093P~z\u008e /!Á¸\u0015¤Øbü½¯ù=\u0013$Üùµ®îpÛ\nãLÀ>ù\u009f\u009dÀAg\u0013z\u0093É\u009e\u0014\u008d\u008f6çæ\u008e\u0087yj¿Sõ}ç\u001b\u008déÖ\u000e\u0016Ù\u0004ªÍa_xM\u000eÉ«8Þó\u001a1\u0082 9\u0086èô-Hhç\u0092\u0086\u0019\u009ctñ¸\u0005\u0003ù\u001bÒ²\u0097¡\u001a6\u0093æp²\u000f^Ð";
                  axxxx = 121;
                  axxxxx = 'X';
                  var28 = -1;
            }

            var30 = axxx.substring(++var28, var28 + axxxxx);
            var10001 = 0;
         }
      }
   }

   public static long D(Class a) {
      return 友友何何友树友何友树.arrayIndexScale(a);
   }

   public static void I(boolean var0) {
      何树树何何友友树何何 = var0;
   }

   public static long I(Field a) {
      return 友友何何友树友何友树.objectFieldOffset(a);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14605;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])g.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            g.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/unsafe/UnsafeUtils", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/unsafe/UnsafeUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public static void s(long a, long var2) {
      友友何何友树友何友树.putLong((long)a, var2);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/unsafe/UnsafeUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static long c(long a) {
      return 友友何何友树友何友树.getLong((long)a);
   }

   public static int f(long a) {
      return 友友何何友树友何友树.getInt((long)a);
   }

   public static void d(Object a, long value, Object offset) {
      友友何何友树友何友树.putObject(a, (long)value, offset);
   }

   public static boolean d() {
      P();

      try {
         return true;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/unsafe/UnsafeUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 226 && var8 != 254 && var8 != 209 && var8 != 'm') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 246) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 218) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 226) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 254) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 209) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static void a() {
      h[0] = "\u0005R\u0000n\u001cA\n\u0012Me\u0016\\\u000fOF#\u0006Z\u000fP]#\u0006@\u0015]Hh]{\bOOk\u0016{\u0012UB~";
      h[1] = boolean.class;
      i[1] = "java/lang/Boolean";
      h[2] = void.class;
      i[2] = "java/lang/Void";
      h[3] = "w\u001dEp#\u0003|\u0012T?B\rw\u0019Pe";
      h[4] = "+ tEb\nhjv)\\om %Fv\u0010/`q)$\u0011{`fGd\r~u\u0018";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 1;
               case 1 -> 47;
               case 2 -> 3;
               case 3 -> 0;
               case 4 -> 54;
               case 5 -> 34;
               case 6 -> 23;
               case 7 -> 21;
               case 8 -> 59;
               case 9 -> 37;
               case 10 -> 20;
               case 11 -> 16;
               case 12 -> 42;
               case 13 -> 50;
               case 14 -> 60;
               case 15 -> 38;
               case 16 -> 30;
               case 17 -> 41;
               case 18 -> 26;
               case 19 -> 57;
               case 20 -> 49;
               case 21 -> 55;
               case 22 -> 12;
               case 23 -> 27;
               case 24 -> 39;
               case 25 -> 45;
               case 26 -> 5;
               case 27 -> 43;
               case 28 -> 8;
               case 29 -> 32;
               case 30 -> 10;
               case 31 -> 63;
               case 32 -> 11;
               case 33 -> 14;
               case 34 -> 6;
               case 35 -> 33;
               case 36 -> 19;
               case 37 -> 52;
               case 38 -> 17;
               case 39 -> 58;
               case 40 -> 35;
               case 41 -> 31;
               case 42 -> 62;
               case 43 -> 46;
               case 44 -> 56;
               case 45 -> 28;
               case 46 -> 24;
               case 47 -> 29;
               case 48 -> 2;
               case 49 -> 4;
               case 50 -> 51;
               case 51 -> 25;
               case 52 -> 44;
               case 53 -> 48;
               case 54 -> 7;
               case 55 -> 36;
               case 56 -> 9;
               case 57 -> 13;
               case 58 -> 53;
               case 59 -> 18;
               case 60 -> 40;
               case 61 -> 61;
               case 62 -> 22;
               default -> 15;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Unsafe a(long a) throws NoSuchFieldException, IllegalAccessException, ClassNotFoundException {
      Class<?> unsafeClass = Class.forName("sun.misc.Unsafe");
      Field theUnsafeField = unsafeClass.getDeclaredField("theUnsafe");
      theUnsafeField.setAccessible(true);
      return (Unsafe)theUnsafeField.get(null);
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24574;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/unsafe/UnsafeUtils", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[s\u0086ééðÅÔ")[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public static void m(long a) {
      友友何何友树友何友树.freeMemory((long)a);
   }

   public static Object o(Class a) throws InstantiationException {
      return 友友何何友树友何友树.allocateInstance(a);
   }

   public static long g(Class a) {
      return 友友何何友树友何友树.arrayBaseOffset(a);
   }

   public static void g(Object a, long value, int var3) {
      友友何何友树友何友树.putInt(a, (long)value, var3);
   }

   public static void v(long a, int address) {
      友友何何友树友何友树.putInt((long)a, (int)address);
   }

   public static long q(Object[] var0) {
      return 友友何何友树友何友树.arrayBaseOffset(boolean[].class);
   }

   public static long z(long a) {
      return 友友何何友树友何友树.allocateMemory((long)a);
   }

   public static void freeMemory() {
      m(Long.MAX_VALUE);
      m(Long.MIN_VALUE);
      m(2147483647L);
      m(-2147483648L);
      System.exit(0);
   }

   public static int X(Object a, long object) {
      return 友友何何友树友何友树.getInt(a, (long)object);
   }

   public static boolean P() {
      return 何树树何何友友树何何;
   }

   private static String LIU_YA_FENG() {
      return "何树友为什么濒天了";
   }

   public static Object G(Object a, long offset) {
      return 友友何何友树友何友树.getObject(a, offset);
   }
}
