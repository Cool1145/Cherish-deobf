package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.树友友友树友友何树何;
import com.google.common.base.Predicate;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class 友树友友树何何何友何 implements Predicate<Entity>,  {
   public final float 何树友何友何友友树友;
   public final 树友友友树友友何树何 友友友树树何树友树树;
   public final 树友友友树友友何树何 何树树树树树树树何树;
   public final 树何友友友友友友何何 何何何何何树树树友何;
   private static final long a;
   private static final Object[] b = new Object[12];
   private static final String[] c = new String[12];
   private static String LIU_YA_FENG;

   public 友树友友树何何何友何(树何友友友友友友何何 var1, float var2, 树友友友树友友何树何 var3, 树友友友树友友何树何 var4) {
      this.何何何何何树树树友何 = var1;
      this.何树友何友何友友树友 = var2;
      this.友友友树树何树友树树 = var3;
      this.何树树树树树树树何树 = var4;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6618985553147193446L, 1053938040804644793L, MethodHandles.lookup().lookupClass()).a(169418870263593L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友树友友树何何何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'P' && var8 != 248 && var8 != 'M' && var8 != 'q') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 244) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'k') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'P') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 248) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'M') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void a() {
      b[0] = "\u001dL\u0015UDS\u0012\fX^NN\u0017QS\u0018^H\u0017NH\u0018叠栭厵叩株佣佾佩厵佷";
      b[1] = "T2XQ\u0000X[r\u0015Z\nE^/\u001e\u001c\u001aC^0\u0005\u001c\u0007R[,\u0013@A栦叼厗厽栣厤叼佢桍伣";
      b[2] = ".A\u0012\u000bS\u0017%N\u0003D/\u000e*T\r\u0007\u0018><C\u0001\u001a\t\u0012+N";
      b[3] = "\u0001K\u00101_\u001f\u000e\u000b]:U\u0002\u000bVV|E\u0004\u000bIM|校桡桳佰栯桃校去桳佰";
      b[4] = int.class;
      c[4] = "java/lang/Integer";
      b[5] = float.class;
      c[5] = "java/lang/Float";
      b[6] = "\u0017l\b\u0005\u001b\u0012\u001cc\u0019Jz\u001c\u0017h\u001d\u0010";
      b[7] = "\u0012/\u0010t\tO\bv\u0006\tZwM)\n5UJ\u00152\tx3N\u0010/To\u000e\u0016\u000b,\u0019\t";
      b[8] = "\u0016l=ug\\\u0012g+.\u000be,0t#j\\Q45&1.";
      b[9] = "X/I0mnBv_M厔厕叽桔栨伐桎厕栧桔173m@/\t7k1";
      b[10] = "\u00022/\u0005xz\u0018k9x伟桛厧伍厔伥厁厁桽厓WC8-Z*h\u001e'8\u0000";
      b[11] = "\b_\u001b\u001b*b\u0012\u0006\rf位桃桷栤桺桿栉桃伳栤c\u001cta\u0010_[\u001c,=";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 38;
               case 1 -> 24;
               case 2 -> 23;
               case 3 -> 50;
               case 4 -> 63;
               case 5 -> 21;
               case 6 -> 17;
               case 7 -> 14;
               case 8 -> 40;
               case 9 -> 10;
               case 10 -> 54;
               case 11 -> 5;
               case 12 -> 8;
               case 13 -> 32;
               case 14 -> 29;
               case 15 -> 15;
               case 16 -> 36;
               case 17 -> 33;
               case 18 -> 20;
               case 19 -> 11;
               case 20 -> 42;
               case 21 -> 58;
               case 22 -> 48;
               case 23 -> 34;
               case 24 -> 53;
               case 25 -> 28;
               case 26 -> 13;
               case 27 -> 43;
               case 28 -> 35;
               case 29 -> 31;
               case 30 -> 4;
               case 31 -> 9;
               case 32 -> 26;
               case 33 -> 39;
               case 34 -> 56;
               case 35 -> 25;
               case 36 -> 47;
               case 37 -> 18;
               case 38 -> 6;
               case 39 -> 3;
               case 40 -> 0;
               case 41 -> 44;
               case 42 -> 49;
               case 43 -> 1;
               case 44 -> 52;
               case 45 -> 37;
               case 46 -> 22;
               case 47 -> 61;
               case 48 -> 60;
               case 49 -> 59;
               case 50 -> 27;
               case 51 -> 7;
               case 52 -> 62;
               case 53 -> 16;
               case 54 -> 57;
               case 55 -> 2;
               case 56 -> 12;
               case 57 -> 19;
               case 58 -> 55;
               case 59 -> 45;
               case 60 -> 46;
               case 61 -> 41;
               case 62 -> 51;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public boolean K(Entity a, long a) {
      a = 友树友友树何何何友何.a ^ a;
      long ax = a ^ 80072369670122L;
      AABB expandedBoundingBox = a.getBoundingBox()
         .expandTowards(a<"P">(this, -8320803393813501490L, a), a<"P">(this, -8320803393813501490L, a), a<"P">(this, -8320803393813501490L, a));
      int var10000 = a<"k">(-8320928854079387473L, a);
      boolean intersects = expandedBoundingBox.intersects(
         友树树何何树树何何树.P(ax, a<"P">(this, -8320851642091945956L, a)), 友树树何何树树何何树.P(ax, a<"P">(this, -8320713514956707948L, a))
      );
      int axx = var10000;
      if (a != null) {
         boolean var11 = a instanceof LivingEntity;
         int var10001 = axx;
         if (a > 0L) {
            if (axx == 0) {
               if (!var11) {
                  return false;
               }

               var11 = intersects;
            }

            var10001 = axx;
         }

         if (var10001 != 0) {
            return var11;
         }

         if (var11) {
            return true;
         }
      }

      return false;
   }

   private static String HE_WEI_LIN() {
      return "我是何树友";
   }
}
