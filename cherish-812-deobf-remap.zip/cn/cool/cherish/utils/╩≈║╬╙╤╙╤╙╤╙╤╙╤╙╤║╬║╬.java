package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.树友友友树友友何树何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;

public enum 树何友友友友友友何何 implements IWrapper,  {
   何何何友树树树何树何,
   树友友何何友何何友友,
   树树树何友友何树友友,
   何友树友树友友何何树,
   何何何何友树何何树何,
   树树友何何何何友树树,
   何树友何何友何友树树;

   private final Item 友何树何何何何何树树;
   private final float 何何友何友友树树友树;
   public double 何树树友友树友树友树;
   public double 树何何何树何树友树友;
   public double 树何何友何树何树树友;
   public float 友友何树何友树树友树;
   public float 何友友树何何何树树树;
   public float 树树友何友何友树何友;
   public BlockHitResult 树友何何友友何何何友;
   public Entity 友树树何树何树何友树;
   private static final long a;
   private static final long b;
   private static final Object[] c = new Object[60];
   private static final String[] e = new String[60];
   private static int _行走的50万——何炜霖 _;

   private 树何友友友友友友何何(Item item, float posX, float posY, float posZ) {
      this.友何树何何何何何树树 = item;
      this.何何友何友友树树友树 = posY;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // $VF: Failed to inline enum fields
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-5912760764859525158L, 2506784712831329537L, MethodHandles.lookup().lookupClass()).a(246037805467713L);
      // $VF: monitorexit
      a = var10000;
      long var14 = a ^ 45909111082958L;
      long var16 = var14 ^ 87609234760870L;
      a();
      Cipher var6;
      Cipher var20 = var6 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var7 = 1; var7 < 8; var7++) {
         var10003[var7] = (byte)(var14 << var7 * 8 >>> 56);
      }

      var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var5 = new String[7];
      int var11 = 0;
      String var10 = "¦\u000bá42a]¢\u0088Hã¸#=é\u0015\u0010J\u00061Å\u009a¼ð<o\u008bÈ\u007f)c\u0010m\b>l\u0088ÇH\u0086«Ç\u0018õ®ð´Ï\"U\u0084\u0004u\u0092Õ0\u0004ýáøG\u0004w9\u001c~d\u0010Î\u009f\u008b0´àÂ\nU©ëÀ\u009d\u0083\u0012æ";
      byte var12 = 84;
      char var9 = 16;
      int var19 = -1;

      label45:
      while (true) {
         String var21 = var10.substring(++var19, var19 + var9);
         byte var10001 = -1;

         while (true) {
            String var29 = b(var6.doFinal(var21.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var5[var11++] = var29;
                  if ((var19 += var9) >= var12) {
                     Cipher var0;
                     Cipher var23 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var14 << var1 * 8 >>> 56);
                     }

                     var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-27, 56, 111, 88, -60, 117, -69, 57});
                     long var33 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     b = var33;
                     何树何何友树树友何友 = !树何友友友友友友何何.class.desiredAssertionStatus();
                     何何何友树树树何树何 = new 树何友友友友友友何何(a<"Ø">(3435647556991787643L, var14), 0.0F, 3.0F, 0.0F);
                     树友友何何友何何友友 = new 树何友友友友友友何何(a<"Ø">(3433057693072535631L, var14), 0.0F, 1.875F, 0.0F);
                     树树树何友友何树友友 = new 树何友友友友友友何何(a<"Ø">(3435209163273676521L, var14), 0.0F, 1.875F, 0.0F);
                     何友树友树友友何何树 = new 树何友友友友友友何何(a<"Ø">(3432492547199102168L, var14), 0.0F, 1.875F, 0.0F);
                     何何何何友树何何树何 = new 树何友友友友友友何何(a<"Ø">(3432609583229289596L, var14), 0.0F, 0.5F, 0.0F);
                     树树友何何何何友树树 = new 树何友友友友友友何何(a<"Ø">(3433120573858367949L, var14), 0.0F, 0.6F, 0.0F);
                     何树友何何友何友树树 = new 树何友友友友友友何何(a<"Ø">(3432025892712407635L, var14), 0.0F, 2.5F, 0.0F);
                     return;
                  }

                  var9 = var10.charAt(var19);
                  break;
               default:
                  var5[var11++] = var29;
                  if ((var19 += var9) < var12) {
                     var9 = var10.charAt(var19);
                     continue label45;
                  }

                  var10 = "+§Ãªû\u008e_b\b\u008fDßâÆ\u001e\u0013\u0003";
                  var12 = 17;
                  var9 = '\b';
                  var19 = -1;
            }

            var21 = var10.substring(++var19, var19 + var9);
            var10001 = 0;
         }
      }
   }

   public float I(long a) {
      a = 树何友友友友友友何何.a ^ a;
      a<"a">(-2443743063215863764L, (long)a);
      if (!a<"µ">(this, -2444243513866206015L, (long)a).equals(a<"Ø">(-2442669085851790385L, (long)a))) {
         return a<"µ">(this, -2444052648703564527L, (long)a);
      } else {
         return !(a<"µ">(this, -2444052648703564527L, (long)a) * BowItem.getPowerForTime(mc.player.getUseItemRemainingTicks()) > 0.0F)
            ? BowItem.getPowerForTime(20)
            : BowItem.getPowerForTime(mc.player.getUseItemRemainingTicks());
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 58;
               case 1 -> 31;
               case 2 -> 45;
               case 3 -> 5;
               case 4 -> 15;
               case 5 -> 6;
               case 6 -> 18;
               case 7 -> 13;
               case 8 -> 16;
               case 9 -> 38;
               case 10 -> 55;
               case 11 -> 37;
               case 12 -> 29;
               case 13 -> 54;
               case 14 -> 49;
               case 15 -> 10;
               case 16 -> 11;
               case 17 -> 22;
               case 18 -> 62;
               case 19 -> 27;
               case 20 -> 57;
               case 21 -> 23;
               case 22 -> 56;
               case 23 -> 30;
               case 24 -> 34;
               case 25 -> 59;
               case 26 -> 36;
               case 27 -> 24;
               case 28 -> 7;
               case 29 -> 39;
               case 30 -> 60;
               case 31 -> 3;
               case 32 -> 51;
               case 33 -> 33;
               case 34 -> 61;
               case 35 -> 47;
               case 36 -> 1;
               case 37 -> 9;
               case 38 -> 42;
               case 39 -> 63;
               case 40 -> 20;
               case 41 -> 14;
               case 42 -> 48;
               case 43 -> 43;
               case 44 -> 12;
               case 45 -> 21;
               case 46 -> 0;
               case 47 -> 32;
               case 48 -> 19;
               case 49 -> 2;
               case 50 -> 50;
               case 51 -> 26;
               case 52 -> 8;
               case 53 -> 41;
               case 54 -> 28;
               case 55 -> 4;
               case 56 -> 17;
               case 57 -> 53;
               case 58 -> 46;
               case 59 -> 25;
               case 60 -> 40;
               case 61 -> 52;
               case 62 -> 35;
               default -> 44;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static 树何友友友友友友何何 e(long a, Item var2) {
      a = 树何友友友友友友何何.a ^ a;
      long ax = a ^ 62250921834277L;
      long axx = a ^ 118901178838546L;
      int var10000 = a<"a">(-3848650169268299930L, (long)a);
      树何友友友友友友何何[] var9 = l(axx);
      int var10 = var9.length;
      int axxx = var10000;
      int var11 = 0;

      while (var11 < var10) {
         树何友友友友友友何何 var6x = var9[var11];
         var10000 = axxx;
         if (a >= 0L) {
            if (axxx != 0) {
               if (var6x.w(ax).equals(var2)) {
                  return var6x;
               }

               var11++;
            }

            var10000 = axxx;
         }

         if (var10000 == 0) {
            break;
         }
      }

      return null;
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 181 && var8 != 'G' && var8 != 216 && var8 != 162) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 255) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'a') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 181) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'G') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 216) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static 树何友友友友友友何何[] l(long var0) {
      var0 = a ^ var0;
      return (树何友友友友友友何何[])a<"Ø">(-4260296639054375064L, var0).clone();
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/树何友友友友友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      c[0] = "\u0017\u007f<\u0017t{\u0018?q\u001c~f\u001dbzZn`\u001d}aZ栊佁县叚叙县叐叟伡佄";
      c[1] = "G|A\u0011B\u001bs_NQ\u000f\u0010yBK\f\u0004ViDK\u0013\u001fV栍佥叩厴厧厳受叻佷伪W";
      c[2] = "^8\u0013\u0002C\u000eQx^\tI\u0013T%UOY\u0015T:NO栽桰栬伃栬桰栽厪栬伃";
      c[3] = int.class;
      e[3] = "java/lang/Integer";
      c[4] = "\u00040g61z\u000f?vyMc\u0000%x:zS\u00162t'k\u007f\u0001?";
      c[5] = float.class;
      e[5] = "java/lang/Float";
      c[6] = "?\u000fd-\u001a`0O)&\u0010}5\u0012\"`\u0018`8\u0014&+[B3\u0005?\"\u0010";
      c[7] = boolean.class;
      e[7] = "java/lang/Boolean";
      c[8] = "+\u0007rt'%+\u0007e(+*1Le6#)+\u0016(*&-<\u0007tt\u0006#&\u0003j\n&-<\u0007t";
      c[9] = double.class;
      e[9] = "java/lang/Double";
      c[10] = "\u0007\u0013\u0001oky\u0007\u0013\u00163gv\u001dX\u0002.t|\rX\u0005)\u007fcG>\u001c5Tu\u001a\u0003\u00195\"D\u0010\u0006\u0010";
      c[11] = void.class;
      e[11] = "java/lang/Void";
      c[12] = "lT>\u001ebklT)Bndv\u001f=_}nf\u001f&Uygn\u001f\t\\frA^$Djzv\u0015\b\\`ai";
      c[13] = "R.\u0007T\u0011bR.\u0010\b\u001dmHe\u0004\u0015\u000egXe\u0016\u0014\bbH2]?\u0012\u007fU?\n";
      c[14] = "^\u000e\u001bI1T^\u000e\f\u0015=[DE\u0018\b.QTE\u0003\u0002*X\\E,\u000b5Ms\u0004\u0001\u00139EDO)\u000b)TT";
      c[15] = "\u001c-1\u001ajH\u001c-&FfG\u0006f2[uM\u0016f5\\~R\\\u001e W4";
      c[16] = "{\u0012\u0019\u0016h-{\u0012\u000eJd\"aY\u001aWw(qY\u0004L`);>\u0019]h";
      c[17] = "\u0017lj'F0\u0017l}{J?\r'ifY5\u001d'naR*WKrfH21`j[N*\fej";
      c[18] = "j[M={\u001cj[Zaw\u0013p\u0010N|d\u0019`\u0010Pgs\u0018*wMv{\u0006";
      c[19] = "S\u0014\u001aDF@X\u001b\u000b\u000b'NS\u0010\u000fQ";
      c[20] = "?V\\7p\u000b4\u001aQ\u000e佄厰厓桳佪体佄桪桉桳75~\u001a(\u000eZ>%\u0017>";
      c[21] = "\f\n\u0001Y\u0013q\u0007F\f`档栐厠佫厩伽厹栐伾叵j[\u001d`\u001bR\u0007PFm\r";
      c[22] = "C8l\u007fROHtaF栢栮栵余叄厅佦栮可叇\u0007)\u0007\\\u0015m\u007f\"KQ";
      c[23] = "R-kRb_V#{\t\u0002X;+%\b3\u000f;\u0012*Qp\b\fn}Ik\b";
      c[24] = "?H{*3\u00052\u0006?1\u000bR\u0003\u0004~h;\u0000\u00038.2b\u0002?I-/z\u0006";
      c[25] = "i\u007f\u0005r-{b3\bK桝栚叅伞伳伖伙叀栟桚n$xh?*\u0016/4e";
      c[26] = "\\C|{\"\u0000W\u000fqB伖桡佮伢叔桛桒去佮厼\u0017\u007fz\u0003Q@y~4@^";
      c[27] = "[$_\u0000t\u0000[2Z\r\u001f7,\u001a~qS11^\nJzL\u0000\"\n\\\u007fA";
      c[28] = "-&I\u0017uC&jD.佁栢厁佇使叭佁司桛栃\"A P{sZJl]";
      c[29] = "U\u000f>j& ^C3S厌桁栣佮桌伎桖伅叹株Ub~bKOm-w\"_";
      c[30] = "0\u000fB\u0006l#=A\u0006\u001dTt\fCGEm#\f\u007f\u0017\u001e=$0\u000e\u0014\u0003% ";
      c[31] = "_|:B'\u001dT07{伓伸佭伝厒桢伓伸栩伝Q\u0014r\u000e\t))\u001f>\u0003";
      c[32] = "C#\t\u0013f'Ho\u0004*佒厜栵叜桻叩双伂佱栆bE34\u0015v\u001aN\u007f9";
      c[33] = "\"g \u0001'(b80O\u001cY\u001b>9\u000egt`>e\u0011w\u0012";
      c[34] = "d'\u0018\f{\u001et'\u0014\u000b\u0010AZqEK \u0016ZAA\u0011b\u0011m=\u0016\ty\u0011";
      c[35] = "v\u0001a@hu{O%[P\"JMd\u0002juJq4X9rv\u00007E!v";
      c[36] = "\t!\u001eEQ0\u0002m\u0013|叻压伻栄伨县校桑厥栄uG_!\u001ey\u0018L\u0004,\b";
      c[37] = "\u0005}\";p\u000e\b3f HY91'{s\t9\rw#!\t\u0005|t>9\r";
      c[38] = "\u000ebXau!\u001ebTf\u001e~04\u0005&!!0\u0004\u0001|l.\u0007xVdw.";
      c[39] = "VB\u0002x\u0004~]\u000e\u000fA桴佛佤厽伴桘估栟栠厽i\u007f\u000bt\u0007\u001e\u0015(\u0013o\u0007";
      c[40] = "=FIS\u001eY6\nDj厴佼桋伧使伷伪佼桋档\"\u0000\u0010Hl\u0011S\u0003\rPh";
      c[41] = "p,C\"#\u000e{`N\u001b桓厵佂位叫变众伫佂叓(p'\u0017gpZ%#\bg";
      c[42] = "M5@t\",FyMM伖伉叡佔叨厎桒桍叡栐+v,=ZmF}w0L";
      c[43] = "%\u0005g?\u001a\u007f.Ij\u0006伮佚众叺栕栟桪佚桓佤\fiOlsPtb\u0003a";
      c[44] = "\u0002\u000ej\u0003h[\u0000\u0010mT\u0010v>W6\u0014r\nPVxW}5";
      c[45] = "%\u0019\u007f3 _(W;(\u0018\b\u0019Uzs!]\u0019i*+qX%\u0018)6i\\";
      c[46] = "[.8an\t\u00058('^!%\u0019\bXa\b\u000f{c5?\u001e\u001f=";
      c[47] = "\u000b\u0003&\\u=\t\u001d!\u000b\r\u001a7ZzKolY[4\b`S\u0007\\:]3)Y\u0018sJ\r";
      c[48] = "\u0003\u007f\u001bN@\u000e\b3\u0016w栰桯伱伞伭伪只厵厯伞p\b\u0019M\u0002*\u0014NWK";
      c[49] = "\u0001C\u001fc^N\u0005M\u000f8>IhEQ9\u000f\u001dh|^`L\u0019_\u0000\txW\u0019";
      c[50] = "\u0014z\u007f;8~T%ou\u0003\r-#f4x\"V#:+hD";
      c[51] = "fP\u0014r\u0018DsULq!8Hz:\u0011H\u0012l_N+]\u00174\\";
      c[52] = ".GGiFw*IW2&pGA\t3\u0017&Gx\u0006jT p\u0004QrO ";
      c[53] = "\u001a$\u000b\u0002j \u0011h\u0006;jXN \u0012]y7\t&\u0004\u000b\u0003cMj\u0006Al$K|P;";
      c[54] = "\u0006|N\u0002q\u007f\r0C;佅栞桰厃另栢叛栞厪桙%\u0005~uW YRfnW";
      c[55] = "C\u0005\u0013qL2HI\u001eH格众佱佤桡伕格厉栵叺xvC8\u0012Y\u0004![#\u0012";
      c[56] = "Qb*hMdAb&o&;o4w/\u0016mo\u0004suTkXx$mOk";
      c[57] = "\fA\f\u001ee9\u0007\r\u0001'栕厂厠传伺古佑伜厠厾gH0*Z\u0014\u001fC|'";
      c[58] = "4Sqj\u000eh9\u001d5q6?\b\u001ft+\u000fk\b#$r_o4R'oGk";
      c[59] = "6z\"/!\u0006;4f4\u0019Q\n6'l$\u0005\n\nw7p\u00016{t*h\u0005";
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static 树何友友友友友友何何 v(String a) {
      return Enum.valueOf(树何友友友友友友何何.class, a);
   }

   public Item w(long a) {
      a = 树何友友友友友友何何.a ^ a;
      return a<"µ">(this, -2463163679998556412L, (long)a);
   }

   public List N(long a) {
      a = 树何友友友友友友何何.a ^ a;
      long ax = a ^ 43600769676075L;
      long axx = a ^ 77119726862744L;
      long axxx = a ^ 93438647771176L;
      int var10000 = a<"a">(-3820575998602438902L, (long)a);
      ArrayList list = new ArrayList();
      int axxxx = var10000;
      if (!a<"Ø">(-3823376724174468135L, (long)a) && mc.player == null) {
         throw new AssertionError();
      } else {
         float var4x = (float)Math.toRadians(mc.player.getYRot());
         float var5 = (float)Math.toRadians(mc.player.getXRot());
         double var6x = a<"µ">(mc.player, -3820399545448421579L, (long)a)
            + (mc.player.getX() - a<"µ">(mc.player, -3820399545448421579L, (long)a)) * WrapperUtils.P(new Object[0]);
         double var8x = a<"µ">(mc.player, -3822459937422763604L, (long)a)
            + (mc.player.getY() - a<"µ">(mc.player, -3822459937422763604L, (long)a)) * WrapperUtils.P(new Object[0]);
         double var10x = a<"µ">(mc.player, -3820656651221691328L, (long)a)
            + (mc.player.getZ() - a<"µ">(mc.player, -3820656651221691328L, (long)a)) * WrapperUtils.P(new Object[0]);
         a<"G">(this, var6x, -3820281791843177160L, (long)a);
         a<"G">(this, var8x + mc.player.getEyeHeight() - 0.1F, -3820181341897282909L, (long)a);
         a<"G">(this, var10x, -3819092333924169803L, (long)a);
         float var12 = Math.min(20.0F, (int)b - mc.player.getUseItemRemainingTicks() + mc.getPartialTick()) / 20.0F;
         a<"G">(this, (float)(-Math.sin(var4x) * Math.cos(var5) * a<"µ">(this, -3819969372554137095L, (long)a) * var12), -3819266098566758516L, (long)a);
         a<"G">(this, (float)(-Math.sin(var5) * a<"µ">(this, -3819969372554137095L, (long)a) * var12), -3822694766846468626L, (long)a);
         a<"G">(this, (float)(Math.cos(var4x) * Math.cos(var5) * a<"µ">(this, -3819969372554137095L, (long)a) * var12), -3822596320214380946L, (long)a);
         a<"G">(this, null, -3820039977527382913L, (long)a);
         a<"G">(this, null, -3823148584022672483L, (long)a);
         list.add(
            new 树树树何树树树友树何(
               a<"µ">(this, -3820281791843177160L, (long)a), ax, a<"µ">(this, -3820181341897282909L, (long)a), a<"µ">(this, -3819092333924169803L, (long)a)
            )
         );
         if (a<"µ">(this, -3820039977527382913L, (long)a) == null
            && a<"µ">(this, -3823148584022672483L, (long)a) == null
            && a<"µ">(this, -3820181341897282909L, (long)a) > 0.0) {
            树友友友树友友何树何 startVec = new 树友友友树友友何树何(
               axxx, a<"µ">(this, -3820281791843177160L, (long)a), a<"µ">(this, -3820181341897282909L, (long)a), a<"µ">(this, -3819092333924169803L, (long)a)
            );
            树友友友树友友何树何 endVec = new 树友友友树友友何树何(
               axxx,
               a<"µ">(this, -3820281791843177160L, (long)a) + a<"µ">(this, -3819266098566758516L, (long)a),
               a<"µ">(this, -3820181341897282909L, (long)a) + a<"µ">(this, -3822694766846468626L, (long)a),
               a<"µ">(this, -3819092333924169803L, (long)a) + a<"µ">(this, -3822596320214380946L, (long)a)
            );
            float size = (float)(!(a<"µ">(this, -3820169100230799319L, (long)a) instanceof BowItem) ? 0.25 : 0.3);
            AABB boundingBox = new AABB(
               a<"µ">(this, -3820281791843177160L, (long)a) - size,
               a<"µ">(this, -3820181341897282909L, (long)a) - size,
               a<"µ">(this, -3819092333924169803L, (long)a) - size,
               a<"µ">(this, -3820281791843177160L, (long)a) + size,
               a<"µ">(this, -3820181341897282909L, (long)a) + size,
               a<"µ">(this, -3819092333924169803L, (long)a) + size
            );
            List<Entity> entities = mc.level
               .getEntities(
                  mc.player,
                  boundingBox.move(
                        a<"µ">(this, -3819266098566758516L, (long)a),
                        a<"µ">(this, -3822694766846468626L, (long)a),
                        a<"µ">(this, -3822596320214380946L, (long)a)
                     )
                     .inflate(1.0, 1.0, 1.0),
                  new 友树友友树何何何友何(this, size, startVec, endVec)
               );
            if (!entities.isEmpty()) {
               label62:
               for (Entity entity : entities) {
                  a<"G">(this, entity, -3823148584022672483L, (long)a);

                  do {
                     var10000 = axxxx;
                     if (a > 0L) {
                        if (axxxx == 0) {
                           return list;
                        }

                        var10000 = axxxx;
                     }

                     if (var10000 != 0) {
                        continue label62;
                     }
                  } while (a <= 0L);

                  boolean var32 = a<"a">(-3819832745902321366L, (long)a);
                  if (a >= 0L) {
                     var32 = !var32;
                  }

                  a<"a">(var32, -3819624809534500485L, (long)a);
                  break;
               }
            }

            label46: {
               BlockHitResult trace = mc.level
                  .clip(
                     new ClipContext(
                        友树树何何树树何何树.P(axx, startVec),
                        友树树何何树树何何树.P(axx, endVec),
                        a<"Ø">(-3823310525548880141L, (long)a),
                        a<"Ø">(-3820464087412976385L, (long)a),
                        mc.player
                     )
                  );
               BlockHitResult var33 = trace;
               if (a > 0L) {
                  if (trace == null) {
                     break label46;
                  }

                  var33 = trace;
               }

               if (var33.getType() != a<"Ø">(-3819755528722320902L, (long)a)) {
                  a<"G">(this, trace, -3820039977527382913L, (long)a);
                  a<"G">(
                     this, a<"µ">(a<"µ">(this, -3820039977527382913L, (long)a).getLocation(), -3819161434382770214L, (long)a), -3820281791843177160L, (long)a
                  );
                  a<"G">(
                     this, a<"µ">(a<"µ">(this, -3820039977527382913L, (long)a).getLocation(), -3821284114262662284L, (long)a), -3820181341897282909L, (long)a
                  );
                  a<"G">(
                     this, a<"µ">(a<"µ">(this, -3820039977527382913L, (long)a).getLocation(), -3819447833695315517L, (long)a), -3819092333924169803L, (long)a
                  );
                  list.add(
                     new 树树树何树树树友树何(
                        a<"µ">(this, -3820281791843177160L, (long)a),
                        ax,
                        a<"µ">(this, -3820181341897282909L, (long)a),
                        a<"µ">(this, -3819092333924169803L, (long)a)
                     )
                  );
               }
            }

            a<"G">(this, a<"µ">(this, -3820281791843177160L, (long)a) + a<"µ">(this, -3819266098566758516L, (long)a), -3820281791843177160L, (long)a);
            a<"G">(this, a<"µ">(this, -3820181341897282909L, (long)a) + a<"µ">(this, -3822694766846468626L, (long)a), -3820181341897282909L, (long)a);
            a<"G">(this, a<"µ">(this, -3819092333924169803L, (long)a) + a<"µ">(this, -3822596320214380946L, (long)a), -3819092333924169803L, (long)a);
            list.add(
               new 树树树何树树树友树何(
                  a<"µ">(this, -3820281791843177160L, (long)a), ax, a<"µ">(this, -3820181341897282909L, (long)a), a<"µ">(this, -3819092333924169803L, (long)a)
               )
            );
            a<"G">(this, a<"µ">(this, -3819266098566758516L, (long)a) * 0.99F, -3819266098566758516L, (long)a);
            a<"G">(this, a<"µ">(this, -3822694766846468626L, (long)a) * 0.99F, -3822694766846468626L, (long)a);
            a<"G">(this, a<"µ">(this, -3822596320214380946L, (long)a) * 0.99F, -3822596320214380946L, (long)a);
            a<"G">(this, a<"µ">(this, -3822694766846468626L, (long)a) - 0.05F, -3822694766846468626L, (long)a);
         }

         return list;
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖黑水";
   }
}
