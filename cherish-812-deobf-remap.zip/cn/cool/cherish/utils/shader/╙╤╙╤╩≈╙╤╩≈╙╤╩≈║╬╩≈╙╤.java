package cn.cool.cherish.utils.shader;

public interface 友友树友树友树何树友 {
   void Z(long var1);

   void t(long var1);
}
