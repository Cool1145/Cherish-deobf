package cn.cool.cherish.utils.shader;

public interface 树树树何何何友树友友 {
   void w(long var1);

   void T(long var1);
}
