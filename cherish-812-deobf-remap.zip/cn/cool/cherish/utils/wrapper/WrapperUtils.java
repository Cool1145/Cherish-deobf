package cn.cool.cherish.utils.wrapper;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.helper.何何树树何何友友友树;
import cn.lzq.injection.asm.mapping.Mapping;
import cn.lzq.injection.asm.transformer.entity.LocalPlayerTransformer;
import cn.lzq.injection.asm.transformer.util.TimerTransformer;
import cn.lzq.injection.asm.transformer.world.ClientLevelTransformer;
import com.mojang.blaze3d.pipeline.RenderTarget;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.inventory.BrewingStandMenu;
import net.minecraft.world.level.entity.TransientEntitySectionManager;
import net.minecraft.world.phys.Vec3;

public final class WrapperUtils implements IWrapper, 何树友 {
   private static int[] 何树树友何友何何树何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[22];
   private static final String[] g = new String[22];
   private static int _我是何树友 _;

   private WrapperUtils(long a) {
      a = 67130880896992L ^ a;
      super();
      throw new UnsupportedOperationException(a<"s">(19061, 5954449777253714239L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(158141177789371283L, 1445242337102243891L, MethodHandles.lookup().lookupClass()).a(233858277961215L);
      // $VF: monitorexit
      a = var10000;
      a();
      F(null);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(136222538595675L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[40];
      int var5 = 0;
      String var4 = "\u00045N\u009e\u0095\"N\u001a\u0017B:=óÁW\u0086\u0011³Í¦\f÷]^\u0018\u001c/ú\u000e%\u0002\t`Ó\u0099\u008cÛ\u0004°9\u0014©\u008d\u0092\u0083T\u009f\u0090+OQÒ,R:º\rb\u009f\"n¦\u009es¦\n£¶0Ò¬\u0018¢Ðäº^ÐÇþ\u0094Å¤\u0094ÖÎÊJ\u0002i\u0018®tnÉæ\u0098È²Å÷ùs÷Øê\u0004úêº\u0015ñí[à=g&Û(Åc\u0093\u001dq\u0089YÊ6 \\\u0087Ä¶\u0098\fûüª\u009c\u0010Èv\u008b\u009cø_\u0084\u001f\u0093\u007f\u008eWºI·ðÉ-9QÔ\u0010¦\u00059ðê5;Í×@Mm&HÆâ\u0010\u0089$àÃxb\u0018\u0083D3DD|\u0086ð\u001bX  §T«5\u0014ÀçêYË>´a\u001eiC4'B(\u0099¡\u000bóÒ¢w\u001d\u001dl¡PßT\u000b\u0081°ûM¹\fQÍZ\u0086\u00ad \u0014ÂRU\ng\"\u008eVÅ¥\u0015\u0094Â\u001b±Ýt?³h£¥ë\u00ad{èÅç¸\u009aqð¼\tYIN\u0085\u0010\u009294F\u0094oC*X;<Ýñ\u009f±ú(>3ØRÏ\u0093a\u009dc°´ÓõC\u0018\u0015GÃWû³ÓãG¸þ\u008bÄyyÝ0\u001eÄGÐ\u001ez\u0018?(\u0087&ç\u0017JÐU\u0082£\u0093\u0097(zÙT!ôÙ±\u0092±÷\u008cú\f\u0005\u009bbûÊ»-±\u0016ýWN\u000b&+ \rÿxêÍ)t¥Ù\u007fûs\u0015ÎÎH$HH\u0007\b<§÷C°\b³Æ`TÍ <2Ý¶% \f£5\u008d\u0097\u000bþÝ`\u0089\u0085iy@\u008c\u0088\u0001\u00901]{â¸â\u0016ô8¹ðË§¹\u0082 \u007f\u009eú©üê1k«d\u0083\u009f\u0094éÃ\u008a\u0084/]ò½J\u001c®Ë{s}·\u0081eE\u000b¥)\u0097µ5£CÅ:|6nªw\u001eá L\fTÜ\tå²Ï\u0017SL]áí\u0013°h¶Àk1.é~Í=O|~9Ã\u0083 Q¼òÚ\u0004)\u001a.ÎY\u0093\u0081A^£¬ªçGýNE8XêoÛ'|Ñ·´ mjÍ¼¡¾ gÝ=\bª/T2z~X\u0006ÿ ßÙ\u008f\u0090qqLm°!\u0001(9¡·Ø«Ï\rB\u008f£\u00942×à\u009eÿ±®ìÉ'\u009d$\u0018ºÞ´ÐÓ@ZQ\u0011\u008dm\u008b&¢e¼\u0018LÚã*\u008cwo%<ý\u0082(\u0000ìÀ·ù\u0084\u0089\u0088E\u0082`*\u0010¿bý#\u000b¼\u0098×K(\u009fë¤ô.¿8\u007fâö\u0006¹¹zø\u0089?âBàæP¢G³@NÊ\u009e\u0015/S\u008a\u0080\u000fPFÒ\u0095Ùo\u0002\u001eÊ\t\u0093\u0085\u0090!°\u0001=\u0084sÏ\u009cÙÃÒô\\\u001a[\u0010£ú+8\u008d\u0011öÉ·ÇôyÄkpÏ \u009déÛÈ£\u0007\u0090ë\u0011\u0087áíUTÁvE\u008dKµâ\u008f\u0012]Hò Å\u00986^u\u0018\u0014öôà\u0088\u0007\u0015\u007fòeÚxz\u0085\u008b_~Ac%v®\u0084\u0088HÃ\u0019\bsÃ\u0084à}bé$øE\u0018ÁÕ\rrµ\u00887h¸CÖ\u008dB\u001fñ\u0082iÎígØòlná\u0098¡Ú$¤(Þ¥é?ÙA\u0091\nõ\u0012ö¿\u0083¢´\u000f9l°\u0099\u0093B\u009dmÐ\u008b\u001e\u0010\u0090ÊÖ\u0080]£º\u0099Û\u0087'×'Â\u001c\t\u0010\u009b\bÌ!\u009bÓDî)©üºh\u0083ñf\u0010ÜñzÒ´¢ûx\u00ad3BÚ\u0011^ñ\u0088 aÔ\u0090\u0088I\u0096ÞvÖ0¥\"Ê9Íñ¶ \fÓ!*`:\u001dÂ\u0083¿vaò\u0010P¡\u0081¾\u0094Ò$øRIË+ù\u0006Û¦)®\u0090*Æuk<\u0089¾\u0089(\u0093y`\u008eå«e\u0015AÎ¡fM¼Ä\u0082\u0086\"\u0085á\u0091TÅú¬Ç¯8\u0013u¨\u001da\u009f\u001a\u0010¤ñrÅj\u0080\u0011z-ÔA\u001b\u001f\u0017|_\u0012 >²â7ì\u001aÅ3ExNXb\nYüèDÍ³wì\u0018Y\u009bTï\u0091PV3\u008d ë0È$Ð\u009ea\f¾\u001c1\u008cA&\u001e¢Â®È¨i¶È]%\u0080Þ¯¶á{)\u0018\u0019\u009b\f¿É\u0089i£'R1B\nËº\u001a*º\u001cDÙøK*(clòzÁ\u0019<ýZ\u0003N¨ÖKû\u00853ÒEX5*P\u0085ÜÓ\u0001#eqs\u009f\bÀ\u009c\u001cVóÚ:\u0018 Ï1+cí¦zÄiJ½ù\u0084\u0087ML\u0014á\u009b\u0096bf\u008b \u0018cXZ=\u0091$g\u0011ãoî½\u000bÅ\u00ad:¤q.è°È\u0094T\u0099Õ<\\d\u0091Ö\u0010©\u0080Óub2P\u0016\u009dCè7®µ\u001dù  áv\r/½\u0095\u0006³Þe\u009d\u008aäÜ½¤\u0012Â\u008cL\u0006 \u0089ç'\u008b¢\u009e\u009f\u0010ý\u0018e¯\u0001b\u0019(C)¬©ûÍû±¸\u008b5qü·¯Þ±d\u0010 $Ü\u0016pf\u001b\u0007\u001e}ÛÈD\u00ad\u009eS";
      short var6 = 1341;
      char var3 = ' ';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[40];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "\u001b\u001doæ\u0083¿\u0011´b\u001a¡\u0006ôapì6¡\u007f x¡\u0007\u0006\u001cåûdòL.¤ æ1#Ò\u0080;S\u000eØ4-\u0019`\u0007XºÚÞý\u0084ÄDÔüO¿7É8è¢ù";
                  var6 = 65;
                  var3 = ' ';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public static float B(long a, ServerboundMovePlayerPacket var2) {
      Field xRotField = 何何树树何何友友友树.n(129843684661419L, var2.getClass(), Mapping.get(ServerboundMovePlayerPacket.class, "xRot", null));

      try {
         return xRotField.getFloat(var2);
      } catch (Exception var8) {
         var8.printStackTrace();
         return 0.0F;
      }
   }

   public static boolean B(long a) {
      a = 67130880896992L ^ a;
      long ax = a ^ 123506706303757L;
      b<"p">(1414915301940361013L, (long)a);
      if (mc.player == null) {
         return false;
      } else {
         Field sprintingField = 何何树树何何友友友树.n(ax, mc.player.getClass(), Mapping.get(mc.player.getClass(), a<"s">(19311, 8966678468026107541L ^ a), null));

         try {
            return sprintingField.getBoolean(mc.player);
         } catch (Exception var8) {
            var8.printStackTrace();
            return false;
         }
      }
   }

   public static void C(ServerboundMovePlayerPacket a, long packet, float var3) {
      Field yRotField = 何何树树何何友友友树.n(129843684661419L, a.getClass(), Mapping.get(ServerboundMovePlayerPacket.class, "yRot", null));

      try {
         yRotField.setFloat(a, var3);
      } catch (Exception var9) {
         var9.printStackTrace();
      }
   }

   public static void F(int[] var0) {
      何树树友何友何何树何 = var0;
   }

   public static float F(ServerboundMovePlayerPacket a, long a) {
      Field yRotField = 何何树树何何友友友树.n(129843684661419L, a.getClass(), Mapping.get(ServerboundMovePlayerPacket.class, "yRot", null));

      try {
         return yRotField.getFloat(a);
      } catch (Exception var8) {
         var8.printStackTrace();
         return 0.0F;
      }
   }

   public static void F(RenderTarget a, long depthBufferId, int var3) {
      depthBufferId = (int)(67130880896992L ^ depthBufferId);
      long ax = depthBufferId ^ 100367632882026L;
      Field depthBufferIdField = 何何树树何何友友友树.n(ax, a.getClass(), Mapping.get(a.getClass(), a<"s">(9899, 1679390430812305719L ^ depthBufferId), null));

      try {
         depthBufferIdField.setInt(a, -1);
      } catch (Exception var9) {
         var9.printStackTrace();
      }
   }

   public static int[] I() {
      return 何树树友何友何何树何;
   }

   public static int J(long a) {
      b<"p">(3823548288515068312L, 60828732437771L);
      if (mc == null) {
         return 0;
      } else {
         Field rightClickDelay_field = 何何树树何何友友友树.n(129843684661419L, mc.getClass(), Mapping.get(mc.getClass(), "rightClickDelay", null));

         try {
            return rightClickDelay_field.getInt(mc);
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0;
         }
      }
   }

   public static void S(Entity a, long entity, ParticleOptions a) {
      int[] ax = I();
      if (mc.level != null) {
         RandomSource random = mc.level.getRandom();
         int i = 0;

         while (i < 16) {
            double offsetX = (random.nextDouble() * 2.0 - 1.0) * a.getBbWidth() / 4.0;
            double offsetY = (random.nextDouble() * 2.0 - 1.0) * a.getBbHeight() / 4.0;
            double offsetZ = (random.nextDouble() * 2.0 - 1.0) * a.getBbWidth() / 4.0;
            if (ax == null) {
               if (offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ <= 1.0) {
                  double posX = a.getX() + offsetX;
                  double posY = a.getY() + a.getBbHeight() / 2.0F + offsetY;
                  double posZ = a.getZ() + offsetZ;
                  double speedY = offsetY + 0.2;
                  mc.level.addParticle(a, posX, posY, posZ, offsetX, speedY, offsetZ);
               }

               i++;
            }

            if (ax != null) {
               break;
            }
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 48;
               case 1 -> 26;
               case 2 -> 25;
               case 3 -> 31;
               case 4 -> 46;
               case 5 -> 61;
               case 6 -> 12;
               case 7 -> 11;
               case 8 -> 52;
               case 9 -> 23;
               case 10 -> 16;
               case 11 -> 44;
               case 12 -> 13;
               case 13 -> 14;
               case 14 -> 21;
               case 15 -> 38;
               case 16 -> 40;
               case 17 -> 3;
               case 18 -> 30;
               case 19 -> 8;
               case 20 -> 20;
               case 21 -> 24;
               case 22 -> 28;
               case 23 -> 56;
               case 24 -> 7;
               case 25 -> 5;
               case 26 -> 53;
               case 27 -> 43;
               case 28 -> 45;
               case 29 -> 9;
               case 30 -> 60;
               case 31 -> 58;
               case 32 -> 4;
               case 33 -> 59;
               case 34 -> 54;
               case 35 -> 39;
               case 36 -> 18;
               case 37 -> 17;
               case 38 -> 33;
               case 39 -> 19;
               case 40 -> 36;
               case 41 -> 15;
               case 42 -> 34;
               case 43 -> 50;
               case 44 -> 2;
               case 45 -> 47;
               case 46 -> 1;
               case 47 -> 22;
               case 48 -> 57;
               case 49 -> 42;
               case 50 -> 35;
               case 51 -> 32;
               case 52 -> 10;
               case 53 -> 37;
               case 54 -> 55;
               case 55 -> 29;
               case 56 -> 41;
               case 57 -> 27;
               case 58 -> 0;
               case 59 -> 51;
               case 60 -> 62;
               case 61 -> 49;
               case 62 -> 6;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static int e(Object[] var0) {
      return LocalPlayerTransformer.getOnGroundTicks();
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static void b(int a, long destroyDelay) {
      b<"p">(216171168228075112L, 54099280724731L);
      if (b<"î">(mc, 216092107255191113L, 54099280724731L) != null) {
         Field destroyDelay_field = 何何树树何何友友友树.n(
            129843684661419L,
            b<"î">(mc, 216092107255191113L, 54099280724731L).getClass(),
            Mapping.get(b<"î">(mc, 216092107255191113L, 54099280724731L).getClass(), "destroyDelay", null)
         );

         try {
            destroyDelay_field.setInt(b<"î">(mc, 216092107255191113L, 54099280724731L), 0);
         } catch (Exception var9) {
            var9.printStackTrace();
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 238 && var8 != 220 && var8 != 192 && var8 != 'A') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 164) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'p') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 238) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 220) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 192) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/wrapper/WrapperUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static float x(long a) {
      b<"p">(5590549162404292866L, 89524716981649L);
      if (mc.player == null) {
         return 0.0F;
      } else {
         Field yRotLast_field = 何何树树何何友友友树.n(129843684661419L, mc.player.getClass(), Mapping.get(mc.player.getClass(), "yRotLast", null));

         try {
            return yRotLast_field.getFloat(mc.player);
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0.0F;
         }
      }
   }

   public static int s(long a) {
      b<"p">(-9087537720168946315L, 100247336288742L);
      if (mc == null) {
         return 0;
      } else {
         Field fps_field = 何何树树何何友友友树.n(129843684661419L, mc.getClass(), Mapping.get(mc.getClass(), "fps", null));

         try {
            return fps_field.getInt(mc);
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0;
         }
      }
   }

   public static void s(int a) {
      ClientLevelTransformer.setSkipTicks((int)a);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public static Object c(ServerboundMovePlayerPacket a, String fieldName, long packet) {
      long ax = 67130880896992L ^ packet ^ 138406557320487L;
      Field field = 何何树树何何友友友树.n(ax, a.getClass(), Mapping.get(ServerboundMovePlayerPacket.class, fieldName, null));

      try {
         return field.get(a);
      } catch (Exception var9) {
         var9.printStackTrace();
         return null;
      }
   }

   public static float n(Object[] var0) {
      return TimerTransformer.getTimerSpeed();
   }

   public static void n(long a, int a) {
      b<"p">(-6027533251840390962L, 45949987695709L);
      if (mc != null) {
         Field rightClickDelay_field = 何何树树何何友友友树.n(129843684661419L, mc.getClass(), Mapping.get(mc.getClass(), "rightClickDelay", null));

         try {
            rightClickDelay_field.setInt(mc, (int)a);
         } catch (Exception var9) {
            var9.printStackTrace();
         }
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   public static void h(long a, float a) {
      b<"p">(1792415649379089480L, 69486456871131L);
      if (b<"î">(mc, 1792354178350910569L, 69486456871131L) != null) {
         Field destroyProgress_field = 何何树树何何友友友树.n(
            129843684661419L,
            b<"î">(mc, 1792354178350910569L, 69486456871131L).getClass(),
            Mapping.get(b<"î">(mc, 1792354178350910569L, 69486456871131L).getClass(), "destroyProgress", null)
         );

         try {
            destroyProgress_field.setFloat(b<"î">(mc, 1792354178350910569L, 69486456871131L), 1.0F);
         } catch (Exception var9) {
            var9.printStackTrace();
         }
      }
   }

   public static String f(long var0) {
      I();
      String var10000 = mc.player == null ? mc.getUser().getName() : mc.player.getName().getString();
      Module.V(new Module[2]);
      return var10000;
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void d(int a, long a) {
      Field missTimeField = 何何树树何何友友友树.n(129843684661419L, mc.getClass(), Mapping.get(mc.getClass(), "missTime", null));

      try {
         missTimeField.setInt(mc, 0);
      } catch (Exception var8) {
         var8.printStackTrace();
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24129;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/wrapper/WrapperUtils", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\b\fÏ;ÊaØ´r\u0091³¿E\u0083¥Û, Õ\u0081\u0093,ÁÕÊóÝ²\u0091(\u009b<ª\u001aá\u0000\t\u0095öGÓã%B±T\u0092\u008eT»Ò\u00ad\u0017\u009c'v Ú*6d\u0017ï©N\u0092ùËP{\u008f|)½, A\u0086Ñ\u0087ù¸È¶!Ëü\u0016\u0012'O")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   public static int a(long a) {
      a = 67130880896992L ^ a;
      long ax = a ^ 41186805199210L;
      b<"p">(-1601701632900035246L, (long)a);
      if (mc.player == null) {
         return 0;
      } else {
         Field positionReminder_field = 何何树树何何友友友树.n(ax, mc.player.getClass(), Mapping.get(mc.player.getClass(), a<"s">(18880, 239906262971285071L ^ a), null));

         try {
            return positionReminder_field.getInt(mc.player);
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0;
         }
      }
   }

   public static void a(long a, float var2) {
      b<"p">(-206665197140797002L, 9495711317285L);
      if (mc.player != null) {
         Field yRotLast_field = 何何树树何何友友友树.n(129843684661419L, mc.player.getClass(), Mapping.get(mc.player.getClass(), "yRotLast", null));

         try {
            yRotLast_field.setFloat(mc.player, var2);
         } catch (Exception var9) {
            var9.printStackTrace();
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/wrapper/WrapperUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void a() {
      f[0] = "1#G\bl1>c\n\u0003f,;>\u0001Ev*;!\u001aEt,3=\u0019\u000eqp\u0005?\b\u001bs; \u0018\u001d\u0002o-";
      f[1] = "\u0018[POku\u0013TA\u0000\u0000a\u0011_VZ,v\u001c";
      f[2] = "~%";
      f[3] = "2y`&L\u00179vqi$\u00177yb";
      f[4] = "(MR@\u000e\u001c#BC\u000fc\u001c#_W";
      f[5] = "jHf'\u001dPe\b+,\u0017M`U j\u001fPmS$!\\rfB=(\u0017";
      f[6] = "{]zV)sO~u\u0016dxEcpKo>M~}Mku\u000e\\v\\r|E*";
      f[7] = "BI\u001c\t{Bvj\u0013I6I|w\u0016\u0014=\u000ftj\u001b\u00129D7H\u0010\u0003 M|>";
      f[8] = void.class;
      g[8] = "java/lang/Void";
      f[9] = "D|\r]7]D|\u001a\u0001;R^7\u001a\u001f3QDmW>3ZOz\u000b\u0012<@";
      f[10] = "&4j11,&4}m=#<\u007f}s5 &%0r))<8ns=<-#0R))<8Ns=<-#Y~1 \u0005>zz";
      f[11] = ";\u0000M.M\u00020\u000f\\a*\u0000%\u0004\\*\u0011";
      f[12] = "q\u001f";
      f[13] = "gd(@\u007fmlk9\u000f\u001ecg`=U";
      f[14] = "5U\\v\u001e>0\u001f\u0000u\"U\u000e\u0018\u0004(M\u007f2^\u001a.\u001a\u0007";
      f[15] = "O\u00197`l7_\u0001/\u0005|R\u0018\u0019<4niY\u001ck8\u0015kK\u0018f~.*NOj\u0005";
      f[16] = "M5J\b\u0019W]-Rm.2\u0013 CP\u0000\u0002B$U\u001d`\u000f]d\u0014\f\t^_.\u001am";
      f[17] = "@\u0016\u0010Lc\u0017E\\LO_p{[H\u00120VG\u001dV\u0014g.F\u0018\u0011\u0016>G\u0017\u001a[\u0018_";
      f[18] = "\u0001\u0017\u0013\"\u0001\u001cY\u0006P*f\u0011hGRqYEhvT*[\u0006\u0006\u0007\u00141\b\u0006";
      f[19] = "1~l\u0000X\u001e!fte`{okeXAK>os\u0015!";
      f[20] = "\u0003\u0017\u0012\u000ex\u001c_S\tDA'bq8>zB\u000fK\u0012X?\u0007V\u0014";
      f[21] = "\u000b8\\]lXP \\M\u0015<`\t =.Y\r3\n[k\u001cTl";
   }

   public static void o(MultiPlayerGameMode a, long a) {
      a = 67130880896992L ^ a;

      try {
         Mapping.get(a.getClass(), a<"s">(3964, 8916399756751040629L ^ a), a<"s">(18591, 4990021560538380223L ^ a));
      } catch (Exception var6) {
         var6.printStackTrace();
      }
   }

   public static float o(long a) {
      b<"p">(-7799176075038492844L, 14387034821575L);
      if (mc.player == null) {
         return 0.0F;
      } else {
         Field xRotLast_field = 何何树树何何友友友树.n(129843684661419L, mc.player.getClass(), Mapping.get(mc.player.getClass(), "xRotLast", null));

         try {
            return xRotLast_field.getFloat(mc.player);
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0.0F;
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static double v(long a) {
      a = 67130880896992L ^ a;
      long ax = a ^ 74085779417385L;
      b<"p">(-1042870504733502191L, (long)a);
      if (mc.player == null) {
         return 0.0;
      } else {
         Field yLast_field = 何何树树何何友友友树.n(ax, mc.player.getClass(), Mapping.get(mc.player.getClass(), a<"s">(21067, 2261236999279050139L ^ a), null));

         try {
            return yLast_field.getDouble(mc.player);
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0.0;
         }
      }
   }

   public static boolean z(long a, ServerboundInteractPacket a) {
      a = 67130880896992L ^ a;

      try {
         Mapping.get(ServerboundInteractPacket.class, a<"s">(27324, 8438262014980917848L ^ a), null);
         return false;
      } catch (SecurityException | NoSuchFieldException var9) {
         var9.printStackTrace();
         return false;
      }
   }

   public static int w(long a, ServerboundInteractPacket var2) {
      return 0;
   }

   public static int A(long a) {
      a = 67130880896992L ^ a;
      long ax = a ^ 8981972778835L;
      b<"p">(-6341998981505367189L, (long)a);
      if (mc == null) {
         return 0;
      } else {
         Field missTimeField = 何何树树何何友友友树.n(ax, mc.getClass(), Mapping.get(mc.getClass(), a<"s">(12759, 5044227198985422948L ^ a), null));

         try {
            return missTimeField.getInt(mc);
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0;
         }
      }
   }

   public static boolean Y(long a, ServerboundInteractPacket a) {
      try {
         Mapping.get(ServerboundInteractPacket.class, "action", null);
         return false;
      } catch (IllegalAccessException | NoSuchFieldException var11) {
         var11.printStackTrace();
         return false;
      }
   }

   public static void L(ServerboundMovePlayerPacket a, float packet, long a) {
      Field xRotField = 何何树树何何友友友树.n(129843684661419L, a.getClass(), Mapping.get(ServerboundMovePlayerPacket.class, "xRot", null));

      try {
         xRotField.setFloat(a, (float)packet);
      } catch (Exception var9) {
         var9.printStackTrace();
      }
   }

   public static void M(float a) {
      TimerTransformer.setTimerSpeed((float)a);
   }

   public static float M(long a) {
      b<"p">(-8346965307847939906L, 89047921167405L);
      if (b<"î">(mc, -8346903564652996449L, 89047921167405L) == null) {
         return 0.0F;
      } else {
         Field destroyProgress_field = 何何树树何何友友友树.n(
            129843684661419L,
            b<"î">(mc, -8346903564652996449L, 89047921167405L).getClass(),
            Mapping.get(b<"î">(mc, -8346903564652996449L, 89047921167405L).getClass(), "destroyProgress", null)
         );

         try {
            return destroyProgress_field.getFloat(b<"î">(mc, -8346903564652996449L, 89047921167405L));
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0.0F;
         }
      }
   }

   public static int N(Object[] var0) {
      return ClientLevelTransformer.getSkipTicks();
   }

   public static double N(long a) {
      a = 67130880896992L ^ a;
      long ax = a ^ 23938529786423L;
      b<"p">(2492931964170946063L, (long)a);
      if (mc.player == null) {
         return 0.0;
      } else {
         Field xLast_field = 何何树树何何友友友树.n(ax, mc.player.getClass(), Mapping.get(mc.player.getClass(), a<"s">(14054, 8811814451200150051L ^ a), null));

         try {
            return xLast_field.getDouble(mc.player);
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0.0;
         }
      }
   }

   public static TransientEntitySectionManager P(long a) {
      b<"p">(-7389299053813105180L, 35265487149431L);
      if (mc.level == null) {
         return null;
      } else {
         Field entityStorage_field = 何何树树何何友友友树.n(129843684661419L, mc.level.getClass(), Mapping.get(mc.level.getClass(), "entityStorage", null));

         try {
            return (TransientEntitySectionManager)entityStorage_field.get(mc.level);
         } catch (Exception var8) {
            var8.printStackTrace();
            return null;
         }
      }
   }

   public static void W(float a, long xRot) {
      b<"p">(7130284952888084068L, 21821667042039L);
      if (mc.player != null) {
         Field xRotLast_field = 何何树树何何友友友树.n(129843684661419L, mc.player.getClass(), Mapping.get(mc.player.getClass(), "xRotLast", null));

         try {
            xRotLast_field.setFloat(mc.player, 90.0F);
         } catch (Exception var9) {
            var9.printStackTrace();
         }
      }
   }

   public static int T(Object[] var0) {
      return LocalPlayerTransformer.getOffGroundTicks();
   }

   public static double T(long a) {
      a = 67130880896992L ^ a;
      long ax = a ^ 105756459087947L;
      b<"p">(6981944479164728435L, (long)a);
      if (mc.player == null) {
         return 0.0;
      } else {
         Field zLast_field = 何何树树何何友友友树.n(ax, mc.player.getClass(), Mapping.get(mc.player.getClass(), a<"s">(22509, 117444335280679240L ^ a), null));

         try {
            return zLast_field.getDouble(mc.player);
         } catch (Exception var8) {
            var8.printStackTrace();
            return 0.0;
         }
      }
   }

   public static void K(long a, ServerboundInteractPacket a, boolean var3) {
   }

   private static String HE_SHU_YOU() {
      return "行走的50万——何炜霖";
   }

   public static boolean G(long a) {
      b<"p">(-7523568969238908159L, 42166208403346L);
      if (mc.player == null) {
         return false;
      } else {
         Field wasSneaking_field = 何何树树何何友友友树.n(129843684661419L, mc.player.getClass(), Mapping.get(mc.player.getClass(), "crouching", null));

         try {
            return wasSneaking_field.getBoolean(mc.player);
         } catch (Exception var8) {
            var8.printStackTrace();
            return false;
         }
      }
   }

   public static void G(int a, long a) {
      b<"p">(8539831698553704980L, 101244549559943L);
      if (mc.player != null) {
         Field positionReminder_field = 何何树树何何友友友树.n(129843684661419L, mc.player.getClass(), Mapping.get(mc.player.getClass(), "positionReminder", null));

         try {
            positionReminder_field.setInt(mc.player, 20);
         } catch (Exception var9) {
            var9.printStackTrace();
         }
      }
   }

   public static void O(int a, Entity fakePlayer, long a) {
      a = 67130880896992L ^ a;
      b<"p">(6844323081119742572L, a);
      if (mc.level != null) {
         try {
            Mapping.get(mc.level.getClass(), a<"s">(12093, 3303598981671169945L ^ a), a<"s">(13449, 1214441252106613793L ^ a));
         } catch (Exception var8) {
            var8.printStackTrace();
         }
      }
   }

   public static boolean O(ServerboundInteractPacket a, long a) {
      a = 67130880896992L ^ a;

      try {
         Mapping.get(ServerboundInteractPacket.class, a<"s">(2930, 5540163779236974473L ^ a), null);
         return false;
      } catch (SecurityException | NoSuchFieldException var9) {
         var9.printStackTrace();
         return false;
      }
   }

   public static Container O(long a, BrewingStandMenu var2) {
      b<"p">(9177962172225952713L, 110278536822618L);
      if (var2 == null) {
         return null;
      } else {
         Field brewingStand_field = 何何树树何何友友友树.n(129843684661419L, var2.getClass(), Mapping.get(var2.getClass(), "brewingStand", null));

         try {
            return (Container)brewingStand_field.get(var2);
         } catch (Exception var9) {
            var9.printStackTrace();
            return null;
         }
      }
   }

   public static Vec3 getCalculateViewVector(Entity entity, float pitch, float yaw) {
      try {
         Mapping.get(Entity.class, "calculateViewVector", "(FF)Lnet/minecraft/world/phys/Vec3;");
         return null;
      } catch (Exception var8) {
         var8.printStackTrace();
         return null;
      }
   }
}
