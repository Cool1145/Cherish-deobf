package cn.cool.cherish.utils;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.world.phys.Vec3;

public class 友树友何友何友树何友 implements IWrapper, 何树友 {
   private double 树树何友友何树友友友;
   private double 何友树树树树友树友树;
   private double 何何何友树友友友友何;
   public 友树友树树何树何树何 友友何友树友友友友何;
   private static boolean 何何何何树树何树树友;
   private static final long a;
   private static final Object[] b = new Object[12];
   private static final String[] c = new String[12];
   private static String HE_WEI_LIN;

   public 友树友何友何友树何友(long a, double var1, double var3, double var5) {
      long ax = 38732491783206L ^ a ^ 76986315700485L;
      super();
      this.n(var1, var3, ax, var5);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6814721088963383984L, 5690539397033970832L, MethodHandles.lookup().lookupClass()).a(22442990683654L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (d()) {
         A(true);
      }
   }

   public double J(long a) {
      a = 38732491783206L ^ a;
      return a<"N">(this, -99213932989886085L, (long)a);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 44;
               case 2 -> 31;
               case 3 -> 57;
               case 4 -> 16;
               case 5 -> 62;
               case 6 -> 51;
               case 7 -> 7;
               case 8 -> 52;
               case 9 -> 56;
               case 10 -> 37;
               case 11 -> 42;
               case 12 -> 54;
               case 13 -> 33;
               case 14 -> 58;
               case 15 -> 46;
               case 16 -> 49;
               case 17 -> 18;
               case 18 -> 48;
               case 19 -> 3;
               case 20 -> 24;
               case 21 -> 35;
               case 22 -> 28;
               case 23 -> 26;
               case 24 -> 36;
               case 25 -> 43;
               case 26 -> 15;
               case 27 -> 21;
               case 28 -> 34;
               case 29 -> 11;
               case 30 -> 14;
               case 31 -> 5;
               case 32 -> 60;
               case 33 -> 41;
               case 34 -> 23;
               case 35 -> 40;
               case 36 -> 6;
               case 37 -> 13;
               case 38 -> 61;
               case 39 -> 19;
               case 40 -> 0;
               case 41 -> 27;
               case 42 -> 25;
               case 43 -> 9;
               case 44 -> 2;
               case 45 -> 20;
               case 46 -> 8;
               case 47 -> 47;
               case 48 -> 29;
               case 49 -> 45;
               case 50 -> 4;
               case 51 -> 38;
               case 52 -> 53;
               case 53 -> 59;
               case 54 -> 55;
               case 55 -> 32;
               case 56 -> 17;
               case 57 -> 1;
               case 58 -> 22;
               case 59 -> 30;
               case 60 -> 39;
               case 61 -> 10;
               case 62 -> 12;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'N' && var8 != 199 && var8 != 205 && var8 != 220) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 230) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 218) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'N') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 199) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 205) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public double s(long a) {
      a = 38732491783206L ^ a;
      return a<"N">(this, -4604114439056296863L, (long)a);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public void n(double a, double var3, long var5, double var7) {
      var5 = 38732491783206L ^ var5;
      a<"Ç">(this, (double)a, -7637040086080609672L, var5);
      a<"Ç">(this, var3, -7637840768666289692L, var5);
      a<"Ç">(this, var7, -7637222316069382061L, var5);
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static boolean d() {
      N();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      b[0] = "!x<0>R.8q;4O+ez}$I+za}厚栬厉佃叙伆厚栬众叝";
      b[1] = double.class;
      c[1] = "java/lang/Double";
      b[2] = "#IT]4!,\t\u0019V><)T\u0012\u0010.:)K\t\u0010厐桟压栶桫佫桊伛桑佲";
      b[3] = boolean.class;
      c[3] = "java/lang/Boolean";
      b[4] = void.class;
      c[4] = "java/lang/Void";
      b[5] = "\u0017\n\n'\u001d}\u001c\u0005\u001bh|s\u0017\u000e\u001f2";
      b[6] = "kI\u0007Y\u0004QtO\u00199佣号栓栿桮栠叽栭叉栿wFR\u000fzAKA[\u0004";
      b[7] = "&\u0013E;\u0001D9\u0015[[r!}\u0006W6@\u001f%\u0005^8;\u001b5\fMe\u0004\u0019-\u0002V[";
      b[8] = "\u00019h3\u0016$\u001e?vS可厂伽厕栁厐可厂厣伋\u0018jT=\rfb1^?\u0004";
      b[9] = ">\u0000WqKB!\u0006I\u0011伬佺伂厬栾叒厲古厜伲'n\u001d\u001c/\b\u001bi\u0014\u0017";
      b[10] = "jH\tg\u000b'uN\u0017\u0007栨桛佖古厺佚栨厁又古yx]y{@E\u007fTr";
      b[11] = "wu\u001eg:=hs\u0000\u0007lX,`\fj{ftc\u0005d\u0000";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友树友何友何友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public void o(long a, float a) {
      a = 38732491783206L ^ a;
      a<"Ç">(this, a, -9002204586196125846L, (long)a);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void r(long a, float a) {
      a = 38732491783206L ^ a;
      a<"Ç">(this, a, -9166432606388711782L, (long)a);
   }

   public static void A(boolean var0) {
      何何何何树树何树树友 = var0;
   }

   public static boolean N() {
      return 何何何何树树何树树友;
   }

   public void N(long a, float a) {
      a = 38732491783206L ^ a;
      a<"Ç">(this, a, 3274632629492941461L, (long)a);
   }

   public double W(long a) {
      a = 38732491783206L ^ a;
      return a<"N">(this, -8023139070005960968L, (long)a);
   }

   private static String HE_WEI_LIN() {
      return "何大伟为什么要诈骗何炜霖";
   }

   public Vec3 Q(long a) {
      return new Vec3(this.树树何友友何树友友友, this.何友树树树树友树友树, this.何何何友树友友友友何);
   }

   public 友树友树树何树何树何 Q(long a) {
      a = 38732491783206L ^ a;
      return a<"N">(this, 7477754003882708159L, (long)a);
   }
}
