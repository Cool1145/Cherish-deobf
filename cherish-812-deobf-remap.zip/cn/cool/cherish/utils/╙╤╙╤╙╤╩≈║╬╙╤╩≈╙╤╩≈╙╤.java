package cn.cool.cherish.utils;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.helper.何何何树友树树友树友;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class 友友友树何友树友树友 implements 何树友 {
   public static final Random 友树友何何树树友友树;
   private static String 树何树何树何树何友树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[38];
   private static final String[] f = new String[38];
   private static String LIU_YA_FENG;

   private 友友友树何友树友树友(long a) {
      a = 136249166073774L ^ a;
      super();
      throw new UnsupportedOperationException(a<"h">(26277, 427981355936800067L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-525426727532788229L, -6275322507627125278L, MethodHandles.lookup().lookupClass()).a(97358963383378L);
      // $VF: monitorexit
      a = var10000;
      a();
      b("HE0qU");
      Cipher var0;
      Cipher var9 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(22040618364654L << var1 * 8 >>> 56);
      }

      var9.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[2];
      int var5 = 0;
      char var3 = '`';
      int var2 = -1;

      while (true) {
         String var11 = a(
               var0.doFinal(
                  "\u0086ó\u0098ÂLÍkã£Û:®\u00170z\u008bÎ-JïÆ\u008c¦°ÙõGa\u008b¶+^Ãºa\u0089\u0010uCùA\u0012¶õ`;\u009fRáø¬Zý¨\\>hMÐ\fËÄãÅÕíÁ~\u0091·¶Iù¨b{óÊ BÔG\u0094\u001c\u008a9\u001f\u007f\u0003±p\u0088{\u00820\u0087\u0018?·@Í8\u0081\u0005Ô\u008cU>(1¶r¬Íù©÷;a\u0015i"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var11;
         if ((var2 += var3) >= 121) {
            b = var7;
            c = new String[2];
            友树友何何树树友友树 = new Random();
            return;
         }

         var3 = "\u0086ó\u0098ÂLÍkã£Û:®\u00170z\u008bÎ-JïÆ\u008c¦°ÙõGa\u008b¶+^Ãºa\u0089\u0010uCùA\u0012¶õ`;\u009fRáø¬Zý¨\\>hMÐ\fËÄãÅÕíÁ~\u0091·¶Iù¨b{óÊ BÔG\u0094\u001c\u008a9\u001f\u007f\u0003±p\u0088{\u00820\u0087\u0018?·@Í8\u0081\u0005Ô\u008cU>(1¶r¬Íù©÷;a\u0015i"
            .charAt(var2);
      }
   }

   public static double B(long a, double var2, double var4) {
      a = 136249166073774L ^ a;
      b<"Ñ">(-2059496226271027899L, (long)a);
      return var2 >= var4 ? var2 : b<"É">(-2060625550486699178L, (long)a).nextDouble() * (var4 - var2) + var2;
   }

   public static int B(long a, int max, int a) {
      return 友树友何何树树友友树.nextInt((int)(a - 0)) + max;
   }

   public static float B(float a, float min, float delta) {
      return -40.0F + (-40.0F - a) * delta;
   }

   public static float S(int a, int a, int a, float a) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:258)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: invokestatic cn/cool/cherish/utils/友友友树何友树友树友.p ()Ljava/lang/String;
      // 03: pop
      // 04: fload 3
      // 05: ldc 90.0
      // 07: fcmpl
      // 08: ifle 0e
      // 0b: ldc 90.0
      // 0d: freturn
      // 0e: fload 3
      // 0f: ldc -90.0
      // 11: fcmpg
      // 12: ifge 18
      // 15: ldc -90.0
      // 17: freturn
      // 18: fload 3
      // 19: freturn
   }

   public static double S(long a, double var2, double var4) {
      p();
      SecureRandom random = new SecureRandom();
      return var2 == var4 ? var2 : random.nextDouble() * (var4 - var2) + var2;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友友友树何友树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void b(String var0) {
      树何树何树何树何友树 = var0;
   }

   public static int x(long a, int var2, int n1) {
      p();
      if (var2 == n1) {
         return var2;
      } else {
         int max = Math.max(var2, n1);
         int min = Math.min(var2, n1);
         return B(65778681928188L, min, max);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static Vec3 n(AABB a, Direction x, double var2, double var4, double var6, long var8) {
      var8 = 136249166073774L ^ var8;
      b<"Ñ">(-2510398852706688249L, var8);
      Math.max(b<"J">(a, -2509987003813756710L, var8), Math.min(var2, b<"J">(a, -2511834330399859223L, var8)));
      Math.max(b<"J">(a, -2509888116521067855L, var8), Math.min(var4, b<"J">(a, -2510420652707398918L, var8)));
      Math.max(b<"J">(a, -2509643557190171722L, var8), Math.min(var6, b<"J">(a, -2510119872854232883L, var8)));
      switch (b<"É">(-2510139281737881187L, var8)[x.ordinal()]) {
         case 1:
         case 2:
            if (x == b<"É">(-2511541207519647446L, var8)) {
               b<"J">(a, -2509888116521067855L, var8);
            } else {
               b<"J">(a, -2510420652707398918L, var8);
            }

            if (var8 > 0L) {
               b<"Ñ">(new Module[3], -2509914035546665514L, var8);
            }
         case 3:
         case 4:
            if (x == b<"É">(-2510569916482375776L, var8)) {
               b<"J">(a, -2509643557190171722L, var8);
            } else {
               b<"J">(a, -2510119872854232883L, var8);
            }

            if (var8 > 0L) {
            }
         case 5:
         case 6:
            if (x == b<"É">(-2509788225345229818L, var8)) {
               b<"J">(a, -2509987003813756710L, var8);
            } else {
               b<"J">(a, -2511834330399859223L, var8);
            }
         default:
            throw new IllegalArgumentException(a<"h">(13876, 8731487536431843335L ^ var8) + x);
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 14;
               case 1 -> 62;
               case 2 -> 42;
               case 3 -> 17;
               case 4 -> 2;
               case 5 -> 60;
               case 6 -> 29;
               case 7 -> 18;
               case 8 -> 56;
               case 9 -> 8;
               case 10 -> 41;
               case 11 -> 34;
               case 12 -> 27;
               case 13 -> 44;
               case 14 -> 49;
               case 15 -> 22;
               case 16 -> 61;
               case 17 -> 15;
               case 18 -> 39;
               case 19 -> 25;
               case 20 -> 9;
               case 21 -> 26;
               case 22 -> 16;
               case 23 -> 45;
               case 24 -> 10;
               case 25 -> 6;
               case 26 -> 4;
               case 27 -> 12;
               case 28 -> 33;
               case 29 -> 53;
               case 30 -> 11;
               case 31 -> 50;
               case 32 -> 47;
               case 33 -> 63;
               case 34 -> 5;
               case 35 -> 37;
               case 36 -> 58;
               case 37 -> 3;
               case 38 -> 40;
               case 39 -> 38;
               case 40 -> 23;
               case 41 -> 59;
               case 42 -> 52;
               case 43 -> 57;
               case 44 -> 0;
               case 45 -> 7;
               case 46 -> 46;
               case 47 -> 20;
               case 48 -> 13;
               case 49 -> 31;
               case 50 -> 21;
               case 51 -> 1;
               case 52 -> 36;
               case 53 -> 28;
               case 54 -> 51;
               case 55 -> 43;
               case 56 -> 35;
               case 57 -> 48;
               case 58 -> 54;
               case 59 -> 32;
               case 60 -> 24;
               case 61 -> 19;
               case 62 -> 55;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友友友树何友树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'J' && var8 != 'x' && var8 != 201 && var8 != 'N') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 162) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 209) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'J') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'x') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 201) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8991;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/友友友树何友树友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static void a() {
      e[0] = "nFw)\u0019&a\u0006:\"\u0013;d[1d\u0003=dD*d厽厂叆根伌厁桧厂栜口";
      e[1] = "PF2\u0010pO[I#_\rWHN*\u0016";
      e[2] = "I\u0012a/\u0014$B\u001dp`s$O\u0016p/V\tQ\u0014b#_&W6o-_8W\u001ax ";
      e[3] = "\u0018\u0003}`h\u0007\u0018\u0003j<d\b\u0002H~!w\u0002\u0012Hy&|\u001dX'H\fG";
      e[4] = double.class;
      f[4] = "java/lang/Double";
      e[5] = "\u0011L/\n:6\u0011L8V69\u000b\u00078K%:Qm2V2<\u000b@4J";
      e[6] = "|\u0000\u0013}\u0015/s@^v\u001f2v\u001dU0\u0017/{\u001bQ{T\rp\nHr\u001f";
      e[7] = "I\u00033$Sa} <d\u001ejw=99\u0015,\u007f 4?\u0011g<\u0002?.\bnwt";
      e[8] = "\\\f\u001d\u0018$\u0017SLP\u0013.\nV\u0011[U>\fV\u000e@U厀厳叴桳佦厰桚厳栮厩\u0017厰桚厳栮厩佦厰厀伭佪";
      e[9] = "s\b";
      e[10] = "\u0011\u0012\f@cv%1\u0003\u0000.}/,\u0006]%;'1\u000b[!pd\u0013\u0000J8y/e";
      e[11] = void.class;
      f[11] = "java/lang/Void";
      e[12] = "4U`T)~4Uw\b%q.\u001ec\u00156{>\u001ed\u0012=dtfq\u0019w";
      e[13] = "v4px\u0014zyt=s\u001eg|)65\u000ea|6-5\u0013py*;iU佀佀伏桏叐桪栄叞桋厕";
      e[14] = "\u0013G'0\fN\rO=\u007fpZ\u0017B><";
      e[15] = "$@UX\f\u001a/OD\u0017m\u0014$D@M";
      e[16] = "8\u0011\u0007\\[Np\u0019\u000fA<ZUB\r\u0016\r\u000eUr\fB\u0000I<\u0015LF_M";
      e[17] = "v(I\u001b\u0004#r}Yv\u001d\u0013\"(J\u0015Xm|9FFe";
      e[18] = "!P\u000f7\u0018\bl@P!b\u001cF\u001eZl]CF.[>^\u000f/I\u001b:\u0001\u000b";
      e[19] = "-)!\"\\\u001c#m}8g桸叟栍桙厂伺厢叟受厃A\\\u000f i~&\u001c\u000b\u007fm";
      e[20] = "arrw'\u001eo6.m\u001c伾桉伒低栍佁厠伍伒低\u0014'\rl2-sg\t36";
      e[21] = "9\u0013bs[y=Fr\u001eSIm\u0007`qW)d\u0007}e:p)\u0018msZy)\u0005y\u001e";
      e[22] = "J'A{Pa\u001e0\u000by9\u00176\u0004,W9j\bo\u001c~\t>\u001f%\u001e";
      e[23] = "*[(vm\u001egKw`\u0017\nM\u0015}-']M%|\u007f+\u0019$B<{t\u001d";
      e[24] = "$&4m<\u0012l.<p[\u0006Iu>'kYIE?sg\u0015 \"\u007fw8\u0011";
      e[25] = "^:No 2\n-\u0004mI](\u0018#\u0003r{T/\u00163&l\u001e-";
      e[26] = "qjl\u0016\u0016/(j%K-LMe-XQ\"#d.HN\u001e";
      e[27] = ";'MhEzs/Eu\"nVtG\"\u00138VDFv\u001e}?#\u0006rAy";
      e[28] = "0\u000bH\u0002x\"b\u0007\u0003ZF栄佐桯厲伶厅佀栔厵伬kxb\u007f\u0019IS<w2\u0019";
      e[29] = "\f'C3qQD/K.\u0016EatIy'\u0010aDH-*V\b#\b)uR";
      e[30] = "N\u001e|uH\u0011\u0006\u0016th/\u0005#Mv?\u001f[#}wk\u0013\u0016J\u001a7oL\u0012";
      e[31] = "\n\u000e\u0007M0dS\u000eN\u0010\u000b\u000b6\u0001F\u0003wiX\u0000E\u0013hU\u0006V\r\u00176/X]U\u0006\u000b";
      e[32] = "&p\u0013C]crgYA4\u001fZVd/\u000f*,eK\u001f[=fg";
      e[33] = "K\u0005\u000f\u0000Y\u0011OP\u001fm叻核句伱伲桴校叢句桵o\u0004\u0000@LS\u001dPG]J";
      e[34] = "L19\u001e\u001bqHd)s\u0010A\u00181:\u0010G?F 6CzqHb2N\u0000/C:#s";
      e[35] = "R>U\u001e\u0007I\u001f.\n\b}]5p\u0000EM\u000b5@\u0001\u0017AN\\'A\u0013\u001eJ";
      e[36] = "qo@,7i9gH1P}\u001c<Jfa*\u001c\fK2lnuk\u000b63j";
      e[37] = "7S\u000eP\u0014#9\u0017RJ/桇叅伳伲株召桇叅厭厬3\u00140:\u0013QTT4e\u0017";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static IllegalArgumentException a(IllegalArgumentException var0) {
      return var0;
   }

   public static float o(float a, float a, float var2, long max) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: invokestatic cn/cool/cherish/utils/友友友树何友树友树友.p ()Ljava/lang/String;
      // 03: pop
      // 04: fload 0
      // 05: fload 1
      // 06: fcmpg
      // 07: ifge 0e
      // 0a: fload 1
      // 0b: goto 13
      // 0e: fload 0
      // 0f: fload 2
      // 10: invokestatic java/lang/Math.min (FF)F
      // 13: freturn
   }

   public static String p() {
      return 树何树何树何树何友树;
   }

   public static float q(long a, float endInclusive, float a) {
      a = 136249166073774L ^ a;
      b<"Ñ">(4252812170067854635L, (long)a);
      if (endInclusive != a) {
         float var10000 = a - endInclusive;
         if (a > 0L) {
            if (var10000 <= 0.0F) {
               return endInclusive;
            }

            var10000 = endInclusive;
         }

         return (float)(var10000 + (a - endInclusive) * Math.random());
      } else {
         return endInclusive;
      }
   }

   public static boolean U(float a, float b, long a) {
      a = 136249166073774L ^ a;
      b<"Ñ">(4286333928716518738L, a);
      return Math.abs(a - b) < 1.0E-4;
   }

   public static float E(float a, float a) {
      return ((a - a) % 360.0F + 540.0F) % 360.0F - 180.0F;
   }

   public static int L(int a, int num, long a, int max) {
      a = 136249166073774L ^ a;
      b<"Ñ">(7806261998628967035L, a);
      return a < 0 ? num : Math.min((int)a, 255);
   }

   public static float N(int a, int a, int angle, float a) {
      p();
      a %= 360.0F;
      if (a >= 180.0F) {
         a -= 360.0F;
      }

      if (a < -180.0F) {
         a += 360.0F;
      }

      if (Module.Z() == null) {
         b("nXkdc");
      }

      return (float)a;
   }

   public static double W(double a, long var2, double var4) {
      return a + (var4 - a) * 友树友何何树树友友树.nextDouble();
   }

   public static Vec3 Q(long a, 何何何树友树树友树友 var2) {
      a = 136249166073774L ^ a;
      return new Vec3(b<"J">(var2, 592856369688413772L, (long)a), b<"J">(var2, 591783720279465445L, (long)a), b<"J">(var2, 593300971367477333L, (long)a));
   }

   private static String LIU_YA_FENG() {
      return "何炜霖国企变私企";
   }

   public static boolean G(long a, float a, float var3) {
      a = 136249166073774L ^ a;
      b<"Ñ">(144118549259844654L, (long)a);
      return Math.abs(var3 - a) < 1.0E-5F;
   }

   public static Vec3 O(AABB a, Direction face, Vec3 aabb, long vec) {
      vec = 136249166073774L ^ vec;
      long ax = vec ^ 70566797024643L;
      return n(
         a,
         face,
         b<"J">(aabb, 5693869036787513853L, (long)vec),
         b<"J">(aabb, 5695033029025569521L, (long)vec),
         b<"J">(aabb, 5694193488288551052L, (long)vec),
         ax
      );
   }
}
