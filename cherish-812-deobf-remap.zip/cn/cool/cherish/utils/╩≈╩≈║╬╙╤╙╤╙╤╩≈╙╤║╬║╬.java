package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Vector3i;

public enum 树树何友友友树友何何 implements  {
   友友树树何树何树友友,
   树友何友何友友树何友,
   友树友友何树友树树树,
   何何友友树友树友友树,
   友友树何树何友何树友,
   友友友友何树树树何树,
   友友何友友何友友何友,
   何树树树树何何何树友;

   public final Vector3i 友何友树何树树树友树;
   private static final long a;
   private static final Object[] b = new Object[12];
   private static final String[] c = new String[12];
   private static int _何炜霖大狗叫 _;

   private 树树何友友友树友何何(Vector3i var3) {
      this.友何友树何树树树友树 = var3;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // $VF: Failed to inline enum fields
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6392917111483686983L, 1701345715387585226L, MethodHandles.lookup().lookupClass()).a(209384959436273L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 91415981965553L;
      long var11 = var9 ^ 1511160806339L;
      a();
      Cipher var1;
      Cipher var15 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var0 = new String[8];
      int var6 = 0;
      String var5 = "ÖXz\\\u0012=<u\u0010©â0\u001d%ì\u008e\u009bï¼b!=Ý-F\bw\u009fA)\u001cùÞC\bª\u009a\u0003\u001aSo\u0093Ø\b¹\u0080°ò^óØ-\bmJ\u000bJE¸\u000bð";
      byte var7 = 61;
      char var4 = '\b';
      int var14 = -1;

      label28:
      while (true) {
         String var16 = var5.substring(++var14, var14 + var4);
         byte var10001 = -1;

         while (true) {
            String var22 = a(var1.doFinal(var16.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var0[var6++] = var22;
                  if ((var14 += var4) >= var7) {
                     友友树树何树何树友友 = new 树树何友友友树友何何(null);
                     树友何友何友友树何友 = new 树树何友友友树友何何(new Vector3i(-1, 0, 0));
                     友树友友何树友树树树 = new 树树何友友友树友何何(new Vector3i(1, 0, 0));
                     何何友友树友树友友树 = new 树树何友友友树友何何(new Vector3i(0, 0, -1));
                     友友树何树何友何树友 = new 树树何友友友树友何何(new Vector3i(0, 0, 1));
                     友友友友何树树树何树 = new 树树何友友友树友何何(new Vector3i(0, 0, 0));
                     友友何友友何友友何友 = new 树树何友友友树友何何(new Vector3i(0, 1, 0));
                     何树树树树何何何树友 = new 树树何友友友树友何何(new Vector3i(0, -1, 0));
                     return;
                  }

                  var4 = var5.charAt(var14);
                  break;
               default:
                  var0[var6++] = var22;
                  if ((var14 += var4) < var7) {
                     var4 = var5.charAt(var14);
                     continue label28;
                  }

                  var5 = "Á6lll/n£\bÜ`¢©î\u0007\u0085=";
                  var7 = 17;
                  var4 = '\b';
                  var14 = -1;
            }

            var16 = var5.substring(++var14, var14 + var4);
            var10001 = 0;
         }
      }
   }

   public static List S(long var0) {
      long var3 = a ^ var0 ^ 39809253578152L;
      return new 友友树树何何友树何友(var3);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static 树树何友友友树友何何[] l(long var0) {
      var0 = a ^ var0;
      return (树树何友友友树友何何[])a<"ß">(3473856663971075238L, var0).clone();
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'P' && var8 != 246 && var8 != 223 && var8 != 195) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'l') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 212) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'P') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 246) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/树树何友友友树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "t9I;mM{y\u00040gP~$\u000fvwV~;\u0014v栓栳佂厜厬厓栓叩佂伂";
      b[1] = "\u000f.%|W!;\r*<\u001a*1\u0010/a\u0011l!\u0016/~\nl桅桳伓叙厲厉桅厩伓佇B";
      b[2] = "V>C/+\u000e]1R`J\u0000V:V:";
      b[3] = "\nnm@\u001dS\\es|厷栤司及住桥厷栤栢栐\u0012M\u0013B\u0007`|\u001b\u0018\\";
      b[4] = "\u0018\u000bAC:+N\u0000_\u007f伎优只厯栧厼桊历只桵>N4:\u0015\u0005P\u0018?$";
      b[5] = "\u0010&\u0011\u001a\u000b?F-\u000f&伿案核桘桷佻伿伌核厂n\u0017\u0005.\u001d(\u0000A\u000e0";
      b[6] = "\u0007\u001em(DJQ\u0015s\u0014栴叧佫厺住受叮栽佫厺\u0012%J[\n\u0010|sAE";
      b[7] = "U<\u0017LI\u000e\u00037\tp口厣厧厘伵桩根桹伹桂hAG\u001fX2\u0006\u0017L\u0001";
      b[8] = "I\u0011\u0016H\u0016\u000b\u001f\u001a\bt厼厦桡伫桰伩厼伸桡厵iE\u0018\u001aD\u001f\u0007\u0013\u0013\u0004";
      b[9] = "0a\u0005s.rfj\u001bO厄叟作叅厹伒厄叟作叅z~ c=o\u0014(+}";
      b[10] = "%V\u001cAU\u001as]\u0002}叿厷栍佬伾桤佡桭佉史cDU\u000e}@\u001e\u0019\\\u0011)";
      b[11] = "N\u001e@\u0013pG\u0018\u0015^/叚只桦桠佢栶佄栰厼厺?\u001e~VC\u0010QHuH";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 56;
               case 1 -> 41;
               case 2 -> 27;
               case 3 -> 54;
               case 4 -> 50;
               case 5 -> 33;
               case 6 -> 4;
               case 7 -> 9;
               case 8 -> 39;
               case 9 -> 31;
               case 10 -> 45;
               case 11 -> 58;
               case 12 -> 59;
               case 13 -> 38;
               case 14 -> 49;
               case 15 -> 1;
               case 16 -> 14;
               case 17 -> 48;
               case 18 -> 16;
               case 19 -> 63;
               case 20 -> 61;
               case 21 -> 57;
               case 22 -> 18;
               case 23 -> 12;
               case 24 -> 10;
               case 25 -> 44;
               case 26 -> 17;
               case 27 -> 2;
               case 28 -> 25;
               case 29 -> 43;
               case 30 -> 11;
               case 31 -> 24;
               case 32 -> 0;
               case 33 -> 46;
               case 34 -> 52;
               case 35 -> 55;
               case 36 -> 22;
               case 37 -> 29;
               case 38 -> 19;
               case 39 -> 32;
               case 40 -> 21;
               case 41 -> 3;
               case 42 -> 60;
               case 43 -> 20;
               case 44 -> 47;
               case 45 -> 28;
               case 46 -> 23;
               case 47 -> 40;
               case 48 -> 15;
               case 49 -> 42;
               case 50 -> 35;
               case 51 -> 36;
               case 52 -> 5;
               case 53 -> 8;
               case 54 -> 62;
               case 55 -> 37;
               case 56 -> 6;
               case 57 -> 26;
               case 58 -> 13;
               case 59 -> 30;
               case 60 -> 53;
               case 61 -> 7;
               case 62 -> 51;
               default -> 34;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static 树树何友友友树友何何 v(String a) {
      return Enum.valueOf(树树何友友友树友何何.class, a);
   }

   public static List K(long var0) {
      long var3 = a ^ var0 ^ 21437784019749L;
      return new 树友树何树树友树友树(var3);
   }

   private static String HE_WEI_LIN() {
      return "何炜霖230622200409390090";
   }
}
