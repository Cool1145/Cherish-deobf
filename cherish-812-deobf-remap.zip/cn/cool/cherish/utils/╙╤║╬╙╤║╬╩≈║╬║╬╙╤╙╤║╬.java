package cn.cool.cherish.utils;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.apache.commons.lang3.RandomUtils;

public final class 友何友何树何何友友何 implements IWrapper, 何树友 {
   private final BlockPos 树何何何友何树友何友;
   private Direction 何树树何友何何树树何;
   private Vec3 何友友友何何友友树树;
   private static final long a;
   private static final Object[] b = new Object[45];
   private static final String[] c = new String[45];
   private static String LIU_YA_FENG;

   public 友何友何树何何友友何(long a, BlockPos blockPos, Direction enumFacing) {
      a = 124163898282002L ^ a;
      long ax = a ^ 69878121122710L;
      super();
      this.树何何何友何树友何友 = blockPos;
      a<"Â">(this, enumFacing, -7548937132708073097L, a);
      a<"Â">(this, this.J(ax), -7548327789354118330L, a);
   }

   public 友何友何树何何友友何(BlockPos blockPos, Direction enumFacing, long a, byte a, Vec3 vec3) {
      this.树何何何友何树友何友 = blockPos;
      this.何树树何友何何树树何 = enumFacing;
      this.何友友友何何友友树树 = vec3;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(7535162155955817617L, 7722280465971196617L, MethodHandles.lookup().lookupClass()).a(60159835387190L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public BlockPos B(long a) {
      return this.树何何何友何树友何友;
   }

   public void J(Vec3 a, long a) {
      a = 124163898282002L ^ a;
      a<"Â">(this, a, -1826038010615766320L, a);
   }

   public Vec3 J(long a) {
      byte ax;
      Vec3 directionVec;
      double x;
      double z;
      label81: {
         a = 124163898282002L ^ a;
         byte var10000 = a<"é">(-3694283453950890880L, (long)a);
         directionVec = Vec3.atLowerCornerOf(a<"Ñ">(this, -3695055281098151181L, (long)a).getNormal());
         ax = var10000;
         switch (a<"X">(-3695914053786427980L, (long)a)[a<"Ñ">(this, -3695055281098151181L, (long)a).getAxis().ordinal()]) {
            case 1:
               double absX = Math.abs(mc.player.getX());
               double xOffset = absX - (int)absX;
               double var25 = mc.player.getX();
               if (a > 0L) {
                  if (var25 < 0.0) {
                     xOffset = 1.0 - xOffset;
                  }

                  var25 = a<"Ñ">(directionVec, -3696315605975666180L, (long)a) * xOffset;
               }

               x = var25;
               z = a<"Ñ">(directionVec, -3696064598008357691L, (long)a) * xOffset;
               var10000 = ax;
               if (a > 0L) {
                  if (ax != 0) {
                     break label81;
                  }

                  var10000 = 2;
               }

               a<"é">(new Module[var10000], -3695163068520645907L, (long)a);
            case 2:
               double absZ = Math.abs(mc.player.getZ());
               double zOffset = absZ - (int)absZ;
               double var27 = mc.player.getZ();
               if (a > 0L) {
                  if (var27 < 0.0) {
                     zOffset = 1.0 - zOffset;
                  }

                  var27 = a<"Ñ">(directionVec, -3696315605975666180L, (long)a) * zOffset;
               }

               x = var27;
               double var28 = a<"Ñ">(directionVec, -3696064598008357691L, (long)a) * zOffset;
               if (a <= 0L) {
                  break;
               }
            default:
               x = 0.25;
         }

         z = 0.25;
      }

      if (a<"Ñ">(this, -3695055281098151181L, (long)a).getAxisDirection() == a<"X">(-3694137976593637996L, (long)a)) {
         x = -x;
         z = -z;
      }

      Vec3 hitVec = new Vec3(
            a<"Ñ">(this, -3695237307182257586L, (long)a).getX() + 0.5,
            a<"Ñ">(this, -3695237307182257586L, (long)a).getY() + 0.5,
            a<"Ñ">(this, -3695237307182257586L, (long)a).getZ() + 0.5
         )
         .add(x + z, a<"Ñ">(directionVec, -3694974265911011994L, (long)a) * 0.5, x + z);
      Vec3 src = mc.player.getEyePosition(1.0F);
      BlockHitResult obj = mc.level
         .clip(new ClipContext(src, hitVec, a<"X">(-3696000419268201413L, (long)a), a<"X">(-3694876749298968770L, (long)a), mc.player));
      BlockHitResult var29 = obj;
      byte var10001 = ax;
      if (a >= 0L) {
         if (ax != 0) {
            if (obj == null) {
               return null;
            }

            var29 = obj;
         }

         var10001 = ax;
      }

      if (var10001 != 0) {
         if (var29.getType() != a<"X">(-3695280465055696058L, (long)a)) {
            return null;
         }

         var29 = obj;
      }

      Vec3 resultVec = var29.getLocation();

      resultVec = switch (a<"X">(-3695914053786427980L, (long)a)[a<"Ñ">(this, -3695055281098151181L, (long)a).getAxis().ordinal()]) {
         case 1 -> new Vec3(
            a<"Ñ">(resultVec, -3696315605975666180L, (long)a),
            a<"Ñ">(resultVec, -3694974265911011994L, (long)a),
            Math.round(a<"Ñ">(resultVec, -3696064598008357691L, (long)a))
         );
         case 2 -> new Vec3(
            Math.round(a<"Ñ">(resultVec, -3696315605975666180L, (long)a)),
            a<"Ñ">(resultVec, -3694974265911011994L, (long)a),
            a<"Ñ">(resultVec, -3696064598008357691L, (long)a)
         );
         default -> resultVec;
      };
      if (a<"Ñ">(this, -3695055281098151181L, (long)a) != a<"X">(-3695082294168573886L, (long)a)
         && a<"Ñ">(this, -3695055281098151181L, (long)a) != a<"X">(-3694582711367582893L, (long)a)) {
         BlockState blockState = mc.level.getBlockState(obj.getBlockPos());
         Block blockAtPos = blockState.getBlock();
         double blockFaceOffset = RandomUtils.nextDouble(0.1, 0.3);
         if (blockAtPos instanceof SlabBlock) {
            SlabType slabType = (SlabType)blockState.getValue(a<"X">(-3694305205674856693L, (long)a));
            if (slabType != a<"X">(-3695855432748655527L, (long)a)) {
               blockFaceOffset += 0.5;
            }
         }

         resultVec = resultVec.add(0.0, -blockFaceOffset, 0.0);
      }

      return resultVec;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 16;
               case 1 -> 36;
               case 2 -> 49;
               case 3 -> 2;
               case 4 -> 10;
               case 5 -> 25;
               case 6 -> 44;
               case 7 -> 45;
               case 8 -> 3;
               case 9 -> 13;
               case 10 -> 1;
               case 11 -> 7;
               case 12 -> 21;
               case 13 -> 26;
               case 14 -> 4;
               case 15 -> 22;
               case 16 -> 53;
               case 17 -> 58;
               case 18 -> 48;
               case 19 -> 0;
               case 20 -> 62;
               case 21 -> 38;
               case 22 -> 23;
               case 23 -> 50;
               case 24 -> 57;
               case 25 -> 32;
               case 26 -> 52;
               case 27 -> 24;
               case 28 -> 34;
               case 29 -> 33;
               case 30 -> 18;
               case 31 -> 28;
               case 32 -> 30;
               case 33 -> 42;
               case 34 -> 6;
               case 35 -> 47;
               case 36 -> 15;
               case 37 -> 5;
               case 38 -> 63;
               case 39 -> 12;
               case 40 -> 17;
               case 41 -> 9;
               case 42 -> 60;
               case 43 -> 41;
               case 44 -> 59;
               case 45 -> 43;
               case 46 -> 20;
               case 47 -> 14;
               case 48 -> 55;
               case 49 -> 35;
               case 50 -> 51;
               case 51 -> 31;
               case 52 -> 56;
               case 53 -> 8;
               case 54 -> 11;
               case 55 -> 40;
               case 56 -> 54;
               case 57 -> 27;
               case 58 -> 37;
               case 59 -> 19;
               case 60 -> 46;
               case 61 -> 61;
               case 62 -> 29;
               default -> 39;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static 友何友何树何何友友何 e(long a, BlockPos var2) {
      a = 124163898282002L ^ a;
      long ax = (a ^ 2471542025130L) >>> 8;
      int axx = (int)((a ^ 2471542025130L) << 56 >>> 56);
      long axxx = a ^ 103256300014910L;
      boolean var9 = a<"é">(-503214926087694017L, (long)a);
      if (树何树树何何树友何何.B(var2.below(), axxx)) {
         return new 友何友何树何何友友何(var2.below(), a<"X">(-502915604783853844L, (long)a), ax, (byte)axx, null);
      } else {
         boolean var10000 = 树何树树何何树友何何.B(var2.south(), axxx);
         boolean var10001 = var9;
         if (a > 0L) {
            if (var9) {
               if (var10000) {
                  return new 友何友何树何何友友何(var2.south(), a<"X">(-501254742441610101L, (long)a), ax, (byte)axx, null);
               }

               var10000 = 树何树树何何树友何何.B(var2.west(), axxx);
            }

            var10001 = var9;
         }

         if (a >= 0L) {
            if (var10001) {
               if (var10000) {
                  return new 友何友何树何何友友何(var2.west(), a<"X">(-501093790881637412L, (long)a), ax, (byte)axx, null);
               }

               var10000 = 树何树树何何树友何何.B(var2.north(), axxx);
            }

            if (a <= 0L) {
               return var10000 ? new 友何友何树何何友友何(var2.east(), a<"X">(-502932716439251781L, (long)a), ax, (byte)axx, null) : null;
            }

            var10001 = var9;
         }

         if (var10001) {
            if (var10000) {
               return new 友何友何树何何友友何(var2.north(), a<"X">(-503040669708107584L, (long)a), ax, (byte)axx, null);
            }

            var10000 = 树何树树何何树友何何.B(var2.east(), axxx);
         }

         return var10000 ? new 友何友何树何何友友何(var2.east(), a<"X">(-502932716439251781L, (long)a), ax, (byte)axx, null) : null;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 209 && var8 != 194 && var8 != 'X' && var8 != 221) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'l') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 233) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 209) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'X') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public Vec3 s(long a) {
      a = 124163898282002L ^ a;
      return a<"Ñ">(this, -8156665651354105163L, (long)a);
   }

   public void s(long a, Direction a) {
      a = 124163898282002L ^ a;
      a<"Â">(this, a, 8238674307663139870L, (long)a);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友何友何树何何友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "F*R\u0013/HF*EO#G\\aER0D\u0006\u000bOO'B\\&IS";
      b[1] = "Z\u001c;Y\u001b'U\\vR\u0011:P\u0001}\u0014\u0001<P\u001ef\u0014县伝史伧栄佯伡厃史伧";
      b[2] = "|G\u001a\u0005+.wH\u000bJW7xR\u0005\t`\u0007nE\t\u0014q+yH";
      b[3] = "|p$mHTs0ifBIvmb ROvry 栶佮栎栏佟佛栶台佊佋";
      b[4] = boolean.class;
      c[4] = "java/lang/Boolean";
      b[5] = "YZ-\u001c{\u0018YZ:@w\u0017C\u0011.]d\u001dS\u0011)Zo\u0002\u0019i<Q%";
      b[6] = "pk[\u000fi-pkLSe\"j XNv(z _I}70FFUV!m{CU \u0010g~J";
      b[7] = "I9HLg\u0002I9_\u0010k\rSr_\rx\u000e\t\u001eP\ri\u0000w3O";
      b[8] = double.class;
      c[8] = "java/lang/Double";
      b[9] = "Q\u001e\u0005fHrQ\u001e\u0012:D}KU\u0006'Ww[U\u001d-S~SU2$Lk|\u0014\u001f<@cK_3$JxT";
      b[10] = "\u007f?*\u000bHZp\u007fg\u0000BGu\"lFRAu=wF召你受伄栕伽佲叾受伄 厣佲栤受桀栕桹栶叾受";
      b[11] = "mu";
      b[12] = "-\u000eC\u001a\u000ep-\u000eTF\u0002\u007f7E@[\u0011u'E[Q\u0015|/EUX\fz(ED@\u0002m&EGF\fi&\u0019C]\u0006jm8[U\u0001M:\u001bR";
      b[13] = "\u0017al\u0018\u0015#\u0018!!\u0013\u001f>\u001d|*U\u0017#\u0010z.\u001eT\u0001\u001bk7\u0017\u001f";
      b[14] = "@\t}:^Xt*rz\u0013S~7w'\u0018\u0015v*z!\u001c^5\bq0\u0005W~~";
      b[15] = "\u00104\u0019f-0\u00104\u000e:!?\n\u007f\u001a'25\u001a\u007f\u0001-6<\u0012\u007f\u000f$/:\u0015\u007f>$!;<=\u0002++";
      b[16] = "\u0006 gBu\r\u0006 p\u001ey\u0002\u001ckd\u0003j\b\fk\u007f\tn\u0001\u0004kq\u0000w\u0007\u0003k`\u0018y\u0010\rkc\u001ew\u0014\r7g\u0005}\u0017F\u0000}\u0019u4\u001a*c\tj\u0010\u0011";
      b[17] = "a\u0010:i7Ma\u0010-5;B{[-((A!1'5?G{\u001c!)~ew\u001c=\u00033Vj\u0016:.5J";
      b[18] = "\u00031:[)f7\u00125\u001bdm=\u000f0Fo+5\u0012=@k`v06Qri=F";
      b[19] = void.class;
      c[19] = "java/lang/Void";
      b[20] = "0Eu5u 0Ebiy/*\u000evtj%:\u000em~n,2\u000eBwq9\u001dOoo}1*\u0004Gwm :";
      b[21] = "\u001d\u0013\rq\u0005H\u0016\u001c\u001c>dF\u001d\u0017\u0018d";
      b[22] = "`\u001cwBP]\"\u0015uGk*\u0018=[`k\\:\u001dq\u0018V\u001e3\u001ft";
      b[23] = "/z\u0007\u001f@4/7\u0001\u007f栻伌伀伖厸伢栻厒伀厈{C\\+g4DG_:<";
      b[24] = "~X .J{:R!pq+\u0012\r qNt\u0012=$t\u000e\"tT+.\u0013\u007f";
      b[25] = "\u007fx\u0007N\u0011\u001dfyH44*LH54\u001b\u0001dn\u0016D\u0002\u0000+";
      b[26] = "JBI(mjSC\u0006RCSxr;;bhYMK\"c'";
      b[27] = "\u000e<\u007f>+YJ6~`\u0010\tbi\u007fa ^bY{do\u0000\u00040t>r]";
      b[28] = "\u0001R\u001b3\u0015hZ\u0010\u000e0gDxo'\u001b+Be+]#\u001ffML\u0006a\ne";
      b[29] = "\u0001\r\u000b\n\u001c<UP\u0012Wx企佣佯伩伺伥原栧叱桭gG'\u0005W\r\u001b\u0011a^V";
      b[30] = "\u000fwC)u\u0006O \u0019+\u00131xB\u007fk~QM|\u0014+)\u000bO";
      b[31] = "\u0014cl@\u0002T\u0014.j \t1_,l\u001e\u001eN\bhh\u001f`\b\u0018..^\u001f_\\*/ ";
      b[32] = "#\u0019^y\u000e/:\u0018\u0011\u00030\u0007J\u001c@q\u0017<:\u0005A>";
      b[33] = " $~\u001fI\u00059%1eu8\u0012\u0014\f\fF\u00073+|\u0015GH";
      b[34] = "s\u0003\u0012\u0001#\\sN\u0014a伜叺参叱伳似厂叺栘栫nZ$\u0003b\tP\u001e.\u0002<";
      b[35] = "\u0001~2E\u0014mJ}0E+\u00050y<A\u0015=W*6\u0018DW";
      b[36] = "F\\\u0002\"^\u0018A\u0018@9&Fx\u001c\u0002{\u001b\u0013x!V-\u0017Z_\u0019^-\u0018P";
      b[37] = "<pa<m\u001be~=/\u000f\n\u0006\"cyk\u00116{bqpq";
      b[38] = "d\u0003V\u001d/f}\u0002\u0019g\u0017QP3dg%z\u007f\u0015G\u0017<{0";
      b[39] = "\t\u001b/Wy`Y^y\u0018\u0007]/i\u000b4FE/&)Uj$\u001c]y\u0010<k";
      b[40] = "\u000e\"/\u007fk}E!-\u007fT\u0019?%!{j-Xv+\";GS'+t5;[2%aT";
      b[41] = "\t\u0016XAr8\u0010\u0017\u0017;]\u000f?<*R}:\u001a\u0019ZK|u";
      b[42] = "\u000fpq\\Q]\u000f=w<佮校桤伜収佡佮校桤伜\rU_J\u0007\"}L^\u0005";
      b[43] = " \u0005w\u0011E!d\u000fvO~qLPwNN'L`sK\u0001x*\t|\u0011\u001c%";
      b[44] = "\u001dzLEE8\u0000 IE=D7\u0000=(P>L+\b\u0012MdI+";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void v(int a, Direction enumFacing, int a, int a) {
      long ax = ((long)a << 32 | (long)a << 48 >>> 32 | (long)a << 48 >>> 48) ^ 124163898282002L;
      a<"Â">(this, enumFacing, -4866832868330776002L, ax);
   }

   public Direction E(long a) {
      return this.何树树何友何何树树何;
   }

   private static String HE_JIAN_GUO() {
      return "何树友，和树做朋友";
   }
}
