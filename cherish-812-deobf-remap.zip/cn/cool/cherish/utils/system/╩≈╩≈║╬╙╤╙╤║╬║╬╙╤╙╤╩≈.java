package cn.cool.cherish.utils.system;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 树树何友友何何友友树 implements 何树友 {
   private static TrayIcon 树友友树树树树友友友;
   private static boolean 友何友何树何友何树友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[18];
   private static final String[] f = new String[18];
   private static String HE_DA_WEI;

   private 树树何友友何何友友树(long a) {
      a = 树树何友友何何友友树.a ^ a;
      super();
      throw new UnsupportedOperationException(a<"w">(21837, 7335626980662910762L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-3457529244621599832L, -5478583882690079689L, MethodHandles.lookup().lookupClass()).a(234384980222651L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 13221778605956L;
      a();
      b<"O">(true, -423018572770528749L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[10];
      int var5 = 0;
      String var4 = "ýª[½\u0005ý\u008bZì5}âV,>\u0093°ÂÙ\"Ç\u007fä\u0090È Qêß\u0006ÒØ\u0090Ry\u008aÐÕö\u009e¼ð&,ïjdÁÒ×$\tA}ö\u0014 Ã~®y+«D÷\u0080ïl¼X@\u000bg\\\u0011o\t#xÑÛ\u0086\u0000q\tôG-\u0086\u0010pÆOª\u0085\u001e \u00176h@~á^\u0088*\u0018çpp\\¼U\u0080\u0095»\b¸çë\u001e¤*}}6HùÓÛG\u0010D\u008bN@Ãq\u0019>\bç\fj\u0004S\u001f\u008f Û\u0092\u0012\u009d®\u0018ùòæ§Us\u000fÙÕ\b\u001fbe¯\u007fmù\u001bú\u008f\u0002Âi\"\u0015\u0087\u0010¦§hô\u0016ûÀÖ\u001fpL\fsÖQº\u0010´éð=¬P#³Y}#\u000f¬\u007f}z";
      short var6 = 215;
      char var3 = '8';
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = a(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     b = var7;
                     c = new String[10];
                     b<"b">(null, -421598313743166889L, var9);
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "\u00055\u009duiÞþFO\u009f2\u008c\u008cá\u0084ÓX\u0096QB/^u\u0080#-ukÓ \u0007J7R1[\u001d\u008b&½³\u0093e\u0084kéË'j\u0000\u0090äpcÿ.\u001c§\u0011÷*G\u0015,\u0082¾ÁÿE\u0002\nçÓ¤\u0080\u0007v\u0010\u0001Dr[¬\u001bEÓú2z\u009fîpñõÞíY\u0091Ëú´\u0007Ï\u0084*";
                  var6 = 105;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   public static void C(long var0) {
      var0 = a ^ var0;

      try {
         new ProcessBuilder(a<"w">(791, 3199679900557759443L ^ var0), a<"w">(25910, 8188402148981028340L ^ var0), a<"w">(23532, 5644149824317492002L ^ var0))
            .inheritIO()
            .start()
            .waitFor();
      } catch (Throwable var2) {
      }
   }

   public static void F(String a, long a) {
      long ax = 树树何友友何何友友树.a ^ a ^ 52040995960339L;
      O(a, ax);
   }

   public static void I(long a, String var2) {
      a = 树树何友友何何友友树.a ^ a;
      long ax = a ^ 49356540567946L;
      int axx = b<"O">(5951895760371304886L, (long)a);
      if (SystemTray.isSupported()) {
         label33: {
            TrayIcon icon = w(ax);
            TrayIcon var10000 = icon;
            short var10001 = axx;
            if (a > 0L) {
               if (axx == 0) {
                  if (icon == null) {
                     break label33;
                  }

                  var10000 = icon;
               }

               var10001 = 23359;
            }

            var10000.displayMessage(a<"w">(var10001, 6074303736997545558L ^ a), var2, b<"á">(5951854401357889459L, (long)a));
         }

         byte var9 = axx;
         if (a >= 0L) {
            if (axx == 0) {
               return;
            }

            var9 = b<"O">(5953543957129255273L, (long)a);
         }

         b<"O">(var9 == 0, 5952027520982742239L, (long)a);
      }

      null.println(a<"w">(9851, 3815752684012993297L ^ a) + var2);
   }

   public static void J(long var0) {
      var0 = a ^ var0;
      if (b<"á">(6013817417727867652L, var0) != null && SystemTray.isSupported()) {
         SystemTray.getSystemTray().remove(b<"á">(6013817417727867652L, var0));
         b<"b">(null, 6013817417727867652L, var0);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/system/树树何友友何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 11;
               case 1 -> 19;
               case 2 -> 58;
               case 3 -> 51;
               case 4 -> 47;
               case 5 -> 45;
               case 6 -> 18;
               case 7 -> 2;
               case 8 -> 22;
               case 9 -> 7;
               case 10 -> 27;
               case 11 -> 31;
               case 12 -> 38;
               case 13 -> 23;
               case 14 -> 9;
               case 15 -> 57;
               case 16 -> 16;
               case 17 -> 48;
               case 18 -> 53;
               case 19 -> 43;
               case 20 -> 12;
               case 21 -> 3;
               case 22 -> 62;
               case 23 -> 63;
               case 24 -> 24;
               case 25 -> 10;
               case 26 -> 32;
               case 27 -> 21;
               case 28 -> 36;
               case 29 -> 44;
               case 30 -> 29;
               case 31 -> 40;
               case 32 -> 33;
               case 33 -> 13;
               case 34 -> 55;
               case 35 -> 4;
               case 36 -> 26;
               case 37 -> 39;
               case 38 -> 17;
               case 39 -> 20;
               case 40 -> 46;
               case 41 -> 14;
               case 42 -> 41;
               case 43 -> 42;
               case 44 -> 30;
               case 45 -> 37;
               case 46 -> 6;
               case 47 -> 8;
               case 48 -> 0;
               case 49 -> 52;
               case 50 -> 5;
               case 51 -> 56;
               case 52 -> 50;
               case 53 -> 15;
               case 54 -> 25;
               case 55 -> 54;
               case 56 -> 61;
               case 57 -> 28;
               case 58 -> 60;
               case 59 -> 1;
               case 60 -> 49;
               case 61 -> 59;
               case 62 -> 34;
               default -> 35;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/system/树树何友友何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      e[0] = "*; \r&~%{m\u0006,c &f@<e 9}@:h:!k\u0003g栀桘伀叅厥伜佄厂厞栟";
      e[1] = boolean.class;
      f[1] = "java/lang/Boolean";
      e[2] = void.class;
      f[2] = "java/lang/Void";
      e[3] = "\u001aC\u0016\u001fr,\u0007VN*.,\tk\u0003\u00112";
      e[4] = "\u0004jm\u007f\rT\u0019\u007f5JQT\u0017BxqM\u0011#nhmBR\u000b_bnF";
      e[5] = " 7\u007f>eE/w25oX**9sgE',=8$g,=$1o";
      e[6] = "d\tl>\u000e.o\u0006}qe:m\rj+I-`";
      e[7] = "\u001e3>-b-\u0015</b\u0003#\u001e7+8";
      e[8] = ">\f4\u000f&\u0011|\b*\u001c[d_?\n<[\u0012l\u001c$\u001bcPh\u00027";
      e[9] = "1B\t\r!\u007fvX\u001emN\u00182\u0019K\ri%0]NV\u0011";
      e[10] = "Y.x\u0004$~\u001f%(\b\u001cXbn\u007f\u0006|c_l;\u0003'\u001b";
      e[11] = "\tZmx|)OQ=tD\u00052\u001ajz$4\u000f\u0018.\u007f\u007fL\u000bCo|4 \bB/#D";
      e[12] = "\u0014\u001fuSw\u0003S\u0005b3.d\u0012\u00181\u000b<\rI\u0002cJGXN@1H.\u0003T\u0012p3";
      e[13] = "N\\\u001eYTb\tF\t9'\u0005M\u0007\\Y\u001c8OCY\u0002d<\u0014\u0002ZI\b?\u0015B\u00059";
      e[14] = "_boXq6\u001dfqK\fO\"EQ17g\u001dbk\tuc\u0003q";
      e[15] = "a\tH\u001dW~#\rV\u000e*\u0019\u0013:w5l\tZ[X\rC;b\u0019\\\u0013P";
      e[16] = "JI\u0012+ \u0006\fBB'\u0018\u000eq\t\u0015)x\u001bL\u000bQ,#c";
      e[17] = "3E\u001d\u0002\u0010\"t_\nb根历及栻桸桻根历及叡aX\u001c85\u001c\\\u0013\\<8";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 221 && var8 != 170 && var8 != 225 && var8 != 'b') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 219) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'O') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 221) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 170) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 225) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 4084;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/system/树树何友友何何友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   public static void U(String a, long a) {
      a = 树树何友友何何友友树.a ^ a;
      long ax = a ^ 132931931560405L;
      if (SystemTray.isSupported()) {
         label18: {
            TrayIcon icon = w(ax);
            TrayIcon var10000 = icon;
            if (a > 0L) {
               if (icon == null) {
                  break label18;
               }

               var10000 = icon;
            }

            var10000.displayMessage(a<"w">(19078, 5269750922045665201L ^ a), a, b<"á">(7694290599547027652L, a));
         }

         if (a > 0L) {
            return;
         }
      }

      null.println(a<"w">(1179, 3568099775033205162L ^ a) + a);
   }

   private static TrayIcon w(long a) {
      a = 树树何友友何何友友树.a ^ a;
      if (b<"á">(1059215456969270978L, (long)a) == null && SystemTray.isSupported()) {
         Image image = Toolkit.getDefaultToolkit().createImage("");
         b<"b">(new TrayIcon(image, a<"w">(23359, 6074282950346758778L ^ a)), 1059215456969270978L, (long)a);
         b<"á">(1059215456969270978L, (long)a).setImageAutoSize(true);

         try {
            SystemTray.getSystemTray().add(b<"á">(1059215456969270978L, (long)a));
         } catch (AWTException var5) {
            null.println(a<"w">(3372, 3622765336566172783L ^ a) + var5.getMessage());
         }
      }

      return b<"á">(1059215456969270978L, (long)a);
   }

   public static boolean r() {
      return 友何友何树何友何树友;
   }

   public static boolean W() {
      r();

      try {
         return true;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   public static void O(String a, long a) {
      byte ax;
      byte var9;
      label46: {
         label45: {
            a = 树树何友友何何友友树.a ^ a;
            long axx = a ^ 18573325005226L;
            ax = b<"O">(4807977083906349462L, a);
            if (SystemTray.isSupported()) {
               label42: {
                  TrayIcon icon = w(axx);
                  TrayIcon var10000 = icon;
                  short var10001 = ax;
                  if (a > 0L) {
                     if (ax == 0) {
                        if (icon == null) {
                           break label42;
                        }

                        var10000 = icon;
                     }

                     var10001 = 23359;
                  }

                  var10000.displayMessage(a<"w">(var10001, 6074369734494656118L ^ a), a, b<"á">(4807802896580528172L, a));
               }

               var9 = ax;
               if (a < 0L) {
                  break label46;
               }

               if (ax == 0) {
                  break label45;
               }
            }

            null.println(a<"w">(29037, 7863546609586551841L ^ a) + a);
         }

         var9 = b<"O">(4808033317186248195L, a);
      }

      if (a >= 0L) {
         if (var9 == 0) {
            return;
         }

         var9 = ax;
      }

      b<"O">(var9 == 0, 4807686811467975306L, a);
   }

   public static void K(boolean var0) {
      友何友何树何友何树友 = var0;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖国企变私企";
   }
}
