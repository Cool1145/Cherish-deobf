package cn.cool.cherish.utils;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.RandomUtils;

public class 何友友何树何树何树友 implements 何树友 {
   public long 树树何树何树友何树树 = System.currentTimeMillis();
   private static Module[] 友树友树树何何友树友;
   private static final long a;
   private static final long b;
   private static final Object[] c = new Object[16];
   private static final String[] d = new String[16];
   private static int _何炜霖大狗叫 _;

   public 何友友何树何树何树友(long a) {
      this.D(11747522392279L);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(1535892793451093251L, -2467665271051992910L, MethodHandles.lookup().lookupClass()).a(3797930857624L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (x() == null) {
         Q(new Module[2]);
      }

      Cipher var0;
      Cipher var5 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(25030821832425L << var1 * 8 >>> 56);
      }

      var5.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var4 = var0.doFinal(new byte[]{17, 102, -88, 77, 35, 29, -63, 15});
      long var6 = (var4[0] & 255L) << 56
         | (var4[1] & 255L) << 48
         | (var4[2] & 255L) << 40
         | (var4[3] & 255L) << 32
         | (var4[4] & 255L) << 24
         | (var4[5] & 255L) << 16
         | (var4[6] & 255L) << 8
         | var4[7] & 255L;
      byte var10001 = -1;
      b = var6;
   }

   public void D(long a) {
      this.树树何树何树友何树树 = System.currentTimeMillis();
   }

   public long F(long a) {
      return System.currentTimeMillis() - this.树树何树何树友何树树;
   }

   public void J(long a, long var3) {
      var3 = 122936793366763L ^ var3;
      a<"Ö">(this, (long)a, -3147380984908337863L, var3);
   }

   public boolean Z(long a, long var3) {
      var3 = 122936793366763L ^ var3;
      long ax = var3 ^ 26888258274158L;
      a<"è">(3262252500313689394L, var3);
      return this.p(System.nanoTime() - a<"¤">(this, 3261751916801414191L, var3), ax) >= a;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public static Module[] x() {
      return 友树友树树何何友树友;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public boolean c(long a, long var3) {
      x();
      return System.currentTimeMillis() - this.树树何树何树友何树树 >= a;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 164 && var8 != 214 && var8 != 'G' && var8 != 'R') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'z') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 232) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 164) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 214) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'G') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (d[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 12;
               case 1 -> 47;
               case 2 -> 51;
               case 3 -> 31;
               case 4 -> 19;
               case 5 -> 8;
               case 6 -> 27;
               case 7 -> 7;
               case 8 -> 29;
               case 9 -> 38;
               case 10 -> 24;
               case 11 -> 25;
               case 12 -> 48;
               case 13 -> 37;
               case 14 -> 35;
               case 15 -> 39;
               case 16 -> 11;
               case 17 -> 60;
               case 18 -> 20;
               case 19 -> 6;
               case 20 -> 45;
               case 21 -> 28;
               case 22 -> 26;
               case 23 -> 17;
               case 24 -> 49;
               case 25 -> 59;
               case 26 -> 32;
               case 27 -> 50;
               case 28 -> 33;
               case 29 -> 54;
               case 30 -> 46;
               case 31 -> 44;
               case 32 -> 13;
               case 33 -> 3;
               case 34 -> 30;
               case 35 -> 18;
               case 36 -> 53;
               case 37 -> 58;
               case 38 -> 42;
               case 39 -> 41;
               case 40 -> 4;
               case 41 -> 9;
               case 42 -> 0;
               case 43 -> 22;
               case 44 -> 57;
               case 45 -> 2;
               case 46 -> 21;
               case 47 -> 63;
               case 48 -> 10;
               case 49 -> 34;
               case 50 -> 1;
               case 51 -> 56;
               case 52 -> 62;
               case 53 -> 40;
               case 54 -> 15;
               case 55 -> 14;
               case 56 -> 43;
               case 57 -> 55;
               case 58 -> 16;
               case 59 -> 52;
               case 60 -> 5;
               case 61 -> 61;
               case 62 -> 23;
               default -> 36;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            d[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      c[0] = "'\u0007|:\u0004O(G11\u000eR-\u001a:w\u001eT-\u0005!w伾叫厏似桃伌桺併桕厢";
      c[1] = long.class;
      d[1] = "java/lang/Long";
      c[2] = "d*\u0006\u0001\u0000^o%\u0017N|G`?\u0019\rKwv(\u0015\u0010Z[a%";
      c[3] = "y*\u0005O\u0017\u000bvjHD\u001d\u0016s7C\u0002\u0015\u000b~1GIV)u ^@\u001d";
      c[4] = "(A}*\rK\u001cbrj@@\u0016\u007fw7K\u0006\u001ebz1OM]@q VD\u00166";
      c[5] = "T\u0006vj\b\u000b`%y*E\u0000j8|wNFb%qqJ\r!\u0007z`S\u0004jq";
      c[6] = "\u0012\t=[9t&*2\u001bt\u007f,77F\u007f9$*:@{rg\b1Qb{,~";
      c[7] = void.class;
      d[7] = "java/lang/Void";
      c[8] = "R5n\t7\u0010f\u0016aIz\u001bl\u000bd\u0014q]d\u0016i\u0012u\u0016'4b\u0003l\u001flB";
      c[9] = "8\u0018$!d\u00023\u00175n\u0005\f8\u001c14";
      c[10] = "1FDOD\boO\u0018F+9\u000b\u0016\u000bKK\flP\u0016QHk";
      c[11] = "t\u0013v1}bg\u0010\u001f!\u0016fy\u0013\u007f6q d\t|Q";
      c[12] = "@all0xSb\u0005栕桂伜栫作栜叏伆桘栫\u0001|s1=\u0002}8ke";
      c[13] = "\u001f.x.-x\f-\u0011'Fx\u0011(r*%{\u0012r`N\u007f=\u000b-u-|>Q?\u0011";
      c[14] = "\u001c\u001a/n\nhB\u0013sgeU&J`j\u0005lA\f}p\u0006\u000b\u001bM.m\u0003;_Maze";
      c[15] = "^\u0005|\u007fl$M\u0006\u0015F\u0007 S\u0005ux`fN\u001fv\u001f:'\u001d\u0002s/~'R\u0015\u0015";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public boolean a(long a, double var3) {
      return this.A((long)var3, 118344821288830L);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/何友友何树何树何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public long m(long a) {
      a = 122936793366763L ^ a;
      long ax = a ^ 107113670440242L;
      return this.p(System.nanoTime() - a<"¤">(this, -7270943911802674573L, (long)a), ax);
   }

   public long p(long a, long var3) {
      long var10000 = 122936793366763L ^ var3;
      return a / 1000000L;
   }

   public static long j(int a, int maxDelay) {
      return RandomUtils.nextInt((int)a, maxDelay);
   }

   public void z(long a, long var3) {
      this.树树何树何树友何树树 = Math.max(this.树树何树何树友何树树, System.currentTimeMillis() + a);
   }

   public boolean u(long a, boolean time, long var4) {
      x();
      if (System.currentTimeMillis() - this.树树何树何树友何树树 > a) {
         if (time) {
            this.D(11747522392279L);
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean r(double a, long var3) {
      var3 = 122936793366763L ^ var3;
      long ax = var3 ^ 135874140129989L;
      a<"è">(2661269740669748377L, var3);
      boolean var10000 = this.p(System.nanoTime() - a<"¤">(this, 2661471188905876868L, var3), ax) >= (long)(a * 1000.0);
      Module[] var10001 = a<"è">(2661340446177539978L, var3);
      if (var3 > 0L) {
         if (var10001 != null) {
            return var10000;
         }

         var10001 = new Module[4];
      }

      a<"è">(var10001, 2661546108742085882L, var3);
      return var10000;
   }

   public boolean A(long a, long var3) {
      x();
      return System.currentTimeMillis() - this.树树何树何树友何树树 > a;
   }

   public void L(long a) {
      a = 122936793366763L ^ a;
      a<"Ö">(this, System.nanoTime(), 6561582938285843044L, (long)a);
   }

   public boolean M(long a, long var3) {
      var3 = 122936793366763L ^ var3;
      a<"è">(-8837842813417593554L, var3);
      return System.currentTimeMillis() - a >= a<"¤">(this, -8838200458805281741L, var3);
   }

   public static long W(int a, long minCPS, int var3) {
      minCPS = (int)(122936793366763L ^ minCPS);
      a<"è">(5746504218192883656L, (long)minCPS);
      long var10000 = (long)(Math.random() * (1000.0 / a - 1000.0 / var3 + 1.0) + 1000.0 / var3);
      a<"è">(new Module[1], 5746253590280075066L, (long)minCPS);
      return var10000;
   }

   private static String HE_WEI_LIN() {
      return "何建国230622195906030014";
   }

   public static void Q(Module[] var0) {
      友树友树树何何友树友 = var0;
   }
}
