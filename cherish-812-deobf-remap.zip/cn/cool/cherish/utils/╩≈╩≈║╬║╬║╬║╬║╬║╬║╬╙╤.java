package cn.cool.cherish.utils;

import cn.cool.cherish.module.何树何何树何友何何何;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public enum 树树何何何何何何何友 implements  {
   何树树树友树友友友树,
   友何树何树何树友友何,
   何何友树友何何友树树,
   树友何何友树树树树何,
   友友友友树树树何友树;

   private static final long a;
   private static final Object[] b = new Object[9];
   private static final String[] c = new String[9];
   private static int _何炜霖国企变私企 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // $VF: Failed to inline enum fields
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2897332959312586538L, 7358972866085844899L, MethodHandles.lookup().lookupClass()).a(50492965844202L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var1;
      Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(137471257516993L << var2 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var0 = new String[5];
      int var6 = 0;
      String var5 = "\u0006,\u0085ÞØW¬I\bsM{¿\u0004<1\u009f\u0010£f\u0014\b;]vZwæ \u0004ò\u008dÿF";
      byte var7 = 34;
      char var4 = '\b';
      int var9 = -1;

      label28:
      while (true) {
         String var11 = var5.substring(++var9, var9 + var4);
         byte var10001 = -1;

         while (true) {
            String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var0[var6++] = var17;
                  if ((var9 += var4) >= var7) {
                     何树树树友树友友友树 = new 树树何何何何何何何友();
                     友何树何树何树友友何 = new 树树何何何何何何何友();
                     何何友树友何何友树树 = new 树树何何何何何何何友();
                     树友何何友树树树树何 = new 树树何何何何何何何友();
                     友友友友树树树何友树 = new 树树何何何何何何何友();
                     return;
                  }

                  var4 = var5.charAt(var9);
                  break;
               default:
                  var0[var6++] = var17;
                  if ((var9 += var4) < var7) {
                     var4 = var5.charAt(var9);
                     continue label28;
                  }

                  var5 = "åÝÜrôóÄø$\fØÇVû`é\u0010\u0087i&Ré\u0093Myzè|FÉªÏ\u0010";
                  var7 = 33;
                  var4 = 16;
                  var9 = -1;
            }

            var11 = var5.substring(++var9, var9 + var4);
            var10001 = 0;
         }
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'P' && var8 != 'N' && var8 != 231 && var8 != 196) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'T') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 206) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'P') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'N') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 231) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/树树何何何何何何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 44;
               case 1 -> 52;
               case 2 -> 58;
               case 3 -> 29;
               case 4 -> 14;
               case 5 -> 39;
               case 6 -> 23;
               case 7 -> 10;
               case 8 -> 50;
               case 9 -> 60;
               case 10 -> 24;
               case 11 -> 48;
               case 12 -> 51;
               case 13 -> 32;
               case 14 -> 53;
               case 15 -> 49;
               case 16 -> 42;
               case 17 -> 47;
               case 18 -> 6;
               case 19 -> 41;
               case 20 -> 27;
               case 21 -> 15;
               case 22 -> 3;
               case 23 -> 28;
               case 24 -> 37;
               case 25 -> 61;
               case 26 -> 36;
               case 27 -> 0;
               case 28 -> 33;
               case 29 -> 46;
               case 30 -> 40;
               case 31 -> 57;
               case 32 -> 30;
               case 33 -> 5;
               case 34 -> 31;
               case 35 -> 17;
               case 36 -> 63;
               case 37 -> 13;
               case 38 -> 25;
               case 39 -> 2;
               case 40 -> 62;
               case 41 -> 19;
               case 42 -> 4;
               case 43 -> 21;
               case 44 -> 16;
               case 45 -> 26;
               case 46 -> 55;
               case 47 -> 45;
               case 48 -> 43;
               case 49 -> 35;
               case 50 -> 8;
               case 51 -> 9;
               case 52 -> 18;
               case 53 -> 20;
               case 54 -> 22;
               case 55 -> 7;
               case 56 -> 56;
               case 57 -> 34;
               case 58 -> 11;
               case 59 -> 54;
               case 60 -> 38;
               case 61 -> 12;
               case 62 -> 59;
               default -> 1;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "MI\u0004\u0005O>B\tI\u000eE#GTBHU%GKYH栱桀佻佲使伳併伄佻召";
      b[1] = "j6\u0012kI]^\u0015\u001d+\u0004VT\b\u0018v\u000f\u0010D\u000e\u0018i\u0014\u0010栠桫伤佐伲佫佤伯伤収\\";
      b[2] = "]Q<3U*V^-|4$]U)&";
      b[3] = "/Yc*k\u0007*\f7E又厩厅厥桅桜栒伷厅桿\\,4U)\u00061)a\u0001";
      b[4] = "\u0013yU\u001d\u007f<\u0016,\u0001r叜厒伧伛伷伯叜伌厹伛jK/7\u001a;\u001a\u0019.3\b";
      b[5] = "\u0013I{~QP\u0016\u001c/\u0011栨叾伧伫厇栈栨栤档伫Dx\u000e\u0002\u0015\u0016)}[V";
      b[6] = "\n5[\"\u001f\u0006\u000f`\u000fM伢伶厠栓厧伐伢厨桺栓d$@T\fj\t!\u0015\u0000";
      b[7] = "\u001e\u0015<y+a\u001b@h\u0016伖栕桮栳叀栏厈叏厴栳\u0003\u007ft3\u0018Jnz!g";
      b[8] = "A<X4\r\u001dDi\f[厮伭栱佞桾伆桴厳叫佞g2ROGc\n7\u0007\u001b";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public static 树树何何何何何何何友 z(String a) {
      return Enum.valueOf(树树何何何何何何何友.class, a);
   }

   public static 树树何何何何何何何友[] r(long var0) {
      var0 = 140220162065795L ^ var0;
      return (树树何何何何何何何友[])a<"ç">(-3298264248965938980L, var0).clone();
   }

   private static String HE_DA_WEI() {
      return "何大伟：我要教育何炜霖";
   }
}
