package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 友何友树何何友何友树 extends 友何友树树树树何树友 implements 何树友 {
   private static final long b;
   private static final Object[] e = new Object[13];
   private static final String[] f = new String[13];
   private static int _何树友为什么濒天了 _;

   public 友何友树何何友何友树(short a, short a, int ms, int a, double endPoint) {
      long ax = ((long)a << 48 | (long)a << 48 >>> 16 | (long)a << 32 >>> 32) ^ b ^ 105309427671024L;
      super(ms, ax, 360.0);
   }

   public 友何友树何何友何友树(long a, int ms, double endPoint, 友何友树树树友树何友 direction) {
      long ax = b ^ a ^ 41018330013198L;
      super(0, 0.0, ax, direction);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(2217263864982427155L, 5007346138641963171L, MethodHandles.lookup().lookupClass()).a(279621296560813L);
      // $VF: monitorexit
      b = var10000;
      b();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 3;
               case 1 -> 49;
               case 2 -> 37;
               case 3 -> 36;
               case 4 -> 22;
               case 5 -> 47;
               case 6 -> 34;
               case 7 -> 62;
               case 8 -> 41;
               case 9 -> 32;
               case 10 -> 56;
               case 11 -> 27;
               case 12 -> 20;
               case 13 -> 57;
               case 14 -> 8;
               case 15 -> 1;
               case 16 -> 30;
               case 17 -> 33;
               case 18 -> 24;
               case 19 -> 39;
               case 20 -> 35;
               case 21 -> 54;
               case 22 -> 12;
               case 23 -> 31;
               case 24 -> 59;
               case 25 -> 42;
               case 26 -> 63;
               case 27 -> 58;
               case 28 -> 43;
               case 29 -> 6;
               case 30 -> 53;
               case 31 -> 17;
               case 32 -> 45;
               case 33 -> 61;
               case 34 -> 2;
               case 35 -> 55;
               case 36 -> 60;
               case 37 -> 11;
               case 38 -> 40;
               case 39 -> 15;
               case 40 -> 14;
               case 41 -> 52;
               case 42 -> 16;
               case 43 -> 48;
               case 44 -> 18;
               case 45 -> 29;
               case 46 -> 10;
               case 47 -> 44;
               case 48 -> 0;
               case 49 -> 25;
               case 50 -> 38;
               case 51 -> 23;
               case 52 -> 5;
               case 53 -> 26;
               case 54 -> 19;
               case 55 -> 51;
               case 56 -> 9;
               case 57 -> 50;
               case 58 -> 7;
               case 59 -> 46;
               case 60 -> 28;
               case 61 -> 21;
               case 62 -> 4;
               default -> 13;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void b() {
      e[0] = "i\u0000\u0019\u0012\u00078f@T\u0019\r%c\u001d__\u001d#c\u0002D_\t9c\u0003V\u0005\u00018d\u001d\u0019厺伽厜栛伻佢厺伽厜栛";
      e[1] = "pb\\ha\u000b{mM'\u001d\u0012twCd*\"b`Oy;\u000eum";
      e[2] = "RE\u001f255]\u0005R9?(XXY\u007f75U^]4t\u0017^OD=?";
      e[3] = boolean.class;
      f[3] = "java/lang/Boolean";
      e[4] = "\u001bh-ds\u0014\u0014(`oy\t\u0011uk)i\u000f\u0011jp)}\u0015\u0011kbsu\u0014\u0016u-佒佉厰桩反栒双栍桪伭";
      e[5] = "\nG";
      e[6] = void.class;
      f[6] = "java/lang/Void";
      e[7] = "uq";
      e[8] = "\u0002$\u0006CGN\t+\u0017\f&@\u0002 \u0013V";
      e[9] = "\f;yr+lJ2*\u001f2\u000b\u000bfyo)kQdxz[2\n<km;h\b=~\u001f";
      e[10] = "r< &M4pm} tQI=y=H`p~w%D\ru`\u007f>L`yj4{t";
      e[11] = "`(_\u0005u:by\u0002\u0003LI[)\u0006\u001epnbj\b\u0006|\u0003";
      e[12] = "^__&&=\u0002\u0014\f8Y*g\u001f\u000e33&^K\tagG";
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'b' && var8 != 223 && var8 != 210 && var8 != 199) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 195) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 231) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'b') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 210) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/友何友树何何友何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   protected double W(double a, long var3) {
      b<"ç">(5784801180111257063L, var3);
      double var10000 = -2.0 * Math.pow((double)a, 3.0) + 3.0 * Math.pow((double)a, 2.0);
      byte var10001 = b<"ç">(5784385621700007245L, var3);
      if (var3 > 0L) {
         if (var10001 != 0) {
            return var10000;
         }

         var10001 = 5;
      }

      b<"ç">(new int[var10001], 5784846457693328341L, var3);
      return var10000;
   }

   private static String LIU_YA_FENG() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
