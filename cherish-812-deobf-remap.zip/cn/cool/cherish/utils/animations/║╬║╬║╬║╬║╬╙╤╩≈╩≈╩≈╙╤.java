package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class 何何何何何友树树树友 implements 何树友 {
   public 友何何何友何友何何何 友友友友友友友树何何;
   protected int 友友友何友友友友树何;
   protected double 友树何何友友树何何友;
   protected 友何树友树何何友树树 何何何友树友何友友树;
   private static int 何何树友树友友友何何;
   private static final long a;
   private static final Object[] c = new Object[18];
   private static final String[] d = new String[18];
   private static int _何炜霖黑水 _;

   public 何何何何何友树树树友(int a, short a, int ms, char a, double endPoint) {
      long ax = ((long)a << 32 | (long)a << 48 >>> 32 | (long)a << 48 >>> 48) ^ 110996213938582L;
      long axx = ax ^ 65618830749890L;
      this(ms, endPoint, a<"Ï">(-3980412661653696580L, ax), axx);
   }

   public 何何何何何友树树树友(int ms, double endPoint, 友何树友树何何友树树 direction, long a) {
      a = 110996213938582L ^ a;
      long ax = a ^ 76884891001242L;
      super();
      a<"Ø">(this, new 友何何何友何友何何何(ax), 113006983081798007L, a);
      a<"Ø">(this, ms, 114775986062869331L, a);
      a<"Ø">(this, endPoint, 114632428951477166L, a);
      a<"Ø">(this, direction, 114433058346262923L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6410962718573159428L, 2733924278838271067L, MethodHandles.lookup().lookupClass()).a(223505017527914L);
      // $VF: monitorexit
      a = var10000;
      b();
      if (U() != 0) {
         Z(37);
      }
   }

   public double B(long a) {
      a = 110996213938582L ^ a;
      long ax = a ^ 6160100752867L;
      return 1.0
         - (double)a<"D">(this, -4367058743694365821L, (long)a).R(ax)
            / a<"D">(this, -4367462134999023193L, (long)a)
            * a<"D">(this, -4367596758624413350L, (long)a);
   }

   public double D(long a) {
      int ax = U();
      if (this.何何何友树友何友友树.P(84496296048692L)) {
         if (this.U(108461126752643L)) {
            return this.友树何何友友树何何友;
         } else {
            double var15 = (double)this.友友友友友友友树何何.R(24887154065026L) / this.友友友何友友友友树何;
            Object[] var16 = new Object[]{null, 51024861930756L};
            var16[0] = var15;
            return this.v(var16) * this.友树何何友友树何何友;
         }
      } else {
         int var10000 = this.U(108461126752643L);
         if (ax == 0) {
            if (var10000 != 0) {
               return 0.0;
            }

            var10000 = this.H(new Object[0]);
         }

         if (ax == 0) {
            if (var10000 == 0) {
               double var10002 = (double)this.友友友友友友友树何何.R(24887154065026L) / this.友友友何友友友友树何;
               Object[] var10005 = new Object[]{null, 51024861930756L};
               var10005[0] = var10002;
               return (1.0 - this.v(var10005)) * this.友树何何友友树何何友;
            }

            var10000 = this.友友友何友友友友树何;
         }

         double revTime = Math.min((long)var10000, Math.max(0L, this.友友友何友友友友树何 - this.友友友友友友友树何何.R(24887154065026L)));
         double var10001 = revTime / this.友友友何友友友友树何;
         Object[] var10004 = new Object[]{null, 51024861930756L};
         var10004[0] = var10001;
         return this.v(var10004) * this.友树何何友友树何何友;
      }
   }

   public static int I() {
      return 何何树友树友友友何何;
   }

   public static void Z(int var0) {
      何何树友树友友友何何 = var0;
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static void b() {
      c[0] = "\u0019\rG!Tp\u0016M\n*^m\u0013\u0010\u0001lNk\u0013\u000f\u001alZq\u0013\u000e\b6Rp\u0014\u0010G众佮佊伯伶厢桓株栎厱";
      c[1] = int.class;
      d[1] = "java/lang/Integer";
      c[2] = double.class;
      d[2] = "java/lang/Double";
      c[3] = "'\u001b\t|\u001d@([Dw\u0017]-\u0006O1\u0007[-\u0019T1\u0013A-\u0018Fk\u001b@*\u0006\t叔伧佺休厾佲叔伧佺休";
      c[4] = "X\u0007V\u001a\u0005}WG\u001b\u0011\u000f`R\u001a\u0010W\u001ffR\u0005\u000bW\u000b|R\u0004\u0019\r\u0003}U\u001aV厲伿栃台桸伭伬厡栃株";
      c[5] = " &cGOO+)r\b3V$3|K\u0004f2$pV\u0015J%)";
      c[6] = void.class;
      d[6] = "java/lang/Void";
      c[7] = "\u0012M2*\u0012[\u0019B#esU\u0012I'?";
      c[8] = "$\u0011JD\u000fEt\f\n|厽桬佈伣厶县桧伨佈厽uE\u0006Ng\u0017\u000b\u001dE\u0017x";
      c[9] = "\f\u0018/\u0011lOQ\bwS\u0016栯栮厲栉厩佋栯叴伬位j-_\b\nj\u0013pOPH";
      c[10] = "cN*\u0014\u000b\u000b3Sj,厹司厑佼取可厹司桋佼\u0015\u0015CY<\u0010vU\u0011\u00051";
      c[11] = "[\u0011-P \u000e\u000b\fmh\f>SGp\u0006`]\u0013\u0015,\u000bQ";
      c[12] = "=f+IgFm{kqDv50v\u001f'\u0015ub*\u0012\u0016J2k~\b-Jh0\u007fq";
      c[13] = "5\u001dO~Kxe\u0000\u000fF{H=K\u0012(\u000b+}\u0019N%:";
      c[14] = "@4\f\u0003u\u0007\u001d$TA\u000f桧桢伀株伥栖伣伦厞台x4\u0017D&I\u0001i\u0007\u001cd";
      c[15] = "\b*miiVX7-Q佅伻佤历桋厒佅厥叺桜RjqYB?+7a\u0001\u0000";
      c[16] = "rO\u0010$b\u0014\"RP\u001c叐叧厀口召叟叐栽伞佽/&/\u001f'EAea\u0018!";
      c[17] = "<7\t2/\"l*I\n4\u00121cYr:m<:Fe^.67Nn!#o(Y\n";
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public void b(boolean a, long a) {
      a = 110996213938582L ^ a;
      long ax = a ^ 123829453352809L;
      a<"¤">(5695087851222052063L, a);
      this.n(a<"Ï">(5695328288199575671L, a), ax);
      if (a > 0L) {
         this.n(a<"Ï">(5694827783226628293L, a), ax);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public 何何何何何友树树树友 n(友何树友树何何友树树 a, long direction) {
      U();
      if (this.何何何友树友何友友树 != a) {
         this.何何何友树友何友友树 = a;
         this.友友友友友友友树何何
            .z(System.currentTimeMillis() - (this.友友友何友友友友树何 - Math.min((long)this.友友友何友友友友树何, this.友友友友友友友树何何.R(24887154065026L))), 26426960096961L);
      }

      return this;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   public void d(long a) {
      a = 110996213938582L ^ a;
      long ax = a ^ 7760774052809L;
      long axx = a ^ 37425044099943L;
      this.n(a<"D">(this, 1993337256864873396L, (long)a).R(axx), ax);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (d[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 15;
               case 1 -> 54;
               case 2 -> 5;
               case 3 -> 2;
               case 4 -> 32;
               case 5 -> 6;
               case 6 -> 13;
               case 7 -> 39;
               case 8 -> 4;
               case 9 -> 51;
               case 10 -> 33;
               case 11 -> 47;
               case 12 -> 44;
               case 13 -> 27;
               case 14 -> 26;
               case 15 -> 62;
               case 16 -> 21;
               case 17 -> 61;
               case 18 -> 42;
               case 19 -> 3;
               case 20 -> 17;
               case 21 -> 11;
               case 22 -> 38;
               case 23 -> 14;
               case 24 -> 16;
               case 25 -> 18;
               case 26 -> 24;
               case 27 -> 53;
               case 28 -> 10;
               case 29 -> 55;
               case 30 -> 1;
               case 31 -> 40;
               case 32 -> 25;
               case 33 -> 46;
               case 34 -> 31;
               case 35 -> 59;
               case 36 -> 57;
               case 37 -> 35;
               case 38 -> 7;
               case 39 -> 43;
               case 40 -> 37;
               case 41 -> 58;
               case 42 -> 22;
               case 43 -> 63;
               case 44 -> 56;
               case 45 -> 41;
               case 46 -> 19;
               case 47 -> 30;
               case 48 -> 36;
               case 49 -> 0;
               case 50 -> 28;
               case 51 -> 29;
               case 52 -> 50;
               case 53 -> 52;
               case 54 -> 20;
               case 55 -> 45;
               case 56 -> 9;
               case 57 -> 8;
               case 58 -> 34;
               case 59 -> 49;
               case 60 -> 48;
               case 61 -> 12;
               case 62 -> 60;
               default -> 23;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            d[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/何何何何何友树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'D' && var8 != 216 && var8 != 207 && var8 != 'O') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'A') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 164) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'D') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 216) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 207) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public boolean a(long a) {
      a = 110996213938582L ^ a;
      long ax = a ^ 68085246817462L;
      return a<"D">(this, 8247936883691623019L, (long)a).f(ax);
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public 友何树友树何何友树树 m(long a) {
      return this.何何何友树友何友友树;
   }

   public void p(double a, long var3) {
      var3 = 110996213938582L ^ var3;
      a<"Ø">(this, (double)a, 7060322414580005826L, var3);
   }

   protected abstract double v(double var1, long var3);

   public static int U() {
      I();

      try {
         return 86;
      } catch (RuntimeException var0) {
         throw b(var0);
      }
   }

   public boolean U(long a) {
      return this.友友友友友友友树何何.Z(this.友友友何友友友友树何, 134456991975300L);
   }

   public void w(long a, int var3) {
      this.友友友何友友友友树何 = 400;
   }

   public boolean E(long a) {
      a = 110996213938582L ^ a;
      long ax = a ^ 139732298343046L;
      return a<"D">(this, 6535216480004749996L, (long)a).P(ax);
   }

   public boolean A(long a, 友何树友树何何友树树 var3) {
      U();
      return this.U(108461126752643L) && this.何何何友树友何友友树.equals(var3);
   }

   public static float A(float a, long a, float speed, float current) {
      a = 110996213938582L ^ a;
      int ax = a<"¤">(3995136961849853361L, a);
      if (speed == a) {
         return speed;
      } else {
         boolean larger;
         float var13;
         label68: {
            label74: {
               larger = a > speed;
               if (current < 0.0F) {
                  var13 = 0.0F;
                  if (a <= 0L) {
                     break label74;
                  }

                  current = 0.0F;
               }

               var13 = current;
               if (a < 0L) {
                  break label68;
               }

               if (current > 1.0F) {
                  current = 1.0F;
               }

               var13 = Math.max((float)a, speed);
            }

            var13 -= Math.min((float)a, speed);
         }

         double dif = var13;
         double factor = dif * current;
         double var19;
         int var14 = (var19 = factor - 0.1) == 0.0 ? 0 : (var19 < 0.0 ? -1 : 1);
         int var10001 = ax;
         if (a >= 0L) {
            if (ax == 0) {
               if (var14 < 0) {
                  factor = 0.1;
               }

               var14 = larger;
            }

            var10001 = ax;
         }

         if (var10001 == 0) {
            if (var14 != 0) {
               var13 = speed;
               float var17 = (float)factor;
               if (a >= 0L) {
                  speed += var17;
                  var13 = speed;
                  var17 = (float)a;
               }

               if (!(var13 >= var17)) {
                  return speed;
               }

               speed = (float)a;
               if (a >= 0L) {
               }
            }

            float var20;
            var14 = (var20 = a - speed) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
         }

         if (var14 < 0) {
            var13 = speed;
            float var18 = (float)factor;
            if (a > 0L) {
               speed -= var18;
               var13 = speed;
               var18 = (float)a;
            }

            if (var13 <= var18) {
               speed = (float)a;
            }
         }

         return speed;
      }
   }

   public void L(long a) {
      a = 110996213938582L ^ a;
      long ax = a ^ 59170441948837L;
      a<"D">(this, -9137155291151980076L, (long)a).c(ax);
   }

   public double L(long a) {
      a = 110996213938582L ^ a;
      return a<"D">(this, 2195268076700795982L, (long)a);
   }

   protected boolean H(Object[] var1) {
      return false;
   }

   private static String HE_JIAN_GUO() {
      return "职业技术教育中心学校";
   }
}
