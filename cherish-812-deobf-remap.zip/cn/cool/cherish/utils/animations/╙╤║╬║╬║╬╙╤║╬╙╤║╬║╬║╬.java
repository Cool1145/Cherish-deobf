package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 友何何何友何友何何何 implements 何树友 {
   public long 友友友友树友何友何何;
   private static final long a;
   private static final Object[] b = new Object[10];
   private static final String[] c = new String[10];
   private static String HE_DA_WEI;

   public 友何何何友何友何何何(long a) {
      a = 128299920177259L ^ a;
      super();
      a<"Ô">(this, System.currentTimeMillis(), 6369713144807108741L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8087970562993286373L, -5519999823642096243L, MethodHandles.lookup().lookupClass()).a(148726020412825L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public boolean Z(long a, long var3) {
      var3 = 128299920177259L ^ var3;
      a<"d">(4606881495597088235L, var3);
      return System.currentTimeMillis() - a<"ñ">(this, 4606765371183486734L, var3) > a;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public void c(long a) {
      a = 128299920177259L ^ a;
      a<"Ô">(this, System.currentTimeMillis(), 6339241479752924953L, (long)a);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 241 && var8 != 212 && var8 != 226 && var8 != 235) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 162) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'd') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 241) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 226) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/友何何何友何友何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 56;
               case 1 -> 63;
               case 2 -> 61;
               case 3 -> 52;
               case 4 -> 42;
               case 5 -> 48;
               case 6 -> 7;
               case 7 -> 15;
               case 8 -> 22;
               case 9 -> 16;
               case 10 -> 40;
               case 11 -> 43;
               case 12 -> 11;
               case 13 -> 31;
               case 14 -> 36;
               case 15 -> 4;
               case 16 -> 14;
               case 17 -> 18;
               case 18 -> 51;
               case 19 -> 38;
               case 20 -> 10;
               case 21 -> 54;
               case 22 -> 20;
               case 23 -> 19;
               case 24 -> 46;
               case 25 -> 0;
               case 26 -> 37;
               case 27 -> 21;
               case 28 -> 41;
               case 29 -> 44;
               case 30 -> 33;
               case 31 -> 50;
               case 32 -> 24;
               case 33 -> 32;
               case 34 -> 28;
               case 35 -> 17;
               case 36 -> 30;
               case 37 -> 59;
               case 38 -> 53;
               case 39 -> 58;
               case 40 -> 35;
               case 41 -> 8;
               case 42 -> 47;
               case 43 -> 12;
               case 44 -> 2;
               case 45 -> 60;
               case 46 -> 26;
               case 47 -> 27;
               case 48 -> 39;
               case 49 -> 57;
               case 50 -> 62;
               case 51 -> 25;
               case 52 -> 49;
               case 53 -> 3;
               case 54 -> 45;
               case 55 -> 23;
               case 56 -> 9;
               case 57 -> 29;
               case 58 -> 55;
               case 59 -> 34;
               case 60 -> 5;
               case 61 -> 13;
               case 62 -> 1;
               default -> 6;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "\u001ek~\bO\u0010\u0011+3\u0003E\r\u0014v8EU\u000b\u0014i#EA\u0011\u0014h1\u001fI\u0010\u0013v~厠併伪伨収伅厠併伪伨";
      b[1] = long.class;
      c[1] = "java/lang/Long";
      b[2] = "\\|- asS<`+knVakm{hV~pmorV\u007fb7gsQa-伖佛佉佪佇又桒栟栍叴";
      b[3] = int.class;
      c[3] = "java/lang/Integer";
      b[4] = "I\u0014 \n\u0004\u0006B\u001b1Ex\u001fM\u0001?\u0006O/[\u00163\u001b^\u0003L\u001b";
      b[5] = "\u000e[L'\u0013r\u0005T]hr|\u000e_Y2";
      b[6] = "O'\f]X!^|\re叾厎另叞株厦你厎佸佀3\\\u0001'\u0018\"^\u0006\u0001qL";
      b[7] = "<4,#\u0018\u0013bc%8s2\u0005i3i\u0010Jxh!3\u0016s";
      b[8] = "?$\u001d\u001b\u0002Was\u0014\u0000ij\u0006y\u0002Q\n\u000e{x\u0010\u000b\f7";
      b[9] = "='-N\u0019\u0012,|,v\u0015~l!b\t\u001c\u00152${F|Ekmm\u0016\u0017\u001bnt\"v";
   }

   public void z(long a, long var3) {
      var3 = 128299920177259L ^ var3;
      a<"Ô">(this, (long)a, 1633653217920908875L, var3);
   }

   public boolean u(long a, boolean time, long var4) {
      var4 = 128299920177259L ^ var4;
      long ax = var4 ^ 78610981062567L;
      a<"d">(-1714174246760883465L, var4);
      if (System.currentTimeMillis() - a<"ñ">(this, -1714269172450950955L, var4) > a) {
         if (time) {
            this.c(ax);
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean H(long a, double var3) {
      long ax = 128299920177259L ^ a ^ 2119350492814L;
      return this.Z((long)var3, ax);
   }

   public long R(long a) {
      a = 128299920177259L ^ a;
      return System.currentTimeMillis() - a<"ñ">(this, -8725468808003523064L, (long)a);
   }

   private static String LIU_YA_FENG() {
      return "何炜霖国企变私企";
   }
}
