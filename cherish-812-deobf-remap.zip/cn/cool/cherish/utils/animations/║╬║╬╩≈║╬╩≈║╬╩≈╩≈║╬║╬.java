package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 何何树何树何树树何何 implements 何树友 {
   private float 树何何友何树友友树友;
   private float 树友树何友树树何何友;
   private 何何何何何友树树树友 何何友树何树树树友友 = new 树何何树友友树何友友(17139344825231L, 0, 0.0, 友何树友树何何友树树.树树友树友何树友何何);
   private static Module[] 何友友友树树树友友何;
   private static final long a;
   private static final Object[] b = new Object[22];
   private static final String[] c = new String[22];
   private static String HE_WEI_LIN;

   public 何何树何树何树树何何(short a, int a, int a) {
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-4181278374207918652L, 2879082768123615981L, MethodHandles.lookup().lookupClass()).a(194576971920489L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (I() == null) {
         S(new Module[1]);
      }
   }

   public static Module[] I() {
      return 何友友友树树树友友何;
   }

   public static void S(Module[] var0) {
      何友友友树树树友友何 = var0;
   }

   public float S(long a) {
      this.树何何友何树友友树友 = (float)(this.树友树何友树树何何友 - this.何何友树何树树树友友.D(124111691745592L));
      return this.树何何友何树友友树友;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/何何树何树何树树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'Q' && var8 != 207 && var8 != 'T' && var8 != 233) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'G') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == '$') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'Q') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 207) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'T') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 52;
               case 1 -> 58;
               case 2 -> 56;
               case 3 -> 19;
               case 4 -> 33;
               case 5 -> 35;
               case 6 -> 21;
               case 7 -> 16;
               case 8 -> 63;
               case 9 -> 25;
               case 10 -> 7;
               case 11 -> 46;
               case 12 -> 5;
               case 13 -> 13;
               case 14 -> 39;
               case 15 -> 9;
               case 16 -> 4;
               case 17 -> 47;
               case 18 -> 12;
               case 19 -> 36;
               case 20 -> 49;
               case 21 -> 34;
               case 22 -> 38;
               case 23 -> 27;
               case 24 -> 32;
               case 25 -> 15;
               case 26 -> 29;
               case 27 -> 17;
               case 28 -> 44;
               case 29 -> 45;
               case 30 -> 42;
               case 31 -> 51;
               case 32 -> 37;
               case 33 -> 8;
               case 34 -> 40;
               case 35 -> 54;
               case 36 -> 59;
               case 37 -> 43;
               case 38 -> 61;
               case 39 -> 53;
               case 40 -> 41;
               case 41 -> 6;
               case 42 -> 14;
               case 43 -> 3;
               case 44 -> 11;
               case 45 -> 1;
               case 46 -> 23;
               case 47 -> 50;
               case 48 -> 31;
               case 49 -> 57;
               case 50 -> 10;
               case 51 -> 24;
               case 52 -> 22;
               case 53 -> 2;
               case 54 -> 62;
               case 55 -> 18;
               case 56 -> 28;
               case 57 -> 30;
               case 58 -> 60;
               case 59 -> 20;
               case 60 -> 26;
               case 61 -> 0;
               case 62 -> 48;
               default -> 55;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      b[0] = "\u0007Z[v@\u0011\b\u001a\u0016}J\f\rG\u001d;Z\n\rX\u0006;N\u0010\rY\u0014aF\u0011\nG[佀佺桯伱栥传栄栾伫伱";
      b[1] = float.class;
      c[1] = "java/lang/Float";
      b[2] = "-l'j^I&c6%\"P)y8f\u0015`?n4{\u0004L(c";
      b[3] = "8D\u0001HO\u00117\u0004LCE\f2YG\u0005U\n2F\\\u0005A\u00102GN_I\u00115Y\u0001佾併伫伎使古栺栱桯厐";
      b[4] = int.class;
      c[4] = "java/lang/Integer";
      b[5] = "|\ri\u001d2EsM$\u00168Xv\u0010/P(^v\u000f4P<Dv\u000e&\n4Eq\u0010i厵伈栻叔桲伒伫厖栻栎";
      b[6] = "B+\"!\"hMko*(uH6dl hE0`'cJN!y.(";
      b[7] = "YIZ!)\u000emjUad\u0005gwP<oCoj]:k\b,HV+r\u0001g>";
      b[8] = void.class;
      c[8] = "java/lang/Void";
      b[9] = "g\u0001\rd\u0000QS\"\u0002$MZY?\u0007yF\u001cQ\"\n\u007fBW\u0012\u0000\u0001n[^Yv";
      b[10] = "A.#gAKu\r,'\f@\u007f\u0010)z\u0007\u0006w\r$|\u0003M4//m\u001aD\u007fY";
      b[11] = "HW\u0016z\bHCX\u00075iFHS\u0003o";
      b[12] = " \u0017\u0014=\u001e;$L\u0007me桙栅召桦叏伸桙叟佲伢\fYxw\u001e\u0004w]#dN";
      b[13] = "D\u0016 \u001e%,@\u0017g}TW\u0012Wa\u001er;\u0011Zr\u000f\u0015";
      b[14] = "S5\u0005&\u00015\ny\u001a'{\u001ao4X \u0018/\u00037U3\tH";
      b[15] = "OZ0NhkK[w-伅位句栾佔栴桁栉句古\t\u0017?k\\]r\u0013b+W";
      b[16] = "V\u0010\u000e7/fR\u0011IT栆佀佢厮佪桍叜叞栦厮7+~,\u000eUNd~-";
      b[17] = "\u0005wr),=\u0001v5JuFUlq3\u007f}\ft31\u001c\u007f\n02)'&\u0012r0J";
      b[18] = "L\u001e\b7\t4HCH<s\u0012vBJ4\u001a5\fA\u000f1LO";
      b[19] = "zpRI@3~-\u0012B:\u001a@,\u0010JS2:/UO\u0005H}k\u0014WA#-/\u0018B:";
      b[20] = "\u00029BJ\\n\u00068\u0005)7\u0015Tx\u0003J\u000byWu\u0010[l(\u0017y\u001fR\u0007xSu\n)";
      b[21] = "&s/~\u0003/\"rh\u001d株厗桖体叕栄株伉伒反\u0016bRe~6o-Rd";
   }

   public boolean m(long a) {
      a = 56404086412384L ^ a;
      long ax = a ^ 116796084511590L;
      a<"$">(8854561560494504375L, (long)a);
      return a<"Q">(this, 8854362626502384936L, (long)a) == a<"Q">(this, 8854177334719139048L, (long)a) || a<"Q">(this, 8856008845565596671L, (long)a).U(ax);
   }

   public void g(float a, long a, int destination) {
      int var10000 = 何何何何何友树树树友.U();
      this.树何何友何树友友树友 = (float)(this.树友树何友树树何何友 - this.何何友树何树树树友友.D(124111691745592L));
      int var10 = var10000;
      this.树友树何友树树何何友 = 0.0F;
      if (this.树何何友何树友友树友 != this.树友树何友树树何何友 - a) {
         this.何何友树何树树树友友 = new 树何何树友友树何友友(17139344825231L, (int)destination, this.树友树何友树树何何友 - this.树何何友何树友友树友, 友何树友树何何友树树.树树友树友何树友何何);
      }

      if (Module.Z() == null) {
         何何何何何友树树树友.Z(++var10);
      }
   }

   public 何何何何何友树树树友 H(long a) {
      a = 56404086412384L ^ a;
      return a<"Q">(this, 3327789911678502711L, (long)a);
   }

   private static String HE_DA_WEI() {
      return "我是何树友";
   }
}
