package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import cn.cool.cherish.ui.何树友何何友友树树友;
import cn.cool.cherish.ui.友何何树友何何何何树;
import cn.cool.cherish.ui.友树友友友友友树何友;
import cn.cool.cherish.ui.树何何树何何何何友何;
import cn.cool.cherish.utils.animations.何何友树友树友树树何;
import cn.cool.cherish.utils.animations.友何友树树树树何树友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何树何友何何树树树树 extends 树树友树友友何友友树 implements 何树友 {
   public static 何树何友何何树树树树 树何树树友友友友树树;
   private final ModeValue 树友树何何友何友友友;
   private final NumberValue 树树树友何何友友友友;
   private final NumberValue 何何树友友树树树何树;
   private final NumberValue 何友树树何何友树何树;
   private final BooleanValue 何何何树友何树何何何;
   private final NumberValue 何友友何友友树树何何;
   private final NumberValue 树树友树何树树树何树;
   private final List<何树何友何何树树树树.友友何何友何树友友友> 何树友何树树树友友友;
   private final 友何友树树树树何树友 树树何何何友树友何友;
   private static String 友友友何树何友友何树;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final Object[] n = new Object[35];
   private static final String[] o = new String[35];
   private static String HE_DA_WEI;

   public 何树何友何何树树树树() {
      long a = c ^ 117738759094963L;
      long ax = a ^ 117892444903013L;
      super(c<"y">(22526, 286682336963948286L ^ a), c<"y">(15549, 3984029271323116986L ^ a), 300.0F, 150.0F);
      this.树友树何何友何友友友 = new ModeValue(
         c<"y">(3317, 8039364900751160817L ^ a),
         new String[]{
            c<"y">(15464, 5041829094261851497L ^ a),
            c<"y">(13300, 5936139019652467455L ^ a),
            c<"y">(4337, 8479751024602851826L ^ a),
            c<"y">(31154, 3521341970399543457L ^ a)
         },
         c<"y">(7163, 9146889157678768882L ^ a)
      );
      this.树树树友何何友友友友 = new NumberValue(c<"y">(14340, 4037687576649466143L ^ a), c<"y">(12794, 988735248980379882L ^ a), 10, 5, 20, 1);
      this.何何树友友树树树何树 = new NumberValue(c<"y">(8775, 6975475607611677530L ^ a), c<"y">(2270, 691031410046153154L ^ a), 14, 8, 20, 1);
      this.何友树树何何友树何树 = new NumberValue(c<"y">(25753, 3529142010962697607L ^ a), c<"y">(6271, 650663442127069547L ^ a), 80, 1, 255, 1);
      this.何何何树友何树何何何 = new BooleanValue(c<"y">(5531, 3034094236919540885L ^ a), c<"y">(18052, 7679911793009688459L ^ a), true);
      this.何友友何友友树树何何 = new NumberValue(c<"y">(24273, 6534552836770555849L ^ a), c<"y">(20650, 6911884937649711532L ^ a), 2, 0, 10, 1);
      this.树树友树何树树树何树 = new NumberValue(c<"y">(28293, 7911882978360776592L ^ a), c<"y">(2742, 2908988353113437092L ^ a), 6, 2, 12, 1);
      this.何树友何树树树友友友 = new ArrayList<>();
      this.树树何何何友树友何友 = new 何何友树友树友树树何(200, 1.0, ax, 1.0F);
      树何树树友友友友树树 = this;
      this.y(true);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2300313849329570604L, 1417999301364099999L, MethodHandles.lookup().lookupClass()).a(187757677898018L);
      // $VF: monitorexit
      c = var10000;
      long var9 = c ^ 36995636818305L;
      c();
      d<"È">("d4gKWb", -3434789887247649898L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[30];
      int var5 = 0;
      String var4 = "£J°\"v}!ßØ«U¾\u0086ÎÐJ\u0010]\u000b\u0014Ý\n.öTK\u0087\u008b\u0096 g\u001d:\u0010þ`\u00adz\u009cMîÒ\u0094r\u0099º\u0089\u008a©u\u0010\u0000\u009f\u008a$î6K'\u0002H¿îM\u0083ñä ¤¸v\u007f¨b\u0018J\u0001\u0097ãnT\u009dÔÜùÑ<¤ÖÕtY\u0091\u0088\u0014æÂá\t: \u008f\tÚ+Ysw !Ãs\u008f\u0087)\u000b5\u00ad\u0084S«\u0095/\u0080äVîAN_|]C\u0018É°aÇÊNS\u009d®´OÁ\u0002$E\u0094nî\u0019üoµ\u001e\u008d s\u0087\u0096¦\u009ftûÚ\u0082VT£:Ù*õÃýÎù)= Å\u001bÛ\u001dØ°\u000eca\u0010¹L\u0019]\u009al¥Àd\u0093À¯ñËJ\r\u0010\u0007çÝj+Í#\u00156\"\u001d\u0019\u009eÄû\u001c\u0010#C\u0014û£\u0004¿ði\fUWí±þX\u0018\u0095AÔ\u008a8ÜmE0|\u0013\n£nñ£G?H\u0014Õý=Q\u0010®\u0002Ó\u007f!:»EuØÖK\u0010wv\f\u0010+\u001eô7&\b\u0007\u0094LÍ#Ú\u0094\u008aÁ« Û\u0085PQé¶Äº*åOÔ«\u00878eâ-Â}R\u0014×4\bÿÂç\u0082H\u009c8 Ñ³\u00932\u009aÊ\u0096ó\u0007mÄüè¨\u007f\u008f\u0093T¯MT÷í»\n\u001câ&7dUy\u0010\u008cÈ\u001a\u0097tý5\u0005PÉ°y\u009b\b\u009d\u0006 E_3Fm:¸9G?ÍÔKj\u0087Úßÿn¿¸ÔM*5÷dXí\u0081\u0090\u0002\u0018\u009f\r\u008c^oG XK\tBîî.@5øê\u001a¡g\u0013À\u001b\u0018öA\u0093.B¯\u0001\u009aÚüÔ3\u001bú(oz\u008bH0\u0082üPc\u0018°f\u00ad¤¤ú7\u0006\u0098òh\u0090o\u001b(\u008däs+Û{\u0011p& G¢\\¿âk«äY=\u001e\u000eÐT\u0098\u0002Ã{ª\u0085Þ\u0013=Ä\u0092N\u0016\u0015u\u008a|\u0019\u0018Î\u0080Ð\u0096Fñ\u0015\u0007\u000bqJ\u0004\u0093qèZ£BÍU_C×^0ä³A\u001a;ê\u0089r\u0084&¯\u0086Þ¿Ó)P´·>L}ÖA 6´j5\u0014ðâØ^í]ô\u008aù;«&[\u008dã¬É° \u0084\"S%É\t\u001b`¶øÇ;ôFR\u001c\u0098à¬Õ\u000bÙ+\u0010\u0099gED¯»7V ]\u001e©õªß\u0097\u00ad\u001e\\?\u00868\u000f\u0016\u0095{B|ÄWCé\u0089,ùþ\u007f#\u0092\u0006\u009c\u0010\u008fß«²ä¬p\u0080\u009fARsÍËSò \u0019*\u0006±¨T_\u001c#grO\u0088\u0085¶ü\u0002\u001aCè¨\u0000\r·ìÀO\u0013W`{¯";
      short var6 = 715;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = d(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     k = var7;
                     l = new String[30];
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "ö\u0012o»ðð\u0012¬Ó\u0099%B\u0004Zýb;x\u009d[¨S\u0004×û\u0094ªh\u0010\u0005Øê õLO¬í\u0004\u0095R\u0003Üßa\\Y¤ê\u0087QÛz-\u0097s©û¶\u000er4ò \u007f";
                  var6 = 65;
                  var3 = ' ';
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   public static void Z(String var0) {
      友友友何树何友友何树 = var0;
   }

   private String i(int state) {
      long a = c ^ 116754152658710L;

      return switch (state) {
         case 0, 1 -> c<"y">(27970, 8142477372273705462L ^ a);
         case 2 -> c<"y">(562, 3617504452793577096L ^ a);
         case 3 -> c<"y">(7959, 6619434090749899688L ^ a);
         case 4 -> c<"y">(15541, 2355961633187106845L ^ a);
         case 5 -> c<"y">(6116, 8481844763014773581L ^ a);
         default -> c<"y">(15771, 888801908819333436L ^ a);
      };
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private String b(何树何友何何树树树树.友友何何友何树友友友 message) {
      long a = c ^ 53260159794989L;
      String prefix = this.i(d<"ë">(message, 2231723886664546895L, a));
      return prefix + c<"y">(16114, 4878740401499552373L ^ a) + d<"ë">(message, 2231647813504281244L, a);
   }

   @EventTarget
   public void x(Render2DEvent event) {
      long a = c ^ 76953374934586L;
      long ax = a ^ 22349545014631L;
      long axx = a ^ 35945214615234L;
      long axxx = a ^ 92249450172872L;
      long axxxx = a ^ 62192755562942L;
      long axxxxx = a ^ 132510311525998L;
      d<"È">(7488736472869161142L, a);
      if (!this.w(new Object[]{axx}) && event.poseStack() != null) {
         synchronized (d<"ë">(this, 7488802837920208225L, a)) {
            if (d<"ë">(this, 7488802837920208225L, a).isEmpty()) {
               d<"ë">(this, 7488466697694882234L, a).H(d<"H">(7489071069908295315L, a), axxxxx);
               if (d<"ë">(this, 7488466697694882234L, a).B(d<"H">(7489071069908295315L, a), axxx)) {
                  return;
               }
            }

            PoseStack poseStack = event.poseStack();
            友何何树友何何何何树 font = Cherish.instance.h().n(d<"ë">(this, 7488592009277760316L, a).getValue().intValue());
            this.v();
            float maxWidth = 0.0F;
            float totalHeight = 0.0F;
            Iterator animationOutput = d<"ë">(this, 7488802837920208225L, a).iterator();
            if (animationOutput.hasNext()) {
               何树何友何何树树树树.友友何何友何树友友友 message = (何树何友何何树树树树.友友何何友何树友友友)animationOutput.next();
               String displayText = this.b(message);
               float textWidth = font.A(displayText);
               maxWidth = Math.max(0.0F, textWidth);
               float messageHeight = font.K() + d<"ë">(this, 7488905698249074987L, a).getValue().floatValue();
               totalHeight = 0.0F + messageHeight;
            }

            d<"Q">(this, Math.max(200.0F, maxWidth + 16.0F), 7489314368135706356L, a);
            d<"Q">(this, Math.max(30.0F, totalHeight + 8.0F), 7485742537695485044L, a);
            float animationOutputx = (float)d<"ë">(this, 7488466697694882234L, a).T(ax);
            if (!(animationOutputx <= 0.001F)) {
               poseStack.pushPose();
               poseStack.scale(animationOutputx, animationOutputx, 1.0F);
               float alphaMultiplier = d<"ë">(this, 7488466697694882234L, a).Y(axxxx) == d<"H">(7489071069908295315L, a) ? animationOutputx : 1.0F;
               alphaMultiplier = Math.max(0.0F, Math.min(1.0F, alphaMultiplier));
               String var35 = d<"ë">(this, 7489396494960797135L, a).getValue();
               byte var36 = -1;
               switch (var35.hashCode()) {
                  case -1955878649:
                     if (!var35.equals(c<"y">(7889, 903758931518776144L ^ a))) {
                        break;
                     }

                     var36 = 0;
                  case -1819712192:
                     if (!var35.equals(c<"y">(29978, 7890406857792981142L ^ a))) {
                        break;
                     }

                     var36 = 1;
                  case 68884316:
                     if (!var35.equals(c<"y">(7163, 9146927194544203387L ^ a))) {
                        break;
                     }

                     var36 = 2;
                  case 79183:
                     if (var35.equals(c<"y">(11193, 1221572006453990970L ^ a))) {
                        var36 = 3;
                     }
               }

               switch (var36) {
                  case 0:
                     何树友何何友友树树友.L(
                        poseStack,
                        this.r(),
                        this.v(),
                        d<"ë">(this, 7489314368135706356L, a),
                        d<"ë">(this, 7485742537695485044L, a),
                        d<"ë">(this, 7488802837920208225L, a),
                        alphaMultiplier,
                        d<"ë">(this, 7488592009277760316L, a).getValue().intValue(),
                        d<"ë">(this, 7489143436332972314L, a).getValue(),
                        d<"ë">(this, 7488905698249074987L, a).getValue().floatValue(),
                        d<"ë">(this, 7488533326608643324L, a).getValue().intValue(),
                        d<"ë">(this, 7488361297999643564L, a).getValue().floatValue(),
                        this
                     );
                  case 1:
                     友树友友友友友树何友.X(
                        poseStack,
                        this.r(),
                        this.v(),
                        d<"ë">(this, 7489314368135706356L, a),
                        d<"ë">(this, 7485742537695485044L, a),
                        d<"ë">(this, 7488802837920208225L, a),
                        alphaMultiplier,
                        d<"ë">(this, 7488592009277760316L, a).getValue().intValue(),
                        d<"ë">(this, 7489143436332972314L, a).getValue(),
                        d<"ë">(this, 7488905698249074987L, a).getValue().floatValue(),
                        d<"ë">(this, 7488533326608643324L, a).getValue().intValue(),
                        d<"ë">(this, 7488361297999643564L, a).getValue().floatValue(),
                        this
                     );
                  case 2:
                     树何何树何何何何友何.b(
                        poseStack,
                        this.r(),
                        this.v(),
                        d<"ë">(this, 7489314368135706356L, a),
                        d<"ë">(this, 7485742537695485044L, a),
                        d<"ë">(this, 7488802837920208225L, a),
                        alphaMultiplier,
                        d<"ë">(this, 7488592009277760316L, a).getValue().intValue(),
                        d<"ë">(this, 7489143436332972314L, a).getValue(),
                        d<"ë">(this, 7488905698249074987L, a).getValue().floatValue(),
                        d<"ë">(this, 7488533326608643324L, a).getValue().intValue(),
                        d<"ë">(this, 7488361297999643564L, a).getValue().floatValue(),
                        this
                     );
                  case 3:
                     友何何树友何何何何树 fontDrawer = Cherish.instance.h().n(d<"ë">(this, 7488592009277760316L, a).getValue().intValue());
                     float currentTextY = this.v();
                     Iterator var27 = d<"ë">(this, 7488802837920208225L, a).iterator();
                     if (var27.hasNext()) {
                        何树何友何何树树树树.友友何何友何树友友友 message = (何树何友何何树树树树.友友何何友何树友友友)var27.next();
                        String displayText = this.b(message);
                        fontDrawer.y(poseStack, displayText, this.r() + 8.0F, currentTextY + 4.0F, -1, d<"ë">(this, 7489143436332972314L, a).getValue());
                        float var10000 = currentTextY + (fontDrawer.K() + d<"ë">(this, 7488905698249074987L, a).getValue().floatValue());
                     }
                  default:
                     poseStack.popPose();
               }
            }
         }
      }
   }

   private static void c() {
      n[0] = "wd0\f_Yx$}\u0007UD}yvA]Yp\u007fr\n\u001e_yzrAT_gzr\u000eI\u0018佁栛佋厤佥佣栅栛栏桾\u0014叽叟佟佋厤佥栧叟叁叕";
      n[1] = "\u0016u_u,]\u001dzN:QE\u000e}Gs";
      n[2] = int.class;
      o[2] = "java/lang/Integer";
      n[3] = "\u001a\u0011]MGb\u0015Q\u0010FM\u007f\u0010\f\u001b\u0000Eb\u001d\n\u001fK\u0006d\u0014\u000f\u001f\u0000Ld\n\u000f\u001fOQ#伬桮伦句佽佘桨桮桢栿";
      n[4] = "\u0003|\u0013\fX<\f<^\u0007R!\taUAB'\t~NAV=\t\u007f\\\u001b^<\u000ea\u0013厤佢厘桱栃栬桾佢桂厫";
      n[5] = "=Pl%?\n2\u0010!.5\u00177M*h%\u00117R1h1\u000b7S#29\n0Ml厍伅厮桏栯桓厍桁估厕";
      n[6] = "rC\u00026\f%}\u0003O=\u00068x^D{\u000e%uX@0M#|]@{\u0007#b]@4\u001adYxh";
      n[7] = "}N";
      n[8] = "zD\u0014QO\u001edL\u000e\u001e-\u0002cQ";
      n[9] = "\u0011\u0018z\u0002W\u0013\u001eX7\t]\u000e\u001b\u0005<ON\u001d\u001e\u00031OQ\u0011\u0002\u001az/M\u0011\u0010\u0013&7Y\u0010\u0007\u0013";
      n[10] = "v\u0005C8g\t}\nRw\u001b\u0010r\u0010\\4, d\u0007P)=\fs\n";
      n[11] = "\u001d\u0002yF\u0004%\u0012B4M\u000e8\u0017\u001f?\u000b\u001d+\u0012\u00192\u000b\u0002'\u000e\u0000yg\u0004%\u0012\t6K=+\u0012\u00192";
      n[12] = "b%*Y\u0019\u0010megR\u0013\rh8l\u0014\u001b\u0010e>h_X桮栐厀栕叱厽伪及厀栕";
      n[13] = float.class;
      o[13] = "java/lang/Float";
      n[14] = "6oY$)\u00139/\u0014/#\u000e<r\u001fi0\u001d9t\u0012i/\u0011%mY\n)\u00180W\u0016+3\u0019";
      n[15] = void.class;
      o[15] = "java/lang/Void";
      n[16] = " (Q2p8+'@}\u00116 ,D'";
      n[17] = "\u0014\u0004',,dK\u0005;q\u0016D.\u001e1qgkI\u0010$3\u0016\u007fL\u0004c,rmQ\u00182K";
      n[18] = "O\u00186\u000f5\b\n\u00033\bS伷桭桳伀株厐厩伩厩伀3h\u0018\u001fV;Q-\u0003\u001aQ";
      n[19] = "\u000bC?r\u0013.TB#/)企佬佺桙取佴桅佬佺伝\u0015\u0016'KJ?/E`@I";
      n[20] = "|\u001d\u0001\u001bU3(K\u0012j桳伎佄佺厳伷厩桊栀佺p\u0014\u0003ihZ\u0017\u001a\u0016+";
      n[21] = "(1f>?p%)de\u0000佑佅厘栄栖栙佑叛厘叞\u000f12~0\"v?<%1";
      n[22] = "nxJ\u0010b\u000b1yVMX桠厗栅佨伪厛伤厗叟叶w1\u0012-c\u0004J1\u0010+~";
      n[23] = "R\u001b\u0003P\fL\u0006M\u0010!佮栵佪叢桫叢株佱栮佼r\u0018NU\u000b\u0011\r\u001eSK]";
      n[24] = "3C.n;}lB23\u0001栖栐古案佔栘栖栐佺案\t?fe[lls\u007fxK";
      n[25] = "\u0018uNL0LGtR\u0011\n栧栻佌佬佶叉栧叡佌史+1\u0005RsA\u0016gOLm";
      n[26] = "Z\u0012')/w\u0005\u0013;t\u0015佘厣桯桁伓佈叆桹伫桁N+l\f\ne+gu\u0011\u001a";
      n[27] = "l~X\u0012PU3\u007fDOj佺伋栃古厶桳栾桏佇栾uTN:f\u001a\u0010\u0018W'v";
      n[28] = "$\u007f\u0006%c1ad\u0003\"\u0005伎栆栔桴佄佘厐叜収厮\u0019>!t1\u000b{{:q6";
      n[29] = "PL8*G^\u000eV+-!wl\bzxLP\u0017Y;4[/";
      n[30] = "^b?Vv\u0010\u0001c#\u000bL伿桽叅伝栨桕桻厧叅厃1q\u001e\u0001`.\ns\u0003]g";
      n[31] = "n\u0013c9/;1\u0012\u007fd\u0015伔厗厴佁厝取桐桍伪佁^+ 8\u000b!;g9%\u001b";
      n[32] = "6\u000foT\u000fei\u000es\t5栎栕桲叓佮佨叔叏厨叓3\u000b~`\u0017-VGg}\u0007";
      n[33] = ":eFqQ[edZ,kC\u0000>Ph\u0016T~\u007f\u0005|\u0007)?hGk\u0016W~=Szk";
      n[34] = "9_`nw\u00134Gb5H厬佔叶变框压伲栐栬变_yQo^$&w_4_";
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6762;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/何树何友何何树树树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = k[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/何树何友何何树树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/何树何友何何树树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 235 && var8 != 'Q' && var8 != 'H' && var8 != 248) {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'n') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 200) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 235) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Q') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'H') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 36;
               case 1 -> 50;
               case 2 -> 21;
               case 3 -> 63;
               case 4 -> 16;
               case 5 -> 54;
               case 6 -> 43;
               case 7 -> 6;
               case 8 -> 5;
               case 9 -> 47;
               case 10 -> 8;
               case 11 -> 2;
               case 12 -> 56;
               case 13 -> 4;
               case 14 -> 1;
               case 15 -> 49;
               case 16 -> 3;
               case 17 -> 41;
               case 18 -> 35;
               case 19 -> 61;
               case 20 -> 12;
               case 21 -> 59;
               case 22 -> 53;
               case 23 -> 7;
               case 24 -> 10;
               case 25 -> 40;
               case 26 -> 57;
               case 27 -> 26;
               case 28 -> 30;
               case 29 -> 58;
               case 30 -> 19;
               case 31 -> 25;
               case 32 -> 44;
               case 33 -> 22;
               case 34 -> 23;
               case 35 -> 11;
               case 36 -> 9;
               case 37 -> 15;
               case 38 -> 60;
               case 39 -> 33;
               case 40 -> 52;
               case 41 -> 17;
               case 42 -> 62;
               case 43 -> 20;
               case 44 -> 46;
               case 45 -> 51;
               case 46 -> 31;
               case 47 -> 55;
               case 48 -> 32;
               case 49 -> 28;
               case 50 -> 24;
               case 51 -> 42;
               case 52 -> 13;
               case 53 -> 14;
               case 54 -> 29;
               case 55 -> 39;
               case 56 -> 45;
               case 57 -> 48;
               case 58 -> 38;
               case 59 -> 27;
               case 60 -> 37;
               case 61 -> 18;
               case 62 -> 34;
               default -> 0;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public static String Y() {
      return 友友友何树何友友何树;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public void R(int state, String text) {
      long a = c ^ 70088401609385L;
      long ax = a ^ 3057326230269L;
      d<"È">(4863373466372729893L, a);
      List var8;
      synchronized (var8 = d<"ë">(this, 4863580573232263666L, a)){} // $VF: monitorenter 

      try {
         何树何友何何树树树树.友友何何友何树友友友 message = new 何树何友何何树树树树.友友何何友何树友友友(1, text, System.currentTimeMillis());
         d<"ë">(this, 4863580573232263666L, a).add(0, message);
         if (d<"ë">(this, 4863580573232263666L, a).size() > d<"ë">(this, 4859795120144167866L, a).getValue().intValue()) {
            d<"ë">(this, 4863580573232263666L, a).remove(d<"ë">(this, 4863580573232263666L, a).size() - 1);
         }

         d<"ë">(this, 4863635305085144361L, a).H(d<"H">(4863446395648368511L, a), ax);
         // $VF: monitorexit
      } finally {
         // $VF: monitorexit
      }
   }

   private static String LIU_YA_FENG() {
      return "何炜霖国企上班";
   }

   public static class 友友何何友何树友友友 implements 何树友 {
      public final int 何树何友树友树何树何;
      public final String 树何何何友何友树树何;
      public final long 何友树何何何树何树何;
      private static String HE_DA_WEI;

      public 友友何何友何树友友友(int state, String text, long timestamp) {
         this.何树何友树友树何树何 = state;
         this.树何何何友何友树树何 = text;
         this.何友树何何何树何树何 = timestamp;
      }

      private static String HE_SHU_YOU() {
         return "何炜霖国企变私企";
      }
   }
}
