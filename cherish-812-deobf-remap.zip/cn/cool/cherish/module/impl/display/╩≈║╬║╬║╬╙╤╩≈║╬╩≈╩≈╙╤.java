package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import cn.cool.cherish.ui.友何何树友何何何何树;
import cn.cool.cherish.utils.animations.何何友树友树友树树何;
import cn.cool.cherish.utils.animations.何树友友何友友何树树;
import cn.cool.cherish.utils.animations.友何友树何何友何友树;
import cn.cool.cherish.utils.animations.友友树树树何何何友友;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树何何何友树何树树友 extends 树树友树友友何友友树 implements 何树友 {
   private final NumberValue 树树友何树何友友树何;
   private final ModeValue 树友树何何何树友何何;
   private 树何何何友树何树树友.树何友友何树友友何何 树友何何树何何树何何;
   private long 何何树友树何友树何友;
   private boolean 友树友何友友友何友树;
   private 友友树树树何何何友友 树树何何何树友友何树;
   private 何何友树友树友树树何 何树树何友树友何友友;
   private 友何友树何何友何友树 友树何何友友树何何友;
   private 何树友友何友友何树树 何树何友何树何树树何;
   private 友友树树树何何何友友 何何友友友何何友友何;
   private float 树友树友树树友何友树;
   private float 树何何树友何何树树友;
   private final float 友友友友何何友树友友;
   private float 友何树友何树树树何何;
   private float 何树友友树友何友树友;
   private final float[] 树树何树友何何何何树;
   private final float[] 友树树友何何树何何树;
   private 友何何树友何何何何树 友树何友友友树树树友;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final long[] n;
   private static final Integer[] o;
   private static final Map p;
   private static final long q;
   private static final Object[] x = new Object[54];
   private static final String[] y = new String[54];
   private static String HE_DA_WEI;

   public 树何何何友树何树树友() {
      long a = c ^ 120937731149585L;
      super(c<"m">(22592, 1322487721734659276L ^ a), c<"m">(25346, 1132637048299644810L ^ a), 140.0F, 140.0F);
      this.树树友何树何友友树何 = new NumberValue(c<"m">(9261, 3728889800464933037L ^ a), c<"m">(4944, 3290146559328524250L ^ a), 1.0, 0.5, 3.0, 0.1);
      this.树友树何何何树友何何 = new ModeValue(
         c<"m">(15818, 8611182775116446031L ^ a),
         c<"m">(4645, 1674988003157513902L ^ a),
         new String[]{
            c<"m">(19329, 703661462911831814L ^ a),
            c<"m">(26479, 6372614663516316646L ^ a),
            c<"m">(32725, 3680105656318065489L ^ a),
            c<"m">(25295, 1268606237634750016L ^ a)
         },
         c<"m">(16328, 472945958227065678L ^ a)
      );
      h<"Þ">(this, h<"ÿ">(-7282715391791807139L, a), -7285756122098254006L, a);
      h<"Þ">(this, 0L, -7285955329921901623L, a);
      h<"Þ">(this, false, -7284383913944068091L, a);
      this.友友友友何何友树友友 = 35.0F;
      h<"Þ">(this, 0.0F, -7284154484467246111L, a);
      h<"Þ">(this, 0.0F, -7282420749920443944L, a);
      this.树树何树友何何何何树 = new float[6];
      this.友树树友何何树何何树 = new float[6];
      this.P();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8945642234921033015L, -6998170470283657600L, MethodHandles.lookup().lookupClass()).a(67790442591887L);
      // $VF: monitorexit
      c = var10000;
      c();
      long var16 = c ^ 20255015811263L;
      Cipher var18;
      Cipher var29 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(var16 << var19 * 8 >>> 56);
      }

      var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[15];
      int var23 = 0;
      String var22 = "*Z8`\u008dE\u0013ïÊ\u0013«³S\u0097>ê\u0010Ø¡A1lv\u001aOK÷X;<\u0012\u001fº \\Î_\u0086\u0084|Í}âm\u001fU\u0085ìÂ³nÎ\u0092{îA½`\\\u0015\u0095\u0082â³Z»\u0010Xrö2Z8ªê\u0093òã0sW\u008fá [x\u001fæ\u007fÝK\bÅpwª¨ð\b\\\u0083\u009c\u000f©£\u0082eQ\u009c\"6\u001c^\u0083?Ä \u0091Î©\u001d§º\u0099Ù+fMã#o^éXw}6?ä©v#ÃZ\u001aäÉ\u0002\u000e\u0010Dëé-\u0083\u00ad\u000bîÈâ\u0088\bR\u0088$\u008e\u0018\u0018\u000e\u001b¼\u008c\"Ã\u0004\u0082\u008cy¨Ç\u009e\u008cß¿¨\u009a\u0084L¶ûõ\u0010\u0082¢ä.ù¹èàíÑ\\I«ÖãY\u0010\u0088½'\u009b\u001c8Kd\u0016â²!\u0005Nó6\u0010ûÃö\u0000¬ç®\u0017'\u0097l\u0002KIÎ\n \u0082ÔÖ@g.îw¼[çÈ\u0011Ýø\u0004Ñ²Ç3\u008f+¾*\u008c\u008a²;\u008c]ª½\u0010\rI\u0005Y0Äø\u0094È!ùG\u000f:\u008dÑ";
      short var24 = 292;
      char var21 = 16;
      int var28 = -1;

      label64:
      while (true) {
         String var30 = var22.substring(++var28, var28 + var21);
         int var10001 = -1;

         while (true) {
            String var43 = d(var18.doFinal(var30.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var43;
                  if ((var28 += var21) >= var24) {
                     k = var25;
                     l = new String[15];
                     p = new HashMap(13);
                     Cipher var5;
                     Cipher var32 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(var16 << var6 * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[6];
                     int var8 = 0;
                     String var9 = "ö5N<Ç\u0002\u009bLÅ\u007f8¡\n%qêDã\b¼kXÞPÞê\u0006\u0018º\"ms";
                     byte var10 = 32;
                     byte var7 = 0;

                     label46:
                     while (true) {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = var9.substring(var10001, var7).getBytes("ISO-8859-1");
                        long[] var33 = var11;
                        var10001 = var8++;
                        long var47 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        byte var52 = -1;

                        while (true) {
                           long var13 = var47;
                           byte[] var15 = var5.doFinal(
                              new byte[]{
                                 (byte)(var13 >>> 56),
                                 (byte)(var13 >>> 48),
                                 (byte)(var13 >>> 40),
                                 (byte)(var13 >>> 32),
                                 (byte)(var13 >>> 24),
                                 (byte)(var13 >>> 16),
                                 (byte)(var13 >>> 8),
                                 (byte)var13
                              }
                           );
                           long var55 = (var15[0] & 255L) << 56
                              | (var15[1] & 255L) << 48
                              | (var15[2] & 255L) << 40
                              | (var15[3] & 255L) << 32
                              | (var15[4] & 255L) << 24
                              | (var15[5] & 255L) << 16
                              | (var15[6] & 255L) << 8
                              | var15[7] & 255L;
                           switch (var52) {
                              case 0:
                                 var33[var10001] = var55;
                                 if (var7 >= var10) {
                                    n = var11;
                                    o = new Integer[6];
                                    Cipher var0;
                                    Cipher var34 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(var16 << var1 * 8 >>> 56);
                                    }

                                    var34.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    byte[] var4 = var0.doFinal(new byte[]{23, 83, -102, 43, 37, 27, 14, 55});
                                    long var50 = (var4[0] & 255L) << 56
                                       | (var4[1] & 255L) << 48
                                       | (var4[2] & 255L) << 40
                                       | (var4[3] & 255L) << 32
                                       | (var4[4] & 255L) << 24
                                       | (var4[5] & 255L) << 16
                                       | (var4[6] & 255L) << 8
                                       | var4[7] & 255L;
                                    byte var41 = -1;
                                    q = var50;
                                    return;
                                 }
                                 break;
                              default:
                                 var33[var10001] = var55;
                                 if (var7 < var10) {
                                    continue label46;
                                 }

                                 var9 = "¤T\t\u009fÈã`\u0097v¯]=ö\u0080SO";
                                 var10 = 16;
                                 var7 = 0;
                           }

                           byte var40 = var7;
                           var7 += 8;
                           var12 = var9.substring(var40, var7).getBytes("ISO-8859-1");
                           var33 = var11;
                           var10001 = var8++;
                           var47 = (var12[0] & 255L) << 56
                              | (var12[1] & 255L) << 48
                              | (var12[2] & 255L) << 40
                              | (var12[3] & 255L) << 32
                              | (var12[4] & 255L) << 24
                              | (var12[5] & 255L) << 16
                              | (var12[6] & 255L) << 8
                              | var12[7] & 255L;
                           var52 = 0;
                        }
                     }
                  }

                  var21 = var22.charAt(var28);
                  break;
               default:
                  var25[var23++] = var43;
                  if ((var28 += var21) < var24) {
                     var21 = var22.charAt(var28);
                     continue label64;
                  }

                  var22 = "\u0084Õ\u000f\u0086x\u0013ªJè\t-îü\u009b\u0097ê º\u0002Îs&B§\u0006uE\u001f$Ã\u008f¨ä\u0007\u0085=V\u0091\u009b½òSd3\u007fÎ\u0005\u008e\u0088";
                  var24 = 49;
                  var21 = 16;
                  var28 = -1;
            }

            var30 = var22.substring(++var28, var28 + var21);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void B(Render2DEvent event) {
      long a = c ^ 116691455644361L;
      long ax = a ^ 101467277639188L;
      h<"Ö">(-4093710613279131282L, a);
      if (!this.w(new Object[]{ax})) {
         if (h<"è">(this, -4090570037426048376L, a) == null) {
            h<"Þ">(this, Cherish.instance.h().n(20), -4090570037426048376L, a);
         }

         h<"Þ">(this, h<"è">(this, -4090764379175110393L, a) + h<"è">(this, -4090927661432145030L, a) / 2.0F, -4091787370617626158L, a);
         h<"Þ">(this, h<"è">(this, -4093649363601910190L, a) + h<"è">(this, -4091975711816288296L, a) / 2.0F, -4093460731241849445L, a);
         this.C();
         if (h<"è">(this, -4093582172529029667L, a) && System.currentTimeMillis() >= h<"è">(this, -4090656158121572847L, a)) {
            this.e();
         }

         this.t(event.poseStack());
         this.b(event.poseStack());
      }
   }

   private void B() {
      long a = c ^ 95500563262217L;
      h<"Ö">(-76548992340262738L, a);
      int i = 0;
      float angle = (float)Math.toRadians(0.0);
      h<"è">(this, -73520680772001346L, a)[0] = h<"è">(this, -74535983977261038L, a) + 80.0F * (float)Math.cos(angle);
      h<"è">(this, -74806098149912252L, a)[0] = h<"è">(this, -76235888518716325L, a) + 80.0F * (float)Math.sin(angle);
      i++;
   }

   private void C() {
      long a = c ^ 107954463562890L;
      long ax = a ^ 106259633433586L;
      long axx = a ^ 13690762510587L;
      long axxx = a ^ 2035695885454L;
      long axxxx = a ^ 25126921685915L;
      h<"Ö">(680958254627485485L, a);
      if (!h<"è">(this, 681069103141208990L, a)) {
         switch (h<"ÿ">(682108055924617458L, a)[h<"è">(this, 682511644806753489L, a).ordinal()]) {
            case 1:
               h<"Þ">(this, 35.0F * (float)h<"è">(this, 682079244179038657L, a).T(new Object[]{ax}), 680733796276914298L, a);
               if (!h<"è">(this, 682079244179038657L, a).g(new Object[]{axxxx})) {
                  break;
               }

               if (h<"è">(this, 682244209356377586L, a).C(c<"m">(23634, 2438723035279772487L ^ a))) {
                  h<"Þ">(this, h<"ÿ">(681617214885353158L, a), 682511644806753489L, a);
                  this.D();
               }

               h<"Þ">(this, h<"ÿ">(681991970023058464L, a), 682511644806753489L, a);
               h<"è">(this, 682199154339158956L, a).M(new Object[]{axxx});
               h<"è">(this, 682199154339158956L, a).H(new Object[]{h<"ÿ">(681398573086586759L, a), axx});
            case 2:
               h<"Þ">(this, (float)(35.0 * h<"è">(this, 681122925901382455L, a).T(new Object[]{ax})), 680733796276914298L, a);
               if (!h<"è">(this, 681122925901382455L, a).g(new Object[]{axxxx})) {
                  break;
               }

               if (h<"è">(this, 682244209356377586L, a).C(c<"m">(30598, 7684740041381732496L ^ a))) {
                  h<"Þ">(this, h<"ÿ">(683097987108824308L, a), 682511644806753489L, a);
                  h<"è">(this, 683066972355861152L, a).M(new Object[]{axxx});
                  h<"è">(this, 683066972355861152L, a).H(new Object[]{h<"ÿ">(681398573086586759L, a), axx});
               }

               h<"Þ">(this, h<"ÿ">(681991970023058464L, a), 682511644806753489L, a);
               h<"è">(this, 682199154339158956L, a).M(new Object[]{axxx});
               h<"è">(this, 682199154339158956L, a).H(new Object[]{h<"ÿ">(681398573086586759L, a), axx});
            case 3:
               h<"Þ">(this, (float)h<"è">(this, 682199154339158956L, a).T(new Object[]{ax}), 681357702424457795L, a);
               if (!h<"è">(this, 682199154339158956L, a).g(new Object[]{axxxx})) {
                  break;
               }

               if (h<"è">(this, 682244209356377586L, a).C(c<"m">(16328, 472932965578844373L ^ a))) {
                  h<"Þ">(this, h<"ÿ">(681676693516297907L, a), 682511644806753489L, a);
                  h<"è">(this, 681242268364339443L, a).M(new Object[]{axxx});
                  h<"è">(this, 681242268364339443L, a).H(new Object[]{h<"ÿ">(681398573086586759L, a), axx});
               }

               if (h<"è">(this, 682244209356377586L, a).C(c<"m">(19587, 4897523647442049946L ^ a))) {
                  h<"Þ">(this, h<"ÿ">(683097987108824308L, a), 682511644806753489L, a);
                  h<"è">(this, 683066972355861152L, a).M(new Object[]{axxx});
                  h<"è">(this, 683066972355861152L, a).H(new Object[]{h<"ÿ">(681398573086586759L, a), axx});
               }

               h<"Þ">(this, h<"ÿ">(681617214885353158L, a), 682511644806753489L, a);
               this.D();
            case 4:
               h<"Þ">(this, (float)(35.0 * (1.0 - h<"è">(this, 681242268364339443L, a).T(new Object[]{ax}))), 680733796276914298L, a);
               if (!h<"è">(this, 681242268364339443L, a).g(new Object[]{axxxx})) {
                  break;
               }

               h<"Þ">(this, h<"ÿ">(681746547218426173L, a), 682511644806753489L, a);
               h<"è">(this, 681122925901382455L, a).M(new Object[]{axxx});
               h<"è">(this, 681122925901382455L, a).H(new Object[]{h<"ÿ">(681398573086586759L, a), axx});
            case 5:
               h<"Þ">(this, (float)(35.0 * h<"è">(this, 681122925901382455L, a).T(new Object[]{ax})), 680733796276914298L, a);
               if (!h<"è">(this, 681122925901382455L, a).g(new Object[]{axxxx})) {
                  break;
               }

               h<"Þ">(this, h<"ÿ">(681617214885353158L, a), 682511644806753489L, a);
               this.D();
            case 6:
               float releaseProgress = (float)h<"è">(this, 683066972355861152L, a).T(new Object[]{ax});
               h<"Þ">(this, 35.0F + 50.0F * releaseProgress, 680733796276914298L, a);
               if (h<"è">(this, 683066972355861152L, a).g(new Object[]{axxxx})) {
                  h<"Þ">(this, h<"ÿ">(681617214885353158L, a), 682511644806753489L, a);
                  this.D();
               }
         }
      }
   }

   private void D() {
      long a = c ^ 11128674383127L;
      h<"Þ">(this, System.currentTimeMillis() + q, 2370425968529220047L, a);
      h<"Þ">(this, true, 2373058962517191171L, a);
   }

   private int S(int index) {
      long a = c ^ 96336743206925L;
      int[] colors = new int[]{
         d<"k">(13409, 7948565696456249284L ^ a),
         -29696,
         -10496,
         d<"k">(30729, 1228296725141717928L ^ a),
         d<"k">(10036, 1275550627209731220L ^ a),
         d<"k">(22052, 6178751574860410247L ^ a),
         d<"k">(23398, 118652908914548930L ^ a)
      };
      return colors[index % colors.length];
   }

   public void V() {
      long a = c ^ 79799482128414L;
      long ax = a ^ 42672541893743L;
      long axx = a ^ 47713334122522L;
      h<"Ö">(-3609893141340343367L, a);
      if (h<"è">(this, -3608247494720559035L, a) == h<"ÿ">(-3611397060018662830L, a)) {
         this.P();
         h<"Þ">(this, false, -3609760439480416502L, a);
         String var8 = h<"è">(this, -3610765662416549530L, a).getValue();
         byte var9 = -1;
         switch (var8.hashCode()) {
            case -1776693134:
               if (!var8.equals(c<"m">(16328, 472905148543069249L ^ a))) {
                  break;
               }

               var9 = 0;
            case -1539719193:
               if (!var8.equals(c<"m">(30598, 7684694466807833604L ^ a))) {
                  break;
               }

               var9 = 1;
            case -1680869110:
               if (!var8.equals(c<"m">(23634, 2438768541136261075L ^ a))) {
                  break;
               }

               var9 = 2;
            case 65579206:
               if (var8.equals(c<"m">(19587, 4897477076432527118L ^ a))) {
                  var9 = 3;
               }
         }

         switch (var9) {
            case 0:
            case 1:
               h<"Þ">(this, h<"ÿ">(-3611182007155350724L, a), -3608247494720559035L, a);
               h<"è">(this, -3609636141155694685L, a).M(new Object[]{axx});
               h<"è">(this, -3609636141155694685L, a).H(new Object[]{h<"ÿ">(-3611611093317553389L, a), ax});
            case 2:
            case 3:
               h<"Þ">(this, h<"ÿ">(-3608107802296925544L, a), -3608247494720559035L, a);
               h<"è">(this, -3611022918394337963L, a).M(new Object[]{axx});
               h<"è">(this, -3611022918394337963L, a).H(new Object[]{h<"ÿ">(-3611611093317553389L, a), ax});
               this.B();
         }
      }
   }

   private void e() {
      long a = c ^ 113612971158773L;
      h<"Þ">(this, h<"ÿ">(8721944454777415353L, a), 8721152242402221230L, a);
      h<"Þ">(this, 0.0F, 8722758605227046917L, a);
      h<"Þ">(this, 0.0F, 8722256709982487100L, a);
      h<"Þ">(this, false, 8722524450748347361L, a);
      h<"Þ">(this, 0L, 8720970610121701421L, a);
      this.V();
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树何何何友树何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7786;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何何何友树何树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = k[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void c() {
      x[0] = "2R,kL-=\u0012a`F08Oj&N-5Inm\r+<Ln&G+\"LniZl桀佩佗佝叨桓伄栭栓參\u0007桓伄号叉佝栲厉厚佩佗";
      x[1] = "\u007f\u0006$Jm7pFiAg*u\u001bb\u0007o7x\u001dfL,1q\u0018f\u0007f1o\u0018fH{v栍伽佟佼叉桉佉桹栛叢";
      x[2] = "hQ\u0002Z'\tc^\u0013\u0015[\u0010lD\u001dVl zS\u0011K}\fm^";
      x[3] = "a2\n\u00166OnrG\u001d<Rk/L[,Tk0W[8Nk1E\u00010Ol/\n厾伌叫栓桍栵厾案併叉";
      x[4] = "T\u000e`{\u001b\u001a[N-p\u0011\u0007^\u0013&6\u0001\u0001^\f=6\u0015\u001b^\r/l\u001d\u001aY\u0013`位桥厾叼伵厅叓伡桤栦";
      x[5] = "[\u0010(\u0012`\u000bTPe\u0019j\u0016Q\rn_y\u0005T\u000bc_f\tH\u0012(<`\u0000](g\u001dz\u0001";
      x[6] = "73s!vy8s>*|d=.5lty0(1'7\u007f9-1l}\u007f'-1#`8\u001c\b\u0019";
      x[7] = "(S";
      x[8] = "\u0004cu,-s\u000b#8''n\u000e~3a7h\u000ea(a#r\u000e`:;+s\t~u厄厉栍桶栜伎会众受厬";
      x[9] = boolean.class;
      y[9] = "java/lang/Boolean";
      x[10] = "Rw)\u0003R@]7d\bX]XjoNH[XutN\\AXtf\u0014T@_j)伵佨古栠叒栖厫栬栾佤";
      x[11] = "Q\u0017^in}^W\u0013bd`[\n\u0018$tf[\u0015\u0003$`|[\u0014\u0011~h}\\\n^叁佔叙栣伬伥叁佔叙栣";
      x[12] = "X\u0018F\n\u00164WX\u000b\u0001\u001c)R\u0005\u0000G\u000f:W\u0003\rG\u00106K\u001aF'\f6Y\u0013\u001a?\u00187N\u0013";
      x[13] = "Ce";
      x[14] = float.class;
      y[14] = "java/lang/Float";
      x[15] = "\u0017\u000e";
      x[16] = "3+ aW6<kmj]+96f,M0~厎佛佗栩厒伅伐佛佗栩";
      x[17] = "\u0019=#\u0011>*\u0016}n\u001a47\u0013 e\\<*\u001e&a\u0017\u007f,\u0017#a\\5,\t#a\u0013(k桫伆佘伧厚桔伯桂栜厹u厎伯厘栜伧桀伐伯伆佘";
      x[18] = "1P";
      x[19] = long.class;
      y[19] = "java/lang/Long";
      x[20] = "\u0018G~b5T\u0017\u00073i?I\u0012Z8/7T\u001f\\<dt株桪叢桁及厑佮厰叢桁";
      x[21] = "O6\\l\u0010\nD9M#q\u0004O2Iy";
      x[22] = "N6\n\u0017c0N`Q~桃栓伯桅厩伣桃栓厱桅jB0j\u001bePBf1";
      x[23] = "G[mK\u00149\u001c\nnO+伎伣厧厗叭佶伎厽厧伉.\u00166\u0011Z%\u0017G.\u001e\u001a";
      x[24] = "K\u001b\u001c8V\u000eKMGQ厬号厴伬县案桶号伪厲|m\u0005T\u001eHFmS\u000f";
      x[25] = "\u0003,f\u001b(|\rnqHJ佅伳叓栚桭桓佅厭叓叀t{a\u0001 2\u001br&Sz";
      x[26] = "y\u0014O+8q\"EL/\u0007栂桙佶桯厍佚但伝佶桯Nnu-\u0015\u0013w=k9T";
      x[27] = "D\u0011O8\u001aCJSXkx栾只叮叩桎桡栾栰栴佷WI^F\u001d\u001b8@\u0019\u0014G";
      x[28] = "t\u001aV:\\V/KU>c叿桔佸厬厜厠栥桔格厬_\tE$\u0014\u0013-\u001dN J";
      x[29] = "e\u000f9}oa>^:yP佖企栩參栁伍又桅佭參\u0018<b.N1{lt9T";
      x[30] = "(=JP'\u0011slIT\u0018桢叒佟伮栬佅伦栈佟伮5$\u0011qkJ\u000f$G*";
      x[31] = "a)-OqQ:x.KNQX/eH3Q`})O4;agvW$\u00033+qPN";
      x[32] = "/e\u001c\u0012\u007f\u0010ydG\rB伱优取另桬厁桵优佈佸u)\f,r]O3\t4.";
      x[33] = "\u0011J\u000bEsSJ\u001b\bAL佤栱伨叱佽桕佤栱桬佯 vIE\u000b\tBv\u0000Z\u001a";
      x[34] = "V\u0001X23j\rP[6\f栙厬栧似伊佑栙厬佣似W7b\rG\u0003=op\u0010\u0002";
      x[35] = "\n1bq:YQ`au\u0005台株体伆受叆株佮体厘\u00145ZU37z`HZ6";
      x[36] = "\u001f$K-\u0001sDuH)>栀栿变伯桑佣叚句栂伯H\u000eu^&MxN}\\%";
      x[37] = "\u000fl!X\u0012\u0017\u000f:z1佶叮佮叅桘佬栲叮台栟A\rAMZ?{\r\u0017\u0016";
      x[38] = "\u001b\u0014\u0015\u0001\t\u007f\u001bBNh栩桜古厽桬厫栩历栾厽uTZ%NGOT\f~";
      x[39] = "+d<6t\r+2g_伐叴栎体桅框桔佪叔栗\\c'W~7fcq\f";
      x[40] = "\u001f^%c\u000b\b\u0011\u001c20i厯伯厡厃栕厪伱桫桻厃\fX\u0015\u001dRqcQRO\b";
      x[41] = "\u0018XBy\u0004nC\tA};叇核桾厸佁佦栝佼伺桢\u001cRjLY\u001e%\u0001tX\u0018";
      x[42] = "\u007fhGqp\u001c\u007f>\u001c\u0018伔句厀佟佺栁伔句桚佟'$#F*;\u001d$u\u001d";
      x[43] = "\u0017M_!\u000f\n\u0017\u001b\u0004H佫佭栲栾佢伕叵栩栲古?t\\PB\u001e\u0005t\n\u000b";
      x[44] = "Tv\u0006ws\u000f\u000f'\u0005sL伸桴桐佢发桕厦估厊叼\u0012s\u000eP9\u000ej YT+";
      x[45] = "\u000f$)\f\u001c.Tu*\b#桝叵栂叓桰栺厇佫变栉i\u0012=Y+!\u0006\u001bz\u000bq";
      x[46] = "x ;\b\u0012\u00118foYp伦桛栂栜佨伭厸厁变叆5J@|&g_\n\u0006(w";
      x[47] = "=t^\u0014iFf%]\u0010V佱栝厈厤桨厕佱叇桒厤qgUk{V\u001en\u00129!";
      x[48] = "\u001e$Y\u0015\u0007U\u0010fNFe佬伮佅叿档厦史桪叛叿zTH\u001c(\r\u0015]\u000fNr";
      x[49] = ":\u0000o\t=\u0011e\u000b-JDr\u0006\u0005?\u0012#R<\u001f:\n\u007f*";
      x[50] = "h\u0005\u0010\u0001ON3T\u0013\u0005p栽案佧佴伹桩叧厒佧栰dMA>\u0004X]\u001cY1D";
      x[51] = "yLL\u0016>7\"\u001dO\u0012\u0001厞桙厰伨厰参厞伝厰桬s?&)\u0019\u001b\nc&!\t";
      x[52] = "\u001b&\u0005}F\u0016@w\u0006yy县使栀叿佅桠桥栻佄佡\u0018H\u0005M)\rwAB\u001fs";
      x[53] = "A\"0BH\u0013\u001as3Fw桠伥佀栐古伪伤桡栄及'F\u0000\u0017-8HOGEw";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = x[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(y[var4]);
            x[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树何何何友树何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static int d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = d(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树何何何友树何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 232 && var8 != 222 && var8 != 255 && var8 != 212) {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'd') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 214) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 232) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 222) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 255) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15961;
      if (o[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = n[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])p.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            p.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何何何友树何树树友", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         o[var3] = var15;
      }

      return o[var3];
   }

   private int a(int color, float alpha) {
      long a = c ^ 11686769476946L;
      int ax = (int)(255.0F * Math.max(0.0F, Math.min(1.0F, alpha)));
      return ax << 24 | color & d<"k">(10786, 1173663373203440863L ^ a);
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (y[var4] != null) {
         return var4;
      } else {
         Object var5 = x[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 35;
               case 1 -> 7;
               case 2 -> 17;
               case 3 -> 23;
               case 4 -> 0;
               case 5 -> 10;
               case 6 -> 37;
               case 7 -> 53;
               case 8 -> 11;
               case 9 -> 14;
               case 10 -> 15;
               case 11 -> 41;
               case 12 -> 46;
               case 13 -> 62;
               case 14 -> 31;
               case 15 -> 55;
               case 16 -> 13;
               case 17 -> 48;
               case 18 -> 6;
               case 19 -> 32;
               case 20 -> 39;
               case 21 -> 56;
               case 22 -> 21;
               case 23 -> 20;
               case 24 -> 42;
               case 25 -> 40;
               case 26 -> 54;
               case 27 -> 50;
               case 28 -> 44;
               case 29 -> 29;
               case 30 -> 2;
               case 31 -> 34;
               case 32 -> 47;
               case 33 -> 43;
               case 34 -> 60;
               case 35 -> 26;
               case 36 -> 27;
               case 37 -> 18;
               case 38 -> 63;
               case 39 -> 52;
               case 40 -> 9;
               case 41 -> 8;
               case 42 -> 5;
               case 43 -> 28;
               case 44 -> 3;
               case 45 -> 30;
               case 46 -> 49;
               case 47 -> 59;
               case 48 -> 25;
               case 49 -> 4;
               case 50 -> 33;
               case 51 -> 19;
               case 52 -> 24;
               case 53 -> 36;
               case 54 -> 51;
               case 55 -> 12;
               case 56 -> 38;
               case 57 -> 57;
               case 58 -> 45;
               case 59 -> 1;
               case 60 -> 61;
               case 61 -> 16;
               case 62 -> 58;
               default -> 22;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            y[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      if (var5 instanceof String) {
         String var6 = y[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         x[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = y[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         x[var4] = var21;
         return var21;
      }
   }

   @Override
   public void t() {
      long a = c ^ 101455711847392L;
      h<"Þ">(this, Cherish.instance.h().n(20), -7632943457229315167L, a);
      this.e();
   }

   private void t(PoseStack poseStack) {
      long a = c ^ 115434494770714L;
      long ax = a ^ 117062903630178L;
      h<"Ö">(-1449256110072719939L, a);
      if (h<"è">(this, -1447798545878868389L, a) != null) {
         String soul = c<"m">(16084, 8872998838821374812L ^ a);
         this.G(poseStack, soul, h<"è">(this, -1449015806340559615L, a), h<"è">(this, -1449567565228756664L, a), this.S(0));
         if (!h<"è">(this, -1449122867558735602L, a)
            && h<"è">(this, -1447680324921471423L, a) != h<"ÿ">(-1448578061926288298L, a)
            && h<"è">(this, -1449463001730143510L, a) > 0.0F) {
            int i = 1;
            if (h<"è">(this, -1447680324921471423L, a) == h<"ÿ">(-1447540603960040292L, a)) {
               float progress = (float)h<"è">(this, -1448134162475613359L, a).T(new Object[]{ax});
               float startX = h<"è">(this, -1447358128502295379L, a)[0];
               float startY = h<"è">(this, -1448749060477041577L, a)[0];
               float targetAngle = (float)Math.toRadians(0.0);
               float targetX = h<"è">(this, -1449015806340559615L, a) + 35.0F * (float)Math.cos(targetAngle);
               float targetY = h<"è">(this, -1449567565228756664L, a) + 35.0F * (float)Math.sin(targetAngle);
               float var10000 = startX + (targetX - startX) * progress;
               var10000 = startY + (targetY - startY) * progress;
               Math.min(1.0F, progress * 2.0F);
            }

            if (h<"è">(this, -1447680324921471423L, a) == h<"ÿ">(-1447114722651797916L, a)) {
               float angle = (float)Math.toRadians(0.0F + h<"è">(this, -1448855146153799469L, a));
               float var23 = h<"è">(this, -1449015806340559615L, a) + h<"è">(this, -1449463001730143510L, a) * (float)Math.cos(angle);
               var23 = h<"è">(this, -1449567565228756664L, a) + h<"è">(this, -1449463001730143510L, a) * (float)Math.sin(angle);
               var23 = 1.0F - (float)h<"è">(this, -1447143010122893264L, a).T(new Object[]{ax});
            }

            float angle = (float)Math.toRadians(0.0F + h<"è">(this, -1448855146153799469L, a));
            float x = h<"è">(this, -1449015806340559615L, a) + h<"è">(this, -1449463001730143510L, a) * (float)Math.cos(angle);
            float y = h<"è">(this, -1449567565228756664L, a) + h<"è">(this, -1449463001730143510L, a) * (float)Math.sin(angle);
            float alpha = Math.min(1.0F, h<"è">(this, -1449463001730143510L, a) / 35.0F);
            int color = this.a(this.S(1), alpha);
            this.G(poseStack, soul, x, y, color);
            i++;
         }
      }
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private void P() {
      long a = c ^ 87923619643978L;
      long ax = a ^ 31882873791161L;
      long var10001 = a ^ 92435107265813L;
      int axx = (int)((a ^ 92435107265813L) >>> 48);
      int axxx = (int)((a ^ 92435107265813L) << 16 >>> 48);
      int axxxx = (int)(var10001 << 32 >>> 32);
      var10001 = a ^ 54040863262633L;
      int axxxxx = (int)((a ^ 54040863262633L) >>> 48);
      int axxxxxx = (int)((a ^ 54040863262633L) << 16 >>> 48);
      int axxxxxxx = (int)(var10001 << 32 >>> 32);
      long axxxxxxxx = a ^ 13263622160146L;
      double speed = h<"è">(this, 1708638175050562057L, a).getValue().doubleValue();
      int expandDuration = (int)(800.0 / speed);
      int rotateDuration = (int)(2000.0 / speed);
      int contractDuration = (int)(600.0 / speed);
      int collectDuration = (int)(1200.0 / speed);
      int releaseDuration = (int)(1000.0 / speed);
      h<"Þ">(this, new 友友树树树何何何友友(expandDuration, (char)axxxxx, (char)axxxxxx, 1.0, axxxxxxx), 1707981815535640055L, a);
      h<"Þ">(this, new 何何友树友树友树树何(contractDuration, 1.0, ax, 1.5F), 1708113181990741555L, a);
      h<"Þ">(this, new 友何友树何何友何友树((short)axx, (short)axxx, rotateDuration, axxxx, 360.0), 1708981215926355308L, a);
      h<"Þ">(this, new 何树友友何友友何树树(axxxxxxxx, collectDuration, 1.0), 1708859516878814977L, a);
      h<"Þ">(this, new 友友树树树何何何友友(releaseDuration, (char)axxxxx, (char)axxxxxx, 1.0, axxxxxxx), 1709837418183296096L, a);
   }

   @Override
   public boolean G(double mouseX, double mouseY, int button) {
      long a = c ^ 71839529018739L;
      h<"Ö">(8109325508851306196L, a);
      boolean dragHandled = super.G(mouseX, mouseY, button);
      if (!dragHandled && button == 0 && h<"è">(this, 8107015619908359464L, a) == h<"ÿ">(8110055249057689407L, a) && !h<"è">(this, 8109443358185863783L, a)) {
         this.V();
         return true;
      } else {
         return dragHandled;
      }
   }

   private void G(PoseStack poseStack, String soulText, float x, float y, int color) {
      long a = c ^ 66818694058454L;
      int width = h<"è">(this, -4313262218451340905L, a).A(soulText);
      int height = h<"è">(this, -4313262218451340905L, a).K();
      float drawX = x - width / 2.0F;
      float drawY = y - height / 2.0F;
      h<"è">(this, -4313262218451340905L, a).c(poseStack, soulText, drawX, drawY, color);
   }

   private static String HE_JIAN_GUO() {
      return "何大伟230622198107200054";
   }

   private static enum 树何友友何树友友何何 implements  {
      何何树树何何友树树友,
      友友友何友树树友何友,
      何友树何树树树何友树,
      树树友友树友树友树友,
      何友友何何树何友树何,
      树树何树友何树树友树,
      何友何友树何树友友树;

      private static final long a;
      private static final Object[] b = new Object[11];
      private static final String[] c = new String[11];
      private static String HE_SHU_YOU;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-3195902415333106086L, 953805738660765863L, MethodHandles.lookup().lookupClass()).a(259672380758141L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 37449051045015L;
         b();
         Cipher var1;
         Cipher var13 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[7];
         int var6 = 0;
         String var5 = "ã\b\u008a¬\u008fÎÖßFFÕN\u0002Ð^Õ\u0010¹,#Z=Çj\u009cÙke\u0003SµÖÇ\u0010t!ë)÷M\u0083ªØP(m@\u0010½\u0010\bdäï@ôoØJ\u0010\u0086\u0089CGÌ{R\u009b¡\u0003~ûvGn*";
         byte var7 = 76;
         char var4 = 16;
         int var12 = -1;

         label28:
         while (true) {
            String var14 = var5.substring(++var12, var12 + var4);
            byte var10001 = -1;

            while (true) {
               String var20 = a(var1.doFinal(var14.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var20;
                     if ((var12 += var4) >= var7) {
                        何何树树何何友树树友 = new 树何何何友树何树树友.树何友友何树友友何何();
                        友友友何友树树友何友 = new 树何何何友树何树树友.树何友友何树友友何何();
                        何友树何树树树何友树 = new 树何何何友树何树树友.树何友友何树友友何何();
                        树树友友树友树友树友 = new 树何何何友树何树树友.树何友友何树友友何何();
                        何友友何何树何友树何 = new 树何何何友树何树树友.树何友友何树友友何何();
                        树树何树友何树树友树 = new 树何何何友树何树树友.树何友友何树友友何何();
                        何友何友树何树友友树 = new 树何何何友树何树树友.树何友友何树友友何何();
                        return;
                     }

                     var4 = var5.charAt(var12);
                     break;
                  default:
                     var0[var6++] = var20;
                     if ((var12 += var4) < var7) {
                        var4 = var5.charAt(var12);
                        continue label28;
                     }

                     var5 = "¹,#Z=Çj\u009cJ-¡\u0090%\u0001\u00826\u0010{À\u008dº\u0083õ\u0090\u008a¦¯Ósý²$\u0093";
                     var7 = 33;
                     var4 = 16;
                     var12 = -1;
               }

               var14 = var5.substring(++var12, var12 + var4);
               var10001 = 0;
            }
         }
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static void b() {
         b[0] = "C%S}\u00197Le\u001ev\u0013*I8\u00150\u001b7D>\u0011{X1M;\u00110\u00121S;\u0011\u007f\u000fv栱伞伨佋厽桉併桚桬叕R桉併厀厶佋桧厓叫伞伨";
         b[1] = "_:1Rx\rk\u0019>\u00125\u0006a\u0004;O>@i\u00196I:\u000b*\u001f?L:@`\u001f!L:\u000f}X桃佩伃伻叏桧伇栭桇厥 桧伇号厝伻栕厽厙佩伃U";
         b[2] = "+N\rNHA A\u001c\u0001)O+J\u0018[";
         b[3] = "vKtQav<J0*栞栐伛栱厊佷栞栐厅栱I\u001ad4=N6Pep";
         b[4] = "BW~\u0016oF\bV:m及叺厱佩厀桴栐叺伯号C]j\u0004\tR<\u0017k@";
         b[5] = "i\u0007q\u007f:)#\u00065\u0004企厕厚伹休栝企厕桀伹L4?k\"\u00023~>/";
         b[6] = "YOxO1>\u0013N<4桎伜伴可优号桎伜厪佱E\rn%\u000bA4]n&X";
         b[7] = "$c6=\u0017^nbrF伬佼栍栙佖伛厲核栍參\u000bv\u0012\u001coft<\u0013X";
         b[8] = "\u00131\u00032.KY0GI伕号佾厑栧伔桑号叠桋>y+\tX4A3*M";
         b[9] = ". URVRd!\u0011)栩栴叝厀桱只栩叮标厀h\u0019S\u0010e%\u0017SRT";
         b[10] = "zr\u0017b3l0sS\u0019伈叐桓佌栳栀桌低厉栈*)6.1wUc7j";
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何何何友树何树树友$树何友友何树友友何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'm' && var8 != 232 && var8 != 233 && var8 != 'u') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 212) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'r') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'm') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 232) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 233) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      public static 树何何何友树何树树友.树何友友何树友友何何[] a() {
         long var0 = a ^ 105894771088718L;
         return (树何何何友树何树树友.树何友友何树友友何何[])a<"é">(5500226695068615517L, var0).clone();
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 4;
                  case 1 -> 37;
                  case 2 -> 47;
                  case 3 -> 61;
                  case 4 -> 18;
                  case 5 -> 30;
                  case 6 -> 1;
                  case 7 -> 62;
                  case 8 -> 10;
                  case 9 -> 22;
                  case 10 -> 41;
                  case 11 -> 39;
                  case 12 -> 51;
                  case 13 -> 6;
                  case 14 -> 34;
                  case 15 -> 14;
                  case 16 -> 58;
                  case 17 -> 16;
                  case 18 -> 53;
                  case 19 -> 26;
                  case 20 -> 3;
                  case 21 -> 28;
                  case 22 -> 43;
                  case 23 -> 9;
                  case 24 -> 11;
                  case 25 -> 40;
                  case 26 -> 12;
                  case 27 -> 5;
                  case 28 -> 20;
                  case 29 -> 60;
                  case 30 -> 24;
                  case 31 -> 0;
                  case 32 -> 42;
                  case 33 -> 46;
                  case 34 -> 48;
                  case 35 -> 50;
                  case 36 -> 23;
                  case 37 -> 13;
                  case 38 -> 21;
                  case 39 -> 63;
                  case 40 -> 35;
                  case 41 -> 32;
                  case 42 -> 33;
                  case 43 -> 36;
                  case 44 -> 57;
                  case 45 -> 54;
                  case 46 -> 7;
                  case 47 -> 56;
                  case 48 -> 59;
                  case 49 -> 29;
                  case 50 -> 55;
                  case 51 -> 31;
                  case 52 -> 52;
                  case 53 -> 38;
                  case 54 -> 8;
                  case 55 -> 49;
                  case 56 -> 25;
                  case 57 -> 15;
                  case 58 -> 19;
                  case 59 -> 45;
                  case 60 -> 44;
                  case 61 -> 17;
                  case 62 -> 27;
                  default -> 2;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public static 树何何何友树何树树友.树何友友何树友友何何 O(String name) {
         return Enum.valueOf(树何何何友树何树树友.树何友友何树友友何何.class, name);
      }

      private static String LIU_YA_FENG() {
         return "何树友为什么濒天了";
      }
   }
}
