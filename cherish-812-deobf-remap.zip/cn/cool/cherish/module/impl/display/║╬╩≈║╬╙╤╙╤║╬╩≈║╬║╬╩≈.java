package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.value.impl.ModeValue;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何树何友友何树何何树 extends Module implements 何树友 {
   public static 何树何友友何树何何树 树树友树树树树何树树;
   public ModeValue 友友何树树树友友友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[15];
   private static final String[] k = new String[15];
   private static String LIU_YA_FENG;

   public 何树何友友何树何何树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/display/何树何友友何树何何树.a J
      // 03: ldc2_w 108058497392806
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 319
      // 0c: ldc2_w 8945443196228829590
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/何树何友友何树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 32165
      // 19: ldc2_w 1374915767817600256
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/何树何友友何树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w -6754588357929695208
      // 26: lload 1
      // 27: invokedynamic å (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/display/何树何友友何树何何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: invokevirtual cn/cool/cherish/module/impl/display/何树何友友何树何何树.r ()[Ljava/lang/String;
      // 33: astore 3
      // 34: aload 0
      // 35: new cn/cool/cherish/value/impl/ModeValue
      // 38: dup
      // 39: sipush 530
      // 3c: ldc2_w 669288387683091129
      // 3f: lload 1
      // 40: lxor
      // 41: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/何树何友友何树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 46: sipush 2397
      // 49: ldc2_w 8096560696454908411
      // 4c: lload 1
      // 4d: lxor
      // 4e: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/何树何友友何树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 53: aload 3
      // 54: aload 3
      // 55: arraylength
      // 56: ifle 5f
      // 59: aload 3
      // 5a: bipush 0
      // 5b: aaload
      // 5c: goto 6c
      // 5f: sipush 5987
      // 62: ldc2_w 78102903595866052
      // 65: lload 1
      // 66: lxor
      // 67: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/何树何友友何树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6c: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 6f: ldc2_w -6754767608829706758
      // 72: lload 1
      // 73: invokedynamic G (Ljava/lang/Object;Lcn/cool/cherish/value/impl/ModeValue;JJ)V bsm=cn/cool/cherish/module/impl/display/何树何友友何树何何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 78: aload 0
      // 79: ldc2_w -6754339434456115082
      // 7c: lload 1
      // 7d: invokedynamic Z (Lcn/cool/cherish/module/impl/display/何树何友友何树何何树;JJ)V bsm=cn/cool/cherish/module/impl/display/何树何友友何树何何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 82: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(4000816160656379799L, -8242179286702081131L, MethodHandles.lookup().lookupClass()).a(266413061188748L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 94384632916833L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[12];
      int var7 = 0;
      String var6 = "\u001e®g[Z\u008bä\u0017ð\u0089h\u0097äñdh\u0018ùp\u0099¦\u0082V9çV\u008d\u0085Ãýºa\u0016\u0085þUñ6(\fU\u0018-äV«cPg\u009ah\u0015è\u0093ØÊü»ô§I\u0016(0Ó\u0003\u0010øÀ\u0082\u000bèÂðåeq®iRhÏh â\n\u00adm¥l\u001fª\u0013dÚ8\u0002ãkØ\u0089Þ4já\u001f¡E\u000e/\u009d\u0016\u001acáÃ\u0010oí¯/6RØ\u0000U\u0085§ë¹UÙY\u0018`^\u0099\r\u0018\u0094¦ùç´7î\u009fÖtÌ®6\u0010ýyGEñ\u0010.7âÚI\u000fþ\u0098hAÖÌ\u00844ÅÊ(\u000b\f+§m\u007fd=\u0004ì^ôt3/\u0093_\u0086ÃÛ¦Ç·-\f£±øs\u0014¬hO\u008d\u0017#7\u001a\u001c\u009f\u0010-ÖAPãÚµSúÍ\u008d\u0088\f;ÿµ";
      short var8 = 233;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[12];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u0097Î%\u0011\u0001?3Ñë-í\u00947á\b©\u0018o0¶,ø/Í\u008eù:\u001e\u008aY3]\u009d\u0007\u0011î×NÆÆ)";
                  var8 = 41;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private boolean Z(String[] array, String value) {
      long a = 何树何友友何树何何树.a ^ 4900687137651L;
      int var7 = array.length;
      c<"ã">(-3920864652363233826L, a);
      int var8 = 0;
      if (0 < var7) {
         String item = array[0];
         if (item.equals(value)) {
            return true;
         }

         var8++;
      }

      return false;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 26;
               case 1 -> 40;
               case 2 -> 11;
               case 3 -> 5;
               case 4 -> 57;
               case 5 -> 62;
               case 6 -> 24;
               case 7 -> 30;
               case 8 -> 29;
               case 9 -> 10;
               case 10 -> 36;
               case 11 -> 19;
               case 12 -> 50;
               case 13 -> 56;
               case 14 -> 42;
               case 15 -> 31;
               case 16 -> 9;
               case 17 -> 58;
               case 18 -> 32;
               case 19 -> 63;
               case 20 -> 61;
               case 21 -> 0;
               case 22 -> 15;
               case 23 -> 46;
               case 24 -> 8;
               case 25 -> 54;
               case 26 -> 12;
               case 27 -> 22;
               case 28 -> 48;
               case 29 -> 53;
               case 30 -> 25;
               case 31 -> 41;
               case 32 -> 59;
               case 33 -> 43;
               case 34 -> 47;
               case 35 -> 23;
               case 36 -> 37;
               case 37 -> 38;
               case 38 -> 20;
               case 39 -> 13;
               case 40 -> 60;
               case 41 -> 49;
               case 42 -> 17;
               case 43 -> 21;
               case 44 -> 14;
               case 45 -> 7;
               case 46 -> 1;
               case 47 -> 45;
               case 48 -> 52;
               case 49 -> 51;
               case 50 -> 3;
               case 51 -> 34;
               case 52 -> 16;
               case 53 -> 39;
               case 54 -> 28;
               case 55 -> 55;
               case 56 -> 6;
               case 57 -> 2;
               case 58 -> 18;
               case 59 -> 4;
               case 60 -> 44;
               case 61 -> 27;
               case 62 -> 35;
               default -> 33;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8940;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/何树何友友何树何何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/何树何友友何树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/何树何友友何树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 217 && var8 != 'G' && var8 != 229 && var8 != 'Z') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'l') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 227) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 217) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'G') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 229) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "ZLO\u001c\"9U\f\u0002\u0017($PQ\tQ 9]W\r\u001ac?TR\rQ)?JR\r\u001e4x佬栳伴厴历伃栨佷伴桮";
      j[1] = "6\u0018X\u001b%\u0006=\u0017ITY\u001f2\rG\u0017n/$\u001aK\n\u007f\u00033\u0017";
      j[2] = "d%\u0006_f\u001fkeKTl\u0002n8@\u0012\u007f\u0011k>M\u0012`\u001dw'\u0006qf\u0014b\u001dIP|\u0015";
      j[3] = "\n-4m\u0007#\u0005myf\r>\u00000r \u0005#\r6vkF%\u00043v \f%\u001a3vo\u0011b!\u0016^";
      j[4] = "\u0011\u001a";
      j[5] = "Kj\"7b+D*o<h6Awdzx0Ah\u007fz\u007f![ky&n![*^1~+]vo1~\tIjm3h6";
      j[6] = "\u0001LU1?_\u0004\u0003e9}S";
      j[7] = "!\u000f-EQU.O`N[H+\u0012k\bSU&\u0014oC\u0010佯众厪佖佳叵佯众桰栒";
      j[8] = "\u00030IlJs\b?X#+}\u00034\\y";
      j[9] = "\u0004\b\u0006\n\b\tWH\u000f\u0018wa>\u000e\u000f\u001cH\u0000G_\u0018\u0000N9";
      j[10] = "rMFyw|h\u0014@C桞栃叐桮校桚桞佇栊桮8\"}d)G^8$b";
      j[11] = "V\u001eqx]D\u000b\u001a/om叭桴桢佊佀厮佳估伦栎\u001dQOT\u001a+x\u0001C]@";
      j[12] = "ex .\u0018(\u007f!&\u0014ANv05mQvy 5\u0014Z<o;',U,oB";
      j[13] = "c|J\u0013\u000bAy%L)司古佟桟栭栰司古叁桟4\u0010EK}%\bG\u0001Bn";
      j[14] = "E'O{x+\u0018$\u000e?E伇桡历桩伜桜伇伥桜厳Ax8G\u007fM0%;\u0006;";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   @Override
   public String k() {
      long a = 何树何友友何树何何树.a ^ 128343474277117L;
      c<"ã">(583280541945021520L, a);
      return this.y() ? this.u() : b<"h">(5987, 78088210494373279L ^ a);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public String u() {
      long a = 何树何友友何树何何树.a ^ 17558607469341L;
      return c<"Ù">(this, 1871618493929375297L, a).getValue();
   }

   private String[] r() {
      long a = 何树何友友何树何何树.a ^ 73198814601577L;
      c<"ã">(2561436275255144388L, a);
      ArrayList fontNames = new ArrayList();
      fontNames.add(b<"h">(24938, 6238615390002569231L ^ a));
      File customDir = new File(
         c<"Ù">(Cherish.getResourcesManager(), 2561582793733754918L, a).getAbsolutePath() + File.separator + b<"h">(20147, 6033734510960660433L ^ a)
      );
      if (customDir.exists() && customDir.isDirectory()) {
         File[] files = customDir.listFiles((dir, name) -> {
            long ax = 何树何友友何树何何树.a ^ 106923577816682L;
            return name.toLowerCase().endsWith(b<"h">(20620, 7699700122549503716L ^ ax));
         });
         if (files != null) {
            int var8 = files.length;
            int var9 = 0;
            if (0 < var8) {
               File file = files[0];
               String fontName = file.getName().replace(b<"h">(27522, 8638067441964640995L ^ a), "");
               fontNames.add(fontName);
               var9++;
            }
         }
      }

      return fontNames.toArray(new String[0]);
   }

   public boolean y() {
      long a = 何树何友友何树何何树.a ^ 49597727208190L;
      c<"ã">(-1145212615599899565L, a);
      if (!this.W()) {
         return true;
      } else {
         File customDir = new File(
            c<"Ù">(Cherish.getResourcesManager(), -1145041907928398927L, a).getAbsolutePath() + File.separator + b<"h">(14558, 7434399829686512174L ^ a)
         );
         File fontFile = new File(customDir, this.X());
         return fontFile.exists() && fontFile.isFile();
      }
   }

   public String X() {
      long a = 何树何友友何树何何树.a ^ 111889399992200L;
      c<"ã">(5579163793373954341L, a);
      return this.W() ? c<"Ù">(this, 5578896856408724180L, a).getValue() + b<"h">(20620, 7699695809095745286L ^ a) : null;
   }

   public boolean W() {
      long a = 何树何友友何树何何树.a ^ 54546208285292L;
      c<"ã">(-2267140516411331391L, a);
      return !c<"Ù">(this, -2267442021421039824L, a).getValue().equals(b<"h">(5987, 78014705150874894L ^ a));
   }

   public void G() {
      long a = 何树何友友何树何何树.a ^ 54516736502183L;
      String[] newFonts = this.r();
      String currentValue = c<"Ù">(this, 3117455727515366651L, a).getValue();
      this.q().removeIf(value -> {
         long ax = 何树何友友何树何何树.a ^ 39037560134727L;
         return value == c<"Ù">(this, 2207748307950649627L, ax);
      });
      c<"G">(
         this,
         new ModeValue(
            b<"h">(9980, 2431397230819520337L ^ a),
            b<"h">(21911, 4577792376198650937L ^ a),
            newFonts,
            this.Z(newFonts, currentValue) ? currentValue : newFonts[0]
         ),
         3117455727515366651L,
         a
      );
      this.q().add(c<"Ù">(this, 3117455727515366651L, a));
   }

   private static String HE_WEI_LIN() {
      return "解放村多种2队1144号";
   }
}
