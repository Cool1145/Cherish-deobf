package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import cn.cool.cherish.ui.何何何树友树何友何友;
import cn.cool.cherish.ui.友树友树何友树友何何;
import cn.cool.cherish.ui.树树树友何树何何友树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友树树树树树树友树友 extends 树树友树友友何友友树 implements 何树友 {
   public final ModeValue 树何树何树友何何何树;
   public final BooleanValue 何友树友何树树何何何;
   public final BooleanValue 友何何友友树树树树树;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final Object[] n = new Object[13];
   private static final String[] o = new String[13];
   private static String HE_DA_WEI;

   public 友树树树树树树友树友() {
      long a = c ^ 2832790164778L;
      super(c<"h">(24027, 1709981323521656085L ^ a), c<"h">(16565, 8382824224223762557L ^ a), 165.0F, 65.0F);
      this.树何树何树友何何何树 = new ModeValue(
         c<"h">(17664, 8274621531776687564L ^ a),
         c<"h">(1090, 5111713682636627080L ^ a),
         new String[]{c<"h">(26320, 7152579379582549527L ^ a), c<"h">(25485, 5560464700377742150L ^ a), c<"h">(12168, 7906952137056057161L ^ a)},
         c<"h">(3925, 5832501323632400282L ^ a)
      );
      this.何友树友何树树何何何 = (BooleanValue)new BooleanValue(c<"h">(23489, 3289681977236685580L ^ a), c<"h">(16136, 577192576573695937L ^ a), false)
         .i(
            () -> {
               long ax = c ^ 57915581307993L;
               d<"c">(-987042413075941436L, ax);
               return !d<"à">(this, -987131240359748110L, ax).C(c<"h">(444, 4564613496735911948L ^ ax))
                  && !d<"à">(this, -987131240359748110L, ax).C(c<"h">(3925, 5832446506808893161L ^ ax));
            }
         );
      this.友何何友友树树树树树 = (BooleanValue)new BooleanValue(c<"h">(425, 1261170356010146155L ^ a), c<"h">(11613, 5227992355454023069L ^ a), false).i(() -> {
         long ax = c ^ 94683778655167L;
         d<"c">(5596620384536725538L, ax);
         return !d<"à">(this, 5596676827787698708L, ax).C(c<"h">(444, 4564575775025360874L ^ ax));
      });
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(3715388951845742066L, -8760184461560210039L, MethodHandles.lookup().lookupClass()).a(88390609929339L);
      // $VF: monitorexit
      c = var10000;
      d();
      long var0 = c ^ 76142801980804L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[14];
      int var7 = 0;
      String var6 = "Ug¤`OÒW\u0012\u0081àf\u0018C\u00974l\u0010¨+Ç\u0019ÎêKÜ)/o\bKU\u0090\u0004\u0018I\u000f»o_\u00ad\u0095¾Ë\"\u0098k]>:¥Õ@g_Ø\r\u0097r\u0018Y&Id,e+\u009dUÓqPÞhN+kioñá\u008d\u0095\b \u00838Hc\"Ïûèçíh~üØíäac~«\u008a=0¥.\u0089¥\u007fî*e\u008b\u00109Ø\u001e\u0004O²\u0012R\u00ad\u0015jh9,¿á\u0010q7¨Ð\u0095±\u001ez½ú\u0013\u0004\u0085Á\u0018\u0083\u0018UD\u0019×\u0013ÌÙ\u0083\u0084\u00065x\u001f¿BÒÇ{\u0095O\"\u009e¼Ü >Ï\u001eüW\u0091¸ò\u0099'\u008aùò]éåÆSb_\u0091ß´ñT\u000büê\u0018\u009c0ï \u0094°°p±9çÇÒªÊúfP¦T\\ã¬B\u0013b¬\u0016\u0087jáÔºóíµ\u0010à×±í\u0004¿rE\u007f·ý2í{{\u0091\u0018\u009b\u0017£È*Z\u001e\u0085NJAi\u001e\u000beO*\r\u0007Á¼åq\u0004";
      short var8 = 283;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = d(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     k = var9;
                     l = new String[14];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "¾xÙÒ\u0090w(hR\u0088q\u009f\u0093c5»\u00100¸Â\u0091\u008aÃ L¡iVt\u0086Íw¿";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void J(Render2DEvent event) {
      long a = c ^ 119017415854311L;
      long ax = a ^ 65001135333337L;
      d<"c">(2806598768595624826L, a);
      if (!this.w(new Object[]{ax})) {
         this.T(d<"à">(this, 2806685740736923980L, a).getValue());
         String var7 = d<"à">(this, 2806685740736923980L, a).getValue();
         byte var8 = -1;
         switch (var7.hashCode()) {
            case -1818419758:
               if (!var7.equals(c<"h">(3925, 5832543735755442775L ^ a))) {
                  break;
               }

               var8 = 0;
            case -1887554740:
               if (!var7.equals(c<"h">(23452, 8449924754621980311L ^ a))) {
                  break;
               }

               var8 = 1;
            case 902708232:
               if (var7.equals(c<"h">(444, 4564569025044546738L ^ a))) {
                  var8 = 2;
               }
         }

         switch (var8) {
            case 0:
               友树友树何友树友何何.R(event, this.r(), this.v(), d<"à">(this, 2806737297562675027L, a), d<"à">(this, 2806822427836275084L, a), this);
            case 1:
               树树树友何树何何友树.O(event, this.r(), this.v(), d<"à">(this, 2806737297562675027L, a), d<"à">(this, 2806822427836275084L, a), this);
            case 2:
               何何何树友树何友何友.D(event, this.r(), this.v(), d<"à">(this, 2806737297562675027L, a), d<"à">(this, 2806822427836275084L, a));
            default:
               this.b(event.poseStack());
         }
      }
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9206;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友树树树树树树友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = k[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树树树树树树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树树树树树树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 224 && var8 != 'Y' && var8 != 'q' && var8 != 'U') {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 219) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'c') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 224) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Y') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'q') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void d() {
      n[0] = "jLl\u0013\u007fae\f!\u0018u|`Q*^}amW.\u0015>gdR.^tgzR.\u0011i Aw\u0006";
      n[1] = "r#";
      n[2] = "\u000e@6'\r\r\u0001\u0000{,\u0007\u0010\u0004]pj\u000f\r\t[t!L\u000b\u0000^tj\u0006\u000b\u001e^t%\u001bL厦栿栉桕桳桳桼句栉厏";
      n[3] = "X\u0013\u007f ~\u001cWS2+t\u0001R\u000e9mg\u0012W\b4mx\u001eK\u0011\u007f\u000e~\u0017^+0/d\u0016";
      n[4] = "\bW\"o@\u007f\u0003X3 <f\fB=c\u000bV\u001aU1~\u001az\rX";
      n[5] = "q7JLA.~w\u0007GK3{*\f\u0001C.v,\bJ\u0000桐栃厒桵古句伔叙厒桵";
      n[6] = float.class;
      o[6] = "java/lang/Float";
      n[7] = "T/KV\u0017\u001d_ Z\u0019v\u0013T+^C";
      n[8] = ", ,\u0002e</n7o\u0007_=73\r9!?0<o";
      n[9] = "8PK\r3E}AZS_栤作样佺栬厜你作佳栾5e\fsE\u001a^%]j\u0015";
      n[10] = "+ 3K4\u0015\u007f-z\u0007U伩位厃栒档桌伩叓厃又zi\u001espr\u0015+\u000bo1";
      n[11] = "eS!\b\u0001\u000e1^hD`厬伃台叚栠厣伲桇株叚9\\\u0005=\u0003`V\u001e\u0010!B";
      n[12] = ",hay\u001baiyp'ws\u0015-=8\u0018xd}`.N\u0019.&t.\u0016h~{bxw";
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 10;
               case 1 -> 0;
               case 2 -> 35;
               case 3 -> 61;
               case 4 -> 33;
               case 5 -> 43;
               case 6 -> 25;
               case 7 -> 52;
               case 8 -> 48;
               case 9 -> 30;
               case 10 -> 14;
               case 11 -> 28;
               case 12 -> 29;
               case 13 -> 17;
               case 14 -> 24;
               case 15 -> 49;
               case 16 -> 5;
               case 17 -> 42;
               case 18 -> 3;
               case 19 -> 8;
               case 20 -> 51;
               case 21 -> 53;
               case 22 -> 19;
               case 23 -> 27;
               case 24 -> 44;
               case 25 -> 34;
               case 26 -> 60;
               case 27 -> 40;
               case 28 -> 39;
               case 29 -> 1;
               case 30 -> 59;
               case 31 -> 47;
               case 32 -> 57;
               case 33 -> 56;
               case 34 -> 13;
               case 35 -> 9;
               case 36 -> 46;
               case 37 -> 20;
               case 38 -> 21;
               case 39 -> 38;
               case 40 -> 23;
               case 41 -> 15;
               case 42 -> 37;
               case 43 -> 45;
               case 44 -> 54;
               case 45 -> 6;
               case 46 -> 63;
               case 47 -> 36;
               case 48 -> 22;
               case 49 -> 4;
               case 50 -> 41;
               case 51 -> 2;
               case 52 -> 16;
               case 53 -> 58;
               case 54 -> 11;
               case 55 -> 26;
               case 56 -> 55;
               case 57 -> 50;
               case 58 -> 12;
               case 59 -> 7;
               case 60 -> 31;
               case 61 -> 18;
               case 62 -> 32;
               default -> 62;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String HE_SHU_YOU() {
      return "何建国230622195906030014";
   }
}
