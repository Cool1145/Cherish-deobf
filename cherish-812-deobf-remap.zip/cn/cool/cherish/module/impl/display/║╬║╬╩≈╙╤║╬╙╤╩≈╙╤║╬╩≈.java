package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import cn.cool.cherish.utils.animations.何何友树友树友树树何;
import cn.cool.cherish.utils.animations.友何友树树树树何树友;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.item.ItemStack;

public class 何何树友何友树友何树 extends 树树友树友友何友友树 implements 何树友 {
   public static 何何树友何友树友何树 何友何树何何树何友友;
   private final NumberValue 何何友友友树何何友树;
   private final 友何友树树树树何树友 何何友友友树友树友友;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final Object[] n = new Object[26];
   private static final String[] o = new String[26];
   private static String HE_DA_WEI;

   public 何何树友何友树友何树() {
      long a = c ^ 106096033556113L;
      long ax = a ^ 32299087979485L;
      super(c<"e">(19708, 5361809612020177130L ^ a), c<"e">(32, 3506708289914999863L ^ a), 200.0F, 100.0F);
      this.何何友友友树何何友树 = new NumberValue(c<"e">(667, 928028585634109070L ^ a), c<"e">(22084, 2323853417375220304L ^ a), 64, 32, 128, 8);
      this.何何友友友树友树友友 = new 何何友树友树友树树何(200, 1.0, ax, 1.0F);
      d<"a">(this, -7575490449870482455L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-6303842651089548664L, -5002861936335206411L, MethodHandles.lookup().lookupClass()).a(165941192646720L);
      // $VF: monitorexit
      c = var10000;
      d();
      long var0 = c ^ 118268141151082L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "Mæ©çï¬ë0ê\u0014\u0012\u008e4-ñ\u001dç\u0015´ã¾ó\r\nwíi`\u00033Mx\u00181q?dî\u008dK`0\u008bZ°²{+c¿1éx\u000bªôh";
      byte var8 = 57;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = d(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     k = var9;
                     l = new String[4];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "VùQ7Ê·Ò§D](¾ês¹^Âñõ\u0085WW[V \u0097É\u0000o!ßF,t4\u008ah½ü?êÖ}\u008bÈ\u0081íù«=]GH\bS¸f";
                  var8 = 57;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 719;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/何何树友何友树友何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = k[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/何何树友何友树友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private ItemStack c() {
      long a = c ^ 46833637964280L;
      d<"K">(5310299844979798075L, a);
      int i = 0;
      if (0 < mc.player.getInventory().getContainerSize()) {
         ItemStack stack = mc.player.getInventory().getItem(0);
         if (stack.getItem() == d<"ï">(5311835771125696103L, a)) {
            return stack;
         }

         i++;
      }

      return d<"ï">(5311526470018361732L, a);
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'j' && var8 != 'e' && var8 != 239 && var8 != 'a') {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 225) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'K') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'j') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'e') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void d() {
      n[0] = "Vb>\fkTVb)Pg[L)=MtQ\\)#VcP\u0016N>GknLf)I";
      n[1] = " \u007fyz+| \u007fn&'s:4z;4y*4d #x`Sy1+f";
      n[2] = "\u0018GjR,0\u0018G}\u000e ?\u0002\fi\u001335\u0012\fw\b$4Xkj\u0019,";
      n[3] = "|__\u0013.\u0014s\u001f\u0012\u0018$\tvB\u0019^,\u0014{D\u001d\u0015o\u0012rA\u001d^%\u0012lA\u001d\u00118UWd5";
      n[4] = "vM";
      n[5] = "ZgU{}\u001dU'\u0018pw\u0000Pz\u00136\u007f\u001d]|\u0017}<\u001bTy\u00176v\u001bJy\u0017yk\\佬作桪叓佇厹栨参伮栉";
      n[6] = "\"t\u000b\u000fsX){\u001a@\u000fA&a\u0014\u00038q0v\u0018\u001e)]'{";
      n[7] = "\u0007\u001d\u0016%\u001e \b][.\u0014=\r\u0000Ph\u0004;\r\u001fKh\u0010!\r\u001eY2\u0018 \n\u0000\u0016厍伤厄桵桢栩厍桠会厯";
      n[8] = "\"{iOEH-;$DOU(f/\u0002\\F-`\"\u0002CJ1yib_J#p5zKK4p";
      n[9] = "t$mAry{d Jxd~9+\fpys?/G3标栆厁桒叩取佃叜厁桒";
      n[10] = float.class;
      o[10] = "java/lang/Float";
      n[11] = "JhW6\u0006}E(\u001a=\f`@u\u0011{\fdLh\r{\fdLh\r&GW_c\u0017!MA@b\u001c";
      n[12] = "`u8.)ko5u%#vjh~c3pjwec'jjvw9/kmh8历伓叏栒栊标桜伓栕又";
      n[13] = "%.\u000fG`\u001a.!\u001e\b\u0001\u0014%*\u001aR";
      n[14] = "\u0001\u0006\u0007\u0007TC\b\u0001XAjbvafxZ\u0006\fE\u0004\u0001S\u0001S\u0003";
      n[15] = "3\rD4!\u001fwXKoG5\t\r\u001cr,\u0015`U]=9m";
      n[16] = "\u0016 \u001aqp\u0000\u0010#\u0016oH伱栳桋佶栓压厯佷厑佶\nt\u001e\u001b)\u0013fr\u001d\u00177";
      n[17] = "_Q8\u0002+WQ\u0017kh&i\u0006\u00114Xsi:MpY\"]SC6\n";
      n[18] = "\f^z'SN\t\u001d}i2伮佭厦叛叛栫伮佭厦栁\u0018\u000f\fA\u0000\u007f|T\u001fO\u0017";
      n[19] = "|\u0004\u007f%/Z8Z*zS佤伟厨栂桟桊佤厁厨变Fl\u0004x\u0015+)=V#\u0010";
      n[20] = "\u0004M!Vh\u001c\u0001\u000e&\u0018\t佼叻伫桚伴佔核佥厵厀i5\u001aZI\"T0Y]\u0007";
      n[21] = ",m3q\u0017\"|6q.l|Bns+V(BRpo\fre,$}\u0015/";
      n[22] = "ys[o}\u0000|0\\!\u001c你优压叺厓栅叾桜压叺P,S}\"\u0005n`G52";
      n[23] = "\u001cu\u0005\u0019%4\u00196\u0002WDc rV\\tx\u0011 \bBt\t\u001c\u007f\u001d\u001658N!\u0003\u0016D";
      n[24] = "(N(%Tpl\u0010}z(叐佋叢厏桟叫低栏核厏F\u0017.,_|)F|wZ";
      n[25] = ",\u0014\u00173Sn*\u0017\u001b-k佟栉桿栿伕伶叁叓厥句HWp!\u001d\u001e$Qs-\u0003";
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/何何树友何友树友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 63;
               case 1 -> 45;
               case 2 -> 43;
               case 3 -> 7;
               case 4 -> 55;
               case 5 -> 3;
               case 6 -> 13;
               case 7 -> 54;
               case 8 -> 12;
               case 9 -> 9;
               case 10 -> 5;
               case 11 -> 40;
               case 12 -> 56;
               case 13 -> 39;
               case 14 -> 18;
               case 15 -> 53;
               case 16 -> 38;
               case 17 -> 34;
               case 18 -> 0;
               case 19 -> 42;
               case 20 -> 49;
               case 21 -> 2;
               case 22 -> 41;
               case 23 -> 6;
               case 24 -> 21;
               case 25 -> 47;
               case 26 -> 33;
               case 27 -> 46;
               case 28 -> 59;
               case 29 -> 23;
               case 30 -> 24;
               case 31 -> 50;
               case 32 -> 22;
               case 33 -> 44;
               case 34 -> 8;
               case 35 -> 35;
               case 36 -> 25;
               case 37 -> 14;
               case 38 -> 57;
               case 39 -> 15;
               case 40 -> 20;
               case 41 -> 1;
               case 42 -> 60;
               case 43 -> 31;
               case 44 -> 62;
               case 45 -> 17;
               case 46 -> 16;
               case 47 -> 19;
               case 48 -> 28;
               case 49 -> 51;
               case 50 -> 27;
               case 51 -> 37;
               case 52 -> 10;
               case 53 -> 30;
               case 54 -> 4;
               case 55 -> 61;
               case 56 -> 52;
               case 57 -> 36;
               case 58 -> 58;
               case 59 -> 11;
               case 60 -> 32;
               case 61 -> 48;
               case 62 -> 26;
               default -> 29;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   @EventTarget
   public void t(Render2DEvent event) {
      long a = c ^ 52433312608657L;
      long ax = a ^ 3492625343318L;
      long axx = a ^ 61365381232883L;
      long axxx = a ^ 75423513131001L;
      long axxxx = a ^ 123123526289503L;
      d<"K">(133134067963492434L, a);
      if (!this.w(new Object[]{axx}) && event.poseStack() != null) {
         ItemStack compassItem = this.c();
         if (compassItem.isEmpty()) {
            d<"j">(this, 134728183496299027L, a).H(d<"ï">(134834578135399105L, a), axxxx);
            if (d<"j">(this, 134728183496299027L, a).B(d<"ï">(134834578135399105L, a), axxx)) {
               return;
            }
         } else {
            d<"j">(this, 134728183496299027L, a).H(d<"ï">(134381271951593118L, a), axxxx);
         }

         PoseStack poseStack = event.poseStack();
         float size = d<"j">(this, 134988776720769240L, a).getValue().floatValue();
         d<"e">(this, size, 135062823230357901L, a);
         d<"e">(this, size, 134277438227697733L, a);
         float animationOutput = (float)d<"j">(this, 134728183496299027L, a).T(ax);
         if (!(animationOutput <= 0.001F)) {
            if (event.side() == d<"ï">(133062867109558941L, a)) {
               poseStack.pushPose();
               poseStack.translate(this.r() + d<"j">(this, 135062823230357901L, a) / 2.0F, this.v() + d<"j">(this, 134277438227697733L, a) / 2.0F, 0.0F);
               poseStack.scale(animationOutput, animationOutput, 1.0F);
               poseStack.translate(-d<"j">(this, 135062823230357901L, a) / 2.0F, -d<"j">(this, 134277438227697733L, a) / 2.0F, 0.0F);
               poseStack.pushPose();
               poseStack.scale(size / 16.0F, size / 16.0F, 1.0F);
               event.guiGraphics().renderItem(compassItem, 0, 0);
               poseStack.popPose();
               poseStack.popPose();
            }

            this.b(event.poseStack());
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String HE_WEI_LIN() {
      return "何炜霖230622200409390090";
   }
}
