package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.友友友何树友何树树树;
import cn.cool.cherish.ui.何何友友树何树何友树;
import cn.cool.cherish.ui.何何树何何友何友树何;
import cn.cool.cherish.ui.树何树何何树树树树何;
import cn.cool.cherish.ui.树树友何友树友友树何;
import cn.cool.cherish.utils.animations.何何何何何友树树树友;
import cn.cool.cherish.utils.animations.友何树友树何何友树树;
import cn.cool.cherish.utils.animations.树友树何树树何树树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友友何何友何友树何树 extends 友友友何树友何树树树 implements 何树友 {
   public static 友友何何友何友树何树 何树树何何友何友何何;
   private final ModeValue 何何何树何树何树何树 = new ModeValue("Mode", new String[]{"Normal", "Shadow", "Glass", "Off"}, "Glass");
   private final NumberValue 友友树友友树何树树何 = new NumberValue("Max Messages", "最大消息数", 10, 5, 20, 1);
   private final NumberValue 何树友友何何友何友友 = new NumberValue("Font Size", "字体大小", 14, 8, 20, 1);
   private final NumberValue 友何友树何树树树友何 = new NumberValue("Background Alpha", "背景透明度", 80, 1, 255, 1);
   private final BooleanValue 何何友友何友友友友友 = new BooleanValue("Text Shadow", "文字阴影", true);
   private final NumberValue 友友友树友友友友何友 = new NumberValue("Message Spacing", "消息间距", 2, 0, 10, 1);
   private final NumberValue 何树树何树友树何何树 = new NumberValue("Corner Radius", "圆角半径", 6, 2, 12, 1);
   private final List<友友何何友何友树何树.树何树何友友树何何友> 友何何友树何树树何何 = new ArrayList<>();
   private final 何何何何何友树树树友 友友友友何何友树友友 = new 树友树何树树何树树何(37618987749219L, 200, 1.0, 1.0F);
   private static String 何树何树何友何何友何;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final Object[] n = new Object[35];
   private static final String[] o = new String[35];
   private static String HE_SHU_YOU;

   public 友友何何友何友树何树() {
      super("IRCGui", "IRC消息", 300.0F, 150.0F);
      何树树何何友何友何何 = this;
      this.J(true);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3689030038377290764L, -3275519859846810502L, MethodHandles.lookup().lookupClass()).a(157195603826120L);
      // $VF: monitorexit
      c = var10000;
      c();
      B("bmc2Y");
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(108368691860371L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[30];
      int var5 = 0;
      String var4 = "\u008bõ\u008f¹\u0080\bW\u001b\u0092a:%\bùG\u0001 üÌ¡\u001bâi7f°Ú\u0011\u000e\u0015Á\u0014±×~\u001fz\bba~m6Ä\u0085eXÖ~ %\u008b\fÑ+nàn\u0010H#\u0089\u009f¯é\t\\\u0016\u0096\u0016\u008a^¶\u00802]\u0083T\u0098ÐÅ\u000b\u0010ÙkëÁÌL\u0015n\u008c·ã\u0014Ç\u0007\u0080\u0086 º\u0081êùLfºrè\u0007ùG´\u0005è\u0007\fÁ.K\u000b³òiiÎ[\u0093úOÓÆ\u0018±=ëÛî°}UmÀÏ\u0002çÀ\u0087\u0080Õó\u0089K|\u008d\u0090' êâÖ\u0085Â\u0086½ìþ`)ó®\u0005ðr¢\u0000u`XÙÓ\u0012l6b\u009f8;\u001cî\u0010\u0016$)9\u0007ßOË»6Î\u0005\u009d¨[\u001d\u0010{Ta1\u0014=Â)\u008a\u000b\u0089h\u0011R\"h\u0010Õ¶ÇýJÁü\u0083M¿ýj\u00ad\u00866x\u0010pN\f@\u0088\u009fÆr}-ü\u0011ÄXû¨ Oº\u0010² Ô\u0094ºÃø¿Ê¢\u008bµ\u000bÈWV\u0087Bå\u001c\u0085\u008a\f\u0082\u0016¥¢Ý®\u0018µ«£\u007f«\u00adwK¿ÔXT\b[¥\u001bjÇ\u009b+.!\bª 8¾ü¦\u0015y¿\u00930iþN¬Ó¦KÌv\u0006rÑÃ\u0014È³Òõ\u0012m¥\u0082è\u0010Ñ ×\u008cØ7·µÈ©6ª\u000f\u009b»Ë\u0018\u0093çæ\u0002·cVÇ·³gI)X{¼\u0087\u0010ÏBÚ«\u00ad\u009c\u0018¶\u008fÿR+£ü\u008e%\u0082ß^Ç0?ßÖB\u0085·5ú¤©\u0010ÙÐ?fS§#Ø§\u0099ã\u008aU,Úu\u0018,ÿ-|\tæè¢Dé`\"ÒT%w\u000fX>2vÄQ}\u0018ûZÄ~h[\u0090æ=«,.z\u0097ívJüÓ\"\u0007Z\u0002E\u0010UÙ+ð\u0083!I\u0095e¼Ö+ÔÿäK Æ0ç©¬Ò(G<iàL©Ö\u0019\u0019\u007fHaÐºýâìÈ\u0006%½\u0006Ï¶\u008a(\u0003Ì¿Ïrò$¹Î¸\u009fêãH&\u0014\u0017²±ôqwN°?<¨üaRxîCÇB7÷\u0018£\u0082\u0018É\u009d¼õû®?¨£Ð;Mb}ÇX8CcA{Õåb HøYNgÚM\u0003QuÿÎ=#\u008d\u009f²®\u0098Bâ\u0084£H\u0080ÔØÝîÉr,\u0018téè0ÛMðìT¹Ág~\u0006\u008aAP]úpv³\u008f7\u0018ÈIH§ûa\u0084\u000ezñ&\u0000\u001eß_$ÁUlQýË\u0081\u001a\u0010åäÉw\u0004\u0093\u0083@)ª-\u0000\u001eëQ\u0019";
      short var6 = 699;
      char var3 = 16;
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = d(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     k = var7;
                     l = new String[30];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "\u0091\u001b\\\u009d|+ÿ9\u0010ÿÎ\u0016©Ó\u0096y 8p5\u000fÀ\bÒyÍ'º7ÉÝkßª/|ûæ\u0090Fxo\u0011V\u008c±Þ!\u0099";
                  var6 = 49;
                  var3 = 16;
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   private String B(int state) {
      return switch (state) {
         case 0, 1 -> "";
         case 2 -> "§4警告§r";
         case 3 -> "§a成功§r";
         case 4 -> "§c失败§r";
         case 5 -> "§c错误§r";
         default -> "§7消息§r";
      };
   }

   public static void B(String var0) {
      何树何树何友何何友何 = var0;
   }

   public static String Z() {
      return 何树何树何友何何友何;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何何友何友树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26538;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何何友何友树何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u0095÷Ü5I×\u000ej, \u0014áïÁ\u001aåÏ\u0004\u0019BI\u009e1\u0086£@, óV\u0097Ôªp×}eö4ÜNú\u008b\u007f, \u001aW.»\u0015\u007fÚ´, > sG¯Ö§\"æÐ\u0014ÜýûC\\, }ÔVU\u00963Ìq5\\\u000f[@KPô, ý\u0015±:i\u008a7îøãÃ\u0012F¶\u0007\u0000, N½2#Ìú;\u0006, R\u0018bËyÂº\u0082, ½ÿÒÒ$X\u008ac, \u0003ª\u00adæ\u008a\u0007\u0001\u001c, w\u0080¦\u0013¬ µÂëUqÔ\u0001#2%, \u0085\u0089\u0003A\fµ_s~áD\u0010bcî\u009a, uJr\u0088Ôï")[var5]
            .getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static void c() {
      n[0] = "jhoSFNe(\"XLS`u)\u001eDNms-U\u0007Hdv-\u001eMHzv-QP\u000f参反伔佥叢佴参栗伔校\r栰作栗伔叻叢栰作体厊";
      n[1] = "Pn\u0017B=8[a\u0006\r@ Hf\u000fD";
      n[2] = int.class;
      o[2] = "java/lang/Integer";
      n[3] = "kB[M4ud\u0002\u0016F>ha_\u001d\u00006ulY\u0019Kuse\\\u0019\u0000?s{\\\u0019O\"4參叧传佻厐住參栽传栿";
      n[4] = "z)4\u0003\u0005@uiy\b\u000f]p4rN\u001f[p+iN\u000bAp*{\u0014\u0003@w44伵伿佺佌伒发桱桻栾叒";
      n[5] = "\u0011jc\t\u001cL\u001aerF`U\u0015\u007f|\u0005We\u0003hp\u0018FI\u0014e";
      n[6] = "f65q\u001e(x>/>|4\u007f#";
      n[7] = ";Efd9Z4\u0005+o3G1X );Z<^$bx\\5[$)2\\+[$f/\u001b\u0010~\f";
      n[8] = "\u0013\u000e~:T\u0016f.u5EY\u001b6f2L\u0010s";
      n[9] = "Q)u0&%^i8;,8[43}?+^2>} 'B+u\u001d<'P\")\u0005(&G\"";
      n[10] = ":+\u001e\u0007/-5kS\f%006XJ560)CJ!,0(Q\u0010)-76\u001e厯伕桓厒桔佥伱压桓案";
      n[11] = "kE(\u00000\u001dd\u0005e\u000b:\u0000aXnM2\u001dl^j\u0006q厹參叠体桲厔伧栙栺栗";
      n[12] = float.class;
      o[12] = "java/lang/Float";
      n[13] = "\b\n;\u001c&#\u0007Jv\u0017,>\u0002\u0017}Q?-\u0007\u0011pQ !\u001b\b;=&#\u0007\u0001t\u0011\u001f-\u0007\u0011p";
      n[14] = "'?2_\tG(\u007f\u007fT\u0003Z-\"t\u0012\u0010I($y\u0012\u000fE4=2q\tL!\u0007}P\u0013M";
      n[15] = void.class;
      o[15] = "java/lang/Void";
      n[16] = "om\u0012NR*db\u0003\u00013$oi\u0007[";
      n[17] = "@$}*Z\u0010\u001d\"z98似伭栂桝桑佥似桩变桝H\b\u0001\fk~$Y\u001e\u001fu";
      n[18] = "5}\u0018&O\u001a7.\u0018w7伢佒厁厽佊叴厼双厁厽\u0017\u0006\u0019osO{S\r`3";
      n[19] = "E\u0000#mt\u007fGS#<\f叙厼叼历企佑叙桦叼历\\7vD\u0000$-v\"OT";
      n[20] = ",}h\u000f2z..h^J佂栏厁反佣众叜佋厁反>tegrpB{/*\u007f";
      n[21] = "K{E_<rI(E\u000eD叔厲厇栺厭厇叔厲伙叠nzm\u0000t]\u0012u'My";
      n[22] = "\u0001\f#\t\u000f+\\\n$\u001am桃史株佇桲估厙佬株佇k]:MC \u0007\f%^]";
      n[23] = "g\u0012\u000b[:wc\n\u001d;伛佃栚厣厷司厅标佞厣tC4rr]\n\u0002>d";
      n[24] = "W)\u0004l%\fUz\u0004=]\u0000m-\u0010<d\u0007\u001dp\u0019!;iVd\u0003d3\u0019\u000bm\u001e;]";
      n[25] = "\r\u0007S\u0016FY\u000f\u001a\u000eA!株株厴栯古佼株台伪佫'\u001fCVFQM\u001d^\u000b\u0011";
      n[26] = "$\u0004b6Qt&Wbg)叒佃佦叇栞佴栈标佦余\u0007\u0015p}YneO~bD";
      n[27] = "o\npJ>\u0005mYp\u001bF*UMd\u00177]+\fn\u0001F\t%O|\tx\u0011%\\.{";
      n[28] = "O\u0014cyBS\u0017Rb&-\u007fsV#4@R\u0011U#-G6";
      n[29] = "rIIbTYp\u001aI3,叿压桯召厐栵佡桑桯佲S\u0012F9FQ/\u001d\ftK";
      n[30] = "@\\\u000e#\u0004nB\u000f\u000er|佖伧伾桱住桥佖档伾桱\u0012Mw\u0005\u001cV\u007f\u001d6\u001b\u000e";
      n[31] = "\u001c\t\u0013/IR\u001eZ\u0013~1叴佻叵桬佃栨栮栿叵伨\u001e\u000fMW\u0006\u000bb\u0000\u0007\u001a\u000b";
      n[32] = "b\u0000\u000f5Fv`\u001dRb!栅桅伭桳余核佁企厳厩\u0004\u001fl9A\rn\u001dqd\u0016";
      n[33] = "k#E\u001c((o;S|桍伜栖伌栣伡桍厂佒伌:E1:`(\u0004Li91";
      n[34] = "\u0014yrz-\u0015\u0016*r+U伭样桟佉桒厖桩佳伛栍Kk\n_vj7d@\u0012{";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何何友何友树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 201 && var8 != 'C' && var8 != 'H' && var8 != 'j') {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 193) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'D') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 201) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'C') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'H') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 8;
               case 1 -> 54;
               case 2 -> 34;
               case 3 -> 55;
               case 4 -> 42;
               case 5 -> 56;
               case 6 -> 20;
               case 7 -> 52;
               case 8 -> 9;
               case 9 -> 36;
               case 10 -> 22;
               case 11 -> 0;
               case 12 -> 50;
               case 13 -> 61;
               case 14 -> 5;
               case 15 -> 13;
               case 16 -> 27;
               case 17 -> 7;
               case 18 -> 37;
               case 19 -> 63;
               case 20 -> 46;
               case 21 -> 29;
               case 22 -> 25;
               case 23 -> 26;
               case 24 -> 51;
               case 25 -> 15;
               case 26 -> 32;
               case 27 -> 2;
               case 28 -> 11;
               case 29 -> 38;
               case 30 -> 6;
               case 31 -> 4;
               case 32 -> 53;
               case 33 -> 33;
               case 34 -> 31;
               case 35 -> 62;
               case 36 -> 16;
               case 37 -> 43;
               case 38 -> 10;
               case 39 -> 44;
               case 40 -> 23;
               case 41 -> 48;
               case 42 -> 49;
               case 43 -> 14;
               case 44 -> 39;
               case 45 -> 17;
               case 46 -> 57;
               case 47 -> 45;
               case 48 -> 21;
               case 49 -> 40;
               case 50 -> 59;
               case 51 -> 3;
               case 52 -> 35;
               case 53 -> 19;
               case 54 -> 47;
               case 55 -> 12;
               case 56 -> 60;
               case 57 -> 28;
               case 58 -> 1;
               case 59 -> 41;
               case 60 -> 58;
               case 61 -> 24;
               case 62 -> 18;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   @EventTarget
   public void N(Render2DEvent event) {
      HUD.A();
      if (!this.Q(new Object[]{52406761729175L}) && event.poseStack() != null) {
         synchronized (this.友何何友树何树树何何) {
            if (this.友何何友树何树树何何.isEmpty()) {
               this.友友友友何何友树友友.n(友何树友树何何友树树.树树友树友何树友何何, 59020024422499L);
               if (this.友友友友何何友树友友.A(14032659181055L, 友何树友树何何友树树.树树友树友何树友何何)) {
                  return;
               }
            }

            PoseStack poseStack = event.poseStack();
            何何友友树何树何友树 font = Cherish.instance.t().H(this.何树友友何何友何友友.getValue().intValue());
            this.C();
            float maxWidth = 0.0F;
            float totalHeight = 0.0F;
            Iterator animationOutput = this.友何何友树何树树何何.iterator();
            if (animationOutput.hasNext()) {
               友友何何友何友树何树.树何树何友友树何何友 message = (友友何何友何友树何树.树何树何友友树何何友)animationOutput.next();
               String displayText = this.K(message);
               float textWidth = font.D(displayText);
               maxWidth = Math.max(0.0F, textWidth);
               float messageHeight = font.x() + this.友友友树友友友友何友.getValue().floatValue();
               totalHeight = 0.0F + messageHeight;
            }

            super.树友树何树何友何树何 = Math.max(200.0F, maxWidth + 16.0F);
            super.何何树树树何何树友树 = Math.max(30.0F, totalHeight + 8.0F);
            float animationOutputx = (float)this.友友友友何何友树友友.D(124111691745592L);
            if (!(animationOutputx <= 0.001F)) {
               poseStack.pushPose();
               poseStack.scale(animationOutputx, animationOutputx, 1.0F);
               float alphaMultiplier = this.友友友友何何友树友友.m(49524715818202L) == 友何树友树何何友树树.树树友树友何树友何何 ? animationOutputx : 1.0F;
               alphaMultiplier = Math.max(0.0F, Math.min(1.0F, alphaMultiplier));
               String var35 = this.何何何树何树何树何树.getValue();
               byte var36 = -1;
               switch (var35.hashCode()) {
                  case -1955878649:
                     if (!var35.equals("Normal")) {
                        break;
                     }

                     var36 = 0;
                  case -1819712192:
                     if (!var35.equals("Shadow")) {
                        break;
                     }

                     var36 = 1;
                  case 68884316:
                     if (!var35.equals("Glass")) {
                        break;
                     }

                     var36 = 2;
                  case 79183:
                     if (var35.equals("Off")) {
                        var36 = 3;
                     }
               }

               switch (var36) {
                  case 0:
                     树树友何友树友友树何.t(
                        poseStack,
                        this.N(),
                        this.C(),
                        super.树友树何树何友何树何,
                        super.何何树树树何何树友树,
                        this.友何何友树何树树何何,
                        alphaMultiplier,
                        this.何树友友何何友何友友.getValue().intValue(),
                        this.何何友友何友友友友友.getValue(),
                        this.友友友树友友友友何友.getValue().floatValue(),
                        this.友何友树何树树树友何.getValue().intValue(),
                        this.何树树何树友树何何树.getValue().floatValue(),
                        this
                     );
                  case 1:
                     树何树何何树树树树何.k(
                        poseStack,
                        this.N(),
                        this.C(),
                        super.树友树何树何友何树何,
                        super.何何树树树何何树友树,
                        this.友何何友树何树树何何,
                        alphaMultiplier,
                        this.何树友友何何友何友友.getValue().intValue(),
                        this.何何友友何友友友友友.getValue(),
                        this.友友友树友友友友何友.getValue().floatValue(),
                        this.友何友树何树树树友何.getValue().intValue(),
                        this.何树树何树友树何何树.getValue().floatValue(),
                        this
                     );
                  case 2:
                     何何树何何友何友树何.i(
                        poseStack,
                        this.N(),
                        this.C(),
                        super.树友树何树何友何树何,
                        super.何何树树树何何树友树,
                        this.友何何友树何树树何何,
                        alphaMultiplier,
                        this.何树友友何何友何友友.getValue().intValue(),
                        this.何何友友何友友友友友.getValue(),
                        this.友友友树友友友友何友.getValue().floatValue(),
                        this.友何友树何树树树友何.getValue().intValue(),
                        this.何树树何树友树何何树.getValue().floatValue(),
                        this
                     );
                  case 3:
                     何何友友树何树何友树 fontDrawer = Cherish.instance.t().H(this.何树友友何何友何友友.getValue().intValue());
                     float currentTextY = this.C();
                     Iterator var27 = this.友何何友树何树树何何.iterator();
                     if (var27.hasNext()) {
                        友友何何友何友树何树.树何树何友友树何何友 message = (友友何何友何友树何树.树何树何友友树何何友)var27.next();
                        String displayText = this.K(message);
                        fontDrawer.e(poseStack, displayText, this.N() + 8.0F, currentTextY + 4.0F, -1, this.何何友友何友友友友友.getValue());
                        float var10000 = currentTextY + (fontDrawer.x() + this.友友友树友友友友何友.getValue().floatValue());
                     }
                  default:
                     poseStack.popPose();
               }
            }
         }
      }
   }

   private String K(友友何何友何友树何树.树何树何友友树何何友 message) {
      String prefix = this.B(message.树何树何树何树友何何);
      return prefix + "->" + message.何何树友友友友树何友;
   }

   private static String HE_DA_WEI() {
      return "行走的50万——何炜霖";
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public void O(int state, String text) {
      HUD.A();
      List var8 = this.友何何友树何树树何何;
      synchronized (this.友何何友树何树树何何){} // $VF: monitorenter 

      try {
         友友何何友何友树何树.树何树何友友树何何友 message = new 友友何何友何友树何树.树何树何友友树何何友(state, text, System.currentTimeMillis());
         this.友何何友树何树树何何.add(0, message);
         if (this.友何何友树何树树何何.size() > this.友友树友友树何树树何.getValue().intValue()) {
            this.友何何友树何树树何何.remove(this.友何何友树何树树何何.size() - 1);
         }

         this.友友友友何何友树友友.n(友何树友树何何友树树.树树何树何树何何友友, 59020024422499L);
         // $VF: monitorexit
      } finally {
         // $VF: monitorexit
      }
   }

   public static class 树何树何友友树何何友 implements 何树友 {
      public final int 树何树何树何树友何何;
      public final String 何何树友友友友树何友;
      public final long 树友何何何友树何何友;
      private static int _何炜霖诈骗 _;

      public 树何树何友友树何何友(int state, String text, long timestamp) {
         this.树何树何树何树友何何 = state;
         this.何何树友友友友树何友 = text;
         this.树友何何何友树何何友 = timestamp;
      }

      private static String HE_JIAN_GUO() {
         return "何大伟：我要教育何炜霖";
      }
   }
}
