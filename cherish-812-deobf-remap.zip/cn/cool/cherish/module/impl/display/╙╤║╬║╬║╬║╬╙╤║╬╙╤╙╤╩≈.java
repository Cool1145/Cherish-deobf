package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.友友友何树友何树树树;
import cn.cool.cherish.ui.友树何友友树何何树树;
import cn.cool.cherish.ui.树友友树何友友树何树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

public class 友何何何何友何友友树 extends 友友友何树友何树树树 implements 何树友 {
   private final ModeValue 树何树友何树何友何何 = new ModeValue("Mode", "模式", new String[]{"Modern", "Glass"}, "Modern");
   public final BooleanValue 树何树友树何树友何友 = new BooleanValue("Text Shadow", "文字阴影", false).A(() -> this.树何树友何树何友何何.K("Modern"));
   public final ModeValue 友友友树树树何友树何 = new ModeValue("Background Mode", "背景模式", new String[]{"Old", "New"}, "New").A(() -> this.树何树友何树何友何何.K("Modern"));
   public static final Map<MobEffect, Integer> 何何何何友友友友友友;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final Object[] n = new Object[11];
   private static final String[] o = new String[11];
   private static String HE_DA_WEI;

   public 友何何何何友何友友树() {
      super("Effects", "药水显示", 90.0F, 30.0F);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3800535781950109258L, 5471200170024221603L, MethodHandles.lookup().lookupClass()).a(250509473823312L);
      // $VF: monitorexit
      c = var10000;
      c();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(138375852065842L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[15];
      int var7 = 0;
      String var6 = "âÇ\n\u0004ds\u0011TïÅ]\u008efQ\\\b\u0010\u0085\u0083\u0091ì\\ïo[ÞëHxËOÚ±\u0010*^(è9Ug©\u0095zeÀ\u0083\u009b©û\u0018±\u0012§æ÷\u0015yÄd\u0001\u0006#\u0097±ò7Ã¿\u0090\u0087>8\u009d÷ Æ¹\u0092YiËÌ(ä¨6ì\u007f\u0084\u008ddêJ\u001e80£;\u009a\u000e!Z7©\u0012\u001ap\u0010k·\u0019\u0015AÏ>r2{î\u0094[ë~\u0092 \u0006\u0003?)ÿ¥\u00062~lqJ\u0006ØY\u008dË\u007f\u0084IæÆa©Þ±ó©±\u001fë* \u0083m\u008d\u008f\u0095¼¥\u00919\u0000l§E\u0097\u0087E\u0080§L\u00810\u00196*lCÂdæ\u0011~0\u0010¼nÙÐ?MI²à\u007fB\u0018nH}Ø I j¤t`º;4ÄZo\u0006\u008b\u009a\u0081¼\u0001¤\u0099\u0012\u001b\u0081ù2?w]L\u0017i7\u0010ï\u000fàî\u0010Ú\u008c\u001cÿwøã\u0094Ó\bË\u0010«\u0005â\r\u000baTÿ\u0083õ¹\u0011mhá£\u0010U÷ñÆ\\Ébç\u0093¹Q7ûZ\u0089O";
      short var8 = 292;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = d(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     k = var9;
                     l = new String[15];
                     何何何何友友友友友友 = new HashMap<>();
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u007f\\*Ã\u009eÔÖl\u0016Æn\u000f\u0007×Ö2\u0010\u0099\u00ad\u0092Ã^ä\u0017}D|.8Îm\u0011\u0019";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友何何何何友何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16112;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友何何何何友何友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[2³Õ(£¼ñÚ, ®\u008c JP\u0093>\u0014, =üY'6L½S, .\u0092¬æüx3©ã\u001dËLa)T}, \tûxïÁÍëøÁ\u0084:P.\u0016\u009f\f, \u0089")[var5]
            .getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static void c() {
      n[0] = "6\u0017-\u0007\u000459W`\f\u000e(<\nkJ\u000651\fo\u0001E38\toJ\u000f3&\to\u0005\u0012t厞伬佖伱伾厑伀厲又桵";
      n[1] = "\u000b({\u001dUY\u0004h6\u0016_D\u00015=PLW\u000430PS[\u0018*{3UR\r\u00104\u0012OS";
      n[2] = "[k8c8KPd),DR_~'osbIi+rbN^d";
      n[3] = "\u0014\u0000\u000bXY\u0007\u001b@FSS\u001a\u001e\u001dM\u0015[\u0007\u0013\u001bI^\u0018\u0001\u001a\u001eI\u0015R\u0001\u0004\u001eIZOF?;a";
      n[4] = "\tx*\u000be\u000e|X!\u0004tA\u0001@2\u0003}\bi";
      n[5] = "~0J$D8`8Pk',d";
      n[6] = " l\u000f\\\u001eL+c\u001e\u0013\u007fB h\u001aI";
      n[7] = "X\u0002N\u0000IKIE\u001a?佩佭佩伤叠叼号右号厺#\u0004MOI\u0007B\u0001^RE";
      n[8] = "iT)o!\u00104\t;/S+SRj`9Y+\u0007ik6b";
      n[9] = "2isR\u0013*#.'m\u0007Qgja\u0003\u001cjeua\u0002nh&mp\u001fUj9mqm";
      n[10] = "-?$gH\u001a<xpX栬似桘厇伔桁佨厢伜伙I(\f\u0000  taI[";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 203 && var8 != 216 && var8 != 186 && var8 != 'J') {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 192) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 241) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 203) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 216) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 186) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友何何何何友何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 34;
               case 1 -> 8;
               case 2 -> 31;
               case 3 -> 2;
               case 4 -> 58;
               case 5 -> 19;
               case 6 -> 40;
               case 7 -> 13;
               case 8 -> 23;
               case 9 -> 55;
               case 10 -> 22;
               case 11 -> 25;
               case 12 -> 7;
               case 13 -> 57;
               case 14 -> 18;
               case 15 -> 10;
               case 16 -> 50;
               case 17 -> 30;
               case 18 -> 53;
               case 19 -> 20;
               case 20 -> 21;
               case 21 -> 48;
               case 22 -> 49;
               case 23 -> 38;
               case 24 -> 26;
               case 25 -> 32;
               case 26 -> 43;
               case 27 -> 51;
               case 28 -> 45;
               case 29 -> 37;
               case 30 -> 47;
               case 31 -> 12;
               case 32 -> 16;
               case 33 -> 59;
               case 34 -> 44;
               case 35 -> 60;
               case 36 -> 9;
               case 37 -> 1;
               case 38 -> 27;
               case 39 -> 41;
               case 40 -> 36;
               case 41 -> 61;
               case 42 -> 24;
               case 43 -> 4;
               case 44 -> 39;
               case 45 -> 56;
               case 46 -> 15;
               case 47 -> 29;
               case 48 -> 42;
               case 49 -> 3;
               case 50 -> 28;
               case 51 -> 6;
               case 52 -> 0;
               case 53 -> 11;
               case 54 -> 14;
               case 55 -> 52;
               case 56 -> 62;
               case 57 -> 35;
               case 58 -> 63;
               case 59 -> 17;
               case 60 -> 5;
               case 61 -> 46;
               case 62 -> 54;
               default -> 33;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private List<MobEffectInstance> v() {
      return mc.player == null ? new ArrayList<>() : new ArrayList<>(mc.player.getActiveEffects());
   }

   @EventTarget
   public void Y(Render2DEvent event) {
      HUD.A();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.X(this.树何树友何树何友何何.getValue());
         List<MobEffectInstance> effects = this.v();
         this.N(effects);
         String var8 = this.树何树友何树何友何何.getValue();
         byte var9 = -1;
         switch (var8.hashCode()) {
            case -1984932033:
               if (!var8.equals("Modern")) {
                  break;
               }

               var9 = 0;
            case 68884316:
               if (var8.equals("Glass")) {
                  var9 = 1;
               }
         }

         switch (var9) {
            case 0:
               友树何友友树何何树树.I(event.poseStack(), effects, this.N(), this.C(), this);
            case 1:
               树友友树何友友树何树.c(event.poseStack(), effects, this.N(), this.C(), this);
            default:
               this.S(event.poseStack());
         }
      }
   }

   private void N(List<MobEffectInstance> effects) {
      HUD.A();
      ArrayList needRemove = new ArrayList();
      Iterator var6 = 何何何何友友友友友友.entrySet().iterator();
      if (var6.hasNext()) {
         Entry<MobEffect, Integer> entry = (Entry<MobEffect, Integer>)var6.next();
         MobEffect effect = entry.getKey();
         MobEffectInstance currentEffect = mc.player.getEffect(effect);
         if (currentEffect == null || currentEffect.getDuration() <= 0 && currentEffect.getDuration() != -1) {
            needRemove.add(effect);
         }
      }

      needRemove.forEach(何何何何友友友友友友::remove);
      var6 = effects.iterator();
      if (var6.hasNext()) {
         MobEffectInstance instance = (MobEffectInstance)var6.next();
         MobEffect effect = instance.getEffect();
         int currentDuration = instance.getDuration();
         if (currentDuration == -1) {
            何何何何友友友友友友.put(effect, -1);
         }

         何何何何友友友友友友.compute(effect, (key, oldDuration) -> {
            HUD.A();
            return oldDuration != null && oldDuration != -1 && currentDuration <= oldDuration ? oldDuration : currentDuration;
         });
      }
   }

   private static String HE_WEI_LIN() {
      return "何建国230622195906030014";
   }
}
