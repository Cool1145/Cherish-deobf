package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.树友何友何何友树树友;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友树树树树何树树友友 extends Module implements 何树友 {
   public static 友树树树树何树树友友 树友友树友友友何树友;
   public final ModeValue 友友树何友何友树树何;
   public final 树友何友何何友树树友 何何何友何何何树何友;
   public final 树友何友何何友树树友 何树何何友树何友友友;
   private static String[] 树友友树树树树何树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[8];
   private static final String[] k = new String[8];
   private static String HE_SHU_YOU;

   public 友树树树树何树树友友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/display/友树树树树何树树友友.a J
      // 003: ldc2_w 9135756910710
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 529
      // 00c: ldc2_w 5926107561926607109
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 10173
      // 019: ldc2_w 1189214465640981677
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w -5242582081290049479
      // 026: lload 1
      // 027: invokedynamic ß (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/ModeValue
      // 033: dup
      // 034: sipush 16998
      // 037: ldc2_w 5646990900531265919
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 18481
      // 044: ldc2_w 7578619591631801134
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 4
      // 04f: anewarray 67
      // 052: dup
      // 053: bipush 0
      // 054: sipush 18746
      // 057: ldc2_w 6105086798064814637
      // 05a: lload 1
      // 05b: lxor
      // 05c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 061: aastore
      // 062: dup
      // 063: bipush 1
      // 064: sipush 12049
      // 067: ldc2_w 3502034651453942797
      // 06a: lload 1
      // 06b: lxor
      // 06c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 071: aastore
      // 072: dup
      // 073: bipush 2
      // 074: sipush 28913
      // 077: ldc2_w 9127905271512282087
      // 07a: lload 1
      // 07b: lxor
      // 07c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 081: aastore
      // 082: dup
      // 083: bipush 3
      // 084: sipush 18843
      // 087: ldc2_w 4985674131498240645
      // 08a: lload 1
      // 08b: lxor
      // 08c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 091: aastore
      // 092: sipush 13524
      // 095: ldc2_w 5640486768835753935
      // 098: lload 1
      // 099: lxor
      // 09a: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09f: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 0a2: putfield cn/cool/cherish/module/impl/display/友树树树树何树树友友.友友树何友何友树树何 Lcn/cool/cherish/value/impl/ModeValue;
      // 0a5: aload 0
      // 0a6: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 0a9: dup
      // 0aa: sipush 15352
      // 0ad: ldc2_w 3453105261608696034
      // 0b0: lload 1
      // 0b1: lxor
      // 0b2: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b7: sipush 19245
      // 0ba: ldc2_w 191903171381430320
      // 0bd: lload 1
      // 0be: lxor
      // 0bf: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c4: new java/awt/Color
      // 0c7: dup
      // 0c8: sipush 255
      // 0cb: sipush 255
      // 0ce: sipush 255
      // 0d1: invokespecial java/awt/Color.<init> (III)V
      // 0d4: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 0d7: putfield cn/cool/cherish/module/impl/display/友树树树树何树树友友.何何何友何何何树何友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 0da: aload 0
      // 0db: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 0de: dup
      // 0df: sipush 25535
      // 0e2: ldc2_w 3521228545744609447
      // 0e5: lload 1
      // 0e6: lxor
      // 0e7: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ec: sipush 5050
      // 0ef: ldc2_w 9005547012760752303
      // 0f2: lload 1
      // 0f3: lxor
      // 0f4: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f9: new java/awt/Color
      // 0fc: dup
      // 0fd: sipush 255
      // 100: sipush 255
      // 103: sipush 255
      // 106: invokespecial java/awt/Color.<init> (III)V
      // 109: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 10c: putfield cn/cool/cherish/module/impl/display/友树树树树何树树友友.何树何何友树何友友友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 10f: aload 0
      // 110: ldc2_w -5242499551333507337
      // 113: lload 1
      // 114: invokedynamic î (Lcn/cool/cherish/module/impl/display/友树树树树何树树友友;JJ)V bsm=cn/cool/cherish/module/impl/display/友树树树树何树树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 119: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-8010318131927904526L, 6629639885979053299L, MethodHandles.lookup().lookupClass()).a(163844113510894L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 56475527091985L;
      a();
      c<"q">(null, 25067681230412819L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[13];
      int var5 = 0;
      String var4 = "\u0087øýn~Ç\u0088Ûé°\u0013\bK\u009aÔ\f \u0004#°-«E+ï³9wº¼\u000e½[Ö)Ëî\u0083ËIX> r\u009eK$\u008a|\u0010\u0015©3M+¿ÐOq\u008a\u0091\u00048ó\u0096® Ü²g¡Ç\n \u001e\u000b)Ý#ä\u008a£¶\u0096Â\u009c3OðÍÒ|\u008f_<\u0094ÔÈÎ\u00182Ý\u0099 4ðÁ\\\n4\u0091PLß jZ{ÿ@kÖéù\u0018\u0080Ì\u009aITÅEÝÐF\u0001(µy=ÒÎ\u00006ûv\u0099%«\u0018\u009bR\u0099ÇN\u0086v¶\fC;:ÿ\u0099 /e\u000bT\u0001\u0019Ú7H\u0010ë~çf99¹\u001e«\u009b8c_ýö\u009a\u0010&Q.Í\u0082ìûl\u0090ÇË\u0096±ç\u0004P «Û\rw\u0001£\u008e}Y\u0084$ÅD\u008e\u0010@ü\u0091~\u0098xÆpè\u001d=E\u009a A\n)\u0010¸Ð\u001dö\u0082®}\u0089\b\u00015·Ó¨Ô\u008a";
      short var6 = 258;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = c(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     c = var7;
                     h = new String[13];
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "8K\u0013\u0006ME\u009f\u008a\u0091ÖÂ\u008a½¦\u00952 \u0088¥\u009aÆÃ`2¢Ì6BÐ#ÝÅE2\u0085ãª)%Ì\u0082\u008dz¤]\u0001s£\u008f";
                  var6 = 49;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   public static String[] C() {
      return 树友友树树树树何树何;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 41;
               case 1 -> 4;
               case 2 -> 23;
               case 3 -> 51;
               case 4 -> 49;
               case 5 -> 45;
               case 6 -> 46;
               case 7 -> 57;
               case 8 -> 11;
               case 9 -> 31;
               case 10 -> 10;
               case 11 -> 60;
               case 12 -> 48;
               case 13 -> 47;
               case 14 -> 1;
               case 15 -> 37;
               case 16 -> 43;
               case 17 -> 8;
               case 18 -> 61;
               case 19 -> 36;
               case 20 -> 63;
               case 21 -> 59;
               case 22 -> 9;
               case 23 -> 50;
               case 24 -> 22;
               case 25 -> 55;
               case 26 -> 17;
               case 27 -> 13;
               case 28 -> 33;
               case 29 -> 53;
               case 30 -> 34;
               case 31 -> 0;
               case 32 -> 38;
               case 33 -> 6;
               case 34 -> 42;
               case 35 -> 25;
               case 36 -> 27;
               case 37 -> 44;
               case 38 -> 3;
               case 39 -> 16;
               case 40 -> 35;
               case 41 -> 30;
               case 42 -> 54;
               case 43 -> 2;
               case 44 -> 20;
               case 45 -> 62;
               case 46 -> 5;
               case 47 -> 39;
               case 48 -> 18;
               case 49 -> 7;
               case 50 -> 56;
               case 51 -> 52;
               case 52 -> 21;
               case 53 -> 15;
               case 54 -> 58;
               case 55 -> 12;
               case 56 -> 24;
               case 57 -> 19;
               case 58 -> 32;
               case 59 -> 40;
               case 60 -> 26;
               case 61 -> 28;
               case 62 -> 14;
               default -> 29;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树树树树何树树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29731;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友树树树树何树树友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 195 && var8 != 'o' && var8 != 223 && var8 != 238) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'h') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'q') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 195) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'o') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树树树树何树树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   public static void d(String[] var0) {
      树友友树树树树何树何 = var0;
   }

   private static void a() {
      j[0] = "\u0014-5V\u0014$\u001bmx]\u001e9\u001e0s\u001b\u0016$\u00136wPU\"\u001a3w\u001b\u001f\"\u00043wT\u0002e厼桒栊栤桪伞桦桒叐叾";
      j[1] = "\"\u00199-\tc-Yt&\u0003~(\u0004\u007f`\u000bc%\u0002{+H余伔厼佂伛厭余伔桦栆";
      j[2] = "ozlw\u001b\u0005\u001aZgx\nJgBt\u007f\u0003\u0003\u000f";
      j[3] = void.class;
      k[3] = "java/lang/Void";
      j[4] = " m\u001792&+b\u0006vS( i\u0002,";
      j[5] = ":7\u0007w}A+u\u001c\u0013p/ct\f+wB&7[a\u001c\u00155q\u000e(nS`q\u0003\u0013";
      j[6] = "\u001c\u001d\u0006.*^\r_\u001dJ桒右厼桽厣厉厈佭桦厧`)2V\u001b\u0005\u000e8pM";
      j[7] = "88od\u0010\u000f;-m~.伻栘厗桊佀样伻作桍厐\u001d\u0017\n=-mt\u0014\u001f?7";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      this.k();
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_WEI_LIN() {
      return "何炜霖大狗叫";
   }
}
