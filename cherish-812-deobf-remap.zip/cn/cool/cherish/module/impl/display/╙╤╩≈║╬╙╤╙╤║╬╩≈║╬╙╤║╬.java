package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.ui.树友何何何树友树何友;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友树何友友何树何友何 extends Module implements 何树友 {
   public static final ModeValue 树何何树树何树友何何;
   public static final ModeValue 何何树树树友友树树树;
   public static final ModeValue 何何何树何何友树何何;
   public static final ModeValue 何友树友树何何树树树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[8];
   private static final String[] k = new String[8];
   private static String HE_WEI_LIN;

   public 友树何友友何树何友何() {
      super("NotificationHUD", "通知显示", 树何友友何树友友何何.友友友树何友何何树何);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5598876970101807768L, -6028263264280718602L, MethodHandles.lookup().lookupClass()).a(172940523628597L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(53821934485833L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[26];
      int var5 = 0;
      String var4 = "òê8\n®ïó\u007f¼\b=\u0085c\u0004 d¡:\u009aì¥¹vV\u009d\u0007ú\u0080¸\u0013n\u008a\u0010\t½Û\u001c\u0097á^|¥!4\u0098£Ä\u00ad2\u0010Q\u0007ò¶\u0010é\u008c\u0018¹\u0016J\u0007Õï\u0084\u0005\u00183Ð\u009415Å2¬>ùØ\u000býò\u0093ªhOùýÞRm¹\u0010:ò\u009b\t;Çº\u0002\u0086èz\u0090V\u0005\u0081F\u0010ç\u0000\u0083L5\u0000c>ÞßVäûÒ\u0087\u008d\u0010\u009fé\u001cS\u0091\u00152\u009f`\u008fçÚ§»¦\u0085\u0010g\u0090\u000b±\u008d·pðD\u0080d\u0012~}í¤\u0010\u001d¢fÙå|þn1\u008e/\f¾}ò\u0085 C\u0082-\u0002\u0086(\u0000\u001f®@eI\u0082\u0099¢\u0085kððý\u001eØ0sÑÕüxÍº¤û(\u009c\u0006â¶¦ü\u0095`¬\u0080þ\u0015\u0089å\u0099\u0000Î{È4É\u008fIx£~Ô\u0082ÚT4Æ¨\u0095Ê¹Æ\u00adÖà\u0018¤ÏÖï=\u0011J!¥áÝ6wwy\u008eùpJ\u0096¸u\u0087¿\u0018\u0015\u0014ÌTñ\u008fò.ê\u0091+6\u001cBF\u001c\u009dæ}ç¡,%B\u0010à|3F\u0081\u001eÅð\u009e\u0015Ã\u0005®\u0088\u0015\u0080\u001090!\u0089¨\u0099}\u0096\u0094î\u0012âhPm\u0090\u0010\u009cuOýO\u0012À\"Ûø9ÂÉµl¼\u0010µ\u001f,\u0092ýVw\u0095Y\u008c¨Kx¥\f\u001c\u0018ÈËÌ\u0096ø_¸øÛiýÆ\u0001NÀ$õo¥¸¿n*-\u0010T\u009b\u0003ö\u0014Y{\f?$Ub\u008cwÐk\u0010\u0091¤\u00ad\u0010çx½\rL\u001b\u0083uÿLm¨\u0010\u0000YbÒ0\u0000á\u0096\u00ad\u0083\u0004Î,\u0096d<\u0010zåV~\u00ad£\u001c¦Â¦h\u0001b¸z÷\u0010yã¼éÿ<\u0099õS¢\u007fã¬`U2\u0010\u0086T5@òS\u0094ó\b2È¼c\u0018i\u009c";
      short var6 = 495;
      char var3 = ' ';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = c(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     c = var7;
                     h = new String[26];
                     树何何树树何树友何何 = new ModeValue("Mode", "模式", new String[]{"Corner", "Center"}, "Corner");
                     何何树树树友友树树树 = new ModeValue("Style", "样式", new String[]{"Cherish", "Exhibition", "Xylitol", "Novoline"}, "Cherish");
                     何何何树何何友树何何 = new ModeValue("Exhibition Color", "Exhibition颜色", new String[]{"White", "Black", "Alpha"}, "White")
                        .A(() -> 何何树树树友友树树树.K("Exhibition"));
                     何友树友树何何树树树 = new ModeValue("Animation", "动画", new String[]{"Side", "Zoom"}, "Side");
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "`Ó[9¢pþ&k'î\u0004ç¤\u008d\u008f\u0080\u009cõ`\u0095\u0017\u008aº\u0014\u009a\u0093lÈº\u0087¤£ÖÊ\u009d\u0080à|Á\u0010vël\u0006¡ÖÖ<0[HA\u0087&Ü\u000b";
                  var6 = 57;
                  var3 = '(';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void F(Render2DEvent event) {
      if (Cherish.instance.getModuleManager().getModule(HUD.class).isEnabled()) {
         树友何何何树友树何友.m(event.poseStack());
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 11;
               case 1 -> 2;
               case 2 -> 10;
               case 3 -> 40;
               case 4 -> 6;
               case 5 -> 57;
               case 6 -> 7;
               case 7 -> 43;
               case 8 -> 47;
               case 9 -> 16;
               case 10 -> 33;
               case 11 -> 61;
               case 12 -> 24;
               case 13 -> 27;
               case 14 -> 29;
               case 15 -> 3;
               case 16 -> 39;
               case 17 -> 5;
               case 18 -> 38;
               case 19 -> 0;
               case 20 -> 44;
               case 21 -> 53;
               case 22 -> 35;
               case 23 -> 42;
               case 24 -> 12;
               case 25 -> 60;
               case 26 -> 50;
               case 27 -> 19;
               case 28 -> 34;
               case 29 -> 63;
               case 30 -> 49;
               case 31 -> 41;
               case 32 -> 1;
               case 33 -> 15;
               case 34 -> 54;
               case 35 -> 48;
               case 36 -> 25;
               case 37 -> 18;
               case 38 -> 55;
               case 39 -> 59;
               case 40 -> 36;
               case 41 -> 8;
               case 42 -> 23;
               case 43 -> 45;
               case 44 -> 4;
               case 45 -> 13;
               case 46 -> 56;
               case 47 -> 51;
               case 48 -> 62;
               case 49 -> 31;
               case 50 -> 14;
               case 51 -> 20;
               case 52 -> 28;
               case 53 -> 46;
               case 54 -> 52;
               case 55 -> 22;
               case 56 -> 17;
               case 57 -> 32;
               case 58 -> 58;
               case 59 -> 21;
               case 60 -> 37;
               case 61 -> 9;
               case 62 -> 30;
               default -> 26;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树何友友何树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29518;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友树何友友何树何友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u0004r¯\u009e¬ÿÂñøÍÇúIÙyæ, ÷ëm\u0081µ\u0004\u0015Ï, :\u0002\u0000¯V{9ú,")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树何友友何树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 216 && var8 != 194 && var8 != 'F' && var8 != 196) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'Y') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'D') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 216) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'F') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "\u0018\u0018g@\b\u0007\u0017X*K\u0002\u001a\u0012\u0005!\r\n\u0007\u001f\u0003%FI\u0001\u0016\u0006%\r\u0003\u0001\b\u0006%B\u001eF厰桧伜叨厬伽桪伣厂佶";
      j[1] = "z\rn\u0007u<uM#\f\u007f!p\u0010(Jl2u\u0016%Js>i\u000fn)u7|5!\bo6";
      j[2] = "d6`R\f\u000bo9q\u001dp\u0012`#\u007f^G\"v4sCV\u000ea9";
      j[3] = ">1r\u0012@j1q?\u0019Jw4,4_Bj9*0\u0014\u0001栔伈厔厗伤栾収厖伊伉";
      j[4] = "\n\u0000^\"q,\u0001\u000fOm\u0010\"\n\u0004K7";
      j[5] = "\u001cT+{#Z\u001dE/Gr;N^.9y\u0001\u0006\u001b*}\u001b\u0002\u000fA7%!JJEsG";
      j[6] = "&yL/\u0018\"'hH\u0013佽伞桔栒样叐口桚桔栒.h\\=\"rV)\u0018;";
      j[7] = "\u0015_`i`4E\u0006roQ反召厡栆佉厒体佲桻佂\u0014k3P\u001f..;jB\u0019";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_DA_WEI() {
      return "何树友，和树做朋友";
   }
}
