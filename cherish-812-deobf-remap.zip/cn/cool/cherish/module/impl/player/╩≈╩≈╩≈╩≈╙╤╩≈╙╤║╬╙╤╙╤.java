package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;

public class 树树树树友树友何友友 extends Module implements 何树友 {
   private final BooleanValue 树友树树友友友何友友 = new BooleanValue("Spoof Slot", "切换欺骗", false);
   private final BooleanValue 树何友何友何友何树何 = new BooleanValue("Back", "还原", true);
   private final NumberValue 友树何何何何何何友友 = new NumberValue("Health", "血量阈值", 15, 1, 120, 1);
   private final NumberValue 何何树何何何树何友何 = new NumberValue("Delay", "延迟", 500, 0, 2000, 50);
   private final BooleanValue 何友友树何何友树树友 = new BooleanValue("Healing", "治疗药水", true);
   private final BooleanValue 树何树友何友树何何树 = new BooleanValue("Regeneration", "再生药水", false);
   private final 何友友何树何树何树友 树何友何友友树何友友 = new 何友友何树何树何树友(51913986529303L);
   private int 树何友友树树友树树何 = -1;
   private boolean 友树何何树何友友友何 = false;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[40];
   private static final String[] k = new String[40];
   private static String HE_WEI_LIN;

   public 树树树树友树友何友友() {
      super("AutoPotion", "自动药水", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(7923444308102591367L, 8804490327805135852L, MethodHandles.lookup().lookupClass()).a(248236119482732L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(114985391536786L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[14];
      int var7 = 0;
      String var6 = "ÃÂ\u008dåýßÈ+v\u0003ð\u0098\u0012ò¥í»Iz,@:\u0095l\u0010$ßf0+\f\\\u001f4·\u00972n\u008cgM\u0010pB|\u0080zÚOIÑõ\u0092¸\u0014V#:\u0018.þG\u0002±\u001d]Év0\bËÒh\u009f\u008f?Ë=\u0081¤\u009a{\u001f ô\u0087\u0086\u009b[5õKÐ!\u008e\u009a»Ò\u0001&B{î\u0000_y±\u008dªûË.\u0089¯û/\u0010XYë7þï\bN\nzX\u0016\u0001Äøq\u0018¡(\u0003\u009eð,Amí9ü»ø&¼²#*\\&\u0003d¬\u0086\u0010÷:8\u008d¿ÞE\u008aäº$yP\tû3\u0018¦èÔÏA8\u009f\u00001æÜ>(\u0013\f\u0006ó\u001fÊ»,øÿ7 ÝÚOà¹\u0007\u0011\u0000\u007f\u0016qÉ¥JÃÍY\u008a/´\u00827Ç\u0016Jô~çÀ]ªa\u0018é\u0019W#ÏX ò\u0093\t~bwó#]Ö\u008cÙ7óra\u0019\u0010D¤|]\u0017ô©È#/àþ\u0002\u00025W";
      short var8 = 275;
      char var5 = 24;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[14];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u0003±J/Ô\u0087Dò}\u000f6\u008eÒ`\u009b\u0091 ÷®°QTáé{\u0007\u0096Îqÿ#\u00192$\r\rÿ\u00ad\u007ffó@¥9dÁ]Z\u008b";
                  var8 = 49;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 29;
               case 1 -> 46;
               case 2 -> 41;
               case 3 -> 30;
               case 4 -> 21;
               case 5 -> 24;
               case 6 -> 59;
               case 7 -> 15;
               case 8 -> 61;
               case 9 -> 6;
               case 10 -> 25;
               case 11 -> 17;
               case 12 -> 44;
               case 13 -> 39;
               case 14 -> 36;
               case 15 -> 10;
               case 16 -> 14;
               case 17 -> 60;
               case 18 -> 58;
               case 19 -> 32;
               case 20 -> 33;
               case 21 -> 43;
               case 22 -> 56;
               case 23 -> 5;
               case 24 -> 28;
               case 25 -> 22;
               case 26 -> 62;
               case 27 -> 18;
               case 28 -> 42;
               case 29 -> 37;
               case 30 -> 4;
               case 31 -> 52;
               case 32 -> 23;
               case 33 -> 63;
               case 34 -> 0;
               case 35 -> 38;
               case 36 -> 57;
               case 37 -> 20;
               case 38 -> 11;
               case 39 -> 2;
               case 40 -> 54;
               case 41 -> 12;
               case 42 -> 40;
               case 43 -> 7;
               case 44 -> 35;
               case 45 -> 26;
               case 46 -> 55;
               case 47 -> 51;
               case 48 -> 3;
               case 49 -> 53;
               case 50 -> 13;
               case 51 -> 50;
               case 52 -> 49;
               case 53 -> 31;
               case 54 -> 19;
               case 55 -> 8;
               case 56 -> 34;
               case 57 -> 48;
               case 58 -> 9;
               case 59 -> 45;
               case 60 -> 47;
               case 61 -> 16;
               case 62 -> 1;
               default -> 27;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树树友树友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28684;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树树友树友何友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[£+IÈ\f\u009c)*+áf\u0018Ih/K, \u001a<\u008a·8ûóê, |@Ñß\u009bu\u0097P, Â ·Ç\u009f\u0010m»n\u009f\u0016'c4%B, \u008b\u001c\u0000\u0091.áô¦r\u0011càíÑO\u008f, \u0082¢í`-w(R, T\u0090¤Ú ÕJ\f'i\u0080\u0005j44r, ãEdî\u001fÂ52, \to\u0013øM")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private boolean x(ItemStack stack) {
      树友何何友何树何树友.E();
      if (stack.isEmpty()) {
         return false;
      } else if (!this.何友友树何何友树树友.getValue() || PotionUtils.getPotion(stack) != Potions.HEALING && PotionUtils.getPotion(stack) != Potions.STRONG_HEALING) {
         return !this.树何树友何友树何何树.getValue()
            ? false
            : PotionUtils.getPotion(stack) == Potions.REGENERATION
               || PotionUtils.getPotion(stack) == Potions.LONG_REGENERATION
               || PotionUtils.getPotion(stack) == Potions.STRONG_REGENERATION;
      } else {
         return true;
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 229 && var8 != 'u' && var8 != 210 && var8 != 162) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'D') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'e') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 229) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 210) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树树友树友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   protected void h() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.W();
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "LD,.q|C\u0004a%{aFYjcs|K_n(0zBZncn\u007fNSg?0栂栾栻栓历栏变佺叡叉";
      j[1] = "j\u0019N\u0003JFeY\u0003\b@[`\u0004\bNSHe\u0002\u0005NLDy\u001bN\"JFe\u0012\u0001\u000esHe\u0002\u0005";
      j[2] = "\u000ft/^\u000bi\u0004{>\u0011wp\u000ba0R@@\u001dv<OQl\n{";
      j[3] = ",IF(a##\t\u000b#k>&T\u0000ex-#R\reg!?KF\u0005{!-B\u001a\u001do :B";
      j[4] = "G55K^\u000fG5\"\u0017R\u0000]~\"\tZ\u0003G$o(Z\bL33\u0004U\u0012";
      j[5] = "V99>HtV9.bD{Lr.|LxV(c}PqL5=|Dd].c]PqL5\u001d|Dd].\nqHxu3)u";
      j[6] = "6W\u0015&\u000ek6W\u0002z\u0002d,\u001c\u0016g\u0011n<\u001c\u0004f\u0017k,KOx\u000fc!W\u0013&*l.W\u000f|\fp!";
      j[7] = int.class;
      k[7] = "java/lang/Integer";
      j[8] = "80k\u007f;)80|#7&\"{h>$,2{V?\"%$4|%?/8\u001d~?2";
      j[9] = "'AT0S'(\u0001\u0019;Y:-\\\u0012}Q' Z\u00166\u0012!)_\u0016}L$%V\u001f!\u0012桙厏佺伯厘佩桙休栾厱";
      j[10] = " 5nP\u001aj\u0014\u0016a\u0010Wa\u001e\u000bdM\\'\u0016\u0016iKXlU4bZAe\u001eB";
      j[11] = "?v\u0017\u00163\u001e06Z\u001d9\u00035kQ[)\u00055tJ[伉厺厗位栨传桍伤桍叓";
      j[12] = boolean.class;
      k[12] = "java/lang/Boolean";
      j[13] = "!\b\u0010l\\+!\b\u00070P$;C\u0013-C.+C\r6T/a$\u0010'\\1";
      j[14] = "_;@=\u0002P_;Wa\u000e_EpC|\u001dUUp]g\nT\u001f\u0017@v\u0002";
      j[15] = "%~\u001c\u001aA\u0016*>Q\u0011K\u000b/cZWC\u0016\"e^\u001c\u0000桨伓叛叹伬栿厲厍佅佧";
      j[16] = "c-Odb\u0011c-X8n\u001eyfL%}\u0014ifR>j\u0015#)W)g\u001d`1\u0015\u001a`\fd'U9";
      j[17] = "7u5t.e7u\"(\"j->651`=>(.&awq-9+i4io\n,x0\u007f/";
      j[18] = "\u0015=TC!T\u001e2E\f@Z\u00159AV";
      j[19] = "qX\u001dW\f~a\u001fDS3`L\u001cDU\t5L \u0014\u0007Nlw[F\u0015\f3";
      j[20] = "p\n\u0011;-(a\\\\B桖住栃厮佼厁桖住佇桴!91hu\nJ#$p";
      j[21] = ")!N\u0014\u001bL8w\u0003m桠厵桚桟厽厮厺伫厀厅~\u0016\u0007\f,!\u0015\f\u0012\u0014";
      j[22] = "\u0007|LI;'\u0016*\u000100\u001dT|\u0018O7c\tv\u001fOY$\n\u007f\u0003^'y\u0000x\u00030";
      j[23] = "m:\fYJ7|lA 叫栔佚伀佡佽併佐叄厞<\u001aO<l,Q\u0019Prl";
      j[24] = "^\u0017\u001ed\u0005zT\b\ri|h3W]#C<3f_y\u001bv[\\\u0000~Eb";
      j[25] = ">M3f\\GdL($#LUGs+\u001c\u001dU|s&LXsF+b\u001dA";
      j[26] = " \u0015E]%>cO\u0014U]DWlb3\u001dHXa$Ze`'U\u001b\u0019?1/";
      j[27] = "\u0016oSww7No[\"\u0005\u0005(0Z|k3X4\nczH";
      j[28] = "OE\u0001A\u000e)^\u0013L8桵低另使史叻桵低另叡1\u0007\u0012tK\u001bC\t\u0007y\u0019";
      j[29] = "pv&1uZ`1\u007f5JDM2\u007f0z\u0013M\u000e/a7Hvu}su\u0017";
      j[30] = "Mq=\u0014b{\u0010/{\u001e\u0018u+ry\u001a#%+N*\u0015hd\u0004~ \u001d\"x";
      j[31] = "z7\u0006A 8jp_E\u001f&Gs_@/yGO\u000f\u0011b*|4]\u0003 u";
      j[32] = "wYI\u0016=}f\u000f\u0004o框会叞叽桠桶厜桞栄佣yRc(gOC\n'y~";
      j[33] = " ^\u0011]1\u00110\u0019HY\u000e\u000f\u001d\u001aH\\>^\u001d&\u0018\rs\u0003&]J\u001f1\\";
      j[34] = "2Qc\u001aH+#\u0007.c栳佌厛佫厐伾叩佌桁佫S\u0018Tk7Q8\u0002As";
      j[35] = "hdL\u0010\u0014zy2\u0001i伫伝栛佞伡伴桯伝叁佞|S\u0011qir\u0011P\u000e?i";
      j[36] = "iX\u0017?Y\u0002y\u001fN;f\u001cT\u001cN>VBT \u001eo\u001b\u0010o[L}YO";
      j[37] = "I%&G,uXsk>伓厌叠桛佋佣厍桖栺厁\u0016E05L%}_%-";
      j[38] = "\u001d\u0016*7e\tH\u001d.b\u0007厯桭桫厔伅叄伱桭厱桎Xn\b\t\u001d5=;\u0003\rH";
      j[39] = "\u001c10^&\u0006\rg}'厇栥伫伋栙佺厇叿厵伋\u0000\u0017$UM,oG9\u0005\u001f";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   protected void M() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.树何友何友友树何友友.D(11747522392279L);
         this.树何友友树树友树树何 = -1;
         this.友树何何树何友友友何 = false;
      }
   }

   private int P() {
      树友何何友何树何树友.E();
      if (mc.player == null) {
         return -1;
      } else {
         int i = 0;
         ItemStack stack = mc.player.getInventory().getItem(0);
         if (!stack.isEmpty() && stack.getItem() == Items.SPLASH_POTION && this.x(stack)) {
            return 0;
         } else {
            i++;
            return -1;
         }
      }
   }

   private void W() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.树何友友树树友树树何 != -1) {
            if (this.树友树树友友友何友友.getValue()) {
               PacketUtils.a(112543050219290L, new ServerboundSetCarriedItemPacket(this.树何友友树树友树树何));
            }

            mc.player.getInventory().selected = this.树何友友树树友树树何;
            this.树何友友树树友树树何 = -1;
         }

         this.友树何何树何友友友何 = false;
      }
   }

   @EventTarget
   public void R(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         float currentHealth = mc.player.getHealth();
         boolean needHeal = currentHealth <= this.友树何何何何何何友友.getValue().floatValue();
         if (!needHeal) {
            if (this.友树何何树何友友友何) {
               this.W();
            }
         } else if (this.树何友何友友树何友友.A(this.何何树何何何树何友何.getValue().longValue(), 118344821288830L)) {
            int potionSlot = this.P();
            if (potionSlot != -1) {
               if (this.树何友友树树友树树何 == -1) {
                  this.树何友友树树友树树何 = mc.player.getInventory().selected;
               }

               if (this.树友树树友友友何友友.getValue()) {
                  mc.getConnection().send(new ServerboundSetCarriedItemPacket(potionSlot));
               }

               mc.player.getInventory().selected = potionSlot;
               mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
               if (this.树何友何友何友何树何.getValue() && this.树何友友树树友树树何 != -1 && this.树何友友树树友树树何 != potionSlot) {
                  this.友树何何树何友友友何 = true;
               }

               this.树何友何友友树何友友.D(11747522392279L);
            }
         }
      }
   }

   private static String HE_SHU_YOU() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
