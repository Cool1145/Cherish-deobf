package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.EggItem;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SnowballItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import why.tree.friend.antileak.Fucker;

public class 何友树树树树何何树树 extends Module implements 何树友 {
   private final NumberValue 友友树何友何友友树树 = new NumberValue("Delay", "延迟", 500, 100, 3000, 100);
   private final NumberValue 何友何何友何树何何树 = new NumberValue("Range", "范围", 10, 5, 30, 0.1);
   private final NumberValue 何何友友树友友何何树 = new NumberValue("Fov", "角度", 180, 0, 180, 10);
   private final NumberValue 何树树何何友树友树友 = new NumberValue("Extra Predict Tick", "额外预测刻", 0, 0, 3, 0.01);
   private final BooleanValue 树友友何友何树树友友 = new BooleanValue("Scaffold Check", "自动搭路检查", false);
   private final BooleanValue 友友友何树友友何树友;
   private final BooleanValue 友友何何友何何树何树;
   private final NumberValue 树友何何友树何树何何;
   private final BooleanValue 树友树树何何何树友树;
   private final BooleanValue 友何树友树何友树何何;
   private final BooleanValue 树何何友何树友友树友;
   private final BooleanValue 何何何何树树树何何友;
   private final BooleanValue 何树何何友何何友何友;
   private final BooleanValue 树友何友友树友树何友;
   private final BooleanValue 何树何何树何树友树何;
   private final NumberValue 何树树树何树何友何树;
   private final BooleanValue 何何何树树友何友树树;
   private Rotation 树何友友树树树树友树;
   private final 何友友何树何树何树友 友何友何友友友友树友;
   private final 何友友何树何树何树友 何友树何何何树何树何;
   private boolean 友友何何何何树树何树;
   private long 友何友何何何友何友树;
   private Map<ThrowableItemProjectile, Long> 树何树友何何树友树何;
   private int 何树友何何何友树友树;
   private int 何何树何友友何友友友;
   private boolean 友何树友树树友树友树;
   private boolean 何树树何友何树树树树;
   private long 树友友友何友友树树友;
   private long 树友何树何树友友何友;
   private final Map<Integer, List<Vec3>> 树树友树何树友树何何;
   private final Map<Integer, List<Vec3>> 何树树何何何何树何何;
   private final Map<Integer, Boolean> 何何树友树树何何树友;
   private final Map<Integer, List<Double>> 友友友何树树树何友友;
   private final int 何友何树何树友何何树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[100];
   private static final String[] n = new String[100];
   private static String HE_DA_WEI;

   public 何友树树树树何何树树() {
      super("AutoThrow", "自动投掷", 树何友友何树友友何何.友树树友何友何树友树);
      树友何何友何树何树友.E();
      this.友友友何树友友何树友 = new BooleanValue("Without Attack", "不攻击时", true);
      this.友友何何友何何树何树 = new BooleanValue("Without Place", "不放置时", true);
      this.树友何何友树何树何何 = new NumberValue("Active For Time", "活动时间", 100, 0, 1000, 10).A(() -> {
         树友何何友何树何树友.E();
         return this.友友何何友何何树何树.getValue() || this.友友友何树友友何树友.getValue();
      });
      this.树友树树何何何树友树 = new BooleanValue("For Main Hand", "使用主手", true);
      this.友何树友树何友树何何 = new BooleanValue("For Off Hand", "使用副手", true);
      this.树何何友何树友友树友 = new BooleanValue("Avoid Walls", "避开墙壁", true);
      this.何何何何树树树何何友 = new BooleanValue("Debug", "调试", false);
      this.何树何何友何何友何友 = new BooleanValue("Use Fishing Rod", "使用钓鱼竿", true);
      this.树友何友友树友树何友 = new BooleanValue("Spoof Slot", "切换欺骗", false);
      this.何树何何树何树友树何 = new BooleanValue("Attack Crystals", "攻击水晶", true);
      this.何树树树何树何友何树 = new NumberValue("Crystal Range", "水晶范围", 8, 3, 15, 0.5).A(this.何树何何树何树友树何::getValue);
      this.何何何树树友何友树树 = new BooleanValue("Prioritize Players", "优先玩家", true).A(this.何树何何树何树友树何::getValue);
      this.树何友友树树树树友树 = null;
      this.友何友何友友友友树友 = new 何友友何树何树何树友(51913986529303L);
      this.何友树何何何树何树何 = new 何友友何树何树何树友(51913986529303L);
      this.友友何何何何树树何树 = false;
      this.友何友何何何友何友树 = 0L;
      this.树何树友何何树友树何 = new HashMap<>();
      this.何树友何何何友树友树 = -1;
      this.何何树何友友何友友友 = 0;
      this.友何树友树树友树友树 = false;
      this.何树树何友何树树树树 = false;
      this.树友友友何友友树树友 = 0L;
      this.树友何树何树友友何友 = 0L;
      this.树树友树何树友树何何 = new HashMap<>();
      this.何树树何何何何树何何 = new HashMap<>();
      this.何何树友树树何何树友 = new HashMap<>();
      this.友友友何树树树何友友 = new HashMap<>();
      this.何友何树何树友何何树 = 8;
      if (Module.Z() == null) {
         树友何何友何树何树友.O(new Module[1]);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2946570459941960249L, -6340752220629607829L, MethodHandles.lookup().lookupClass()).a(259224572120720L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(127383429623380L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[55];
      int var18 = 0;
      String var17 = "g}ofÏ6AD\u0085\u0083bÒÇë\u009eïQ×è!\u008c\u0001\t4V#Ãæ\u00846ÁÝ °n®Zç\u007fþ\u000ffÎi\u0010dÏ\u008dcÉOô«ÓQ\u009f5\u0098{Å\u008c\u0015$Ó\u001e áâb\u008e¾²C\u009bËÂ*\u0013à7¸´Ó)\u0018¦â[b\u0002 «\u0092/ñÀÒÓ\u00187B2ºÌ\u0082\u0019ÉC0\u0005±\u001cQMÙÈîHÀR\u0013\u0094\u0090`d×\u0093\u0016¯I@\f%×6·\u001fjÚÿE#Ø\u009aÝý¤7S ú\u0018\u008a\u0005\u008dS\u0086ê\u0015óÆ\u00adsXµZÔ\u009cÀ8/Îb>\u0099zðçk\u008b\u008a\u0000+Ü\u0016¶xb°ª4Ä\u0010O\u0018\u0096\u0015±]H\t¸Ã\u008b²d\u0090OÓu¤ =ç®\u008e\u0090\u000bÆN(§cÚ¿\u0084q\u0002\u0005\u008f\u00ad\u0097ÖÅçÆó\u0015  Øy\u0010%\u0002÷a\u0090\u0001cÜB¤\u0085Þ\u000fáð\u008fã\u0094\u0010Â\u00896\u009bÒkÌ80\u0097¹\u00893I|\u0092\u0018\u00070Ç,{\u008a\u009ffCN§Ä«\u0003\u00adAK}Ú1\u0012\u0097 ¤\u0010Ç\u0004,×\fi¯¬;\u0003¨\u0098ºxgë\u0018F@ë\u00840{'¿KÏîª°·²ñaÂïïkü\u001c¶ ò\u008e\u001b\bJrÕ¡@\u001d\u000b\u0086å\u0090ð\u0013J¦Ò·ØZâ\u0086xË\b\u0011-\u009d\u007f\u009b\u0010Ö\u0005f.\u0095}\u0000\u009f\u001f\u009c\u000eXÞ\u0004Lª\u0018\u0012\u0006\tnOö×xò¦PLR²\u007fãæZv\u0080¸\u001eö\u009b\u0010B\u009c§ïâ~Év0¤`5I³6aX\u0012Ì\u0084Pe8~\u0087\u0083P@þúM|©j\bÚÛÇàRòþÆk¶\u0014\u009cd;(þ¥\u0018ì\u0082'8z\u009e\u0013¥ÖKÒF\u0097[xé\u009d \u0013f\bÆÍ \u000fAª\u0087¯\u0080\"cÕÁv\u007f\u0001\u0097Auâ¡ÊÉç\u00ad{\u001b}\u000b<ÐX1öf\u0090\fJLª^vG&Çlqa\u0090J\rü\u008dÝÿü\u0096\u008b;\u00053·ÀPº&è:Ð\u0000\u0004ôm0ÅÇ\u0002[y)\u009a$õtj\u0081\u0003ÑÎ\u001dê[¹ b\u0001±\u0081Å\u008dRXÄé\u0012DÐò¯úO~6\u0018õF +ÿ\u001b(Å4f\u008c\u009a×é\u0081\u0099M\u0002kwýL\u0019æv\u0005Ü¢¡³P¹\u0085Ã-âÁ#ÛT$+y\u009bµÆa \u008dK*Òbi\u0087¾Aè\u0088´Ù\fR\u009fÓ£Jðú^m»åO\u008fS¸ÍrÔ\u0010@lÜ÷ìvÙ,f«¸1Ó\u000e\t_`aë8ÕÖ\u001aû#P\u000eI\u008b_+z÷ç\\Õ\u0085¹\u0083<p®\u009aYb$\u0090+\u0093±Wìn\u0006Í\u008fM\u0095mä\u0095¥¿/\u001dr\u0011¿\u008aekù\u00993wênú¼\t\u0016[$Ú\u0088\u00066\u0095ù·Ñ¸\nàk%UH7Û}-\u0019Õ\bî\u0010+¡É®9,\u0018`\u001fT\u0099\u00929ê\u008bî\u009eýãB\u00ad0h\u008a\te\u0005úI\\@ \u008dhþ»8\u0007D2\u0002«Ô \u009e\u001cªÓö\u008d¯\u00862\u008e\u0006sß\u0098M÷!Û5>(r\u009c\u0005ä\fÞÃ¯\u009eh\u0084ÿæÕdã'Ù(ÒÓMªÅ¹Ð\u0007ÛÁ\f²y-¶ïh¤Õ\u000b= $%\u0093\u000f\u0015ÌÓ«À\u00850µ\u0082\u001aQÎÂßEíq0\u0005ý\u0018_úÀ)?°\u0001\u0018\u009f~|c\u0098/[,·\\¶ä\u0091æ¬Ì¨\b±ãR\u0002Að ÉÀå\u0001`»'¿9Ó*\u0014\u001f\u0080\u0092-\u0019â'\tùÆ 55ùï\u0089ì¾\u008ef`ñ\u0081¤æîo\u008b\u009eÇÌ+\u000fSª_¶ÕÞZ\u00adH Vgh\u009d÷däOÞ¯ïú×\u0017'Ö\u0099qh\u001c@#\u0000\u00adà\u0003´â_E\u0010ÿÜ&\u0004Mð\u0007ý¡ò9\u00ad§\u0015\u00177k¤À°¯ÁFunèÂöÃÊÀÎÌ4¡ì(}\u00adò3{p\u0080\u008e\u000fø8\u000b\u0017BY\"Í\u00adM#¬ÞV'2\u009b\u001fÎö\u001f\u0099\t3\u0096¡k\u009c\u00adÕ§\\ùõht# Óg9º£\u008c6+\u0090\u0017n\u0019\u007f2Öw\u0093\u009fW\u009aç÷·JZ\u0081&kçÒÊ>A\u0088Ö~hÝ\\\u0082\u008f¹7t© ÙU\u0086\nújö\u0090\u0001M\u000b\u001d%>â\u008d#Má_\u001b¦öñ¿$\\§¿a\u0093\u000b\n\u0091\u0085\u0099¼æÿÿ\u0081ä\u0018è=)|¾\u007f¤\u0090Aü=ç\u00814\u001bwYûø\u0088\u001fW©\u0004\u0010\r*j=×Ä\"tj5Á\u008dj¿\u0080ü(á\u0092¤7\u0018]ãÉÉ\u0015O\\àF\u009e\u0017\b0\u001b\u001aÔ\u001e°35\u0010+\u009aTyV(zãÓ!±Æ\u0018æ ;Þ^Ã2.¤³\b,%5¹\"SQ42¢-YÌb¿Lú\u0004½g?Yb \u0005gÈ\u0087Ns\\\u0082¨1\u0012\u0080\u0086\u00815\u0007OL·\u009c\b°\u0082¿\u001f¬{u\u0010_¨^0é*iºéön\u009bB8g}³Þà\u0003¸zhi¦\u001a*Þì\u0086`öz.ýy²Ô2\u001b¬Ó.TB½Ä\u0089kä[³\u0018\u0007Ï7lDðNÂ\u009eÐ\u0014´¶jc8\u0090)Ø`A\u009e 1\u0018\u0010®ü¿`H\u0004§ûW}\u0016¯{\u008aù\nC\u0004z\u001a{4\u009f ù\u0094%\u00950\bäþ(F\u0002Q\u0080\u0084Lò\u0095î$ì\u0014\u0015\u001f´\u0086@PÆ:Ò\u009c«XFaç\u0098¼\u0091\u0091â\rMæ0·Ú¼U?Ñ\u0001ß\u0084µ_gI\u0084¿¼\u0014ä\u007f²ß6U\u001dÅk\u0088\u009aòô´\u000f\u008a6¯\u0091aô\fV¢/\u001eÿ\u0018·\u008e\u008c.{¼íæR\u0085¦*ÿ.±°Ö³F!\u00065nV\u009e£\u0082æW$ð Øû$$º¹Ä\u0080X\u0090·¿ó \u001d\u009dºÀSU\u001fËl?ÕIpä:G^e\u0010$\u009eÁØ/\u0005f(+Íp\u001cÉµeB(\b°qü\u001dzÕÇ½¶¹1\u0016ä\\\u0002f5s^\u0016Á¬ý#R\u008c-{»v\u000e\u008fè«bÜº\u0014/ IZFæ¦\\£d\u0000\u000b\t\u00063û/$ÒiKÌu4¶¶1<\u001a_Í±É-\u0010Å-1\u000b¿B¦LªYkð9þ½\u009c@÷\u00895`¬\tÉhæÅS[d¤Ýª@ö\u0096\u0005\u0000\u0094Ô\u001dÀ\u00983\u0097ò³:\u0098Þ¿\"\u0094ß\u0086\t\u008fË£$\f¯\fØZ\u0016¿Årn¬\u0099If@8\r\u009fÑÃ\u0080hm\u0018\u0004Ïá\u0090Wá0¬ë\r\u0015²cì*ÁGB\u0086'ÖÙ³O½½D\u0086\u0084ÈÚQ}p\f\u001bìÖL;\u0000¥8r}ù\u009b^*Â\u008e¹\u0080\u0097¾\u0095_Í\u00adiäO\u001bH\rÁí±P¶ï,\u0089j\u0014kôl\u0012\u0085o\u0001ìÊ²\u0080PÏ\u009e?+eI\u008ep\u00859@\u0004Ì\u0090\u0004(ôT\u009ct°p|ÓDü\u0087ìÞ$\u001b²\u0018·\u0010ë\u0012\u001f\u0098ç\u0092\u0092\u0011\u008b%D\fà:Z¶¡\u000fÐÙ¼8ø]`÷\u0095B4Ë$\\Â9«M\u0002»/½Ë\u0087\u0012Xv<ä\n\u008bóTð©]\u0090$\u00003å/\u0085\u0086a\u0005ªÁ\u000b¿þnþ.^oÿ~\f@(¬9ÀMÅ\u0002Ú[\u007f Y(~xl7c=\u0097ÒÌÇÚ×\u0092[\u0081´|nqPxx¿\u00944^\u0011ç ö\u008e\u001b~¸Íz¾\u0092@\u0086â»!g\u000bK¦Ã^·¡¥\u000bÇ\b[ää\u008eg¸`)Y\u001d\u008a\u001a¥è¾²\u0097ýw¢Õ\u0084qèQAx{\rN\n|¤\u0015ÛÆ}\b \u000byî®2¡\u0019õß6ßV\u0082qhd\u0001:sJ\u008bf]\u0083}Ä¬b>\u0017\u008cWå·o¹^¹\u0003Ñ1ÏÏ<\fÛ¶(³È«<¶I2\u0012µ\u008d_àj\u0012f}\u0018ÇUNÕãÚl\u0097Ã,K bê¾-`{£.õÑb±Xî\u000fÓ<pÅ\u000b\u00829|QZ@\u000ezcø\u00149¹<ã±ÐÉè6w1\rÃàÛ¢iG¢öq!\u009cd{T}<\u0018Á'ÎH1}÷\u0086\u008fäÃ\u0015·\u0007ú\u0019.$QÂÕõ\u0099¥òlÏô\u0094\u0081Û*±Ô\u001f!\u001eRs2Ü\u0010ì1ß\u008a\u0002oB³x\\k\u0012 %ßO";
      short var19 = 2300;
      char var16 = ' ';
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[55];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(127383429623380L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = ";ÎÙÀI\u0015\u0083¦?ÛîZ\u00825{å".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Integer[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "(~\u0090\u0091\u0088\u009dÖ\rsäè\u00161\u0099ò\u0019¿\nÖwÞï¥\u000b\u0010+\u0005MpDÜ\r¸j8\u0082Zx\u0098ì\t";
                  var19 = 41;
                  var16 = 24;
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private 何友树树树树何何树树.树友友何友树树友树友 C(int entityId) {
      树友何何友何树何树友.E();
      List motionHistory = this.何树树何何何何树何何.getOrDefault(entityId, new ArrayList<>());
      List<Double> speedHistory = this.友友友何树树树何友友.getOrDefault(entityId, new ArrayList<>());
      List<Vec3> positionHistory = this.树树友树何树友树何何.getOrDefault(entityId, new ArrayList<>());
      if (motionHistory.size() >= 3 && speedHistory.size() >= 3 && !positionHistory.isEmpty()) {
         Vec3 currentMotion = (Vec3)motionHistory.get(motionHistory.size() - 1);
         Vec3 prevMotion = (Vec3)motionHistory.get(motionHistory.size() - 2);
         double currentSpeed = speedHistory.get(speedHistory.size() - 1);
         double prevSpeed = speedHistory.get(speedHistory.size() - 2);
         double prevPrevSpeed = speedHistory.get(speedHistory.size() - 3);
         boolean isInAir = !this.何何树友树树何何树友.getOrDefault(entityId, true);
         double currentAngle = Math.atan2(currentMotion.z, currentMotion.x);
         double prevAngle = Math.atan2(prevMotion.z, prevMotion.x);
         double angleDiff = Math.abs(currentAngle - prevAngle);
         if (angleDiff > Math.PI) {
            angleDiff = (Math.PI * 2) - angleDiff;
         }

         double acceleration = currentSpeed - prevSpeed;
         double prevAcceleration = prevSpeed - prevPrevSpeed;
         if (angleDiff > 0.3) {
            ;
         }

         if (acceleration > 0.01 && prevAcceleration > 0.0) {
            ;
         }

         if (acceleration < -0.01 && prevAcceleration < 0.0) {
            ;
         }

         if (Math.abs(acceleration) < 0.01) {
            ;
         }

         if (acceleration > 0.01 && prevAcceleration <= 0.0) {
            ;
         }

         if (acceleration < -0.01 && prevAcceleration >= 0.0) {
            ;
         }

         何友树树树树何何树树.友树何何树友友何树何 type = 何友树树树树何何树树.友树何何树友友何树何.何树何树友何何树何友;
         double turnTrend = angleDiff > 0.1 ? currentAngle - prevAngle : 0.0;
         if (turnTrend > Math.PI) {
            turnTrend -= Math.PI * 2;
         }

         if (turnTrend < -Math.PI) {
            turnTrend += Math.PI * 2;
         }

         Vec3 lastPosition = positionHistory.get(positionHistory.size() - 1);
         return new 何友树树树树何何树树.树友友何友树树友树友(type, currentAngle, turnTrend, isInAir, lastPosition);
      } else {
         return new 何友树树树树何何树树.树友友何友树树友树友(
            何友树树树树何何树树.友树何何树友友何树何.友树友何何何树何友友,
            0.0,
            0.0,
            false,
            positionHistory.isEmpty() ? new Vec3(0.0, 0.0, 0.0) : positionHistory.get(positionHistory.size() - 1)
         );
      }
   }

   private List<Vec3> J(Vec3 targetPos, double ticks) {
      树友何何友何树何树友.E();
      if (this.Q(new Object[]{52406761729175L})) {
         return new ArrayList<>();
      } else {
         List<Vec3> points = new ArrayList<>();
         Vec3 eyePos = new Vec3(mc.player.getX(), mc.player.getY() + mc.player.getEyeHeight(), mc.player.getZ());
         points.add(eyePos);
         double dx = targetPos.x - eyePos.x;
         double dy = targetPos.y - eyePos.y;
         double dz = targetPos.z - eyePos.z;
         double horizontalDist = Math.sqrt(dx * dx + dz * dz);
         double horizontalVelocity = this.y(horizontalDist, ticks, 0.99);
         double initialYVelocity = this.S(dy, ticks, 0.03, 0.99);
         double vx = dx / horizontalDist * horizontalVelocity;
         double vz = dz / horizontalDist * horizontalVelocity;
         double x = eyePos.x;
         double y = eyePos.y;
         double z = eyePos.z;
         int numSteps = Math.max(10, (int)(ticks * 2.0));
         double stepSize = ticks / numSteps;
         int i = 0;
         if (0 < numSteps) {
            x += vx * stepSize;
            y += initialYVelocity * stepSize;
            z += vz * stepSize;
            double var10000 = vx * Math.pow(0.99, stepSize);
            var10000 = initialYVelocity * Math.pow(0.99, stepSize) - 0.03 * stepSize;
            var10000 = vz * Math.pow(0.99, stepSize);
            points.add(new Vec3(x, y, z));
            i++;
         }

         return points;
      }
   }

   private double S(double targetY, double time, double gravity, double airResistance) {
      树友何何友何树何树友.E();
      double minVy = -10.0;
      int iter = 0;
      double y = 0.0;
      if (0.0 < time) {
         y = 0.0;
      }

      if (y < targetY) {
         minVy = 0.0;
      }

      iter++;
      return (minVy + 0.0) / 2.0;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 49;
               case 2 -> 6;
               case 3 -> 63;
               case 4 -> 50;
               case 5 -> 33;
               case 6 -> 18;
               case 7 -> 37;
               case 8 -> 57;
               case 9 -> 29;
               case 10 -> 28;
               case 11 -> 23;
               case 12 -> 40;
               case 13 -> 1;
               case 14 -> 51;
               case 15 -> 60;
               case 16 -> 8;
               case 17 -> 11;
               case 18 -> 21;
               case 19 -> 46;
               case 20 -> 10;
               case 21 -> 0;
               case 22 -> 58;
               case 23 -> 25;
               case 24 -> 59;
               case 25 -> 52;
               case 26 -> 14;
               case 27 -> 54;
               case 28 -> 32;
               case 29 -> 47;
               case 30 -> 62;
               case 31 -> 12;
               case 32 -> 20;
               case 33 -> 24;
               case 34 -> 22;
               case 35 -> 56;
               case 36 -> 45;
               case 37 -> 4;
               case 38 -> 41;
               case 39 -> 27;
               case 40 -> 44;
               case 41 -> 34;
               case 42 -> 39;
               case 43 -> 2;
               case 44 -> 35;
               case 45 -> 3;
               case 46 -> 43;
               case 47 -> 13;
               case 48 -> 36;
               case 49 -> 17;
               case 50 -> 31;
               case 51 -> 48;
               case 52 -> 5;
               case 53 -> 53;
               case 54 -> 26;
               case 55 -> 7;
               case 56 -> 19;
               case 57 -> 61;
               case 58 -> 30;
               case 59 -> 38;
               case 60 -> 55;
               case 61 -> 9;
               case 62 -> 16;
               default -> 15;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23191;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树何何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[g5\u001fñì¢~Eô\u0094\u0083ÓlÀSÊ, £Yú;f®G\u0002Öþ¢I\u0001ÙP\u009d, \u0082\u0084Ú}@ç\\BM\u000fí§gt\u0090×, êõ\u000b±?~\u000b\u0013N\u0080\u00857êE]ì, \u0087AÌ5\u0092a\u0092º9\u0097**¢=c{1E\"#G×\u008f\u008fD&\u0001)1)¾nM5ÐèÂß\u0000Ñ\u001eM¬÷ë8\u0098\u0082»§R\u001fèÉì!©u\u0092\u0006\u0004cÛé, ïÃÔ\u0081ì¾")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   @EventTarget
   public void x(LivingUpdateEvent event) {
      d<"Y">(-8635943969990724212L, 33881913264171L);
      if (!this.Q(new Object[]{52406761729175L})
         && (Boolean)Fucker.isLogin
         && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)
         && (
            d<"ë">(-8635795805738972311L, 33881913264171L) == null
               || !d<"ë">(-8635795805738972311L, 33881913264171L).isEnabled()
               || !d<"$">(this, -8629720108668784012L, 33881913264171L).getValue()
         )) {
         long currentTime = System.currentTimeMillis();
         if (d<"$">(this, -8630423077041353601L, 33881913264171L)
            && currentTime - d<"$">(this, -8636692949012937023L, 33881913264171L) > d<"$">(this, -8636894532762562279L, 33881913264171L).getValue().longValue()
            )
          {
            d<"O">(this, false, -8630423077041353601L, 33881913264171L);
         }

         if (d<"$">(this, -8636552073116293028L, 33881913264171L)
            && currentTime - d<"$">(this, -8629823269392115230L, 33881913264171L) > d<"$">(this, -8636894532762562279L, 33881913264171L).getValue().longValue()
            )
          {
            d<"O">(this, false, -8636552073116293028L, 33881913264171L);
         }

         if (d<"$">(this, -8637443836771527379L, 33881913264171L).getValue() && d<"$">(this, -8630423077041353601L, 33881913264171L)) {
            if (d<"$">(this, -8630663489425419154L, 33881913264171L).getValue()) {
               ClientUtils.P(125527250587045L, "Skipping throw due to attack");
            }
         } else if (d<"$">(this, -8637292885645837211L, 33881913264171L).getValue() && d<"$">(this, -8636552073116293028L, 33881913264171L)) {
            if (d<"$">(this, -8630663489425419154L, 33881913264171L).getValue()) {
               ClientUtils.P(125527250587045L, "Skipping throw due to place");
            }
         } else {
            this.L();
            if (d<"$">(this, -8635672406196358342L, 33881913264171L) != null) {
               RotationUtils.F(d<"$">(this, -8635672406196358342L, 33881913264171L), 3052380832273L);
            }

            if (d<"$">(this, -8629797496985850297L, 33881913264171L) && currentTime >= d<"$">(this, -8630232870524935369L, 33881913264171L)) {
               if (d<"$">(this, -8630663489425419154L, 33881913264171L).getValue()) {
                  ClientUtils.P(125527250587045L, "Reeling in fishing rod");
               }

               this.G();
               if (mc.player.getOffhandItem().getItem() instanceof FishingRodItem) {
                  d<"$">(mc, -8630475005378034584L, 33881913264171L).useItem(mc.player, d<"ë">(-8637241216730210984L, 33881913264171L));
               }

               d<"O">(this, false, -8629797496985850297L, 33881913264171L);
               d<"O">(this, 0, -8636923595402289301L, 33881913264171L);
               d<"O">(this, null, -8635672406196358342L, 33881913264171L);
            } else if (!d<"$">(this, -8629797496985850297L, 33881913264171L)) {
               Map<ThrowableItemProjectile, Long> shouldAdd = new HashMap<>();
               Iterator throwableSlot = mc.level.entitiesForRendering().iterator();
               if (throwableSlot.hasNext()) {
                  Entity entity = (Entity)throwableSlot.next();
                  if (entity instanceof ThrowableItemProjectile snowball) {
                     if (d<"$">(this, -8630912889606438952L, 33881913264171L).containsKey(snowball)) {
                        shouldAdd.put(snowball, (Long)d<"$">(this, -8630912889606438952L, 33881913264171L).get(snowball));
                     }

                     shouldAdd.put(snowball, System.currentTimeMillis());
                  }
               }

               throwableSlot = d<"$">(this, -8630912889606438952L, 33881913264171L).keySet().iterator();
               if (throwableSlot.hasNext()) {
                  ThrowableItemProjectile snowball = (ThrowableItemProjectile)throwableSlot.next();
                  if (!shouldAdd.containsKey(snowball) && d<"$">(this, -8630663489425419154L, 33881913264171L).getValue()) {
                     ClientUtils.P(
                        125527250587045L,
                        String.format(
                           "One throwable item(id:%s) has disappeared",
                           snowball.getId(),
                           System.currentTimeMillis() - (Long)d<"$">(this, -8630912889606438952L, 33881913264171L).get(snowball)
                        )
                     );
                  }
               }

               d<"O">(this, shouldAdd, -8630912889606438952L, 33881913264171L);
               if (d<"$">(this, -8636923595402289301L, 33881913264171L) == 1) {
                  int throwableSlotx = this.l();
                  if (throwableSlotx == -1) {
                     d<"O">(this, 0, -8636923595402289301L, 33881913264171L);
                     return;
                  }

                  if (throwableSlotx == -2) {
                     d<"O">(this, -1, -8630116064943179592L, 33881913264171L);
                     ItemStack offhandStack = mc.player.getOffhandItem();
                     boolean var10000 = offhandStack.getItem() instanceof FishingRodItem;
                  }

                  d<"O">(this, d<"$">(mc.player.getInventory(), -8629212716648672571L, 33881913264171L), -8630116064943179592L, 33881913264171L);
                  if (d<"$">(this, -8629627841683752772L, 33881913264171L).getValue() && mc.getConnection() != null) {
                     mc.getConnection().send(new ServerboundSetCarriedItemPacket(throwableSlotx));
                  }

                  d<"O">(mc.player.getInventory(), throwableSlotx, -8629212716648672571L, 33881913264171L);
                  ItemStack mainHandStack = mc.player.getInventory().getItem(throwableSlotx);
                  boolean isFishingRod = mainHandStack.getItem() instanceof FishingRodItem;
                  d<"$">(mc, -8630475005378034584L, 33881913264171L).useItem(mc.player, d<"ë">(-8637241216730210984L, 33881913264171L));
                  if (isFishingRod) {
                     d<"O">(this, true, -8629797496985850297L, 33881913264171L);
                     if (d<"$">(this, -8630663489425419154L, 33881913264171L).getValue()) {
                        ClientUtils.P(
                           125527250587045L, String.format("time: %s", d<"$">(this, -8630232870524935369L, 33881913264171L), System.currentTimeMillis())
                        );
                     }

                     d<"O">(this, 0, -8636923595402289301L, 33881913264171L);
                     d<"O">(this, null, -8635672406196358342L, 33881913264171L);
                  }

                  d<"O">(this, 2, -8636923595402289301L, 33881913264171L);
               } else {
                  if (d<"$">(this, -8636923595402289301L, 33881913264171L) == 2) {
                     this.G();
                     d<"O">(this, 0, -8636923595402289301L, 33881913264171L);
                     d<"O">(this, null, -8635672406196358342L, 33881913264171L);
                  }

                  if (!d<"$">(this, -8628919301168543011L, 33881913264171L)
                     .A(d<"$">(this, -8629599816373089675L, 33881913264171L).getValue().intValue(), 118344821288830L)) {
                     return;
                  }

                  int throwableSlotxx = this.l();
                  if (throwableSlotxx == -1) {
                     return;
                  }

                  if (throwableSlotxx == -2) {
                     boolean var55 = mc.player.getOffhandItem().getItem() instanceof FishingRodItem;
                  }

                  boolean var44 = mc.player.getInventory().getItem(throwableSlotxx).getItem() instanceof FishingRodItem;
                  Entity targetEntity = null;
                  Vec3 targetPos = null;
                  double finalTick = 0.0;
                  boolean isCrystalTarget = false;
                  List<LivingEntity> entityList = Cherish.instance
                     .m()
                     .J(106720686485339L, d<"$">(this, -8637134444717279138L, 33881913264171L).getValue().floatValue())
                     .filter(entity -> RotationUtils.A(51024501214516L, this.何何友友树友友何何树.getValue().floatValue(), entity))
                     .toList();
                  if (!entityList.isEmpty() && entityList.get(0) instanceof Player) {
                     targetEntity = (Entity)entityList.get(0);
                     double tick = (float)this.N(targetEntity);
                     PlayerInfo playerInfo = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                     if (playerInfo == null) {
                        return;
                     }

                     playerInfo.getLatency();
                     finalTick = tick + 2.0 + d<"$">(this, -8630367544851017481L, 33881913264171L).getValue().doubleValue();
                     targetPos = this.U(targetEntity, finalTick);
                     if (targetPos == null) {
                        targetEntity = null;
                     }
                  }

                  if (d<"$">(this, -8629932588854110282L, 33881913264171L).getValue()
                     && !var44
                     && (targetEntity == null || d<"$">(this, -8636039095028099152L, 33881913264171L).getValue() && targetEntity != null)) {
                     List<Entity> crystals = this.O(d<"$">(this, -8629392716632324550L, 33881913264171L).getValue().doubleValue());
                     if (!crystals.isEmpty()) {
                        Entity crystal = crystals.get(0);
                        if (targetEntity != null && d<"$">(this, -8636039095028099152L, 33881913264171L).getValue()) {
                           double playerDist = mc.player.distanceTo(targetEntity);
                           double crystalDist = mc.player.distanceTo(crystal);
                           if (crystalDist < playerDist * 0.7) {
                           }
                        }

                        targetEntity = crystal;
                        isCrystalTarget = true;
                        double distance = mc.player.distanceTo(crystal);
                        finalTick = Math.max(5.0, distance * 0.8);
                        targetPos = new Vec3(crystal.getX(), crystal.getY() + 0.5, crystal.getZ());
                        if (d<"$">(this, -8630663489425419154L, 33881913264171L).getValue()) {
                           ClientUtils.P(
                              125527250587045L,
                              String.format(
                                 "Fishing rod cast",
                                 d<"$">(targetPos, -8629006051783381893L, 33881913264171L),
                                 d<"$">(targetPos, -8630619894320566335L, 33881913264171L),
                                 d<"$">(targetPos, -8629297463070189947L, 33881913264171L),
                                 distance,
                                 finalTick
                              )
                           );
                        }
                     }
                  }

                  if (targetEntity == null || targetPos == null) {
                     return;
                  }

                  d<"$">(this, -8628919301168543011L, 33881913264171L).D(11747522392279L);
                  d<"O">(this, (long)(System.currentTimeMillis() + finalTick * 60.0), -8630232870524935369L, 33881913264171L);
                  if (d<"$">(this, -8636420304019023793L, 33881913264171L).getValue() && this.c(targetPos, finalTick)) {
                     if (d<"$">(this, -8630663489425419154L, 33881913264171L).getValue()) {
                        ClientUtils.P(125527250587045L, "will reel in at: %d ms (current: %d)");
                     }

                     return;
                  }

                  if (d<"$">(this, -8630663489425419154L, 33881913264171L).getValue()) {
                     String var50 = isCrystalTarget ? "Targeting crystal at %.1f" : "%.1f";
                     ClientUtils.P(125527250587045L, String.format(b<"o">(14685, 3681747800314668015L), var50, finalTick));
                  }

                  Rotation calculatedRotation = RotationUtils.G(targetPos, 29982110852869L);
                  calculatedRotation = new Rotation(21273681362686L, calculatedRotation.getYaw(), calculatedRotation.l(5377274095808L) + -1.0F);
                  if (d<"$">(this, -8630663489425419154L, 33881913264171L).getValue()) {
                     ClientUtils.P(
                        125527250587045L, String.format("%.1f (dist: %.1f", calculatedRotation.l(5377274095808L) - -1.0F, calculatedRotation.l(5377274095808L))
                     );
                  }

                  d<"O">(this, calculatedRotation, -8635672406196358342L, 33881913264171L);
                  RotationUtils.F(calculatedRotation, 3052380832273L);
                  d<"O">(this, 1, -8636923595402289301L, 33881913264171L);
               }
            }
         }
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != '$' && var8 != 'O' && var8 != 235 && var8 != 162) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 226) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Y') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == '$') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'O') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 235) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private boolean c(Vec3 targetPos, double ticks) {
      树友何何友何树何树友.E();
      if (this.Q(new Object[]{52406761729175L})) {
         return true;
      } else {
         List<Vec3> trajectoryPoints = this.J(targetPos, ticks);
         int i = 0;
         if (0 < trajectoryPoints.size() - 1) {
            Vec3 current = trajectoryPoints.get(0);
            Vec3 next = trajectoryPoints.get(1);
            BlockHitResult result = mc.level.clip(new ClipContext(current, next, Block.COLLIDER, Fluid.NONE, null));
            if (result.getType() == Type.BLOCK && 0 < trajectoryPoints.size() - 2) {
               BlockPos blockPos = result.getBlockPos();
               BlockState blockState = mc.level.getBlockState(blockPos);
               if (!blockState.isAir() && !blockState.getCollisionShape(mc.level, blockPos).isEmpty()) {
                  if (this.何何何何树树树何何友.getValue()) {
                     ClientUtils.P(125527250587045L, String.format("", blockPos.getX(), blockPos.getY(), blockPos.getZ(), 0, trajectoryPoints.size()));
                  }

                  return true;
               }
            }

            i++;
         }

         return false;
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 4291;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树何何树树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   @Override
   protected void h() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.G();
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private double f(double time, 何友树树树树何何树树.树友友何友树树友树友 pattern, double targetSpeed, double distance) {
      树友何何友何树何树友.E();
      if (this.Q(new Object[]{52406761729175L})) {
         return time;
      } else {
         double adjustFactor = 1.0;
         switch (何友树树树树何何树树$何友友树何树友树树友.树何何友何树何何友友[pattern.何友树何何何树何树何.ordinal()]) {
            case 1:
               double var10000 = 1.5 + Math.min(targetSpeed * 4.0, 0.6);
            case 2:
            case 3:
            case 4:
            case 5:
               double turnFactor = 1.05;
               double targetToPlayerAngle = Math.atan2(mc.player.getZ() - pattern.友友树友友何树友何友.z, mc.player.getX() - pattern.友友树友友何树友何友.x);
               double turnRelativeToPlayer = Math.cos(targetToPlayerAngle - pattern.友树友何何友友树何何);
               if (turnRelativeToPlayer > 0.3) {
                  turnFactor = 0.9;
               }

               if (turnRelativeToPlayer < -0.3) {
                  turnFactor = 1.3;
               }

               adjustFactor = turnFactor;
            case 6:
               if (!(targetSpeed > 0.15)) {
                  break;
               }

               double var21 = 1.0 + Math.min(distance / 15.0, 0.5);
            default:
               adjustFactor = 1.05;
         }

         return time * adjustFactor;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private double f(Entity target, double time, double velocity, double airResistance, double gravity) {
      树友何何友何树何树友.E();
      Vec3 predictedTargetPos = this.K(target, time);
      if (this.Q(new Object[]{52406761729175L})) {
         return Double.MAX_VALUE;
      } else {
         double dx = predictedTargetPos.x - mc.player.getX();
         double dy = predictedTargetPos.y - (mc.player.getY() + mc.player.getEyeHeight());
         double dz = predictedTargetPos.z - mc.player.getZ();
         double horizontalDist = Math.sqrt(dx * dx + dz * dz);
         double initialYVelocity = this.S(dy, time, 0.03, 0.99);
         double horizontalVelocity = this.y(horizontalDist, time, airResistance);
         if (Math.sqrt(horizontalVelocity * horizontalVelocity + initialYVelocity * initialYVelocity) > 1.6500000000000001) {
            return 100.0;
         } else {
            double vx = dx / horizontalDist * horizontalVelocity;
            double vz = dz / horizontalDist * horizontalVelocity;
            double snowballX = 0.0;
            double snowballY = 0.0;
            double snowballZ = 0.0;
            int tick = 0;
            if (0.0 < Math.ceil(time)) {
               snowballX = 0.0 + vx;
               snowballY = 0.0 + initialYVelocity;
               snowballZ = 0.0 + vz;
               double var10000 = vx * airResistance;
               double motionY = initialYVelocity * airResistance;
               var10000 = vz * airResistance;
               var10000 = motionY - gravity;
               tick++;
            }

            double finalX = mc.player.getX() + snowballX;
            double finalY = mc.player.getY() + mc.player.getEyeHeight() + snowballY;
            double finalZ = mc.player.getZ() + snowballZ;
            return Math.sqrt(
               Math.pow(finalX - predictedTargetPos.x, 2.0) + Math.pow(finalY - predictedTargetPos.y, 2.0) + Math.pow(finalZ - predictedTargetPos.z, 2.0)
            );
         }
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private int l() {
      树友何何友何树何树友.E();
      if (this.Q(new Object[]{52406761729175L})) {
         return -1;
      } else {
         if (this.友何树友树何友树何何.getValue()) {
            ItemStack offhandStack = mc.player.getOffhandItem();
            if (!offhandStack.isEmpty()) {
               if (offhandStack.getItem() instanceof EggItem || offhandStack.getItem() instanceof SnowballItem) {
                  return -2;
               }

               if (this.何树何何友何何友何友.getValue() && offhandStack.getItem() instanceof FishingRodItem) {
                  return -2;
               }
            }
         }

         if (this.树友树树何何何树友树.getValue()) {
            int i = 0;
            ItemStack stack = mc.player.getInventory().getItem(0);
            if (stack.isEmpty()) {
            }

            if (stack.getItem() instanceof EggItem || stack.getItem() instanceof SnowballItem) {
               return 0;
            }

            if (this.何树何何友何何友何友.getValue() && stack.getItem() instanceof FishingRodItem) {
               return 0;
            }

            i++;
         }

         return -1;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "{e\u0002\t\u001c\bt%O\u0002\u0016\u0015qxDD\u001e\b|~@\u000f]\u000eu{@D\u0003\u000byrI\u0018]伲叓栚栽桻桢伲位栚栽";
      m[1] = "\u0003z\u000b\bS\u0002\f:F\u0003Y\u001f\tgMEJ\f\fa@EU\u0000\u0010x\u000b%I\u0000\u0002qW=]\u0001\u0015q";
      m[2] = "3`5\u001dTz< x\u0016^g9}sPVz4{w\u001b\u0015|=~wPKy1w~\f\u0015佀厛栟栊桯株佀伅栟栊Z台栄伅佛栊厵台佀桁佛";
      m[3] = "U\u0010\u007f)\u0004(U\u0010hu\b'O[|h\u001b-_[{o\u00102\u0015#ndZ";
      m[4] = double.class;
      n[4] = "java/lang/Double";
      m[5] = "H\u0003\u001bN\u00058V\u000b\u0001\u0001f,R";
      m[6] = "-X4\u001e\f\u000b\"\u0018y\u0015\u0006\u0016'ErS\u000e\u000b*Cv\u0018M\r#FvS\u0013\b/O\u007f\u000fM桵厅佣住厶伶桵伛栧发";
      m[7] = "\u0015>\u001c]I\u0018!\u001d\u0013\u001d\u0004\u0013+\u0000\u0016@\u000fU#\u001d\u001bF\u000b\u001e`?\u0010W\u0012\u0017+I";
      m[8] = "\u001f\u0004|B`\u001e\u0014\u000bm\r\u001c\u0007\u001b\u0011cN+7\r\u0006oS:\u001b\u001a\u000b";
      m[9] = "RMExl\u0000RMR$`\u000fH\u0006F9s\u0005X\u0006T8u\u0000HQ\u001f\u0013o\u001dU\\H";
      m[10] = "`\tm\u001ewAoI \u0015}\\j\u0014+SnOo\u0012&SqCs\u000bm?wAo\u0002\"\u0013NOo\u0012&";
      m[11] = boolean.class;
      n[11] = "java/lang/Boolean";
      m[12] = "Wh\u0002/\u0005%Wh\u0015s\t*M#\u0001n\u001a ]#?o\u001c)Kl\u0015u\u0001#WE\u0017o\f";
      m[13] = "b@P>4yb@Gb8vx\u000bJu-gcWO>)bcQKs6|\"BE}<>_@Vf<bnJQ~=@`D]u+QoQM\u007f7@mFOu-4MFPy6~";
      m[14] = long.class;
      n[14] = "java/lang/Long";
      m[15] = int.class;
      n[15] = "java/lang/Integer";
      m[16] = "\u0016K1y\u0006_\u0016K&%\nP\f\u000028\u0019Z\u001c\u0000 9\u001f_\fWk'\u0007W\u0001K7y\"X\u000eK+#\u0004D\u0001";
      m[17] = "\u0014\u001e*\u001b\n\u007f\u001b^g\u0010\u0000b\u001e\u0003lV\b\u007f\u0013\u0005h\u001dK]\u0018\u0014q\u0014\u0000";
      m[18] = "\biJr2\u0005<JE2\u007f\u000e6W@otH>JMip\u0003}hFxi\n6\u001e";
      m[19] = "M}\u0003uFKB=N~LVG`E8DKJfAs\u0007栵佻变另佃核可句但佸";
      m[20] = "xB?9p\u0010w\u0002r2z\rr_ytj\u000br@btw\u001aw\\t(1-tXp.v\u0010u";
      m[21] = "Y\u0001\u001b}\u001dZm\"\u0014=PQg?\u0011`[\u0017o\"\u001cf_\\,\u0000\u0017wFUgv";
      m[22] = void.class;
      n[22] = "java/lang/Void";
      m[23] = "A\u0018yH?PNX4C5MK\u0005?\u0005=PF\u0003;N~VO\u0006;\u0005 SC\u000f2Y~佪叩桧框栺桁佪佷桧框\u000f伅叴叩桧伂栺厛栮栳厽";
      m[24] = "j\n";
      m[25] = "}w#Ii\u0006r7nBc\u001bwje\u0004k\u0006zlaO(\u0000sia\u0004v\u0005\u007f`hX(似叕栈栜栻栗似佋栈栜\u000e栗厢叕佌叆栻栗厢栏叒";
      m[26] = "\u0013$.t\u000f)\u0013$9(\u0003&\to-5\u0010,\u0019o*2\u001b3S\t3.0%\u000e46.F\u0014\u00041?";
      m[27] = "I\rn@?>I\ry\u001c31SFm\u0001 ;CFv\u000b$2KFY\u0002;'d\u0007t\u001a7/SLX\u0002=4L";
      m[28] = "e4%jv\u0018e426z\u0017\u007f\u007f&+i\u001do\u007f=!m\u0014g\u007f\u0012(r\u0001H>?0~\t\u007fu\u0017(n\u0018o";
      m[29] = "du*@,\u0006du=\u001c \t~>=\u0002(\nddp#(\u0001os,\u000f'\u001b";
      m[30] = "9\u0011!s6\u00169\u00116/:\u0019#Z612\u001a9\u0000{0.\u0013#\u001d%1:\u00062\u0006{\u0010.\u0013#\u001d\u00051:\u00062\u0006\u0012<6\u001a\u001a\u001b18";
      m[31] = "4)\u001f\b=A;iR\u00037\\>4YE'Z>+BE伇句厜伒栠伾桃佻框厌";
      m[32] = "\u001aI\u000eR\u0015D\u0011F\u001f\u001dtJ\u001aM\u001bG";
      m[33] = "\u00013i^\u0018:\u0002/s7伯余桿伃叚叴伯叇厥厝\u0019^\u0010t\u0019?sU\u0016n\u0018";
      m[34] = "f4<w~*e(&\u001e栍受作伄厏标佉栍作伄L'-n;6%pkxb";
      m[35] = "i!x]w\u0012#uw\u001e\u0013厩厐佅会句叐厩厐叛桞&)Slc#^c\u0007c ";
      m[36] = "JO\u00124\u0005{IS\b]厬历佰使厡伀伲桜佰栻bb\u00055\u0017Z\\6P4J";
      m[37] = "C\bdkx\u0001\n\u000ff~\u0017'=9ZR^&?w=m~\u0019\u001c\u0016tj|\f";
      m[38] = "lvwF\\eojm/佫厘佖但叄佲栯伆佖栂\u0007\u0016\u000f!1tnAI7h";
      m[39] = "$;y\bAmnovK%栌佃栛厅厰佸栌佃栛伛s\u001f,!y\"\u000bUx.:";
      m[40] = "^d6\t AF96\u000b[u{\u001c\u000b!\u0017sfX-\\\"WG'5\u0001\"U";
      m[41] = "\u0015[\u0004\u0016?pA\f\u0004N]栀伧伿厢佶桄佄伧厡厢+=(\u0002\u000b]O$k\u0016\u0018";
      m[42] = "\u0014\u00020\u000eOO\u0017\u001e*g另厲厰伲桙厤另伬桪厬@XO\u0001I\u0017~\f\u001a\u0000\u0014";
      m[43] = "KsEg`\u0002\u0001'J$\u0004厹桨厉伧佁余档伬厉厹\u001c>CN1\u001edt\u0017Ar";
      m[44] = "\u001a\u001cx)p5\f\rwo\u001a\fp\u0001$g 2\u0016\u000b'|~^";
      m[45] = "QS\\\u0013r\u001cROFz佅栻栯佣佱伧佅栻佫佣,F$E\u0007\u0004M\u0014 ^\u000b";
      m[46] = "DZ^$ag\u000e\u000eQg\u0005叜厽厠厢厜叆叜伣桺厢_?&A\u0018\u0005'urN[";
      m[47] = "\u001b4\u0006s\rL\u0018(\u001c\u001a桾厱桥桀伫佇伺桫县桀v%\r\u0002F!HqX\u0003\u001b";
      m[48] = "-O\u0002+\u0003~ K\u0006jy栖厎佹校栋桠双厎叧校\u0012F~wUUjFr?C";
      m[49] = "\u000e#\"I-nI8`\u0018C栖叱厄栁叡厀双叱桞佅\"\u007fk\b,vC8pJ}";
      m[50] = "v\u000b}Q@EpW<\u0002!可栃栢厏佦叢佱栃司桕;M\u001c+Q-RK@j\u0002";
      m[51] = "Zm|3]lYqfZ栮伏叾參栕桃栮桋叾栙\f7\u0007>Y8`a\r=Z";
      m[52] = "[dYrN[XxC\u001b叧伸栥及栰但叧桼佡佔)$N\u0015\u0006q\u0017p\u001b\u0014[";
      m[53] = "L\u001fJ5\u0006tO\u0003P\\伱厉栲伯佧企桵众栲伯:9V2\u0011\u0012E,\u00015M";
      m[54] = " }#YP8#a90佧佛会栉桊右佧叅桞栉S\u000fPv}hm[\u0005w ";
      m[55] = "Z+\u0013\u0005;`\u001d0QTULf\"K\u001fom\u0000(H\u00041\u0001";
      m[56] = "S-D\u0014A:\u001a*F\u0001.\u001e*\u0013k:n\u0012%\u001e-]Q2\u001a=L\u0014V0\u000f";
      m[57] = "Ts2_\u0004\u001cWo(6桷使佮叝伟栯厭叡株叝B\t\u0004R\tf|]QST";
      m[58] = "# \u0006\u000fr\u0006l4\u0006\b\u0013\nJc\u000e]\"\\JZ\u0005\u001c)\u0019\u007f!S\u0018.]";
      m[59] = "\u001f\u000f.\u000bQSNOr\n)3r~\u00155~$cl\u00133n9y}\u000b.b+.\u0006w\bK\u0010\u0015W7TJ";
      m[60] = ")\u0012&KYW*\u000e<\"株桰厍桦伋栻台桰伓伢V\u001e\u000f\u000e\u007fE7L\u000b\u0015s";
      m[61] = "\u000f\"\"[qV\f>82栂厫厫厌伏叱变桱桱厌R\u0003f\fS(.\b$UT";
      m[62] = "_E\u0014\u0018\u001c\u001b\u0015\u0011\u001b[x伾桼伡栲厠伥伾桼伡叨cBZZ\u0007O\u001b\b\u000eUD";
      m[63] = "\u00064i\u0007YD\u0005(sn佮档桸伄叚伳株档桸桀\u0019QB@\u00104aQN\b\u0006";
      m[64] = "#UB?P\u0003.QF~*厱桚叽伥佛叩厱桚佣伥\u0006\u0010\fyC\u001a}F\b~\u0007";
      m[65] = "AX\u001fL_5BD\u0005%叶佖句佨伲佸叶佖句栬o\u0014Ho\u001dR\u0013\u001f\n6\u001a";
      m[66] = "SqSQ<&PmI8伋栁号佁佾佥厕栁号栅#Q4hK}IZ2rJ";
      m[67] = "Rg\u0010\u0010\u0018;\u00183\u001fS|桚桱厝佲桲县伞伵桇栶kFzW%K\u0013\f.Xf";
      m[68] = "b[\u0005\n\u000f^-O\u0005\rnR\u000b\u0018\rX_\u0006\u000b!\u0006\u0019TA>ZP\u001dS\u0005";
      m[69] = "e-u\\,af.z_RcQ'(Xm7Q\u0016uQ<uod|\u000e0d";
      m[70] = "\u0000YwP2*\u0003Em9厛佉桾号栞栠厛栍厤栭\u0007\u0006).\u0016Y\u007f\u0006%f\u0000";
      m[71] = "\u0015\u001d\u0019\u0004ut\u0016\u0001\u0003m佂桓桫伭伴厮栆厉桫厳iT&0H\u001f\u0000\u0003`&\u0011";
      m[72] = "\u0017$N\u0014B}\u001a JU8佑厴桖伩佰佥栕伪桖伩-\u00025H4\u0010UHaGw";
      m[73] = "SHkz(nPTq\u0013伟伍栭另栂栊伟伍栭另\u001b/~7\u0005\u001fz}z,\t";
      m[74] = ">\u0005c(t\u0015=\u0019yA佃佶伄伵栊桘标佶伄厫\u0013~t[c\u0010-*!Z>";
      m[75] = "\nb\u001a\f0m\u000e!N\tH=goJ\\xkg_J\u001er.R$\u001c\u001auj";
      m[76] = "T\u0016c6s?[\u00124&\u001e\u0016q7\u0012D|7\n\u00032+s3]\u0013";
      m[77] = "p?g@2M7$%\u0011\\kL6?Zf@*<<A8,\"#9M-\u00112!2D\\";
      m[78] = "\u0012\u0015N{\u000e\\C\u001d[1t-7j|Jt\u0006KTEsOWCA\u000f";
      m[79] = "\u001aF_w2b\u0019ZE\u001e桁企桤叨佲佃桁原桤佶/\"d;L\u0011Np` @";
      m[80] = "\u0014\n\u000b.8e^^\u0004m\\栄叭株栭厖原栄样株号Uf$\u0011HP-,p\u001e\u000b";
      m[81] = "gb\\sDK(v\\t%G\u000e!T!\u0014\u0010\u000e\u0018_`\u001fT;c\td\u0018\u0010";
      m[82] = "\ng\u001bcD\n\u000e$Of<ZgjK3\u0003\u0005gZKq\u0006IR!\u001du\u0001\r";
      m[83] = "O4\u0018_\u001e[L(\u00026厷伸叫伄厫叵厷厦栱厚hSN\u001d\u00129\u0017F\u0019\u001aN";
      m[84] = "-fD\u001e\u0001n.z^w伶桉桓栒佩桮伶厓众栒4NR*pd]\u0019\u0014<)";
      m[85] = "\u0019\foZ\u000b4\u001a\u0010u3厢叉厽似栆株桸佗厽厢\u001f\u000f]mO[~]YvC";
      m[86] = "E\u0010E4u@AS\u00111\r\u0010(\u001d\u0015d=G(-\u0015&7\u0003\u001dVC\"0G";
      m[87] = "Q\u0016%\"V7G\u0014*?.9lF{m\u0011hl}/>^(Z\u0017$8D)";
      m[88] = "\u001b!\u001e\u0001W\u0016\u0018=\u0004h栤叫县休厭伵栤栱县厏nWWXF4P\u0003\u0002Y\u001b";
      m[89] = "\u0011\u001e9HAo\u0012\u0002#!栲厒伫厰厊核叨案伫厰I\u001eA!L\u000bwJ\u0014 \u0011";
      m[90] = "^\u0011^m\u000bu]\rD\u0004厢厈栠伡叭余厢厈栠桥.=X1\u0003\u0013Gj\u001e'Z";
      m[91] = ")r}J`yc&r\t\u0004参低伖伟史余参栊伖桛1>8,0&Itl#s";
      m[92] = "}m&\"lD~q<Koz'z3r{\u0006&`19\u0006G`eo6zFzg$K";
      m[93] = "\u00026_osY\u0001*E\u0006佄桾伸伆栶佛栀厤桼伆/9s\u0017_#\u0011m&\u0016\u0002";
      m[94] = "\"N1(\u001e\u0014!R+A桭叩优栺伜桘厷叩优叠Ap\tN~D={K\u0017y";
      m[95] = ".\u0001b\u0013%Q-\u001dxz厌厬伔伱住伧桖桶伔桵\u0012E>U8\u0001jE2\u001d.";
      m[96] = "WU|eJ2ZQx$0桚佪栧桟原栩伞栮栧伛\\\n=\rC$'\\9\n\u0007";
      m[97] = "]'\u0010\u0006G/P#\u0014G=厝叾桕叩叼你桇叾休叩?\u0007cW R\u0001\u0003 \u0003%";
      m[98] = "u\u00134H_\u000bv\u000f.!佨佨发厽桝叢叶佨住桧D\u0018\fO(\u0011-OJYq";
      m[99] = "~\u0002\u0010Mzz}\u001e\n$位桝佄伲厣佹位厇佄厬`\u001bz4#\u0017^O/5~";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private Vec3 U(Entity target, double ticks) {
      树友何何友何树何树友.E();
      if (mc.level == null) {
         return null;
      } else {
         this.Y(target);
         何友树树树树何何树树.树友友何友树树友树友 pattern = this.C(target.getId());
         double motionX = target.getX() - target.xOld;
         double motionY = target.getY() - target.yOld;
         double motionZ = target.getZ() - target.zOld;
         double predictedX = target.getX();
         double predictedY = target.getY();
         double predictedZ = target.getZ();
         boolean onGround = target.onGround();
         double turnMultiplier = 0.0;

         double speedMultiplier = switch (何友树树树树何何树树$何友友树何树友树树友.树何何友何树何何友友[pattern.何友树何何何树何树何.ordinal()]) {
            case 1 -> 1.05 + Math.min(ticks * 0.01, 0.15);
            case 2 -> 1.03 + Math.min(ticks * 0.008, 0.12);
            case 3 -> 0.97 - Math.min(ticks * 0.01, 0.15);
            case 4 -> 0.98 - Math.min(ticks * 0.008, 0.12);
            case 5 -> {
               turnMultiplier = pattern.树何树树友树何树树何 * 0.8;
               yield 0.95;
            }
            default -> 1.0;
         };
         motionX *= speedMultiplier;
         motionZ *= speedMultiplier;
         if (Math.abs(turnMultiplier) > 0.01) {
            double currentAngle = pattern.友树友何何友友树何何;
            double speed = Math.sqrt(motionX * motionX + motionZ * motionZ);
            double newAngle = currentAngle + turnMultiplier;
            motionX = Math.cos(newAngle) * speed;
            motionZ = Math.sin(newAngle) * speed;
         }

         if (pattern.树友何树树树友友友树) {
            motionY = Math.max(motionY - 0.08, -3.92);
         }

         int i = 0;
         if (0.0 < Math.min(ticks, 20.0)) {
            motionX *= 0.91;
            motionZ *= 0.91;
            if (onGround) {
               if (Math.abs(motionY) < 0.005) {
                  motionY = 0.0;
               }

               motionY *= 0.98;
            }

            motionY = (motionY - 0.08) * 0.98;
            if (motionY < -3.92) {
               motionY = -3.92;
            }

            predictedX += motionX;
            predictedY += motionY;
            predictedZ += motionZ;
            if (predictedY <= target.getY() && Math.abs(motionY) < 0.005) {
               predictedY = target.getY();
            }

            if (motionY < 0.0) {
               BlockPos pos = new BlockPos((int)predictedX, (int)(predictedY - 0.2), (int)predictedZ);
               if (!mc.level.isEmptyBlock(pos)) {
                  predictedY = Math.floor(predictedY) + 1.0;
               }
            }

            i++;
         }

         return new Vec3(predictedX, predictedY + target.getEyeHeight(), predictedZ);
      }
   }

   private double y(double distance, double time, double airResistance) {
      double minV = 0.0;
      树友何何友何树何树友.E();
      int iter = 0;
      double d = 0.0;
      int t = 0;
      if (0.0 < time) {
         d = 2.5;
         t++;
      }

      if (d < distance) {
         minV = 2.5;
      }

      iter++;
      return (minV + 2.5) / 2.0 * 1.02;
   }

   @EventTarget
   public void y(PacketEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ServerboundInteractPacket) {
            this.友何树友树树友树友树 = true;
            this.树友友友何友友树树友 = System.currentTimeMillis();
            if (this.何何何何树树树何何友.getValue()) {
               ClientUtils.P(125527250587045L, "Detected attack packet");
            }
         }

         if (packet instanceof ServerboundUseItemPacket wrapper) {
            if (wrapper.getHand() == InteractionHand.MAIN_HAND) {
               if (!mc.player.getMainHandItem().isEmpty() && mc.player.getMainHandItem().getItem() instanceof FishingRodItem) {
                  return;
               }
            } else if (!mc.player.getOffhandItem().isEmpty() && mc.player.getOffhandItem().getItem() instanceof FishingRodItem) {
               return;
            }

            this.何树树何友何树树树树 = true;
            this.树友何树何树友友何友 = System.currentTimeMillis();
            if (this.何何何何树树树何何友.getValue()) {
               ClientUtils.P(125527250587045L, "Detected active packet");
            }
         }

         if (packet instanceof ServerboundPlayerActionPacket && ((ServerboundPlayerActionPacket)event.getPacket()).getAction() == Action.START_DESTROY_BLOCK) {
            this.何树树何友何树树树树 = true;
            this.树友何树何树友友何友 = System.currentTimeMillis();
            if (this.何何何何树树树何何友.getValue()) {
               ClientUtils.P(125527250587045L, "Detected active packet");
            }
         }
      }
   }

   private void Y(Entity entity) {
      树友何何友何树何树友.E();
      if (entity != null) {
         int entityId = entity.getId();
         Vec3 currentPosition = new Vec3(entity.getX(), entity.getY(), entity.getZ());
         Vec3 currentMotion = new Vec3(entity.getX() - entity.xOld, entity.getY() - entity.yOld, entity.getZ() - entity.zOld);
         List<Vec3> positionHistory = this.树树友树何树友树何何.getOrDefault(entityId, new ArrayList<>());
         positionHistory.add(currentPosition);
         if (positionHistory.size() > 8) {
            positionHistory.remove(0);
         }

         this.树树友树何树友树何何.put(entityId, positionHistory);
         List<Vec3> motionHistory = this.何树树何何何何树何何.getOrDefault(entityId, new ArrayList<>());
         motionHistory.add(currentMotion);
         if (motionHistory.size() > 8) {
            motionHistory.remove(0);
         }

         this.何树树何何何何树何何.put(entityId, motionHistory);
         double currentSpeed = Math.sqrt(currentMotion.x * currentMotion.x + currentMotion.z * currentMotion.z);
         List<Double> speedHistory = this.友友友何树树树何友友.getOrDefault(entityId, new ArrayList<>());
         speedHistory.add(currentSpeed);
         if (speedHistory.size() > 8) {
            speedHistory.remove(0);
         }

         this.友友友何树树树何友友.put(entityId, speedHistory);
         this.何何树友树树何何树友.put(entityId, entity.onGround());
      }
   }

   private void L() {
      树友何何友何树何树友.E();
      if (mc.level != null) {
         Iterator var4 = mc.level.entitiesForRendering().iterator();
         if (var4.hasNext()) {
            Entity entity = (Entity)var4.next();
            if (entity instanceof Player && entity != mc.player) {
               this.Y(entity);
            }
         }
      }
   }

   @Override
   protected void M() {
      this.友何友何友友友友树友.D(11747522392279L);
      this.何友树何何何树何树何.D(11747522392279L);
      this.树何友友树树树树友树 = null;
      this.何何树何友友何友友友 = 0;
      this.友何树友树树友树友树 = false;
      this.何树树何友何树树树树 = false;
      this.友友何何何何树树何树 = false;
      this.何树友何何何友树友树 = -1;
      this.树树友树何树友树何何.clear();
      this.何树树何何何何树何何.clear();
      this.何何树友树树何何树友.clear();
      this.友友友何树树树何友友.clear();
   }

   private double N(Entity target) {
      树友何何友何树何树友.E();
      if (this.Q(new Object[]{52406761729175L})) {
         return 0.0;
      } else {
         何友树树树树何何树树.树友友何友树树友树友 pattern = this.C(target.getId());
         double offsetX = target.getX() - mc.player.getX();
         double offsetZ = target.getZ() - mc.player.getZ();
         double horizontalDist = Math.sqrt(offsetX * offsetX + offsetZ * offsetZ);
         double baseFlightTime = horizontalDist / 1.5;
         double targetMotionX = target.getX() - target.xOld;
         double targetMotionZ = target.getZ() - target.zOld;
         double targetSpeed = Math.sqrt(targetMotionX * targetMotionX + targetMotionZ * targetMotionZ);
         double targetAngle = Math.atan2(targetMotionZ, targetMotionX);
         double throwAngle = Math.atan2(offsetZ, offsetX);
         double angleDiff = Math.abs(targetAngle - throwAngle);
         if (angleDiff > Math.PI) {
            angleDiff = (Math.PI * 2) - angleDiff;
         }

         double targetSpeedAlongThrow = targetSpeed * Math.cos(angleDiff);
         if (Math.abs(angleDiff) < Math.PI / 2) {
         }

         if (Math.abs(angleDiff) > Math.PI * 3.0 / 4.0) {
            double var10000 = 1.4 + Math.min(targetSpeed * 2.0, 0.8);
         }

         double distanceFactor = Math.min(1.0 + horizontalDist / 20.0 * 0.5, 1.8);
         double speedAdjustedTime = baseFlightTime * (1.0 + targetSpeedAlongThrow * 0.8);
         double adjustedTime = speedAdjustedTime * 1.15 * distanceFactor;
         adjustedTime = this.f(adjustedTime, pattern, targetSpeed, horizontalDist);
         double bestHitTime = adjustedTime;
         double minError = Double.MAX_VALUE;
         double searchRadius = Math.max(adjustedTime * 0.25, 5.0);
         double searchStep = Math.max(adjustedTime * 0.05, 0.5);
         double timeGuess = adjustedTime - searchRadius;
         if (timeGuess <= adjustedTime + searchRadius) {
            if (!(timeGuess <= 0.0)) {
               double error = this.f(target, timeGuess, 1.5, 0.99, 0.03);
               if (error < Double.MAX_VALUE) {
                  minError = error;
                  bestHitTime = timeGuess;
               }
            }

            double var66 = timeGuess + searchStep;
         }

         timeGuess = searchStep * 2.0;
         double refinedStep = searchStep / 4.0;
         double timeGuessx = bestHitTime - timeGuess;
         if (timeGuessx <= bestHitTime + timeGuess) {
            if (!(timeGuessx <= 0.0)) {
               double error = this.f(target, timeGuessx, 1.5, 0.99, 0.03);
               if (error < minError) {
                  bestHitTime = timeGuessx;
               }
            }

            double var67 = timeGuessx + refinedStep;
         }

         timeGuessx = bestHitTime * 1.05;
         if (this.何何何何树树树何何友.getValue()) {
            ClientUtils.P(
               125527250587045L, String.format("Target speed: %.2f", targetSpeed * 20.0, angleDiff * 180.0 / Math.PI, 1.15 * distanceFactor, timeGuessx)
            );
         }

         return Math.max(timeGuessx, 1.0);
      }
   }

   private Vec3 K(Entity target, double ticks) {
      树友何何友何树何树友.E();
      Vec3 basePosition = this.U(target, ticks);
      if (basePosition == null) {
         return null;
      } else {
         List<Vec3> posHistory = this.树树友树何树友树何何.get(target.getId());
         List<Vec3> motionHistory = this.何树树何何何何树何何.get(target.getId());
         if (posHistory != null && posHistory.size() >= 2 && motionHistory != null && motionHistory.size() >= 2) {
            Vec3 latestMotion = motionHistory.get(motionHistory.size() - 1);
            Vec3 prevMotion = motionHistory.get(motionHistory.size() - 2);
            double motionChange = Math.sqrt(Math.pow(latestMotion.x - prevMotion.x, 2.0) + Math.pow(latestMotion.z - prevMotion.z, 2.0));
            if (motionChange > 0.05) {
               double currentSpeed = Math.sqrt(latestMotion.x * latestMotion.x + latestMotion.z * latestMotion.z);
               double moveAngle = Math.atan2(latestMotion.z, latestMotion.x);
               double extraDistance = currentSpeed * ticks * 0.3;
               double newX = basePosition.x + Math.cos(moveAngle) * extraDistance;
               double newZ = basePosition.z + Math.sin(moveAngle) * extraDistance;
               return new Vec3(newX, basePosition.y, newZ);
            } else {
               return basePosition;
            }
         } else {
            return basePosition;
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "何大伟230622198107200054";
   }

   private void G() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.何树友何何何友树友树 != -1) {
            if (this.树友何友友树友树何友.getValue()) {
               mc.getConnection().send(new ServerboundSetCarriedItemPacket(this.何树友何何何友树友树));
            }

            mc.player.getInventory().selected = this.何树友何何何友树友树;
            this.何树友何何何友树友树 = -1;
         }
      }
   }

   private List<Entity> O(double range) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && mc.level != null) {
         List<Entity> crystals = new ArrayList<>();

         for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity != null && !entity.isRemoved()) {
               if (!(entity instanceof EndCrystal)) {
                  break;
               }

               double distance = mc.player.distanceTo(entity);
               if (distance < 1.5) {
                  if (!this.何何何何树树树何何友.getValue()) {
                     continue;
                  }

                  ClientUtils.P(125527250587045L, String.format("Skipping crystal at %.1f", entity.getX(), entity.getY(), entity.getZ(), distance));
               }

               double heightDifference = entity.getY() - mc.player.getY();
               if (heightDifference > 2.0) {
                  if (!this.何何何何树树树何何友.getValue()) {
                     continue;
                  }

                  ClientUtils.P(125527250587045L, String.format("%.1f", entity.getX(), entity.getY(), entity.getZ(), heightDifference));
               }

               if (distance <= range) {
                  crystals.add(entity);
               }
               break;
            }
         }

         crystals.sort(Comparator.comparingDouble(mc.player::distanceTo));
         if (this.何何何何树树树何何友.getValue() && !crystals.isEmpty()) {
            ClientUtils.P(125527250587045L, String.format("%.1f (too close: %.1f blocks)", crystals.size(), range));
         }

         return crystals;
      } else {
         return new ArrayList<>();
      }
   }

   private static enum 友树何何树友友何树何 implements  {
      树树友何树友何何树树,
      友友何何友友友友友树,
      友何何何友何友树何树,
      树何树友友何树何树何,
      友友友友友友友何树友,
      树友树树友友树树树友,
      何树何树友何何树何友,
      友树友何何何树何友友;

      private static final long a;
      private static final Object[] b = new Object[12];
      private static final String[] c = new String[12];
      private static int _何树友被何大伟克制了 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(8853540402823431190L, -7806061777203071413L, MethodHandles.lookup().lookupClass()).a(27515101306323L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(80724976422968L << var2 * 8 >>> 56);
         }

         var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[8];
         int var6 = 0;
         String var5 = "S\u0095!TH¯23ì~X\u0005\u001eõ\u0018ó\u00106ãjN\b1äô\u009a\u008b\u000eµ£ã¹\u0094\b\u0015H³)\u0015Ñ\u00ad¡\u0018LÂÎÜàm,+3ëLÆ^\u00adûÚÅ\u008b\u009d\u0098\u0088\täø\u0010\u0086|»ÎE\u0089¨ØG¿i9\u0000Á\u0017u\b»£:ûé&R\u0083";
         byte var7 = 93;
         char var4 = 16;
         int var9 = -1;

         label28:
         while (true) {
            String var11 = var5.substring(++var9, var9 + var4);
            byte var10001 = -1;

            while (true) {
               String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var17;
                     if ((var9 += var4) >= var7) {
                        树树友何树友何何树树 = new 何友树树树树何何树树.友树何何树友友何树何();
                        友友何何友友友友友树 = new 何友树树树树何何树树.友树何何树友友何树何();
                        友何何何友何友树何树 = new 何友树树树树何何树树.友树何何树友友何树何();
                        树何树友友何树何树何 = new 何友树树树树何何树树.友树何何树友友何树何();
                        友友友友友友友何树友 = new 何友树树树树何何树树.友树何何树友友何树何();
                        树友树树友友树树树友 = new 何友树树树树何何树树.友树何何树友友何树何();
                        何树何树友何何树何友 = new 何友树树树树何何树树.友树何何树友友何树何();
                        友树友何何何树何友友 = new 何友树树树树何何树树.友树何何树友友何树何();
                        return;
                     }

                     var4 = var5.charAt(var9);
                     break;
                  default:
                     var0[var6++] = var17;
                     if ((var9 += var4) < var7) {
                        var4 = var5.charAt(var9);
                        continue label28;
                     }

                     var5 = "¾Á\u0015\u0090.9W\u007fÅû!èJ·öðp\u0088\u0005Øû¼gk\u0010O7n~\"%bÒÊYyeUþ\u009c÷";
                     var7 = 41;
                     var4 = 24;
                     var9 = -1;
               }

               var11 = var5.substring(++var9, var9 + var4);
               var10001 = 0;
            }
         }
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      public static 何友树树树树何何树树.友树何何树友友何树何 s(String name) {
         return Enum.valueOf(何友树树树树何何树树.友树何何树友友何树何.class, name);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 216 && var8 != 'k' && var8 != 192 && var8 != 210) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 251) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'B') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 216) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'k') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 192) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 34;
                  case 1 -> 60;
                  case 2 -> 41;
                  case 3 -> 9;
                  case 4 -> 48;
                  case 5 -> 7;
                  case 6 -> 49;
                  case 7 -> 12;
                  case 8 -> 31;
                  case 9 -> 24;
                  case 10 -> 26;
                  case 11 -> 3;
                  case 12 -> 35;
                  case 13 -> 33;
                  case 14 -> 39;
                  case 15 -> 58;
                  case 16 -> 17;
                  case 17 -> 6;
                  case 18 -> 61;
                  case 19 -> 0;
                  case 20 -> 21;
                  case 21 -> 19;
                  case 22 -> 22;
                  case 23 -> 40;
                  case 24 -> 36;
                  case 25 -> 20;
                  case 26 -> 42;
                  case 27 -> 46;
                  case 28 -> 30;
                  case 29 -> 44;
                  case 30 -> 38;
                  case 31 -> 53;
                  case 32 -> 63;
                  case 33 -> 62;
                  case 34 -> 4;
                  case 35 -> 23;
                  case 36 -> 13;
                  case 37 -> 45;
                  case 38 -> 25;
                  case 39 -> 15;
                  case 40 -> 1;
                  case 41 -> 47;
                  case 42 -> 11;
                  case 43 -> 5;
                  case 44 -> 54;
                  case 45 -> 55;
                  case 46 -> 52;
                  case 47 -> 59;
                  case 48 -> 56;
                  case 49 -> 29;
                  case 50 -> 8;
                  case 51 -> 57;
                  case 52 -> 28;
                  case 53 -> 10;
                  case 54 -> 27;
                  case 55 -> 2;
                  case 56 -> 37;
                  case 57 -> 32;
                  case 58 -> 51;
                  case 59 -> 16;
                  case 60 -> 50;
                  case 61 -> 14;
                  case 62 -> 18;
                  default -> 43;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "V0n~K_Yp#uAB\\-(3I_Q+,x\nYX.,3T\\T'%o\n佥叾桏桑栌栵佥你桏桑9可校你伋桑取可佥栤伋";
         b[1] = "\u0005\u000f4=Uy1,;}\u0018r;1> \u001343,3&\u0017\u007fp*:#\u00174./6*\u001ehp伖厜桂桪栋桏伖伂桂桪>厕桒伂伆桪发厕伖框伆@";
         b[2] = "&~\r\u0005B~-q\u001cJ#p&z\u0018\u0010";
         b[3] = "\u001c\u001e:\u000e\foEO>j叾栉口佲伇伷栤位口召ZV\fpD\u001e%\u000f]t";
         b[4] = "q.,2k=(\u007f(V桃厁桔栆厏厕桃桛桔叜Ljk\").33:&";
         b[5] = "$\u001d\ndYo}L\u000e\u0000桱栉叛佱桳參伵位栁栵j<Yp|\u001d\u0015e\bt";
         b[6] = "\u001d`\u0003\u001b:-D1\u0007\u007f又伏佼伌厠伢又桋佼案cC:2E`\u001c\u001ak6";
         b[7] = "~`TDR\u0004'1P 厠厸伟伌号口厠厸厁案4\u001cR\u001b&`KE\u0003\u001f";
         b[8] = "#nw\u001c4mz?sx佘栋佂框叔伥佘栋佂厜\u0017D4r{nh\u001dev";
         b[9] = "\u0011\n?\f\u0018iH[;h只叕叮司厜厫只佋栴司_T\u0018vI\n \rIr";
         b[10] = "6QK\u00195\u000eo\u0000O}栝伬栓厣叨传栝伬栓伽+A5\u0011nQT\u0018d\u0015";
         b[11] = "nzj\u0015iu7+nq伅叉伏桒栓伬伅佗桋桒\nHi4o)k\u000e1vn";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树何何树树$友树何何树友友何树何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      public static 何友树树树树何何树树.友树何何树友友何树何[] K() {
         return (何友树树树树何何树树.友树何何树友友何树何[])何友何树树何何何树树.clone();
      }

      private static String HE_SHU_YOU() {
         return "何炜霖诈骗";
      }
   }

   private record 树友友何友树树友树友(何友树树树树何何树树.友树何何树友友何树何 何友树何何何树何树何, double 友树友何何友友树何何, double 树何树树友树何树树何, boolean 树友何树树树友友友树, Vec3 友友树友友何树友何友) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[11];
      private static final String[] c = new String[11];
      private static String LIU_YA_FENG;

      private 树友友何友树树友树友(何友树树树树何何树树.友树何何树友友何树何 何友树何何何树何树何, double 友树友何何友友树何何, double 树何树树友树何树树何, boolean 树友何树树树友友友树, Vec3 友友树友友何树友何友) {
         this.何友树何何何树何树何 = 何友树何何何树何树何;
         this.友树友何何友友树何何 = 0.0;
         this.树何树树友树何树树何 = 0.0;
         this.树友何树树树友友友树 = false;
         this.友友树友友何树友何友 = 友友树友友何树友何友;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-3310763040054214852L, 1991252587733130209L, MethodHandles.lookup().lookupClass()).a(236432061496483L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public double V() {
         return this.友树友何何友友树何何;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树何何树树$树友友何友树树友树友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 237 && var8 != 216 && var8 != 'F' && var8 != 'M') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'q') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 208) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 237) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 216) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'F') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 40;
                  case 1 -> 10;
                  case 2 -> 28;
                  case 3 -> 15;
                  case 4 -> 33;
                  case 5 -> 42;
                  case 6 -> 60;
                  case 7 -> 51;
                  case 8 -> 30;
                  case 9 -> 4;
                  case 10 -> 17;
                  case 11 -> 32;
                  case 12 -> 23;
                  case 13 -> 52;
                  case 14 -> 62;
                  case 15 -> 5;
                  case 16 -> 47;
                  case 17 -> 46;
                  case 18 -> 39;
                  case 19 -> 25;
                  case 20 -> 56;
                  case 21 -> 49;
                  case 22 -> 18;
                  case 23 -> 0;
                  case 24 -> 14;
                  case 25 -> 59;
                  case 26 -> 22;
                  case 27 -> 58;
                  case 28 -> 1;
                  case 29 -> 53;
                  case 30 -> 24;
                  case 31 -> 41;
                  case 32 -> 36;
                  case 33 -> 6;
                  case 34 -> 37;
                  case 35 -> 20;
                  case 36 -> 8;
                  case 37 -> 19;
                  case 38 -> 50;
                  case 39 -> 57;
                  case 40 -> 12;
                  case 41 -> 35;
                  case 42 -> 45;
                  case 43 -> 38;
                  case 44 -> 7;
                  case 45 -> 2;
                  case 46 -> 27;
                  case 47 -> 3;
                  case 48 -> 61;
                  case 49 -> 43;
                  case 50 -> 48;
                  case 51 -> 29;
                  case 52 -> 9;
                  case 53 -> 55;
                  case 54 -> 13;
                  case 55 -> 44;
                  case 56 -> 54;
                  case 57 -> 21;
                  case 58 -> 34;
                  case 59 -> 63;
                  case 60 -> 26;
                  case 61 -> 16;
                  case 62 -> 31;
                  default -> 11;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "q/5x\u0002\u000b~oxs\b\u0016{2s5\u0000\u000bv4w~C\r\u007f1w5\u001d\bs8~iC伱叙桐栊栊桼伱佇桐栊?桼厯叙伔叐栊桼厯栃厊";
         b[1] = double.class;
         c[1] = "java/lang/Double";
         b[2] = "Hg^x[AG'\u0013sQ\\Bz\u00185YAO|\u001c~\u001aGFy\u001c5DBJp\u0015i\u001a佻叠栘桡栊栥佻佾栘桡?叿栿佾作桡叐叿佻栺作";
         b[3] = boolean.class;
         c[3] = "java/lang/Boolean";
         b[4] = "Wr\u0007:e\u0002Wr\u0010fi\rM9\u0004{z\u0007]9\u0003|q\u0018\u0017A\u0016w;";
         b[5] = ">lO\ng\u001b5c^E\u0006\u0015>hZ\u001f";
         b[6] = "F?v\u0003&&\\`i9桀企栻栚反栠伄桅栻佞\u000e\u0000`5MimD;mD";
         b[7] = "9OvU%d#\u0010io桃叝伀桪栗桶厙叝厞桪\u000eU5wd\u0012`\u0016>b&";
         b[8] = " B58c?:\u001d*\u0002叟桜厇伣伐叁叟桜伙伣M;%,+\u0014.\u007f~t\"";
         b[9] = "nDBOX\u0000t\u001b]u古厹栓去叹伨栾厹佗去:OZGk@X\u000eJF7";
         b[10] = ".}P\u000f`#4\"O5佂厚桓伜併佨栆伄桓伜(\f}2sq\u0015Hvip";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public boolean o() {
         return this.树友何树树树友友友树;
      }

      public 何友树树树树何何树树.友树何何树友友何树何 r() {
         return this.何友树何何何树何树何;
      }

      public Vec3 E() {
         return this.友友树友友何树友何友;
      }

      public double X() {
         return this.树何树树友树何树树何;
      }

      private static String LIU_YA_FENG() {
         return "何大伟230622198107200054";
      }
   }
}
