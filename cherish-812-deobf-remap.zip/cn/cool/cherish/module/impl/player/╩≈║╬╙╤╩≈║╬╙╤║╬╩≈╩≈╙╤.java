package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.alchemy.PotionUtils;

public class 树何友树何友何树树友 extends Module implements 何树友 {
   private final BooleanValue 树何何树树树友友友友;
   private final BooleanValue 友友何何何树何何树友;
   private final NumberValue 友友树树友何友何树友;
   private final NumberValue 树何何友何友友何友友;
   private final BooleanValue 何树友友树友树何树树;
   private final BooleanValue 何友树友树何友树树树;
   private final 树友树友友何何树何何 友何何友树树何何何友;
   private int 何友何树何友友何友树;
   private boolean 何树树何何何何树何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[40];
   private static final String[] k = new String[40];
   private static String LIU_YA_FENG;

   public 树何友树何友何树树友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/树何友树何友何树树友.a J
      // 003: ldc2_w 83852649080537
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 41824307226572
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 22788
      // 014: ldc2_w 239909319027629799
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 24245
      // 021: ldc2_w 4081188806896523614
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w 5498039577386309765
      // 02e: lload 1
      // 02f: invokedynamic Ù (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/BooleanValue
      // 03b: dup
      // 03c: sipush 13589
      // 03f: ldc2_w 1706604461941945079
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 7270
      // 04c: ldc2_w 5517244978430696321
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 0
      // 057: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 05a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 05d: putfield cn/cool/cherish/module/impl/player/树何友树何友何树树友.树何何树树树友友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 060: aload 0
      // 061: new cn/cool/cherish/value/impl/BooleanValue
      // 064: dup
      // 065: sipush 32671
      // 068: ldc2_w 4754290719198525559
      // 06b: lload 1
      // 06c: lxor
      // 06d: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 072: sipush 22742
      // 075: ldc2_w 1137467596665560880
      // 078: lload 1
      // 079: lxor
      // 07a: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07f: bipush 1
      // 080: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 083: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 086: putfield cn/cool/cherish/module/impl/player/树何友树何友何树树友.友友何何何树何何树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 089: aload 0
      // 08a: new cn/cool/cherish/value/impl/NumberValue
      // 08d: dup
      // 08e: sipush 15027
      // 091: ldc2_w 136465314437430614
      // 094: lload 1
      // 095: lxor
      // 096: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09b: sipush 31240
      // 09e: ldc2_w 457186034742345193
      // 0a1: lload 1
      // 0a2: lxor
      // 0a3: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a8: bipush 15
      // 0aa: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ad: bipush 1
      // 0ae: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0b1: bipush 120
      // 0b3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0b6: bipush 1
      // 0b7: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ba: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0bd: putfield cn/cool/cherish/module/impl/player/树何友树何友何树树友.友友树树友何友何树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 0c0: aload 0
      // 0c1: new cn/cool/cherish/value/impl/NumberValue
      // 0c4: dup
      // 0c5: sipush 27486
      // 0c8: ldc2_w 9142307193686535348
      // 0cb: lload 1
      // 0cc: lxor
      // 0cd: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d2: sipush 5276
      // 0d5: ldc2_w 5532031632072561521
      // 0d8: lload 1
      // 0d9: lxor
      // 0da: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0df: sipush 500
      // 0e2: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0e5: bipush 0
      // 0e6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0e9: sipush 2000
      // 0ec: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ef: bipush 50
      // 0f1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0f4: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0f7: putfield cn/cool/cherish/module/impl/player/树何友树何友何树树友.树何何友何友友何友友 Lcn/cool/cherish/value/impl/NumberValue;
      // 0fa: aload 0
      // 0fb: new cn/cool/cherish/value/impl/BooleanValue
      // 0fe: dup
      // 0ff: sipush 6493
      // 102: ldc2_w 5577756720636944057
      // 105: lload 1
      // 106: lxor
      // 107: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 10c: sipush 8095
      // 10f: ldc2_w 8341941949218019455
      // 112: lload 1
      // 113: lxor
      // 114: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 119: bipush 1
      // 11a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 11d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 120: putfield cn/cool/cherish/module/impl/player/树何友树何友何树树友.何树友友树友树何树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 123: aload 0
      // 124: new cn/cool/cherish/value/impl/BooleanValue
      // 127: dup
      // 128: sipush 28905
      // 12b: ldc2_w 3102511032410552069
      // 12e: lload 1
      // 12f: lxor
      // 130: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 135: sipush 9697
      // 138: ldc2_w 8915080363184906760
      // 13b: lload 1
      // 13c: lxor
      // 13d: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 142: bipush 0
      // 143: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 146: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 149: putfield cn/cool/cherish/module/impl/player/树何友树何友何树树友.何友树友树何友树树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 14c: aload 0
      // 14d: new cn/cool/cherish/utils/树友树友友何何树何何
      // 150: dup
      // 151: lload 3
      // 152: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 155: putfield cn/cool/cherish/module/impl/player/树何友树何友何树树友.友何何友树树何何何友 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 158: aload 0
      // 159: bipush -1
      // 15a: ldc2_w 5498569445625527651
      // 15d: lload 1
      // 15e: invokedynamic y (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 163: aload 0
      // 164: bipush 0
      // 165: ldc2_w 5498244516191378241
      // 168: lload 1
      // 169: invokedynamic y (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/树何友树何友何树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16e: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-5085486195187426998L, -4433376179778862383L, MethodHandles.lookup().lookupClass()).a(69207446008412L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 65176918202615L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[14];
      int var7 = 0;
      String var6 = "\u001d\u0010Ú\u0097DÂ\u0086kAÿª³gÝCþ(µ²\u0001\u0080õµ\u0002dÄéü\u0000·Þo\u0018çP9ãßL\u001c\u009cÂõ\r\u0001ûîWÁ8²Ög{_äg\u0018\u0014rE$?f\u0099@²îå\u0005<`\u0016\u0019P´ëæ=z\u001b\u0006\u0018Ncáv\u0090V©¨z\u00adÍ\u009a×e\u0006\u0097{\u001fA\nT\\³ú\u0010¡©5ôÁ\u0094ÿÈ\u0093S~²\tÂô}\u0010\u009e[*YÀ\u0000ÌÛéòAä\u0096xôÀ =ù\u008e(\u000bÈ\u0099Þ\u0089\bð\u008fRq6qM\u0004¾yº¸\u000e\u0089ðÊVRn\u0099\tÔ\u00105\u0094\u0098á\u0084ðw-\u001cß\rJh_.ñ ÆÃ7¼\u0013\u0098\u0084Ú-+ªõ9\u0099VE\u001a?\u0014*\u0017\u0012\u009f\u0087ß#¯þ\u0007ê\u0012½\u0010\u0098\u009a\u0099²s\u000eÐ\u0081÷Ð1S\u009d|\u009b¦ Á\u009cNî©$cJ\u001c=®}?¿Bö/Ïm\u001b9·9b\u0088'\u0096\b\u00adY\u0014\r\u0010¦ÖI}l«Í\u0083B_&ë\u001dÀP'";
      short var8 = 291;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[14];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "È\u0012ï¨'ÖAÑ\u001bûIê\u0089Úèø \u0090ÎY\u009f\u00968}ä\u0092l\u0005\u009ap¨ÇHSjà&O¢_ÃVo\u001c³å\u0004sö";
                  var8 = 49;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   protected void F() {
      long a = 树何友树何友何树树友.a ^ 73508485840736L;
      long ax = a ^ 48869803994330L;
      c<"x">(6193891953390055970L, a);
      if (!this.w(new Object[]{ax})) {
         this.E();
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 24;
               case 1 -> 39;
               case 2 -> 15;
               case 3 -> 17;
               case 4 -> 46;
               case 5 -> 27;
               case 6 -> 23;
               case 7 -> 47;
               case 8 -> 62;
               case 9 -> 25;
               case 10 -> 9;
               case 11 -> 10;
               case 12 -> 50;
               case 13 -> 45;
               case 14 -> 32;
               case 15 -> 0;
               case 16 -> 51;
               case 17 -> 60;
               case 18 -> 29;
               case 19 -> 13;
               case 20 -> 6;
               case 21 -> 53;
               case 22 -> 54;
               case 23 -> 63;
               case 24 -> 21;
               case 25 -> 26;
               case 26 -> 19;
               case 27 -> 22;
               case 28 -> 56;
               case 29 -> 2;
               case 30 -> 49;
               case 31 -> 55;
               case 32 -> 59;
               case 33 -> 30;
               case 34 -> 34;
               case 35 -> 7;
               case 36 -> 35;
               case 37 -> 18;
               case 38 -> 11;
               case 39 -> 4;
               case 40 -> 37;
               case 41 -> 43;
               case 42 -> 57;
               case 43 -> 58;
               case 44 -> 31;
               case 45 -> 5;
               case 46 -> 20;
               case 47 -> 42;
               case 48 -> 12;
               case 49 -> 38;
               case 50 -> 1;
               case 51 -> 8;
               case 52 -> 40;
               case 53 -> 36;
               case 54 -> 16;
               case 55 -> 33;
               case 56 -> 44;
               case 57 -> 52;
               case 58 -> 28;
               case 59 -> 61;
               case 60 -> 3;
               case 61 -> 48;
               case 62 -> 14;
               default -> 41;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2986;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友树何友何树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友树何友何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private int x() {
      long a = 树何友树何友何树树友.a ^ 44011156573607L;
      c<"x">(7436134809942081765L, a);
      if (mc.player == null) {
         return -1;
      } else {
         int i = 0;
         ItemStack stack = mc.player.getInventory().getItem(0);
         if (!stack.isEmpty() && stack.getItem() == c<"Ù">(7439147257079115031L, a) && this.z(stack)) {
            return 0;
         } else {
            i++;
            return -1;
         }
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友树何友何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 197 && var8 != 'y' && var8 != 217 && var8 != 241) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 164) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'x') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 197) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'y') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 217) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "\u0013$o}\u0011y\u001cd\"v\u001bd\u00199)0\u0013y\u0014?-{P\u007f\u001d:-0\u000ez\u00113$lP佃伥厁伔叕桯叝去伟伔";
      j[1] = "/\u000e\u0018YD9\u001b-\u0017\u0019\t2\u00110\u0012D\u0002t\u0019-\u001fB\u0006?Z\u000f\u0014S\u001f6\u0011y";
      j[2] = "\u001a^\u0002%\nz\u0015\u001eO.\u0000g\u0010CDh\bz\u001dE@#K|\u0014@@h\u0015y\u0018II4K栄伬叻栽伓厮佀桨校叧";
      j[3] = "Fu2\nP\u001aMz#E,\u0003B`-\u0006\u001b3Tw!\u001b\n\u001fCz";
      j[4] = "v\u0017G3sTyW\n8yI|\n\u0001~jZy\f\f~uVe\u0015G\u0012sTy\u001c\b>JZy\f\f";
      j[5] = int.class;
      k[5] = "java/lang/Integer";
      j[6] = boolean.class;
      k[6] = "java/lang/Boolean";
      j[7] = "e\u000fs%D\u0001e\u000fdyH\u000e\u007fDpd[\u0004oDbe]\u0001\u007f\u0013){E\tr\u000fu%`\u0006}\u000fi\u007fF\u001ar";
      j[8] = "q|~\u0001.gq|i]\"hk7}@1b{7c[&c1P~J.}";
      j[9] = "{A\u0014\u0002Q\u0012{A\u0003^]\u001da\n\u0017CN\u0017q\n\tXY\u0016;m\u0014IQ";
      j[10] = "\u00007cX\\~\u00007t\u0004Pq\u001a|`\u0019C{\n|^\u0018Er\u001c3t\u0002Xx\u0000\u001av\u0018U";
      j[11] = "Kv\u0007\n.sKv\u0010V\"|Q=\u0010H*\u007fKg]i*t@p\u0001E%n";
      j[12] = "?|\u00123_2?|\u0005oS=%7\u0005q[>?mHpG7%p\u0016qS\"4kHPG7%p6qS\"4k!|_>\u001cv\u0002x";
      j[13] = "\\Y`\u001b\f|S\u0019-\u0010\u0006aVD&V\u0016gV[=V桲变栮叼厅伭伶栂佪佢";
      j[14] = "Dc\u0010+\u0010{K#] \u001afN~Vf\tuKx[f\u0016yWa\u0010\u0006\nyEhL\u001e\u001exRh";
      j[15] = "u\u000fr] \u0003zO?V*\u001e\u007f\u00124\u0010\"\u0003r\u00140[a伹佃厪伉佫厄伹佃桰桍";
      j[16] = "#\u0012~Nb9#\u0012i\u0012n69Y}\u000f}<)Yc\u0014j=c\u0016f\u0003g5 \u000e$0`$$\u0018d\u0013";
      j[17] = "r\u0017[\t\u001bxr\u0017LU\u0017wh\\XH\u0004}x\\FS\u0013|2\u0013CD\u001etq\u000b\u0001w\u0019eu\u001dA";
      j[18] = "\u0001jO<-\u001b\ne^sL\u0015\u0001nZ)";
      j[19] = ">u`eHAbmk'$佽叄栗叏桁佹口栞栗栕X\u001e^m\u007f55\u001fB94";
      j[20] = "^%sQ:R\u0000g*\b\u000bz)\u0016\bfKv&\u001bN\u000fy\u0002\u0000f#Q;[Y";
      j[21] = "Y->Tie\u000b1rX\u000201nz\u0001=d1_s\\2$\u000b2(\bod";
      j[22] = "_$W\"~\u0011\u0003<\\`\u0012桩伻伂栢栆栋厳厥厜司\u001f(\u000e\f.\u0002r)\u0012Xe";
      j[23] = "o#*\u00156q3;!WZ位厕伅桟併厙叓伋厛桟(aj+'vQ`b4;";
      j[24] = "yq\u0010FZ,%i\u001b\u00046厎伝佗县桢栯伐伝佗县{\u0007+/v\u0016\u0002\u0007=2:";
      j[25] = "n[-N\u0019H{Yy\u0015cDS\u001e'LY\u0011S\"w\u001d\rU=\u001f`\u0011\u0005A";
      j[26] = "E,\u0014<`\t\u00194\u001f~\f伵桥桎伥作佑伵桥伊伥\u00010\u0010\u00056\u001d1tW\u0000/";
      j[27] = "\u0017t^e\u001awKlU'v栏佳佒叱伅厵叕佳双叱XGkA0[!\u0012h\u0010m";
      j[28] = "ki\u0017^A\u0013k<T3W)~gVZTJ>c\u00163";
      j[29] = "&\u001c\u0016ki?z\u0004\u001d)\u0005伃栆厤厹桏叆桇佂桾档V? u\u0016C;><!]";
      j[30] = "\u0014\u000fnhxVH\u0017e*\u0014^-N2h*WRNp>i7\u0017D?ktH\u0017\u0006i(\u0014";
      j[31] = "~N+c}*jY!%\u0013伕叔台厄厝叐伕佊株厄^z5{\u000e)<n\"qH";
      j[32] = "\fF\u0001~\u0007\u0018\u0019DU%}\u00141\u0003\u000b\u007fME1?[-\u0013\u0005_\u0002L!\u001b\u0011";
      j[33] = "=Rd\"YZy\u0015cvi\tTPcwRYTlg4P\u00049\u000f%6XV";
      j[34] = "wAqiK\u0006bC%21\nJ\u0004{h\u0001UJ8+:_\u001b$\u0005<6W\u000f";
      j[35] = "%71d\"my/:&N叏叟休伀伄桗佑佁桕厞Ytrv=d4un\"v";
      j[36] = "Y\u0012z_\u0012;L\u0010.\u0004h7dWp^Xidk \f\u0006&\nV7\u0000\u000e2";
      j[37] = "\u0001p.I:g\u0014rz\u0012@k<5$Hp<<\tt\u001a.zR4c\u0016&n";
      j[38] = "\b]=YRBY\u001f0\\#Rc\u0014a\u0016\u001c\u0003c/g]^C\u0004VfUA_";
      j[39] = "I\u0018\b\b\"\u001b\u0015\u0000\u0003JN厹厳桺桽叶伓厹伭桺厧5\u007f\u0007\u001f\\\rL*\u0004N\u0001";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 树何友树何友何树树友.a ^ 4971189927047L;
      long ax = a ^ 116737586720573L;
      long axx = a ^ 97152478078338L;
      c<"x">(-7632939787470818875L, a);
      if (!this.w(new Object[]{ax})) {
         c<"Å">(this, -7632639399030754726L, a).U(axx);
         c<"y">(this, -1, -7633426540842342595L, a);
         c<"y">(this, false, -7632483681830092513L, a);
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean z(ItemStack stack) {
      long a = 树何友树何友何树树友.a ^ 45892547892623L;
      c<"x">(4547074918643833037L, a);
      if (stack.isEmpty()) {
         return false;
      } else if (!c<"Å">(this, 4547016237265509910L, a).getValue()
         || PotionUtils.getPotion(stack) != c<"Ù">(4547272996517802056L, a) && PotionUtils.getPotion(stack) != c<"Ù">(4545261214867133117L, a)) {
         return !c<"Å">(this, 4546822893400559425L, a).getValue()
            ? false
            : PotionUtils.getPotion(stack) == c<"Ù">(4545616963435823329L, a)
               || PotionUtils.getPotion(stack) == c<"Ù">(4545339860875636754L, a)
               || PotionUtils.getPotion(stack) == c<"Ù">(4545809347113411053L, a);
      } else {
         return true;
      }
   }

   private void E() {
      long a = 树何友树何友何树树友.a ^ 88312849620860L;
      long ax = a ^ 69237362576582L;
      long axx = a ^ 66640116278259L;
      c<"x">(3884650863005700670L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"Å">(this, 3885423222246081734L, a) != -1) {
            if (c<"Å">(this, 3885397477676062541L, a).getValue()) {
               PacketUtils.v(new Object[]{axx, new ServerboundSetCarriedItemPacket(c<"Å">(this, 3885423222246081734L, a))});
            }

            c<"y">(mc.player.getInventory(), c<"Å">(this, 3885423222246081734L, a), 3884270769725840823L, a);
            c<"y">(this, -1, 3885423222246081734L, a);
         }

         c<"y">(this, false, 3884544151836484324L, a);
      }
   }

   @EventTarget
   public void L(LivingUpdateEvent event) {
      long a = 树何友树何友何树树友.a ^ 128750321389959L;
      long ax = a ^ 30444360483389L;
      long axx = a ^ 28446600603616L;
      long axxx = a ^ 45906319132802L;
      c<"x">(4256508751037766853L, a);
      if (!this.w(new Object[]{ax})) {
         float currentHealth = mc.player.getHealth();
         boolean needHeal = currentHealth <= c<"Å">(this, 4259544443045072141L, a).getValue().floatValue();
         if (!needHeal) {
            if (c<"Å">(this, 4256896825503837215L, a)) {
               this.E();
            }
         } else if (c<"Å">(this, 4256776290125176666L, a).Y(c<"Å">(this, 4256978314413548103L, a).getValue().longValue(), axx)) {
            int potionSlot = this.x();
            if (potionSlot != -1) {
               if (c<"Å">(this, 4256164007035275837L, a) == -1) {
                  c<"y">(this, c<"Å">(mc.player.getInventory(), 4259445268713116492L, a), 4256164007035275837L, a);
               }

               if (c<"Å">(this, 4256061229006100918L, a).getValue()) {
                  mc.getConnection().send(new ServerboundSetCarriedItemPacket(potionSlot));
               }

               c<"y">(mc.player.getInventory(), potionSlot, 4259445268713116492L, a);
               c<"Å">(mc, 4256000387399150457L, a).useItem(mc.player, c<"Ù">(4255935070278827349L, a));
               if (c<"Å">(this, 4259802042298251988L, a).getValue()
                  && c<"Å">(this, 4256164007035275837L, a) != -1
                  && c<"Å">(this, 4256164007035275837L, a) != potionSlot) {
                  c<"y">(this, true, 4256896825503837215L, a);
               }

               c<"Å">(this, 4256776290125176666L, a).U(axxx);
            }
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "解放村多种2队1144号";
   }
}
