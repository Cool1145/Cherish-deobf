package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.render.CameraEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.CameraType;
import net.minecraft.world.phys.Vec3;

public class 树何友友树友何树友友 extends Module implements 何树友 {
   private final NumberValue 友何何树何何友树友友 = new NumberValue("Speed", "速度", 0.01, 0.35, 10, 0.01);
   private long 友何何友何友何友何何 = 0L;
   private long 树何友何友友何树树友 = 0L;
   private Rotation 友友友友树友树友友树;
   private Vec3 树友树树何何何树友树;
   private Vec3 树树树树何树树何友友;
   private CameraType 树友树友何树树树何树 = CameraType.FIRST_PERSON;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[30];
   private static final String[] k = new String[30];
   private static String HE_JIAN_GUO;

   public 树何友友树友何树友友() {
      super("FreeCam", "灵魂出窍", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-130358400293202175L, 1596116946982297301L, MethodHandles.lookup().lookupClass()).a(238623611581098L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(98453224074581L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "x5\u0089Râ\u001b{8Cþ{*\u001f´æ\n\u0010Ûd\u0010ç\u0083\u0017\u001biô(\u0000ñLµEå";
      byte var8 = 33;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[4];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "¢Úx\u000b\u001c`J\u001f.°î\u009bs\u008b\u008a@\u0091\u008aûBÌ\u0002C|\u0010 E#Ã\u0092|0\u009beï¦Í\u0087F÷µ";
                  var8 = 41;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 22;
               case 1 -> 31;
               case 2 -> 39;
               case 3 -> 24;
               case 4 -> 0;
               case 5 -> 49;
               case 6 -> 19;
               case 7 -> 57;
               case 8 -> 6;
               case 9 -> 43;
               case 10 -> 20;
               case 11 -> 62;
               case 12 -> 38;
               case 13 -> 15;
               case 14 -> 1;
               case 15 -> 7;
               case 16 -> 37;
               case 17 -> 17;
               case 18 -> 3;
               case 19 -> 33;
               case 20 -> 10;
               case 21 -> 55;
               case 22 -> 51;
               case 23 -> 40;
               case 24 -> 48;
               case 25 -> 50;
               case 26 -> 4;
               case 27 -> 53;
               case 28 -> 44;
               case 29 -> 61;
               case 30 -> 54;
               case 31 -> 60;
               case 32 -> 8;
               case 33 -> 42;
               case 34 -> 16;
               case 35 -> 47;
               case 36 -> 41;
               case 37 -> 11;
               case 38 -> 32;
               case 39 -> 58;
               case 40 -> 35;
               case 41 -> 12;
               case 42 -> 21;
               case 43 -> 23;
               case 44 -> 52;
               case 45 -> 28;
               case 46 -> 63;
               case 47 -> 46;
               case 48 -> 2;
               case 49 -> 34;
               case 50 -> 27;
               case 51 -> 14;
               case 52 -> 45;
               case 53 -> 36;
               case 54 -> 13;
               case 55 -> 30;
               case 56 -> 29;
               case 57 -> 25;
               case 58 -> 56;
               case 59 -> 18;
               case 60 -> 9;
               case 61 -> 59;
               case 62 -> 26;
               default -> 5;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友友树友何树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28982;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友友树友何树友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   @EventTarget(4)
   public void x(MoveInputEvent event) {
      树友何何友何树何树友.E();
      if (mc.player != null && mc.level != null) {
         double speed = this.友何何树何何友树友友.getValue().doubleValue();
         float yRot = mc.player.getYRot();
         double yRotRad = Math.toRadians(yRot);
         double forwardX = -Math.sin(yRotRad);
         double forwardZ = Math.cos(yRotRad);
         double strafeX = -Math.cos(yRotRad);
         double strafeZ = -Math.sin(yRotRad);
         Vec3 offset = new Vec3(
            (event.getForwardImpulse() * forwardX - event.getLeftImpulse() * strafeX) * speed,
            event.isKeyJump() != event.isKeyShift() ? (event.isKeyJump() ? speed : -speed) : 0.0,
            (event.getForwardImpulse() * forwardZ - event.getLeftImpulse() * strafeZ) * speed
         );
         this.树树树树何树树何友友 = this.树友树树何何何树友树;
         this.树友树树何何何树友树 = this.树友树树何何何树友树.add(offset);
         this.树何友何友友何树树友 = this.友何何友何友何友何何;
         this.友何何友何友何友何何 = System.nanoTime();
         event.setForwardImpulse(0.0F);
         event.setLeftImpulse(0.0F);
         event.setKeyJump(false);
         event.setKeyShift(false);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友友树友何树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 206 && var8 != 'H' && var8 != 'l' && var8 != 203) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 201) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 254) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 206) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'H') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'l') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   public void h() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && this.友友友友树友树友友树 != null) {
         mc.options.setCameraType(this.树友树友何树树树何树);
         RenderSystem.enableCull();
         mc.player.setYRot(this.友友友友树友树友友树.getYaw());
         mc.player.setXRot(this.友友友友树友树友友树.l(5377274095808L));
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "Mm_\u001aZQB-\u0012\u0011PLGp\u0019WXQJv\u001d\u001c\u001bWCs\u001dWEROz\u0014\u000b\u001b栯佻又厺桨叾佫栿又厺";
      j[1] = "6I))+f6I>u'i,\u0002>k/j6XsD'b=^<S?\u007f=";
      j[2] = long.class;
      k[2] = "java/lang/Long";
      j[3] = "h\u0003(l\u000e\u0001gCeg\u0004\u001cb\u001en!\f\u0001o\u0018jjO桿佞厦反佚桰厥叀伸体";
      j[4] = "|&Ak\u0004+w)P$x2x3^gO\u0002n$Rz^.y)";
      j[5] = "\u0015\u0011\u0007h\n=\u0015\u0011\u00104\u00062\u000fZ\u0004)\u00158\u001fZ\u0003.\u001e'U\"\u0016%T";
      j[6] = double.class;
      k[6] = "java/lang/Double";
      j[7] = "B 2ZeXM`\u007fQoEH=t\u0017gXE;p\\$^L>p\u0017z[@7yK$栦只伛佉史佟栦佴桟受";
      j[8] = "Nq\u001cd\u000b\"zR\u0013$F)pO\u0016yMoxR\u001b\u007fI$;p\u0010nP-p\u0006";
      j[9] = "\u001c!\u0006RBf\u001c!\u0011\u000eNi\u0006j\u0011\u0010Fj\u001c0\\1Fa\u0017'\u0000\u001dI{";
      j[10] = "&[hwH(&[\u007f+D'<\u0010\u007f5L$&J2\u0016U5!Qr*";
      j[11] = "[8d:9\u000eTx)13\u0013Q%\"w \u0000T#/w?\fH:d\u0017#\fZ38\u000f7\rM3";
      j[12] = "][\u0005-\u001c*R\u001bH&\u00167WFC`\u00061WYX`\u001b REN<]\u0017QAJ:\u001a*P";
      j[13] = "6K!l\u001d\u0019=D0#|\u00176O4y";
      j[14] = "2z\u00049~U:%\u0003;\u001f3K\u00068\rH7F\u001d9\u0006Y8A\u000e)\u0002\u001fV6!\u001a %^i&\u0018";
      j[15] = "mmh\b\f*888q\u000b\u00152j{\f\u000fdd$n\u001bb.6+x\u001c\u0013xx>oq";
      j[16] = "vaQ]m\f1#\u0000\u0007\f\u0013\u001djV^3L\u001dZPRi\u000f1!S\u0007b\u0001";
      j[17] = "VQVTAe\u0003\u0004\u0006-栶厙栫厪佦栴栶桃佯桰;\u0014\u0012<J\b\u0001\u001cM;H";
      j[18] = "P\u0011\u0017 U-\u0017SFz42;\u001a\u0010#\u0004e;*\u0016/Q.\u0017Q\u0015zZ ";
      j[19] = ";\"\nkdz\u007f!B5\u0007\b\u0007`\u001cv?uv&Iv;E";
      j[20] = "3\u0005(A\u0001\u001dfPx8厬使伊叾优叻伲叡伊你E\u0002UN0\u0007/IQ\u001d&";
      j[21] = "\u0012:scd\u007fGo#\u001a叉厃厵叁标叙栓厃厵栛\u001e*k*\u0017l!!x#K";
      j[22] = "DA*\u001fV\u0003\u0011\u0014zf校栥根桠会桿校佡口厺GZ\u0003\u0001\u001f\u00186\u001dAPE";
      j[23] = "rF_O1R2EE\u001c][\u001b\u0015\u001f\u001bc\u000b\u001b$\u0019M'\r!DVJ#N";
      j[24] = "8M\u0014wN&0\u0012\u0013u/R@*)SxDL*)Hi\u001c8M\u0014wN&0\u0012\u0013u";
      j[25] = "\u0006*Y?\u000e\tS\u007f\tF桹叵桻栋佩伛伽栯厡栋4z[\u000b]sE=\u0019Z\u0007";
      j[26] = "\u0005J5G\u001d\u000bT\u001bgV~厨栦桭厛佧厽伶栦厷桁:DUR\t;Z\u0015\u0004\u0000\u0018";
      j[27] = "\u0005\u0006kU{\\PS;,栌伾厢佣叅可佈桺桸叽\u0006\u0016/\u000f\u0006\u0004l]+\\\u0010";
      j[28] = "p\\]PJ]7\u001e\f\n+B\u001bWZS\u001b\u0014\u001bg\\_N^7\u001c_\nEP";
      j[29] = "SqZ\u0017_z\u0006$\nn史优佪桐佪伳史桜叴厊7QN!\u000f+S\fK,R";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @EventTarget
   public void t(TickEvent event) {
      树友何何友何树何树友.E();
      if (mc.player != null && mc.level != null) {
         RotationUtils.F(this.友友友友树友树友友树, 3052380832273L);
      }
   }

   @EventTarget
   public void t(CameraEvent event) {
      树友何何友何树何树友.E();
      if (mc.player != null && mc.level != null) {
         mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
         double smoothness = Math.max(Math.min(1.0, (System.nanoTime() - this.友何何友何友何友何何) * 1.0 / Math.max(this.友何何友何友何友何何 - this.树何友何友友何树树友, 1L)), 0.0);
         event.setPosition(
            new Vec3(
               (this.树友树树何何何树友树.x - this.树树树树何树树何友友.x) * smoothness + this.树树树树何树树何友友.x,
               (this.树友树树何何何树友树.y - this.树树树树何树树何友友.y) * smoothness + this.树树树树何树树何友友.y,
               (this.树友树树何何何树友树.z - this.树树树树何树树何友友.z) * smoothness + this.树树树树何树树何友友.z
            )
         );
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   public void M() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.树何友何友友何树树友 = this.友何何友何友何友何何 = System.nanoTime();
         this.树树树树何树树何友友 = this.树友树树何何何树友树 = mc.player.getPosition(1.0F).add(0.0, mc.player.getEyeHeight(), 0.0);
         this.友友友友树友树友友树 = new Rotation(21273681362686L, mc.player.getYRot(), mc.player.getXRot());
         RenderSystem.disableCull();
         this.树友树友何树树树何树 = mc.options.getCameraType();
         mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
      }
   }

   @EventTarget
   public void K(WorldEvent event) {
      this.n();
   }

   private static String HE_DA_WEI() {
      return "何炜霖国企变私企";
   }
}
