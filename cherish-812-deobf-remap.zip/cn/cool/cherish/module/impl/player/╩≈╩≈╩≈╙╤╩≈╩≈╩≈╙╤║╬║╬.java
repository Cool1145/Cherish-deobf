package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.item.SpoofItemUtils;
import cn.cool.cherish.utils.item.友何树树何树何何何友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult.Type;

public class 树树树友树树树友何何 extends Module implements 何树友 {
   private final BooleanValue 何树友何友何何友友友 = new BooleanValue("Spoof Slot (Visual)", "切换欺骗(视觉)", true);
   private boolean 何友何树何树树树友何 = false;
   private int 何何何友何友何何友何 = 0;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[27];
   private static final String[] k = new String[27];
   private static String HE_SHU_YOU;

   public 树树树友树树树友何何() {
      super("AutoTool", "自动工具", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7678572103276319601L, -3834372019269003358L, MethodHandles.lookup().lookupClass()).a(267095315804934L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(39244420118557L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "£nÒA?sÜv¶Z\u001dÐ;\u008e5S\bæ¨B_\u001c\u009e\u0087\u0087§P\u001fv\u0015'Í\u0018ÓrqÕM\"ÆåWÑ\u0080ý\u0091:Y3n\u0001_:F\u009a> ";
      byte var8 = 57;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[4];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "Õ¤\u0019o»(ß0ve\u009dIX×\u0015Â¢\u0003ø2\f\u001e>^\u0093)·n\u008d\u000e\u0089\u0092Þ,+§W`á\u0080(Ú \u0083¯v\r¨J\u009cå\u008f¨qÐ±Á\u000e=\u0086\u0017\u009aÎ³{»Q{Yµ\u0089\u008eÔÐjir\u00adÿÁT";
                  var8 = 81;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 63;
               case 1 -> 44;
               case 2 -> 29;
               case 3 -> 32;
               case 4 -> 27;
               case 5 -> 5;
               case 6 -> 1;
               case 7 -> 33;
               case 8 -> 46;
               case 9 -> 36;
               case 10 -> 58;
               case 11 -> 62;
               case 12 -> 0;
               case 13 -> 55;
               case 14 -> 13;
               case 15 -> 60;
               case 16 -> 57;
               case 17 -> 8;
               case 18 -> 45;
               case 19 -> 22;
               case 20 -> 10;
               case 21 -> 59;
               case 22 -> 3;
               case 23 -> 14;
               case 24 -> 16;
               case 25 -> 51;
               case 26 -> 2;
               case 27 -> 50;
               case 28 -> 43;
               case 29 -> 21;
               case 30 -> 25;
               case 31 -> 4;
               case 32 -> 18;
               case 33 -> 11;
               case 34 -> 49;
               case 35 -> 15;
               case 36 -> 37;
               case 37 -> 7;
               case 38 -> 28;
               case 39 -> 19;
               case 40 -> 9;
               case 41 -> 26;
               case 42 -> 47;
               case 43 -> 40;
               case 44 -> 35;
               case 45 -> 12;
               case 46 -> 56;
               case 47 -> 30;
               case 48 -> 53;
               case 49 -> 31;
               case 50 -> 52;
               case 51 -> 48;
               case 52 -> 38;
               case 53 -> 34;
               case 54 -> 42;
               case 55 -> 23;
               case 56 -> 24;
               case 57 -> 6;
               case 58 -> 54;
               case 59 -> 20;
               case 60 -> 17;
               case 61 -> 61;
               case 62 -> 39;
               default -> 41;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 31679;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树友树树树友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[iB\u0004\u0081ÙÈ\u0093-kÉÝ\u0098\u0098û[¹, \u0017âÏ)`¦´\u007fg")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树友树树树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void s() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.何树友何友何何友友友.getValue()) {
            if (!SpoofItemUtils.e(96871185550697L)) {
               return;
            }

            mc.player.getInventory().selected = this.何何何友何友何何友何;
            SpoofItemUtils.z(29996098265021L);
         }

         mc.player.getInventory().selected = this.何何何友何友何何友何;
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树友树树树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'c' && var8 != 'D' && var8 != 238 && var8 != 245) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'o') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 235) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'c') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'D') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 238) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "d|\u0005\u0012\rQk<H\u0019\u0007LnaC_\u000fQcgG\u0014LWjbG_\u0012RfkN\u0003L栯栖栃叠桠桳栯双佇佾";
      j[1] = int.class;
      k[1] = "java/lang/Integer";
      j[2] = "/sH\u0010\u000ea/s_L\u0002n58KQ\u0011d%8YP\u0017a5o\u0012N\u000fi8sN\u0010*f7sRJ\fz8";
      j[3] = "\u001b\u001b-V<^\u0014[`]6C\u0011\u0006k\u001b>^\u001c\u0000oP}X\u0015\u0005o\u001b#]\u0019\ffG}栠厳传佖叾伆栠伭桤又";
      j[4] = "\"\t1\t\u0016R\u0016*>I[Y\u001c7;\u0014P\u001f\u0014*6\u0012TTW\b=\u0003M]\u001c~";
      j[5] = "#PT =.#PC|1!9\u001bCb9\"#A\u000eC9)(VRo63";
      j[6] = "{\u0010a\u000b+\"{\u0010vW'-a[bJ4'q[eM?8;=|Q\u0014.f\u0000yQ";
      j[7] = "DySF\u0013\u001eOvB\to\u0007@lLJX7V{@WI\u001bAv";
      j[8] = "2\u007fk/du2\u007f|shz(4hn{p84oiporRvu[y/osu-H%jz";
      j[9] = "\tP]lC[\tPJ0OT\u0013\u001bJ.GW\tA\u0007\r^F\u000eZG1";
      j[10] = ")\rpa\u00104)\rg=\u001c;3Fg#\u00148)\u001c*\u0004\u0018$\n\tt?\u00143 ";
      j[11] = "\n8sbn\u0019\u0005x>id\u0004\u0000%5/w\u0017\u0005#8/h\u001b\u0019:sCn\u0019\u00053<oW\u0017\u0005#8";
      j[12] = boolean.class;
      k[12] = "java/lang/Boolean";
      j[13] = "1jN\r\u0004c>*\u0003\u0006\u000e~;w\b@\u0006c6q\f\u000bE栝伇叏厫伻桺叇厙佑伵";
      j[14] = "HGrW\fZCHc\u0018mTHCgB";
      j[15] = "\u0014:(#?R\u0018&h+\\em\u0000Z\f\\\u0012T~},!\u001eH>u";
      j[16] = "J6`\u0003\fO\b<1E1\u001c#wdC\u0000O#FaDC\f\u001f49\u0014UO";
      j[17] = "16#O\u001ams<r\t'>Xw'\u000f\u0016nXF\"\bU.d4zXCm";
      j[18] = "\f~c(jM\r>`,P\u001fgw%ynOgF\"1n\t\r{`;?O";
      j[19] = "T3{\u0015\u0003rQt|(佣佞伴反佀叫佣佞厪体\u001dTBs\b4xEAy";
      j[20] = "s2Gdi\u0018vu@Y伉桰厍佒叢伄伉厪厍双!f.\u0005w1K#n\u000b7";
      j[21] = "\tp11FA]t>7?Hg,`e\u0000\u0019g\u0017!(OG\nr0+E";
      j[22] = "96\t\u001d\t\u001e=<T\u0007d4\u00037\u001a\u001c\u0007\u0010r`U\t\u0004y";
      j[23] = "\u0004Uw\n+e\u000e\u0002}D\u0012叜栬校变佫发佂栬叻栂6#rY\u0004\"L)%SJ";
      j[24] = "]Uh5\r*\\\u0015k17x6\\.d\b)6m+0K+_\u0013y'Jo";
      j[25] = "x\r(V\u0003t}J/k佣叆优栩伓桲栧栜历佭N[L:/\np\u0001Pb9";
      j[26] = "\rZ\u000f0p_\b\u001d\b\r$.\r\\\u0005j0JT\t\u000e1M\u0013\u000b\u000b\u000ep)J^\u0000U\r";
   }

   public void p() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         int bestSlot = -1;
         if (mc.hitResult != null && !mc.level.isEmptyBlock(((BlockHitResult)mc.hitResult).getBlockPos())) {
            BlockState blockState = mc.level.getBlockState(((BlockHitResult)mc.hitResult).getBlockPos());
            int i = 0;
            ItemStack item = mc.player.getInventory().getItem(0);
            if (!item.isEmpty() && !友何树树何树何何何友.T(item, 12770860351312L)) {
               float speed = item.getDestroySpeed(blockState);
               if (speed > 1.0F) {
                  bestSlot = 0;
               }
            }

            i++;
            if (bestSlot != -1) {
               mc.player.getInventory().selected = bestSlot;
            }
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void r(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (!mc.options.keyUse.isDown() && mc.options.keyAttack.isDown() && mc.hitResult != null && mc.hitResult.getType() == Type.BLOCK) {
            if (!this.何友何树何树树树友何) {
               this.何何何友何友何何友何 = mc.player.getInventory().selected;
               if (this.何树友何友何何友友友.getValue() && !SpoofItemUtils.e(96871185550697L)) {
                  SpoofItemUtils.m(this.何何何友何友何何友何, 18080999206181L);
               }
            }

            this.p();
            this.何友何树何树树树友何 = true;
         }

         if (this.何友何树何树树树友何) {
            this.s();
            this.何友何树何树树树友何 = false;
         }

         this.何何何友何友何何友何 = mc.player.getInventory().selected;
      }
   }

   @Override
   public void M() {
      this.何何何友何友何何友何 = 0;
   }

   private static String HE_DA_WEI() {
      return "何炜霖国企上班";
   }
}
