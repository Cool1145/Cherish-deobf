package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.树树何友树何友友何友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class 何树树何何树何何友树 extends Module implements 何树友 {
   private final ModeValue 友何树友何友友友何友 = new ModeValue("Attack Sound Effect", "攻击音效", new String[]{"None", "Undertale"}, "Undertale");
   private final ModeValue 何友树友友树何树何友 = new ModeValue("Kill Sound Effect", "击杀音效", new String[]{"None", "MiniWorld"}, "None");
   private final ModeValue 友何何树树何何友何树 = new ModeValue("Hurt Sound Effect", "受伤音效", new String[]{"None", "Undertale"}, "Undertale");
   private final ModeValue 何何何树树何树树树友 = new ModeValue("Win Sound Effect", "胜利音效", new String[]{"None", "Undertale"}, "Undertale");
   private final ModeValue 何友何何友树友何何何 = new ModeValue("Combat Start Sound Effect", "战斗开始音效", new String[]{"None", "Undertale", "MiniWorld"}, "Undertale");
   private final 何何何友友何树何何何 友树友何树何何树树树 = new 何何何友友何树何何何("If combat text contains", "如果战斗文本包含", "现在开始").A(() -> {
      树友何何友何树何树友.E();
      return !this.何友何何友树友何何何.K("");
   });
   private final 何何何友友何树何何何 友友友树友何友何友何 = new 何何何友友何树何何何("If win text contains", "如果胜利文本包含", "胜利,赢,Win").A(() -> {
      树友何何友何树何树友.E();
      return !this.何何何树树何树树树友.K("None");
   });
   private final BooleanValue 友友友树友树友树树何 = new BooleanValue("LagBack Check", "回弹检测", true);
   private boolean 何树树友树树树何何树 = false;
   private int 树树友友何树树友何友 = 0;
   private static final float 友友树树树何树树何何 = 0.8F;
   private static final float 何何何何何何友树友友 = 0.1F;
   private static final double 何树友树树何树树何何 = 16.0;
   private String 树何友树树树树友友树 = null;
   何友友何树何树何树友 何友何友友树树友树友 = new 何友友何树何树何树友(51913986529303L);
   何友友何树何树何树友 何何树友何何树何树友 = new 何友友何树何树何树友(51913986529303L);
   private Player 何何树树树树树友树友 = null;
   private int 友树树何友何树友何何 = 0;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[40];
   private static final String[] n = new String[40];
   private static int _何树友为什么濒天了 _;

   public 何树树何何树何何友树() {
      super("PlayerSoundEffect", "玩家音效", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8537727593540773021L, 7472827379530182275L, MethodHandles.lookup().lookupClass()).a(248025249624520L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(46093231610799L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[40];
      int var18 = 0;
      String var17 = "\u0086\\Þ\u008e\u008d\u001aG\u00adÛêÂ\u0006\u000bWåc\u0012*ÚtÛ\u008bô¬\u0081°\u0094l\u0003\u000b7\u0005Ç,P<{g×u\u009f\u0086¤N[ü1ë S\u0084\u0005\u001bêÚÒ\u009eÏ¸ \u0011k\b(ª\\YÅ(\u0081ú³\u0002ï]\np\u0080&\u00971(v«\u0007È\u008e\u0088é\u0083fAøÖ\u0094\u0013IúNV\u009c¥]¡8X¯\u0012\\è/²gÅ\u009dou\u0093snÔY8ÂÎ$¥\fÂ \u008eåñe\u0098\u000fïÓ\u008a\u0090õêW&\u000e¸Tä\u0003Ô\nâ1ÝÅ_ø¯\u00194\u009e¤\u0093ÒÞéZÏwR]ühÁ¥Ã\u0004É\u0089\u00183F\u0003Ãw]õS*w:ôx?ad?ü\u0094ØÁüö\u0083\u0010Þ~\u0099#E»æ\r^Âm¶\u0018\u0003Cð\u0010Î@´Cô£ç\u001f/À\u0006h&\u0005ÄU +Vª\u008cÆé\u008dOó&ezyë:Ï1/«¢ñ\u001dÝ\u0083ôvìê6\u008c\\^ \u0091\u009fd¹óK¸£ù»\u0017+5¸Õ\u0002A\u008fZü:U\u0092£Y\u000b\u0085Ù\u0099\u0006\u0095¥(pæ¹\u008f\u0095ýÌ.zÉ\u0003\u001bZÀÊYp|Ãd\u0096²\u0018ã\"°\fß\u0013\u000e:\u001c¼h\u001a-\u009cÿ¤i\u0010G>øîÏ\nñ'¬ÕúR,z\u008dÍ\u0010@ç3\u0003þo\u0094õ\u008fá|&5Êó\u00140db\u008ek\u0097~F)×TRø\u0087¢I9gx9F\u0013\u0000|\u0084bTàÑ~h=hT§\u008fI0T[þ6SgZØ\u001e\u008c\u0017 =ð£Âh\u001bÌ\tÕ=}\tµ¢rù1aÌôÉ.\u0085M\u0096ô¥\\1\"\"\u0003(N½Fa÷\u0018Íøê\u008a\u009e\"Õ]\"cúókE\u000b\n´\u0080-jgãòõ@eó\u0084n\u001f\u0087TI\u0081\u0018D\u0010ã\u0087\u001eåÁ\u0090j\u0001\u001e\u001a»\n»;SÂqÇépÞÛ(9eñp\u001e\u0005\u0098^âÔ\u0012(\u0083K\u0091*Þ·µíiÂ«K\u001b\u0005®ÄDGÓ\u0086ôµ½¶)\u00ad\u0006Ô\u0018ù°~\u008d\u000bÞ²\u009eI\u0012\u0006/(¼¢$B¥ \\1êÉÛ(\u007f\u007fB¶!àjiP\u0092¿fk\u001aiZÂ!Î\u0093ªÑ¶nL\u0095KñºqrPtÅè\\Eq\u00058 +W¨;ÐþîÓ<áéYåµcá\u0099$±®èN&õtÇy½VÝð\u0086 þ9í¹\u0000ä\u00161<»MÌ\u00029:\u008bÄª\u0002:õ.8\u0098ß8ôz\r\fÀÿ(S\u0087\u008f5°_\rF\u0002Tôf\u009cFP+(©\u001dm\u0016¦Ó\u0016\u0016q´/$\u0016VÆç¥\u007f×\u0011\r\u0099²(¹¬%úî\u0092¦\u000f\u0015üÈpüðI>ÃîAjX\u001b\u0000Î¿\u0001=WÎ\u0001«ÎáÞ]Ãð\u0016äV\u0010ÍÂhä\u0097\\W@.£1\u00008?oé ÍÒÆ\u009f¤\u009b±Ô\u001bDa-V¼}\u0004\\l§«7\fæèpÔ;øeô%}\u0018:ß\u0085æít5¿¿éíI\u001cL\u009c\u0017\bÞS\u009a\u0089ÿ\u0013²\u0018XêÚ\u0090(z·\f»n\u001a-\u0098«Üû\u0080\u0083\u0014ÏíIÇQ\u0010<\u0018mó2X-låk¼ß\u0014\\oø(Âmr\u0017-fÁ\u009f`\u008fm¥\u00153EW\u0004íú\u000b\u0092¬v^\u00ad\u0092å>úG\u0019\u0085CEE½.¦\u0004À \u001fÖ¢¾cí,\u001e#ñ§µ´\"¸\u009bI¬«é\u008bÀð³\u009a\u00003ø\u0007ûÜ\u0099(àu\u000bsæðL\u000eø\u0014HÒÇ1-\u001eÚ}Ä²\u001dÒú\u0086û\u0016ÿ\u000b|z1\f+µ¬\u0086\u001e\u0004ä\u008e(\u0086$8P§Ì\u0084T\u0085BJ\u0092V#\u0086dóÿ\u009bU\u0080Û-\u009a\"aÈ\u0005á¢\u0006.\u000b\"M\u009e³\f\r\u0089\u0018Û\u008a²\u001eQByåÎG\u0013Ô\u0016!Nß,ª\nwkÚw\n\u0010Ò¶M´õ\u0013ííç\u00adÐ\u0088w¨´1\u0010j \u0088ÛNÊQ6õ1<â\u00ad\u00adsõ Ç\u000b\u009d\u0015:\u0006P\u0091¦8'/wqBZÓC)$°}\u001cGúb\u001dë\u0084:?38\bÙç±÷q°\u0092\u0015\u0006Jy\u008e±à¸|\u0099¢.b\u000f\u0086\u0005níI\u0010f\u0012\u0004qö\b´Mûç\u0091íL¦\u008aG\rER!&i|Â6Tß\u00190D\u009e\u0012»uf-\b\u0092ÁfP_¯\thÔ©¼ìIK\u00adÓ\u009d\u0088Ò.ÚÙ\u0000\u0003\u001dÑh\u008b®Å¦LAm¹Â\u008dÉ`~";
      short var19 = 1253;
      char var16 = '0';
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[40];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(46093231610799L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "UôF\u0004´B\u0094\u0007Ü8'\u0011SÓÕ_".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "=Þ\u009eÚ'9¥\u0007q\u008f\u008a\u0007>È\t¢\\Oöð3D\u0091-\u0007\u0012¬õTöø\u000b\u0098Ä\u0011ª\u009a¸°¢(\u0081C\"\u008b1G2\u0092\u0004wfÁ]\bÓ¯|É\u0016\u009a\u0004Õ$rêÑt2m&\u0004\u0012Ul\u00046-+B<";
                  var19 = 81;
                  var16 = '(';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private void C() {
      树友何何友何树何树友.E();
      String baseDir = Cherish.getResourcesManager().resources.getAbsolutePath() + "\\sound\\";
      String mode = this.何友树友友树何树何友.getValue();
      byte var9 = -1;
      switch (mode.hashCode()) {
         case -1492564645:
            if (mode.equals("MiniWorld")) {
               var9 = 0;
            }
         default:
            switch (var9) {
               case 0:
                  this.友树树何友何树友何何++;
                  int soundIndex = (this.友树树何友何树友何何 - 1) % 5 + 1;
                  树树何友树何友友何友.d(baseDir + "mini\\" + soundIndex + "Q.wav", 44432082049881L, 0.8F);
                  if (this.友树树何友何树友何何 % 5 == 0) {
                  }
            }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 40;
               case 1 -> 2;
               case 2 -> 18;
               case 3 -> 13;
               case 4 -> 6;
               case 5 -> 47;
               case 6 -> 42;
               case 7 -> 49;
               case 8 -> 59;
               case 9 -> 16;
               case 10 -> 39;
               case 11 -> 25;
               case 12 -> 41;
               case 13 -> 57;
               case 14 -> 24;
               case 15 -> 34;
               case 16 -> 53;
               case 17 -> 29;
               case 18 -> 46;
               case 19 -> 44;
               case 20 -> 26;
               case 21 -> 9;
               case 22 -> 51;
               case 23 -> 56;
               case 24 -> 31;
               case 25 -> 12;
               case 26 -> 7;
               case 27 -> 43;
               case 28 -> 20;
               case 29 -> 61;
               case 30 -> 22;
               case 31 -> 15;
               case 32 -> 62;
               case 33 -> 37;
               case 34 -> 27;
               case 35 -> 63;
               case 36 -> 14;
               case 37 -> 17;
               case 38 -> 5;
               case 39 -> 10;
               case 40 -> 48;
               case 41 -> 4;
               case 42 -> 58;
               case 43 -> 55;
               case 44 -> 28;
               case 45 -> 30;
               case 46 -> 3;
               case 47 -> 50;
               case 48 -> 1;
               case 49 -> 45;
               case 50 -> 33;
               case 51 -> 54;
               case 52 -> 52;
               case 53 -> 35;
               case 54 -> 32;
               case 55 -> 38;
               case 56 -> 8;
               case 57 -> 60;
               case 58 -> 11;
               case 59 -> 36;
               case 60 -> 21;
               case 61 -> 23;
               case 62 -> 19;
               default -> 0;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25216;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何树树何何树何何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[¸õ·}\u0013ÃõË^À³ÀÕ\u0081\u0098\u0000fÛ³\u0089\u0092\u0099É5, ^±Oð\u0010æÑVgña\u0096I\u009a=¿, \u0093gë¼\u009b}½\u000bûù\u001fíð°\u0080lE\u000b\u0087\u0080+ÔEÚ, EF\u009f;Z\u0094ùvÓ\u0095¼Ä\u0081sëx¢\u007føÇ\u0095ù¦¸gz¾Ô\u001dh+., 3` gz\u0018Y\"\u0086<\u009ftåÌSW, ßnöxCa(e, Îµ+ëu·è³, e\u009a½3\u0085cÐGX}\u0096çN\u0083¿\u0099, ´ÿ¼¯\u0000b£ÑDmY\u0084\u0006â¿\u000b, \u0089y\u0089¸ÊÊ\u0011½D%\u001a\u0088\u000e7 0·¾WEX@ñ\u0011, èì\u008c\u0007ÞDýÌ, ¨ÿ\u0003B¯¼Å÷, º`1W5\u001e4ìÊG6wIÅÔ\u00105Ü\u008c Bgf8\u0086\u0098qv\tìaå, \\\u009c\u0089É\tâ\"û\u0082\u008fø© #I\u0083, ®&\u0096")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树树何何树何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private float s(double distance) {
      树友何何友何树何树友.E();
      return distance >= 16.0 ? 0.1F : (float)(0.8F - distance / 16.0 * 0.7F);
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 219 && var8 != 244 && var8 != 'D' && var8 != 'F') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 218) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 243) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 219) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'D') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 28597;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何树树何何树何何友树", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树树何何树何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   public void h() {
      树友何何友何树何树友.E();
      树树何友树何友友何友.Y("combat", 116666512799915L);
      if (this.树何友树树树树友友树 != null) {
         树树何友树何友友何友.N(this.树何友树树树树友友树, 131645432355300L);
         this.树何友树树树树友友树 = null;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树树何何树何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      m[0] = "/sN\fTT 3\u0003\u0007^I%n\bAVT(h\f\n\u0015R!m\fAKW-d\u0005\u001d\u0015佮桝栌伵伺株佮伙取桱";
      m[1] = "A\u007fNXc\u0011A\u007fY\u0004o\u001e[4M\u0019|\u0014K4_\u0018z\u0011[c\u0014\u0006b\u0019V\u007fHX^\u0014Nc_\u0004";
      m[2] = int.class;
      n[2] = "java/lang/Integer";
      m[3] = "U\u000b\u0003\u0012i&ZKN\u0019c;_\u0016E_k&R\u0010A\u0014( [\u0015A_v%W\u001cH\u0003(桘叽估佸厺体桘佣桴另";
      m[4] = "e4\u0002z\u0018}Q\u0017\r:Uv[\n\bg^0S\u0017\u0005aZ{\u00105\u000epCr[C";
      m[5] = "J\u001au3D A\u0015d|89N\u000fj?\u000f\tX\u0018f\"\u001e%O\u0015";
      m[6] = "e64zKWn9%56O}>,|";
      m[7] = "kxEkL\u0004d8\b`F\u0019ae\u0003&U\ndc\u000e&J\u0006xzEEL\u000fm@\ndV\u000e";
      m[8] = "\u0007d\u0002FE{\b$OMOf\ryD\u000b_`\rf_\u000bXq\u0017eYWIq\u0017$~@Y{\u0011xO@YY\u0005dMBOf";
      m[9] = "D,F dzAcv(&v";
      m[10] = boolean.class;
      n[10] = "java/lang/Boolean";
      m[11] = "\u0012Wy_\u0005E\u0012Wn\u0003\tJ\b\u001cn\u001d\u0001I\u0012F#\u0001\u0004M\u0005W\u007f_$C\u001fSa!\u0004M\u0005W\u007f";
      m[12] = "8\u0011$\u0006Q47Qi\r[)2\fbKK/2\u0013yK佫厐厐伪栛估栯伎桊厴";
      m[13] = "\rbR\u000eIe\u0002\"\u001f\u0005Cx\u0007\u007f\u0014CPk\u0002y\u0019COg\u001e`R伸佳佟厥叇伩桼佳佟伻";
      m[14] = "g-\u0006\u0015 'g-\u0011I,(}f1S,:O'\u0000V,:}!\u001c\\";
      m[15] = "1vFO.\u000e>6\u000bD$\u0013;k\u0000\u00027\u0000>m\r\u0002(\f\"tFn.\u000e>}\tB\u0017\u0000>m\r";
      m[16] = "Hd\u00123q\u000bG$_8{\u0016ByT~s\u000bO\u007fP50桵佾叁号伅栏厯叠佟佩";
      m[17] = "@\u0019\u0013$\"|K\u0016\u0002kCr@\u001d\u00061";
      m[18] = "\u0013\u000fkhY3V\ty\n佶厐栰厭叆栓佶桊佴厭\u00056Zc\u0016\u000f`x[=V";
      m[19] = "L&m\u0010H\u0018\t \u007fr叹桡厵会栚伯佧桡桯桞\u0003CZ\u0001J\"d\u0015\u0004\u0005\n";
      m[20] = "}I\u0005,\u001b\\8O\u0017N桰栥厄叫伶桗桰叿会叫kw\r\r{HW7\u0006\u0005!";
      m[21] = ",>42\u0016\u0003i8&P厧伾佋框桃伍伹厠佋框Zl\u0015S)>?\"\u0014\ri";
      m[22] = "\u0015w[P: PqI2桑伝召栏栬栫桑厃召栏5\u000e)?@s\fIv?E";
      m[23] = "fM*\u000es\u0005<[7E\u0013\u000e6N)\ti\u001f6NNJp\u00120Y?It\u0015`";
      m[24] = "']Y+Veb[KI佹栜栄叿栮桐栽佘佀栥7vJcmS\\qJ;v";
      m[25] = "Tfp8..\u0011`bZ原伓桷叄佃厙原厍伳叄\u001ef-~Qf{(, \u0011";
      m[26] = "$>\u0004\\a(\"<V\u0002[\u001b\u001eg\f\u001a5=sb_\u0004fV";
      m[27] = "Lk1\u0018Y@\u0011b;\u001d)&0W[VY\u0016\u0002kg\u000bP\u001c\u0007";
      m[28] = "c\u001exg=L8\u0011?x\u0001B\u000bT8,8\u0012\u000bn9y0\u0010<Ryr8J";
      m[29] = "r-\u001a%\u000bV7+\bG伤佫伕桕桭会桠栯桑厏t{\b\u0006w-\u00115\tX7";
      m[30] = "U\u0003\u0013\u00031:\u0010\u0005\u0001a伞厙伲伿厾桸厀伇伲伿}]2jP\u0003\u0018\u001334\u0010";
      m[31] = "Q\u001fBlW(\u0014\u0019P\u000eLHP\u0002]lUy\u0005C\u00125%s\u0017\u000fN~\u0014&V@\u0017\u000e";
      m[32] = "f@\u000fAL$#F\u001d#佣伙桅核桸栺栧厇桅叢a\u001aT!`\u001f\rDW:=";
      m[33] = "Qh\u0018\u0002C\f\u0014n\n`佬伱桲及伫伽栨伱桲及vPO\u0011Ts\rQV\u0000S";
      m[34] = "T\u0007v\u000bi \u0011\u0001di变桙桷伻叛伴栂厃伳伻\u0018P\u007fqR\u0006$\u0010ty\b";
      m[35] = "\u0002I?(?\u0004GO-J厎厧叻栱厒众厎伹叻併Q{-\u001d\u0004M6-s\u0019D";
      m[36] = "\b;\u00065u\fM=\u0014W佚厯佯厙厫桎栞厯栫厙hgy\u0011\r \u0013f`\u0000\n";
      m[37] = "q&o\u0001R+*pq\u0007(厍栂桘又佣叫伓栂厂栒>B)\u007f~q[\u0019\u007fax";
      m[38] = "y_:.7\u0006<Y(L历厥厀栧厗桕历桿桚佣T%8\u0018;\u0004;|?\u001f ";
      m[39] = "fh?t\u0010\u0017=gxk,\u0019\u000e!v1\u001dH\u000e\u0018~j\u001dK9$>a\u0015\u0011";
   }

   @EventTarget
   public void k(PacketEvent event) {
      d<"ó">(-4846789616725412441L, 52969251585210L);
      if (!this.Q(new Object[]{52406761729175L})) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundPlayerPositionPacket
            && d<"Û">(mc.player, -4849286080509112183L, 52969251585210L) > 200
            && d<"Û">(this, -4849330435436132951L, 52969251585210L).getValue()) {
            String baseDir = d<"Û">(Cherish.getResourcesManager(), -4845886210871732077L, 52969251585210L).getAbsolutePath() + "";
            树树何友树何友友何友.d(baseDir + "SFX.wav", 44432082049881L, 0.8F);
         }

         if (packet instanceof ServerboundInteractPacket wrapper
            && WrapperUtils.Y(114813987783679L, wrapper)
            && d<"Û">(this, -4846953120521627763L, 52969251585210L)) {
            Entity targetEntity = mc.level.getEntity(WrapperUtils.w(72331927741833L, wrapper));
            if (targetEntity != null && !((LivingEntity)targetEntity).isDeadOrDying() && targetEntity.isAlive()) {
               d<"ô">(this, false, -4846953120521627763L, 52969251585210L);
               double distance = mc.player.distanceTo(targetEntity);
               float volume = this.s(distance);
               String baseDir = d<"Û">(Cherish.getResourcesManager(), -4845886210871732077L, 52969251585210L).getAbsolutePath() + "\\sound\\other\\";
               String mode = d<"Û">(this, -4846885482600443275L, 52969251585210L).getValue();
               if (d<"Û">(this, -4849494812888009136L, 52969251585210L).c(c<"n">(5968, 9151554411014879460L), 41972279541307L)) {
                  byte var34 = -1;
                  switch (mode.hashCode()) {
                     case 977234782:
                        if (mode.equals("Undertale")) {
                           var34 = 0;
                        }
                     default:
                        switch (var34) {
                           case 0:
                              树树何友树何友友何友.d(baseDir + "undertale_attack.wav", 44432082049881L, volume);
                           default:
                              d<"Û">(this, -4849494812888009136L, 52969251585210L).D(11747522392279L);
                        }
                  }
               }
            }
         }

         if (packet instanceof ClientboundSetTitleTextPacket wrapperx && !d<"Û">(this, -4846581989044391082L, 52969251585210L).K("None")) {
            Component titleComponent = wrapperx.getText();
            String titleText = Component.literal(titleComponent.getString()).getString();
            String baseDir = d<"Û">(Cherish.getResourcesManager(), -4845886210871732077L, 52969251585210L).getAbsolutePath() + "\\sound\\other\\";
            String mode = d<"Û">(this, -4846581989044391082L, 52969251585210L).getValue();
            String[] keywords = d<"Û">(this, -4849577139658081262L, 52969251585210L).getValue().split(",");
            boolean containsWinKeyword = false;
            int var51 = keywords.length;
            int var35 = 0;
            if (0 < var51) {
               String keyword = keywords[0];
               if (titleText.contains(keyword.trim())) {
                  containsWinKeyword = true;
               }

               var35++;
            }

            if (containsWinKeyword) {
               树树何友树何友友何友.Y("combat", 116666512799915L);
               if (d<"Û">(this, -4845957856847821892L, 52969251585210L) != null) {
                  树树何友树何友友何友.N(d<"Û">(this, -4845957856847821892L, 52969251585210L), 131645432355300L);
                  d<"ô">(this, null, -4845957856847821892L, 52969251585210L);
               }

               byte var52 = -1;
               switch (mode.hashCode()) {
                  case 977234782:
                     if (mode.equals("Undertale")) {
                        var52 = 0;
                     }
                  default:
                     switch (var52) {
                        case 0:
                           树树何友树何友友何友.d(baseDir + "undertale_win.wav", 44432082049881L, 0.8F);
                     }
               }
            }
         }

         if (packet instanceof ClientboundSystemChatPacket wrapperx && !d<"Û">(this, -4846515053736914985L, 52969251585210L).K("None")) {
            Component messageComponent = wrapperx.content();
            String messageText = Component.literal(messageComponent.getString()).getString();
            String baseDirx = d<"Û">(Cherish.getResourcesManager(), -4845886210871732077L, 52969251585210L).getAbsolutePath() + "\\sound\\other\\";
            String modex = d<"Û">(this, -4846515053736914985L, 52969251585210L).getValue();
            String[] keywordsx = d<"Û">(this, -4846187947499253858L, 52969251585210L).getValue().split(",");
            boolean containsWinKeywordx = false;
            int var53 = keywordsx.length;
            int var56 = 0;
            if (0 < var53) {
               String keyword = keywordsx[0];
               if (messageText.contains(keyword.trim())) {
                  containsWinKeywordx = true;
               }

               var56++;
            }

            if (containsWinKeywordx) {
               byte var54 = -1;
               switch (modex.hashCode()) {
                  case 977234782:
                     if (!modex.equals("Undertale")) {
                        break;
                     }

                     var54 = 0;
                  case -1492564645:
                     if (modex.equals("MiniWorld")) {
                        var54 = 1;
                     }
               }

               switch (var54) {
                  case 0:
                     d<"ô">(this, baseDirx + "undertale_combat.wav", -4845957856847821892L, 52969251585210L);
                     ClientUtils.P(
                        125527250587045L,
                        d<"D">(-4846751293613255150L, 52969251585210L) + "[" + WrapperUtils.f(111441258359257L) + "] LOVE 9999999 *⭐" + ChatFormatting.RESET
                     );
                     树树何友树何友友何友.d(d<"Û">(this, -4845957856847821892L, 52969251585210L), 44432082049881L, 0.8F);
                  case 1:
                     d<"ô">(this, baseDirx + "miniworld_combat.wav", -4845957856847821892L, 52969251585210L);
                     树树何友树何友友何友.d(d<"Û">(this, -4845957856847821892L, 52969251585210L), 44432082049881L, 0.8F);
               }
            }
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void r(AttackEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.何树树友树树树何何树 = true;
         if (event.getTarget() instanceof Player player && player != mc.player && !this.何友树友友树何树何友.K("None")) {
            this.何何树树树树树友树友 = player;
         }
      }
   }

   @Override
   public void M() {
      this.友树树何友何树友何何 = 0;
      this.何何树树树树树友树友 = null;
   }

   @EventTarget
   public void H(WorldEvent event) {
      树树何友树何友友何友.B(128503974172331L);
      this.友树树何友何树友何何 = 0;
      this.何何树树树树树友树友 = null;
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖国企变私企";
   }

   @EventTarget
   public void O(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (mc.player.hurtTime > this.树树友友何树树友何友 && mc.player.hurtTime > 5) {
         String baseDir = Cherish.getResourcesManager().resources.getAbsolutePath() + "\\sound\\other\\";
         String var12 = this.友何何树树何何友何树.getValue();
         byte var13 = -1;
         switch (var12.hashCode()) {
            case 977234782:
               if (var12.equals("Undertale")) {
                  var13 = 0;
               }
            default:
               switch (var13) {
                  case 0:
                     树树何友树何友友何友.d(baseDir + "undertale_hurt.wav", 44432082049881L, 0.8F);
               }
         }
      }

      this.树树友友何树树友何友 = mc.player.hurtTime;
      if (this.何何树树树树树友树友 != null && !this.何何树树树树树友树友.isAlive() && !this.何友树友友树何树何友.K("None")) {
         if (this.何何树友何何树何树友.c(500L, 41972279541307L)) {
            this.C();
            this.何何树友何何树何树友.D(11747522392279L);
         }

         this.何何树树树树树友树友 = null;
      }
   }
}
