package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class 友何友友何何树何友何 extends Module implements 何树友 {
   private final ModeValue 友树友树何友友友何树 = new ModeValue("Healing Mode", "治疗模式", new String[]{"GoldenHead", "MushroomStew"}, "GoldenHead");
   private final NumberValue 友树何何何友友何何何 = new NumberValue("Use Delay", "使用延迟", 500, 0, 3000, 50);
   private final NumberValue 何树友友何何友何友友 = new NumberValue("Health", "血量阈值", 15, 1, 120, 1);
   private final NumberValue 何何友树何何友树树何 = new NumberValue("Switch Delay", "切换延迟", 100, 50, 500, 10);
   private final BooleanValue 树树何友友树树友何树 = new BooleanValue("Spoof Slot", "切换欺骗", false);
   private final BooleanValue 友友何友何树何友友树 = new BooleanValue("Debug Message", "调试信息", false);
   private final 何友友何树何树何树友 友树友树树友何树树友 = new 何友友何树何树何树友(51913986529303L);
   private final 何友友何树何树何树友 何树树何何何友树何树 = new 何友友何树何树何树友(51913986529303L);
   private int 树友何何树树友何何何 = -1;
   private boolean 友友树树友友友友友何 = false;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[36];
   private static final String[] l = new String[36];
   private static String HE_DA_WEI;

   public 友何友友何何树何友何() {
      super("AutoHealing", "自动治疗", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-6777390196831305311L, 6276776854754701525L, MethodHandles.lookup().lookupClass()).a(34618905782001L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(124859746063883L << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[37];
      int var12 = 0;
      String var11 = " *ê\u0000NRG\u0011úv\u00ad\n,\u0082Ê\u0013\u0018\u0001KÔ\u0081ò\u001d4\u0012´ø\u0007e²Ø@<C\n\nNå¤\u0013ª\u0018C§-bg\u0080\u0090»Ç\u0099o=¯\rUF\rðuªÚ\u0005d$\u0010´MÄ\u009e^É4ñðÚÉ( \u0003Øh L\u008f¶ë\u0007ØA\u0088à*/¦\u00074(\u0083\u009ez\u0019\u000b\u0095H¯â\"ñ\u0084&µ\u0080\u0083«\u0010\u009deò\u0093Ì\u00148Úw(h7\u0089Þó´\u0010¬¡uÂ\u0084\u0000\u0088%w\u0012u\u007f\u009a\u0083\u009dv \u0091ï\u0099v8J\u008a\u000b\\\u001c,±dØJ%?³\u008c\t\u0001\u008b\u009eÎ¹4b×D~\u0083~\u0010ê\u0010\u0011²Ñb(\u009fnX\u001f\u001c÷\u0010`` wvSÒûÑ¯§}\u0081×\u000b«×\u001aI?i\u0000P\";\u0080p=:,LYR\u000f®\u0010ô»Â\u0019\u0089þÐèÕ Ve×±Op ov\u0096#\u000f\u0006\u0096\u001fÊ|\f\u0014haëÜ¤ºµ\u008cÄ}÷n}ËLÈO,£?\u0018öwA³î§m\u0094\u0010Ñ-¯¯Z\u0003¨£\u0017Ê£ñLz3 ¦K\u008eÄÁ\u0098³ßæ*\u008c7\u0087\u0007\u001b&H\u0097\u008aÚ\u009fâ\u0095\"\u0090\u0000fßà\f7Õ §\u009b¨Ý¹\u0006\u0080!ììÎ#c\u0097á>AR\u000fËÞ\u0017ä\u0094\u007fæMdðÿ\u009aM\u0018\u008b\u001d\u00937d\u0097E\fÑ^\u0080\u001a-8ÚIÄaØ|\u0099[\u008a\r\u0010qù$\u00ad\u0085B\\ù²g\u0017U^J5ö k=É9~\u0094ÄK×f¸²÷õ«\u009e»Ç¿¨ä¦\u008d\u0012~û\u0085h>-.Ý\u0018\u001c\u000e\u001e`\u008c\"xgqýhf\u0087'ßÏ4\u0086WèïPMz ÔÿqNïi×kfõA`\u0003\u008f\u009a'7\u0007\u001c\u001c\u009b;\u0083OµÖ;ú\u009d1A( Kó'I\"GgãÈÃ¼\u000bù:f`îUs\u0003Å¬¬]¶\r©¿8°\u001c*\u0018Å ö?rÃEÛàXIøl¿PO&\u0003ä%Áò][ \u0002O>mÌ!a\u001a×¹¥´LÅ\u0004ÕÛêÆHKà]éÝ·jûõ$Lá ´£\b\u009dV¸\u0007®\u001eï\u0093[\tL¼ý@¬\u008c5|Db3áúÆ$\u001c\u0000\u0082r\u0010·«Añý;£\u0000×\u0004qXg$Iq\u0018\u0002` Q\u0095|¬2B4\u0083ëô\u0095\u001bS\u0099Ò!R\u008aïé\u0092 ¤$á$\féÉÐ¨Ð¦\u0080Ï \u0087/\u0013Döû\u0093¸²\u00014c]6aä\u0085y ÅZÙ\rbçb\u0014ñ\u0014\u001d\"í\u001fß\u0087¬ÿ½Ô\u0017³ð\u0005\t\u000e\u0005Yk\u0013Öã\u0018Å \u0018(ÍMÎh\u0094Á \u0088Ê \\ì\u0012Ñö-@\b\"¦ R4\u001dE,ÿNMUrq\\Û¾¡j\u009d -×¿\u008e64\râ\r¿9\u0004¨j x-\u0082&ÔÒ\u0088\u0090UÑå¿÷\u0090\u0011Ç~jTøÆ°Üó¼\u0015\u0091Ý÷öp¼@>Wr÷z\u008dt3c\u0014»U\u0085ÿcl\u00adªhÊgi*Ê`\u0082ØÌl½\u0013ýÈ%³ZÏ_áhù@Ï\u001f\":Â\u001ce\u000eE\u009d\u0011ê\u00871ìçø¦\f\u0087ø\u0006(\ffq\u009b\"\u0099Ä\u001aÕ\u001c\u0098_\u0006\u0086Ø\u0081\u0013¨\u007fÍ\u0016S\u009f\u008bÁªH\u0007\u0096sWACºµºA}m\u00970íª+±\u009fÙ\u0011¥a\u0013\u0001\u0095\u001c¹Í¤s[S\u009cÁK$*â\u008bV¼0È\u0012\u0094J\u001cx@òãy?ó<(ô\u001f\u001ctY\u0018ÇT'¾\u0084\u007f¨\u000fÖö&\u009a0ÀA\u0003\u0011\u0015qÏP¼T~";
      short var13 = 1010;
      char var10 = 16;
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[37];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(124859746063883L << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{57, 13, -125, 4, 69, 28, 83, 3});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "\u0015ÄÁ/\u0095f²Õ½ãs\u00887¢í\u0001§±eY÷wÏ¨ª\u0096\fJwllc\u0018÷\u007f\u0019ÉFÖ)Ã\u0016z\u0000|aè\u0006N=\u008bøæ¬\u0080;m";
                  var13 = 57;
                  var10 = ' ';
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 14;
               case 1 -> 42;
               case 2 -> 0;
               case 3 -> 19;
               case 4 -> 12;
               case 5 -> 39;
               case 6 -> 25;
               case 7 -> 24;
               case 8 -> 62;
               case 9 -> 33;
               case 10 -> 53;
               case 11 -> 22;
               case 12 -> 34;
               case 13 -> 21;
               case 14 -> 3;
               case 15 -> 17;
               case 16 -> 41;
               case 17 -> 2;
               case 18 -> 40;
               case 19 -> 47;
               case 20 -> 38;
               case 21 -> 56;
               case 22 -> 50;
               case 23 -> 32;
               case 24 -> 45;
               case 25 -> 8;
               case 26 -> 29;
               case 27 -> 36;
               case 28 -> 28;
               case 29 -> 10;
               case 30 -> 43;
               case 31 -> 46;
               case 32 -> 7;
               case 33 -> 54;
               case 34 -> 1;
               case 35 -> 59;
               case 36 -> 6;
               case 37 -> 26;
               case 38 -> 57;
               case 39 -> 18;
               case 40 -> 44;
               case 41 -> 58;
               case 42 -> 11;
               case 43 -> 31;
               case 44 -> 9;
               case 45 -> 13;
               case 46 -> 52;
               case 47 -> 20;
               case 48 -> 55;
               case 49 -> 30;
               case 50 -> 16;
               case 51 -> 15;
               case 52 -> 4;
               case 53 -> 27;
               case 54 -> 63;
               case 55 -> 5;
               case 56 -> 49;
               case 57 -> 61;
               case 58 -> 23;
               case 59 -> 37;
               case 60 -> 60;
               case 61 -> 48;
               case 62 -> 35;
               default -> 51;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 10226;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友友何何树何友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u0005h\u0083")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友友何何树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 227 && var8 != 'D' && var8 != 'T' && var8 != 'r') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 196) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 221) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 227) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'D') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'T') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友友何何树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   protected void h() {
      this.W();
      this.y("自动治疗已禁用");
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private boolean d(ItemStack stack) {
      树友何何友何树何树友.E();
      return stack.hasTag() && stack.getTag() != null && stack.getTag().contains("SkullOwner");
   }

   private static void a() {
      k[0] = "f\u0015K6!\u000eiU\u0006=+\u0013l\b\r{#\u000ea\u000e\t0`\bh\u000b\t{>\rd\u0002\u0000'`厪佐厰厮伀伛桰佐厰估";
      k[1] = boolean.class;
      l[1] = "java/lang/Boolean";
      k[2] = int.class;
      l[2] = "java/lang/Integer";
      k[3] = "\u0019\u0015,j]{\u0016UaaWf\u0013\bj'_{\u001e\u000enl\u001c栅伯厰叉作栣叟厱伮佗";
      k[4] = "{Un$7\u001dt\u0015#/=\u0000qH(i-\u0006qW3i伍厹叓佮桑伒桉伧栉台";
      k[5] = ".#\u0012n\f\f!c_e\u0006\u0011$>T#\u0015\u0002!8Y#\n\u000e=!\u0012@\f\u0007(\u001b]a\u0016\u0006";
      k[6] = "c+;\u000bkJh$*D\u0000^j/=\u001e,Ig";
      k[7] = "=`hWN-=`\u007f\u000bB\"'+\u007f\u0015J!=q24J*6fn\u0018E0";
      k[8] = ".u\u000bK\u007f\u0014.u\u001c\u0017s\u001b4>\u001c\t{\u0018.dQ\bg\u00114y\u000f\ts\u0004%bQ(g\u00114y/\ts\u0004%b8\u0004\u007f\u0018\r\u007f\u001b\u0000";
      k[9] = "P!\u000fBCxP!\u0018\u001eOwJj\f\u0003\\}Zj\u001e\u0002ZxJ=U\u001cBpG!\tBg\u007fH!\u0015\u0018AcG";
      k[10] = "\u000eaC4\u0005\u000b\u0001!\u000e?\u000f\u0016\u0004|\u0005y\u001c\u0005\u0001z\by\u0003\t\u001dcC\u0015\u0005\u000b\u0001j\f9<\u0005\u0001z\b";
      k[11] = "\u001a}~i\r'\u001a}i5\u0001(\u00006}(\u0012\"\u00106C)\u0014+\u0006yi3\t!\u001aPk)\u0004";
      k[12] = "$X>pF.+\u0018s{L3.Ex=D.#C|v\u0007(*F|=Y-&Oua\u0007桐厌佣佅变佼桐伒栧叛";
      k[13] = ":T\u007fv}]\u000ewp60V\u0004juk;\u0010\fwxm?[OUs|&R\u0004#";
      k[14] = "1g\u00125m1>'_>g,;zTxt?>|Yxk3\"e\u0012\u0018w30lN\u0000c2'l";
      k[15] = "\u0005/I\u0016\u00132\u0005/^J\u001f=\u001fdJW\f7\u000fdTL\u001b6E\u0003I]\u0013(";
      k[16] = "W\u000bChkOW\u000bT4g@M@@)tJ]@^2cK\u0017'C#k";
      k[17] = "BP_\u000fmJI_N@\fDBTJ\u001a";
      k[18] = "\u0002\u001bsz\u0003}VH0C厼栋叿桬栘厀伢栋栥厶\u0001xD{\u0006\bn\u007f\u0016lQ";
      k[19] = ">\u000er\u0016$1j]1/厛桇參桹佝召厛厝佝桹\u0000\u0013bg\u007f\u0000oSe 9";
      k[20] = "\u0018]GaloL\u000e\u0004X位栙栿佮佨伅叓栙佻株5c+i\u001cNZdy~K";
      k[21] = "b+\u000e^a`6xMgt\u000f`u\u0003\u001fgwgu\u001f\u0001\u001d3l:\u0004\u001de4l&\u001ag";
      k[22] = "!\u0001w>%r\"\u0010t-\u001dwJM7k\"#J|0m#i{Fo#o%";
      k[23] = "kcgDXj2}>A2\u007f\u0002 eJ\r.\u0002\u001ba\u0016\\t9x1\u0014Pq";
      k[24] = "A\f\n7/o\u0015_I\u000e厐參伢厡伥栗伎參厼桻x1n:\u0007]\ns(9A";
      k[25] = "\u0004\u0002\u001c\u0012\roQ\rDL|F}s:\"<Jr~|ELcSC\u0010\u0010C;\r";
      k[26] = "\u001cfy\u0016\u0007LK%i\nk8,,q\u000e\u0002\u0018Ir&B\fu";
      k[27] = "\u0004\"]LZ\\Pq\u001eu佻佮叹桕佲伨句株栣休/\u001c\u001d\u0003\u0002'@\u0019ZW\u0004";
      k[28] = "au\u001eM5K5&]t厊叧框栂厯厷厊叧厜但l\u00047N/ \u0014I8E";
      k[29] = "\u0016]JspnB\u000e\tJ栕参併佮校桓叏作併佮8saoM_[#ccH";
      k[30] = "t4r|\fB g1E伭栴厉厙佝优厳佰厉厙\u0000,K\u001dr1o)\fIt";
      k[31] = "|D\u0006>\u001cm(\u0017E\u0007厣栛伟佷伩叄厣佟伟佷tn[2zA\u001bk\u001cf|";
      k[32] = "\u001b%o6\u001aROv,\u000f桿栤佸厈叞栖桿叾佸桒\u001d0[\u0007]tor\u001d\u0004\u001b";
      k[33] = "$0h9\u001b>&/(ne2\u001am)<]d\u001aQyaUa4)aj_2";
      k[34] = "o\u001f{1,NkE%8N厲桌栽取伏厍伬桌叧栌RtJ;Gwmp\u0010eN";
      k[35] = ")\u0006)\\G\\+\u0019i\u000b9P\u0017[h[\t\u0006\u0017g8\u0004\t\u00039\u001f \u000f\u0003P";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private int k() {
      树友何何友何树何树友.E();
      if (this.Q(new Object[]{52406761729175L})) {
         return -1;
      } else {
         int i = 0;
         ItemStack stack = mc.player.getInventory().getItem(0);
         if (this.t(stack)) {
            return 0;
         } else {
            i++;
            return -1;
         }
      }
   }

   private boolean t(ItemStack stack) {
      树友何何友何树何树友.E();
      if (stack.isEmpty()) {
         return false;
      } else {
         String var5 = this.友树友树何友友友何树.getValue();
         byte var6 = -1;
         switch (var5.hashCode()) {
            case 964847273:
               if (!var5.equals("GoldenHead")) {
                  break;
               }

               var6 = 0;
            case 1265266539:
               if (var5.equals("MushroomStew")) {
                  var6 = 1;
               }
         }
         return switch (var6) {
            case 0 -> this.N(stack);
            case 1 -> this.u(stack);
            default -> false;
         };
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void z() {
      this.友树友树树友何树树友.D(11747522392279L);
      this.何树树何何何友树何树.D(11747522392279L);
      this.树友何何树树友何何何 = -1;
      this.友友树树友友友友友何 = false;
   }

   private boolean u(ItemStack stack) {
      return stack.getItem() == Items.MUSHROOM_STEW;
   }

   private void y(String message) {
      if (this.友友何友何树何友友树.getValue()) {
         ClientUtils.P(125527250587045L, "[AutoHealing]" + "自动治疗已禁用");
      }
   }

   @Override
   protected void M() {
      树友何何友何树何树友.E();
      this.z();
      String mode = this.友树友树何友友友何树.getValue().equals("GoldenHead") ? "金头" : "蘑菇煲";
      this.y("自动治疗已启用，模式:" + mode);
   }

   private boolean N(ItemStack stack) {
      树友何何友何树何树友.E();
      if (stack.getItem() != Items.PLAYER_HEAD) {
         return false;
      } else {
         String displayName = stack.getDisplayName().getString().toLowerCase();
         return displayName.contains("golden head") || displayName.contains("gold head") || displayName.contains("金头") || this.d(stack);
      }
   }

   private void W() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.树友何何树树友何何何 != -1) {
            if (this.树树何友友树树友何树.getValue()) {
               PacketUtils.a(112543050219290L, new ServerboundSetCarriedItemPacket(this.树友何何树树友何何何));
            }

            mc.player.getInventory().selected = this.树友何何树树友何何何;
            this.树友何何树树友何何何 = -1;
         }

         this.友友树树友友友友友何 = false;
      }
   }

   @EventTarget
   public void Q(TickEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.友友树树友友友友友何 && this.何树树何何何友树何树.A(this.何何友树何何友树树何.getValue().longValue(), 118344821288830L)) {
            this.W();
         } else if (!this.友友树树友友友友友何) {
            float currentHealth = mc.player.getHealth();
            float maxHealth = mc.player.getMaxHealth();
            float healthPercent = currentHealth / maxHealth * 100.0F;
            if (this.友友何友何树何友友树.getValue() && this.友树友树树友何树树友.A(5000L, 118344821288830L)) {
               String var10001 = String.format("%.1f", currentHealth);
               String var10002 = String.format("%.1f", maxHealth);
               String a = String.format("%.1f", healthPercent);
               String ax = var10002;
               String var21 = var10001;
               this.y("当前血量: " + var21 + "/" + ax + " (" + a + "%)");
            }

            if (!(healthPercent > this.何树友友何何友何友友.getValue().floatValue())) {
               if (this.友树友树树友何树树友.A(this.友树何何何友友何何何.getValue().longValue(), 118344821288830L)) {
                  int healingItemSlot = this.k();
                  if (healingItemSlot == -1) {
                     String itemName = this.友树友树何友友友何树.getValue().equals("GoldenHead") ? "金头" : "蘑菇煲";
                     this.y("快捷栏中没有找到" + itemName);
                  } else {
                     this.树友何何树树友何何何 = mc.player.getInventory().selected;
                     if (this.树树何友友树树友何树.getValue()) {
                        PacketUtils.a(112543050219290L, new ServerboundSetCarriedItemPacket(healingItemSlot));
                     }

                     mc.player.getInventory().selected = healingItemSlot;

                     try {
                        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                        String itemName = this.友树友树何友友友何树.getValue().equals("GoldenHead") ? "金头" : "蘑菇煲";
                        this.y("成功使用" + itemName);
                     } catch (Exception var22) {
                        String itemNamex = this.友树友树何友友友何树.getValue().equals("GoldenHead") ? "金头" : "蘑菇煲";
                        this.y("使用" + itemNamex + "时出错:" + var22.getMessage());
                     }

                     if (this.树友何何树树友何何何 != -1 && this.树友何何树树友何何何 != healingItemSlot) {
                        this.友友树树友友友友友何 = true;
                        this.何树树何何何友树何树.D(11747522392279L);
                     }

                     this.友树友树树友何树树友.D(11747522392279L);
                  }
               }
            }
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "何大伟230622198107200054";
   }
}
