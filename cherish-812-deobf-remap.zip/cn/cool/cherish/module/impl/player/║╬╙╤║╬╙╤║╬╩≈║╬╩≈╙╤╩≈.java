package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.move.MoveMathEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;

public class 何友何友何树何树友树 extends Module implements 何树友 {
   public final ModeValue 友友何何友友树何友树 = new ModeValue("Mode", "模式", new String[]{"Freeze", "Cancel"}, "Freeze");
   private final NumberValue 树何树友友何何何树友 = new NumberValue("Freeze Tick", 20, 1, 20, 1);
   private final BooleanValue 友友何友友友树何何友 = new BooleanValue("Only Air", true);
   private final BooleanValue 树友何何树何树树何何 = new BooleanValue("No Move", true);
   private final BooleanValue 友树友何何何树友友树 = new BooleanValue("Lag Check", true);
   private final 何友友何树何树何树友 何友树何树友何何友树 = new 何友友何树何树何树友(51913986529303L);
   private int 何树何友何何友友树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[28];
   private static final String[] k = new String[28];
   private static String HE_DA_WEI;

   public 何友何友何树何树友树() {
      super("Stuck", "卡空", 树何友友何树友友何何.友树树友何友何树友树, 88);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(7384779705612871331L, 2266932796717747469L, MethodHandles.lookup().lookupClass()).a(178125762127264L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(13014045448110L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[13];
      int var7 = 0;
      String var6 = "\u007fÙFÆF\u0085¯\u0095Îä\u001atÊÊâÎ\u0010¸[ûã\u0094\"Q\\d\u0089Ñ\u009a\u0083\\\u009f&\u0010«\t\u0006È\u0019Ç\u0088IYøîÎ[oHç &P6G\u0084^\u0019\r\u008e2\u001bÍÜtk\u0010W9ÓX}*YèÒBÑ+Âèü;\u0010\u001e?#u\"¹ù\u0094râæØz\u0088ªF\u0018Ï£Î\u0098\u0082\u0017$Õ\u001d\u0013wÞ*k\bò\u009ak¿>&Ú\u00adö\u0010q*åÕ\u0083@K\u0097HÙ\u0015gÔ9\u001a:\u0010G\u0017`ã5õ\u0098â\u008c\u0098\u0017æø$õN ÃËX\u0002[f d\u0012mÝh\u0011eeä]Vá«\u008e#EõÂê\u009c-\u007f¹rÁ\u0010Ø\u0000\u0080)ô\u001a\tP±AÖ¢ %\u0087È\u0010é\u0089¸y\u0015\u008fA:n_B÷ðÃFò";
      short var8 = 226;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[13];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ÀÙÝX¨»\u00172\n0ùøôÏlæ\u0086[<¥Þ\u001b#~²\u0097ý«Å¯þì\u0010¶\u000e\u0090M\u0088«\\¹m\u001b£\u0018qMÅ7";
                  var8 = 49;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void D(MoveInputEvent event) {
      if (树友何何友何树何树友.E() == null) {
         if (!this.树友何何树何树树何何.getValue()) {
            return;
         }

         event.setForwardImpulse(0.0F);
      }

      event.setLeftImpulse(0.0F);
   }

   @EventTarget
   public void V(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.何树何友何何友友树何++;
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 46;
               case 1 -> 10;
               case 2 -> 24;
               case 3 -> 13;
               case 4 -> 29;
               case 5 -> 34;
               case 6 -> 23;
               case 7 -> 8;
               case 8 -> 11;
               case 9 -> 55;
               case 10 -> 63;
               case 11 -> 56;
               case 12 -> 59;
               case 13 -> 35;
               case 14 -> 48;
               case 15 -> 6;
               case 16 -> 58;
               case 17 -> 61;
               case 18 -> 38;
               case 19 -> 18;
               case 20 -> 62;
               case 21 -> 57;
               case 22 -> 42;
               case 23 -> 20;
               case 24 -> 22;
               case 25 -> 31;
               case 26 -> 44;
               case 27 -> 0;
               case 28 -> 19;
               case 29 -> 32;
               case 30 -> 39;
               case 31 -> 4;
               case 32 -> 17;
               case 33 -> 50;
               case 34 -> 51;
               case 35 -> 1;
               case 36 -> 16;
               case 37 -> 2;
               case 38 -> 5;
               case 39 -> 40;
               case 40 -> 33;
               case 41 -> 47;
               case 42 -> 14;
               case 43 -> 49;
               case 44 -> 28;
               case 45 -> 26;
               case 46 -> 36;
               case 47 -> 27;
               case 48 -> 12;
               case 49 -> 21;
               case 50 -> 37;
               case 51 -> 15;
               case 52 -> 43;
               case 53 -> 45;
               case 54 -> 41;
               case 55 -> 9;
               case 56 -> 7;
               case 57 -> 52;
               case 58 -> 60;
               case 59 -> 30;
               case 60 -> 54;
               case 61 -> 53;
               case 62 -> 3;
               default -> 25;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   @EventTarget
   private void i(WorldEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.n();
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26749;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何友何友何树何树友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[Ó¸K\\äN4¯, \u001dU®\u0099ajý\u0018, 2G2²ð³\u0015L, É²\u0095\u009e\u008cö;#FÕºÂÀ¿ÇK, FA")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友何友何树何树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 249 && var8 != 'W' && var8 != 'o' && var8 != 'b') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'S') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 194) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 249) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'W') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'o') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @EventTarget
   public void c(PacketEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (event.getSide() == Event.Side.PRE && this.友树友何何何树友友树.getValue() && event.getPacket() instanceof ClientboundPlayerPositionPacket) {
            this.n();
         }
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友何友何树何树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   public void h() {
      this.何树何友何何友友树何 = 0;
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "`\t\u001a\u0002T\u001eoIW\t^\u0003j\u0014\\OV\u001eg\u0012X\u0004\u0015桠佖厬叿伴株厺又伲佡";
      j[1] = "\"\u0006{QBO-F6ZHR(\u001b=\u001c@O%\u001d9W\u0003I,\u00189\u001c]L \u00110@\u0003併厊伽厞佧格併桐厣桄";
      j[2] = "\u007fSg`Rcp\u0013*kX~uN!-KmpH,-TalQgARcpX(mkmpH,";
      j[3] = "}(J\u0011\u0017rrh\u0007\u001a\u001dow5\f\\\u0015rz3\b\u0017Vts6\b\\\bq\u007f?\u0001\u0000V栌叕伓伱厹伭栌佋桗厯";
      j[4] = "\u0011#=\u0013!\u001a%\u00002Sl\u0011/\u001d7\u000egW'\u0000:\bc\u001cd\"1\u0019z\u0015/T";
      j[5] = "\u0005U%u\u007f\u0017\u000eZ4:\u0003\u000e\u0001@:y4>\u0017W6d%\u0012\u0000Z";
      j[6] = int.class;
      k[6] = "java/lang/Integer";
      j[7] = "B\u0002U3%\u000eMB\u00188/\u0013H\u001f\u0013~<\u0000M\u0019\u001e~#\fQ\u0000U\u001d%\u0005D:\u001a<?\u0004";
      j[8] = "5\u001f\u0010(Z\u0004:_]#P\u0019?\u0002VeC\n:\u0004[e\\\u0006&\u001d\u0010\u0005@\u00064\u0014L\u001dT\u0007#\u0014";
      j[9] = ")\u00161?\u001eA)\u0016&c\u0012N3]&}\u001aM)\u0007k\\\u001aF\"\u00107p\u0015\\";
      j[10] = "^\u000fgx(z^\u000fp$$uDDp:,v^\u001e=\u00195gY\u0005}%";
      j[11] = "\u001d5$2r\u0015\u001d53n~\u001a\u0007~3pv\u0019\u001d$~Wz\u0005>1 lv\u0012\u0014";
      j[12] = "pT=Q[.\u007f\u0014pZQ3zI{\u001cQ7vTg\u001cQ7vTgA\u001a\u0004e_}F\u0010\u0012z^v";
      j[13] = "]>GE\u0003\u0010R~\nN\t\rW#\u0001\b\u0019\u000bW<\u001a\b伹厴叵伅桸佳桽伪栯厛";
      j[14] = "sOd+Wux@ud6{sKq>";
      j[15] = "\t^M\rj\u0002K[\u0010s桉叺伦佧栳伮桉栠伦佧*J6_\u0017_KN,K\u001f";
      j[16] = ".\r{\u0012\t,l\b&l佮栎企厪佁伱台叔桅伴\u001cPW|\"\u0019s\u0013Qn3";
      j[17] = "?\u0019Y\"v]}\u001c\u0004\\厏厥伐传叽原桕伻厎桤>aw\r5C\\>1\n4";
      j[18] = "5}d\u000bC\u0001wx9u桠佧桞叚叀伨伤佧桞叚\u0003KCU:`c\u0005A\u0004*";
      j[19] = "$'OTD}n7\\Q(Q\u001ee\r\u0017K,&>S\u0012\u0018\u001c";
      j[20] = ";0\u0012%1\u0013y5O[佖叫桐伉桬厘佖併厊桍uj7Mu>D7dD)";
      j[21] = "LN\u0002ro;\u000eK_\f厖參佣叩厦叏桌佝佣叩e53fRO\u00041)rZ";
      j[22] = "\u0003Ru%T@V\rj;&Mj\u0000-|\u0018\u001dj1+{I\u0019RZo}TX";
      j[23] = "j\f}awx(\t \u001f厎桚叛伵佇佂桔厀叛桱\u001a&+%t\r{\"11|";
      j[24] = "E*\t]\u001b2\u00180\f\u0019\"\u0016/\u00036VFqNwJ\u000b\\t\n";
      j[25] = "\u0019LS\u0011O^\u0003\u001bUr叽栨桫叩佯厱佣栨厱栳2\u0019XP\u0011[]\u0003\u000fV";
      j[26] = "MH\b{\u0010n\tN\u0015:\u007fk%F]yN<%wW|\u001b8\u0017\t\u001c=\u0013h";
      j[27] = "`L*\u0007<>\"Iwyo\u0005.\u0011s\u0013`zbY#\u0007\u00069+\u0016'\u001fyucF3y";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   public void M() {
      this.何友树何树友何何友树.D(11747522392279L);
      mc.options.keySprint.setDown(mc.options.keySprint.isDown());
   }

   @EventTarget
   public void M(Render2DEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && !this.友友何何友友树何友树.K("Cancel")) {
         int y = mc.getWindow().getGuiScaledHeight() / 2 + 40;
         if (this.友友何友友友树何何友.getValue() && !mc.player.onGround()) {
            HUD.instance.b(event.poseStack(), "Stuck now...", this.何树何友何何友友树何 / this.树何树友友何何何树友.getValue().floatValue(), this.何树何友何何友友树何, y);
         }
      }
   }

   @EventTarget
   private void W(MoveMathEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         String var11 = this.友友何何友友树何友树.getValue();
         byte var12 = -1;
         switch (var11.hashCode()) {
            case 2112431799:
               if (!var11.equals("Freeze")) {
                  break;
               }

               var12 = 0;
            case 2011110042:
               if (var11.equals("Cancel")) {
                  var12 = 1;
               }
         }

         switch (var12) {
            case 0:
               if (this.友友何友友友树何何友.getValue() && mc.player.onGround()) {
                  return;
               }

               if (!mc.player.isSpectator()) {
                  if (this.何树何友何何友友树何 == this.树何树友友何何何树友.getValue().intValue()) {
                     RotationUtils.F(new Rotation(21273681362686L, mc.player.getYRot() + (float)(Math.random() - 0.5), mc.player.getXRot()), 3052380832273L);
                     event.setCancelled(false);
                     this.何树何友何何友友树何 = 0;
                  }

                  KeyMapping.set(mc.options.keySprint.getKey(), false);
                  event.setCancelled(true);
               }

               if (this.友友何友友友树何何友.getValue() && !mc.player.onGround() && !mc.player.isSpectator()) {
                  break;
               }

               this.何树何友何何友友树何 = 0;
            case 1:
               event.setCancelled(true);
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "我是何树友";
   }
}
