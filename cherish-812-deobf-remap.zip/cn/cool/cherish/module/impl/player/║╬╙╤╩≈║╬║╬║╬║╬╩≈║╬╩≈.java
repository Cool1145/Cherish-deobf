package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Items;

public class 何友树何何何何树何树 extends Module implements 何树友 {
   private final NumberValue 树何何何友何友树树树 = new NumberValue("Delay", "延迟", 0, 0, 3, 1);
   private final BooleanValue 友树树友何树友友何树 = new BooleanValue("Scaffold Check", "自动搭路检查", false);
   private final BooleanValue 友友树树何树友何友树 = new BooleanValue("Disable On Cobweb", "手持蜘蛛网时禁用", true);
   private int 友树何友树树何何何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[20];
   private static final String[] k = new String[20];
   private static String HE_SHU_YOU;

   public 何友树何何何何树何树() {
      super("FastPlace", "快速放置", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8138339159299131532L, 8555296570936995105L, MethodHandles.lookup().lookupClass()).a(66298945575556L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(140241232397424L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[8];
      int var7 = 0;
      String var6 = "\u0007¹Ø\u009aaèÛ9´Â6 ô{]Ì ¹\bÁ\u0080Óãò\u0018\u009dî\u0083Äì¦;vg\u001d\u008fÎ£!\u0093£\u001fG\u001cù\u0082»\u009ev\u0018\u0091Që!\u0005K©Õ\u000f\u0091\u0090\u0099q\u0019É\u001f\u000b®BSmõ\u0091¶0\u0083?\u009ei\u009d\t2æ\u009eo2]xþëBY\u0006$Íñ\u000b\u0003B{MþëÔE\u0097\u0017V¾bÚ?\u0010ò÷^\u009drK\u0091¤$'\u0010\u0090\u0086Ó\u0013'E\u0089«\u008e0Ì!¾[Rb(í¦ëK\u0091Óvc¥L|\u007fßcc.\u0005*Ä\u0006`º\u008f\u0098-ï2\u009a\u009d\u0012×Ðû0/\u0098z´R\u0014";
      short var8 = 181;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[8];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ÌõA¿2\u0082±\u009d¹zU+VX9~§\u008c\u009aÈK¡på(¦´9\nûjýEÎ\u0090 Ã nÖÅð4\u009d\u009dmÅ|;-÷w\u001c¯I¿~\u0013p\u00973añ\u009fß";
                  var8 = 65;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 5;
               case 1 -> 18;
               case 2 -> 52;
               case 3 -> 55;
               case 4 -> 15;
               case 5 -> 54;
               case 6 -> 0;
               case 7 -> 21;
               case 8 -> 43;
               case 9 -> 19;
               case 10 -> 20;
               case 11 -> 27;
               case 12 -> 36;
               case 13 -> 22;
               case 14 -> 4;
               case 15 -> 45;
               case 16 -> 39;
               case 17 -> 41;
               case 18 -> 26;
               case 19 -> 10;
               case 20 -> 28;
               case 21 -> 35;
               case 22 -> 48;
               case 23 -> 23;
               case 24 -> 46;
               case 25 -> 37;
               case 26 -> 14;
               case 27 -> 40;
               case 28 -> 61;
               case 29 -> 56;
               case 30 -> 29;
               case 31 -> 13;
               case 32 -> 34;
               case 33 -> 59;
               case 34 -> 60;
               case 35 -> 33;
               case 36 -> 49;
               case 37 -> 38;
               case 38 -> 51;
               case 39 -> 58;
               case 40 -> 6;
               case 41 -> 42;
               case 42 -> 1;
               case 43 -> 47;
               case 44 -> 11;
               case 45 -> 30;
               case 46 -> 9;
               case 47 -> 17;
               case 48 -> 16;
               case 49 -> 44;
               case 50 -> 62;
               case 51 -> 53;
               case 52 -> 3;
               case 53 -> 57;
               case 54 -> 63;
               case 55 -> 8;
               case 56 -> 24;
               case 57 -> 31;
               case 58 -> 50;
               case 59 -> 7;
               case 60 -> 25;
               case 61 -> 2;
               case 62 -> 12;
               default -> 32;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21195;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树何何何何树何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树何何何何树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树何何何何树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 253 && var8 != 'Q' && var8 != 'N' && var8 != 195) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'H') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 210) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 253) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Q') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'N') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @EventTarget
   public void c(TickEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && (树友何何友何树何树友.树友友树友友友友树何 == null || !树友何何友何树何树友.树友友树友友友友树何.isEnabled() || !this.友树树友何树友友何树.getValue())) {
         if (mc.player.getMainHandItem().getItem() != Items.COBWEB && mc.player.getOffhandItem().getItem() != Items.COBWEB || !this.友友树树何树友何友树.getValue()) {
            if ((mc.player.getMainHandItem().getItem() instanceof BlockItem || mc.player.getOffhandItem().getItem() instanceof BlockItem)
               && WrapperUtils.J(11394190809835L) != 0) {
               WrapperUtils.n(22835015615421L, this.树何何何友何友树树树.getValue().intValue());
            }
         }
      }
   }

   @Override
   public void h() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         WrapperUtils.n(22835015615421L, this.友树何友树树何何何何);
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "[xMQk>T8\u0000Za#Qe\u000b\u001ci>\\c\u000fW*8Uf\u000f\u001ct=Yo\u0006@*伄右标伶佧佑伄栩佃桲";
      j[1] = "8\u0007dTo\u001f3\bu\u001b\u0013\u0006<\u0012{X$6*\u0005wE5\u001a=\b";
      j[2] = int.class;
      k[2] = "java/lang/Integer";
      j[3] = ";QR\nll4\u0011\u001f\u0001fq1L\u0014Gnl<J\u0010\f-j5O\u0010Gso9F\u0019\u001b-栒厓佪伩厢佖栒伍栮厷";
      j[4] = "P.vTj\u0004d\ry\u0014'\u000fn\u0010|I,If\rqO(\u0002%/z^1\u000bnY";
      j[5] = "YylB~MV9!ItPSd*\u000fgCVb'\u000fxOJ{lc~MVr#OGCVb'";
      j[6] = "mv\u0000\u0006^Vmv\u0017ZRYw=\u0003GASg=\u001d\\VR-Z\u0000M^L";
      j[7] = "\u0016(,\\:P\u0016(;\u00006_\fc/\u001d%U\u001cc1\u00062TV\u0004,\u0017:";
      j[8] = ").d &U&n)+,H#3\"m?[&5/m W:,d\r<W(%8\u0015(V?%";
      j[9] = "\b\u001fr^}$\u0007_?Uw9\u0002\u00024\u0013\u007f$\u000f\u00040X<桚伾厺厗佨栃厀厠伤伉";
      j[10] = "`\u0004x4hIk\u000bi{\tG`\u0000m!";
      j[11] = "\u001d\u0001\u001e\u0012NX\u0000\t\n#右叹桫桹伻栺右佧厱桹f\u0018@\u0004\tQY\u001bREJ";
      j[12] = "v<-5-'k49\u0004厐桜栀厞伈栝厐历佄桄U?#{blj<1:!";
      j[13] = "c04E\u0007!~8 t\u0010C5hq\u001d\u0004swl5\u0015yz5l%\tI81(-t";
      j[14] = "z7C\u0005\u0013kg?W4厮栐佈厕栢栭估佔佈伋;\r\u0000r+&A]Sni";
      j[15] = "iX=\u0016L6(\u0001bF0桊厐叿栙叨右厐厐栥佝+\n7n\u0001|NKn1Q";
      j[16] = "T(\rd C\u0015qR4\\knwZ`.^\fw\u00002&&";
      j[17] = "Wd\u0006tf\t\u0013h\u0002$\u0004厩桰栐厹佂叇伷桰及档\u001f:\u0007\u0015b\u0018|~\u000b\u00112";
      j[18] = "q\u0011\fAN\u007fw\u0000\u0005\u001dru\u001aAD\u0014L \u001a}@E\u001by)\u0017\fB\bg";
      j[19] = "HWGUL\u001cU_Sd栫伣佺佫叼伹叱桧栾栯?Z\f\u0014WZNZ\u000f\u0012^";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   public void M() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.友树何友树树何何何何 = WrapperUtils.J(11394190809835L);
      }
   }

   private static String HE_SHU_YOU() {
      return "何炜霖国企上班";
   }
}
