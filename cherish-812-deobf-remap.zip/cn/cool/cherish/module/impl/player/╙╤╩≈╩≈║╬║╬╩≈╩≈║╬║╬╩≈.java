package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

public class 友树树何何树树何何树 extends Module implements 何树友 {
   private final BooleanValue 何友何友何友树友友友;
   private final BooleanValue 友何友树何何友树何树;
   private final BooleanValue 树树树友友树树友何树;
   private final NumberValue 何友何何何友友何何友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[25];
   private static final String[] k = new String[25];
   private static int _行走的50万——何炜霖 _;

   public 友树树何何树树何何树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/player/友树树何何树树何何树.a J
      // 03: ldc2_w 101277411758542
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 2017
      // 0c: ldc2_w 3503449554775191917
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 16148
      // 19: ldc2_w 7282480807073515935
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w -5055293839863986980
      // 26: lload 1
      // 27: invokedynamic Ð (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/BooleanValue
      // 33: dup
      // 34: sipush 29009
      // 37: ldc2_w 3606064377065261019
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 14175
      // 44: ldc2_w 7899854258480153046
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: bipush 0
      // 4f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 52: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 55: putfield cn/cool/cherish/module/impl/player/友树树何何树树何何树.何友何友何友树友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 58: aload 0
      // 59: new cn/cool/cherish/value/impl/BooleanValue
      // 5c: dup
      // 5d: sipush 5288
      // 60: ldc2_w 9082409635324797472
      // 63: lload 1
      // 64: lxor
      // 65: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6a: sipush 6261
      // 6d: ldc2_w 6471630202082668275
      // 70: lload 1
      // 71: lxor
      // 72: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 77: bipush 1
      // 78: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 7b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 7e: putfield cn/cool/cherish/module/impl/player/友树树何何树树何何树.友何友树何何友树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 81: aload 0
      // 82: new cn/cool/cherish/value/impl/BooleanValue
      // 85: dup
      // 86: sipush 25681
      // 89: ldc2_w 147249214752412374
      // 8c: lload 1
      // 8d: lxor
      // 8e: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 93: sipush 22139
      // 96: ldc2_w 1194109963559854324
      // 99: lload 1
      // 9a: lxor
      // 9b: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // a0: bipush 1
      // a1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // a4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // a7: putfield cn/cool/cherish/module/impl/player/友树树何何树树何何树.树树树友友树树友何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // aa: aload 0
      // ab: new cn/cool/cherish/value/impl/NumberValue
      // ae: dup
      // af: sipush 21374
      // b2: ldc2_w 4809305182513194483
      // b5: lload 1
      // b6: lxor
      // b7: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // bc: sipush 3819
      // bf: ldc2_w 3569363079579744357
      // c2: lload 1
      // c3: lxor
      // c4: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // c9: ldc2_w 70.0
      // cc: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // cf: dconst_0
      // d0: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // d3: ldc2_w 90.0
      // d6: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // d9: dconst_1
      // da: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // dd: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // e0: putfield cn/cool/cherish/module/impl/player/友树树何何树树何何树.何友何何何友友何何友 Lcn/cool/cherish/value/impl/NumberValue;
      // e3: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(695785796023610253L, -5423922185130354151L, MethodHandles.lookup().lookupClass()).a(121416166544826L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 135493528145296L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[10];
      int var7 = 0;
      String var6 = "pß\u0004\u0001#2à·\u0002\u0089ò4¦Û\u00ad\u0098dû\u0094N\u001a©-=Â.\u009fÛã#ª³\r\raÊ\u000b3TN(ó\u001e»ªË¯}\u008fîC\u0018Á(±ÐØ\u0084wrµ\u0010CGýO06\u009c?\u0097:\u009f2çß}\r\u0011*× Ü\u0087HÇ\u0086¢\u0080\u009dUÕ+ð§²\b\u0004¥\u0007\u0016\u0091²\u0093!Çïp6þy\u007f\u008aL\u0010®Ô|èºÆÐ¥\u000ea®@-ìàÐ 7É²Ø&\u0081A²\u0099\u0003¬ZÖxMø\u008eÒ´¹\u001ci'êòB0(VÜa\u001a(6RY9Ô\u008f\u0081\u0002±Ô7ïV\u0088\u000eÂ¹QêÖµ\u0016k\u008e\u0083ÐÙÇWÆ\u008cþøZ(áÀ\u0000\ng(»\\g\r#A\u008d\u008aÃ\u000eÈ¸íF\u007f¦A\u008fpO\u0083\u0088õ\u001a\u0000u·æ¸\u0017\u008f\u008c{P®\u0092\u0003äº\u001e(>$ ò\u0082Ê¡Iv\u000bý\u008dÖ\u0080ÍÑ\u0089&\tß\u000f1p\u0016>1>\nòäÛ?\u0010¤¾rWÆQÃ";
      short var8 = 287;
      char var5 = '(';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[10];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\f`Sø<+Ä\u0003L)=K¿\u0093ô(\u0000 Cô¡]h\n\u001e\\ûÙÈ,WP!-¯j6\u000f}\u0002(cZn\u0005ãQJ8é¾ø!¿ù.\u0087Vªfgm¤±ýª\u0097\u0018¸À>\u0001pÞê\u0082\u000eµZ\u0014(";
                  var8 = 81;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public static Block B(Player player) {
      return e(BlockPos.containing(player.getX(), player.getY() - 1.0, player.getZ()));
   }

   @EventTarget
   public void D(MotionEvent event) {
      long a = 友树树何何树树何何树.a ^ 84095007293102L;
      long ax = a ^ 49130570903452L;
      c<"Ý">(1635433609424521459L, a);
      if (!this.w(new Object[]{ax})) {
         if (!c<"Ò">(this, 1635161215494043688L, a).getValue() || mc.player.onGround()) {
            if (!c<"Ò">(this, 1636873522477089706L, a).getValue() || this.H()) {
               label31: {
                  if (B(mc.player) instanceof AirBlock) {
                     if (!this.j()) {
                        break label31;
                     }

                     c<"Ò">(c<"Ò">(mc, 1634811689413531324L, a), 1635020327074013859L, a).setDown(true);
                  }

                  if (mc.player.onGround()) {
                     c<"Ò">(c<"Ò">(mc, 1634811689413531324L, a), 1635020327074013859L, a).setDown(false);
                  }
               }

               if (c<"Ò">(this, 1635323449513122920L, a).getValue()) {
                  this.M();
               }
            }
         }
      }
   }

   private boolean D(BlockPos blockBelow) {
      long a = 友树树何何树树何何树.a ^ 72045437990188L;
      long ax = a ^ 36638714340382L;
      c<"Ý">(6714928404070630257L, a);
      if (this.w(new Object[]{ax})) {
         return false;
      } else {
         HitResult hitResult = c<"Ò">(mc, 6715578701156093729L, a);
         if (hitResult != null && hitResult.getType() == c<"Ð">(6715729310171595414L, a)) {
            BlockPos lookingAt = ((BlockHitResult)hitResult).getBlockPos();
            return lookingAt.equals(blockBelow);
         } else {
            return false;
         }
      }
   }

   public void F() {
      long a = 友树树何何树树何何树.a ^ 84278473801192L;
      long ax = a ^ 48869803994330L;
      c<"Ý">(6193640183935306677L, a);
      if (!this.w(new Object[]{ax})) {
         c<"Ò">(c<"Ò">(mc, 6194143064631612922L, a), 6194352254158201317L, a).setDown(false);
         if (c<"Ò">(this, 6194656062188019502L, a).getValue()) {
            c<"Ò">(c<"Ò">(mc, 6194143064631612922L, a), 6194228805037616950L, a).setDown(false);
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public static Block e(BlockPos pos) {
      long a = 友树树何何树树何何树.a ^ 32789321483977L;
      c<"Ý">(7986407824750981268L, a);
      return mc.level == null ? null : mc.level.getBlockState(pos).getBlock();
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 59;
               case 1 -> 13;
               case 2 -> 25;
               case 3 -> 30;
               case 4 -> 19;
               case 5 -> 18;
               case 6 -> 9;
               case 7 -> 24;
               case 8 -> 16;
               case 9 -> 35;
               case 10 -> 28;
               case 11 -> 0;
               case 12 -> 2;
               case 13 -> 40;
               case 14 -> 45;
               case 15 -> 23;
               case 16 -> 17;
               case 17 -> 36;
               case 18 -> 50;
               case 19 -> 15;
               case 20 -> 4;
               case 21 -> 26;
               case 22 -> 61;
               case 23 -> 1;
               case 24 -> 14;
               case 25 -> 43;
               case 26 -> 47;
               case 27 -> 8;
               case 28 -> 11;
               case 29 -> 51;
               case 30 -> 32;
               case 31 -> 21;
               case 32 -> 56;
               case 33 -> 38;
               case 34 -> 27;
               case 35 -> 5;
               case 36 -> 37;
               case 37 -> 22;
               case 38 -> 12;
               case 39 -> 6;
               case 40 -> 55;
               case 41 -> 63;
               case 42 -> 7;
               case 43 -> 49;
               case 44 -> 48;
               case 45 -> 57;
               case 46 -> 34;
               case 47 -> 52;
               case 48 -> 33;
               case 49 -> 53;
               case 50 -> 29;
               case 51 -> 20;
               case 52 -> 60;
               case 53 -> 44;
               case 54 -> 54;
               case 55 -> 39;
               case 56 -> 10;
               case 57 -> 62;
               case 58 -> 46;
               case 59 -> 3;
               case 60 -> 41;
               case 61 -> 42;
               case 62 -> 31;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 3931;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友树树何何树树何何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友树树何何树树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 210 && var8 != 'J' && var8 != 208 && var8 != 231) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'E') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 221) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 210) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'J') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 208) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友树树何何树树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "Db,99-Db;e5\"^);{=!DsvZ=*Od*v20";
      j[1] = "R\u0002\b\u0017\u0001*R\u0002\u001fK\r%HI\u001fU\u0005&R\u0013Rv\u001c7U\b\u0012J";
      j[2] = "9d\u0005\u001c\u0016\\6$H\u0017\u001cA3yCQ\u0014\\>\u007fG\u001aWZ7zGQ\t_;sN\rW司桋栛佾伪桨栢伏佟栺";
      j[3] = "I48\u00158@Ftu\u001e2]C)~X!NF/sX>BZ6848@F?w\u0018\u0001NF/s";
      j[4] = "*;An)?%{\fe#\" &\u0007#+?- \u0003hh9$%\u0003#6<(,\n\u007fh伅伜厞伺叆桗厛厂伀伺";
      j[5] = "\u000bM~l\u001a\u001f?nq,W\u00145stq\\R=nywX\u0019~LrfA\u00105:";
      j[6] = "\u001b3uB3p\u0010<d\rOi\u001f&jNxY\t1fSiu\u001e<";
      j[7] = "7\u007fsy767\u007fd%;9-4d;3:7n)\u001c?&\u0014{w'31>";
      j[8] = "@\f'0G\u001e@\f0lK\u0011ZG$qX\u001bJG#vS\u0004\u0000!:jx\u0012]\u001c?j";
      j[9] = "*z\u0003$x)*z\u0014xt&01\u0000eg, 1\u0007bl3jW\u001e~G%7j\u001b~1\u0014=o\u0012";
      j[10] = "Qtt\u000b^6^49\u0000T+[i2F\\6Vo6\r\u001f伌佧发伏伽叺伌佧栋桋";
      j[11] = "[Q\tA_'T\u0011DJU:QLO\fF)TJB\fY%HS\tlE%ZZUtQ$MZ";
      j[12] = "F\u001c#\u0016::M\u00132Y[4F\u00186\u0003";
      j[13] = "<\u0002\nGsf=\u0005\u000b\u000b\u0018叏佘厯桼伪佅叏栜伱桼w\"ne\u0016\u000fGakf\u0000";
      j[14] = "i>p9fhh9qu\rkPlfgs{\"3c2u\u0002l)qwtp3,$q\r";
      j[15] = "GDG\u0000\u0006c\u0005\u001aC_\u007f佐去叢厾厡厼佐伥核厾b@hBC\u0004\f\u00026F\u001c";
      j[16] = "Z*\u0000\u0005\u001eK\r!F`\u0015$\u0006a\u0000^E$7a\u0005\u001dDKW)R]\u0016";
      j[17] = "8\\P\u0003A(p\u000b\u0010Qy&VP\u0017\u0004HuVa\u0010]Iyc^D\u0005\u0001u";
      j[18] = "\u000e+\u0002!dLY DDo#R`\u0002{>#cdC ?\u000e\u0004!A\u007f|";
      j[19] = "Be\u0004\u0014w\u001e\n2DFO\u0010,iC\u0013~F,XDJ\u007fO\u0019g\u0010\u00127C";
      j[20] = "x\u0006B(R>)\b\u001d)/J\u0002\"9\u001a/>%U\u0003$\u0011o+\n\u0002";
      j[21] = "Np\\U/iOw]\u0019D栚桮标台厦桝栚厴佃株e~a\u0017dYU=d\u0014r";
      j[22] = "\t |^\u001d\u0012\b'}\u0012v伥右伓低伳厵去佭伓叐nFC\u0000v~\tJ\u0014@t";
      j[23] = "C,\u001fZ\nRB+\u001e\u0016a佥厹伟厳伷厢校厹厁厳j[Z\u001a8\u001aZ\u0018_\u0019.";
      j[24] = "X6{5}v\u001c=(>\u0007mcc9;7t\b;-,g\u0012";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 友树树何何树树何何树.a ^ 12064182763023L;
      long ax = a ^ 116737586720573L;
      if (c<"Ý">(-7632619844296161198L, a) == null) {
         if (this.w(new Object[]{ax})) {
            return;
         }

         mc.player.setShiftKeyDown(false);
      }
   }

   private boolean j() {
      long a = 友树树何何树树何何树.a ^ 131465537370251L;
      long ax = a ^ 25588535863737L;
      c<"Ý">(-3416259759763550506L, a);
      return this.w(new Object[]{ax}) ? false : mc.player.getXRot() >= c<"Ò">(this, -3416917168506863356L, a).getValue().floatValue();
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void M() {
      long a = 友树树何何树树何何树.a ^ 104096153760078L;
      long ax = a ^ 68686080958588L;
      c<"Ý">(1824565762182268691L, a);
      if (!this.w(new Object[]{ax})) {
         if (!c<"Ò">(this, 1824327978281711560L, a).getValue() || mc.player.onGround()) {
            if (this.j()) {
               BlockPos blockBelow = BlockPos.containing(mc.player.getX(), mc.player.getY() - 1.0, mc.player.getZ());
               BlockState blockState = mc.level.getBlockState(blockBelow);
               if (blockState.getBlock() instanceof AirBlock && this.H()) {
                  c<"Ò">(c<"Ò">(mc, 1823982342300719452L, a), 1824028551896638352L, a).setDown(this.W() && !this.D(blockBelow));
               }
            }
         }
      }
   }

   private boolean W() {
      long a = 友树树何何树树何何树.a ^ 139373946744216L;
      long ax = a ^ 33081879084202L;
      c<"Ý">(5009138076705135557L, a);
      if (this.w(new Object[]{ax})) {
         return false;
      } else {
         HitResult hitResult = c<"Ò">(mc, 5009894476529637269L, a);
         return hitResult != null && hitResult.getType() == c<"Ð">(5010025324396550690L, a);
      }
   }

   private boolean H() {
      long a = 友树树何何树树何何树.a ^ 8681398934620L;
      long ax = a ^ 113463179578734L;
      c<"Ý">(8376820295855614465L, a);
      return this.w(new Object[]{ax}) ? false : !mc.player.getMainHandItem().isEmpty() && mc.player.getMainHandItem().getItem() instanceof BlockItem;
   }

   private static String HE_SHU_YOU() {
      return "何炜霖大狗叫";
   }
}
