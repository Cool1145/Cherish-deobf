package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.item.BlockItem;

public class 树树树何何何树何树何 extends Module implements 何树友 {
   private final NumberValue 何友何树友树友树树友;
   private final BooleanValue 何友何树友友友树树树;
   private final BooleanValue 何树友友树树友何树何;
   private int 何何树何何何何树何树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[20];
   private static final String[] k = new String[20];
   private static String LIU_YA_FENG;

   public 树树树何何何树何树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/player/树树树何何何树何树何.a J
      // 03: ldc2_w 74551931244968
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 22045
      // 0c: ldc2_w 7728880818072934779
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树何何何树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 25179
      // 19: ldc2_w 6837936917705878847
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树何何何树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 7314788997449909392
      // 26: lload 1
      // 27: invokedynamic ý (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/树树树何何何树何树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/NumberValue
      // 33: dup
      // 34: sipush 17112
      // 37: ldc2_w 7471103525999234488
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树何何何树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 11434
      // 44: ldc2_w 7500573083717673935
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树何何何树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: bipush 0
      // 4f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 52: bipush 0
      // 53: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 56: bipush 3
      // 57: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5a: bipush 1
      // 5b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5e: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 61: putfield cn/cool/cherish/module/impl/player/树树树何何何树何树何.何友何树友树友树树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 64: aload 0
      // 65: new cn/cool/cherish/value/impl/BooleanValue
      // 68: dup
      // 69: sipush 27285
      // 6c: ldc2_w 2054737634346853878
      // 6f: lload 1
      // 70: lxor
      // 71: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树何何何树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 76: sipush 32626
      // 79: ldc2_w 6593141884797251600
      // 7c: lload 1
      // 7d: lxor
      // 7e: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树何何何树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 83: bipush 0
      // 84: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 87: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 8a: putfield cn/cool/cherish/module/impl/player/树树树何何何树何树何.何友何树友友友树树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 8d: aload 0
      // 8e: new cn/cool/cherish/value/impl/BooleanValue
      // 91: dup
      // 92: sipush 30521
      // 95: ldc2_w 8760354262653565016
      // 98: lload 1
      // 99: lxor
      // 9a: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树何何何树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 9f: sipush 15425
      // a2: ldc2_w 3781541498920055590
      // a5: lload 1
      // a6: lxor
      // a7: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树何何何树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // ac: bipush 1
      // ad: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // b0: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // b3: putfield cn/cool/cherish/module/impl/player/树树树何何何树何树何.何树友友树树友何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // b6: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-5726291882924805295L, 9067823148239305658L, MethodHandles.lookup().lookupClass()).a(99877374913710L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 25956248241041L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[8];
      int var7 = 0;
      String var6 = "MÊÿ\u0097¶$\u001e¹\r\"g\f²\na,*6·[\u009aºERzªý\u00003\b 3õû.\u0010\u0084__§\u0010è\u0093mwÎ\u0001aõ\u001dFÀO\u001eD=\f\u0018Ò¾Ûvóúô\u008cá¢\u0099³*¨\u0013h\u0096¸½t\u001d\u0088&r(ÿ z\u0088\u0083o3` .\u0096\u001c';î\u0091zs\u0016[ÎÞv¬¿¤$hËáFt`£\u0092å\u001b¥ç\u0084\u0010\u0095I[«fêáy}ñëÇu¹Ï\t ?tZ\u0090´^iD6\u00adU*ÌãÑ\u0088ç\u001dR\\KpDh\nàPÛQD\"É";
      short var8 = 173;
      char var5 = '(';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[8];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "¥\u0013\u0097úÎ£\u0081µp\nú¯\u000b?7á\u0019·Á4\u008aS¡\u0089\u007f«i7lÐ*D\u0082·\u0015ì\u0004\u008e\u0003\u0007\u0016ú\u0004éx\u000fíÞõìº?×\u009fÝî I\u0098è]1q®°Öõ¿CóÜå\u0088¬\u0002c8I+xO7n\u0015lëëAú";
                  var8 = 89;
                  var5 = '8';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 树树树何何何树何树何.a ^ 11325818544602L;
      long ax = a ^ 131693188751469L;
      long axx = a ^ 48869803994330L;
      c<"ö">(6192989153236208073L, a);
      if (!this.w(new Object[]{axx})) {
         int var10000 = c<"ê">(this, 6192810157907021452L, a);
         Object[] var10003 = new Object[]{null, ax};
         var10003[0] = var10000;
         WrapperUtils.J(var10003);
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 49;
               case 1 -> 19;
               case 2 -> 41;
               case 3 -> 16;
               case 4 -> 39;
               case 5 -> 18;
               case 6 -> 44;
               case 7 -> 26;
               case 8 -> 36;
               case 9 -> 11;
               case 10 -> 8;
               case 11 -> 35;
               case 12 -> 60;
               case 13 -> 47;
               case 14 -> 45;
               case 15 -> 0;
               case 16 -> 62;
               case 17 -> 48;
               case 18 -> 57;
               case 19 -> 27;
               case 20 -> 14;
               case 21 -> 38;
               case 22 -> 56;
               case 23 -> 54;
               case 24 -> 22;
               case 25 -> 9;
               case 26 -> 53;
               case 27 -> 28;
               case 28 -> 32;
               case 29 -> 1;
               case 30 -> 43;
               case 31 -> 13;
               case 32 -> 50;
               case 33 -> 37;
               case 34 -> 5;
               case 35 -> 55;
               case 36 -> 52;
               case 37 -> 24;
               case 38 -> 15;
               case 39 -> 6;
               case 40 -> 17;
               case 41 -> 2;
               case 42 -> 4;
               case 43 -> 51;
               case 44 -> 29;
               case 45 -> 46;
               case 46 -> 58;
               case 47 -> 33;
               case 48 -> 3;
               case 49 -> 31;
               case 50 -> 25;
               case 51 -> 12;
               case 52 -> 23;
               case 53 -> 59;
               case 54 -> 7;
               case 55 -> 20;
               case 56 -> 10;
               case 57 -> 21;
               case 58 -> 30;
               case 59 -> 34;
               case 60 -> 42;
               case 61 -> 40;
               case 62 -> 61;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树何何何树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27361;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树何何何树何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树何何何树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 234 && var8 != 203 && var8 != 253 && var8 != 221) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'P') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 246) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 234) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 203) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 253) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "oK\u0007H\"x`\u000bJC(eeVA\u0005 xhPENc~aUE\u0005={m\\LYc栆栝栴佼佾优栆余栴佼";
      j[1] = ")\tv\rZE&I;\u0006PX#\u00140@CK&\u0012=@\\G:\u000bv,ZE&\u00029\u0000cK&\u0012=";
      j[2] = "`S^jk/o\u0013\u0013aa2jN\u0018'i/gH\u001cl*)nM\u001c't,bD\u0015{*伕佖叶伥参栕压又佨伥";
      j[3] = "KfQ=\u000by\u007fE^}FruX[ M4}EV&I\u007f>g]7Pvu\u0011";
      j[4] = "\u000e(\u001fn\u001cZ\u000e(\b2\u0010U\u0014c\u001c/\u0003_\u0004c\u00024\u0014^N\u0004\u001f%\u001c@";
      j[5] = "\u0002ic8\u001e\u0006\u0002itd\u0012\t\u0018\"`y\u0001\u0003\b\"~b\u0016\u0002BEcs\u001e";
      j[6] = "(.\u000e|0R'nCw:O\"3H1)\\'5E16P;,\u000eQ*P)%RI>Q>%";
      j[7] = "Su\u001eC\u0003xXz\u000f\f\u007faW`\u0001OHQAw\rRY}Vz";
      j[8] = "\rpSFE.\u00020\u001eMO3\u0007m\u0015\u000bG.\nk\u0011@\u0004伔伻叕伨佰叡伔伻栏桬";
      j[9] = int.class;
      k[9] = "java/lang/Integer";
      j[10] = "yBg|?zrMv3^tyFri";
      j[11] = "({^J\u0000\u001fpcM'佥核厈及栽栾叻佼桒佔$\\\u0003Gv3AW\u0005_";
      j[12] = "\u001dK\u0019H~\u001a\u0011SCN\u0013似口号只叵叐似佽栭只6.\u001e\u0010JDM\"\u0006JL";
      j[13] = "gV1GMs?N\"*伨伐栝佹伖佷伨桔余栽K\u0014\u001f*\u007fV)\u0014\u0014|c";
      j[14] = "/J^\u0007>-wRMjo\u0013q\u0007[[dr'@_\u0017\u0006.sG\u0015\bgx4CYj";
      j[15] = "0S\\OwzfOM\u001a\u0012j\t\u0013\u0010O~%lIENt\u0015";
      j[16] = "r F\u0002;u*8Uo佞厈佌桋叿厬叀桒栈桋<\u00148-,hY\u001f>5";
      j[17] = "\fgd\u001bOVZ{uN*栠叶叞叕桭栳佤栬叞佋t\u0013CGrs\u001bE_V'";
      j[18] = "\u001a\nw\u001d2&N\u000f0\u001a]uwK7Wc ww5\u0000$yI\u0011v\u0015d\"";
      j[19] = "B\u00180J)D\u001a\u0000#'佌厹佼桳厉栾叒档核厩J\u001bl\u0016MR)\u0019-\u001bD";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   @EventTarget
   public void p(TickEvent event) {
      long a = 树树树何何何树何树何.a ^ 43633329916414L;
      long ax = a ^ 99118852163657L;
      long axx = a ^ 1725252224254L;
      long axxx = a ^ 57230505879586L;
      c<"ö">(4455686421268177389L, a);
      if (!this.w(new Object[]{axx})
         && (c<"ý">(4454707988156752273L, a) == null || !c<"ý">(4454707988156752273L, a).isEnabled() || !c<"ê">(this, 4454678325623353099L, a).getValue())) {
         if (mc.player.getMainHandItem().getItem() != c<"ý">(4454830968131418385L, a)
               && mc.player.getOffhandItem().getItem() != c<"ý">(4454830968131418385L, a)
            || !c<"ê">(this, 4455412027789631717L, a).getValue()) {
            if ((mc.player.getMainHandItem().getItem() instanceof BlockItem || mc.player.getOffhandItem().getItem() instanceof BlockItem)
               && WrapperUtils.r(new Object[]{axxx}) != 0) {
               int var10000 = c<"ê">(this, 4454852266281832935L, a).getValue().intValue();
               Object[] var10003 = new Object[]{null, ax};
               var10003[0] = var10000;
               WrapperUtils.J(var10003);
            }
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 树树树何何何树何树何.a ^ 83642513220157L;
      long ax = a ^ 116737586720573L;
      long axx = a ^ 105212279882721L;
      c<"ö">(-7631722797926970834L, a);
      if (!this.w(new Object[]{ax})) {
         c<"Ë">(this, WrapperUtils.r(new Object[]{axx}), -7631896741467959957L, a);
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_WEI_LIN() {
      return "何炜霖大狗叫";
   }
}
