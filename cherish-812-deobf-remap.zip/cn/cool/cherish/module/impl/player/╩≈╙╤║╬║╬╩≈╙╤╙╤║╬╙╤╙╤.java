package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树友何何树友友何友友 extends Module implements 何树友 {
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[9];
   private static final String[] k = new String[9];
   private static int _何炜霖国企上班 _;

   public 树友何何树友友何友友() {
      super("NoClickDelay", "无点击延迟", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-9017690398480870589L, 5393646438247952171L, MethodHandles.lookup().lookupClass()).a(247098078462146L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(119843978950239L << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = ' ';
      int var4 = -1;

      while (true) {
         String var13 = c(
               var2.doFinal(
                  "\u0099(µQ?4ù3!9\u009cºSï\u001a\u009d\u000fë5Ä\u0002\u0011\u0010¾I*Í\u0000 ï\u0088n 7RM\u0015i®Óè\u00865à\u008b÷qìõ\t©\u008f\u0097-\f\u0004ÊÓ]äÅäYÃ\u0089"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 65) {
            c = var9;
            h = new String[2];
            return;
         }

         var5 = "\u0099(µQ?4ù3!9\u009cºSï\u001a\u009d\u000fë5Ä\u0002\u0011\u0010¾I*Í\u0000 ï\u0088n 7RM\u0015i®Óè\u00865à\u008b÷qìõ\t©\u008f\u0097-\f\u0004ÊÓ]äÅäYÃ\u0089"
            .charAt(var4);
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   @EventTarget
   public void e(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (mc.player != null && mc.level != null) {
         WrapperUtils.d(0, 24928558720942L);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 24;
               case 1 -> 35;
               case 2 -> 49;
               case 3 -> 5;
               case 4 -> 10;
               case 5 -> 56;
               case 6 -> 4;
               case 7 -> 20;
               case 8 -> 36;
               case 9 -> 37;
               case 10 -> 3;
               case 11 -> 39;
               case 12 -> 44;
               case 13 -> 60;
               case 14 -> 13;
               case 15 -> 25;
               case 16 -> 34;
               case 17 -> 53;
               case 18 -> 12;
               case 19 -> 61;
               case 20 -> 40;
               case 21 -> 55;
               case 22 -> 21;
               case 23 -> 50;
               case 24 -> 7;
               case 25 -> 29;
               case 26 -> 57;
               case 27 -> 1;
               case 28 -> 15;
               case 29 -> 0;
               case 30 -> 58;
               case 31 -> 54;
               case 32 -> 38;
               case 33 -> 62;
               case 34 -> 9;
               case 35 -> 30;
               case 36 -> 19;
               case 37 -> 45;
               case 38 -> 31;
               case 39 -> 14;
               case 40 -> 41;
               case 41 -> 52;
               case 42 -> 48;
               case 43 -> 63;
               case 44 -> 11;
               case 45 -> 43;
               case 46 -> 16;
               case 47 -> 26;
               case 48 -> 23;
               case 49 -> 27;
               case 50 -> 33;
               case 51 -> 42;
               case 52 -> 46;
               case 53 -> 18;
               case 54 -> 22;
               case 55 -> 32;
               case 56 -> 17;
               case 57 -> 51;
               case 58 -> 6;
               case 59 -> 59;
               case 60 -> 28;
               case 61 -> 47;
               case 62 -> 8;
               default -> 2;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友何何树友友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2867;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树友何何树友友何友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友何何树友友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'u' && var8 != 202 && var8 != 246 && var8 != 'o') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 216) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 230) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'u') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 246) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = ")hTF\u0016\u000e&(\u0019M\u001c\u0013#u\u0012\u000b\u0014\u000e.s\u0016@W\b'v\u0016\u000b\t\r+\u007f\u001fWW桰厁体伯叮伬桰伟栗厱";
      j[1] = "c\u0000\tj\u007fEW#\u0006*2N]>\u0003w9\bU#\u000eq=C\u0016\u0001\u0005`$J]w";
      j[2] = "g&\u001d\u0017\u0007{hfP\u001c\rfm;[Z\u0005{`=_\u0011F}i8_Z\u0018xe1V\u0006F栅叏伝佦桥厣叟佑厃司";
      j[3] = "PK\u0005w=+[D\u00148A2T^\u001a{v\u0002BI\u0016fg.UD";
      j[4] = ">$1\u0004\u001aF1d|\u000f\u0010[49wI\u0018F9?s\u0002[核伈厁叔伲桤叢厖伟佊";
      j[5] = "h\u0015w|z7c\u001af3\u001b9h\u0011bi";
      j[6] = "\u0018}=*~N\u0001*.HO\u007fB}o03\u001d\u0010s-p\u0002";
      j[7] = "^\u0014\"]\u0004B\u0019\u0001/]\u007f叽桽桿厝佸厼佣桽厥桇%EL\u0018\u001e%Y\u0002Y\u0015\u001e";
      j[8] = "]nWWG__zB\u0005yId+\u0013\u0004\u0013M\u0007nL\u0004\u0016 ^.\u0016T\u0014C\u001bq\u0016Qy";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_WEI_LIN() {
      return "解放村多种2队1144号";
   }
}
