package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class 何树何友何何树树树友 extends Module implements 何树友 {
   private final ModeValue 友树树何树友何何友树;
   private final ModeValue 何树树友何何友树友树;
   private final ModeValue 友友友树树何何何树友;
   private final ModeValue 友何何何友友友树树友;
   private final ModeValue 何树何何树友树何何树;
   private final 友树何树友友何树友友 友友树何树友何友何何;
   private final 友树何树友友何树友友 何友树树友友树树何何;
   private final BooleanValue 友树何友何何何友友友;
   private boolean 友何友友何何树树树何;
   private int 树友友何友何何树树友;
   private static final float 树友友友何友何友友树 = 0.8F;
   private static final float 树树树友树何树友树友 = 0.1F;
   private static final double 树何树何友树友何树何 = 16.0;
   private String 树何何树友何何树树友;
   树友树友友何何树何何 何友树友树友树何友树;
   树友树友友何何树何何 友树树树树树何树何树;
   private Player 树树友树何树何友树树;
   private int 友友树友何何树何友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[40];
   private static final String[] n = new String[40];
   private static String LIU_YA_FENG;

   public 何树何友何何树树树友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/何树何友何何树树树友.a J
      // 003: ldc2_w 44857519556461
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 36889390242856
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 25100
      // 014: ldc2_w 5220500226518538067
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 18701
      // 021: ldc2_w 408834944092339294
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -5213082576752061398
      // 02e: lload 1
      // 02f: invokedynamic F (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/ModeValue
      // 03b: dup
      // 03c: sipush 14659
      // 03f: ldc2_w 84020973482642462
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 11292
      // 04c: ldc2_w 2029031296007870802
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 2
      // 057: anewarray 101
      // 05a: dup
      // 05b: bipush 0
      // 05c: sipush 19772
      // 05f: ldc2_w 1937555121329141885
      // 062: lload 1
      // 063: lxor
      // 064: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 069: aastore
      // 06a: dup
      // 06b: bipush 1
      // 06c: sipush 4899
      // 06f: ldc2_w 8975337415901423218
      // 072: lload 1
      // 073: lxor
      // 074: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 079: aastore
      // 07a: sipush 4899
      // 07d: ldc2_w 8975337415901423218
      // 080: lload 1
      // 081: lxor
      // 082: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 087: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 08a: putfield cn/cool/cherish/module/impl/player/何树何友何何树树树友.友树树何树友何何友树 Lcn/cool/cherish/value/impl/ModeValue;
      // 08d: aload 0
      // 08e: new cn/cool/cherish/value/impl/ModeValue
      // 091: dup
      // 092: sipush 8092
      // 095: ldc2_w 3864321557598841550
      // 098: lload 1
      // 099: lxor
      // 09a: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09f: sipush 1862
      // 0a2: ldc2_w 3346633112309412380
      // 0a5: lload 1
      // 0a6: lxor
      // 0a7: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ac: bipush 2
      // 0ad: anewarray 101
      // 0b0: dup
      // 0b1: bipush 0
      // 0b2: sipush 19772
      // 0b5: ldc2_w 1937555121329141885
      // 0b8: lload 1
      // 0b9: lxor
      // 0ba: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bf: aastore
      // 0c0: dup
      // 0c1: bipush 1
      // 0c2: sipush 11784
      // 0c5: ldc2_w 8880602280964365167
      // 0c8: lload 1
      // 0c9: lxor
      // 0ca: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0cf: aastore
      // 0d0: sipush 19772
      // 0d3: ldc2_w 1937555121329141885
      // 0d6: lload 1
      // 0d7: lxor
      // 0d8: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0dd: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 0e0: putfield cn/cool/cherish/module/impl/player/何树何友何何树树树友.何树树友何何友树友树 Lcn/cool/cherish/value/impl/ModeValue;
      // 0e3: aload 0
      // 0e4: new cn/cool/cherish/value/impl/ModeValue
      // 0e7: dup
      // 0e8: sipush 1493
      // 0eb: ldc2_w 1634422356551839901
      // 0ee: lload 1
      // 0ef: lxor
      // 0f0: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f5: sipush 11928
      // 0f8: ldc2_w 3225717580006595535
      // 0fb: lload 1
      // 0fc: lxor
      // 0fd: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 102: bipush 2
      // 103: anewarray 101
      // 106: dup
      // 107: bipush 0
      // 108: sipush 19772
      // 10b: ldc2_w 1937555121329141885
      // 10e: lload 1
      // 10f: lxor
      // 110: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 115: aastore
      // 116: dup
      // 117: bipush 1
      // 118: sipush 4899
      // 11b: ldc2_w 8975337415901423218
      // 11e: lload 1
      // 11f: lxor
      // 120: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 125: aastore
      // 126: sipush 4899
      // 129: ldc2_w 8975337415901423218
      // 12c: lload 1
      // 12d: lxor
      // 12e: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 133: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 136: putfield cn/cool/cherish/module/impl/player/何树何友何何树树树友.友友友树树何何何树友 Lcn/cool/cherish/value/impl/ModeValue;
      // 139: aload 0
      // 13a: new cn/cool/cherish/value/impl/ModeValue
      // 13d: dup
      // 13e: sipush 24123
      // 141: ldc2_w 1870706293541661558
      // 144: lload 1
      // 145: lxor
      // 146: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14b: sipush 24800
      // 14e: ldc2_w 9039619173909976451
      // 151: lload 1
      // 152: lxor
      // 153: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 158: bipush 2
      // 159: anewarray 101
      // 15c: dup
      // 15d: bipush 0
      // 15e: sipush 19772
      // 161: ldc2_w 1937555121329141885
      // 164: lload 1
      // 165: lxor
      // 166: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16b: aastore
      // 16c: dup
      // 16d: bipush 1
      // 16e: sipush 4899
      // 171: ldc2_w 8975337415901423218
      // 174: lload 1
      // 175: lxor
      // 176: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 17b: aastore
      // 17c: sipush 4899
      // 17f: ldc2_w 8975337415901423218
      // 182: lload 1
      // 183: lxor
      // 184: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 189: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 18c: putfield cn/cool/cherish/module/impl/player/何树何友何何树树树友.友何何何友友友树树友 Lcn/cool/cherish/value/impl/ModeValue;
      // 18f: aload 0
      // 190: new cn/cool/cherish/value/impl/ModeValue
      // 193: dup
      // 194: sipush 20658
      // 197: ldc2_w 2174523775356265963
      // 19a: lload 1
      // 19b: lxor
      // 19c: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1a1: sipush 26414
      // 1a4: ldc2_w 6541334060306223728
      // 1a7: lload 1
      // 1a8: lxor
      // 1a9: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ae: bipush 3
      // 1af: anewarray 101
      // 1b2: dup
      // 1b3: bipush 0
      // 1b4: sipush 19772
      // 1b7: ldc2_w 1937555121329141885
      // 1ba: lload 1
      // 1bb: lxor
      // 1bc: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c1: aastore
      // 1c2: dup
      // 1c3: bipush 1
      // 1c4: sipush 4899
      // 1c7: ldc2_w 8975337415901423218
      // 1ca: lload 1
      // 1cb: lxor
      // 1cc: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1d1: aastore
      // 1d2: dup
      // 1d3: bipush 2
      // 1d4: sipush 11784
      // 1d7: ldc2_w 8880602280964365167
      // 1da: lload 1
      // 1db: lxor
      // 1dc: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e1: aastore
      // 1e2: sipush 4899
      // 1e5: ldc2_w 8975337415901423218
      // 1e8: lload 1
      // 1e9: lxor
      // 1ea: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ef: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 1f2: putfield cn/cool/cherish/module/impl/player/何树何友何何树树树友.何树何何树友树何何树 Lcn/cool/cherish/value/impl/ModeValue;
      // 1f5: aload 0
      // 1f6: new cn/cool/cherish/value/impl/友树何树友友何树友友
      // 1f9: dup
      // 1fa: sipush 3953
      // 1fd: ldc2_w 5753515225270204979
      // 200: lload 1
      // 201: lxor
      // 202: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 207: sipush 10637
      // 20a: ldc2_w 1616561589917392066
      // 20d: lload 1
      // 20e: lxor
      // 20f: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 214: sipush 10211
      // 217: ldc2_w 4169526721814336182
      // 21a: lload 1
      // 21b: lxor
      // 21c: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 221: invokespecial cn/cool/cherish/value/impl/友树何树友友何树友友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
      // 224: aload 0
      // 225: invokedynamic get (Lcn/cool/cherish/module/impl/player/何树何友何何树树树友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/player/何树何友何何树树树友.U ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 22a: invokevirtual cn/cool/cherish/value/impl/友树何树友友何树友友.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 22d: checkcast cn/cool/cherish/value/impl/友树何树友友何树友友
      // 230: putfield cn/cool/cherish/module/impl/player/何树何友何何树树树友.友友树何树友何友何何 Lcn/cool/cherish/value/impl/友树何树友友何树友友;
      // 233: aload 0
      // 234: new cn/cool/cherish/value/impl/友树何树友友何树友友
      // 237: dup
      // 238: sipush 16995
      // 23b: ldc2_w 7475851813369902901
      // 23e: lload 1
      // 23f: lxor
      // 240: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 245: sipush 23573
      // 248: ldc2_w 630185720002636105
      // 24b: lload 1
      // 24c: lxor
      // 24d: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 252: sipush 6473
      // 255: ldc2_w 8883110161269599261
      // 258: lload 1
      // 259: lxor
      // 25a: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 25f: invokespecial cn/cool/cherish/value/impl/友树何树友友何树友友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
      // 262: aload 0
      // 263: invokedynamic get (Lcn/cool/cherish/module/impl/player/何树何友何何树树树友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/player/何树何友何何树树树友.i ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 268: invokevirtual cn/cool/cherish/value/impl/友树何树友友何树友友.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 26b: checkcast cn/cool/cherish/value/impl/友树何树友友何树友友
      // 26e: putfield cn/cool/cherish/module/impl/player/何树何友何何树树树友.何友树树友友树树何何 Lcn/cool/cherish/value/impl/友树何树友友何树友友;
      // 271: aload 0
      // 272: new cn/cool/cherish/value/impl/BooleanValue
      // 275: dup
      // 276: sipush 3965
      // 279: ldc2_w 5793252542797101606
      // 27c: lload 1
      // 27d: lxor
      // 27e: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 283: sipush 13925
      // 286: ldc2_w 12790366656693033
      // 289: lload 1
      // 28a: lxor
      // 28b: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 290: bipush 1
      // 291: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 294: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 297: putfield cn/cool/cherish/module/impl/player/何树何友何何树树树友.友树何友何何何友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 29a: aload 0
      // 29b: bipush 0
      // 29c: ldc2_w -5212849355857636932
      // 29f: lload 1
      // 2a0: invokedynamic Þ (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2a5: aload 0
      // 2a6: bipush 0
      // 2a7: ldc2_w -5211816363754616683
      // 2aa: lload 1
      // 2ab: invokedynamic Þ (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2b0: aload 0
      // 2b1: aconst_null
      // 2b2: ldc2_w -5213044218300571905
      // 2b5: lload 1
      // 2b6: invokedynamic Þ (Ljava/lang/Object;Ljava/lang/String;JJ)V bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2bb: aload 0
      // 2bc: new cn/cool/cherish/utils/树友树友友何何树何何
      // 2bf: dup
      // 2c0: lload 3
      // 2c1: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 2c4: ldc2_w -5213444789803829907
      // 2c7: lload 1
      // 2c8: invokedynamic Þ (Ljava/lang/Object;Lcn/cool/cherish/utils/树友树友友何何树何何;JJ)V bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2cd: aload 0
      // 2ce: new cn/cool/cherish/utils/树友树友友何何树何何
      // 2d1: dup
      // 2d2: lload 3
      // 2d3: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 2d6: ldc2_w -5212925958945558797
      // 2d9: lload 1
      // 2da: invokedynamic Þ (Ljava/lang/Object;Lcn/cool/cherish/utils/树友树友友何何树何何;JJ)V bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2df: aload 0
      // 2e0: aconst_null
      // 2e1: ldc2_w -5213376727352922765
      // 2e4: lload 1
      // 2e5: invokedynamic Þ (Ljava/lang/Object;Lnet/minecraft/world/entity/player/Player;JJ)V bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2ea: aload 0
      // 2eb: bipush 0
      // 2ec: ldc2_w -5213257042786470706
      // 2ef: lload 1
      // 2f0: invokedynamic Þ (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/何树何友何何树树树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2f5: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(3103107465143737805L, 3124674858855723769L, MethodHandles.lookup().lookupClass()).a(161920568584345L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 46368029397153L;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[40];
      int var18 = 0;
      String var17 = "v{XÌ\u0090tÑæ<Î\\ _Ø¶v qØÏ5Ú\u000fëJ\u0088# `\u00003Á:w¸¼a^îxù÷\u0016\u0019\u007fG©G\r(bõåu¶:gU6\u0007¥\u008bÒO'(ÒÍ~á-\f\u008eLj³P,½P\u0019¾\u001câ(îÇ\u0098fð(E\u008b3\u009d×ó\u000f¶Ø_\u0097÷R\u0006qaÐá7Á«\u001fÈM2\u0083@å{í\u0019×æ¤T÷}lúÆ(º\u0093BçAºû\u0084\u0005éèûV¤ù{`Æúßê°ê-¹}ÞZw\u0089²\u0000\u00817çÍ¬<\u001cÅ(b\u0082¥=n\u008a\u0011ÊÝè\u001e\u001b#²\u0087\u009c\u0083\u0091\u008d3\u008f\t\u0017\u0095w\u0098sÛT8q6\u0012\u001d\u001c*>:«\u0087\u0010ÔÍÆ¤:\u0012¼&\u008dÂ\u0085È\u0096¿\u0080\u0019\u0010·`g´ô¸;<l~\u008bêðØ$\u0098\u0018\u0015¹,^u?Ë\u0001K·¸§\u0094¢\u000fAMÀ}ô\u008dÌ÷28ÛÛDfåç\u008cã÷«o\u0094â\"jÀj\u0094î\u00122p\\\u0081ÛðØy®Ú&ïkv\u008b\u0004ýiOZSÙ¡JE¨ÿw\u0091ÕU60\u0085¼@ ï÷hË\u0013[y~\u0019>\"#|=ë98è/Þ§â\u0084\u008b\u0012/+©=áA²(æ\tãá\u001bO8?5iQ©x¡DÇ3\tî\u0097DúôýÙN\u0081Ebd5¨ÞÑ\u0018¢CDËf\u0010?.ÒùùJö\\ÎÒØ\u0094ÞóüC0Að5«È>í¦è3¬O\u001b²%q\u009e\u0003T\u000f_G¾\u0000Ìs\u0081PYC·\u009d^\u0080äjÉé\u0011?Ï¡±[6'éô0\u001d²©\u0006¿Òè\t\u0013¡ºz×>É\u000fåz{¬È3|\f0µL3nyÑ \u0016Ò\u0084^\u0082\u0015O/³A£eù(Ú)(®7 ^¨!J\u008fX\u0084\u008fÆP\u009eOöìr\u007f\u0015M.\u001d\u0087É\u000b\u0013ð\u0097>\u008e×\u0010\u0007íEê'V\u000e(l\u0086\t&]U\u0085´\u009d\u0082¥êªÍ1\u0000ÆZÇ®Vª,Nb³Ê\u0002ü)£Þ4üèD\u0083þ?\u0098 åÊ69\u0091³ÄÇç\u009dV7\u0015U\u0082äÝJÆ-ýâÂC±\u0097\u008bömì2\f\u0018Æ3\u0090QU\u0018ç\u000bMz\u0012÷\u008f\\^ò&á8xÅ=\u001dÆ ý!û9\u001fµpùµ\u008e\u00945\u0002ê§`Ò}\u0096\u0082Vö\u009eg\u008d,o\b=DÄD(Yé¿¸\u0018\u0017¹VnÅ¼#â9¤®¨W{ÆkR\u0013Ñ@÷_\u001f9Wòyüq8¯ºE*\u0080 ÿÔÑ\"\"¹ÿÕ8kêî\b\u0087ÆO\u0088Ö§>-\u008fT\u009d²å1\u0095g ¼v\u0010\u009eª?\u0095¢ý\u0018é^®Of\u0010¢u\u0006 ÿ\u001dyú¼\u008dGÐ\u009b?\u009eJÉ\u0014o\u0016ÕÄ\u0016\u0017\u0092\u009b!\u008fÏf\u0004\u00874\u0002¥\u00880åó¹¦\u000fÚ\n\u009b·@V·¥?\u0017\u0007\u0092;ë\u0094\u0005¼ë£Þñÿì9Bý6\u0097\u0092iÒmU\nÝÉ¤ñh«ºÇt(æûî7\u0012\u001a_\u0092\r#Uy\u0094¤\u000e`y½Î9[\u009a\u0013 ´\u009e\u0019ÜÝ¥ÃÉ\u0004Ï,\u0019q¿\u0096ó0ü\u0095èäL\u0095\u0090\u0001(0ß\u0094d\u0019\u0017ÒÄ\t£+²|äç\rë\u0001\u001dº´\u0010Ö_±Ñ!\u008e²vñJ7ûï\u001dìR+(_\u0007ÇÝa\u009b!\u001fZòÄaÃ}|^\u0004Ö\u0093Íî\u008f\u009cLr\u009d\u0019Ý{9\u0014p\u0096?^?<+ãf Ë\u0098°³|o2 \u0085\u0099û´Wíö\u0092ï@\u0094ÞÑçøÛ<µ\u0017P\u009es[å yMóä\u0006k_\u0014kC`\baoUl\u0007\u0091'\n\u0003ÌÛ.\u001agÀ\u0006[\u009eÏ\r\u0018O%[T<Ýû\u007fï\u0097w¥\u001d\u009e+<¥èI\u0081Tâ£°0Z>ô\bÅ$÷\u009f\u008e\u000b»¼\u0092\u000b\"ß>\u0012J*TKÖ\u009aãa\u0090\u001c@\u0082\u000e}u\u001eFº×q\u009e\u0081\u009a7kC\u0085'Ý\u0096\u0010\u008dá?Â\u0001|¸[*\u008d\u0001\u0096\u0084\u001bo§ ¥¤\u001d` êí«Ë]9\u0094¦N\u008cBikÿçþð\u0013\u0014ç\u0001û×\u008f³ãÁ\u0018Ñ\u0006¡K©Ò\u0086¸ÞS¬`\u008e]b°\u0013xíÅ:(¿8\u0010PÆ³¤¡¥\u001ejë \u0095\u0018Õ².Ë\u0018¥|[Ò\u0005²L|\u008e1´èpâ \u0081ÂÅU\u0091\u0092\u0091% \u0018`\u0095+¨Gð\u000b\u0092ø\u008e\u0002¾T\u001f:ãÙÁ½Ð\u0089\u0095\u0088k";
      short var19 = 1277;
      char var16 = 16;
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[40];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0018\nïU\t2\b#\u0012S²\"2~tD".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "\r9µ\u0091\u0087@7bÙ\u0086ág\u0007«\u0091\u0092ñ¦tÍ$/²Nbî1Î\u001eYå-³;Ä\fý¡\u0092F\u0010 u\u0090±j·ýY\u0004¦,\u0087\u00129\u0093¸";
                  var19 = 57;
                  var16 = '(';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 何树何友何何树树树友.a ^ 37182690436400L;
      long ax = a ^ 65491710804242L;
      long axx = a ^ 100230587165177L;
      d<"y">(6193822419934445010L, a);
      cn.cool.cherish.utils.树友树友树树何何树何.T(axx, b<"n">(30346, 7875955903973269905L ^ a));
      if (d<"¥">(this, 6195408248464522402L, a) != null) {
         cn.cool.cherish.utils.树友树友树树何何树何.l(d<"¥">(this, 6195408248464522402L, a), ax);
         d<"Þ">(this, null, 6195408248464522402L, a);
      }
   }

   private void I() {
      long a = 何树何友何何树树树友.a ^ 51515652623188L;
      long ax = a ^ 132407524550707L;
      String baseDir = d<"¥">(Cherish.getResourcesManager(), -4930508062907023848L, a).getAbsolutePath() + b<"n">(17964, 7895810058631708532L ^ a);
      d<"y">(-4931178088761912394L, a);
      String mode = d<"¥">(this, -4930695935593962420L, a).getValue();
      byte var9 = -1;
      switch (mode.hashCode()) {
         case -1492564645:
            if (mode.equals(b<"n">(11784, 8880600039669339990L ^ a))) {
               var9 = 0;
            }
         default:
            switch (var9) {
               case 0:
                  d<"Þ">(this, d<"¥">(this, -4926994886009243401L, a) + 1, -4926994886009243401L, a);
                  int soundIndex = (d<"¥">(this, -4926994886009243401L, a) - 1) % 5 + 1;
                  cn.cool.cherish.utils.树友树友树树何何树何.I(
                     baseDir + b<"n">(7101, 7743665525685101281L ^ a) + soundIndex + b<"n">(11636, 6647229288658474027L ^ a), ax, 0.8F
                  );
                  if (d<"¥">(this, -4926994886009243401L, a) % 5 == 0) {
                  }
            }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 17;
               case 1 -> 18;
               case 2 -> 38;
               case 3 -> 15;
               case 4 -> 48;
               case 5 -> 11;
               case 6 -> 8;
               case 7 -> 25;
               case 8 -> 40;
               case 9 -> 60;
               case 10 -> 43;
               case 11 -> 3;
               case 12 -> 35;
               case 13 -> 28;
               case 14 -> 29;
               case 15 -> 58;
               case 16 -> 31;
               case 17 -> 42;
               case 18 -> 24;
               case 19 -> 47;
               case 20 -> 2;
               case 21 -> 50;
               case 22 -> 0;
               case 23 -> 13;
               case 24 -> 33;
               case 25 -> 30;
               case 26 -> 14;
               case 27 -> 59;
               case 28 -> 61;
               case 29 -> 36;
               case 30 -> 32;
               case 31 -> 55;
               case 32 -> 34;
               case 33 -> 51;
               case 34 -> 5;
               case 35 -> 57;
               case 36 -> 7;
               case 37 -> 39;
               case 38 -> 44;
               case 39 -> 9;
               case 40 -> 49;
               case 41 -> 22;
               case 42 -> 6;
               case 43 -> 12;
               case 44 -> 21;
               case 45 -> 10;
               case 46 -> 26;
               case 47 -> 54;
               case 48 -> 23;
               case 49 -> 16;
               case 50 -> 4;
               case 51 -> 53;
               case 52 -> 62;
               case 53 -> 56;
               case 54 -> 27;
               case 55 -> 37;
               case 56 -> 52;
               case 57 -> 46;
               case 58 -> 41;
               case 59 -> 19;
               case 60 -> 1;
               case 61 -> 45;
               case 62 -> 20;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树何友何何树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 745;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何树何友何何树树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 165 && var8 != 222 && var8 != 'F' && var8 != 'm') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 237) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'y') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 165) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 222) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'F') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 18250;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何树何友何何树树树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树何友何何树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   @EventTarget
   public void f(AttackEvent event) {
      long a = 何树何友何何树树树友.a ^ 35534451967062L;
      long ax = a ^ 50520159129020L;
      d<"y">(8400023835996839092L, a);
      if (!this.w(new Object[]{ax})) {
         d<"Þ">(this, true, 8400116813737529991L, a);
         if (event.getTarget() instanceof Player player
            && player != mc.player
            && !d<"¥">(this, 8399398711422774094L, a).C(b<"n">(19772, 1937564354197601094L ^ a))) {
            d<"Þ">(this, player, 8402966905726496328L, a);
         }
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树何友何何树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      m[0] = "dv\f?Hek6A4BxnkJrJecmN9\tcjhNrWffaG.\t佟栖位叩伉佲栛栖栉叩";
      m[1] = "Uk.\"IJUk9~EEO -cVO_ ?bPJOwt|HBBk(\"tOZw?~";
      m[2] = int.class;
      n[2] = "java/lang/Integer";
      m[3] = "57XiAj:w\u0015bKw?*\u001e$Cj2,\u001ao\u0000l;)\u001a$^i7 \u0013x\u0000佐伃厒伣叁栿収厝伌伣";
      m[4] = "Xy\t\u00071blZ\u0006G|ifG\u0003\u001aw/nZ\u000e\u001csd-x\u0005\rjmf\u000e";
      m[5] = "|\u0004C)NnsD\u000e\"Dsv\u0019\u0005dW`s\u001f\bdHlo\u0006C\u0007Nez<\f&Td";
      m[6] = "_?N|4\u0007T0_3H\u001e[*Qp\u007f.M=]mn\u0002Z0";
      m[7] = "2XQ\u0004_\u0015=\u0018\u001c\u000fU\b8E\u0017IF\u001b=C\u001aIY\u0017!ZQ%_\u0015=S\u001e\tf\u001b=C\u001a";
      m[8] = "`d\u001eW@\u0002o$S\\J\u001fjyX\u001aZ\u0019jfC\u001a]\bpeEFL\bp$bQ\\\u0002vxSQ\\ bdQSJ\u001f";
      m[9] = "\u000e)7\u0012\u0000k\u000bf\u0007\u001aBg";
      m[10] = "&W\u000b-;=&W\u001cq72<\u001c\u001co?1&FQs:51W\r-\u001a;+S\u0013S:51W\r";
      m[11] = "\u007fIm}\u0012U\u007fIz!\u001eZe\u0002Z;\u001eHWCk>\u001eHeEw4";
      m[12] = "kbHep_d\"\u0005nzBa\u007f\u000e(iQdy\u0003(v]x`H反栎佥栙叇厭体栎叻參";
      m[13] = boolean.class;
      n[13] = "java/lang/Boolean";
      m[14] = "8.;G~Q3!*\b\u0003I &#A";
      m[15] = "?\u0016\u0016O\u001d\u00130V[D\u0017\u000e5\u000bP\u0002\u0007\b5\u0014K\u0002档厷桍厳右佹伧桭伉伭";
      m[16] = "Q[e\fR@^\u001b(\u0007X][F#AP@V@'\n\u0013佺佧叾伞伺叶佺佧栤桚";
      m[17] = "wu+6Z<|z:y;2wq>#";
      m[18] = "4 B\u0017\t,#yDn佬桅桊叝佺伳史桅厐标'UT72s\u001cVU?<";
      m[19] = "Q\u0017\f}z~FN\n\u0004桛反叵佴厪余伟栗栯只i==5\b\u0013\u0000jz\u007fY";
      m[20] = "\u0019VqjRR\u000e\u000fw\u0013厩栻伣厫佉低伷叡厽厫\u0014.PC\u0007\n~n\bK\u0007";
      m[21] = "NB\u0010+\u000er\u000b\u0000\u00180vs\u001d\u0004\r0\fb\u001d\u0004js\u0013jJ\u0006\u0011?Jl@";
      m[22] = "e>a\nrPbldI\u0018\u0002\r;6\f)S\r\u0002>L#R`ki\u000bi\u0003";
      m[23] = ".\u001e\u0006~'*9G\u0000\u0007叜桃桐佽桺叄佂伇厊根c<z1(MX?{9&";
      m[24] = "\u0011u/Q!,A0{^O\tcF\u001e\u001f0b_daOu6P";
      m[25] = "D\u001b\b\n[\bSB\u000es厠去叠格桴伮伾伥栺另mH\u0006\u0013BHVK\u0007\u001bL";
      m[26] = "AS|K!\u001cV\nz2佄厯栿桴叚叱栀桵佻估\u0019\u0002fU\u0018\u0004v]'\u000bM";
      m[27] = ".\u001cr\u001ed\u001elB*\u001e\u0014\u001b\u0014\u00190VkUt_,\u0013md";
      m[28] = "I\u0002!*\u0000\u000f^['S叻伢叭叿伙伎校桦样佡DbW\u0000GD::J\u0002H";
      m[29] = "z|dt#\u000em%b\r但桧佀伟栘収栂伣佀桛\u00016~\u0015|/:5\u007f\u001dr";
      m[30] = "\u0007M{y\"1\u0010\u0014}\u0000sA\\B~}v Z\u0012qo\u001a}Q\u0013cl{{\u0001\u001cq\u0000";
      m[31] = "z)\u0013\u0003O\u0018}{\u0016@%J\u0012/M\u000b\u001c\u001a\u0012\u0015LE\u001e\u001a\u007f|\u001b\u0002TK";
      m[32] = "\u0003T.\u0011^5\u0014\r(h厥历桽伷桒厫伻历伹伷KX\u0019|Z\u0003$\u0007X\"\u000f";
      m[33] = "G-\u0007&\u001e\u0007J=\u0015f.伱叮厔厸叙叭伱佰桎厸\u001aD\u0016QkKqI\u0006C+";
      m[34] = "\u0017#N`\u0000V\u0000zH\u0019校佻伭栄叨佄佥栿桩叞+pQB\r,I'\u0003L\u001a";
      m[35] = "&l\"&Ce15$_厸栌桘桋桞框伦栌伜桋G5B~//.nK/q";
      m[36] = "f$F`JOq}@\u0019伯叼栘叙栺叚桫佢参栃#sKTogJ(B\u00051";
      m[37] = "xl^e3Ro5X\u001c栒栻叜桋佦栅佖叡栆桋;%g[&=\u0004zk\u001dr";
      m[38] = "DT=-;tS\r;T叀余佾伷厛厗叀栝栺厩XofoB\u0007clggL";
      m[39] = "z/@P_2mvF)厤厁栄叒佸佴桾伟叞佌%\u0010\u0018y#+LG_3r";
   }

   private float p(double distance) {
      long a = 何树何友何何树树树友.a ^ 88935623394206L;
      d<"y">(-911255862449185924L, a);
      return distance >= 16.0 ? 0.1F : (float)(0.8F - distance / 16.0 * 0.7F);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 何树何友何何树树树友.a ^ 113864685643479L;
      d<"Þ">(this, 0, -7630077346832214668L, a);
      d<"Þ">(this, null, -7630203602829570871L, a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void u(WorldEvent event) {
      long a = 何树何友何何树树树友.a ^ 88100450398291L;
      long ax = a ^ 90258033396299L;
      cn.cool.cherish.utils.树友树友树树何何树何.Y(ax);
      d<"Þ">(this, 0, -9180391322129759248L, a);
      d<"Þ">(this, null, -9180546536812111283L, a);
   }

   @EventTarget
   public void X(LivingUpdateEvent event) {
      long a = 何树何友何何树树树友.a ^ 22111890763398L;
      long ax = a ^ 23249284123498L;
      long axx = a ^ 73301003029985L;
      long axxx = a ^ 48169966038483L;
      d<"y">(-7042832251974830492L, a);
      if (d<"¥">(mc.player, -7042516256270517241L, a) > d<"¥">(this, -7043396235206155906L, a) && d<"¥">(mc.player, -7042516256270517241L, a) > 5) {
         String baseDir = d<"¥">(Cherish.getResourcesManager(), -7043229817986999350L, a).getAbsolutePath() + b<"n">(18506, 8993711339365094595L ^ a);
         String var12 = d<"¥">(this, -7042928363129643060L, a).getValue();
         byte var13 = -1;
         switch (var12.hashCode()) {
            case 977234782:
               if (var12.equals(b<"n">(4899, 8975376106508226457L ^ a))) {
                  var13 = 0;
               }
            default:
               switch (var13) {
                  case 0:
                     cn.cool.cherish.utils.树友树友树树何何树何.I(baseDir + b<"n">(30712, 6578676767486143312L ^ a), axx, 0.8F);
               }
         }
      }

      d<"Þ">(this, d<"¥">(mc.player, -7042516256270517241L, a), -7043396235206155906L, a);
      if (d<"¥">(this, -7039863248694868840L, a) != null
         && !d<"¥">(this, -7039863248694868840L, a).isAlive()
         && !d<"¥">(this, -7043457272932105826L, a).C(b<"n">(19772, 1937577869101224342L ^ a))) {
         if (d<"¥">(this, -7040028204479609064L, a).c(c<"d">(7586, 8024984149692466349L ^ a), ax)) {
            this.I();
            d<"¥">(this, -7040028204479609064L, a).U(axxx);
         }

         d<"Þ">(this, null, -7039863248694868840L, a);
      }
   }

   @EventTarget
   public void K(PacketEvent event) {
      long a = 何树何友何何树树树友.a ^ 62074242350972L;
      long ax = a ^ 116865466289465L;
      long axx = a ^ 59201550988950L;
      long axxx = a ^ 80241875381189L;
      long axxxx = a ^ 37615156632414L;
      long axxxxx = a ^ 63006081587856L;
      long axxxxxx = a ^ 23965645973931L;
      long axxxxxxx = a ^ 121780080581659L;
      long axxxxxxxx = a ^ 8417799846953L;
      long axxxxxxxxx = a ^ 73174644372405L;
      long axxxxxxxxxx = a ^ 65066226378358L;
      d<"y">(5744615142737242014L, (long)a);
      if (!this.w(new Object[]{axx})) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundPlayerPositionPacket
            && d<"¥">(mc.player, 5745353073027389112L, (long)a) > 200
            && d<"¥">(this, 5745254044182347992L, (long)a).getValue()) {
            String baseDir = d<"¥">(Cherish.getResourcesManager(), 5745264521643870768L, (long)a).getAbsolutePath() + b<"n">(5240, 1529423955303127342L ^ a);
            cn.cool.cherish.utils.树友树友树树何何树何.I(baseDir + b<"n">(5366, 8720788997369878967L ^ a), axxxxxxx, 0.8F);
         }

         if (packet instanceof ServerboundInteractPacket wrapper
            && WrapperUtils.Y((long)wrapper, (ServerboundInteractPacket)axxxxxx)
            && d<"¥">(this, 5744672938227247533L, (long)a)) {
            Entity targetEntity = mc.level.getEntity(WrapperUtils.k(new Object[]{ax, wrapper}));
            if (targetEntity != null && !((LivingEntity)targetEntity).isDeadOrDying() && targetEntity.isAlive()) {
               d<"Þ">(this, false, 5744672938227247533L, (long)a);
               double distance = mc.player.distanceTo(targetEntity);
               float volume = this.p(distance);
               String baseDir = d<"¥">(Cherish.getResourcesManager(), 5745264521643870768L, (long)a).getAbsolutePath()
                  + b<"n">(18506, 8993750747397784889L ^ a);
               String mode = d<"¥">(this, 5745458570379962936L, (long)a).getValue();
               if (d<"¥">(this, 5744076535985294716L, (long)a).c(c<"d">(22524, 3736005467094146824L ^ a), axxxxx)) {
                  byte var34 = -1;
                  switch (mode.hashCode()) {
                     case 977234782:
                        if (mode.equals(b<"n">(20662, 1774583208940740095L ^ a))) {
                           var34 = 0;
                        }
                     default:
                        switch (var34) {
                           case 0:
                              cn.cool.cherish.utils.树友树友树树何何树何.I(baseDir + b<"n">(5255, 6754331324277905874L ^ a), axxxxxxx, volume);
                           default:
                              d<"¥">(this, 5744076535985294716L, (long)a).U(axxxxxxxx);
                        }
                  }
               }
            }
         }

         if (packet instanceof ClientboundSetTitleTextPacket wrapperx
            && !d<"¥">(this, 5744268221282049820L, (long)a).C(b<"n">(19772, 1937538117462458476L ^ a))) {
            Component titleComponent = wrapperx.getText();
            String titleText = Component.literal(titleComponent.getString()).getString();
            String baseDir = d<"¥">(Cherish.getResourcesManager(), 5745264521643870768L, (long)a).getAbsolutePath() + b<"n">(18506, 8993750747397784889L ^ a);
            String mode = d<"¥">(this, 5744268221282049820L, (long)a).getValue();
            String[] keywords = d<"¥">(this, 5744519218795993664L, (long)a).getValue().split(",");
            boolean containsWinKeyword = false;
            int var51 = keywords.length;
            int var35 = 0;
            if (0 < var51) {
               String keyword = keywords[0];
               if (titleText.contains(keyword.trim())) {
                  containsWinKeyword = true;
               }

               var35++;
            }

            if (containsWinKeyword) {
               cn.cool.cherish.utils.树友树友树树何何树何.T(axxxxxxxxx, b<"n">(30814, 8221537485470086405L ^ a));
               if (d<"¥">(this, 5743949210242557678L, (long)a) != null) {
                  cn.cool.cherish.utils.树友树友树树何何树何.l(d<"¥">(this, 5743949210242557678L, (long)a), axxxx);
                  d<"Þ">(this, null, 5743949210242557678L, (long)a);
               }

               byte var52 = -1;
               switch (mode.hashCode()) {
                  case 977234782:
                     if (mode.equals(b<"n">(4899, 8975354560969006691L ^ a))) {
                        var52 = 0;
                     }
                  default:
                     switch (var52) {
                        case 0:
                           cn.cool.cherish.utils.树友树友树树何何树何.I(baseDir + b<"n">(21396, 432611866773102284L ^ a), axxxxxxx, 0.8F);
                     }
               }
            }
         }

         if (packet instanceof ClientboundSystemChatPacket wrapperx && !d<"¥">(this, 5744761416538167082L, (long)a).C(b<"n">(19772, 1937538117462458476L ^ a))) {
            Component messageComponent = wrapperx.content();
            String messageText = Component.literal(messageComponent.getString()).getString();
            String baseDirx = d<"¥">(Cherish.getResourcesManager(), 5745264521643870768L, (long)a).getAbsolutePath() + b<"n">(18506, 8993750747397784889L ^ a);
            String modex = d<"¥">(this, 5744761416538167082L, (long)a).getValue();
            String[] keywordsx = d<"¥">(this, 5743805192505405536L, (long)a).getValue().split(",");
            boolean containsWinKeywordx = false;
            int var53 = keywordsx.length;
            int var56 = 0;
            if (0 < var53) {
               String keyword = keywordsx[0];
               if (messageText.contains(keyword.trim())) {
                  containsWinKeywordx = true;
               }

               var56++;
            }

            if (containsWinKeywordx) {
               byte var54 = -1;
               switch (modex.hashCode()) {
                  case 977234782:
                     if (!modex.equals(b<"n">(4899, 8975354560969006691L ^ a))) {
                        break;
                     }

                     var54 = 0;
                  case -1492564645:
                     if (modex.equals(b<"n">(24976, 2298739999387331813L ^ a))) {
                        var54 = 1;
                     }
               }

               switch (var54) {
                  case 0:
                     d<"Þ">(this, baseDirx + b<"n">(14280, 8884462054840859282L ^ a), 5743949210242557678L, (long)a);
                     ChatFormatting var10000 = d<"F">(5744365676376990932L, (long)a);
                     String var10001 = WrapperUtils.E(new Object[]{axxx});
                     ChatFormatting var10003 = ChatFormatting.RESET;
                     ClientUtils.e(new Object[]{var10000 + "[" + var10001 + b<"n">(23802, 6781590503758139822L ^ a) + var10003, axxxxxxxxxx});
                     cn.cool.cherish.utils.树友树友树树何何树何.I(d<"¥">(this, 5743949210242557678L, (long)a), axxxxxxx, 0.8F);
                  case 1:
                     d<"Þ">(this, baseDirx + b<"n">(29973, 7041009621456468068L ^ a), 5743949210242557678L, (long)a);
                     cn.cool.cherish.utils.树友树友树树何何树何.I(d<"¥">(this, 5743949210242557678L, (long)a), axxxxxxx, 0.8F);
               }
            }
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "行走的50万——何炜霖";
   }
}
