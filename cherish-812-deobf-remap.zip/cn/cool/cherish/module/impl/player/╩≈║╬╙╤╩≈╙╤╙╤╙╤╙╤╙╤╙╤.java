package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.HitResult.Type;

public class 树何友树友友友友友友 extends Module implements 何树友 {
   private final BooleanValue 友树友树何何树树友何 = new BooleanValue("Auto Place Blocks", "自动放置方块", false);
   private final BooleanValue 友树何树友友友何树何 = new BooleanValue("Require Block In Hand", "需要手持方块", true);
   private final BooleanValue 何何何友树树友何何何 = new BooleanValue("Require On Ground", "需要在地面上", true);
   private final NumberValue 友树树树何友何何何友 = new NumberValue("Pitch Threshold", "俯视角度阈值", 70.0, 0.0, 90.0, 1.0);
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[25];
   private static final String[] k = new String[25];
   private static int _行走的50万——何炜霖 _;

   public 树何友树友友友友友友() {
      super("Eagle", "安全蹲搭", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(5026612028078615166L, 7856551704131180667L, MethodHandles.lookup().lookupClass()).a(151301915935002L);
      // $VF: monitorexit
      a = var10000;
      c();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(86248614935642L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[10];
      int var7 = 0;
      String var6 = "¨HÐ\u0006ã\u0093(i\u001cÙ\u008dx#¡Eµ®\u009cÝ\túä»\u0001q¢\u0003p\u0002$î=¶3£\u0017F\u00169¢ Ü¹\u0004\u0093ñ@g*ô¡Ü4PñÙéÔø\u009fd·\u009f¥õ\u0096°\u0010å\u001e\u0005\u0091¹(¥*Ï1\u001cÐ \u00048ãt±\fgë\u0083Mîîï\u008bv\u0013iÅ6§$µn\u007f\u001bi7¸ðµ\u0084ïb(vÜ´ÇÒ\u001e\u0006\u0018\u0019(^\u008aBcþÀýB\u0083tçW^º\u008b\u0083\u0082ù\u0094\u0096F6L%ßôÚPP\u008e(\u000f\u0088õe5ïc\u000fää\u0096Ø\nÁ\u0012\u008d\u001dxÐÙ\u0091~{\u008eé)?Û\u0099\u000eP¼ñ^A#Æ)Ó|(\u001a`\u001c\u008a?\u0089m\u0016ë \u001aéÿ@¾Æ§\u0087®/¼\u0094WnÌD/á\u0095Îbé1¥ãqaÃçÕ\u0018R\u009a\u00ad\t\u0087\u0007âpÛ>«\u0004\u0096R:i\u0085\u001b\f'²(w\u0011\u0010\u009a%èö±\u009eØbwí\u000b«³Ü A";
      short var8 = 279;
      char var5 = '(';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[10];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ÔÂ\u0002\u0097\u0085j\u0085\tø\u0007ÓK\u000eX\u001dt\tÆXË´x5vUçà\u0085ø\u0000\u0011â\u008d?²\t1kV\u0006(\u0089o¥Ù\\Èuû\u0083¡ý6@aÕg6r\u0007J\tª\u0017í'çye\u0018¨²!únd³\u0080áá\u009e";
                  var8 = 81;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private boolean I() {
      树友何何友何树何树友.E();
      if (this.Q(new Object[]{52406761729175L})) {
         return false;
      } else {
         HitResult hitResult = mc.hitResult;
         return hitResult != null && hitResult.getType() == Type.BLOCK;
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 57;
               case 2 -> 34;
               case 3 -> 19;
               case 4 -> 45;
               case 5 -> 63;
               case 6 -> 1;
               case 7 -> 4;
               case 8 -> 11;
               case 9 -> 26;
               case 10 -> 14;
               case 11 -> 12;
               case 12 -> 21;
               case 13 -> 38;
               case 14 -> 9;
               case 15 -> 40;
               case 16 -> 29;
               case 17 -> 51;
               case 18 -> 28;
               case 19 -> 53;
               case 20 -> 32;
               case 21 -> 35;
               case 22 -> 47;
               case 23 -> 55;
               case 24 -> 7;
               case 25 -> 59;
               case 26 -> 44;
               case 27 -> 54;
               case 28 -> 16;
               case 29 -> 39;
               case 30 -> 17;
               case 31 -> 60;
               case 32 -> 3;
               case 33 -> 13;
               case 34 -> 15;
               case 35 -> 36;
               case 36 -> 43;
               case 37 -> 62;
               case 38 -> 5;
               case 39 -> 50;
               case 40 -> 61;
               case 41 -> 42;
               case 42 -> 10;
               case 43 -> 48;
               case 44 -> 2;
               case 45 -> 0;
               case 46 -> 24;
               case 47 -> 8;
               case 48 -> 56;
               case 49 -> 22;
               case 50 -> 27;
               case 51 -> 46;
               case 52 -> 58;
               case 53 -> 6;
               case 54 -> 52;
               case 55 -> 33;
               case 56 -> 30;
               case 57 -> 41;
               case 58 -> 20;
               case 59 -> 49;
               case 60 -> 25;
               case 61 -> 18;
               case 62 -> 31;
               default -> 23;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友树友友友友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26489;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友树友友友友友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[u#Còûj\u009cl\\é!ÔBz¥Vìne#«Å\u0085., yÖv\u0088ðÖ±\tÇ¡w@\u0018rxÓ, ·fV\u001d¹\u0094Ú2\u0011Ë©rÁ\u0018wa^Ò\\Õ´HÝÅ, \u0011/\u009f\u0002±\u0003ÞEA\u0084Ó\u0017ÚºTÀ8o\u008b?¬´§¹, 4B\u0080Ð\u0004ÍÊ\"\u0097ä\u0017\u0087²r!¦®\u0080¬\b£aÑ·, \u0011äF\"\u0012|yøÀ£¸\u0010\u0019oÛ\u0015ØKél\u0011\u0017úË, ¡RC\u0007$äuv»²")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void c() {
      j[0] = "VPG\u001fB8Y\u0010\n\u0014H%\\M\u0001R@8QK\u0005\u0019\u0003>XN\u0005R];TG\f\u000e\u0003框你叵桸厷另厜叾叵厢";
      j[1] = "^-[%\u0007\u0013Qm\u0016.\r\u000eT0\u001dh\u001e\u001dQ6\u0010h\u0001\u0011M/[\u0004\u0007\u0013Q&\u0014(>\u001dQ6\u0010";
      j[2] = "+[9Nb\u0000+[.\u0012n\u000f1\u0010.\ff\f+Jc/\u007f\u001d,Q#\u0013";
      j[3] = "G\fH_%|G\f_\u0003)s]G_\u001d!pG\u001d\u0012:-ld\bL\u0001!{N";
      j[4] = "X)\u0002\u001c\u000b\u001eWiO\u0017\u0001\u0003R4DQ\t\u001e_2@\u001aJ\u0018V7@Q\u0014\u001dZ>I\rJ桠台伒佹厴伱桠佮桖叧";
      j[5] = "~u'?l\rJV(\u007f!\u0006@K-\"*@HV $.\u000b\u000bt+57\u0002@\u0002";
      j[6] = "{NV(\"\u0018pAGg^\u0001\u007f[I$i1iLE9x\u001d~A";
      j[7] = "2;\"Z4?2;5\u000680(p5\u0018032*x9089=$\u0015?\"";
      j[8] = "\u0019&zC>P\u0016f7H4M\u0013;<\u000e<P\u001e=8E\u007f栮伯厃原併桀叴厱伝企";
      j[9] = "?\u0004\t'a&?\u0004\u001e{m)%O\nf~#5O\rau<\u007f)\u0014}^*\"\u0014\u0011}(\u001b(\u0011\u0018";
      j[10] = "\u0015\u0013NGz)\u0015\u0013Y\u001bv&\u000fXM\u0006e,\u001fXJ\u0001n3U>S\u001dE%\b\u0003V\u001d";
      j[11] = "%=9i,P*}tb&M/ \u007f$5^*&r$*R6?9D6R$6e\\\"S36";
      j[12] = "\u001b9nzK&\u00106\u007f5*(\u001b={o";
      j[13] = "\u000f w&CxU..$$]u\u000e\u0007\u0002$)Xr+&KsV+)";
      j[14] = "a>13\nn$)'kw}\u000fsb1F.\u000fBbl\u001cxg{>l\b~";
      j[15] = "c\u0015_*\u000b\u0010d\u0016CX伺伶伂叨栾桁厤伶伂佶'aW\u000f?WZ*\\S$";
      j[16] = "\u0001o}[m~L1w]S ke \u001ampkT ^:tA)eI,,";
      j[17] = "ivO\u000b#{nuSy厌栙厖桑佪伤桖栙厖伕7@\u007fd54J\u000bt8.";
      j[18] = "C\\l\f(b\u0006KzTUq-\u0011?\u000ed'- ?S>tE\u0019cS*r";
      j[19] = "`\nmF<ag\tq4厓栃桅栭佈号伍佇企号\u0015\u0004i`\"J.S5w3";
      j[20] = "\u0018\u0013`5\u001baNT'=x\u001d#\u0016b7\u00046YIe`\u001dP";
      j[21] = "vk\u0000\u00146S1)HG\u000e厬桒栍叻佴反伲桒受校)3\u0010s)\u0000\u0015tR;z";
      j[22] = "nR'\u0004\u000e=#\f-\u00020c\u0004XzE\u000f2\u0004i}\fBa>Vy\u000f\f6";
      j[23] = "\u000f\u00075%&S\b\u0004)W厉栱佮栠厎厔厉併株佤MnzLSE0%q\u0010H";
      j[24] = "\u0010@\u0005\u001f&|\u0017C\u0019m#\u0007\u0010\u001cF\u00016j\u0012\u001a\u001e\rJ;NE\u0011\u0011'9H\u001d\u001dm";
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 239 && var8 != 207 && var8 != '$' && var8 != 'u') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'x') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'n') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 239) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 207) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友树友友友友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @Override
   public void h() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         mc.options.keyShift.setDown(false);
         if (this.友树友树何何树树友何.getValue()) {
            mc.options.keyUse.setDown(false);
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private void a() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (!this.何何何友树树友何何何.getValue() || mc.player.onGround()) {
            if (this.A()) {
               BlockPos blockBelow = BlockPos.containing(mc.player.getX(), mc.player.getY() - 1.0, mc.player.getZ());
               BlockState blockState = mc.level.getBlockState(blockBelow);
               if (blockState.getBlock() instanceof AirBlock && this.O()) {
                  mc.options.keyUse.setDown(this.I() && !this.T(blockBelow));
               }
            }
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static Block v(BlockPos pos) {
      树友何何友何树何树友.E();
      return mc.level == null ? null : mc.level.getBlockState(pos).getBlock();
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static Block A(Player player) {
      return v(BlockPos.containing(player.getX(), player.getY() - 1.0, player.getZ()));
   }

   private boolean A() {
      树友何何友何树何树友.E();
      return this.Q(new Object[]{52406761729175L}) ? false : mc.player.getXRot() >= this.友树树树何友何何何友.getValue().floatValue();
   }

   @Override
   public void M() {
      if (树友何何友何树何树友.E() == null) {
         if (this.Q(new Object[]{52406761729175L})) {
            return;
         }

         mc.player.setShiftKeyDown(false);
      }
   }

   @EventTarget
   public void N(MotionEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (!this.何何何友树树友何何何.getValue() || mc.player.onGround()) {
            if (!this.友树何树友友友何树何.getValue() || this.O()) {
               label31: {
                  if (A(mc.player) instanceof AirBlock) {
                     if (!this.A()) {
                        break label31;
                     }

                     mc.options.keyShift.setDown(true);
                  }

                  if (mc.player.onGround()) {
                     mc.options.keyShift.setDown(false);
                  }
               }

               if (this.友树友树何何树树友何.getValue()) {
                  this.a();
               }
            }
         }
      }
   }

   private boolean T(BlockPos blockBelow) {
      树友何何友何树何树友.E();
      if (this.Q(new Object[]{52406761729175L})) {
         return false;
      } else {
         HitResult hitResult = mc.hitResult;
         if (hitResult != null && hitResult.getType() == Type.BLOCK) {
            BlockPos lookingAt = ((BlockHitResult)hitResult).getBlockPos();
            return lookingAt.equals(blockBelow);
         } else {
            return false;
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "我是何树友";
   }

   private boolean O() {
      树友何何友何树何树友.E();
      return this.Q(new Object[]{52406761729175L})
         ? false
         : !mc.player.getMainHandItem().isEmpty() && mc.player.getMainHandItem().getItem() instanceof BlockItem;
   }
}
