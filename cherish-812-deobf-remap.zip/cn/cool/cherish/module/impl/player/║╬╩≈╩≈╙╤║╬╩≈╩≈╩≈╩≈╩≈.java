package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.UpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.Vec3;

public class 何树树友何树树树树树 extends Module implements 何树友 {
   private final NumberValue 树何树何友何何何友树;
   private final BooleanValue 树何何何树友何树树何;
   private final BooleanValue 树树树友友何何树友何;
   private final BooleanValue 何何何友何树何树何树;
   private final NumberValue 何何树友树树何友友树;
   private final BooleanValue 友何树友友友友何友何;
   private Rotation 何何树友友何何何何友;
   private EndCrystal 树树友友何友何何友友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[32];
   private static final String[] k = new String[32];
   private static String LIU_YA_FENG;

   public 何树树友何树树树树树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/何树树友何树树树树树.a J
      // 003: ldc2_w 30661780363146
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 16146
      // 00c: ldc2_w 3183409268678182576
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 7673
      // 019: ldc2_w 3720315122852815959
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w 8022139022235503604
      // 026: lload 1
      // 027: invokedynamic Â (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/NumberValue
      // 033: dup
      // 034: sipush 27168
      // 037: ldc2_w 3659501757231109007
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 2778
      // 044: ldc2_w 8195426281297736570
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: ldc2_w 2.3
      // 051: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 054: bipush 1
      // 055: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 058: ldc2_w 2.9
      // 05b: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 05e: ldc2_w 0.1
      // 061: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 064: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 067: putfield cn/cool/cherish/module/impl/player/何树树友何树树树树树.树何树何友何何何友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 06a: aload 0
      // 06b: new cn/cool/cherish/value/impl/BooleanValue
      // 06e: dup
      // 06f: sipush 542
      // 072: ldc2_w 3742498037968174007
      // 075: lload 1
      // 076: lxor
      // 077: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07c: sipush 2246
      // 07f: ldc2_w 6344496050727448938
      // 082: lload 1
      // 083: lxor
      // 084: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 089: bipush 1
      // 08a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 08d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 090: putfield cn/cool/cherish/module/impl/player/何树树友何树树树树树.树何何何树友何树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 093: aload 0
      // 094: new cn/cool/cherish/value/impl/BooleanValue
      // 097: dup
      // 098: sipush 2989
      // 09b: ldc2_w 1724578085057229323
      // 09e: lload 1
      // 09f: lxor
      // 0a0: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a5: sipush 29496
      // 0a8: ldc2_w 5477658519025126041
      // 0ab: lload 1
      // 0ac: lxor
      // 0ad: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b2: bipush 1
      // 0b3: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0b6: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0b9: putfield cn/cool/cherish/module/impl/player/何树树友何树树树树树.树树树友友何何树友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0bc: aload 0
      // 0bd: new cn/cool/cherish/value/impl/BooleanValue
      // 0c0: dup
      // 0c1: sipush 21583
      // 0c4: ldc2_w 6607565597533416936
      // 0c7: lload 1
      // 0c8: lxor
      // 0c9: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ce: sipush 18821
      // 0d1: ldc2_w 6331074594888069160
      // 0d4: lload 1
      // 0d5: lxor
      // 0d6: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0db: bipush 0
      // 0dc: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0df: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0e2: putfield cn/cool/cherish/module/impl/player/何树树友何树树树树树.何何何友何树何树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0e5: aload 0
      // 0e6: new cn/cool/cherish/value/impl/NumberValue
      // 0e9: dup
      // 0ea: sipush 11412
      // 0ed: ldc2_w 3841021169525151038
      // 0f0: lload 1
      // 0f1: lxor
      // 0f2: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f7: sipush 5667
      // 0fa: ldc2_w 8735056740194873216
      // 0fd: lload 1
      // 0fe: lxor
      // 0ff: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 104: ldc2_w 180.0
      // 107: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 10a: dconst_0
      // 10b: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 10e: ldc2_w 180.0
      // 111: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 114: ldc2_w 10.0
      // 117: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 11a: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 11d: aload 0
      // 11e: ldc2_w 8022256998755058767
      // 121: lload 1
      // 122: invokedynamic Ý (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 127: dup
      // 128: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 12b: pop
      // 12c: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 131: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 134: checkcast cn/cool/cherish/value/impl/NumberValue
      // 137: putfield cn/cool/cherish/module/impl/player/何树树友何树树树树树.何何树友树树何友友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 13a: aload 0
      // 13b: new cn/cool/cherish/value/impl/BooleanValue
      // 13e: dup
      // 13f: sipush 3982
      // 142: ldc2_w 2457677350977893925
      // 145: lload 1
      // 146: lxor
      // 147: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14c: sipush 8200
      // 14f: ldc2_w 4141215094823868832
      // 152: lload 1
      // 153: lxor
      // 154: invokedynamic q (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 159: bipush 1
      // 15a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 15d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 160: putfield cn/cool/cherish/module/impl/player/何树树友何树树树树树.友何树友友友友何友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 163: aload 0
      // 164: aconst_null
      // 165: ldc2_w 8022916478559260220
      // 168: lload 1
      // 169: invokedynamic l (Ljava/lang/Object;Lcn/cool/cherish/utils/helper/Rotation;JJ)V bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16e: aload 0
      // 16f: aconst_null
      // 170: ldc2_w 8022553637462836640
      // 173: lload 1
      // 174: invokedynamic l (Ljava/lang/Object;Lnet/minecraft/world/entity/boss/enderdragon/EndCrystal;JJ)V bsm=cn/cool/cherish/module/impl/player/何树树友何树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 179: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1624665076848718816L, -9071075321923947695L, MethodHandles.lookup().lookupClass()).a(164584133743580L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 126848191262178L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[14];
      int var7 = 0;
      String var6 = "tÔG\u009f\u0005/ó\"¸\u0091\u001bÃÊ\b\u008eÄRº\u000bJt\u0086\u009a¹â\nmÌq\u008aQ\u0018\u0087°e\u0006}\u00ad\u00ad5\u0018ÿ=k\u0094\u0088ÿBýA²è\u008b8+gñ\u0015s,³\u0093ËúL\u0018¼p\u00ad8Y»¥n\u0091p:\u0016\u0002Xo\u0095ãåu~\u0014fÒz\u0018ìæÙ\u00ad\u0090Á¦\u0092Wõçý\u001d²%v\u0017MÚön¯ôú Uhìè\u0014^²|f\u009b(EN\u009aOoÊÛ¥\u0084¦çâ\u000b`¬§ËiåEÓ\u0010;\u0093H\u000e\u0098Ä÷Êýh ÿ0n+Ý\u0018)ªNßx»x×\u0015¦ùý?Zy\u0015÷åÀy¯TÝ\u0091 D\u0012\t\u0001TÿðV$wáÌhu\u008erOoÜ\to>Ì\u0012\u0017Ð0=O¤¹\u0003 \u0083\u0083ÉBØ\u0099\u008au1üJî\u009b©3\u001d±M&nzßb_wØl¤}%|D(ÂÔ\u001cº\u009c\u0006.S\u0012\u007fL,\u001eo\u009c3xÎ\\*!yà¾¦OE|%\u0002T¶\u001f,R4å\u0098}y\u0010a\u00ad¶Á\u00ad\u009a²Âî}\u0086Â\n§\u0083\u0010 \u00171\u0011\u008dv\u009a\u008f\u0019\u008cªªÎÞ4\u0097q¿tdè\u000bN!ÍV\u0091\\b¿ã)Ï";
      short var8 = 347;
      char var5 = '(';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[14];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\nRu\u0097\u0018/\u0006Yw:ÇW~\u000e2$\u000fï¤Ð\u001f\u009f\u008b\u0011\u0018Â\\~ÔòÑé¢i3)nÀZ1q3\u0092_\u0012G&î:";
                  var8 = 49;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   protected void F() {
      long a = 何树树友何树树树树树.a ^ 58692795428139L;
      c<"l">(this, null, 6194154305454945437L, a);
      c<"l">(this, null, 6193848639060950785L, a);
   }

   public Rotation Z() {
      long a = 何树树友何树树树树树.a ^ 80829428723404L;
      return c<"Ý">(this, 6201863949626062714L, a);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 46;
               case 1 -> 52;
               case 2 -> 41;
               case 3 -> 50;
               case 4 -> 32;
               case 5 -> 57;
               case 6 -> 25;
               case 7 -> 13;
               case 8 -> 27;
               case 9 -> 29;
               case 10 -> 48;
               case 11 -> 28;
               case 12 -> 21;
               case 13 -> 33;
               case 14 -> 42;
               case 15 -> 26;
               case 16 -> 15;
               case 17 -> 30;
               case 18 -> 62;
               case 19 -> 3;
               case 20 -> 38;
               case 21 -> 11;
               case 22 -> 58;
               case 23 -> 20;
               case 24 -> 55;
               case 25 -> 61;
               case 26 -> 44;
               case 27 -> 49;
               case 28 -> 12;
               case 29 -> 51;
               case 30 -> 45;
               case 31 -> 36;
               case 32 -> 10;
               case 33 -> 40;
               case 34 -> 1;
               case 35 -> 43;
               case 36 -> 7;
               case 37 -> 53;
               case 38 -> 59;
               case 39 -> 63;
               case 40 -> 18;
               case 41 -> 39;
               case 42 -> 54;
               case 43 -> 0;
               case 44 -> 22;
               case 45 -> 6;
               case 46 -> 56;
               case 47 -> 34;
               case 48 -> 9;
               case 49 -> 16;
               case 50 -> 23;
               case 51 -> 17;
               case 52 -> 47;
               case 53 -> 35;
               case 54 -> 14;
               case 55 -> 24;
               case 56 -> 4;
               case 57 -> 60;
               case 58 -> 5;
               case 59 -> 8;
               case 60 -> 19;
               case 61 -> 2;
               case 62 -> 31;
               default -> 37;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5881;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何树树友何树树树树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树树友何树树树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树树友何树树树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 221 && var8 != 'l' && var8 != 194 && var8 != 202) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'P') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 221) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'l') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @EventTarget(4)
   public void n(UpdateEvent event) {
      long a = 何树树友何树树树树树.a ^ 7861624456858L;
      long ax = a ^ 33214947329899L;
      long axx = a ^ 77539289260451L;
      long axxx = a ^ 118917637621204L;
      long axxxx = a ^ 128614270505839L;
      c<"Z">(-124136503490275017L, a);
      if (!this.w(new Object[]{ax}) && c<"Ý">(mc, -123917594278374553L, a) != null) {
         EndCrystal bestTarget = null;
         double rangeSq = Math.pow(c<"Ý">(this, -124937464119153358L, a).getValue().doubleValue(), 2.0);

         for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity instanceof EndCrystal crystal) {
               if (mc.player.distanceToSqr(crystal) > rangeSq) {
               }

               if (!this.m(crystal)) {
               }

               bestTarget = crystal;
               break;
            }
         }

         c<"l">(this, bestTarget, -124470478941317968L, a);
         if (c<"Ý">(this, -124470478941317968L, a) != null) {
            c<"l">(this, RotationUtils.z(new Object[]{c<"Ý">(this, -124470478941317968L, a), axx}), -124063657537265876L, a);
            if (c<"Ý">(this, -124510523902529588L, a).getValue()) {
               Rotation var10000 = c<"Ý">(this, -124063657537265876L, a);
               boolean var10002 = c<"Ý">(this, -124268149185739450L, a).getValue();
               boolean var10004 = c<"Ý">(this, -124740719478024865L, a).getValue();
               Object[] var10007 = new Object[]{null, null, null, null, null, c<"Ý">(this, -124781647702354139L, a).getValue().floatValue()};
               var10007[4] = var10004;
               var10007[3] = false;
               var10007[2] = var10002;
               var10007[1] = axxxx;
               var10007[0] = var10000;
               RotationUtils.y(var10007);
            }

            Rotation var19 = c<"Ý">(this, -124063657537265876L, a);
            LocalPlayer var20 = mc.player;
            var19.A(new Object[]{axxx, var20});
            c<"Ý">(mc, -123917594278374553L, a).attack(mc.player, c<"Ý">(this, -124470478941317968L, a));
            mc.player.swing(c<"Â">(-123939652663459526L, a));
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "\u001a[\\\u0019~5\u0015\u001b\u0011\u0012t(\u0010F\u001aT|5\u001d@\u001e\u001f?3\u0014E\u001eTa6\u0018L\u0017\b?伏桨栤厹伯栀桋桨栤档";
      j[1] = "\u0007Wg\u000bU\u000b\b\u0017*\u0000_\u0016\rJ!FO\u0010\rU:FR\u0001\bI,\u001a\u00146\u000bM(\u001cS\u000b\n";
      j[2] = "\u001c>]\\\u00004\u0013~\u0010W\n)\u0016#\u001b\u0011\u0019:\u0013%\u0016\u0011\u00066\u000f<]}\u00004\u00135\u0012Q9:\u0013%\u0016";
      j[3] = "\u0005-\n\u0003]\\\u0005-\u001d_QS\u001ff\tBBY\u000ff\u000eEIFE\u0000\u0017YbP\u0018=\u0012Y\u0014a\u00128\u001b";
      j[4] = "\u007fm-Yu}\u007fm:\u0005yre&.\u0018jxu&5\u0012nq}&\u001a\u001bqdRg7\u0003}le,\u001b\u001bwwz";
      j[5] = ")P#\u0019O%&\u0010n\u0012E8#MeTM%.Ka\u001f\u000e#'NaTP&+Gh\b\u000e伟伟叵佘厱栱厁厁佫佘";
      j[6] = "gXw\u0014wES{xT:NYf}\t1\bQ{p\u000f5C\u0012Y{\u001e,JY/";
      j[7] = "\u0005k#jC[\u000ed2%?B\u0001~<f\br\u0017i0{\u0019^\u0000d";
      j[8] = "4VE/l\u00104VRs`\u001f.\u001dFns\u0015>\u001d]dw\u001c6\u001drmh\t\u0019\\_ud\u0001.\u0017wmt\u0010>";
      j[9] = "\\\u0012oLy%\\\u0012x\u0010u*FYl\rf VYR\f`)@\u0016x\u0016}#\\?z\fp";
      j[10] = "&u\u0016\u0004||&u\u0001Xps<>\u0001Fxp&dLgx{-s\u0010Kwa";
      j[11] = "@HI\u0013;]@H^O7RZ\u0003^Q?Q@Y\u0013P#XZDMQ7MK_\u0013p#XZDmQ7MK_z\\;QcBYX";
      j[12] = "=\u00100/+A=\u0010's'N'[3n4D7[!o2A'\fjc)[ [!o\"M!\u00116`!G=[\u0001o\"k!\f7u'D";
      j[13] = "#\u0007 w!\",Gm|+?)\u001af:8,,\u001ck:' 0\u0005 Z; \"\f|B/!5\f";
      j[14] = "\u0001|*\u0018d+\u000e<g\u0013n6\u000balUf+\u0006gh\u001e%休伷叙佑伮叀休伷栃栕";
      j[15] = "\t\u001b\b\u0017\u001d)\u0002\u0014\u0019X|'\t\u001f\u001d\u0002";
      j[16] = "P}Y\u0016iX\u0013!C+佅佨桲叜叺佶佅佨伶叜9\u0012qG\n%ZN\"NR";
      j[17] = "P7\u000f:\u0019F\u0013k\u0015\u0007厫佶桲厖厬叄厫佶厨伈o=PG\u0017k\u0000e\u0007QT";
      j[18] = "K|\u0018\u0007\rB\u001f?PQ7w<En:w{3H(SO\u0002\u001f>X\u0007\fJI";
      j[19] = "\u001c\u0005<-#x\u001cOg2Owt\u000fdmp#t>m<4&HE/i,(";
      j[20] = "uN9/v7*\u0019\"n\u0011\u0019\u000e(\u001d\u001e+a0B!ut6+\u0003";
      j[21] = "b,#\b4Z;(x\u0011\u0004h\u001f\u0016\u00030Hn\u0002R}\u000f`Zh+$\u000b;C";
      j[22] = "\f\u0018EF\u0019\nOD_{桱伺佪伧格厸伵桾栮伧%AP\u000bKDJ\u0019\u0007\u001d\b";
      j[23] = "u\u0019gsC>!Sy|?*NWs~R4q\u000b1l\u0007U";
      j[24] = "i\u001e\u001f@S\u0015*B\u0005}Kxn\u0003E\u001d\u0013\u0007l\u0004\u001a\u001a\"D-F\u001fL]F*\u0019\u0018}";
      j[25] = "\u0007+\u0012G\\\u0014Ep\bD51}\b'!\b\u0012B(\u0003BJIX+";
      j[26] = "!=^\u000e\u0017?baD3桿桋栃厜叽佮伻桋叙伂>\t^>faQQ\t(%";
      j[27] = "\u0005HR\u0015O1F\u0014H(栧桅叽叩佯叫佣企叽叩2\u0018@5DN]B\u00016\u0007";
      j[28] = "\u001f2<:\u007f4\\n&\u0007栗伄栽伍原佚体伄叧桉\\6l&X(%ba(D";
      j[29] = "FV`2Hx\u0005U\u007f<5低厴召叜厘叶低伪栶叜[\u0004j\bFb0Gi\u0017H";
      j[30] = "\u0005Zn+jBF\u0006t\u0016但佲栧叻栗栏但召叽校\u000e'yPB@wst^^";
      j[31] = "eT#\u000fc\u0005&\b92住伵伃叵伞栫住桱伃栯C\b*\u0004\"\b,P}\u0012a";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private boolean m(Entity entity) {
      long a = 何树树友何树树树树树.a ^ 113020892640746L;
      c<"Z">(-3659566754021987769L, a);
      if (!c<"Ý">(this, -3659405892768493708L, a).getValue()) {
         return true;
      } else {
         Vec3 eyePos = mc.player.getEyePosition();
         Vec3 entityCenter = entity.getBoundingBox().getCenter();
         return mc.level.clip(new ClipContext(eyePos, entityCenter, c<"Â">(-3659698730986274556L, a), c<"Â">(-3660014244892382919L, a), mc.player)).getType()
            == c<"Â">(-3659650639701205422L, a);
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 何树树友何树树树树树.a ^ 126714656403148L;
      c<"l">(this, null, -7633239785268250758L, a);
      c<"l">(this, null, -7632547095002579738L, a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_SHU_YOU() {
      return "刘凤楠230622109211173513";
   }
}
