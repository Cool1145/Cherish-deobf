package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.树何树树何树何何树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import why.tree.friend.antileak.Fucker;

public class 友何何树友友何何树友 extends Module implements 何树友 {
   private final BooleanValue 何树何何友何何友何友;
   private final BooleanValue 友树何何友友树友树何;
   private final BooleanValue 树何何何友树何树何树;
   private final NumberValue 何树友何友树友友友何;
   private final BooleanValue 友何何友友树友友何树;
   private final BooleanValue 何何树何友友何友友友;
   private final Set<BlockPos> 何树友何树何树友何何;
   private final Map<BlockPos, BlockState> 何友树树何何树友树友;
   private Timer 何树友树何何何树何何;
   private int 友友树何何友树树友树;
   private int 树何何树树友树友友何;
   private int 树友友树友友何树友友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final long m;
   private static final Object[] n = new Object[33];
   private static final String[] o = new String[33];
   private static int _何炜霖黑水 _;

   public 友何何树友友何何树友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/render/友何何树友友何何树友.a J
      // 003: ldc2_w 60616148372940
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 11199
      // 00c: ldc2_w 7445832244145436889
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 2292
      // 019: ldc2_w 312192975269829520
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w -5148005708059789730
      // 026: lload 1
      // 027: invokedynamic Ñ (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/BooleanValue
      // 033: dup
      // 034: sipush 16656
      // 037: ldc2_w 2088162213373629049
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 21238
      // 044: ldc2_w 8222287510708568468
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 1
      // 04f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 052: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 055: putfield cn/cool/cherish/module/impl/render/友何何树友友何何树友.何树何何友何何友何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 058: aload 0
      // 059: new cn/cool/cherish/value/impl/BooleanValue
      // 05c: dup
      // 05d: sipush 19924
      // 060: ldc2_w 8531967430404726458
      // 063: lload 1
      // 064: lxor
      // 065: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 06a: ldc "床"
      // 06c: bipush 1
      // 06d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 070: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 073: putfield cn/cool/cherish/module/impl/render/友何何树友友何何树友.友树何何友友树友树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 076: aload 0
      // 077: new cn/cool/cherish/value/impl/BooleanValue
      // 07a: dup
      // 07b: sipush 2927
      // 07e: ldc2_w 4777070475341993996
      // 081: lload 1
      // 082: lxor
      // 083: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 088: sipush 6845
      // 08b: ldc2_w 2796577267281037783
      // 08e: lload 1
      // 08f: lxor
      // 090: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 095: bipush 1
      // 096: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 099: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 09c: invokedynamic get ()Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/render/友何何树友友何何树友.P ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 0a1: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0a4: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 0a7: putfield cn/cool/cherish/module/impl/render/友何何树友友何何树友.树何何何友树何树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0aa: aload 0
      // 0ab: new cn/cool/cherish/value/impl/NumberValue
      // 0ae: dup
      // 0af: sipush 1357
      // 0b2: ldc2_w 7866827196345783848
      // 0b5: lload 1
      // 0b6: lxor
      // 0b7: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bc: sipush 2525
      // 0bf: ldc2_w 1334959948451748533
      // 0c2: lload 1
      // 0c3: lxor
      // 0c4: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c9: bipush 12
      // 0cb: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ce: bipush 1
      // 0cf: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0d2: bipush 32
      // 0d4: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0d7: bipush 1
      // 0d8: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0db: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0de: putfield cn/cool/cherish/module/impl/render/友何何树友友何何树友.何树友何友树友友友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 0e1: aload 0
      // 0e2: new cn/cool/cherish/value/impl/BooleanValue
      // 0e5: dup
      // 0e6: sipush 21298
      // 0e9: ldc2_w 2421441217693007957
      // 0ec: lload 1
      // 0ed: lxor
      // 0ee: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f3: sipush 8164
      // 0f6: ldc2_w 5603998672694217867
      // 0f9: lload 1
      // 0fa: lxor
      // 0fb: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 100: bipush 1
      // 101: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 104: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 107: putfield cn/cool/cherish/module/impl/render/友何何树友友何何树友.友何何友友树友友何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 10a: aload 0
      // 10b: new cn/cool/cherish/value/impl/BooleanValue
      // 10e: dup
      // 10f: sipush 5605
      // 112: ldc2_w 8607696657633674889
      // 115: lload 1
      // 116: lxor
      // 117: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11c: sipush 22161
      // 11f: ldc2_w 3979946422418949626
      // 122: lload 1
      // 123: lxor
      // 124: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 129: bipush 1
      // 12a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 12d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 130: putfield cn/cool/cherish/module/impl/render/友何何树友友何何树友.何何树何友友何友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 133: aload 0
      // 134: new java/util/HashSet
      // 137: dup
      // 138: invokespecial java/util/HashSet.<init> ()V
      // 13b: putfield cn/cool/cherish/module/impl/render/友何何树友友何何树友.何树友何树何树友何何 Ljava/util/Set;
      // 13e: aload 0
      // 13f: new java/util/concurrent/ConcurrentHashMap
      // 142: dup
      // 143: invokespecial java/util/concurrent/ConcurrentHashMap.<init> ()V
      // 146: putfield cn/cool/cherish/module/impl/render/友何何树友友何何树友.何友树树何何树友树友 Ljava/util/Map;
      // 149: aload 0
      // 14a: sipush 25803
      // 14d: ldc2_w 6312335841742558003
      // 150: lload 1
      // 151: lxor
      // 152: invokedynamic e (IJ)I bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 157: ldc2_w -5147857914991897366
      // 15a: lload 1
      // 15b: invokedynamic À (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 160: aload 0
      // 161: sipush 2005
      // 164: ldc2_w 5325035090840383532
      // 167: lload 1
      // 168: lxor
      // 169: invokedynamic e (IJ)I bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16e: ldc2_w -5148277987147945952
      // 171: lload 1
      // 172: invokedynamic À (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 177: aload 0
      // 178: bipush 0
      // 179: ldc2_w -5148623443276387532
      // 17c: lload 1
      // 17d: invokedynamic À (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/render/友何何树友友何何树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 182: aload 0
      // 183: invokevirtual cn/cool/cherish/module/impl/render/友何何树友友何何树友.U ()V
      // 186: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-410394224520271608L, 5555627030944516230L, MethodHandles.lookup().lookupClass()).a(11590209415454L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var16 = a ^ 125874478216438L;
      Cipher var18;
      Cipher var28 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(var16 << var19 * 8 >>> 56);
      }

      var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[14];
      int var23 = 0;
      String var22 = "óÄî&âÎ\t\u007f\u0097ÀÀì\u0088\u0013xí\u0010Ú\tqáB\t\u0081\u0015®nôòD\u008bn4(éy1ÅÄÉ·ÜAÆW¬\u000fÂÝ\u0086dvÇ\u009a8ÛTqtZV\n\u0013ð}ú?2\u001b¦\t)\u0002\u0005\u0010Tó}¡qU\u0014µ£mÕ\u001eü\u001d8p\u0010PLt\u0095ÈæJ\u0018ßÇ!<²Á¨ý m\u0099õ'óFdÓxo\u001a\u00978£Aÿ\u0014Ènñd\u0095É±|ÖíðµevÅ\u0010X£·1\u0010\u0095<np\u008fùè\u0013f\u0014, ÇÏ\u001d\u009dÂÞÑæ3\u0095Ð~5ì0\f#Bµ¬ÀH×\u008ftD\u0017®:Só\u0081\u0010ñ\u00adpiWÕ»ií¹K7Fú\u009bE \u001cË9QÖào7%ê2ÝÙø®2\u0004ÚØ\u008cçÆ0Èª¦Á\u008dD\u0082Gú\u0010¦Õz'\u0091¬\u0017s\u0019\nýµë¡Î`\u0018\n\u0086[=¹5®\u0097¬\u0096\u0016r\\ ³½\u0092ÇÚÂYse\u0015";
      short var24 = 283;
      char var21 = 16;
      int var27 = -1;

      label56:
      while (true) {
         String var29 = var22.substring(++var27, var27 + var21);
         int var10001 = -1;

         while (true) {
            String var40 = c(var18.doFinal(var29.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var40;
                  if ((var27 += var21) >= var24) {
                     c = var25;
                     h = new String[14];
                     l = new HashMap(13);
                     Cipher var5;
                     Cipher var31 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(var16 << var6 * 8 >>> 56);
                     }

                     var31.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[2];
                     int var8 = 0;
                     byte var7 = 0;

                     do {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = "v\u0081LJWÿ\u0096âT\u009cÉÖzæ(ú".substring(var10001, var7).getBytes("ISO-8859-1");
                        var10001 = var8++;
                        long var13 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        byte[] var15 = var5.doFinal(
                           new byte[]{
                              (byte)(var13 >>> 56),
                              (byte)(var13 >>> 48),
                              (byte)(var13 >>> 40),
                              (byte)(var13 >>> 32),
                              (byte)(var13 >>> 24),
                              (byte)(var13 >>> 16),
                              (byte)(var13 >>> 8),
                              (byte)var13
                           }
                        );
                        long var10004 = (var15[0] & 255L) << 56
                           | (var15[1] & 255L) << 48
                           | (var15[2] & 255L) << 40
                           | (var15[3] & 255L) << 32
                           | (var15[4] & 255L) << 24
                           | (var15[5] & 255L) << 16
                           | (var15[6] & 255L) << 8
                           | var15[7] & 255L;
                        byte var47 = -1;
                        var11[var10001] = var10004;
                     } while (var7 < 16);

                     j = var11;
                     k = new Integer[2];
                     Cipher var0;
                     Cipher var32 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var16 << var1 * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{16, 109, -44, -31, -27, -6, -41, -54});
                     long var45 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     byte var38 = -1;
                     m = var45;
                     return;
                  }

                  var21 = var22.charAt(var27);
                  break;
               default:
                  var25[var23++] = var40;
                  if ((var27 += var21) < var24) {
                     var21 = var22.charAt(var27);
                     continue label56;
                  }

                  var22 = "\u0017\u000b\u0006)ê×Ù\u0080\u001bé¹ï=Á\u0083ibÕåE¤ 6ã\u0010=\"&øò9\u0080ì¾\u001e2Å¹T\u0019ô";
                  var24 = 41;
                  var21 = 24;
                  var27 = -1;
            }

            var29 = var22.substring(++var27, var27 + var21);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 友何何树友友何何树友.a ^ 12038987522228L;
      d<"A">(6193589322827006299L, a);
      d<"M">(this, 6195333700027875563L, a).clear();
      d<"M">(this, 6194199907658587795L, a).clear();
      if (d<"M">(this, 6193992084813787122L, a) != null) {
         d<"M">(this, 6193992084813787122L, a).cancel();
         d<"À">(this, null, 6193992084813787122L, a);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 23;
               case 1 -> 36;
               case 2 -> 26;
               case 3 -> 6;
               case 4 -> 37;
               case 5 -> 24;
               case 6 -> 8;
               case 7 -> 40;
               case 8 -> 46;
               case 9 -> 54;
               case 10 -> 16;
               case 11 -> 50;
               case 12 -> 3;
               case 13 -> 29;
               case 14 -> 11;
               case 15 -> 60;
               case 16 -> 2;
               case 17 -> 35;
               case 18 -> 32;
               case 19 -> 39;
               case 20 -> 31;
               case 21 -> 10;
               case 22 -> 44;
               case 23 -> 48;
               case 24 -> 52;
               case 25 -> 22;
               case 26 -> 41;
               case 27 -> 28;
               case 28 -> 47;
               case 29 -> 25;
               case 30 -> 33;
               case 31 -> 20;
               case 32 -> 27;
               case 33 -> 30;
               case 34 -> 13;
               case 35 -> 1;
               case 36 -> 51;
               case 37 -> 15;
               case 38 -> 45;
               case 39 -> 21;
               case 40 -> 63;
               case 41 -> 56;
               case 42 -> 9;
               case 43 -> 59;
               case 44 -> 7;
               case 45 -> 42;
               case 46 -> 0;
               case 47 -> 38;
               case 48 -> 58;
               case 49 -> 55;
               case 50 -> 61;
               case 51 -> 57;
               case 52 -> 18;
               case 53 -> 19;
               case 54 -> 43;
               case 55 -> 12;
               case 56 -> 53;
               case 57 -> 34;
               case 58 -> 5;
               case 59 -> 62;
               case 60 -> 17;
               case 61 -> 4;
               case 62 -> 14;
               default -> 49;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何树友友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11237;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何树友友何何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'M' && var8 != 192 && var8 != 209 && var8 != 211) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'F') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'A') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'M') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 192) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 209) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何树友友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20339;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何树友友何何树友", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   @EventTarget
   public void c(Render3DEvent event) {
      long a = 友何何树友友何何树友.a ^ 20443588526912L;
      long ax = a ^ 57271443296046L;
      d<"A">(8502818947321012911L, a);
      if (!this.w(new Object[]{ax})) {
         int chunkX = d<"M">(mc.player.chunkPosition(), 8503860430737843320L, a);
         int chunkZ = d<"M">(mc.player.chunkPosition(), 8503045391028303063L, a);
         int radius = d<"M">(this, 8502937009591360527L, a).getValue().intValue();
         if (Math.abs(chunkX - d<"M">(this, 8503648452491696742L, a)) > 0
            || Math.abs(chunkZ - d<"M">(this, 8503220250873800364L, a)) > 0
            || radius != d<"M">(this, 8502884020536468920L, a)) {
            d<"À">(this, chunkX, 8503648452491696742L, a);
            d<"À">(this, chunkZ, 8503220250873800364L, a);
            d<"À">(this, radius, 8502884020536468920L, a);
            this.j(chunkX, chunkZ, radius);
         }

         this.K(event, chunkX, chunkZ, radius);
      }
   }

   private void h() {
      long a = 友何何树友友何何树友.a ^ 60353115107987L;
      long ax = a ^ 18027674418941L;
      long var10001 = a ^ 138540714252996L;
      int axx = (int)((a ^ 138540714252996L) >>> 48);
      int axxx = (int)((a ^ 138540714252996L) << 16 >>> 48);
      int axxxx = (int)(var10001 << 32 >>> 32);
      d<"A">(-4047838058049039492L, a);
      if (!this.w(new Object[]{ax})) {
         树何树树何树何何树何.N(
            (char)axx,
            () -> {
               long axxxxx = 友何何树友友何何树友.a ^ 78210279033282L;
               d<"A">(4360119399671457837L, axxxxx);
               if ((Boolean)d<"M">(this, 4360467713012682916L, axxxxx).v().get()
                  && d<"M">(this, 4360467713012682916L, axxxxx).getValue()
                  && (Boolean)Fucker.isLogin
                  && (Boolean)Fucker.isBeta) {
                  d<"M">(this, 4359618776741328869L, axxxxx).entrySet().removeIf(entry -> {
                     long axxxxxx = 友何何树友友何何树友.a ^ 108041956374200L;
                     return mc.level.getBlockState((BlockPos)entry.getKey()).getBlock() != d<"Ñ">(4898132335850467442L, axxxxxx);
                  });
               }
            },
            (char)axxx,
            axxxx
         );
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何树友友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static void a() {
      n[0] = "-u\u0003eIb\"5NnC\u007f'hE(Kb*nAc\bd#kA(Th \u007fHt\b叆伛低格反叭佘伛栊另";
      n[1] = "\u0000ol&h\u001e\u001egvi\u000b\n\u001a";
      n[2] = "2=TVT-92E\u0019?9;9RC\u0013.6";
      n[3] = "p/6\u0004NC\u007fo{\u000fD^z2pILCw4t\u0002\u000fE~1tISI}%}\u0015\u000fnv5l\u0002Sor,}\u0015@";
      n[4] = "^t1-UYU{ b(AF|)+";
      n[5] = "$ur\u0006\u0004\u0016+5?\r\u000e\u000b.h4K\u001d\u0018+n9K\u0002\u00147wr'\u0004\u0016+~=\u000b=\u0018+n9";
      n[6] = "p/3[\"|n')\u0014X`w+7";
      n[7] = "~ -\u007fY-q``tS0t=k2[-y;oy\u0018众佈厅佖佉叽众佈桟栒";
      n[8] = int.class;
      o[8] = "java/lang/Integer";
      n[9] = "2\u001e\u0018\u001e$(,\u0016\u0002QY8,";
      n[10] = "-1PK;\u0015-1G\u00177\u001a7zS\n$\u0010'zH\u0000 \u0019/zg\r#\u0012(\u0004K\u0016";
      n[11] = "\u0004`H\u0012v\u0016\u000b \u0005\u0019|\u000b\u000e}\u000e_o\u0018\u000b{\u0003_p\u0014\u0017bH?l\u0014\u0005k\u0014'x\u0015\u0012k";
      n[12] = "uB!R\u00186uB6\u000e\u00149o\t\"\u0013\u00073\u007f\t9\u0019\u0003:w\t7\u0010\u001a<p\t\u0017\u0010\u001a<pT";
      n[13] = "rP897\u001brP/e;\u0014h\u001b;x(\u001ex\u001b r,\u0017p\u001b.{5\u0011w\u001b\u000e{5\u0011w";
      n[14] = "#f\u0012\u0013\u0001.(i\u0003\\` #b\u0007\u0006";
      n[15] = "j\u000bx=\u000e\"+\u0013#D伸栋伍伧发伙伸发伍厹\u0012\u007f\u001fra\u0016u~\u001a\"m";
      n[16] = "/<\u001f^\u001a|n$D'伬厏栌桔伨佺桨厏栌厎uY\u0018/~<\u0005E\u001c=";
      n[17] = "\u001c;&`dh]#}\u0019fX\u001f3*\"r&@6/f\u000fa_,wdq>Z)3\u0019";
      n[18] = "\u000b\u001e\u0000\u0014nq\rR\u0002\u0000V栄栯佽校桼桏佀叵口叻ek#\u000eQ\u0000\tmo\fE";
      n[19] = "bp\u000e\u0019+\u001c#hU`厃佱伅参厧桹厃可伅栘d[:Lim\u0003Z?\u001ce";
      n[20] = "5r+5S\u0000tjpL叻右栖佞伜厏校栩双栚Ar\b\u000e1`0>^\ta";
      n[21] = "AN\"|e>\u0000Vy\u0005反栗伦佢压叆栗反桢佢H>tnJS/?q>F";
      n[22] = "\u0000G\u001br+NA_@\u000b伝伣栣佫厲又伝厽叹叵q0:\u001e\u000bZ\u00161?N\u0007";
      n[23] = "\u0000E-(~\u0007\u0005\u001fzt\u001a\nh\u001a+.%Th&(#$Z\\Wdu#\n";
      n[24] = "x`K^\u0017J81B\u0000+uBeW\u0000\u0015B/!JWN+";
      n[25] = "\u001f[\u0006\r~\f^C]t栌叿另栳厯厷佈栥另叩lJ%\u0002\u001bI\u001d\u0006s\u0005K";
      n[26] = "-^\r9DdlFV@佲桍叔佲厤桙召厗叔佲gp\u00175hB\u0005q\u0015mq";
      n[27] = "'5Z*\u001b(\"o\rv\u007f%Oj\\,@zOV_!Au{'\u0013wF%";
      n[28] = "\u0001A<+6%@YgR桄佈佦佭厕桋伀栌佦栩Vi'u\n\\1h\"%\u0006";
      n[29] = "Kp]\u00010g\nh\u0006x伆桎厲栘佪伥伆桎伬作7D20\u001b8\u000f\u001b24\b";
      n[30] = "v\u0012\rC\u0017E7\nV:桥伨休桺桾叹桥厶厏伾g\u0004LKr\u0000\u0016H\u001aL\"";
      n[31] = "|5H\u0015]d%/\u001f\t%4\u001bo\u0017Z\u001fa\u001bR\u001eZ\u0015k34P\u0001Cg";
      n[32] = "Vq \u0010\re\u0017i{i伻桌厯佝桓伴桿厖伱佝JWW1Sn:\b\u0005-\u0016";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 友何何树友友何何树友.a ^ 84308039492435L;
      d<"A">(-7632674536010530116L, a);
      if (d<"M">(this, -7632971736626631659L, a) == null) {
         this.U();
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void j(int chunkX, int chunkZ, int radius) {
      long var10001 = 友何何树友友何何树友.a ^ 28034914019175L ^ 89730069073712L;
      int a = (int)((友何何树友友何何树友.a ^ 28034914019175L ^ 89730069073712L) >>> 48);
      int ax = (int)((友何何树友友何何树友.a ^ 28034914019175L ^ 89730069073712L) << 16 >>> 48);
      int var8 = (int)(var10001 << 32 >>> 32);
      树何树树何树何何树何.N(
         (char)a,
         () -> {
            long axx = 友何何树友友何何树友.a ^ 109755020050472L;
            long axxx = axx ^ 76223793728582L;
            ConcurrentHashMap newCryingObsidian = new ConcurrentHashMap();
            d<"A">(-763248477073759801L, axx);
            int x = chunkX - radius;
            if (x <= chunkX + radius) {
               int z = chunkZ - radius;
               if (z <= chunkZ + radius) {
                  try {
                     if (this.w(new Object[]{axxx})) {
                        return;
                     }

                     LevelChunk chunk = mc.level.getChunk(x, z);
                     this.R(chunk, newCryingObsidian);
                  } catch (Exception var13) {
                  }

                  z++;
               }

               x++;
            }

            if ((Boolean)d<"M">(this, -762978899776530098L, axx).v().get()
               && d<"M">(this, -762978899776530098L, axx).getValue()
               && (Boolean)Fucker.isLogin
               && (Boolean)Fucker.isBeta) {
               d<"M">(this, -762692878423556593L, axx).clear();
               d<"M">(this, -762692878423556593L, axx).putAll(newCryingObsidian);
            }
         },
         (char)ax,
         var8
      );
   }

   @EventTarget
   public void q(WorldEvent event) {
      long a = 友何何树友友何何树友.a ^ 23430608725321L;
      d<"M">(this, 5766613656383259926L, a).clear();
      d<"M">(this, 5767748017032551278L, a).clear();
      this.Y();
   }

   private void U() {
      long a = 友何何树友友何何树友.a ^ 16954332685844L;
      d<"À">(this, new Timer(b<"e">(6024, 7472877647193206589L ^ a), true), 6004845743821629778L, a);
      d<"M">(this, 6004845743821629778L, a).scheduleAtFixedRate(new 友何何树友友何何树友$友树友友树何友友何友(this), 0L, m);
   }

   private void Y() {
      long a = 友何何树友友何何树友.a ^ 10733002468401L;
      d<"À">(this, c<"e">(2005, 5325064350022930897L ^ a), -2778126806366489321L, a);
      d<"À">(this, c<"e">(2005, 5325064350022930897L ^ a), -2778551021584774691L, a);
      d<"À">(this, 0, -2778346438362248503L, a);
   }

   private boolean P(BlockEntity blockEntity) {
      long a = 友何何树友友何何树友.a ^ 103119036693103L;
      d<"A">(5705879955957586816L, a);
      Block block = blockEntity.getBlockState().getBlock();
      return d<"M">(this, 5704558078801543266L, a).getValue() && block instanceof ChestBlock
         || d<"M">(this, 5704959810163804961L, a).getValue() && block instanceof BedBlock;
   }

   private void R(LevelChunk chunk, Map<BlockPos, BlockState> cryingObsidianPos) {
      long a = 友何何树友友何何树友.a ^ 2926035638907L;
      d<"A">(-1208366617172231276L, a);
      int chunkX = d<"M">(chunk.getPos(), -1208978734852031165L, a) * 16;
      int chunkZ = d<"M">(chunk.getPos(), -1208105418605842964L, a) * 16;
      int minY = mc.level.getMinBuildHeight();
      int maxY = mc.level.getMaxBuildHeight();
      if (minY < maxY) {
         int x = 0;
         int z = 0;
         BlockPos pos = new BlockPos(chunkX + 0, minY, chunkZ + 0);
         BlockState state = chunk.getBlockState(pos);
         Block block = state.getBlock();
         if ((Boolean)d<"M">(this, -1208587851053628643L, a).v().get()
            && d<"M">(this, -1208587851053628643L, a).getValue()
            && (Boolean)Fucker.isLogin
            && (Boolean)Fucker.isBeta
            && block == d<"Ñ">(-1208431988570710863L, a)) {
            cryingObsidianPos.put(pos, state);
         }

         z++;
         x++;
         int y = minY + 1;
      }
   }

   private Color G(BlockEntity blockEntity) {
      long a = 友何何树友友何何树友.a ^ 130905830452722L;
      d<"A">(-7443762639641555939L, a);
      Block block = blockEntity.getBlockState().getBlock();
      if (block instanceof ChestBlock && blockEntity instanceof ChestBlockEntity chestBlock) {
         BlockPos pos = chestBlock.getBlockPos();
         float openness = chestBlock.getOpenNess(0.0F);
         if (openness > 0.0F) {
            d<"M">(this, -7440999019188466259L, a).add(pos);
         }

         return d<"M">(this, -7440999019188466259L, a).contains(pos) ? new Color(255, 0, 80) : new Color(80, 255, 0);
      } else {
         return block instanceof BedBlock ? new Color(255, 0, 80) : new Color(255, 255, 255);
      }
   }

   private static String HE_SHU_YOU() {
      return "刘凤楠230622109211173513";
   }
}
