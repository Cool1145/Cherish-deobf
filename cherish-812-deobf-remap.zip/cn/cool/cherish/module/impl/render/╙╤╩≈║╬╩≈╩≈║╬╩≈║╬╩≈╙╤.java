package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.树树何树何何树何何树;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.phys.Vec3;

public final class 友树何树树何树何树友 extends Module implements 何树友 {
   private final BooleanValue 友何友何友树树友树树 = new BooleanValue("Rainbow", "彩虹", false);
   private final BooleanValue 树友树何友树树树树树 = new BooleanValue("Show Name", "显示名称", true);
   private final BooleanValue 何树友树何何友何何友 = new BooleanValue("Cull Offscreen", "剔除屏幕外", true);
   private final BooleanValue 何何友友友何何树何友 = new BooleanValue("Show Enchantments", "显示附魔", true);
   private final NumberValue 友树友何树树树何树何 = new NumberValue("Line Width", "线条宽度", 1.5F, 0.5F, 5.0F, 0.5F);
   private final NumberValue 树友何友何树友树何树 = new NumberValue("Range", "范围", 64, 8, 128, 1);
   private final NumberValue 何树何何树树树树树友 = new NumberValue("Max Items", "最大物品数", 15, 5, 50, 1);
   private final NumberValue 树树何何友树何树树何 = new NumberValue("Update Frequency", "更新频率", 15, 5, 30, 1);
   private final List<友树何树树何树何树友.树树何友树何何树树树> 树树何友友树友树友树 = new CopyOnWriteArrayList<>();
   private final Map<ItemEntity, Component> 友树友何树何友友友树 = new HashMap<>();
   private final Map<ItemEntity, String> 树树何何树何树何树树 = new HashMap<>();
   private final Set<ItemEntity> 友何树树何何何友何友 = new HashSet<>();
   private int 树友何何树何何友树何 = 0;
   private int 友友何何友友友何友友 = -1;
   private int 友友树友树何友树友何 = 0;
   private float 树何友树友树友友树何;
   private float 友何何何何何何树友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[55];
   private static final String[] n = new String[55];
   private static String HE_WEI_LIN;

   public 友树何树树何树何树友() {
      super("ItemESP", "掉落物透视", 树何友友何树友友何何.友友树树何友树树友树);
      this.q();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6418957852714766780L, -4679277636126970222L, MethodHandles.lookup().lookupClass()).a(203164553940958L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var24 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(80124515578828L << var14 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[34];
      int var18 = 0;
      String var17 = "p²4éé\u0095<ë\u009b\u001fA\u001d¢\u0094&âÈ¡ùq=ª;j9(Ý¸§\u0017[Ù \u0007ïc\u001d\u008f$\u0096*RN³í£\u009axg\u008b9n\u0082a\u008c\u0011\u0002\u0012¦°\u0085ÃÌ/# ß\r\u0086\n\u000bg¿ß¯ÊK`öiÔr\u0098\u008b¤f¢\u000402à(~x*\u0090ÏÊ\u0010ÉV;9\u0000\u001djä,\u0015¸ÔÂ|§\u0012 \u0010\u000e|&]y®7X!\u0019±\u0010¤a\u008cai=ÜÿM\u009ahÑ\u0087ù¯\u0005ë\u0083É(7\u001eö\u0016\u001c4sú¤v^ÄÏ¬\u008c\u0000ñ\u008d\u001dc©\u009dï$Ü\u0019H\u0095=\\É\u0084³\r¶¶\u0096iRá(\u0003@W¤0\u0007\u000e\u008d1|%òÉ\u0091\"`\u001b\u001f\u0082\\\u0003Uâ®dT\u0088âøí'£éK\u009fÎ\u0013\u0080fc\u0010û\nép¢¼dÒ  +\u001bÆ\u001cEë(ê~\u0017ú\u0016%,Ã2»IM\fÊñú\u009dÄ\u0083ñÖ\u0082{£·\u00adO=!\u001f¿\\ÛPè¥ÞÝ\r¢ \u0082·\u0090yLpz/¤\u000eÌöH¨?þ¾õ sÃKy\u007f\u0007\u008d×\fíj\u0083\u0095 \u0017\u000f[htÕ\u0094ÌV\u009dO\u008c\u009f¤ZÀª\fÎ\u0001w7ü/Ë>Ê\u0099äHÐ#\u0018=q\u0099ª¬f\"¯<¢\u0015\u0018sBóÖÝ4º·òä+± t\u0019c!Ë&ûÿÓ\u0085Ó\beAÍ\u001bTÕOÝl'ÝÚ³Lf\u009då/TÒ \u009b\fìs>¾7\u000eÚô¡\u00ad¤%Pàïz\u0099.tØ\u009e¶\u0086\u001b\u001dB\u00ad¬N\u008b\u0010\u0005wú«Íå8\u0094ü\u0096À\u0084\u008a\u0089\u008d\u0081\u0010Xö\u008eiïê\u0090\u0089ð\u0087u\u00adXC\u0099=\u0010Ó\u0013qLÌþf\u0019`àÒ²©\u008dÃ:\u0010\u008e\u0092é5â|7UËÕJ\fý\u0097.\u008d\u0010Ù\u008aã\u001a\u0089\u00177b\u0015Áÿç¤Ð3ô\u0010o\u009e°#Ü\u0010N}\u0098:°kq\u0083aS\u0018ñ¿Ù¥Èµv{;2(c \u008av`Ùí\u0094þ¼ù\u008aI >\u0086Õ^\u0012\u0016BrÇ\u00ad©ò})\u0090\u001bñ¿\u0013Õ\u0098.\u0001\u0082=j\u00899}«Q\u0096(¦2¸èm¶\u009d\u0017ÁOßa\u001cLü\u001eB+ho\u0091\u0017\u0082®áO2na{ö\u0005Í²â384w)\u0010xu¼\"pX\u001bÆh+Ì\u008f\u0080m\u008e½\u0010\u0000õÎD¹6æÁm'\u0093èrRvF\u0010É\u000fQjø\u008b\u000e\u0003 tè\u00108áæá(\u000b\u0093B=í¯ª\u0086ÑÞ.\u008eÃ«\bÖ\u0082ñKº\rÏ\u0005\u0082Ûbl\u0097]¦\u0088Ç\u008c÷§\u0001çµÀK ¤zÙ£\u009bu¨\u000e/o[LÛ\u008cýR¢\u0019\u00139ZüV<V4)§6\u001c\n_\u0010×ªM5è\f?\u000f´Ã@\u001e}B\u0006ç\u0010\u0095rðN+j%F\u008eqg)©+¤\u0004 ²WÊà$G\u0090s\u0091ßf\nè\u000bS·\u000e\u0086<à\fª\u000f«ÀI/(4M¢n\u0010\u00820\u0087¢ `Þ²\u0099Õ¥dÑ\nß2";
      short var19 = 855;
      char var16 = ' ';
      int var23 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            String var36 = c(var13.doFinal(var25.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var23 += var16) >= var19) {
                     c = var20;
                     h = new String[34];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var27 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(80124515578828L << var1 * 8 >>> 56);
                     }

                     var27.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[4];
                     int var3 = 0;
                     String var4 = "\u0094\u0004\t]\u0000TÏ%L³\u0014î\u0010È}C";
                     byte var5 = 16;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var43 = -1;

                        while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    j = var6;
                                    k = new Integer[4];
                                    return;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "Ùó\u001f+Ô\u0086Í~\u001eçÍOç¹ºy";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label54;
                  }

                  var17 = "<M\u0091¶/\u0017¬]<©?\u008b\u007f÷W¡\u0010Qø^Ðy0¶|Éçã\u008ec¼gV";
                  var19 = 33;
                  var16 = 16;
                  var23 = -1;
            }

            var25 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   }

   private String I(int number) {
      BetterCamera.e();
      String[] romanNumerals = new String[]{"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
      return number >= 1 && number <= 10 ? romanNumerals[number] : String.valueOf(number);
   }

   private void Z() {
      BetterCamera.e();
      if (this.友何友何友树树友树树.getValue()) {
         if (this.友友树友树何友树友何++ < 3) {
            return;
         }

         this.友友树友树何友树友何 = 0;
         this.友友何何友友友何友友 = 何树友友树树友何树何.t(94608897312632L, 10, 1).getRGB();
      }

      this.友友何何友友友何友友 = 树树何树何何树何何树.树树友友友友树友何何.树树何何友树何何友树.O();
   }

   private boolean V(ItemEntity entity) {
      BetterCamera.e();
      return entity != null && entity.isAlive() && !entity.isRemoved();
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 10;
               case 1 -> 11;
               case 2 -> 53;
               case 3 -> 50;
               case 4 -> 8;
               case 5 -> 39;
               case 6 -> 42;
               case 7 -> 45;
               case 8 -> 19;
               case 9 -> 57;
               case 10 -> 27;
               case 11 -> 41;
               case 12 -> 3;
               case 13 -> 6;
               case 14 -> 33;
               case 15 -> 58;
               case 16 -> 63;
               case 17 -> 21;
               case 18 -> 51;
               case 19 -> 46;
               case 20 -> 28;
               case 21 -> 30;
               case 22 -> 40;
               case 23 -> 7;
               case 24 -> 35;
               case 25 -> 12;
               case 26 -> 38;
               case 27 -> 5;
               case 28 -> 44;
               case 29 -> 14;
               case 30 -> 55;
               case 31 -> 15;
               case 32 -> 31;
               case 33 -> 18;
               case 34 -> 17;
               case 35 -> 4;
               case 36 -> 52;
               case 37 -> 56;
               case 38 -> 29;
               case 39 -> 1;
               case 40 -> 49;
               case 41 -> 32;
               case 42 -> 20;
               case 43 -> 9;
               case 44 -> 23;
               case 45 -> 37;
               case 46 -> 22;
               case 47 -> 13;
               case 48 -> 16;
               case 49 -> 54;
               case 50 -> 2;
               case 51 -> 34;
               case 52 -> 47;
               case 53 -> 59;
               case 54 -> 60;
               case 55 -> 43;
               case 56 -> 25;
               case 57 -> 61;
               case 58 -> 48;
               case 59 -> 0;
               case 60 -> 24;
               case 61 -> 36;
               case 62 -> 26;
               default -> 62;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private String i(ItemEntity itemEntity) {
      return this.树树何何树何树何树树.computeIfAbsent(itemEntity, entity -> {
         d<"î">(9219990380725903677L, 85490846826489L);
         ItemStack itemStack = entity.getItem();
         if (!this.i(itemStack)) {
            return "";
         } else {
            try {
               CompoundTag tag = itemStack.getTag();
               if (tag != null && tag.contains("StoredEnchantments")) {
                  ListTag enchantmentList = tag.getList("StoredEnchantments", 10);
                  if (enchantmentList.isEmpty()) {
                     return "";
                  } else {
                     List<String> enchantmentNames = new ArrayList<>();
                     int i = 0;
                     if (0 < enchantmentList.size()) {
                        CompoundTag enchantmentTag = enchantmentList.getCompound(0);
                        String enchantmentId = enchantmentTag.getString("id");
                        int level = enchantmentTag.getInt("lvl");
                        String name = this.t(enchantmentId);
                        if (level > 1) {
                           name = name + " " + this.I(level);
                        }

                        enchantmentNames.add(name);
                        i++;
                     }

                     return String.join(",", enchantmentNames);
                  }
               } else {
                  return "";
               }
            } catch (Exception var14) {
               return b<"a">(17442, 4255508363834465024L);
            }
         }
      });
   }

   private void i(PoseStack matrixStack, ItemEntity itemEntity, int color, Vec3 cameraPos) {
      d<"î">(1596685860629235942L, 36226246645282L);

      try {
         Component nameComponent = d<"ä">(this, 1596629930616983250L, 36226246645282L).computeIfAbsent(itemEntity, entity -> entity.getItem().getHoverName());
         Vec3 entityPos = itemEntity.position();
         double x = d<"ä">(entityPos, 1596831344135842589L, 36226246645282L);
         double y = d<"ä">(entityPos, 1597325780234548777L, 36226246645282L) + itemEntity.getBbHeight() + 0.5;
         double z = d<"ä">(entityPos, 1597055449797723852L, 36226246645282L);
         float distanceSq = (float)cameraPos.distanceToSqr(x, y, z);
         if (distanceSq <= d<"ä">(this, 1595691065243411994L, 36226246645282L)) {
            matrixStack.pushPose();
            matrixStack.translate(
               x - d<"ä">(cameraPos, 1596831344135842589L, 36226246645282L),
               y - d<"ä">(cameraPos, 1597325780234548777L, 36226246645282L),
               z - d<"ä">(cameraPos, 1597055449797723852L, 36226246645282L)
            );
            matrixStack.mulPose(d<"ä">(mc, 1597287481277711589L, 36226246645282L).getMainCamera().rotation());
            float scale = distanceSq > 100.0F ? 0.025F * (float)Math.sqrt(distanceSq * 0.01F) : 0.025F;
            matrixStack.scale(-scale, -scale, scale);
            String enchantmentText = null;
            if (d<"ä">(this, 1595516216890928066L, 36226246645282L).getValue() && this.i(itemEntity.getItem())) {
               enchantmentText = this.i(itemEntity);
            }

            float nameWidth = d<"ä">(mc, 1598507726889127086L, 36226246645282L).width(nameComponent);
            float enchantWidth = d<"ä">(mc, 1598507726889127086L, 36226246645282L).width(enchantmentText);
            float nameX = -nameWidth * 0.5F;
            float enchantX = -enchantWidth * 0.5F;
            int backgroundColor = c<"i">(20198, 1112642875123674309L);
            int enchantColor = c<"i">(9806, 3343650699288003694L);
            BufferSource bufferSource = mc.renderBuffers().bufferSource();
            d<"ä">(mc, 1598507726889127086L, 36226246645282L)
               .drawInBatch(
                  nameComponent,
                  nameX,
                  0.0F,
                  color,
                  false,
                  matrixStack.last().pose(),
                  bufferSource,
                  d<"Þ">(1595940058746099077L, 36226246645282L),
                  backgroundColor,
                  c<"i">(30507, 1001538746346542346L)
               );
            if (!enchantmentText.isEmpty()) {
               d<"ä">(mc, 1598507726889127086L, 36226246645282L)
                  .drawInBatch(
                     Component.literal(enchantmentText),
                     enchantX,
                     10.0F,
                     enchantColor,
                     false,
                     matrixStack.last().pose(),
                     bufferSource,
                     d<"Þ">(1595940058746099077L, 36226246645282L),
                     backgroundColor,
                     c<"i">(26004, 7626484999486179254L)
                  );
            }

            bufferSource.endBatch();
            matrixStack.popPose();
         }
      } catch (Exception var26) {
         d<"ä">(this, 1596629930616983250L, 36226246645282L).remove(itemEntity);
         d<"ä">(this, 1596802043662606157L, 36226246645282L).remove(itemEntity);
      }
   }

   private boolean i(ItemStack itemStack) {
      return itemStack.getItem() == Items.ENCHANTED_BOOK;
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何树树何树何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24362;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何树树何树何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u009e3®±Â Ã¿\u0094öúCóW\u0086\u0017, $u\u009b\u001aÄ\u0096°½ýîsE4\u0010\u0097[, ñ¨·\u0086l\u001fÎ\u0095ºi\u001cÛ£Ðô_, \u0084Ð\u0011\u0081åÏêß, Wb\u0018m\u0013¼\u009a~´¥\u0080³=\u008aÑa, ×®k\u0011ØNô£{££|1±µI\u001a+,%Ìk-\u0094, ÀøjV&\u0010l\u001a:[@»¾h¦=»°óæ×<ð°, ¬\u0013aTy$")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25120;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何树树何树何树友", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何树树何树何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 228 && var8 != 253 && var8 != 222 && var8 != 'o') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'Y') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 238) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 228) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 253) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 222) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @Override
   public void h() {
      super.h();
      this.K();
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何树树何树何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private boolean d(ItemEntity entity, Vec3 cameraPos) {
      BetterCamera.e();
      Vec3 entityPos = entity.position();
      Vec3 toEntity = entityPos.subtract(cameraPos);
      if (toEntity.lengthSqr() < 4.0) {
         return true;
      } else {
         double playerYaw = Math.toRadians(mc.player.getYRot());
         double playerPitch = Math.toRadians(mc.player.getXRot());
         Vec3 lookDirection = new Vec3(-Math.sin(playerYaw) * Math.cos(playerPitch), -Math.sin(playerPitch), Math.cos(playerYaw) * Math.cos(playerPitch));
         Vec3 normalizedToEntity = toEntity.normalize();
         double dotProduct = normalizedToEntity.dot(lookDirection);
         return dotProduct > -0.5;
      }
   }

   private static void a() {
      m[0] = "O4e5\u0015m@t(>\u001fpE)#x\u0017mH/'3TkA*'x\bgB>.$T@I.?3\bAM7.$\u001b";
      m[1] = "\tm\"7\u0013q\u0002b3xni\u0011e:1";
      m[2] = "yWM\fEcv\u0017\u0000\u0007O~sJ\u000bAGc~L\u000f\n\u0004ewI\u000fAXit]\u0006\u001d\u0004叇栋佬桲桾使栝住栨厨";
      m[3] = "R\u0004(\u0013[\u0014Y\u000b9\\0\u0000[\u0000.\u0006\u001c\u0017V";
      m[4] = "m7\b>\u000f#m7\u001fb\u0003,w|\u000b\u007f\u0010&g|\u0015d\u0007'-\u001b\bu\u000f9";
      m[5] = "Pt{:TYPtlfXVJ?x{K\\Z?f`\\]\u0010X{qT";
      m[6] = "\u001c\r\u0014\u007fp1\u0002\u0005\u000e0\u0012-\u0005\u0018";
      m[7] = "bo\u0019(pi|g\u0003g\ry|";
      m[8] = "0SiP0\\?\u0013$[:A:N/\u001d2\\7H+VqZ>M+\u001d;Z M+R&\u001d桂栬伒栢伊佦桂佨伒栢";
      m[9] = "\u001eW]y,<\u0011\u0017\u0010r&!\u0014J\u001b452\u0011L\u00164*>\rU]栋厈伆伨栨桢住厈厘伨";
      m[10] = int.class;
      n[10] = "java/lang/Integer";
      m[11] = ">wga\u0002?17*j\b\"4j!,\u001b11l,,\u0004=-ug@\u0002?1|(l;11l,";
      m[12] = "v\u0018r4c(v\u0018eho'lSeu|$6\u000fc}g2l\u000fo\u007f}oZ\bovz\bv/c}g2l\u000fo\u007f}";
      m[13] = "|c\u0019W|/|c\u000e\u000bp f(\u000e\u0016c#<T\b\u001ex5ft\u0014";
      m[14] = "k{7\u0010[Ous-_8[q";
      m[15] = float.class;
      n[15] = "java/lang/Float";
      m[16] = "f\u0001L8\u0012\u007fiA\u00013\u0018bl\u001c\nu\u000bqi\u001a\u0007u\u0014}u\u0003L\u0015\b}g\n\u0010\r\u001c|p\n";
      m[17] = "\u0003NTT-l\u0003NC\b!c\u0019\u0005W\u00152i\t\u0005P\u00129vC}E\u0019s";
      m[18] = double.class;
      n[18] = "java/lang/Double";
      m[19] = "/h(\f\u0015'/h?P\u0019(5#?N\u0011+/yrE\r'oK3L\fj\u0005d/R\u0014/8@3F\u001d";
      m[20] = "[<Ic\th[<^?\u0005gAw^!\rd[-\u0013\u0000\roP:O,\u0002u";
      m[21] = "scq{;Oscf'7@i(f9?Csr+'3Hycw0$\bZgh0\u0004Csb`'3T";
      m[22] = "B\u0013FB\u0019%B\u0013Q\u001e\u0015*XXQ\u0000\u001d)B\u0002\u001c\u000b\u0001%\u00020]\u0002\u0000";
      m[23] = "0bm;O\f?\" 0E\u0011:\u007f+vM\f7y/=\u000e桲伆叇厈伍栱厨厘余伖";
      m[24] = "4\u0005}Q^\t?\nl\u001e?\u00074\u0001hD";
      m[25] = "M2uX,[H;uD@佸伩厔发古伝佸桭伊发'p\u001d\u001d4nZ\u007fY\u0017f";
      m[26] = "9}yO<=<tySP桚參佅叝佭桉厀栙佅标0:;lj#T( pt";
      m[27] = "?\u0019}\u00165j~\u000e+K\u0005{RU|I4-Ri}\u0013:k\u007f\u0000(Odo";
      m[28] = "@w\u000e~!kE~\u000ebM栌伤发桰参桔取厺栋伴\u0001$g\u0000,\u0013{0h\b/";
      m[29] = "g2Cl\u001f<b;Cps+^mKz\u000e \"(Mt\u0013Bd8Mn\u0011>!>Css";
      m[30] = "&{\u0003G{x#r\u0003[\u0017栟栆佃厧叻栎叅栆叝桽8+;o$\u0007R~jgp";
      m[31] = "\u001883#h\u0012N0<-\rv9\u0013\u001a\u0014Mw3\u0003\u0002\b\rA\u0012 &-2\u0017\u001a/(";
      m[32] = "iNE\u0014KslGE\b'栔桉佶使厨栾佐桉栲使kMu<Y\u001f\u000f_n G";
      m[33] = "Nqm\u0015s,Kxm\t\u001f厑厴佉佗厩叜厑伪受叉j >\u0018pc\u0011`=Me";
      m[34] = "3\u001e|J[<8\u0015uMei\tM J[<\t|wL\u0002:;\u001f&H\u0017g";
      m[35] = "2; _j\u0016 (\u007fT\u0014\u0001\u000fuyX$W\u000fE/^+\u000e`)s\u0001*\u0002";
      m[36] = "d\r\u000bINxa\u0004\u000bU\"栟厞桱伱叵栻栟桄桱桵6\u0012>4\u000b\u0010K\u001dz>Y";
      m[37] = "RP&o+qWY&sG双伶栬桘位会佒厨佨厂\u0010z6\nP}w(2\u0002W";
      m[38] = "^S\u007f\u001a1%[Z\u007f\u0006]厘伺叵佅厦桄桂厤栯栁emc\u000eUd\u0018b'\u0004\u0007";
      m[39] = "\\h+nlf[2)q\u0003桇桸佖休取栚伃似又桕\u0015=9\u0000mq)o3\u0010k";
      m[40] = "w`\f\u001egOri\f\u0002\u000b史厍栜厨桸佖史桗叆伶a4]!a\u0002\u001at^tt";
      m[41] = "p-Y\u001cF\u0017u$Y\u0000*厪桐压佣桺佷厪厊压栧cCS 2P\u0004SY7&";
      m[42] = "v:\u001f\u0003R\u0018j/\u0005xC%,.Y\u0012V]y~\u000e\u0007.";
      m[43] = "4y~q2E1p~m^栢栔佁佄栗伃栢佐栅栀\u000e7\u0001dfwi'\u000bsr";
      m[44] = "F\u001b\u0002]\u0002HT\b]V|_{U[ZC\u0000{e\r\\CP\u0014\tQ\u0003B\\";
      m[45] = "\u00010\n}$T\u00049\naH叩佥伈估佟伕佷校厖估\u0002!XAk\u0017x5WIh";
      m[46] = "Y $>\u0014s^z&!{桒桽厀厀历厸桒厧伞伞EF(\u00038,}Ar\u0001'";
      m[47] = "CjAmg/Qy\u001ef\u00198~$\u0018j)o~\u0014Nl&7\u0011x\u00123';";
      m[48] = "6\u001fb\u001c\u0015\u00013\u0016b\u0000y厼栖厹佘桺桠桦佒档佘c\u0013\u0007c\b8\u0007\u0001\u001c\u007f\u0016";
      m[49] = "\u0001x-9A^\u0004q-%-佽校叞桓伛佰口佥佀厉F\u001d\u0018Q~6;\u0012\\[,";
      m[50] = "r5?#A\u0014y;r,1\u001d\u0015os#\u0001L|\u0002N,\bB.47sH\u0003{";
      m[51] = "2Tt0$y7]t,H佚栒佬低桖桑栞栒栨叐O\"\u007fgC.+0d{]";
      m[52] = "YF-[,BRM$\\\u0012\u0017c\u0015q[,Cc$&\u001d\u007fCZHt\u000fxG";
      m[53] = "j\r\u0016R>7o\u0004\u0016NR桐厐伵伬栴伏伔厐桱伬-m%<\f\u0018V-&i\u0019";
      m[54] = "TXl\ni\u007fQ\u00138^\u0011叚叹栳栙伲叒栀栣叩栙o\u007fkVOx\tz \u0002\u001b";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private void m() {
      this.q();
      this.r();
      BetterCamera.e();
      Vec3 playerPos = mc.player.position();

      for (Entity entity : mc.level.entitiesForRendering()) {
         if (entity instanceof ItemEntity itemEntity) {
            double distanceSq = playerPos.distanceToSqr(entity.position());
            if (!(distanceSq > this.友何何何何何何树友何)) {
               boolean found = false;
               Iterator var11 = this.树树何友友树友树友树.iterator();
               if (var11.hasNext()) {
                  友树何树树何树何树友.树树何友树何何树树树 data = (友树何树树何树何树友.树树何友树何何树树树)var11.next();
                  if (data.s() == itemEntity) {
                     data.y(Math.sqrt(distanceSq));
                     found = true;
                  }
               }

               if (!found && distanceSq <= this.树何友树友树友友树何) {
                  this.树树何友友树友树友树.add(new 友树何树树何树何树友.树树何友树何何树树树(itemEntity, Math.sqrt(distanceSq)));
               }
               break;
            }
         }
      }

      if (this.树树何友友树友树友树.size() > 1) {
         this.树树何友友树友树友树.sort(Comparator.comparingDouble(友树何树树何树何树友.树树何友树何何树树树::x));
      }

      int limit = this.何树何何树树树树树友.getValue().intValue();
      if (this.树树何友友树友树友树.size() > limit) {
         List<友树何树树何树何树友.树树何友树何何树树树> toRemoveData = this.树树何友友树友树友树.subList(limit, this.树树何友友树友树友树.size());
         Iterator var15 = toRemoveData.iterator();
         if (var15.hasNext()) {
            友树何树树何树何树友.树树何友树何何树树树 data = (友树何树树何树何树友.树树何友树何何树树树)var15.next();
            this.友树友何树何友友友树.remove(data.s());
            this.树树何何树何树何树树.remove(data.s());
         }

         toRemoveData.clear();
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private String t(String enchantmentId) {
      BetterCamera.e();

      try {
         ResourceLocation resourceLocation = ResourceLocation.parse(enchantmentId);
         Enchantment enchantment = (Enchantment)BuiltInRegistries.ENCHANTMENT.get(resourceLocation);
         if (enchantment != null) {
            Component displayName = enchantment.getFullname(1);
            String fullName = displayName.getString();
            return fullName.replaceAll("I$", "");
         }
      } catch (Exception var9) {
      }

      if (enchantmentId.startsWith("minecraft:")) {
         enchantmentId = enchantmentId.substring(10);
      }

      return enchantmentId.replace("_", " ");
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void q() {
      float rangeValue = this.树友何友何树友树何树.getValue().floatValue();
      this.树何友树友树友友树何 = rangeValue * rangeValue;
      this.友何何何何何何树友何 = this.树何友树友树友友树何 * 1.44F;
   }

   private void r() {
      this.友何树树何何何友何友.clear();
      BetterCamera.e();
      Iterator var4 = this.树树何友友树友树友树.iterator();
      if (var4.hasNext()) {
         友树何树树何树何树友.树树何友树何何树树树 data = (友树何树树何树何树友.树树何友树何何树树树)var4.next();
         if (!this.V(data.s())) {
            this.友何树树何何何友何友.add(data.s());
         }
      }

      if (!this.友何树树何何何友何友.isEmpty()) {
         this.树树何友友树友树友树.removeIf(datax -> this.友何树树何何何友何友.contains(datax.s()));
         this.友何树树何何何友何友.forEach(entity -> {
            this.友树友何树何友友友树.remove(entity);
            this.树树何何树何树何树树.remove(entity);
         });
      }
   }

   @Override
   public void M() {
      super.M();
      this.K();
      this.q();
   }

   private void K() {
      this.树树何友友树友树友树.clear();
      this.友树友何树何友友友树.clear();
      this.树树何何树何树何树树.clear();
      this.友何树树何何何友何友.clear();
   }

   @EventTarget
   public void K(Render3DEvent event) {
      BetterCamera.e();
      if (mc.level != null && mc.player != null) {
         this.树友何何树何何友树何++;
         if (this.树友何何树何何友树何 >= this.树树何何友树何树树何.getValue().intValue() || this.树树何友友树友树友树.isEmpty()) {
            this.树友何何树何何友树何 = 0;
            this.m();
         }

         this.Z();
         PoseStack poseStack = event.poseStack();
         Vec3 cameraPos = mc.gameRenderer.getMainCamera().getPosition();
         Iterator var9 = this.树树何友友树友树友树.iterator();
         if (var9.hasNext()) {
            友树何树树何树何树友.树树何友树何何树树树 data = (友树何树树何树何树友.树树何友树何何树树树)var9.next();
            ItemEntity itemEntity = data.s();
            if (!this.V(itemEntity)) {
            }

            if (this.何树友树何何友何何友.getValue() && !this.d(itemEntity, cameraPos)) {
            }

            友友何何友友树何何友.C(poseStack, itemEntity, this.友友何何友友友何友友, this.友树友何树树树何树何.getValue().floatValue(), 62387300884722L);
            if (this.树友树何友树树树树树.getValue()) {
               this.i(poseStack, itemEntity, this.友友何何友友友何友友, cameraPos);
            }
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "职业技术教育中心学校";
   }

   private static class 树树何友树何何树树树 implements 何树友 {
      private final ItemEntity 友友何树友树友友树何;
      private double 何友友友树友何友友友;
      private static final long a;
      private static final Object[] b = new Object[6];
      private static final String[] c = new String[6];
      private static String HE_WEI_LIN;

      public 树树何友树何何树树树(ItemEntity entity, double distance) {
         this.友友何树友树友友树何 = entity;
         this.何友友友树友何友友友 = distance;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-8430429499924801515L, 2557510539443866126L, MethodHandles.lookup().lookupClass()).a(215999636470321L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      public double x() {
         return this.何友友友树友何友友友;
      }

      public ItemEntity s() {
         return this.友友何树友树友友树何;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何树树何树何树友$树树何友树何何树树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'J' && var8 != 224 && var8 != 170 && var8 != 'z') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 164) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 197) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'J') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 224) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 170) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 17;
                  case 1 -> 48;
                  case 2 -> 36;
                  case 3 -> 21;
                  case 4 -> 44;
                  case 5 -> 46;
                  case 6 -> 4;
                  case 7 -> 11;
                  case 8 -> 7;
                  case 9 -> 14;
                  case 10 -> 54;
                  case 11 -> 55;
                  case 12 -> 27;
                  case 13 -> 25;
                  case 14 -> 42;
                  case 15 -> 47;
                  case 16 -> 60;
                  case 17 -> 6;
                  case 18 -> 59;
                  case 19 -> 57;
                  case 20 -> 20;
                  case 21 -> 41;
                  case 22 -> 28;
                  case 23 -> 31;
                  case 24 -> 32;
                  case 25 -> 3;
                  case 26 -> 58;
                  case 27 -> 35;
                  case 28 -> 29;
                  case 29 -> 23;
                  case 30 -> 9;
                  case 31 -> 18;
                  case 32 -> 38;
                  case 33 -> 16;
                  case 34 -> 13;
                  case 35 -> 30;
                  case 36 -> 39;
                  case 37 -> 0;
                  case 38 -> 5;
                  case 39 -> 43;
                  case 40 -> 50;
                  case 41 -> 10;
                  case 42 -> 56;
                  case 43 -> 15;
                  case 44 -> 52;
                  case 45 -> 51;
                  case 46 -> 61;
                  case 47 -> 62;
                  case 48 -> 53;
                  case 49 -> 63;
                  case 50 -> 8;
                  case 51 -> 37;
                  case 52 -> 26;
                  case 53 -> 49;
                  case 54 -> 33;
                  case 55 -> 19;
                  case 56 -> 45;
                  case 57 -> 12;
                  case 58 -> 40;
                  case 59 -> 24;
                  case 60 -> 1;
                  case 61 -> 22;
                  case 62 -> 2;
                  default -> 34;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "\u0013GS42R\u001c\u0007\u001e?8O\u0019Z\u0015y0R\u0014\\\u00112sT\u001dY\u0011y/X\u001eM\u0018%s叶桡佼桬框伈栬伥核厶s桌栬伥叢桬伂伈栬桡核";
         b[1] = ")E!E\u0004P)E6\u0019\b_3\u000e\"\u0004\u001bU#\u000e0\u0005\u001dP3Y{\u0002\u001d\\*\u000e\u001c\u001f\fT\u0002N!\u0002\u001d@";
         b[2] = double.class;
         c[2] = "java/lang/Double";
         b[3] = "_F\u0001\u0010/JTI\u0010_ND_B\u0014\u0005";
         b[4] = "\u0013Dttk3\r\b\"\u000e佈収厼号标反佈収厼号\u001e7eh\u0011\nwon3\u0007";
         b[5] = "\u0001\u0002\u0003-c~\u001fNUW叞厃估桫厪桎叞厃桴伯i%|*\u0017J\u001b6#<";
      }

      public void y(double newDistance) {
         this.何友友友树友何友友友 = newDistance;
      }

      private static String HE_WEI_LIN() {
         return "我是何树友";
      }
   }
}
