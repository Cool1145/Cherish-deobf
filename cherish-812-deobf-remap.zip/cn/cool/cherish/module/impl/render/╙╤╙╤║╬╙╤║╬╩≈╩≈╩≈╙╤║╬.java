package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友友何友何树树树友何 extends Module implements 何树友 {
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[27];
   private static final String[] k = new String[27];
   private static String HE_WEI_LIN;

   public 友友何友何树树树友何() {
      super("BACave", "碧蓝光环", 树何友友何树友友何何.友友树树何友树树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5969064590810248960L, 2228599371353074312L, MethodHandles.lookup().lookupClass()).a(270257583020663L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(135131537516757L << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 16;
      int var4 = -1;

      while (true) {
         String var13 = c(
               var2.doFinal(
                  "©\u0005æ¢*¾J\u00137O|Q\u001eGs\r Ó±TÊhi¾éÞ-ÿ\u0094\u0013(ê+\\1-\u009d»ñ\u0081\u001d\u0015µ\u009cK\u00ad<Ã\u0012"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 49) {
            c = var9;
            h = new String[2];
            return;
         }

         var5 = "©\u0005æ¢*¾J\u00137O|Q\u001eGs\r Ó±TÊhi¾éÞ-ÿ\u0094\u0013(ê+\\1-\u009d»ñ\u0081\u001d\u0015µ\u009cK\u00ad<Ã\u0012".charAt(var4);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private void e(PoseStack poseStack, float radius, float yOffset, float lineWidth, Color color, float lineLength) {
      RenderSystem.lineWidth(lineWidth * (float)mc.getWindow().getGuiScale());
      BetterCamera.e();
      Tesselator tesselator = Tesselator.getInstance();
      BufferBuilder bufferBuilder = tesselator.getBuilder();
      bufferBuilder.begin(Mode.DEBUG_LINE_STRIP, DefaultVertexFormat.POSITION_COLOR);
      int i = 0;
      double x = Math.cos(0.0) * radius;
      double z = Math.sin(0.0) * radius;
      bufferBuilder.vertex(poseStack.last().pose(), (float)x, yOffset, (float)z)
         .color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F)
         .endVertex();
      i++;
      tesselator.end();
      bufferBuilder.begin(Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
      float r = color.getRed() / 255.0F;
      float g = color.getGreen() / 255.0F;
      float b = color.getBlue() / 255.0F;
      float a = color.getAlpha() / 255.0F;
      bufferBuilder.vertex(poseStack.last().pose(), 0.0F, yOffset, -radius).color(r, g, b, a).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), 0.0F, yOffset, -radius - lineLength).color(r, g, b, a).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), 0.0F, yOffset, radius).color(r, g, b, a).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), 0.0F, yOffset, radius + lineLength).color(r, g, b, a).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), radius, yOffset, 0.0F).color(r, g, b, a).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), radius + lineLength, yOffset, 0.0F).color(r, g, b, a).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), -radius, yOffset, 0.0F).color(r, g, b, a).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), -radius - lineLength, yOffset, 0.0F).color(r, g, b, a).endVertex();
      tesselator.end();
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 2;
               case 1 -> 19;
               case 2 -> 33;
               case 3 -> 26;
               case 4 -> 54;
               case 5 -> 28;
               case 6 -> 39;
               case 7 -> 21;
               case 8 -> 3;
               case 9 -> 46;
               case 10 -> 15;
               case 11 -> 47;
               case 12 -> 34;
               case 13 -> 16;
               case 14 -> 59;
               case 15 -> 50;
               case 16 -> 8;
               case 17 -> 60;
               case 18 -> 29;
               case 19 -> 49;
               case 20 -> 38;
               case 21 -> 14;
               case 22 -> 13;
               case 23 -> 58;
               case 24 -> 17;
               case 25 -> 51;
               case 26 -> 41;
               case 27 -> 55;
               case 28 -> 22;
               case 29 -> 63;
               case 30 -> 27;
               case 31 -> 30;
               case 32 -> 11;
               case 33 -> 57;
               case 34 -> 12;
               case 35 -> 40;
               case 36 -> 5;
               case 37 -> 23;
               case 38 -> 7;
               case 39 -> 43;
               case 40 -> 48;
               case 41 -> 44;
               case 42 -> 42;
               case 43 -> 9;
               case 44 -> 32;
               case 45 -> 6;
               case 46 -> 18;
               case 47 -> 61;
               case 48 -> 0;
               case 49 -> 37;
               case 50 -> 10;
               case 51 -> 24;
               case 52 -> 20;
               case 53 -> 56;
               case 54 -> 31;
               case 55 -> 53;
               case 56 -> 45;
               case 57 -> 4;
               case 58 -> 25;
               case 59 -> 35;
               case 60 -> 1;
               case 61 -> 62;
               case 62 -> 36;
               default -> 52;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友友何友何树树树友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 4729;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友友何友何树树树友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'W' && var8 != 'q' && var8 != 250 && var8 != 204) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 208) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'W') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'q') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 250) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友友何友何树树树友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "\u001a:W9L\u0004\u0015z\u001a2F\u0019\u0010'\u0011tN\u0004\u001d!\u0015?\r桺伬原厲伏栲厠厲企伬";
      j[1] = "nz\u001fI\b\u0015a:RB\u0002\bdgY\u0004\n\u0015ia]OI\u0013`d]\u0004\u0015\u001fcpTXI8h`EO\u00159lyTX\u0006";
      j[2] = "\u000e\u0006.\u0016!\u007f\u0005\t?Y\\g\u0016\u000e6\u0010";
      j[3] = "<\u0013\tC\u0010\u00043SDH\u001a\u00196\u000eO\u000e\u0012\u0004;\bKEQ\u00022\rK\u000e\r\u000e1\u0019BRQ厠厔伨召併桮桺桎厶佲";
      j[4] = "\u0011 \u001a\u0013=\u001a\u001a/\u000b\\A\u0003\u00155\u0005\u001fv3\u0003\"\t\u0002g\u001f\u0014/";
      j[5] = "?M\u001ac\u000f26C\u0019*L?0C\r(Q9rT\u0012?\u00168$\f!(\u0010)9Z1\"\u00100=VS\u0000\r99";
      j[6] = "o\u0014$NR\u000bf\u001a'\u0007\u0011\u0006`\u001a3\u0005\f\u0000\"\r,\u0012K\u0001tU\r\u0005Y\u0005y\u0017=6Z\u0016x\u001e1&P\u0016a\u001a=";
      j[7] = "\tnr\u0005[Y\u0000`qL\u0018T\u0006`eN\u0005RDwzYBS\u0012/INDB\u000fyYDD[\u000bu";
      j[8] = "\u0006\u001d_/P=\u0006\u001dHs\\2\u001cV\\nO8\fV[iD'F.Nb\u000e";
      j[9] = double.class;
      k[9] = "java/lang/Double";
      j[10] = "kC\u001b5\\lkC\fiPcq\b\fwX`kRAk]d|C\u001d5}jfG\u0003K]d|C\u001d";
      j[11] = "\u0013^N<R%\u0013^Y`^*\t\u0015Y~V)\u0013O\u0014_V\"\u0018XHsY8";
      j[12] = "i\u007f\u0016KCgi\u007f\u0001\u0017Ohs4\u0001\tGkinL\u0017K`c\u007f\u0010\u0000\\ @{\u000f\u0000|ki~\u0007\u0017K|";
      j[13] = "\u0007!/]2\u0019\f.>\u0012S\u0017\u0007%:H";
      j[14] = "6h:.!7q(:_wPquz:zayxr`\u001a";
      j[15] = "%\u0016\u001d4HL\"\tX2/FO_\u001ak\u0010\u0019Oo\u001e:I\u0012 \u0011\u00186]X";
      j[16] = "@mJ\u0014\u0001{Fn\u001cVzj(n\u001c\u0011K<(W\u0013C\u001c>G)\u0015O\bt";
      j[17] = "o:\u0001&Z\u0016h%D =\u001c\u0005s\u0006y\rK\u0005C\u0002([Hj=\u0004$O\u0002";
      j[18] = "v4%t{qq,qv\u001d&Li#gsw\"5utvOw;7t%!+m$q\u001d";
      j[19] = "\u0000ay[_~\u0000\u007fy\u001dnsh/{[P&h\u001er\u0013\u001fyB./S\u001f$";
      j[20] = "K\u00108P\u0017+\u001e\u0013+]{\u0007=>\u000fs,\u000f12\u001fg{p\u0014\u001e>P\u001b%\u0017\r3";
      j[21] = "t:$JbQxb-\u001dST\u001fckFj\u0007\u001fSk\u00178H#\"n\u0004=G";
      j[22] = "N-\u000eY\u007f.H.X\u001b\u0004?&.X\\5h&\u0017W\u000ebkIiQ\u0002v!";
      j[23] = "\u000b\u001fjM\b;\f\u0000/Ko1aVm\u0012_gafiC\te\u000e\u0018oO\u001d/";
      j[24] = "R#5Y_i\u0013gy&厬叓桵框佔句桶栉厯框\t\u0018\u0013,\u0013opYW`";
      j[25] = "\n-G0j.\f.\u0011r\u0011?b.\u00115 kb\u0017\u001egwk\ri\u0018kc!";
      j[26] = "{\t90b..\n*=\u000e\u0002\r'\u000e\u0013Y\n\u0001+\u001e\u000bU\u0012\u001a,\u000b\\5**\u0001?<`)9\f";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void P(Render3DEvent event) {
      if (!this.Q(new Object[]{52406761729175L})) {
         ;
      }
   }

   private static String HE_DA_WEI() {
      return "何大伟230622198107200054";
   }
}
