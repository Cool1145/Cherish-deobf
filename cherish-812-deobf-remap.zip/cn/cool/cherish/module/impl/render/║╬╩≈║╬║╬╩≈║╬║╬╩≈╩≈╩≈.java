package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.render.友友树何树树友树友何;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.phys.Vec3;

public final class 何树何何树何何树树树 extends Module implements 何树友 {
   private final BooleanValue 友友树何何何树树树友;
   private final BooleanValue 友友友树树何何何树何;
   private final BooleanValue 何友树树树何何树树何;
   private final BooleanValue 何友友何何友树友友树;
   private final NumberValue 何树树何树何友树树何;
   private final NumberValue 树树友友树友树何友树;
   private final NumberValue 树何树树友树友何何何;
   private final NumberValue 树树何友何何友树何何;
   private final List<何树何何树何何树树树.何何树树何何树友何何> 树树友友友友树何友树;
   private final Map<ItemEntity, Component> 何树何何树友何树友树;
   private final Map<ItemEntity, String> 何友友树树何何友友树;
   private final Set<ItemEntity> 何何树树友何友何树友;
   private int 友何何何树何树树友树;
   private int 何树何树树友友树树树;
   private int 友何何友友友友何树友;
   private float 友友树何树何友何树友;
   private float 何友树友何树何友何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[55];
   private static final String[] n = new String[55];
   private static String HE_JIAN_GUO;

   public 何树何何树何何树树树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/render/何树何何树何何树树树.a J
      // 003: ldc2_w 85409550490204
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 12548
      // 00c: ldc2_w 1037107083465395786
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 22118
      // 019: ldc2_w 7530000804151781684
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w -1274832881939575308
      // 026: lload 1
      // 027: invokedynamic ù (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/BooleanValue
      // 033: dup
      // 034: sipush 16859
      // 037: ldc2_w 4075729709124615813
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 6954
      // 044: ldc2_w 2527828448562685018
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 0
      // 04f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 052: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 055: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.友友树何何何树树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 058: aload 0
      // 059: new cn/cool/cherish/value/impl/BooleanValue
      // 05c: dup
      // 05d: sipush 11636
      // 060: ldc2_w 7002587574047543844
      // 063: lload 1
      // 064: lxor
      // 065: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 06a: sipush 5060
      // 06d: ldc2_w 3030849042015988892
      // 070: lload 1
      // 071: lxor
      // 072: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 077: bipush 1
      // 078: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 07b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 07e: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.友友友树树何何何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 081: aload 0
      // 082: new cn/cool/cherish/value/impl/BooleanValue
      // 085: dup
      // 086: sipush 19500
      // 089: ldc2_w 2251827803421864824
      // 08c: lload 1
      // 08d: lxor
      // 08e: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 093: sipush 3696
      // 096: ldc2_w 3385672910427861283
      // 099: lload 1
      // 09a: lxor
      // 09b: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a0: bipush 1
      // 0a1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0a4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0a7: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.何友树树树何何树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0aa: aload 0
      // 0ab: new cn/cool/cherish/value/impl/BooleanValue
      // 0ae: dup
      // 0af: sipush 16153
      // 0b2: ldc2_w 5844426924071485526
      // 0b5: lload 1
      // 0b6: lxor
      // 0b7: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bc: sipush 23091
      // 0bf: ldc2_w 4456559183981667650
      // 0c2: lload 1
      // 0c3: lxor
      // 0c4: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c9: bipush 1
      // 0ca: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0cd: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0d0: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.何友友何何友树友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0d3: aload 0
      // 0d4: new cn/cool/cherish/value/impl/NumberValue
      // 0d7: dup
      // 0d8: sipush 25161
      // 0db: ldc2_w 8922980365814324499
      // 0de: lload 1
      // 0df: lxor
      // 0e0: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e5: sipush 9098
      // 0e8: ldc2_w 3821356420088274120
      // 0eb: lload 1
      // 0ec: lxor
      // 0ed: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f2: ldc 1.5
      // 0f4: invokestatic java/lang/Float.valueOf (F)Ljava/lang/Float;
      // 0f7: ldc 0.5
      // 0f9: invokestatic java/lang/Float.valueOf (F)Ljava/lang/Float;
      // 0fc: ldc 5.0
      // 0fe: invokestatic java/lang/Float.valueOf (F)Ljava/lang/Float;
      // 101: ldc 0.5
      // 103: invokestatic java/lang/Float.valueOf (F)Ljava/lang/Float;
      // 106: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 109: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.何树树何树何友树树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 10c: aload 0
      // 10d: new cn/cool/cherish/value/impl/NumberValue
      // 110: dup
      // 111: sipush 17152
      // 114: ldc2_w 9203109210381417545
      // 117: lload 1
      // 118: lxor
      // 119: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11e: sipush 22444
      // 121: ldc2_w 7159541640408590564
      // 124: lload 1
      // 125: lxor
      // 126: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 12b: bipush 64
      // 12d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 130: bipush 8
      // 132: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 135: sipush 128
      // 138: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 13b: bipush 1
      // 13c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 13f: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 142: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.树树友友树友树何友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 145: aload 0
      // 146: new cn/cool/cherish/value/impl/NumberValue
      // 149: dup
      // 14a: sipush 7438
      // 14d: ldc2_w 6559763611353621061
      // 150: lload 1
      // 151: lxor
      // 152: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 157: sipush 18574
      // 15a: ldc2_w 270874666382489555
      // 15d: lload 1
      // 15e: lxor
      // 15f: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 164: bipush 15
      // 166: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 169: bipush 5
      // 16a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 16d: bipush 50
      // 16f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 172: bipush 1
      // 173: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 176: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 179: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.树何树树友树友何何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 17c: aload 0
      // 17d: new cn/cool/cherish/value/impl/NumberValue
      // 180: dup
      // 181: sipush 3497
      // 184: ldc2_w 7298686908682121965
      // 187: lload 1
      // 188: lxor
      // 189: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 18e: sipush 30679
      // 191: ldc2_w 1738543159545710731
      // 194: lload 1
      // 195: lxor
      // 196: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 19b: bipush 15
      // 19d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1a0: bipush 5
      // 1a1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1a4: bipush 30
      // 1a6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1a9: bipush 1
      // 1aa: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1ad: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1b0: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.树树何友何何友树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 1b3: aload 0
      // 1b4: new java/util/concurrent/CopyOnWriteArrayList
      // 1b7: dup
      // 1b8: invokespecial java/util/concurrent/CopyOnWriteArrayList.<init> ()V
      // 1bb: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.树树友友友友树何友树 Ljava/util/List;
      // 1be: aload 0
      // 1bf: new java/util/HashMap
      // 1c2: dup
      // 1c3: invokespecial java/util/HashMap.<init> ()V
      // 1c6: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.何树何何树友何树友树 Ljava/util/Map;
      // 1c9: aload 0
      // 1ca: new java/util/HashMap
      // 1cd: dup
      // 1ce: invokespecial java/util/HashMap.<init> ()V
      // 1d1: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.何友友树树何何友友树 Ljava/util/Map;
      // 1d4: aload 0
      // 1d5: new java/util/HashSet
      // 1d8: dup
      // 1d9: invokespecial java/util/HashSet.<init> ()V
      // 1dc: putfield cn/cool/cherish/module/impl/render/何树何何树何何树树树.何何树树友何友何树友 Ljava/util/Set;
      // 1df: aload 0
      // 1e0: bipush 0
      // 1e1: ldc2_w -1277997798085036314
      // 1e4: lload 1
      // 1e5: invokedynamic o (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ea: aload 0
      // 1eb: bipush -1
      // 1ec: ldc2_w -1276676668909858266
      // 1ef: lload 1
      // 1f0: invokedynamic o (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f5: aload 0
      // 1f6: bipush 0
      // 1f7: ldc2_w -1274907430086492194
      // 1fa: lload 1
      // 1fb: invokedynamic o (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/render/何树何何树何何树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 200: aload 0
      // 201: invokevirtual cn/cool/cherish/module/impl/render/何树何何树何何树树树.S ()V
      // 204: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-4293587803156086295L, -341961501628068903L, MethodHandles.lookup().lookupClass()).a(60157132703769L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 69573885655642L;
      Cipher var13;
      Cipher var24 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[34];
      int var18 = 0;
      String var17 = "\u0004°èNÞÍ\nú`¸¿#«Ú]ºh¼6\u0003=8ò\u00972\u0014dÿª\u0082\f\u001a ©ÈSr´º\u009e8¾Î+âÔ\u009b´VðD´\fïfç\u009e`\bx\u0086\u0018mí¥\u0018÷z\tæ¡)·)ÇK\u001c> p\u0088wÛS\u009a[¶\u009eË\u0089 \u0098gqÅ]è`¯d\u000e3Äuba¢¬f~~ \u00ad\u001e]o%J\u0081GGÔ\u0017 \u0004.àÀÅ\u009e}®³D[\f\u0087ñÈÏõ¦\u000bý>\u0017ï\u0014@\u00077Æçü»²\u0010×`²Ô\u0095lî\u0017ÀàK\u0095dë\fþ\u0010\t[4\u0007\u008fxËGA\u0086±§Â\t¸\u0007\u0010Öie\u008a+½¼\u0097M3\u009a PÅïh\u0018tü2\u0011©bÅ\u0081Ûp\u001aµ§±®\u0094ilâõ\u000bUåµ\u00100Õ8d(È#wU9\u009c\u008b>\u0098$ß\u0018\u008eàa\u0010FW#Gr/Äµ²CàÍÆ«\u000eU\u0086ÙYµ\u0010oí]ªky«\u001d0M\u008fkF{\u001f\u0084 Lâ\u0017ä[´\u0099\u008e¶\u001b#nÛ ë\u0099\u0016\u0097a}TÌ\u0007»\u00186B\u0092ª+in \u0005\u009fÈ»\u00009¡þ\u0085¥æÿá\u0099\n\u0010Aq\u0004\u0013p\\¥ý®n\u0087\u008c\u0013Der\u0010D¦+\u00ad\u009b\u0098Ó¥K3\\¯\u0093\u001cì\b(öÏ°\u008bÆ±ÈÆZAbd¤\teù\\rí}f\u0001;ðíì\n³MÈr\u008f!ºÐè: ]\u0097\u0010Qß\u0082\u008cz 6/à¹\u001f\u001dM\u0016\u009e\u0087\u0010Ì¿Í³;{QþrQ\u0099:w]\u0003\u0091 ~\nAù²jâ\u008dÄ)/^¹ç8Ý\u0092¤&OÀ\u0003'ÎEeSK$R\u0000 (\u000eÉÝ\u009e¤\u0012öh±(ø¸à:Sã£»\u0013\u0014P\u007f\u0007àr¿\u00ad\u000fæ\u0092\u001fu\u0003Ä\"\u0003\u0092ü\u0017\u0006(AWY)qË¯ï|Ä!y\u0089¢w!nÔðð\"ÊË7ÔGbãWàu·\u008ek{{Þq\u0089© O¬\u008b\u0099\u001d\u0099/t\u0093\u008fu\u0002Þ\u0084¿¨n¥RaCô×ýÁ³\u00adÓ\u0080¼.\u0006\u0010\u001fXt\u009b\u0094V1B\u0086\u008d´æ\u008e'\u0015\u0086\u0010¬\u0003¥·¤@\tOE²\u0089X\u008c³\u008ae\u0010°\u0080y,ª7r\u0096É\u008d\u001ep\u000bÎÑv\u0010]è±[ãH\f=slú\u0085\r±~Å\u0010\u000e²¼R\b¶Çº$ô\u0094å®á\u00ad3\u0018ò\u0097\u009bJêc\u0010Ðç\u001c2l\u0083Zé\u0082N\u001f-¬EÔ\b\\\u0010\u0014\u0087wé\u008d©4Ð§öA\u009búoÚf0]Ø\u0014í\u000ec\u0081®E«\\W%]ÂÑ\u009f¨\u008b\u009aN©*¸\u0088±\u0003w7þ\u0095>\u0087ù\u0090ö9ß¤L\u009c(W}×s¹2\u0010\fë\u0000àÛ?\u0018\u0098m\u0005\u00ad}ï\u008c\u008a¸0:º4p\u001d\u009b\t\u00064mÃZ\u009dö+\u000elOQ\u0000¯\u0018/y\u009d\u0010\u001cðü¢\u0007{Ó3fIO¿è2º\u0017\u0019\u008a$\u0001Á\u0088";
      short var19 = 839;
      char var16 = ' ';
      int var23 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            String var36 = c(var13.doFinal(var25.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var23 += var16) >= var19) {
                     c = var20;
                     h = new String[34];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var27 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var27.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[4];
                     int var3 = 0;
                     String var4 = "ªTU$\u0081\u0010JS\u0018ÎÆ¹\u0098\u0000.¸";
                     byte var5 = 16;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var43 = -1;

                        while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    j = var6;
                                    k = new Integer[4];
                                    return;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "f_qëJÌÕ\u001c}\u000b§WvxÃ\u008b";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label54;
                  }

                  var17 = "$Ú\u0084\u0090÷îTå³Ð-÷5æ N fp\u0013\u0089ûa\u0013x.pcÎ'7H;¬\u0012\u0098\u001b}*I->£é»Ýç\u00896";
                  var19 = 49;
                  var16 = 16;
                  var23 = -1;
            }

            var25 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   }

   private boolean C(ItemStack itemStack) {
      long a = 何树何何树何何树树树.a ^ 122049246794434L;
      return itemStack.getItem() == d<"ù">(2800262992561070785L, a);
   }

   public void F() {
      super.F();
      this.O();
   }

   private void S() {
      long a = 何树何何树何何树树树.a ^ 51599123653383L;
      float rangeValue = d<"E">(this, -7560039732684678294L, a).getValue().floatValue();
      d<"o">(this, rangeValue * rangeValue, -7559345228398754356L, a);
      d<"o">(this, d<"E">(this, -7559345228398754356L, a) * 1.44F, -7559714922934935266L, a);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 10;
               case 1 -> 50;
               case 2 -> 8;
               case 3 -> 0;
               case 4 -> 59;
               case 5 -> 12;
               case 6 -> 40;
               case 7 -> 37;
               case 8 -> 45;
               case 9 -> 18;
               case 10 -> 25;
               case 11 -> 31;
               case 12 -> 23;
               case 13 -> 32;
               case 14 -> 53;
               case 15 -> 19;
               case 16 -> 41;
               case 17 -> 63;
               case 18 -> 36;
               case 19 -> 38;
               case 20 -> 54;
               case 21 -> 44;
               case 22 -> 9;
               case 23 -> 27;
               case 24 -> 1;
               case 25 -> 2;
               case 26 -> 29;
               case 27 -> 35;
               case 28 -> 34;
               case 29 -> 16;
               case 30 -> 61;
               case 31 -> 20;
               case 32 -> 47;
               case 33 -> 49;
               case 34 -> 39;
               case 35 -> 17;
               case 36 -> 33;
               case 37 -> 15;
               case 38 -> 6;
               case 39 -> 5;
               case 40 -> 24;
               case 41 -> 22;
               case 42 -> 57;
               case 43 -> 26;
               case 44 -> 60;
               case 45 -> 52;
               case 46 -> 21;
               case 47 -> 56;
               case 48 -> 43;
               case 49 -> 51;
               case 50 -> 48;
               case 51 -> 42;
               case 52 -> 62;
               case 53 -> 7;
               case 54 -> 4;
               case 55 -> 55;
               case 56 -> 13;
               case 57 -> 3;
               case 58 -> 58;
               case 59 -> 28;
               case 60 -> 11;
               case 61 -> 46;
               case 62 -> 14;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/何树何何树何何树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20756;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/何树何何树何何树树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 17153;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/何树何何树何何树树树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/何树何何树何何树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'E' && var8 != 'o' && var8 != 249 && var8 != 'I') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'U') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 242) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'E') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'o') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 249) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/何树何何树何何树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "qG+\u0000\u001ci~\u0007f\u000b\u0016t{ZmM\u001eiv\\i\u0006]o\u007fYiM\u0001c|M`\u0011]体栃佼佐桲伦体栃核栔";
      m[1] = "d:zR:Oz2`\u001dXS}/";
      m[2] = "-w| \r93\u007ffon-7";
      m[3] = "d\u0007=%Kwz\u000f'j6gz";
      m[4] = "R@{[\u0012JR@l\u0007\u001eEH\u000bx\u001a\rOX\u000bf\u0001\u001aN\u0012l{\u0010\u0012P";
      m[5] = "]\u0015\bX<\u0005]\u0015\u001f\u00040\nG^\u000b\u0019#\u0000W^\u0015\u00024\u0001\u001d9\b\u0013<";
      m[6] = "l\")Js}g-8\u0005\u0018ie&/_4~h";
      m[7] = "W1\u001c\u000382XqQ\b2/],ZN!<X*WN>0D3\u001c.\"0V:@661A:";
      m[8] = float.class;
      n[8] = "java/lang/Float";
      m[9] = "P\u0003H\u007fn\u000b_C\u0005td\u0016Z\u001e\u000e2l\u000bW\u0018\ny/\r^\u001d\n2s\u0001]\t\u0003n/&V\u0019\u0012ys'R\u0000\u0003n`";
      m[10] = "<F\u0011F1N7I\u0000\tLV$N\t@";
      m[11] = "hxyK7Yg84@=Dbe?\u0006.Wgc2\u00061[{zyj7Ygs6F\u000eWgc2";
      m[12] = int.class;
      n[12] = "java/lang/Integer";
      m[13] = "s3r8\"hs3ed.gixez&ds\"([&ox5tw)u";
      m[14] = "&J'\u0004bV&J0XnY<\u00010FfZ&[}XjQ,J!O}\u0011\u000fN>O]Z&K6XjM";
      m[15] = "\u001dr@_*\u0004\u001drW\u0003&\u000b\u00079W\u001d.\b\u001dc\u001a\u00162\u0004]Q[\u001f3I7~G\u0001+\f\nZ[\u0015\"";
      m[16] = "\t2f !>\t2q|-1\u0013yea>;\u0003ybf5$I\u0001wm\u007f";
      m[17] = double.class;
      n[17] = "java/lang/Double";
      m[18] = "\\J}Tv\u0007\\Jj\bz\bF\u0001j\u0016r\u000b\\['\u001dn\u0007\u001cif\u0014o";
      m[19] = "7vl#s`86!(y}=k*nq`0m.%2佚企叓众伕受佚企栉桓";
      m[20] = "pq/\nQ)pq8V]&j:8KN%0f>CU3jf2AOn\\a2HH\tpF>CU3jf2AO";
      m[21] = "\u0005\u001cY\u001fan\u0005\u001cNCma\u001fWN^~bE+HVet\u001f\u000bT";
      m[22] = "oA6/ X`\u0001{$*Ee\\pb\"XhZt)a^a_tb+^\u007f_t-6\u0019叇栾栉桝桞佢栝栾叓厇";
      m[23] = "4ejex6;%'nr+>x,(a8;~!(~4'gj栗叜伌厜佞休反栆案厜";
      m[24] = ";]\u0005pU\u00150R\u0014?4\u001b;Y\u0010e";
      m[25] = "75?sB3;%\u000e収叽厌桅桃体佐佣桖企Z1|\u00056!3~n^~";
      m[26] = "W$[jeL[4j栍佄栩栥厈桳受佄佭佡KVdw\r\rvQdv\b";
      m[27] = "fP]'\nh4BLxsh\n\u0001\u0015vB>\n=\u00144\u000e?fMO3\rf";
      m[28] = "e\u0004OP?\u0017i\u0014~样桚伶反伶伣叭桚伶体kB^-V?VE^,S";
      m[29] = "\u0014W^\u001bvR\u0016V@\u001a\u0010佬伧佳叱伣位佬档佳叱~\u007fR\u0000@]\u0011}\f\u0017P";
      m[30] = "gMh|u~k]Y佟及栛栕栻伄佟栐栛佑\"fs2{qK)ai3";
      m[31] = "iB\tT\u0003\u001ceR8叩伢伽佟栴佥栳桦厣栛-\bA\u001e\u00188VUU\u0007\u001d";
      m[32] = "P*o[|P@6iUFzt\u001b]f\u0006{~\u000bEzFHE3k\u00007XY5e";
      m[33] = "b}C\u0006jhnmr桡栏受及发厱桡佋受栐\u0012KArij/\tA|j";
      m[34] = "J~w!(zFnF伂厗叅核栈伛伂厗叅核\u0011|e(\u007f[~8aey";
      m[35] = "@I\u0004gV$LY5叚叩桁佶栿佨叚佷桁叨&\u000b&M7RX\u0005{S>";
      m[36] = "F7V_wl\u001d6L\u0017\u0005a{6\u0015\u001156{\u0006DAo1\\lFTn>";
      m[37] = "q-Y\u00114!}=h伲压桄叙伟桱伲压伀佇BVP/2c<X\r1;";
      m[38] = "r\u000b\u0001\u0019(T)\n\u001bQZYO\nBWe\u0006O:\u0013\u00070\thP\u0011\u00121\u0006";
      m[39] = "D#n\u000ez\u0005H3_伭佛桠栶厏伂厳佛桠召Le\u0019yE\u0016&5\u001f7D";
      m[40] = "n4\u000bCF\u0013b$:你栣桶佘桂佧叾栣桶佘[\u0006MTR4f\u0001MUW";
      m[41] = "v\u0018s~p\u0015z\bB栙栕厪叞桮厁栙佑厪栄w~pbT,JypcQ";
      m[42] = "&:\u00035h\u001ezh^#\u0006桦桓佘桹桓栟伢厉叆厣Jj@)z\u000e+6\u0012tl";
      m[43] = "\bu`Nhg\u0004eQ右佉但厠叙厒右佉栂厠\u001aa[ucYa<Olf";
      m[44] = "\u0005k&p'1\u0007j8qA桋厨发桓取厂厑伶栋厉\u0015/+\u0007w,v-*\u0019v";
      m[45] = ",P\u0014}M+ @%叀史桎会佢佸栚栨桎厄?\u001ar\n.:VU`Qf";
      m[46] = ")eTrd\u0002ye]t\u0004\u0002O;\u000e-:WO\n\u0006d>\u000fzoQ%v\u001d";
      m[47] = "\u00173\u0015:+'X9\u0004*[\u0005)fAsbgQ?K%;[";
      m[48] = "\u0012#\u0019\u0003'I\u001e3(传桂佨桠桕叫厾桂栬桠L\u0018\u0016:MC7E\u0002#H";
      m[49] = "15\u00135H8j4\t}:5\f4P{\nc\f\u0004\u0001+Pe+n\u0003>Qj";
      m[50] = "saF\u001b\u001e=\u007fqw伸桻伜佅栗厴伸桻厂栁\u000eM_\u001e8ba\t[S>";
      m[51] = "xe:\nQq(e3\f1q\u001e;`U\u000f%\u001e\n2\u000fKtv3:W\\ ";
      m[52] = ",'>0[\u0006 7\u000f''Fy\"`\"VC'37N\u001bD-'c?\u001e\u001a<p\u000f";
      m[53] = "(ns\r_I~0!\u000ff\u001a\u0012iu\tVK{\u0004HZ\u0001\f/7(F\u001d\u0018=";
      m[54] = "UE\u0000\u0012yHYU1伱叆号佣佷史桵叆号栧*\u000e\u001d>MCCA\u000fe\u0005";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private boolean t(ItemEntity entity, Vec3 cameraPos) {
      long a = 何树何何树何何树树树.a ^ 51923237730870L;
      d<"ò">(-3592194958030075100L, a);
      Vec3 entityPos = entity.position();
      Vec3 toEntity = entityPos.subtract(cameraPos);
      if (toEntity.lengthSqr() < 4.0) {
         return true;
      } else {
         double playerYaw = Math.toRadians(mc.player.getYRot());
         double playerPitch = Math.toRadians(mc.player.getXRot());
         Vec3 lookDirection = new Vec3(-Math.sin(playerYaw) * Math.cos(playerPitch), -Math.sin(playerPitch), Math.cos(playerYaw) * Math.cos(playerPitch));
         Vec3 normalizedToEntity = toEntity.normalize();
         double dotProduct = normalizedToEntity.dot(lookDirection);
         return dotProduct > -0.5;
      }
   }

   public void t() {
      super.t();
      this.O();
      this.S();
   }

   private void j() {
      long a = 何树何何树何何树树树.a ^ 59382418696462L;
      d<"ò">(-2513592928489695204L, a);
      this.S();
      this.K();
      Vec3 playerPos = mc.player.position();

      for (Entity entity : mc.level.entitiesForRendering()) {
         if (entity instanceof ItemEntity itemEntity) {
            double distanceSq = playerPos.distanceToSqr(entity.position());
            if (!(distanceSq > d<"E">(this, -2513176012185326825L, a))) {
               boolean found = false;
               Iterator var11 = d<"E">(this, -2513497497500287704L, a).iterator();
               if (var11.hasNext()) {
                  何树何何树何何树树树.何何树树何何树友何何 data = (何树何何树何何树树树.何何树树何何树友何何)var11.next();
                  if (data.e() == itemEntity) {
                     data.b(Math.sqrt(distanceSq));
                     found = true;
                  }
               }

               if (!found && distanceSq <= d<"E">(this, -2513334601327783995L, a)) {
                  d<"E">(this, -2513497497500287704L, a).add(new 何树何何树何何树树树.何何树树何何树友何何(itemEntity, Math.sqrt(distanceSq)));
               }
               break;
            }
         }
      }

      if (d<"E">(this, -2513497497500287704L, a).size() > 1) {
         d<"E">(this, -2513497497500287704L, a).sort(Comparator.comparingDouble(何树何何树何何树树树.何何树树何何树友何何::S));
      }

      int limit = d<"E">(this, -2517369478963266590L, a).getValue().intValue();
      if (d<"E">(this, -2513497497500287704L, a).size() > limit) {
         List<何树何何树何何树树树.何何树树何何树友何何> toRemoveData = d<"E">(this, -2513497497500287704L, a).subList(limit, d<"E">(this, -2513497497500287704L, a).size());
         Iterator var15 = toRemoveData.iterator();
         if (var15.hasNext()) {
            何树何何树何何树树树.何何树树何何树友何何 data = (何树何何树何何树树树.何何树树何何树友何何)var15.next();
            d<"E">(this, -2514509439024683687L, a).remove(data.e());
            d<"E">(this, -2513395483870501959L, a).remove(data.e());
         }

         toRemoveData.clear();
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private String U(ItemEntity itemEntity) {
      long a = 何树何何树何何树树树.a ^ 108467630740230L;
      return d<"E">(this, -6406664335242651215L, a).computeIfAbsent(itemEntity, entity -> {
         long ax = 何树何何树何何树树树.a ^ 106122960930637L;
         d<"ò">(-5521771540092586401L, ax);
         ItemStack itemStack = entity.getItem();
         if (!this.C(itemStack)) {
            return "";
         } else {
            try {
               CompoundTag tag = itemStack.getTag();
               if (tag != null && tag.contains(b<"v">(18723, 5061371391206730623L ^ ax))) {
                  ListTag enchantmentList = tag.getList(b<"v">(12192, 7713705787006340590L ^ ax), 10);
                  if (enchantmentList.isEmpty()) {
                     return "";
                  } else {
                     List<String> enchantmentNames = new ArrayList<>();
                     int i = 0;
                     if (0 < enchantmentList.size()) {
                        CompoundTag enchantmentTag = enchantmentList.getCompound(0);
                        String enchantmentId = enchantmentTag.getString(b<"v">(30065, 1410723128017655606L ^ ax));
                        int level = enchantmentTag.getInt(b<"v">(14073, 7847507773926069437L ^ ax));
                        String name = this.R(enchantmentId);
                        if (level > 1) {
                           name = name + " " + this.R(level);
                        }

                        enchantmentNames.add(name);
                        i++;
                     }

                     return String.join(b<"v">(9742, 5499444478602462276L ^ ax), enchantmentNames);
                  }
               } else {
                  return "";
               }
            } catch (Exception var14) {
               return b<"v">(30201, 2184651547570280363L ^ ax);
            }
         }
      });
   }

   private void w(PoseStack matrixStack, ItemEntity itemEntity, int color, Vec3 cameraPos) {
      long a = 何树何何树何何树树树.a ^ 104152765746443L;
      d<"ò">(-497502385253237735L, a);

      try {
         Component nameComponent = d<"E">(this, -495463823085207204L, a).computeIfAbsent(itemEntity, entity -> entity.getItem().getHoverName());
         Vec3 entityPos = itemEntity.position();
         double x = d<"E">(entityPos, -496871209819597482L, a);
         double y = d<"E">(entityPos, -495626933106108304L, a) + itemEntity.getBbHeight() + 0.5;
         double z = d<"E">(entityPos, -497005594824680111L, a);
         float distanceSq = (float)cameraPos.distanceToSqr(x, y, z);
         if (distanceSq <= d<"E">(this, -496592481311593536L, a)) {
            matrixStack.pushPose();
            matrixStack.translate(
               x - d<"E">(cameraPos, -496871209819597482L, a), y - d<"E">(cameraPos, -495626933106108304L, a), z - d<"E">(cameraPos, -497005594824680111L, a)
            );
            matrixStack.mulPose(d<"E">(mc, -497421195264330528L, a).getMainCamera().rotation());
            float scale = distanceSq > 100.0F ? 0.025F * (float)Math.sqrt(distanceSq * 0.01F) : 0.025F;
            matrixStack.scale(-scale, -scale, scale);
            String enchantmentText = null;
            if (d<"E">(this, -495697626693772829L, a).getValue() && this.C(itemEntity.getItem())) {
               enchantmentText = this.U(itemEntity);
            }

            float nameWidth = d<"E">(mc, -495526749746560314L, a).width(nameComponent);
            float enchantWidth = d<"E">(mc, -495526749746560314L, a).width(enchantmentText);
            float nameX = -nameWidth * 0.5F;
            float enchantX = -enchantWidth * 0.5F;
            int backgroundColor = c<"m">(861, 8173564021647817037L ^ a);
            int enchantColor = c<"m">(31854, 1960260947507168893L ^ a);
            BufferSource bufferSource = mc.renderBuffers().bufferSource();
            d<"E">(mc, -495526749746560314L, a)
               .drawInBatch(
                  nameComponent,
                  nameX,
                  0.0F,
                  color,
                  false,
                  matrixStack.last().pose(),
                  bufferSource,
                  d<"ù">(-496711827334278622L, a),
                  backgroundColor,
                  c<"m">(28544, 8446611303227479441L ^ a)
               );
            if (!enchantmentText.isEmpty()) {
               d<"E">(mc, -495526749746560314L, a)
                  .drawInBatch(
                     Component.literal(enchantmentText),
                     enchantX,
                     10.0F,
                     enchantColor,
                     false,
                     matrixStack.last().pose(),
                     bufferSource,
                     d<"ù">(-496711827334278622L, a),
                     backgroundColor,
                     c<"m">(10928, 3603715149770526882L ^ a)
                  );
            }

            bufferSource.endBatch();
            matrixStack.popPose();
         }
      } catch (Exception var26) {
         d<"E">(this, -495463823085207204L, a).remove(itemEntity);
         d<"E">(this, -496582726041614404L, a).remove(itemEntity);
      }
   }

   private void M() {
      long a = 何树何何树何何树树树.a ^ 113046763035390L;
      long ax = a ^ 52812058229439L;
      d<"ò">(7993252027053353964L, a);
      if (d<"E">(this, 7993049403102409479L, a).getValue()) {
         int var10002 = d<"E">(this, 7992962515812073340L, a);
         d<"o">(this, var10002 + 1, 7992962515812073340L, a);
         if (var10002 < 3) {
            return;
         }

         d<"o">(this, 0, 7992962515812073340L, a);
         d<"o">(this, 树树何友友友友何树友.w(ax, 10, 1).getRGB(), 7992339200149344900L, a);
      }

      d<"o">(this, d<"E">(d<"ù">(7993161208292902404L, a), 7989736426379294514L, a).a(), 7992339200149344900L, a);
   }

   private String R(String enchantmentId) {
      long a = 何树何何树何何树树树.a ^ 4590731735404L;
      d<"ò">(396280080745611390L, a);

      try {
         ResourceLocation resourceLocation = ResourceLocation.parse(enchantmentId);
         Enchantment enchantment = (Enchantment)d<"ù">(394442833192339548L, a).get(resourceLocation);
         if (enchantment != null) {
            Component displayName = enchantment.getFullname(1);
            String fullName = displayName.getString();
            return fullName.replaceAll(b<"v">(17067, 226164455957272279L ^ a), "");
         }
      } catch (Exception var9) {
      }

      if (enchantmentId.startsWith(b<"v">(8736, 4208439344699799125L ^ a))) {
         enchantmentId = enchantmentId.substring(b<"v">(4719, 3219641814953903630L ^ a).length());
      }

      return enchantmentId.replace("_", " ");
   }

   private boolean R(ItemEntity entity) {
      long a = 何树何何树何何树树树.a ^ 29465805279306L;
      d<"ò">(7231022066727887192L, a);
      return entity != null && entity.isAlive() && !entity.isRemoved();
   }

   private String R(int number) {
      long a = 何树何何树何何树树树.a ^ 73205744741973L;
      d<"ò">(1893367931109236551L, a);
      String[] romanNumerals = new String[]{
         "",
         "I",
         b<"v">(26112, 4837313015594495299L ^ a),
         b<"v">(6709, 5486840711518671205L ^ a),
         b<"v">(13920, 757575062488775982L ^ a),
         "V",
         b<"v">(23022, 4048330519569404582L ^ a),
         b<"v">(3513, 8348893378024654576L ^ a),
         b<"v">(9391, 5018796340823093233L ^ a),
         b<"v">(18025, 8427002342396333350L ^ a),
         "X"
      };
      return number >= 1 && number <= 10 ? romanNumerals[number] : String.valueOf(number);
   }

   private void O() {
      long a = 何树何何树何何树树树.a ^ 13513404394972L;
      d<"E">(this, 1858993922596583930L, a).clear();
      d<"E">(this, 1857893951353315723L, a).clear();
      d<"E">(this, 1859030448500385643L, a).clear();
      d<"E">(this, 1859422233325701083L, a).clear();
   }

   @EventTarget
   public void K(Render3DEvent event) {
      long a = 何树何何树何何树树树.a ^ 32806781089388L;
      long ax = a ^ 96544360981385L;
      d<"ò">(4791767713410221950L, a);
      if (mc.level != null && mc.player != null) {
         d<"o">(this, d<"E">(this, 4788438824248826582L, a) + 1, 4788438824248826582L, a);
         if (d<"E">(this, 4788438824248826582L, a) >= d<"E">(this, 4788216423408349966L, a).getValue().intValue()
            || d<"E">(this, 4790819018465993290L, a).isEmpty()) {
            d<"o">(this, 0, 4788438824248826582L, a);
            this.j();
         }

         this.M();
         PoseStack poseStack = event.poseStack();
         Vec3 cameraPos = d<"E">(mc, 4791703978051522439L, a).getMainCamera().getPosition();
         Iterator var9 = d<"E">(this, 4790819018465993290L, a).iterator();
         if (var9.hasNext()) {
            何树何何树何何树树树.何何树树何何树友何何 data = (何树何何树何何树树树.何何树树何何树友何何)var9.next();
            ItemEntity itemEntity = data.e();
            if (!this.R(itemEntity)) {
            }

            if (d<"E">(this, 4788337979847547469L, a).getValue() && !this.t(itemEntity, cameraPos)) {
            }

            友友树何树树友树友何.m(ax, poseStack, itemEntity, d<"E">(this, 4789583902760762902L, a), d<"E">(this, 4791281714549562631L, a).getValue().floatValue());
            if (d<"E">(this, 4788014794898008976L, a).getValue()) {
               this.w(poseStack, itemEntity, d<"E">(this, 4789583902760762902L, a), cameraPos);
            }
         }
      }
   }

   private void K() {
      long a = 何树何何树何何树树树.a ^ 16731937660475L;
      d<"ò">(7649598958401728297L, a);
      d<"E">(this, 7650206014893978684L, a).clear();
      Iterator var4 = d<"E">(this, 7650342955145939485L, a).iterator();
      if (var4.hasNext()) {
         何树何何树何何树树树.何何树树何何树友何何 data = (何树何何树何何树树树.何何树树何何树友何何)var4.next();
         if (!this.R(data.e())) {
            d<"E">(this, 7650206014893978684L, a).add(data.e());
         }
      }

      if (!d<"E">(this, 7650206014893978684L, a).isEmpty()) {
         d<"E">(this, 7650342955145939485L, a).removeIf(datax -> {
            long ax = 何树何何树何何树树树.a ^ 71578250378286L;
            return d<"E">(this, -4017294462151338455L, ax).contains(datax.e());
         });
         d<"E">(this, 7650206014893978684L, a).forEach(entity -> {
            long ax = 何树何何树何何树树树.a ^ 38956067104726L;
            d<"E">(this, -7799460975297205375L, ax).remove(entity);
            d<"E">(this, -7798346196625281695L, ax).remove(entity);
         });
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖诈骗";
   }

   private static class 何何树树何何树友何何 implements 何树友 {
      private final ItemEntity 树树友何何何树树友友;
      private double 树何友何友树何友友友;
      private static final long a;
      private static final Object[] b = new Object[6];
      private static final String[] c = new String[6];
      private static String HE_DA_WEI;

      public 何何树树何何树友何何(ItemEntity entity, double distance) {
         long a = 何树何何树何何树树树.何何树树何何树友何何.a ^ 72188581058402L;
         super();
         this.树树友何何何树树友友 = entity;
         a<"í">(this, distance, 5997744281334756117L, a);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(6564234376879838997L, -6153351424689348778L, MethodHandles.lookup().lookupClass()).a(139516012267546L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public double S() {
         long a = 何树何何树何何树树树.何何树树何何树友何何.a ^ 89757796686163L;
         return a<"Å">(this, 2093422450480774436L, a);
      }

      public ItemEntity e() {
         long a = 何树何何树何何树树树.何何树树何何树友何何.a ^ 117955616016829L;
         return a<"Å">(this, -3610998004827519439L, a);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      public void b(double newDistance) {
         long a = 何树何何树何何树树树.何何树树何何树友何何.a ^ 88196585557205L;
         a<"í">(this, newDistance, 5227365474690050210L, a);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 197 && var8 != 237 && var8 != 234 && var8 != 212) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 255) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'G') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 197) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 237) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 234) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/何树何何树何何树树树$何何树树何何树友何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 32;
                  case 1 -> 52;
                  case 2 -> 5;
                  case 3 -> 3;
                  case 4 -> 40;
                  case 5 -> 21;
                  case 6 -> 41;
                  case 7 -> 38;
                  case 8 -> 48;
                  case 9 -> 10;
                  case 10 -> 44;
                  case 11 -> 36;
                  case 12 -> 25;
                  case 13 -> 20;
                  case 14 -> 62;
                  case 15 -> 23;
                  case 16 -> 31;
                  case 17 -> 37;
                  case 18 -> 34;
                  case 19 -> 47;
                  case 20 -> 57;
                  case 21 -> 11;
                  case 22 -> 28;
                  case 23 -> 42;
                  case 24 -> 18;
                  case 25 -> 6;
                  case 26 -> 1;
                  case 27 -> 58;
                  case 28 -> 46;
                  case 29 -> 39;
                  case 30 -> 30;
                  case 31 -> 49;
                  case 32 -> 22;
                  case 33 -> 4;
                  case 34 -> 59;
                  case 35 -> 55;
                  case 36 -> 45;
                  case 37 -> 13;
                  case 38 -> 51;
                  case 39 -> 0;
                  case 40 -> 14;
                  case 41 -> 33;
                  case 42 -> 19;
                  case 43 -> 50;
                  case 44 -> 35;
                  case 45 -> 2;
                  case 46 -> 60;
                  case 47 -> 9;
                  case 48 -> 56;
                  case 49 -> 53;
                  case 50 -> 24;
                  case 51 -> 16;
                  case 52 -> 29;
                  case 53 -> 43;
                  case 54 -> 61;
                  case 55 -> 15;
                  case 56 -> 8;
                  case 57 -> 12;
                  case 58 -> 7;
                  case 59 -> 26;
                  case 60 -> 27;
                  case 61 -> 63;
                  case 62 -> 54;
                  default -> 17;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "\u0017)\u001cWh\u0005\u0018iQ\\b\u0018\u001d4Z\u001aj\u0005\u00102^Q)\u0003\u00197^\u001au\u000f\u001a#WF)伿桥伒佧栥佒伿桥桖栣\u0010佒伿桥桖佧佡栖厡伡伒";
         b[1] = "NT|\u000e\u0007PNTkR\u000b_T\u001f\u007fO\u0018UD\u001fmN\u001ePTH&I\u001e\\M\u001fAT\u000fTe_|I\u001e@";
         b[2] = double.class;
         c[2] = "java/lang/Double";
         b[3] = "~,R7Luu#Cx-{~(G\"";
         b[4] = "<(T}eKy&W\u001d栒栮叁休伴佀栒栮叁厏i`o]>=\u0010~nX";
         b[5] = "\u001c\u0010Kmt\u000eY\u001eH\r栃伯叡伩厵栔佇厱叡厷v7\"\u001b\u001f\u0004\u0017\u007fxH^";
      }

      private static String HE_WEI_LIN() {
         return "何建国230622195906030014";
      }
   }
}
