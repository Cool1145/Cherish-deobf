package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.client.树何树树何树何何树何;
import cn.cool.cherish.utils.player.树友友何树友树树树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.树友何友何何友树树友;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import why.tree.friend.antileak.Fucker;

public class 树何树何何友树友树何 extends Module implements 何树友 {
   private final ModeValue 何树树树何树何友何何;
   private final ModeValue 友友友树友树何友何何;
   private final ModeValue 友友友何树树何树树树;
   public final BooleanValue 树友树何树树何何友友;
   private final BooleanValue 树友何何何树何何何何;
   private final BooleanValue 树何何友何树何树友树;
   private final BooleanValue 友树何何树何友树何树;
   private final BooleanValue 何树何友何友何友友树;
   private final 树友何友何何友树树友 树何树友树何树树友树;
   private final BooleanValue 何何何树友何树树何友;
   private final 树友何友何何友树树友 何友友何树友友树树友;
   private final BooleanValue 友树友友友友何何何友;
   private final 树友何友何何友树树友 友何何树友树友何何友;
   private final BooleanValue 树何树何友何友树友友;
   private final 树友何友何何友树树友 友何树树树树何何友何;
   private final BooleanValue 友友何树何树树何何友;
   private final 树友何友何何友树树友 友何何树友友何友友树;
   private final BooleanValue 何友何树树树何树友何;
   private final 树友何友何何友树树友 何友友树何何友友树友;
   private final BooleanValue 树友何友友树何树何友;
   private final 树友何友何何友树树友 友友何树树树友何何何;
   private final BooleanValue 友何何何友何何何友友;
   private final 树友何友何何友树树友 友何何友友何友树友何;
   private final BooleanValue 树友树友友友友何何友;
   private final 树友何友何何友树树友 友何树何友树友友树何;
   private final 树友何友何何友树树友 何友树何树友友树何何;
   private final 树友何友何何友树树友 友树友何友友友何友树;
   private final NumberValue 友何友树何何树何树何;
   private final NumberValue 友树友友何友何何何友;
   private final NumberValue 树友树何树何何何何何;
   private final NumberValue 何何树何何何树何友何;
   private final NumberValue 友树友何何友何树友何;
   private final NumberValue 何何何何何树友友友何;
   private final NumberValue 何树树树树友何何何友;
   private final BooleanValue 友树友友树何树友友友;
   private final BooleanValue 树友友树友友何树友友;
   private final ConcurrentHashMap<BlockPos, 树何树何何友树友树何.树树友友友何友何何树> 何何树友何友何树友树;
   private final Set<BlockPos> 树何友树友何友何树友;
   private final Set<BlockPos> 何树何友何何友友树何;
   private BlockPos 何何树何树何何何树树;
   private static final double 树树友何何友友何树树 = 4.0;
   private Level 树友树友友友何友友树;
   private boolean 树何友友友树友何友何;
   private final 树友树友友何何树何何 树何友友树友树何何何;
   private final CopyOnWriteArraySet<BlockPos> 树何树何友何何友树何;
   private long 树树树树友友友友友何;
   private static final long 何树树树树树树友何友;
   private static final int[][] 友友友友何何友树友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[155];
   private static final String[] n = new String[155];
   private static String LIU_YA_FENG;

   public 树何树何何友树友树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:200)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/render/树何树何何友树友树何.a J
      // 003: ldc2_w 99299228196397
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 132307420882174
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 13351
      // 014: ldc2_w 6169014441350001428
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 22712
      // 021: ldc2_w 6309073904646004662
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w 5718039840174963244
      // 02e: lload 1
      // 02f: invokedynamic Ø (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/ModeValue
      // 03b: dup
      // 03c: sipush 18892
      // 03f: ldc2_w 228045336016195234
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 27488
      // 04c: ldc2_w 609716775202237508
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 3
      // 057: anewarray 171
      // 05a: dup
      // 05b: bipush 0
      // 05c: sipush 11103
      // 05f: ldc2_w 6246949831081716787
      // 062: lload 1
      // 063: lxor
      // 064: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 069: aastore
      // 06a: dup
      // 06b: bipush 1
      // 06c: sipush 18524
      // 06f: ldc2_w 5394506374622711652
      // 072: lload 1
      // 073: lxor
      // 074: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 079: aastore
      // 07a: dup
      // 07b: bipush 2
      // 07c: sipush 14592
      // 07f: ldc2_w 5497900385079950883
      // 082: lload 1
      // 083: lxor
      // 084: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 089: aastore
      // 08a: sipush 28291
      // 08d: ldc2_w 6714102543197481467
      // 090: lload 1
      // 091: lxor
      // 092: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 097: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 09a: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何树树树何树何友何何 Lcn/cool/cherish/value/impl/ModeValue;
      // 09d: aload 0
      // 09e: new cn/cool/cherish/value/impl/ModeValue
      // 0a1: dup
      // 0a2: sipush 15883
      // 0a5: ldc2_w 1819448432856529160
      // 0a8: lload 1
      // 0a9: lxor
      // 0aa: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0af: sipush 28796
      // 0b2: ldc2_w 3596349343061784323
      // 0b5: lload 1
      // 0b6: lxor
      // 0b7: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bc: bipush 3
      // 0bd: anewarray 171
      // 0c0: dup
      // 0c1: bipush 0
      // 0c2: sipush 31369
      // 0c5: ldc2_w 3556130690487533047
      // 0c8: lload 1
      // 0c9: lxor
      // 0ca: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0cf: aastore
      // 0d0: dup
      // 0d1: bipush 1
      // 0d2: sipush 3201
      // 0d5: ldc2_w 3605899054861175686
      // 0d8: lload 1
      // 0d9: lxor
      // 0da: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0df: aastore
      // 0e0: dup
      // 0e1: bipush 2
      // 0e2: sipush 8740
      // 0e5: ldc2_w 3131004102859744590
      // 0e8: lload 1
      // 0e9: lxor
      // 0ea: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ef: aastore
      // 0f0: sipush 26036
      // 0f3: ldc2_w 8448517178305159867
      // 0f6: lload 1
      // 0f7: lxor
      // 0f8: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0fd: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 100: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友友友树友树何友何何 Lcn/cool/cherish/value/impl/ModeValue;
      // 103: aload 0
      // 104: new cn/cool/cherish/value/impl/ModeValue
      // 107: dup
      // 108: sipush 1153
      // 10b: ldc2_w 2865721956036625306
      // 10e: lload 1
      // 10f: lxor
      // 110: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 115: sipush 23184
      // 118: ldc2_w 8237753339071045053
      // 11b: lload 1
      // 11c: lxor
      // 11d: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 122: bipush 3
      // 123: anewarray 171
      // 126: dup
      // 127: bipush 0
      // 128: sipush 8321
      // 12b: ldc2_w 6536229502107314056
      // 12e: lload 1
      // 12f: lxor
      // 130: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 135: aastore
      // 136: dup
      // 137: bipush 1
      // 138: sipush 20592
      // 13b: ldc2_w 3814789707248506634
      // 13e: lload 1
      // 13f: lxor
      // 140: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 145: aastore
      // 146: dup
      // 147: bipush 2
      // 148: sipush 16789
      // 14b: ldc2_w 5769781786698450610
      // 14e: lload 1
      // 14f: lxor
      // 150: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 155: aastore
      // 156: sipush 8321
      // 159: ldc2_w 6536229502107314056
      // 15c: lload 1
      // 15d: lxor
      // 15e: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 163: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 166: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友友友何树树何树树树 Lcn/cool/cherish/value/impl/ModeValue;
      // 169: aload 0
      // 16a: new cn/cool/cherish/value/impl/BooleanValue
      // 16d: dup
      // 16e: sipush 29475
      // 171: ldc2_w 7843943779881661441
      // 174: lload 1
      // 175: lxor
      // 176: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 17b: sipush 13379
      // 17e: ldc2_w 3347923382322131825
      // 181: lload 1
      // 182: lxor
      // 183: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 188: bipush 0
      // 189: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 18c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 18f: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树友树何树树何何友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 192: ldc2_w 5722145791158381231
      // 195: lload 1
      // 196: invokedynamic C (JJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 19b: aload 0
      // 19c: new cn/cool/cherish/value/impl/BooleanValue
      // 19f: dup
      // 1a0: sipush 28316
      // 1a3: ldc2_w 4520103087299275244
      // 1a6: lload 1
      // 1a7: lxor
      // 1a8: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ad: sipush 4384
      // 1b0: ldc2_w 2681540223361734208
      // 1b3: lload 1
      // 1b4: lxor
      // 1b5: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ba: bipush 1
      // 1bb: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1be: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1c1: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树友何何何树何何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1c4: aload 0
      // 1c5: new cn/cool/cherish/value/impl/BooleanValue
      // 1c8: dup
      // 1c9: sipush 19362
      // 1cc: ldc2_w 7919827379309251767
      // 1cf: lload 1
      // 1d0: lxor
      // 1d1: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1d6: sipush 12137
      // 1d9: ldc2_w 9139033477909473345
      // 1dc: lload 1
      // 1dd: lxor
      // 1de: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e3: bipush 1
      // 1e4: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1e7: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1ea: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树何何友何树何树友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1ed: aload 0
      // 1ee: new cn/cool/cherish/value/impl/BooleanValue
      // 1f1: dup
      // 1f2: sipush 25019
      // 1f5: ldc2_w 201504751766677202
      // 1f8: lload 1
      // 1f9: lxor
      // 1fa: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ff: sipush 15264
      // 202: ldc2_w 892859963361361030
      // 205: lload 1
      // 206: lxor
      // 207: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 20c: bipush 1
      // 20d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 210: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 213: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友树何何树何友树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 216: aload 0
      // 217: new cn/cool/cherish/value/impl/BooleanValue
      // 21a: dup
      // 21b: sipush 8790
      // 21e: ldc2_w 1068341239739933988
      // 221: lload 1
      // 222: lxor
      // 223: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 228: sipush 28138
      // 22b: ldc2_w 5074692624024808149
      // 22e: lload 1
      // 22f: lxor
      // 230: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 235: bipush 1
      // 236: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 239: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 23c: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何树何友何友何友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 23f: aload 0
      // 240: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 243: dup
      // 244: sipush 17817
      // 247: ldc2_w 7654425685539685110
      // 24a: lload 1
      // 24b: lxor
      // 24c: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 251: sipush 11014
      // 254: ldc2_w 5506009874360855675
      // 257: lload 1
      // 258: lxor
      // 259: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 25e: new java/awt/Color
      // 261: dup
      // 262: bipush 0
      // 263: sipush 255
      // 266: sipush 255
      // 269: invokespecial java/awt/Color.<init> (III)V
      // 26c: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 26f: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树何树友树何树树友树 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 272: aload 0
      // 273: new cn/cool/cherish/value/impl/BooleanValue
      // 276: dup
      // 277: sipush 2117
      // 27a: ldc2_w 1643154642415275900
      // 27d: lload 1
      // 27e: lxor
      // 27f: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 284: sipush 25171
      // 287: ldc2_w 4555988511364261211
      // 28a: lload 1
      // 28b: lxor
      // 28c: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 291: bipush 1
      // 292: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 295: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 298: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何何何树友何树树何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 29b: aload 0
      // 29c: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 29f: dup
      // 2a0: sipush 19972
      // 2a3: ldc2_w 5701532148595853587
      // 2a6: lload 1
      // 2a7: lxor
      // 2a8: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2ad: sipush 14506
      // 2b0: ldc2_w 4387635856915136417
      // 2b3: lload 1
      // 2b4: lxor
      // 2b5: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2ba: new java/awt/Color
      // 2bd: dup
      // 2be: bipush 0
      // 2bf: sipush 255
      // 2c2: bipush 0
      // 2c3: invokespecial java/awt/Color.<init> (III)V
      // 2c6: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 2c9: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何友友何树友友树树友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 2cc: aload 0
      // 2cd: new cn/cool/cherish/value/impl/BooleanValue
      // 2d0: dup
      // 2d1: sipush 23918
      // 2d4: ldc2_w 6421610828641507956
      // 2d7: lload 1
      // 2d8: lxor
      // 2d9: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2de: sipush 17701
      // 2e1: ldc2_w 5800301821047079521
      // 2e4: lload 1
      // 2e5: lxor
      // 2e6: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2eb: bipush 1
      // 2ec: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2ef: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2f2: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友树友友友友何何何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2f5: aload 0
      // 2f6: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 2f9: dup
      // 2fa: sipush 9939
      // 2fd: ldc2_w 2443113163550319053
      // 300: lload 1
      // 301: lxor
      // 302: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 307: sipush 29262
      // 30a: ldc2_w 3704927624527525217
      // 30d: lload 1
      // 30e: lxor
      // 30f: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 314: new java/awt/Color
      // 317: dup
      // 318: sipush 255
      // 31b: bipush 0
      // 31c: bipush 0
      // 31d: invokespecial java/awt/Color.<init> (III)V
      // 320: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 323: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友何何树友树友何何友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 326: aload 0
      // 327: new cn/cool/cherish/value/impl/BooleanValue
      // 32a: dup
      // 32b: sipush 15473
      // 32e: ldc2_w 5338974682546109203
      // 331: lload 1
      // 332: lxor
      // 333: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 338: sipush 7822
      // 33b: ldc2_w 4218924048658291128
      // 33e: lload 1
      // 33f: lxor
      // 340: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 345: bipush 1
      // 346: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 349: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 34c: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树何树何友何友树友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 34f: aload 0
      // 350: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 353: dup
      // 354: sipush 24741
      // 357: ldc2_w 4810984579119753129
      // 35a: lload 1
      // 35b: lxor
      // 35c: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 361: sipush 5761
      // 364: ldc2_w 134544622625444326
      // 367: lload 1
      // 368: lxor
      // 369: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 36e: new java/awt/Color
      // 371: dup
      // 372: sipush 210
      // 375: sipush 210
      // 378: sipush 210
      // 37b: invokespecial java/awt/Color.<init> (III)V
      // 37e: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 381: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友何树树树树何何友何 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 384: aload 0
      // 385: new cn/cool/cherish/value/impl/BooleanValue
      // 388: dup
      // 389: sipush 30124
      // 38c: ldc2_w 6112329002301305577
      // 38f: lload 1
      // 390: lxor
      // 391: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 396: ldc_w "铁"
      // 399: bipush 1
      // 39a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 39d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 3a0: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友友何树何树树何何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 3a3: aload 0
      // 3a4: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 3a7: dup
      // 3a8: sipush 18807
      // 3ab: ldc2_w 1669147060952698469
      // 3ae: lload 1
      // 3af: lxor
      // 3b0: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3b5: sipush 20125
      // 3b8: ldc2_w 651022689331087746
      // 3bb: lload 1
      // 3bc: lxor
      // 3bd: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3c2: new java/awt/Color
      // 3c5: dup
      // 3c6: sipush 255
      // 3c9: sipush 215
      // 3cc: bipush 0
      // 3cd: invokespecial java/awt/Color.<init> (III)V
      // 3d0: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 3d3: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友何何树友友何友友树 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 3d6: aload 0
      // 3d7: new cn/cool/cherish/value/impl/BooleanValue
      // 3da: dup
      // 3db: sipush 4188
      // 3de: ldc2_w 9188393604464170856
      // 3e1: lload 1
      // 3e2: lxor
      // 3e3: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3e8: ldc_w "金"
      // 3eb: bipush 1
      // 3ec: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 3ef: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 3f2: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何友何树树树何树友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 3f5: aload 0
      // 3f6: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 3f9: dup
      // 3fa: sipush 12556
      // 3fd: ldc2_w 2848838779418637945
      // 400: lload 1
      // 401: lxor
      // 402: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 407: bipush 115
      // 409: ldc2_w 9126869684173653768
      // 40c: lload 1
      // 40d: lxor
      // 40e: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 413: new java/awt/Color
      // 416: dup
      // 417: sipush 205
      // 41a: bipush 127
      // 41c: bipush 50
      // 41e: invokespecial java/awt/Color.<init> (III)V
      // 421: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 424: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何友友树何何友友树友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 427: aload 0
      // 428: new cn/cool/cherish/value/impl/BooleanValue
      // 42b: dup
      // 42c: sipush 2694
      // 42f: ldc2_w 7063970410190032272
      // 432: lload 1
      // 433: lxor
      // 434: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 439: ldc_w "铜"
      // 43c: bipush 1
      // 43d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 440: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 443: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树友何友友树何树何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 446: aload 0
      // 447: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 44a: dup
      // 44b: sipush 176
      // 44e: ldc2_w 5197401815422617548
      // 451: lload 1
      // 452: lxor
      // 453: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 458: sipush 8967
      // 45b: ldc2_w 3119491941338833980
      // 45e: lload 1
      // 45f: lxor
      // 460: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 465: new java/awt/Color
      // 468: dup
      // 469: bipush 0
      // 46a: bipush 0
      // 46b: sipush 255
      // 46e: invokespecial java/awt/Color.<init> (III)V
      // 471: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 474: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友友何树树树友何何何 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 477: aload 0
      // 478: new cn/cool/cherish/value/impl/BooleanValue
      // 47b: dup
      // 47c: sipush 26993
      // 47f: ldc2_w 8470450120040427083
      // 482: lload 1
      // 483: lxor
      // 484: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 489: sipush 3678
      // 48c: ldc2_w 2577729131057596723
      // 48f: lload 1
      // 490: lxor
      // 491: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 496: bipush 1
      // 497: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 49a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 49d: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友何何何友何何何友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 4a0: aload 0
      // 4a1: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 4a4: dup
      // 4a5: sipush 8939
      // 4a8: ldc2_w 618920746148095360
      // 4ab: lload 1
      // 4ac: lxor
      // 4ad: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4b2: sipush 15057
      // 4b5: ldc2_w 4918997674846322086
      // 4b8: lload 1
      // 4b9: lxor
      // 4ba: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4bf: new java/awt/Color
      // 4c2: dup
      // 4c3: bipush 50
      // 4c5: bipush 50
      // 4c7: bipush 50
      // 4c9: invokespecial java/awt/Color.<init> (III)V
      // 4cc: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 4cf: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友何何友友何友树友何 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 4d2: aload 0
      // 4d3: new cn/cool/cherish/value/impl/BooleanValue
      // 4d6: dup
      // 4d7: sipush 15875
      // 4da: ldc2_w 6587223107360323845
      // 4dd: lload 1
      // 4de: lxor
      // 4df: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e4: ldc_w "煤"
      // 4e7: bipush 0
      // 4e8: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 4eb: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 4ee: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树友树友友友友何何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 4f1: aload 0
      // 4f2: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 4f5: dup
      // 4f6: sipush 29445
      // 4f9: ldc2_w 1368917582893298747
      // 4fc: lload 1
      // 4fd: lxor
      // 4fe: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 503: sipush 5872
      // 506: ldc2_w 2793741526762508676
      // 509: lload 1
      // 50a: lxor
      // 50b: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 510: new java/awt/Color
      // 513: dup
      // 514: sipush 255
      // 517: bipush 100
      // 519: sipush 255
      // 51c: invokespecial java/awt/Color.<init> (III)V
      // 51f: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 522: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友何树何友树友友树何 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 525: aload 0
      // 526: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 529: dup
      // 52a: sipush 24230
      // 52d: ldc2_w 6387242544703347075
      // 530: lload 1
      // 531: lxor
      // 532: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 537: sipush 5904
      // 53a: ldc2_w 8896065956084437050
      // 53d: lload 1
      // 53e: lxor
      // 53f: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 544: new java/awt/Color
      // 547: dup
      // 548: sipush 128
      // 54b: sipush 128
      // 54e: sipush 128
      // 551: invokespecial java/awt/Color.<init> (III)V
      // 554: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 557: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何友树何树友友树何何 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 55a: aload 0
      // 55b: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 55e: dup
      // 55f: sipush 31530
      // 562: ldc2_w 9162009554226691083
      // 565: lload 1
      // 566: lxor
      // 567: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 56c: sipush 25559
      // 56f: ldc2_w 5660527736415364287
      // 572: lload 1
      // 573: lxor
      // 574: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 579: new java/awt/Color
      // 57c: dup
      // 57d: sipush 128
      // 580: bipush 0
      // 581: sipush 128
      // 584: invokespecial java/awt/Color.<init> (III)V
      // 587: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 58a: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友树友何友友友何友树 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 58d: aload 0
      // 58e: new cn/cool/cherish/value/impl/NumberValue
      // 591: dup
      // 592: sipush 12074
      // 595: ldc2_w 3972039708613699639
      // 598: lload 1
      // 599: lxor
      // 59a: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 59f: sipush 3818
      // 5a2: ldc2_w 1116820619712645597
      // 5a5: lload 1
      // 5a6: lxor
      // 5a7: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5ac: bipush 30
      // 5ae: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5b1: bipush 5
      // 5b2: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5b5: bipush 100
      // 5b7: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5ba: bipush 1
      // 5bb: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5be: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 5c1: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友何友树何何树何树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 5c4: aload 0
      // 5c5: new cn/cool/cherish/value/impl/NumberValue
      // 5c8: dup
      // 5c9: sipush 15572
      // 5cc: ldc2_w 3766831817249618920
      // 5cf: lload 1
      // 5d0: lxor
      // 5d1: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5d6: sipush 25376
      // 5d9: ldc2_w 3984033808025429043
      // 5dc: lload 1
      // 5dd: lxor
      // 5de: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5e3: sipush 500
      // 5e6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5e9: bipush 100
      // 5eb: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5ee: sipush 2000
      // 5f1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5f4: bipush 100
      // 5f6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5f9: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 5fc: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友树友友何友何何何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 5ff: aload 0
      // 600: new cn/cool/cherish/value/impl/NumberValue
      // 603: dup
      // 604: sipush 9819
      // 607: ldc2_w 578884470305841520
      // 60a: lload 1
      // 60b: lxor
      // 60c: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 611: sipush 6742
      // 614: ldc2_w 4474684032737009003
      // 617: lload 1
      // 618: lxor
      // 619: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 61e: bipush 10
      // 620: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 623: bipush 5
      // 624: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 627: bipush 50
      // 629: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 62c: bipush 1
      // 62d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 630: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 633: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树友树何树何何何何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 636: aload 0
      // 637: new cn/cool/cherish/value/impl/NumberValue
      // 63a: dup
      // 63b: sipush 15031
      // 63e: ldc2_w 2404280994419998158
      // 641: lload 1
      // 642: lxor
      // 643: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 648: sipush 21711
      // 64b: ldc2_w 3483154054128014249
      // 64e: lload 1
      // 64f: lxor
      // 650: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 655: bipush 2
      // 656: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 659: bipush 1
      // 65a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 65d: bipush 10
      // 65f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 662: bipush 1
      // 663: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 666: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 669: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何何树何何何树何友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 66c: aload 0
      // 66d: new cn/cool/cherish/value/impl/NumberValue
      // 670: dup
      // 671: sipush 32465
      // 674: ldc2_w 5011756686157658548
      // 677: lload 1
      // 678: lxor
      // 679: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 67e: sipush 25339
      // 681: ldc2_w 1683897771378419096
      // 684: lload 1
      // 685: lxor
      // 686: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 68b: ldc2_w 6.0
      // 68e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 691: dconst_1
      // 692: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 695: ldc2_w 10.0
      // 698: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 69b: ldc2_w 0.5
      // 69e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 6a1: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 6a4: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友树友何何友何树友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 6a7: pop
      // 6a8: aload 0
      // 6a9: new cn/cool/cherish/value/impl/NumberValue
      // 6ac: dup
      // 6ad: sipush 7752
      // 6b0: ldc2_w 6395028346010032458
      // 6b3: lload 1
      // 6b4: lxor
      // 6b5: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6ba: sipush 32264
      // 6bd: ldc2_w 1415614167568529700
      // 6c0: lload 1
      // 6c1: lxor
      // 6c2: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6c7: bipush 10
      // 6c9: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 6cc: bipush 3
      // 6cd: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 6d0: bipush 20
      // 6d2: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 6d5: bipush 1
      // 6d6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 6d9: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 6dc: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何何何何何树友友友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 6df: aload 0
      // 6e0: new cn/cool/cherish/value/impl/NumberValue
      // 6e3: dup
      // 6e4: sipush 17340
      // 6e7: ldc2_w 678596631014802614
      // 6ea: lload 1
      // 6eb: lxor
      // 6ec: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6f1: sipush 28452
      // 6f4: ldc2_w 5969508512918972480
      // 6f7: lload 1
      // 6f8: lxor
      // 6f9: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6fe: bipush 50
      // 700: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 703: bipush 10
      // 705: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 708: sipush 200
      // 70b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 70e: bipush 5
      // 70f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 712: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 715: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何树树树树友何何何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 718: aload 0
      // 719: new cn/cool/cherish/value/impl/BooleanValue
      // 71c: dup
      // 71d: sipush 31887
      // 720: ldc2_w 4718123146041277335
      // 723: lload 1
      // 724: lxor
      // 725: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 72a: sipush 4348
      // 72d: ldc2_w 8210821279652960187
      // 730: lload 1
      // 731: lxor
      // 732: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 737: bipush 1
      // 738: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 73b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 73e: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.友树友友树何树友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 741: aload 0
      // 742: new cn/cool/cherish/value/impl/BooleanValue
      // 745: dup
      // 746: sipush 31281
      // 749: ldc2_w 7249601931154210048
      // 74c: lload 1
      // 74d: lxor
      // 74e: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 753: sipush 8379
      // 756: ldc2_w 7484854912518383515
      // 759: lload 1
      // 75a: lxor
      // 75b: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 760: bipush 1
      // 761: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 764: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 767: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树友友树友友何树友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 76a: aload 0
      // 76b: new java/util/concurrent/ConcurrentHashMap
      // 76e: dup
      // 76f: invokespecial java/util/concurrent/ConcurrentHashMap.<init> ()V
      // 772: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何何树友何友何树友树 Ljava/util/concurrent/ConcurrentHashMap;
      // 775: aload 0
      // 776: invokestatic java/util/concurrent/ConcurrentHashMap.newKeySet ()Ljava/util/concurrent/ConcurrentHashMap$KeySetView;
      // 779: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树何友树友何友何树友 Ljava/util/Set;
      // 77c: aload 0
      // 77d: invokestatic java/util/concurrent/ConcurrentHashMap.newKeySet ()Ljava/util/concurrent/ConcurrentHashMap$KeySetView;
      // 780: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.何树何友何何友友树何 Ljava/util/Set;
      // 783: aload 0
      // 784: aconst_null
      // 785: ldc2_w 5720728097848529365
      // 788: lload 1
      // 789: invokedynamic n (Ljava/lang/Object;Lnet/minecraft/core/BlockPos;JJ)V bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 78e: aload 0
      // 78f: bipush 0
      // 790: ldc2_w 5724131333218941523
      // 793: lload 1
      // 794: invokedynamic n (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 799: aload 0
      // 79a: new cn/cool/cherish/utils/树友树友友何何树何何
      // 79d: dup
      // 79e: lload 3
      // 79f: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 7a2: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树何友友树友树何何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 7a5: aload 0
      // 7a6: new java/util/concurrent/CopyOnWriteArraySet
      // 7a9: dup
      // 7aa: invokespecial java/util/concurrent/CopyOnWriteArraySet.<init> ()V
      // 7ad: putfield cn/cool/cherish/module/impl/render/树何树何何友树友树何.树何树何友何何友树何 Ljava/util/concurrent/CopyOnWriteArraySet;
      // 7b0: aload 0
      // 7b1: lconst_0
      // 7b2: ldc2_w 5717359748140554545
      // 7b5: lload 1
      // 7b6: invokedynamic n (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 7bb: ldc2_w 5721667486562088358
      // 7be: lload 1
      // 7bf: invokedynamic C (JJ)Z bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 7c4: ifeq 7d3
      // 7c7: ldc_w "yzjndb"
      // 7ca: ldc2_w 5722802355577310479
      // 7cd: lload 1
      // 7ce: invokedynamic C (Ljava/lang/Object;JJ)V bsm=cn/cool/cherish/module/impl/render/树何树何何友树友树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 7d3: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1664445033475515667L, -9163521654149608909L, MethodHandles.lookup().lookupClass()).a(215614848640630L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 132894553257910L;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[99];
      int var18 = 0;
      String var17 = "üxÛê\u0088íÜZpTa~G?¥È_Ê\u0095û\u0015Eõ¢<qü\u0011\u0088_\u0006:\u0087oó\u0012ÜHâ\u0088\u0010]ïwÔ¡\u0088d]ÀB\u0015#=Bö,\u0010¯\u009bÈ \u0007G/÷\u008e¬í¡ã\u0095#w\u0018SâÙÓ-R½«vQO£K¾·'§õR[ïºÊ\u0093(8,µ\u0019#ñ5R7ÍûUßf<:kk\u009b\u0080{Æ·ïª\u0002±\u0016\u001e¸»Ñ£è\u00934\u008fW\u001fæ\u0018à\u001e\u0005§ox^ùh\nÏôÄN[ÇfDI0Ô\u0014æV\u0010e\u0019D\u0080·Ê\u0011 ª\u0088A¨èýÇ\b\u0018Zï÷\u0006pÅWV\u009e\u008aBÿA>F\u001eß½6!}}e\u0005\u0010¨ÛT\u008c½mY´\fµ\u0087îìæ\u0082ô(\u0087\u009ao¦A¾UÒ~\t±wË\u0093¬ô®5âà\u0005\u008b^À¥B\u0011\u0083e\u0092\f>r\u0015øfw+w3\u0018Éû\u0097ÌaDLR¸`\u000e\u009d\u0015¤\u009e\bÜ\u0085\u008d(\u009c\u0080÷¤ <ÆÑÂê½\u0097F\u008cQ\u0016Yüä\u0089-u\u0088PÇ¨Ç4\u009eÛÄ\u0002Tc\u0011\u0099\u0010\u0018N÷\n|¯F\u009eÈ8¹¸\u0005#\u0085[\u00163JÉ\fuÛ+P ¢\u0001!\u000eþÆAÊ<K\u001c\u0089[zÑ.8\u0090ù1+ng\u009d-#E7Ñ|?\u0014 8\u008d'zá\u0084m\u0081\u0097Ë\u0005òc÷ô!\u0015ùjz;/vþ¹\u0090Å\u001büO@ü \"\u0013\u0080\u0091¢ÁÃ\u0005 ¯\u001cÅú\u0002$À\u0085ÃÕh,\f\u00adQà\u0094O\u009d\u008e½wñ\u0010¶ß\u0086\u0081UÏWL»\u008b`°¤\u00adñ^\u00102\b\u0083AÅÿ\u00adhÐ\u00adI\u0080\u001d2Ý¼\u00108¼ìmu\u0010Ç\u001c\n\u0007¬\u0081=N-\\\u0010rÞ\u009e³h\u0012\u0082]½fz£5¯r\u0090(ð\\f9\u0000¥nØ\u0010\u0019Qf^êíÐþ&Ç\u008fv6«à'\u001fú½\u0085-\u0095§\u008b¶|\u0004\u00014:)\u0010\u0019%ß\u001eË(\u009cýC\u008d@\u0087f°¤\u009d\u0010¡\u0088±\u0013\u0005.\u008b\u0019RDNõ\u007fÓe\u008d \u0084éµS\u0004Ìê\u0007\u001dy:£ÞA\u0083¾ZÌ¨Í\u009d\u0006\nn0\u009cNÄÈC¿|(ø\b\u001dJ¦\u007fÃÒ\u0089\u009b\u008b4\u0014ó0N(r\\\u0093\f¶ògÜ\u0006TO0«¯&ú·\u0090\u000f\u001a\u0095=û a~Üé2\u0012ºAîZÙÁ\u008aÎÞ8Âlìõ\u0089ÿ\u0080}£\u0083tû§\u0085óH \\OF\u0081°6®\u00adÞ\u007f-:7ÆiÜô@GJë@Zåatá\u0094Ó«ôé\u0018\u0095ðÞñ§\u009d(Èw\u0093Ú\u001b§\u0086 ?a\u009dòì\u0083uq¼\u0010\u0096\u0005,¢v\u0097ÍþÃ)¼~pÖL\u0013\u0010\u0090Ò¾34¿\u0096üõÏw@EÂìÀ \u0018Ïé\u008d[â\u0005,\u0090¶B\b)8\u0087\u009fpK\u0019Må&\u0083ÞÒk%a%\bÐ\u0006\u0010x\u0018»÷\u001fëØå.G\u0003àç'±Û Ýé¯;ð\u0013Áfä«\u0005\u0082-QPÜì¤o?Ã\u0007»\u0092óm²Cµ\u000e\u0014á(¦\u009f\u0000N\u0000\u0014<Ù\u0096õtYÊj$M\u001cà\u0010ß\u0099õ\u0098ç\u0088÷A£\u001ax0¥Å\t\u0093<;J¨G\u0010f\u0089\u00024¤ä§e`ñ\u001ah\u001f¯ìe\u0010ÿce\u0011ò0«o\u001aø\u0018©¯3\u008cØ\u0010ï>\u0001^«à`½ÃØuÛ(¸X4\u0010\u0010\u0095O\u0084\u0011\u008cÝÝ\u00adÍ9ÞÍgªC\u0018.ÝEûî>ç¤Ïù;Ñ\u0018\u0099¼\b{Øä\u0005ãôAÿ0Io»G4îØ¹Çkd |\u000f}\nI\u0006ÖêH\u008e\u0095¤\u008bÉÇð3AóBû¤;7<\u0081\u0002d°\u0092\n~NÖT!@¥ò\u008c\u0018¾\u001f\u001c²\u0099Ì\u001e×Ä\u0098\fò\u0080I\u008e¸Y¬1¹\u00adoH]cewêÀ¨½ün\u0017³R\u0094S\u0082 \u0012\u0082²£íÖ\u0014e¯ÃX²\n©\u000b¬:yzº\u0018RÎha\u0084&ga\u008f\"\u009d\u0099#c\u001f\u0081®\u00048gò\u001e#Ë\u0010W±ÔùÍÖÄNÙ÷\u008a¿Ë+öW \u0006Ì*Ú\u008f5\u0090\býèë\u0086üs¾\u0017F\u0017\u0017Ö\u0086tÞU\u0006\u009dïû\u0096$Ùÿ\u0010N\u0094âÃ!\u0080}Ø&\u00adò\u0089þoòq\u0010Tõ\u009c\u000bÓ»4±¹°\u0005þÐËW\u0097 c\tÇûMOV¿×%\u001a£ÖD\u0005¡£\u0017\u0098è\u009e\u0011f\u009a9ü\u007fÅJÕI©(Ä\"ûâ«\"ì:\u0010V®«r.²nµ_ú\u00870\u0000_²ÌÜ¨£\u001de\töÀ\u0094\u0088Â¹û¯U(³SÇGÇb\u0010.\u009chµ\u0014ÀÚhÅVÒ¥\u0007\u0096¥\u0018gçÝ<\u0085E\u0080ôï\u0015É5í\u0001\t^\u0007\u0010\u009cØØèÛäå((Éü:]ÖëÈ\u0018\u00ad\u0017s\u008f(Úp%Ä\u001e\n\u008eæz Ä\u001bdSá\u009c±$\u0097\u00106C~ßJ\u0001kUv\u0095\u001f\u0013'Ñ\u0081B\u0018Ê\u0098\u0000«\u0004ùy\u0002\u001es\t\u009e\u008b\u0098¯`\u0003öýìWcM¾\u0010ªõd\"Q\u0019õ\u001b7§\u0016<¡_Ð\u001d \u00197\u001e²ÿ\u00907<xÌ\u008cäª¼?Ë\u0018ë\u009c}O\u001a±\u0000|ûpn éQH Ì\u0013\u0006âÐ>[û\u0017[¨þ¾\\Õ±Æ~N8U\u0097®+\u000f¶\u008b\u0001X\u001eþ©\u0010Õ\u00050®äi\u0011¬\u0089a\u00927àû;\u0003\u0010|\u001dªx6\u0019Wó\u001cZÉw3\u0012ëÚ \u008cñ\u000fK®U\u0017ÂÅ#¶°Î\u0099éÚ\u0086\u0016Grrâ\u008d\u0016È\u009dK]%imJ\u0018´Ûñ@ô55üG`¸MÜ¨³fßwôx\u0096ÄÄd\u0010.ä\u008es\u0085*ëÎã\u00927v\u009f0C» \u009cÖa¶Æf+[ÊÊ¹1;q6öjÓ\u0083D\u0084\u008c¿è@ØD\u0012«HÈy\u0010>cÅ½,\u0080¨u\u009eÿ×\u0005'¦Nä\u0010ÈÀfEô¼\u0018ô\u0092lF6é\u0086¬4 ÅÞ9 òÐ\u0083o$\u001dP=[|\u000byõ}Fô;jç\u00ad\u0082.\u000fk/Ê\u0093;(,´\u000bQ\u008e.\u0003°\u001aö'åo- Ù\u0005\u0010¡WC\u0087f}\u0011lÃá¡\u0002ÒkT]Io\u0082P\u0084@ ¹HMð¤\u008d#qeUÕ\u009d¦£\u009e»íM¬ÿ¶«\u00ad\u0091Â1\u007fÍ¶\u0019\u001b\u0015 \u0098ibõ½\u001d\u0011\u0018½\u001c\u0011õ6\u001d \u0090tÕ\u0006\u0084\u009dp\u0080\u0005\f\u0091ü¯_óçàP\u0006áZSÐ8}Õ\u0095\u0012û5rf-Ì,ùÇ\u000f\u0015\u001f\u0090Ï\f9\b\u0086b}å\u0089\u000b\u008b \u0083aä¦!\u0093µå\u009c<\u0003\u0091i«\u0002Þè\u0084\u0086\u0080îy\u00adI\n<ì¦\u0091OÛ#ÔZÓj\u0006íÎgK ç\u0011û(»¤ïü\u0010Ås#ßÜW`Û2Ê²ñ©\u009b\\\u0088~ò\bæ1£ ¼('|w\u0082\"Í±Êí`(\u0000½h=OL¯\u0099ð\u0005\u0000å*UXV\u0007\u0090µ2b\u001aKáiôvYf\u0017\u009eYòâ\u0002õ\f?4h \u0005\u001dÆ\u0002¾5\u009dõÎ> ÖéõÕ¸\u008a\nP\u0083r\u0015q¨\\\bLy×n¿\u0014 `\u0090áÍÎ¦îY\u008c+°\u0000\u008b\u0006Ú\u009dQ\u000f\u0005ó\u0095&\býnyb¢Ôbò[\u0018\u0006\u001dãï{A,\u001b\u0096¨\u008e\u008a¼>\u0094:\u00858úúZåÄü\u0018Êjlö±Ö?¾\rUG\u007fc\u0004ÊÅ»°?¼c\u0006æÌ\u0010IüÏ\u008c\u008fÅ/ì®\u009dì-ª3Tn ³r\u0091¶\u0015¡cbPÅ\u001c\u0007{\u0010K&\t\rÿ\u0016jP\u001d\u0085¿?\u0002\u0010ÿã>á(\u0088EXÔ9¢m\u0007\u009få\u009da/\u0004\u001c\u0089ü\u0095 ÷Íí\u009aw\u00989÷¸7\u0088\u009fþ\u0093~d8\t2$\u0000\u0018\u001e\u001f# \u0095'0Ë3C\u0083\u008a\u0001\u0018³\u0084´N\u001eÕgwZS\u0010°\u001cáv\u001d\u0010z\u008e£Éh;§luD ¦Ë®2.¬úb]\u008d\\ÑÝ\u0093ë[iÒ:r\nsa{\u0084Ñ\u0094ÔOxS7 ¡\u0019U\u0084MK\u000e/DÐmÜì`8k2ô\u0001\u008cÏý\u009f´ (T¯Mt\u0002\u007f\u0018Ø\u009bß}¬ìð®¥.N\u00819£\u008d±\u008e·`Ì'Q\u008b\u0013\u0010åf\u0086\u0094k^ô×\u0017'è\u009aî<aö\u0018ß·ïÊD\u0015G¯'Mè|K\u008bÍÑ?ô¥Ñ}®xS n!\u0000æª(áÿR\u0018×ý\u0000ðïOWç\u009azÝ\u008b\u007fO'y3Xµ ®\r Â³gT\u0005@'\u0018æ\u008c\u0013\u007f0ë¯ Øï\n\u0083±3Sdû;\u001cK±\u0088\u0010= Ä{\u0017\bÅ\u0092\u0095\u001eów¶¼§ Ë¥2¶©VÉ\u0016Ö¯\u0096sÔ\u007f»\u009eVï\u0018±Y\f\u0013\u0080¥\u0011Búþ\u0092úÛd&èÁA{\f¹\u0086[\u0002\u0018=CÝ°l\u007fÉ\u00865¯\u0099\u008e\u0096æ\f\u0082\u001c;·\u0019KpÇ\u0007\u0018µÀN\u0086\u0091Èã\u0012{As\u0004(Ôº¨\u009d\u0090ºÞä\f\u008a+\u0010ýÇà\u000f\u009cú3çò\u0081ë\u009cwT]\u009e ](\u00ad:\u0096J4©CÀl\u0004>\u0011í³a\u0011N¸µ¢?Ò²\u0010\u009e·\u0096«Ñ¢\u0010ôwË?å\u0082\u0097\u008a;Æ\nDÈÁM± |»Tþäá{Bî$õß\u001c§Ì^>WO\u0004ÎËÉç\u0003!&ÌJ`]µ\u0018úhA{jÅý%ó\u0080i{51ý\n\u007fOÖc\t\u000bÄï\u0010mYÐ\u0096Ts\u009bE9ái\nûpõÊ";
      short var19 = 2688;
      char var16 = '(';
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[99];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0089\u0089e¸¤Ó\rVÚ´\u00ad\u0092r\u0080]å".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     何树树树树树树友何友 = c<"e">(7804, var11 ^ 5350565801090816229L);
                     友友友友何何友树友树 = new int[][]{{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "\u0014,x\u001a´B½·%\u0082Iö\rØP7nÀ\u0000\u0084y\u008cB7!ÂÖ\u001f\u0017\u0088³\u008a \u0099\u001c\u0006í\u009e\u0003óþé)î\u0092\u000e!áeU¥`\\ÆðÔÃD\u0007áU©èZÊ";
                  var19 = 65;
                  var16 = ' ';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private double D(BlockPos point, BlockPos lineStart, BlockPos lineEnd) {
      long a = 树何树何何友树友树何.a ^ 88290149458794L;
      double x0 = point.getX();
      d<"C">(-5607492513113171992L, a);
      double y0 = point.getY();
      double z0 = point.getZ();
      double x1 = lineStart.getX();
      double y1 = lineStart.getY();
      double z1 = lineStart.getZ();
      double x2 = lineEnd.getX();
      double y2 = lineEnd.getY();
      double z2 = lineEnd.getZ();
      double dx = x2 - x1;
      double dy = y2 - y1;
      double dz = z2 - z1;
      double lineLength2 = dx * dx + dy * dy + dz * dz;
      if (lineLength2 == 0.0) {
         return Math.sqrt((x0 - x1) * (x0 - x1) + (y0 - y1) * (y0 - y1) + (z0 - z1) * (z0 - z1));
      } else {
         double t = ((x0 - x1) * dx + (y0 - y1) * dy + (z0 - z1) * dz) / lineLength2;
         t = Math.max(0.0, Math.min(1.0, t));
         double projX = x1 + t * dx;
         double projY = y1 + t * dy;
         double projZ = z1 + t * dz;
         return Math.sqrt((x0 - projX) * (x0 - projX) + (y0 - projY) * (y0 - projY) + (z0 - projZ) * (z0 - projZ));
      }
   }

   private void D(BlockPos playerPos, int scanRange) {
      long a = 树何树何何友树友树何.a ^ 91419755902735L;
      String var6 = d<"b">(this, 2759541552708738283L, a).getValue();
      d<"C">(2759347768879711117L, a);
      byte var7 = -1;
      switch (var6.hashCode()) {
         case 1377272541:
            if (!var6.equals(b<"t">(25611, 4979779519975082540L ^ a))) {
               break;
            }

            var7 = 0;
         case 355597568:
            if (!var6.equals(b<"t">(28291, 6714095024138567897L ^ a))) {
               break;
            }

            var7 = 1;
         case 2029746065:
            if (var6.equals(b<"t">(24836, 108515200915197735L ^ a))) {
               var7 = 2;
            }
      }

      switch (var7) {
         case 0:
            this.Y(playerPos, scanRange);
         case 1:
            if (!(Boolean)Fucker.isLogin || !(Boolean)Fucker.isBeta && !(Boolean)Fucker.树何何友何树树友友树) {
               break;
            }

            this.J(playerPos, scanRange);
         case 2:
            this.b(playerPos, scanRange);
      }
   }

   protected void F() {
      long a = 树何树何何友树友树何.a ^ 11593549153446L;
      d<"b">(this, 6183817418303346915L, a).clear();
      d<"b">(this, 6196277613646751247L, a).clear();
      d<"b">(this, 6189568966476499525L, a).clear();
      d<"b">(this, 6183721056897711787L, a).clear();
   }

   private void J(BlockPos playerPos, int scanRange) {
      long a = 树何树何何友树友树何.a ^ 62319814060768L;
      long ax = a ^ 59388403423683L;
      d<"C">(8909324739854851682L, a);
      if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
         int px = playerPos.getX();
         int py = playerPos.getY();
         int pz = playerPos.getZ();
         Set<BlockPos> visitedInScan = new HashSet<>();
         int x = px - scanRange;
         if (x <= px + scanRange) {
            int y = Math.max(mc.level.getMinBuildHeight(), py - scanRange);
            if (y <= Math.min(mc.level.getMaxBuildHeight(), py + scanRange)) {
               int z = pz - scanRange;
               if (z <= pz + scanRange) {
                  BlockPos pos = new BlockPos(x, y, z);
                  Block block = 树友友何树友树树树何.o(ax, pos);
                  if (block == d<"Ø">(8909548574230574544L, a) && d<"b">(this, 8904348105024990286L, a).getValue()) {
                     d<"b">(this, 8905700085608232613L, a).put(pos, new 树何树何何友树友树何.树树友友友何友何何树(block, d<"Ø">(8903902510428843040L, a), 10.0));
                     this.x(pos);
                  }

                  if (block == d<"Ø">(8905444966592121451L, a) && d<"b">(this, 8916460122949402695L, a).getValue()) {
                     d<"b">(this, 8905700085608232613L, a).put(pos, new 树何树何何友树友树何.树树友友友何友何何树(block, d<"Ø">(8905772121890325867L, a), 10.0));
                  }

                  if (d<"b">(this, 8912120451634916102L, a).getValue() && this.i(pos) && !visitedInScan.contains(pos)) {
                     Set<BlockPos> caveBlocks = this.p(pos, visitedInScan, scanRange, playerPos);
                     if (caveBlocks.size() >= d<"b">(this, 8912583757199261236L, a).getValue().intValue() && this.i(caveBlocks)) {
                        this.S(caveBlocks);
                     }
                  }

                  z++;
               }

               y++;
            }

            x++;
         }
      }
   }

   @EventTarget
   public void J(Render3DEvent event) {
      long a = 树何树何何友树友树何.a ^ 106157218627757L;
      long ax = a ^ 77470764181713L;
      d<"C">(-3321088594612161489L, a);
      if (!this.w(new Object[]{ax})) {
         Vec3 camPos = d<"b">(mc, -3317120324952563578L, a).getMainCamera().getPosition();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         RenderSystem.setShader(GameRenderer::getPositionColorShader);
         PoseStack poseStack = event.poseStack();
         poseStack.pushPose();

         try {
            d<"b">(this, -3324897263065351520L, a).clear();
            Iterator var9 = d<"b">(this, -3325275923896886040L, a).entrySet().iterator();
            if (var9.hasNext()) {
               Entry<BlockPos, 树何树何何友树友树何.树树友友友何友何何树> entry = (Entry<BlockPos, 树何树何何友树友树何.树树友友友何友何何树>)var9.next();
               BlockPos pos = entry.getKey();
               树何树何何友树友树何.树树友友友何友何何树 info = entry.getValue();
               if (mc.level.isLoaded(pos)) {
                  Block currentBlock = mc.level.getBlockState(pos).getBlock();
                  if (currentBlock == d<"b">(info, -3324253646206289751L, a) && this.w(info)) {
                     d<"b">(this, -3324897263065351520L, a).add(pos);
                     this.i(poseStack, pos, info, camPos);
                  }
               }
            }

            d<"b">(this, -3325275923896886040L, a).entrySet().removeIf(entryx -> {
               long axx = 树何树何何友树友树何.a ^ 4179484812168L;
               d<"C">(8272123802623792906L, axx);
               return !d<"b">(this, 8286329536781064581L, axx).contains(entryx.getKey());
            });
         } finally {
            poseStack.popPose();
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
         }
      }
   }

   private void S(Set<BlockPos> caveBlocks) {
      long a = 树何树何何友树友树何.a ^ 24853683195344L;
      long ax = a ^ 26612492205811L;
      d<"C">(2059387009548532050L, a);
      Iterator var7 = caveBlocks.iterator();
      if (var7.hasNext()) {
         BlockPos caveBlock = (BlockPos)var7.next();
         Direction[] var9 = Direction.values();
         int var10 = var9.length;
         int var11 = 0;
         if (0 < var10) {
            Direction dir = var9[0];
            BlockPos adjacentPos = caveBlock.relative(dir);
            Block block = 树友友何树友树树树何.o(ax, adjacentPos);
            if (this.j(block)) {
               double authenticity = this.f(adjacentPos, block);
               if (authenticity >= d<"b">(this, 2058795250605664044L, a).getValue().doubleValue()
                  && this.H(adjacentPos, block, d<"b">(this, 2061459708962255605L, a).getValue().intValue())) {
                  树何树何何友树友树何.友友树树何何何友何何 type = this.i(block);
                  d<"b">(this, 2064699477734478229L, a).put(adjacentPos, new 树何树何何友树友树何.树树友友友何友何何树(block, type, authenticity));
               }
            }

            var11++;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private boolean i(BlockPos pos) {
      long a = 树何树何何友树友树何.a ^ 41223828469986L;
      long ax = a ^ 3878851006622L;
      d<"C">(-6222186370461201312L, a);
      if (!this.w(new Object[]{ax}) && mc.level.isLoaded(pos)) {
         BlockState state = mc.level.getBlockState(pos);
         return state.isAir()
            || !state.canOcclude()
            || state.getBlock() == d<"Ø">(-6217163441112646306L, a)
            || state.getBlock() == d<"Ø">(-6220904488074172327L, a)
            || state.getBlock() == d<"Ø">(-6216206194071482718L, a);
      } else {
         return false;
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 36;
               case 1 -> 41;
               case 2 -> 2;
               case 3 -> 6;
               case 4 -> 61;
               case 5 -> 11;
               case 6 -> 4;
               case 7 -> 59;
               case 8 -> 46;
               case 9 -> 44;
               case 10 -> 23;
               case 11 -> 54;
               case 12 -> 38;
               case 13 -> 19;
               case 14 -> 55;
               case 15 -> 60;
               case 16 -> 1;
               case 17 -> 34;
               case 18 -> 52;
               case 19 -> 33;
               case 20 -> 26;
               case 21 -> 27;
               case 22 -> 3;
               case 23 -> 32;
               case 24 -> 24;
               case 25 -> 37;
               case 26 -> 50;
               case 27 -> 22;
               case 28 -> 31;
               case 29 -> 30;
               case 30 -> 16;
               case 31 -> 10;
               case 32 -> 51;
               case 33 -> 58;
               case 34 -> 53;
               case 35 -> 21;
               case 36 -> 35;
               case 37 -> 0;
               case 38 -> 49;
               case 39 -> 47;
               case 40 -> 20;
               case 41 -> 29;
               case 42 -> 48;
               case 43 -> 8;
               case 44 -> 25;
               case 45 -> 18;
               case 46 -> 7;
               case 47 -> 14;
               case 48 -> 62;
               case 49 -> 15;
               case 50 -> 45;
               case 51 -> 63;
               case 52 -> 9;
               case 53 -> 13;
               case 54 -> 56;
               case 55 -> 57;
               case 56 -> 17;
               case 57 -> 42;
               case 58 -> 39;
               case 59 -> 40;
               case 60 -> 43;
               case 61 -> 5;
               case 62 -> 28;
               default -> 12;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private void i(PoseStack poseStack, BlockPos pos, 树何树何何友树友树何.树树友友友何友何何树 info, Vec3 camPos) {
      long a = 树何树何何友树友树何.a ^ 72213604619070L;
      AABB box = new AABB(pos);
      d<"C">(178524017106659260L, a);
      Color color = this.p(d<"b">(info, 166283313070041914L, a));
      String var10 = d<"b">(this, 177385456095180184L, a).getValue();
      byte var11 = -1;
      switch (var10.hashCode()) {
         case 2222509:
            if (!var10.equals(b<"t">(26036, 8448526946590224296L ^ a))) {
               break;
            }

            var11 = 0;
         case 2368532:
            if (!var10.equals(b<"t">(30118, 9216136046685880233L ^ a))) {
               break;
            }

            var11 = 1;
         case 2076577:
            if (var10.equals(b<"t">(4479, 1545221318266985324L ^ a))) {
               var11 = 2;
            }
      }

      switch (var11) {
         case 0: {
            AABB fillBox = new AABB(pos.getX() + 0.1, pos.getY() + 0.1, pos.getZ() + 0.1, pos.getX() + 0.9, pos.getY() + 0.9, pos.getZ() + 0.9);
            Color fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), 100);
            this.q(poseStack, fillBox, fillColor, camPos);
         }
         case 1:
            this.K(poseStack, box, color, camPos);
         case 2: {
            AABB fillBox = new AABB(pos.getX() + 0.1, pos.getY() + 0.1, pos.getZ() + 0.1, pos.getX() + 0.9, pos.getY() + 0.9, pos.getZ() + 0.9);
            Color fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), 100);
            this.q(poseStack, fillBox, fillColor, camPos);
            this.K(poseStack, box, color, camPos);
         }
      }
   }

   private boolean i(Set<BlockPos> cave) {
      long a = 树何树何何友树友树何.a ^ 12898810848382L;
      d<"C">(-5387865690020704004L, a);
      if (cave.stream().anyMatch(this::m)) {
         return true;
      } else {
         double linearFactor = this.k(cave);
         if (linearFactor >= 0.7) {
            return false;
         } else {
            double branchFactor = this.g(cave);
            if (branchFactor <= 0.3) {
               return false;
            } else {
               double heightVariance = this.L(cave);
               return heightVariance > 3.0;
            }
         }
      }
   }

   private 树何树何何友树友树何.友友树树何何何友何何 i(Block block) {
      long a = 树何树何何友树友树何.a ^ 17068616945173L;
      d<"C">(-2354977373388178793L, a);
      if (block == d<"Ø">(-2355342941718752987L, a)) {
         return d<"Ø">(-2349697015884461867L, a);
      } else if (block == d<"Ø">(-2353238451140720155L, a)) {
         return d<"Ø">(-2353389584537194228L, a);
      } else if (block == d<"Ø">(-2349955241937785186L, a)) {
         return d<"Ø">(-2350140525834591842L, a);
      } else {
         return this.v(block) ? d<"Ø">(-2354782679903170403L, a) : d<"Ø">(-2350710558133904198L, a);
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树何何友树友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private void b(BlockPos playerPos, int scanRange) {
      this.Y(playerPos, scanRange);
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2140;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树何何友树友树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private void x(BlockPos spawnerPos) {
      long a = 树何树何何友树友树何.a ^ 44891466993021L;
      long ax = a ^ 42308064001630L;
      int radius = d<"b">(this, -2579956483861977077L, a).getValue().intValue();
      d<"C">(-2577932707707913729L, a);
      int cobblestoneCount = 0;
      Set<BlockPos> cobblestonePositions = new HashSet<>();
      int x = -radius;
      if (x <= radius) {
         int y = -radius;
         if (y <= radius) {
            int z = -radius;
            if (z <= radius) {
               BlockPos checkPos = spawnerPos.offset(x, y, z);
               Block block = 树友友何树友树树树何.o(ax, checkPos);
               if (block == d<"Ø">(-2576136731185149299L, a)) {
                  cobblestoneCount++;
                  cobblestonePositions.add(checkPos);
               }

               z++;
            }

            y++;
         }

         x++;
      }

      if (cobblestoneCount >= d<"b">(this, -2578089069202196398L, a).getValue().intValue()) {
         Iterator var16 = cobblestonePositions.iterator();
         if (var16.hasNext()) {
            BlockPos pos = (BlockPos)var16.next();
            d<"b">(this, -2591127300006702792L, a).put(pos, new 树何树何何友树友树何.树树友友友何友何何树(d<"Ø">(-2576136731185149299L, a), d<"Ø">(-2576283329093012892L, a), 8.0));
         }
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'b' && var8 != 'n' && var8 != 216 && var8 != 224) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 200) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'C') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'b') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'n') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 216) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 24698;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树何何友树友树何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private void c() {
      long a = 树何树何何友树友树何.a ^ 78714575391049L;
      long ax = a ^ 122684034019797L;
      d<"C">(6344789707457232331L, a);
      long currentTime = System.currentTimeMillis();
      if (currentTime - d<"b">(this, 6358020265980448341L, a) >= c<"e">(14776, 2447531534212891103L ^ a)) {
         Iterator var8 = d<"b">(this, 6358546325897155852L, a).entrySet().iterator();
         if (var8.hasNext()) {
            Entry<BlockPos, 树何树何何友树友树何.树树友友友何友何何树> entry = (Entry<BlockPos, 树何树何何友树友树何.树树友友友何友何何树>)var8.next();
            BlockPos pos = entry.getKey();
            树何树何何友树友树何.树树友友友何友何何树 info = entry.getValue();
            if (!d<"b">(this, 6346368700722031584L, a).contains(pos) && d<"b">(this, 6344710567695330883L, a).getValue()) {
               String blockName = this.t(d<"b">(info, 6357332184488161613L, a));
               String message = String.format(b<"t">(26539, 5082844758246143938L ^ a), blockName, pos.getX(), pos.getY(), pos.getZ());
               if (d<"b">(info, 6346283547813072133L, a) == d<"Ø">(6358186720151509990L, a)) {
                  message = message + String.format(b<"t">(3433, 3755395405783325961L ^ a), d<"b">(info, 6345918833375149620L, a));
               }

               ClientUtils.e(new Object[]{message, ax});
               d<"b">(this, 6346368700722031584L, a).add(pos);
            }
         }

         d<"n">(this, currentTime, 6358020265980448341L, a);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树何何友树友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private double f(BlockPos orePos, Block oreBlock) {
      long a = 树何树何何友树友树何.a ^ 107748723596108L;
      long ax = a ^ 78091133825840L;
      d<"C">(5334547806732545998L, a);
      if (this.w(new Object[]{ax})) {
         return 0.0;
      } else {
         double score = 0.0 + this.P(orePos, oreBlock) + this.p(orePos) + this.U(orePos, oreBlock) + this.d(orePos) + this.X(orePos);
         int exposedFaces = 0;
         Direction[] var11 = Direction.values();
         int var12 = var11.length;
         int var13 = 0;
         if (0 < var12) {
            Direction dir = var11[0];
            if (this.i(orePos.relative(dir))) {
               exposedFaces++;
            }

            var13++;
         }

         if (exposedFaces > 0 && exposedFaces < 6) {
            score += 2.0;
         }

         if (exposedFaces == 6) {
            score--;
         }

         return Math.max(0.0, Math.min(10.0, score));
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private double d(BlockPos orePos) {
      long a = 树何树何何友树友树何.a ^ 92120882374987L;
      long ax = a ^ 102693048277608L;
      d<"C">(4039496597505875401L, a);
      double score = 0.0;
      int airBlocks = 0;
      int stoneBlocks = 0;
      Direction[] var11 = Direction.values();
      int var12 = var11.length;
      int var13 = 0;
      if (0 < var12) {
         Direction dir = var11[0];
         BlockPos adjacent = orePos.relative(dir);
         Block block = 树友友何树友树树树何.o(ax, adjacent);
         if (this.i(adjacent)) {
            airBlocks++;
         }

         if (block == d<"Ø">(4035251428307951032L, a) || block == d<"Ø">(4040908579335027223L, a)) {
            stoneBlocks++;
         }

         var13++;
      }

      if (airBlocks >= 1 && airBlocks <= 3) {
         score = 1.5;
      }

      if (stoneBlocks >= 3) {
         score++;
      }

      return score;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树何何友树友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      m[0] = "a[(\u001bKDa[?GGK{\u0010+ZTAk\u00100PPHc\u0010>YINd\u0010\u001eYINdM";
      m[1] = "SP6]6PSP!\u0001:_I\u001b5\u001c)UY\u001b.\u0016-\\Q\u001b \u001f4ZV\u001b\u0000\u001f4ZV";
      m[2] = "yDzu\u00078v\u00047~\r%sY<8\u00058~_8sF>wZ88\u001a2tN1dF框住栻企佃厣框发栻企";
      m[3] = "\u0012Q\r+\u0019/\u0019^\u001cde6\u0016D\u0012'R\u0006\u0000S\u001e:C*\u0017^";
      m[4] = "Mbebz4B\"(ip)G\u007f#/x4Jy'd;2C|'/g>@h.s;\u0019Kx?dg\u0018Oa.st";
      m[5] = "&Q\u0002<|8-^\u0013s\u0001 >Y\u001a:";
      m[6] = "b\u0014t\u001d4V|\u001cnRyLf\u0016w\u000ehFf\u0001,?uMk\u0000p\u000e\u007fM|=c\u000frni\u0005";
      m[7] = "rf\u0016";
      m[8] = "\u0004T\u000fNL \u000b\u0014BEF=\u000eII\u0003U.\u000bOD\u0003J\"\u0017V\u000fcV\"\u0005_S{B#\u0012_";
      m[9] = "\u000ez\u000bq\u0015h\u0001:Fz\u001fu\u0004gM<\ff\u0001a@<\u0013j\u001dx\u000bP\u0015h\u0001qD|,f\u0001a@";
      m[10] = boolean.class;
      n[10] = "java/lang/Boolean";
      m[11] = "\u0000gM\u0016Iy\u000f'\u0000\u001dCd\nz\u000b[Sb\ne\u0010[样叝桲参厨传佳标伶作";
      m[12] = "]\u001eC[\u00018]\u001eT\u0007\r7GUT\u001a\u001e4\u001d9[\u001a\u000f:c\u0014D";
      m[13] = "4\"ZHV|;b\u0017C\\a>?\u001c\u0005T|39\u0018N\u0017z:<\u0018\u0005Kv9(\u0011Y\u0017栂伂桝伡佾史栂厜桝伡\u000f史变框桝伡佾佬变伂伙";
      m[14] = long.class;
      n[14] = "java/lang/Long";
      m[15] = "l;=[2br3'\u0014Orr";
      m[16] = "I\u001f\u0012\u001fEOW\u0017\bP\bUM\u001d\u0011\f\u0019_M\nJ=\u0004JZ1\n)\u0019SW\u001b%\f\u0019[Z-\u0001\n";
      m[17] = "@>-LxRO~`GrOJ#k\u0001zRG%oJ9TN o\u0001eXM4f]9栬佶桁佖佺叜栬叨桁佖\u000b栆栬叨厛又佺叜佨佶桁";
      m[18] = double.class;
      n[18] = "java/lang/Double";
      m[19] = "bvS{3Zm6\u001ep9Ghk\u00156*Tmm\u001865XqtSU3QdN\u001ct)P";
      m[20] = "[DB7u\f[DUky\u0003A\u000fAvj\tQ\u000fFqa\u0016\u001b`w[Z";
      m[21] = "\u0016(X\u001c\u0004p\u001f&[UG}\u0019&OWZ{[1P@\u001dz\riqW\u000f~\u0000+Ad\fm\u0001\"Mt\u0006m\u0018&A";
      m[22] = "\u001fLBG\u001eR\u0016BA\u000e]_\u0010BU\f@YRUJ\u001b\u0007X\u0004\ry\f\u0001I\u0019[i\u0006\u0001P\u001dW";
      m[23] = "r+Y7\\1{%Z~\u001f<}%N|\u0002:?2QkE;ijb|C*t<rvC3p0\u0010T^:t";
      m[24] = "\u0018xb\u0017CA\u0018xuKON\u00023aV\\D\u00123fQW[XKsZ\u001d";
      m[25] = "|H#:H2|H4fD=f\u00034xL>|YyYL5wN%uC/";
      m[26] = "\b,Veb\u0004\b,A9n\u000b\u0012gA'f\b\b=\f9j\u0003\u0002,P.}C!(O.]\b\b-G9j\u001f";
      m[27] = "k\\jFY\u0017d\u001c'MS\naA,\u000b@\u0019dG!\u000b_\u0015x^j栴叽伭參佧休叮栧桩參";
      m[28] = "\nh9/M8\u0017}a\r\f5\u000f{";
      m[29] = "\u001dbB@3\u0011\u0012\"\u000fK9\f\u0017\u007f\u0004\r1\u0011\u001ay\u0000Fr\u0017\u0013|\u0000\r.\u001b\u0010h\tQr桯伫栝伹佶厗桯厵栝伹\u0007伉桯伫余厧佶桍桯桯栝";
      m[30] = "5\u0015";
      m[31] = void.class;
      n[31] = "java/lang/Void";
      m[32] = "$tT+\u0006*+4\u0019 \f7.i\u0012f\u0004*#o\u0016-G\b(~\u000f$\f";
      m[33] = "sWRq.<|\u0017\u001fz$!yJ\u0014<,<tL\u0010wo伆佅史伩佇厊伆佅栨桭";
      m[34] = "%\u001f25y\u000e%\u001f%iu\u0001?T1tf\u000b/T*~b\u0002'T\n~b\u0002'";
      m[35] = "W\u0017U:\u001e\u000b\\\u0018Du\u007f\u0005W\u0013@/";
      m[36] = "\u0019k\u001bEu:\nk\u000f+r\u0015G4[\u0014!\u0015zsPUg.\u0005s\u001a\u0014";
      m[37] = "\u0017r)u>q_vvpZ栃佳取受又桃叙佳取佉\u000be~Wzue \"Jg";
      m[38] = "2l_583zh\u00000\\厛栒佖伿桒企厛栒佖桻Kbiv2\u0000p$#t;";
      m[39] = "7+$\u0007Q:$+0iV\u0015mqeU\u0006r\u0003L YF983 \u0013\u0007";
      m[40] = "V'1\u0015y\u001eE'%{~1\tq{J.15?z\u0005k\nJ?0D";
      m[41] = "\u0007\u0013\u001f\u001fUh\u0014\u0013\u000bqRG]I^M\r/3t\u001bABk\b\u000b\u001b\u000b\u0003";
      m[42] = "\u001bgg\u0018\rc\bgsv\nLD1-GTLx\u007f,\b\u001fw\u0007\u007ffI";
      m[43] = "hKX~P\u0004 O\u0007{4桶厒佱厦參栭伲案佱厦\u0000\n^,\u0015\u0007;L\u0014.\u001c";
      m[44] = "%C6H\fQmGiMh叹栅叧佖叵厫叹佁叧栒6\t@vB`K\u0010G&Z";
      m[45] = "*b\u0006>3&9b\u0012P4\tp8Gmgf\u001e\u0005\u0002`$%%z\u0002*e";
      m[46] = "\u0015N$\u001ct3\u0006N0rs\u001cK\u0011gB%\u001cvVo\ff'\tV%M";
      m[47] = "cb\f\u001f)g+fS\u001aM佑伇佘栨厢伐栕桃佘史as='<SZ5w%5";
      m[48] = "\u001eh]\t\u0006TVl\u0002\fb佢古栖伽桮厡叼栾佒伽w\u0003EMi\u000b\n\u001aB\u001dq";
      m[49] = "\u001bj\r}Y~Kt\b3&叀桨栌佯叁句佞伬佈叱\u0002J8\u001e(W?J~\fx";
      m[50] = "\n'}mLy\u0019'i\u0003KVTx?9\u001fVi?6}^m\u0016?|<";
      m[51] = "|\u001f\u0001:Ero\u001f\u0015TB]\"@Co\u0016]\u001f\u0007J*Wf`\u0007\u0000k";
      m[52] = "BQ8GR\u001fQQ,)U0\u0018\u000by\u0015\u0004\\v6<\u0019E\u001cMI<S\u0004";
      m[53] = "\n<h=1;\u0019<|S6\u0014Tc+ca\u0014i$#-#/\u0016$il";
      m[54] = "nyN\u001f]r}yZqZ]0&\u000bK\u000b]\ra\u0005\u000fOfraON";
      m[55] = "H2p\u0002\u007fm\u00006/\u0007\u001b叅伬桌桔桥栂佛伬厖伐|z|\u001b3&\u0001c{K+";
      m[56] = "LCP>\u000f]_CDP\br\u0013\u0015\u001aa^r/[\u001b.\u001dIP[Qo";
      m[57] = "\u001fP\bi0\u0007\u0019]\b3@\u0003(\u000eN`~V(?\u00165!T\u001dCNf:\t";
      m[58] = "6Z\u001b\u001a\u0004\u0012~^D\u001f`桠佒栤句桽伽桠栖叾栿d\u0001\u0003e[M\u0019\u0018\u00045C";
      m[59] = ")\u0001g!@\u001a:\u0001sOG5s[&s\u0018[\u001dfc\u007fW\u0019&\u0019c5\u0016";
      m[60] = "C\u00007\u0010:\u0015P\u0000#~=:\u0019ZvBmRwg3N-\u0016L\u00183\u0004l";
      m[61] = "H^\u001e&\u0015Z\u0000ZA#qXq\u0003D=\u0010\r\u000bY^hA1K^F9MK\u0011D\u0013hq";
      m[62] = "\u000e<[lZ/F8\u0004i>桝佪厘桿发佣厇佪桂厥\u0012W'T)ZxE.\t<";
      m[63] = "\u0003D z\n\u001eSZ%4u桺桰栢栆叆伨桺厪佦栆\u0005DZ\u0002[%d\u001f\u001dXD";
      m[64] = "_{HE>`\u0017\u007f\u0017@Z又伻佁桬司厙佖厥叟桬;;q\fz\u001eF\"v\\b";
      m[65] = "d?\u0013`]L>fCa%n_3\u0011=@\t&nT1L0";
      m[66] = "r\u007f6AW\u0015:{iD3伣桒栁栒佢株伣厈佅佖?_\u0007zc1C\u0002\u0006:i";
      m[67] = "}oh'g>*2b`\u0004mG2*$43G\u0002|%k>u?|cyn";
      m[68] = "SP\"N\u000fF@P6 \bi\r\u000fa\u0010[i0Hi^\u001dROH#\u001f";
      m[69] = "&]F{a<|GF*\\,A\u001e\u0000/l\u007f-p:&&>{\u001aD|<>*";
      m[70] = "U\u00164{23\u001d\u0012k~V厛桵厲及栜伋桁厯厲及\u0005hi\u0011Hk>.#\u0013A";
      m[71] = "\"\r($M7j\tw!)企栂桳栌桃只企但伷取Z\u0014>|\u0015e4\u0019b'Q";
      m[72] = "Jq\u0004\u0001\u001d+\u0010(T\u0000e<q}\u0006\\\u0000n\b CP\fW\u0015<\u0007Z\u000fgH(U^e";
      m[73] = "o\tr4(\"'\r-1L厊伋伳桖厉桕厊伋伳厌J-3<\b$744l\u0010";
      m[74] = ".%\u0002exEf!]`\u001c样叔桛叼变叟佳叔厁栦\u001b{\u001eu=Af-Jf>";
      m[75] = "5\u000b+\u0018v\u0018&\u000b?vq7oQjJ.X\u0001l/Fa\u001b:\u0013/\f ";
      m[76] = "\u001d\u0012TCAYFU\u000e\\{叻栵叨佢佾伦校佱栲栦#J\u0001GK\u0005B\u0011F\u001dT";
      m[77] = "DbuyMSWba\u0017J|\u001e84+\u001b\u0017p\u0005q'ZPKzqm\u001b";
      m[78] = "}avt<,nab\u001a;\u0003#>1+n\u0003\u001ey=d.8ayw%";
      m[79] = "@2\u001caX+\b6Cd<桙厺厖核叜叿伝桠厖叢\u001f\u0002q\u0004lC$D;\u0006e";
      m[80] = "s/3pk?iap&\u000fmD 0t?:D\u0010fs`>v-f5rn";
      m[81] = "Njgc\u0018\u0010\u0006n8f|伦厴収伇栄县厸桮栔厙\u001d\u001d\u0001\u001dk1`\u0004\u0006Ms";
      m[82] = "\n*\tw+\u0002\u0019*\u001d\u0019,-PpH$zG>M\r)<\u0001\u00052\rc}";
      m[83] = "{\u000f#3\u0000\u0000h\u000f7]\u0007/!UbaXFOh'm\u0017\u0003t\u0017''V";
      m[84] = "E\u001dt\u0004[dV\u001d`j\\K\u001fG5W\n\"qzpZLgJ\u0005p\u0010\r";
      m[85] = "\u001dQzw]5UU%r9伃叧叵桞佔佤厝叧栯厄\tX$NP,tA#\u001eH";
      m[86] = "\u0015M\u0010~\u0003w\u0006M\u0004\u0010\u0004XK\u0012T-PXvU[n\u0011c\tU\u0011/";
      m[87] = "\u0016\u0000\u0002T>F^\u0004]QZ叮佲伺佢叩伇佰佲厤叼*d\u001cR^]\u0011\"VPW";
      m[88] = "\nv\u001aE-yQ1@Z\u0017佅司伒厲另叔叛司桖厲%&!P/KD}f\n0";
      m[89] = "#\n(\u000e1mk\u000ew\u000bU叅栃厮佈伭厖佛栃厮佈phd}\u0012e\u001ee8&V";
      m[90] = "\u001duW:\u001d\u0003\u000euCT\u001a,C*\u0012iN,~m\u001c*\u000f\u0017\u0001mVk";
      m[91] = "\u000f;_\u0005E\u007f\u001c;KkBPQd\u001fP\u0010Pl#\u0014\u0015Wk\u0013#^T";
      m[92] = "L\u000b\\\u00159^_\u000bH{>q\u0013]\u0016Joq/\u0013\u0017\u0005+JP\u0013]D";
      m[93] = "Ym\r>XuC#Nh<'nb\u000e:\fqnRX=St\\oX{A$";
      m[94] = "{D\u0018D\u0013|3@GAw佊厁佾格栣桮佊桛叠佸:I&?\u001aG\u0001\u000fl=\u0013";
      m[95] = "\u0000\fY@\\KH\b\u0006E8佽栠伶厧佣佥口叺桲伹>QCZ\u0019XTCJ\u0007\f";
      m[96] = "[Tyg\u001eSHTm\t\u0019|\u0004\u000238J|8L2w\fGGLx6";
      m[97] = "\u000ev4/i`Frk*\r又佪佌及厒佐又栮叒佔Qlq]wb,uv\ro";
      m[98] = "X1tk\u007f\u0003\u000fl~,\u001cPbl6h-\u0005b\\`is\u0003Pa`/aS";
      m[99] = "|qa\u0010\u007f1qq`_\u001eM^\u0002XbIER\u000eHv\u001en*,8L.c*-w";
      m[100] = "[\b\u00031)\u001e\u000eRK:J\u0012a\\\u000fmsAal\\\"{\u0006VVKb;\u001e";
      m[101] = "`+rHR&(/-M6厎桀厏厌叵叵伐伄休厌6\b|$u-\rN6&|";
      m[102] = "\u001c\u0011\u0016qR\u0003T\u0015It6桱佸厵叨栖叵桱佸伫佶\u000f\t\u0016G\u0016Gk\rUZ\u0014";
      m[103] = "w\tKT\r\u0015 TA\u0013nFMT\tW_\u0010Md_V\u0001\u0015\u007fY_\u0010\u0013E";
      m[104] = "\u0013i(=\u0014j[mw8p栘叩体佈伞桩作佷体佈CN0W7wx\bzU>";
      m[105] = "0eAy@\u001f#eU\u0017G0n:\u0000)\u00150S}\niR\u000b,}@(";
      m[106] = "\f7WIm^D3\bL\t栬佨桉伷叴佔叶栬厓厩77\u0004Hi\b\fqNJ`";
      m[107] = "'d\u001a\u0016\u0018A4d\u000ex\u001fnx2PIMnD|Q\u0006\nU;|\u001bG";
      m[108] = "q\u0004JqS\u001a9\u0000\u0015t7伬伕伾伪佒栮厲压厠伪\u000f\n\u0013/\u001c\u0007a\u0007OtX";
      m[109] = "!B.I'@2B:' o{\u0018o\u001bq\t\u0015%*\u00170C.Z*]q";
      m[110] = "*J\fZkKbNS_\u000f口低栴佬叧栖口叐栴佬$nZyKZYw])S";
      m[111] = "ad7p\b:)`hul案厛栚佗栗伱伌伅佞佗\u000eQ3?|z`\\od8";
      m[112] = "iT\u0000>9%!P_;]桗厓株叾厃厞厍伍佮叾@c\u007f-\n_{%5/\u0003";
      m[113] = "\u00048mL3\u0001L<2IW厩叾厜桉叱桎伷叾伂伍2;\u0013\f$jNf\u0012L.";
      m[114] = "B\bd\u0007>\u0003\n\f;\u0002Z厫厸伲桀伤桃桱伦伲厚ydY\u0006V;B\"\u0013\u0004_";
      m[115] = "I\u0001F\u000b\u0015\u0010Z\u0001Re\u0012?\u0016W\fTE?*\u0019\r\u001b\u0007\u0004U\u0019GZ";
      m[116] = "9{,\u001f\u000ef*{8q\tIg$oLVIZcg\u000f\u001cr%c-N";
      m[117] = "\\7*}e\u001b\u00143ux\u0001伭伸桉佊栚作伭伸桉栎\u00031\n\u0019=*}k\u0010\u0019l";
      m[118] = "MtFw\u001f!^tR\u0019\u0018\u000e\u0013+\u0007#F\u000e.l\rg\r5QlG&";
      m[119] = "\u000b+C\u0005&\u001d\u0018+Wk!2Qq\u0002V~Z?LG[1\u001e\u00043G\u0011p";
      m[120] = "\nP\u0007M3I\u000b\u000eVFOzo\u0000\fO X\u0001EPR=9";
      m[121] = "\u0015}F\u001d(\u0013B LZK@/ \u0004\u001e{\u001f/\u0010R\u001f$\u0013\u001d-RY6C";
      m[122] = "8\u001c&J\u0014&p\u0018yOp伐栘伦变佩厳伐参厸栂4N||By\u000f\b6~K";
      m[123] = "1\u0011c$A\u0002<\u0011bk k\u0003aKB ]gL:x\u0010PgMu";
      m[124] = "Y\u000bd47;\u000eVnsThcV&7e<cfp6;;Q[pp)k";
      m[125] = "\u0018\u0013b(Kv\u000b\u0013vFLYFL!x\u0013Y{\u000b)8Yb\u0004\u000bcy";
      m[126] = ":\u001e\u0002u0A)\u001e\u0016\u001b7ndAF#dnY\u0006Ie\"U&\u0006\u0003$";
      m[127] = "kC=8HZ#Gb=,佬伏栽佝伛佱栨伏叧佝F\u0011S5[p(\u001c\u000fn\u001f";
      m[128] = "\u0007Y$-j\u0006\u001dC:x\u0001伤厧佧伃伝参伤伹栣厝@b\u0002\u001c\\01z\u0001_F";
      m[129] = "R\u001e^eM\tS\u0005Bi=3p>{F=\u000eQ\u0006I{X\u000fJ\u001aE";
      m[130] = "\u0019ELU\u001f@\nEX;\u0018oC\u001f\r\u0007I\u0002-\"H\u000b\bC\u0016]HAI";
      m[131] = "~\u001fz\u001fP\u0001m\u001fnqW.$E;M\u0007HJx~AG\u0002q\u0007~\u000b\u0006";
      m[132] = "k[~Up(#_!P\u0014厀厑佡桚栲栍厀伏佡伞+u98Z(Vl>hB";
      m[133] = "\u0002pJ\"bIJt\u0015'\u0006栻栢栎桮原叅叡司叔伪\\7[Fv\u0019bxZYi";
      m[134] = "*}\u00038j%q:Y'P伙但厇厫伅桉桝栂伙桱Xa}p$R9::*;";
      m[135] = "m)\u000ey{d:t\u0004>\u00187WtLz)`WD\u001a{wdey\u001a=e4";
      m[136] = "tWA\thO<S\u001e\f\f叧桔右县伪叏佹伐佭县w1F*O\f\u0019<\u001aq\u000b";
      m[137] = "+I\tx#N8I\u001d\u0016$au\u0016H+uaHQBh1Z7Q\b)";
      m[138] = ";fc\u000fi/!( Y\r}\fi`\u000b2\"\fY6\fb.>d6Jp~";
      m[139] = "Y\u0012=M&.\u0011\u0016bHB桜伽桬佝台伟优厣桬佝3('\rD}Z+>\u0004\t";
      m[140] = "\b\u0004Nn'\\\u001b\u0004Z\u0000 sV[\r0\u007fsk\u001c\u0005~5H\u0014\u001cO?";
      m[141] = "t[;@\u0013\u0015<_dEw伣伐栥叅佣厴伣桔叿栟>K\u0002'Vy\u000f\u0007\u0019*\\";
      m[142] = "fk\u0013N~G=,IQD句伊桋伥样厇栿伊厑伥.u\u001f<2BO.Xf-";
      m[143] = "$BiRGm/\u0012gQ9栍桛併栒栨栠佉厁叫又1_~ KuHT..H";
      m[144] = "b\u001e8Vdyq\u001e,8cV<Az\u00076V\u0001\u0006sFvm~\u00069\u0007";
      m[145] = "\u0019nr\u001e|oQj-\u001b\u0018叇口及厌伽佅叇根及桖`%<C70\u001c$tOj";
      m[146] = "\u0001W:{jnQI?5\u0015栊伶併栜栝取栊厨叫佘\u0004j#\u0015Si{jiT";
      m[147] = "E`(9 _V`<W'p\u001f:ijr\u0018q\u0007,g7\\Jx,-v";
      m[148] = "HRe\u000b.h\u0013\u0015?\u0014\u0014及厺厨栗桲佉佔伤桲反k%0\u0012\u000b4\n~wH\u0014";
      m[149] = "#5Bl&ak1\u001diB叉叙厑伢栋桛佗栃桋桦\u0012.s+)Ensrk#";
      m[150] = "fOv\u001ac7.K)\u001f\u0007原伂叫桒伹佚桅伂栱伖d:>8W;\n7bc\u0013";
      m[151] = "\u000ft\u0013Y\u001f7\u001ct\u00077\u0018\u0018Q+W\rL\u0018llXI\r#\u0013l\u0012\b";
      m[152] = "%j?q] 6j+\u001fZ\u000f{5\u007f$\r\u000fFrtaO49r> ";
      m[153] = "V\u0014 8\u0005dE\u00144V\u0002K\bKbkRK5\fk(\u0017pJ\f!i";
      m[154] = "Mh9(\u0013)\u0005lf-w桛伩佒叇伋桮伟桭双栝VIs\t6fm\u000f9\u000b?";
   }

   @EventTarget
   public void m(TickEvent event) {
      long a = 树何树何何友树友树何.a ^ 65290944942115L;
      long ax = a ^ 32541050091615L;
      long axx = a ^ 35149231676802L;
      long axxx = a ^ 52675780129504L;
      long var10001 = a ^ 127532319202406L;
      int axxxx = (int)((a ^ 127532319202406L) >>> 48);
      int axxxxx = (int)((a ^ 127532319202406L) << 16 >>> 48);
      int axxxxxx = (int)(var10001 << 32 >>> 32);
      d<"C">(-4510561279759326047L, a);
      if (!this.w(new Object[]{ax})) {
         if (d<"b">(this, -4511214045588834191L, a).getValue()) {
            this.c();
         }

         if (d<"b">(this, -4508471835102840348L, a).Y(d<"b">(this, -4515702371601312731L, a).getValue().longValue(), axx)) {
            BlockPos currentPlayerPos = mc.player.blockPosition();
            boolean hasMovedSignificantly = true;
            if (d<"b">(this, -4509657062741499941L, a) != null && currentPlayerPos.distSqr(d<"b">(this, -4509657062741499941L, a)) < 4.0) {
               hasMovedSignificantly = false;
            }

            if (hasMovedSignificantly || d<"b">(this, -4509657062741499941L, a) == null) {
               d<"n">(this, currentPlayerPos, -4509657062741499941L, a);
               if (!d<"b">(this, -4504072207175044003L, a)) {
                  d<"n">(this, true, -4504072207175044003L, a);
                  树何树树何树何何树何.N((char)axxxx, () -> {
                     long axxxxxxx = 树何树何何友树友树何.a ^ 6629476791042L;

                     try {
                        this.D(currentPlayerPos, d<"b">(this, -6740883064025481899L, axxxxxxx).getValue().intValue());
                     } finally {
                        d<"n">(this, false, -6746551298389158020L, axxxxxxx);
                     }
                  }, (char)axxxxx, axxxxxx);
               }
            }

            d<"b">(this, -4508471835102840348L, a).U(axxx);
         }
      }
   }

   private boolean m(BlockPos pos) {
      long a = 树何树何何友树友树何.a ^ 69837590127878L;
      long ax = a ^ 54059982771749L;
      Direction[] var7 = Direction.values();
      d<"C">(3765643208760267140L, a);
      int var8 = var7.length;
      int var9 = 0;
      if (0 < var8) {
         Direction dir = var7[0];
         BlockPos adjacent = pos.relative(dir);
         Block block = 树友友何树友树树树何.o(ax, adjacent);
         if (block == d<"Ø">(3772148132900484698L, a)
            || block == d<"Ø">(3771900269721001707L, a)
            || block == d<"Ø">(3780439722358161803L, a)
            || block == d<"Ø">(3765254543842241373L, a)
            || block == d<"Ø">(3769478027452423720L, a)
            || block == d<"Ø">(3766922166031172270L, a)) {
            return true;
         }

         var9++;
      }

      return false;
   }

   private double p(BlockPos orePos) {
      long a = 树何树何何友树友树何.a ^ 8903556691563L;
      long ax = a ^ 7385255298376L;
      d<"C">(2823606407366017769L, a);
      int naturalBlocks = 0;
      Direction[] var10 = Direction.values();
      int var11 = var10.length;
      int var12 = 0;
      if (0 < var11) {
         Direction dir = var10[0];
         Block adjacentBlock = 树友友何树友树树树何.o(ax, orePos.relative(dir));
         if (adjacentBlock == d<"Ø">(2819337044751532696L, a)
            || adjacentBlock == d<"Ø">(2825000655414535479L, a)
            || adjacentBlock == d<"Ø">(2824812250485652136L, a)
            || adjacentBlock == d<"Ø">(2820007396284195942L, a)
            || adjacentBlock == d<"Ø">(2822059279855530923L, a)
            || adjacentBlock == d<"Ø">(2822627071384113603L, a)) {
            naturalBlocks++;
         }

         var12++;
      }

      return 0.0 + naturalBlocks / 6.0 * 2.0;
   }

   private Color p(Block block) {
      long a = 树何树何何友树友树何.a ^ 8558072883177L;
      d<"C">(-5283434018298129557L, a);
      if (block == d<"Ø">(-5287767365063707046L, a) || block == d<"Ø">(-5283174942962230808L, a)) {
         return d<"b">(this, -5281716461116621539L, a).getValue();
      } else if (block == d<"Ø">(-5285118507656800589L, a) || block == d<"Ø">(-5285422661839846552L, a)) {
         return d<"b">(this, -5284587532097261136L, a).getValue();
      } else if (block == d<"Ø">(-5289170973629304272L, a) || block == d<"Ø">(-5282657974590597697L, a)) {
         return d<"b">(this, -5282901950430537242L, a).getValue();
      } else if (block == d<"Ø">(-5280744796184052787L, a) || block == d<"Ø">(-5281327441160777509L, a)) {
         return d<"b">(this, -5282459320256502622L, a).getValue();
      } else if (block == d<"Ø">(-5285810919641090536L, a) || block == d<"Ø">(-5282100516501651551L, a) || block == d<"Ø">(-5280569068135237378L, a)) {
         return d<"b">(this, -5283539697457031117L, a).getValue();
      } else if (block == d<"Ø">(-5284502716630902341L, a) || block == d<"Ø">(-5284971083079641433L, a)) {
         return d<"b">(this, -5284862435431987403L, a).getValue();
      } else if (block == d<"Ø">(-5287164110857128044L, a) || block == d<"Ø">(-5287877589013594119L, a)) {
         return d<"b">(this, -5288312365226401860L, a).getValue();
      } else if (block == d<"Ø">(-5284352272029765288L, a) || block == d<"Ø">(-5287816898503664987L, a)) {
         return d<"b">(this, -5285739005175438056L, a).getValue();
      } else if (block == d<"Ø">(-5283799487710742311L, a)) {
         return d<"b">(this, -5285355453467939483L, a).getValue();
      } else if (block == d<"Ø">(-5283964440808857575L, a)) {
         return d<"b">(this, -5282437854261621120L, a).getValue();
      } else {
         return block == d<"Ø">(-5287436626484115614L, a) ? d<"b">(this, -5281029417117121147L, a).getValue() : d<"Ø">(-5287954374962472012L, a);
      }
   }

   private Set<BlockPos> p(BlockPos startNodePos, Set<BlockPos> visitedGlobal, int maxRangeFromPlayer, BlockPos playerPos) {
      long a = 树何树何何友树友树何.a ^ 59434062959566L;
      HashSet currentCaveBlocks = new HashSet();
      d<"C">(-9040333010398795956L, a);
      Queue<BlockPos> queue = new LinkedList<>();
      int maxFillSize = d<"b">(this, -9042712281307953382L, a).getValue().intValue() * 10;
      queue.add(startNodePos);
      currentCaveBlocks.add(startNodePos);
      if (!queue.isEmpty() && currentCaveBlocks.size() < maxFillSize) {
         BlockPos currentPos = queue.poll();
         int[][] var12 = d<"Ø">(-9025661473317693635L, a);
         int var13 = var12.length;
         int var14 = 0;
         label24:
         if (0 < var13) {
            int[] dir = var12[0];
            BlockPos nextPos = new BlockPos(currentPos.getX() + dir[0], currentPos.getY() + dir[1], currentPos.getZ() + dir[2]);
            if (nextPos.distManhattan(playerPos) > maxRangeFromPlayer) {
            }

            if (this.i(nextPos) && visitedGlobal.add(nextPos)) {
               if (currentCaveBlocks.size() >= maxFillSize) {
                  break label24;
               }

               currentCaveBlocks.add(nextPos);
               queue.add(nextPos);
            }

            var14++;
         }

         if (currentCaveBlocks.size() >= maxFillSize) {
         }
      }

      return currentCaveBlocks;
   }

   private double k(Set<BlockPos> cave) {
      long a = 树何树何何友树友树何.a ^ 104019249453019L;
      d<"C">(-8746235037769456807L, a);
      if (cave.size() < 3) {
         return 1.0;
      } else {
         BlockPos[] extremePoints = this.N(cave);
         BlockPos start = extremePoints[0];
         BlockPos end = extremePoints[1];
         double maxDist = start.distManhattan(end);
         double totalDeviation = 0.0;
         Iterator avgDeviation = cave.iterator();
         if (avgDeviation.hasNext()) {
            BlockPos pos = (BlockPos)avgDeviation.next();
            totalDeviation = 0.0 + this.D(pos, start, end);
         }

         double avgDeviationx = totalDeviation / cave.size();
         return Math.max(0.0, Math.min(1.0, 1.0 - avgDeviationx / maxDist));
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private String t(Block block) {
      long a = 树何树何何友树友树何.a ^ 118984531191441L;
      d<"C">(8634829023927849491L, a);
      if (block == d<"Ø">(8639725320211707682L, a) || block == d<"Ø">(8635106510368544912L, a)) {
         return b<"t">(22700, 1322812484354942752L ^ a);
      } else if (block == d<"Ø">(8637648207135233995L, a) || block == d<"Ø">(8637345430368109072L, a)) {
         return b<"t">(11281, 8426295588161049475L ^ a);
      } else if (block == d<"Ø">(8638322975517930312L, a) || block == d<"Ø">(8631238228289475783L, a)) {
         return b<"t">(4633, 5330784417086926224L ^ a);
      } else if (block == d<"Ø">(8633239310774516405L, a) || block == d<"Ø">(8632449765353001379L, a)) {
         return "铁";
      } else if (block == d<"Ø">(8637179536976033632L, a) || block == d<"Ø">(8631815467923750617L, a) || block == d<"Ø">(8633345057701886342L, a)) {
         return "金";
      } else if (block == d<"Ø">(8633901006980323523L, a) || block == d<"Ø">(8633516151864842207L, a)) {
         return "铜";
      } else if (block == d<"Ø">(8635744366855026412L, a) || block == d<"Ø">(8639527680800964225L, a)) {
         return b<"t">(28656, 2942800041471086653L ^ a);
      } else if (block == d<"Ø">(8634067221895770144L, a) || block == d<"Ø">(8639466990965251037L, a)) {
         return "煤";
      } else if (block == d<"Ø">(8634605155222813089L, a)) {
         return b<"t">(15852, 789413900972573249L ^ a);
      } else if (block == d<"Ø">(8634523815467622753L, a)) {
         return b<"t">(7577, 5921293159732372021L ^ a);
      } else {
         return block == d<"Ø">(8639922347611358746L, a) ? b<"t">(4824, 6641668240336481559L ^ a) : b<"t">(23635, 6962070851893240729L ^ a);
      }
   }

   protected void t() {
      long a = 树何树何何友树友树何.a ^ 84478253647681L;
      long ax = a ^ 97152478078338L;
      d<"b">(this, -7622883931264263420L, a).clear();
      d<"b">(this, -7630540364558670360L, a).clear();
      d<"b">(this, -7637398600205416030L, a).clear();
      d<"b">(this, -7622417309267624628L, a).clear();
      d<"n">(this, null, -7635838324939274055L, a);
      d<"n">(this, 0L, -7623412207317090211L, a);
      d<"b">(this, -7634507966614393210L, a).U(ax);
   }

   private double g(Set<BlockPos> cave) {
      long a = 树何树何何友树友树何.a ^ 100312378136940L;
      d<"C">(587759555223399918L, a);
      if (cave.size() < 10) {
         return 0.0;
      } else {
         int junctions = 0;
         Iterator var6 = cave.iterator();
         if (var6.hasNext()) {
            BlockPos pos = (BlockPos)var6.next();
            int adjacentAir = 0;
            Direction[] var9 = Direction.values();
            int var10 = var9.length;
            int var11 = 0;
            if (0 < var10) {
               Direction dir = var9[0];
               if (cave.contains(pos.relative(dir))) {
                  adjacentAir++;
               }

               var11++;
            }

            if (adjacentAir >= 3) {
               junctions++;
            }
         }

         return (double)junctions / cave.size();
      }
   }

   private boolean v(Block block) {
      long a = 树何树何何友树友树何.a ^ 116240144019402L;
      d<"C">(9119251240670911304L, a);
      return block == d<"Ø">(9115823479808163320L, a)
         || block == d<"Ø">(9120519882044956288L, a)
         || block == d<"Ø">(9131052313514786994L, a)
         || block == d<"Ø">(9120639364709434478L, a);
   }

   private boolean j(Block block) {
      long a = 树何树何何友树友树何.a ^ 82685076573659L;
      d<"C">(6674110604474251609L, a);
      String var5 = d<"b">(this, 6677152748612729100L, a).getValue();
      byte var6 = -1;
      switch (var5.hashCode()) {
         case 2466289:
            if (!var5.equals(b<"t">(18542, 4819348079469370497L ^ a))) {
               break;
            }

            var6 = 0;
         case 1234985285:
            if (!var5.equals(b<"t">(20682, 1250388730467255317L ^ a))) {
               break;
            }

            var6 = 1;
         case 65921:
            if (var5.equals(b<"t">(5352, 4209611507240878090L ^ a))) {
               var6 = 2;
            }
      }
      return switch (var6) {
         case 0 -> this.q(block);
         case 1 -> this.z(block);
         case 2 -> this.q(block) || this.z(block);
         default -> this.q(block);
      };
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void q(PoseStack poseStack, AABB box, Color color, Vec3 camPos) {
      long a = 树何树何何友树友树何.a ^ 75022345902830L;
      float red = color.getRed() / 255.0F;
      float green = color.getGreen() / 255.0F;
      float blue = color.getBlue() / 255.0F;
      float alpha = color.getAlpha() / 255.0F;
      double minX = d<"b">(box, 5452361408436208934L, a) - d<"b">(camPos, 5447367253083195157L, a);
      double minY = d<"b">(box, 5450548394268867327L, a) - d<"b">(camPos, 5453034610424406491L, a);
      double minZ = d<"b">(box, 5450351252000436501L, a) - d<"b">(camPos, 5453407298573534360L, a);
      double maxX = d<"b">(box, 5448151534723989868L, a) - d<"b">(camPos, 5447367253083195157L, a);
      double maxY = d<"b">(box, 5450846147220457741L, a) - d<"b">(camPos, 5453034610424406491L, a);
      double maxZ = d<"b">(box, 5450176122114773865L, a) - d<"b">(camPos, 5453407298573534360L, a);
      Matrix4f matrix = poseStack.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(d<"Ø">(5450682704089655788L, a), d<"Ø">(5450318483219430554L, a));
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      BufferUploader.drawWithShader(buffer.end());
   }

   private boolean q(Block block) {
      long a = 树何树何何友树友树何.a ^ 125353987503591L;
      d<"C">(2639968145219092837L, a);
      return d<"b">(this, 2646033804337516454L, a).getValue() && (block == d<"Ø">(2634718285684859988L, a) || block == d<"Ø">(2639128811357883366L, a))
         || d<"b">(this, 2641982639589804885L, a).getValue() && (block == d<"Ø">(2641653044752123069L, a) || block == d<"Ø">(2641394016515330406L, a))
         || d<"b">(this, 2641859252913398648L, a).getValue() && (block == d<"Ø">(2636684750118789182L, a) || block == d<"Ø">(2647640789678884785L, a))
         || d<"b">(this, 2643575737183605582L, a).getValue() && (block == d<"Ø">(2646273097362401731L, a) || block == d<"Ø">(2646570006859956949L, a))
         || d<"b">(this, 2640495808218438444L, a).getValue()
            && (block == d<"Ø">(2642332273355580438L, a) || block == d<"Ø">(2647061437570313647L, a) || block == d<"Ø">(2646378955957054192L, a))
         || d<"b">(this, 2646346805662046485L, a).getValue() && (block == d<"Ø">(2641318359347579829L, a) || block == d<"Ø">(2640929106196300969L, a))
         || d<"b">(this, 2640980349596655981L, a).getValue() && (block == d<"Ø">(2643135287960216986L, a) || block == d<"Ø">(2635690535194062327L, a))
         || d<"b">(this, 2643417254430953706L, a).getValue() && (block == d<"Ø">(2640306000843940694L, a) || block == d<"Ø">(2635612115739609259L, a));
   }

   private double U(BlockPos orePos, Block oreBlock) {
      long a = 树何树何何友树友树何.a ^ 136952214531457L;
      long ax = a ^ 125482482310818L;
      int sameOreBlocks = 0;
      d<"C">(8990596109099194627L, a);
      int x = -2;
      int y = -2;
      int z = -2;
      BlockPos checkPos = orePos.offset(-2, -2, -2);
      Block checkBlock = 树友友何树友树树树何.o(ax, checkPos);
      if (checkBlock == oreBlock) {
         sameOreBlocks++;
      }

      z++;
      y++;
      x++;
      if (sameOreBlocks >= 2 && sameOreBlocks <= 8) {
         return 2.0;
      } else if (sameOreBlocks == 1) {
         return 1.0;
      } else {
         return sameOreBlocks > 8 ? 0.5 : 0.0;
      }
   }

   private boolean z(Block block) {
      long a = 树何树何何友树友树何.a ^ 85775477910946L;
      d<"C">(8999934830491785504L, a);
      return block == d<"Ø">(8994714351669443374L, a)
         || block == d<"Ø">(8993772161763058596L, a)
         || block == d<"Ø">(9006621057792765731L, a)
         || block == d<"Ø">(8999509861150499833L, a)
         || block == d<"Ø">(9005125303931312482L, a);
   }

   private boolean w(树何树何何友树友树何.树树友友友何友何何树 info) {
      long a = 树何树何何友树友树何.a ^ 28889672691281L;
      d<"C">(-66035233251042605L, a);
      switch (d<"Ø">(-61618513808415201L, a)[d<"b">(info, -69002521729930723L, a).ordinal()]) {
         case 1:
            return this.j(d<"b">(info, -62599452687296939L, a));
         case 2:
         case 3:
            return d<"b">(this, -61999781146040065L, a).getValue();
         case 4:
            return d<"b">(this, -68534938724907786L, a).getValue();
         case 5:
            return d<"b">(this, -64255642110085657L, a).getValue();
         default:
            return false;
      }
   }

   private void Y(BlockPos playerPos, int scanRange) {
      long a = 树何树何何友树友树何.a ^ 34047307566071L;
      long ax = a ^ 17977785055444L;
      d<"C">(1923989213735862133L, a);
      int px = playerPos.getX();
      int py = playerPos.getY();
      int pz = playerPos.getZ();
      int x = px - scanRange;
      if (x <= px + scanRange) {
         int y = Math.max(mc.level.getMinBuildHeight(), py - scanRange);
         if (y <= Math.min(mc.level.getMaxBuildHeight(), py + scanRange)) {
            int z = pz - scanRange;
            if (z <= pz + scanRange) {
               BlockPos pos = new BlockPos(x, y, z);
               Block block = 树友友何树友树树树何.o(ax, pos);
               if (this.j(block)) {
                  树何树何何友树友树何.友友树树何何何友何何 type = this.i(block);
                  d<"b">(this, 1909598060989994930L, a).put(pos, new 树何树何何友树友树何.树树友友友何友何何树(block, type, 10.0));
               }

               z++;
            }

            y++;
         }

         x++;
      }
   }

   private double X(BlockPos orePos) {
      long a = 树何树何何友树友树何.a ^ 73808163706046L;
      long ax = a ^ 85273550563229L;
      d<"C">(5042408877583622204L, a);
      int naturalFeatures = 0;
      int suspiciousFeatures = 0;
      int x = -2;
      int y = -2;
      int z = -2;
      BlockPos checkPos = orePos.offset(-2, -2, -2);
      Block block = 树友友何树友树树树何.o(ax, checkPos);
      if (block == d<"Ø">(5036243280810512642L, a)
         || block == d<"Ø">(5041373019515339781L, a)
         || block == d<"Ø">(5039696395652695248L, a)
         || block == d<"Ø">(5042323046353320083L, a)) {
         naturalFeatures++;
      }

      if (block == d<"Ø">(5044018011861397860L, a) || block == d<"Ø">(5035978533722312715L, a)) {
         suspiciousFeatures++;
      }

      z++;
      y++;
      x++;
      double score = 0.0 + Math.min(naturalFeatures * 0.1, 1.0) - suspiciousFeatures * 0.5;
      return Math.max(-1.0, score);
   }

   private double L(Set<BlockPos> cave) {
      long a = 树何树何何友树友树何.a ^ 67103458932173L;
      d<"C">(7244394111956009295L, a);
      if (cave.size() < 3) {
         return 0.0;
      } else {
         double avgY = cave.stream().mapToDouble(Vec3i::getY).average().orElse(0.0);
         double variance = cave.stream().mapToDouble(pos -> Math.pow(pos.getY() - avgY, 2.0)).sum() / cave.size();
         return Math.sqrt(variance);
      }
   }

   private BlockPos[] N(Set<BlockPos> cave) {
      long a = 树何树何何友树友树何.a ^ 81455333325105L;
      d<"C">(7526980751056817587L, a);
      if (cave != null && cave.size() >= 2) {
         List<BlockPos> positions = new ArrayList<>(cave);
         BlockPos p1 = positions.get(0);
         BlockPos p2 = p1;
         Iterator p3 = positions.iterator();
         if (p3.hasNext()) {
            BlockPos currentPos = (BlockPos)p3.next();
            int dist = currentPos.distManhattan(p1);
            if (dist > -1) {
               p2 = currentPos;
            }
         }

         BlockPos p3x = p2;
         Iterator var17 = positions.iterator();
         if (var17.hasNext()) {
            BlockPos currentPos = (BlockPos)var17.next();
            int dist = currentPos.distManhattan(p2);
            if (dist > -1) {
               p3x = currentPos;
            }
         }

         return new BlockPos[]{p2, p3x};
      } else {
         List<BlockPos> tempList = new ArrayList<>(Objects.requireNonNullElseGet(cave, HashSet::new));
         if (tempList.isEmpty()) {
            return new BlockPos[]{d<"Ø">(7526711197772695345L, a), d<"Ø">(7526711197772695345L, a)};
         } else {
            BlockPos p = tempList.get(0);
            return new BlockPos[]{p, p};
         }
      }
   }

   private double P(BlockPos orePos, Block oreBlock) {
      long a = 树何树何何友树友树何.a ^ 33750772521129L;
      d<"C">(-3896350649183736789L, a);
      int y = orePos.getY();
      if (oreBlock == d<"Ø">(-3900668260331091686L, a) || oreBlock == d<"Ø">(-3896039069014579544L, a)) {
         if (y >= -64 && y <= 16) {
            return 2.0;
         }

         if (y <= -32) {
            return 1.5;
         }
      }

      if ((oreBlock == d<"Ø">(-3893608252153363315L, a) || oreBlock == d<"Ø">(-3894226273765118053L, a)) && y >= -64 && y <= 320) {
         return 2.0;
      } else {
         return (oreBlock == d<"Ø">(-3897253180114121192L, a) || oreBlock == d<"Ø">(-3900680290115525147L, a)) && y >= 0 && y <= 320 ? 2.0 : 0.5;
      }
   }

   private boolean W(Block block1, Block block2) {
      long a = 树何树何何友树友树何.a ^ 106185691218288L;
      d<"C">(-8055779082649782798L, a);
      if (block1 != null && block2 != null) {
         if (block1 != d<"Ø">(-8068351825554026301L, a) && block1 != d<"Ø">(-8054965858151235727L, a)
            || block2 != d<"Ø">(-8068351825554026301L, a) && block2 != d<"Ø">(-8054965858151235727L, a)) {
            if (block1 != d<"Ø">(-8070326983016868695L, a) && block1 != d<"Ø">(-8058806891777117402L, a)
               || block2 != d<"Ø">(-8070326983016868695L, a) && block2 != d<"Ø">(-8058806891777117402L, a)) {
               if (block1 != d<"Ø">(-8057395145970557612L, a) && block1 != d<"Ø">(-8057621467693189566L, a)
                  || block2 != d<"Ø">(-8057395145970557612L, a) && block2 != d<"Ø">(-8057621467693189566L, a)) {
                  if (block1 != d<"Ø">(-8056004319937292351L, a) && block1 != d<"Ø">(-8069181901385843652L, a)
                     || block2 != d<"Ø">(-8056004319937292351L, a) && block2 != d<"Ø">(-8069181901385843652L, a)) {
                     if (block1 != d<"Ø">(-8053454683011133311L, a) && block1 != d<"Ø">(-8058256075435943624L, a) && block1 != d<"Ø">(-8057290259112583577L, a)
                        || block2 != d<"Ø">(-8053454683011133311L, a)
                           && block2 != d<"Ø">(-8058256075435943624L, a)
                           && block2 != d<"Ø">(-8057290259112583577L, a)) {
                        if (block1 != d<"Ø">(-8052968418434535382L, a) && block1 != d<"Ø">(-8052700787647732239L, a)
                           || block2 != d<"Ø">(-8052968418434535382L, a) && block2 != d<"Ø">(-8052700787647732239L, a)) {
                           if (block1 != d<"Ø">(-8054301888274132723L, a) && block1 != d<"Ø">(-8069104718210967200L, a)
                              || block2 != d<"Ø">(-8054301888274132723L, a) && block2 != d<"Ø">(-8069104718210967200L, a)) {
                              return block1 != d<"Ø">(-8056715859199787230L, a) && block1 != d<"Ø">(-8056546559907549122L, a)
                                    || block2 != d<"Ø">(-8056715859199787230L, a) && block2 != d<"Ø">(-8056546559907549122L, a)
                                 ? block1 == block2
                                 : true;
                           } else {
                              return true;
                           }
                        } else {
                           return true;
                        }
                     } else {
                        return true;
                     }
                  } else {
                     return true;
                  }
               } else {
                  return true;
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean H(BlockPos initialOrePos, Block oreType, int minVeinSize) {
      long a = 树何树何何友树友树何.a ^ 23710663796264L;
      long ax = a ^ 56528876785236L;
      long axx = a ^ 29953494144267L;
      d<"C">(3993684174202835626L, a);
      if (minVeinSize <= 1) {
         return true;
      } else if (!this.w(new Object[]{ax}) && mc.level.isLoaded(initialOrePos)) {
         Set<BlockPos> visited = new HashSet<>();
         Queue<BlockPos> queue = new LinkedList<>();
         queue.add(initialOrePos);
         visited.add(initialOrePos);
         int veinSize = 1;
         int checks = 0;
         if (!queue.isEmpty()) {
            BlockPos pos = queue.poll();
            checks++;
            Direction[] var18 = Direction.values();
            int var19 = var18.length;
            int var20 = 0;
            if (0 < var19) {
               Direction dir = var18[0];
               BlockPos neighbor = pos.relative(dir);
               if (!visited.contains(neighbor) && mc.level.isLoaded(neighbor)) {
                  visited.add(neighbor);
                  Block block = 树友友何树友树树树何.o(axx, neighbor);
                  if (this.W(block, oreType)) {
                     veinSize++;
                     queue.add(neighbor);
                     if (veinSize >= minVeinSize) {
                        return true;
                     }
                  }
               }

               var20++;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   @EventTarget
   public void T(WorldEvent event) {
      long a = 树何树何何友树友树何.a ^ 89336301388369L;
      long ax = a ^ 133330994002637L;
      d<"C">(-3236629868287985965L, a);
      if (d<"b">(this, -3235892276330030813L, a) != mc.level) {
         d<"n">(this, mc.level, -3235892276330030813L, a);
         d<"b">(this, -3231879298059362796L, a).clear();
         d<"b">(this, -3239563254082756360L, a).clear();
         d<"b">(this, -3237349376087126862L, a).clear();
         d<"b">(this, -3231431402169943972L, a).clear();
         ClientUtils.e(new Object[]{b<"t">(5569, 1573287474799693532L ^ a), ax});
      }
   }

   private void K(PoseStack poseStack, AABB box, Color color, Vec3 camPos) {
      long a = 树何树何何友树友树何.a ^ 12405134588245L;
      float red = color.getRed() / 255.0F;
      float green = color.getGreen() / 255.0F;
      float blue = color.getBlue() / 255.0F;
      double minX = d<"b">(box, -6336034007217117539L, a) - d<"b">(camPos, -6331039818575092562L, a);
      double minY = d<"b">(box, -6332215483703731900L, a) - d<"b">(camPos, -6334773133221494176L, a);
      double minZ = d<"b">(box, -6334094185029463378L, a) - d<"b">(camPos, -6335110603172255965L, a);
      double maxX = d<"b">(box, -6331788915709713705L, a) - d<"b">(camPos, -6331039818575092562L, a);
      double maxY = d<"b">(box, -6332618789908829514L, a) - d<"b">(camPos, -6334773133221494176L, a);
      double maxZ = d<"b">(box, -6333849718399733550L, a) - d<"b">(camPos, -6335110603172255965L, a);
      Matrix4f matrix = poseStack.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(d<"Ø">(-6333809658176075337L, a), d<"Ø">(-6334272488793514207L, a));
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      BufferUploader.drawWithShader(buffer.end());
   }

   private static String HE_WEI_LIN() {
      return "何树友，和树做朋友";
   }

   private static enum 友友树树何何何友何何 implements  {
      何何友友何树树树何树,
      友友友树树何何何树友,
      何友何友友友友友树友,
      友何树何树友树何友何,
      友树友何何何树何树树;

      private static final long a;
      private static final Object[] b = new Object[9];
      private static final String[] c = new String[9];
      private static int _何炜霖230622200409390090 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-6367369600952647110L, 3362825798962785342L, MethodHandles.lookup().lookupClass()).a(1241920570714L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 44502741405025L;
         a();
         Cipher var1;
         Cipher var13 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[5];
         int var6 = 0;
         String var5 = "\u008dR\u0014oÈ\bÔ\u0082\u008a\u0089ÎW\u008aÖÎe\u00180Tå\r;OT\tå÷\u0013º%\u00adv?¥C.Våã\u0019a\b\u0087ï\u0082A`Ú\u0094:";
         byte var7 = 50;
         char var4 = 16;
         int var12 = -1;

         label28:
         while (true) {
            String var14 = var5.substring(++var12, var12 + var4);
            byte var10001 = -1;

            while (true) {
               String var20 = a(var1.doFinal(var14.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var20;
                     if ((var12 += var4) >= var7) {
                        何何友友何树树树何树 = new 树何树何何友树友树何.友友树树何何何友何何();
                        友友友树树何何何树友 = new 树何树何何友树友树何.友友树树何何何友何何();
                        何友何友友友友友树友 = new 树何树何何友树友树何.友友树树何何何友何何();
                        友何树何树友树何友何 = new 树何树何何友树友树何.友友树树何何何友何何();
                        友树友何何何树何树树 = new 树何树何何友树友树何.友友树树何何何友何何();
                        return;
                     }

                     var4 = var5.charAt(var12);
                     break;
                  default:
                     var0[var6++] = var20;
                     if ((var12 += var4) < var7) {
                        var4 = var5.charAt(var12);
                        continue label28;
                     }

                     var5 = "\u0014À$×\u0099zzzäh\u0003+Òháý\bV{\u0082ÐÔ·ï©";
                     var7 = 25;
                     var4 = 16;
                     var12 = -1;
               }

               var14 = var5.substring(++var12, var12 + var4);
               var10001 = 0;
            }
         }
      }

      public static 树何树何何友树友树何.友友树树何何何友何何[] B() {
         long var0 = a ^ 90145319215592L;
         return (树何树何何友树友树何.友友树树何何何友何何[])a<"Ð">(-8626701038887382877L, var0).clone();
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 195 && var8 != 'P' && var8 != 208 && var8 != 'm') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 211) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 231) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 195) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'P') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 208) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树何何友树友树何$友友树树何何何友何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 43;
                  case 1 -> 48;
                  case 2 -> 46;
                  case 3 -> 41;
                  case 4 -> 37;
                  case 5 -> 42;
                  case 6 -> 30;
                  case 7 -> 24;
                  case 8 -> 0;
                  case 9 -> 25;
                  case 10 -> 60;
                  case 11 -> 39;
                  case 12 -> 31;
                  case 13 -> 1;
                  case 14 -> 16;
                  case 15 -> 33;
                  case 16 -> 10;
                  case 17 -> 55;
                  case 18 -> 9;
                  case 19 -> 28;
                  case 20 -> 2;
                  case 21 -> 53;
                  case 22 -> 51;
                  case 23 -> 19;
                  case 24 -> 49;
                  case 25 -> 52;
                  case 26 -> 59;
                  case 27 -> 23;
                  case 28 -> 40;
                  case 29 -> 11;
                  case 30 -> 20;
                  case 31 -> 14;
                  case 32 -> 45;
                  case 33 -> 50;
                  case 34 -> 58;
                  case 35 -> 4;
                  case 36 -> 35;
                  case 37 -> 22;
                  case 38 -> 56;
                  case 39 -> 32;
                  case 40 -> 7;
                  case 41 -> 34;
                  case 42 -> 3;
                  case 43 -> 62;
                  case 44 -> 17;
                  case 45 -> 47;
                  case 46 -> 29;
                  case 47 -> 8;
                  case 48 -> 44;
                  case 49 -> 13;
                  case 50 -> 63;
                  case 51 -> 18;
                  case 52 -> 12;
                  case 53 -> 26;
                  case 54 -> 21;
                  case 55 -> 57;
                  case 56 -> 27;
                  case 57 -> 61;
                  case 58 -> 15;
                  case 59 -> 38;
                  case 60 -> 5;
                  case 61 -> 6;
                  case 62 -> 36;
                  default -> 54;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "3d'v\u0013d<$j}\u0019y9ya;\u0011d4\u007fepRb=ze;\u000en>nlgR栚伅栛作佀厷栚厛栛作1厷叀桁栛作佀伩叀伅佟";
         b[1] = "\u0018es3\u0010V,F|s]]&[y.V\u001b.Ft(RPm@}-R\u001b1L~9[Gm核佅桌佫你厈核叛桌佫\u0011厈叢栁桌佫你伖叢佅伈\u0005";
         b[2] = "\u0013-\u001e\rKv\u0018\"\u000fB*x\u0013)\u000b\u0018";
         b[3] = "QV\u0018K\u0003T\u0015X\u0000-叼可厫栬桫佰佢佱桱叶r\u0014\\F\u000e\t\nPR^";
         b[4] = "YlsKCs\u001dbk-厼佖桹佒栀叮桦佖厣佒\u0019\u0014\u001ca\u00063aP\u0012y";
         b[5] = "\u001esl\u000b)(Z}tm佈厓佺叓叅厮取厓栾叓\u0006Tv:A,~\u0010x\"";
         b[6] = "^%9PO[\u001a+!6伮佾厤厅伎栯桪栺伺桟S\u000f\u0010I\u0001z+K\u001eQ";
         b[7] = "8E\u0019B\u0018\u0010|K\u0001$叧厫作佻厰佹栽厫参句s\u001d\u0018\u0006b\\\u000eVF\u0016}";
         b[8] = "(A\u007fh\fPlOg\u000e右栱叒使佈体栩併栈栻\u00157SBw\u001ems]Z";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public static 树何树何何友树友树何.友友树树何何何友何何 P(String name) {
         return Enum.valueOf(树何树何何友树友树何.友友树树何何何友何何.class, name);
      }

      private static String LIU_YA_FENG() {
         return "何树友被何大伟克制了";
      }
   }

   private static class 树树友友友何友何何树 implements 何树友 {
      final Block 树何何树树友树友友何;
      final 树何树何何友树友树何.友友树树何何何友何何 树树树树友何树友何树;
      final double 友树树何友友何何何友;
      final long 友树何友何何何友友友;
      private static String HE_WEI_LIN;

      树树友友友何友何何树(Block block, 树何树何何友树友树何.友友树树何何何友何何 type, double authenticity) {
         this.树何何树树友树友友何 = block;
         this.树树树树友何树友何树 = type;
         this.友树树何友友何何何友 = authenticity;
         this.友树何友何何何友友友 = System.currentTimeMillis();
      }

      private static String HE_SHU_YOU() {
         return "何炜霖诈骗";
      }
   }
}
