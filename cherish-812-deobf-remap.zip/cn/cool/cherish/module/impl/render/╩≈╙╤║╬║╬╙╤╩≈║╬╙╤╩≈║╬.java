package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.友树友友何友树友树友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.client.树何树树何树何何树何;
import cn.cool.cherish.utils.player.树友友何树友树树树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import why.tree.friend.antileak.Fucker;

public class 树友何何友树何友树何 extends Module implements 何树友 {
   private final ModeValue 何树何友何何树树友何;
   private final BooleanValue 何何何树树友树何友树;
   private final NumberValue 何友何树树树何树何树;
   private final NumberValue 友友树何何何树树树友;
   private final NumberValue 何何友树树友友树友树;
   private final NumberValue 何友何树树友树树何友;
   private final NumberValue 树何树何友何友树友友;
   private final BooleanValue 友何何友树友树树树友;
   private final NumberValue 何树友何友何何友友友;
   private final BooleanValue 友何树树树友树树树友;
   private final BooleanValue 友友何树友树友何友友;
   private final BooleanValue 树何树树友何友何树何;
   private final BooleanValue 友何友友何何树树树友;
   private final Color 树友友友何何友何友友;
   private final Color 何树何树友友树友何树;
   private static final int 树友何树友何树友何友;
   private static final double 友友友友何何友友友树 = 0.7;
   private static final double 树友树友树树友何树友 = 0.8;
   private static final double 友友何树树树树何友树 = 3.0;
   private static final int 何友友何何何友何友何;
   private static final double 树何何友友树何友何树 = 3.0;
   private static final int 友树友何树何树友树何;
   private final Set<BlockPos> 友友何何树友友何树友;
   private final Set<BlockPos> 何树友友何友树友树何;
   private AtomicBoolean 树树树友友何树何友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[46];
   private static final String[] n = new String[46];
   private static String HE_JIAN_GUO;

   public 树友何何友树何友树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/render/树友何何友树何友树何.a J
      // 003: ldc2_w 20541566883501
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 21843
      // 00c: ldc2_w 7020699587332543601
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 27545
      // 019: ldc2_w 9174048700294572708
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w -3919240955219815684
      // 026: lload 1
      // 027: invokedynamic Ó (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/ModeValue
      // 033: dup
      // 034: sipush 28127
      // 037: ldc2_w 2169028385286040804
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 15022
      // 044: ldc2_w 7341805281181105058
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 3
      // 04f: anewarray 130
      // 052: dup
      // 053: bipush 0
      // 054: sipush 25574
      // 057: ldc2_w 3366994302086750962
      // 05a: lload 1
      // 05b: lxor
      // 05c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 061: aastore
      // 062: dup
      // 063: bipush 1
      // 064: sipush 23197
      // 067: ldc2_w 2125625340119948201
      // 06a: lload 1
      // 06b: lxor
      // 06c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 071: aastore
      // 072: dup
      // 073: bipush 2
      // 074: sipush 24961
      // 077: ldc2_w 4237140683619180700
      // 07a: lload 1
      // 07b: lxor
      // 07c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 081: aastore
      // 082: sipush 25574
      // 085: ldc2_w 3366994302086750962
      // 088: lload 1
      // 089: lxor
      // 08a: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 08f: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 092: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.何树何友何何树树友何 Lcn/cool/cherish/value/impl/ModeValue;
      // 095: aload 0
      // 096: new cn/cool/cherish/value/impl/BooleanValue
      // 099: dup
      // 09a: sipush 4346
      // 09d: ldc2_w 2231484913680470448
      // 0a0: lload 1
      // 0a1: lxor
      // 0a2: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a7: sipush 20083
      // 0aa: ldc2_w 6432016914863755110
      // 0ad: lload 1
      // 0ae: lxor
      // 0af: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b4: bipush 1
      // 0b5: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0b8: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0bb: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.何何何树树友树何友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0be: aload 0
      // 0bf: new cn/cool/cherish/value/impl/NumberValue
      // 0c2: dup
      // 0c3: sipush 9335
      // 0c6: ldc2_w 7433255918884250967
      // 0c9: lload 1
      // 0ca: lxor
      // 0cb: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d0: sipush 27157
      // 0d3: ldc2_w 4977803501242362705
      // 0d6: lload 1
      // 0d7: lxor
      // 0d8: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0dd: ldc2_w 2.0
      // 0e0: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0e3: dconst_1
      // 0e4: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0e7: ldc2_w 5.0
      // 0ea: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0ed: ldc2_w 0.5
      // 0f0: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0f3: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0f6: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.何友何树树树何树何树 Lcn/cool/cherish/value/impl/NumberValue;
      // 0f9: aload 0
      // 0fa: new cn/cool/cherish/value/impl/NumberValue
      // 0fd: dup
      // 0fe: sipush 23071
      // 101: ldc2_w 3459777135554108252
      // 104: lload 1
      // 105: lxor
      // 106: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 10b: sipush 23097
      // 10e: ldc2_w 8120716081579563828
      // 111: lload 1
      // 112: lxor
      // 113: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 118: sipush 200
      // 11b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 11e: bipush 20
      // 120: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 123: sipush 255
      // 126: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 129: bipush 5
      // 12a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 12d: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 130: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.友友树何何何树树树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 133: aload 0
      // 134: new cn/cool/cherish/value/impl/NumberValue
      // 137: dup
      // 138: sipush 4248
      // 13b: ldc2_w 3162816765033599399
      // 13e: lload 1
      // 13f: lxor
      // 140: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 145: sipush 2681
      // 148: ldc2_w 3053139550214572915
      // 14b: lload 1
      // 14c: lxor
      // 14d: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 152: bipush 64
      // 154: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 157: bipush 32
      // 159: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 15c: sipush 128
      // 15f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 162: bipush 8
      // 164: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 167: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 16a: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.何何友树树友友树友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 16d: aload 0
      // 16e: new cn/cool/cherish/value/impl/NumberValue
      // 171: dup
      // 172: sipush 7861
      // 175: ldc2_w 8860585891253149604
      // 178: lload 1
      // 179: lxor
      // 17a: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 17f: sipush 11216
      // 182: ldc2_w 6566666941029477000
      // 185: lload 1
      // 186: lxor
      // 187: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 18c: bipush 32
      // 18e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 191: bipush 16
      // 193: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 196: bipush 64
      // 198: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 19b: bipush 8
      // 19d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1a0: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1a3: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.何友何树树友树树何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 1a6: aload 0
      // 1a7: new cn/cool/cherish/value/impl/NumberValue
      // 1aa: dup
      // 1ab: sipush 788
      // 1ae: ldc2_w 4541201307792884242
      // 1b1: lload 1
      // 1b2: lxor
      // 1b3: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b8: sipush 17527
      // 1bb: ldc2_w 1326598475485021541
      // 1be: lload 1
      // 1bf: lxor
      // 1c0: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c5: bipush 24
      // 1c7: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1ca: bipush 10
      // 1cc: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1cf: bipush 100
      // 1d1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1d4: bipush 2
      // 1d5: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1d8: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1db: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.树何树何友何友树友友 Lcn/cool/cherish/value/impl/NumberValue;
      // 1de: aload 0
      // 1df: new cn/cool/cherish/value/impl/BooleanValue
      // 1e2: dup
      // 1e3: sipush 23861
      // 1e6: ldc2_w 2040675254674988063
      // 1e9: lload 1
      // 1ea: lxor
      // 1eb: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f0: sipush 12274
      // 1f3: ldc2_w 3042983488603516629
      // 1f6: lload 1
      // 1f7: lxor
      // 1f8: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1fd: bipush 0
      // 1fe: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 201: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 204: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.友何何友树友树树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 207: aload 0
      // 208: new cn/cool/cherish/value/impl/NumberValue
      // 20b: dup
      // 20c: sipush 19003
      // 20f: ldc2_w 7216522309073046288
      // 212: lload 1
      // 213: lxor
      // 214: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 219: sipush 2523
      // 21c: ldc2_w 6091534558252550381
      // 21f: lload 1
      // 220: lxor
      // 221: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 226: bipush 15
      // 228: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 22b: bipush 5
      // 22c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 22f: bipush 50
      // 231: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 234: bipush 1
      // 235: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 238: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 23b: aload 0
      // 23c: invokedynamic get (Lcn/cool/cherish/module/impl/render/树友何何友树何友树何;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/render/树友何何友树何友树何.y ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 241: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 244: checkcast cn/cool/cherish/value/impl/NumberValue
      // 247: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.何树友何友何何友友友 Lcn/cool/cherish/value/impl/NumberValue;
      // 24a: aload 0
      // 24b: new cn/cool/cherish/value/impl/BooleanValue
      // 24e: dup
      // 24f: sipush 28052
      // 252: ldc2_w 2295561776197282946
      // 255: lload 1
      // 256: lxor
      // 257: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 25c: sipush 2395
      // 25f: ldc2_w 7864540340662487055
      // 262: lload 1
      // 263: lxor
      // 264: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 269: bipush 1
      // 26a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 26d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 270: aload 0
      // 271: invokedynamic get (Lcn/cool/cherish/module/impl/render/树友何何友树何友树何;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/render/树友何何友树何友树何.f ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 276: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 279: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 27c: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.友何树树树友树树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 27f: aload 0
      // 280: new cn/cool/cherish/value/impl/BooleanValue
      // 283: dup
      // 284: sipush 1021
      // 287: ldc2_w 1778217907664765651
      // 28a: lload 1
      // 28b: lxor
      // 28c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 291: sipush 31408
      // 294: ldc2_w 6835354751163317139
      // 297: lload 1
      // 298: lxor
      // 299: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 29e: bipush 1
      // 29f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2a2: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2a5: aload 0
      // 2a6: invokedynamic get (Lcn/cool/cherish/module/impl/render/树友何何友树何友树何;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/render/树友何何友树何友树何.S ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 2ab: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 2ae: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 2b1: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.友友何树友树友何友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2b4: aload 0
      // 2b5: new cn/cool/cherish/value/impl/BooleanValue
      // 2b8: dup
      // 2b9: sipush 3413
      // 2bc: ldc2_w 5135774083357002874
      // 2bf: lload 1
      // 2c0: lxor
      // 2c1: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c6: sipush 3781
      // 2c9: ldc2_w 8834700971432366018
      // 2cc: lload 1
      // 2cd: lxor
      // 2ce: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2d3: bipush 1
      // 2d4: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2d7: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2da: aload 0
      // 2db: invokedynamic get (Lcn/cool/cherish/module/impl/render/树友何何友树何友树何;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/render/树友何何友树何友树何.A ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 2e0: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 2e3: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 2e6: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.树何树树友何友何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2e9: aload 0
      // 2ea: new cn/cool/cherish/value/impl/BooleanValue
      // 2ed: dup
      // 2ee: sipush 24608
      // 2f1: ldc2_w 9193054816424796520
      // 2f4: lload 1
      // 2f5: lxor
      // 2f6: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2fb: sipush 18487
      // 2fe: ldc2_w 500249349114267909
      // 301: lload 1
      // 302: lxor
      // 303: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 308: bipush 0
      // 309: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 30c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 30f: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.友何友友何何树树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 312: aload 0
      // 313: new java/awt/Color
      // 316: dup
      // 317: bipush 31
      // 319: bipush 1
      // 31a: sipush 221
      // 31d: sipush 216
      // 320: invokespecial java/awt/Color.<init> (IIII)V
      // 323: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.树友友友何何友何友友 Ljava/awt/Color;
      // 326: aload 0
      // 327: new java/awt/Color
      // 32a: dup
      // 32b: sipush 255
      // 32e: sipush 165
      // 331: bipush 0
      // 332: sipush 216
      // 335: invokespecial java/awt/Color.<init> (IIII)V
      // 338: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.何树何树友友树友何树 Ljava/awt/Color;
      // 33b: aload 0
      // 33c: invokestatic java/util/concurrent/ConcurrentHashMap.newKeySet ()Ljava/util/concurrent/ConcurrentHashMap$KeySetView;
      // 33f: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.友友何何树友友何树友 Ljava/util/Set;
      // 342: aload 0
      // 343: invokestatic java/util/concurrent/ConcurrentHashMap.newKeySet ()Ljava/util/concurrent/ConcurrentHashMap$KeySetView;
      // 346: putfield cn/cool/cherish/module/impl/render/树友何何友树何友树何.何树友友何友树友树何 Ljava/util/Set;
      // 349: aload 0
      // 34a: new java/util/concurrent/atomic/AtomicBoolean
      // 34d: dup
      // 34e: bipush 0
      // 34f: invokespecial java/util/concurrent/atomic/AtomicBoolean.<init> (Z)V
      // 352: ldc2_w -3918894288237043444
      // 355: lload 1
      // 356: invokedynamic â (Ljava/lang/Object;Ljava/util/concurrent/atomic/AtomicBoolean;JJ)V bsm=cn/cool/cherish/module/impl/render/树友何何友树何友树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 35b: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6399996700300606020L, -2313405962342108589L, MethodHandles.lookup().lookupClass()).a(30853338033905L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 63825235760917L;
      Cipher var13;
      Cipher var24 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[93];
      int var18 = 0;
      String var17 = "¥:\u0099É\u0080!$îy'\u008eÙÕ6Î¶\u008c\u0016\u0099'\u0019ÏÖ\u001eQHÿ\nµàôOX@\u008fæ¯ð\u0010M(ÏÉ^\u008dU\u001aõRã¼©\u000fX\u0014\u008ci$\u0088+@nRdaS?\u0004\u008e<\u0019\u008bþ5Z\u0005Þ@ßºI\u0014\u009b××ºéïÞ!\"cÉ×LÏA×öìõvnêco\u0002J³iýT\u0014#Töh¾\u0093ç÷ 1\u001c!ñF,O8[V@'\u008bv\u0011Qí\u001aY;Ø\u00103]\u001f\u0016â\u001cL_\u000eÝ Vnæ8óqëfzé¥õ\n«¼Vu\u0085ä\u0080ø\u0096P\u0099fò6m\u0001Ò\u0086b(|\u0003|B2\u0001\u0013$\u000f\u001e{ÃýÝµvÐGGï\u001f\u0016º¾&¨\u0088I\u009b\u001a\u0017\\ØÕ%ZxòµÐ\u0018\u0007\u0084ÖQSx²\u009b, Û»UìV&û\u0084\u0005oc\u0002iZ\u0010E\u0096\u0010Óê©ä \u000e¡äý$ØÙ\u0096(`¡¥Ó\u0099¯\u008fÏøá±Ì°r\u0003þ\u00079õ\u0007ÓìÄ%\u00908G\u009da3\u0087y\u009a³ªX\u00876\"\u009c\u0010½7\f\t¸[÷]¨ÐjÌ\u0006o\u0098p 4\u0081G0prwfÿªÝÚ\u0081!\u0082$\u0089Ú\tÎ\u0084æÎÜçIÏ\u008e\u0081÷sº\u0010\b?T÷â_KÑ¹\u0015bç\u009aC\u008f2\u0010\u0094\r\u001fág9\rÓÄ\u0090¾o¤\u0006³\u009b\u0010ÕÍÄZÔrH\u008dõç\u0083ðsqÆ$\u0010:\u008a\f¾ñ®ti\u0089ð\u008dz\u000f\u000fÃ> Wó\u0019¯\u0088\u008bÖ|EØ \u0099ÔXG#1\bUmKý\t´EuÔ\u0005¡ä\u000f`\u0010\u008e\"\u0082\u0096p¢\u0090ü<\u008cüGÛ;ö9\u0010²qÑ\u009d\u007f<\u0080¼^\u0083ú0\u009b\u000fËÖ\u0010D©×J¶+ÆB¼y²ân¢*\u0015 ç¢\u0005ô\u0095Ó¾3\u0083 \u0084ë¼Ã$\u0099]-ÿå\u00ad°eHÒ¦\bÃ÷\u0010xã\u0010\u000f?\u0080vù\"á\u0083Áù³á÷í$Ä\u0010\u0001\u0097{É\u0083\u000eÝ\u0095û\u009a\u0090j=\u000f}\u0095\u0018\u001ff·G\u0090ýÖ\u009d?½?êja\u001fB!Òø\u0088üE¤c(\u0082¢\u0099úq\u00adµÝW¦ÈSM\u008bá á:;¨¿As\u0095,\n¤\u0017\\<Ä\n\u0093È<,w\u0013\u001c\u0095\u00109¨4\u001ab»¤±ý'\u0082\u0012Ç\u0091\u0007®\u0010Ú#ð\u00056Þ®3í°&\u0098\u001f«¸\u0016\u0010_\u0092d¸¾\u009fÉh×|«\u008d\u0096íãø Ü6\u0093fà#3 \u0004\u007f5*èBU\u009e,\u0094KQö&\u001düÎº`Pýä#£\u00106ô\u0097\u009fÞÍ¿\b\u00127bîàõ½\u0011\u0010Í\tÌ¨\u008a\b}¼máÎt5\t\tâ \u008d?,\u001cZ\u0006\bû\u0012\u001dº/¥¨ç6 (Ûñáó)·\u0089ËMYû}V¿ &É_q®ìiJ\u008b\rò·\u009cßÂCDÒEãÀó\u000b\u001e\u0081>\u000b:¬\u008eq\u001b 0¸TÒí¤p\u0093õðÛ\u0081Õ\u009dCÙG¹\u009c°3\u0016>bÏ¶\u0083¡ ÀÙ\u009aP[\u0095\u0097)\u007f\u0005\u0083n~\u0014öpòòÀ±[>=²ýtï\u0010\u0091\u0017ÄÏ¬ä^2a*SnØ\u009fÃ\u001aV¼\u001dx¦\u0012+àp'i\ny²Y·Ñ\u001d×\u0007\u0006a*r@µÈ\u0095\u000b»å\u0016/\u001aòûô'\u009e\u0004\u0010\u009cê\u00ad\u000fnëì·.\u008b\u009fWÖ·Ê¨X4òÖp\rÙ^Á\u0084=\u0010\u008a\u000fi]\u0080\u0013EÜ´\u0005í:vw²IøU\u0004.óêï\u0099\u0006]ñªfâª>\u00ad5K\u009bo³½¾ßA\u0082L¶A«Ê\u0011D£ /J¢¶kÖ\\FÙv\u009ab\u0006\u0089)a%)Ì\u0017O\u009f Û¬\u0018:ÂÕ\u0017½\u008a3qí³¿\u007fèè1Ñ\u00939úcÈ\u0018ÓÎ\u0018ÙLåùtÐ\\'\u0017f\u0093¿¯ÝæIq\u009d\nÓ)\u0013¦\u0002\u0010\u0089ºà\u0003kªà\u0081l\u0084Ç\u0089±\u001eù\n\u0018sÄ_\u001cNcÆ\u0090O\u0018gÄäü\u0013\u0001^¸Ô3ú#ñ  þz.\u0083°Oÿ¹ýÂÁÖK\u0001OàÊW)\u008cÄE\u0011\u0002¯\u008b0c£»\u0082¾\u0010c}mw\u000eù+(|ä\r\u0081F\u0019Êõ\u0010O$Ë5´\u0011Æ?\u0080ôÙ¬²ì¢J(¬âÅ^¿[~ünâ#ºJ¶¶\u000f(¼/Á\u0003©\u0016têZi\u001d¼Û\u001dc\u009bq¿Á\u0014XU, e¦®\rÚ ¼h\u008a2\u0016þZÊ\u0093Ç©0äA\u000f\u0004à7À\u0016+pä«}r\u0010ëÀÀ\u0017¡Ö:\nx\u00976µ0Ñ-N\u0010½\u00003\u008b\u0080¯R1ò'\u0014oHZ ,( \u007feã#IrùØø\u008a\u001d¹\u0089ÂE\u001c«°\u008b¶ú\u009cm\u008d°'@4Lk\u0096\r\u00952xN\\<ý \u009búOoU¿\\\u0089ê¿`³\u0098+\u00895\u008b©\u0015`\u000eEÛ%Å<{Spîµº\u0018DíD\u0087Hô#§\u0001°ùîÀfrûÚÚ\u0088C)´\u001ai q¯;±¼Ò\u0007Hd?Ñ=Am\u008cONB\u0099tôÆ»BË©Òl-Ê\u001f©0÷6\u0092ËZ³fàµ|¯ ñ+>\u0019K³m\u0010\u0004µ£Ù\u0002®ã\u0011[ÏÚ\u008a©A\\\u001a\u0017khCOXÃe£\u0091øÍ ê\u008b\u0013Ð(-Ä`¯q\u0091ÖÉäd+ªÙâÐ,\u009cè\u0088:\r\u0007ñÝ\u0093.\u0012\u0010íÃK7°Û ë\u00944\u0017µ\u008a\u0082ú* Zv¹~8jãÓ»·\u0081A±>×ÌïX\u009e³.ò\u00adÛ\u008a\f\u000f\u001aÒ\u0092E\u001e\u0018Lt¶zSäÖ÷\u0016¯èÍ3á\u0007\u0014j\u0014¯Îb\u0005\u0014ù\u0010f*\u0010ZÁ}²0j\u0006\u0084vJ¯$\u000b 6JÇ,55!÷4BUê\u008bxå\u0015¢\u0092\u008e\u009aµB+Û\u009f\u008a4¨\u00ad\u009bÓX æÉÈíÀ\u0003l²IEK\u001cNt\r´Û}\u0088\u0003®{WG\u009cÄwÝ zê\u0095PÙjçö\u0007\\\u0012\u0099\nÝI\u00ad¨Ù2ú\u0005úÖ\u009e\\ÈÀ/×¨\u009e²\u0004\u0093x«\u0083\u000e\f\u007f$\n|ß!\u009b\u0095fA\u0086´±tÛq<ÛÁ\u001b4\u0011âp\u0017f5ë$:M\u008cé\u0002±D\b´Åö\u009aóLIÔ éÐF_5{í=Â\u0094ñ'xGè\u0085Hy&fM\u0093U\u00ad\u0088\u0081\u0012\fâ\rK¾\u00107\u0018H\u000f\u001ax\u0095}þ\bTZY\u0094Ò®\u0010éJå\u0093¼»?ª±éÔö×l=\t \u0083À\u000f\u0095\u009d§7é}\b¼\u0095¿\u0006(K^Õ\u000f|^|P\u009d08\u0018Ôÿ\u001e:G\u0010õÃ3j~r\u009f¯äGÇìÉ´h&\u0018¢\u0092}\u0086\u008a\u0019#±\u0010\u001f\u009c,Á\u001d(\u0088ë\u0016¶kå~ÆÝ\u0010¹E\u008cjÝ[ö·5¶M2<ÍSl sÆé\n\u0010ÿ±>$a\u00111\u0093ï©ö.8û\u0082¡\u0013\u001fgÖ\tHóó×\u0098\u0012\u0010\u009dDÁ/_Mk\u009dÚ-·Ïv\r\u001e\u008f\u0010Q\u0082 {äÏ×6\u009d\n8\u00171bñâ \u0006\u008d\u001aY\r«\u008dC6;\u001a®{ÿ,PG±ÅnK¿à7£Íor)0\u009dâH\u0000R×â\u0085\u0098 \u008fY\\H]ï\\À\u0003\u0085\u0019\u001c\u009aàì\u0085\u0097\u0082\t1Wu¼\u0015ÅHs]å%<\u001f6øhá¿Ôãþ\tÈÙÐ\u009bS²\u0089!î\u0002ðk!¨\u001ee8ÊÜ\u0019Íý\u008bÈ °ª¼³/Wn%ÅQ${cQßõ\u00adÜ\u0014\u008bòoÔf\u0006\u009d4\u0014*\u0098!\u000bPèÓA\u009a2Vm_\u0099\u00976V\u0080g|¹=¶\u0083ô¾\u0081Ç¹A:\u0012¿EÉ>½ô\u0018jZ\u0095ãNcÂ\u0011|\u0007*½M£±v=E´.,]ÍÊi;\u008c\u0007[Å\u000e£\u008dµì)Y\u0092¶s\u0012bAVÒ.\u00104\u008ch\u0010Éür\u0085\u008c\bâµs>Qz\u0010[°ÙÕõ»^%²ö´ûúRÿÜ\u0018\u001c{\u0083\u0019Û\u0014è\u001b\u0016!Ñ§~K-q¬uaþ\u0006nÙ<\u0018s,_\u0090\u007f¿jí¿l«\u001dõ\u009e\bVá\u0014Ä\u000bë`\u008dà ÝìbQôïú\u008dO\u001a·[í¼mÌçd\u0089ÞÈÜH:égÓ\u008e±0j\u008f\u0010¢²°Ñ\u008b³çIï27Ëò\u009aoD0ùO\f|\u0001B©h¸\u0084hÇbô\u008d¶d«7ïDý®¨öP³µÉº¯I\u000fsÈytÊP\u009bF¯ª_Çþ\u0090u\u0018v½v\u0088a\u0005*ö\u0019¥\u0080³[Êj\u008bü~é\u0016èÈ\u0001\u00108£ëö\u0083F~4z\u008c *\u0016\u0085r3çz0Yÿ\u0085\u0017[F¾CÜ\u0007õ@d\u009c$÷\u000eS,Ìe±O êÎ]sË5ÕnÚOûþª=\u0010\t®6MÅã?\u0091k\u0091¯N`µ>Ù@aBç¤|ü\u008aÙ¸âdÂ[\u0097Æ/ël63JÚ>>\u0016\u0094EÀ\u0081\u0090\u009f(w\u0089ò\u0099\u0080!*]é.\u0002\u0099Æ\u007f\u001dk\u0080A_=÷êÀ!ë\u0006ûxJ+Sÿ\u0010LpëÐÆ¨©ÊÙ\u007f\u0018\u001f¶¢l\u0007\u0018\fúe1Ã1\u0004ÿ¨K\u001f\u0093#(|\u0097\u0007\u0000\fvY°0N\u0010\u001f\u00ad\u0014\u0000Äá;<\u008dn\u0015\u0088á\u0093Fp\u0010 \u008dL\u008b\u008f]\u008cÿGòÁ0ÚY.À\u0018ÀÑ?5å\u0003O\u0011\u0006 |\u001a\u0004¹\u009b\u0005â\u0019#®°ôéá\u0010òÚ·VbIt\u001eì×.\u0096\u0099<\u000eô@nríAr\u008eÚá\u001duãÌéWë¡ä\u0003\u0082ky\\\u0011u=P¬\u0007\u000f®\u009a#bÍ-!±áÝPÊ\u00931 â¡D<¦Â0@f\u0091MÙB\u007f\u0013\u0091\u0014\u0096äÅ";
      short var19 = 2746;
      char var16 = ' ';
      int var23 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            String var36 = c(var13.doFinal(var25.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var23 += var16) >= var19) {
                     c = var20;
                     h = new String[93];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var27 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var27.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[7];
                     int var3 = 0;
                     String var4 = "{5¬tHÔSÔ¬\r¶\nò0;\u001eË±ôá\u00903¼\u0017q\u0019\u008c\u008f4õ¢$1w<\u0094~\u0096½§";
                     byte var5 = 40;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var43 = -1;

                        while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    j = var6;
                                    k = new Integer[7];
                                    树友何树友何树友何友 = c<"t">(12416, var11 ^ 7231666017131439575L);
                                    友树友何树何树友树何 = c<"t">(20186, var11 ^ 3859947229281704843L);
                                    何友友何何何友何友何 = c<"t">(1595, var11 ^ 7255901594651104104L);
                                    return;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\tÄ*ø|-ä8ðÉÄZ\u0010Ö\u009eÊ";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label54;
                  }

                  var17 = "gÒ\u0094U\u0010Ý\u000bE5¤1\u009aÔ\u0092\u001f\u0017 ¬9±l\u0019H_g\u009cF q\u008cÛ°8ám\u008aE\u0000m5<^ËabïqE/";
                  var19 = 49;
                  var16 = 16;
                  var23 = -1;
            }

            var25 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   }

   private boolean C(String blockId) {
      long a = 树友何何友树何友树何.a ^ 117943520255095L;
      d<"ä">(235698358515926867L, a);
      return blockId.contains(b<"r">(25857, 1769595551245102789L ^ a))
         || blockId.contains(b<"r">(28969, 6829145844115503806L ^ a))
         || blockId.contains(b<"r">(6156, 3772360644595520487L ^ a))
         || blockId.contains(b<"r">(30568, 5689513233054104803L ^ a))
         || blockId.contains(b<"r">(11835, 4265591814711289341L ^ a))
         || blockId.contains(b<"r">(18544, 431805013263467410L ^ a));
   }

   private void C() {
      long a = 树友何何友树何友树何.a ^ 127005072844275L;
      d<"ä">(-4989629194907631913L, a);
      if (d<"þ">(this, -4989096389295304110L, a) != null) {
         d<"þ">(this, -4989096389295304110L, a).set(false);
         d<"â">(this, null, -4989096389295304110L, a);
      }
   }

   @EventTarget
   public void D(TickEvent event) {
      long a = 树友何何友树何友树何.a ^ 42348501444964L;
      long ax = a ^ 43730650238836L;
      long var10001 = a ^ 80952465419085L;
      int axx = (int)((a ^ 80952465419085L) >>> 48);
      int axxx = (int)((a ^ 80952465419085L) << 16 >>> 48);
      int axxxx = (int)(var10001 << 32 >>> 32);
      d<"ä">(8527024558354362944L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         if (!d<"þ">(this, 8526578819790560965L, a).get() && d<"þ">(this, 8526578819790560965L, a).compareAndSet(false, true)) {
            树何树树何树何何树何.N((char)axx, () -> {
               long axxxxx = 树友何何友树何友树何.a ^ 12104196888238L;
               long axxxxxx = axxxxx ^ 5194473791582L;
               d<"ä">(-3919189206776689270L, axxxxx);

               try {
                  String e = d<"þ">(this, -3918539807504746985L, axxxxx).getValue();
                  byte var7x = -1;
                  switch (e.hashCode()) {
                     case -901402615:
                        if (!e.equals(b<"r">(25574, 3366984799430517489L ^ axxxxx))) {
                           break;
                        }

                        var7x = 0;
                     case -1581447705:
                        if (!e.equals(b<"r">(23197, 2125599314674457514L ^ axxxxx))) {
                           break;
                        }

                        var7x = 1;
                     case 2076577:
                        if (e.equals(b<"r">(24961, 4237113932188033183L ^ axxxxx))) {
                           var7x = 2;
                        }
                  }

                  switch (var7x) {
                     case 0:
                        this.X();
                     case 1:
                        this.e();
                     case 2:
                        this.X();
                        this.e();
                  }
               } catch (Exception var11) {
                  if (d<"þ">(this, -3918448697089543916L, axxxxx).getValue()) {
                     ClientUtils.e(new Object[]{b<"r">(1569, 9218924690368251765L ^ axxxxx) + var11.getMessage(), axxxxxx});
                  }
               } finally {
                  d<"þ">(this, -3918602520263007985L, axxxxx).set(false);
               }
            }, (char)axxx, axxxx);
         }
      }
   }

   public void F() {
      this.Z();
      this.C();
   }

   private void Z() {
      long a = 树友何何友树何友树何.a ^ 48045975600948L;
      d<"þ">(this, 2309204189833053655L, a).clear();
      d<"þ">(this, 2307698375912855571L, a).clear();
   }

   private boolean e(BlockPos pos, Set<BlockPos> blocks) {
      long a = 树友何何友树何友树何.a ^ 139498344021790L;
      long ax = a ^ 96521328443985L;
      d<"ä">(2318311415873610810L, a);
      if (blocks.contains(pos)) {
         return false;
      } else {
         Block block = 树友友何树友树树树何.o(ax, pos);
         return block != null && !(block instanceof AirBlock);
      }
   }

   private void e() {
      long a = 树友何何友树何友树何.a ^ 7803655427367L;
      long ax = a ^ 6980339053367L;
      long axx = a ^ 9499301962711L;
      d<"ä">(-3885143901551407613L, a);
      if (!this.w(new Object[]{ax})) {
         int range = d<"þ">(this, -3884303842952638360L, a).getValue().intValue();
         int vRange = d<"þ">(this, -3884613859334442841L, a).getValue().intValue();
         int playerX = (int)mc.player.getX();
         int playerY = (int)mc.player.getY();
         int playerZ = (int)mc.player.getZ();
         int minY = Math.max(playerY - vRange, mc.level.getMinBuildHeight());
         int maxY = Math.min(playerY + vRange, mc.level.getMaxBuildHeight());
         Set<BlockPos> visitedBlocks = new HashSet<>();
         int rangeSquared = range * range;
         int x = playerX - range;
         if (x <= playerX + range) {
            int z = playerZ - range;
            if (z <= playerZ + range) {
               int dx = x - playerX;
               int dz = z - playerZ;
               if (dx * dx + dz * dz <= rangeSquared) {
                  int y = minY;
                  if (minY <= maxY) {
                     try {
                        BlockPos pos = new BlockPos(x, y, z);
                        if (visitedBlocks.contains(pos)) {
                        }

                        if (this.v(pos) && this.o(pos)) {
                           Set<BlockPos> potentialShaftBlocks = new HashSet<>();
                           this.j(pos, potentialShaftBlocks, visitedBlocks, 300);
                           int minSize = d<"þ">(this, -3883629537281214887L, a).getValue().intValue();
                           if (potentialShaftBlocks.size() >= minSize && this.c(potentialShaftBlocks)) {
                              d<"þ">(this, -3884992566003043840L, a).addAll(potentialShaftBlocks);
                           }
                        }
                     } catch (Exception var29) {
                        if (d<"þ">(this, -3884403394556349795L, a).getValue()) {
                           String axxx = var29.getMessage();
                           ClientUtils.e(
                              new Object[]{
                                 b<"r">(32035, 1906597586890211307L ^ a) + x + "," + minY + "," + z + b<"r">(19617, 6810080398513311268L ^ a) + axxx, axx
                              }
                           );
                        }
                     }

                     y = minY + 2;
                  }
               }

               z += 3;
            }

            x += 3;
         }

         if (d<"þ">(this, -3884403394556349795L, a).getValue()) {
            ClientUtils.e(
               new Object[]{
                  b<"r">(41, 6006263830288515816L ^ a) + d<"þ">(this, -3884992566003043840L, a).size() + b<"r">(23471, 7451375589094922533L ^ a), axx
               }
            );
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private boolean i(String blockId) {
      long a = 树友何何友树何友树何.a ^ 108931236565929L;
      d<"ä">(-3703271440545101683L, a);
      return blockId.contains(b<"r">(6590, 6643609909598084493L ^ a))
         || blockId.contains(b<"r">(21437, 4778819555513964419L ^ a))
         || blockId.contains(b<"r">(16515, 4390479093619164376L ^ a))
         || blockId.contains(b<"r">(10419, 2858927006259604726L ^ a));
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 62;
               case 1 -> 41;
               case 2 -> 58;
               case 3 -> 63;
               case 4 -> 14;
               case 5 -> 36;
               case 6 -> 9;
               case 7 -> 52;
               case 8 -> 1;
               case 9 -> 11;
               case 10 -> 44;
               case 11 -> 43;
               case 12 -> 16;
               case 13 -> 51;
               case 14 -> 50;
               case 15 -> 23;
               case 16 -> 35;
               case 17 -> 24;
               case 18 -> 42;
               case 19 -> 32;
               case 20 -> 39;
               case 21 -> 30;
               case 22 -> 8;
               case 23 -> 3;
               case 24 -> 26;
               case 25 -> 55;
               case 26 -> 40;
               case 27 -> 60;
               case 28 -> 13;
               case 29 -> 61;
               case 30 -> 54;
               case 31 -> 22;
               case 32 -> 25;
               case 33 -> 38;
               case 34 -> 17;
               case 35 -> 27;
               case 36 -> 15;
               case 37 -> 33;
               case 38 -> 37;
               case 39 -> 28;
               case 40 -> 7;
               case 41 -> 49;
               case 42 -> 20;
               case 43 -> 31;
               case 44 -> 59;
               case 45 -> 45;
               case 46 -> 21;
               case 47 -> 57;
               case 48 -> 19;
               case 49 -> 56;
               case 50 -> 10;
               case 51 -> 5;
               case 52 -> 18;
               case 53 -> 29;
               case 54 -> 4;
               case 55 -> 0;
               case 56 -> 2;
               case 57 -> 46;
               case 58 -> 53;
               case 59 -> 47;
               case 60 -> 6;
               case 61 -> 48;
               case 62 -> 34;
               default -> 12;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2193;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友何何友树何友树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树友何何友树何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树友何何友树何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 7550;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友何何友树何友树何", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private boolean c(Set<BlockPos> potentialShaft) {
      long a = 树友何何友树何友树何.a ^ 113960262533644L;
      long ax = a ^ 86531019947843L;
      long axx = a ^ 114478669591804L;
      d<"ä">(6718898443121285416L, a);

      try {
         Set<BlockPos> borderBlocks = this.p(potentialShaft);
         int mineshaftFeatureScore = 0;
         int artificialBlockScore = 0;
         int totalBlocks = 0;

         for (BlockPos pos : borderBlocks) {
            Block block = 树友友何树友树树树何.o(ax, pos);
            if (block != null) {
               String blockId = block.getDescriptionId().toLowerCase();
               totalBlocks++;
               if (this.A(blockId)) {
                  mineshaftFeatureScore++;
               }

               if (this.U(blockId)) {
                  artificialBlockScore++;
               }
               break;
            }
         }

         boolean hasLinearStructure = this.z(potentialShaft);
         boolean hasMineshaftFeatures = mineshaftFeatureScore > 0;
         boolean hasArtificialElements = artificialBlockScore > totalBlocks * 0.3;
         return hasMineshaftFeatures && hasArtificialElements && hasLinearStructure;
      } catch (Exception var17) {
         if (d<"þ">(this, 6718441612307735990L, a).getValue()) {
            ClientUtils.e(new Object[]{b<"r">(839, 3591659175913903786L ^ a) + var17.getMessage(), axx});
         }

         return false;
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 254 && var8 != 226 && var8 != 211 && var8 != 'i') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 165) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 228) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 254) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 226) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 211) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private boolean f(String blockId) {
      long a = 树友何何友树何友树何.a ^ 140673901234444L;
      d<"ä">(6214486850631193128L, a);
      return blockId.contains(b<"r">(29871, 7696095310515776092L ^ a)) || blockId.contains(b<"r">(30174, 1760439290858253142L ^ a));
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树友何何友树何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "-kI\u000fZ\u001b\"+\u0004\u0004P\u0006'v\u000fBX\u001b*p\u000b\t\u001b\u001d#u\u000bBG\u0011 a\u0002\u001e\u001b桥厅佐伲厧栤伡厅栔伲";
      m[1] = "^\u000e?u=#QNr~7>T\u0013y8$-Q\u0015t8;!M\f?T=#Q\u0005px\u0004-Q\u0015t";
      m[2] = "\u007fk\u000bu=0p+F~7-uvM8$>pp@8;2li\u000bX'2~`W@33i`";
      m[3] = "ihdkHzf()`Bgcu\"&Jzns&m\t|gv&&Updb/z\tWor>mUVkk/zF";
      m[4] = "lSp&\u001bFg\\aif^t[h ";
      m[5] = "\u0006\u0007 rbK\u0018\u000f:=\u001f[\u0018";
      m[6] = ",\u0005\u0012NJ&'\n\u0003\u0001!2%\u0001\u0014[\r%(";
      m[7] = "}@D:#X}@Sf/Wg\u000bG{<]w\u000b@|7B=sUw}";
      m[8] = double.class;
      n[8] = "java/lang/Double";
      m[9] = "(QeDm\u001a6Y\u007f\u000b \u0000,SfW1\n,D=D7\u0000/Yp\u000b\u0002\u001b-]zF\u0001\u0000-\\vD-";
      m[10] = "hao\u000b'wg!\"\u0000-jb|)F>ygz$F!u{co%'|nY \u0004=}";
      m[11] = "!B*[Q\r<Wry\u0010\u0000$Q";
      m[12] = " +c\u001aD] +tFHR:`tX@Q :9y@Z+-eUO@";
      m[13] = "\u0012n~\u0016aB\u0012niJmM\b%iTeN\u0012\u007f$JiE\u0018nx]~\u0005;jg]^N\u0012ooJiY";
      m[14] = "(RL\fW?!\\OE\u00142'\\[G\t4eKDPN53\u0013wGH$.EgMH=*I\u0005oU4.";
      m[15] = "\u001a\u001e{,-z\u0013\u0010xenw\u0015\u0010lgsqW\u0007sp4p\u0001_Rg&t\f\u001dbT%g\r\u0014nD/g\u0014\u0010b";
      m[16] = "P}_RIwYs\\\u001b\nz_sH\u0019\u0017|\u001ddW\u000eP}K<d\u0019VlVjt\u0013VuRf";
      m[17] = "\u0005\u0016)PR\u0019\nVd[X\u0004\u000f\u000bo\u001dP\u0019\u0002\rkV\u0013伣伳厳佒佦叶伣伳桩栖";
      m[18] = "}|J\u000e\u0013\u0015vs[Ar\u001b}x_\u001b";
      m[19] = ">\u001a_t\u0001}.\u001bA<0^\u001ainKgV\u0016e~_0{nOC5_koQ\u000b";
      m[20] = "S\tG+n\u0003D\u0016\u0002#\u000fWmG\u0001x6\u0004mwV2cHH\u0015W41\u0006";
      m[21] = "8\u001b\u0014.\u0001A?E\u0016G厰佥伉厶桫厄桪校桍厶r5NR6\n\u001ev\u0013G";
      m[22] = "?\u001dB\f\u0019@8C@e伶栠厐伮叧伸伶叺厐厰$\\\u0016\u00039I\u001e\u0007\u000e_5";
      m[23] = "*xWJ\n\u0005-&U#桡县厅叕佬佾去伡厅叕1\u001c\tC$mKE\u0001\u0016~";
      m[24] = "{^~j\nR|\u0000|\u0003去佶栎栩栁叀桡栲栎右\u0018qEAuOt2\u0018T";
      m[25] = "\u0003u>(>!\u0004+<A桕伅桶但厛伜厏桁厬变Xx1b\u0005!b#)>\t";
      m[26] = "'AW|\u000eP}\u0000T8lWL\u0001V|\\\u0000L1Q?\u000e\u0005eQ\u0011/\u001d\u0004";
      m[27] = "\u0000Y6=NM\u0007\u00074T叿号伱栮厓桍叿佩厯叴P&\u0001^\u000eH<e\\K";
      m[28] = "zQ))q?}\u000f+@佞伛叕栦桖厃叀桟叕栦Oy~||\u0005u\"f p";
      m[29] = "7ofA\f}01d(桧余桂栘參併厽余桂作\u0000ZCn9~l\u0019\u001e{";
      m[30] = "\u0012A0\u001a\"$H\u00003^@#y\u00011\u001a\u007f|y16Y\"qPQvI1p";
      m[31] = ">\r\n\naZ9S\bc叐叠伏伾桵厠叐佾桋厠lXrHo\u0011\u0014Y(I+";
      m[32] = "\u0015P\t{$P\u0012\u000e\u000b\u0012伋只伤栧桶发桏栰伤叽o++\u0013\u0013\u0004Up3O\u001f";
      m[33] = "Z`i&n-]>kO栅桍栯反双伒栅伉叵体\u000fq}.\n14.u.\\";
      m[34] = "b0#(\u0011\u001cen!A伾桼体厝优伜桺桼反伃E~\\\ti4;#\u001c\u0001?";
      m[35] = "0sq\u00165\u00117-s\u007f厄伵原叞佊伢桞桱桅叞\u0017\rz\u0002>b{N'\u0017";
      m[36] = "&:\u0018`\u0013 /i\u0019y.案桔佝桸栙样伌厎參厢\u0000Ek4`\\qL85y";
      m[37] = "\tN+@yN\u000e\u0010))佖佪伸根桔只栒佪厦根M[6]\u0007_!\u0018kH";
      m[38] = "\u001ey{k5\fQozg\rXy%)?3\ry\u0014!e6\nI+v8l\u000e";
      m[39] = "\u001dx-'T\u0000\u001a&/N佻桠伬栏厈厍栿厺伬栏KqWF\u0013m1(_\u0013I";
      m[40] = "\u000f\u0005s5\u0014p\r\u0015}{wE5R1`K \u000f\u0019<:\u0011\u001b";
      m[41] = "+N{\\@jq\u000fx\u0018\"m@\u000ez\\\u0012;@>}\u001f@?i^=\u000fS>";
      m[42] = "\bpe4\u001ba\u000f.g]伴栁厧叝佞厞桰叛桽佃\u0003f\bsYl{gRr\u001d";
      m[43] = "2\rjP/P5Sh9伀只伃桺栕栠伀栰伃桺\f\u0000 \u00134Y6[8O8";
      m[44] = "b\u0014uT89eJw=#@2\u0017kX!+2\u0014~\u0006J|c\u0002vV!|`\u0017(=";
      m[45] = "m?iPw]jak9叆叧栘伌佒佤栜栽栘厒\u000f\u0000x\u001ekk5[`Bg";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private void o(BlockPos start, Set<BlockPos> caveBlocks, Set<BlockPos> visitedBlocks, int maxSize) {
      long a = 树友何何友树何友树何.a ^ 95642147493592L;
      long ax = a ^ 98162427748392L;
      d<"ä">(-3897192781643854340L, a);
      Deque<BlockPos> queue = new ArrayDeque<>();
      queue.add(start);

      while (!queue.isEmpty() && caveBlocks.size() < 300) {
         BlockPos current = queue.poll();
         if (!visitedBlocks.contains(current)) {
            visitedBlocks.add(current);

            try {
               if (!this.v(current)) {
               }

               caveBlocks.add(current);
               Direction[] e = Direction.values();
               int var13 = e.length;
               int var14 = 0;
               if (0 < var13) {
                  Direction dir = e[0];
                  BlockPos neighbor = current.relative(dir);
                  if (Math.abs(neighbor.getX() - start.getX()) <= 50) {
                     if (Math.abs(neighbor.getZ() - start.getZ()) > 50) {
                     }

                     if (!visitedBlocks.contains(neighbor)) {
                        queue.add(neighbor);
                     }
                  }

                  var14++;
               }
            } catch (Exception var17) {
               if (d<"þ">(this, -3897722171928891038L, a).getValue()) {
                  ClientUtils.e(new Object[]{b<"r">(6123, 4282581259701212832L ^ a) + var17.getMessage(), ax});
               }
            }
            break;
         }
      }
   }

   private boolean o(BlockPos pos) {
      long a = 树友何何友树何友树何.a ^ 13936967720723L;
      long ax = a ^ 41483315028572L;
      d<"ä">(4621037917477684279L, a);
      int dx = -2;
      int dy = -1;
      int dz = -2;
      BlockPos checkPos = pos.offset(-2, -1, -2);
      Block block = 树友友何树友树树树何.o(ax, checkPos);
      if (block != null) {
         String blockId = block.getDescriptionId().toLowerCase();
         if (d<"þ">(this, 4624417203942882439L, a).getValue() && this.f(blockId)) {
            return true;
         }

         if (d<"þ">(this, 4624582062916361577L, a).getValue() && this.C(blockId)) {
            return true;
         }

         if (d<"þ">(this, 4624158647839775075L, a).getValue() && this.y(blockId)) {
            return true;
         }
      }

      dz++;
      dy++;
      dx++;
      return false;
   }

   @EventTarget
   public void p(WorldEvent event) {
      this.Z();
   }

   private Set<BlockPos> p(Set<BlockPos> caveBlocks) {
      long a = 树友何何友树何友树何.a ^ 15262896888436L;
      HashSet borderBlocks = new HashSet();
      d<"ä">(-4231632342666395312L, a);
      HashSet airBlocksSet = new HashSet<>(caveBlocks);
      Iterator var7 = caveBlocks.iterator();
      if (var7.hasNext()) {
         BlockPos pos = (BlockPos)var7.next();
         Direction[] var9 = Direction.values();
         int var10 = var9.length;
         int var11 = 0;
         if (0 < var10) {
            Direction dir = var9[0];
            BlockPos neighbor = pos.relative(dir);
            if (!airBlocksSet.contains(neighbor)) {
               borderBlocks.add(neighbor);
            }

            var11++;
         }
      }

      return borderBlocks;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 树友何何友树何友树何.a ^ 118119198509357L;
      d<"â">(this, new AtomicBoolean(false), -7629885384075198836L, a);
      this.Z();
   }

   private boolean g(Set<BlockPos> cave) {
      long a = 树友何何友树何友树何.a ^ 5638824177618L;
      long ax = a ^ 48612694266525L;
      long axx = a ^ 11663797672226L;
      d<"ä">(8133553758295586038L, a);

      try {
         if (cave.size() < d<"þ">(this, 8137013083722695965L, a).getValue().intValue()) {
            return false;
         } else if (!this.O(cave)) {
            return false;
         } else {
            Set<BlockPos> borderBlocks = this.p(cave);
            int naturalBlockCount = 0;
            int totalBlocks = 0;
            boolean hasCaveFeatures = false;

            for (BlockPos pos : borderBlocks) {
               Block block = 树友友何树友树树树何.o(ax, pos);
               if (block != null) {
                  String blockId = block.getDescriptionId().toLowerCase();
                  totalBlocks++;
                  if (this.q(blockId)) {
                     naturalBlockCount++;
                  }

                  if (this.i(blockId)) {
                     hasCaveFeatures = true;
                  }
                  break;
               }
            }

            if (totalBlocks > 0 && (double)naturalBlockCount / totalBlocks < 0.7) {
               return false;
            } else {
               double volumeToSurfaceRatio = (double)cave.size() / borderBlocks.size();
               if (volumeToSurfaceRatio > 3.0) {
                  return false;
               } else {
                  int var21 = c<"t">(20483, 6497035007994117521L ^ a);
                  int maxY = c<"t">(17836, 7225088225927473211L ^ a);
                  Iterator heightRange = cave.iterator();
                  if (heightRange.hasNext()) {
                     BlockPos posx = (BlockPos)heightRange.next();
                     var21 = Math.min(var21, posx.getY());
                     maxY = Math.max(maxY, posx.getY());
                  }

                  int heightRangex = maxY - var21 + 1;
                  if (heightRangex < 4) {
                     return false;
                  } else {
                     return hasCaveFeatures ? true : naturalBlockCount > totalBlocks * 0.8;
                  }
               }
            }
         }
      } catch (Exception var19) {
         if (d<"þ">(this, 8134294265022187624L, a).getValue()) {
            ClientUtils.e(new Object[]{b<"r">(14113, 4790888505449140088L ^ a) + var19.getMessage(), axx});
         }

         return false;
      }
   }

   private boolean v(BlockPos pos) {
      long a = 树友何何友树何友树何.a ^ 137909415466676L;
      long ax = a ^ 92891216833531L;
      long axx = a ^ 50076777096680L;
      d<"ä">(-8537056596111094384L, a);
      if (mc.level == null) {
         return false;
      } else {
         Block block = 树友友何树友树树树何.o(ax, pos);
         return block == null
            ? false
            : block instanceof AirBlock
               || block instanceof LiquidBlock && !d<"þ">(this, -8536259085870545828L, a).getValue()
               || block instanceof VineBlock
               || 友树友友何友树友树友.M(pos, axx);
      }
   }

   private void v(BufferBuilder builder, Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b, float a) {
      builder.vertex(matrix, x1, y1, z1).color(r, g, b, a).endVertex();
      builder.vertex(matrix, x2, y2, z2).color(r, g, b, a).endVertex();
   }

   private void j(BlockPos start, Set<BlockPos> shaftBlocks, Set<BlockPos> visitedBlocks, int maxSize) {
      long a = 树友何何友树何友树何.a ^ 33628749874560L;
      long ax = a ^ 18891835716464L;
      d<"ä">(1923648066916458148L, a);
      ArrayDeque queue = new ArrayDeque();
      queue.add(start);

      while (!queue.isEmpty() && shaftBlocks.size() < 300) {
         BlockPos current = (BlockPos)queue.poll();
         if (!visitedBlocks.contains(current)) {
            visitedBlocks.add(current);

            try {
               if (!this.v(current)) {
               }

               shaftBlocks.add(current);
               Direction[] e = Direction.values();
               int var13 = e.length;
               int var14 = 0;
               if (0 < var13) {
                  Direction dir = e[0];
                  BlockPos neighbor = current.relative(dir);
                  if (Math.abs(neighbor.getX() - start.getX()) <= 50) {
                     if (Math.abs(neighbor.getZ() - start.getZ()) > 50) {
                     }

                     if (!visitedBlocks.contains(neighbor)) {
                        queue.add(neighbor);
                     }
                  }

                  var14++;
               }
            } catch (Exception var17) {
               if (d<"þ">(this, 1923259401218122298L, a).getValue()) {
                  ClientUtils.e(new Object[]{b<"r">(31503, 6607666421969479975L ^ a) + var17.getMessage(), ax});
               }
            }
            break;
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean q(String blockId) {
      long a = 树友何何友树何友树何.a ^ 102210657446889L;
      d<"ä">(3808754293237952717L, a);
      return blockId.contains(b<"r">(10903, 7544730633089324795L ^ a))
         || blockId.contains(b<"r">(22164, 7360671176614505113L ^ a))
         || blockId.contains(b<"r">(5197, 953481983736621135L ^ a))
         || blockId.contains(b<"r">(22201, 285091735261244064L ^ a))
         || blockId.contains(b<"r">(10790, 9014952717067195954L ^ a))
         || blockId.contains(b<"r">(32044, 6818233004283838779L ^ a))
         || blockId.contains(b<"r">(7896, 6047840373216158354L ^ a))
         || blockId.contains(b<"r">(15645, 8612490799305425180L ^ a))
         || blockId.contains(b<"r">(6399, 6873004322081055912L ^ a))
         || blockId.contains(b<"r">(1205, 362971065369770214L ^ a))
         || blockId.contains(b<"r">(5692, 8887137937977191010L ^ a))
         || blockId.contains(b<"r">(17875, 3736879165019486606L ^ a))
         || blockId.contains(b<"r">(17034, 1050711401176727291L ^ a))
         || blockId.contains(b<"r">(8294, 3111300035993279589L ^ a))
         || blockId.contains(b<"r">(10119, 4981002172241746829L ^ a))
         || blockId.contains(b<"r">(20907, 8035764723529346542L ^ a))
         || blockId.contains(b<"r">(31791, 8487536199602290799L ^ a))
         || blockId.contains(b<"r">(17649, 5886239076067506350L ^ a))
         || blockId.contains(b<"r">(8517, 1636551816199937341L ^ a));
   }

   private boolean U(Set<BlockPos> cave) {
      long a = 树友何何友树何友树何.a ^ 35237465974665L;
      int minX = c<"t">(20483, 6497075534092891594L ^ a);
      d<"ä">(-5135487722827760467L, a);
      int maxX = c<"t">(17836, 7225056222124925024L ^ a);
      int minY = c<"t">(20483, 6497075534092891594L ^ a);
      int maxY = c<"t">(17836, 7225056222124925024L ^ a);
      int minZ = c<"t">(20483, 6497075534092891594L ^ a);
      int maxZ = c<"t">(17836, 7225056222124925024L ^ a);
      Iterator width = cave.iterator();
      if (width.hasNext()) {
         BlockPos pos = (BlockPos)width.next();
         minX = Math.min(minX, pos.getX());
         maxX = Math.max(maxX, pos.getX());
         minY = Math.min(minY, pos.getY());
         maxY = Math.max(maxY, pos.getY());
         minZ = Math.min(minZ, pos.getZ());
         maxZ = Math.max(maxZ, pos.getZ());
      }

      int widthx = maxX - minX + 1;
      int height = maxY - minY + 1;
      int length = maxZ - minZ + 1;
      int maxDim = Math.max(widthx, Math.max(height, length));
      int minDim = Math.min(widthx, Math.min(height, length));
      double linearScore = minDim > 0 ? (double)maxDim / minDim : 0.0;
      return linearScore < 3.0;
   }

   private boolean U(String blockId) {
      long a = 树友何何友树何友树何.a ^ 113744772311299L;
      d<"ä">(8516678938785968679L, a);
      return blockId.contains(b<"r">(4457, 2527118797023637471L ^ a))
         || blockId.contains(b<"r">(26050, 4374382573706550080L ^ a))
         || blockId.contains(b<"r">(27996, 1895869612685661154L ^ a))
         || blockId.contains(b<"r">(6757, 7722434609856177390L ^ a))
         || blockId.contains(b<"r">(20890, 7787526940488970009L ^ a))
         || blockId.contains(b<"r">(26982, 5766766590560966535L ^ a))
         || blockId.contains(b<"r">(22596, 7396749243709695706L ^ a))
         || blockId.contains(b<"r">(19431, 7090993386833261890L ^ a));
   }

   private boolean z(Set<BlockPos> shaft) {
      long a = 树友何何友树何友树何.a ^ 105921114472688L;
      int minX = c<"t">(13459, 8162215995467626020L ^ a);
      int maxX = c<"t">(24577, 1804751574094422706L ^ a);
      int minY = c<"t">(20483, 6497145735639700147L ^ a);
      d<"ä">(-2323200475450844204L, a);
      int maxY = c<"t">(17836, 7225126215885522713L ^ a);
      int minZ = c<"t">(20483, 6497145735639700147L ^ a);
      int maxZ = c<"t">(17836, 7225126215885522713L ^ a);
      Iterator width = shaft.iterator();
      if (width.hasNext()) {
         BlockPos pos = (BlockPos)width.next();
         minX = Math.min(minX, pos.getX());
         maxX = Math.max(maxX, pos.getX());
         minY = Math.min(minY, pos.getY());
         maxY = Math.max(maxY, pos.getY());
         minZ = Math.min(minZ, pos.getZ());
         maxZ = Math.max(maxZ, pos.getZ());
      }

      int widthx = maxX - minX + 1;
      int height = maxY - minY + 1;
      int length = maxZ - minZ + 1;
      int[] dimensions = new int[]{widthx, height, length};
      Arrays.sort(dimensions);
      double linearRatio = (double)dimensions[2] / Math.max(dimensions[0], 1);
      return linearRatio >= 2.0;
   }

   private void w(PoseStack poseStack, BufferBuilder builder, BlockPos pos, float r, float g, float b, float a, Vec3 camPos, Set<BlockPos> blocks) {
      long ax = 树友何何友树何友树何.a ^ 120921788000103L;
      float x = (float)(pos.getX() - d<"þ">(camPos, -551458630052310133L, ax));
      float y = (float)(pos.getY() - d<"þ">(camPos, -552496699991958918L, ax));
      float z = (float)(pos.getZ() - d<"þ">(camPos, -551176433455464033L, ax));
      Matrix4f matrix = poseStack.last().pose();
      boolean[] shouldRenderFace = new boolean[6];
      shouldRenderFace[0] = this.e(pos.below(), blocks);
      d<"ä">(-552437702786220989L, ax);
      shouldRenderFace[1] = this.e(pos.above(), blocks);
      shouldRenderFace[2] = this.e(pos.north(), blocks);
      shouldRenderFace[3] = this.e(pos.south(), blocks);
      shouldRenderFace[4] = this.e(pos.west(), blocks);
      shouldRenderFace[5] = this.e(pos.east(), blocks);
      if (shouldRenderFace[0]) {
         this.v(builder, matrix, x, y, z, x + 1.0F, y, z, r, g, b, a);
         this.v(builder, matrix, x, y, z, x, y, z + 1.0F, r, g, b, a);
         this.v(builder, matrix, x + 1.0F, y, z, x + 1.0F, y, z + 1.0F, r, g, b, a);
         this.v(builder, matrix, x, y, z + 1.0F, x + 1.0F, y, z + 1.0F, r, g, b, a);
      }

      if (shouldRenderFace[1]) {
         this.v(builder, matrix, x, y + 1.0F, z, x + 1.0F, y + 1.0F, z, r, g, b, a);
         this.v(builder, matrix, x, y + 1.0F, z, x, y + 1.0F, z + 1.0F, r, g, b, a);
         this.v(builder, matrix, x + 1.0F, y + 1.0F, z, x + 1.0F, y + 1.0F, z + 1.0F, r, g, b, a);
         this.v(builder, matrix, x, y + 1.0F, z + 1.0F, x + 1.0F, y + 1.0F, z + 1.0F, r, g, b, a);
      }

      if (shouldRenderFace[2] || shouldRenderFace[4]) {
         this.v(builder, matrix, x, y, z, x, y + 1.0F, z, r, g, b, a);
      }

      if (shouldRenderFace[2] || shouldRenderFace[5]) {
         this.v(builder, matrix, x + 1.0F, y, z, x + 1.0F, y + 1.0F, z, r, g, b, a);
      }

      if (shouldRenderFace[3] || shouldRenderFace[4]) {
         this.v(builder, matrix, x, y, z + 1.0F, x, y + 1.0F, z + 1.0F, r, g, b, a);
      }

      if (shouldRenderFace[3] || shouldRenderFace[5]) {
         this.v(builder, matrix, x + 1.0F, y, z + 1.0F, x + 1.0F, y + 1.0F, z + 1.0F, r, g, b, a);
      }
   }

   @EventTarget
   public void u(Render3DEvent event) {
      long a = 树友何何友树何友树何.a ^ 76019086887952L;
      long ax = a ^ 75188772710912L;
      d<"ä">(5990473667479820084L, a);
      if (!this.w(new Object[]{ax})) {
         Camera camera = d<"þ">(mc, 5990337444585571314L, a).getMainCamera();
         Vec3 camPos = camera.getPosition();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableDepthTest();
         RenderSystem.lineWidth(d<"þ">(this, 5990548984307399049L, a).getValue().floatValue());
         if (d<"þ">(this, 5990077187791981779L, a).getValue()) {
            if ((
                  d<"þ">(this, 5990001839502994601L, a).C(b<"r">(20662, 8808390239235803946L ^ a))
                     || d<"þ">(this, 5990001839502994601L, a).C(b<"r">(22434, 3528540082347281431L ^ a))
               )
               && !d<"þ">(this, 5994183802211186419L, a).isEmpty()) {
               this.N(event.poseStack(), camPos, d<"þ">(this, 5994183802211186419L, a), d<"þ">(this, 5993606921658505790L, a));
            }

            if ((
                  d<"þ">(this, 5990001839502994601L, a).C(b<"r">(1285, 5661284352371580644L ^ a))
                     || d<"þ">(this, 5990001839502994601L, a).C(b<"r">(24961, 4237058826267638305L ^ a))
               )
               && !d<"þ">(this, 5990625208664156983L, a).isEmpty()) {
               this.N(event.poseStack(), camPos, d<"þ">(this, 5990625208664156983L, a), d<"þ">(this, 5990233990987042389L, a));
            }
         }

         RenderSystem.disableBlend();
         RenderSystem.enableDepthTest();
      }
   }

   private boolean y(String blockId) {
      long a = 树友何何友树何友树何.a ^ 37717498066491L;
      d<"ä">(2956920338187693343L, a);
      return blockId.contains(b<"r">(4313, 319837082415640950L ^ a)) || blockId.contains(b<"r">(19057, 8271388549348682673L ^ a));
   }

   private boolean y(Set<BlockPos> potentialCave) {
      long a = 树友何何友树何友树何.a ^ 24768196186571L;
      long ax = a ^ 69890556439684L;
      long axx = a ^ 27752452450107L;
      d<"ä">(-3532753217172157713L, a);

      try {
         if (!this.g(potentialCave)) {
            return false;
         } else {
            Set<BlockPos> borderBlocks = this.p(potentialCave);
            int naturalFeatureScore = 0;
            int artificialFeatureScore = 0;

            for (BlockPos borderPos : borderBlocks) {
               Block block = 树友友何树友树树树何.o(ax, borderPos);
               if (block != null) {
                  String blockId = block.getDescriptionId().toLowerCase();
                  if (this.q(blockId)) {
                     naturalFeatureScore++;
                  }

                  if (this.U(blockId)) {
                     artificialFeatureScore++;
                  }
                  break;
               }
            }

            boolean hasIrregularShape = this.U(potentialCave);
            return naturalFeatureScore > artificialFeatureScore && hasIrregularShape;
         }
      } catch (Exception var16) {
         if (d<"þ">(this, -3532015974369675663L, a).getValue()) {
            ClientUtils.e(new Object[]{b<"r">(25070, 533607628740274092L ^ a) + var16.getMessage(), axx});
         }

         return false;
      }
   }

   private boolean A(String blockId) {
      long a = 树友何何友树何友树何.a ^ 90548376631436L;
      d<"ä">(2863840170481689512L, a);
      return this.C(blockId)
         || this.f(blockId)
         || this.y(blockId)
         || blockId.contains(b<"r">(24013, 7288894986083037925L ^ a))
         || blockId.contains(b<"r">(11954, 5538574752241418656L ^ a))
         || blockId.contains(b<"r">(18500, 5913778785216882554L ^ a))
         || blockId.contains(b<"r">(2560, 6629041695843951907L ^ a));
   }

   private void X() {
      long a = 树友何何友树何友树何.a ^ 91141117601991L;
      long ax = a ^ 91970874461911L;
      long axx = a ^ 102663230889527L;
      d<"ä">(-5191128886092712989L, a);
      if (!this.w(new Object[]{ax})) {
         int range = d<"þ">(this, -5190262503716426360L, a).getValue().intValue();
         int vRange = d<"þ">(this, -5190607776939520697L, a).getValue().intValue();
         int playerX = (int)mc.player.getX();
         int playerY = (int)mc.player.getY();
         int playerZ = (int)mc.player.getZ();
         int minY = Math.max(playerY - vRange, mc.level.getMinBuildHeight());
         int maxY = Math.min(playerY + vRange, mc.level.getMaxBuildHeight());
         Set<BlockPos> visitedBlocks = new HashSet<>();
         int rangeSquared = range * range;
         int x = playerX - range;
         if (x <= playerX + range) {
            int z = playerZ - range;
            if (z <= playerZ + range) {
               int dx = x - playerX;
               int dz = z - playerZ;
               if (dx * dx + dz * dz <= rangeSquared) {
                  int y = minY;
                  if (minY <= maxY) {
                     try {
                        BlockPos pos = new BlockPos(x, y, z);
                        if (visitedBlocks.contains(pos)) {
                        }

                        if (this.v(pos)) {
                           Set<BlockPos> potentialCaveBlocks = new HashSet<>();
                           this.o(pos, potentialCaveBlocks, visitedBlocks, 300);
                           int minSize = d<"þ">(this, -5190067011315334648L, a).getValue().intValue();
                           if (potentialCaveBlocks.size() >= minSize && this.y(potentialCaveBlocks)) {
                              d<"þ">(this, -5190247184852233692L, a).addAll(potentialCaveBlocks);
                           }
                        }
                     } catch (Exception var29) {
                        if (d<"þ">(this, -5190532376210845827L, a).getValue()) {
                           String axxx = var29.getMessage();
                           ClientUtils.e(
                              new Object[]{
                                 b<"r">(2979, 3215190081040921751L ^ a) + x + "," + minY + "," + z + b<"r">(11796, 7325231476007047486L ^ a) + axxx, axx
                              }
                           );
                        }
                     }

                     y = minY + 3;
                  }
               }

               z += 5;
            }

            x += 5;
         }

         if (d<"þ">(this, -5190532376210845827L, a).getValue()) {
            ClientUtils.e(
               new Object[]{
                  b<"r">(7706, 1045982480683475237L ^ a) + d<"þ">(this, -5190247184852233692L, a).size() + b<"r">(19957, 7486299289391493788L ^ a), axx
               }
            );
         }
      }
   }

   private void N(PoseStack poseStack, Vec3 camPos, Set<BlockPos> blocks, Color color) {
      long a = 树友何何友树何友树何.a ^ 53515147793449L;
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      BufferBuilder builder = Tesselator.getInstance().getBuilder();
      builder.begin(d<"Ó">(798804655472940081L, a), d<"Ó">(798278091403395502L, a));
      float alpha = d<"þ">(this, 800026465097548606L, a).getValue().floatValue() / 255.0F;
      d<"ä">(800239439111720717L, a);
      float r = color.getRed() / 255.0F;
      float g = color.getGreen() / 255.0F;
      float b = color.getBlue() / 255.0F;
      Iterator var13 = blocks.iterator();
      if (var13.hasNext()) {
         BlockPos pos = (BlockPos)var13.next();
         this.w(poseStack, builder, pos, r, g, b, alpha, camPos, blocks);
      }

      BufferUploader.drawWithShader(builder.end());
   }

   private boolean O(Set<BlockPos> cave) {
      long a = 树友何何友树何友树何.a ^ 57315345351885L;
      d<"ä">(2017332311754809321L, a);
      if (cave.isEmpty()) {
         return true;
      } else {
         Set<BlockPos> visited = new HashSet<>();
         Queue<BlockPos> queue = new LinkedList<>();
         BlockPos start = cave.iterator().next();
         queue.add(start);
         visited.add(start);
         if (!queue.isEmpty()) {
            BlockPos current = queue.poll();
            Direction[] var9 = Direction.values();
            int var10 = var9.length;
            int var11 = 0;
            if (0 < var10) {
               Direction dir = var9[0];
               BlockPos neighbor = current.relative(dir);
               if (cave.contains(neighbor) && !visited.contains(neighbor)) {
                  visited.add(neighbor);
                  queue.add(neighbor);
               }

               var11++;
            }
         }

         return visited.size() == cave.size();
      }
   }

   private static String HE_DA_WEI() {
      return "刘凤楠230622109211173513";
   }
}
