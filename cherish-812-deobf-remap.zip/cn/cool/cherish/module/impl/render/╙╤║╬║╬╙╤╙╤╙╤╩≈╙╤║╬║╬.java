package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;

public class 友何何友友友树友何何 extends Module implements 何树友 {
   private final ModeValue 友友何友友何友树友何;
   private final ModeValue 何何树友何友何树友树;
   private final NumberValue 友友友友友友友何树友;
   private final BooleanValue 树友树何树树树树友友;
   private final NumberValue 何友友树何树何友何友;
   private final NumberValue 友友树树何树友何友树;
   private long 友何何何何树树友何友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[23];
   private static final String[] n = new String[23];
   private static String HE_JIAN_GUO;

   public 友何何友友友树友何何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/render/友何何友友友树友何何.a J
      // 003: ldc2_w 80144948899713
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 29624
      // 00c: ldc2_w 5536991962011546734
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 12693
      // 019: ldc2_w 3828184990449694285
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w 8581153931209026261
      // 026: lload 1
      // 027: invokedynamic õ (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/ModeValue
      // 033: dup
      // 034: sipush 5766
      // 037: ldc2_w 2672024850325950790
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 5983
      // 044: ldc2_w 5406198969995579532
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 2
      // 04f: anewarray 74
      // 052: dup
      // 053: bipush 0
      // 054: sipush 7913
      // 057: ldc2_w 6587193797687531835
      // 05a: lload 1
      // 05b: lxor
      // 05c: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 061: aastore
      // 062: dup
      // 063: bipush 1
      // 064: sipush 17191
      // 067: ldc2_w 9219603532472583410
      // 06a: lload 1
      // 06b: lxor
      // 06c: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 071: aastore
      // 072: sipush 18889
      // 075: ldc2_w 1854260800944279056
      // 078: lload 1
      // 079: lxor
      // 07a: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07f: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 082: putfield cn/cool/cherish/module/impl/render/友何何友友友树友何何.友友何友友何友树友何 Lcn/cool/cherish/value/impl/ModeValue;
      // 085: aload 0
      // 086: new cn/cool/cherish/value/impl/ModeValue
      // 089: dup
      // 08a: sipush 15777
      // 08d: ldc2_w 4432710491982559868
      // 090: lload 1
      // 091: lxor
      // 092: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 097: sipush 3780
      // 09a: ldc2_w 2259147745382091032
      // 09d: lload 1
      // 09e: lxor
      // 09f: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a4: bipush 2
      // 0a5: anewarray 74
      // 0a8: dup
      // 0a9: bipush 0
      // 0aa: sipush 32115
      // 0ad: ldc2_w 890985751266245293
      // 0b0: lload 1
      // 0b1: lxor
      // 0b2: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b7: aastore
      // 0b8: dup
      // 0b9: bipush 1
      // 0ba: sipush 26418
      // 0bd: ldc2_w 5410638234667753712
      // 0c0: lload 1
      // 0c1: lxor
      // 0c2: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c7: aastore
      // 0c8: sipush 13375
      // 0cb: ldc2_w 9089560488948298735
      // 0ce: lload 1
      // 0cf: lxor
      // 0d0: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d5: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 0d8: putfield cn/cool/cherish/module/impl/render/友何何友友友树友何何.何何树友何友何树友树 Lcn/cool/cherish/value/impl/ModeValue;
      // 0db: aload 0
      // 0dc: new cn/cool/cherish/value/impl/NumberValue
      // 0df: dup
      // 0e0: sipush 12655
      // 0e3: ldc2_w 1055883154844677804
      // 0e6: lload 1
      // 0e7: lxor
      // 0e8: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ed: sipush 2836
      // 0f0: ldc2_w 5676149863998704846
      // 0f3: lload 1
      // 0f4: lxor
      // 0f5: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0fa: ldc2_w 24.0
      // 0fd: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 100: dconst_1
      // 101: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 104: ldc2_w 24.0
      // 107: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 10a: dconst_1
      // 10b: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 10e: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 111: putfield cn/cool/cherish/module/impl/render/友何何友友友树友何何.友友友友友友友何树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 114: aload 0
      // 115: new cn/cool/cherish/value/impl/BooleanValue
      // 118: dup
      // 119: sipush 8642
      // 11c: ldc2_w 859975249424901657
      // 11f: lload 1
      // 120: lxor
      // 121: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 126: sipush 6175
      // 129: ldc2_w 317822476062154696
      // 12c: lload 1
      // 12d: lxor
      // 12e: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 133: bipush 0
      // 134: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 137: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 13a: putfield cn/cool/cherish/module/impl/render/友何何友友友树友何何.树友树何树树树树友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 13d: aload 0
      // 13e: new cn/cool/cherish/value/impl/NumberValue
      // 141: dup
      // 142: sipush 27631
      // 145: ldc2_w 6953623629716401211
      // 148: lload 1
      // 149: lxor
      // 14a: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14f: sipush 1168
      // 152: ldc2_w 1182631180325897041
      // 155: lload 1
      // 156: lxor
      // 157: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 15c: ldc2_w 24000.0
      // 15f: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 162: dconst_0
      // 163: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 166: ldc2_w 24000.0
      // 169: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 16c: ldc2_w 100.0
      // 16f: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 172: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 175: putfield cn/cool/cherish/module/impl/render/友何何友友友树友何何.何友友树何树何友何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 178: aload 0
      // 179: new cn/cool/cherish/value/impl/NumberValue
      // 17c: dup
      // 17d: sipush 8177
      // 180: ldc2_w 6287735501216995374
      // 183: lload 1
      // 184: lxor
      // 185: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 18a: sipush 11369
      // 18d: ldc2_w 6146178125346401208
      // 190: lload 1
      // 191: lxor
      // 192: invokedynamic d (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 197: ldc2_w 0.1
      // 19a: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 19d: ldc2_w 0.1
      // 1a0: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1a3: ldc2_w 0.5
      // 1a6: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1a9: ldc2_w 0.05
      // 1ac: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1af: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1b2: putfield cn/cool/cherish/module/impl/render/友何何友友友树友何何.友友树树何树友何友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 1b5: aload 0
      // 1b6: lconst_0
      // 1b7: ldc2_w 8581100701051161116
      // 1ba: lload 1
      // 1bb: invokedynamic N (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/render/友何何友友友树友何何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c0: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8361765478097645583L, -6631302896836186739L, MethodHandles.lookup().lookupClass()).a(81082836315632L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 45043797871111L;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[20];
      int var18 = 0;
      String var17 = "Ü\u0083\u0084D\u000fô\u008bû\u0080ZÀ\u009e*\u0092øQ\u0018\u0004ÊßOoßxÇ:ôqÂV\u0004ê´a\u000e\bÂ¶\u0085\\!\u0010oË=§\u0093Ñ®\u0014%FÍåj(\u008eP\u0018®\u0003\u009a\u009c¿ªHb}\u0083;<`\\\u0010*ô_ÿ;SFå\u0015 \u0080ã3µg\u0003\u009cÒNj0±b\u0005\u0080O\u0097{Í¾¯·\u0015\u008e\u008e<eU\u001e\u0080\u0007Ô\u0018\u0085¢,\u009a[ÿ\r\u009f¬ï^2\u009b¯B\u0017n\u0013\f¤ ËêQ\u0018n©÷Ø\u008d´*ý\u0002\u0099\u008b\u0088\u008dT\u0017L«\u001eWÃdBØØ\u0010ª#yÅ ÆöØ¾\u0011$\u000e\u0010 ¤U \u0002\u0096÷ \u00146\u001dY#:OßÇ½b\u0094\u0003Y\u0012¾Èþokl\u009d\u0006²\u001bCu\u009f Çé\u009cW¸ýÀøJç·lÙËèmò8\u0099P\u0084Á3\u008e\u0019jº\u0085÷\u00adðD\u0018Ô «.w\u0096×LÍ\u0017Íá\u0002wá-\u0004»)à\u0006²KD\u0010sÞ¡Þd\u0003£°\u0006¤!Ð»£«>\u0010p¸ê>ád\u00ad\u0090ý<ÅëÉëýs _Ï×\u0085¯ààjÅ¶?U\u001fÉjt\u0012N,t\u0010î\u0005á\u001f½yt[\u001cÇ\u008f ´Çè\u00929¦F¿\u0097WÙ\u009d¤ócî\u0005$ÅáØÃ¯;½38£ÕpàÆ\u0018í\u0018z\b\u0098\u001d\u007f\rytÏ\u008bG÷ØÆQ\u0096?5ò2\u0095q\u0010\u0086K]k·´òuÕ©«\\rõQ\u0007 \u0089Ä\u00807á\u0007½ÜI 3W\u000bwä.¨ï÷Ç6\u008fÙ\u000eÁq³ê\u0017\u0005)Ã";
      short var19 = 449;
      char var16 = 16;
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[20];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0096Å_Ñãh{Q¡\u009cïP¦&þQG\u008dªæC\u0006i½".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 24);

                     j = var6;
                     k = new Long[3];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "]û æ\u00191\u0099GpÆ¢\u001b#¯\u001dä\u0098\u0013G$¯Û\u0086©´cxzA\u009bP3\u0018\u0010\u001f¬\u008cÛ\býx%mµU¬þ¼qC5#\u0017`\u00060\u000e";
                  var19 = 57;
                  var16 = ' ';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 17;
               case 1 -> 35;
               case 2 -> 9;
               case 3 -> 5;
               case 4 -> 30;
               case 5 -> 41;
               case 6 -> 3;
               case 7 -> 24;
               case 8 -> 38;
               case 9 -> 22;
               case 10 -> 51;
               case 11 -> 52;
               case 12 -> 8;
               case 13 -> 59;
               case 14 -> 19;
               case 15 -> 26;
               case 16 -> 45;
               case 17 -> 11;
               case 18 -> 32;
               case 19 -> 36;
               case 20 -> 46;
               case 21 -> 31;
               case 22 -> 15;
               case 23 -> 13;
               case 24 -> 33;
               case 25 -> 2;
               case 26 -> 62;
               case 27 -> 56;
               case 28 -> 61;
               case 29 -> 63;
               case 30 -> 23;
               case 31 -> 54;
               case 32 -> 18;
               case 33 -> 20;
               case 34 -> 44;
               case 35 -> 25;
               case 36 -> 60;
               case 37 -> 50;
               case 38 -> 7;
               case 39 -> 43;
               case 40 -> 37;
               case 41 -> 53;
               case 42 -> 47;
               case 43 -> 27;
               case 44 -> 10;
               case 45 -> 4;
               case 46 -> 0;
               case 47 -> 1;
               case 48 -> 42;
               case 49 -> 34;
               case 50 -> 49;
               case 51 -> 16;
               case 52 -> 58;
               case 53 -> 12;
               case 54 -> 29;
               case 55 -> 39;
               case 56 -> 48;
               case 57 -> 57;
               case 58 -> 14;
               case 59 -> 55;
               case 60 -> 40;
               case 61 -> 28;
               case 62 -> 21;
               default -> 6;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友友友树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12480;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友友友树友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友友友树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @EventTarget
   public void c(PacketEvent event) {
      long var10000 = 友何何友友友树友何何.a ^ 46575768164119L;
      Packet<?> packet = event.getPacket();
      if (packet instanceof ClientboundSetTimePacket) {
         event.setCancelled(true);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'Z' && var8 != 'N' && var8 != 245 && var8 != 217) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 241) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'n') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'Z') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'N') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 245) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20819;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友友友树友何何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友友友树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      m[0] = "~a\u0000FZ^q!MMPCt|F\u000bX^yzB@\u001bXp\u007fB\u000bGTskKW\u001b叺佈佚句叮叾栠取佚佻";
      m[1] = "r<)A\u001aMy38\u000efTv)6MQd`>:P@Hw3";
      m[2] = "ygR\\\u00191v'\u001fW\u0013,sz\u0014\u0011\u0000?v|\u0019\u0011\u001f3jeRq\u00033xl\u000ei\u00172ol";
      m[3] = "s\u001be\u000el\u0006|[(\u0005f\u001by\u0006#Cu\b|\u0000.Cj\u0004`\u0019e l\ru#*\u0001v\f";
      m[4] = "`\u001bm,\u000e\u0019`\u001bzp\u0002\u0016zPzn\n\u0015`\n7o\u0016\u001cz\u0017in\u0002\tk\f7A\u000f\u0019k\u0010mN\u0006\u0006k\u0012";
      m[5] = float.class;
      n[5] = "java/lang/Float";
      m[6] = "i\u000f\u0018\r)\u0018fOU\u0006#\u0005c\u0012^@+\u0018n\u0014Z\u000bh\u001eg\u0011Z@4\u0012d\u0005S\u001ch5o\u0015B\u000b44k\fS\u001c'";
      m[7] = "hh.v2\u0002cg?9O\u001ap`6p";
      m[8] = long.class;
      n[8] = "java/lang/Long";
      m[9] = "p-(,0w\u007fme':jz0na)y\u007f6ca6uc/(\r0w\u007f&g!\ty\u007f6c";
      m[10] = "\no5!\u0010\u000f\u0005/x*\u001a\u0012\u0000rsl\u0012\u000f\rtw'Q伵似及低众厴伵似栐栊";
      m[11] = "\u007fQm92vt^|vSx\u007fUx,";
      m[12] = "/o$?D\u001a9v%OAvrn!7CK$9-\u007f(O!o2$\u0015\u0019vczO";
      m[13] = "\u00125\u001e\u0002\u000b\t\u0004,\u001fr伺厦厵桇伭桫伺厦伫厝pK\u0007\u001bL7JJ\n\\H";
      m[14] = ";:B\u0017*,-#Cg伛伝框厒佱厤伛桙厜案,]-90jJ\u0005y#a";
      m[15] = "\u0004_\u0016-l\fAG\u000f#\tl8\n\u001e=4[\\H\f6x2";
      m[16] = "(\u0017x\u000bR\u001d-Wu\t)格栎佺栅桲栰佸叔古叟k\u0016\u0015sGgS\u0013U~E";
      m[17] = "\u007f\u00145c&2i\r4\u0013厉伃但伢伆栊桓厝但厼[-s!'N#t*g+";
      m[18] = "Ne\t\b\u0003^X|\bx厬叱佷反厤伥厬栫叩体gB\u0004KE5\u0001\u001aPQ\u0014";
      m[19] = "Xp`,MnNia\\叢叁栥栂体桅叢佟叿栂\u000eeA|\u0006r4dL;\u0002";
      m[20] = "#%D/VN5<E_栣叡桞伓栳框栣栻厄厍*aSL.q@b[[=";
      m[21] = "K0<)!0\u0015#;mE`&}`o~>&Ae7;r\b{n3.h";
      m[22] = "U\t.}==C\u0010/\r厒厒史厡厃収厒伌栨厡@41/\u000b\u000bz5<h\u000f";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 友何何友友友树友何何.a ^ 91631038647942L;
      d<"N">(this, 0L, -7633273517219943653L, a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void R(TickEvent event) {
      long a = 友何何友友友树友何何.a ^ 135640419886336L;
      long ax = a ^ 72738138637499L;
      d<"n">(-4787179583406327205L, a);
      if (!this.w(new Object[]{ax})) {
         if (d<"Z">(this, -4785117157825083347L, a).C(b<"d">(18889, 1854247087043626129L ^ a))) {
            mc.level.setDayTime(d<"Z">(this, -4787306766154813648L, a).getValue().longValue());
         }

         mc.level.setDayTime(d<"Z">(this, -4785353714942852963L, a));
         d<"N">(
            this,
            d<"Z">(this, -4785353714942852963L, a)
               + (
                     d<"Z">(this, -4785506814861105346L, a).getValue()
                        ? -d<"Z">(this, -4785414295210542435L, a).getValue().longValue()
                        : d<"Z">(this, -4785414295210542435L, a).getValue().longValue()
                  )
                  * c<"z">(13420, 6902476404423022764L ^ a),
            -4785353714942852963L,
            a
         );
         if (d<"Z">(this, -4785353714942852963L, a) > c<"z">(28045, 8625445069611139404L ^ a)) {
            d<"N">(this, 0L, -4785353714942852963L, a);
         }

         if (d<"Z">(this, -4785353714942852963L, a) < 0L) {
            d<"N">(this, c<"z">(19958, 6215843833205170484L ^ a), -4785353714942852963L, a);
         }

         if (d<"Z">(this, -4787067871185842993L, a).C(b<"d">(13375, 9089575362216507758L ^ a))) {
            d<"N">(mc.level, 0.0F, -4785593187870633598L, a);
         }

         d<"N">(mc.level, d<"Z">(this, -4785159648108456542L, a).getValue().floatValue(), -4785593187870633598L, a);
      }
   }

   private static String HE_SHU_YOU() {
      return "何大伟230622198107200054";
   }
}
