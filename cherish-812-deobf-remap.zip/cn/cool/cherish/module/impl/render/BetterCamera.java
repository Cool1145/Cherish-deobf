package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class BetterCamera extends Module implements 何树友 {
   public final BooleanValue motionCamera = new BooleanValue("Motion Camera", "动态相机", true);
   public final NumberValue interpolation = new NumberValue("Motion Interpolation", "动态插值", 0.15, 0.01, 0.35, 0.01).A(this.motionCamera::getValue);
   public final BooleanValue noHurtShake = new BooleanValue("No Hurt Shake", "无伤害抖动", true);
   public final BooleanValue noClip = new BooleanValue("No Clip", "穿墙模式", true);
   public final NumberValue cameraDistance = new NumberValue("No Clip 3rd Camera Distance", "穿墙第三人称距离", 4, 0.1, 10, 0.1).A(this.noClip::getValue);
   public final BooleanValue keepFov = new BooleanValue("Keep Fov", "保持视场角", true);
   public final NumberValue fovValue = new NumberValue("Fov", "视场角值", 1.1, 0.0, 2.0, 0.01).A(this.keepFov::getValue);
   public final BooleanValue noFog = new BooleanValue("No Fog", "无雾效", true);
   public final BooleanValue noFire = new BooleanValue("No Fire", "无火焰", true);
   public static BetterCamera instance;
   private static String 友友友何何树友树何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[12];
   private static final String[] k = new String[12];
   private static String HE_JIAN_GUO;

   public BetterCamera() {
      super("BetterCamera", "更好的相机", 树何友友何树友友何何.友友树树何友树树友树);
      instance = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8229590930750792830L, 3639699333494145639L, MethodHandles.lookup().lookupClass()).a(197339812087384L);
      // $VF: monitorexit
      a = var10000;
      a();
      E("R6yOKc");
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(87612182606876L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[20];
      int var5 = 0;
      String var4 = "Ü)Ý\\Õç\u0004\u008d\u001cß`P\u008a´)Ù0å¥´\u008fIDÒ¦t\u0090<ï\u0085Yf\u0013)Á)øQ\u001a8µ\u000f¾Þ¯\u0096^%õÉdt\u00ad\u0084\u009bhÚß|BU\"Q(#\u0010Ç\u0097\u0015Ò©\u0086Ø\u009dmÿ$Y\u0018O¬Ó ;ºqÁå\u000b&¡\u0092~\u00adÊi\u0007×\u00adÀÿËæ\u0099EDÍ8\u0087V\u007f\u009byó/\u0010%\u009d;axk÷\u0000\u0080\u008c\u0016\u0018H0§Ä LR\u0097ZAKj\u001f¡½*:oLÈ\u007f\u0086\u0013\u0003\u0005Ú\u0093Åoi\u0087ùäm\u0083\u0094õ\u0018\u008dØ¹<\u0007\u00041I:klX7»\u0001¸¾Âu\u009b\u00065OB \u0094ä\t]@\u0097\u0007hì,\u008a\u0005z\u0015ù¿\u001dè¨\u008b\u00adjv\u0003®GòªÔBSô za{e¼\u0015oÅn³\u000eÒÎ÷\tó÷5Ü\u0007\u0017.R\u0010[(t°áXB` ~pøÙ¢Û0\u0084\u0091\u0016³°p\t \u0002»wp\u001e?\u000f;\u0007\u0087Z\u0000¾ÖÂYk0\u0093º^\u0097ïµF13°\u0088Æ\u001fL\u0097ú´¹+)ùÊ\u000fÊ§bz8\u008b°\u0006KD²z>ª©ó\u009c3\u0016\u0090¸7ÓZÊ -oCÔü\u001c\u0089FZ\u001e\u00032\u009fO\u0099yL\u0004.îÜÏ\u0006\u008a¯gàvbNë\u0098 â\u008bÎ)\u0090À.\u001añ\u0086)\u009cí\u0085\u00966u±\bH!Mõ\u0017oÈ\u0095\u008a\u0083 FW\u0010N\u009d»\u0019à¾C¶PE\u00adf\u00adÔ\u009ds Wm\u001brj\u0081\u0087õM\u0094\u008aË\u009dø}öÎDp\u0016Ó\u0000p\u0082å\u0013\u001a\u0099\u0000ü¾'\u0018Ó\\K£Ú¿³<*h\u00adèòr¯D½Ü\u007f;¢\\\bå8\u00ad\f\u0087â\u0003m\u000byÖkù\u009a\u0012\u0082\tî²*\bÜð\u0090\u0089R(áK¸WK\n.c3]£DÎ\u0015¨ÑbxÈÃÅ\u009a\u0013Ê\u0089\u009fx\u008f\r&ë\u0018s¨{F¡L9`\u001f\u009bÓU&CÓ7ñá»j6r\u007f¸";
      short var6 = 561;
      char var3 = 16;
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = c(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     c = var7;
                     h = new String[20];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "m\u009d\u0018IA?¥'«×²F\u008f¾ÛÅ\u0003\u0089c\u0084¦t§æÑ\u008f\u0004?v#Kã \u0096&\u0000\u008f\u000fÇ\u009fÜ\u0007\tz\u001eö\u0097×>þ\b½\u008a\u0000\u0015n\bX\u0019\u0019Ô*0\u0094;";
                  var6 = 65;
                  var3 = ' ';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public static String e() {
      return 友友友何何树友树何何;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 27;
               case 1 -> 35;
               case 2 -> 53;
               case 3 -> 18;
               case 4 -> 24;
               case 5 -> 37;
               case 6 -> 48;
               case 7 -> 21;
               case 8 -> 1;
               case 9 -> 52;
               case 10 -> 58;
               case 11 -> 38;
               case 12 -> 4;
               case 13 -> 33;
               case 14 -> 22;
               case 15 -> 40;
               case 16 -> 62;
               case 17 -> 39;
               case 18 -> 36;
               case 19 -> 13;
               case 20 -> 10;
               case 21 -> 26;
               case 22 -> 5;
               case 23 -> 60;
               case 24 -> 34;
               case 25 -> 57;
               case 26 -> 61;
               case 27 -> 12;
               case 28 -> 23;
               case 29 -> 20;
               case 30 -> 41;
               case 31 -> 43;
               case 32 -> 56;
               case 33 -> 3;
               case 34 -> 9;
               case 35 -> 15;
               case 36 -> 42;
               case 37 -> 28;
               case 38 -> 63;
               case 39 -> 7;
               case 40 -> 19;
               case 41 -> 29;
               case 42 -> 25;
               case 43 -> 17;
               case 44 -> 45;
               case 45 -> 8;
               case 46 -> 55;
               case 47 -> 59;
               case 48 -> 31;
               case 49 -> 30;
               case 50 -> 11;
               case 51 -> 32;
               case 52 -> 16;
               case 53 -> 50;
               case 54 -> 51;
               case 55 -> 46;
               case 56 -> 0;
               case 57 -> 2;
               case 58 -> 14;
               case 59 -> 49;
               case 60 -> 44;
               case 61 -> 6;
               case 62 -> 54;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/BetterCamera" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 32696;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/BetterCamera", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[H\u0097\u00ad\u0015?\u0082\u0000Ù, \u0087îË5ÿ\u0086.\u0099³ºd²õY=ßr\u0083ÉQÅ3²Ñ, QàäP-\u001e\u0006B, ¤,s5\u008dÛb¥É´\u000fâÏ â\u0005, \u0081ÀÙ\u0012ñ2Î7, ¼\u009ci\u0004ªòbDUüD÷Ö>Ë\u0088, \u001c°Ü\u0085Á1ª\u0013z³df\u0013\u0014v[,")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/BetterCamera" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'k' && var8 != 'w' && var8 != 'e' && var8 != 239) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 228) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 251) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'k') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'w') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'e') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "#6fN}y,v+Ewd)+ \u0003\u007fy$-$H<\u007f-($\u0003`s.<-_<T%,<H`U!5-_s";
      j[1] = "\u000f*K0W\u001c\u0000j\u0006;]\u0001\u00057\r}N\u0012\u00001\u0000}Q\u001e\u001c(K\u0011W\u001c\u0000!\u0004=n\u0012\u00001\u0000";
      j[2] = "OO1\"\b\u0016@\u000f|)\u0002\u000bERwo\n\u0016HTs$I桨佹只叔伔桶厲叧佴佊";
      j[3] = "Q;2\u0001MKZ4#N0SI3*\u0007";
      j[4] = void.class;
      k[4] = "java/lang/Void";
      j[5] = ",gs h\u0018'hbo\t\u0016,cf5";
      j[6] = "S\u001d\u0012.\baU\\RO\u0012zCM\u000e)<tZA\u0013&w$TI\u0000\u007fJpPP\u0000";
      j[7] = "JbGRf\u0017L#\u00073x\r]/UUr\u0006&?\rHx\u0014Z9L\b";
      j[8] = "?,P\u0002C89m\u0010cZ#\u0018yJ\u001b<}8xBS\u0001)<aB";
      j[9] = "\u0004RN\"\t`\u0002\u0013\u000eC\u0015q\u0005\u001b{$\b\u001cQ\bP*F!\u0005\fI*";
      j[10] = "\u0016~[\u0005\u0011\u001c\u0010?\u001bd#`@-J\u0005\u0003PA=P\u0014nZ\u0007 O[^\u0011\u0014)_d";
      j[11] = "46`es9g)sj\u001e厘収案栛佈叝桂栔厒栛\u0015'<o!owt#|.";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void E(String var0) {
      友友友何何树友树何何 = var0;
   }

   private static String HE_SHU_YOU() {
      return "何炜霖大狗叫";
   }
}
