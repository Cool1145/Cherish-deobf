package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.树何树树何树何何树何;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Matrix4f;
import why.tree.friend.antileak.Fucker;

public class 树何树友树何何友树何 extends Module implements 何树友 {
   private final Map<树何树友树何何友树何.树何友何友友何友何何, BlockState> 树何树树何友何树友友;
   private final List<BlockPos> 树友何友何友友树树树;
   private final List<BlockPos> 友何友何树树友树友友;
   private final Map<Block, Color> 何树何树树友友树树树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[49];
   private static final String[] k = new String[49];
   private static String HE_DA_WEI;

   public 树何树友树何何友树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/render/树何树友树何何友树何.a J
      // 03: ldc2_w 124498150314052
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 21860
      // 0c: ldc2_w 8148388425204597957
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 11233
      // 19: ldc2_w 4677765832392112705
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 3368089027615754663
      // 26: lload 1
      // 27: invokedynamic ª (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new java/util/concurrent/ConcurrentHashMap
      // 33: dup
      // 34: invokespecial java/util/concurrent/ConcurrentHashMap.<init> ()V
      // 37: putfield cn/cool/cherish/module/impl/render/树何树友树何何友树何.树何树树何友何树友友 Ljava/util/Map;
      // 3a: aload 0
      // 3b: new java/util/concurrent/CopyOnWriteArrayList
      // 3e: dup
      // 3f: invokespecial java/util/concurrent/CopyOnWriteArrayList.<init> ()V
      // 42: putfield cn/cool/cherish/module/impl/render/树何树友树何何友树何.树友何友何友友树树树 Ljava/util/List;
      // 45: aload 0
      // 46: new java/util/concurrent/CopyOnWriteArrayList
      // 49: dup
      // 4a: invokespecial java/util/concurrent/CopyOnWriteArrayList.<init> ()V
      // 4d: putfield cn/cool/cherish/module/impl/render/树何树友树何何友树何.友何友何树树友树友友 Ljava/util/List;
      // 50: aload 0
      // 51: new java/util/HashMap
      // 54: dup
      // 55: invokespecial java/util/HashMap.<init> ()V
      // 58: putfield cn/cool/cherish/module/impl/render/树何树友树何何友树何.何树何树树友友树树树 Ljava/util/Map;
      // 5b: aload 0
      // 5c: ldc2_w 3368507851331564180
      // 5f: lload 1
      // 60: invokedynamic j (Ljava/lang/Object;JJ)Ljava/util/Map; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 65: ldc2_w 3364269187489522895
      // 68: lload 1
      // 69: invokedynamic ª (JJ)Lnet/minecraft/world/level/block/Block; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6e: new java/awt/Color
      // 71: dup
      // 72: sipush 255
      // 75: sipush 215
      // 78: bipush 0
      // 79: invokespecial java/awt/Color.<init> (III)V
      // 7c: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // 81: pop
      // 82: aload 0
      // 83: ldc2_w 3368507851331564180
      // 86: lload 1
      // 87: invokedynamic j (Ljava/lang/Object;JJ)Ljava/util/Map; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 8c: ldc2_w 3367734331770209644
      // 8f: lload 1
      // 90: invokedynamic ª (JJ)Lnet/minecraft/world/level/block/Block; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 95: new java/awt/Color
      // 98: dup
      // 99: sipush 255
      // 9c: sipush 215
      // 9f: bipush 0
      // a0: invokespecial java/awt/Color.<init> (III)V
      // a3: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // a8: pop
      // a9: aload 0
      // aa: ldc2_w 3368507851331564180
      // ad: lload 1
      // ae: invokedynamic j (Ljava/lang/Object;JJ)Ljava/util/Map; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // b3: ldc2_w 3367981963161972768
      // b6: lload 1
      // b7: invokedynamic ª (JJ)Lnet/minecraft/world/level/block/Block; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // bc: new java/awt/Color
      // bf: dup
      // c0: bipush 0
      // c1: sipush 255
      // c4: sipush 255
      // c7: invokespecial java/awt/Color.<init> (III)V
      // ca: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // cf: pop
      // d0: aload 0
      // d1: ldc2_w 3368507851331564180
      // d4: lload 1
      // d5: invokedynamic j (Ljava/lang/Object;JJ)Ljava/util/Map; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // da: ldc2_w 3364799979965812713
      // dd: lload 1
      // de: invokedynamic ª (JJ)Lnet/minecraft/world/level/block/Block; bsm=cn/cool/cherish/module/impl/render/树何树友树何何友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // e3: new java/awt/Color
      // e6: dup
      // e7: bipush 0
      // e8: sipush 255
      // eb: sipush 255
      // ee: invokespecial java/awt/Color.<init> (III)V
      // f1: invokeinterface java/util/Map.put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; 3
      // f6: pop
      // f7: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7771436077215923320L, 6058030129456390430L, MethodHandles.lookup().lookupClass()).a(38742880176756L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 43037153249704L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = ' ';
      int var4 = -1;

      while (true) {
         String var13 = c(
               var2.doFinal(
                  "¼/xp|¢=\u0018\u001aÙ\b[E\u001c\u000eW\u0001{ÓGK\tH¾È/ú6r\u008düï(\u0005³Ô*\u0002ÈL\u0003£\u001bi£d£0\u0005¶\u009cÉìÚ³Ì+á+dÛëê(e\u001fÕË{\bÁ\u0003\u007f"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 73) {
            c = var9;
            h = new String[2];
            return;
         }

         var5 = "¼/xp|¢=\u0018\u001aÙ\b[E\u001c\u000eW\u0001{ÓGK\tH¾È/ú6r\u008düï(\u0005³Ô*\u0002ÈL\u0003£\u001bi£d£0\u0005¶\u009cÉìÚ³Ì+á+dÛëê(e\u001fÕË{\bÁ\u0003\u007f"
            .charAt(var4);
      }
   }

   public void F() {
      long a = 树何树友树何何友树何.a ^ 47753581701891L;
      long ax = a ^ 48869803994330L;
      if (c<"Ã">(6194888342495199600L, a) == null) {
         if (this.w(new Object[]{ax})) {
            return;
         }

         c<"j">(mc, 6193917211348026976L, a).allChanged();
      }
   }

   @EventTarget
   public void I(PacketEvent event) {
      long a = 树何树友树何何友树何.a ^ 129842486351239L;
      long ax = a ^ 124293456204382L;
      c<"Ã">(-1478034615697260556L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundBlockUpdatePacket S23) {
            c<"j">(this, -1477552522600989854L, a).add(S23.getPos());
            c<"j">(this, -1478736832889485490L, a).put(new 树何树友树何何友树何.树何友何友友何友何何(S23.getPos()), S23.getBlockState());
         }

         if (packet instanceof ClientboundSectionBlocksUpdatePacket S22) {
            S22.runUpdates((pos, state) -> {
               long axx = 树何树友树何何友树何.a ^ 19019023301418L;
               c<"j">(this, -4191784089671133745L, axx).add(pos);
               c<"j">(this, -4190845794906002973L, axx).put(new 树何树友树何何友树何.树何友何友友何友何何(pos), state);
            });
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 53;
               case 1 -> 26;
               case 2 -> 13;
               case 3 -> 0;
               case 4 -> 12;
               case 5 -> 60;
               case 6 -> 56;
               case 7 -> 19;
               case 8 -> 47;
               case 9 -> 32;
               case 10 -> 16;
               case 11 -> 36;
               case 12 -> 20;
               case 13 -> 24;
               case 14 -> 58;
               case 15 -> 57;
               case 16 -> 41;
               case 17 -> 33;
               case 18 -> 54;
               case 19 -> 40;
               case 20 -> 44;
               case 21 -> 38;
               case 22 -> 15;
               case 23 -> 8;
               case 24 -> 4;
               case 25 -> 25;
               case 26 -> 10;
               case 27 -> 28;
               case 28 -> 55;
               case 29 -> 48;
               case 30 -> 62;
               case 31 -> 46;
               case 32 -> 2;
               case 33 -> 3;
               case 34 -> 35;
               case 35 -> 51;
               case 36 -> 5;
               case 37 -> 9;
               case 38 -> 30;
               case 39 -> 49;
               case 40 -> 11;
               case 41 -> 29;
               case 42 -> 43;
               case 43 -> 1;
               case 44 -> 63;
               case 45 -> 61;
               case 46 -> 18;
               case 47 -> 23;
               case 48 -> 27;
               case 49 -> 52;
               case 50 -> 21;
               case 51 -> 7;
               case 52 -> 34;
               case 53 -> 42;
               case 54 -> 50;
               case 55 -> 17;
               case 56 -> 45;
               case 57 -> 31;
               case 58 -> 39;
               case 59 -> 22;
               case 60 -> 37;
               case 61 -> 14;
               case 62 -> 6;
               default -> 59;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树友树何何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 32532;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树友树何何友树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private Color s(BlockState state) {
      long a = 树何树友树何何友树何.a ^ 96861699931873L;
      Block block = state.getBlock();
      return c<"j">(this, 7442772693507121L, a).getOrDefault(block, c<"ª">(7792237831349699L, a));
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树友树何何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'j' && var8 != 'g' && var8 != 170 && var8 != 'i') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'D') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 195) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'j') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'g') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 170) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public void c(int range) {
      long var10001 = 树何树友树何何友树何.a ^ 78909976805808L ^ 51390726922832L;
      int a = (int)((树何树友树何何友树何.a ^ 78909976805808L ^ 51390726922832L) >>> 48);
      int ax = (int)((树何树友树何何友树何.a ^ 78909976805808L ^ 51390726922832L) << 16 >>> 48);
      int axx = (int)(var10001 << 32 >>> 32);
      int playerX = (int)mc.player.getX();
      int playerY = (int)mc.player.getY();
      int playerZ = (int)mc.player.getZ();
      树何树树何树何何树何.N((char)a, () -> {
         long axxx = 树何树友树何何友树何.a ^ 68717524698799L;
         c<"Ã">(4059079384852786396L, axxx);
         Set<BlockPos> uncheckedSet = new HashSet<>(c<"j">(this, 4060985336181065380L, axxx));
         HashSet checkedSet = new HashSet(c<"j">(this, 4059684623393908810L, axxx));
         Set<Block> oreBlocks = new HashSet<>();
         oreBlocks.add(c<"ª">(4059492059978999499L, axxx));
         oreBlocks.add(c<"ª">(4060387058990618882L, axxx));
         oreBlocks.add(c<"ª">(4060846383211147812L, axxx));
         oreBlocks.add(c<"ª">(4059950866322232199L, axxx));
         List<BlockPos> newBlocks = new ArrayList<>();
         int processed = 0;
         int x = -rangex;
         if (x <= rangex) {
            int y = -rangex;
            if (y <= rangex) {
               int z = -rangex;
               if (z <= rangex) {
                  BlockPos blockPos = new BlockPos(playerX + x, playerY + y, playerZ + z);
                  if (!uncheckedSet.contains(blockPos)) {
                     if (checkedSet.contains(blockPos)) {
                     }

                     if (mc.level.isLoaded(blockPos)) {
                        if (oreBlocks.stream().noneMatch(b -> {
                           long axxxx = 树何树友树何何友树何.a ^ 27065025964573L;
                           return b == c<"ª">(6118039469172453619L, axxxx);
                        }) && this.H(blockPos)) {
                        }

                        Block block = mc.level.getBlockState(blockPos).getBlock();
                        if (oreBlocks.contains(block)) {
                           newBlocks.add(blockPos);
                           uncheckedSet.add(blockPos);
                        }

                        if (++processed >= 1000) {
                           try {
                              Thread.sleep(1L);
                           } catch (InterruptedException var22) {
                              Thread.currentThread().interrupt();
                              return;
                           }
                        }
                     }
                  }

                  z++;
               }

               y++;
            }

            x++;
         }

         synchronized (c<"j">(this, 4060985336181065380L, axxx)) {
            c<"j">(this, 4060985336181065380L, axxx).addAll(newBlocks);
         }
      }, (char)ax, axx);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private void d(PoseStack poseStack, float minX, float maxX, float minY, float maxY, float minZ, float maxZ, int startColor, float alpha) {
      long a = 树何树友树何何友树何.a ^ 91897799038436L;
      Matrix4f matrix = poseStack.last().pose();
      float red = (startColor >> 16 & 0xFF) / 255.0F;
      float green = (startColor >> 8 & 0xFF) / 255.0F;
      float blue = (startColor & 0xFF) / 255.0F;
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      bufferBuilder.begin(c<"ª">(-6116099587433536256L, a), c<"ª">(-6119503092673333782L, a));
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
   }

   private static void a() {
      j[0] = "w\rz\u0019\u0016bxM7\u0012\u001c\u007f}\u0010<T\u0014bp\u00168\u001fWdy\u00138T\u000bhz\u00071\bW栜佁桲原桫伬佘叟桲企";
      j[1] = "2(\u0007\u000b:\u00039'\u0016DQ\u0017;,\u0001\u001e}\u00006";
      j[2] = "6\u0002\u0017RK\u0019(\n\r\u001d)\u0005/\u0017";
      j[3] = "7\u001d4G6T8]yL<I=\u0000r\n4T0\u0006vAwR9\u0003v\n+^:\u0017\u007fVwy1\u0007nA+x5\u001e\u007fV8";
      j[4] = "a&I^a\u001cj)X\u0011\u001c\u0004y.QX";
      j[5] = "K\"\u007f|\u007f\u0019U*e3\u001c\rQ";
      j[6] = "\u007f8\u001f5NK\u007f8\biBDes\u001ctQNus\u0007~UG}s\twLAzs)wLAz.";
      j[7] = "\u000bM*\u0002l\u000f\u000bM=^`\u0000\u0011\u0006)Cs\n\u0001\u00062Iw\u0003\t\u0006<@n\u0005\u000e\u0006\u001c@n\u0005\u000e";
      j[8] = "\u007fU\u0001y>}\u007fU\u0016%2re\u001e\u0016;:q\u007fD[\u001a:ztS\u000765`";
      j[9] = "D\u001cZ\u001f'\u0015D\u001cMC+\u001a^WM]#\u0019D\r\u0000C/\u0012N\u001c\\T8Rf\u001cXT&.O\u0017JT8\u0019X";
      j[10] = "l$\u0011-\u0017\fcd\\&\u001d\u0011f9W`\u0015\fk?S+V伶佚厁佪伛厳伶佚桛栮";
      j[11] = ";z,8A\u0001&ot\u001a\u0000\f>i";
      j[12] = "J?Af\r\u001cC1B/N\u0011E1V-S\u0017\u0007&I:\u0014\u0016Q~h-\u0006\u0012\\<X\u001e\u0005\u0001]5T\u000e\u000f\u0001D1X";
      j[13] = "\fF\u0011x\u0007N\u0005H\u00121DC\u0003H\u00063YEA_\u0019$\u001eD\u0017\u0007*3\u0018U\nQ:9\u0018L\u000e]";
      j[14] = "{v\u0011\u0010&Irx\u0012YeDtx\u0006[xB6o\u0019L?C`7*[9R}a:Q9KymXs$B}";
      j[15] = "VF\u00114~CVF\u0006hrLL\r\u0012uaF\\\r\u0015rjY\u0016b$XQ";
      j[16] = double.class;
      k[16] = "java/lang/Double";
      j[17] = "\u001fn\u0014,|S\u001fn\u0003pp\\\u0005%\u0003nx_\u001f\u007fNptT\u0015n\u0012gc\u00146j\rgC_\u001fo\u0005ptH";
      j[18] = "u[w8-2u[`d!=o\u0010ty27\u007f\u0010s~9(5hfus";
      j[19] = "Z2\u001e\r\u0001:Q=\u000fB`4Z6\u000b\u0018";
      j[20] = "\u0017?q.;]\u001a)k \u0000\b|y0v1[|E=:e_\u0011te'yW";
      j[21] = "\u0014WI\u0014=\u0005L\u0017\u001bj0~\n\u001c\n\u000b0\u0005\u000eB@j\"N\nM\u0018\u0011&\u0010@,";
      j[22] = "\u00038Tk\u0014\u0006[x\u0006\u0015桩厾伻厀伱取厳桤桿桚l,\u0017\f\u0005&\u001co\u001a\u0017\u0016";
      j[23] = "].|<^l\t )\u007f&Ky\b\u001fLqCu\u0004\u000fX&nX|}{M:V)>";
      j[24] = "?7\u001b(7A/+V}HA\u0001a\u001c\u007fy\u0014\u0001QLzyB?1V(1V";
      j[25] = "\u001d59c#%S(%y\u00195zw{2 fzGwaig@$!f&f";
      j[26] = "A2\"E\u0015\u001bQ.o\u0010j\u001b\u007fd%\u0012[L\u007fTu\u0017[\u0018A4oE\u0013\f";
      j[27] = "H4\u0014\u001c\u001bpX(YIdpvb\u0013KU&vRCNUsH2Y\u001c\u001dg";
      j[28] = "4yl\b8L3x\u007fU\u0007\u001c^5*V9J^\u0004-\bl\u001be9z\t;O";
      j[29] = "td.B8\u0016yr4L\u0003C\u001f'c\u0011?\u0012tI^\u0017~Hq$oOcTy";
      j[30] = "$|<bY%1r?yg)\u0018-y,W~\u0018\u001d)/V*&}3}\u001e>";
      j[31] = "YJ\u0010`c^LD\u0013{]Re\u001bU.b\re+\u0005-lQ[K\u001f\u007f$E";
      j[32] = "<[u$=U1Mo*\u0006\u0000W\u001c=u6_W!90cW:\u0010a-\u007f_";
      j[33] = "\u007fBs\u0002H0rTi\fse\u0014\u0005;SJ5\u00148?\u0016\u00162y\tg\u000b\n:";
      j[34] = "_&\u001f~\"jXh^eD栁桸伉根栕桝佅厢厗口\fzj^&F~}$\u001f=";
      j[35] = "C#\u0017b\u0017\u001c\u001bcE\u001c厰伺句伅栶栅厰桾句厛/%\u0014\u0016E=_f\u0019\rV";
      j[36] = ":ZtOrN*F9\u001a\rN\u0004\fs\u0018=\u0011\u0004<#\u001d<M:\\9OtY";
      j[37] = "\u000bb:\u0017c\u0012\fc)J\\Ba.|Ib\u0017a\u001f/\u000f:\u0016Oz{\t0G";
      j[38] = "\tyd[K|\u0004o~Up)b?%\u0003A\u007fb\u0003(O\u0015~\u000f2pR\tv";
      j[39] = "70r\b\u000f\r:&h\u00064X\\s?[\b\b4\u001d\u0002]IS2p3\u0005TO:";
      j[40] = "4JK^o\u001fl\n\u0019 佖桽伌栨桪口又桽案栨s\u001bz\u00018\u000fOM3\u00002";
      j[41] = "\u001e?ie\u000b\u0017J1<&s%*\u001a\u001b\u0001s\u0015\u001bmh\"\u0018A\u00158+";
      j[42] = "d\u001bMy\u0017&;\u000fWtv\u0001^YL{\u001a1#\u0013]v\u000e_";
      j[43] = "`^\u001a\u001du\u0015pBWH\n\u0015^\b\u001dJ:K^8MO;\u0016`XW\u001ds\u0002";
      j[44] = "k\u0017\u000b\u0006n2{\u000bFS\u00112UA\fQ fUq\\T 1k\u0011F\u0006h%";
      j[45] = "6 m;\u0014!#.n *-\nq(u\u001a{\nAxv\u001b.4!b$S:";
      j[46] = "\u001f{H\u0014\f%\u0012mR\u001a7pt<\u0000E\u0007#t\u0001\u0004\u0000R'\u00190\\\u001dN/";
      j[47] = "[HYD\u0003wTN^\u00122\u0015+5~e2zW\u000fN\u0019\u000fuQ\b\u0018";
      j[48] = "2\"m=Tkjb?C栩位桎桀伈厀佭栉厔厚UxAu>gi.\bt4";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 树何树友树何何友树何.a ^ 120053100701924L;
      long ax = a ^ 116737586720573L;
      c<"Ã">(-7629119216480730473L, a);
      c<"j">(this, -7630958657257375187L, a).clear();
      c<"j">(this, -7633363967550084881L, a).clear();
      c<"j">(this, -7629741084464134655L, a).clear();
      if (!this.w(new Object[]{ax})) {
         c<"j">(mc, -7632914459312388729L, a).allChanged();
      }
   }

   public void g(PoseStack poseStack, BlockPos pos, BlockState state, int color, boolean fillMode, boolean wireframeMode, float fillAlpha) {
      long a = 树何树友树何何友树何.a ^ 101949487353505L;
      c<"Ã">(-1127344705183537966L, a);
      if (!state.isAir()) {
         VoxelShape shape = state.getShape(mc.level, pos);
         if (!shape.isEmpty()) {
            Camera camera = c<"j">(mc, -1127858568188841726L, a).getMainCamera();
            Vec3 camPos = camera.getPosition();
            double x = pos.getX() - c<"j">(camPos, -1128284733590008567L, a);
            double y = pos.getY() - c<"j">(camPos, -1127292542567645095L, a);
            double z = pos.getZ() - c<"j">(camPos, -1128220035823327652L, a);
            poseStack.pushPose();
            poseStack.translate(x, y, z);
            Iterator var20 = shape.toAabbs().iterator();
            if (var20.hasNext()) {
               AABB aabb = (AABB)var20.next();
               float minX = (float)c<"j">(aabb, -1127394892394534025L, a);
               float maxX = (float)c<"j">(aabb, -1128445370171899345L, a);
               float minY = (float)c<"j">(aabb, -1127757240602887964L, a);
               float maxY = (float)c<"j">(aabb, -1127179716110395559L, a);
               float minZ = (float)c<"j">(aabb, -1128511823217112627L, a);
               float maxZ = (float)c<"j">(aabb, -1128594471117550577L, a);
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               RenderSystem.disableDepthTest();
               RenderSystem.setShader(GameRenderer::getPositionColorShader);
               this.d(poseStack, minX, maxX, minY, maxY, minZ, maxZ, color, 0.3F);
               RenderSystem.disableDepthTest();
               RenderSystem.defaultBlendFunc();
               this.M(poseStack, minX, maxX, minY, maxY, minZ, maxZ, color);
            }

            RenderSystem.enableDepthTest();
            poseStack.popPose();
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void z(Render3DEvent event) {
      long a = 树何树友树何何友树何.a ^ 73568101729160L;
      long ax = a ^ 76918378103889L;
      c<"Ã">(9039783997788826107L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         c<"j">(this, 9040215736727015745L, a).forEach((pos, state) -> {
            long axx = 树何树友树何何友树何.a ^ 36241982788361L;
            c<"Ã">(-1300799529026176646L, axx);
            if (state.getBlock() != c<"ª">(-1301463135113561005L, axx) && this.O(state)) {
               BlockPos blockPos = pos.Q();
               if (mc.level.getBlockState(blockPos).getBlock() == c<"ª">(-1301463135113561005L, axx)) {
                  return;
               }

               BlockState actualState = mc.level.getBlockState(blockPos);
               Color color = this.s(state);
               int colorRGB = color.getRGB();
               this.g(event.poseStack(), blockPos, actualState, colorRGB, true, true, 0.3F);
            }
         });
      }
   }

   @EventTarget
   public void A(WorldEvent event) {
      this.k();
   }

   @EventTarget
   public void X(LivingUpdateEvent event) {
      long a = 树何树友树何何友树何.a ^ 112168502843960L;
      long ax = a ^ 106757314371041L;
      c<"Ã">(2649215311259168843L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         this.c(5);
      }
   }

   private void M(PoseStack poseStack, float minX, float maxX, float minY, float maxY, float minZ, float maxZ, int startColor) {
      long a = 树何树友树何何友树何.a ^ 12525785375123L;
      Matrix4f matrix = poseStack.last().pose();
      float red = (startColor >> 16 & 0xFF) / 255.0F;
      float green = (startColor >> 8 & 0xFF) / 255.0F;
      float blue = (startColor & 0xFF) / 255.0F;
      float alpha = (startColor >> 24 & 0xFF) / 255.0F;
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      bufferBuilder.begin(c<"ª">(-6960356971038718601L, a), c<"ª">(-6961315236043619939L, a));
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
   }

   private boolean H(BlockPos pos) {
      long a = 树何树友树何何友树何.a ^ 7186831172916L;
      c<"Ã">(-7219402388709290169L, a);
      return mc.level.getBlockState(pos.above()).getBlock() == c<"ª">(-7220008714226611602L, a)
         || mc.level.getBlockState(pos.above()).getBlock() == c<"ª">(-7220197001043341144L, a)
         || mc.level.getBlockState(pos.below()).getBlock() == c<"ª">(-7220008714226611602L, a)
         || mc.level.getBlockState(pos.below()).getBlock() == c<"ª">(-7220197001043341144L, a)
         || mc.level.getBlockState(pos.south()).getBlock() == c<"ª">(-7220008714226611602L, a)
         || mc.level.getBlockState(pos.south()).getBlock() == c<"ª">(-7220197001043341144L, a)
         || mc.level.getBlockState(pos.north()).getBlock() == c<"ª">(-7220008714226611602L, a)
         || mc.level.getBlockState(pos.north()).getBlock() == c<"ª">(-7220197001043341144L, a)
         || mc.level.getBlockState(pos.east()).getBlock() == c<"ª">(-7220008714226611602L, a)
         || mc.level.getBlockState(pos.east()).getBlock() == c<"ª">(-7220197001043341144L, a)
         || mc.level.getBlockState(pos.west()).getBlock() == c<"ª">(-7220008714226611602L, a)
         || mc.level.getBlockState(pos.west()).getBlock() == c<"ª">(-7220197001043341144L, a);
   }

   private boolean O(BlockState state) {
      long a = 树何树友树何何友树何.a ^ 101946797011495L;
      c<"Ã">(5538545690599987284L, a);
      Block block = state.getBlock();
      return block != c<"ª">(5538957238026654275L, a) && block != c<"ª">(5535212304809061770L, a)
         ? block == c<"ª">(5535878880562480812L, a) || block == c<"ª">(5539345124289701647L, a)
         : true;
   }

   private static String HE_DA_WEI() {
      return "何树友被何大伟克制了";
   }

   public static class 树何友何友友何友何何 implements 何树友 {
      private final int 何何树何何何友树友友;
      private final int 友友何何友友友友友树;
      private final int 树树树何树友友树树树;
      private static final long a;
      private static final Object[] b = new Object[11];
      private static final String[] c = new String[11];
      private static String HE_WEI_LIN;

      public 树何友何友友何友何何(BlockPos pos) {
         this.何何树何何何友树友友 = pos.getX();
         this.友友何何友友友友友树 = pos.getY();
         this.树树树何树友友树树树 = pos.getZ();
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(176377941168199769L, 6661038406272920151L, MethodHandles.lookup().lookupClass()).a(216966167802069L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      @Override
      public boolean equals(Object obj) {
         long a = 树何树友树何何友树何.树何友何友友何友何何.a ^ 69173809399168L;
         a<"ì">(7947372667036672522L, a);
         if (this == obj) {
            return true;
         } else if (obj != null && this.getClass() == obj.getClass()) {
            树何树友树何何友树何.树何友何友友何友何何 position = (树何树友树何何友树何.树何友何友友何友何何)obj;
            return a<"i">(this, 7946929923709943852L, a) == a<"i">(position, 7946929923709943852L, a)
               && a<"i">(this, 7947419032874264617L, a) == a<"i">(position, 7947419032874264617L, a)
               && a<"i">(this, 7946982147999304227L, a) == a<"i">(position, 7946982147999304227L, a);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         long a = 树何树友树何何友树何.树何友何友友何友何何.a ^ 3830005338977L;
         int result = a<"i">(this, -5140833431333464371L, a);
         result = 31 * result + a<"i">(this, -5139774775749771576L, a);
         return 31 * result + a<"i">(this, -5140744922163094334L, a);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'i' && var8 != 164 && var8 != 211 && var8 != 't') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 233) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 236) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'i') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 164) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 211) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树友树何何友树何$树何友何友友何友何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 8;
                  case 1 -> 59;
                  case 2 -> 62;
                  case 3 -> 46;
                  case 4 -> 9;
                  case 5 -> 53;
                  case 6 -> 12;
                  case 7 -> 23;
                  case 8 -> 37;
                  case 9 -> 19;
                  case 10 -> 17;
                  case 11 -> 11;
                  case 12 -> 30;
                  case 13 -> 7;
                  case 14 -> 43;
                  case 15 -> 21;
                  case 16 -> 51;
                  case 17 -> 33;
                  case 18 -> 41;
                  case 19 -> 34;
                  case 20 -> 60;
                  case 21 -> 28;
                  case 22 -> 42;
                  case 23 -> 58;
                  case 24 -> 55;
                  case 25 -> 26;
                  case 26 -> 35;
                  case 27 -> 25;
                  case 28 -> 29;
                  case 29 -> 50;
                  case 30 -> 18;
                  case 31 -> 15;
                  case 32 -> 27;
                  case 33 -> 24;
                  case 34 -> 13;
                  case 35 -> 6;
                  case 36 -> 2;
                  case 37 -> 47;
                  case 38 -> 22;
                  case 39 -> 1;
                  case 40 -> 20;
                  case 41 -> 39;
                  case 42 -> 48;
                  case 43 -> 38;
                  case 44 -> 16;
                  case 45 -> 52;
                  case 46 -> 45;
                  case 47 -> 61;
                  case 48 -> 63;
                  case 49 -> 40;
                  case 50 -> 56;
                  case 51 -> 49;
                  case 52 -> 14;
                  case 53 -> 3;
                  case 54 -> 54;
                  case 55 -> 5;
                  case 56 -> 0;
                  case 57 -> 57;
                  case 58 -> 36;
                  case 59 -> 31;
                  case 60 -> 10;
                  case 61 -> 4;
                  case 62 -> 32;
                  default -> 44;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "&6\u001b\t;\u0019)vV\u00021\u0004,+]D9\u0019!-Y\u000fz\u001f((YD&\u0013+<P\u0018z桧伐桉叾桻企伣厎桉你N桅伣厎伍叾厡企厽伐伍";
         b[1] = int.class;
         c[1] = "java/lang/Integer";
         b[2] = "Y5_vh9R:N9\u0014 ] @z#\u0010K7Lg2<\\:";
         b[3] = "%h(>\"T*(e5(I/uns T\"sj8cR+vjs?^(bc/cy#rr8?x'kc/,";
         b[4] = "E\u001f\u0012\u00018\nN\u0010\u0003NE\u0012]\u0017\n\u0007";
         b[5] = "kqb{#\u0005`~s4B\u000bkuwn";
         b[6] = "{Z\u001a\u0005hR|\rDf厖司住佬厽厥厖司发栨~_i_o]\u0001\u001d'G/";
         b[7] = "Pm>!\u000fc\u0012ye#oFj20#\u0017r\u0011n9%\u001f\u0018";
         b[8] = "\n?y\u0005\u00026\rh'f栦框桺伉栄厥叼框桺桍\u001d_\u0003;\u001e8b\u001dM#^";
         b[9] = "#.'\u0005\u0007\\$yyf佧佨桓优伞伻叹栬厉历C_\u0006Q7)<\u001dHIw";
         b[10] = "$\f'u\u000e\u0010#[y\u0016Zyt\u0002=t]\u001d0\u0019|q3@(\u0019!xW\u00043X$\u0016";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public BlockPos Q() {
         long a = 树何树友树何何友树何.树何友何友友何友何何.a ^ 9782464719745L;
         return new BlockPos(a<"i">(this, -9203074342099571155L, a), a<"i">(this, -9202031011428973016L, a), a<"i">(this, -9202986932364286942L, a));
      }

      private static String HE_JIAN_GUO() {
         return "我是何树友";
      }
   }
}
