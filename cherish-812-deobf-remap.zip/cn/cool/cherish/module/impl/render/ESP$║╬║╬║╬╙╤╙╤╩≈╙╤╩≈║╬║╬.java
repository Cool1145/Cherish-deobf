package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.ChatFormatting;

// $VF: synthetic class
class ESP$何何何友友树友树何何 implements 何树友 {
   private static final Object[] a = new Object[20];
   private static final String[] b = new String[20];
   private static int _何大伟：我要教育何炜霖 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8287209772948393709L, -3877515827425607894L, MethodHandles.lookup().lookupClass()).a(275238726542023L);
      // $VF: monitorexit
      long var0 = var10000 ^ 14034814717375L;
      a();

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108242647150609042L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var17) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108324738442427501L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var16) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8106580204653890385L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var15) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108632498595692439L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var14) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108105878650499746L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var13) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8106513710404575108L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var12) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108580367744801825L, var0).ordinal()] = 7;
      } catch (NoSuchFieldError var11) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8107918717629124793L, var0).ordinal()] = 8;
      } catch (NoSuchFieldError var10) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8106623166703105762L, var0).ordinal()] = 9;
      } catch (NoSuchFieldError var9) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108414416578927887L, var0).ordinal()] = 10;
      } catch (NoSuchFieldError var8) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108025308010530079L, var0).ordinal()] = 11;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[ChatFormatting.AQUA.ordinal()] = 12;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108216895544609811L, var0).ordinal()] = 13;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108089158393606374L, var0).ordinal()] = 14;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108477011737363430L, var0).ordinal()] = 15;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"V">(-8106756718998695920L, var0)[a<"V">(-8108702357978930794L, var0).ordinal()] = 16;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 203 && var8 != '$' && var8 != 'V' && var8 != 246) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'z') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 198) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 203) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'V') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/ESP$何何何友友树友树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 10;
               case 1 -> 63;
               case 2 -> 55;
               case 3 -> 7;
               case 4 -> 44;
               case 5 -> 20;
               case 6 -> 13;
               case 7 -> 4;
               case 8 -> 37;
               case 9 -> 15;
               case 10 -> 22;
               case 11 -> 51;
               case 12 -> 52;
               case 13 -> 32;
               case 14 -> 45;
               case 15 -> 39;
               case 16 -> 46;
               case 17 -> 12;
               case 18 -> 58;
               case 19 -> 42;
               case 20 -> 23;
               case 21 -> 40;
               case 22 -> 43;
               case 23 -> 19;
               case 24 -> 11;
               case 25 -> 21;
               case 26 -> 60;
               case 27 -> 38;
               case 28 -> 62;
               case 29 -> 25;
               case 30 -> 24;
               case 31 -> 50;
               case 32 -> 0;
               case 33 -> 35;
               case 34 -> 18;
               case 35 -> 9;
               case 36 -> 6;
               case 37 -> 14;
               case 38 -> 31;
               case 39 -> 17;
               case 40 -> 26;
               case 41 -> 27;
               case 42 -> 57;
               case 43 -> 61;
               case 44 -> 59;
               case 45 -> 34;
               case 46 -> 41;
               case 47 -> 48;
               case 48 -> 16;
               case 49 -> 36;
               case 50 -> 56;
               case 51 -> 1;
               case 52 -> 29;
               case 53 -> 2;
               case 54 -> 8;
               case 55 -> 53;
               case 56 -> 5;
               case 57 -> 28;
               case 58 -> 3;
               case 59 -> 30;
               case 60 -> 33;
               case 61 -> 49;
               case 62 -> 54;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "v@O3\u0004=v@Xo\b2l\u000bxu\b ^JIp\b lLUz";
      a[1] = "e7p#lAjw=(f\\o*6nnAb,2%-Gk)2nqKh=;2-kU\tz伕佖佻反厒桏压栒佻体";
      a[2] = "E\"";
      a[3] = "6Ddq\u000et=Ku>oz6@qd";
      a[4] = "T9*_ O\u0016=~a\u0000d$C\u00126\u001cx1[\n,D\u001aQgp\u0005.XU3";
      a[5] = "x\u0017ta6\u0019:\u0013 _\u001e:\u001dnG\u0005\u001f?G\u0012*;l\u0017-P.o";
      a[6] = "\u0015\\)\\^LWX}bu|c7M]\u0000B\u0014\u0002'\u001f\u0004\u0016";
      a[7] = "\u0016\u0011@yV\u000bT\u0015\u0014G};dfbG\r[M\u0015@-O_\u0019";
      a[8] = "\u0017nNk6KUj\u001aU\u001ehr\u0017}\u001f\u0016|eT\u0015o6\u001fL>Wkb";
      a[9] = "rD) _\u00000@}\u001eq.\u00103M!\u0001\u000es\u001a'c\u0005Z";
      a[10] = "H\u00006}2\u0019\n\u0004bC\f>;:my2M\u0013P/}f";
      a[11] = "\u001bz7H@?Y~cvn\u0011m\u000b\u0010v\u001bo@~7\u001cYk\u0014";
      a[12] = "\u0010Z-m\u0007=R^yS/\u001eu#\u001e\u001a:\nf`vi\u0007iK\n4mS";
      a[13] = "4||:[%vx(\u0004`\u000fJ\u001aU\u0004\u0000uox|nBq;";
      a[14] = ">\u0004\u0011B\f9|\u0000E|9\u001eEz2#hl;ZK\u0018\u0002.?\u000e";
      a[15] = "\u0017do\nF\u0017U`;4m:l\u0012\u000b\u000b\u0018\u0019\u0016:aI\u001cM";
      a[16] = "%6>'9Lg2j\u0019\u0011o@O\rV\u0007oK\fe#9\u0018~f''m";
      a[17] = "rdt[U:u''6栴伇栐叚叜栯佰桃栐叚\u001f\u000fN9micFA?l";
      a[18] = "ZhV'<\u001b\u0018l\u0002\u0019\u00148?\u0011eA\u0005+=\u0016\u007f\u0019gK\u0001lVs%OU";
      a[19] = "p\u001enG6U2\u001a:y\u001ev\u0015g]6\br\u0002b\nFh[q@`\u0004l\u000f";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String LIU_YA_FENG() {
      return "我是何树友";
   }
}
