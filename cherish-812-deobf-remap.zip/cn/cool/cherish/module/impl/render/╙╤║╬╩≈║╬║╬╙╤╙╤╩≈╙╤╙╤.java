package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.ui.何友友友树友何友树何;
import cn.cool.cherish.ui.何树何友友何何友友树;
import cn.cool.cherish.value.impl.ModeValue;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友何树何何友友树友友 extends Module implements 何树友 {
   public ModeValue 友何友友何何树树树友 = new ModeValue("Mode", "模式", new String[]{"List", "Compact"}, "List");
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[15];
   private static final String[] k = new String[15];
   private static int _何炜霖230622200409390090 _;

   public 友何树何何友友树友友() {
      super("ClickGui", "点击界面", 树何友友何树友友何何.友友树树何友树树友树, 344);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-245045201009054440L, -6264693776208918158L, MethodHandles.lookup().lookupClass()).a(168347590312228L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(102618757900748L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[8];
      int var7 = 0;
      String var6 = "\u0080w\u0082<Ø\u0094r\u0087\u00ad)KëØq\u009eØ\u0010>Ôî\u0092ê\u0012!¹T\u0013\u0002\u007f(®©ÿ\u0018L\u008a¹møóD\u00069Ð\u009dàÀ`@è±nè\u00028\u009d\u000f\"\u0010÷L.Õ3\u0013\u0017ÿÛ±3\u009c%V\t£\u0010||\u000f\u0018<ðD²Ê\u009e\u001fÑ'¤\u0010\b\u0010G7ó`×L¨\u008bò|x\u0083\u0092\u0003fb";
      byte var8 = 109;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[8];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\b\u0080Ùñ\u001e\u0086\u0011txoÅ\u0006\u0094WØH\u0091Dà\u000fþ\t.+\u0010÷Þ\u009d´\u009bò¹\u000e\u00adÀáª\u0017ø\u0007Ê";
                  var8 = 41;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 47;
               case 1 -> 5;
               case 2 -> 44;
               case 3 -> 55;
               case 4 -> 31;
               case 5 -> 53;
               case 6 -> 52;
               case 7 -> 4;
               case 8 -> 8;
               case 9 -> 41;
               case 10 -> 6;
               case 11 -> 60;
               case 12 -> 63;
               case 13 -> 27;
               case 14 -> 20;
               case 15 -> 19;
               case 16 -> 35;
               case 17 -> 10;
               case 18 -> 2;
               case 19 -> 1;
               case 20 -> 25;
               case 21 -> 13;
               case 22 -> 11;
               case 23 -> 54;
               case 24 -> 48;
               case 25 -> 59;
               case 26 -> 26;
               case 27 -> 42;
               case 28 -> 9;
               case 29 -> 28;
               case 30 -> 43;
               case 31 -> 3;
               case 32 -> 30;
               case 33 -> 22;
               case 34 -> 7;
               case 35 -> 37;
               case 36 -> 40;
               case 37 -> 16;
               case 38 -> 49;
               case 39 -> 61;
               case 40 -> 62;
               case 41 -> 56;
               case 42 -> 50;
               case 43 -> 51;
               case 44 -> 39;
               case 45 -> 29;
               case 46 -> 34;
               case 47 -> 21;
               case 48 -> 23;
               case 49 -> 36;
               case 50 -> 17;
               case 51 -> 12;
               case 52 -> 32;
               case 53 -> 38;
               case 54 -> 14;
               case 55 -> 33;
               case 56 -> 45;
               case 57 -> 24;
               case 58 -> 18;
               case 59 -> 58;
               case 60 -> 0;
               case 61 -> 15;
               case 62 -> 57;
               default -> 46;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何树何何友友树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 30715;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何树何何友友树友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'd' && var8 != 245 && var8 != 253 && var8 != 'O') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'y') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'm') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'd') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 245) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 253) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何树何何友友树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "9\u00103@W\u007f6P~K]b3\ru\rU\u007f>\u000bqF\u0016y7\u000eq\rJu4\u001axQ\u0016叛伏桯佈佶右叛桋厵取";
      j[1] = ". \u007fZYu!`2QSh$=9\u0017@{!;4\u0017_w=\"\u007ftY~(\u00180UC\u007f";
      j[2] = "B\u001bFY\u0002rM[\u000bR\boH\u0006\u0000\u0014\u0000rE\u0000\u0004_C栌佴厾厣佯桼取只传伽";
      j[3] = "G4X}6MHt\u0015v<PM)\u001e04M@/\u001a{wKI*\u001a0+GJ>\u0013lw`A.\u0002{+aE7\u0013l8";
      j[4] = "w].vWT|R?9*LoU6p";
      j[5] = "{\r4\u0006K&tMy\rA;q\u0010rKQ 6伶发厮可桘叓伶发桴佱";
      j[6] = "Z/? l\u0001Uor+f\u001cP2ymv\u0007\u0017伔栀伖又厥佬伔叚厈栒";
      j[7] = "\u001ei\u0016\u0016I*\u0015f\u0007Y53\u001a|\t\u001a\u0002\u0003\fk\u0005\u0007\u0013/\u001bf";
      j[8] = "\u0003\u0018\u000ep:;\b\u0017\u001f?[5\u0003\u001c\u001be";
      j[9] = "FK6\u0013pP\u0000\u0002Q\u001c\u0017\u0011\u0013A+LfCD\u000e*u*EK\nh\u0004x\u0012\u0004\u000bQ";
      j[10] = "\u007f:?T\u001aC}wu\rwSE0tS\u0017\u000e,6=\t\u0011>";
      j[11] = "Qqs+\u001b)Vu{;g伔伷反叀桜厤桐厩反栚E\\6\u001a`\u007f%[2\u0012p";
      j[12] = "jwB\u0012Q\u0019,>%厷佫厦厕休佸桭栯桼厕LW\u0018R\u0002=sU\u0018\u000f";
      j[13] = "\u0003E\u0010PD>]\u0003\u001b\u000by厞叺桥桹佬厺桄栠县桹1CdI\u001d]R\u001d\"BF";
      j[14] = "l\\Ze{]a\u0019\u0003gF株桉叧校叜桟佮厓叧佥\u001fzK2^\u0005qw\u000ek\\";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   protected void M() {
      BetterCamera.e();
      if (Cherish.instance != null && Cherish.getConfigManager() != null && !this.Q(new Object[]{52406761729175L})) {
         Cherish.getConfigManager().x();
         String var6 = this.友何友友何何树树树友.getValue();
         byte var7 = -1;
         switch (var6.hashCode()) {
            case 2368702:
               if (!var6.equals("List")) {
                  break;
               }

               var7 = 0;
            case -1679830269:
               if (var6.equals("Compact")) {
                  var7 = 1;
               }
         }

         switch (var7) {
            case 0:
               mc.setScreen(何树何友友何何友友树.树树友树友树何友友何);
            case 1:
               mc.setScreen(何友友友树友何友树何.何何友友树友树友友树);
            default:
               this.n();
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "职业技术教育中心学校";
   }
}
