package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.misc.何友友友树树树树树树;
import cn.cool.cherish.ui.树树树友友树友树树树;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.友友树何树树友树友何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import cn.lzq.injection.asm.invoked.render.RenderNamePlateEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.scores.Team;
import org.joml.Vector3f;

public class 友何友树何何友何友树 extends Module implements 何树友 {
   private final ModeValue 树树友友树友树树何何;
   private final BooleanValue 友友树何友何树友友何;
   private final BooleanValue 何何友树何何树友友何;
   private final BooleanValue 何树树何树树树树何友;
   private final BooleanValue 友友何友何树何友友树;
   private final BooleanValue 友友树树树树友何何何;
   private final BooleanValue 何何树树何友树何树何;
   private final BooleanValue 何树何何树友何何友树;
   private static final DecimalFormat 何何树友友何何何何友;
   private static final Map<String, String> 树树友何树何树友友友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[45];
   private static final String[] k = new String[45];
   private static String HE_DA_WEI;

   public 友何友树何何友何友树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/render/友何友树何何友何友树.a J
      // 003: ldc2_w 37360990260870
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 12123
      // 00c: ldc2_w 1177339253393699111
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 8231
      // 019: ldc2_w 5416730473317809761
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w 8239976631909979691
      // 026: lload 1
      // 027: invokedynamic N (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/ModeValue
      // 033: dup
      // 034: sipush 16741
      // 037: ldc2_w 2129630473141378854
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 1166
      // 044: ldc2_w 7581612257685871341
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 2
      // 04f: anewarray 89
      // 052: dup
      // 053: bipush 0
      // 054: sipush 21668
      // 057: ldc2_w 720241941875903200
      // 05a: lload 1
      // 05b: lxor
      // 05c: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 061: aastore
      // 062: dup
      // 063: bipush 1
      // 064: sipush 6845
      // 067: ldc2_w 1972375592745698552
      // 06a: lload 1
      // 06b: lxor
      // 06c: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 071: aastore
      // 072: sipush 21668
      // 075: ldc2_w 720241941875903200
      // 078: lload 1
      // 079: lxor
      // 07a: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07f: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 082: putfield cn/cool/cherish/module/impl/render/友何友树何何友何友树.树树友友树友树树何何 Lcn/cool/cherish/value/impl/ModeValue;
      // 085: aload 0
      // 086: new cn/cool/cherish/value/impl/BooleanValue
      // 089: dup
      // 08a: sipush 5085
      // 08d: ldc2_w 8653255363264941440
      // 090: lload 1
      // 091: lxor
      // 092: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 097: sipush 7158
      // 09a: ldc2_w 3882190618143557006
      // 09d: lload 1
      // 09e: lxor
      // 09f: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a4: bipush 1
      // 0a5: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0a8: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0ab: putfield cn/cool/cherish/module/impl/render/友何友树何何友何友树.友友树何友何树友友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0ae: aload 0
      // 0af: new cn/cool/cherish/value/impl/BooleanValue
      // 0b2: dup
      // 0b3: sipush 26406
      // 0b6: ldc2_w 70177057690351940
      // 0b9: lload 1
      // 0ba: lxor
      // 0bb: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c0: sipush 680
      // 0c3: ldc2_w 5543055147849129175
      // 0c6: lload 1
      // 0c7: lxor
      // 0c8: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0cd: bipush 1
      // 0ce: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0d1: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0d4: putfield cn/cool/cherish/module/impl/render/友何友树何何友何友树.何何友树何何树友友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0d7: aload 0
      // 0d8: new cn/cool/cherish/value/impl/BooleanValue
      // 0db: dup
      // 0dc: sipush 15329
      // 0df: ldc2_w 8951700373599561141
      // 0e2: lload 1
      // 0e3: lxor
      // 0e4: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e9: sipush 13102
      // 0ec: ldc2_w 3877836036107513206
      // 0ef: lload 1
      // 0f0: lxor
      // 0f1: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f6: bipush 1
      // 0f7: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0fa: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0fd: putfield cn/cool/cherish/module/impl/render/友何友树何何友何友树.何树树何树树树树何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 100: aload 0
      // 101: new cn/cool/cherish/value/impl/BooleanValue
      // 104: dup
      // 105: sipush 18021
      // 108: ldc2_w 8983205096484395031
      // 10b: lload 1
      // 10c: lxor
      // 10d: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 112: sipush 9536
      // 115: ldc2_w 6261223266605939477
      // 118: lload 1
      // 119: lxor
      // 11a: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11f: bipush 1
      // 120: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 123: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 126: putfield cn/cool/cherish/module/impl/render/友何友树何何友何友树.友友何友何树何友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 129: aload 0
      // 12a: new cn/cool/cherish/value/impl/BooleanValue
      // 12d: dup
      // 12e: sipush 28179
      // 131: ldc2_w 5038256271754686540
      // 134: lload 1
      // 135: lxor
      // 136: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 13b: sipush 1458
      // 13e: ldc2_w 4352653794197773298
      // 141: lload 1
      // 142: lxor
      // 143: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 148: bipush 1
      // 149: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 14c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 14f: putfield cn/cool/cherish/module/impl/render/友何友树何何友何友树.友友树树树树友何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 152: aload 0
      // 153: new cn/cool/cherish/value/impl/BooleanValue
      // 156: dup
      // 157: sipush 10120
      // 15a: ldc2_w 8414832412258122194
      // 15d: lload 1
      // 15e: lxor
      // 15f: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 164: sipush 11136
      // 167: ldc2_w 8192724116475852242
      // 16a: lload 1
      // 16b: lxor
      // 16c: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 171: bipush 1
      // 172: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 175: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 178: putfield cn/cool/cherish/module/impl/render/友何友树何何友何友树.何何树树何友树何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 17b: aload 0
      // 17c: new cn/cool/cherish/value/impl/BooleanValue
      // 17f: dup
      // 180: sipush 14801
      // 183: ldc2_w 7053292545486366614
      // 186: lload 1
      // 187: lxor
      // 188: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 18d: sipush 20927
      // 190: ldc2_w 3059381308681342913
      // 193: lload 1
      // 194: lxor
      // 195: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何友树何何友何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 19a: bipush 1
      // 19b: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 19e: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1a1: putfield cn/cool/cherish/module/impl/render/友何友树何何友何友树.何树何何树友何何友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1a4: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-5964355844920426219L, -8385816275543372289L, MethodHandles.lookup().lookupClass()).a(136581656330987L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 4490167742493L;
      a();
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[57];
      int var5 = 0;
      String var4 = "\bè\u0010Òa\u0015«ZF¶5#'éN~\u0010f\u001b+¨[\u0080>`cMÛï\u009dwx\u0090\u0018\u000fM\"ýìæö[o \u008dEñ\u0000À@\u0096VAÆ\u0099©yà\u00183ú9=X\u0089³\u009ax\u0015µ¯\tB³60F\"\fD\u0085¼ð\u0010é±íBi]*\u0005ÝA}àK\u0015²ï\u0010¼aÚ»ëqAÀ&QØ¹\u0002¸\u009f¬\u0010¡\u008bµ\u008a¿G\u008cÓ\u0081î+\u0098\u008aý´\b\u0018?Ù\b\u0086\u008312eÅSít\u009f]ó4\u0082:\u0099\u0010Ìbü}\u0018n\u0083«Y\u009by\u0095?\u001dIf\u0093\u00ade§\u0088æÿÕ\u008dt\u0088\u001b\u0005\u0018Q©ÎG¹\fuçÀ\u001a«:x\u0098ðúIª\u008a\u0007\"¨\u0090Æ XhßÝ7<\u008bz\u009dJ\u0097w[ÉÔ¸@¾ì}n.»Ý©4ñ)3\u0019;É\u0018èbÈÿôúDo\u00953.Ýá\u0095\u008e\u0080â¡ë \u0082.[X\u0010éVk%\u009c\u008e\u0018\u0093{n!\u0082°J©Æ(¯¨Ã¦fÍzº¥ÔÄ>\u0080¡ù\u0014\u0092i\u00116ì28*\u0002o\r\bMAÝ©\bÈ¹PÕ\u0089¹y\u0010bl\u0004£5@ý|\b½u²^ºóÉ\u0010B~Ó\u0080Ñ\\ãq\u0015ÄëyÄðF~\u0010\u0095\u000e«YXß\u0083í\u0083çîÐM¯Ý\b\u0010«}õO\u000f×\u0086/{ÊÖ\u0098íù\u0084Y\u0010Å\u0007¨f´î¨sÿá®\u008c\u0006\u0013w× \u009cç\u0096\\a]Å¾\u008bOû'\u008c\u009e*(hñ\u009f³6À\u000f¬\u0080lNWÈ\u0084L%\u0010@jxÿ\u0094;,\u0083\t]¬\u0011'$\u009b±\u0018t´8é\"\u0017R\fð×\u0010<LÇ\u000f³\tJr\u0097þ\u0012Ty\u0010\b\u0080ÁJñ\u0015\u0095\u008d\u0004k+\u001eu{ Ù £¸&§1Òö\u009ckR\u0085Ôý²H©\u0097~ÍÇ$åH\u008fÛ·pâQ{Ã\u0005 \u0007×\u00040ôZè\u0005L\u0096ß)t6Ó\u009f\u0095ÓzKGu.ÝÙÞ\"¡\u0013\u0006)!\u0018\u008d\u0010:;M\u009e\u000e±u\u0093ÏÓõmUùG\u001fr~\u001d4\u00155 \u001bÑ\u0087J-ý\u0012ã\f\u0004W\u0090ßÃAz\u0092pÐøÇÌ\u008a¡4t\fdX¥`b â.P$\u001b\u0099\u0099§b?\u009fü\u0091yg}ÎÀØ\u0016?ª\u0014µ¢\u009bg¡\u0089\u0084ò¼\u0010Jù3nãþ\u0081s\u009c\u0087\u00814\u0087\u0004\u001b\u009f\u0018\u0010óì¦m\u001cP\u0088åh'Û\u000f¾Ðª$UÚÆm¸j\b\u0010\u008e\u0004±Ï\u0016;|ä\u000b¼\u0098Ñ£Ó\u0007Þ\u0010\u009dª<£ªß(\u0015æs\u0081\u0088nB\b  sß/rp¡·b\u001dª{\u0093TÐ:Ý\u0092Ø×ç\u000b}\u0000sg\u001dåúZ\u0081E=\u0010(2GÉm(zÂT\u00adV\ræ>\u009b\f\u0010\r\u0094\u008dPEÀ¦»mÑÄ\u0015br«Ç0\u0011\u008cë\tD\t/7ê\u0005Ö\u00024\nÈ\u000eå\u0084±éÈîíúöÍcZí\u0005Y hÒ\u009bA(\nö\u009eL\nxscy÷j\u0010\u0084.\u0082Æ]Ö\u0080¦ì7Ò\u0083L\u009d\u000e5\u0010\u000b\u0082\u0089\u0085Ðó\u0093%ÕJÏº@?7Ý(òñ¢ö\u0087\u0094¥jú\u00ad}Ás\u0081\u001d*=ò\u0089küm\u007fóÐq=v\\±/\u0091\"\u0083C:\u0013ÀÃc\u0018ptï\u0011-W\u0091\u0089Èù\u0086o\u0007·\u0015È\u0093ÒÖ?\u0006G\u0086| ÍøÕç´Ñ\u0007zÓ%æüÔ¨ÝáÎ-$¢+\u00ad\u007f\u0097\u009e\u0095z\u0084\u000b\u0084\u009eS\u0010ô¶å³\u001cã\"dÚ\f1múð\u0007Ë &\u0012ÒÚÈêç»i\u001aç¸\u0011\u008d¯\u000f¢käì[\u008bE&OÄ5å\u009b0\u0096\u008c\u0010Ò%Î\u0090oÙ\u0003¿3Üx\u001e\u0001:(\u0080 ºXëæº\u008c\\\u008csd\rl'û'<_h¼\u0089W@Ø\u0093\u00059¨ðÀ\u0093oí ÜìHÑ'\u008f$¤\u009fõt\u0002>l\u0005ØRf\u0089«-\u001c¶÷¬!×\u009f\u008bdQ¯\u0010\u0011F¡Q\u008c\u000bF\b\u009dp¡\u001b°\u0080\u0014: Ã»xÍD>\u0084ù\u0085c·\u0000\fã21ý\u0010£d{\u0098c½$ái{8\u0083ëí\u0010Ó\u00938\u0014\u0014¤\b\u001dñØS\u0014á\u0080mU\u0010(¯Á0$1ÁÔ¡-î°zØú` ^`ñ\u001eF6r\u0014\u0092\u009e\u0080^é\u0094Js®ß\u000bªY\u001c¹]ïÈío1\u008d¡\u0012 zõ(Ð\u000f\u007f\u0002{*\týB\u0019ý\u0094ñ²ÆrhµkÚúÝ_4¬ïç<\u009f\u0018sAÖn=\u009càp³G\u0088Ò<¾\u0081O,\u0017r6\\\u008dKm\u0018\u0015ûC÷Q\u0095\u0010\u0000Y\u0017¨¦Êy\u009b\bù\nóf\u0090X±t\u0010\u00812m\\`ØÅf+\u0083\u0002\b.\u001a\u0019Û";
      short var6 = 1334;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = c(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     c = var7;
                     h = new String[57];
                     何何树友友何何何何友 = new DecimalFormat(b<"h">(13242, 1397865520860320592L ^ var9), DecimalFormatSymbols.getInstance(Locale.ENGLISH));
                     树树友何树何树友友友 = Map.of(
                        b<"h">(30375, 6584506222391563860L ^ var9),
                        b<"h">(17308, 8940800830084424562L ^ var9),
                        b<"h">(12614, 9138504076859298208L ^ var9),
                        b<"h">(440, 5602099521677451636L ^ var9),
                        b<"h">(2641, 4962819368711285414L ^ var9),
                        b<"h">(20126, 6326222714846260808L ^ var9),
                        b<"h">(4519, 2957331195042361706L ^ var9),
                        b<"h">(16582, 3918514353352450086L ^ var9),
                        b<"h">(19086, 5461504624298043980L ^ var9),
                        b<"h">(6284, 1616690775359289459L ^ var9),
                        b<"h">(128, 1040953460108386427L ^ var9),
                        b<"h">(7633, 6910490366650907955L ^ var9),
                        b<"h">(31688, 5437746667728837437L ^ var9),
                        b<"h">(17763, 844273463852967313L ^ var9),
                        b<"h">(5068, 2171211973017858855L ^ var9),
                        b<"h">(20942, 526112008583295280L ^ var9),
                        b<"h">(9067, 9146366015681053612L ^ var9),
                        b<"h">(14286, 4095061755288311602L ^ var9),
                        b<"h">(15882, 3289232240139919074L ^ var9),
                        b<"h">(14645, 3008835485280754138L ^ var9)
                     );
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "ñÄmøH\u0001\u0004%$:õª\u001bÝ\u0095Â\u0010ßÖ\"þè1É»uíÂlë\u0014G\u0019";
                  var6 = 33;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void D(RenderNamePlateEvent event) {
      long a = 友何友树何何友何友树.a ^ 67299599799466L;
      long ax = a ^ 81939537547606L;
      c<"ã">(-6307309039057393154L, a);
      if (!this.w(new Object[]{ax})) {
         if (event.getEntity() instanceof Player) {
            event.setCancelled(true);
         }
      }
   }

   private List<ItemStack> S(Player player) {
      long a = 友何友树何何友何友树.a ^ 137075433783813L;
      ArrayList equipment = new ArrayList();
      c<"ã">(4528561043180044113L, a);
      Iterator var6 = player.getArmorSlots().iterator();
      if (var6.hasNext()) {
         ItemStack item = (ItemStack)var6.next();
         equipment.add(0, item);
      }

      equipment.add(player.getMainHandItem());
      equipment.add(player.getOffhandItem());
      equipment.removeIf(ItemStack::isEmpty);
      return equipment;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 57;
               case 1 -> 16;
               case 2 -> 49;
               case 3 -> 0;
               case 4 -> 22;
               case 5 -> 53;
               case 6 -> 13;
               case 7 -> 54;
               case 8 -> 6;
               case 9 -> 26;
               case 10 -> 40;
               case 11 -> 55;
               case 12 -> 29;
               case 13 -> 44;
               case 14 -> 51;
               case 15 -> 61;
               case 16 -> 34;
               case 17 -> 24;
               case 18 -> 4;
               case 19 -> 43;
               case 20 -> 12;
               case 21 -> 30;
               case 22 -> 60;
               case 23 -> 63;
               case 24 -> 48;
               case 25 -> 28;
               case 26 -> 17;
               case 27 -> 8;
               case 28 -> 14;
               case 29 -> 39;
               case 30 -> 32;
               case 31 -> 3;
               case 32 -> 37;
               case 33 -> 31;
               case 34 -> 2;
               case 35 -> 62;
               case 36 -> 7;
               case 37 -> 10;
               case 38 -> 23;
               case 39 -> 25;
               case 40 -> 36;
               case 41 -> 21;
               case 42 -> 5;
               case 43 -> 56;
               case 44 -> 27;
               case 45 -> 20;
               case 46 -> 42;
               case 47 -> 38;
               case 48 -> 18;
               case 49 -> 41;
               case 50 -> 47;
               case 51 -> 52;
               case 52 -> 11;
               case 53 -> 58;
               case 54 -> 33;
               case 55 -> 59;
               case 56 -> 15;
               case 57 -> 45;
               case 58 -> 50;
               case 59 -> 35;
               case 60 -> 46;
               case 61 -> 1;
               case 62 -> 19;
               default -> 9;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private boolean i(Player player) {
      long a = 友何友树何何友何友树.a ^ 103475117915668L;
      c<"ã">(-9022525407663520960L, a);
      return player == mc.player || !player.isAlive() || player.isSpectator() || player.isInvisibleTo(mc.player) || mc.player.distanceTo(player) > 128.0F;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何友树何何友何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27687;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何友树何何友何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private void s(GuiGraphics graphics, ItemStack stack, float x, float y) {
      long a = 友何友树何何友何友树.a ^ 124411495250214L;
      c<"ã">(431118281887712370L, a);
      Map enchants = EnchantmentHelper.getEnchantments(stack);
      if (!enchants.isEmpty()) {
         树树树友友树友树树树 fm = Cherish.instance.h();
         PoseStack poseStack = graphics.pose();
         Iterator var12 = enchants.entrySet().iterator();
         if (var12.hasNext()) {
            Entry<Enchantment, Integer> entry = (Entry<Enchantment, Integer>)var12.next();
            String name = entry.getKey().getDescriptionId();
            String shortName = name.substring(name.lastIndexOf(".") + 1);
            String text = c<"N">(430993304583414200L, a).getOrDefault(shortName, shortName.substring(0, Math.min(4, shortName.length())))
               + " "
               + entry.getValue();
            poseStack.pushPose();
            poseStack.translate(0.0F, 0.0F, 50.0F);
            fm.n(10).m(poseStack, text, x + 8.0F - fm.n(10).A(text) / 2, y + 0.0F, new Color(118, 4, 239, 181).getRGB());
            poseStack.popPose();
         }
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何友树何何友何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 221 && var8 != 251 && var8 != 'N' && var8 != 213) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'h') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 227) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 221) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'N') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private Color n(Entity entity) {
      long a = 友何友树何何友何友树.a ^ 106560929895000L;
      c<"ã">(7963967261234786060L, a);
      if (entity instanceof LivingEntity) {
         ;
      }

      return c<"N">(7964260380766718186L, a);
   }

   @EventTarget
   public void h(Render3DEvent event) {
      long a = 友何友树何何友何友树.a ^ 83522436649972L;
      long ax = a ^ 66271153542664L;
      long axx = a ^ 62223134782042L;
      long axxx = a ^ 48000780352111L;
      c<"ã">(3398415736342326944L, a);
      if (!this.w(new Object[]{ax})) {
         switch (c<"N">(3397212847883700002L, a)[event.side().ordinal()]) {
            case 1:
               友友树何树树友树友何.q(event.poseStack(), axxx);
            case 2:
               友友树何树树友树友何.e(axx);
         }
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "+&\"Rz\u0007$foYp\u001a!;d\u001fx\u0007,=`T;\u0001%8`\u001fg\r&,iC;厣伝厃栝佤佀厣伝厃栝";
      j[1] = "\u0010LN7&0\u001f\f\u0003<,-\u001aQ\bz?>\u001fW\u0005z 2\u0003NN\u0019&;\u0016t\u00018<:";
      j[2] = "X/A\\eHWo\fWoUR2\u0007\u0011|FW4\n\u0011cJK-A}eHW$\u000eQ\\FW4\n";
      j[3] = "X!AdD\u001aS.P+8\u0003\\4^h\u000f3J#Ru\u001e\u001f].";
      j[4] = "}_E*DNr\u001f\b!NSwB\u0003gFNzD\u0007,\u0005HsA\u0007gYDpU\u000e;\u0005c{E\u001f,Yb\u007f\\\u000e;J";
      j[5] = "7\u001a\t\u0015cw<\u0015\u0018Z\u001eo/\u0012\u0011\u0013";
      j[6] = "c|\u0019b2!le\u001b-X0jt\u0002bp\u0013fo\u0002bh";
      j[7] = "jR\u0001\r\u0013TjR\u0016Q\u001f[p\u0019\u0002L\fQ`\u0019\u0010M\nTpN[S\u0012\\}R\u0007\r.QeN\u0010Q";
      j[8] = double.class;
      k[8] = "java/lang/Double";
      j[9] = "#\u00100e`u,P}njh)\rv(bu$\u000brc!s-\u000er(}\u007f.\u001a{t!发伕厵栏体佚发伕厵栏\"叄栋桑厵栏栗叄发压伫";
      j[10] = "4D";
      j[11] = "pK\t* ^\u007f\u000bD!*CzVOg\"^wPK,a佤但叮佲伜厄佤但栴栶";
      j[12] = ">/\u001dHX\"1oPCR?42[\u0005R;8/G\u0005R;8/GX\u0019\b+$]_\u0013\u001e4%V";
      j[13] = "\u001bqz2Bd\u001bqmnNk\u0001:mpFh\u001b` QFc\u0010w|}Iy";
      j[14] = "_q\u001c\u001b\u0004&_q\u000bG\b)E:\u000bY\u0000*_`FR\u001c&\u001fR\u0007[\u001d";
      j[15] = "\u001f\u000bmF\u00023\u0010K M\b.\u0015\u0016+\u000b\u0018(\u0015\t0\u000b\u001f9\u0012\u0001&WC桍桭估厈叮厦厗伩桴厈";
      j[16] = "\u001a\n&Wc^\u0004\u0002<\u0018\u0000J\u0000";
      j[17] = "7x\nIa\u001b88GBk\u0006=eL\u0004c\u001b0cHO \u001d9fH\u0004c\u001d'u\n叡叅县企佃栵栻栟伡桅";
      j[18] = "\u0016NNRK\u000f\u000b[\u0016p\n\u0002\u0013]";
      j[19] = "`pf)L:k\u007fwf-4`ts<";
      j[20] = "t\u0003ZR/$ \u0014\u0016\tW栁佀厲叨佥厔佅叞伬叨8={dJVIijvK";
      j[21] = "I\u001d3I\\\t\u001bZ4F&伵伪伾桊召栿厫厴桺厐/\u0019UK[>TXQ\u0007\\";
      j[22] = "s+OqE\u0012s|\u000f\r佢栳栌伝桬栔栦栳佈厃u4PHh<\u001efRIp";
      j[23] = "6]_i%Pa\u0011\te\u0014_\\Z\u0007>)\f\\c\u000bpr]iX\tw/Z";
      j[24] = "\u0005{\u000f0eGPhV(_~r^2AoXTtT :K\rl";
      j[25] = "\u0006?M\u000bbY\u0006h\rwqaZo\u0010Ou\u0000[/\u000fK\u0018[[3O\u001ayZ\u001b,Kw";
      j[26] = "l9'0-R;uq<\u001c]\u0006>\u007fg!\r\u0006\u0007s)z_3<q.'X";
      j[27] = "=W\u001f~\f\u0003=\u0000_\u0002伫佦厘栥佸佟桯司厘佡%;\u0019Y&@Ni\u001bX>";
      j[28] = "\u0005TRi\u000e\u001eQC\u001e2v叡桵句叠佞桯使伱栿栺\u0003\u001cA\u0015\u001d^rHP\u0007\u001c";
      j[29] = "mvzHz\tm!:4參史栒佀厃佩栙史又佀@\roSva+_mRn";
      j[30] = "\u001e\u0005K\u0017,\r\u001eR\u000bk伋佨桡桷伬厨桏佨桡伳qR9W\u0005\u0012\u001a\u0000;V\u001d";
      j[31] = "e\u0002\u0018\u0012`>eUXn栃栟叀厪栻厭栃栟佞伴\"\u0012h|j\u001b@\u0013 w";
      j[32] = "\u0014x\u0001+gR\u0017eTu\u0003栭栲作桲栏栚佩叨参厨\u0016<MA<\u000fp?P\u0014b";
      j[33] = "-Weu\u0014G!Bgtr|\u0007c\u0018R%w\u001ce\t\u000e\u0019C{W>q\u0015VyV";
      j[34] = "ERg\u0003<WE\u0005'\u007f厅厬佾叺伀桦伛厬叠栠]F)\r^E6\u0014+\fF";
      j[35] = "@-\u0003\u0004gL@zCx叞厷栿桟栠桡叞伩佻伛9Ar\u0016[:R\u0013p\u0017C";
      j[36] = ">0J\u007fI\r>g\n\u0003株栬厛伆桩佞株叶厛厘piPLc&\u0001=A^b";
      j[37] = "\u0013\u0011ZI\u0001-\u0013F\u001a5伦栌伨伧桹叶伦佈厶档`\f\u0014w\b\u0006\u000b^\u0016v\u0010";
      j[38] = "mgI^pI&=N\u000b\t(VdO\u0016b\u001a2nF\u001egv";
      j[39] = "T\u000fBw\"aTX\u0002\u000b伅伄栫厧去佖伅伄佯厧x7h)\nY\u0003n$=P";
      j[40] = "NKr\rH~\\AoO:佇格栾栗你佧栃另佺栗=QvY\u0017|YC|DU";
      j[41] = ":\u0014G\u001d\u0000ve@\u001c\u0010m|\\LN\u0019S(\\}F[\u0014cu\u0017\u0013Q\b,";
      j[42] = "wVDJC0{CFK%\u0010\\l%|%$g\u0010\u0002WZ(r\u0012\u0003";
      j[43] = "*s.\u0010\u0004g~dbK|厘桚参厜厹伡伆伞参厜z\u00168::\"\u000bB)(;";
      j[44] = "+FU \u0018-|\n\u0003,)\"AA\rw\u0014pAx\u00019O tC\u0003>\u0012'";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private int k() {
      long a = 友何友树何何友何友树.a ^ 125090851347209L;
      c<"ã">(-6353273777201043875L, a);
      if (!c<"Ý">(this, -6352953293079151678L, a).getValue() && !c<"Ý">(this, -6351604905102679110L, a).getValue()) {
         return 70;
      } else {
         return c<"Ý">(this, -6352953293079151678L, a).getValue() && c<"Ý">(this, -6351604905102679110L, a).getValue() ? 106 : 88;
      }
   }

   private Color t(LivingEntity entity) {
      long a = 友何友树何何友何友树.a ^ 116455323923318L;
      c<"ã">(1129201772486987298L, a);
      Color componentColor = this.q(entity.getDisplayName());
      if (componentColor != null) {
         return componentColor;
      } else {
         if (entity instanceof Player player) {
            Team team = player.getTeam();
            if (team != null && team.getColor().getColor() != null) {
               return new Color(team.getColor().getColor());
            }

            if (c<"N">(1128168563804387437L, a) != null && c<"N">(1128168563804387437L, a).isEnabled()) {
               String teamColorName = c<"N">(1128168563804387437L, a).z(player);
               return (Color)c<"N">(1127871964635820431L, a).get(teamColorName != null ? teamColorName.toLowerCase() : null);
            }
         }

         return null;
      }
   }

   private void g(Render2DEvent event, Player player, Vector3f screenPos) {
      long a = 友何友树何何友何友树.a ^ 72372702635628L;
      c<"ã">(-7299891620926088392L, a);
      PoseStack poseStack = event.poseStack();
      poseStack.pushPose();
      poseStack.translate(screenPos.x(), screenPos.y(), 0.0F);
      if (c<"Ý">(this, -7299955923790573561L, a).getValue()) {
         float scale = Math.max(0.6F, Math.min(1.0F, 10.0F / mc.player.distanceTo(player)));
         poseStack.scale(scale, scale, 1.0F);
      }

      if (b<"h">(31611, 2451390322931240403L ^ a).equals(c<"Ý">(this, -7295855645119038844L, a).getValue())) {
         this.R(event, player);
      }

      this.q(event, player);
      poseStack.popPose();
   }

   @EventTarget
   public void v(Render2DEvent event) {
      long a = 友何友树何何友何友树.a ^ 129820435776007L;
      long ax = a ^ 1792298420219L;
      c<"ã">(9140799812887084883L, a);
      if (!this.w(new Object[]{ax}) && mc.level != null) {
         for (Player player : mc.level.players()) {
            if (!this.i(player)) {
               Vector3f pos = this.u(player, event.partialTick());
               this.g(event, player, pos);
               break;
            }
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void q(Render2DEvent event, Player player) {
      long a = 友何友树何何友何友树.a ^ 124209445987131L;
      long ax = a ^ 99498801771923L;
      树树树友友树友树树树 fm = Cherish.instance.h();
      c<"ã">(2298702892858941039L, a);
      PoseStack poseStack = event.guiGraphics().pose();
      StringBuilder text = new StringBuilder(this.z(player));
      if (c<"Ý">(this, 2299025558559507440L, a).getValue()) {
         text.append(b<"h">(29917, 7162853579477583627L ^ a))
            .append(c<"N">(2298800847533683251L, a).format(mc.player.distanceTo(player)))
            .append(b<"h">(24439, 258919943869213841L ^ a));
      }

      if (c<"Ý">(this, 2299247926097763208L, a).getValue()) {
         text.append(b<"h">(22113, 679558219114194316L ^ a))
            .append(c<"N">(2298800847533683251L, a).format(player.getHealth()))
            .append(b<"h">(16840, 5760353277073142315L ^ a));
      }

      String fullText = text.toString();
      float width = fm.n(20).A(fullText);
      float height = fm.n(20).K();
      RenderUtils.K(
         poseStack, ax, -width / 2.0F - 5.0F, -height / 2.0F - 8.0F, width / 2.0F + 5.0F, height / 2.0F - 2.0F, 4.0, 100.0, new Color(20, 20, 20, 180)
      );
      fm.n(20).c(poseStack, fullText, -width / 2.0F, -height, this.n(player).getRGB());
      if (c<"Ý">(this, 2299844874707941590L, a).getValue()) {
         this.Y(event, player, height / 2.0F - 44.0F);
      }
   }

   private Color q(Component component) {
      long a = 友何友树何何友何友树.a ^ 30454565606462L;
      c<"ã">(7558106010044492138L, a);
      if (component.getStyle().getColor() != null) {
         return new Color(component.getStyle().getColor().getValue());
      } else {
         String text = component.getString();
         if (text.length() < 2) {
            return null;
         } else {
            int i = 0;
            if (0 < text.length() - 1) {
               if (text.charAt(0) == 167) {
                  String colorCode = String.valueOf(text.charAt(1)).toLowerCase();
                  if (c<"N">(7557238336475402814L, a).containsKey(colorCode)) {
                     return (Color)c<"N">(7557238336475402814L, a).get(colorCode);
                  }
               }

               i++;
            }

            return null;
         }
      }
   }

   private String z(Player player) {
      long a = 友何友树何何友何友树.a ^ 123174377506817L;
      c<"ã">(-5414273521337060011L, a);
      StringBuilder name = new StringBuilder();
      if (何友友友树树树树树树.l(player)) {
         name.append(b<"h">(5401, 1874957631017569769L ^ a));
      }

      if (何友友友树树树树树树.B(player)) {
         name.append(b<"h">(6390, 5002455330889744432L ^ a));
      }

      if (c<"Ý">(this, -5417178385052098420L, a).getValue()) {
         if (何友友友树树树树树树.c(player)) {
            name.append(b<"h">(7644, 5300142291927811382L ^ a));
         }

         if (何友友友树树树树树树.X(player)) {
            name.append(b<"h">(8236, 7596703753310763229L ^ a));
         }

         if (何友友友树树树树树树.k(player)) {
            name.append(b<"h">(16523, 9098577831536662627L ^ a));
         }

         if (何友友友树树树树树树.y(player)) {
            name.append(b<"h">(32174, 2164080727197885818L ^ a));
         }

         if (何友友友树树树树树树.C(player)) {
            name.append(b<"h">(14618, 3926024555243954683L ^ a));
         }
      }

      String teamColorCode = c<"N">(-5417248363981362168L, a).getOrDefault(this.n(player), b<"h">(31284, 6522366324906336985L ^ a));
      name.append(teamColorCode).append(player.getName().getString()).append(b<"h">(17319, 3614050474831518529L ^ a));
      return name.toString();
   }

   private Vector3f u(Player player, float partialTick) {
      long a = 友何友树何何友何友树.a ^ 6064535196951L;
      long ax = a ^ 99786181498218L;
      double x = Mth.lerp(partialTick, c<"Ý">(player, -6212639598190215534L, a), player.getX());
      double y = Mth.lerp(partialTick, c<"Ý">(player, -6213136119645617609L, a), player.getY()) + player.getBbHeight() + 0.5;
      double z = Mth.lerp(partialTick, c<"Ý">(player, -6213344611917512937L, a), player.getZ());
      return 友友树何树树友树友何.J((float)x, (float)y, (float)z, (float)mc.getWindow().getGuiScale(), ax);
   }

   private Color r(float health) {
      float percent = health / 20.0F;

      long var10000 = 友何友树何何友何友树.a ^ 16051886974L;
      return switch ((int)(percent * 4.0F)) {
         case 1 -> new Color(255, 165, 0);
         case 2 -> new Color(255, 255, 85);
         case 3, 4 -> new Color(85, 255, 85);
         default -> new Color(255, 85, 85);
      };
   }

   private void Y(Render2DEvent event, Player player, float yOffset) {
      long a = 友何友树何何友何友树.a ^ 31023277675037L;
      long ax = a ^ 60192727876789L;
      c<"ã">(-1242766057336148151L, a);
      List equipment = this.S(player);
      if (!equipment.isEmpty()) {
         GuiGraphics graphics = event.guiGraphics();
         PoseStack poseStack = graphics.pose();
         float boxWidth = equipment.size() * 16 + 8;
         float boxX = -boxWidth / 2.0F;
         RenderUtils.K(poseStack, ax, boxX, yOffset, boxX + boxWidth, yOffset + 24.0F, 4.0, 100.0, new Color(20, 20, 20, 180));
         int i = 0;
         if (0 < equipment.size()) {
            ItemStack stack = (ItemStack)equipment.get(0);
            if (event.side() == c<"N">(-1238649377435250401L, a)) {
               graphics.renderItem(stack, (int)(boxX + 4.0F + 0.0F), (int)(yOffset + 4.0F));
               graphics.renderItemDecorations(c<"Ý">(mc, -1242130559524982927L, a), stack, (int)(boxX + 4.0F + 0.0F), (int)(yOffset + 4.0F));
            }

            if (c<"Ý">(this, -1242486947174906208L, a).getValue()) {
               this.s(graphics, stack, boxX + 4.0F + 0.0F, yOffset - 8.0F);
            }

            i++;
         }
      }
   }

   private void R(Render2DEvent event, Player player) {
      long a = 友何友树何何友何友树.a ^ 137303691904138L;
      long ax = a ^ 95009450988066L;
      c<"ã">(-5163467075302540834L, a);
      树树树友友树友树树树 fm = Cherish.instance.h();
      PoseStack poseStack = event.guiGraphics().pose();
      String name = this.z(player);
      String health = c<"Ý">(this, -5162921938985419719L, a).getValue()
         ? c<"N">(-5163386697849563774L, a).format(player.getHealth()) + b<"h">(32223, 4206155196425185705L ^ a)
         : "";
      String distance = c<"Ý">(this, -5163716138540702655L, a).getValue()
         ? "[" + c<"N">(-5163386697849563774L, a).format(mc.player.distanceTo(player)) + b<"h">(14887, 7101330280333176442L ^ a)
         : "";
      float maxWidth = Math.max(fm.n(24).A(name), Math.max(fm.n(16).A(health), fm.n(16).A(distance)));
      float totalWidth = maxWidth + 10.0F;
      float totalHeight = fm.n(24).K()
         + 10
         + (c<"Ý">(this, -5162921938985419719L, a).getValue() ? fm.n(16).K() + 2 : 0)
         + (c<"Ý">(this, -5163716138540702655L, a).getValue() ? fm.n(16).K() + 2 : 0);
      RenderUtils.K(poseStack, ax, -totalWidth / 2.0F, -totalHeight - 1.0F, totalWidth / 2.0F, 0.0, 4.0, 100.0, new Color(20, 20, 20, 180));
      if (c<"Ý">(this, -5162921938985419719L, a).getValue()) {
         float healthPercent = player.getHealth() / player.getMaxHealth();
         RenderUtils.drawRectangle(poseStack, -totalWidth / 2.0F + 3.0F, -2.0F, (totalWidth - 6.0F) * healthPercent, 1.0F, this.r(player.getHealth()).getRGB());
      }

      float y = -totalHeight + 5.0F;
      fm.n(24).c(poseStack, name, -totalWidth / 2.0F + 5.0F, y, this.n(player).getRGB());
      if (c<"Ý">(this, -5162921938985419719L, a).getValue()) {
         y += fm.n(24).K() + 2;
         fm.n(16).c(poseStack, health, -totalWidth / 2.0F + 5.0F, y, this.r(player.getHealth()).getRGB());
      }

      if (c<"Ý">(this, -5163716138540702655L, a).getValue()) {
         y += fm.n(16).K() + 2;
         fm.n(16)
            .c(
               poseStack,
               distance,
               (double)(-totalWidth / 2.0F + 5.0F),
               y + (!c<"Ý">(this, -5162921938985419719L, a).getValue() ? 5.0 : 0.5),
               c<"N">(-5163849056438720375L, a).getRGB()
            );
      }

      if (c<"Ý">(this, -5162325095672733849L, a).getValue()) {
         this.Y(event, player, totalHeight - this.k());
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖诈骗";
   }
}
