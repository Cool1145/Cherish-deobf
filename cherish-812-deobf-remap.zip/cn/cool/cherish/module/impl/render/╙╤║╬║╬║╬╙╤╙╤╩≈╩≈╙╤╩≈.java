package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友何何何友友树树友树 extends Module implements 何树友 {
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[27];
   private static final String[] k = new String[27];
   private static String HE_WEI_LIN;

   public 友何何何友友树树友树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/render/友何何何友友树树友树.a J
      // 03: ldc2_w 89672392717492
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 23938
      // 0c: ldc2_w 6997108877092963836
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic b (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何何友友树树友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 21259
      // 19: ldc2_w 1756132239013759860
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic b (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何何友友树树友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 5750316433845897909
      // 26: lload 1
      // 27: invokedynamic ï (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/友何何何友友树树友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2867538326559638493L, 9170078249933316692L, MethodHandles.lookup().lookupClass()).a(152190554380487L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 130045227037895L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = ' ';
      int var4 = -1;

      while (true) {
         String var13 = c(
               var2.doFinal(
                  "Õ\u0007\u008c|ï\u0010î\u0084\u0005ñ*\u0081 \u00adÜèr\u0013åû\u0011®þvè\u0001gÖ¿\u0015qÇ\u0010p\u0082µz¿JêØuE\u0095Á^ºÉÍ"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 49) {
            c = var9;
            h = new String[2];
            return;
         }

         var5 = "Õ\u0007\u008c|ï\u0010î\u0084\u0005ñ*\u0081 \u00adÜèr\u0013åû\u0011®þvè\u0001gÖ¿\u0015qÇ\u0010p\u0082µz¿JêØuE\u0095Á^ºÉÍ".charAt(var4);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 48;
               case 1 -> 20;
               case 2 -> 33;
               case 3 -> 7;
               case 4 -> 17;
               case 5 -> 45;
               case 6 -> 11;
               case 7 -> 24;
               case 8 -> 10;
               case 9 -> 61;
               case 10 -> 16;
               case 11 -> 41;
               case 12 -> 6;
               case 13 -> 1;
               case 14 -> 56;
               case 15 -> 5;
               case 16 -> 60;
               case 17 -> 2;
               case 18 -> 27;
               case 19 -> 50;
               case 20 -> 29;
               case 21 -> 30;
               case 22 -> 3;
               case 23 -> 62;
               case 24 -> 9;
               case 25 -> 13;
               case 26 -> 63;
               case 27 -> 28;
               case 28 -> 40;
               case 29 -> 12;
               case 30 -> 23;
               case 31 -> 59;
               case 32 -> 43;
               case 33 -> 19;
               case 34 -> 21;
               case 35 -> 54;
               case 36 -> 31;
               case 37 -> 22;
               case 38 -> 53;
               case 39 -> 47;
               case 40 -> 32;
               case 41 -> 51;
               case 42 -> 8;
               case 43 -> 36;
               case 44 -> 26;
               case 45 -> 15;
               case 46 -> 25;
               case 47 -> 44;
               case 48 -> 46;
               case 49 -> 35;
               case 50 -> 34;
               case 51 -> 57;
               case 52 -> 4;
               case 53 -> 39;
               case 54 -> 42;
               case 55 -> 52;
               case 56 -> 58;
               case 57 -> 55;
               case 58 -> 37;
               case 59 -> 49;
               case 60 -> 38;
               case 61 -> 14;
               case 62 -> 0;
               default -> 18;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 22454;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何何友友树树友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何何友友树树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何何友友树树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @EventTarget
   public void c(Render3DEvent event) {
      long a = 友何何何友友树树友树.a ^ 16170387217302L ^ 123848442452419L;
      if (!this.w(new Object[]{a})) {
         ;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 163 && var8 != 'x' && var8 != 239 && var8 != 234) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 222) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 197) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 163) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'x') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "\u0004~ttv4\u000b>9\u007f|)\u000ec29t4\u0003e6r7伎伲叛伏佂叒伎伲栁桋";
      j[1] = "`|LV\u000fxirO\u001fLuor[\u001dQs-eD\n\u0016r{=w\u001d\u0010cfkg\u0017\u0010zbg\u00055\rsf";
      j[2] = "|O\u0019}w\u0014uA\u001a44\u0019sA\u000e6)\u001f1V\u0011!n\u001eg\u000e06|\u001ajL\u0000\u0005\u007f\tkE\f\u0015u\trA\u0000";
      j[3] = "O}\u001c2AFFs\u001f{\u0002K@s\u000by\u001fM\u0002d\u0014nXLT<'y^]Ij7s^DMf";
      j[4] = "3t\u0007Osq<4JDyl9iA\u0002qq4oEI2w=jE\u0002n{>~L^2叕伅住佼叧受栏桁发核";
      j[5] = ":^\u0015+*%1Q\u0004dV<>K\n'a\f(\\\u0006:p ?Q";
      j[6] = "j\u001d(L{\be]eGq\u0015`\u0000n\u0001y\bm\u0006jJ:\u000ed\u0003j\u0001f\u0002g\u0017c]:%l\u0007rJf$h\u001ec]u";
      j[7] = "\u001b<1,6[\u00103 cKC\u00034)*";
      j[8] = "#NS\b\u000e\u0003#NDT\u0002\f9\u0005DJ\n\u000f#_\tV\u000f\u000b4NU\b/\u0005.JKv\u000f\u000b4NU";
      j[9] = double.class;
      k[9] = "java/lang/Double";
      j[10] = "j+V;UZj+AgYUp`AyQVj:\fXQ]a-Pt^G";
      j[11] = "-lK\u00015W-l\\]9X7'\\C1[-}\u0011]=P'lMJ*\u0010\u0004hRJ\n[-mZ]=L";
      j[12] = "\u0004c\u0000T\u0015Z\u0004c\u0017\b\u0019U\u001e(\u0003\u0015\n_\u000e(\u0004\u0012\u0001@DP\u0011\u0019K";
      j[13] = "\u001f\u0002\u0012\u0019*S\u0014\r\u0003VK]\u001f\u0006\u0007\f";
      j[14] = "Ca\u007f\u007fy\u0014\u0002)s@J:qDN\u0017B6}TZ@~\u000fE&~#?GI";
      j[15] = "?`!{\u000e;<9#.27Q0zu\u000bdQ\u0000}<@cf;8tS+";
      j[16] = "[@ :5&U\u0000fZ桃桕佯栠桅桃伇厏叱叺\\3#0RV6=cv";
      j[17] = "~~f//4\"q#r^=\u00147l*oj\u0014\u000ec\u007f`:}29l;1";
      j[18] = "m\u0016?\\@],^3css_3\u000e4{\u007fS#\u00168cdT6A\u001bG@*\u0011\"Z\u000fL";
      j[19] = "]\boh0W\u0001\u0007*5A^7Aemp\n7xj8\u007fY^D0+$R";
      j[20] = "z\u007f_,D\u0004&p\u001aq5\r\u00106U)\u0004[\u0010\u000fZ|\u000b\ny3\u0000oP\u0001";
      j[21] = "eXt\u0001\u000eo#\t{\u00045d\rY?U\u000b1\rh6QD19\u0002;W\u000ex";
      j[22] = "iwHK\n\u0013<-\n[u\u0007Ru\rVMR 1\u0017QOni0\f\u0011I\u001c-*\u000b\u0013u";
      j[23] = "\u0017dp4XHV5zu'|+f)cVKG)kn\u001d\"";
      j[24] = "1{!|3);i x\u000e,V+w%>{V\u001bss0+?')`k ";
      j[25] = "-0Q\n&x'\"P\u000e\u001b}J`\u0007S++JP\u0003\u0005%z#lY\u0016~q";
      j[26] = "='}\u0015%`75|\u0011\u0018eZw+L':ZG/\u001a&b3{u\t}i";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void M(PoseStack poseStack, float radius, float yOffset, float lineWidth, Color color, float lineLength) {
      long a = 友何何何友友树树友树.a ^ 97382449450313L;
      c<"Å">(-706547934885787670L, a);
      RenderSystem.lineWidth(lineWidth * (float)mc.getWindow().getGuiScale());
      Tesselator tesselator = Tesselator.getInstance();
      BufferBuilder bufferBuilder = tesselator.getBuilder();
      bufferBuilder.begin(c<"ï">(-706904285134143393L, a), c<"ï">(-704869041840006976L, a));
      int i = 0;
      double x = Math.cos(0.0) * radius;
      double z = Math.sin(0.0) * radius;
      bufferBuilder.vertex(poseStack.last().pose(), (float)x, yOffset, (float)z)
         .color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F)
         .endVertex();
      i++;
      tesselator.end();
      bufferBuilder.begin(c<"ï">(-704932528863602816L, a), c<"ï">(-704869041840006976L, a));
      float r = color.getRed() / 255.0F;
      float g = color.getGreen() / 255.0F;
      float b = color.getBlue() / 255.0F;
      float ax = color.getAlpha() / 255.0F;
      bufferBuilder.vertex(poseStack.last().pose(), 0.0F, yOffset, -radius).color(r, g, b, ax).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), 0.0F, yOffset, -radius - lineLength).color(r, g, b, ax).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), 0.0F, yOffset, radius).color(r, g, b, ax).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), 0.0F, yOffset, radius + lineLength).color(r, g, b, ax).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), radius, yOffset, 0.0F).color(r, g, b, ax).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), radius + lineLength, yOffset, 0.0F).color(r, g, b, ax).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), -radius, yOffset, 0.0F).color(r, g, b, ax).endVertex();
      bufferBuilder.vertex(poseStack.last().pose(), -radius - lineLength, yOffset, 0.0F).color(r, g, b, ax).endVertex();
      tesselator.end();
   }

   private static String HE_DA_WEI() {
      return "何炜霖230622200409390090";
   }
}
