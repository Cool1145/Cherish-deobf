package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// $VF: synthetic class
class 树何树何何友树友树何$何树何何友何树树树树 implements 何树友 {
   private static final Object[] a = new Object[10];
   private static final String[] b = new String[10];
   private static String LIU_YA_FENG;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-7742573803277121725L, 8423119855929358819L, MethodHandles.lookup().lookupClass()).a(188789032675493L);
      // $VF: monitorexit
      long var0 = var10000 ^ 39547787423620L;
      a();

      try {
         a<"î">(1636725180559134811L, var0)[a<"î">(1636288129940910883L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"î">(1636725180559134811L, var0)[a<"î">(1636615500509816920L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"î">(1636725180559134811L, var0)[a<"î">(1636667949813406361L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"î">(1636725180559134811L, var0)[a<"î">(1636499170547777981L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"î">(1636725180559134811L, var0)[a<"î">(1636246044407503028L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 224 && var8 != 195 && var8 != 238 && var8 != 'V') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 243) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 170) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 224) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 195) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 238) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树何树何何友树友树何$何树何何友何树树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 11;
               case 1 -> 22;
               case 2 -> 45;
               case 3 -> 8;
               case 4 -> 7;
               case 5 -> 25;
               case 6 -> 30;
               case 7 -> 50;
               case 8 -> 62;
               case 9 -> 0;
               case 10 -> 33;
               case 11 -> 36;
               case 12 -> 34;
               case 13 -> 41;
               case 14 -> 55;
               case 15 -> 54;
               case 16 -> 61;
               case 17 -> 28;
               case 18 -> 35;
               case 19 -> 43;
               case 20 -> 10;
               case 21 -> 39;
               case 22 -> 23;
               case 23 -> 18;
               case 24 -> 17;
               case 25 -> 29;
               case 26 -> 3;
               case 27 -> 5;
               case 28 -> 63;
               case 29 -> 47;
               case 30 -> 1;
               case 31 -> 32;
               case 32 -> 9;
               case 33 -> 20;
               case 34 -> 6;
               case 35 -> 49;
               case 36 -> 60;
               case 37 -> 59;
               case 38 -> 4;
               case 39 -> 58;
               case 40 -> 31;
               case 41 -> 57;
               case 42 -> 42;
               case 43 -> 2;
               case 44 -> 19;
               case 45 -> 12;
               case 46 -> 15;
               case 47 -> 56;
               case 48 -> 24;
               case 49 -> 16;
               case 50 -> 52;
               case 51 -> 37;
               case 52 -> 38;
               case 53 -> 40;
               case 54 -> 21;
               case 55 -> 26;
               case 56 -> 51;
               case 57 -> 46;
               case 58 -> 14;
               case 59 -> 27;
               case 60 -> 44;
               case 61 -> 13;
               case 62 -> 53;
               default -> 48;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "8\u000f\u0012a\r?7O_j\u0007\"2\u0012T,\u000f??\u0014PgL96\u0011P,\u001055\u0005YpL桁伎桰佩佗厩桁厐桰佩&厩厛桊桰佩佗伷厛伎伴";
      a[1] = "\f++IHl\u0003kfBBq\u00066m\u0004Jl\u000b0iO\tj\u00025i\u0004Uf\u0001!`X\t栒伺桔佐使召栒厤桔佐\u000e佲栒伺伐収使栶栒桾桔";
      a[2] = "lz";
      a[3] = "E4q.=JN;`a\\DE0d;";
      a[4] = "nxxZG\u0000l8#1厽厣參桜栊佬伣伽栙历\u0013_C\u000bk|s]\u0003P";
      a[5] = "Gtr\u0004?\u0002E4)o叅伿栰伔栀厬栟伿只伔\u0019\u0001;\tBpy\u0003{R";
      a[6] = "A=\u000f#e\u000fO%VB佞厡你休佮厁佞伿栤厏3{y\u000fMuY{>\u0010^";
      a[7] = "\u0018k\u0003^T\u0013\u001a+X5估厰伫厕厫叶厮厰桯厕h[P\u0018\u001do\bY\u0010C";
      a[8] = "w\n#\u0012$6uJxy佀伋叚叴伕桠栄桏佄栮H\u0017 =r\u000e(\u0015`f";
      a[9] = "\u0011mh :\u001a\u0013-3K叀档厼伍佞伖栚伧桦桉\u0003%>\u0011\u0014ic'~J";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String HE_DA_WEI() {
      return "何炜霖大狗叫";
   }
}
