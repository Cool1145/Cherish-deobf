package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;

public class 友友友友何树友何树树 extends Module implements 何树友 {
   private final ModeValue 友何树友友何友何友何;
   private final 树友树友友何何树何何 友何友友友友何树树友;
   private boolean 树何何何何何树友树友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[26];
   private static final String[] k = new String[26];
   private static String LIU_YA_FENG;

   public 友友友友何树友何树树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/combat/友友友友何树友何树树.a J
      // 03: ldc2_w 32472491714453
      // 06: lxor
      // 07: lstore 1
      // 08: lload 1
      // 09: dup2
      // 0a: ldc2_w 9007145329906
      // 0d: lxor
      // 0e: lstore 3
      // 0f: pop2
      // 10: aload 0
      // 11: sipush 18394
      // 14: ldc2_w 5859942632562560564
      // 17: lload 1
      // 18: lxor
      // 19: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友友何树友何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e: sipush 23590
      // 21: ldc2_w 8739693849494918606
      // 24: lload 1
      // 25: lxor
      // 26: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友友何树友何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2b: ldc2_w 5724484171095631104
      // 2e: lload 1
      // 2f: invokedynamic E (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/combat/友友友友何树友何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 34: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 37: aload 0
      // 38: new cn/cool/cherish/value/impl/ModeValue
      // 3b: dup
      // 3c: bipush 40
      // 3e: ldc2_w 182910062858258883
      // 41: lload 1
      // 42: lxor
      // 43: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友友何树友何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 48: sipush 14675
      // 4b: ldc2_w 7126242417005949116
      // 4e: lload 1
      // 4f: lxor
      // 50: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友友何树友何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 55: bipush 2
      // 56: anewarray 85
      // 59: dup
      // 5a: bipush 0
      // 5b: sipush 25710
      // 5e: ldc2_w 8870771431442492802
      // 61: lload 1
      // 62: lxor
      // 63: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友友何树友何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 68: aastore
      // 69: dup
      // 6a: bipush 1
      // 6b: sipush 5072
      // 6e: ldc2_w 6373643554817235517
      // 71: lload 1
      // 72: lxor
      // 73: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友友何树友何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 78: aastore
      // 79: sipush 25710
      // 7c: ldc2_w 8870771431442492802
      // 7f: lload 1
      // 80: lxor
      // 81: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友友何树友何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 86: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 89: putfield cn/cool/cherish/module/impl/combat/友友友友何树友何树树.友何树友友何友何友何 Lcn/cool/cherish/value/impl/ModeValue;
      // 8c: aload 0
      // 8d: new cn/cool/cherish/utils/树友树友友何何树何何
      // 90: dup
      // 91: lload 3
      // 92: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 95: putfield cn/cool/cherish/module/impl/combat/友友友友何树友何树树.友何友友友友何树树友 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 98: aload 0
      // 99: bipush 0
      // 9a: ldc2_w 5724248807482071091
      // 9d: lload 1
      // 9e: invokedynamic Å (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/友友友友何树友何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // a3: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(3941656381609509890L, -4403469338198903244L, MethodHandles.lookup().lookupClass()).a(23572116966687L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 15788397521084L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[8];
      int var7 = 0;
      String var6 = "Pð¯êl¼ë\u000f!o-öd\u009e \u0094\u0010iHÀ\u001cKÕÆ±à\u0096f£\u0094\u0012vP\u0010÷0-KG\u008fr\u0080Öÿ\u0010H@e\u0013l\u0010³£Æ\u0001µ\u007fÂ0ëH¼Å#\u008eMa\u0018K\u0091±m*tª_²q\\;*â¡'s*\tóÔpú^\u0010+Þ$)\u0082Æ·\u0015q¿sÇU9xy";
      byte var8 = 109;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[8];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = ";X\u000e\u009c«\u0094\u009f\u008c«\u0007=O§\u009d\u0014 \u0010^R°ÔJGm\rN\u008a'ÊÁ\u008cÂs";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 友友友友何树友何树树.a ^ 67243055349010L;
      long ax = a ^ 32995681248869L;
      c<"Å">(this, false, 6194627993543115444L, a);
      c<"Â">(this, 6193677475307276230L, a).U(ax);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private void i(Class<?> packetType, Object... params) {
      long a = 友友友友何树友何树树.a ^ 91297976688188L;
      c<"i">(3954034136192022701L, a);
      if (packetType == PosRot.class) {
         c<"Â">(mc.player, 3952078156924004356L, a)
            .send(new PosRot((Double)params[0], (Double)params[1], (Double)params[2], (Float)params[3], (Float)params[4], false));
      }

      if (packetType == Pos.class) {
         c<"Â">(mc.player, 3952078156924004356L, a).send(new Pos((Double)params[0], (Double)params[1], (Double)params[2], false));
      }

      if (packetType == Rot.class) {
         c<"Â">(mc.player, 3952078156924004356L, a).send(new Rot((Float)params[0], (Float)params[1], false));
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 5;
               case 1 -> 45;
               case 2 -> 58;
               case 3 -> 53;
               case 4 -> 2;
               case 5 -> 17;
               case 6 -> 11;
               case 7 -> 33;
               case 8 -> 57;
               case 9 -> 24;
               case 10 -> 4;
               case 11 -> 37;
               case 12 -> 6;
               case 13 -> 28;
               case 14 -> 26;
               case 15 -> 15;
               case 16 -> 21;
               case 17 -> 40;
               case 18 -> 0;
               case 19 -> 27;
               case 20 -> 63;
               case 21 -> 61;
               case 22 -> 59;
               case 23 -> 1;
               case 24 -> 20;
               case 25 -> 50;
               case 26 -> 7;
               case 27 -> 60;
               case 28 -> 43;
               case 29 -> 62;
               case 30 -> 48;
               case 31 -> 16;
               case 32 -> 14;
               case 33 -> 36;
               case 34 -> 38;
               case 35 -> 13;
               case 36 -> 30;
               case 37 -> 49;
               case 38 -> 55;
               case 39 -> 34;
               case 40 -> 3;
               case 41 -> 56;
               case 42 -> 35;
               case 43 -> 19;
               case 44 -> 25;
               case 45 -> 18;
               case 46 -> 42;
               case 47 -> 51;
               case 48 -> 52;
               case 49 -> 12;
               case 50 -> 22;
               case 51 -> 44;
               case 52 -> 32;
               case 53 -> 23;
               case 54 -> 9;
               case 55 -> 47;
               case 56 -> 39;
               case 57 -> 10;
               case 58 -> 31;
               case 59 -> 29;
               case 60 -> 41;
               case 61 -> 46;
               case 62 -> 8;
               default -> 54;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 1695;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友友何树友何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友友何树友何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 194 && var8 != 197 && var8 != 'E' && var8 != 'J') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'j') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'i') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 194) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 197) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'E') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友友何树友何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "z\bttNYuH9\u007fDDp\u001529LY}\u00136r\u000f_t\u001669BYt\u0004;c\u000f叽叒厭厑佂栰叽佌桷桋";
      j[1] = boolean.class;
      k[1] = "java/lang/Boolean";
      j[2] = "v#g2&Gyc*9,Z|>!\u007f<\\|!:\u007f桘口栄历厂伄伜根佀优";
      j[3] = "@s\u0013bTDO3^i^YJnU/VDGhQd\u0015佾佶取佨佔台佾佶栌栬";
      j[4] = "f \bhAyi`EcKdl=N%Cya;Jn\u0000\u007fh>J%Myh,G\u007f\u0000]l\"JJ[dd";
      j[5] = "\t\u0003d]\u000e\u0012= k\u001dC\u00197=n@H_? cFL\u0014|\u0002hWU\u001d7t";
      j[6] = "\u000brs=\u0016\u0012\u0000}brj\u000b\u000fgl1];\u0019p`,L\u0017\u000e}";
      j[7] = "w]\u0004Q=%x\u001dIZ78}@B\u001c$+xFO\u001c;'d_\u0004\u007f=.qeK^'/";
      j[8] = "LYf\u001aD\u0005LYqFH\nV\u0012qX@\tLH<DE\r[Y`\u001ae\u0003A]~dE\r[Y`";
      j[9] = "o\u0007e(\u0004\u0017o\u0007rt\b\u0018uLrj\u0000\u001bo\u0016?k\u001c\u0012u\u000baj\b\u0007d\u0010?E\u0005\u0017d\feV\b\u001dj\u0007eJ\u0000\ru\u0007\u007fc\u001b";
      j[10] = float.class;
      k[10] = "java/lang/Float";
      j[11] = "B%\u0000\u001e*qB%\u0017B&~Xn\u0017\\.}B4Z}.vI#\u0006Q!l";
      j[12] = "`6\u0005\r@\u001c`6\u0012QL\u0013z}\u0012OD\u0010`'_l]\u0001g<\u001fP";
      j[13] = "\u001c?LW\u0002{\u001c?[\u000b\u000et\u0006t[\u0015\u0006w\u001c.\u00162\nk?;H\t\u0006|\u0015";
      j[14] = "\u0010xP~\u0019K\u001bwA1xE\u0010|Ek";
      j[15] = "I\bH\u0006Fs\u0015\u001c\u0017\u0010}\u0013sC\u0015\f\u00163B\u0019\u0015\u001aGB";
      j[16] = "ro^\u0000g5jz\u001dd叅伍栈叓叠伹叅伍叒位#Y< pk\u0012\u001ae!i";
      j[17] = "&Z\u001cif\u000b \t\u0001%\u001f右栅叴厦但佂右佁栮厦\u001b%]eE\u001c #\u000ex\t";
      j[18] = "D\u0001m\u0005r5\\\u0014.azP\u001b\u0004z\u0013,nAEl\n\u0013l]\u0014b^-6\u001c\u0002{a";
      j[19] = "!(3\"jC%,-g\u0007LH+q*9\u001b EI$fAab)&uF{";
      j[20] = "\u0005[\\\u0012DTI\u0004\u0014U}\u0004bS_SCTbbV\u0005\u0017\u000bZ\u0019\u001aP\u001bQ";
      j[21] = "fjmF3\u0007*?a\u001c\\\u0012\u00015=\u001flM\u0001\u00046C`\u0017-\u007fc[,\u0007";
      j[22] = "W0\u000bB\u0012~O%H&桪但佩伒伫佻桪变栭厌v[\ruLpN\u0019\u000e*";
      j[23] = "cT\u0002P\"\u0014?@]F\u0019D?_CA\u007fN4$\u0005X$]b\u0015YL{K";
      j[24] = "\u0012g1c@y\u0016c/&-v{dzd\u001d){]t>\u001df\u0015\"!\"Wv";
      j[25] = "6r{GJ^.g8#叨佦厖収叅叠佶栢桌収\u0006\u001aUYk58\u001fOJ'";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 友友友友何树友何树树.a ^ 135747998891765L;
      long ax = a ^ 97152478078338L;
      c<"Å">(this, false, -7633325353997844141L, a);
      c<"Â">(this, -7632727774793661407L, a).U(ax);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void q(LivingUpdateEvent event) {
      long a = 友友友友何树友何树树.a ^ 128477200646793L;
      long ax = a ^ 111614133785409L;
      long axx = a ^ 106123362947362L;
      long axxx = a ^ 47243488649102L;
      long axxxx = a ^ 71630465863249L;
      long axxxxx = a ^ 31460242514822L;
      long axxxxxx = a ^ 20313684150068L;
      long axxxxxxx = a ^ 97717257347988L;
      c<"i">(3056443079267345432L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"Â">(this, 3057230127667078286L, a).C(b<"i">(25710, 8870726565502994590L ^ a))) {
            if (this.w(new Object[]{ax})) {
               return;
            }

            if (c<"E">(3056985225335327285L, a).B() != null && c<"Â">(this, 3057087248350674223L, a)) {
               if (!(c<"Â">(mc.player, 3057783887797417153L, a) > 0.0F) && WrapperUtils.B(new Object[0]) <= 3) {
                  return;
               }

               double d0 = mc.player.getX() - WrapperUtils.A(new Object[]{axxxxxx});
               double d1 = mc.player.getY() - WrapperUtils.r(new Object[]{axxxx});
               double d2 = mc.player.getZ() - WrapperUtils.P(new Object[]{axxxxxxx});
               double d3 = c<"E">(3056985225335327285L, a).r().getYaw() - WrapperUtils.R(new Object[]{axxxxx});
               double d4 = c<"E">(3056985225335327285L, a).r().J(new Object[]{axx}) - WrapperUtils.I(new Object[]{axxx});
               boolean positionChanged = d0 * d0 + d1 * d1 + d2 * d2 > 9.0E-4;
               boolean rotationChanged = d3 != 0.0 || d4 != 0.0;
               if (positionChanged && rotationChanged) {
                  this.i(
                     PosRot.class,
                     mc.player.getX(),
                     mc.player.getY() - 0.03,
                     mc.player.getZ(),
                     c<"E">(3056985225335327285L, a).r().getYaw(),
                     c<"E">(3056985225335327285L, a).r().J(new Object[]{axx})
                  );
               }

               if (positionChanged) {
                  this.i(Pos.class, mc.player.getX(), mc.player.getY() - 0.03, mc.player.getZ());
               }

               if (rotationChanged) {
                  this.i(Rot.class, c<"E">(3056985225335327285L, a).r().getYaw(), c<"E">(3056985225335327285L, a).r().J(new Object[]{axx}));
               }

               c<"Â">(mc.player, 3057308580250727601L, a).send(new StatusOnly(false));
               WrapperUtils.z(new Object[]{WrapperUtils.q(new Object[0]) + 1});
            }

            c<"Å">(this, false, 3057087248350674223L, a);
         }
      }
   }

   @EventTarget
   public void w(WorldEvent event) {
      long a = 友友友友何树友何树树.a ^ 12455654795286L;
      long ax = a ^ 44523095880545L;
      c<"Å">(this, false, 68551435575908272L, a);
      c<"Â">(this, 67671251741250242L, a).U(ax);
   }

   @EventTarget
   public void R(PacketEvent event) {
      long a = 友友友友何树友何树树.a ^ 85777444319009L;
      long ax = a ^ 139937609474516L;
      c<"i">(559167717645437360L, (long)a);
      if (event.getPacket() instanceof ServerboundInteractPacket wrapper && WrapperUtils.Y((long)wrapper, (ServerboundInteractPacket)ax)) {
         c<"Å">(this, true, 559799291286147207L, (long)a);
      }
   }

   @EventTarget
   public void K(StrafeEvent event) {
      long a = 友友友友何树友何树树.a ^ 132400180661641L;
      long ax = a ^ 115657238600769L;
      c<"i">(-6527221663451649256L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"Â">(this, -6526425964981556338L, a).C(b<"i">(30052, 5684282477808834193L ^ a))
            || c<"Â">(this, -6526425964981556338L, a).C(b<"i">(24807, 4188103671376298769L ^ a))) {
            KeyMapping.set(
               c<"Â">(c<"Â">(mc, -6526746560252551539L, a), -6526806954115390778L, a).getKey(),
               c<"E">(-6526670862749383371L, a).B() != null && c<"Â">(this, -6526568995166490065L, a)
            );
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "职业技术教育中心学校";
   }
}
