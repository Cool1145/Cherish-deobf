package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.packet.BlinkUtils;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.render.友友树何树树友树友何;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public class 何树树友友何何何树树 extends Module implements 何树友 {
   private final ModeValue 树何树何友友友何何友;
   private final NumberValue 友树友友何何友何树友;
   private final NumberValue 树何树树何树友友友树;
   private final BooleanValue 树何何何树友何树树友;
   private final BooleanValue 树友友树树友树何树何;
   private final BooleanValue 何何友树何友何树友友;
   private final BooleanValue 何友树友友友友树树友;
   private final BooleanValue 何何何树友何何友树何;
   private final BooleanValue 友何树树树何何何何树;
   private final NumberValue 友友友何友友树何何何;
   private final BooleanValue 友树友何何何树友何友;
   private final 树友树友友何何树何何 树何友何友友何友何何;
   private final 树友树友友何何树何何 树友树树友友树友何何;
   private boolean 树友友何友友友树何友;
   private boolean 何何树友树友树何友友;
   private boolean 何友树何树何何何友树;
   private RemotePlayer 友何何友何友何友何何;
   private Vec3 友树何何树树友何友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[53];
   private static final String[] l = new String[53];
   private static String HE_JIAN_GUO;

   public 何树树友友何何何树树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/combat/何树树友友何何何树树.a J
      // 003: ldc2_w 78228244693405
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 108415460171838
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 10353
      // 014: ldc2_w 913987084572135485
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 13382
      // 021: ldc2_w 3191970598283283456
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w 846377282971400096
      // 02e: lload 1
      // 02f: invokedynamic ª (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/ModeValue
      // 03b: dup
      // 03c: sipush 24037
      // 03f: ldc2_w 3976983476444882361
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 23850
      // 04c: ldc2_w 5214062258024834413
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 3
      // 057: anewarray 92
      // 05a: dup
      // 05b: bipush 0
      // 05c: sipush 13099
      // 05f: ldc2_w 8156166325915356027
      // 062: lload 1
      // 063: lxor
      // 064: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 069: aastore
      // 06a: dup
      // 06b: bipush 1
      // 06c: sipush 31884
      // 06f: ldc2_w 2145557206547252440
      // 072: lload 1
      // 073: lxor
      // 074: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 079: aastore
      // 07a: dup
      // 07b: bipush 2
      // 07c: sipush 13602
      // 07f: ldc2_w 8820964469178830178
      // 082: lload 1
      // 083: lxor
      // 084: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 089: aastore
      // 08a: sipush 13099
      // 08d: ldc2_w 8156166325915356027
      // 090: lload 1
      // 091: lxor
      // 092: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 097: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 09a: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.树何树何友友友何何友 Lcn/cool/cherish/value/impl/ModeValue;
      // 09d: aload 0
      // 09e: new cn/cool/cherish/value/impl/NumberValue
      // 0a1: dup
      // 0a2: sipush 13099
      // 0a5: ldc2_w 8156166325915356027
      // 0a8: lload 1
      // 0a9: lxor
      // 0aa: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0af: sipush 17161
      // 0b2: ldc2_w 2640443791387720529
      // 0b5: lload 1
      // 0b6: lxor
      // 0b7: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bc: ldc2_w 6.0
      // 0bf: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0c2: dconst_1
      // 0c3: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0c6: ldc2_w 12.0
      // 0c9: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0cc: ldc2_w 0.1
      // 0cf: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0d2: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0d5: aload 0
      // 0d6: invokedynamic get (Lcn/cool/cherish/module/impl/combat/何树树友友何何何树树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/何树树友友何何何树树.c ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 0db: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0de: checkcast cn/cool/cherish/value/impl/NumberValue
      // 0e1: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.友树友友何何友何树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 0e4: aload 0
      // 0e5: new cn/cool/cherish/value/impl/NumberValue
      // 0e8: dup
      // 0e9: sipush 16291
      // 0ec: ldc2_w 1805031340858935278
      // 0ef: lload 1
      // 0f0: lxor
      // 0f1: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f6: sipush 28167
      // 0f9: ldc2_w 4832019202083903057
      // 0fc: lload 1
      // 0fd: lxor
      // 0fe: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 103: ldc2_w 500.0
      // 106: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 109: ldc2_w 10.0
      // 10c: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 10f: ldc2_w 1000.0
      // 112: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 115: ldc2_w 10.0
      // 118: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 11b: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 11e: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.树何树树何树友友友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 121: aload 0
      // 122: new cn/cool/cherish/value/impl/BooleanValue
      // 125: dup
      // 126: sipush 13268
      // 129: ldc2_w 468777367490759569
      // 12c: lload 1
      // 12d: lxor
      // 12e: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 133: sipush 21527
      // 136: ldc2_w 8821529499572661316
      // 139: lload 1
      // 13a: lxor
      // 13b: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 140: bipush 1
      // 141: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 144: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 147: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.树何何何树友何树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 14a: aload 0
      // 14b: new cn/cool/cherish/value/impl/BooleanValue
      // 14e: dup
      // 14f: sipush 27489
      // 152: ldc2_w 5130489214575006496
      // 155: lload 1
      // 156: lxor
      // 157: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 15c: sipush 20363
      // 15f: ldc2_w 6187757494728849360
      // 162: lload 1
      // 163: lxor
      // 164: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 169: bipush 1
      // 16a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 16d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 170: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.树友友树树友树何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 173: aload 0
      // 174: new cn/cool/cherish/value/impl/BooleanValue
      // 177: dup
      // 178: sipush 1900
      // 17b: ldc2_w 3246538327300357945
      // 17e: lload 1
      // 17f: lxor
      // 180: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 185: sipush 14475
      // 188: ldc2_w 8807354817648066773
      // 18b: lload 1
      // 18c: lxor
      // 18d: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 192: bipush 1
      // 193: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 196: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 199: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.何何友树何友何树友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 19c: aload 0
      // 19d: new cn/cool/cherish/value/impl/BooleanValue
      // 1a0: dup
      // 1a1: sipush 24580
      // 1a4: ldc2_w 2318620583037884505
      // 1a7: lload 1
      // 1a8: lxor
      // 1a9: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ae: sipush 22008
      // 1b1: ldc2_w 5576780860044799418
      // 1b4: lload 1
      // 1b5: lxor
      // 1b6: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1bb: bipush 1
      // 1bc: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1bf: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1c2: aload 0
      // 1c3: ldc2_w 846520108145674255
      // 1c6: lload 1
      // 1c7: invokedynamic þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1cc: dup
      // 1cd: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 1d0: pop
      // 1d1: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 1d6: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 1d9: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 1dc: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.何友树友友友友树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1df: aload 0
      // 1e0: new cn/cool/cherish/value/impl/BooleanValue
      // 1e3: dup
      // 1e4: sipush 27695
      // 1e7: ldc2_w 2906852751365330040
      // 1ea: lload 1
      // 1eb: lxor
      // 1ec: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f1: sipush 23393
      // 1f4: ldc2_w 3332713740435874600
      // 1f7: lload 1
      // 1f8: lxor
      // 1f9: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1fe: bipush 1
      // 1ff: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 202: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 205: aload 0
      // 206: ldc2_w 846520108145674255
      // 209: lload 1
      // 20a: invokedynamic þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 20f: dup
      // 210: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 213: pop
      // 214: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 219: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 21c: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 21f: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.何何何树友何何友树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 222: aload 0
      // 223: new cn/cool/cherish/value/impl/BooleanValue
      // 226: dup
      // 227: sipush 22315
      // 22a: ldc2_w 3494621456516935528
      // 22d: lload 1
      // 22e: lxor
      // 22f: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 234: sipush 9824
      // 237: ldc2_w 8056510525618920996
      // 23a: lload 1
      // 23b: lxor
      // 23c: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 241: bipush 1
      // 242: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 245: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 248: aload 0
      // 249: ldc2_w 846520108145674255
      // 24c: lload 1
      // 24d: invokedynamic þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 252: dup
      // 253: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 256: pop
      // 257: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 25c: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 25f: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 262: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.友何树树树何何何何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 265: aload 0
      // 266: new cn/cool/cherish/value/impl/NumberValue
      // 269: dup
      // 26a: sipush 27347
      // 26d: ldc2_w 706900408785457801
      // 270: lload 1
      // 271: lxor
      // 272: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 277: sipush 32644
      // 27a: ldc2_w 7923552209183164364
      // 27d: lload 1
      // 27e: lxor
      // 27f: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 284: ldc2_w 0.3
      // 287: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 28a: dconst_0
      // 28b: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 28e: dconst_1
      // 28f: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 292: ldc2_w 0.05
      // 295: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 298: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 29b: aload 0
      // 29c: invokedynamic get (Lcn/cool/cherish/module/impl/combat/何树树友友何何何树树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/何树树友友何何何树树.V ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 2a1: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 2a4: checkcast cn/cool/cherish/value/impl/NumberValue
      // 2a7: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.友友友何友友树何何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 2aa: aload 0
      // 2ab: new cn/cool/cherish/value/impl/BooleanValue
      // 2ae: dup
      // 2af: sipush 7186
      // 2b2: ldc2_w 7294198725492483139
      // 2b5: lload 1
      // 2b6: lxor
      // 2b7: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2bc: sipush 20313
      // 2bf: ldc2_w 5755066257560729362
      // 2c2: lload 1
      // 2c3: lxor
      // 2c4: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c9: bipush 1
      // 2ca: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2cd: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2d0: aload 0
      // 2d1: ldc2_w 846520108145674255
      // 2d4: lload 1
      // 2d5: invokedynamic þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2da: dup
      // 2db: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 2de: pop
      // 2df: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 2e4: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 2e7: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 2ea: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.友树友何何何树友何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2ed: aload 0
      // 2ee: new cn/cool/cherish/utils/树友树友友何何树何何
      // 2f1: dup
      // 2f2: lload 3
      // 2f3: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 2f6: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.树何友何友友何友何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 2f9: aload 0
      // 2fa: new cn/cool/cherish/utils/树友树友友何何树何何
      // 2fd: dup
      // 2fe: lload 3
      // 2ff: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 302: putfield cn/cool/cherish/module/impl/combat/何树树友友何何何树树.树友树树友友树友何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 305: aload 0
      // 306: bipush 0
      // 307: ldc2_w 843294639456974717
      // 30a: lload 1
      // 30b: invokedynamic X (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 310: aload 0
      // 311: bipush 0
      // 312: ldc2_w 843025401178441456
      // 315: lload 1
      // 316: invokedynamic X (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 31b: aload 0
      // 31c: bipush 0
      // 31d: ldc2_w 843693074779804709
      // 320: lload 1
      // 321: invokedynamic X (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/何树树友友何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 326: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(5771324166031524694L, 6983476825959995893L, MethodHandles.lookup().lookupClass()).a(28678567937780L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var5 = a ^ 61559112429079L;
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(var5 << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[30];
      int var12 = 0;
      String var11 = "v\u001bÛæó\u0088ÿ¢ÔÏô>\u0083HÙþ \u0081BÊþ\u007f)BõÏ°--\u001eò]\u0013_\u0082§\u0091¡)¬Å¿ÇÿN\u0001¶±-\u0010\u0004ØG\u001eø\u008b)¶®ú1\u0005\u0093\fªÔ(9\u009f ×¾ûè¨·Á':h\u0015åMU\u0010-¶jQÖµ;×j²«*l_bÃ\u000e¯\u008f8_\b\u0010|ÜhY\u0015ðÙÏi#é\u00ad.\u0081\u009c\u001d (\u00104'¦Ûa,\u0006å+G\u0018ödhXËÒ_\u0019\u0091a\u009e8\u0084\u001aGJ²\u0096\u001a\u0010r\u009fÊ\u0087\u001b*øæ?~Pðî\rBª Úf-Ñ@e[/ÄÎ \u0013\u0002\u000e\u0004ÃB\u0004\u000eÖÑçzQ\u0096éÕ\u0000S\u0083Û\u0092\u0010ÃtÂñ^|[S\u001aèá¨Ó}\u0012\u001a \u0084+\u001a½ ©\u000b\u0010PÌ15ß?X\u001dÙ4às)xÎ¡,(\u001f¯\u0089l~k .lõ\u008cgh.ìNÜæo\u008e®ü\\å\u009eÉï\u009ao\u001e¶È\u0006¹*\u0012Î\\\u0019 »I¼Y\u0014öÀ\u001c\u0015\u0096§03\u001b\u009a·ëÙ·ë(Åo*\u0098A_\u0010?<;\u0003\u0010¶®ªæ\rÂv\u009cH¸\u0017ã\u008f0\u000eÌ\u0010\u008aèn3\u008cÃ\u008b·ó\u007f\r\u0093\t\u0015\u008df0mØ(S\u001a\u0082\u001f\u001e¥Yµ+\u0011jÞ±Ï¢¤ÇÏ^ä|kvtØüO6¥Öl½VÇÊëþâ\u008fÊïÚ7*\u0086\u0010\u000eb°Ï~\u0092y|4383\u0018å\u0019ñ Êê\u0084Á\u0091U-$\u0011\n{\u0098 wÑÔÂ\u0003y\u0004\u0005Ê\u0084\u0092Õ\u0002ÿý]ÆO×\u0018ÔØ!\u008fö_\u001aõZåuñ£Ê(\u0016#8°,aEk§\u0010c\u0001l8¨\u0091ø¨m.@ëd;,\u009b <\u0011âD\u0083¶\u0093¿\u0088\rÃ(\u0090ÕÝÐcA£\u001a-\r\u0011\u00040tB=&p¬\u008a \u0090\u0010Ñ\u0091\u000e\fÙév\u0098,\u008a\u0089§E\u00adk\u00ad\u008aãd\u008c¼§\u00138Ü¿I(Éî\u0018×\u0005£¥Ü§L½&©ª`\u001a?$øÚ\u0089¸\u00ad\u00879\u0002B Õsô7]í\f;ªÚ¦v\u0096¸!q\u008cª@dØº\u009cfW\u0019È\u0018Io\u0096+\u0010\u000b\u008eÏ\u00047É\r\u0084§âzÓÝYã\u0081\u0018Ù(wÎC\u007fýMl¥AÞ\u0095%¿É\u009d×\u0093&ÎþÕú «ÛÖqÀ\u0091\u0088ªâ\u001fç§M(j@\u001d\u008cHUEÃ\u0095\u0005\u00906\u008cÙtÔ¶\u000e \u0086}\u0091\u009f\u0017\u0002ÀÚìÑ¾´ÛÎà «\u0014!X;aËî\u008fF\u0011!C\u0018ÿÝ\u0018\u008cÌÝ~¤LÜ \u009fþ\u0098oÔ´\u001f¨\u0092\u000e»\u0093\u0014\u0012\u00965";
      short var13 = 755;
      char var10 = 16;
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[30];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var5 << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-94, -76, 97, -121, 109, 2, 22, -1});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "8ìV\u0004\u001d\u008c\u000b\u001dk\u009cL\u001dS\t\u0081ô\u0003{¡\u0017\u0095(Rz\u0010\u000e\u001d¦\u0002\u0095\u007fÛ\"Êæ\u0099Î°ObQ";
                  var13 = 41;
                  var10 = 24;
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   private void B() {
      long a = 何树树友友何何何树树.a ^ 55082102451415L;
      c<"X">(this, new RemotePlayer(mc.level, mc.player.getGameProfile()), -1803059933704040553L, a);
      c<"X">(c<"þ">(this, -1803059933704040553L, a), c<"þ">(mc.player, -1802784959993990668L, a), -1803156297624222543L, a);
      c<"þ">(this, -1803059933704040553L, a).copyPosition(mc.player);
      c<"þ">(this, -1803059933704040553L, a).setUUID(mc.player.getUUID());
      c<"þ">(this, -1803059933704040553L, a).setId(mc.player.getId());
   }

   public void F() {
      this.f();
   }

   private boolean F() {
      long a = 何树树友友何何何树树.a ^ 41124200138865L;
      c<"£">(-4441451211621108572L, a);
      if (c<"þ">(this, -4442750318181665644L, a) == null) {
         return false;
      } else {
         double yaw = Math.toRadians(mc.player.getYRot());
         Vec3 lookDirection = new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
         Vec3 real = c<"þ">(this, -4442750318181665644L, a).subtract(mc.player.position());
         real = new Vec3(c<"þ">(real, -4441264524885679861L, a), 0.0, c<"þ">(real, -4444404988415048248L, a));
         if (real.length() < 0.1) {
            return false;
         } else {
            real = real.normalize();
            double smooth = lookDirection.dot(real);
            return smooth > 0.3;
         }
      }
   }

   @EventTarget
   public void F(LivingUpdateEvent event) {
      long a = 何树树友友何何何树树.a ^ 102566244490607L;
      long ax = a ^ 136429218098787L;
      long axx = a ^ 81688422987570L;
      long axxx = a ^ 139069897575358L;
      long axxxx = a ^ 86195220931804L;
      long axxxxx = a ^ 126368158400131L;
      c<"£">(1676099415781056954L, a);
      if (!this.w(new Object[]{ax})) {
         this.T(c<"þ">(this, 1676387040216126073L, a).getValue());
         if (c<"þ">(this, 1675873891379047311L, a) && c<"þ">(this, 1677122682828743050L, a) == null) {
            c<"X">(this, mc.player.position(), 1677122682828743050L, a);
            this.B();
         }

         if (c<"þ">(this, 1675873891379047311L, a) && c<"þ">(this, 1677122682828743050L, a) != null) {
            this.n();
            if (c<"þ">(this, 1677565378701910625L, a).getValue() && this.F()
               || c<"þ">(this, 1675944260809638931L, a).getValue() && c<"þ">(mc.player, 1679181242694663551L, a) > 0) {
               this.e();
               return;
            }
         }

         if (c<"þ">(this, 1676387040216126073L, a).C(b<"p">(22086, 2576623664878645995L ^ a))) {
            if (c<"þ">(this, 1677445780884424919L, a) && !c<"þ">(this, 1675652764651379202L, a)) {
               this.q();
               c<"X">(this, false, 1677445780884424919L, a);
               c<"þ">(this, 1679253364094400103L, a).U(axxxx);
            }

            if (!c<"þ">(this, 1675873891379047311L, a) && !c<"þ">(this, 1675652764651379202L, a)) {
               this.q();
               c<"þ">(this, 1679253364094400103L, a).U(axxxx);
            }

            if (c<"þ">(this, 1675873891379047311L, a)
               && !c<"þ">(this, 1675652764651379202L, a)
               && c<"þ">(this, 1679253364094400103L, a).C(axx, c<"þ">(this, 1678809697561493392L, a).getValue().floatValue())) {
               this.e();
               this.q();
               c<"þ">(this, 1679253364094400103L, a).U(axxxx);
            }
         } else {
            LivingEntity target = this.K();
            if (target != null) {
               double distance = RotationUtils.O(target);
               if (distance
                  <= (
                     c<"þ">(this, 1676387040216126073L, a).C(b<"p">(13602, 8820939916961780112L ^ a))
                        ? c<"þ">(c<"ª">(1679063399743750011L, a), 1679747951037488745L, a).getValue().floatValue()
                        : c<"þ">(this, 1676121079404297386L, a).getValue().floatValue()
                  )) {
                  if (c<"þ">(this, 1677445780884424919L, a) && !c<"þ">(this, 1675652764651379202L, a)) {
                     ClientUtils.e(new Object[]{b<"p">(8106, 7840674820994186002L ^ a) + c<"þ">(this, 1677445780884424919L, a), axxxxx});
                     this.q();
                     c<"X">(this, false, 1677445780884424919L, a);
                     c<"þ">(this, 1679253364094400103L, a).U(axxxx);
                  }

                  if (!c<"þ">(this, 1675873891379047311L, a) && !c<"þ">(this, 1675652764651379202L, a)) {
                     this.q();
                     c<"þ">(this, 1679253364094400103L, a).U(axxxx);
                  }

                  if (c<"þ">(this, 1675873891379047311L, a)
                     && !c<"þ">(this, 1675652764651379202L, a)
                     && c<"þ">(this, 1679253364094400103L, a).C(axx, c<"þ">(this, 1678809697561493392L, a).getValue().floatValue())) {
                     this.e();
                     this.q();
                     c<"þ">(this, 1679253364094400103L, a).U(axxxx);
                  }
               }
            }

            this.b();
            if (c<"þ">(this, 1675652764651379202L, a) && c<"þ">(this, 1675724516694859716L, a).Y(j, axxx)) {
               c<"X">(this, false, 1675652764651379202L, a);
            }
         }
      }
   }

   private void e() {
      long a = 何树树友友何何何树树.a ^ 127850189351890L;
      long ax = a ^ 38536675889219L;
      BlinkUtils.M(new Object[]{ax});
      c<"X">(this, false, 7060746340697939250L, a);
      c<"X">(this, null, 7060376746629961527L, a);
      c<"X">(this, null, 7061495595536238738L, a);
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 46;
               case 1 -> 50;
               case 2 -> 30;
               case 3 -> 24;
               case 4 -> 12;
               case 5 -> 37;
               case 6 -> 23;
               case 7 -> 5;
               case 8 -> 2;
               case 9 -> 22;
               case 10 -> 42;
               case 11 -> 41;
               case 12 -> 11;
               case 13 -> 32;
               case 14 -> 15;
               case 15 -> 20;
               case 16 -> 53;
               case 17 -> 55;
               case 18 -> 63;
               case 19 -> 45;
               case 20 -> 61;
               case 21 -> 25;
               case 22 -> 7;
               case 23 -> 31;
               case 24 -> 6;
               case 25 -> 59;
               case 26 -> 8;
               case 27 -> 47;
               case 28 -> 17;
               case 29 -> 28;
               case 30 -> 27;
               case 31 -> 16;
               case 32 -> 0;
               case 33 -> 34;
               case 34 -> 19;
               case 35 -> 33;
               case 36 -> 13;
               case 37 -> 10;
               case 38 -> 54;
               case 39 -> 43;
               case 40 -> 9;
               case 41 -> 62;
               case 42 -> 3;
               case 43 -> 4;
               case 44 -> 29;
               case 45 -> 21;
               case 46 -> 57;
               case 47 -> 40;
               case 48 -> 60;
               case 49 -> 36;
               case 50 -> 39;
               case 51 -> 14;
               case 52 -> 52;
               case 53 -> 35;
               case 54 -> 58;
               case 55 -> 38;
               case 56 -> 44;
               case 57 -> 1;
               case 58 -> 56;
               case 59 -> 48;
               case 60 -> 18;
               case 61 -> 26;
               case 62 -> 49;
               default -> 51;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/何树树友友何何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void b() {
      long a = 何树树友友何何何树树.a ^ 139210384763436L;
      c<"£">(-2305402804379363591L, a);
      if (c<"þ">(this, -2305062664408785716L, a)) {
         this.e();
      }

      c<"X">(this, false, -2305211222294024895L, a);
      c<"X">(this, false, -2304611727007678572L, a);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13289;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/何树树友友何何何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   @EventTarget
   public void x(AttackEvent event) {
      long a = 何树树友友何何何树树.a ^ 121199864799742L;
      long ax = a ^ 137539783792717L;
      c<"£">(-1453676442009445077L, a);
      if (event.isPost() && !event.isCancelled()) {
         c<"X">(this, true, -1454611843845675373L, a);
         c<"þ">(this, -1454541860777204907L, a).U(ax);
         if (c<"þ">(this, -1454428349084657890L, a)) {
            this.e();
            c<"X">(this, true, -1452886421795048378L, a);
            c<"þ">(this, -1451043662807233802L, a).U(ax);
         }
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/何树树友友何何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 254 && var8 != 'X' && var8 != 170 && var8 != 251) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 246) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 163) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 254) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'X') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 170) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private void n() {
      long a = 何树树友友何何何树树.a ^ 33254261425783L;
      c<"£">(890288857608600226L, a);
      if (c<"þ">(this, 890044411797447991L, a) != null) {
         c<"þ">(this, 890044411797447991L, a).setPos(c<"þ">(this, 891173174008412818L, a));
         c<"þ">(this, 890044411797447991L, a).setYRot(mc.player.getYRot());
         c<"þ">(this, 890044411797447991L, a).setXRot(mc.player.getXRot());
         c<"X">(c<"þ">(this, 890044411797447991L, a), c<"þ">(c<"þ">(this, 891173174008412818L, a), 890391295468695309L, a), 889649371171881338L, a);
         c<"X">(c<"þ">(this, 890044411797447991L, a), c<"þ">(c<"þ">(this, 891173174008412818L, a), 891525190690137902L, a), 890463805403152409L, a);
         c<"X">(c<"þ">(this, 890044411797447991L, a), c<"þ">(c<"þ">(this, 891173174008412818L, a), 888465239281748942L, a), 888899995770543623L, a);
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private void f() {
      long a = 何树树友友何何何树树.a ^ 105441480067836L;
      long ax = a ^ 84432394466127L;
      c<"£">(4670709071177446953L, a);
      if (c<"þ">(this, 4671047286998481948L, a)) {
         this.e();
      }

      c<"X">(this, false, 4670830815479139729L, a);
      c<"X">(this, false, 4671497948998098756L, a);
      c<"X">(this, null, 4671733231075636761L, a);
      c<"X">(this, null, 4670606054193916348L, a);
      c<"þ">(this, 4674431466503840244L, a).U(ax);
      c<"þ">(this, 4670897190773049431L, a).U(ax);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "#:$Mhw,ziFbj)'b\u0000jw$!fK)q-$f\u0000dw-6kZ)位桑桅叁句佒位伕桅栛";
      k[1] = boolean.class;
      l[1] = "java/lang/Boolean";
      k[2] = "[\bU->\f[\bBq2\u0003ACBo:\u0000[\u0019\u000fs?\u0004L\bS-\u0001\u0000X\u0002Uf\u0003\tT\u0014Dq";
      k[3] = "w\n\u0018a\u000bxw\n\u000f=\u0007wmA\u001b \u0014}}A\u001c'\u001fb79\t,U";
      k[4] = "\u001f9\u0016H j\u0010y[C*w\u0015$P\u0005\"j\u0018\"TNal\u0011'T\u0005,j\u00115Y_aN\u0015;Tj:w\u001d";
      k[5] = "#>NCOD\u0017\u001dA\u0003\u0002O\u001d\u0000D^\t\t\u0015\u001dIX\rBV?BI\u0014K\u001dI";
      k[6] = "K\u001fX/>'@\u0010I`B>O\nG#u\u000eY\u001dK>d\"N\u0010";
      k[7] = "6R_\u0004W79\u0012\u0012\u000f]*<O\u0019IN99I\u0014IQ5%P_%W79Y\u0010\tn99I\u0014";
      k[8] = double.class;
      l[8] = "java/lang/Double";
      k[9] = float.class;
      l[9] = "java/lang/Float";
      k[10] = "\u0011\u0015F;5O\u0011\u0015Qg9@\u000b^Qy1C\u0011\u0004\u001ce4G\u0006\u0015@;\u0014I\u001c\u0011^E4G\u0006\u0015@";
      k[11] = "\u0013 <\u0005\u00072\u001c`q\u000e\r/\u0019=zH\u001d)\u0019\"aH桹厖桡厅叙伳伽桌伥伛";
      k[12] = "F\"\u0014l;rIbYg1oL?R!\"|I9_!=pU \u0014B;y@\u001a[c!x";
      k[13] = " \u0017V\u007f2\"/W\u001bt8?*\n\u00102+,/\f\u001d24 3\u0015VR( !\u001c\nJ<!6\u001c";
      k[14] = "w[I_n)x\u001b\u0004Td4}F\u000f\u0012l)p@\u000bY/伓佁叾伲佩及伓佁栤桶";
      k[15] = "KX[r\tFD\u0018\u0016y\u0003[AE\u001d?\u000bFLC\u0019tH@EF\u0019?\u0002@[F\u0019p\u001f\u0007口栧桤栀桷佼根栧厾叚";
      k[16] = "\u0006lzr;J\t,7y1W\fq<?\"D\tw1?=H\u0015nz栀原佰厮佗企叚桅栴厮";
      k[17] = int.class;
      l[17] = "java/lang/Integer";
      k[18] = "A,.\u000b\u00104J#?Dq:A(;\u001e";
      k[19] = "r5>w\u001bGx<h~i桠桐栕桋叞厪桠伔叏厑\u001dXG#<8}\u0004\u0017;q";
      k[20] = " \u0007\r#)\"y\u0010S|\u0010.NC\u0002/-~Nz\r%{#$\u0006\u000b{(9";
      k[21] = "1\u001bvi'\u0000mYs\u0011厏桨叏似佁佌桕厲佑厢\u001c,sI|\nrxr\tu";
      k[22] = "ST#\u001e7\u0001\u000f\u0016&f5pRJ.\u001b<\u000bR\u0015#\u0007\\L\nI4\u0006'LUD(f";
      k[23] = "~\\\u0013V2_q^\u001fDB佦佊佱厳佳伟佦栎佱厳.(WfU\u001c\u0011=@eC";
      k[24] = "\u0013\u0010Ls\u001b^ORI\u000b伭佲叭桳佻又伭栶叭厩&6O\u0017^\u0001HbNWW";
      k[25] = "*\u0004Ae2\u001e \r\u0017l@AwFQf&K|=\u00166,Jc\u0003\u001c?zC";
      k[26] = ":^5vj\nf\u001c0\u000e栘厸栞栽厜反栘厸佚佹_1z\u001fb\u001d%kn\u0017a";
      k[27] = "Zz\u001f\n@-_\"\\J2|2x]F\u000b,2B\u000e\u001eM-_-\u000e\b@+";
      k[28] = "\u0012\u001bln|PNYi\u0016栎佼栶桸佛栏叔叢召桸\u0006')K\u001f\u000bf{ySR";
      k[29] = "\u001dy\u0017\u000e.\t\u001c{NY\\\u0004p1N\flSp\u0001J\n7\t\u001a}LTd\u0013";
      k[30] = "\u000bl\u0005$C3K|\u0006\u007f2厐栣叟厪会佯厐佧栅厪G\u0003#V\u007f\u0018'C3U$";
      k[31] = "c\u0018;n'#?Z>\u0016休厑桇厡厒叕厏桋桇厡Q+sj.\t?\u007fr*'";
      k[32] = "2\r\u001d\u0010\u0006b7U^Pt3Z\u000f_]D`Z5Y\u0012\u0019 dW\u001b\\\ta";
      k[33] = "qk$\u000e]Tpi}Y/Y\u001c#}\f\u0010\u0006\u001c\u0013y\nDTvo\u007fT\u0017N";
      k[34] = "\u0015&\u0007\u007f) L1Y \u0010,{b\bs-\u007f{[\u0007y{!\u0011'\u0001'(;";
      k[35] = "\u0000_~z1\u0003\\\u001d{\u0002桃伯栤佸受叁厙伯你另\u00142 \fMKhzc\u0000W";
      k[36] = "qhrVGO-*w.可佣休发佅叭佱叽休住\u0018\u0017Q\u0000p+zNF^/";
      k[37] = "]ed\u0013iE\u0001'ak栛号厣栆栗厨栛佩桹佂\u000eV=\f\u0010t`\u0002<L\u0019";
      k[38] = "\u0011d\u000e-..M&\u000bU历框可叝伹伈历伂栵叝dd{5\u001ct\u00048+-Q";
      k[39] = "?\u0005;\u0014;s5\fm\u001dI\u001c\u0004\u0007*\u0007)<|A.\u0006xM";
      k[40] = "6:gJ\u001a\u000ejxb2桨伢又伝収叱伬厼佖伝\r\r\n\u001bnywW\u001e\u0013m";
      k[41] = "\u0006(o\u0014\u000eeZjjl伸佉栢厑栜厯桼佉司厑\u0005U^t\u000b ~\\\u000biJ";
      k[42] = "Zigb\u0007V\u0006+b\u001a桵古厤低収叙厯栾伺叐\r#WGWav*\u0002Z\u0016";
      k[43] = "t#\u001c\u0013;b-4BL\u0002n\u001ad\u001a\u001f2=\u001a^\u001cPo}$<^\u001e\u007f<";
      k[44] = "r\u0010NjL,.RK\u0012古厞厌伷叧发栾伀伒伷$#\u00197\u007f\u0000D\u007fI/2";
      k[45] = "B\f\u0005\u0006\u007f%M\u000e\t\u0014\u000f桘叨县桿厽双厂佶桥厥~f1H\u0004\u0016\u001ai3D\u0016";
      k[46] = "#\u001bI5P\u001az\f\u0017ji\u0016M_F9TDMfI3\u0002\u001b'\u001aOmQ\u0001";
      k[47] = "&\r\u001c{KuzO\u0019\u0003口余栂桮桯佞佽余但桮v>\u001f<k\u001c\u0018j\u001e|b";
      k[48] = "*zr\u007fu\nv8w\u0007佃厸栎佝栁佚佃伦叔栙\u0018>%\u001b'rc7p\u0006f";
      k[49] = "a\\I\"e-`^\u0010u\u0017 \f\u0014\u0010 'v\f$\u0014&|-fX\u0012x/7";
      k[50] = "/kvdR\bs)s\u001c栠伤住佌栅叟佤桠栋叒\u001c!\u0006Abzru\u0007\u0001k";
      k[51] = "\u0013V$$\u0000 O\u0014!\\伶伌佳栵厍企伶厒样佱NaTi^G 5U)W";
      k[52] = "hGc]Xv4\u0005f%台栞伈你栐格台佚厖你\t\u001fKdkOj\u001eI=<";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      this.f();
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void q() {
      long a = 何树树友友何何何树树.a ^ 71322574219271L;
      long ax = a ^ 2529301356750L;
      c<"£">(-2149714422707497774L, a);
      if (!c<"þ">(this, -2149910294659522841L, a)) {
         c<"X">(this, mc.player.position(), -2148696790522456862L, a);
         this.B();
         BlinkUtils.g(new Object[]{ax});
         c<"X">(this, true, -2149910294659522841L, a);
      }
   }

   @EventTarget
   public void z(Render3DEvent event) {
      long a = 何树树友友何何何树树.a ^ 52712198723117L;
      long ax = a ^ 16138144851233L;
      long axx = a ^ 125759893850192L;
      long axxx = a ^ 30978068077313L;
      c<"£">(-2593860971874325768L, a);
      if (!this.w(new Object[]{ax})
         && c<"þ">(this, -2589823389457555521L, a).getValue()
         && c<"þ">(this, -2593065316333444915L, a)
         && c<"þ">(this, -2594034477926451859L, a) != null) {
         友友树何树树友树友何.N(
            event.poseStack(),
            c<"þ">(this, -2594034477926451859L, a),
            c<"þ">(this, -2589899976068106395L, a).getValue()
               ? 树树何友友友友何树友.w(axx, 10, 1).getRGB()
               : c<"þ">(c<"ª">(-2593398126657305847L, a), -2590429140606753938L, a).a(),
            c<"þ">(this, -2590624626811782794L, a).getValue(),
            c<"þ">(this, -2592429659708890374L, a).getValue(),
            c<"þ">(this, -2593240760926242394L, a).getValue(),
            c<"þ">(this, -2593490229584232087L, a).getValue().floatValue(),
            axxx
         );
      }
   }

   private LivingEntity K() {
      long a = 何树树友友何何何树树.a ^ 35896106871704L;
      long ax = a ^ 100875403269490L;
      c<"£">(7040760525314971469L, a);
      LivingEntity target = null;
      if (c<"þ">(this, 7040468500892476558L, a).C(b<"p">(8057, 8114346261438418213L ^ a)) && c<"ª">(7042018660071147916L, a).isEnabled()) {
         target = c<"ª">(7042018660071147916L, a).B();
      }

      if (target == null && c<"þ">(this, 7040468500892476558L, a).C(b<"p">(13099, 8156266930290712958L ^ a))) {
         Iterator var7 = Cherish.instance.S().W(c<"þ">(this, 7040738998809823837L, a).getValue().floatValue(), ax).iterator();
         if (var7.hasNext()) {
            LivingEntity entity = (LivingEntity)var7.next();
            if (entity != null && !entity.isDeadOrDying() && entity.isAlive() && entity.getHealth() > 0.0F) {
               double distance = RotationUtils.O(entity);
               if (distance <= c<"þ">(this, 7040738998809823837L, a).getValue().floatValue()) {
                  target = entity;
               }
            }
         }
      }

      return target;
   }

   private static String HE_JIAN_GUO() {
      return "何大伟230622198107200054";
   }
}
