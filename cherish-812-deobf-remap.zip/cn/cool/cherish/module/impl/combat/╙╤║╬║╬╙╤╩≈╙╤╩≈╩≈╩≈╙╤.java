package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult.Type;
import net.minecraftforge.client.ForgeHooksClient;

public class 友何何友树友树树树友 extends Module implements 何树友 {
   private final NumberValue 树友何友树树树友树友 = new NumberValue("Max CPS", "最大每秒点击次数", 14, 1, 20, 1);
   private final NumberValue 友何友友何友树何友友 = new NumberValue("Min CPS", "最小每秒点击次数", 10, 1, 20, 1);
   private final BooleanValue 树树友友树友树树何何 = new BooleanValue("Right Click", "右键点击", false);
   private final BooleanValue 树何友树树友友树何何 = new BooleanValue("Left Click", "左键点击", true);
   private final BooleanValue 友何友何树友树树何何 = new BooleanValue("Left Click Forge CallEvent", "左键点击时触发触发Forge事件", true).A(this.树何友树树友友树何何::getValue);
   private final BooleanValue 树树友树友树何何何友 = new BooleanValue("Hit Select", "点击选择", false);
   private final BooleanValue 友友树树何何何友树友 = new BooleanValue("Jitter", "抖动", false);
   private final NumberValue 树树树树友树友何友友 = new NumberValue("Jitter Strength", "抖动强度", 1.0, 0.1, 3.0, 0.1);
   private final BooleanValue 树树何树何树何树友何 = new BooleanValue("Horizontal Jitter", "水平抖动", true);
   private final BooleanValue 友何友友友树树何何树 = new BooleanValue("Vertical Jitter", "垂直抖动", true);
   private final BooleanValue 树树树树树何何树何友 = new BooleanValue("Disable On Mining", "挖掘时禁用", true);
   private final 何友友何树何树何树友 何友何友树树何树友树 = new 何友友何树何树何树友(51913986529303L);
   private int 树友树友树友树友友何;
   private long 树何何树树友友树何何;
   private int 何何友树友树树友何友;
   private BlockPos 树友树树友友何友树何;
   private int 树树何友友树何树友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[47];
   private static final String[] n = new String[47];
   private static String LIU_YA_FENG;

   public 友何何友树友树树树友() {
      super("AutoClicker", "自动点击", 树何友友何树友友何何.何何何何何树何何友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3596579758020422942L, 7655842165473159500L, MethodHandles.lookup().lookupClass()).a(243453099801419L);
      // $VF: monitorexit
      a = var10000;
      c();
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(76693714897322L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[24];
      int var18 = 0;
      String var17 = "z?k÷¥\u0096\u0014×¹Q\u0090-$÷À \u007f\u0006p\u001dt×mñ\u0018\u0006Ü-\u0013uè\u001aî\\\u0013·ó\u009dGZ:\u009fÏ¿]S\u00801\u0088\u0010rç\u0099Ñ0Nóó:\u0094~L%º>\u0098\u0018¢;Eùx\u0000Ír\u0001`-\u008b´\u0090c<\u0003ÍFR\u0002t*Ê\u0018\u0002ÙçµáÌc¡éB\u008eØÌîF¶9-Ë\u009f\u00072¢l(j\"ç\u0083á\u0089á¯Îí.ÞÑ,wÇ¤`4þsÒÀ\u0090\u008a\u0094\u0016\u0087-ö\u0089ôpá]Ô\u0092\u0002½3 ò\u0090WmP\u0005\u0085m\u0097\u0098Þûã\"O\u009c8q¹\u000f_ËQ\u0004j\u000f¨yj¡ì\u008b lU`ÕÂ&·0¹Ä¦\u001e_çejÿÔz¶\u001eÕ\u0095\t\u0096w(0R\u0003=t\u0010]jÉCuVñ\u009fþµ¤\u008e\u0006ÝÔp0Òök°â0ÔýnPº\u00198\u0098\u001dc&\u0000OW\u0090\u0015¦O!Ö'`¯7\u0002^ÚÅÂöIû\u0087´WõL\u0088,ýáK0\\\u0099úf\u00ad\n7·É\u00842\u0086 ¯\u009a½_²à*P¿kÔ\u0016LÕ\u008d\u0087'ÿÜþ\u0092¬ÎP»¦øµZ\t\u000bé~4ú\u0010î D»¯«Ö\u0018\u009e?D\u007fv¸Óh@r\u0016]ÿÈaj´u#\u001a\u000f\f>Ö\nºD¬\u0090Ò\u009fñ(]\u0015\u0086ýqJÝ¤WCH3åS\u001b*@d÷î\u0004ðÎ²à©fÛÌê»\u0012_t1u\u0007\u009eòw\u0018ãP¯¿\u0095áyQÅ\u0099×\u001d0J\u00034Ã\u0002\u0015Þ;Î¾å\u0018Ã\u0007¬,áU\u0011\u0085W\u0003O4§M\u0090\u009ag}ÐÇ\u0012U´ª\u0010\rû\u009a7²À\u001f5\u0018\u009a3}\u009aw]ç\u0018K¥å5\u0098\u0003T&\u0011\u0086\u00842:\u0006\u008a½i\u0086\u001a9ø\f%î8\u008c½¬\u0002ur\u0097»,SZ\u007fY\u008d\u00835\u007f\u0081#QTx`ûæ\u0019\u008aù\u0091 vùÀÜ\u00adÑb¹\t\u001f|_\u0014Ó\u0007äÌz,Îní»à³U éÏS\n\u0097v³=ï,\u000eoBà\u0013\u001c\b\u0018@]^ìBêJZÐ.\u0097´8\u001c89¨Î%ª\u0094Ôÿ©5\u0000UÉÞ°L£\u0093£\u0019Y\u001f°\u0099`òãÛÕ\u009dº¦\u008b\r$Ê¾\\N\u008fCj±,\u0006»e!Ö:\u001aèn¢FÕ  \u009a8)Å\u000f\u000b|\u0088\u0002\\ú²å½Zfë\u0082EPrÜ9jë\u008bÙëðs¢ \u008f\\\u009f\u0012\\0\u0090ùt\u0017\u0084(f2í$\u0016â©Q¨SgZv¥\"#7j#;";
      short var19 = 725;
      char var16 = 24;
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[24];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(76693714897322L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0019V\u0091\u0093JAa²æ3>²n-xÁ".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "\u007fðî\u0014'\u0015\u007f \u008aZ\u001a[@ê\u001cbk\u0088 î\"~môÓw8bPR\u008b\u000e +Ûç\u0011½+N¬×köòÝGÎ\u0003iÙÔ6÷có\u0019!\u0094\u0080\u0011\u0086O\u0087?";
                  var19 = 65;
                  var16 = ' ';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private boolean e() {
      KillAura.x();
      if (!mc.options.keyAttack.isDown()) {
         this.a();
         return false;
      } else if (mc.hitResult != null && mc.hitResult.getType() == Type.BLOCK) {
         BlockHitResult blockHit = (BlockHitResult)mc.hitResult;
         BlockPos currentBlockPos = blockHit.getBlockPos();
         if (树何树树何何树友何何.F(currentBlockPos, 65332937941542L)) {
            this.a();
            return false;
         } else {
            if (this.树友树树友友何友树何 == null || !this.树友树树友友何友树何.equals(currentBlockPos)) {
               this.树友树树友友何友树何 = currentBlockPos;
               this.树树何友友树何树友何 = 0;
            }

            this.树树何友友树何树友何++;
            return this.树树何友友树何树友何 >= 1;
         }
      } else {
         this.a();
         return false;
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 29;
               case 1 -> 0;
               case 2 -> 36;
               case 3 -> 43;
               case 4 -> 40;
               case 5 -> 3;
               case 6 -> 8;
               case 7 -> 55;
               case 8 -> 49;
               case 9 -> 26;
               case 10 -> 52;
               case 11 -> 13;
               case 12 -> 32;
               case 13 -> 33;
               case 14 -> 14;
               case 15 -> 41;
               case 16 -> 24;
               case 17 -> 16;
               case 18 -> 20;
               case 19 -> 54;
               case 20 -> 60;
               case 21 -> 31;
               case 22 -> 44;
               case 23 -> 45;
               case 24 -> 56;
               case 25 -> 25;
               case 26 -> 23;
               case 27 -> 28;
               case 28 -> 10;
               case 29 -> 53;
               case 30 -> 51;
               case 31 -> 38;
               case 32 -> 1;
               case 33 -> 4;
               case 34 -> 63;
               case 35 -> 6;
               case 36 -> 27;
               case 37 -> 47;
               case 38 -> 17;
               case 39 -> 18;
               case 40 -> 15;
               case 41 -> 11;
               case 42 -> 58;
               case 43 -> 21;
               case 44 -> 37;
               case 45 -> 59;
               case 46 -> 2;
               case 47 -> 22;
               case 48 -> 48;
               case 49 -> 46;
               case 50 -> 9;
               case 51 -> 61;
               case 52 -> 34;
               case 53 -> 7;
               case 54 -> 57;
               case 55 -> 39;
               case 56 -> 35;
               case 57 -> 19;
               case 58 -> 62;
               case 59 -> 42;
               case 60 -> 50;
               case 61 -> 30;
               case 62 -> 12;
               default -> 5;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友何何友树友树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 22385;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友何何友树友树树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[¨\u0007+÷/\u0019\u0012³*û®©s#V5, 0e;7[\u001eÓõÔî²\u0010joµ), Sar\u0013ðC±G, rBO%m\\G\u0098Y\u0001B¥×\u001f\u009b\u008a, Þ;\u000b\u001e\u0018c\u0098\u009d:£·Ý\u0080\t<C, \u008c")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private void x() {
      KillAura.x();
      if (this.树树友友树友树树何何.getValue()) {
         if (mc.options.keyUse.isDown()) {
            if (!mc.options.keyAttack.isDown()) {
               友树友友树何树友树友.P(1, true, 4415651973784L);
               if (Math.random() > 0.9) {
                  友树友友树何树友树友.P(1, true, 4415651973784L);
               }
            }
         }
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 429;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友何何友树友树树树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'o' && var8 != 195 && var8 != 'v' && var8 != 219) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'S') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'j') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'o') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 195) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'v') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友何何友树友树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void c() {
      m[0] = "u\u007f9zWXz?tq]E\u007fb\u007f7UXrd{|\u0016^{a{7[X{svm\u0016叼佃佄叜栈右栦标栀叜";
      m[1] = long.class;
      n[1] = "java/lang/Long";
      m[2] = "\u001b)JaVB\u0014i\u0007j\\_\u00114\f,OL\u00142\u0001,P@\b+J@VB\u0014\"\u0005loL\u00142\u0001";
      m[3] = "W v\u000f hX`;\u0004*u]=0B\"hP;4\tanY>4B,hY,9\u0018aL]\"4-:uU";
      m[4] = "B;Ab+\u001ev\u0018N\"f\u0015|\u0005K\u007fmSt\u0018Fyi\u00187:Mhp\u0011|L";
      m[5] = "Qn|j\u0012bQnk6\u001emK%k(\u0016nQ\u007f&4\u0013jFnzj3d\\jd\u0014\u0013jFnz";
      m[6] = int.class;
      n[6] = "java/lang/Integer";
      m[7] = "\u001a\u0011^\u0018\u0011n\u001a\u0011ID\u001da\u0000ZIZ\u0015b\u001a\u0000\u0004{\u0015i\u0011\u0017XW\u001as";
      m[8] = "0b\\\u0006,o0bKZ `*)KD(c0s\u0006O4optKZ$c0t\u0006{\"t;bF";
      m[9] = "\u001dp\u001b ?\f\u00120V+5\u0011\u0017m]m%\u0017\u0017rFm伅厨厵佋栤伖桁伶桯叕";
      m[10] = "4\u0015jY\u0014\n?\u001a{\u0016h\u00130\u0000uU_#&\u0017yHN\u000f1\u001a";
      m[11] = "Z\u001fB\u0007PNZ\u001fU[\\A@TUFOB\u001a8ZF^Ld\u0015E";
      m[12] = "\u0019si\u001co\u0003\u0019s~@c\f\u00038j]p\u0006\u00138mZ{\u0019Y^tFP\u000f\u0004cqF&>\u000efx";
      m[13] = "_\u0011D\u0002\u007f!_\u0011S^s.EZS@{-_\u0000\u001ecb<X\u001b^_";
      m[14] = "8im\u001d\u0007;8izA\u000b4\"\"z_\u000378x7x\u000f+\u001bmiC\u0003<1";
      m[15] = "x\u0012@#\u0010wx\u0012W\u007f\u001cxbYCb\u000frrYDe\u0004m8?]y/{e\u0002Xy";
      m[16] = "O\u00153\u001f\"2@U~\u0014(/E\buR;<@\u000exR$0\\\u00173280N\u001eo*,1Y\u001e";
      m[17] = "=7\u000e\u0017zr2wC\u001cpo7*HZxr:,L\u0011;栌伋厒叫伡栄取厕伌併";
      m[18] = "%p#/7W.\u007f2`VY%t6:";
      m[19] = "1nYp\u0014\u001e:zAA桡伧佝栏栲厂去档佝佋+x\u0013@>t\u00150\u001f\u001e`";
      m[20] = "y#b\u0002_|r7z3株栁伕厘叓株佮栁压伆\u0010\u000fJe&'`JVfy";
      m[21] = "\u001fmI@\u0019j\u0014yQq厶体叭取佦厲桬体叭取;\u001b\u0015|Co\u000b\u000f\u0004cP";
      m[22] = "/\\Mn%S$HU_桐栮佃栽佢框伔栮叝佹?f/\\nF[3 \r{";
      m[23] = "\u0007e_s\b\u0005P>\u0001)u\u0005k8\b#LUk\u0002\fk\b\u0005@rIw\u000bZ";
      m[24] = "\tIk\u0014+W\u0002]s%桞株校栨栀佸会株佥史\u0019\u001c!XHS}I.\t]";
      m[25] = "zG\u0000\u0012Y\u0002p\u0012\u000fH4\u000f\u001cL_\u001b\u0005\\\u001c}TS\u000e\u00057@UL\u000f\u0005";
      m[26] = "\u001c\u0003x\u0015\\B\u0017\u0017`$Y&\u0012@aO]\u0019G\n1[0\u0019\u0016\u0010aI\u000fL\\@u$";
      m[27] = "(2\u0011{S\u0019 s\u0002g=/\\\b0U=Ue%\u0016xA]$6\n";
      m[28] = ":Uso\u001d\r1Ak^厲伴又佰栘厝桨桰佖佰\u0001g\u0017\u0002{Oe2\u0018Sn";
      m[29] = "{!&aN\fqt);#\u0001\u001d*yh\u0012Q\u001d\u001br \u0019\u000b6&s?\u0018\u000b";
      m[30] = "2\u0001\u0002a/~9\u0015\u001aP桚叙栚桠厳厓伞叙栚伤p`xv8\u0013\u001e>!h2";
      m[31] = "5J9;\u00075>^!\n桲案叇栫厈栓伶伌余叱K3\r:tP/f\u0002ka";
      m[32] = ",*9KZi}=n\u001bbw\u0016ywZ]>t<wP^\u0007";
      m[33] = "\u0000\u0004\u007f^\u0019fM\u0013rH\"ikGw\u000f\u001d8kv'H\u0019<\\\u001c*\tGh";
      m[34] = ".P\u001d3t('\u0010]t\u0005伇伙佰伱佑栜伇伙叮桵\fo'5\u0012\u001d~fguU";
      m[35] = "\u0010\\fM+V\u001bH~|桞叱佼叧栍桥桞叱核叧\u0014\u0016'@L^$\u00026__";
      m[36] = "KA2\t\u0002>@U*8桷厙档叺桙叻桷厙厹佤@\u0004\u0017'\u0014E0A\u000b$K";
      m[37] = "){*dV1\"o2U栣桌叛叀桁厖栣桌佅佞Xl\\>ha<9So}";
      m[38] = "_\u0011\u001a\u0001,\u001a\u0012\u0006\u0017\u0017\u0017\u00154R\u0012P)E4c\u001aRrJ\u000e\u0000\u0010\u0007}\u0010";
      m[39] = "\u000f-,8mM\u000494\t栘栰栧桌厝栐参佴叽厖^ca[S/nwpD@";
      m[40] = "T\u0004t\u0014D\u0019\u0019\u0013y\u0002\u007f\u0016?G|EO@?v{C\u0018\bS\b'\u0002\u0005H";
      m[41] = "g?Zq=rl+B@伌佋厕桞叫桙案叕伋厄(|(k8;X94hg";
      m[42] = "K\b\u0003(a\u001c@\u001c\u001b\u0019収去档桩伬佄佐去档厳q k\u0013\n\u0012\u0015udB\u001f";
      m[43] = "\u001c$\u0018B&\u0007\u00170\u0000s众厠佰原桳桪众桺叮桅jM7\u0013\u001dc\u0011K:\u0003\\";
      m[44] = "\u007f\bB\f^9t\u001cZ=栫伀厍桩栩叾叱桄伓伭0\u0004T6>\u0012TQ[g+";
      m[45] = "{8t~\u0012{sygb|B\n\u001eE\u0013Lz!(poD;24";
      m[46] = "/\u000b>\u000f\f\u001a$\u001f&>厣伣叝厰厏栧桹伣佃桪L\u0007\u0006\u0015n\u0011(R\tD{";
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private void d() {
      d<"j">(8124248216932169999L, 33581468840119L);
      if (d<"o">(this, 8123386523727774263L, 33581468840119L).getValue()) {
         if (d<"o">(this, 8123770040262705439L, 33581468840119L) > 1) {
            if (!d<"o">(d<"o">(mc, 8124132678063873050L, 33581468840119L), 8120352535511293247L, 33581468840119L).isDown()) {
               boolean shouldClick = Math.sin(d<"o">(this, 8121087614405054153L, 33581468840119L)) + 1.0 > Math.random()
                  || Math.random() > 0.25
                  || d<"o">(this, 8123874383476425402L, 33581468840119L).c(c<"u">(26938, 6919179579026139287L), 41972279541307L);
               boolean validTarget = d<"o">(mc, 8124288704926686092L, 33581468840119L) == null
                  || d<"o">(mc, 8124288704926686092L, 33581468840119L).getType() != d<"v">(8120552066257329319L, 33581468840119L)
                  || 树何树树何何树友何何.F(((BlockHitResult)d<"o">(mc, 8124288704926686092L, 33581468840119L)).getBlockPos(), 65332937941542L)
                  || d<"o">(mc, 8124288704926686092L, 33581468840119L).getType() == d<"v">(8123487570476404654L, 33581468840119L);
               if (shouldClick && validTarget) {
                  if (d<"o">(this, 8120038157406748085L, 33581468840119L).getValue()) {
                     ForgeHooksClient.onMouseButtonPre(
                        d<"o">(d<"o">(mc, 8124132678063873050L, 33581468840119L), 8120062656263756963L, 33581468840119L).getKey().getValue(), 1, 0
                     );
                     友树友友树何树友树友.P(0, true, 4415651973784L);
                     ForgeHooksClient.onMouseButtonPost(
                        d<"o">(d<"o">(mc, 8124132678063873050L, 33581468840119L), 8120062656263756963L, 33581468840119L).getKey().getValue(), 1, 0
                     );
                  }

                  友树友友树何树友树友.P(0, true, 4415651973784L);
               }
            }
         }
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友何何友树友树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void a() {
      this.树友树树友友何友树何 = null;
      this.树树何友友树何树友何 = 0;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private void o() {
      KillAura.x();
      long clicks = (long)(Math.round((float)友友友树何友树友树友.x(1391347873739L, this.友何友友何友树何友友.getValue().intValue(), this.树友何友树树树友树友.getValue().intValue())) * 1.5);
      this.树何何树树友友树何何 = 1000L / clicks;
      if (mc.options.keyAttack.isDown()) {
         this.何何友树友树树友何友++;
      }

      this.何何友树友树树友何友 = 0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @EventTarget
   public void g(MotionEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})) {
         WrapperUtils.d(0, 24928558720942L);
         this.树友树友树友树友友何++;
         if (!this.树树树树树何何树何友.getValue() || !this.e()) {
            this.T();
            this.O();
         }
      }
   }

   @EventTarget
   public void g(AttackEvent event) {
      this.树友树友树友树友友何 = 0;
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void X() {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})) {
         float strength = this.树树树树友树友何友友.getValue().floatValue();
         if (this.树树何树何树何树友何.getValue() && Math.random() > 0.5) {
            float yawChange = (float)(Math.random() > 0.5 ? Math.random() * strength : -Math.random() * strength);
            mc.player.setYRot(mc.player.getYRot() + yawChange);
         }

         if (this.友何友友友树树何何树.getValue() && Math.random() > 0.5) {
            float pitchChange = (float)(Math.random() > 0.5 ? Math.random() * strength : -Math.random() * strength);
            float newPitch = mc.player.getXRot() + pitchChange;
            if (newPitch > 90.0F) {
               newPitch = 90.0F;
            }

            if (newPitch < -90.0F) {
               newPitch = -90.0F;
            }

            mc.player.setXRot(newPitch);
         }
      }
   }

   private void T() {
      KillAura.x();
      if (this.友友树树何何何友树友.getValue()) {
         boolean shouldJitter = this.树何友树树友友树何何.getValue() && mc.options.keyAttack.isDown()
            || this.树树友友树友树树何何.getValue() && mc.options.keyUse.isDown() && !mc.options.keyAttack.isDown();
         if (shouldJitter && !this.e()) {
            this.X();
         }
      }
   }

   private static String HE_SHU_YOU() {
      return "刘凤楠230622109211173513";
   }

   private void O() {
      KillAura.x();
      if (this.何友何友树树何树友树.c(this.树何何树树友友树何何, 41972279541307L)) {
         if (mc.screen == null) {
            if (this.树树友树友树何何何友.getValue() && this.树友树友树友树友友何 < 10 && mc.player.hurtTime > 0 && this.何友何友树树何树友树.c(this.树何何树树友友树何何, 41972279541307L)) {
            }
         }
      }
   }
}
