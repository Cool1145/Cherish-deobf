package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.友树友友何友树友树友;
import cn.cool.cherish.utils.友树树何何树树何何树;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.player.树友友何树友树树树何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.client.ForgeHooksClient;

public class 友树友何何树何友树友 extends Module implements 何树友 {
   private final NumberValue 何友树何何友树何树树;
   private final NumberValue 何树友树何何友何何友;
   private final BooleanValue 树树树何树友友树树树;
   private final BooleanValue 友何友何何何何友何友;
   private final BooleanValue 何树友何友何何何树何;
   private final BooleanValue 友何何友树何友何友树;
   private final BooleanValue 树何友友树树友何何友;
   private final NumberValue 何何何何树何树友何树;
   private final BooleanValue 何友友何友树何树树何;
   private final BooleanValue 何何友树友树何何树树;
   private final BooleanValue 友何何树友友友何树友;
   private final 树友树友友何何树何何 友何何友何何何友友树;
   private int 树何友树何何友树树何;
   private long 何友树何友何何树友树;
   private int 树何树树友何友友何树;
   private BlockPos 友树何树友树友友友树;
   private int 树树友何何树友何树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[47];
   private static final String[] n = new String[47];
   private static String HE_WEI_LIN;

   public 友树友何何树何友树友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/combat/友树友何何树何友树友.a J
      // 003: ldc2_w 73960626264527
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 116137582100471
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 23446
      // 014: ldc2_w 6683282888307014318
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 15283
      // 021: ldc2_w 6150660451631798919
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -7748559181482772696
      // 02e: lload 1
      // 02f: invokedynamic Ó (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/NumberValue
      // 03b: dup
      // 03c: sipush 3221
      // 03f: ldc2_w 7847683388585717158
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 17699
      // 04c: ldc2_w 4491708597979440153
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 14
      // 058: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 05b: bipush 1
      // 05c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 05f: bipush 20
      // 061: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 064: bipush 1
      // 065: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 068: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 06b: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.何友树何何友树何树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 06e: aload 0
      // 06f: new cn/cool/cherish/value/impl/NumberValue
      // 072: dup
      // 073: sipush 7844
      // 076: ldc2_w 6240489940551843732
      // 079: lload 1
      // 07a: lxor
      // 07b: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 080: sipush 15227
      // 083: ldc2_w 3998525775567133278
      // 086: lload 1
      // 087: lxor
      // 088: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 08d: bipush 10
      // 08f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 092: bipush 1
      // 093: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 096: bipush 20
      // 098: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09b: bipush 1
      // 09c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09f: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0a2: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.何树友树何何友何何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 0a5: aload 0
      // 0a6: new cn/cool/cherish/value/impl/BooleanValue
      // 0a9: dup
      // 0aa: sipush 12444
      // 0ad: ldc2_w 707532558010257850
      // 0b0: lload 1
      // 0b1: lxor
      // 0b2: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b7: sipush 140
      // 0ba: ldc2_w 8473072430707548602
      // 0bd: lload 1
      // 0be: lxor
      // 0bf: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c4: bipush 0
      // 0c5: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0c8: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0cb: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.树树树何树友友树树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0ce: aload 0
      // 0cf: new cn/cool/cherish/value/impl/BooleanValue
      // 0d2: dup
      // 0d3: sipush 20090
      // 0d6: ldc2_w 2827073179652714334
      // 0d9: lload 1
      // 0da: lxor
      // 0db: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e0: sipush 12575
      // 0e3: ldc2_w 3570964699601080362
      // 0e6: lload 1
      // 0e7: lxor
      // 0e8: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ed: bipush 1
      // 0ee: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0f1: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0f4: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.友何友何何何何友何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0f7: aload 0
      // 0f8: new cn/cool/cherish/value/impl/BooleanValue
      // 0fb: dup
      // 0fc: sipush 31480
      // 0ff: ldc2_w 2518730495771597765
      // 102: lload 1
      // 103: lxor
      // 104: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 109: sipush 4484
      // 10c: ldc2_w 3415259907785699493
      // 10f: lload 1
      // 110: lxor
      // 111: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 116: bipush 1
      // 117: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 11a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 11d: aload 0
      // 11e: ldc2_w -7748830980347267803
      // 121: lload 1
      // 122: invokedynamic õ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 127: dup
      // 128: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 12b: pop
      // 12c: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 131: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 134: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 137: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.何树友何友何何何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 13a: aload 0
      // 13b: new cn/cool/cherish/value/impl/BooleanValue
      // 13e: dup
      // 13f: sipush 2740
      // 142: ldc2_w 7473788545259514765
      // 145: lload 1
      // 146: lxor
      // 147: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14c: sipush 22657
      // 14f: ldc2_w 3525778042019379622
      // 152: lload 1
      // 153: lxor
      // 154: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 159: bipush 0
      // 15a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 15d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 160: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.友何何友树何友何友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 163: aload 0
      // 164: new cn/cool/cherish/value/impl/BooleanValue
      // 167: dup
      // 168: sipush 15528
      // 16b: ldc2_w 5903957470217608595
      // 16e: lload 1
      // 16f: lxor
      // 170: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 175: sipush 16991
      // 178: ldc2_w 1744533635295044448
      // 17b: lload 1
      // 17c: lxor
      // 17d: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 182: bipush 0
      // 183: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 186: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 189: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.树何友友树树友何何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 18c: aload 0
      // 18d: new cn/cool/cherish/value/impl/NumberValue
      // 190: dup
      // 191: sipush 30244
      // 194: ldc2_w 2276470473186268950
      // 197: lload 1
      // 198: lxor
      // 199: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 19e: sipush 14317
      // 1a1: ldc2_w 1872673366474823386
      // 1a4: lload 1
      // 1a5: lxor
      // 1a6: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ab: dconst_1
      // 1ac: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1af: ldc2_w 0.1
      // 1b2: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1b5: ldc2_w 3.0
      // 1b8: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1bb: ldc2_w 0.1
      // 1be: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1c1: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1c4: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.何何何何树何树友何树 Lcn/cool/cherish/value/impl/NumberValue;
      // 1c7: aload 0
      // 1c8: new cn/cool/cherish/value/impl/BooleanValue
      // 1cb: dup
      // 1cc: sipush 3703
      // 1cf: ldc2_w 1588442428447764309
      // 1d2: lload 1
      // 1d3: lxor
      // 1d4: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1d9: sipush 29252
      // 1dc: ldc2_w 2843097858651411317
      // 1df: lload 1
      // 1e0: lxor
      // 1e1: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e6: bipush 1
      // 1e7: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1ea: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1ed: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.何友友何友树何树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1f0: aload 0
      // 1f1: new cn/cool/cherish/value/impl/BooleanValue
      // 1f4: dup
      // 1f5: sipush 22787
      // 1f8: ldc2_w 9075904300833634365
      // 1fb: lload 1
      // 1fc: lxor
      // 1fd: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 202: sipush 29151
      // 205: ldc2_w 3515846891650404579
      // 208: lload 1
      // 209: lxor
      // 20a: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 20f: bipush 1
      // 210: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 213: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 216: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.何何友树友树何何树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 219: aload 0
      // 21a: new cn/cool/cherish/value/impl/BooleanValue
      // 21d: dup
      // 21e: sipush 20411
      // 221: ldc2_w 6102537179622108827
      // 224: lload 1
      // 225: lxor
      // 226: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 22b: sipush 3369
      // 22e: ldc2_w 5245203444313074698
      // 231: lload 1
      // 232: lxor
      // 233: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友树友何何树何友树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 238: bipush 1
      // 239: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 23c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 23f: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.友何何树友友友何树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 242: aload 0
      // 243: new cn/cool/cherish/utils/树友树友友何何树何何
      // 246: dup
      // 247: lload 3
      // 248: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 24b: putfield cn/cool/cherish/module/impl/combat/友树友何何树何友树友.友何何友何何何友友树 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 24e: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-3613895626295133571L, -6816581302866175291L, MethodHandles.lookup().lookupClass()).a(227270223342633L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 4241395436223L;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[24];
      int var18 = 0;
      String var17 = " \u0096d\u0003\u0010\rÔò\u008eÍ\u001e\u0098\u009e\u0088\u009fM®\u0018áX@Ô ô\u0018Ñt5´\n41\u0010xñÙCwØ»ºs\u007f\u000bPqg\u0093Õ\u0010ðm^ûù\u0090J\u0016$Õcá\u008dÖ#½\u0018^\u009aÏbXa\u00940µþæ\u0014µxÃw0è\u009eñ\u00884\u0005¤\u0018CrZiø\\ÀØÄ\u007f\u008bßÊ¥\u0084ÖÆ\u0007\u001fã\u0010b~í \u0003¬;Ã\u0084((JQÖ\u000e%z\u0006=\u0091ì\rÎ\u0082p3Á;\u0018\u001c@0¤\rï¿ ÈÐed»íÿ\u0007\u001c¶ìA\u0017©7!lq\u0092!õ¬Ô\\Æ\u0014\u0012t\u0094×yä \"=ÊÃ\u009cv(R3\u0012\u0091¬xç/8\u0087év¶\bjg\u0001Ä\u001d(\u008d«U.X éÈ®§\u0004ÀÆ÷K\u00025yvw;ÓH}Û\b\u0097\u0014]\u0095Àì×þX§Gä k T¿X\u008bg±býÑ¼ôSâ\n\u0001ÙO(:þµ¢\u009b\u0092,´\u00834Uß\u0010¯þ\u008céÉÉÅ¸\t\u0084¦\u0011%/YÛ8§»»^¨\u001bè¹Þ©PÃÏ´|\u0090\u0093\n\u0092\u0083BÕ\fÓûóÏ\u001e^¦º4Ã,¬û`\nkÂ\u0097-%Ç9\u0002@\u000bÉÕ2$Ú\rÕ4@½¢=h3¹\u0000j`õMÚ\u0088ð\u009eW\\ \u008a(%nòFì\u000b\u0019L\u00adÞV5½\u000e\u0082Ã\u00892\u0019ª©?R¤\u0012\u001fK\u000fUó)×ì7\u0095\u0019ØxH\"§\u0017\u001d\u001f -\u0013\u00078\u0091Ú\u009e\u0017½§E\u0094õ?7\\\u0014\"p\u0019)³\u0012\u0003,è#MR[¤ë\u0010Ô\u0017Ü·mÞa\u000f¤Dö6ì,\u0099Ì\u0018\u0096:µµö\u009c\u00183},\u0004B¦b\u0007D\u001eÓ©è`PCR@l\u0087\n'\u008c ^r}B/\\\u0005òÇ/éqkØ²\u0015\u0087é¢ÓM{t\t°Ì«ßË)Ïö·ý2Á\fú\u009aØ\u0088Oeá.\u0017z%\u0014\u0093Û\u0001\u008c;ºð¥\u0085(èÍ-\u009a\ff%¨\u0081²\u0016\u000b=h°7úx\u0097\u0099ü\u001cÐ8~ø©È)\u0003´\u0087·\u0014\u008a\u008e\u000fgV÷\u0018\u0085Kû¨\u0007\u0010Cm+Áó\u007f¯6Xg\u0012,©!\u0095kI\u0083(\u009e\u009f\u001b\u0013ÚÒH\u008c\u009d-A\u007fb\nù\u0015\u009eÎGn`Ñªà\u0091{\u008d\u008aöµjkU\u001f\u0099\u0014$\u0017Üä8\u0015À\u0085§\u0019xÊ\u0007\u0085¿ÐQãßÂ\u00072Ð\bLEÐ¹°è·}³f\u0000¾\u0082£åD\u0099 NsG·û¡*,Ps\u0095âna\u00062¼\u0000Ê \u0013´¹l¼vç*ßJ\u0006á\u0088t¸(¨\u0099Æ`ê:ä\u0099yE?hï]0>";
      short var19 = 757;
      char var16 = ' ';
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[24];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "÷_\u009eº\u0094¨¬\u0012ïì\u009a\u0080ºöµæ".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "#°\u0089Ì ô§õ'ÇÉ\b'm¥\u0087\u0094Î\u0080\u009alð:l·iQ\u0000S×ö¨ \u0016*\tB²Yß3#¶¿\nôí\tóz'à2\u0018/N\u0082\u008e8r¤y?aØ";
                  var19 = 65;
                  var16 = ' ';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void B(MotionEvent event) {
      long a = 友树友何何树何友树友.a ^ 113481149205847L;
      long ax = a ^ 80479732251072L;
      long axx = a ^ 70956928143144L;
      d<"ö">(-4548130931717319439L, a);
      if (!this.w(new Object[]{ax})) {
         Object[] var10003 = new Object[]{null, axx};
         var10003[0] = 0;
         WrapperUtils.j(var10003);
         d<"e">(this, d<"õ">(this, -4548483579979339860L, a) + 1, -4548483579979339860L, a);
         if (!d<"õ">(this, -4547935675929598830L, a).getValue() || !this.f()) {
            this.b();
            this.J();
         }
      }
   }

   private void J() {
      long a = 友树友何何树何友树友.a ^ 110042908975117L;
      long ax = a ^ 77553323063452L;
      long var10001 = a ^ 132364963487269L;
      d<"ö">(7907133623443945899L, a);
      if (d<"õ">(this, 7907007382774996813L, a).c(d<"õ">(this, 7905686729344691326L, a), ax)) {
         if (d<"õ">(mc, 7906362437779150579L, a) == null) {
            if (d<"õ">(this, 7905259895468002033L, a).getValue()
               && d<"õ">(this, 7906783179116890870L, a) < 10
               && d<"õ">(mc.player, 7905329163470352843L, a) > 0
               && d<"õ">(this, 7907007382774996813L, a).c(d<"õ">(this, 7905686729344691326L, a), ax)) {
            }
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private void e() {
      long a = 友树友何何树何友树友.a ^ 108842822021802L;
      long ax = a ^ 84637564159549L;
      d<"ö">(-4675634938938283252L, a);
      if (!this.w(new Object[]{ax})) {
         float strength = d<"õ">(this, -4679176990833325770L, a).getValue().floatValue();
         if (d<"õ">(this, -4678137510921348330L, a).getValue() && Math.random() > 0.5) {
            float yawChange = (float)(Math.random() > 0.5 ? Math.random() * strength : -Math.random() * strength);
            mc.player.setYRot(mc.player.getYRot() + yawChange);
         }

         if (d<"õ">(this, -4674846103836187694L, a).getValue() && Math.random() > 0.5) {
            float pitchChange = (float)(Math.random() > 0.5 ? Math.random() * strength : -Math.random() * strength);
            float newPitch = mc.player.getXRot() + pitchChange;
            if (newPitch > 90.0F) {
               newPitch = 90.0F;
            }

            if (newPitch < -90.0F) {
               newPitch = -90.0F;
            }

            mc.player.setXRot(newPitch);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 25;
               case 1 -> 30;
               case 2 -> 54;
               case 3 -> 42;
               case 4 -> 58;
               case 5 -> 38;
               case 6 -> 33;
               case 7 -> 49;
               case 8 -> 55;
               case 9 -> 28;
               case 10 -> 61;
               case 11 -> 32;
               case 12 -> 27;
               case 13 -> 53;
               case 14 -> 24;
               case 15 -> 5;
               case 16 -> 26;
               case 17 -> 56;
               case 18 -> 39;
               case 19 -> 8;
               case 20 -> 0;
               case 21 -> 36;
               case 22 -> 51;
               case 23 -> 16;
               case 24 -> 31;
               case 25 -> 52;
               case 26 -> 12;
               case 27 -> 23;
               case 28 -> 34;
               case 29 -> 48;
               case 30 -> 41;
               case 31 -> 47;
               case 32 -> 50;
               case 33 -> 19;
               case 34 -> 6;
               case 35 -> 43;
               case 36 -> 2;
               case 37 -> 10;
               case 38 -> 21;
               case 39 -> 62;
               case 40 -> 13;
               case 41 -> 15;
               case 42 -> 22;
               case 43 -> 18;
               case 44 -> 20;
               case 45 -> 63;
               case 46 -> 1;
               case 47 -> 37;
               case 48 -> 35;
               case 49 -> 4;
               case 50 -> 44;
               case 51 -> 9;
               case 52 -> 40;
               case 53 -> 17;
               case 54 -> 45;
               case 55 -> 29;
               case 56 -> 14;
               case 57 -> 60;
               case 58 -> 7;
               case 59 -> 11;
               case 60 -> 57;
               case 61 -> 59;
               case 62 -> 46;
               default -> 3;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private void i() {
      long a = 友树友何何树何友树友.a ^ 74574650675931L;
      long ax = a ^ 46307949322927L;
      d<"ö">(-6958642081870673027L, a);
      long clicks = (long)(
         Math.round(
               (float)友树树何何树树何何树.k(
                  ax, d<"õ">(this, -6958099270782160191L, a).getValue().intValue(), d<"õ">(this, -6958877144142355314L, a).getValue().intValue()
               )
            )
            * 1.5
      );
      d<"e">(this, c<"q">(4620, 250746928396575200L ^ a) / clicks, -6962419924216848728L, a);
      if (d<"õ">(d<"õ">(mc, -6962096934360210990L, a), -6958249918774963793L, a).isDown()) {
         d<"e">(this, d<"õ">(this, -6962042042583062900L, a) + 1, -6962042042583062900L, a);
      }

      d<"e">(this, 0, -6962042042583062900L, a);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友树友何何树何友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13633;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友树友何何树何友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private void b() {
      long a = 友树友何何树何友树友.a ^ 31056079526558L;
      d<"ö">(1668777212796797752L, a);
      if (d<"õ">(this, 1668184051598170988L, a).getValue()) {
         boolean shouldJitter = d<"õ">(this, 1668513558504568436L, a).getValue()
               && d<"õ">(d<"õ">(mc, 1667728603117857175L, a), 1669159244332636650L, a).isDown()
            || d<"õ">(this, 1668947383094556978L, a).getValue()
               && d<"õ">(d<"õ">(mc, 1667728603117857175L, a), 1668331108514468898L, a).isDown()
               && !d<"õ">(d<"õ">(mc, 1667728603117857175L, a), 1669159244332636650L, a).isDown();
         if (shouldJitter && !this.f()) {
            this.e();
         }
      }
   }

   private void x() {
      long a = 友树友何何树何友树友.a ^ 131730255430567L;
      d<"e">(this, null, 5625102882490780501L, a);
      d<"e">(this, 0, 5625447573650304225L, a);
   }

   @EventTarget
   public void s(AttackEvent event) {
      long a = 友树友何何树何友树友.a ^ 137948559696349L;
      d<"e">(this, 0, 7812214881248201510L, a);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友树友何何树何友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 11401;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友树友何何树何友树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 245 && var8 != 'e' && var8 != 211 && var8 != 181) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 219) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 246) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 245) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'e') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 211) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private boolean f() {
      long a = 友树友何何树何友树友.a ^ 93970667112235L;
      long ax = a ^ 47105958749936L;
      d<"ö">(765041569771822733L, a);
      if (!d<"õ">(d<"õ">(mc, 761599945763730466L, a), 765403255846765663L, a).isDown()) {
         this.x();
         return false;
      } else if (d<"õ">(mc, 765285634371428146L, a) != null && d<"õ">(mc, 765285634371428146L, a).getType() == d<"Ó">(764758240487644522L, a)) {
         BlockHitResult blockHit = (BlockHitResult)d<"õ">(mc, 765285634371428146L, a);
         BlockPos currentBlockPos = blockHit.getBlockPos();
         if (友树友友何友树友树友.M(currentBlockPos, ax)) {
            this.x();
            return false;
         } else {
            if (d<"õ">(this, 764560791336439769L, a) == null || !d<"õ">(this, 764560791336439769L, a).equals(currentBlockPos)) {
               d<"e">(this, currentBlockPos, 764560791336439769L, a);
               d<"e">(this, 0, 764970350095968365L, a);
            }

            d<"e">(this, d<"õ">(this, 764970350095968365L, a) + 1, 764970350095968365L, a);
            return d<"õ">(this, 764970350095968365L, a) >= 1;
         }
      } else {
         this.x();
         return false;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友树友何何树何友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      m[0] = "uT%^Wqz\u0014hU]l\u007fIc\u0013UqrOgX\u0016w{Jg\u0013[q{XjI\u0016叕标叱佞佨栩佋叝栫叀";
      m[1] = long.class;
      n[1] = "java/lang/Long";
      m[2] = "\nwdYS\u0006\u00057)RY\u001b\u0000j\"\u0014Q\u0006\rl&_\u0012\u0000\u0004i&\u0014_\u0006\u0004{+N\u0012\"\u0000u&{I\u001b\b";
      m[3] = "(^f!\rl\u001c}ia@g\u0016`l<K!\u001e}a:Oj]_j+Vc\u0016)";
      m[4] = "T\u0016<\fF)[Vq\u0007L4^\u000bzA_'[\rwA@+G\u0014<-F)[\u001ds\u0001\u007f'[\rw";
      m[5] = int.class;
      n[5] = "java/lang/Integer";
      m[6] = "/6\u0001?&{/6\u0016c*t5}\u0016}\"w/'[\\\"|$0\u0007p-f";
      m[7] = "i pX 3i g\u0004,<skg\u001a$?i1*9=.n*j\u0005";
      m[8] = "\u0005*u\u001fTB\u0005*bCXM\u001fav^KG\u000faqY@XE\u0007hEkN\u0018:mE\u001d\u007f\u0012?d";
      m[9] = "`A8\u0015\u0004G`A/I\bHz\n;T\u001bBj\n<S\u0010] l%O;K}Q O";
      m[10] = "i`S\u0010[\u001ai`DLW\u0015s+DR_\u0016iq\tuS\nJdWN_\u001d`";
      m[11] = "\u000e\u0015wf(\u0002\u0005\u001af)T\u001b\n\u0000hjc+\u001c\u0017dwr\u0007\u000b\u001a";
      m[12] = "[\u001d\u0017\u0014tAT]Z\u001f~\\Q\u0000QYnZQ\u001fJY栊句栩厸史伢低栿佭伦";
      m[13] = "M\u0002c\u0007z\u0019BB.\fp\u0004G\u001f%Jx\u0019J\u0019!\u0001;伣佻厧优伱叞伣佻桽桜";
      m[14] = "105XpS10\"\u0004|\\+{\"\u0019o_q\u0017-\u0019~Q\u000f:2";
      m[15] = "\u0010@\u0004\bz5\u001f\u0000I\u0003p(\u001a]BEc;\u001f[OE|7\u0003B\u0004%`7\u0011KX=t6\u0006K";
      m[16] = "h:Kh\u001aGh:\\4\u0016Hrq\\*\u001eKh+\u0011!\u0002G(,\\4\u0012Kh,\u0011\u0015\u0014\\c:Q";
      m[17] = "\r\b\b\u000eCO\r\b\u001fRO@\u0017C\u001fLGC\r\u0019RPBG\u001a\b\u000e\u000ebI\u0000\f\u0010pBG\u001a\b\u000e";
      m[18] = "a k\u0013Q\u0015j/z\\0\u001ba$~\u0006";
      m[19] = "\u00018\u001fp\u0010Q\b0L\u001a伵叢桽伈叢佇伵核厧桌!`TAX<\u0010k\u0018\u001c";
      m[20] = "zoM\u001bnwsg\u001eq佋栞叜佟厰伬佋佚栆佟sJzlm~\r@o;u";
      m[21] = "&6&4I\b/>u^佬伥伞伆栁伃栨去伞桂\u00184\t\u0015y\"rnV\u001c ";
      m[22] = "\u001dct\u0004.+\u0014k'n桏伆桡栗厉伳厕厘伥栗JU4+Hh1\u0011; \u001a";
      m[23] = "\u000b/)\u000eDA\r>#\u0017~I`eyM@\u0019`T}H\u000f\\\fe.\u0010\u0018]";
      m[24] = "\u0012T\t\u0005[\\A\f\u001e\u0004`\u0003xXBFQPxiGD\u0019S\u0015\u001b\n\u001e\u0011S";
      m[25] = "&T:PHS/\\i:Y#|A;F[O)@<[0\u001c;\u0006xQ\\I:\u0001e:";
      m[26] = "\u0010i\u0002G2\u0005\u0019aQ-众厶厶余叿栴众桬桬余<\u0016&\u001e\u0007xB\u001c3I\u001f";
      m[27] = "\u0003\u0004,~U@\n\f\u007f\u0014叮佭厥伴住佉佰右伻厪\u0012/A[\u0014\u0015l%T\f\f";
      m[28] = "]S#\u0000D\u0003MV9R(\u0007a\u0007}Z\u0011Wa=~\tXYPF:\u0006S\u000b";
      m[29] = " r9BUb)zj(叮住优叜栞併叮住历栆\u0007\u0013Ay7cy\u0019T./";
      m[30] = "zZ,db?sR\u007f\u000e栃伒叜叴栋栗叙伒佂叴\u00125v$mKl?csu";
      m[31] = "\",9-X>n\u007f{:=厌栊叐叀伖你厌低栊叀K\fp)uf:@#kb";
      m[32] = "Y'4#\u0014_P/gI厯栶佡桓叉桐厯召叿桓\n PK\r8{7\u0013P\r";
      m[33] = "\\5pJH\u0017U=# 栩桾栠伅桗口右桾栠桁N\u001b\\\fK$0\u0011I[S";
      m[34] = "|\u0012rgP\u00032Lj6*3\u0006mDN*GzWewP\t$O4";
      m[35] = "tn==3A}fnW桒佬叒栚佞伊厈栨栈佞\u0003l)A!ex(&Js";
      m[36] = "eAh\u0005:\u001clI;o厁伱佝可伋伲伟厯參栵V_9\u0007kJl\u001d;Tj";
      m[37] = "\u0012|Lv4O\u001bt\u001f\u001c休叼桮佌伯叟桕佢桮栈rvtRMh\u0018,+[\u0014";
      m[38] = "Ju\u001f\u0005&eLw\fQ\u001e^s+\u0011\u0004adHl\u001a\u0015t\u000f";
      m[39] = "roJ7J\u0016{g\u0019]栫桿叔佟伩桄叱伻栎佟tfP\u0016'd\u000f\"_\u001du";
      m[40] = "0\u0006\u0015)W!9\u000eFC召伌伈桲叨厀召伌桌厨+xC:'\u0017UrVm?";
      m[41] = "EnFM\u0010\u001a\u000b0^\u001cj%:\r`'TX\u0006<A]\u001a\u0006\u001em";
      m[42] = "$\u0016z5K\u001a\"\u0007p,q\u0012O\\*vNCOm-~\u0003\u001caTh$\u001c\u0003";
      m[43] = "==\u001eCF<45M)佣休厛桉口栰佣休桁桉 \u0012R'*,^\u0018Gp2";
      m[44] = "\b~L3D\u001c[&[2\u007fCbr\u0007pN\u0013bC\u0002r\u0006\u0013\u000f1O(\u000e\u0013";
      m[45] = "s$N\u001amDu5D\u0003WL\u0018n\u001eYg\u001a\u0018_M\u00182@3&\u0017\u0010:X";
      m[46] = "h\u001fk%m\u001fa\u00178O佈桶収桫伈伒取伲佐厱U%-\u00027\u000b?\u007fr\u000bn";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void r() {
      long a = 友树友何何树何友树友.a ^ 51637435010357L;
      long ax = a ^ 67430461357866L;
      d<"ö">(37016985685136531L, a);
      if (d<"õ">(this, 36723711558364825L, a).getValue()) {
         if (d<"õ">(d<"õ">(mc, 40467096281759292L, a), 39451052106515337L, a).isDown()) {
            if (!d<"õ">(d<"õ">(mc, 40467096281759292L, a), 36373722360155713L, a).isDown()) {
               树友友何树友树树树何.z(ax, 1, true);
               if (Math.random() > 0.9) {
                  树友友何树友树树树何.z(ax, 1, true);
               }
            }
         }
      }
   }

   private void T() {
      long a = 友树友何何树何友树友.a ^ 96032811275641L;
      long ax = a ^ 129514598305256L;
      long axx = a ^ 75807377647462L;
      long axxx = a ^ 45043810432162L;
      d<"ö">(-2823762046283559713L, a);
      if (d<"õ">(this, -2828107371306632813L, a).getValue()) {
         if (d<"õ">(this, -2827188395207679698L, a) > 1) {
            if (!d<"õ">(d<"õ">(mc, -2827208068321384848L, a), -2828171348819190843L, a).isDown()) {
               boolean shouldClick = Math.sin(d<"õ">(this, -2827531093610489590L, a)) + 1.0 > Math.random()
                  || Math.random() > 0.25
                  || d<"õ">(this, -2823926220497589703L, a).c(c<"q">(4876, 7865644122088171331L ^ a), ax);
               boolean validTarget = d<"õ">(mc, -2824648554498568864L, a) == null
                  || d<"õ">(mc, -2824648554498568864L, a).getType() != d<"Ó">(-2824049773627027656L, a)
                  || 友树友友何友树友树友.M(((BlockHitResult)d<"õ">(mc, -2824648554498568864L, a)).getBlockPos(), axxx)
                  || d<"õ">(mc, -2824648554498568864L, a).getType() == d<"Ó">(-2824855559216747082L, a);
               if (shouldClick && validTarget) {
                  if (d<"õ">(this, -2827313441774030205L, a).getValue()) {
                     ForgeHooksClient.onMouseButtonPre(d<"õ">(d<"õ">(mc, -2827208068321384848L, a), -2824530934113675763L, a).getKey().getValue(), 1, 0);
                     树友友何树友树树树何.z(axx, 0, true);
                     ForgeHooksClient.onMouseButtonPost(d<"õ">(d<"õ">(mc, -2827208068321384848L, a), -2824530934113675763L, a).getKey().getValue(), 1, 0);
                  }

                  树友友何树友树树树何.z(axx, 0, true);
               }
            }
         }
      }
   }

   private static String HE_SHU_YOU() {
      return "何炜霖230622200409390090";
   }
}
