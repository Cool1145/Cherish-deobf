package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.GameLoopEvent;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.packet.HandleReceivePacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundMoveEntityPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ClientboundSetHealthPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ClientboundTeleportEntityPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import why.tree.friend.antileak.Fucker;

public class 友友友何树何何友何树 extends Module implements 何树友 {
   private final NumberValue 何树树何何友树何树友 = new NumberValue("Range", "范围", 1.0, 0.0, 10.0, 0.1);
   private final NumberValue 树友树何友何何友友树 = new NumberValue("Delay", "延迟", 150, 0, 1000, 10);
   private final BooleanValue 树友何何树何何友树何 = new BooleanValue("FilterVelocity", "过滤反击退", false);
   private final NumberValue 何友友何树树友何树树 = new NumberValue("NextBackTrackDelay", "下次回溯延迟", 0, 0, 1000, 10);
   private final NumberValue 何何友友何友何树何树 = new NumberValue("Chance", "触发概率", 100, 0, 100, 1);
   private final BooleanValue 树何友友树树友何何友 = new BooleanValue("PauseOnHurtTime", "受伤时暂停", false);
   private final NumberValue 友树何友树树何友树友 = new NumberValue("HurtTime", "受伤时间阈值", 5, 0, 10, 1);
   private final NumberValue 何何何何树何树友何树 = new NumberValue("LastAttackTimeToWork", "攻击后生效时间", 800, 0, 5000, 50);
   private final 何友友何树何树何树友 树何友友何树友树树友 = new 何友友何树何树何树友(51913986529303L);
   private final 何友友何树何树何树友 何何友何树友友何何友 = new 何友友何树何树何树友(51913986529303L);
   private final 何友友何树何树何树友 何友树友友友友友何树 = new 何友友何树何树何树友(51913986529303L);
   private final 何友友何树何树何树友 何树树何树友树树何友 = new 何友友何树何树何树友(51913986529303L);
   private Entity 友何树友何友树树友友;
   private 友友友何树何何友何树.友树何树树何树何树友 友何友何树友何友友何;
   private final LinkedHashSet<友友友何树何何友何树.树树友友友何友友何友> 友树友树何树何何何何 = new LinkedHashSet<>();
   private boolean 何友友友友树树友友何 = false;
   private volatile boolean 树树何何友友树树友树 = false;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[59];
   private static final String[] k = new String[59];
   private static String LIU_YA_FENG;

   public 友友友何树何何友何树() {
      super("BackTrack", "回溯", 树何友友何树友友何何.何何何何何树何何友树);
      this.树何友友何树友树树友.D(11747522392279L);
      this.何何友何树友友何何友.D(11747522392279L);
      this.何友树友友友友友何树.D(11747522392279L);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8346508114268837263L, 7263534471255639876L, MethodHandles.lookup().lookupClass()).a(256645923005592L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(34947821266566L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[20];
      int var7 = 0;
      String var6 = "\u0083n\u009ej\u008fñä÷l\u008e:6;74cè.]y\u001e=ÔVÀ\u008e[\u0003r\u007f\u0019{\u0018\u0004\u0011º$:\u000bt\u0085Wÿ|þ\u0098\u0018GËî2\u009c\u0096½Ì\u001b#(\u009c¦Weý\b\\R$ü\u001bE\u008b\u0082E\u009f¸ñ\u0093câH êÿ¯MîÝÖ§\u0093^$\u000eÃ\u0099u\u000b\u008f0\u00176üÎ¢\u008a\u0001\u0002þ¥\bíå%\u0092Z\u008e\u0083h\u0081´²:E\u001emó\u0013\u0095 ú\u0099I\u0094Æ\u000e?\u0090ûtå-\u001e9g(\u0092å\u0010FI\u0004·³Ö\u0090\u0089D+ú½°Þ\u0087â\u0010n\u009f/Èx\u0000\u0007ò#[\u00917\u0000Ýÿó\u0018\u0011\u0015ð2i¢D\u0002Å¼î%rh\\}\u0091\u0094\u0080æÐ÷ÿK Ôaú+'\u00adw\u0094÷\u009dkë\u0015XY\u001c\u0013¼\u00adÉO(Æ¥~!T\"Á°N\u000f(\u001eÓ®¦¡êP M\u0091M\u001fÆ\u001fÂ>\u001d;\u0015útI\u0083¯{Åm\u0093\tçÁ¿ø'm~¨\u0001IÒ\u0018\\`Þ\u00026\u0013\u008aO\u001bß³Ö0\u007fïßn\"±Þ|Øm\u0003\u0010è\u00ad\u008bO \u0088,!®/86i\u0016f1(yBÉAVëe§ø@\u007f.n\u0017fñR8\u000f¤Ä\u0003Á\u0011þ7ô@bk}a\u0096ð¸£/Ã\u0084b(èÇ\u0000Äá\u0004\u009c\u0005j\r\u009f8§üÁ\u0003\u001au\u001a&³ÖÙ÷\u0082Ä&4\u0012²¢\u0099t\u009d2\u0091HÈ\u0001¶ ê\u0084Æ\u0004\u0017·Êt\u000eÂê)ß¿\u0099Èñ\u0004-p\u0088M¶\u0099Fvf r»ß\u0004\u0010£®\u001bNJ\u001c\u0082í(=$C3³\u0086>\u0010ë\u0017gø§\u0088R\tÑ2Ë·\u009fÓ\t\u00ad\u0010h8xçbUú³@j¬Ù/{\u0081p |1áá¯¦\u0091tæiÄO&\"x\u009bE2aÛ\n\u0013E¤ïé·Ì \u009aq«";
      short var8 = 521;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[20];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "¸M\u0006\u0081î×ú¸³\u0003\fô\u0086ûqþ Â\u0091\u0086\u009aU}\u001dÓ8f\u001d*LÂÉ\u008e\u00846\u0011x`aQû!ª\u0098ãkë\u0001»";
                  var8 = 49;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void F(GameLoopEvent event) {
      KillAura.x();
      if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
         if (this.L()) {
            this.F(false);
         }

         if (!this.树树何何友友树树友树) {
            this.m();
         }
      }
   }

   @EventTarget
   public void F(AttackEvent event) {
      KillAura.x();
      if (this.isEnabled() && !this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
         this.何友树友友友友友何树.D(11747522392279L);
         if (this.友何友何树友何友友何 != null) {
            this.友何友何树友何友友何.N(true);
         }

         Entity entity = event.getTarget();
         this.H(entity);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private void F(boolean clear) {
      KillAura.x();
      LinkedHashSet var5 = this.友树友树何树何何何何;
      synchronized (this.友树友树何树何何何何){} // $VF: monitorenter 

      try {
         long currentTime = System.currentTimeMillis();
         if (this.友树友树何树何何何何.stream().anyMatch(packet -> {
            KillAura.x();
            return currentTime - packet.何树树何何何友何友树 >= this.树友树何友何何友友树.getValue().longValue();
         })) {
            this.友树友树何树何何何何.forEach(packet -> {
               KillAura.x();
               if (mc.getConnection() != null) {
                  try {
                     Packet<ClientGamePacketListener> clientPacket = (Packet<ClientGamePacketListener>)packet.树友友友何何友友何树;
                     if (this.i()) {
                        if (clientPacket instanceof ClientboundSetEntityMotionPacket || clientPacket instanceof ClientboundExplodePacket) {
                           return;
                        }

                        clientPacket.handle(mc.getConnection());
                     }

                     clientPacket.handle(mc.getConnection());
                  } catch (Exception var6x) {
                  }
               }
            });
            this.友树友树何树何何何何.clear();
            this.友何树友何友树树友友 = null;
            this.友何友何树友何友友何 = null;
         }

         // $VF: monitorexit
      } finally {
         // $VF: monitorexit
      }
   }

   @EventTarget
   public void S(HandleReceivePacketEvent event) {
      KillAura.x();
      if (this.isEnabled() && !this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
         if (!this.友树友树何树何何何何.isEmpty()) {
            this.树何友友何树友树树友.z((long)(Math.random() * this.何友友何树树友何树树.getValue().longValue()), 95391731592959L);
         }

         synchronized (this.友树友树何树何何何何) {
            if (!event.isCancelled() && event.getPacket() != null) {
               if (!this.友树友树何树何何何何.isEmpty() || this.L()) {
                  Packet<?> packet = event.getPacket();
                  if (!(packet instanceof ServerboundChatPacket)
                     && !(packet instanceof ClientboundSystemChatPacket)
                     && !(packet instanceof ServerboundCommandSuggestionPacket)) {
                     if (!(packet instanceof ClientboundPlayerPositionPacket) && !(packet instanceof ClientboundDisconnectPacket)) {
                        if (!(packet instanceof ClientboundSoundPacket soundPacket && soundPacket.getSound().get() == SoundEvents.PLAYER_HURT)) {
                           if (packet instanceof ClientboundSetHealthPacket healthPacket && healthPacket.getHealth() <= 0.0F) {
                              this.o(true);
                           } else if (this.友何树友何友树树友友 != null && mc.level != null) {
                              boolean isEntityPacket = packet instanceof ClientboundMoveEntityPacket
                                 && ((ClientboundMoveEntityPacket)packet).getEntity(mc.level) == this.友何树友何友树树友友;
                              boolean isPositionPacket = packet instanceof ClientboundTeleportEntityPacket
                                 && ((ClientboundTeleportEntityPacket)packet).getId() == this.友何树友何友树树友友.getId();
                              if ((isEntityPacket || isPositionPacket) && this.友何友何树友何友友何 != null) {
                                 if (packet instanceof ClientboundMoveEntityPacket c03) {
                                    double dx = c03.getXa() / 4096.0;
                                    double dy = c03.getYa() / 4096.0;
                                    double dz = c03.getZa() / 4096.0;
                                    if (this.友何友何树友何友友何.C() != null) {
                                       new Vec3(this.友何友何树友何友友何.C().x + dx, this.友何友何树友何友友何.C().y + dy, this.友何友何树友何友友何.C().z + dz);
                                    } else {
                                       Object var10000 = null;
                                    }

                                    if (Math.abs(dx) > 5.0 || Math.abs(dy) > 5.0 || Math.abs(dz) > 5.0) {
                                       return;
                                    }
                                 }

                                 ClientboundTeleportEntityPacket p = (ClientboundTeleportEntityPacket)packet;
                                 Vec3 pos = new Vec3(p.getX(), p.getY(), p.getZ());
                                 if (this.友何友何树友何友友何 != null && pos != null) {
                                    double moveDistance = this.友何友何树友何友友何.C().distanceTo(pos);
                                    if (moveDistance > 5.0) {
                                       return;
                                    }

                                    this.友何友何树友何友友何.Y(pos);
                                 }
                              }

                              event.setCancelled(true);
                              this.友树友树何树何何何何.add(new 友友友何树何何友何树.树树友友友何友友何友(packet));
                           }
                        }
                     } else {
                        this.o(true);
                     }
                  }
               }
            }
         }
      }
   }

   public void Z(boolean handlePackets, boolean clearOnly) {
      KillAura.x();
      if (!this.树树何何友友树树友树) {
         this.树树何何友友树树友树 = true;

         try {
            synchronized (this.友树友树何树何何何何) {
               if (mc.getConnection() != null) {
                  this.友树友树何树何何何何.forEach(packet -> {
                     try {
                        Packet<ClientGamePacketListener> clientPacket = (Packet<ClientGamePacketListener>)packet.树友友友何何友友何树;
                        mc.tell(() -> {
                           KillAura.x();

                           try {
                              if (this.i()) {
                                 if (clientPacket instanceof ClientboundSetEntityMotionPacket || clientPacket instanceof ClientboundExplodePacket) {
                                    return;
                                 }

                                 clientPacket.handle(mc.getConnection());
                              }

                              clientPacket.handle(mc.getConnection());
                           } catch (Exception var5x) {
                           }
                        });
                     } catch (Exception var5) {
                     }
                  });
               }

               this.友树友树何树何何何何.clear();
            }
         } finally {
            this.友何树友何友树树友友 = null;
            this.友何友何树友何友友何 = null;
            this.树树何何友友树树友树 = false;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private boolean i() {
      c<"J">(633043959825866907L, 69862228953285L);
      return c<"ª">(634424090622495243L, 69862228953285L) != null
         && c<"ª">(634424090622495243L, 69862228953285L).isEnabled()
         && !c<"ó">(c<"ª">(634424090622495243L, 69862228953285L), 634559180766858594L, 69862228953285L).K("")
         && !c<"ó">(c<"ª">(634424090622495243L, 69862228953285L), 634559180766858594L, 69862228953285L).K("Legit")
         && c<"ó">(this, 633704945874952721L, 69862228953285L).getValue();
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 24;
               case 1 -> 27;
               case 2 -> 56;
               case 3 -> 21;
               case 4 -> 42;
               case 5 -> 29;
               case 6 -> 63;
               case 7 -> 48;
               case 8 -> 4;
               case 9 -> 53;
               case 10 -> 8;
               case 11 -> 17;
               case 12 -> 36;
               case 13 -> 62;
               case 14 -> 38;
               case 15 -> 0;
               case 16 -> 44;
               case 17 -> 5;
               case 18 -> 2;
               case 19 -> 13;
               case 20 -> 37;
               case 21 -> 50;
               case 22 -> 47;
               case 23 -> 11;
               case 24 -> 15;
               case 25 -> 30;
               case 26 -> 61;
               case 27 -> 57;
               case 28 -> 34;
               case 29 -> 20;
               case 30 -> 19;
               case 31 -> 12;
               case 32 -> 6;
               case 33 -> 58;
               case 34 -> 39;
               case 35 -> 3;
               case 36 -> 60;
               case 37 -> 46;
               case 38 -> 26;
               case 39 -> 55;
               case 40 -> 40;
               case 41 -> 23;
               case 42 -> 22;
               case 43 -> 32;
               case 44 -> 52;
               case 45 -> 18;
               case 46 -> 14;
               case 47 -> 7;
               case 48 -> 28;
               case 49 -> 45;
               case 50 -> 43;
               case 51 -> 35;
               case 52 -> 49;
               case 53 -> 1;
               case 54 -> 54;
               case 55 -> 16;
               case 56 -> 10;
               case 57 -> 25;
               case 58 -> 41;
               case 59 -> 9;
               case 60 -> 59;
               case 61 -> 51;
               case 62 -> 33;
               default -> 31;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 30599;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友何树何何友何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[!¿Õi\u008c-\u0014öº?\u0007\u0080¶\u009fAM, \u0090dåU6ò0XeUWd")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友何树何何友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 243 && var8 != 195 && var8 != 170 && var8 != 'b') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 254) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'J') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 243) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 195) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 170) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private boolean c(Entity target) {
      KillAura.x();
      if (target != null && target.isAlive() && !target.isRemoved()) {
         if (target instanceof LivingEntity living && living.getHealth() < 3.0F) {
            return false;
         } else {
            Vec3 backtrackPos = this.友何友何树友何友友何 != null ? this.友何友何树友何友友何.C() : target.position();
            if (backtrackPos == null) {
               return false;
            } else {
               double backtrackDistance = backtrackPos.distanceTo(mc.player.position());
               if (!(backtrackDistance > 6.0) && !(backtrackDistance < this.何树树何何友树何树友.getValue().doubleValue())) {
                  boolean outOfRange = backtrackDistance > this.何树树何何友树何树友.getValue().floatValue();
                  if (!outOfRange) {
                     return false;
                  } else {
                     if (outOfRange) {
                        this.何何友何树友友何何友.D(11747522392279L);
                     }

                     return target instanceof LivingEntity
                        && KillAura.instance.V((LivingEntity)target)
                        && mc.player.tickCount > 10
                        && Math.random() * 100.0 < this.何何友友何友何树何树.getValue().doubleValue()
                        && !this.O()
                        && !this.何友树友友友友友何树.A(this.何何何何树何树友何树.getValue().longValue(), 118344821288830L);
                  }
               } else {
                  return false;
               }
            }
         }
      } else {
         return false;
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友何树何何友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private boolean n(Entity entity) {
      KillAura.x();
      if (this.友何友何树友何友友何 != null && this.友何友何树友何友友何.C() != null) {
         double distance = entity.position().distanceTo(this.友何友何树友何友友何.C());
         return distance > 3.0;
      } else {
         return true;
      }
   }

   @Override
   public void h() {
      this.o(true);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "r}JX\u0005Cr}]\u0004\tLh6I\u0019\u001aFx6[\u0018\u001cCha\u0010:\u0001\\uvY3\u0006^ulG";
      j[1] = int.class;
      k[1] = "java/lang/Integer";
      j[2] = "EB'\u00033rJ\u0002j\b9oO_aN1rBYe\u0005rtK\\eN?rKNh\u0014r取叭叧作桱伉佈叭佹栘";
      j[3] = "@c)\u0001tVKl8N\u001fBIg/\u00143UD";
      j[4] = boolean.class;
      k[4] = "java/lang/Boolean";
      j[5] = "g\u0011:*awhQw!kjm\f|gcw`\nx, qi\u000fxgmwi\u001du= Sm\u0013x\b{je";
      j[6] = "h\u00160qlp\\5?1!{V(:l*=^57j.v\u001d\u0017<{7\u007fVa";
      j[7] = "`\u0010sU\u0019\roP>^\u0013\u0010j\r5\u0018\u0000\u0003o\u000b8\u0018\u001f\u000fs\u0012sx\u0003\u000fa\u001b/`\u0017\u000ev\u001b";
      j[8] = "\u0004\u0019W\u0007v\u0013\u000bY\u001a\f|\u000e\u000e\u0004\u0011Jt\u0013\u0003\u0002\u0015\u00017\u0015\n\u0007\u0015Jz\u0013\n\u0015\u0018\u00107厷厬厼伬桵佌伩厬伢桨@叒桭伲桦桨伱栈伩桶厼";
      j[9] = "I\u001b(d\u0013nI\u001b?8\u001faSP+%\fkCP9$\nnS\u0007r\u000f\u0010sN\n%";
      j[10] = "\raq%\u001b(\u0002!<.\u00115\u0007|7h\u00013\u0007c,h伡厌厥佚桎伓桥伒桿叄";
      j[11] = "B`\u0011;q6M \\0{+H}Wvs6E{S=0案佴叅叴伍栏厒只佛佪";
      j[12] = "<'\u007fuC\u00023g2~I\u001f6:98A\u0002;<=s\u0002\u000429=8O\u00022+0b\u0002厦厔厂伄标佹伸厔伜桀2栽桼厔厂厚佃叧厦伊厂";
      j[13] = long.class;
      k[13] = "java/lang/Long";
      j[14] = "\u001b-\u0006Z3q\u001b-\u0011\u0006?~\u0001f\u0005\u001b,t\u0011f\u0002\u001c'k[\u001e\u0017\u0017m";
      j[15] = double.class;
      k[15] = "java/lang/Double";
      j[16] = "7\u0017Y!\u001eY8W\u0014*\u0014D=\n\u001fl\u0004B=\u0015\u0004l\u0003S:\u001d\u00120_d1\u0017\u0013'\u0003c \u0010\u001b1";
      j[17] = "J|QfU\\TtK)6HP";
      j[18] = "\u001fOr++\u001d\u0001GhdI\u0001\u001bEa.M\t\u0006FW/q";
      j[19] = "/\u001f\u0013C\u0017' _^H\u001d:%\u0002U\u000e\u000e) \u0004X\u000e\u0011%<\u001d\u0013b\u0017' \u0014\\N.) \u0004X";
      j[20] = "KopK84Kog\u00174;Q$j\u0000!*JxoK%/J~k\u0006:1\u000bZe\u0006>8Q";
      j[21] = "Er2Z\u0002\u0011Er%\u0006\u000e\u001e_9%\u0018\u0006\u001dEch\u0004\u0003\u0019Rr4Z#\u0017Hv*$\u0003\u0019Rr4";
      j[22] = "^fA\u0016>TQ&\f\u001d4IT{\u0007[<TY}\u0003\u0010\u007fRPx\u0003[2TPj\u000e\u0001\u007fmXd\u0000\u00168OD";
      j[23] = "/%a\u001ejD e,\u0015`Y%8'SsJ >*SlF<'a0jO)\u001d.\u0011pN";
      j[24] = "vZ}U\u007f\u0004vZj\ts\u000bl\u0011z\u0014g\u0003|L'(}\u0018v[L\rw\u0003lL";
      j[25] = "\u001a$BF}\u007f\u001a$U\u001aqp\u0000oE\u0007ex\u00102\u0018;\u007fc\u001a%s\u001eux\u0000";
      j[26] = "?v/I7.4y>\u0006V ?r:\\";
      j[27] = "\u0015]\\\u0019uY\u001dYN\u000eJ似可格可厪厉厢可佸栵iuZLBP\u00197[\u001cL";
      j[28] = "YVNJ?\nQR\\]\u0000[`\u0014FYf\u000e\\\u001fE@n2ZV]\\<\u000eQUDT\u0000";
      j[29] = "<X[\u0010\u001e@4\\I\u0007!桡佘口叨桹核去佘佽叨`MG:\u001bE\u0004S\u0019}\u0018";
      j[30] = ") SkZ*z)\u0014\u007f8厖厀桔厪栛佥厖桚厎伴\u0002Sk>uU~E*,r";
      j[31] = "|t4Q|1tp&FC佔历叏伙核桚及优栕桝!\u007f{<|:Ax3$p";
      j[32] = "/FB\u007f:\u0005'BPh\u0005你佋佣佯栖佘栤叕佣栫\u000f9OoNLo>\u0007wB";
      j[33] = "sN\nCBDw\u000fSP,J.MH@J@%6\u000fQ\u0012A&Y\u000b\u0010KR";
      j[34] = "v<+:\"l~89-\u001d厗桖伙厘桓栄伉厌桝厘J!&64%*&n.8";
      j[35] = "Oa?Q.mNq8C\\tGp9F:~L\u000b+E&kSs*U!y";
      j[36] = "eDW^RWm@EIm厬企叿佺样厮伲原叿佺.P\u000bg]\u001aJ\r\u001d S";
      j[37] = "jzXG4ob~JP\u000b伊伎叁叫佪又伊桊佟栱77%*rVW0m2~";
      j[38] = "QI\u0010W3d\u0005\n\u000fQV17\u0000R\u0010fg70\u0002\u00159c\u001fB\u0015\u0013o`";
      j[39] = ">\u007f/4<$k}8*@r\u00049l{q#\u0004\u0000$%&e9qlu~";
      j[40] = ":G :`7!\u00174Jb\u0001b\u001fhs2\u0001X^8,u<)\u0016ht";
      j[41] = "Y7\u0006\u0017\u00006Q3\u0014\u0000?体厣厌厵厤栦栗厣厌伫g\u0005u\u001d4\rX\\n\u0006!";
      j[42] = "Ie\u0005eu\u007fAa\u0017rJ会桩栄伨佈厉桞伭栄厶\u0015v5\tm\u000buq}\u0011a";
      j[43] = "rvK{6\u0016&5T}SC\u0014?\t<l\u001c\u0014\u000fY9<\u0011<}N?j\u0012";
      j[44] = "P|n\u0006!\u000fXx|\u0011\u001e叴桰叇标伫标佪伴余佃vr\r\u0014}'\u0014pH\fy";
      j[45] = "#v>\u0015#\u0005\"f9\u0007Q桤伐栅厇桲伌厾伐叟厇k>\u0016?&&\u001b7\u001f\"\u007f";
      j[46] = "FNFv\t\u0017J\u0019\u0018+m\bqN\u0019.W]qwCi\u0004\u001d\u001aNG-V\u0014";
      j[47] = "xj[\\\u00186pnIK'栗桘住佶可古栗桘发栲,\u001du<iP\u0013Dn'|";
      j[48] = "<u_ZL_84\u0006I\"@\u00071\u001aYOIhi\u0000[B0";
      j[49] = "\u001f#3q\u0016\u001f\u0017'!f)栾佻厘厀作栰古栿桂厀\u0001\u0016\u001cF<?qT\u001d\u00162";
      j[50] = "2B`\u0005baf\u0001\u007f\u0003\u00074T\u000b\"B7cT;rGhf|IeA>e";
      j[51] = "{U\u0013_f-&W\u0016[X伌伖伷伩佩桁伌伖厩桭4hn,\u0001JH5l)\u0005";
      j[52] = "\"n9/p+*j+8O低但叕伔框厌叐但佋厊_p({q5/2)+\u007f";
      j[53] = "\u0019\u0018 i\tQ\u0011\u001c2~6伴根桹伍栀叵桰根伽厓\u0019\tR@\u0007,iKS\u0010\t";
      j[54] = "xKZf\f\u001cpOHq3叧伜株叩佋台栽桘台叩\u0016\r@$\\\u0017}\u0003K9R";
      j[55] = "h1MP//`5_G\u0010栎厒桐你口位佊厒厊栤 ,e(9C@+-05";
      j[56] = "\u000fWkhj\u0016CHj!\u0013伬栦栰但佇低厲佢只栂\u001a\"LA\u0016abl\u0014\u0000T";
      j[57] = "8\b\u0019\bqu0\f\u000b\u001fN桔参伭伴桡伓伐参桩伴x\"r>K\u0007\u001c<,yH";
      j[58] = "\u001c\u001f=>)DP\u0000<wP栺可厢厎休伍叠可似桔L<Q\u0010\u0006q1kJI\u001d";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private void m() {
      this.Z(true, false);
   }

   private void o(boolean handlePackets) {
      this.Z(handlePackets, false);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void r(Entity entity) {
      KillAura.x();
      if (this.友何友何树友何友友何 != null) {
         double distance = entity.distanceTo(mc.player);
         if (distance > 6.0) {
            this.m();
            return;
         }

         this.友何友何树友何友友何.Y(entity.position());
      }
   }

   private boolean L() {
      KillAura.x();
      return this.友何树友何友树树友友 != null && this.友何树友何友树树友友.isAlive() && this.c(this.友何树友何友树树友友);
   }

   @EventTarget
   public void L(Render3DEvent event) {
      KillAura.x();
      if (this.友何树友何友树树友友 != null && this.友何友何树友何友友何 != null) {
         AABB backtrackBox = new AABB(
            this.友何友何树友何友友何.C().x - 0.4,
            this.友何友何树友何友友何.C().y,
            this.友何友何树友何友友何.C().z - 0.4,
            this.友何友何树友何友友何.C().x + 0.4,
            this.友何友何树友何友友何.C().y + this.友何树友何友树树友友.getBbHeight(),
            this.友何友何树友何友友何.C().z + 0.4
         );
         RenderUtils.友友树友树何友树友何.put(backtrackBox, new Color(255, 0, 0, 100));
         if (this.友何友何树友何友友何.u() != null) {
            AABB actualBox = new AABB(
               this.友何友何树友何友友何.u().x - 0.4,
               this.友何友何树友何友友何.u().y,
               this.友何友何树友何友友何.u().z - 0.4,
               this.友何友何树友何友友何.u().x + 0.4,
               this.友何友何树友何友友何.u().y + this.友何树友何友树树友友.getBbHeight(),
               this.友何友何树友何友友何.u().z + 0.4
            );
            RenderUtils.友友树友树何友树友何.put(actualBox, new Color(0, 255, 0, 100));
         }
      }
   }

   @Override
   public void M() {
      this.树何友友何树友树树友.D(11747522392279L);
      this.何树树何树友树树何友.D(11747522392279L);
      this.o(false);
   }

   public void H(Entity entity) {
      KillAura.x();
      if (entity != null && entity.isAlive() && !entity.isRemoved() && (!(entity instanceof LivingEntity) || !(((LivingEntity)entity).getHealth() <= 0.0F))) {
         double actualDistance = entity.position().distanceTo(mc.player.position());
         if (actualDistance > 5.5) {
            if (this.友何树友何友树树友友 != null) {
               this.m();
            }
         } else {
            boolean isSameTarget = this.友何树友何友树树友友 != null && entity.getId() == this.友何树友何友树树友友.getId();
            if (isSameTarget) {
               this.何友友友友树树友友何 = entity instanceof LivingEntity && ((LivingEntity)entity).hurtTime >= this.友树何友树树何友树友.getValue().intValue();
               if (this.友何友何树友何友友何 != null) {
                  this.友何友何树友何友友何.c(entity.position());
                  if (this.友何友何树友何友友何.u().distanceTo(mc.player.position()) > 5.5) {
                     this.m();
                     return;
                  }
               }

               if (!this.c(entity)) {
                  this.m();
               } else {
                  if (this.友何友何树友何友友何 == null || this.n(entity)) {
                     if (this.友何友何树友何友友何 == null) {
                        this.友何友何树友何友友何 = new 友友友何树何何友何树.友树何树树何树何树友();
                     }

                     this.r(entity);
                  }
               }
            } else if (this.c(entity)) {
               this.m();
               this.友何友何树友何友友何 = new 友友友何树何何友何树.友树何树树何树何树友();
               this.r(entity);
               this.友何友何树友何友友何.c(entity.position());
               this.友何树友何友树树友友 = entity;
            }
         }
      } else {
         if (this.友何树友何友树树友友 != null && this.友何树友何友树树友友.getId() == entity.getId()) {
            this.m();
         }
      }
   }

   @EventTarget
   public void T(TickEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
         if (this.友何树友何友树树友友 != null && this.友何友何树友何友友何 != null) {
            this.友何友何树友何友友何.N(false);
            this.友何友何树友何友友何.c(this.友何树友何友树树友友.position());
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "何树友被何大伟克制了";
   }

   private boolean O() {
      KillAura.x();
      return this.树何友友树树友何何友.getValue() && this.何友友友友树树友友何;
   }

   private static class 友树何树树何树何树友 implements 何树友 {
      private Vec3 友友何友友何何树树树;
      private Vec3 树何友树树何友树树友;
      private long 树何树何树友树何何树;
      private boolean 友树树何友树友树树何;
      private Vec3 树树何何友何树何友何;
      private static final long a;
      private static final long b;
      private static final Object[] c = new Object[15];
      private static final String[] d = new String[15];
      private static String LIU_YA_FENG;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(6252082331466449854L, 3870034232300295389L, MethodHandles.lookup().lookupClass()).a(262628964974189L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var2;
         Cipher var7 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var3 = 1; var3 < 8; var3++) {
            var10003[var3] = (byte)(78808410416856L << var3 * 8 >>> 56);
         }

         var7.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         byte[] var6 = var2.doFinal(new byte[]{-44, -15, -43, -120, 74, 33, -104, 6});
         long var8 = (var6[0] & 255L) << 56
            | (var6[1] & 255L) << 48
            | (var6[2] & 255L) << 40
            | (var6[3] & 255L) << 32
            | (var6[4] & 255L) << 24
            | (var6[5] & 255L) << 16
            | (var6[6] & 255L) << 8
            | var6[7] & 255L;
         byte var10001 = -1;
         b = var8;
      }

      public Vec3 C() {
         return this.友友何友友何何树树树;
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = c[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(d[var4]);
               c[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = c[var4];
         if (var5 instanceof String) {
            String var6 = d[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            c[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public void c(Vec3 pos) {
         KillAura.x();
         if (pos != null) {
            if (this.树何友树树何友树树友 != null) {
               long currentTime = System.currentTimeMillis();
               if (!this.友树树何友树友树树何 && currentTime - this.树何树何树友树何何树 < 50L) {
                  return;
               }

               double distance = this.树何友树树何友树树友.distanceTo(pos);
               double maxDistance = this.友树树何友树友树树何 ? 20.0 : 10.0;
               if (distance > maxDistance) {
                  if (this.树树何何友何树何友何 != null) {
                     this.树何友树树何友树树友 = this.树树何何友何树何友何;
                  }

                  return;
               }
            }

            this.树何友树树何友树树友 = pos;
            if (!this.友树树何友树友树树何) {
               this.树树何何友何树何友何 = pos;
            }

            this.树何树何树友树何何树 = System.currentTimeMillis();
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = d[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            c[var4] = var21;
            return var21;
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'D' && var8 != 204 && var8 != 205 && var8 != 'P') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 223) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 225) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'D') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 204) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 205) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static void a() {
         c[0] = "RT\u0019\u000b\rC]\u0014T\u0000\u0007^XI_F\u000fCUO[\rLE\\J[F\u0001C\\XV\u001cL叧叺叱佢桹伷佹叺佯栦L厩栽佤栫栦伽桳佹栠叱";
         c[1] = "UM\n3\u0012sUM\u001do\u001e|O\u0006\tr\rv_\u0006\u000eu\u0006i\u0015~\u001b~L";
         c[2] = "'\u0005's,X,\n6<PA#\u00108\u007fgq5\u00074bv]\"\n";
         c[3] = "!\u0005n'as.E#,kn+\u0018(jcs&\u001e,! u/\u001b,jms/\t!0 W+\u0007,\u0005{n#";
         c[4] = ";\u0015(EXS\u000f6'\u0005\u0015X\u0005+\"X\u001e\u001e\r6/^\u001aUN\u0014$O\u0003\\\u0005b";
         c[5] = boolean.class;
         d[5] = "java/lang/Boolean";
         c[6] = long.class;
         d[6] = "java/lang/Long";
         c[7] = "s\u0012:o|jx\u001d+ \u001dds\u0016/z";
         c[8] = "_\u0013\u0006-TK_\u0014TN司另佦厱叴伓佦格栢桫7w\u0006F\nC\u000fvQ\u001e]";
         c[9] = "\u0011\u001c?pe\"\u0011\u001bm\u0013cLL\u0002n(2t\u001aEb\"\nu\n\u001d5+2#M\u0011?\u0013";
         c[10] = "pKp^#1pL\"=桕伂受栳桘你厏框栍叩A\u0004q<%\u001by\u0005&dr";
         c[11] = "Z%>\u0004;hZ\"lg桍佛栧伙栖厤桍佛佣桝\u000f[e>Z;v\u00025oS";
         c[12] = "J3qXJ+\u0013)+]4#pm,\u0002Q6M.+\u0016WS";
         c[13] = "k@p9\u000f\u0001kG\"Z桹桶佒佼厂伇桹伲双佼Ac]\f>\u0010yb\nTi";
         c[14] = ",z|=KY,}.^叧栮桑但厎桇叧栮桑但Me[P/w7![Q/";
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友何树何何友何树$友树何树树何树何树友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (d[var4] != null) {
            return var4;
         } else {
            Object var5 = c[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 34;
                  case 1 -> 1;
                  case 2 -> 20;
                  case 3 -> 35;
                  case 4 -> 6;
                  case 5 -> 56;
                  case 6 -> 24;
                  case 7 -> 16;
                  case 8 -> 59;
                  case 9 -> 8;
                  case 10 -> 9;
                  case 11 -> 11;
                  case 12 -> 50;
                  case 13 -> 52;
                  case 14 -> 4;
                  case 15 -> 57;
                  case 16 -> 21;
                  case 17 -> 19;
                  case 18 -> 61;
                  case 19 -> 37;
                  case 20 -> 26;
                  case 21 -> 38;
                  case 22 -> 31;
                  case 23 -> 18;
                  case 24 -> 33;
                  case 25 -> 2;
                  case 26 -> 25;
                  case 27 -> 5;
                  case 28 -> 22;
                  case 29 -> 30;
                  case 30 -> 23;
                  case 31 -> 60;
                  case 32 -> 14;
                  case 33 -> 49;
                  case 34 -> 43;
                  case 35 -> 39;
                  case 36 -> 54;
                  case 37 -> 12;
                  case 38 -> 51;
                  case 39 -> 42;
                  case 40 -> 45;
                  case 41 -> 44;
                  case 42 -> 58;
                  case 43 -> 41;
                  case 44 -> 13;
                  case 45 -> 15;
                  case 46 -> 48;
                  case 47 -> 3;
                  case 48 -> 62;
                  case 49 -> 46;
                  case 50 -> 63;
                  case 51 -> 40;
                  case 52 -> 53;
                  case 53 -> 32;
                  case 54 -> 0;
                  case 55 -> 10;
                  case 56 -> 47;
                  case 57 -> 36;
                  case 58 -> 17;
                  case 59 -> 7;
                  case 60 -> 27;
                  case 61 -> 55;
                  case 62 -> 29;
                  default -> 28;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               d[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      public Vec3 u() {
         return this.树何友树树何友树树友;
      }

      public void Y(Vec3 pos) {
         KillAura.x();
         if (this.友友何友友何何树树树 != null) {
            double distance = this.友友何友友何何树树树.distanceTo(pos);
            if (distance > 5.0) {
               return;
            }
         }

         this.友友何友友何何树树树 = pos;
         if (!this.友树树何友树友树树何) {
            this.树树何何友何树何友何 = pos;
         }
      }

      public void N(boolean attacking) {
         this.友树树何友树友树树何 = attacking;
      }

      private static String HE_DA_WEI() {
         return "何炜霖国企上班";
      }
   }

   private static class 树树友友友何友友何友 implements 何树友 {
      final Packet<?> 树友友友何何友友何树;
      final long 何树树何何何友何友树;
      private static int _何炜霖国企上班 _;

      树树友友友何友友何友(Packet<?> packet) {
         this.树友友友何何友友何树 = packet;
         this.何树树何何何友何友树 = System.currentTimeMillis();
      }

      private static String LIU_YA_FENG() {
         return "何大伟为什么要诈骗何炜霖";
      }
   }
}
