package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.item.友何树树何树何何何友;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.何树何树友树树友友何;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class 友树树树何友树树友何 extends Module implements 何树友 {
   private final ModeValue 何何友友友何何树何何 = new ModeValue("Mode", "模式", new String[]{"CSGO", "New", "Old"}, "New");
   private final NumberValue 友树何树友友何何友树 = new NumberValue("Range", "范围", 5, 3, 100, 0.1);
   private final NumberValue 何树友树何树树何何树 = new NumberValue("Fov", "视野角度", 180, 0, 360, 1);
   private final ModeValue 友何友友友何友何何树 = new ModeValue(
      "Priority Mode", "目标优先级模式", new String[]{"Distance", "Health", "Fov", "Direction", "EasyToKill", "ThreatLevel", "LivingTime", "Armor"}, "Distance"
   );
   private final BooleanValue 何何何友友友树何树何 = new BooleanValue("On Click", "点击触发", true);
   private final NumberValue 友何树何树树树友何何 = new NumberValue("Click Time", "点击时间", 500.0, 0.0, 1000.0, 1.0);
   private final BooleanValue 树友树树树何何树友何 = new BooleanValue("Through Walls", "穿墙", false);
   private final NumberValue 友友友树树树友树友友 = new NumberValue("Through Walls Range", "穿墙范围", 2.5, 1, 6.0, 0.1).A(this.树友树树树何何树友何::getValue);
   private final BooleanValue 何树树树友何何何树何 = new BooleanValue("Disable On Mining", "挖掘时禁用", true);
   private final NumberValue 友树树树树何何友何友 = new NumberValue("Max Rotation Speed", "最大转头速度", 5, 1, 10, 1).A(() -> this.何何友友友何何树何何.K("CSGO"));
   private final NumberValue 友友何树树何何树友何 = new NumberValue("Min Rotation Speed", "最小转头速度", 5, 1, 10, 1).A(() -> this.何何友友友何何树何何.K(""));
   private final BooleanValue 树何树友友友何何友友 = new BooleanValue("Only Yaw", "仅水平瞄准", false).A(() -> this.何何友友友何何树何何.K("New"));
   private final NumberValue 树树树友友友友何何何 = new NumberValue("Smooth", "平滑度", 15.0, 1.0, 90.0, 1.0).A(() -> this.何何友友友何何树何何.K("New"));
   private final BooleanValue 树何友何树友树友友树 = new BooleanValue("Aim Head", "瞄准头部", true).A(() -> this.何何友友友何何树何何.K("Old"));
   private final NumberValue 何何何友树何何友何友 = new NumberValue("Head Height", "头部高度", 0.85, 0.0, 1.0, 0.01).A(() -> {
      KillAura.x();
      return this.何何友友友何何树何何.K("Old") && this.树何友何树友树友友树.getValue();
   });
   private final BooleanValue 何友树树友树树何友树 = new BooleanValue("Aim Body", "瞄准身体", true).A(() -> this.何何友友友何何树何何.K(""));
   private final NumberValue 何树友树树树树何友何 = new NumberValue("Body Height", "身体高度", 0.5, 0.0, 1.0, 0.01).A(() -> {
      KillAura.x();
      return this.何何友友友何何树何何.K("CSGO") && this.何友树树友树树何友树.getValue();
   });
   private final BooleanValue 何何树友树树何友友树 = new BooleanValue("Aim Feet", "瞄准脚部", false).A(() -> this.何何友友友何何树何何.K("Old"));
   private final NumberValue 何何友树树树树友树何 = new NumberValue("Feet Height", "脚部高度", 0.1, 0.0, 1.0, 0.01).A(() -> {
      KillAura.x();
      return this.何何友友友何何树何何.K("Old") && this.何何树友树树何友友树.getValue();
   });
   private final NumberValue 树何友友树树友树树何 = new NumberValue("Aim Threshold", "瞄准阈值", 5.0, 1.0, 45.0, 1.0).A(() -> this.何何友友友何何树何何.K("Old"));
   private final BooleanValue 树友友友友友树何树何;
   private final NumberValue 何友何友树何何友树树;
   private final BooleanValue 何树树何何友树友树友;
   private final NumberValue 友何友何何友何何树友;
   private Rotation 树树何友友何树友友友;
   private Rotation 友树何何树何树何何何;
   private boolean 树树何何何树友树何树;
   private final 何友友何树何树何树友 何树友树友树友树树何;
   private final List<LivingEntity> 友友友树友友何友何树;
   private double 友树何何友友友何友树;
   private double 友树友何友何友友树树;
   private float 何树友友何树友树何友;
   private float 树树何友树友友树友何;
   private float 友树树何友树友友友树;
   private float 树树友何何友何树树何;
   private float 何何友何友何何友友何;
   private float 树树何友树树何树友何;
   private BlockPos 树友何树友何友树何友;
   private int 何树友树何树树树友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[87];
   private static final String[] k = new String[87];
   private static String HE_JIAN_GUO;

   public 友树树树何友树树友何() {
      super("AimAssist", "自动瞄准", 树何友友何树友友何何.何何何何何树何何友树);
      KillAura.x();
      this.树友友友友友树何树何 = new BooleanValue("Horizontal Aim", "水平瞄准", true).A(() -> this.何何友友友何何树何何.K("Old"));
      this.何友何友树何何友树树 = new NumberValue("Horizontal Speed", "水平速度", 1.0, 0.1, 2.0, 0.1).A(() -> {
         KillAura.x();
         return this.何何友友友何何树何何.K("Old") && this.树友友友友友树何树何.getValue();
      });
      this.何树树何何友树友树友 = new BooleanValue("Vertical Aim", "垂直瞄准", true).A(() -> this.何何友友友何何树何何.K(""));
      this.友何友何何友何何树友 = new NumberValue("Vertical Speed", "垂直速度", 1.0, 0.1, 2.0, 0.1).A(() -> {
         KillAura.x();
         return this.何何友友友何何树何何.K("Old") && this.何树树何何友树友树友.getValue();
      });
      this.树树何何何树友树何树 = false;
      this.何树友树友树友树树何 = new 何友友何树何树何树友(51913986529303L);
      this.友友友树友友何友何树 = new ArrayList<>();
      this.友树何何友友友何友树 = 0.0;
      this.友树友何友何友友树树 = 0.0;
      this.何树友友何树友树何友 = 0.15F;
      this.树树何友树友友树友何 = 0.15F;
      this.友树树何友树友友友树 = 0.0F;
      this.树树友何何友何树树何 = 0.0F;
      this.何何友何友何何友友何 = 0.0F;
      this.树树何友树树何树友何 = 0.0F;
      if (Module.Z() == null) {
         KillAura.f(new Module[2]);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(5146865222035012808L, -456252369033473879L, MethodHandles.lookup().lookupClass()).a(139297145900153L);
      // $VF: monitorexit
      a = var10000;
      c();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(95324565599457L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[71];
      int var7 = 0;
      String var6 = "m2\u009a]\b°5z\u000bW\u007f\u0018/pÔ\f«\u0000Æ\u009f\n?«¦ \u001cO¾_XÛ¬Çjªºsâú\u0094»§2i\u00adÝ\u001a\u0001B\u009d©¯\u0002GR_  \u001c?\u0089ôj·X\r\u00913ÀÜ &OÀ0ðP\u0091Zý\u0085§\u0090\u0093\u0083¿DVe\u001a(\u00060\u0014\u001c®\u001d<©Êí\u0015Ä%È7J«`\u009d\u0001Y\u0090±¸IàË3x0\u009fý\u001b\u0088öûp\u0089·ò @úC1.áæ®>\u009fµ«w^\u0091Ç\u0093¬R\u0014¨¹\u001a\u0085Ô|£\u0007$N´ì\u0018\u0089A)\u0010òÆ\u0089«\u008eÇê\u001d\u0082·@8Ð\u0083*qÿE,á\u00104@ú\u0002f*%\u001cì\u001c³ÖC\"=ø(½ëÝ@Â\u0082ðT\u0080ýFc@mq5ç\"C\u0000¾Éôø0O|\u0006H(\u0002d\u0092Æ\fF\u001c%\u0013ÿ \u0001ÿm¥ß\u000bì\u000fV+\u009am\u0095ÝÄînM\u009f¹Áax\u0089áHBX`ÞÃ¢\u0018Ý{[\u008es^j\u0089Ï8@ê£\u000fò¥\u0080Cø\u0087\u00867 Ü 3w¤¯}´½«X\rÒîf¡¾)½sîò\u0016_<AÆ6ôÔ0\u0081\u008e\u0016\u0010\u0085¦9u\u009ey°4~>'\u0001vB÷4\u0010Ø\u008d\u007fíß\u0095½$\u0084L\u0000¤·â$B\u0018Y9\u0080)Çºçyã¯\u0010l\u008bÕ-y)\u001fF52\u0095dZ\u0018fC\u0095< \u0012ýÂSþ&ÚÇ÷Ûw\u009dÙ\u009cJ\nnKó\u0018þyi\u0014\u009b\u008dÉ+é\u0081Þö«ãá\u0082\u0093Ü°¤.îåJ\u0010N·Î\u00136a¶iÛßÏâû3\u001f\u009a  \u001d\u0003>çfò×)ÇÔ\\\u0014QÐÆäuå\u0090gE\u008cj($øÖ¬\u0082_\u0085\u0018:ce\u009aC3\u0096\u008cYA\u0014csìá\u0096¡\u0003t\tL\u0084ìþ \u00adNTYQ\u009b ë×n¢Y¶1QeN\u007f\u009f\u009a]o\u0085ãÞ\u0002]6\u0087\u00adÐà èNU¼\u001f\u0099B¿U[\tqÜ\u009d©®\u0011;«Z\u001e\u0006\u008e¯ê\u00066\u008d\u0087~Î\u0016 lÄ1ÝsXÅF$Ø|\"o\u0013¤Ê\u0083\u0097\"=+dJ^Q\u00979Ìd½\u008fg(«\u0097£»pàtÕû\u0083\u0001$\u009eö\u008fÞ\u009dô©]F$ô«\u0000½_\u0010\u00ad¬Ì£\u0090½Véb<[\u0010\u0010ïÇ\u0005\u0080´w\"é?\u0095ÔÜ=ñ|A Å¨<x\u0089\u0098§Cqõ\u009a£b0C:C§Kt[öw*aAÉ\u0093®µI\u0019 \u001eAR(p5jè*a\u0005\u0099/Ìz\u0092bN!9\u001aÐAÚuy¾ÑP±ñÛ\u0018dz\u0085¶}üåÀ(:æêøÔ½9{c@\u0081\u0086õ®\u0085\u00100h\u0001õÎAm»V¿ÿ\u00066á\u009c\u0095\u0010Ï\u0019¨\u007fe\u0084# æ\u001eÁ\u0091\u009e4\u0016Ñ º>¨Ú\u0082\fì³¹¹R\u0097x[\u001a\u000b$Â\u000f<ò?â¿V0\u008a¼¾»\u0080\u0018 K²R\u0017Uk\u00810Ä¥¨\u009dÓÁ¦×¹\\\u008b|`\u0085\u0017\u000bCjù\u0089Xc'\u0019\u0010Öan\u0012m\u0090¼¼î£r£ÐzK\u0085 Ð\u0081ã(£ù\u008e%\u0088ðïÅ=Éãd\u008a~ZYÈï\tü$î\u0011)iWe\u0015 U\u0096\u0088,\u00873tÊÕ\u0087¡ÞÏF'Ã~\u00932í\u009a)ÝGI\u0099¯,\u0010ó\u001c\u0011\u0010\"\u00001\u0083\u0015¦ñmh2f~}@«N\u0018\u0095U\u009d\nÓw®\u0092\u0002\u0006áxÖµ%Í:\u008a\u009fÍ&´ôO <D\u0099Ô\u0019¿SRV¬¦\u0014\u000fÜ&¬þ¯ò\u00ado\u001e·\b/ºÒuN\u0099\u0013-(Æ\u0099\u0003>\u0010-Å{6Ä\u001f\u00936²\u001d«ÉiÓ\u0006¬ÁV²SD\u0012Ñ¼\u009d\u0088Øt\u009c{\u0085 jdÏ hk\f\n\u000b<\u0083Ù]À]ÞÈYÄù\u001b$`\u0014fùEÝ\f9\u001d\u001c+¶\u0090\u0088\u0010\u0015tZ\f×|\u001bmKD\u008c<¹éõ§\u0010¨\u0018§Ñó«¹\u009eÓ7ÚiµÞ\u001em ®²Í´[|¹îör\u009eâ=\u001a W\u0096²6\u007fxêWô\u001b\u008fF*E¾¹\u008c\u0010ÔWvt\u0003¹\"ûÊYwüèùc (Ç\u001f\r'Ä\u001ee\u009b%i@{ \r\u0087Ñ+\báÁÌÀbZëä(Ü?r0g¸ËøO[N\u0014\r\u0018\u0001ã4ÿT\u0099\u0099«\u0000]6\u0005|%Yÿ\u0087C¹iî\u0006-® cê\u0083\u0098×g\u000e\u0003Å%²_±Ø¼ÞØnÐ1ï¶ê¼dÛ=cç\u001eºã(\b\bÕêÈ?Ë!ë\u001f¢\b¬\u0098\u007f\u008c\u0007tì\u000f\u0012¦\u009eðâ®~åôþ:>áÙÌy©\"wK\u0018\u0002©\u0007>5f\u0096kD~=©\u009a\u0080\u0090µ8B:¡ï\u0093;|  .Z\u001dS\"Ø¥ptH\u0001\u008aôÁªø\u000e{5îÆ \fo2Un4xÇ\u0093 6[\u001dÕüªKëpW¾C+<¨H!2ÅùE\"lEi¨RüÂ\u0085ª\u0007 âÇ\u001dMrâO\u0095\u0006²£\u0014ñ\u0018\u0016Q6%K\u001fÀI=4\u0088\u008dÜ©²\u001c0Þ -\u0099\u000bS0²\u0099\u000b\u0089ÿ\u008ey\u009c\nùW|Ë¼¬Ôhî§¾\u0097ßh#«±\u0097 æ\u001dz¶ù\u001d¥b$7ÙfÉ!é¥üÅb[X²äø6Nöâ\u001fIÒa\u0018©`Â\u001e\u0087è\u001aáèt9\"\u007fÀ(Ks1t¬/>\u0007¼(î\u0016á\u0016÷ç.\u0017\f\u0089ñóò\u009d<èªþåxt\u0010¹\u008d Öx\u009eQµv!Ò:\\ø§Cîô\u0018i\tc\u009edFd\u0088rE\u009f $3Ì§cUg#s»?\u0099 mï\u0006£Ó-\u0015È\u0093Ó\u0090zÉ#\u0006¾¿ìÌ}N\u0088eóºÓô\u0004\u000e\u0017×; àæ;\u0012Ä-N|\u0000\u0004ÆÉ½N|Í_\u0005wGºà4X\u0095É|¦X\u008aõ¼\u0010ª¤¥ÙùÝÂ£ù¶ÒÕ}£¹\u0017\u0010\u00ad\u0080ËÐÏ_\u008d©\u0013>r8\u0091¸\u0098ë\u0010F\u001b\u0090\u0005W\u0014Ql\u008e¬å.Á+ð\u0087\u0010Òy\f\u0088ÎÊô]z³¿\u0081«Ün=\u0018\u001bôD\u0086Çz9MÅD\u000fÓz\u0003Å\u001dþx\u001dÄlr;Ó\u0018ÙvïT#v\u0094t5âM¼Ê\u008e\u00ad\u0006\u009aFh\u0085§æ¶¨\u0010h§ô&<\u0005^×\u00ad§´m^\u0096Ø\u0094\u0018Ðp´ðBK2\u0095`\u001a\u00adæ\u0011\\Ï\u0016Û#\u009eâb¿mÁ\u0018\u0087BÂ\ruÜ\u0089ay\u0007@\u0087y\"G¶]\u0096(\u0097XÏÂH\u0018â\u008aZÜP'\u0014 Apé\u0017åtãÛÐ\f\u00adSO\u009cëÚ\u0010ÒÐã\u001d\u0006Î\u001dÜ?¸êÍJù¼\u009d";
      short var8 = 1900;
      char var5 = 24;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[71];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u008f\u009aiT¸\u0014Mýþ_øñe\u0017®\u0011æ!\u0016\u0081ªLy9\u0000Mü\u0085¾ë\u0096vÉI»b\u0088i¯J\u0018_J\f\\\u008bÒù\r\u0006Ät\u0012t\u0081ú¢â#>#\u008bop%";
                  var8 = 65;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private float V(float current, float target, float speed, boolean isYaw) {
      KillAura.x();
      if (this.Q(new Object[]{52406761729175L})) {
         return 0.0F;
      } else {
         float diff = Mth.wrapDegrees(target - current);
         float absDiff = Math.abs(diff);
         if (absDiff > 90.0F) {
            diff = diff > 0.0F ? 5.0F : -5.0F;
            return current + diff;
         } else {
            float targetVelocity = isYaw ? target - this.友树树何友树友友友树 : target - this.树树友何何友何树树何;
            this.何何友何友何何友友何 = this.何何友何友何何友友何 * 0.9F + targetVelocity * 0.1F;
            this.树树何友树树何树友何 = this.树树何友树树何树友何 * 0.9F + targetVelocity * 0.1F;
            float baseSmoothFactor = speed / 20.0F;
            if (absDiff > 15.0F) {
               baseSmoothFactor = Math.min(baseSmoothFactor * 1.2F, 0.9F);
            }

            if (absDiff > 5.0F) {
               baseSmoothFactor = Math.min(baseSmoothFactor, 0.6F);
            }

            baseSmoothFactor = Math.min(baseSmoothFactor * 0.95F, 0.4F);
            float velocityFactor = Math.abs(this.何何友何友何何友友何) * 0.2F;
            float targetSmoothFactor = baseSmoothFactor * (1.0F + Math.min(velocityFactor, 0.5F));
            this.何树友友何树友树何友 = this.何树友友何树友树何友 + (targetSmoothFactor - this.何树友友何树友树何友) * 0.3F;
            this.友树树何友树友友友树 = target;
            this.树树何友树友友树友何 = this.树树何友树友友树友何 + (targetSmoothFactor - this.树树何友树友友树友何) * 0.3F;
            this.树树友何何友何树树何 = target;
            float rotationAmount = diff * this.何树友友何树友树何友;
            rotationAmount = Mth.clamp(rotationAmount, -20.0F, 20.0F);
            return current + rotationAmount;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 6;
               case 1 -> 59;
               case 2 -> 15;
               case 3 -> 32;
               case 4 -> 30;
               case 5 -> 5;
               case 6 -> 24;
               case 7 -> 37;
               case 8 -> 21;
               case 9 -> 8;
               case 10 -> 47;
               case 11 -> 19;
               case 12 -> 20;
               case 13 -> 7;
               case 14 -> 1;
               case 15 -> 10;
               case 16 -> 60;
               case 17 -> 35;
               case 18 -> 63;
               case 19 -> 57;
               case 20 -> 61;
               case 21 -> 18;
               case 22 -> 25;
               case 23 -> 45;
               case 24 -> 2;
               case 25 -> 27;
               case 26 -> 12;
               case 27 -> 58;
               case 28 -> 22;
               case 29 -> 0;
               case 30 -> 56;
               case 31 -> 54;
               case 32 -> 11;
               case 33 -> 55;
               case 34 -> 23;
               case 35 -> 17;
               case 36 -> 28;
               case 37 -> 39;
               case 38 -> 41;
               case 39 -> 26;
               case 40 -> 50;
               case 41 -> 34;
               case 42 -> 46;
               case 43 -> 36;
               case 44 -> 52;
               case 45 -> 62;
               case 46 -> 43;
               case 47 -> 16;
               case 48 -> 4;
               case 49 -> 44;
               case 50 -> 31;
               case 51 -> 14;
               case 52 -> 51;
               case 53 -> 49;
               case 54 -> 3;
               case 55 -> 9;
               case 56 -> 48;
               case 57 -> 33;
               case 58 -> 42;
               case 59 -> 40;
               case 60 -> 29;
               case 61 -> 13;
               case 62 -> 38;
               default -> 53;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友树树树何友树树友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 15929;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友树树树何友树树友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u0013\\_§^Ç¸Áfg¬\\Rê\u0095f, ¨,=E\u008câSËu\u008a+¬ÒF_£, \u0098¼\u0091ö(7]\u001aæ»5ö·\u0081÷×, \\¤O©0\tðu U,¥\u009e0\u0007O\u009f½Ük}\u008aa\u0019, V*]°Âç²È®N\u008dûØµ]\u0000, \u001elß\u0006\u001d¯^:ÎkhðÒUÁÒ, `\u0014?*!\u0014\u0099ª, c/Û\u0091\u009dK°OQ\u009aj°ÐP Ôu3\u001d\u0096îÉ ß, %\u0098¬»óÊ¥&|ã©ôÁ/\u0003u, \u0082ZG\u009dK_¿ZG\u0010çDõ)Øª, \u008c3¬Ò\u0002\u007fK\u0092¶ ½¢{»æ\u008c, KKÝ\u0085RÁù/, \u009dXZ¶j\u00ad·\u0093, Ú®»E)Yw=Iö\u009c\u0094½tr\u0006, ØSx[\u0086'\u009d06\u007f&\u0003v2U3, @\u008dQ0>àõz\u0096\u0085\u001c\u001ec¢ñ\b, Ñ¤")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private void s() {
      KillAura.x();
      if (!this.何树树树友何何何树何.getValue() || !this.q()) {
         if (!this.何何何友友友树何树何.getValue() || mc.options.keyAttack.isDown()) {
            this.y();
            if (this.友友友树友友何友何树.isEmpty()) {
               return;
            }

            Player target = null;

            for (LivingEntity entity : this.友友友树友友何友何树) {
               if (entity instanceof Player player) {
                  target = player;
                  break;
               }
            }

            Vec2 currentLookAngles = new Vec2(mc.player.getYRot(), mc.player.getXRot());
            Vec3 ePos = target.position();
            Vec3 eHeadPos = ePos.add(new Vec3(0.0, target.getEyeHeight(), 0.0));
            Vec2 anglesFoot = this.s(ePos);
            Vec2 anglesHead = this.s(eHeadPos);
            Vec2 difference = this.h(currentLookAngles.negated().add(anglesHead));
            Vec2 differenceFoot = this.h(currentLookAngles.negated().add(anglesFoot));
            float targetYaw = (float)(currentLookAngles.x + difference.x / this.树树树友友友友何何何.getValue().doubleValue());
            if (currentLookAngles.y > anglesFoot.y || currentLookAngles.y < anglesHead.y) {
               float targetPitchFoot = (float)(currentLookAngles.y + differenceFoot.y / this.树树树友友友友何何何.getValue().doubleValue());
               float targetPitchHead = (float)(currentLookAngles.y + difference.y / this.树树树友友友友何何何.getValue().doubleValue());
               float diffFoot = Math.abs(currentLookAngles.y - targetPitchFoot);
               float diffHead = Math.abs(currentLookAngles.y - targetPitchHead);
               float targetPitch = diffFoot > diffHead ? targetPitchHead : targetPitchFoot;
               if (!this.树何树友友友何何友友.getValue()) {
                  mc.player.setXRot(targetPitch);
               }

               mc.player.setYRot(targetYaw);
            }

            if (!this.树何树友友友何何友友.getValue()) {
               mc.player.setXRot(currentLookAngles.y);
            }

            mc.player.setYRot(targetYaw);
         }
      }
   }

   private Vec2 s(Vec3 position) {
      Vec3 playerPos = new Vec3(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ());
      Vec3 diff = position.subtract(playerPos);
      double horizontalDistance = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
      float yaw = (float)Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(diff.y, horizontalDistance)));
      return new Vec2(Mth.wrapDegrees(yaw), Mth.clamp(pitch, -90.0F, 90.0F));
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'V' && var8 != 219 && var8 != 239 && var8 != 236) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 202) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 196) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'V') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 219) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友树树树何友树树友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void c() {
      j[0] = "\u000f`6|]w\u0000 {wWj\u0005}p1_w\b{tz\u001cq\u0001~t1Qw\u0001lyk\u001c叓桽栟栉佊叹栉桽叅位";
      j[1] = "'c(+yV(#e sK-~nf`X(xcf\u007fT4a(\u0005y]![g$c\\";
      j[2] = "Vx(\u0010\r\u0006Vx?L\u0001\tL3+Q\u0012\u0003\\3,V\u0019\u001c\u0016K9]R";
      j[3] = float.class;
      k[3] = "java/lang/Float";
      j[4] = "q=\u0019=Oy~}T6Ed{ _pMyv&[;\u000e\u007f\u007f#[pCy\u007f1V*\u000e]{?[\u001fUds";
      j[5] = "9\u001bx\u0015\u000fM\r8wUBF\u0007%r\bI\u0000\u000f8\u007f\u000eMKL\u001at\u001fTB\u0007l";
      j[6] = "92r\u000fs\u001f2=c@\u000f\u0006='m\u000386+0a\u001e)\u001a<=";
      j[7] = "f\u0001s03\u000bf\u0001dl?\u0004|Jpq,\u000elJwv'\u0011&,nj\f\u0007{\u0011kjz6q\u0014b";
      j[8] = "X+9#\"IX+.\u007f.FB`.a&EX:cB?T_!#~";
      j[9] = "4u1}qn4u&!}a.>&?ub4dk\u0018y~\u0017q5#ui=";
      j[10] = "~DZ+@v~DMwLyd\u000fMj_z>cBjNt@N]";
      j[11] = "6n\u000e>vI6n\u0019bzF,%\u0019|rE6\u007fT]rN=h\bq}T";
      j[12] = "\u000e/\u0007a>\u0019\u000e/\u0010=2\u0016\u0014d\u0004 !\u001c\u0004d\u0003'*\u0003N\u0002\u001a;\u0001\u0015\u0013?\u001f;";
      j[13] = int.class;
      k[13] = "java/lang/Integer";
      j[14] = "k\u001a6\u000eDLu\u0012,A&Pr\u000f";
      j[15] = "Sk\u0013&?/\\+^-52YvUk&!\\pXk9-@i\u0013\u000b%-R`O\u00131,E`";
      j[16] = "F6~\u0013\u0012rIv3\u0018\u0018oL+8^\u000b|I-5^\u0014pU4~2\u0012rI=1\u001e+|I-5";
      j[17] = "y_m94\u0011v\u001f 2>\fsB+t.\ns]0t伎厵发佤桒伏桊伫栋叺";
      j[18] = double.class;
      k[18] = "java/lang/Double";
      j[19] = "~*\u001f62x~*\bj>wda\u001cw-}ta\u000ev+xd6ET6gy!\f]1ey;\u0012";
      j[20] = ";,9\u001cg\u000b;,.@k\u0004!g:]x\u000e1g=Zs\u0011{\u001f(Q9";
      j[21] = "aU\u000e{K\u0016Uv\u0001;\u0006\u001d_k\u0004f\r[Wv\t`\t\u0010\u0014T\u0002q\u0010\u0019_\"";
      j[22] = void.class;
      k[22] = "java/lang/Void";
      j[23] = "J9Fa<4Ey\u000bj6)@$\u0000,>4M\"\u0004g}桊佼厜厣佗桂厐叢伂伽";
      j[24] = "79{>p\u00078y65z\u001a=$=sr\u00070\"981%;3 1z";
      j[25] = "(qeDRi\u001cRj\u0004\u001fb\u0016OoY\u0014$\u001eRb_\u0010o]piN\tf\u0016\u0006";
      j[26] = boolean.class;
      k[26] = "java/lang/Boolean";
      j[27] = "hj/\u0017\u00125g*b\u001c\u0018(bwiZ\b.bhrZ\u0015?gtd\u0006S\bdp`\u0000\u00145e";
      j[28] = "hKWI>1hK@\u00152>r\u0000@\u000b:=hZ\r*<-uKk\u0006=<jKQ";
      j[29] = "\fKDG-.\u0007DU\bL \fOQR";
      j[30] = "8>\u0016\u0007Huz\u007f\u001b_)t\u0003nI\rBchqF\u001f\u0015\u001ami\u001a\u001c\u0012q9mW\t)";
      j[31] = "\u0005HJjs\f\u0014D\u001c\r叙桥桲栾桪佐佇县伶古sd|@\u0014K\u001e6p\u0003R";
      j[32] = "Pa +3\nAmvL厙档栧体叚桕厙厹叽栗\u0019v9\u0010^g(}0\u0018\u0006";
      j[33] = "}*\u001d\u0007A\u000el&K`栱厽叐历叧厣栱伣栊优$\nG\u0017y>[\\\u0019\u001fj";
      j[34] = "\u0014=@QL\u001f\u00051\u00166佸厬档桋厺栯格伲厹桋y\\J\u0006\u0010)\u0006\n\u0014\u000e\u0003";
      j[35] = "S:\tnFXB6_\t佲栱叾桌右栐召栱栤伈0cRC['Ru\u0015\u0015Q";
      j[36] = "=s\u00189\u001f\u0017mr\r5p\u0001\u0006{LaAU\u0006B\u0016 \r\u0015;x\u001a2K\u000e";
      j[37] = "MmZ<9\u0010\\a\f[伍厣佾叁桺伆伍厣栺栛c26\\\\n\u000e`:\u001f\u001a";
      j[38] = "\u001aC3U;w\u000bOe2桋佚桭可叉叱伏佚厷可\nX=n\u001eWu\u000ecf\r";
      j[39] = "kH4\u00017G{\u0011)G\f%\u0004N,Ug\u000eoQ#G0w";
      j[40] = "aRKp0~p^\u001d\u0017厚栗双你厱佊厚反栖栤r|'suWHp55n";
      j[41] = "3!gS5fqd9\u0015\u000ehZ+cR?8Z\u001ag\u0012q:gq$\u00006f";
      j[42] = "\u0003`A\u0003\bO\u0012l\u0017d桸栦估双桡桽似栦厮佒x^\u0002U\rfIU\u000b]U";
      j[43] = "?r\n\u0015m\u0017.~\\r栝厤伌栄台伯叇桾伌叞3Mh\u001c<q\\\u0010:\u0017`";
      j[44] = ";_K'zf*S\u001d@叐佋桌佭桫桙栊叕伈佭r)u**\\\u001f{yil";
      j[45] = "?`H+Y\u001f.l\u001eL栩桶厒佒伬厏佭桶案佒qvS\u00051f@}Z\ri";
      j[46] = "C\tOh\u0015\\L\u000f\u001dav佧佱伹佻佄桯佧佱厧栿\u0019\u0019WE\u0015E\u007f\u0016Q\u0017\u001c";
      j[47] = "\u001dP\u000ezS\"\f\\X\u001d佧伏伮叼叴叞栣伏桪佢7wU;\u0019DH!\u000b3\n";
      j[48] = "\u0017kp{`\u0016\u0006g&\u001c及桿伤余桐佁栐伻伤余I~e\u0000\u0013`+}{\\\u001f";
      j[49] = "\u0015'?bWD\u0004+i\u0005佣佩桢压栟栜佣号厸桑\u0006oQ]\u00113y9\u000fU\u0002";
      j[50] = "AQ!KlyP]w,佘栐召栧佅栵栜栐召栧\u0018\u001deq\u0017\u000e$\u0011df\u0017";
      j[51] = ",JV\u0019t==F\u0000~tM~LU\u0001c|([\t\u0003\u001dq+\u001f\u0010\u0000,'<C\u0012~";
      j[52] = "$N\u001b=?\u007ft\u000f\u001c8^cCN[y`2C\u007f\u0000? t+@\u00199=g";
      j[53] = "B<\u001fw\u0015K\u0012}\u0018rtW%<_3J\u0007%\rX0J\u0000Im\u001au\u0014F";
      j[54] = "pc\u000bQXNao]6佬栧叝叏佯栯史栧佃叏2\fRT~e\u0003\u0007[\\&";
      j[55] = "e+&vx\u0002\"il2\u0012\u0013\u000bg$3-D\u000bW$lx\u001d5f/epE";
      j[56] = "\u0011O\u0012\u0018*\u001f\u0000CD\u007f厀桶伢佽叨厼厀伲厼根+\u0014=\u0012\u0005J\u0011\u0018/T\u001e";
      j[57] = "F)@'w]W%\u0016@标佰叫厅桠桙叝栴栱伛y)x\u0011W*\u0014{tR\u0011";
      j[58] = "\u0000\u0002Q*]\u000f\u0011\u000e\u0007M栭桦伳估伵桔号桦伳桴h,\u0004F^\u001c\u0016?^\u0010\u0017";
      j[59] = "Q18\u0019\u0018 @=n~伬桉叼桇作桧桨伍佢桇\u0001\u0017\u0017l@2lE\u001b/\u0006";
      j[60] = ">n\u001f\u0018W./bI\u007f叽伃厓作佻厼佣伃桉参&\u0016Xb/mKDT!i";
      j[61] = "o\u00139\u000fh8~\u001foh参压参桥參厫作压作桥\u0000\u0001j3q\u001a{\u0004n,e";
      j[62] = "-uz\u0017=/<y,p桍框桚叙厀厳厗伂伞佇C\u00192c<v.K> z";
      j[63] = "\u007f\n*m1<n\u0006|\n桁厏栈桼栊佗伅桕叒伸\u0013`7%{\u001el6i-h";
      j[64] = "F\u0012N7\u0011fW\u001e\u0018P伥佋併厾桮伍伥叕併厾w9\u001e*W\u0011\u001ak\u0012i\u0011";
      j[65] = "MA2S\"\u0011\\Md4厈桸佾样又号伖似叠样\u000b]-]\\Bf\u000f!\u001e\u001a";
      j[66] = "e,V,pdt \u0000K佄佉又伞厬伖佄受又伞oqz~k*^zsv3";
      j[67] = "p;r[8;a7$<厒厈叝桍桒栥厒桒叝厗KU7wa8&\u0007;4'";
      j[68] = "\u0006\u0005y.8V\u0017\t/I伌佻厫桳桙桐案句桱伷@ 7\u001a\u0017\u0006-r;YQ";
      j[69] = "<TchXV-X5\u000f史句伏栢桃佒佬栿厑佦ZfW\u001a-W74[Yk";
      j[70] = "BVm\u0014W0SZ;s佣桙栵栠厗伮佣伝栵佤T\u0019Q)FB+O\u000f!U";
      j[71] = "\u0003\u001ak~\u0000O\u0016Ke$p\u001b9F8%@M9vig\r\u000f\u0004LeuK\u0014";
      j[72] = "pn\u007fPk\u0005ab)7栛桬佃参桟叴叁桬叝作F\ra\u001f~hw\u0006h\u0017&";
      j[73] = "iLFx'\n,FBp\u001e*\u0010bq\u0003\u001e]=Y\u0002yt\u00187]\n";
      j[74] = "\u0019\u001d\u000e`?\\\b\u0011X\u0007伋栵厴桫栮栞桏佱厴伯7n0\u0010\b\u001eZ<<SN";
      j[75] = "\u001bk/\u0018\u0006u\ngy\u007f桶佘厶余栏厼桶叆厶栝\u0016\u0015\u0000l\u001f\u007fiC^d\f";
      j[76] = ">ix\u001c\f\u000e/e.{伸伣厓叅厂伦伸桧伍佛A\u0001\u001f\u0010n?|DU\u0015";
      j[77] = "\u001cPpg<G\r\\&\u0000伈栮桫佢伔參桌叴桫叼Ij:^\u0018D6<dV\u000b";
      j[78] = "Px\u001a\u0010&TE)\u0014JV\u0000j$IKi_j\u0014\u0018\t+\u0014W.\u0014\u001bm\u000f";
      j[79] = "k\u0005mf,\")D`>M=PU2l&4;J=~qM";
      j[80] = "_\u000bkdf:JZe>\u0016neW8?&9egi}kzX]eo-a";
      j[81] = "-\u000ekcXHjL!'2YCBi&\r\u000fCriyXW}CbpP\u000f";
      j[82] = "7\r\u0001\u0005_\u0010gL\u0006\u0000>\fP\rAA\u0001]P<IA\u0006Sb[\u0014\u001dY\u000b";
      j[83] = "M\bCeI>\u001d\tVi&(v\u0000\u0017=\u0017yv9\u0017b^~\u0011\u0005\u001bcI~";
      j[84] = "\u0004\u001f\u0006Q\u0011TT\u001e\u0013]~B?\u0017R\tO\u0014?.\bH\u0003V\u0002\u0014\u0004ZEM";
      j[85] = "8<\t\tAH)0_n栱校伋厐右伳栱叻厕厐0\fD^<7R\u000fZ\u00020";
      j[86] = "\u0004\u000bgC3{\u0015\u00071$厙佖厩厧厝佹厙佖伷桽^^ eT]c\u001bj`";
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @EventTarget
   public void c(Render2DEvent event) {
      KillAura.x();
      if (this.何何友友友何何树何何.K("CSGO")) {
         this.P();
      }

      if (this.何何友友友何何树何何.K("New")) {
         this.s();
      }
   }

   private Vec2 h(Vec2 vec) {
      return new Vec2(Mth.wrapDegrees(vec.x), Mth.wrapDegrees(vec.y));
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private Rotation l(LivingEntity entity, double heightOffset) {
      KillAura.x();
      if (this.Q(new Object[]{52406761729175L})) {
         return null;
      } else {
         float currentYaw = mc.player.getYRot();
         float currentPitch = mc.player.getXRot();
         double entityX = entity.getX();
         double entityY = entity.getY();
         double entityZ = entity.getZ();
         double posX = entityX - mc.player.getX();
         double posY = entityY + entity.getBbHeight() * heightOffset - (mc.player.getY() + mc.player.getEyeHeight());
         double posZ = entityZ - mc.player.getZ();
         double dX = entityX - entity.xOld;
         double dZ = entityZ - entity.zOld;
         double dX2 = dX - this.友树何何友友友何友树;
         double dZ2 = dZ - this.友树友何友何友友树树;
         this.友树何何友友友何友树 = dX;
         this.友树友何友何友友树树 = dZ;
         double targetYawCalc = Math.toDegrees(Math.atan2(posZ, posX)) - 90.0;
         double yawDiffToTarget = Math.abs(Mth.wrapDegrees((float)(currentYaw - targetYawCalc)));
         double aimStrength = Math.max(0.1, Math.min(0.8, yawDiffToTarget / 45.0));
         if (yawDiffToTarget > this.树何友友树树友树树何.getValue().doubleValue() && yawDiffToTarget < 120.0) {
            double dist = Math.sqrt(posX * posX + posZ * posZ);
            double predictionTime = Math.min(dist / 25.0, 0.3);
            posX += dX * aimStrength * predictionTime * 3.0;
            posZ += dZ * aimStrength * predictionTime * 3.0;
            posX += dX2 * aimStrength * predictionTime * predictionTime * 1.5;
            posZ += dZ2 * aimStrength * predictionTime * predictionTime * 1.5;
         }

         double horizontalDistance = Math.sqrt(posX * posX + posZ * posZ);
         float yaw = (float)(Math.toDegrees(Math.atan2(posZ, posX)) - 90.0);
         float pitch = (float)(-Math.toDegrees(Math.atan2(posY, horizontalDistance)));
         yaw = Mth.wrapDegrees(yaw);
         pitch = Mth.clamp(pitch, -90.0F, 90.0F);
         float yawDiffSmooth = Mth.wrapDegrees(yaw - currentYaw);
         float pitchDiffSmooth = pitch - currentPitch;
         float smoothF = (float)(0.3F + aimStrength * 0.2F);
         yaw = currentYaw + yawDiffSmooth * smoothF;
         pitch = currentPitch + pitchDiffSmooth * smoothF;
         return new Rotation(21273681362686L, yaw, pitch);
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private double d(Entity entity) {
      if (this.Q(new Object[]{52406761729175L})) {
         return 0.0;
      } else {
         Rotation targetRot = RotationUtils.k(entity, 90907436658038L);
         float entityYaw = targetRot.getYaw();
         float entityPitch = targetRot.l(5377274095808L);
         float playerYaw = mc.player.getYRot();
         float playerPitch = mc.player.getXRot();
         float deltaYaw = 友友友树何友树友树友.N(0, 572919893, 49115, entityYaw - playerYaw);
         float deltaPitch = 友友友树何友树友树友.N(0, 572919893, 49115, entityPitch - playerPitch);
         return Math.abs(deltaYaw) + Math.abs(deltaPitch);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean q() {
      KillAura.x();
      if (!mc.options.keyAttack.isDown()) {
         this.E();
         return false;
      } else if (mc.hitResult != null && mc.hitResult.getType() == Type.BLOCK) {
         BlockHitResult blockHit = (BlockHitResult)mc.hitResult;
         BlockPos currentBlockPos = blockHit.getBlockPos();
         if (树何树树何何树友何何.F(currentBlockPos, 65332937941542L)) {
            this.E();
            return false;
         } else {
            if (this.树友何树友何友树何友 == null || !this.树友何树友何友树何友.equals(currentBlockPos)) {
               this.树友何树友何友树何友 = currentBlockPos;
               this.何树友树何树树树友树 = 0;
            }

            this.何树友树何树树树友树++;
            return this.何树友树何树树树友树 >= 1;
         }
      } else {
         this.E();
         return false;
      }
   }

   private boolean q(LivingEntity entity) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})
         && 何树何树友树树友友何.p(31768596091278L, entity, true)
         && !entity.isDeadOrDying()
         && !(entity.getHealth() <= 0.0F)
         && RotationUtils.A(51024501214516L, this.何树友树何树树何何树.getValue().floatValue(), entity)) {
         boolean hasLineOfSight = mc.player.hasLineOfSight(entity);
         if (hasLineOfSight) {
            this.友树何树友友何何友树.getValue().floatValue();
         }

         if (this.树友树树树何何树友何.getValue()) {
            this.友友友树树树友树友友.getValue().floatValue();
         }

         return false;
      } else {
         return false;
      }
   }

   private Comparator<LivingEntity> w() {
      KillAura.x();
      String var6 = this.友何友友友何友何何树.getValue();
      byte var7 = -1;
      switch (var6.hashCode()) {
         case 353103893:
            if (!var6.equals("Distance")) {
               break;
            }

            var7 = 0;
         case -2137395588:
            if (!var6.equals("Health")) {
               break;
            }

            var7 = 1;
         case 70829:
            if (!var6.equals("Fov")) {
               break;
            }

            var7 = 2;
         case 1041377119:
            if (!var6.equals("Direction")) {
               break;
            }

            var7 = 3;
         case -1415550666:
            if (!var6.equals("LivingTime")) {
               break;
            }

            var7 = 4;
         case 63533343:
            if (!var6.equals("Armor")) {
               break;
            }

            var7 = 5;
         case 1179233083:
            if (!var6.equals("EasyToKill")) {
               break;
            }

            var7 = 6;
         case -255982230:
            if (var6.equals("ThreatLevel")) {
               var7 = 7;
            }
      }
      return switch (var7) {
         case 0 -> Comparator.comparingDouble(e -> RotationUtils.i(e, 55874601829708L));
         case 1 -> Comparator.comparingDouble(LivingEntity::getHealth);
         case 2 -> Comparator.comparingDouble(this::d);
         case 3 -> Comparator.comparingDouble(RotationUtils::q);
         case 4 -> (a, b) -> Integer.compare(b.tickCount, a.tickCount);
         case 5 -> (a, b) -> Integer.compare(友树友友树何树友树友.g(50820545736658L, b), 友树友友树何树友树友.g(50820545736658L, a));
         case 6 -> (a, b) -> {
            double scoreA = a.getHealth() / (友树友友树何树友树友.g(50820545736658L, a) + 1);
            double scoreB = b.getHealth() / (友树友友树何树友树友.g(50820545736658L, b) + 1);
            return Double.compare(scoreA, scoreB);
         };
         case 7 -> {
            double playerAttack = 友何树树何树何何何友.N(20090517461351L, mc.player.getMainHandItem());
            yield (a, b) -> {
               double threatScoreA = (a.getHealth() + 友树友友树何树友树友.g(50820545736658L, a)) / playerAttack;
               double threatScoreB = (b.getHealth() + 友树友友树何树友树友.g(50820545736658L, b)) / playerAttack;
               return Double.compare(threatScoreA, threatScoreB);
            };
         }
         default -> Comparator.comparingDouble(e -> RotationUtils.i(e, 55874601829708L));
      };
   }

   @EventTarget
   public void r(Render3DEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.何何友友友何何树何何.K("Old")) {
            if (!this.何树树树友何何何树何.getValue() || !this.q()) {
               if (mc.options.keyAttack.isDown()) {
                  this.何树友树友树友树树何.D(11747522392279L);
               }

               if (!this.何何何友友友树何树何.getValue() || !this.何树友树友树友树树何.A(this.友何树何树树树友何何.getValue().longValue(), 118344821288830L)) {
                  this.y();
                  if (!this.友友友树友友何友何树.isEmpty()) {
                     LivingEntity target = this.友友友树友友何友何树.get(0);
                     Rotation headRotation = this.树何友何树友树友友树.getValue() ? this.l(target, this.何何何友树何何友何友.getValue().doubleValue()) : null;
                     Rotation bodyRotation = this.何友树树友树树何友树.getValue() ? this.l(target, this.何树友树树树树何友何.getValue().doubleValue()) : null;
                     Rotation feetRotation = this.何何树友树树何友友树.getValue() ? this.l(target, this.何何友树树树树友树何.getValue().doubleValue()) : null;
                     double distHead = Math.abs(mc.player.getXRot() - headRotation.l(5377274095808L));
                     double distBody = Math.abs(mc.player.getXRot() - bodyRotation.l(5377274095808L));
                     double distFeet = Math.abs(mc.player.getXRot() - feetRotation.l(5377274095808L));
                     if (this.树何友何树友树友友树.getValue() && headRotation != null && distHead <= distBody && distHead <= distFeet) {
                     }

                     if (this.何友树树友树树何友树.getValue() && bodyRotation != null && distBody <= distFeet) {
                     }

                     if (this.何何树友树树何友友树.getValue() && feetRotation != null) {
                     }

                     if (headRotation != null) {
                     }

                     if (bodyRotation != null) {
                     }

                     if (feetRotation != null) {
                     }

                     Rotation finalRotation = RotationUtils.W(target, 97069441325077L);
                     if (finalRotation != null) {
                        float yaw = finalRotation.getYaw();
                        float pitch = finalRotation.l(5377274095808L);
                        if (this.树友友友友友树何树何.getValue()) {
                           mc.player.setYRot(this.V(mc.player.getYRot(), yaw, this.何友何友树何何友树树.getValue().floatValue(), true));
                        }

                        if (this.何树树何何友树友树友.getValue()) {
                           mc.player.setXRot(this.V(mc.player.getXRot(), pitch, this.友何友何何友何何树友.getValue().floatValue(), false));
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void y() {
      this.友友友树友友何友何树.clear();
      KillAura.x();
      Iterator var6 = Cherish.instance.m().V(this.友树何树友友何何友树.getValue().floatValue() + 1.0F, 16843851536371L).iterator();
      if (var6.hasNext()) {
         LivingEntity entity = (LivingEntity)var6.next();
         if (this.q(entity)) {
            this.友友友树友友何友何树.add(entity);
         }
      }

      this.友友友树友友何友何树.sort(this.w());
   }

   private void E() {
      this.树友何树友何友树何友 = null;
      this.何树友树何树树树友树 = 0;
   }

   @Override
   protected void M() {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.友树树何友树友友友树 = mc.player.getYRot();
         this.树树友何何友何树树何 = mc.player.getXRot();
         this.友树何何友友友何友树 = 0.0;
         this.友树友何友何友友树树 = 0.0;
         this.何何友何友何何友友何 = 0.0F;
         this.树树何友树树何树友何 = 0.0F;
         this.何树友友何树友树何友 = 0.15F;
         this.树树何友树友友树友何 = 0.15F;
         this.E();
      }
   }

   private void P() {
      KillAura.x();
      if (!this.何树树树友何何何树何.getValue() || !this.q()) {
         boolean isLeftClicking = mc.mouseHandler.isLeftPressed();
         if (this.何何何友友友树何树何.getValue() && this.树树何何何树友树何树 && !isLeftClicking) {
            this.友树何何树何树何何何 = this.树树何友友何树友友友 = null;
         }

         this.树树何何何树友树何树 = isLeftClicking;
         boolean shouldAim = !this.何何何友友友树何树何.getValue() || isLeftClicking;
         if (shouldAim && !this.Q(new Object[]{52406761729175L}) && this.树树何友友何树友友友 != null && this.友树何何树何树何何何 != null) {
            float partialTicks = mc.getFrameTime();
            Rotation rotations = new Rotation(
               21273681362686L,
               this.友树何何树何树何何何.getYaw() + (this.树树何友友何树友友友.getYaw() - this.友树何何树何树何何何.getYaw()) * partialTicks,
               this.友树何何树何树何何何.l(5377274095808L) + (this.树树何友友何树友友友.l(5377274095808L) - this.友树何何树何树何何何.l(5377274095808L)) * partialTicks
            );
            float strength = 友友友树何友树友树友.x(1391347873739L, this.友友何树树何何树友何.getValue().intValue() * 30, this.友树树树树何何友何友.getValue().intValue() * 30);
            double sensitivity = (Double)mc.options.sensitivity().get() * 0.6F + 0.2F;
            double gcd = sensitivity * sensitivity * sensitivity * 8.0;
            float deltaYaw = (float)((rotations.getYaw() - mc.player.getYRot()) * (strength / 100.0F) * gcd);
            float deltaPitch = (float)((rotations.l(5377274095808L) - mc.player.getXRot()) * (strength / 100.0F) * gcd);
            mc.player.turn(deltaYaw, deltaPitch);
         }
      }
   }

   @EventTarget
   public void K(LivingUpdateEvent event) {
      KillAura.x();
      this.X(this.友何友友友何友何何树.getValue());
      if (!this.何树树树友何何何树何.getValue() || !this.q()) {
         if (this.何何友友友何何树何何.K("CSGO")) {
            this.y();
            LivingEntity target = null;
            if (!this.友友友树友友何友何树.isEmpty()) {
               target = this.友友友树友友何友何树.get(0);
            }

            this.友树何何树何树何何何 = this.树树何友友何树友友友 = null;
            this.友树何何树何树何何何 = this.树树何友友何树友友友;
            this.树树何友友何树友友友 = RotationUtils.k(target, 90907436658038L);
         }
      }
   }

   private static String HE_SHU_YOU() {
      return "何炜霖230622200409390090";
   }
}
