package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.value.impl.BooleanValue;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeableLeatherItem;
import net.minecraft.world.item.ItemStack;

public class 友友友何何树树树何树 extends Module implements 何树友 {
   public static 友友友何何树树树何树 何树树树何何树友何树;
   private final BooleanValue 树友友树友何树友树树;
   private final BooleanValue 何何友树友树何何友友;
   private final BooleanValue 友友友何树友树友友何;
   private static final int 友何友何树树友树友友;
   private static final int 何何友何树何树友友友;
   private static final int 友友树友树友树何树友;
   private static final int 何友树何友树树树树树;
   private static final int 何树何友树何树友友树;
   private static final int 树友何树友树树友何何;
   private static final int 树树何树何树友何树树;
   private static final int 树树何友何何何何何友;
   private static int 树友何何何何树树何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[19];
   private static final String[] n = new String[19];
   private static int _行走的50万——何炜霖 _;

   public 友友友何何树树树何树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/misc/友友友何何树树树何树.a J
      // 03: ldc2_w 36011897116202
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 19535
      // 0c: ldc2_w 7364277467825978236
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 5255
      // 19: ldc2_w 1168587218713764790
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w -6061779320098662248
      // 26: lload 1
      // 27: invokedynamic Í (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/BooleanValue
      // 33: dup
      // 34: sipush 9120
      // 37: ldc2_w 3413162910288467088
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 16101
      // 44: ldc2_w 5820665377919683025
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: bipush 1
      // 4f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 52: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 55: putfield cn/cool/cherish/module/impl/misc/友友友何何树树树何树.树友友树友何树友树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 58: aload 0
      // 59: new cn/cool/cherish/value/impl/BooleanValue
      // 5c: dup
      // 5d: sipush 26998
      // 60: ldc2_w 2296910372097433164
      // 63: lload 1
      // 64: lxor
      // 65: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6a: sipush 19162
      // 6d: ldc2_w 7951983004231777763
      // 70: lload 1
      // 71: lxor
      // 72: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 77: bipush 1
      // 78: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 7b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 7e: putfield cn/cool/cherish/module/impl/misc/友友友何何树树树何树.何何友树友树何何友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 81: aload 0
      // 82: new cn/cool/cherish/value/impl/BooleanValue
      // 85: dup
      // 86: sipush 7456
      // 89: ldc2_w 7457492195279333912
      // 8c: lload 1
      // 8d: lxor
      // 8e: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 93: sipush 27933
      // 96: ldc2_w 883515815866997288
      // 99: lload 1
      // 9a: lxor
      // 9b: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // a0: bipush 0
      // a1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // a4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // a7: putfield cn/cool/cherish/module/impl/misc/友友友何何树树树何树.友友友何树友树友友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // aa: aload 0
      // ab: ldc2_w -6061321108034370946
      // ae: lload 1
      // af: invokedynamic Ì (Lcn/cool/cherish/module/impl/misc/友友友何何树树树何树;JJ)V bsm=cn/cool/cherish/module/impl/misc/友友友何何树树树何树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // b4: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-1966167637765362976L, 4331023846234714718L, MethodHandles.lookup().lookupClass()).a(41805703249589L);
      // $VF: monitorexit
      a = var10000;
      long var20 = a ^ 50864714279099L;
      a();
      d<"B">(0, -7678146555529953613L, var20);
      Cipher var11;
      Cipher var25 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(var20 << var12 * 8 >>> 56);
      }

      var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[11];
      int var16 = 0;
      String var15 = "\u0016\u008dú7Ç\u008bà\u0095~ð/ÉN\u0007Õ.Å:ãÍm·\u0098w\u0010\u0012\u001c£ê\u0099d\u0018§uÙMî0oÊ\u0084\u0010\u007fñu\u0000^*ya\u0001\u008a\u0080çÍ\u0097\u008a*\u0010\u0000¤¹_ó\nñó¿W\u0007\u009bÒË¬r\u0018\u0093D\u009dDt{R²ä\u008fÙ_\u009aF°!ß\u0080\u0007rÞ6j# ¯±«ÂûÉ¬ÍïH\u0007â\u0005\u0081\u009eÑøê\u0081!õÔruy\u009enß0\u0014Þ&\u0010.:¥ô«²»Ý¥ y²ã?\u0097\u0091\u0010Ö\u009fF\u0099&\u008aJ+øµt£\u0097äâ \u0018\u0018~\u001a®¿\u001f\u000eN\u009c.¬\nE7S!\u0082°[Cä\u0095GÌ";
      short var17 = 192;
      char var14 = 24;
      int var24 = -1;

      label54:
      while (true) {
         String var26 = var15.substring(++var24, var24 + var14);
         int var10001 = -1;

         while (true) {
            String var37 = c(var11.doFinal(var26.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var37;
                  if ((var24 += var14) >= var17) {
                     c = var18;
                     h = new String[11];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var28 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var20 << var1 * 8 >>> 56);
                     }

                     var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[22];
                     int var3 = 0;
                     String var4 = "Êp]û[m\u0099=\u0001ò&Ab\u0094\u000eþ/ã½\u000e\u009d\u0083\u0089yt©\\D\u001aMý\u001c¨\u0088¦åé~4\u001b\u009em2\u001d\u000fvj\u0094z§\u0005\t¶ê\u0096\u0095¢N;x\u008f\u0090zqïðNÀ~G3r]Nçô \u008b\u0006Ý7\u000fª'pòlDn\u00952£9\b#\u0088>X>ñ\u008bØ\n£\u009bôMÈÓK_,ª$\u000fÇîì\u0000IÙ.&1¡öô8fðM\b ³^ðGÞ\u0086]\u0001²å|7 OÐI6¯*<ÛKKÍ MÖ";
                     short var5 = 160;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var29 = var6;
                        var10001 = var3++;
                        long var41 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var44 = -1;

                        while (true) {
                           long var8 = var41;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var46 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var44) {
                              case 0:
                                 var29[var10001] = var46;
                                 if (var2 >= var5) {
                                    j = var6;
                                    k = new Integer[22];
                                    树树何树何树友何树树 = c<"l">(28174, var20 ^ 266430689224137417L);
                                    何树何友树何树友友树 = c<"l">(32678, var20 ^ 6457056234874178407L);
                                    何何友何树何树友友友 = c<"l">(22488, var20 ^ 4540790584264106778L);
                                    友何友何树树友树友友 = c<"l">(10156, var20 ^ 3272934187555771236L);
                                    友友树友树友树何树友 = c<"l">(1591, var20 ^ 3865463237766378236L);
                                    树树何友何何何何何友 = c<"l">(14384, var20 ^ 6834863650989067507L);
                                    树友何树友树树友何何 = c<"l">(21365, var20 ^ 9134562179209603004L);
                                    何友树何友树树树树树 = c<"l">(28541, var20 ^ 6112983060448910265L);
                                    return;
                                 }
                                 break;
                              default:
                                 var29[var10001] = var46;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "N_ñ\u0000\u0005Èz\u00ad\u0096ÖÍhEÔ¡µ";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var35 = var2;
                           var2 += 8;
                           var7 = var4.substring(var35, var2).getBytes("ISO-8859-1");
                           var29 = var6;
                           var10001 = var3++;
                           var41 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var44 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var24);
                  break;
               default:
                  var18[var16++] = var37;
                  if ((var24 += var14) < var17) {
                     var14 = var15.charAt(var24);
                     continue label54;
                  }

                  var15 = "®ÑÏYh«ÆË/\u0094ñß²U\u0015£±\u0010µ'â\u008d6X\nÆ\u0011Ö\r\u001bôy\u0010\u0011·¥Ð\u0086\u0092E\u001d±=\u0017ºù\u0014\u0089á";
                  var17 = 49;
                  var14 = ' ';
                  var24 = -1;
            }

            var26 = var15.substring(++var24, var24 + var14);
            var10001 = 0;
         }
      }
   }

   private int J(int color) {
      long a = 友友友何何树树树何树.a ^ 60805804471683L;
      d<"B">(5208573595221097271L, a);
      if (color == c<"l">(16811, 6905652042789120086L ^ a)) {
         return c<"l">(32007, 1279731292094059755L ^ a);
      } else if (color == c<"l">(3219, 7205499014590768504L ^ a)) {
         return c<"l">(30601, 4570465828660567678L ^ a);
      } else if (color == c<"l">(13032, 7706547083089255194L ^ a)) {
         return c<"l">(15767, 3555036837738648696L ^ a);
      } else if (color == 170) {
         return 170;
      } else if (color == c<"l">(26300, 109677656691396438L ^ a)) {
         return c<"l">(29225, 3010344454704290780L ^ a);
      } else if (color == c<"l">(12469, 8927251427124189517L ^ a)) {
         return c<"l">(27151, 5633660336648537058L ^ a);
      } else if (color == c<"l">(29853, 8907152291861028195L ^ a)) {
         return c<"l">(10611, 4457088455953973405L ^ a);
      } else {
         return color == c<"l">(30824, 8358190533763387806L ^ a) ? c<"l">(6845, 8822416847784063817L ^ a) : -1;
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 30;
               case 2 -> 58;
               case 3 -> 34;
               case 4 -> 22;
               case 5 -> 16;
               case 6 -> 7;
               case 7 -> 12;
               case 8 -> 17;
               case 9 -> 35;
               case 10 -> 53;
               case 11 -> 37;
               case 12 -> 14;
               case 13 -> 44;
               case 14 -> 48;
               case 15 -> 5;
               case 16 -> 29;
               case 17 -> 40;
               case 18 -> 33;
               case 19 -> 49;
               case 20 -> 8;
               case 21 -> 63;
               case 22 -> 27;
               case 23 -> 1;
               case 24 -> 55;
               case 25 -> 62;
               case 26 -> 25;
               case 27 -> 31;
               case 28 -> 60;
               case 29 -> 18;
               case 30 -> 52;
               case 31 -> 19;
               case 32 -> 38;
               case 33 -> 6;
               case 34 -> 10;
               case 35 -> 0;
               case 36 -> 39;
               case 37 -> 51;
               case 38 -> 3;
               case 39 -> 2;
               case 40 -> 28;
               case 41 -> 15;
               case 42 -> 24;
               case 43 -> 42;
               case 44 -> 59;
               case 45 -> 13;
               case 46 -> 23;
               case 47 -> 56;
               case 48 -> 45;
               case 49 -> 32;
               case 50 -> 46;
               case 51 -> 11;
               case 52 -> 26;
               case 53 -> 41;
               case 54 -> 21;
               case 55 -> 47;
               case 56 -> 43;
               case 57 -> 9;
               case 58 -> 61;
               case 59 -> 54;
               case 60 -> 20;
               case 61 -> 36;
               case 62 -> 4;
               default -> 57;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友友友何何树树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23763;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/友友友何何树树树何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友友友何何树树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25013;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/友友友何何树树树何树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 211 && var8 != 219 && var8 != 205 && var8 != 204) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'H') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'B') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 211) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 219) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 205) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public int n(Player player) {
      long a = 友友友何何树树树何树.a ^ 26535782569860L;
      d<"B">(-6174508234261063376L, a);
      if (player == null) {
         return -1;
      } else {
         ItemStack helmet = (ItemStack)d<"Ó">(player.getInventory(), -6174762941142580960L, a).get(3);
         return helmet.isEmpty() ? -1 : this.k(helmet);
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友友友何何树树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "\u0005+U@]:\nk\u0018KW'\u000f6\u0013\r_:\u00020\u0017F\u001c<\u000b5\u0017\r_<\u0015&U叨叹厞伳伐桪栲栣伀桷";
      m[1] = int.class;
      n[1] = "java/lang/Integer";
      m[2] = "\ff\u00193\r@\ff\u000eo\u0001O\u0016-\u001ar\u0012E\u0006-\bs\u0014@\u0016zCm\fH\u001bf\u001f3)G\u0014f\u0003i\u000f[\u001b";
      m[3] = "A4\u0004KK@A4\u0013\u0017GO[\u007f\u0013\nTL\u0001\u001f\u001f\u000bh\\C=<\fU]";
      m[4] = "oT\u001agR\u0010d[\u000b(.\tkA\u0005k\u00199}V\tv\b\u0015j[";
      m[5] = "uTQdm(z\u0014\u001cog5\u007fI\u0017)o(rO\u0013b,伒佃叱伪佒叉伒佃栫桮";
      m[6] = void.class;
      n[6] = "java/lang/Void";
      m[7] = "6g\u000b \u0001=9'F+\u000b <zMm\u001839|@m\u0007?%e\u000b\u0001\u0001=9lD-839|@";
      m[8] = "hf3$4Xci\"kUVhb&1";
      m[9] = "K),Q-)\u0016p'0桗叔叨桙厍佭桗叔栲桙N\r/)\u0013.u\u0001?.\u0014";
      m[10] = "#b\u0003RX|~;\b3rBz5\u001dI\u0001!(q\u0010M;";
      m[11] = "<d?{#$a=4\u001a伝栃桅栔伀佇桙叙企栔]z)x=nc'ps";
      m[12] = "1\u000e[\u0001\\!o\u000e\u0003U9厍佗伫佥佡叺桗叉桯校<\u00026iK]S\\61\u001f";
      m[13] = "\u0014\u00038/%SIZ3N厅厮厷伷桃厍桟厮厷伷Zs'SL\u0004a\u007f7TK";
      m[14] = "]\u0014\u0014>P\u0013\u0000M\u001f_b-\u0004C\n%\tNV\u0007\u0007!3\u0011[\u0017\u000e:RC\f\u0001\u000b_";
      m[15] = "\u0003$&\u001f.\u0005S7`O\u0015RmedG*\u0001m^c\u0013y\u0000\u0006f<\t~P";
      m[16] = "F0\u0012^T\b\u001bi\u0019?^6\u001c'\u0017\u0003JV\u001b;\u0012F7\fX>LBW\u000bD;\t?";
      m[17] = "XTYR{R\u0005\rR3^l\u0001\u0003GI\"\u000fSGJM\u0018";
      m[18] = "c\u000bS1:e>RXP伄伆叀桻史桉伄伆叀厡1m8e;\f\na(b<";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private int k(ItemStack helmet) {
      long a = 友友友何何树树树何树.a ^ 67855390211208L;
      d<"B">(-9132287475338956228L, a);
      int helmetColor = u(helmet);
      return this.v(helmetColor) ? this.J(helmetColor) : -1;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private boolean v(int color) {
      long a = 友友友何何树树树何树.a ^ 60534430576662L;
      d<"B">(5610801606707314338L, a);
      return color == -1
         ? false
         : color == c<"l">(32007, 1279731029282443646L ^ a)
            || color == c<"l">(30601, 4570465566376385515L ^ a)
            || color == c<"l">(15767, 3555037099475079661L ^ a)
            || color == 170
            || color == c<"l">(29225, 3010344184946908745L ^ a)
            || color == c<"l">(27151, 5633660608025970295L ^ a)
            || color == c<"l">(10611, 4457088177575462152L ^ a)
            || color == c<"l">(6845, 8822416578026682076L ^ a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public String z(Player player) {
      int color = this.n(player);
      return this.O(color);
   }

   private static int u(ItemStack stack) {
      long a = 友友友何何树树树何树.a ^ 64924206420133L;
      d<"B">(-5951409707470528256L, a);
      return stack.getItem() instanceof DyeableLeatherItem ? ((DyeableLeatherItem)stack.getItem()).getColor(stack) : -1;
   }

   public boolean E(LivingEntity entity) {
      long a = 友友友何何树树树何树.a ^ 53088757950489L;
      long ax = a ^ 49182701759736L;
      d<"B">(6184659601324349884L, a);
      if (this.w(new Object[]{ax})) {
         return false;
      } else if (d<"Ó">(this, 6184417105736328615L, a).getValue()
         && mc.player.getTeam() != null
         && entity.getTeam() != null
         && mc.player.getTeam().isAlliedTo(entity.getTeam())) {
         return true;
      } else {
         Component displayName = mc.player.getDisplayName();
         if (d<"Ó">(this, 6184125043935586158L, a).getValue() && entity instanceof Player entityPlayer) {
            ItemStack myHead = (ItemStack)d<"Ó">(mc.player.getInventory(), 6184565683911179965L, a).get(3);
            ItemStack entityHead = (ItemStack)d<"Ó">(entityPlayer.getInventory(), 6184565683911179965L, a).get(3);
            if (!myHead.isEmpty() && !entityHead.isEmpty()) {
               int myTeamColor = this.k(myHead);
               int entityTeamColor = this.k(entityHead);
               if (myTeamColor != -1 && entityTeamColor != -1) {
                  return myTeamColor == entityTeamColor;
               }
            }
         }

         if (d<"Ó">(this, 6184712675770691113L, a).getValue() && !displayName.getString().isEmpty() && !entity.getDisplayName().getString().isEmpty()) {
            String targetName = entity.getDisplayName().getString().replace(b<"f">(27023, 3191772424671879307L ^ a), "");
            String clientName = displayName.getString().replace(b<"f">(6295, 4546533671436882326L ^ a), "");
            return targetName.startsWith("§" + clientName.charAt(1));
         } else {
            return false;
         }
      }
   }

   public static int A() {
      return 树友何何何何树树何何;
   }

   public static void Y(int var0) {
      树友何何何何树树何何 = var0;
   }

   public static int N() {
      A();

      try {
         return 63;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public String O(int color) {
      long a = 友友友何何树树树何树.a ^ 9208035408981L;
      d<"B">(-9106651163059801375L, a);
      if (color == -1) {
         return "无";
      } else if (color == c<"l">(32007, 1279791707180375357L ^ a)) {
         return "红";
      } else if (color == c<"l">(30601, 4570504249344137128L ^ a)) {
         return "黄";
      } else if (color == c<"l">(15767, 3555090776425422254L ^ a)) {
         return "绿";
      } else if (color == 170) {
         return "蓝";
      } else if (color == c<"l">(29225, 3010334501616914954L ^ a)) {
         return "青";
      } else if (color == c<"l">(27151, 5633711938596309556L ^ a)) {
         return "紫";
      } else if (color == c<"l">(10611, 4457153252293364043L ^ a)) {
         return "白";
      } else {
         return color == c<"l">(6845, 8822475201839823519L ^ a) ? "灰" : b<"f">(7166, 5777034592267945655L ^ a);
      }
   }

   private static String HE_SHU_YOU() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
