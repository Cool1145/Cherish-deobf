package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import it.unimi.dsi.fastutil.ints.IntListIterator;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundAddPlayerPacket;
import net.minecraft.network.protocol.game.ClientboundMoveEntityPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class 树何树树友何何树树友 extends Module implements 何树友 {
   public static 树何树树友何何树树友 何友友何友何友友友树;
   private final BooleanValue 树树树何何何何何何何;
   private final BooleanValue 树何何何友树友树树树;
   private final BooleanValue 何友树何树何友树何树;
   private final BooleanValue 友何树何树友友友友友;
   private final BooleanValue 树何何友何树友树何何;
   private final BooleanValue 何友何友树何友何树何;
   private final BooleanValue 友友树树何友树树何何;
   private final BooleanValue 何友友友树树友树何树;
   private final BooleanValue 友何何友友树树树何友;
   private final BooleanValue 何友友友友友何何树友;
   private final List<Integer> 友友树树何友何树何友;
   private final Map<UUID, String> 树友友树友友友友树何;
   private final Map<Integer, String> 树友友何何友友何友树;
   private final Map<UUID, Long> 何友友何树树树何何树;
   private final Set<Integer> 何何何树树友友友友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final long k;
   private static final Object[] l = new Object[36];
   private static final String[] m = new String[36];
   private static String LIU_YA_FENG;

   public 树何树树友何何树树友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/misc/树何树树友何何树树友.a J
      // 003: ldc2_w 29308087692313
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 24125
      // 00c: ldc2_w 2479510121040982300
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 1866
      // 019: ldc2_w 4875069547576322160
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w -996220252128461183
      // 026: lload 1
      // 027: invokedynamic e (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/BooleanValue
      // 033: dup
      // 034: sipush 16990
      // 037: ldc2_w 3678753206415535478
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 15378
      // 044: ldc2_w 7142830798545081131
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 0
      // 04f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 052: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 055: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.树树树何何何何何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 058: aload 0
      // 059: new cn/cool/cherish/value/impl/BooleanValue
      // 05c: dup
      // 05d: sipush 23427
      // 060: ldc2_w 6123436028198270136
      // 063: lload 1
      // 064: lxor
      // 065: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 06a: sipush 21055
      // 06d: ldc2_w 709738101568027904
      // 070: lload 1
      // 071: lxor
      // 072: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 077: bipush 0
      // 078: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 07b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 07e: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.树何何何友树友树树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 081: aload 0
      // 082: new cn/cool/cherish/value/impl/BooleanValue
      // 085: dup
      // 086: sipush 9163
      // 089: ldc2_w 6113933763785149695
      // 08c: lload 1
      // 08d: lxor
      // 08e: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 093: sipush 15335
      // 096: ldc2_w 6213085321974568141
      // 099: lload 1
      // 09a: lxor
      // 09b: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a0: bipush 0
      // 0a1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0a4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0a7: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.何友树何树何友树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0aa: aload 0
      // 0ab: new cn/cool/cherish/value/impl/BooleanValue
      // 0ae: dup
      // 0af: sipush 20220
      // 0b2: ldc2_w 33834146265375184
      // 0b5: lload 1
      // 0b6: lxor
      // 0b7: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bc: sipush 10093
      // 0bf: ldc2_w 6976473731535358031
      // 0c2: lload 1
      // 0c3: lxor
      // 0c4: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c9: bipush 0
      // 0ca: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0cd: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0d0: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.友何树何树友友友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0d3: aload 0
      // 0d4: new cn/cool/cherish/value/impl/BooleanValue
      // 0d7: dup
      // 0d8: sipush 26314
      // 0db: ldc2_w 3061506159589394925
      // 0de: lload 1
      // 0df: lxor
      // 0e0: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e5: sipush 6030
      // 0e8: ldc2_w 3747571085323008174
      // 0eb: lload 1
      // 0ec: lxor
      // 0ed: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f2: bipush 0
      // 0f3: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0f6: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0f9: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.树何何友何树友树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0fc: aload 0
      // 0fd: new cn/cool/cherish/value/impl/BooleanValue
      // 100: dup
      // 101: sipush 18502
      // 104: ldc2_w 804107873173481342
      // 107: lload 1
      // 108: lxor
      // 109: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 10e: sipush 18352
      // 111: ldc2_w 7320072839044933785
      // 114: lload 1
      // 115: lxor
      // 116: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11b: bipush 0
      // 11c: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 11f: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 122: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.何友何友树何友何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 125: aload 0
      // 126: new cn/cool/cherish/value/impl/BooleanValue
      // 129: dup
      // 12a: sipush 3598
      // 12d: ldc2_w 974295193819537697
      // 130: lload 1
      // 131: lxor
      // 132: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 137: sipush 28628
      // 13a: ldc2_w 3064407233666711807
      // 13d: lload 1
      // 13e: lxor
      // 13f: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 144: bipush 0
      // 145: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 148: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 14b: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.友友树树何友树树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 14e: aload 0
      // 14f: new cn/cool/cherish/value/impl/BooleanValue
      // 152: dup
      // 153: sipush 8150
      // 156: ldc2_w 4401720103646261493
      // 159: lload 1
      // 15a: lxor
      // 15b: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 160: sipush 26997
      // 163: ldc2_w 7428519402518251089
      // 166: lload 1
      // 167: lxor
      // 168: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16d: bipush 0
      // 16e: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 171: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 174: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.何友友友树树友树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 177: aload 0
      // 178: new cn/cool/cherish/value/impl/BooleanValue
      // 17b: dup
      // 17c: sipush 3035
      // 17f: ldc2_w 7734687922644215014
      // 182: lload 1
      // 183: lxor
      // 184: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 189: sipush 13694
      // 18c: ldc2_w 8329154845184776768
      // 18f: lload 1
      // 190: lxor
      // 191: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 196: bipush 1
      // 197: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 19a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 19d: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.友何何友友树树树何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1a0: aload 0
      // 1a1: new cn/cool/cherish/value/impl/BooleanValue
      // 1a4: dup
      // 1a5: sipush 31988
      // 1a8: ldc2_w 760378309562307546
      // 1ab: lload 1
      // 1ac: lxor
      // 1ad: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b2: sipush 30353
      // 1b5: ldc2_w 4776273717051300276
      // 1b8: lload 1
      // 1b9: lxor
      // 1ba: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1bf: bipush 0
      // 1c0: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1c3: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1c6: aload 0
      // 1c7: ldc2_w -999113264577036747
      // 1ca: lload 1
      // 1cb: invokedynamic ú (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1d0: dup
      // 1d1: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 1d4: pop
      // 1d5: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 1da: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 1dd: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 1e0: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.何友友友友友何何树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1e3: aload 0
      // 1e4: new java/util/ArrayList
      // 1e7: dup
      // 1e8: invokespecial java/util/ArrayList.<init> ()V
      // 1eb: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.友友树树何友何树何友 Ljava/util/List;
      // 1ee: aload 0
      // 1ef: new java/util/concurrent/ConcurrentHashMap
      // 1f2: dup
      // 1f3: invokespecial java/util/concurrent/ConcurrentHashMap.<init> ()V
      // 1f6: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.树友友树友友友友树何 Ljava/util/Map;
      // 1f9: aload 0
      // 1fa: new java/util/concurrent/ConcurrentHashMap
      // 1fd: dup
      // 1fe: invokespecial java/util/concurrent/ConcurrentHashMap.<init> ()V
      // 201: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.树友友何何友友何友树 Ljava/util/Map;
      // 204: aload 0
      // 205: new java/util/concurrent/ConcurrentHashMap
      // 208: dup
      // 209: invokespecial java/util/concurrent/ConcurrentHashMap.<init> ()V
      // 20c: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.何友友何树树树何何树 Ljava/util/Map;
      // 20f: aload 0
      // 210: new java/util/HashSet
      // 213: dup
      // 214: invokespecial java/util/HashSet.<init> ()V
      // 217: putfield cn/cool/cherish/module/impl/misc/树何树树友何何树树友.何何何树树友友友友何 Ljava/util/Set;
      // 21a: aload 0
      // 21b: ldc2_w -997118222024529735
      // 21e: lload 1
      // 21f: invokedynamic Ý (Lcn/cool/cherish/module/impl/misc/树何树树友何何树树友;JJ)V bsm=cn/cool/cherish/module/impl/misc/树何树树友何何树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 224: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(4652544777691408710L, -9035919873696272071L, MethodHandles.lookup().lookupClass()).a(154747590566358L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var10 = a ^ 83557132462807L;
      Cipher var12;
      Cipher var22 = var12 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var10 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var13 = 1; var13 < 8; var13++) {
         var10003[var13] = (byte)(var10 << var13 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var19 = new String[25];
      int var17 = 0;
      String var16 = "½^\u001a\u0096çF\u008e\u0000|\u0089¼\u0003¼©1í(ù\u000fc\u00989Ù~ø?°1G\u0086\u0014®®-Á\u001ch\u001dãíï\u0088×\u0081.EÍ%r\"ü¥}±pûF(åÀ:ÖCÆè¼ ~\u0015=\u0018÷\u008dî§CÑºs\u008eç/²¹<³ûá,~\u00adõx\\ëÑÌ\u009e\u0010\u008dûz\u00ad ¿\u0013:p¨të\u0098\u001987\u0018¿\u0019ü@+\u0015ÃÆ\u001fÔ^ez\u0081uâ\u0012\\\u009a«\u0098dè\u0016\u0010ÿòsúCTÅ`\u008bahëº¶wë \u008dÍ\u0005Y³yl¸g\u009d*`|ë9\u008eÞ]ý\u007f|Ý\u00176ÍÅÝ¶·ÝV\u0085 ñòÌ±ÔHD¥J\u0015U7&¨·çjÂ¾¶N2Uô À4¡\u0013!\u0082e N)\\®£\u0089\u0086\rÜ£\u0081ÖÒ}·f\u001a)\u001f\u0015W^ö\t¤Üv\u0003dÇ=ò@©£J#\u001c ªª\u0095«L\u00995\u009b\u00824ZFö\u0094\t3\u0080BM\u0087S»Óîî\u0097/#\u0093Eû ]\u0088éªÏTøÎæ±\u0098T²XèçuZ\u001eJ{!g½QH Bäå\u0094,\u0002³Î\u000b\u0007Ø\u00ad\u000fT,Ä\\$\u008f\u009cV\u000f{Þ9c\u0082,\u008c*¤¸\u0010ªMU[\u009a\u0091.zÉÜ\u008c¼´\u0001|ÿ\u0010'Í@Çã¹}\u0004¼¶\u0002\u0085\bó\u0089\u008f\u0010üa\u0019\u008a%\u0006ä\u0005T\u0088f\r>\u00ad\n\u0088\u0010\f\u0005\u0096\u009býþ.à°ÿ¸Ù³ë|Ì\u0010\u0010¤\u0004Úâ?O[\u0018\u008b¬Nã\u0019s£ X#e\u0084\bÜ|îÛF¦kÉ´q/w»¦Ãú+s\u0095ÉÄ\u0000\u008b¾³My\u0010Òæ¾I\u0084À´rÔ\u000eîT\u0096Ú\u00ad{\u0010\u0082û§bý\u0081Fð=\u009aÝïÈ\u009bò\u008c\u0010\u0013\u008bXçç<'\u0019\u00921\u008dÕ;{Ó)\u0010ý1LnOÒYµÃe\u0005\u008a\u0081òØ; r¿\u0005\u0091\u0089\u0089Ú\u0099\u0002%\u009b~8ð¢` \n®\u0002\u000bc\u0016Îk¡\u009b@òaf\u0093 /\u00ad8kCÖ\u0098,\u000býøZb\u001b\u008a½[\u007f}7\f{\u0088q\f3Ä\u008d¯@w\u009a";
      short var18 = 606;
      char var15 = 16;
      int var21 = -1;

      label49:
      while (true) {
         String var23 = var16.substring(++var21, var21 + var15);
         byte var10001 = -1;

         while (true) {
            String var33 = c(var12.doFinal(var23.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var19[var17++] = var33;
                  if ((var21 += var15) >= var18) {
                     c = var19;
                     h = new String[25];
                     Cipher var5;
                     Cipher var25 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var10 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(var10 << var6 * 8 >>> 56);
                     }

                     var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var9 = var5.doFinal(new byte[]{60, 88, 115, 127, 41, -88, -78, 96});
                     long var37 = (var9[0] & 255L) << 56
                        | (var9[1] & 255L) << 48
                        | (var9[2] & 255L) << 40
                        | (var9[3] & 255L) << 32
                        | (var9[4] & 255L) << 24
                        | (var9[5] & 255L) << 16
                        | (var9[6] & 255L) << 8
                        | var9[7] & 255L;
                     var10001 = -1;
                     j = var37;
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var10 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var10 << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{8, -3, -97, -13, -116, -126, 83, 16});
                     long var39 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     k = var39;
                     return;
                  }

                  var15 = var16.charAt(var21);
                  break;
               default:
                  var19[var17++] = var33;
                  if ((var21 += var15) < var18) {
                     var15 = var16.charAt(var21);
                     continue label49;
                  }

                  var16 = "Iq'\u008b½tß\u0089U\u0084bZ2[\u0013m\u0010¢1\u008f\u00818\\hbÌ;(s\u009bôE£";
                  var18 = 33;
                  var15 = 16;
                  var21 = -1;
            }

            var23 = var16.substring(++var21, var21 + var15);
            var10001 = 0;
         }
      }
   }

   public void F() {
      this.R();
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (m[var4] != null) {
         return var4;
      } else {
         Object var5 = l[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 52;
               case 1 -> 51;
               case 2 -> 49;
               case 3 -> 35;
               case 4 -> 7;
               case 5 -> 10;
               case 6 -> 31;
               case 7 -> 23;
               case 8 -> 41;
               case 9 -> 32;
               case 10 -> 24;
               case 11 -> 27;
               case 12 -> 14;
               case 13 -> 45;
               case 14 -> 17;
               case 15 -> 36;
               case 16 -> 34;
               case 17 -> 39;
               case 18 -> 2;
               case 19 -> 53;
               case 20 -> 28;
               case 21 -> 9;
               case 22 -> 0;
               case 23 -> 42;
               case 24 -> 12;
               case 25 -> 33;
               case 26 -> 3;
               case 27 -> 8;
               case 28 -> 4;
               case 29 -> 5;
               case 30 -> 22;
               case 31 -> 38;
               case 32 -> 61;
               case 33 -> 29;
               case 34 -> 37;
               case 35 -> 54;
               case 36 -> 11;
               case 37 -> 43;
               case 38 -> 59;
               case 39 -> 19;
               case 40 -> 18;
               case 41 -> 20;
               case 42 -> 55;
               case 43 -> 46;
               case 44 -> 26;
               case 45 -> 47;
               case 46 -> 40;
               case 47 -> 25;
               case 48 -> 1;
               case 49 -> 6;
               case 50 -> 57;
               case 51 -> 16;
               case 52 -> 30;
               case 53 -> 48;
               case 54 -> 21;
               case 55 -> 13;
               case 56 -> 15;
               case 57 -> 58;
               case 58 -> 56;
               case 59 -> 63;
               case 60 -> 60;
               case 61 -> 62;
               case 62 -> 50;
               default -> 44;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            m[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7430;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树树友何何树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树树友何何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 250 && var8 != 'S' && var8 != 'e' && var8 != 221) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 202) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 164) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 250) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'S') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'e') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树树友何何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   public boolean f(Entity entity) {
      long a = 树何树树友何何树树友.a ^ 140695635391951L;
      c<"¤">(7780073268065074456L, a);
      if (this.isEnabled() && entity instanceof Player) {
         if (!c<"ú">(this, 7780440439525537720L, a).getValue()
            || !(entity.getBbHeight() <= 0.5) && !((Player)entity).isSleeping() && c<"ú">(entity, 7780860213446815912L, a) >= 80) {
            if (c<"ú">(this, 7778914388606979270L, a).getValue() && ((Player)entity).isDeadOrDying()) {
               return true;
            } else if (c<"ú">(this, 7780262319001995072L, a).getValue() && ((Player)entity).getHealth() == 0.0F) {
               return true;
            } else if (c<"ú">(this, 7781082212018757168L, a).getValue() && ((Player)entity).isSleeping()) {
               return true;
            } else if (!c<"ú">(this, 7782112789695049909L, a).getValue() || entity.getId() < (int)j && entity.getId() > -1) {
               if (c<"ú">(this, 7780996924731703736L, a).getValue() && mc.getConnection().getPlayerInfo(entity.getUUID()) == null) {
                  return true;
               } else if (c<"ú">(this, 7780590362361610278L, a).getValue() && !c<"ú">(this, 7779095721037435416L, a).contains(entity.getId())) {
                  return true;
               } else {
                  return c<"ú">(this, 7778854096105678819L, a).getValue()
                     ? c<"ú">(this, 7780525878957475146L, a).contains(entity.getId())
                     : c<"ú">(this, 7780128514128308116L, a).getValue()
                        && ((Player)entity).getInventory().getArmor(0).isEmpty()
                        && ((Player)entity).getInventory().getArmor(1).isEmpty()
                        && ((Player)entity).getInventory().getArmor(2).isEmpty()
                        && ((Player)entity).getInventory().getArmor(3).isEmpty();
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = l[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = m[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         l[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      l[0] = "`+bx\u001fvok/s\u0015kj6$5\u001dvg0 ~^pn5 5\u001dpp&b栊伥栈栒厎伙低桡栈又";
      l[1] = "ZO(_\u0007CU\u000feT\r^PRn\u0012\u0005C]TjYF佹佬只体佩厣佹佬栰栗";
      l[2] = "{5>P\u007f~tus[ucq(x\u001dfpt.u\u001dy|h7>q\u007f~t>q]Fpt.u";
      l[3] = "%\u00159v\u0017S;\u001d#9tG?";
      l[4] = "<O_Mr\u0019\"GE\u0002\u000f\t\"";
      l[5] = "\rl\u0014B\u001b\u0006\u0002,YI\u0011\u001b\u0007qR\u000f\u0019\u0006\nwVDZ\u0000\u0003rV\u000f\u0019\u0000\u001da\u0014只县厢伻佗栫栰桥似桿";
      l[6] = int.class;
      m[6] = "java/lang/Integer";
      l[7] = "M8\"$C6F73k?/I-=(\b\u001f_:15\u00193H7";
      l[8] = "\u0000O\u001ag\u001cH\u0000O\r;\u0010G\u001a\u0004\u0000,\u0005V\u0001X\u0005g\u0001S\u0001^\u0001*\u001eM@M\u000f$\u0014\u000f-F\u0007,\u001fU\fE\u001b'\u0015q\u0002K\u0017,\u0003h\u0000L\u0001\u001c\u0001E\u000f^\u000b\u0019\u0010B\u0005O\u001am0B\u001aC\u0001'";
      l[9] = "i\n\u001dz]\u0007i\n\n&Q\bsA\u001e;B\u0002cA\u00051F\u000bkA.5]\u000bS\u0016\u00191";
      l[10] = "rb0\f1\u0002lj*CS\u001ekw";
      l[11] = "\u001fYT*X\u001a\u001fYCvT\u0015\u0005\u0012WkG\u001f\u0015\u0012EjA\u001a\u0005E\u000eA[\u0007\u0018HY";
      l[12] = "E:`!\u0013'N5qnr)E>u4";
      l[13] = "y\bn,?sy\u001ax:FBBL|-&rz\u000b#/{\u000b";
      l[14] = "\u0000&XodmX)\f\u000f栙栊桺伅似佒佝低伾伅a6cp_ \u001bj\u007fv_";
      l[15] = "yBlK{\u0003!M8+佂厾叙佡厖佶叜厾叙栥UHaDzX+\u0010n\u0010";
      l[16] = "]$[C\u0019A\u0005+\u000f#传叼叽厙厡叠传佢栧厙b\u001a\u001e\\\u0002\"\u0018F\u0002Z\u0002";
      l[17] = "\u00040\u0004}T,\u0004\"\u0012k-\u0012?t\u0016|M-\u00073I~\u0010T";
      l[18] = ">\u0010r\u0006j f\u001f&f体厝桄伳桒伻反桇伀桷K_m=a\u00161\u0003q;a";
      l[19] = "+\f\u001e\u0019Xgs\u0003Jy佡叚压伯栾桠栥佄伕桫'CW'#C\u001fD^(9";
      l[20] = "C?p>$]\u001b0$^厃叠根桘伔厝桙栺佽伜Ig#@\u001c93;?F\u001c";
      l[21] = "Gy``Qo\u001fv4\u0000栬叒叧佚伄參叶佌叧栞Y:^/O6a=W U";
      l[22] = "\r4W\u001bIGU;\u0003{叮佤桷众桷厸叮叺厭厉nBNZR2\u0014\u001eR\\R";
      l[23] = "\u001cXd.H\u000bDW0N佱伨伢栿桄厍可厶厼佻]uA\b\rD$0\u001d\u001f\u000f";
      l[24] = "Z&\u000e\tHQ\u0002)Zi栵佲佤厛佪桰可栶佤伅7POL\u0005 M\fSJ\u0005";
      l[25] = "pq+6\u001c\u0017(~\u007fV桡厪叐栖发厕去厪栊佒\u0012l\u0013Wx>*k\u001aXb";
      l[26] = "\u0002BN\u0004lmY]I\u0001\u0011\u001as|&!U\u001an}+y,!\u0000M\fGw>\u0007H";
      l[27] = "bd[\u0010no`+\u0014 叁佉佂佈佸口栛受栆栌%]sj/y^_<%";
      l[28] = " L\u000f\bnDo\n\u000eN\u001fSH\bZ\u000b.\u0002H1WWy]f\t\u0010\b{\u0000";
      l[29] = "n_uhc\u00151Ii5[<\rzED\u0005.\u0014 %z5\nhRzl)W";
      l[30] = "ym\u0007iEo!bS\t佼叒叙叐栧栐叢栈佇栊>0Br&kDl^t&";
      l[31] = "\u0006%=\u0003\t0^*ic桴伓伸伆叇桺厮桗桼桂\u0004Z\u000e-Y#~\u0006\u0012+Y";
      l[32] = "\u0004\u0004\u0004>kx\\\u000bP^双佛伺厹叾桇栖栟伺厹=gle[\u0002G;pc[";
      l[33] = "\u0010h|\t&@Hg(i伟叽伮叕桜伴厁佣桪佋EP!]On?\f=[O";
      l[34] = "\u0015\u0019ajb#M\u00165\no]K\u0005`3wg\u0004\nfg\u0006`\u0014_a{</\u001bY5\n";
      l[35] = "\u0003\u0018\u0019w/B[\u0017M\u0017厈叿桹桿佽叔伖栥伽厥 ($F_\u0000Pe'X\f";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = l[var4];
      if (var5 instanceof String) {
         String var6 = m[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         l[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      this.R();
   }

   @EventTarget
   public void g(PacketEvent event) {
      long a = 树何树树友何何树树友.a ^ 38809163201361L;
      long ax = a ^ 70852762606666L;
      long axx = a ^ 86355545345194L;
      c<"¤">(-1916840368998222970L, a);
      if (!this.w(new Object[]{ax})) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundMoveEntityPacket wrapper && c<"ú">(this, -1917292042630148424L, a).getValue()) {
            Entity entity = wrapper.getEntity(mc.level);
            if (entity instanceof Player && wrapper.isOnGround() && !c<"ú">(this, -1915513175410860922L, a).contains(entity.getId())) {
               c<"ú">(this, -1915513175410860922L, a).add(entity.getId());
            }
         }

         if (c<"ú">(this, -1915623946078377603L, a).getValue()) {
            if (packet instanceof ClientboundPlayerInfoUpdatePacket wrapperx) {
               if (!wrapperx.actions().contains(c<"e">(-1917151841399964134L, a))) {
                  return;
               }

               Iterator displayName = wrapperx.entries().iterator();
               if (displayName.hasNext()) {
                  net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Entry entry = (net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Entry)displayName.next();
                  if (entry.displayName() != null && entry.displayName().getSiblings().isEmpty() && entry.gameMode() == c<"e">(-1917075492117798925L, a)) {
                     UUID uuid = entry.profile().getId();
                     c<"ú">(this, -1916667934059690173L, a).put(uuid, System.currentTimeMillis());
                     c<"ú">(this, -1917355035149341599L, a).put(uuid, entry.displayName().getString());
                  }
               }
            }

            if (packet instanceof ClientboundAddPlayerPacket wrapperx) {
               if (!c<"ú">(this, -1916667934059690173L, a).containsKey(wrapperx.getPlayerId())) {
                  return;
               }

               String displayName = (String)c<"ú">(this, -1917355035149341599L, a).get(wrapperx.getPlayerId());
               if (c<"ú">(this, -1916716478779920588L, a).getValue()) {
                  ClientUtils.e(new Object[]{b<"h">(6700, 7799599717959426648L ^ a) + displayName + ")", axx});
               }

               c<"ú">(this, -1916545618160336441L, a).put(wrapperx.getEntityId(), displayName);
               c<"ú">(this, -1916667934059690173L, a).remove(wrapperx.getPlayerId());
               c<"ú">(this, -1916378750996313132L, a).add(wrapperx.getEntityId());
            }

            if (packet instanceof ClientboundRemoveEntitiesPacket wrapperx) {
               IntListIterator var19 = wrapperx.getEntityIds().iterator();
               if (var19.hasNext()) {
                  Integer entityId = (Integer)var19.next();
                  if (c<"ú">(this, -1916378750996313132L, a).contains(entityId)) {
                     String displayName = (String)c<"ú">(this, -1916545618160336441L, a).get(entityId);
                     if (c<"ú">(this, -1916716478779920588L, a).getValue()) {
                        ClientUtils.e(new Object[]{b<"h">(12973, 6293159513089592003L ^ a) + displayName + ")", axx});
                     }

                     c<"ú">(this, -1916378750996313132L, a).remove(entityId);
                  }
               }
            }
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = l[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void R() {
      long a = 树何树树友何何树树友.a ^ 12981464931021L;
      c<"ú">(this, 358044161169165821L, a).clear();
      c<"ú">(this, 358923955890888795L, a).clear();
      c<"ú">(this, 359037998982752840L, a).clear();
      c<"ú">(this, 358748854432327391L, a).clear();
   }

   @EventTarget
   public void G(MotionEvent e) {
      long a = 树何树树友何何树树友.a ^ 135299138670000L;
      long ax = a ^ 25065578134091L;
      c<"¤">(6016910266199440133L, a);
      if (e.isPre()) {
         Iterator var7 = c<"ú">(this, 6019053123837243810L, a).entrySet().iterator();
         if (var7.hasNext()) {
            Entry<UUID, Long> entry = (Entry<UUID, Long>)var7.next();
            if (System.currentTimeMillis() - entry.getValue() > k) {
               if (c<"ú">(this, 6018828641764694485L, a).getValue()) {
                  ClientUtils.e(
                     new Object[]{b<"h">(1940, 1484649173935606032L ^ a) + (String)c<"ú">(this, 6018347899608783488L, a).get(entry.getKey()) + ")", ax}
                  );
               }

               c<"ú">(this, 6019053123837243810L, a).remove(entry.getKey());
            }
         }
      }
   }

   @EventTarget
   public void G(WorldEvent event) {
      this.R();
   }

   private static String LIU_YA_FENG() {
      return "何树友被何大伟克制了";
   }
}
