package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.packet.SyncHandleReceivePacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public class 树树何树友何何何何树 extends Module implements 何树友 {
   public static 树树何树友何何何何树 友何友树树何友友友何;
   private final BooleanValue 友友何何何何友树树树;
   private final BooleanValue 何何友何友友树树友树;
   private final BooleanValue 友树树何何友树树树友;
   private final BooleanValue 友友何何树何树树友友;
   private final BooleanValue 友何何友友树友树树友;
   private final BooleanValue 何何何何树树友友树何;
   private final BooleanValue 友友友何友树树树何友;
   private final BooleanValue 何何友树何友友友何何;
   private final BooleanValue 树何友树树何树何何树;
   private final BooleanValue 何友友友树树友友树友;
   private final BooleanValue 何友何树树何何何树树;
   private final BooleanValue 何何何何何何友树友树;
   private final BooleanValue 树树何树友何树友友友;
   private final BooleanValue 友何何树树树友何何何;
   public static List<Entity> 何树友树树何友树友何;
   private static final List<Player> 友友友友友树何树何树;
   private static final List<Player> 何友树友友树树树何树;
   private static final Map<Player, Set<String>> 友树友何树友何何何友;
   private static final Map<Player, Set<String>> 友何树何友树树何友何;
   public static int 友树友友友何树友树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[62];
   private static final String[] k = new String[62];
   private static String HE_DA_WEI;

   public 树树何树友何何何何树() {
      long a = 117749894448771L;
      c<"¥">(-8750978847132099678L, a);
      super(b<"a">(13527, 2317941324427193856L), b<"a">(30074, 2389180092024074129L), c<"r">(-8750595497835440998L, a));
      this.友友何何何何友树树树 = new BooleanValue(b<"a">(31139, 6922174852534412144L), b<"a">(10675, 6555358463667139404L), true);
      this.何何友何友友树树友树 = new BooleanValue(b<"a">(515, 759980485208004838L), b<"a">(8671, 6464444074791861038L), true);
      this.友树树何何友树树树友 = new BooleanValue(b<"a">(27245, 4309146927823925420L), b<"a">(18574, 4112199379489886788L), true);
      this.友友何何树何树树友友 = new BooleanValue(b<"a">(11051, 5347903445011001813L), b<"a">(6739, 8227977345044529402L), true);
      this.友何何友友树友树树友 = new BooleanValue(b<"a">(6298, 6480401573656183372L), b<"a">(3241, 2423883492407989833L), true);
      this.何何何何树树友友树何 = new BooleanValue(b<"a">(17125, 8297365289301678128L), b<"a">(30001, 9041546177920741323L), true);
      this.友友友何友树树树何友 = new BooleanValue(b<"a">(14194, 6149000849900924312L), b<"a">(5947, 2406025970688183805L), true);
      this.何何友树何友友友何何 = new BooleanValue(b<"a">(7161, 7310334302038212917L), b<"a">(2759, 3429440208633810956L), true);
      this.树何友树树何树何何树 = new BooleanValue(b<"a">(25916, 4889212871905165297L), b<"a">(6810, 1565092200991277158L), true);
      this.何友友友树树友友树友 = new BooleanValue(b<"a">(6298, 8221513855379128916L), b<"a">(2466, 5940675904032527114L), true);
      this.何友何树树何何何树树 = new BooleanValue(b<"a">(22678, 1921617923039560265L), b<"a">(16200, 3831703266946180539L), true);
      this.何何何何何何友树友树 = new BooleanValue(b<"a">(17164, 980571446269680079L), b<"a">(20526, 7648819268033022679L), true);
      this.树树何树友何树友友友 = new BooleanValue(b<"a">(405, 5233444132530150206L), b<"a">(11506, 6891903173628982822L), true)
         .A(c<"Ï">(this, -8752689303336415405L, a)::getValue);
      this.友何何树树树友何何何 = new BooleanValue(b<"a">(11475, 2601300875103794690L), b<"a">(9707, 3015413286308970259L), true)
         .A(c<"Ï">(this, -8752689303336415405L, a)::getValue);
      c<"Þ">(this, -8752225172483802853L, a);
      if (c<"¥">(-8753605940903143397L, a) == null) {
         c<"¥">("X0gOh", -8750825174873329694L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7843883337576589189L, -1490478858600966211L, MethodHandles.lookup().lookupClass()).a(125568081150441L);
      // $VF: monitorexit
      a = var10000;
      long var9 = 76014304672799L;
      a();
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[72];
      int var5 = 0;
      String var4 = "T\u0087ÞC/z©Tdè\u009e.j¡ã®9IÕ\u0007Ú´·s6\u0018\u0084?¿\u009a¾´\u0087·\u0017»4ÿ!\u000b\u0018§\u000b)æÚ\u0093þ¼\u0095È{{=\u0004w>±MsQO\u001có\u009e\u0010\u00163ç\u0084£\u008e\u0005`\u0080aèk=\u0097v\t \u0004¾\u0097y2Å\u0096 dæÝ\nd\u001bòá\u0098\u009f¬e!\u001eB>Ü#Õ¢Z\nT®\u0018\u008f\u0001^\t\u0091\u0092ªSÆ\u008d+Ñµ\u0011\u0089¶UòOýªP:d(î+.\u000eK\u007f×«\u001a/Ðª\u0084\u0081ßM;t\u0087ù£¹¹ÁÒA\u0091[\u009a»\u0082ÿ\u0092ÇN\\\u0001\rU]\u0088G )Op\u007fÖ»\u0015Q\u007f{~\u009eå COÎñM·\u0005°\u001f¢N\u0015ÕÖæàÙÎî@\u001eö\u0017Ì<\u009fF®\u0087zÿ?=`#\u0088[\u000f\u0007d\u0094\u008a\u0011¢\u001cÞ`ëaú£\u0006q\\3däp(i\u0081¥Ã\u0004Ëê#\u008b_\u0082W\u0011¼a\u008c\u00849ÁDv\u0011E<ñW\u0088<^¼\u0090\u001c·ÆG»ªzû\u0081\u0001\u001al¤\u008c 0_\u0099èv_è3XÝ\u0085k&RC ýiWê\u0094J«\u0089ÿ\u001eþM\u001bªE\u0011\n\u001eÿ\\\u008b\u001a\u008cÍàR;©ÙøÍ,\u0010âì+vÆ|²ª°\u008cjÄ-ûsÃ\u0010áìEøn£U= nº\u008fW,\u0084\u008e\u0010¹÷\"J¥n}\u0086äßwÞ8¦!R G\u008f\u0095\u0010/5}0\fÏÃ\u0091é\u0082¶@µÒÁ¦\u007f\u000eoUU\u00009¯\u001cdV7\u0010*\n\u001a\f\u0081ä$[8, ´\u008eNÑ4\u0018f¿Ë\u0005éy*I>\u0017WÌ\u009aè-\u000b\u0095Ì©U\u0003í\u0086½\u0018\u0097±ä°,¼hå\u001aËzÈ\u0096À\u0097\u0091\u001f^\u0014*.=3\u0097 aBp\u0006þ³Ígp¼j¬¡n\u0086x\u007fY/\u0017\u0090D@Ø\b>ÕG7H\u009cÊ \u0089`NÄª$hºÇãiÜuäÌ\u0083\u0005õf¯È\u0090fÀOÃyb}Ïwû ÿß\u008aîwÓ\u0080o¤¹KÑÈ'ï>P\u008c*/ \u0096´\u0016ª\u0082Èyº#|Å \u0092àÇÕ¼\u0098ë.\u0012Ã\u0006·<\u009dE)\u007fÉ\b\u0081\\rv\u0018]xä²\rç^ë0\u0099¦²\u001c»þæ³þàYÅú»¸Ü/\u0081'o1ì\u00adFÊØ\u001f°á¬\u0019\u009b8\f¿\u001e\n\u0011v2·\u0098Ø$\u009f~<H(6[\bî»^±àfA\u008f\u0082Þ=nzÕ¿Ñ°Ê¤FÓP]\u0098±VHÊ{a\u0088cµÃ\u0080%z(qªp÷Bfydõ\u0019^H\u0018Û\u008d\u001fA»ªz\u008c\u0091kéP'\u001e©ÈiDãq\u0014\u0001û¬Þ\u0004\u0000 \u000eÌÖ\u001c¶\u0089\u001c5Pc¬áW\u001eðß^ñ \u000eØ1á\u0018\u000bKÍr,Ä\u001cw ¬¦ìèá.X@É®\"\u009b\f_uD¿\u008d\u0003Û\u0092ª\u009an°ñãJ(¥§¤ \u001dè\u0012\u0083S¼ú\u0015â'\u008cÿè¡LQ\u001eLÍ\u009fÄ\u0087ý{·\u000bé1\u0017Â\u000e;\u0018èL\u0092\u0011Àî©\u0015Ò©g\u000fíá\u009aÙ¥\u001f\u0088\u0089\u0011Ä;\u007f ehG\u009c²paHÜ\u009a=VºË9Øi2J\u00049N¸!ü¡£\u0095.ß\u009e\u0097 vôîø\u0081í,s\u0086\u008fr\u00871\u0003ûìBºIÖ\u007fÓ\u007f8é\\K£\u0099Ft\u0085\u0010u6îF\u0083Ð-±ú\u001e4Ú\u009f¥²ÔP¨\u0082+Ûæ±^6Ö8BC\b''Æ\u0016\u0004\u008d\u0094\u001a\u0095C¸º<ÊÂ%ÊwÎ|\\m]ÃòD\u0011w\u0015d\u0018£¤Z£%[å;i0wÞ-êöp\\n\u0012ßÈ\u008dþ·mß©y\u001b/\fÍÛ&\b\u008d \u0019 #\u008db\u001d_\u0096Î&\u0084\u0088Ý\u009cé¸÷GqÛ\u008f¼¹\u0098¼.\u0081\u0001\u007f´îú@©\"\u0005·dÅ\u008cJ®³äåA9ÓC áÄq\u0014\u0085Oz)/pÑº§_v)ËOrÀ¼wðá\u007f²\u0090î#\u009aP·\u0082K\u0085´¨7\u009b½\u00adò_Ò-a\u0016\u0018qÑÀßO2\u009a\u0087ùn\u001d\u00868¥¸Å\u0096Bë×\u009cè\u0010_(\u009aV¡ä\u009eí \u0088sþþ\u0082\u001eOú¤7ù\u0092ÚÙïmìÒ0\u0094òû\u0099À\u0098E¥^\u0092Ç\u0007!4(k\u001dÅ\u008cYÑ(\u0095!\u001aÓ³á\f&NyeÒî\u00186Ò$\u009bH\u008cQ<Çn?k\u0087\u009f\u0018\räx\u0010\u00102më¹\u0099Å&õ\u0084\u0080l\u000b%X@T@83¶5Æ¥ü\u0098Ç³vä¤³j5À\u009a9ßw6Õ-&ÑS\u0015E¢\u0086= \tÒi3á\u0099c:Mò-\u008d»\u009d'Ó^\u0015®\tÝs\u0092¢ýK\u0014ÿ\u0004-º ìv\u0085¾Bï\u0014\fÇ\u0017\u000bÕov\u001adÌ\u009eP3m]Þ«vÒ\u0094öqÓÑ³(\u009d¿Ìj\u0090 \"ëÔ\u009e°\u008c\u000eRÐH\u0083ýíTq¨Ñe\u0093L\u008f=þõ¬fµ¹\u008b÷U¬µ´ (\b\u009f¨\u0090{\u0001Ãðç§\"x7Q9)Â\u0006^Õ}\u0081\u008a{Â*1yYå4\u0018ÈBý\u009d\u008e@\u00ad÷)ó\u008e%\u001fÍºoäGlë\u00964â< ¯=\u008fÿøJáì?D7½_\r¡Å\u0096®vD?ù£Pia\u0084®P\u000b\u0091ù\u0018Ù\t²c\\ÔYCâù6\u0017Ú\u0095P\u007f/1uUU\t\u001er\u0010Q-ü\u009e\u008e_v^¹\u000eEfÎ\u0081$\u001c\u0010Tî(8ÁTÓÅ÷zU»2.1\u0000(Ixduv\u0005Ç\u0013yJ½YÁ\u0098Ò\u009b¿Ì\u0007ÒJZ|õ$}~T\u0000\u001fZ\u0084\u009dÈÎ³j8Çm ßqr®ä{\u0083*ôµ\u0085¨J\u0090k\u0006\u0001ê\u0094©\"\u0019wîüÌ\u0017\u008e¹\u0095\u001a\r\u0010\u009dk\u0087@\u0086Ù;*q\u0093\u00042Ù\r\u0099\u0004\u0010-lÜ\u00959êm¤\u001emd/)*$J(î]\u000b\u009a¸hPèËð1¤l¶«Ü;0ÉcQÜ\u0094\u0087ãÊyöo\u0010o:È¿R±²ê\u009a8(\u0085\u0093pÄq\u0088\\ü \u001e#\u0083\u0094{=:{)\u009a\u0012\u0081\u008b\u0016%\u009f\u009b\u001eÖÍc)ó\u0085lÍR\t\u0019\u009f¶ Õð\u0004=K,Ì|9ÇäÅ\u008fL\u000bæ\bú\u008a?\u009e\u0080/AæK'Ô§°õ´ (\nÓ&ªnÊG\u0010wYúh¶J½X}\u0011Uw\u0098´Üu²å\u0091d\u007f=\u0085\u0018\u008f\u0087UP*ù5º#R?\u0004´¥\u0083B\u001a\u0088\u008f\r\u001eKuù\u0010\u000bÉä\u0015\u008b6qV×ËX|z\u0094U¼\u0010Â\u0010Ü\u0010\u0091w\u0081÷\u0017¹J\u008c\u008fTz~\u0018\r\u0019ÌT'\u0080\u008amé5±Ð\u0004\u000fá[;6.t+I\u0016c u{\u009b=8\u0083\u0081\"^}!\u00148\u00102\u0094±kU)\u0082_(\u0091SBÆè;\u008d=ß(>H\u001c\u000bOÑRQ2¢ðä\u00898Á§u\u0001\u0096x¤B;w+»Øä³\tëH²f\tD\u0096\u0097_à\u0010\u0081ÆÙ9\u008aúx³õ7ÝfçÎïô\u0010äZv¡;kg\u0083à¾-A\u0090¬º7 EZ:\u000fð»B\u000f*Å\u0093QD2®\u007f\u001c\u00ad^;\u0089ã×'2µ\u001d\u0012Æ®L\u0099(85Ï^\u0088AñÒù\u0015ÊÔ ì2\u001apXY\u009b5Yoà&\u009f·\u007fBÇ½\u0085\u008a\u0006âÃÙ1\u000bo\u0018ßYxð\u0088ãSæ\t)zV:þV\u008aPÑ\u009dG«i¹È P*3ý\u009aÊ\u0019\u0084wv¥·ZÛ\u0012\" 8&ßÕmo>\u0014(íÈ²p\u0088þ\u0018X~xOÌ©ù\u0016[(\u0098\u0097f>\u0084J}Ãvêø\u0096»b0,\u0080n@Q\u008fsFÈV\u0002ã\u0086ar+adñu+§&Ù\u009eÀÐajè\u0085n\u0088K\u0001ÙC¤Ð¿&\u0014yÅ\u0082\u009bþ\u0017 \u0002æÔ\r\u0097\u009a?í+b}JfWe «\u0099Ú\u0093\u0084È\u0016Q,qd\u0003\u0002|U¢(Ac\u0089ÑwË5Ú\u008d\u009c''ØÐ)$]\u0001cÛ\u0087\u0084äÁ\u008eÒ\u0093ÏÚh¼¾©aÉ\r\u0003\u00ad¶\u0091\u0010*\u0003£\u0004Ü\u009f/'\u00ad½9*\bi#3";
      short var6 = 2309;
      char var3 = '(';
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = c(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     c = var7;
                     h = new String[72];
                     c<"Þ">(new ArrayList(), -4892319953748666995L, var9);
                     友友友友友树何树何树 = new ArrayList<>();
                     何友树友友树树树何树 = new ArrayList<>();
                     友树友何树友何何何友 = new HashMap<>();
                     友何树何友树树何友何 = new HashMap<>();
                     c<"Þ">(0, -4893883103499947741L, var9);
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "695?\tÛc\u0082&7ó\u0018#\u0092Êä\u0010ð÷\u001b\u009e4\u0085\u00851Ø!d¾\u0085IÇ ";
                  var6 = 33;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   @EventTarget(0)
   public void C(SyncHandleReceivePacketEvent event) {
      long a = 140108623058341L;
      long ax = 125527250587045L;
      long axx = 52406761729175L;
      String axxx = c<"¥">(1560588943600076932L, a);
      if (!this.Q(new Object[]{axx})) {
         Packet<?> packet;
         boolean var10000;
         packet = event.getPacket();
         var10000 = packet instanceof ClientboundSystemChatPacket;
         label119:
         if (axxx != null) {
            label117: {
               if (var10000) {
                  ClientboundSystemChatPacket wrapper = (ClientboundSystemChatPacket)packet;
                  var10000 = wrapper.content().getString().isEmpty();
                  if (axxx != null) {
                     if (var10000) {
                        return;
                     }

                     var10000 = c<"Ï">(this, 1562229042790341749L, a).getValue();
                  }

                  if (axxx == null) {
                     break label119;
                  }

                  if (var10000) {
                     String message = wrapper.content().getString();
                     String playerName = mc.player.getGameProfile().getName();
                     var10000 = message.contains("<");
                     if (axxx != null) {
                        if (var10000) {
                           return;
                        }

                        var10000 = message.contains(b<"a">(10369, 8344580596547285549L));
                     }

                     if (axxx == null) {
                        break label119;
                     }

                     if (var10000) {
                        c<"Þ">(c<"r">(1562561539180648601L, a) + 1, 1562561539180648601L, a);
                        ClientUtils.P(ax, b<"a">(28826, 5679981379789892215L) + c<"r">(1562561539180648601L, a));
                        var10000 = c<"Ï">(this, 1562148424777091842L, a).getValue();
                        label110:
                        if (axxx != null) {
                           if (var10000) {
                              var10000 = c<"Ï">(this, 1562229042790341749L, a).getValue();
                              if (axxx == null) {
                                 break label110;
                              }

                              if (var10000) {
                                 mc.getConnection().sendCommand(b<"a">(17597, 5053354723648740887L));
                              }
                           }

                           var10000 = message.contains(playerName);
                        }

                        if (axxx == null) {
                           break label119;
                        }

                        if (var10000) {
                           var23 = mc.getConnection();
                           if (axxx == null) {
                              break label117;
                           }

                           if (var23 != null) {
                              var10000 = c<"Ï">(this, 1558826081586362229L, a).getValue();
                              if (axxx == null) {
                                 break label119;
                              }

                              if (var10000) {
                                 var10000 = c<"Ï">(this, 1562229042790341749L, a).getValue();
                                 if (axxx == null) {
                                    break label119;
                                 }

                                 if (var10000) {
                                    Connection networkManager = mc.getConnection().getConnection();
                                    networkManager.disconnect(Component.literal(b<"a">(6733, 4033509629328048315L)));
                                 }
                              }
                           }
                        }
                     }
                  }
               }

               var23 = c<"Ï">(this, 1558949174603180153L, a).getValue();
            }

            var10000 = (Boolean)var23;
         }

         label127: {
            if (axxx != null) {
               if (!var10000) {
                  return;
               }

               var24 = packet;
               if (axxx == null) {
                  break label127;
               }

               var10000 = packet instanceof ClientboundAddEntityPacket;
            }

            if (!var10000) {
               return;
            }

            var24 = packet;
         }

         ClientboundAddEntityPacket packet2 = (ClientboundAddEntityPacket)var24;
         if (packet2.getType() == c<"r">(1558900373123680025L, a)) {
            Vec3 var20 = new Vec3(packet2.getX(), packet2.getY(), packet2.getZ());
            Vec3 var21 = mc.player.position();
            double distance = var21.distanceTo(var20);
            String var25 = String.format(b<"a">(14475, 8355919817372426790L), c<"Ï">(var20, 1562482682893222725L, a));
            String var10001 = String.format(b<"a">(29417, 214972512384460852L), c<"Ï">(var20, 1561747054211876472L, a));
            String var10002 = String.format(b<"a">(29417, 214972512384460852L), c<"Ï">(var20, 1562327433933491497L, a));
            int axxxx = (int)distance;
            String axxxxx = var10002;
            String axxxxxx = var10001;
            String var18 = var25;
            ClientUtils.P(
               ax,
               b<"a">(2089, 5983202901071483616L)
                  + var18
                  + b<"a">(24008, 1056960663099049736L)
                  + axxxxxx
                  + b<"a">(23563, 8207896733887203049L)
                  + axxxxx
                  + b<"a">(584, 8841480875659483367L)
                  + axxxx
                  + b<"a">(29433, 5900656715184318501L)
            );
         }
      }
   }

   public static boolean I(Player player) {
      long a = 38380838287158L;
      return l(player, c<"r">(8592232090620238352L, a));
   }

   public static boolean S(Player player) {
      long a = 132290307039239L;
      return l(player, c<"r">(2308144330245376288L, a));
   }

   public static boolean Z(Player player) {
      long a = 129872161475648L;
      String var10000 = c<"¥">(886463741914730849L, a);
      Set items = (Set)c<"r">(886366451205810202L, a).get(player);
      String ax = var10000;
      Set var5 = items;
      if (ax != null) {
         if (items == null) {
            return false;
         }

         var5 = items;
      }

      boolean var6 = var5.contains(b<"a">(25760, 397128410207469168L));
      return ax == null ? var6 : var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 4;
               case 1 -> 33;
               case 2 -> 28;
               case 3 -> 29;
               case 4 -> 11;
               case 5 -> 44;
               case 6 -> 9;
               case 7 -> 12;
               case 8 -> 40;
               case 9 -> 38;
               case 10 -> 37;
               case 11 -> 61;
               case 12 -> 51;
               case 13 -> 16;
               case 14 -> 26;
               case 15 -> 41;
               case 16 -> 24;
               case 17 -> 35;
               case 18 -> 2;
               case 19 -> 27;
               case 20 -> 25;
               case 21 -> 14;
               case 22 -> 45;
               case 23 -> 3;
               case 24 -> 10;
               case 25 -> 0;
               case 26 -> 30;
               case 27 -> 52;
               case 28 -> 39;
               case 29 -> 49;
               case 30 -> 22;
               case 31 -> 55;
               case 32 -> 13;
               case 33 -> 23;
               case 34 -> 15;
               case 35 -> 32;
               case 36 -> 62;
               case 37 -> 1;
               case 38 -> 58;
               case 39 -> 19;
               case 40 -> 63;
               case 41 -> 48;
               case 42 -> 43;
               case 43 -> 18;
               case 44 -> 8;
               case 45 -> 34;
               case 46 -> 5;
               case 47 -> 59;
               case 48 -> 42;
               case 49 -> 7;
               case 50 -> 46;
               case 51 -> 31;
               case 52 -> 20;
               case 53 -> 47;
               case 54 -> 57;
               case 55 -> 6;
               case 56 -> 17;
               case 57 -> 60;
               case 58 -> 54;
               case 59 -> 53;
               case 60 -> 50;
               case 61 -> 36;
               case 62 -> 56;
               default -> 21;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               if (var10 < 0) {
                  var10 += 128;
               }

               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var15 = var7[var13 % var7.length];
               if (var15 == 0) {
                  break;
               }

               var12[var13] = (char)(var12[var13] ^ var15);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树树何树友何何何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23275;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            var4 = (Object[])i.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               i.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/树树何树友何何何何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u009cÖ\u001cé\u0002b\u0082ã\"\u0012ÿ½[\u0012HÎ6øk\u000fCÉRL, |CÊÉ'J\u0090")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树树何树友何何何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         MethodHandle var9;
         if (var8 != 207 && var8 != 202 && var8 != 'r' && var8 != 222) {
            var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 235) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 165) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 207) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'r') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName())
            .append(" : ")
            .append(var10 != null ? var10.toString() : (var11 != null ? var11.toString() : " null "))
            .append(" : ")
            .append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @Override
   public void h() {
      long a = 134075062536118L;
      c<"r">(-4056687464518504924L, a).clear();
      c<"r">(-4054848316576379609L, a).clear();
      c<"r">(-4056845651518702205L, a).clear();
      c<"r">(-4055287527913584904L, a).clear();
      c<"r">(-4054631123835755540L, a).clear();
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      Method var5 = e(var0, var1, var2, var3, var4);
      if (var5 != null) {
         return var5;
      } else {
         Class[] var6 = var0.getInterfaces();
         if (var6 != null) {
            for (int var7 = 0; var7 < var6.length; var7++) {
               var5 = f(var6[var7], var1, var2, var3, var4);
               if (var5 != null) {
                  return var5;
               }
            }
         }

         return null;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      Field var3 = e(var0, var1, var2);
      if (var3 != null) {
         return var3;
      } else {
         Class[] var4 = var0.getInterfaces();
         if (var4 != null) {
            for (int var5 = 0; var5 < var4.length; var5++) {
               var3 = f(var4[var5], var1, var2);
               if (var3 != null) {
                  return var3;
               }
            }
         }

         return null;
      }
   }

   public static boolean l(Player player, Item item) {
      long a = 85947835532682L;
      String var4 = c<"¥">(-4213291007121385301L, a);
      Item var10000 = player.getMainHandItem().getItem();
      Item var10001 = item;
      if (var4 != null) {
         if (var10000 == item) {
            return true;
         }

         var10000 = player.getOffhandItem().getItem();
         var10001 = item;
      }

      return var10000 == var10001;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Class var23 = var8;

         while (true) {
            Method var25 = e(var23, var10, var15, var13, var14);
            if (var25 != null) {
               j[var4] = var25;
               return var25;
            }

            if (var23.getName().equals("java.lang.Object")) {
               break;
            }

            if ((var23 = var23.getSuperclass()) == null) {
               j(1419459367068109L, 0L);
               break;
            }
         }

         var23 = var8;

         while (true) {
            Class[] var26;
            if ((var26 = var23.getInterfaces()) != null) {
               for (int var18 = 0; var18 < var26.length; var18++) {
                  Method var19 = f(var26[var18], var10, var15, var13, var14);
                  if (var19 != null) {
                     j[var4] = var19;
                     return var19;
                  }
               }
            }

            if (var23.getName().equals("java.lang.Object")) {
               StringBuffer var27 = new StringBuffer();
               var27.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
               int var28 = 0;

               while (var28 < var13) {
                  var27.append(var14[var28].getName());
                  if (++var28 < var13) {
                     var27.append(", ");
                  }
               }

               var27.append(')');
               throw new RuntimeException(var27.toString());
            }

            if ((var23 = var23.getSuperclass()) == null) {
               var23 = j(1419459367068109L, 0L);
            }
         }
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = ")$#[\n{)$4\u0007\u0006t3o \u001a\u0015~#o>\u0001\u0002\u007fi\b#\u0010\na";
      j[1] = "cTpMO^cTg\u0011CQy\u001fs\fP[i\u001fm\u0017GZ#xp\u0006O";
      j[2] = "\u0016~FTz$\u0019>\u000b_p9\u001cc\u0000\u0019x$\u0011e\u0004R;\"\u0018`\u0004\u0019x\"\u0006sF栦栄伞桤叛伽佢佀伞桤";
      j[3] = "\u000eF\u0015C\u000fU\u0005I\u0004\fsL\nS\nOD|\u001cD\u0006RUP\u000bI";
      j[4] = "?9\u0007]3d0yJV9y5$A\u00101d8\"E[rb1'E\u00101b/4\u0007佫桍叀桍伂佼佫桍佞伉";
      j[5] = "ETN8:\\N[_wGD]\\V>";
      j[6] = "Q\b_J\u001bKO\u0000E\u0005x_K";
      j[7] = "\n\u0004@:I\u0010\u0014\fZu+\f\u0013\u0011";
      j[8] = "\u007fYeT^\u000b\u007fYr\bR\u0004e\u0012f\u0015A\u000eu\u0012t\u001cU\u0007rH?7\\\u0000TZw\u001fP\u0016b";
      j[9] = "?\u0011!\u0014Xv?\u00116HTy%Z\"UGs5Z0\\Sz2\u0000{wZ}\u0014\u00123_Vk";
      j[10] = int.class;
      k[10] = "java/lang/Integer";
      j[11] = "\u0002wNw1,\u0002wY+=#\u0018<M6.)\b<J1%6BD_:o";
      j[12] = double.class;
      k[12] = "java/lang/Double";
      j[13] = "$WIba/+\u0017\u0004ik2.J\u000f/x!+L\u0002/g-7UICa/+\\\u0006oX!+L\u0002";
      j[14] = "!Q\n>p\f!Q\u001db|\u0003;\u001a\t\u007fo\t+\u001a\u001b~i\f;MPUs\u0011&@\u0007Dd\u0015*";
      j[15] = "EY\u0012\u0000VnEY\u0005\\Za_\u0012\u0005BRbEHH^WfRY\u0014\u0000whH]\n~WfRY\u0014";
      j[16] = "e\r4Z0{jMyQ:fo\u0010r\u00172{b\u0016v\\q栅体厨发佬桎叟反伶住";
      j[17] = "}1[\u0014'^rq\u0016\u001f-Cw,\u001dY%^z*\u0019\u0012f|q;\u0000\u001b-";
      j[18] = "\u00019K\u0011T+5\u001aDQ\u0019 ?\u0007A\f\u0012f7\u001aL\n\u0016-t8G\u001b\u000f$?N";
      j[19] = void.class;
      k[19] = "java/lang/Void";
      j[20] = ")_\b&\t]\"P\u0019ihS)[\u001d3";
      j[21] = "\u0001_2T\u0016YT\\/\nz佦司桿厏厬档栢栢伻桕oG\u0007\n\u00024\u0017\u0007XT\u001b";
      j[22] = "\u0006nt1*gSmioF佘栥厔栓栓伛叆栥厔佗\n{9\r3rr;fS*";
      j[23] = "\u0005\u0002\"\u000f\u000b3\u0001W}n\u0014\u0015_\u0000~WE\u0015c\u0003-S\b:\u0005J-\u0002\u0013";
      j[24] = "/\n\u0014j9Fz\t\t4U叧佈佮厩厒桌叧栌株厩Qd\u0015.IW=i\u001b+\r";
      j[25] = "a$9~1\u00101d/}T\u0017\b$n9lA\b\u001dahl\u0003`e1h3\u001e";
      j[26] = "}\u0002qE3byW.$,D'\u0000-\u0018}D\u001b\u0003~\u00190k}J~H+";
      j[27] = "rJ51LB'I(o 口压伮伖栓佽根桑厰厈\n\u0011\u0011s\tvf\u001c\u001fvM";
      j[28] = "ef'\u0014\u000eGl(r\u0011`\u0019\u0003\"z\u0016^J\u0003\u0018sT\u0005I:(z\u001aPL";
      j[29] = "\nB3muv_A.3\u0019受佭伦桔桏栀受佭伦伐V(%\u000b\u0001p:%+\u000eE";
      j[30] = "C\u0006\u0001\\4?\u0016VP[\u000b\u0004(\u0005V[`,B\u0000\u001eTpV";
      j[31] = "j|>#\u0002-?\u007f#}n伒伍历伝叛厭桖桉历桙\u0018_~k?}tRpn{";
      j[32] = "\r]eN\u0002B\t\b:/\u001ddW_=\u001fCdk\\j\u0012\u0001K\r\u0015jC\u001a";
      j[33] = "\u0007D-v5uRG0(Y叔栤桤伎伐厚栎栤桤厐Mh&\u0006\u0007n!e(\u0003C";
      j[34] = ".ZF=\u001a\u0002{Y[cv桹栍伾校叅伫桹受厠叻\u0006GQ/\u0019\u0005jJ_*]";
      j[35] = "\u0010p\u0016Z9\\Es\u000b\u0004U佣叩伔桱桸伈佣佷桐桱ad\u000f\u00113U\ri\u0001\u0014w";
      j[36] = "cq\u0017&m)c+\u00076\u0002&\u0004\u007fPz2p\u0004OZ9:%l\u007fT%iv";
      j[37] = "<\"$vGbi!9(+佝叅变厙桔栲參叅栂厙M\u001a1=ag!\u0017?8%";
      j[38] = "1A\u0013\"CY#I@l?\f\u000f\nO!\u000e]\u000f3A#@\b)Y\u0011xN_";
      j[39] = "\u0018C-\u0003:MH\u0003;\u0000_JqCzDg\u0019qzu\u0015g^\u0019\u0002%\u00158C";
      j[40] = ",\u0003:q\u0011}y\u0000'/}叜栏叹厇厉传栆叕栣伙JB\"iP5 \u0012yg\u0007";
      j[41] = "\u000b\u0018w(aP\u000bBg8\u000e_l\u00160t1\u0000l&:76\\\u0004\u00164+e\u000f";
      j[42] = "z\u000fEF\u0013z/\fX\u0018\u007f叛伝叵栢桤伢叛厃叵佦}E!>\rW\u001f\u0010\"#S";
      j[43] = "ld\n4S\u000eh1UUL(6fRd\u001c(\ne\u0005hP\u0007l,\u00059K";
      j[44] = "nbGRig;aZ\f\u0005叆厗厘佤厪栜栜桍伆叺i44o!\u0004\u00059:je";
      j[45] = "m\"tP\u0002I8!i\u000en佶伊但佗伶伳叨桎变栓k_\u001ala7\u0007R\u0014i%";
      j[46] = "2_^1>j6\n\u0001P!Lh]\u0003itLT^Qm=c2\u0017Q<&";
      j[47] = "P\u0012\u0014\u0007{\u001ePH\u0004\u0017\u0014\u00117\u001cS[$F7,Y\u0018,\u0012_\u001cW\u0004\u007fA";
      j[48] = "_`8V\u00064\nc%\bj厕厦厚厅厮桳伋桼伄桟mWjT=>\u0015\u00175\n$";
      j[49] = "=Vf\u001eB>hU{@.桅佚厬栁格佳桅佚伲栁%\u001fm<\u0015%I\u0012c9Q";
      j[50] = "B(m\u0019q\n\u0017+pG\u001d\u0001x+|[pU\u0006t.EdhB~jO \u0016\u001d,t[\u001d";
      j[51] = "\u000eYAlF\\\u000e\u0001\\%~厠桽佡口伊桧桺桽栥佽W\u0014\u0006\u0005\u0007\u0018h\u0014^\u0018N";
      j[52] = "ve#\\\u001b\u0017vl,\u0014u\u0005L.)\u001bD\u0016vu#NLl";
      j[53] = "rT xsC'W=&\u001f叢伕桴伃厀栆核伕厮伃C#G2\u0001c\"xKp\u0012";
      j[54] = "\u0006o\u0007\r+/\u0006f\bEE&<$\rJt.\u0006\u007f\u0007\u001f|TP~\u001d\u00059lBeG\u0016E";
      j[55] = "(O!Zd\u001d,\u001a~;{;rM~\u0002,;NN.\u0006g\u0014(\u0007.W|";
      j[56] = "E\u001c6mjA\u0010\u001f+3\u0006叠厼佸伕伋佛叠桦格桑V7\u0012D_u::\u001cA\u001b";
      j[57] = "~y7\u0005lKz,hdsm${oU$m\u0018x8YoB~18\bt";
      j[58] = "\u000e\u0014lG[\u000b[\u0017q\u00197伴佩叮栋伡叴厪号佰住|\u0006X\u000fW/\u0010\u000bV\n\u0013";
      j[59] = "UM\n\f<N\u0000N\u0017RP可桶厷伩栮厓佱伲伩厷7lJ\u0015\u0018IV7FW\u000b";
      j[60] = "h'5D\u0015{=$(\u001ay佄伏佃伖桦桠叚厑标伖\u007fH(idv\u0013E&l ";
      j[61] = "s\u0015o1=`w@0P\"F)\u00171i|F\u0015\u0014`m>is]`<%";
   }

   private void m(Player player) {
      long a;
      String ax;
      Set playerReportedItems;
      boolean var11;
      a = 120407682473885L;
      String var10000 = c<"¥">(6886075913662759612L, a);
      playerReportedItems = c<"r">(6887038509312253651L, a).computeIfAbsent(player, k -> new HashSet());
      ax = var10000;
      var11 = c<"Ï">(this, 6887471200326967505L, a).getValue();
      label224:
      if (ax != null) {
         if (var11) {
            var11 = this.y(player);
            if (ax == null) {
               break label224;
            }

            if (var11) {
               var11 = playerReportedItems.contains(b<"a">(19525, 1118587367615731373L));
               if (ax == null) {
                  break label224;
               }

               if (!var11) {
                  this.k(player, b<"a">(26467, 4672057589062811065L));
                  playerReportedItems.add(b<"a">(30021, 5464484913755565952L));
               }
            }
         }

         var11 = c<"Ï">(this, 6889265263700275197L, a).getValue();
      }

      label214:
      if (ax != null) {
         if (var11) {
            var11 = this.q(player);
            if (ax == null) {
               break label214;
            }

            if (var11) {
               var11 = playerReportedItems.contains(b<"a">(26361, 5755854177393753149L));
               if (ax == null) {
                  break label214;
               }

               if (!var11) {
                  this.k(player, b<"a">(11052, 277742470547796469L));
                  playerReportedItems.add(b<"a">(23358, 9021702950934315487L));
               }
            }
         }

         var11 = c<"Ï">(this, 6889214916802830544L, a).getValue();
      }

      label204:
      if (ax != null) {
         if (var11) {
            var11 = G(player);
            if (ax == null) {
               break label204;
            }

            if (var11) {
               var11 = playerReportedItems.contains(b<"a">(17819, 5062886948048150325L));
               if (ax == null) {
                  break label204;
               }

               if (!var11) {
                  this.k(player, b<"a">(26670, 19373404967318227L));
                  playerReportedItems.add(b<"a">(25760, 397128410207469168L));
                  Set<String> items = c<"r">(6886032468988361671L, a).computeIfAbsent(player, k -> new HashSet<>());
                  items.add(b<"a">(25760, 397128410207469168L));
               }
            }
         }

         var11 = c<"Ï">(this, 6886670057119600089L, a).getValue();
      }

      label194:
      if (ax != null) {
         if (var11) {
            var11 = S(player);
            if (ax == null) {
               break label194;
            }

            if (var11) {
               var11 = playerReportedItems.contains(b<"a">(16444, 2901847153412676324L));
               if (ax == null) {
                  break label194;
               }

               if (!var11) {
                  this.k(player, b<"a">(24722, 2627984712583887424L));
                  playerReportedItems.add(b<"a">(25089, 8680788780241369326L));
                  Set<String> items = c<"r">(6886032468988361671L, a).computeIfAbsent(player, k -> new HashSet<>());
                  items.add(b<"a">(25089, 8680788780241369326L));
               }
            }
         }

         var11 = c<"Ï">(this, 6887805123974335284L, a).getValue();
      }

      label184:
      if (ax != null) {
         if (var11) {
            var11 = w(player);
            if (ax == null) {
               break label184;
            }

            if (var11) {
               var11 = playerReportedItems.contains(b<"a">(10448, 2431472788672901683L));
               if (ax == null) {
                  break label184;
               }

               if (!var11) {
                  this.k(player, b<"a">(7004, 6224976402797445554L));
                  playerReportedItems.add(b<"a">(10448, 2431472788672901683L));
                  Set<String> items = c<"r">(6886032468988361671L, a).computeIfAbsent(player, k -> new HashSet<>());
                  items.add(b<"a">(10448, 2431472788672901683L));
               }
            }
         }

         var11 = c<"Ï">(this, 6887103178064836845L, a).getValue();
      }

      label174:
      if (ax != null) {
         if (var11) {
            var11 = t(player);
            if (ax == null) {
               break label174;
            }

            if (var11) {
               var11 = playerReportedItems.contains(b<"a">(17896, 8233906474579205917L));
               if (ax == null) {
                  break label174;
               }

               if (!var11) {
                  this.k(player, b<"a">(14010, 8350047805625035841L));
                  playerReportedItems.add(b<"a">(26841, 7790871796704719423L));
                  Set<String> items = c<"r">(6886032468988361671L, a).computeIfAbsent(player, k -> new HashSet<>());
                  items.add(b<"a">(26841, 7790871796704719423L));
               }
            }
         }

         var11 = c<"Ï">(this, 6886334497302053105L, a).getValue();
      }

      label164:
      if (ax != null) {
         if (var11) {
            var11 = I(player);
            if (ax == null) {
               break label164;
            }

            if (var11) {
               var11 = playerReportedItems.contains(b<"a">(8260, 7079864267929942662L));
               if (ax == null) {
                  break label164;
               }

               if (!var11) {
                  this.k(player, b<"a">(5054, 7950224321328531794L));
                  playerReportedItems.add(b<"a">(23220, 725038557710286954L));
                  Set<String> items = c<"r">(6886032468988361671L, a).computeIfAbsent(player, k -> new HashSet<>());
                  items.add(b<"a">(23220, 725038557710286954L));
               }
            }
         }

         var11 = c<"Ï">(this, 6887178865193714237L, a).getValue();
      }

      label154:
      if (ax != null) {
         if (var11) {
            var11 = this.E(player);
            if (ax == null) {
               break label154;
            }

            if (var11) {
               var11 = playerReportedItems.contains(b<"a">(23997, 518900443388381002L));
               if (ax == null) {
                  break label154;
               }

               if (!var11) {
                  this.o(player);
                  playerReportedItems.add(b<"a">(8892, 7479047623406909543L));
               }
            }
         }

         var11 = c<"Ï">(this, 6887564541013332847L, a).getValue();
      }

      if (ax != null) {
         if (!var11) {
            return;
         }

         var11 = this.M(player);
      }

      if (ax != null) {
         if (!var11) {
            return;
         }

         var11 = playerReportedItems.contains(b<"a">(10546, 8651928687060906966L));
      }

      if (ax != null && !var11) {
         this.H(player);
         playerReportedItems.add(b<"a">(379, 8620635991227947913L));
      }
   }

   public static boolean m(Entity entity) {
      long a = 113807132904640L;
      String var3 = c<"¥">(-3689209453290155551L, a);
      boolean var10000 = entity instanceof Player;
      if (var3 != null) {
         if (!var10000) {
            return false;
         }

         var10000 = c<"r">(-3689478880363755951L, a).contains(entity);
      }

      return var3 == null ? var10000 : var10000;
   }

   private void o(Player player) {
      long a = 82841006089034L;
      long ax = 125527250587045L;
      String axx = c<"¥">(-6681257884599714197L, a);
      boolean var10000 = c<"r">(-6678852980531508520L, a).contains(player);
      if (axx != null) {
         if (!var10000) {
            c<"r">(-6678852980531508520L, a).add(player);
         }

         var10000 = c<"r">(-6681518480180925989L, a).contains(player);
      }

      if (axx != null) {
         if (var10000) {
            return;
         }

         c<"r">(-6681518480180925989L, a).add(player);
      }

      String playerName = player.getName().getString();
      ClientUtils.P(ax, b<"a">(24800, 766375971160504852L) + playerName);
   }

   public static boolean p(Player player) {
      long a = 76228902303134L;
      String var10000 = c<"¥">(-5362826896809727809L, a);
      Set items = (Set)c<"r">(-5362886806291639868L, a).get(player);
      String ax = var10000;
      Set var5 = items;
      if (ax != null) {
         if (items == null) {
            return false;
         }

         var5 = items;
      }

      boolean var6 = var5.contains(b<"a">(26841, 7790871796704719423L));
      return ax == null ? var6 : var6;
   }

   @EventTarget
   public void p(TickEvent e) {
      long a = 100886882043950L;
      long ax = 52406761729175L;
      String axx = c<"¥">(5198130113742247183L, a);
      if (!this.Q(new Object[]{ax})) {
         Minecraft var10000 = mc;
         if (axx != null) {
            if (mc.player == null) {
               return;
            }

            var10000 = mc;
         }

         ClientLevel var11 = var10000.level;
         if (axx != null) {
            if (var10000.level == null) {
               return;
            }

            var11 = mc.level;
         }

         label110: {
            int var12 = var11.players().isEmpty();
            if (axx != null) {
               if (var12 != 0) {
                  return;
               }

               var10000 = mc;
               if (axx == null) {
                  break label110;
               }

               var12 = c<"Ï">(mc.player, 5199372155265128001L, a) % 6;
            }

            if (var12 != 0) {
               return;
            }

            var10000 = mc;
         }

         Iterator var7 = var10000.level.players().iterator();

         while (true) {
            if (var7.hasNext()) {
               Player player = (Player)var7.next();
               if (axx == null) {
                  break;
               }

               label80: {
                  label114: {
                     boolean me = player != mc.player;
                     boolean sameTeam = this.K(player);
                     var14 = c<"Ï">(this, 5197293799927534207L, a).getValue();
                     label78:
                     if (axx != null) {
                        if (!var14) {
                           var14 = me;
                           if (axx == null) {
                              break label78;
                           }

                           if (me) {
                              var14 = sameTeam;
                              if (axx == null) {
                                 break label78;
                              }

                              if (!sameTeam) {
                                 this.m(player);
                              }
                           }
                        }

                        var15 = this;
                        if (axx == null) {
                           break label114;
                        }

                        var14 = c<"Ï">(this, 5197293799927534207L, a).getValue();
                     }

                     if (!var14) {
                        break label80;
                     }

                     var15 = this;
                  }

                  var15.m(player);
               }

               if (axx != null) {
                  continue;
               }
            }

            this.X(c<"Ï">(this, 5197293799927534207L, a).getValue() ? b<"a">(9232, 7624866894059405015L) : b<"a">(9035, 1486801787093350787L));
            break;
         }
      }
   }

   private void k(Player player, String message) {
      long a = 48815413627220L;
      long ax = 125527250587045L;
      String var7 = c<"¥">(-8549801970465385355L, a);
      if (var7 != null) {
         if (!c<"r">(-8551889651541843770L, a).contains(player)) {
            c<"r">(-8551889651541843770L, a).add(player);
         }

         ClientUtils.P(ax, b<"a">(19132, 338164573648949324L) + player.getName().getString() + " " + message);
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Field)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Class var12 = var8;

         while (true) {
            Field var13 = e(var12, var10, var11);
            if (var13 != null) {
               j[var4] = var13;
               return var13;
            }

            Class[] var14 = var12.getInterfaces();
            if (var14 != null) {
               for (int var15 = 0; var15 < var14.length; var15++) {
                  var13 = f(var14[var15], var10, var11);
                  if (var13 != null) {
                     j[var4] = var13;
                     return var13;
                  }
               }
            }

            if (var12.getName().equals("java.lang.Object")) {
               StringBuffer var19 = new StringBuffer();
               var19.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
               throw new RuntimeException(var19.toString());
            }

            var12 = var12.getSuperclass();
            if (var12 == null) {
               var12 = j(1419459367068109L, 0L);
            }
         }
      }
   }

   public static boolean t(Player player) {
      long a = 18995803771418L;
      return l(player, c<"r">(-3305684420093558174L, a));
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean q(Player player) {
      long a = 67581767851978L;
      return player.hasEffect(c<"r">(2288936263201696266L, a));
   }

   public static boolean w(Player player) {
      long a = 31481402043676L;
      return l(player, c<"r">(3250099722991699007L, a));
   }

   private boolean y(Player player) {
      long a = 78960215734351L;
      return player.hasEffect(c<"r">(4055813456664349492L, a));
   }

   private boolean E(Player player) {
      long a = 102926852199381L;
      return l(player, c<"r">(-7791933491718569418L, a));
   }

   public static boolean Y(Player player) {
      long a = 110303780588864L;
      String var10000 = c<"¥">(-3653184146736246687L, a);
      Set items = (Set)c<"r">(-3653241889373034214L, a).get(player);
      String ax = var10000;
      Set var5 = items;
      if (ax != null) {
         if (items == null) {
            return false;
         }

         var5 = items;
      }

      boolean var6 = var5.contains(b<"a">(25089, 8680788780241369326L));
      return ax == null ? var6 : var6;
   }

   @EventTarget
   public void X(WorldEvent e) {
      long a = 80554528228855L;
      c<"r">(5040355424867167333L, a).clear();
      c<"r">(5042756440422109030L, a).clear();
      c<"r">(5040091949157072834L, a).clear();
      c<"r">(5042212758306686137L, a).clear();
      c<"r">(5042411774141620653L, a).clear();
   }

   private int L(Player player, boolean returnLevel) {
      long a = 112129622848984L;
      String var5 = c<"¥">(-5344284059389597447L, a);
      byte var10000 = player.hasEffect(c<"r">(-5345289061211373544L, a));
      if (var5 != null) {
         if (var10000 != 0) {
            return player.getEffect(c<"r">(-5345289061211373544L, a)).getAmplifier() + 1;
         }

         var10000 = 0;
      }

      return var10000;
   }

   private boolean M(Player player) {
      long a = 131121722720287L;
      String ax = c<"¥">(-9218205103072289474L, a);
      Player var10000 = player;
      if (ax != null) {
         if (l(player, c<"r">(-9218097799958305395L, a))) {
            return true;
         }

         var10000 = player;
      }

      String playerName = var10000.getName().getString().toLowerCase();
      boolean var6 = playerName.contains(b<"a">(379, 8620635991227947913L));
      if (ax != null) {
         if (!var6) {
            boolean var7 = playerName.contains(b<"a">(2561, 1440656116310626536L));
            if (ax == null) {
               return var7;
            }

            if (!var7) {
               return false;
            }
         }

         var6 = true;
      }

      return var6;
   }

   public static boolean P(Player player) {
      long a = 125005387280963L;
      String var10000 = c<"¥">(3624937815179947874L, a);
      Set items = (Set)c<"r">(3624841589635618329L, a).get(player);
      String ax = var10000;
      Set var5 = items;
      if (ax != null) {
         if (items == null) {
            return false;
         }

         var5 = items;
      }

      boolean var6 = var5.contains(b<"a">(23220, 725038557710286954L));
      return ax == null ? var6 : var6;
   }

   public static boolean W(Player player) {
      long a = 41112169044510L;
      String var10000 = c<"¥">(6490541836948539199L, a);
      Set items = (Set)c<"r">(6490622667119689284L, a).get(player);
      String ax = var10000;
      Set var5 = items;
      if (ax != null) {
         if (items == null) {
            return false;
         }

         var5 = items;
      }

      boolean var6 = var5.contains(b<"a">(27623, 1520616490714378496L));
      return ax == null ? var6 : var6;
   }

   private void H(Player player) {
      long a = 5698807479034L;
      long ax = 125527250587045L;
      String axx = c<"¥">(4248910005769562075L, a);
      boolean var10000 = c<"r">(4251324246128907112L, a).contains(player);
      if (axx != null) {
         if (!var10000) {
            c<"r">(4251324246128907112L, a).add(player);
         }

         var10000 = c<"r">(4251200693748056271L, a).contains(player);
      }

      if (axx != null) {
         if (var10000) {
            return;
         }

         c<"r">(4251200693748056271L, a).add(player);
      }

      String playerName = player.getName().getString();
      ClientUtils.P(ax, b<"a">(25140, 6771824092093561083L) + playerName);
   }

   private boolean K(Player player) {
      return false;
   }

   private static String HE_JIAN_GUO() {
      return "刘凤楠230622109211173513";
   }

   public static boolean G(Player player) {
      long a = 20470123626298L;
      String var10000 = c<"¥">(9166864370593440283L, a);
      ItemStack mainHand = player.getMainHandItem();
      ItemStack offHand = player.getOffhandItem();
      String ax = var10000;
      Item var6 = mainHand.getItem();
      Item var10001 = c<"r">(9166043329001122288L, a);
      if (ax != null) {
         if (var6 == var10001) {
            return true;
         }

         var6 = mainHand.getItem();
         var10001 = c<"r">(9165048746448768650L, a);
      }

      if (ax != null) {
         if (var6 == var10001) {
            return true;
         }

         var6 = offHand.getItem();
         var10001 = c<"r">(9166043329001122288L, a);
      }

      if (ax != null) {
         if (var6 == var10001) {
            return true;
         }

         var6 = offHand.getItem();
         var10001 = c<"r">(9165048746448768650L, a);
      }

      return var6 == var10001;
   }

   private int G(Player player, boolean returnLevel) {
      long a = 34065671778875L;
      String var5 = c<"¥">(-993550634917974246L, a);
      byte var10000 = player.hasEffect(c<"r">(-991497862663274176L, a));
      if (var5 != null) {
         if (var10000 != 0) {
            return player.getEffect(c<"r">(-991497862663274176L, a)).getAmplifier() + 1;
         }

         var10000 = 0;
      }

      return var10000;
   }

   public static boolean O(Entity entity) {
      long a = 74241966467834L;
      String var3 = c<"¥">(-1515620117850638373L, a);
      boolean var10000 = entity instanceof Player;
      if (var3 != null) {
         if (!var10000) {
            return false;
         }

         var10000 = c<"r">(-1513479770932539185L, a).contains(entity);
      }

      return var3 == null ? var10000 : var10000;
   }
}
