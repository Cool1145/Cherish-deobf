package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.packet.SyncHandleReceivePacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public class 何友友友树树树树树树 extends Module implements 何树友 {
   public static 何友友友树树树树树树 何友友何何友友何何何;
   private final BooleanValue 树树树树何树树何友友;
   private final BooleanValue 树何友树何友树何树何;
   private final BooleanValue 树友友何树友何何树友;
   private final BooleanValue 树何何何树友何树树何;
   private final BooleanValue 何树何树树友树友树何;
   private final BooleanValue 何友树何树何树树友何;
   private final BooleanValue 树树友友友友树友何友;
   private final BooleanValue 友何何友何友何何树何;
   private final BooleanValue 友何树友何树树树何何;
   private final BooleanValue 友树友何友友友何何友;
   private final BooleanValue 树友友何树树友树何友;
   private final BooleanValue 树何友何树友友何何何;
   private final BooleanValue 树树何树树何何树友树;
   private final BooleanValue 何何树树树何何何友何;
   public static List<Entity> 何友何友何树友树友树;
   private static final List<Player> 友树何何树树何何树何;
   private static final List<Player> 友友何树树树何何友树;
   private static final Map<Player, Set<String>> 何树友何友友友友何友;
   private static final Map<Player, Set<String>> 友友树何何何树树树友;
   public static int 何友树何树友何何友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[62];
   private static final String[] k = new String[62];
   private static String LIU_YA_FENG;

   public 何友友友树树树树树树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:200)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/misc/何友友友树树树树树树.a J
      // 003: ldc2_w 89647211420170
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 13718
      // 00c: ldc2_w 428878172300889060
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 2663
      // 019: ldc2_w 4279311234844357659
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w -3679569132609615146
      // 026: lload 1
      // 027: invokedynamic Ì (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: ldc2_w -3683799153565063218
      // 032: lload 1
      // 033: invokedynamic ß (JJ)I bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 038: aload 0
      // 039: new cn/cool/cherish/value/impl/BooleanValue
      // 03c: dup
      // 03d: sipush 6488
      // 040: ldc2_w 3757366369489446766
      // 043: lload 1
      // 044: lxor
      // 045: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04a: sipush 22125
      // 04d: ldc2_w 8304200994470733854
      // 050: lload 1
      // 051: lxor
      // 052: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 057: bipush 1
      // 058: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 05b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 05e: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.树树树树何树树何友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 061: istore 3
      // 062: aload 0
      // 063: new cn/cool/cherish/value/impl/BooleanValue
      // 066: dup
      // 067: sipush 9588
      // 06a: ldc2_w 6632911996245891845
      // 06d: lload 1
      // 06e: lxor
      // 06f: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 074: sipush 29105
      // 077: ldc2_w 1292635297699172313
      // 07a: lload 1
      // 07b: lxor
      // 07c: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 081: bipush 1
      // 082: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 085: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 088: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.树何友树何友树何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 08b: aload 0
      // 08c: new cn/cool/cherish/value/impl/BooleanValue
      // 08f: dup
      // 090: sipush 5872
      // 093: ldc2_w 1508449796269729986
      // 096: lload 1
      // 097: lxor
      // 098: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09d: sipush 30677
      // 0a0: ldc2_w 7835034344780138900
      // 0a3: lload 1
      // 0a4: lxor
      // 0a5: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0aa: bipush 1
      // 0ab: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0ae: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0b1: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.树友友何树友何何树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0b4: aload 0
      // 0b5: new cn/cool/cherish/value/impl/BooleanValue
      // 0b8: dup
      // 0b9: sipush 15022
      // 0bc: ldc2_w 2677995984328836305
      // 0bf: lload 1
      // 0c0: lxor
      // 0c1: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c6: sipush 20824
      // 0c9: ldc2_w 1666916974349594386
      // 0cc: lload 1
      // 0cd: lxor
      // 0ce: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d3: bipush 1
      // 0d4: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0d7: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0da: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.树何何何树友何树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0dd: aload 0
      // 0de: new cn/cool/cherish/value/impl/BooleanValue
      // 0e1: dup
      // 0e2: sipush 17461
      // 0e5: ldc2_w 8169757968854268529
      // 0e8: lload 1
      // 0e9: lxor
      // 0ea: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ef: sipush 21191
      // 0f2: ldc2_w 4999784408524827791
      // 0f5: lload 1
      // 0f6: lxor
      // 0f7: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0fc: bipush 1
      // 0fd: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 100: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 103: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.何树何树树友树友树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 106: aload 0
      // 107: new cn/cool/cherish/value/impl/BooleanValue
      // 10a: dup
      // 10b: sipush 27638
      // 10e: ldc2_w 1111499860776621496
      // 111: lload 1
      // 112: lxor
      // 113: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 118: sipush 9764
      // 11b: ldc2_w 3482684328738641936
      // 11e: lload 1
      // 11f: lxor
      // 120: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 125: bipush 1
      // 126: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 129: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 12c: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.何友树何树何树树友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 12f: aload 0
      // 130: new cn/cool/cherish/value/impl/BooleanValue
      // 133: dup
      // 134: sipush 2942
      // 137: ldc2_w 4838694981966755121
      // 13a: lload 1
      // 13b: lxor
      // 13c: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 141: sipush 12775
      // 144: ldc2_w 8893822267713605529
      // 147: lload 1
      // 148: lxor
      // 149: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14e: bipush 1
      // 14f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 152: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 155: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.树树友友友友树友何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 158: aload 0
      // 159: new cn/cool/cherish/value/impl/BooleanValue
      // 15c: dup
      // 15d: sipush 23931
      // 160: ldc2_w 402998160730792766
      // 163: lload 1
      // 164: lxor
      // 165: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16a: sipush 23646
      // 16d: ldc2_w 449464161289577008
      // 170: lload 1
      // 171: lxor
      // 172: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 177: bipush 1
      // 178: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 17b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 17e: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.友何何友何友何何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 181: aload 0
      // 182: new cn/cool/cherish/value/impl/BooleanValue
      // 185: dup
      // 186: sipush 25613
      // 189: ldc2_w 7957237701532293702
      // 18c: lload 1
      // 18d: lxor
      // 18e: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 193: sipush 21900
      // 196: ldc2_w 210393212407229397
      // 199: lload 1
      // 19a: lxor
      // 19b: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1a0: bipush 1
      // 1a1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1a4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1a7: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.友何树友何树树树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1aa: aload 0
      // 1ab: new cn/cool/cherish/value/impl/BooleanValue
      // 1ae: dup
      // 1af: sipush 20491
      // 1b2: ldc2_w 1959446975524941372
      // 1b5: lload 1
      // 1b6: lxor
      // 1b7: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1bc: sipush 15130
      // 1bf: ldc2_w 1057261405985752435
      // 1c2: lload 1
      // 1c3: lxor
      // 1c4: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c9: bipush 1
      // 1ca: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1cd: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1d0: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.友树友何友友友何何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1d3: aload 0
      // 1d4: new cn/cool/cherish/value/impl/BooleanValue
      // 1d7: dup
      // 1d8: sipush 19133
      // 1db: ldc2_w 257081426564199624
      // 1de: lload 1
      // 1df: lxor
      // 1e0: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e5: sipush 23838
      // 1e8: ldc2_w 3407641621605589848
      // 1eb: lload 1
      // 1ec: lxor
      // 1ed: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f2: bipush 1
      // 1f3: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1f6: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1f9: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.树友友何树树友树何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1fc: aload 0
      // 1fd: new cn/cool/cherish/value/impl/BooleanValue
      // 200: dup
      // 201: sipush 3172
      // 204: ldc2_w 6759931791159161372
      // 207: lload 1
      // 208: lxor
      // 209: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 20e: sipush 28027
      // 211: ldc2_w 9218909870871581451
      // 214: lload 1
      // 215: lxor
      // 216: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 21b: bipush 1
      // 21c: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 21f: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 222: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.树何友何树友友何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 225: aload 0
      // 226: new cn/cool/cherish/value/impl/BooleanValue
      // 229: dup
      // 22a: sipush 23753
      // 22d: ldc2_w 2496833652159619750
      // 230: lload 1
      // 231: lxor
      // 232: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 237: sipush 3694
      // 23a: ldc2_w 1693783245777399868
      // 23d: lload 1
      // 23e: lxor
      // 23f: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 244: bipush 1
      // 245: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 248: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 24b: aload 0
      // 24c: ldc2_w -3680929218884785041
      // 24f: lload 1
      // 250: invokedynamic Ò (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 255: dup
      // 256: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 259: pop
      // 25a: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 25f: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 262: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 265: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.树树何树树何何树友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 268: aload 0
      // 269: new cn/cool/cherish/value/impl/BooleanValue
      // 26c: dup
      // 26d: sipush 9608
      // 270: ldc2_w 2095097179574721525
      // 273: lload 1
      // 274: lxor
      // 275: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 27a: sipush 32279
      // 27d: ldc2_w 6985206935216357492
      // 280: lload 1
      // 281: lxor
      // 282: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 287: bipush 1
      // 288: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 28b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 28e: aload 0
      // 28f: ldc2_w -3680929218884785041
      // 292: lload 1
      // 293: invokedynamic Ò (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 298: dup
      // 299: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 29c: pop
      // 29d: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 2a2: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 2a5: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 2a8: putfield cn/cool/cherish/module/impl/misc/何友友友树树树树树树.何何树树树何何何友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2ab: aload 0
      // 2ac: ldc2_w -3683903906309950752
      // 2af: lload 1
      // 2b0: invokedynamic ö (Lcn/cool/cherish/module/impl/misc/何友友友树树树树树树;JJ)V bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2b5: ldc2_w -3680801183208238338
      // 2b8: lload 1
      // 2b9: invokedynamic ß (JJ)Z bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2be: ifne 2ce
      // 2c1: iinc 3 1
      // 2c4: iload 3
      // 2c5: ldc2_w -3681149308930058442
      // 2c8: lload 1
      // 2c9: invokedynamic ß (IJJ)V bsm=cn/cool/cherish/module/impl/misc/何友友友树树树树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2ce: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(293541420618007461L, -3221624848390680316L, MethodHandles.lookup().lookupClass()).a(86345172423545L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 46912407418187L;
      a();
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[72];
      int var5 = 0;
      String var4 = "\u0012\u001beÆ&\u000fÎ;9äçZ\u00ad»I\u001b\u0010E¯\n±&\u0087ß\u009d~b/\u009c\u001f\u0091\u0083û\u0010n\u0093yjcv}±Ân\u001b8G¼r¾ BòÛÙâälëa\u0087å@´(E\u0091\u0080\u0091Æ\u0098\u009f\u0084oq¿³ÄGì\u0015+¶\u0010Ø9Ê.RÌ\u0002\u000e&a?8ñ>\u0012\u0018(Ó\u0083\u0099?3Ö'ò_TÝZf$ð\u00adÐ\u008a(Ð\u001e_R¦ÕapgWè6Þkù%Ï\u008fÎ+? ÝeÙ$l,MÑÃì\u008eH,Ï\u00932¢\u008d¬ç¡Ë\u0091~¾ê,6\u0000\u009bz\u0083 \u00ad§\u001cP\u001a#\u0005û\u001cÕ\u009c\u0012uÃðY(\u0091\n§è¨\u008f%*èbùÝÑÖÐ(6Í4Ýò`þP)Èi]ÎÆO\u0087\u0094\u00adTÂ*':ºzx½c;FlÙ½\u008dù\u0099¼\u0090ÑÓ(\u0093\u0018¹\u009f\u008buÖ\u0007n\u001d¢\u008b£*Òé'ã:uQ\u008eûja9¢rHkÀ¿Ì6o\u0085Q\u0015á¬(¦Ø\u0017\u0092-\rÄÃ\u001d\u000bÙç\b\u0016czÌ1\u0005G:*\u001d\bß<Éb\u0000÷\u0004\u0091é×Æ¨\u0015/|·(\u007fP_\r\u0099\u000eÿÌ½3\u0011lª4ÝB\fÙÐXýxn¬ßöãÒ\u0019\u001aU\u0081\u008b\u001fý3\u0012\u0000$Ü\u0010*H´\u0092o°\u0098t\u009fVÇYïÂÅ\n@\u0090Ñèâý#ÜÆß@§Ex\u0016\u0087\u0012P¾yG'ÄÊ¬\u0097\u001e\u009b:é\u0090{Ò\u0015ÉU4\u0010\u0081\u009f\u0003ïð\u0013¾5Ä<\u0086½égdÌÇ:7¡\n$ð~Ä1\u0098 ÿ\n\u001f8\u0005ÕÑ¾£k\u000fA\u008d#n\u000b®´5¡\u008aÔ\u0013çÝ1ÿÀ\u007fÙÄ/ S¢|=\r:Ý\fôh\u009d#J\u0005n\u0018\"¾mïã\u000e9|\u001e-ÿZ(\u0000°<\u0018kp0òV\b0q\u008f¡XõÑø\u0005ÏX,âFU\u0002ÃR O²¾XKîA\u0096\u001a6\u0005¿\u008c³5©_tÏ\u001aì\u0080á\u001f\u0015\u001côOrµÐ\u009a\u0010Ì_£\u0014\u001b1Ï*ß\u001aû£\u00818vK\u001848$\u00176¿e-\u009f`ûß\u00891\u0006A\\ÜÝ£\tü$â((u\u009f\u0087Æå\u008dÎõ£õ8\u001f¢\u0000\u001c\u0088µÑ*·Yû\u0006·}~~S\u007fòæ$\u000b\u0016£äg\u009e$(o\u0081é\u0098a\u0015Ì\u00947\u0092 \u001cÉ`t#d\u0004¦\tK¾\u0099b$9×¥£û0Se\u0015\u0097\u009e£Ø4P ¼\u0019lEùWõ\u0086>ù8û\rö\u009c\u00181ÕiX¥O\u008a»|¾\u0018 ùz\u008e¿@Ò9Ã\u008eèTz÷Â\u0019Ð=-\u001dYÀ\u009eë.O[åó\u0083yá\u0085è\u008bc\u008dÓPWf`F¥\u00844¥_¾#í\u0097\u008f\u0007ú¿wpÌÂ\u0087°\u008e3\u0012\"\u0003à\u00100 Þzý\u00841é¢\\&HÎ\u0000[\u0017åþ\u0082\u0091h\u0019\u0005Ù3°BÓ7DÂ8M\u00ad ç\u008bU`\u001f.ôÃä\u0006íaøYÐ\u0005ê®äð\u0015:N\u0086çwç\u0017°¥¼Þ\u0010°·¨\u0018ð\n\u0097\u0082X\u0088\u0080¨FN\u0092Ï\u0010ýÏ&¾«mÅåÊ_\u0090\u0088ûf/nHQ43\u008dåÖ6üçày<2vãÌÑé\u000bÏ4\u00ad|\u0002ç¬v,T\u00801Fô~êö§Äøñ\u0091\u0017/Â\ftèÑ\tb¸ö¿\u0082\u0083\u0087l(!M\u0094½õD\u0098R±)V>Åa \u0003\u001c\u009fL\u0080\u0016\u001a\n\u0089WPX©¿<ª]Ì¶\u0000#ÚWÎ»½\u0094 ý§¹y Îz¤Ð·¶î \u001d\u008b¿=~`\u0001]\u008c\u00177È\u009bG¥äÑÇÒ©õ4C¹ \u000e¤©íþæ £2\u0091Ãchî«S0©5?\u008dÿp\u0088û61¯Å´ý\u001a\u0010\rãy\u0013\u000eq©Qh4IïHMYJ(ÖDô0Û\u008b:â\n£ ö\u0093\u0018GTöò\u001bª\n \u009e\u0018DQÂi\u000fN>\u008a\u001a\u0098B\u0098\u0089\u0002L`(ì#ï\u001aÌ+fr\u0088MÁª>«ýÏ\u000e11ì^$¯\u0096ÌÁê\u0019Ésxñ>\u0095ëÂ«&\u0089 \u0018É\u008b¾\u0095o\u0083Ë¯/¼¾³½xàvÃÁ]/@å\u0016>\u0018\u0010\u0082\u0014+'ÄF{>ksþbMÏd\u0080\u008d«êE\u001d\u008c©\u0010V$êDÄ`Ñ´Mt']û´\u0099ß \u0090ØmIJÏ'r\u0016\u0011²'u¿{ä\u0004Kæï\u0099y\u009f8Iý<£\u0092ü\u000b¾(Ò\u009aÁÕÙÁÓæeê\u008b\u0016ÁË·â/5\u001a\u0000Tr8Ù\u009b¶ãÇ^ÀXÞòc\u0089\u0087\u0085\tFu\u0010î§áM\u0019/\u0099¾\u0004[U.ÊòÿÍ\u0010\\\u0081£`¦?)\u0085wJ\u0089WP\u0086t((zs\u0090|ý\u0003'Þ\tEÜýt|òM®\u0093êÌ\u0085;È\u0081QçÃ:\n\u0004öl2þoÎq¹c·\u0018Z\u001bÜkúµ\u0010rÂn\u0010ÑMU`¯\u0004dR\f\u0011Ãc\u0006 S\u0017s\u0094\u0086ü\u009cla\n\u000eß\u0016ÑZ\u0002\bºm\u00ad§\u001d¤{£\u0004L\nõÖ\u0083I\u0010À6r\u0092\u0002WV\u008e\u001f\u001a}\u0090¬e¨c\u0018ï{\u000bÍa§¶\u009fû\b¶\u000fe¯\u007fðÜÈ\u0098K\u008dè¨Õ \u0083$¤2Ð\u009b&ej¶jÈ¼Pÿ\u008d~r¾4ðIÓ\u001f\u0016\u0017{|·\u0086v\u0089 QÑ»Þ*g´Äò\u0000ó\u009fUP6_uö\u00944\u0004Ê¾ÌÆòâ¹¢ô\u001f\u008b\u0010ËãÐ¾\u0016\u0014 p²m\u0000\u008c\u0003v\u0001³ \u0012vøþ\bA\u009dª½4§àúQT³\u0015»\u001cÇ\u0096Í]Î\u0013Ìï¶\u0099©\u001c\u0092 ü\u0000\u001f§ê¿Ó\u009eJôÔcr\\\u009e'tç¤\u009e\u0082!T\u001fB\u0017åö0\u0096>á öú'\u0005ð\u00adõ\u009c{\u008a¤$ôø+\u0015\u0001Hó.\u008c6õ\u0097áép÷KÿÜ°\u0010B¿\\fðC\rRÎË_\u001b\u000fßø\u008e\u008846³)è\u0090\u008a\nÄã\u001e¡2À\u0092\r\u0094¸\u0016\u0012¾zì\u000fÅ\u008côt\"Ï\u009bÌôÌ¦Î£x\u00910ÖWj;\u008ddù\nìÒÁÿÝÕ1M\u0081Åc$nÚòó~\u001a±ó¬¢ì3á®\u008b\u008cNZnl8¶\u0007GY!²\u0001\u001e_\u0080O«¦R\u0014ú\u008dî\u0083i#r+±n\u0013\u0004êû\u0089&\u007fãøYªN!2Iz'w\u009fdgè&¶½\u009b¨OÊt(®Í\u007f-]\u0081\u0082\u0013\u0092] ÷\u009f°Ød2'mLC@õÉ¶\u001eI,ìf0Â\u0084q×\u0095\u0019C\u009bÛ(ëÕ\u001a&\u0015\u009bÀôÚN¬\t\u0088Ë7^ý¯ÞoÚv\u0019í\u009f£ó¬Ê2\u009dS\u0088ö²x©ûDÑ \fÎ\u0001ïõaM íJ¿7¸\b¦fÚ\u008d=\u0087£Ìhã-/½_t]\u008cN \u0096ó¹\u0099¦Ó/WúþÊôºo\u0007Ë§J\u000f\u0002¡\u0015\u0085¼½J\u0013ôì\u0084éÛ\u0010`Ì\u009f%\u001aªÕ\u008aC§\u0091þ:âV\u009f0\u0081\f2º«\u001fd\u0083ëó\u0018\u001aÀËm\u008f\u0092\u0081¡S,\u009al\u000b&\u007f\f®GÎyê¤ñ\u001aæò\u008d\f3\u001eð/yîj\u0099»(}Ú\u0014~_aãd¶\u0098ðmÊ <UÌ}C(Ýä\bÚ\t\u0006\u000fáÈØ±\u001eV\u001b%R\u0018N\u0086ç\u0018\u0002kíÈtM\u001f¯S\u0006\u007f\u0005\u0084Û\u008d´®\u0096¦èM\u0080\u0018\u001f\u0018 î\u0000\u0003£8½\"\u0097\u0003\u0000\u001a´\u0084±`E-Í\u0019«C\u0081Õ\u0018îûL}2ynj´»\u008c\u009cLteÕk\u0004,bäpâ¡\u0018ã\u0092u/\u009c§¨ymßì]g¡Õ.\u0010ÕÓ5\u0098v5\u0088 QÁÒ`îª\u009b\u0018ìÉÈaqQY>¾\u0084|½fèVO35\u0096q\u0007hZ¬\u0010üL×ü,´ÒaÛXúèé÷áé °G?âÊIèÚ¤SLw5õâcÅ{ÑT£\u009eæ'\u0085õè5\u008b\u009e¯\u0010 ¶M\u0013ö¾\u0017®¡8(m\u0084ô¯ïRý\u0014r\u008a#¡p1MÄ\u000b\n-9\u0098ô";
      short var6 = 2293;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = c(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     c = var7;
                     h = new String[72];
                     c<"ö">(new ArrayList(), -2041551026777704889L, var9);
                     友树何何树树何何树何 = new ArrayList<>();
                     友友何树树树何何友树 = new ArrayList<>();
                     何树友何友友友友何友 = new HashMap<>();
                     友友树何何何树树树友 = new HashMap<>();
                     c<"ö">(0, -2041376864668213079L, var9);
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "7½a³2l\u0014\u0000£\u0011#õ\u0016îW_ 8Ü©GÉZëJ4ë¯V\u008akÄ²ÚR-\u0095\\<_v\u0013îØv\u0095Q\u001cì";
                  var6 = 49;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   public static boolean B(Entity entity) {
      long a = 何友友友树树树树树树.a ^ 39869807896447L;
      c<"ß">(8185450260527577736L, a);
      return entity instanceof Player && c<"Ì">(8187311297356236645L, a).contains(entity);
   }

   private boolean B(Player player) {
      long a = 何友友友树树树树树树.a ^ 51663644453429L;
      return player.hasEffect(c<"Ì">(4385688391839233821L, a));
   }

   public static boolean C(Player player) {
      long a = 何友友友树树树树树树.a ^ 4103072344903L;
      c<"ß">(-4782637684822100304L, a);
      Set items = (Set)c<"Ì">(-4779349761262400677L, a).get(player);
      return items != null && items.contains(b<"u">(2742, 8321335806379525532L ^ a));
   }

   private void D(Player player) {
      long a = 何友友友树树树树树树.a ^ 123570129026345L;
      long ax = a ^ 114968949211660L;
      c<"ß">(-1458139586457075475L, a);
      if (!c<"Ì">(-1456722201573016027L, a).contains(player)) {
         c<"Ì">(-1456722201573016027L, a).add(player);
      }

      if (!c<"Ì">(-1458838421883822623L, a).contains(player)) {
         c<"Ì">(-1458838421883822623L, a).add(player);
         String playerName = player.getName().getString();
         ClientUtils.e(new Object[]{b<"u">(285, 2384842943556081733L ^ a) + playerName, ax});
      }
   }

   public static boolean F(Player player) {
      long a = 何友友友树树树树树树.a ^ 103971333776815L;
      return U(player, c<"Ì">(8308172284046900440L, a));
   }

   public void F() {
      long a = 何友友友树树树树树树.a ^ 64296863040287L;
      c<"Ì">(6196641893273239571L, a).clear();
      c<"Ì">(6194525604241990615L, a).clear();
      c<"Ì">(6196726620185961221L, a).clear();
      c<"Ì">(6195783214251645030L, a).clear();
      c<"Ì">(6193697947706630915L, a).clear();
   }

   private void I(Player player, String message) {
      long a = 何友友友树树树树树树.a ^ 86491681908267L;
      long ax = a ^ 94950104242446L;
      if (c<"ß">(3516437539774446556L, a) == 0) {
         if (!c<"Ì">(3515780974255039783L, a).contains(player)) {
            c<"Ì">(3515780974255039783L, a).add(player);
         }

         ClientUtils.e(new Object[]{b<"u">(12803, 3644406742102782048L ^ a) + player.getName().getString() + " " + message, ax});
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 45;
               case 1 -> 51;
               case 2 -> 17;
               case 3 -> 44;
               case 4 -> 56;
               case 5 -> 53;
               case 6 -> 59;
               case 7 -> 55;
               case 8 -> 5;
               case 9 -> 60;
               case 10 -> 52;
               case 11 -> 24;
               case 12 -> 62;
               case 13 -> 29;
               case 14 -> 58;
               case 15 -> 25;
               case 16 -> 8;
               case 17 -> 0;
               case 18 -> 23;
               case 19 -> 49;
               case 20 -> 2;
               case 21 -> 6;
               case 22 -> 11;
               case 23 -> 16;
               case 24 -> 9;
               case 25 -> 38;
               case 26 -> 4;
               case 27 -> 31;
               case 28 -> 27;
               case 29 -> 41;
               case 30 -> 54;
               case 31 -> 32;
               case 32 -> 20;
               case 33 -> 13;
               case 34 -> 50;
               case 35 -> 22;
               case 36 -> 57;
               case 37 -> 35;
               case 38 -> 26;
               case 39 -> 61;
               case 40 -> 7;
               case 41 -> 14;
               case 42 -> 10;
               case 43 -> 63;
               case 44 -> 37;
               case 45 -> 12;
               case 46 -> 21;
               case 47 -> 34;
               case 48 -> 43;
               case 49 -> 19;
               case 50 -> 36;
               case 51 -> 46;
               case 52 -> 48;
               case 53 -> 15;
               case 54 -> 30;
               case 55 -> 47;
               case 56 -> 33;
               case 57 -> 3;
               case 58 -> 18;
               case 59 -> 28;
               case 60 -> 42;
               case 61 -> 1;
               case 62 -> 39;
               default -> 40;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12945;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/何友友友树树树树树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/何友友友树树树树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static boolean c(Player player) {
      long a = 何友友友树树树树树树.a ^ 77317791517203L;
      c<"ß">(6699548607987595223L, a);
      Set items = (Set)c<"Ì">(6699125733581629967L, a).get(player);
      return items != null && items.contains(b<"u">(13891, 1878272729984129056L ^ a));
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 210 && var8 != 194 && var8 != 204 && var8 != 246) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 199) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 223) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 210) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 204) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/何友友友树树树树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private boolean n(Player player) {
      return false;
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   public static boolean l(Entity entity) {
      long a = 何友友友树树树树树树.a ^ 122356975760721L;
      c<"ß">(-6649911546603362138L, a);
      return entity instanceof Player && c<"Ì">(-6649225076504128103L, a).contains(entity);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "<fns&\u001e<fy/*\u0011&-m29\u001b6-s).\u001a|Jn8&\u0004";
      j[1] = "A/.E8oA/9\u00194`[d-\u0004'jKd3\u001f0k\u0001\u0003.\u000e8";
      j[2] = "SdIy&'\\$\u0004r,:Yy\u000f4$'T\u007f\u000b\u007fg!]z\u000b4$!CiI发厂厃佥佟桶栋桘伝校";
      j[3] = int.class;
      k[3] = "java/lang/Integer";
      j[4] = "\fG \u0010vZ\u0003\u0007m\u001b|G\u0006Zf]tZ\u000b\\b\u00167\\\u0002Yb]t\\\u001cJ 伦叒叾厤核栟桢栈栤桾";
      j[5] = "|MoM:\u0017wB~\u0002F\u000exXpAq>nO|\\`\u0012yB";
      j[6] = "J9\u0005n2PT1\u001f!PLS,";
      j[7] = "8n.M^a&f4\u0002=u\"";
      j[8] = "a-\u001bg\n\u001fa-\f;\u0006\u0010{f\u0018&\u0015\u001akf\n/\u0001\u0013l<A\u0004\b\u0014J.\t,\u0004\u0002|";
      j[9] = "M6\tO\u001b'M6\u001e\u0013\u0017(W}\n\u000e\u0004\"G}\u0018\u0007\u0010+@'S,\u0019,f5\u001b\u0004\u0015:";
      j[10] = "R3Rh'j]s\u001fc-wX.\u0014%>d](\u0019%!hA1RI'j]8\u001de\u001ed](\u0019";
      j[11] = "`\f/U/!`\f8\t#.zG,\u00140$jG>\u00156!z\u0010u>,<g\u001d\"/;8k";
      j[12] = "\u0016~\u0014 {$\u0016~\u0003|w+\f5\u0017ad!\u001c5\u0010fo>VM\u0005m%";
      j[13] = double.class;
      k[13] = "java/lang/Double";
      j[14] = "4@t\u0019T2;\u00009\u0012^/>]2TV23[6\u001f\u0015\u00108J/\u0016^";
      j[15] = boolean.class;
      k[15] = "java/lang/Boolean";
      j[16] = "Hy\u001fym\u0010G9Rrg\rBdY4o\u0010Ob]\u007f,伪佾叜佤住叉伪佾栆栠";
      j[17] = void.class;
      k[17] = "java/lang/Void";
      j[18] = "anGaOlanP=Cc{%P#K`a\u007f\u001d?NdvnAanjlj_\u001fNdvnA";
      j[19] = "1\u001b2jos:\u0014#%\u000e}1\u001f'\u007f";
      j[20] = "\u0007QPw_qV\u0018D c\u007fm\u0011\u0007$[,m(\b~\u0002{K\u0013\u000f+\\{";
      j[21] = "\b\u0013DA\u0016t_]N\u001ck受栫伱佢栴桲佉佯桵佢-W%IV\u0000LPt\t\u0016";
      j[22] = "I9I\u000e<^\u00106Qp9v\u0014|\nAnv(\u007f\u000bK,YC-M@)";
      j[23] = "'0\u0016Dj/~?\u000e:o\u0007zuU\u000b?\u0007FvT\u0001z(-$\u0012\n\u007f";
      j[24] = "Uy\u0014+#=\u00027\u001ev^厞桶叅伲厄厝厞伲佛厬Ga1\u0015;\u0010v\"'\u0001=";
      j[25] = ">>3H;:ip9\u0015F厙叇桘伕佹伛桃栝桘压${gn:5\u001e=$40";
      j[26] = "wC\u000b?Y\u001a&\n\u001fhe\u0014\u001d\u0003\\l]B\u001d:S6\u0004\u0010;\u0001TcZ\u0010";
      j[27] = " fj\\.%yir\"+\r}#.\u001b|\rA (\u0019>\"*rn\u0012;";
      j[28] = "|3[^)\b+}Q\u0003T伵伛桕根栫伉伵伛厏佽2k\u0004<q_\u0003(\u0012(w";
      j[29] = "G\u001c\u0006\u0018>>\u0010R\fEC伃厾厠传伩厀厝传伾传ty!\u0006\u000f\u0000\u0014.o\fR";
      j[30] = "\u0005Rk\u0017'\fZA-DK\u0007m\u0019jGuTm#m\nr\u0005VF2\u00194V";
      j[31] = "\u0010\u0018\u0000n\rhM^T+2C*\u0018]~OjHF\u0000{\u0003\u0005";
      j[32] = "mt\u0019\u000e{t4{\u0001p~\\01Z@ \\\f2[Kksg`\u001d@n";
      j[33] = "?\t\u0000E\u0012\u0004hG\n\u0018o桽佘伫伦栰厬伹栜桯伦)P\b\u007fK\u0004\u0018\u0013\u001ekM";
      j[34] = "\u000et\\\r\u0004U\u0000e\fX~Ji+\t\bN\u001di\u001b\u0002\u0004\u001e\u0015LcMVFF";
      j[35] = "M^z&Sg\u0016I|$c叛佺佨伝会厠栁古栬桙G\ts\u001dTp8Rd\u001bV";
      j[36] = "4q;%n\u000bc?1x\u0013桲反反伝桐叐伶体栗厃I,\u0007t3?xo\u0011`5";
      j[37] = "\u0010 -TB9\u001e1}\u00018&w\u007fxQ\u0007ywOs]XyR7<\u000f\u0000*";
      j[38] = "d\u0000{\n=;3NqW@桂厝厼佝桿桙厘桇伢參f\u007f7$B\u007fW<!0D";
      j[39] = "\u0015\u0006 \u0007\b\u001eBH*Zu伣栶厺伆厨厶厽召伤厘kHCE\u0002&Q\u000e\u0000\u001f\b";
      j[40] = "$M\u0001\u0007<\u0019s\u0003\u000bZA\u0010\u001e\u000eBR{Ie\t\u0007U<y\"\nCQq\u0002%OD\u0016A";
      j[41] = "+G/z\u000b\u0000rH7\u0004\u000e(v\u0002i=[(J\u0001m?\u001b\u0007!S+4\u001e";
      j[42] = "\u000f+=:j\u0004Rmi\u007fU 5+`*(\u0006Wu=/di";
      j[43] = "\u001c_\u00139nuEP\u000bGk]A\u001aT~:]}\u0019Q|~r\u0016K\u0017w{";
      j[44] = "k\u001cvR#\u0011bJj@SCP\u001c$\u001fb\u0012P%/L<PhGq\u00119\u001c";
      j[45] = "-\u0014\u0000r^tzZ\n/#栍栎伶桢标佾佉栎厨桢\u001e\u001cxmV\u0004/_nyP";
      j[46] = "\"7\u0010X\u00023uy\u001a\u0005\u007f桊栁桑桲佩桦桊佅压厨4@?bu\u0014\u0005\u0003)vs";
      j[47] = ".\u0001\u000e|\f\u0013yO\u0004!q伮受桧伨栉伬桪栍厽伨\u0010N\u001fnC\n!\r\tzE";
      j[48] = "$g;B\u0005Rs)1\u001fx叱佃栁厃佳桡栫标佅伝.G^d%?\u001f\u0004Hp#";
      j[49] = "82>\u001aBz1c7[<tQfbU]i!v;\u000f]\u0019";
      j[50] = ".\u007f3)\u001f^y19tb叽佉佝压优厡佣佉栙伕E]Rn=7t\u001eDz;";
      j[51] = "enM>]62 Gc 伋厜佌叵伏根厕框叒栯R\u001cg$+\t3\u001b6dk";
      j[52] = "uYE\u0007ZQ\"\u0017OZ'史厌佻栧桲栾佬伒句栧k\u001b\u00004\u001c\u0001\n\u001cQt\\";
      j[53] = "\u001e\u001bL\u001e]yIUFC 栀佹厧栮伯口栀佹桽佪r\u001fu^YHC\\cJ_";
      j[54] = "H+p\u001f\u0007\u0013\u001fezBz伮厱桍佖桪厹伮伯厗栒s@\u001f\u001d)d\u0011\u001eB\u0018e";
      j[55] = "ztgTg1-:m\t\u001a案伝又佁校叙厒伝佖佁8%=:6c\tf+.0";
      j[56] = "\u000fPr*:\u0001X\u001exwG桸栬召及厅厄桸叶佲及Fx\rO\u0012vw;\u001b[\u0014";
      j[57] = "\u0010mc\u0017*b\u001e|3BP}w26\u0012`+w\u0002=\u001e0\"RzrLhq";
      j[58] = "Bn'\u0007\u001d!\u001f(sB\"\u001dxnz\u0017_#\u001a0'\u0012\u0013L\u0013l&\u0003G&\u00001p\u0011\"";
      j[59] = "\u0015\rqHn\u007fL\u0002i6kWHH4\u000f5WtK3\r~x\u001f\u0019u\u0006{";
      j[60] = "X6[lqp\u00019C\u0012tX\u0005s\u001c.%X9p\u0019)awR\"_\"d";
      j[61] = "\u0006[!\\E@Q\u0015+\u00018佽栥佹桃栩叻根叿栽伇0\u0007LF\u0019%\u0001DZR\u001f";
   }

   private int a(Player player, boolean returnLevel) {
      long a = 何友友友树树树树树树.a ^ 97813540204021L;
      c<"ß">(-4963092878449520591L, a);
      return player.hasEffect(c<"Ì">(-4963262041489446861L, a)) ? player.getEffect(c<"Ì">(-4963262041489446861L, a)).getAmplifier() + 1 : 0;
   }

   public static boolean k(Player player) {
      long a = 何友友友树树树树树树.a ^ 29059253686248L;
      c<"ß">(-7417514847298055649L, a);
      Set items = (Set)c<"Ì">(-7421000485516185612L, a).get(player);
      return items != null && items.contains(b<"u">(19581, 3656224518585542607L ^ a));
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private int g(Player player, boolean returnLevel) {
      long a = 何友友友树树树树树树.a ^ 135692269389418L;
      c<"ß">(-3418847227468620899L, a);
      return player.hasEffect(c<"Ì">(-3422087217214301374L, a)) ? player.getEffect(c<"Ì">(-3422087217214301374L, a)).getAmplifier() + 1 : 0;
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static boolean U(Player player, Item item) {
      long a = 何友友友树树树树树树.a ^ 138557329394903L;
      c<"ß">(-7336128625063423712L, a);
      return player.getMainHandItem().getItem() == item || player.getOffhandItem().getItem() == item;
   }

   public static boolean U(Player player) {
      long a = 何友友友树树树树树树.a ^ 106369655328363L;
      ItemStack mainHand = player.getMainHandItem();
      c<"ß">(-7457480386949745745L, a);
      ItemStack offHand = player.getOffhandItem();
      return mainHand.getItem() == c<"Ì">(-7456881969647574471L, a)
         || mainHand.getItem() == c<"Ì">(-7456914543628514702L, a)
         || offHand.getItem() == c<"Ì">(-7456881969647574471L, a)
         || offHand.getItem() == c<"Ì">(-7456914543628514702L, a);
   }

   public static boolean z(Player player) {
      long a = 何友友友树树树树树树.a ^ 132197897857828L;
      return U(player, c<"Ì">(4450560583208592251L, a));
   }

   private void z(Player player) {
      long a = 何友友友树树树树树树.a ^ 61960761545250L;
      long ax = a ^ 35910220213511L;
      c<"ß">(4956473061755924454L, a);
      if (!c<"Ì">(4955057833014661422L, a).contains(player)) {
         c<"Ì">(4955057833014661422L, a).add(player);
      }

      if (!c<"Ì">(4954575486755025464L, a).contains(player)) {
         c<"Ì">(4954575486755025464L, a).add(player);
         String playerName = player.getName().getString();
         ClientUtils.e(new Object[]{b<"u">(27871, 170823693393435286L ^ a) + playerName, ax});
      }
   }

   public static boolean y(Player player) {
      long a = 何友友友树树树树树树.a ^ 87487386577730L;
      c<"ß">(-4781164227107080523L, a);
      Set items = (Set)c<"Ì">(-4780260271184065698L, a).get(player);
      return items != null && items.contains(b<"u">(23065, 4010119801435968792L ^ a));
   }

   private void y(Player player) {
      long a = 何友友友树树树树树树.a ^ 92338283589314L;
      c<"ß">(8658318014581052166L, a);
      Set playerReportedItems = c<"Ì">(8657802500737676731L, a).computeIfAbsent(player, k -> new HashSet());
      if (c<"Ò">(this, 8657705793124734094L, a).getValue() && this.O(player) && !playerReportedItems.contains(b<"u">(19368, 6419337063265599769L ^ a))) {
         this.I(player, b<"u">(21514, 3731818578610200222L ^ a));
         playerReportedItems.add(b<"u">(16872, 8800706166505769792L ^ a));
      }

      if (c<"Ò">(this, 8657904418213379773L, a).getValue() && this.B(player) && !playerReportedItems.contains(b<"u">(9275, 6226418512326061727L ^ a))) {
         this.I(player, b<"u">(4166, 7317674819733641946L ^ a));
         playerReportedItems.add(b<"u">(17410, 9082800509252243081L ^ a));
      }

      if (c<"Ò">(this, 8655973817386378652L, a).getValue() && U(player) && !playerReportedItems.contains(b<"u">(8983, 797339779878447547L ^ a))) {
         this.I(player, b<"u">(20202, 3737244744106738761L ^ a));
         playerReportedItems.add(b<"u">(8983, 797339779878447547L ^ a));
         Set<String> items = c<"Ì">(8658459415082929886L, a).computeIfAbsent(player, k -> new HashSet<>());
         items.add(b<"u">(8983, 797339779878447547L ^ a));
      }

      if (c<"Ò">(this, 8657248662095096964L, a).getValue() && F(player) && !playerReportedItems.contains(b<"u">(19765, 3484439300461496241L ^ a))) {
         this.I(player, b<"u">(7210, 5914113716664522451L ^ a));
         playerReportedItems.add(b<"u">(19765, 3484439300461496241L ^ a));
         Set<String> items = c<"Ì">(8658459415082929886L, a).computeIfAbsent(player, k -> new HashSet<>());
         items.add(b<"u">(19765, 3484439300461496241L ^ a));
      }

      if (c<"Ò">(this, 8656270488981862834L, a).getValue() && W(player) && !playerReportedItems.contains(b<"u">(26449, 42977783180635599L ^ a))) {
         this.I(player, b<"u">(4880, 174755413628279183L ^ a));
         playerReportedItems.add(b<"u">(26449, 42977783180635599L ^ a));
         Set<String> items = c<"Ì">(8658459415082929886L, a).computeIfAbsent(player, k -> new HashSet<>());
         items.add(b<"u">(26449, 42977783180635599L ^ a));
      }

      if (c<"Ò">(this, 8656990478786593899L, a).getValue() && z(player) && !playerReportedItems.contains(b<"u">(14078, 2671812437489056773L ^ a))) {
         this.I(player, b<"u">(9329, 8097512306152140508L ^ a));
         playerReportedItems.add(b<"u">(14078, 2671812437489056773L ^ a));
         Set<String> items = c<"Ì">(8658459415082929886L, a).computeIfAbsent(player, k -> new HashSet<>());
         items.add(b<"u">(14078, 2671812437489056773L ^ a));
      }

      if (c<"Ò">(this, 8656852160330165595L, a).getValue() && E(player) && !playerReportedItems.contains(b<"u">(18440, 5250409071991358109L ^ a))) {
         this.I(player, b<"u">(9368, 6618963524192923144L ^ a));
         playerReportedItems.add(b<"u">(18440, 5250409071991358109L ^ a));
         Set<String> items = c<"Ì">(8658459415082929886L, a).computeIfAbsent(player, k -> new HashSet<>());
         items.add(b<"u">(18440, 5250409071991358109L ^ a));
      }

      if (c<"Ò">(this, 8658582997531164323L, a).getValue() && this.Y(player) && !playerReportedItems.contains(b<"u">(593, 7550016504804591853L ^ a))) {
         this.D(player);
         playerReportedItems.add(b<"u">(22750, 7912247919855243845L ^ a));
      }

      if (c<"Ò">(this, 8657884829434580441L, a).getValue() && this.G(player) && !playerReportedItems.contains(b<"u">(7894, 5341392841789428811L ^ a))) {
         this.z(player);
         playerReportedItems.add(b<"u">(7894, 5341392841789428811L ^ a));
      }
   }

   @EventTarget
   public void E(WorldEvent e) {
      long a = 何友友友树树树树树树.a ^ 115973975750844L;
      c<"Ì">(7952714795148721072L, a).clear();
      c<"Ì">(7950035556164556916L, a).clear();
      c<"Ì">(7952337727044327590L, a).clear();
      c<"Ì">(7951257981667124165L, a).clear();
      c<"Ì">(7950890152418646176L, a).clear();
   }

   public static boolean E(Player player) {
      long a = 何友友友树树树树树树.a ^ 88617777306505L;
      return U(player, c<"Ì">(-3643928214352104165L, a));
   }

   @EventTarget(0)
   public void Y(SyncHandleReceivePacketEvent event) {
      long a = 何友友友树树树树树树.a ^ 26692539795345L;
      long ax = a ^ 15732259317844L;
      long axx = a ^ 775067515060L;
      c<"ß">(-7964981386891683226L, a);
      if (!this.w(new Object[]{ax})) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundSystemChatPacket wrapper) {
            if (wrapper.content().getString().isEmpty()) {
               return;
            }

            if (c<"Ò">(this, -7966305139018468876L, a).getValue()) {
               String message = wrapper.content().getString();
               String playerName = mc.player.getGameProfile().getName();
               if (message.contains("<")) {
                  return;
               }

               if (message.contains(b<"u">(8563, 1710493449694741167L ^ a))) {
                  c<"ö">(c<"Ì">(-7966409919400553869L, a) + 1, -7966409919400553869L, a);
                  ClientUtils.e(new Object[]{b<"u">(19755, 8867900326138867440L ^ a) + c<"Ì">(-7966409919400553869L, a), axx});
                  if (c<"Ò">(this, -7964817101586299172L, a).getValue() && c<"Ò">(this, -7966305139018468876L, a).getValue()) {
                     mc.getConnection().sendCommand(b<"u">(25010, 3379069596816163428L ^ a));
                  }

                  if (message.contains(playerName)
                     && mc.getConnection() != null
                     && c<"Ò">(this, -7963719002272754320L, a).getValue()
                     && c<"Ò">(this, -7966305139018468876L, a).getValue()) {
                     Connection networkManager = mc.getConnection().getConnection();
                     networkManager.disconnect(Component.literal(b<"u">(5866, 7444627461102908699L ^ a)));
                  }
               }
            }
         }

         if (c<"Ò">(this, -7966513996556121626L, a).getValue() && packet instanceof ClientboundAddEntityPacket packet2) {
            if (packet2.getType() != c<"Ì">(-7963624085867923053L, a)) {
               return;
            }

            Vec3 var20 = new Vec3(packet2.getX(), packet2.getY(), packet2.getZ());
            Vec3 var21 = mc.player.position();
            long var10001 = 6104964050068180323L ^ a;
            double distance = var21.distanceTo(var20);
            String var10000 = String.format(b<"u">(11918, var10001), c<"Ò">(var20, -7965382974816749030L, a));
            String var23 = String.format(b<"u">(18625, 815988451665767173L ^ a), c<"Ò">(var20, -7966224023047487645L, a));
            String var10002 = String.format(b<"u">(18625, 815988451665767173L ^ a), c<"Ò">(var20, -7965559254049697595L, a));
            int axxx = (int)distance;
            String axxxx = var10002;
            String axxxxx = var23;
            String var18 = var10000;
            ClientUtils.e(
               new Object[]{
                  b<"u">(1620, 4299966730033538462L ^ a)
                     + var18
                     + b<"u">(16419, 4880645333216060367L ^ a)
                     + axxxxx
                     + b<"u">(23788, 8020429546745823042L ^ a)
                     + axxxx
                     + b<"u">(18521, 8594936731514956704L ^ a)
                     + axxx
                     + b<"u">(15256, 8266067371136817262L ^ a),
                  axx
               }
            );
         }
      }
   }

   private boolean Y(Player player) {
      long a = 何友友友树树树树树树.a ^ 89296034679651L;
      return U(player, c<"Ì">(-7095913078373172295L, a));
   }

   public static boolean X(Player player) {
      long a = 何友友友树树树树树树.a ^ 75344780453978L;
      c<"ß">(4521032799670285741L, a);
      Set items = (Set)c<"Ì">(4517411190303868998L, a).get(player);
      return items != null && items.contains(b<"u">(6268, 7188173379378779255L ^ a));
   }

   @EventTarget
   public void L(TickEvent e) {
      long a = 何友友友树树树树树树.a ^ 108861362417328L;
      long ax = a ^ 128687524938101L;
      c<"ß">(-550927183955520652L, a);
      if (!this.w(new Object[]{ax})) {
         if (mc.player != null && mc.level != null && !mc.level.players().isEmpty()) {
            if (c<"Ò">(mc.player, -552116397326601284L, a) % 6 == 0) {
               Iterator var7 = mc.level.players().iterator();
               if (var7.hasNext()) {
                  Player player = (Player)var7.next();
                  boolean me = player != mc.player;
                  boolean sameTeam = this.n(player);
                  if (!c<"Ò">(this, -552018178740289876L, a).getValue() && me && !sameTeam) {
                     this.y(player);
                  }

                  if (c<"Ò">(this, -552018178740289876L, a).getValue()) {
                     this.y(player);
                  }
               }

               this.T(c<"Ò">(this, -552018178740289876L, a).getValue() ? b<"u">(19187, 5312867415418503289L ^ a) : b<"u">(19017, 2687996741825691797L ^ a));
            }
         }
      }
   }

   public static boolean W(Player player) {
      long a = 何友友友树树树树树树.a ^ 116832489704959L;
      return U(player, c<"Ì">(-2657857821042602826L, a));
   }

   private boolean G(Player player) {
      long a = 何友友友树树树树树树.a ^ 89478857456563L;
      c<"ß">(-5955583046040369545L, a);
      if (U(player, c<"Ì">(-5955840452860799326L, a))) {
         return true;
      } else {
         String playerName = player.getName().getString().toLowerCase();
         return playerName.contains(b<"u">(17561, 3720716812859562874L ^ a)) || playerName.contains(b<"u">(29939, 402777819950803732L ^ a));
      }
   }

   private boolean O(Player player) {
      long a = 何友友友树树树树树树.a ^ 90408356590428L;
      return player.hasEffect(c<"Ì">(7329601471827981978L, a));
   }

   private static String HE_WEI_LIN() {
      return "何树友被何大伟克制了";
   }
}
