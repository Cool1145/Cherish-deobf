package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.client.树友何何何树何树友友;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.other.BlinkEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPongPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;
import why.tree.friend.antileak.Fucker;

public class 友何树友何友何树树友 extends Module implements 何树友 {
   public static 友何树友何友何树树友 何友友何树树树何何树;
   private static final boolean 树树友何何树树何友友 = false;
   public final BooleanValue 友树友友树友何何树友;
   private final BooleanValue 树何树友树何友友友何;
   private final BooleanValue 友友友友树友何友何树;
   private final BooleanValue 树树树树友友何友友何;
   public final BooleanValue 树何友何树何友何树何;
   private final BooleanValue 何树树何树何何何树何;
   private final BooleanValue 树何树树何树树友树树;
   private final BooleanValue 树友树何何友树树何何;
   private final BooleanValue 树树树树友友友友友何;
   private final BooleanValue 友友树树何树何友友友;
   private final BooleanValue 树友何友何友树友友何;
   private final BooleanValue 树友树树树何树友树何;
   private final BooleanValue 友友何友友树何友友树;
   private final BooleanValue 友友树树树友树何何何;
   private final BooleanValue 友友树何何何友何友何;
   private ServerboundContainerClosePacket 树友何何何树何何何何;
   private final 何友友何树何树何树友 树树树树友树何何何何;
   private long 何友何树树友何树友友;
   private boolean 何树树树树树树树何树;
   private long 树友树何何友树友友何;
   private long 何树树何树友树友树树;
   private int 何树友树树友树何何树;
   private int 树友何何友树友何友友;
   private static final double[] 友树树树树何何友何友;
   private static final double 何友树树树何何树树何 = 1.0E-10;
   private final Random 何何友何树友友何何友;
   private float 树何友树何何何友树何;
   private float 友何友树树树树何树友;
   private float 树何树树何友友何树友;
   private float 何友何友友树树树友树;
   private float 何树友何何友友何树友;
   private float 何树友何树何树友何何;
   private float 友何树友友友何何树何;
   private float 何何树树何何树树友树;
   private float 友友友何树树友何友何;
   private float 友友树树友树友友何树;
   private boolean 树树友树树友何何何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[60];
   private static final String[] n = new String[60];
   private static String HE_DA_WEI;

   public 友何树友何友何树树友() {
      何树友树何何何树何何.a();
      super("Disabler", "反作弊禁用器", 树何友友何树友友何何.友树何友何树树树树何);
      this.友树友友树友何何树友 = new BooleanValue("Grim", "Grim", false);
      this.树何树友树何友友友何 = new BooleanValue("BadPackets A", "坏包 A", false).A(() -> {
         何树友树何何何树何何.a();
         return (Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树) && this.友树友友树友何何树友.getValue();
      });
      this.友友友友树友何友何树 = new BooleanValue("Duplicate Rot Place", "重复旋转放置", false).A(this.友树友友树友何何树友::getValue);
      this.树树树树友友何友友何 = new BooleanValue("Aim Duplicate Look", "重复视角", false).A(this.友树友友树友何何树友::getValue);
      this.树何友何树何友何树何 = new BooleanValue("Aim 360", "瞄准 360", false).A(this.友树友友树友何何树友::getValue);
      this.何树树何树何何何树何 = new BooleanValue("Blink", "瞬移", false).A(this.友树友友树友何何树友::getValue);
      this.树何树树何树树友树树 = new BooleanValue("Aca", "Aca", false);
      this.树友树何何友树树何何 = new BooleanValue("Fast Switch", "快速切换", false).A(() -> {
         何树友树何何何树何何.a();
         return (Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树) && this.树何树树何树树友树树.getValue();
      });
      this.树树树树友友友友友何 = new BooleanValue("Inventory Frequency", "背包频率", false).A(this.树何树树何树树友树树::getValue);
      this.友友树树何树何友友友 = new BooleanValue("Aim Step", "步进瞄准", false).A(this.树何树树何树树友树树::getValue);
      this.树友何友何友树友友何 = new BooleanValue("Perfect Rotation", "完美转头", false).A(this.树何树树何树树友树树::getValue);
      this.树友树树树何树友树何 = new BooleanValue("Themis", "Themis", false);
      this.友友何友友树何友友树 = new BooleanValue("Blink", "瞬移", false).A(this.树友树树树何树友树何::getValue);
      this.友友树树树友树何何何 = new BooleanValue("Only Server", "仅在服务器生效", false);
      this.友友树何何何友何友何 = new BooleanValue("Debug", "调试信息", false).A(() -> false);
      this.树友何何何树何何何何 = null;
      this.树树树树友树何何何何 = new 何友友何树何树何树友(51913986529303L);
      this.何友何树树友何树友友 = System.currentTimeMillis();
      this.何树树树树树树树何树 = false;
      this.树友树何何友树友友何 = 0L;
      this.何树树何树友树友树树 = 0L;
      this.何树友树树友树何何树 = -1;
      this.树友何何友树友何友友 = 0;
      this.何何友何树友友何何友 = new Random();
      this.树何友树何何何友树何 = 0.0F;
      this.友何友树树树树何树友 = 0.0F;
      this.树何树树何友友何树友 = 0.0F;
      this.何友何友友树树树友树 = 0.0F;
      this.何树友何何友友何树友 = 0.0F;
      this.何树友何树何树友何何 = 0.0F;
      this.友何树友友友何何树何 = 0.0F;
      this.何何树树何何树树友树 = 0.0F;
      this.友友友何树树友何友何 = 0.0F;
      this.友友树树友树友友何树 = 0.0F;
      this.树树友树树友何何何何 = false;
      何友友何树树树何何树 = this;
      Module.V(new Module[2]);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5211255685295877223L, 5666102880225348150L, MethodHandles.lookup().lookupClass()).a(220086982518458L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(59198717304070L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[63];
      int var18 = 0;
      String var17 = " \u0086(DbâÓa{\u0006ßh#FLa%¨\u009dFÐ<\u0002\u000fcÛD°Û.Ãy\u0002?¾\u0097G:6\u0018Ä}÷\u0006\u0083êÝO\u009d\u009aÜÐ-P^ä\u0010e\u00ad¿Ï#\u00808;Ñ´Í\u0004ëåÈ%(\u008fÊýáÂ¡\u0002_PoÑÂ\u0004\u0001\u0015ö.ñ\u0085\u009dñháb\u0089i¸\b÷4\tZï\u0017\u009fÈ\u0010÷»ã(·tå\u0015\u008a\u0014\u0015ßã\u0007\u0097åÛ«ÈºÝ`ï\u0080A\u0010¦fÂe\u0087\u0016\u0002Þ\u0013sÙ\u001d\u0011æ\u0007®ø\u0097 Hn\u0092´+D\u001b:Ä<²Hù³´\u0082ÿ#cÈÕ\u007f\u008bÂ2\u0010pdë\u0099\u008f¬(OkÕ\u008aà\u001e÷ù84Ûu³\u0094\u001aÂ rÉø6\u008dpÁ÷9×\u001cßz96ñïáðÞ&\u0003\u0005\u0010£)æÈÔJI\u0094\u0015¯S\u0018N-y&\u0010\u001fQñ¨\u0011\u0001Ì@»\u001féó¡\u0019#©@\u00ad.LVxù\u008aé\u0099Fâ£3\u0099é^#\u009ahhîó¯\u000ehÏTàõ\u009cC´óµè\u000b\u001ewåvè{Ê\u0097Ko\u009fùÕ\u008dQ^Ú\u0084ÀZ\u008d£íû!R\u008cµ\u0010%\u008e3÷\u009f/\u0002Î¥\u0004\u0007È4RÛX\u0018\u00886Ux«Ze\u0090Ð¾Â]\u000bø·K3ÔÐð.Y\u001e`\u0018µ\u0015pÞÕBù·\bèz¾\u0000ç\u0080\u0019.êÁ\u0001\u009e´[b\u0010\u0010S\f/ªS\u001dÛ+ûL\u0017³È\u001bFP\u0010.CÓtÝ\u00126\u0088eÑ\u001c\u000eÓ«\u008b¥µeL\u008eQý\u0093l£B\u00136óòLÎöÓ#ÇXF¾9z%ëæcíD\u009fE[\t'\u0092À©qV(ßÆpkª\u0085©»UË!å/\u009bë\br\u0003º%\u0018X¦qMrÃ]÷\u0096¬ úö\u008fé¿~òt\u008aè¸CißÀºg\t\u00adôQÅÒ'\u0094\u0013ù\u009f»\u0088¾\u009b#^jÄ`\u000e½S\\£WÒ¾×Ë¤\u008d\u0002}ïmêa»ºÓh\u001dÕ;\u0017\u0018\u0002ðÎ\u0005ÑÆ.\u0086qoõ=Ü<(Ê;Ï\u001fHxDË½W îp\u0007\u009d¾\u009c?@\u0093\u0082\u0014\n\u008a0A!\bóÀ\u001eïrm¦IïC^¬\u0018UÛ×ËKÆÉy\u0000Çº\u0095\u000e\u0005\u009cx\u0088?\u0006ú3\u007f8éHy:}\u0001\u0012\u000bbü»ã\u0091\u009a$]Î\u0092\u0097®\u007f¥îuÔ\u0091Y?\u0081H\u0011eÃ\u009c\u001d#«ÉDöd\fìÌÅw'\u0018\u0018MÆ\u000e\u009c\u00848hñ~¢c¥;xk\u0084i\u0007{\u008a\u008a[f\u0006\u0018\u0018\u009c¯öU\u009aEó\u009a¯ ÂÐàÂ;~¹Æ\u0096\u001c~¹\u0012þ8Ú³t\u001bùuò\u0082?¯\u009dÖÎ \u008aÂ«Ó$k1¾ +¹ÕPéa¡ím\u009d!Y6£\u0002Ó1\u009f\u0016Séé\u0087Y!f\u008fÀ»2!l£HÇA\t7ì)\u0094cxp<íw\u0004zi7Öã×!è³\u001f+){°\u001eH\u0091tí\u009dxRF`áôÝV\u0019Ê\u008dzjç\u00146Ê$ù%<¯Oî\u0002'I~qhºx\f\u0096H\u009c\u008e\u0080\u0010ñ\u009eÈ\u0081¦Z/\u009aþð¦<;@\u009c¾P<C¯ç`\u0085Ôß\u0080±bð(Ýq\u0087cL¸&ý5\u009d\u0090t³ {Ì\u0002å\u0015t]Ñþ+\u0084Ñs\u0085\u009cÏ2©7\u008d\u0092áå\u0092\u009e\u001aÿâØ\u0016Gð÷ã»¡ñÊ\u0007,Åc\"åÌaò*\u008f\u0017\u0096^¥(\u0097\u0000\u008c\u0013\u0098é\u0003ò,\u0004ÎÔt¼½ê6´\u0002\u0003\u0002\u000eØ±\u008c^\u000e\"H;)\u000e\u0082\u0081Ö\u0087\u008c-\u009cú\u0018,h`Jd\u0091GD\u0002\u0097I§\u0018>Itø\u0002½½Cì²\u001fX\u008b#¸Æ¤<\u001bD\u0013ßvüã/C36O©®«D6¨\u0018\"åÌÛÆ®êÒ\u009eØ\u0007ÀØ9_É\u0080ÍxÛ\t:âòHþ·\\}\b\u008cÔ}\u0096\u007f\nðJP}fÑaÿ©?«ð+KG\u0018xÍ\u0001§ Y\u000e\u0015<DÔ\u0010]dà\u0007<Ù\u0080YÉÞ¤ÁHÃZt\u0010\u009a\u0096\u0000:\u0092â\u0088W\u0014þþÁÕ\u0004Á:\u0010\u008f\u001d³~±y\u00015÷¾[}q\u0011(Æ\u0018É\u0011}\u001f\t²¬>\u009b\u008fn@¹2_\u008c\u009b.Ü\u000e\u008dýíñ\u0010çîZ+^\u0093\fal{S+Ìôp[@¿V\u009e@ò¿\u0090~];\u001fä-_\\\u0002]Q\u0086~BÒeò¼\nd²F[I¿\u0003¦ì·ÞU÷ÅLb®X\u0007\u0014!\u0012õÅQ\u0087{%Z\u008e\u0007Lû\u0014\u0015\u001cìñ(c6\u00adTo\u001a\u009c\u001f±~\u0080\u0080]\u0011C\u0015\u001b\u0017ä\u0018À\u008dÌÑB\u00978\u0092ý\u0090\u001a+üìÑW¬H½¨\u0010»â×\u008e\rô\u0013>¿_ÎyXÓ\u001b\u008c(\u0095ÝÜmxûb£òÅuãÚXÙ-kù\u0095!H\u001bðmÂ ò\u0091IõÈ%]£í\u000b\u009b·ªð\u0010ï\u008d\u0083]âÙ^£\u0097seI\u0002Î×`\u0010=PÀ\u00836+\u0095\u001aROê³ þÙ\u001e\u0010ÏÅA+x¡â§\u009b\u009dº|ö\u0002Ë\u0096(µß\u0001ü\u0003_\u000f äN\u0001Èu 3AÃ\u000bçã4*ë. 6y\u0010Âº\u0090'Mð\\\n\"\u009e\u0015H\u0010ªñ\u0090\u0018ø\u0002\\f'¶»\få\u0092ú\u0084\u0010UD,\u0002m4½ÎXì\u0099ì\\u\u0018\u008a\u0018\u0091ï\u001fÒ\u009cúp\u0001:Z\u0088\tk\u008e\u008eôò\u008dñU\u001cíþ\"\u0018Ô\u0088â\u0089Ü<¶ëIDÚjÓÍÛvÓ\u0005¦ÝCYmé(ó\u0095Ú\u0098Èðy\u008a\f>\u0014à$G§Úµì\u0014dî\u0096¼Ð4Ñµ\u000esf2\u000e¨è\u0086_0\u0015½Ò d\u009a\u0093l£\u008e½ga\rú\u0019ì@KûþÄ\u0081±\u009065jT2\u0085{wû\u0086µH\u0007Û>!t5!3%ß\u001bæ\u00107ÆN@üa4\u0083@ØÔúâV¢©Ñ &\u001e¯>:ÌæÊ\u0012\u0016\u00ad9\u0080U\f\u0090_\u0085\u0093Ø\u008d~¢\u0084ãÆ\u0096ôö_\u0089\u001eéý¶xSv\u001d\u0011@\u00180WÏl}#\u008eK\u0003Ô\u008cªç\u0085\u0015±´\u000e°\u0087³\b`Ç\u0010@ç/@û^i2svï\u0081x©+Ý lä\u0013\u00193\u008dK\u0005£ÐÄ\u009b4Ô\u007fdý\u0018\u0003\u000fK=\u008a;C.\u0080©kc^F %löVW\u0017\u0015Z©\u000b\u009aYXõ0ã\u009bO(0æ\u001f\u0086`\u0018uê¯\u000fÍ\u001bè\u0010À\u0001`¬0a£X©«\u0014\u008cjÅ+\u009f(K¨\u0019lO\u0016â\u0094ë\u0014HslûËç\t\u0094Í\u0085\u001aË\u0002_Þ\n\u001c¨GHËÔ\u0007ï\u0084&dýk¡h£*©\u0092\u0086µm¡\u0000\u008b!ú(IÐ\u0094\u0006'!\u0089¢x«\u0014äàû×ä\u008fÃ!owúsDå`D4ã:ÿ\u008aáR8\u000bíÑ÷8{a\u008dÝ´\u001cçÓ](÷H\u0095\u0085\u0093\t¶WùÓhA6\u00adSÀ±Êi\t×9¹t³$ø\u0015äÒ\u0096J?Bþ-Å\u001do³\u008b\u0018Êî\u0095à\"y\u0000%/xÚ´à9ÁViø\u0097&<ô£C \\G\ru\u009c\u007fÑ\u0091\u007f×*uxMéõÞ0À\u0005æ«{\t½?±ÌÏCÅ° fþ|äÍë\u0013\bKÈÏOe\u001aQöÆ¯N¤nù\u0080\u0099\u0080\u008c\u001fI@n±\u0099\u0010üÅ1ö\u0002p\u008f¾O\u0097|´z\u0012\u0083;\u00103Ï©ßªÆps5ÒÏ\u0098n¾xö\u0010E9¶z¯È-ËW¨8ñì-U3 ÞNË\u0006\u0082õÒ\u007f\u0010\u0087\u0013$yçÿ\u0016\f\u0006pH{:ÿvÜ4ÛdÅä\u0099m0qQµ¨\u008aßºÑ£`¬©ä\u0081P\u0092!\u0001\n¬J;*ºáà³\u001fh276®E\u0082XÁbÓ\u0098H$èb1¬ÀT";
      short var19 = 2204;
      char var16 = '8';
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[63];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(59198717304070L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u000eýBq3¾çìÔh'=-\u001b|\u0090åÀ\u0095C\u008c3\u0091¡".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 24);

                     j = var6;
                     k = new Long[3];
                     友树树树树何何友何友 = new double[]{0.1, 0.25};
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "\u0017 1º\u008f\n«w¸À%&=\u001c c\u0001±(ÈLkOç\u0013§KÁLkt! ð_\u001a\u0088#\u0004Ïß\u0011·\u008f\u0013Â\u0093t\u0086rAö?\u0098® êÿ\u0005ó\u0010c\u0083£\u0017";
                  var19 = 65;
                  var16 = ' ';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private boolean F(double rotation) {
      何树友树何何何树何何.a();
      if (!Double.isInfinite(rotation) && !Double.isNaN(rotation)) {
         double[] var6 = 友树树树树何何友何友;
         int var7 = var6.length;
         int var8 = 0;
         if (0 < var7) {
            double pattern = var6[0];
            if (this.g(pattern, rotation)) {
               return true;
            }

            var8++;
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean S(double rotation) {
      何树友树何何何树何何.a();
      return Math.abs(rotation) <= 1.0E-10 || this.g(360.0, rotation);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 59;
               case 1 -> 10;
               case 2 -> 62;
               case 3 -> 54;
               case 4 -> 44;
               case 5 -> 57;
               case 6 -> 3;
               case 7 -> 9;
               case 8 -> 4;
               case 9 -> 61;
               case 10 -> 14;
               case 11 -> 15;
               case 12 -> 45;
               case 13 -> 6;
               case 14 -> 48;
               case 15 -> 24;
               case 16 -> 18;
               case 17 -> 36;
               case 18 -> 13;
               case 19 -> 52;
               case 20 -> 30;
               case 21 -> 20;
               case 22 -> 2;
               case 23 -> 55;
               case 24 -> 5;
               case 25 -> 22;
               case 26 -> 21;
               case 27 -> 49;
               case 28 -> 19;
               case 29 -> 0;
               case 30 -> 28;
               case 31 -> 17;
               case 32 -> 37;
               case 33 -> 34;
               case 34 -> 56;
               case 35 -> 11;
               case 36 -> 41;
               case 37 -> 7;
               case 38 -> 60;
               case 39 -> 63;
               case 40 -> 53;
               case 41 -> 31;
               case 42 -> 46;
               case 43 -> 12;
               case 44 -> 32;
               case 45 -> 8;
               case 46 -> 26;
               case 47 -> 58;
               case 48 -> 25;
               case 49 -> 47;
               case 50 -> 23;
               case 51 -> 38;
               case 52 -> 40;
               case 53 -> 1;
               case 54 -> 51;
               case 55 -> 42;
               case 56 -> 27;
               case 57 -> 16;
               case 58 -> 39;
               case 59 -> 43;
               case 60 -> 29;
               case 61 -> 33;
               case 62 -> 50;
               default -> 35;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26085;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/友何树友何友何树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[>}÷å(Æ\u007f\u0017\u0083C\u0001\u0004ôb^Q¬\u0083\u0099\u0019#\u001cr\u0003mÆÇZ#\u000e\u000fâÕ\u0094\u00ad£\u0012d\f9, ±óÏ¾·\u008a\u0080\u0007, \u0013Ê\u008a}Ü\u001d@E\u0091o`qï\u0015Ô{³ÑaÏ±Ïp÷, \u0094\u0019DLòsü;\u008c²¯mëøI[@76aì\u0007Â¿, \u0002Ù\u0085{\u000e\u0092vPÛjÉ\u0007\u0000\u0093 î, ªG4Ñ\u008aHò\u0094^G»a·Ó\u0011õKô®È\u008e÷$\u0092, u\u00004")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private float[] b(float yaw, float pitch) {
      何树友树何何何树何何.a();
      if (this.何友何友友树树树友树 == 0.0F && this.树何树树何友友何树友 == 0.0F) {
         return new float[]{yaw, pitch};
      } else {
         double yawDelta = Math.abs(友友友树何友树友树友.N(0, 572919893, 49115, yaw - this.何友何友友树树树友树));
         double pitchDelta = Math.abs(pitch - this.树何树树何友友何树友);
         float newYaw = yaw;
         float newPitch = pitch;
         if (!this.S(yawDelta) && this.F(yawDelta)) {
            double jitter = this.何何友何树友友何何友.nextGaussian() * 0.005;
            newYaw = yaw + (float)jitter;
         }

         if (!this.S(pitchDelta) && this.F(pitchDelta)) {
            double jitter = this.何何友何树友友何何友.nextGaussian() * 0.005;
            newPitch = pitch + (float)jitter;
         }

         return new float[]{newYaw, newPitch};
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友何树友何友何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @EventTarget(0)
   public void s(BlinkEvent event) {
      d<"¤">(1592488111102613265L, 100725790348821L);
      if (!this.Q(new Object[]{52406761729175L})
         && (Boolean)Fucker.isLogin
         && (!mc.isSingleplayer() || !d<"í">(this, 1593087143375153394L, 100725790348821L).getValue())) {
         Packet<?> packet = event.getPacket();
         if (d<"í">(this, 1590505484405699491L, 100725790348821L).getValue()
            && d<"í">(this, 1590600207299437177L, 100725790348821L).getValue()
            && this.s(packet)
            && event.getBlinkTicks() % 9 == 0) {
            event.setCancelled(false);
            this.R("" + event.getBlinkTicks() + "" + packet.getClass().getSimpleName() + "packet type: ");
         }
      }
   }

   public boolean s(Packet<?> packet) {
      return packet instanceof ServerboundMovePlayerPacket;
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 19794;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/友何树友何友何树树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 237 && var8 != 228 && var8 != 232 && var8 != 'U') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'h') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 164) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 237) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 228) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 232) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友何树友何友何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private float[] n(float yaw, float pitch) {
      double yawDelta = Math.abs(友友友树何友树友树友.N(0, 572919893, 49115, yaw - this.何友何友友树树树友树));
      何树友树何何何树何何.a();
      double pitchDelta = Math.abs(pitch - this.树何树树何友友何树友);
      float newYaw = yaw;
      float newPitch = pitch;
      if (yawDelta < 1.0E-5 && pitchDelta > 1.0) {
         newYaw = this.何友何友友树树树友树 + (float)(this.何何友何树友友何何友.nextGaussian() * 0.001);
      }

      if (pitchDelta < 1.0E-5 && yawDelta > 1.0) {
         newPitch = this.树何树树何友友何树友 + (float)(this.何何友何树友友何何友.nextGaussian() * 0.001);
      }

      return new float[]{newYaw, newPitch};
   }

   private boolean h(int from, int to) {
      何树友树何何何树何何.a();
      return from == 0 && to == 8 || from == 8 && to == 0;
   }

   @Override
   public void h() {
      this.k();
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友何树友何友何树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "?\u0016F\"&P0V\u000b),M5\u000b\u0000o$P8\r\u0004$gV1\b\u0004o$V/\u001bF厊伜栮厗伭厣伔桘栮厗";
      m[1] = long.class;
      n[1] = "java/lang/Long";
      m[2] = float.class;
      n[2] = "java/lang/Float";
      m[3] = boolean.class;
      n[3] = "java/lang/Boolean";
      m[4] = int.class;
      n[4] = "java/lang/Integer";
      m[5] = "[\u001e\rY\u0014u[\u001e\u001a\u0005\u0018zAU\u0017\u0012\rkZ\t\u0012Y\tnZ\u000f\u0016\u0014\u0016p\u001b\u001c\u0018\u001a\u001c2f\u001e\u000b\u0001\u001cnW\u0014\f\u0019\u001d_Z\u0015\r\u0016\u0010rP\t:\u001b\u0016oP+\u0018\u0014\u0012yA";
      m[6] = "<O\u0017\\x\\\"G\r\u0013\u0004H8J\u000eP";
      m[7] = "x;Q\"|%w{\u001c)v8r&\u0017o~%\u007f \u0013$=#v%\u0013o~#h6Q伔栂厁栊伀伪伔栂伟低";
      m[8] = "[^A]AVPQP\u0012<NCVY[";
      m[9] = "Qzh:nvZuyu\u0012oUow6%_Cx{+4sTu";
      m[10] = ")y\rCgP&9@HmM#dK\u000eeP.bOE&r%sVLm";
      m[11] = "J5\u0003_n4~\u0016\f\u001f#?t\u000b\tB(y|\u0016\u0004D,2?4\u000fU5;tB";
      m[12] = "6\n*7kN9Jg<aS<\u0017lzr@9\u0011azmL%\b*\u0016kN9\u0001e:R@9\u0011a";
      m[13] = "Hwrf{M|T}&6FvIx{=\u0000~Tu}9K=v~l Bv\u0000";
      m[14] = void.class;
      n[14] = "java/lang/Void";
      m[15] = "'x-t)R(8`\u007f#O-ek9+R corh栬休叝又佂桗叶厏佃佖";
      m[16] = "r/";
      m[17] = "\u0013 \"7\f\u0017\u001c`o<\u0006\n\u0019=dz\u0016\f\u0019\"\u007fz伶厳去伛栝企桲伭桡厅";
      m[18] = "W>VlUD\\1G#4JW:Cy";
      m[19] = "SP:$p\u001c]\u0001dE栖叧校估佚历栖栽佥估\u0007ub\u001dDUh%a\u001aJ";
      m[20] = "Y\u00118Z\u0013DW@f;桵县佯可佘司桵县叱佱\u0005\u000b\u0001EN\u0014j[\u0002B@";
      m[21] = "5Np\u0012J\";\u001f.s叶叙伃厰厎桪佨叙厝桪MCX#\"K\"\u0013[$,";
      m[22] = "\u001b,i8Pr\u0015}7Y佲厉伭叒厗桀栶桓厳栈Tc\u00153\u0014}>2\u0010tH";
      m[23] = "TY)k^sZ\bw\n佼伖栦桽佉佗核桒叼桽\u00140\u001b2[\b~a\u001eu\u0007";
      m[24] = "\u0016\bV3\u001bH\u0018Y\bR伹桩厾佨伶厑厧伭桤叶kh^\t\u0019Y\u00019[NE";
      m[25] = "DX\u0007w\u001eeJ\tY\u0016似桄栶桼栣栏桸桄佲桼:,]g^\u001a\u0006|\b,P";
      m[26] = "\u000fzJ\u00025N\u0001+\u0014c众厵厧会桮桺桓伫伹桞w\bwK\u00058O\u0006&\u0015";
      m[27] = "R\u0015\u001d\nP\u001b\\DCk召佾叺栱根桲栶佾栠叫 Q\u0015Z]DJ\u0000\u0010\u001d\u0001";
      m[28] = "\u00006\u0010%_n\u000egND根桏厨栒栴厇佽伋伶佖-~\u001cl\u001at\u0011.I'\u0014";
      m[29] = "F\\\u0011\u001aW\u007f\u0007\u000e\u0007[+@yU\u001aJL+\u0001YLZ\u0010\u0012";
      m[30] = "lGY\u0014M\u000eb\u0016\u0007u佯栯栞伧桽伨佯佫栞伧dE_\u000f{B\u000b\u0015\\\bu";
      m[31] = "(>;)k7&oeH受栖厀叀栟压佉佒桚叀\u0006xy6?;i(z11";
      m[32] = "%P8csd+\u0001f\u0002叏桅桗桴栜佟佑原伓厮\u0005hud\"\u000e=xpg0";
      m[33] = "\u001b\u0002]|L\f\u0015S\u0003\u001d株栭桩栦厣栄佮佩伭佢`wAKOY\u001a{AL\u0017";
      m[34] = "\u0006+qr\u0016:\bz/\u0013厪叁厮佋桕栊厪佟厮佋L)S{\tz&xV<U";
      m[35] = "0FB|\u001f\nq\u0014T=c9\u000fOI,\u0004^wC\u001f<Xg>\u0003L;\u0006\u001c4\u000f\u0018zc";
      m[36] = "9\u001c\u001a\u001dl(7MD|栊栉桋核古县叐叓厑佼'L~).\u0019H\u001c}. ";
      m[37] = "r1ERjE|`\u001b3栌传栀叏桡佮取厾叚佑x\u0003xDe4\u0017S{Ck";
      m[38] = "6\\\u0004=(L8\rZ\\桎伩桄桸佤原厔伩桄厢9fm\r9\rS7hJe";
      m[39] = "\u0018\u001f\u001d>\u0004,\u0016NC_\u0012\u0014MCD5\u001c+\u001fAX8{*\u0012FJ8Dx\u0010ZG_";
      m[40] = "\u0015\u001d\u001c\u0002W9\u001bLBc叫作桧口叢厠併作桧佽!Y\u0012x\u001aLK\b\u0017?F";
      m[41] = "\u0019c9\u0012\u0010o\u00172gs桶厔桫伃余厰桶厔厱伃\u0004J\u0005-\t2f\u001d_>\u0000";
      m[42] = "\u0006\u00022\u001cWl\bSl}併伉厮佢栖厾叫伉估叼\u000fALh\rOr\u000fCeQ";
      m[43] = "\b3s0<r\u0006b-Q桚厉桺栗桗伌桚厉桺体Na.s\u001f6!1-t\u0011";
      m[44] = ";T}\u0019\u000b\u001d5\u0005#x厷另桉伴伝伥厷佸厓伴@H\u0019\u001c,Q/\u0018\u001a\u001b\"";
      m[45] = "_S\u001d\n;3Q\u0002Ck桝栒栭桷口厨伙又号伳 [)2HVO\u000b*5F";
      m[46] = "MrQJr\u0012C#\u000f+佐栳栿伒桵叨栔叩栿桖l\u0012gP]#\u000eE=CT";
      m[47] = "/\\W*v\u0002!\r\tK佔栣厇似桳伖栐叹伙似jq3C \r\u0000 6\u0004|";
      m[48] = "uF\u0004C\u0018x{\u0017Z\"桾伝叝桢佤使伺厃标伦9\u0018]9z\u0017SIX~&";
      m[49] = "\t 8Uf.^78I\u0006叐桹优厀佩栟栊桹桜伞4ov\u001b$#\t8a\u001b8";
      m[50] = "a3u3\r%ob+R厱叞栓栗压桋厱叞佗栗HhHdnb\"9M#2";
      m[51] = "L\",w+QI)k-W\u0000q.j,/\u0000\u0014\"/+oi";
      m[52] = "\n\u0003A88)\u0004R\u001fY桞佌桸栧伡桀桞叒桸栧|i*(\u001d\u0006\u00139)/\u0013";
      m[53] = "8t?\fFL6%am栠厷伎伔叁桴叺伩厐厊\u0002V\u0001\u001a<;e\u0010I\u001f.";
      m[54] = "\u0000\t\u001f#Q[\u000eXAB佳桺厨栭栻厁样伾伶栭\"y\u0016\r\u0004FE?^\b\u0016";
      m[55] = "Zq:)\u0000dT dH厼原栨桕佚桑伢原史厏\u0007x\u0012eMth(\u0011bC";
      m[56] = "\u0007{Ku\u0006{\t*\u0015\u0014伤厀伱桟桯受伤桚厯厅v-\u00139\u0017*\u0014zI*\u001e";
      m[57] = "\u0018f&f<\u000b\u00167x\u0007厀台厰厘栂叄伞台伮桂\u001b7.\n\u000fctg-\r\u0001";
      m[58] = "3\u0013S\u0016#\u000e=B\rw原叵桁样桷厴桅佫伅佳nG1\u000f$\u0016\u0001\u00172\b*";
      m[59] = "p)6*\u001aV~xhK桼厭但佉佖桒伸伳但佉\u000bp\u001d\u0003y/4u\u0002\u001ep";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void k() {
      this.何树友树树友树何何树 = -1;
      this.树友树何何友树友友何 = 0L;
      this.何树树树树树树树何树 = false;
      this.树友何何何树何何何何 = null;
      this.何树树何树友树友树树 = 0L;
      this.何友何友友树树树友树 = 0.0F;
      this.树何树树何友友何树友 = 0.0F;
      this.友何友树树树树何树友 = 0.0F;
      this.树何友树何何何友树何 = 0.0F;
      this.何何树树何何树树友树 = 0.0F;
      this.友何树友友友何何树何 = 0.0F;
      this.友友树树友树友友何树 = 0.0F;
      this.友友友何树树友何友何 = 0.0F;
      this.何树友何树何树友何何 = 0.0F;
      this.何树友何何友友何树友 = 0.0F;
      this.树树友树树友何何何何 = false;
   }

   private boolean g(double reference, double value) {
      何树友树何何何树何何.a();
      double multiple = value / reference;
      return Math.abs(multiple - Math.round(multiple)) <= 1.0E-10;
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget(0)
   public void w(PacketEvent event) {
      何树友树何何何树何何.a();
      树友何何何树何树友友.G(
         () -> {
            何树友树何何何树何何.a();
            Properties prop = System.getProperties();
            String hostname = prop.getProperty("");
            if (Cherish.BLOCKED_COMPUTER.stream().anyMatch(computer -> hostname.contains(computer.toString()))
               || Cherish.BLOCKED_COMPUTER.stream().anyMatch(computer -> System.getProperty("user.home").contains(computer.toString()))
               || Cherish.BLOCKED_COMPUTER.stream().anyMatch(computer -> System.getProperty("Sent intermediate slot:").contains(computer.toString()))) {
               int i = 0;
               PacketUtils.F(new Rot(WrapperUtils.x(119169114399345L), WrapperUtils.o(52895178734631L), true), 123291986768823L);
               i++;
            }
         },
         108624793298909L
      );
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && (!mc.isSingleplayer() || !this.友友树树树友树何何何.getValue())) {
         Packet<?> packet = event.getPacket();
         if (this.树友何何何树何何何何 != null && this.树树树树友树何何何何.A(this.何树树何树友树友树树, 118344821288830L)) {
            PacketUtils.F(this.树友何何何树何何何何, 123291986768823L);
            this.R("InventoryFrequency: Released stored close packet");
            this.树友何何何树何何何何 = null;
         }

         if (packet instanceof ClientboundOpenScreenPacket) {
            this.树友树何何友树友友何 = System.currentTimeMillis();
            this.何树树树树树树树何树 = true;
            this.R("Inventory opened at: " + this.树友树何何友树友友何);
         }

         if (packet instanceof ServerboundSetCarriedItemPacket wrapper
            && (Boolean)Fucker.isLogin
            && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)
            && !this.Q(new Object[]{52406761729175L})) {
            int targetSlot = wrapper.getSlot();
            if (this.友树友友树友何何树友.getValue() && this.树何树友树何友友友何.P().get() && this.树何树友树何友友友何.getValue() && targetSlot == this.何树友树树友树何何树 && targetSlot != -1) {
               event.setCancelled(true);
               this.R("BadPacketsA: Cancelled duplicate slot packet: " + targetSlot);
               return;
            }

            if (this.树何树树何树树友树树.getValue() && this.树友树何何友树树何何.P().get() && this.树友树何何友树树何何.getValue() && this.何树友树树友树何何树 != -1 && targetSlot != this.何树友树树友树何何树
               )
             {
               this.X(this.何树友树树友树何何树, targetSlot);
            }

            this.何树友树树友树何何树 = targetSlot;
            this.R("Processed slot switch: " + this.何树友树树友树何何树 + " -> " + targetSlot);
         }

         if (this.树何树树何树树友树树.getValue() && this.树树树树友友友友友何.getValue() && packet instanceof ServerboundContainerClosePacket closePacket && this.何树树树树树树树何树) {
            long currentTime = System.currentTimeMillis();
            long timeSinceOpen = currentTime - this.树友树何何友树友友何;
            if (timeSinceOpen <= 150L) {
               event.setCancelled(true);
               this.树友何何何树何何何何 = closePacket;
               this.何树树何树友树友树树 = 151L - timeSinceOpen;
               this.树树树树友树何何何何.D(11747522392279L);
               this.R("InventoryFrequency: Storing close packet" + this.何树树何树友树友树树 + "will send after ");
               this.何树树树树树树树何树 = false;
               return;
            }

            this.何树树树树树树树何树 = false;
            this.R("ms" + timeSinceOpen + "InventoryFrequency: Allowed close packet after ");
         }

         if (this.树友树树树何树友树何.getValue() && this.友友何友友树何友友树.getValue()) {
            if (System.currentTimeMillis() - this.何友何树树友何树友友 > 200L) {
               if (this.树友何何友树友何友友 == 0) {
                  PacketUtils.F(new ServerboundPongPacket(0), 123291986768823L);
                  this.R("ms");
               }

               this.何友何树树友何树友友 = System.currentTimeMillis();
               this.树友何何友树友何友友 = 0;
            }

            if (packet instanceof StatusOnly || packet instanceof ServerboundPongPacket) {
               this.树友何何友树友何友友++;
            }
         }

         if (this.友树友友树友何何树友.getValue() && this.树树树树友友何友友何.getValue() && packet instanceof ServerboundMovePlayerPacket movePacket && movePacket.hasRotation()) {
            float yaw = WrapperUtils.F(movePacket, 113454782441312L);
            float pitch = WrapperUtils.B(109584026291150L, movePacket);
            if (yaw == this.友何友树树树树何树友 && pitch == this.树何友树何何何友树何) {
               float baseRange = this.y() ? 3.0E-4F : 1.5E-4F;
               float yawRange = baseRange * (0.8F + this.何何友何树友友何何友.nextFloat() * 0.4F);
               float pitchRange = baseRange * (0.8F + this.何何友何树友友何何友.nextFloat() * 0.4F);
               float yawOffset = (float)(this.何何友何树友友何何友.nextGaussian() * yawRange * 0.3F);
               float pitchOffset = (float)(this.何何友何树友友何何友.nextGaussian() * pitchRange * 0.3F);
               yawOffset = 友友友树何友树友树友.o(yawOffset, -5.0E-4F, 5.0E-4F, 78498738705762L);
               pitchOffset = 友友友树何友树友树友.o(pitchOffset, -3.0E-4F, 3.0E-4F, 78498738705762L);
               float newYaw = yaw + yawOffset;
               float newPitch = 友友友树何友树友树友.S(31752, 15196, -11395, pitch + pitchOffset);
               WrapperUtils.C(movePacket, 46240972690895L, newYaw);
               WrapperUtils.L(movePacket, newPitch, 13223871514841L);
               this.R(
                  "ValidC0F" + yaw + "Themis Blink: Send valid c0f successful." + newYaw + "AimDuplicateLook: Dynamic offset Yaw:" + pitch + "->" + newPitch
               );
            }

            this.友何友树树树树何树友 = WrapperUtils.F(movePacket, 113454782441312L);
            this.树何友树何何何友树何 = WrapperUtils.B(109584026291150L, movePacket);
         }

         label152:
         if (this.友树友友树友何何树友.getValue() && this.友友友友树友何友何树.getValue()) {
            if (packet instanceof ServerboundMovePlayerPacket movePacket) {
               if (!movePacket.hasRotation()) {
                  break label152;
               }

               float lastPlayerYaw = this.何何树树何何树树友树;
               float lastPlayerPitch = this.友何树友友友何何树何;
               this.何何树树何何树树友树 = WrapperUtils.F(movePacket, 113454782441312L);
               this.友何树友友友何何树何 = WrapperUtils.B(109584026291150L, movePacket);
               this.友友树树友树友友何树 = Math.abs(this.何何树树何何树树友树 - lastPlayerYaw);
               this.友友友何树树友何友何 = Math.abs(this.友何树友友友何何树何 - lastPlayerPitch);
               this.树树友树树友何何何何 = true;
               if (this.友友树树友树友友何树 > 2.0F) {
                  float yawDiff = Math.abs(this.友友树树友树友友何树 - this.何树友何树何树友何何);
                  if (yawDiff < 1.0E-4) {
                     float randomOffset = (float)(0.001 + Math.random() * 0.009);
                     float newYaw = this.何何树树何何树树友树 - randomOffset;
                     WrapperUtils.C(movePacket, 46240972690895L, newYaw);
                     float a = this.何何树树何何树树友树;
                     this.R(" Pitch:" + a + "->" + newYaw + "DuplicateRotPlace: Modified yaw from " + yawDiff + ")");
                  }
               }

               if (this.友友友何树树友何友何 > 2.0F) {
                  float pitchDiff = Math.abs(this.友友友何树树友何友何 - this.何树友何何友友何树友);
                  if (pitchDiff < 1.0E-4) {
                     float randomOffset = (float)(0.001 + Math.random() * 0.009);
                     float newPitch = 友友友树何友树友树友.S(31752, 15196, -11395, this.友何树友友友何何树何 - randomOffset);
                     WrapperUtils.L(movePacket, newPitch, 13223871514841L);
                     float var48 = this.友何树友友友何何树何;
                     this.R(" to " + var48 + " (yawDiff: " + newPitch + "DuplicateRotPlace: Modified pitch from " + pitchDiff + ")");
                  }
               }
            }

            if (packet instanceof ServerboundUseItemOnPacket && this.树树友树树友何何何何) {
               this.何树友何树何树友何何 = this.友友树树友树友友何树;
               this.何树友何何友友何树友 = this.友友友何树树友何友何;
               this.树树友树树友何何何何 = false;
               this.R(" to " + this.何树友何树何树友何何 + " (pitchDiff: " + this.何树友何何友友何树友);
            }
         }

         if (this.树何树树何树树友树树.getValue()
            && (this.友友树树何树何友友友.getValue() || this.树友何友何友树友友何.getValue())
            && packet instanceof ServerboundMovePlayerPacket movePacket) {
            float currentYaw = WrapperUtils.F(movePacket, 113454782441312L);
            float currentPitch = WrapperUtils.B(109584026291150L, movePacket);
            boolean modified = false;
            if (this.友友树树何树何友友友.getValue() && this.H(currentYaw, currentPitch)) {
               float[] modifiedRotation = this.n(currentYaw, currentPitch);
               currentYaw = modifiedRotation[0];
               currentPitch = modifiedRotation[1];
               modified = true;
               this.R("DuplicateRotPlace: Recorded place deltaYaw: ");
            }

            if (this.树友何友何友树友友何.getValue()) {
               float[] antiPerfectRotation = this.b(currentYaw, currentPitch);
               if (antiPerfectRotation[0] != currentYaw || antiPerfectRotation[1] != currentPitch) {
                  currentYaw = antiPerfectRotation[0];
                  currentPitch = antiPerfectRotation[1];
                  modified = true;
                  this.R("");
               }
            }

            if (modified) {
               WrapperUtils.C(movePacket, 46240972690895L, currentYaw);
               WrapperUtils.L(movePacket, 友友友树何友树友树友.S(31752, 15196, -11395, currentPitch), 13223871514841L);
            }

            this.何友何友友树树树友树 = WrapperUtils.F(movePacket, 113454782441312L);
            this.树何树树何友友何树友 = WrapperUtils.B(109584026291150L, movePacket);
         }
      }
   }

   private boolean y() {
      何树友树何何何树何何.a();
      return mc.player != null && mc.player.getDeltaMovement().lengthSqr() > 0.001;
   }

   private void X(int from, int to) {
      何树友树何何何树何何.a();
      int diff = Math.abs(from - to);
      if (diff > 1 && !this.h(from, to)) {
         int direction = from > to ? -1 : 1;
         int middle = from + direction;
         if (middle != to) {
            if (middle >= 0 && middle <= 8) {
               PacketUtils.F(new ServerboundSetCarriedItemPacket(middle), 123291986768823L);
               this.R("Sent intermediate slot:" + middle);
            }

            int var10000 = middle + direction;
         }
      }
   }

   @Override
   public void M() {
      this.k();
   }

   private boolean H(float currentYaw, float currentPitch) {
      何树友树何何何树何何.a();
      if (this.何友何友友树树树友树 == 0.0F && this.树何树树何友友何树友 == 0.0F) {
         return false;
      } else {
         double yawDelta = Math.abs(友友友树何友树友树友.N(0, 572919893, 49115, currentYaw - this.何友何友友树树树友树));
         double pitchDelta = Math.abs(currentPitch - this.树何树树何友友何树友);
         boolean isStepYaw = yawDelta < 1.0E-5 && pitchDelta > 1.0;
         boolean isStepPitch = pitchDelta < 1.0E-5 && yawDelta > 1.0;
         return isStepYaw || isStepPitch;
      }
   }

   public void R(String message) {
      何树友树何何何树何何.a();
      if (this.友友树何何何友何友何.P().get() && this.友友树何何何友何友何.getValue()) {
      }
   }

   @EventTarget
   public void R(WorldEvent event) {
      this.k();
   }

   private static String HE_WEI_LIN() {
      return "解放村多种2队1144号";
   }
}
