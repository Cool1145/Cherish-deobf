package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.player.树何何何树何友何树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友何树树何何何树树何 extends Module implements 何树友 {
   private final NumberValue 何树友何何何友友树树;
   private final NumberValue 友何何友友树友树树友;
   private final BooleanValue 友树树树何树树何友树;
   private final BooleanValue 树树何何何树友友树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[33];
   private static final String[] k = new String[33];
   private static String HE_WEI_LIN;

   public 友何树树何何何树树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/movement/友何树树何何何树树何.a J
      // 03: ldc2_w 76365229495503
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 20060
      // 0c: ldc2_w 2794939526324538438
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic l (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何树树何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 15195
      // 19: ldc2_w 3290320912338467142
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic l (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何树树何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w -5947936428661304705
      // 26: lload 1
      // 27: invokedynamic è (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/movement/友何树树何何何树树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/NumberValue
      // 33: dup
      // 34: sipush 7751
      // 37: ldc2_w 5351528745356205151
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic l (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何树树何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: dconst_1
      // 42: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 45: ldc2_w 0.1
      // 48: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 4b: ldc2_w 5.0
      // 4e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 51: ldc2_w 0.1
      // 54: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 57: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 5a: putfield cn/cool/cherish/module/impl/movement/友何树树何何何树树何.何树友何何何友友树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 5d: aload 0
      // 5e: new cn/cool/cherish/value/impl/NumberValue
      // 61: dup
      // 62: sipush 10254
      // 65: ldc2_w 2049755712168471061
      // 68: lload 1
      // 69: lxor
      // 6a: invokedynamic l (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何树树何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6f: dconst_1
      // 70: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 73: ldc2_w 0.1
      // 76: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 79: ldc2_w 5.0
      // 7c: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 7f: ldc2_w 0.1
      // 82: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 85: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 88: putfield cn/cool/cherish/module/impl/movement/友何树树何何何树树何.友何何友友树友树树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 8b: aload 0
      // 8c: new cn/cool/cherish/value/impl/BooleanValue
      // 8f: dup
      // 90: sipush 19701
      // 93: ldc2_w 8423543733678362348
      // 96: lload 1
      // 97: lxor
      // 98: invokedynamic l (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何树树何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 9d: bipush 1
      // 9e: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // a1: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/Boolean;)V
      // a4: putfield cn/cool/cherish/module/impl/movement/友何树树何何何树树何.友树树树何树树何友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // a7: aload 0
      // a8: new cn/cool/cherish/value/impl/BooleanValue
      // ab: dup
      // ac: sipush 26846
      // af: ldc2_w 3298468773225523906
      // b2: lload 1
      // b3: lxor
      // b4: invokedynamic l (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何树树何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // b9: bipush 0
      // ba: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // bd: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/Boolean;)V
      // c0: putfield cn/cool/cherish/module/impl/movement/友何树树何何何树树何.树树何何何树友友树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // c3: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-1950460057268831239L, 8234863700424529728L, MethodHandles.lookup().lookupClass()).a(235855049737770L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 109921312181620L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[6];
      int var7 = 0;
      String var6 = "\u00886;\u0001\u009d%ÜüÇuÛÓé\u008c\u007f\u0095\u0081\u0080OÄb½)è¾9c/Í\u0083\u000e¡d\u0011î¶4ãI\u0096o\u0084\u009cU8×=C\u0018j%l÷eHD\u0083¨à=\u0096@\r\u0011¾I!©\u0099\u008a¼\u001fW\u0010¡nÞ¢$ñç\u001e\u001døÔ\u0089bZÖ³ ¾.AÊ>ó±\u0092DMÃ\u0001øJ\\\u0081\u0001ó°\u0017ø!§\u0082\u009dôÊò\u0098}\u0093ú";
      byte var8 = 123;
      char var5 = '0';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[6];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u0085ÔÈ\u0017Q·N\u00054`\u008eÂ9\u0088\u0092ãi\u0095\u0007\u0015Ý\u0083«º¤¸\u0096\u001eçG\u0012\u0093`~µ\u001e¹`ó]\u0010@¼å¶\u0083é'9\u009d\u0014IxP®\u008b\u0086";
                  var8 = 57;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   protected void F() {
      long a = 友何树树何何何树树何.a ^ 105365191879758L;
      long ax = a ^ 48869803994330L;
      long axx = a ^ 91390451462248L;
      c<"R">(6195304182742955515L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"S">(this, 6194636392896670988L, a).getValue()) {
            树何何何树何友何树何.Y(axx);
         }
      }
   }

   @EventTarget
   public void I(MotionEvent event) {
      long a = 友何树树何何何树树何.a ^ 99381011415425L;
      long ax = a ^ 45924683989269L;
      c<"R">(4050180697402759220L, a);
      if (!this.w(new Object[]{ax})) {
         mc.player
            .setDeltaMovement(c<"S">(mc.player.getDeltaMovement(), 4052046511698020723L, a), 0.0, c<"S">(mc.player.getDeltaMovement(), 4051156967312154514L, a));
         int hSpeed = c<"S">(this, 4051276761721780166L, a).getValue().intValue();
         int vSpeed = c<"S">(this, 4051836183335731813L, a).getValue().intValue();
         if (c<"S">(c<"S">(mc, 4051433600158959232L, a), 4051553495891008278L, a).isDown()) {
            mc.player
               .setDeltaMovement(
                  c<"S">(mc.player.getDeltaMovement(), 4052046511698020723L, a), vSpeed, c<"S">(mc.player.getDeltaMovement(), 4051156967312154514L, a)
               );
         }

         if (c<"S">(c<"S">(mc, 4051433600158959232L, a), 4052039274820257844L, a).isDown()) {
            mc.player
               .setDeltaMovement(
                  c<"S">(mc.player.getDeltaMovement(), 4052046511698020723L, a), -vSpeed, c<"S">(mc.player.getDeltaMovement(), 4051156967312154514L, a)
               );
         }

         if (c<"S">(mc.player, 4051013047089654147L, a) != 0.0F || c<"S">(mc.player, 4051496655646084409L, a) != 0.0F) {
            float forward = c<"S">(mc.player, 4051013047089654147L, a);
            float strafe = c<"S">(mc.player, 4051496655646084409L, a);
            float yaw = mc.player.getYRot();
            double sin = Math.sin(Math.toRadians(yaw));
            double cos = Math.cos(Math.toRadians(yaw));
            double motionX = (strafe * cos - forward * sin) * hSpeed;
            double motionZ = (forward * cos + strafe * sin) * hSpeed;
            mc.player.setDeltaMovement(motionX, c<"S">(mc.player.getDeltaMovement(), 4051910510952279135L, a), motionZ);
         }

         c<"í">(mc.player, 0.0F, 4051780592742029297L, a);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 10;
               case 1 -> 22;
               case 2 -> 57;
               case 3 -> 2;
               case 4 -> 43;
               case 5 -> 39;
               case 6 -> 11;
               case 7 -> 13;
               case 8 -> 55;
               case 9 -> 24;
               case 10 -> 51;
               case 11 -> 17;
               case 12 -> 3;
               case 13 -> 6;
               case 14 -> 30;
               case 15 -> 8;
               case 16 -> 53;
               case 17 -> 59;
               case 18 -> 54;
               case 19 -> 9;
               case 20 -> 25;
               case 21 -> 19;
               case 22 -> 21;
               case 23 -> 28;
               case 24 -> 5;
               case 25 -> 20;
               case 26 -> 63;
               case 27 -> 34;
               case 28 -> 52;
               case 29 -> 60;
               case 30 -> 12;
               case 31 -> 41;
               case 32 -> 27;
               case 33 -> 49;
               case 34 -> 37;
               case 35 -> 4;
               case 36 -> 32;
               case 37 -> 48;
               case 38 -> 16;
               case 39 -> 29;
               case 40 -> 15;
               case 41 -> 40;
               case 42 -> 42;
               case 43 -> 33;
               case 44 -> 7;
               case 45 -> 44;
               case 46 -> 58;
               case 47 -> 36;
               case 48 -> 35;
               case 49 -> 50;
               case 50 -> 38;
               case 51 -> 61;
               case 52 -> 56;
               case 53 -> 47;
               case 54 -> 62;
               case 55 -> 1;
               case 56 -> 31;
               case 57 -> 45;
               case 58 -> 18;
               case 59 -> 0;
               case 60 -> 26;
               case 61 -> 46;
               case 62 -> 23;
               default -> 14;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何树树何何何树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12139;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何树树何何何树树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何树树何何何树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'S' && var8 != 237 && var8 != 232 && var8 != 'q') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 251) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'R') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'S') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 237) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 232) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "\bSX=zx\u0007\u0013\u00156pe\u0002N\u001epxx\u000fH\u001a;;~\u0006M\u001apxx\u001dX\u001b;{cE叶伣桏栄佂伾佨桧桏佀";
      j[1] = "\f\u0019&vz)\u0003Yk}p4\u0006\u0004`;c'\u0003\u0002m;|+\u001f\u001b&Wz)\u0003\u0012i{C'\u0003\u0002m";
      j[2] = "2sE0&U2sRl*Z(8Rr\"Y2b\u001fn']%sC0\u0007S?w]N']%sC";
      j[3] = int.class;
      k[3] = "java/lang/Integer";
      j[4] = "lf8BJ`gi)\r6yhs'N\u0001I~d+S\u0010eii";
      j[5] = "?S^\u001d\\\u00180\u0013\u0013\u0016V\u00055N\u0018P^\u00188H\u001c\u001b\u001d\u001e1M\u001cP^\u0018*X\u001d\u001b]\u0003r佨去伫司厼桍叶去伫佦";
      j[6] = "S\np|\u007fFX\u0005a3\u0002^K\u0002hz";
      j[7] = "KJy:8\u0005D\n412\u0018AW?w:\u0005LQ;<y伿佽可伂伌厜伿佽栵框";
      j[8] = ":\u0006OL\u0003U5F\u0002G\tH0\u001b\t\u0001\u001a[5\u001d\u0004\u0001\u0005W)\u0004Oa\u0019W;\r\u0013y\rV,\r";
      j[9] = "|\u0016\u0015\u001c7H|\u0016\u0002@;Gf]\u0002^3D|\u0007O\u007f3Ow\u0010\u0013S<U";
      j[10] = "4(R\u000e*\b4(ER&\u0007.cEL.\u000449\bo7\u00153\"HS";
      j[11] = float.class;
      k[11] = "java/lang/Float";
      j[12] = "h\u0013aR\u000eQh\u0013v\u000e\u0002^rXb\u0013\u0011TbXe\u0014\u001aK( p\u001fP";
      j[13] = double.class;
      k[13] = "java/lang/Double";
      j[14] = "'{h^\r`'{\u007f\u0002\u0001o=0\u007f\u001c\tl'j2;\u0005p\u0004\u007fl\u0000\tg.";
      j[15] = "6\\wbSY=Sf-2W6Xbw";
      j[16] = "\u0012\u0005+tz\u0000I\u0004&\f佀桠只伻优佑叞厺栰桿E1bFW\u0007!peI\u0010";
      j[17] = "t\u0007\u001fxFG/\u0006\u0012\u0000叢栧桖桽伬栙核佣厌桽q\u007f[^>\u000bNe\u0011F";
      j[18] = "\tr+Z3{\becAU{`,k\u0006k+`\u001dm[9+G`=\u000f9e";
      j[19] = "O\u0007<==n\u001b\u001c3dL8!Ag4tn!{o9 h\u000b\u001bo4+l";
      j[20] = "5\u0014\u001ar\u0001#a\u000f\u0015+pu[RA{H![hIv\u001c%q\bI{\u0017!";
      j[21] = "\u0003I6W\u0011SWR9\u000e`\u0005m\u000fm^YUm5o\r\u0018ZW\bj\t\u0003\u000f";
      j[22] = "\u0015fXDP\"Ek^\u001d:tr&\u0006H\n#r\u0016\rDV{@zW\u0016\u0000'";
      j[23] = "\u001bamOP=@``7栮桝佽佟佞栮叴厇根佟\u0003HM$Qm<R\u0007<";
      j[24] = "_Q,213\u0004P!J厕众伹叱厁桓厕桓桽叱Bw)u\u001aS&6.z]";
      j[25] = "Z\u007fXt\u0011\u001d\nr^-{K=?\u0006xK\u001d=\u000f\rt\u0017D\u000fcW&A\u0018";
      j[26] = "v(,O^:&|,\u0001.)\u001e|zI\u001f\u007f\u001eM)\u001b\u0014705~\u0011\u00125";
      j[27] = "O\u0004xfR,\u001f\t~?8z(D&j\u0007%(t-fTu\u001a\u0018w4\u0002)";
      j[28] = "\u0010\bT=H`@\\Ts8sx\\\u0002;\b,xmQi\u0002mV\u0015\u0006c\u0004o";
      j[29] = "&c0\u0016M\"}b=nC[&95S\u0010?va \u0014*`$kcTN0|~$n";
      j[30] = "z\u001cIa6Q#MC|Z厫厄栾栿佁厙厫会栾句\u001cgS(ZJ%>\u0002\"G";
      j[31] = "\fj+<I-Xq$e8{b/y;\b$b\u0016x8T+Hvx5_/";
      j[32] = "\u0004TD[P\u0019C\u000eHP \u001f?\u000f\u0016LG\u0014DM\u0013\u001a@y";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 友何树树何何何树树何.a ^ 28081770770345L;
      long ax = a ^ 116737586720573L;
      c<"R">(-7629834398425188836L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"S">(this, -7633278042684341970L, a).getValue()) {
            mc.player.handleEntityEvent((byte)2);
            c<"í">(mc.player, 10, -7633576997355940119L, a);
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_WEI_LIN() {
      return "何炜霖诈骗";
   }
}
