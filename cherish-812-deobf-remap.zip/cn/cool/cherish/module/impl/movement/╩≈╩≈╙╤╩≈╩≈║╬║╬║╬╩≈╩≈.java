package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.combat.KillAura;
import cn.cool.cherish.module.impl.player.何何友何友树友友何何;
import cn.cool.cherish.utils.render.友友树何树树友树友何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.JumpEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class 树树友树树何何何树树 extends Module implements 何树友 {
   public static 树树友树树何何何树树 何友友树树友树树何友;
   public final ModeValue 树何树树友树何树树何;
   private final NumberValue 友友友友何树树友何何;
   private final BooleanValue 树友何友树何友树树何;
   private final BooleanValue 树树友何何树树树友友;
   private final BooleanValue 何友何友树友何何何何;
   private final BooleanValue 友何何树何友何友友树;
   private boolean 友何树何何何何何友友;
   public boolean 何树友何树树何树树友;
   private int 友何树友树树树友何树;
   private boolean 友何友树友树树友友树;
   private boolean 何树友友树友友何树友;
   public static boolean 何友树何何树何树何树;
   public static boolean 友树树树树树友树树友;
   public float 友何树友何树友友树何;
   private int 树树何树友友树何树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[60];
   private static final String[] k = new String[60];
   private static int _何炜霖国企变私企 _;

   public 树树友树树何何何树树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/movement/树树友树树何何何树树.a J
      // 003: ldc2_w 42549203561732
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 10632
      // 00c: ldc2_w 1405896672201138981
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 22288
      // 019: ldc2_w 6411199120585334201
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w -5186955178177542752
      // 026: lload 1
      // 027: invokedynamic t (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/ModeValue
      // 033: dup
      // 034: sipush 5626
      // 037: ldc2_w 1882502122340867924
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 13130
      // 044: ldc2_w 9054646276777277934
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 2
      // 04f: anewarray 89
      // 052: dup
      // 053: bipush 0
      // 054: sipush 4071
      // 057: ldc2_w 3899498843198539089
      // 05a: lload 1
      // 05b: lxor
      // 05c: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 061: aastore
      // 062: dup
      // 063: bipush 1
      // 064: sipush 17288
      // 067: ldc2_w 4388779409244490023
      // 06a: lload 1
      // 06b: lxor
      // 06c: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 071: aastore
      // 072: sipush 4071
      // 075: ldc2_w 3899498843198539089
      // 078: lload 1
      // 079: lxor
      // 07a: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07f: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 082: putfield cn/cool/cherish/module/impl/movement/树树友树树何何何树树.树何树树友树何树树何 Lcn/cool/cherish/value/impl/ModeValue;
      // 085: aload 0
      // 086: new cn/cool/cherish/value/impl/NumberValue
      // 089: dup
      // 08a: sipush 27048
      // 08d: ldc2_w 7409987645104923394
      // 090: lload 1
      // 091: lxor
      // 092: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 097: sipush 21530
      // 09a: ldc2_w 1987329324334948026
      // 09d: lload 1
      // 09e: lxor
      // 09f: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a4: ldc2_w 2.0
      // 0a7: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0aa: ldc2_w 0.5
      // 0ad: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0b0: ldc2_w 6.0
      // 0b3: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0b6: ldc2_w 0.1
      // 0b9: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0bc: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0bf: putfield cn/cool/cherish/module/impl/movement/树树友树树何何何树树.友友友友何树树友何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 0c2: aload 0
      // 0c3: new cn/cool/cherish/value/impl/BooleanValue
      // 0c6: dup
      // 0c7: sipush 18369
      // 0ca: ldc2_w 5003194004750765430
      // 0cd: lload 1
      // 0ce: lxor
      // 0cf: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d4: sipush 4876
      // 0d7: ldc2_w 2472527001213295018
      // 0da: lload 1
      // 0db: lxor
      // 0dc: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e1: bipush 0
      // 0e2: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0e5: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0e8: aload 0
      // 0e9: invokedynamic get (Lcn/cool/cherish/module/impl/movement/树树友树树何何何树树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/movement/树树友树树何何何树树.j ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 0ee: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0f1: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 0f4: putfield cn/cool/cherish/module/impl/movement/树树友树树何何何树树.树友何友树何友树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0f7: aload 0
      // 0f8: new cn/cool/cherish/value/impl/BooleanValue
      // 0fb: dup
      // 0fc: sipush 5156
      // 0ff: ldc2_w 4169360811066809985
      // 102: lload 1
      // 103: lxor
      // 104: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 109: sipush 5576
      // 10c: ldc2_w 1449838090775584608
      // 10f: lload 1
      // 110: lxor
      // 111: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 116: bipush 0
      // 117: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 11a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 11d: aload 0
      // 11e: invokedynamic get (Lcn/cool/cherish/module/impl/movement/树树友树树何何何树树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/movement/树树友树树何何何树树.J ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 123: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 126: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 129: putfield cn/cool/cherish/module/impl/movement/树树友树树何何何树树.树树友何何树树树友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 12c: ldc2_w -5188001997175544394
      // 12f: lload 1
      // 130: invokedynamic L (JJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 135: aload 0
      // 136: new cn/cool/cherish/value/impl/BooleanValue
      // 139: dup
      // 13a: sipush 19808
      // 13d: ldc2_w 1095586130397595587
      // 140: lload 1
      // 141: lxor
      // 142: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 147: sipush 28863
      // 14a: ldc2_w 7333164474524547613
      // 14d: lload 1
      // 14e: lxor
      // 14f: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 154: bipush 0
      // 155: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 158: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 15b: aload 0
      // 15c: invokedynamic get (Lcn/cool/cherish/module/impl/movement/树树友树树何何何树树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/movement/树树友树树何何何树树.M ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 161: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 164: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 167: putfield cn/cool/cherish/module/impl/movement/树树友树树何何何树树.何友何友树友何何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 16a: aload 0
      // 16b: new cn/cool/cherish/value/impl/BooleanValue
      // 16e: dup
      // 16f: sipush 15566
      // 172: ldc2_w 845558887138260591
      // 175: lload 1
      // 176: lxor
      // 177: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 17c: sipush 32610
      // 17f: ldc2_w 8272603623404778958
      // 182: lload 1
      // 183: lxor
      // 184: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 189: bipush 0
      // 18a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 18d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 190: aload 0
      // 191: invokedynamic get (Lcn/cool/cherish/module/impl/movement/树树友树树何何何树树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/movement/树树友树树何何何树树.p ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 196: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 199: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 19c: putfield cn/cool/cherish/module/impl/movement/树树友树树何何何树树.友何何树何友何友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 19f: aload 0
      // 1a0: bipush 0
      // 1a1: ldc2_w -5185437057015497637
      // 1a4: lload 1
      // 1a5: invokedynamic ú (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1aa: pop
      // 1ab: aload 0
      // 1ac: bipush 0
      // 1ad: ldc2_w -5186310073502827672
      // 1b0: lload 1
      // 1b1: invokedynamic ú (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b6: aload 0
      // 1b7: bipush -1
      // 1b8: ldc2_w -5187443070596724716
      // 1bb: lload 1
      // 1bc: invokedynamic ú (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c1: aload 0
      // 1c2: bipush 0
      // 1c3: ldc2_w -5185571279504697627
      // 1c6: lload 1
      // 1c7: invokedynamic ú (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1cc: aload 0
      // 1cd: bipush 0
      // 1ce: ldc2_w -5187177012722414073
      // 1d1: lload 1
      // 1d2: invokedynamic ú (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1d7: aload 0
      // 1d8: bipush 0
      // 1d9: ldc2_w -5187926496469123958
      // 1dc: lload 1
      // 1dd: invokedynamic ú (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e2: aload 0
      // 1e3: ldc2_w -5186795900174327681
      // 1e6: lload 1
      // 1e7: invokedynamic X (Lcn/cool/cherish/module/impl/movement/树树友树树何何何树树;JJ)V bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ec: ldc2_w -5187251308977134583
      // 1ef: lload 1
      // 1f0: invokedynamic L (JJ)Z bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f5: ifeq 1fc
      // 1f8: bipush 0
      // 1f9: goto 1fd
      // 1fc: bipush 1
      // 1fd: ldc2_w -5186521450707978449
      // 200: lload 1
      // 201: invokedynamic L (ZJJ)V bsm=cn/cool/cherish/module/impl/movement/树树友树树何何何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 206: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8199386945480214927L, 8958671988405798763L, MethodHandles.lookup().lookupClass()).a(166815372076190L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 11852873721376L;
      a();
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[18];
      int var5 = 0;
      String var4 = "\u001c¸¹\u0083R=S\u0086S7$Ï\u008a\u0087\u007f\u0001¬Ô\u0087ø\u008f)\u0092ß\u0010A¡\u0086Ï\u001b\u0080ü´\u0004ýR\u0004Ñ¬\u0016\u0017 \u0014}¨B]S`\u0097¼Â\u001b\u000e\u0004à\u0000\u0016³]¹%z\u0012\u0016\u008c\u0098R\u0015\u0093R\u0014ý\u0004\u0010H:áé?O#\u0089xâ\u008f\u0089û|Å\u0091\u0010k,³Ã\u000eÞ4\u0011Å\u001fr;\u000b?\u001fã\u0010LìôÏÍrgê\u0018\u009e£´`°\u0019Ñ z\u00999\fOw\u000e-¥\b+Û\tNEéô\u008aDË\u0005i\u008aU\u0005ÐªÑ%\u0099¿\\\u0010Úi\u0006q`,}ñw%°ç÷\u000f\u0005Ñ \u0003\u007f|\u0003}ú\u0083«.s²¿\u000ey\b\u00ad·\u0007z\u000e Jæ\u0098»\u0082p\u009dXË\u008a±\u0010>Á\u008f\u0080³#\u008f\u0003¿:àëb\u001cB} Ý\u0085\u0099Ncª\u0001yÞó\u009f\u001b£û\u009ftâ\u001df«\u009d®xÐ1\u007fWÓn\u0095\u009f~ \u00058\u00140àöçL\b¿79ê1ÖWÚs\u0005KI\u007f\u0094Ù\u0000Ê\b4¦\u0015\u008d\u0084\u0010Ñ©l\u0085¸¤´Ä^Æã¾Âª\t\u008c\u0010ÞxCÎVÏ\u0091\u001f\u000bÓQ\u0096W\u0012\u0011\u0085(\u0010 »Á4Ø,4î{\u0092°)oþ\u0016¯\u008baÀÓ×ÿ&~Þ÷Ñ.Ó\u008bÚ({ËÎVØ{7\u0018²s½\u008dLÓ¹Ó\u0095øA\b©·\u001eÉâL\"WÎ\u0081yÎ";
      short var6 = 391;
      char var3 = 24;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = c(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     c = var7;
                     h = new String[18];
                     c<"X">(false, -5538964943935125637L, var9);
                     c<"X">(false, -5538743067666006194L, var9);
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "^Ì.\u008daiù:Y:Å¹:j^]\u0010ÛÆ 5ýò;ü´\u0004v.Czä\u0012";
                  var6 = 33;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   private void C() {
      long a = 树树友树树何何何树树.a ^ 18739956662111L;
      this.Z();
      KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, -1561645589015789945L, a), -1560293607055385426L, a).getKey(), false);
      KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, -1561645589015789945L, a), -1560257420328595110L, a).getKey(), false);
   }

   public void F() {
      long a = 树树友树树何何何树树.a ^ 64287847284984L;
      c<"L">(6196002427728119882L, a);
      c<"ú">(this, false, 6195434376251152020L, a);
      c<"X">(false, 6195145513591447971L, a);
      this.C();
      if (c<"t">(6195367836802800022L, a)) {
         c<"Ñ">(mc, 6193787521538769184L, a).setCameraType(c<"Ñ">(mc, 6193787521538769184L, a).getCameraType());
         c<"X">(false, 6195367836802800022L, a);
      }
   }

   @EventTarget
   public void I(LivingUpdateEvent event) {
      long a = 树树友树树何何何树树.a ^ 104461209681920L;
      long ax = a ^ 80313879915554L;
      c<"L">(-7708761677957199694L, a);
      if (!this.w(new Object[]{ax})) {
         this.T(c<"Ñ">(this, -7709481047415191099L, a).getValue());
         LivingEntity target = c<"t">(-7706354700668466814L, a).B();
         if (c<"Ñ">(this, -7709481047415191099L, a).C(b<"t">(8991, 1298979238715311280L ^ a))) {
            this.O(target);
         }

         if (c<"Ñ">(this, -7709481047415191099L, a).C(b<"t">(17288, 4388874581380899875L ^ a))) {
            this.y(target);
         }
      }
   }

   private void Z() {
      long a = 树树友树树何何何树树.a ^ 87145632255249L;
      KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, 1737744958903389385L, a), 1737771301692665343L, a).getKey(), false);
      KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, 1737744958903389385L, a), 1734893370332312579L, a).getKey(), false);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 60;
               case 1 -> 7;
               case 2 -> 45;
               case 3 -> 11;
               case 4 -> 57;
               case 5 -> 43;
               case 6 -> 63;
               case 7 -> 8;
               case 8 -> 31;
               case 9 -> 37;
               case 10 -> 58;
               case 11 -> 56;
               case 12 -> 14;
               case 13 -> 25;
               case 14 -> 38;
               case 15 -> 21;
               case 16 -> 54;
               case 17 -> 32;
               case 18 -> 49;
               case 19 -> 19;
               case 20 -> 20;
               case 21 -> 12;
               case 22 -> 27;
               case 23 -> 34;
               case 24 -> 41;
               case 25 -> 46;
               case 26 -> 29;
               case 27 -> 59;
               case 28 -> 26;
               case 29 -> 33;
               case 30 -> 44;
               case 31 -> 24;
               case 32 -> 30;
               case 33 -> 48;
               case 34 -> 51;
               case 35 -> 17;
               case 36 -> 40;
               case 37 -> 50;
               case 38 -> 1;
               case 39 -> 61;
               case 40 -> 13;
               case 41 -> 2;
               case 42 -> 6;
               case 43 -> 55;
               case 44 -> 23;
               case 45 -> 53;
               case 46 -> 22;
               case 47 -> 5;
               case 48 -> 47;
               case 49 -> 42;
               case 50 -> 36;
               case 51 -> 18;
               case 52 -> 35;
               case 53 -> 3;
               case 54 -> 4;
               case 55 -> 0;
               case 56 -> 52;
               case 57 -> 15;
               case 58 -> 9;
               case 59 -> 28;
               case 60 -> 39;
               case 61 -> 16;
               case 62 -> 62;
               default -> 10;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树友树树何何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29353;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树友树树何何何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 209 && var8 != 250 && var8 != 't' && var8 != 'X') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 224) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'L') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 209) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 250) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 't') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树友树树何何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "{0`=A\u0004tp-6K\u0019q-&pC\u0004|+\";\u0000\u0002u.\"pC\u0004n;#;@\u001f6桏桟厕栿桺位伋伛桏栿";
      j[1] = "SQi^Gv\\\u0011$UMkYL/\u0013^x\\J\"\u0013At@SipG}Ui&Q]|";
      j[2] = boolean.class;
      k[2] = "java/lang/Boolean";
      j[3] = int.class;
      k[3] = "java/lang/Integer";
      j[4] = "#\u0003\u0019?t=#\u0003\u000ecx29H\u000e}p1#\u0012C\\p:(\u0005\u001fp\u007f ";
      j[5] = "\u00034\tj\u0004Q\u00034\u001e6\b^\u0019\u007f\u001e(\u0000]\u0003%S\u000b\u0019L\u0004>\u00137";
      j[6] = "\u0003Ey&\u007f7\bJhi\u0003.\u0007Pf*4\u001e\u0011Gj7%2\u0006J";
      j[7] = "#\rXMZ\u001b,M\u0015FP\u0006)\u0010\u001e\u0000X\u001b$\u0016\u001aK\u001b\u001d-\u0013\u001a\u0000X\u001b6\u0006\u001bK[\u0000n伶厽佻叾县桑厨厽佻你";
      j[8] = "'h&*\b},g7eue?`>,";
      j[9] = "_a\u000b\rW#_a\u001cQ[,E*\u001cOS/_pQh_3|e\u000fSS$V";
      j[10] = "Cl[IA`L,\u0016BK}Iq\u001d\u0004XnLw\u0010\u0004GbPn[d[bBg\u0007|OcUg";
      j[11] = ";-\\*!\b4m\u0011!+\u001510\u001ag#\b<6\u001e,`\u000e53\u001eg-\b5!\u0013=`,1/\u001e\b;\u00159";
      j[12] = ";s|g;;;sk;74!8k%?7;b&9:3,szg\u001a=6wd\u0019:3,sz";
      j[13] = "`\u0016kIa$oV&Bk9j\u000b-\u0004x*o\r \u0004g&s\u0014kha$o\u001d$DX*o\r ";
      j[14] = "Sp\u000eq%\u0007\\0Cz/\u001aYmH<'\u0007TkLwd\u0001]nL<:\u0004QgE`d伽佥叕併叙桛厣叻佋併";
      j[15] = float.class;
      k[15] = "java/lang/Float";
      j[16] = "r\u001e6:x2r\u001e!ft=hU!x|>r\u000fly`7h\u00122xt\"y\tlWy2y\u00156Xp-y\u0017";
      j[17] = "m/emv\nm/r1z\u0005wdd7r\u000f-\u0018p-\u007f\fn\u0019~6i\u0000f";
      j[18] = "o`\u001a\"4lo`\r~8cu+\u0019c+ie+\u001ed v/S\u000boj";
      j[19] = double.class;
      k[19] = "java/lang/Double";
      j[20] = "^kcjE<C~;H\u00041[x";
      j[21] = "\\v\rO#zS6@D)gVkK\u0002!z[mOIbXP|V@)";
      j[22] = void.class;
      k[22] = "java/lang/Void";
      j[23] = "\"\u0019=(\f;-Yp#\u0006&(\u0004{e\u000e;%\u0002\u007f.M企伔厼但伞厨企伔桦栂";
      j[24] = "\u007f\u000f\u000b\u007f{Rt\u0000\u001a0\u001a\\\u007f\u000b\u001ej";
      j[25] = "Wp^4: \u00034\u0005O桞厙伷厏桽伒厄桃桳休d~!(\u0006r\u00057}>\u0004";
      j[26] = "q=\u0018~c>09[(](\u001a0\u001cwmx\u001a\u0001\u0018/d{(:^5:x";
      j[27] = "\u001a\u0004\u0007{\u0015\u0013\u0011C\u000f)rEv\b]sL\u0015v9XwL\u001a\u001fA\u0019s\u000fL";
      j[28] = "_|AeB7\u000b8\u001a\u001e叼伐厡桙厸标栦厎厡桙{'C$\u0002q\u0016\u007f\u000f#\r";
      j[29] = "\u000e\u0017\u0003~\u0015{ZSX\u0005\u0001\u0001\u000fM\u0006d\u0017x\u0002IS`h=U\u0014Xz\u00110QA\\\u0005";
      j[30] = "{\u0003\b,v\"/GSW又伅桟佢佯伊佖伅厅叼2nw1&\u000e_6;6)";
      j[31] = "a\u0012\u0019noc)\u001a\u0005l\r=7\u0000\u0014}k7<{X}|&3D\u0010u`$";
      j[32] = "0fQ\u0014[6d\"\no栿休栔桃厨桶佻桕栔伇k\u0013\u0017ps`TT\\!";
      j[33] = "UW;k\u00030\u0001\u0013`\u0010厽桓桱桲栘栉厽桓桱厨\u0001)\u0002#\bZlqN$\u0007";
      j[34] = "$\u007f;\u0005p\u0017p;`~佐桴叚伞栘桧佐桴栀厀\u0001Gq\u0004yrl\u001f=\u0003v";
      j[35] = "\u0000ur`\u0012\u0014Aq16,\u0002kxvi\u001c\\kIr1\u0015QYr4+KR";
      j[36] = "nb\u0011f\u001dvc5\u0016d{jR4RaK=R\u0004\u0004;\u001e=kcS2\u0003f";
      j[37] = "\u001exc\u0016j\rH6#\u0016Z\n#xc@f]#D6\u00115T\b}a\u0013%\n";
      j[38] = "\u0012p0kB:\u001f'7i$&.&sl\u001by.\u0016%6Aq\u0017qr?\\*";
      j[39] = "VG\u000e\u001eZp\u0002\u0003Ue佺叉伶厸栭厦佺佗伶伦4TAx\u0007EU\u001d\u001dn\u0005";
      j[40] = "aKaV;;s\u001edC^参反核栜佱厝参体核叆,1kj[`\u0016#>oN";
      j[41] = "\u001aSE~~r[W\u0006(@dq^Awp7qoE/y7CT\u00035'4";
      j[42] = "\u0004d@\u001adaP \u001ba叚但佤桁伧厢佄变叺桁zP\u007fiUf\u001b\u0019#\u007fW";
      j[43] = "\u0019c\u0004,x<M'_W佘厅叧框栧厔栜桟佹厜>j9|_\"D>}'";
      j[44] = "\u00175KC&\u001cCq\u00108厘伻栳及伬校厘厥栳佔qQ&\u0014\u001bh@Y<\u001b\u0011";
      j[45] = " '8h\u00198t0<yt$Ggt8EuG^\u007fg\n&yo/j\u0017*";
      j[46] = "&%\bPCmraS+佣叔栂佄佯栲佣栎但栀2\u0012B~{(_J\u000eyt";
      j[47] = "rJ$=+ioP} \u0012\\\u001f\u000b8*r$rSt-}\u0015qR*&.v%L(<\u0012";
      j[48] = "Q\u0010Q-?3\u0005T\nV厁厊厯可伶桏桛厊伱佱ki{*\u000e\u0010[&r$\u0005";
      j[49] = "liG\u0016ph8~C\u0007\u001dt\u000b)\u000bI# \u000b\u0010\u0003\u0005tzm}[Isu";
      j[50] = "*lq\tV/~(*r叨伈栎厓桒桫栲厖佊桉KHK+{9z\u0018F6w";
      j[51] = "\u0007/5JG3Skn1栣桐叹低佒栨栣桐叹叐\u000f\u0000\\;V-nI\u0000-T";
      j[52] = "fv#5\u001b\r{lz(\"\u001c\u000b7?\"B@fos%Mq";
      j[53] = "\u001d\u0005_aD<IA\u0004\u001a佤桟口叺桼叙叺伛根叺e#E/@\b\b{\t(O";
      j[54] = "P[I\u0018s#\u0011_\nNM5;VM\u0011}d;gIItf\t\\\u000fS*e";
      j[55] = "|r>'y\u0018=v}qG\u000e\u0017\u007f:.wQ\u0017N>v~]%uxl ^";
      j[56] = "\u0016\u000b@r\u001a\u0011\u0001VHia<;zwOa\u000eKP[y\u0013\u0019\u0016X@";
      j[57] = "3\u0000*\u000395mKqRU桔叁厲取桵桌伐栛厲佈ld<=\u001ey\u0014:wfO";
      j[58] = "YpZG\u0019\u000f\u000b|FXv\u0015dqF\u0002\u000eK\u0006#\u0019]\u0017s";
      j[59] = "fd[%ss2 \u0000^栗栐伆桁厢厝栗佔桂伅adnw71P4cj;";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 树树友树树何何何树树.a ^ 136504183669535L;
      c<"ú">(this, -1, -7630827753980533233L, a);
      c<"ú">(this, false, -7629699321941961357L, a);
      c<"ú">(this, false, -7632762522722332096L, a);
      c<"X">(false, -7629429430429621692L, a);
      c<"X">(false, -7629915361278748047L, a);
      this.C();
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static float U(Player from, Vec3 pos) {
      long a = 树树友树树何何何树树.a ^ 64216738980537L;
      return from.getYRot()
         + Mth.wrapDegrees(
            (float)Math.toDegrees(Math.atan2(c<"Ñ">(pos, 4015566043753275765L, a) - from.getZ(), c<"Ñ">(pos, 4015730395635806070L, a) - from.getX()))
               - 90.0F
               - from.getYRot()
         );
   }

   private void y(LivingEntity target) {
      long a = 树树友树树何何何树树.a ^ 129732786740631L;
      long var10001 = a ^ 106921757783340L;
      var10001 = a ^ 90894461142954L;
      c<"L">(618067254752777509L, a);
      KillAura ka = (KillAura)Cherish.instance.getModuleManager().getModule(KillAura.class);
      何何友何友树友友何何 sca = (何何友何友树友友何何)Cherish.instance.getModuleManager().getModule(何何友何友树友友何何.class);
      if ((!c<"Ñ">(this, 619244857816915127L, a).getValue() || c<"Ñ">(c<"Ñ">(mc, 620247061831785551L, a), 617202960115135378L, a).isDown())
         && !sca.isEnabled()
         && ka.isEnabled()) {
         c<"X">(false, 618923344290348236L, a);
      } else {
         c<"X">(false, 618923344290348236L, a);
      }
   }

   @EventTarget
   public void E(Render3DEvent event) {
      long a = 树树友树树何何何树树.a ^ 82425267123607L;
      long ax = a ^ 102243538295221L;
      long axx = a ^ 126773754082832L;
      if (!this.w(new Object[]{ax})) {
         PoseStack poseStack = event.poseStack();
         LivingEntity target = c<"t">(2349351561386343445L, a).B();
         if (c<"Ñ">(this, 2349483524533902691L, a).getValue()) {
            友友树何树树友树友何.M(
               poseStack,
               target,
               c<"Ñ">(this, 2346742015032151883L, a).getValue().doubleValue(),
               1,
               event.partialTick(),
               c<"t">(2347348979972397295L, a),
               axx,
               2.0F
            );
         }
      }
   }

   @EventTarget
   public void E(JumpEvent event) {
      long a = 树树友树树何何何树树.a ^ 36311749788692L;
      c<"L">(-3382058051366368090L, a);
      if (c<"Ñ">(this, -3380490475259605551L, a).C(b<"t">(17288, 4388780007683153975L ^ a)) && c<"t">(-3380638186160609969L, a)) {
         event.setRotationYaw(c<"Ñ">(this, -3380757370397889142L, a));
      }
   }

   @EventTarget
   public void T(StrafeEvent event) {
      long a = 树树友树树何何何树树.a ^ 124973070136971L;
      c<"L">(-2049185448939487687L, a);
      if (c<"Ñ">(this, -2051031751243956402L, a).C(b<"t">(25843, 5786850411126846939L ^ a)) && c<"t">(-2050580575126317104L, a)) {
         event.setRotationYaw(c<"Ñ">(this, -2050699435026456811L, a));
      }
   }

   private void O(LivingEntity target) {
      long a = 树树友树树何何何树树.a ^ 91416582114238L;
      c<"L">(2214352912662594316L, a);
      boolean canStrafe = !c<"t">(2214141627501879635L, a).isEnabled()
         && c<"t">(2212264809390539324L, a).isEnabled()
         && c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2215276935669544122L, a).isDown();
      if (canStrafe) {
         if (c<"Ñ">(this, 2213688240318067292L, a).getValue()) {
            KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2213967865507702203L, a).getKey(), mc.player.onGround());
         }

         if (!c<"Ñ">(this, 2214913265310096850L, a)) {
            c<"ú">(this, -1, 2213789235579449006L, a);
            c<"ú">(this, true, 2214913265310096850L, a);
         }

         if (c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2212060903838411600L, a).isDown()) {
            c<"ú">(this, -1, 2213789235579449006L, a);
         }

         if (c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2214794867996193452L, a).isDown()) {
            c<"ú">(this, 1, 2213789235579449006L, a);
         }

         label44: {
            if (mc.player.distanceTo(target) < c<"Ñ">(this, 2213612393707794786L, a).getValue().doubleValue()) {
               if (c<"Ñ">(this, 2212347061049694945L, a)) {
                  break label44;
               }

               KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2214076757407197263L, a).getKey(), true);
               c<"ú">(this, true, 2212347061049694945L, a);
            }

            if (c<"Ñ">(this, 2212347061049694945L, a)) {
               KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2214076757407197263L, a).getKey(), false);
               c<"ú">(this, false, 2212347061049694945L, a);
            }
         }

         if (c<"Ñ">(mc.player, 2213572056961058457L, a)) {
            c<"ú">(this, c<"Ñ">(this, 2213789235579449006L, a) * -1, 2213789235579449006L, a);
            this.Z();
         }

         if (c<"Ñ">(this, 2213789235579449006L, a) == -1) {
            KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2212060903838411600L, a).getKey(), true);
            KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2214794867996193452L, a).getKey(), false);
         }

         KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2214794867996193452L, a).getKey(), true);
         KeyMapping.set(c<"Ñ">(c<"Ñ">(mc, 2212016957303720550L, a), 2212060903838411600L, a).getKey(), false);
      }

      if (c<"Ñ">(this, 2214913265310096850L, a)) {
         c<"ú">(this, false, 2214913265310096850L, a);
         c<"ú">(this, false, 2212347061049694945L, a);
         this.C();
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖国企上班";
   }
}
