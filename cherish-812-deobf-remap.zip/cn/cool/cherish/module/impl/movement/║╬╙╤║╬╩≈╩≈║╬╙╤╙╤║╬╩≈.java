package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.player.树何何何树何友何树何;
import cn.cool.cherish.utils.player.树友友何树友树树树何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.world.phys.Vec3;

public class 何友何树树何友友何树 extends Module implements 何树友 {
   private final ModeValue 树何友何何树友友何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[22];
   private static final String[] k = new String[22];
   private static int _职业技术教育中心学校 _;

   public 何友何树树何友友何树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/movement/何友何树树何友友何树.a J
      // 03: ldc2_w 139064399239465
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 7042
      // 0c: ldc2_w 7145160109545431021
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何树树何友友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 4045
      // 19: ldc2_w 9186756850963942305
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何树树何友友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 3980758185878092746
      // 26: lload 1
      // 27: invokedynamic Ù (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/movement/何友何树树何友友何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/ModeValue
      // 33: dup
      // 34: sipush 25871
      // 37: ldc2_w 1286492883326886246
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何树树何友友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 2514
      // 44: ldc2_w 8867499823983627706
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何树树何友友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: bipush 3
      // 4f: anewarray 65
      // 52: dup
      // 53: bipush 0
      // 54: sipush 14760
      // 57: ldc2_w 8558554366886133187
      // 5a: lload 1
      // 5b: lxor
      // 5c: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何树树何友友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 61: aastore
      // 62: dup
      // 63: bipush 1
      // 64: sipush 28865
      // 67: ldc2_w 8348617388848116897
      // 6a: lload 1
      // 6b: lxor
      // 6c: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何树树何友友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 71: aastore
      // 72: dup
      // 73: bipush 2
      // 74: sipush 13976
      // 77: ldc2_w 3753226097970295538
      // 7a: lload 1
      // 7b: lxor
      // 7c: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何树树何友友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 81: aastore
      // 82: sipush 28922
      // 85: ldc2_w 8104110416680154263
      // 88: lload 1
      // 89: lxor
      // 8a: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何树树何友友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 8f: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 92: putfield cn/cool/cherish/module/impl/movement/何友何树树何友友何树.树何友何何树友友何何 Lcn/cool/cherish/value/impl/ModeValue;
      // 95: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(5199269256795209311L, -3622901133698734406L, MethodHandles.lookup().lookupClass()).a(154367446240267L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 134667498410427L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[10];
      int var7 = 0;
      String var6 = "\u000b\u001a0Æ\u00adÈO\u000bØrj\u0097q\b÷\u0003\u0010\\ \u008d¤\u000fþcpÙÀWD»{/{ r\u00883w@}m¹!!§ñÿÄ\u0094 K:Ç¬\u001f\u007fEàVImxß\u0006ï\u0000\u0010\u008f\u0098Þ\u00870Öü\u0094¯äF\u0096Ì\u0000!£\u0010\u001amÎÔ\u0092ÚXÅ\u0018E\u0017Vqm\u009eZ\u0010PØ´\u001f\u001eu\u0015\u008cêoX\u0000\u0004NúN\u0010Û\u009d\u00879jR©p\u0018Uó\u000bÏ\u009aJV\u0010$gð\u0001æMÎ)ñÝ¶ÜN~Q\u001e";
      short var8 = 151;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[10];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "rÛT9ÙB\u00142\u008cÞÿA¨kx\u0014 \u009e!-\u001bÄªÇÅÐ¼k¥×\u009fçG\u008c/&\u0002øó\u009fHU´Ò\u008f\u008d\u0095ä·";
                  var8 = 49;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   protected void F() {
      long a = 何友何树树何友友何树.a ^ 26146668706784L;
      if (c<"s">(this, 6192929109190426523L, a).C(b<"n">(28922, 8104223961480107614L ^ a))) {
         KeyMapping.set(
            c<"s">(c<"s">(mc, 6194178830838314845L, a), 6194353681737439192L, a).getKey(),
            c<"s">(c<"s">(mc, 6194178830838314845L, a), 6194353681737439192L, a).isDown()
         );
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 55;
               case 1 -> 38;
               case 2 -> 60;
               case 3 -> 49;
               case 4 -> 61;
               case 5 -> 28;
               case 6 -> 26;
               case 7 -> 23;
               case 8 -> 8;
               case 9 -> 45;
               case 10 -> 20;
               case 11 -> 9;
               case 12 -> 31;
               case 13 -> 32;
               case 14 -> 1;
               case 15 -> 12;
               case 16 -> 14;
               case 17 -> 7;
               case 18 -> 42;
               case 19 -> 43;
               case 20 -> 35;
               case 21 -> 56;
               case 22 -> 59;
               case 23 -> 29;
               case 24 -> 36;
               case 25 -> 52;
               case 26 -> 57;
               case 27 -> 21;
               case 28 -> 19;
               case 29 -> 50;
               case 30 -> 46;
               case 31 -> 48;
               case 32 -> 33;
               case 33 -> 53;
               case 34 -> 13;
               case 35 -> 47;
               case 36 -> 58;
               case 37 -> 51;
               case 38 -> 15;
               case 39 -> 40;
               case 40 -> 44;
               case 41 -> 39;
               case 42 -> 18;
               case 43 -> 54;
               case 44 -> 34;
               case 45 -> 37;
               case 46 -> 11;
               case 47 -> 62;
               case 48 -> 25;
               case 49 -> 6;
               case 50 -> 30;
               case 51 -> 4;
               case 52 -> 27;
               case 53 -> 41;
               case 54 -> 0;
               case 55 -> 24;
               case 56 -> 16;
               case 57 -> 2;
               case 58 -> 3;
               case 59 -> 63;
               case 60 -> 22;
               case 61 -> 10;
               case 62 -> 5;
               default -> 17;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何友何树树何友友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13139;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/何友何树树何友友何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   @EventTarget
   public void s(LivingUpdateEvent event) {
      long a = 何友何树树何友友何树.a ^ 61809909627930L;
      long ax = a ^ 3860640574240L;
      long axx = a ^ 55930903682367L;
      long axxx = a ^ 107678302381472L;
      c<"O">(-3310868845574218508L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"s">(this, -3311381825839286175L, a).C(b<"n">(23586, 2900293047133781375L ^ a)) && 树何何何树何友何树何.x(axxx)) {
            KeyMapping.set(c<"s">(c<"s">(mc, -3311259374293471065L, a), -3311011959846645726L, a).getKey(), mc.player.onGround());
            树何何何树何友何树何.B(axx);
         }
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何友何树树何友友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 's' && var8 != 208 && var8 != 217 && var8 != 'P') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 230) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'O') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 's') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 208) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 217) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "P\fl\u0014L?P\f{H@0JG{VH3P\u001d6wH8[\nj[G\"";
      j[1] = "(|#\n=W(|4V1X274H9[(myk J/v9W";
      j[2] = "y_mimCv\u001f bg^sB+$oC~D/o,EwA/$oClT.olX4佤厈佟栓栽住叺厈佟栓";
      j[3] = "d\u0018o\n\"ZkX\"\u0001(Gn\u0005)G;Tk\u0003$G$Xw\u001ao$\"Qb  \u00058P";
      j[4] = "\u000b?\u0019:5t\u00000\buIm\u000f*\u00066~]\u0019=\n+oq\u000e0";
      j[5] = "?.(\u001f#m?.?C/b%e?]'a??rz+}\u001c*,A'j6";
      j[6] = "\u0018\u0010u:\u0003z\u0017P81\tg\u0012\r3w\u0001z\u001f\u000b7<B|\u0016\u000e7w\u0001z\r\u001b6<\u0002aU伫厐伌厧叞桪厵厐伌伹";
      j[7] = "W_S*66\\PBeK.OWK,";
      j[8] = "_rTh\"T_rC4.[E9W)=QU9L#9X]9B* ^Z9b* ^Zd";
      j[9] = "O\n-c'\u0014O\n:?+\u001bUA.\"8\u0011EA5(<\u0018MA;!%\u001eJA\u001b!%\u001eJ";
      j[10] = "9fURe\u00129fB\u000ei\u001d#-V\u0013z\u00173-Q\u0014q\byUD\u001f;";
      j[11] = double.class;
      k[11] = "java/lang/Double";
      j[12] = "V0Q\u0011_\"Yp\u001c\u001aU?\\-\u0017\\]\"Q+\u0013\u0017\u001e优你厕伪伧叻优你桏桮";
      j[13] = "W.A\u0003\u0006\u0003\\!PLg\rW*T\u0016";
      j[14] = "/28@I3)a/\u0019'桕佋厓伊佻栾厏叕伍伊&\u001d&)72D\u001b0i=";
      j[15] = "\u001dl=t~MD#=e\u000f\u001ftlw,6OtQqkqNBk(pl\u001d";
      j[16] = "]I 'hc\u0000\u0010)\u001e~]\u000b\u0019` .]:\u0019g!|uH\u0010)u+";
      j[17] = "\"\u001f+Ot\u0019&\f)E\u0018\u0006K],\u001a(PKm&\u001e(\u0012q\u0007s\u001b~T";
      j[18] = "T\u001aQ{}\u0005RIF\"\u0013\u0013mBOqv\u0015\u0012\u0013@c\"zW\tRx|\u0005\u0006\u0006@,\u0013";
      j[19] = "\u0014\u0011!1\u001ck\u001d_ufcwz\u001f$eS(z.%/_(OE b_a";
      j[20] = "\u00190\u0011nM/U/Thu厞只桗栲佞厶厞佴桗叨\u0003E#\u0013#\u0013q\t<V%";
      j[21] = "Wy7/e\u0001\u0010`3>\u0007\u0000k-#'m\u000f\u0015ar:{f";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void M(MotionEvent event) {
      long a = 何友何树树何友友何树.a ^ 60712913283515L;
      long ax = a ^ 13752720817793L;
      long axx = a ^ 121969033048065L;
      c<"O">(552923864706959701L, a);
      if (!this.w(new Object[]{ax})) {
         String var9 = c<"s">(this, 552417486545350080L, a).getValue();
         switch (var9) {
            case b<"n">(28922, 8104188158184014853L ^ a):
               KeyMapping.set(c<"s">(c<"s">(mc, 553102883950421254L, a), 553348102259508611L, a).getKey(), 树何何何树何友何树何.x(axx) && mc.player.onGround());
            default:
               this.T(c<"s">(this, 552417486545350080L, a).getValue());
         }
      }
   }

   @EventTarget
   public void W(StrafeEvent event) {
      long a = 何友何树树何友友何树.a ^ 125107271761574L;
      long ax = a ^ 135384322039683L;
      long axx = a ^ 44054507136796L;
      int axxx = (int)((a ^ 94870945934349L) >>> 32);
      int axxxx = (int)((a ^ 94870945934349L) << 32 >>> 32);
      long axxxxx = a ^ 89137618915740L;
      long axxxxxx = a ^ 133797437128924L;
      c<"O">(-3408899821872013752L, a);
      if (c<"s">(this, -3407023446920316195L, a).C(b<"n">(22177, 5770042723966104911L ^ a))) {
         if (mc.player.onGround() && 树何何何树何友何树何.x(axx)) {
            树何何何树何友何树何.c(树何何何树何友何树何.h(axxxxxx) - 0.01, axxx, axxxx);
            mc.player.jumpFromGround();
         }

         Vec3 motion = mc.player.getDeltaMovement();
         if (WrapperUtils.B(new Object[0]) == 1
            || 树友友何树友树树树何.F(0.0, c<"s">(motion, -3409205026811285082L, a), 0.0, axxxxx) != c<"Ù">(-3407094579741173705L, a)
               && WrapperUtils.B(new Object[0]) > 2) {
            树何何何树何友何树何.B(ax);
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "何大伟230622198107200054";
   }
}
