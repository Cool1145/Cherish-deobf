package cn.cool.cherish.module;

public interface 树树友树友树何何何友 {
   void b(long var1);

   int[] b();

   boolean b(树树友树友树何何何友 var1);

   void a(树树友树友树何何何友 var1);

   long a(long var1);
}
