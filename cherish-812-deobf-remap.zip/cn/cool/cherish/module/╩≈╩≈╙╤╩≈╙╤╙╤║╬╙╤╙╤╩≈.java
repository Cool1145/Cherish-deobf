package cn.cool.cherish.module;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.ui.树何树友树何何友何何;
import cn.cool.cherish.utils.render.RenderUtils;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public abstract class 树树友树友友何友友树 extends Module implements 何树友 {
   protected long 树友树树友何友何友友;
   protected boolean 树何友何友友何树树何;
   protected float 树友友友树树树树树何;
   protected float 何何何友树友友树友友;
   protected float 何何友树树树何友友友;
   protected float 友何友友树友何树树友;
   protected float 友树树友树友树树何何;
   protected float 何何何树友何树树何友;
   protected float 树树树树友何何友何友;
   protected float 何友树何树友树树树树;
   protected boolean 友友树何树友树友友树;
   protected float 树树友何友友何何友树;
   private static String[] 友何友树何何树友树何;
   private static final long a;
   private static final String[] h;
   private static final String[] i;
   private static final Map j = new HashMap(13);
   private static final Object[] v = new Object[35];
   private static final String[] w = new String[35];
   private static String HE_SHU_YOU;

   public 树树友树友友何友友树(String name, String cnName, float width, float height) {
      this(name, cnName, width, height, 10.0F, 10.0F);
   }

   public 树树友树友友何友友树(String name, String cnName, float width, float height, float defaultX, float defaultY) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/树树友树友友何友友树.a J
      // 03: ldc2_w 54846608706527
      // 06: lxor
      // 07: lstore 7
      // 09: aload 0
      // 0a: aload 1
      // 0b: aload 2
      // 0c: ldc2_w 9150698508641717863
      // 0f: lload 7
      // 11: invokedynamic ã (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/树树友树友友何友友树.g (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 19: aload 0
      // 1a: invokestatic java/lang/System.currentTimeMillis ()J
      // 1d: ldc2_w 9150897676329936796
      // 20: lload 7
      // 22: invokedynamic s (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/树树友树友友何友友树.g (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 27: aload 0
      // 28: bipush 0
      // 29: ldc2_w 9150336776487144760
      // 2c: lload 7
      // 2e: invokedynamic s (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/树树友树友友何友友树.g (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 33: aload 0
      // 34: ldc 150.0
      // 36: ldc2_w 9150229013375462422
      // 39: lload 7
      // 3b: invokedynamic s (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/树树友树友友何友友树.g (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 40: aload 0
      // 41: ldc 100.0
      // 43: ldc2_w 9151261241825740178
      // 46: lload 7
      // 48: invokedynamic s (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/树树友树友友何友友树.g (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4d: aload 0
      // 4e: fload 5
      // 50: ldc2_w 9150534979387089116
      // 53: lload 7
      // 55: invokedynamic s (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/树树友树友友何友友树.g (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5a: aload 0
      // 5b: fload 6
      // 5d: ldc2_w 9146873776483296228
      // 60: lload 7
      // 62: invokedynamic s (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/树树友树友友何友友树.g (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 67: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-7749268414256251059L, 5724219637641413175L, MethodHandles.lookup().lookupClass()).a(244594234378441L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 129627125227100L;
      b();
      String[] var12 = new String[3];
      g<"y">(var12, -1480783345716797570L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[2];
      int var5 = 0;
      char var3 = '8';
      int var2 = -1;

      while (true) {
         String var15 = c(
               var0.doFinal(
                  "\f\u0082¸#\u0015Td[\u008f\tüoS§_¯\u007f\u0015³²\u0013´àÂW\u008e%j(Ü3\u00adX×§²9ªCÇ~Ø+\"©\u0006©dì©hç]Ç\u0003í \u001dÛ( Xç:\u0080Cò-Ì\b\u0085\u008fìÁ®ÂÑQí\u0083ÇB2°õMg\u0001\u009d"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var15;
         if ((var2 += var3) >= 89) {
            h = var7;
            i = new String[2];
            return;
         }

         var3 = "\f\u0082¸#\u0015Td[\u008f\tüoS§_¯\u007f\u0015³²\u0013´àÂW\u008e%j(Ü3\u00adX×§²9ªCÇ~Ø+\"©\u0006©dì©hç]Ç\u0003í \u001dÛ( Xç:\u0080Cò-Ì\b\u0085\u008fìÁ®ÂÑQí\u0083ÇB2°õMg\u0001\u009d"
            .charAt(var2);
      }
   }

   public void B(float defaultY) {
      long a = 树树友树友友何友友树.a ^ 75713070550612L;
      g<"s">(this, defaultY, -4937268997582051729L, a);
   }

   public void C(boolean initialized) {
      long a = 树树友树友友何友友树.a ^ 30419999317509L;
      g<"s">(this, initialized, -6114009666208638750L, a);
   }

   public void I(float defaultX) {
      long a = 树树友树友友何友友树.a ^ 106220359469246L;
      g<"s">(this, defaultX, 4439540360427676605L, a);
   }

   public void J(long lastTime) {
      long a = 树树友树友友何友友树.a ^ 48934720704985L;
      g<"s">(this, lastTime, 7275734056897346970L, a);
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (w[var4] != null) {
         return var4;
      } else {
         Object var5 = v[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 51;
               case 1 -> 8;
               case 2 -> 19;
               case 3 -> 5;
               case 4 -> 49;
               case 5 -> 13;
               case 6 -> 17;
               case 7 -> 25;
               case 8 -> 7;
               case 9 -> 30;
               case 10 -> 56;
               case 11 -> 33;
               case 12 -> 11;
               case 13 -> 0;
               case 14 -> 9;
               case 15 -> 44;
               case 16 -> 62;
               case 17 -> 3;
               case 18 -> 2;
               case 19 -> 18;
               case 20 -> 50;
               case 21 -> 32;
               case 22 -> 23;
               case 23 -> 54;
               case 24 -> 45;
               case 25 -> 34;
               case 26 -> 36;
               case 27 -> 37;
               case 28 -> 43;
               case 29 -> 38;
               case 30 -> 57;
               case 31 -> 46;
               case 32 -> 6;
               case 33 -> 28;
               case 34 -> 41;
               case 35 -> 53;
               case 36 -> 1;
               case 37 -> 12;
               case 38 -> 10;
               case 39 -> 31;
               case 40 -> 27;
               case 41 -> 14;
               case 42 -> 63;
               case 43 -> 22;
               case 44 -> 55;
               case 45 -> 20;
               case 46 -> 48;
               case 47 -> 40;
               case 48 -> 42;
               case 49 -> 39;
               case 50 -> 4;
               case 51 -> 26;
               case 52 -> 29;
               case 53 -> 15;
               case 54 -> 47;
               case 55 -> 58;
               case 56 -> 21;
               case 57 -> 59;
               case 58 -> 61;
               case 59 -> 16;
               case 60 -> 60;
               case 61 -> 24;
               case 62 -> 35;
               default -> 52;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            w[var4] = new String(var12);
            return var4;
         }
      }
   }

   public boolean i() {
      long a = 树树友树友友何友友树.a ^ 59704545398580L;
      return g<"ì">(this, 4184119981122663794L, a);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/树树友树友友何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void b(PoseStack pose) {
      long a = 树树友树友友何友友树.a ^ 101360173455362L;
      g<"y">(7864124041997443993L, a);
      this.p();
      long now = System.currentTimeMillis();
      float delta = Math.min((float)(now - g<"ì">(this, 7864385825811002433L, a)) / 1000.0F, 0.05F);
      g<"s">(this, now, 7864385825811002433L, a);
      float var10001 = g<"ì">(this, 7864324979655049733L, a);
      float var10002 = g<"ì">(this, 7865132775743185476L, a) ? 1.0F : 0.0F;
      Object[] var10005 = new Object[]{null, null, delta * 8.0F};
      var10005[1] = var10002;
      var10005[0] = var10001;
      g<"s">(this, RenderUtils.g(var10005), 7864324979655049733L, a);
      RenderUtils.drawRectangle(
         pose,
         g<"ì">(this, 7863711018609361590L, a),
         g<"ì">(this, 7863553187012558826L, a),
         g<"ì">(this, 7863646692912185291L, a),
         g<"ì">(this, 7864026377049200207L, a),
         new Color(0, 0, 0, (int)(g<"ì">(this, 7864324979655049733L, a) * 100.0F)).getRGB()
      );
      Cherish.instance
         .h()
         .n(16)
         .L(
            pose,
            String.format(b<"t">(23477, 6593407201444871026L ^ a), (int)g<"ì">(this, 7863711018609361590L, a), (int)g<"ì">(this, 7863553187012558826L, a)),
            g<"ì">(this, 7863711018609361590L, a) + g<"ì">(this, 7863646692912185291L, a) / 2.0F,
            g<"ì">(this, 7863553187012558826L, a) + g<"ì">(this, 7864026377049200207L, a) / 2.0F,
            new Color(255, 255, 255, (int)(g<"ì">(this, 7864324979655049733L, a) * 255.0F)).getRGB()
         );
      if (g<"y">(7863593103726497209L, a)) {
         g<"y">("ajfhEb", 7863324535740854587L, a);
      }
   }

   private static void b() {
      v[0] = "\r<\u0007_tB\u0002|JT~_\u0007!A\u0012vB\n'EY5格桿厙核号叐佸厥厙核";
      v[1] = float.class;
      w[1] = "java/lang/Float";
      v[2] = boolean.class;
      w[2] = "java/lang/Boolean";
      v[3] = "Zca-=QQlpbAH^v~!vxHar<gT_l";
      v[4] = "4#e\u0004%m;c(\u000f/p>>#I'm38'\u0002d佗伂历伞伲厁佗伂桜桚";
      v[5] = "S+\u001471SX$\u0005xLKK#\f1";
      v[6] = long.class;
      w[6] = "java/lang/Long";
      v[7] = "\"Cx\u0005\u0010\u000f-\u00035\u000e\u001a\u0012(^>H\u0012\u000f%X:\u0003Q-.I#\n\u001a";
      v[8] = void.class;
      w[8] = "java/lang/Void";
      v[9] = "O,O\u001d\u0000oO,XA\f`UgX_\u0004cO=\u0015~\u0004hD*IR\u000br";
      v[10] = "\u0007I(ZRD\u0007I?\u0006^K\u001d\u0002?\u0018VH\u0007Xr\u0013JDG_?\u0006ZH\u0007_r'\\_\fI2";
      v[11] = "\u0019vb\u000b(YlVi\u00049\u0016\u0011Nz\u00030_y";
      v[12] = "`<\u001f\u0012\u0011Zo|R\u0019\u001bGj!Y_\u000bAj>B_\tGb\"A\u0014\f\u001bJ\u0005C\u0010\u000eEf ";
      v[13] = "\u001e\u0006\u001b\u0019\r+\u0010\u0017\u0014RB7\u001e\u0013\u001b^\u0002<_\u0018\u0013PX1_8\u0013P\u000b>\u0003";
      v[14] = "\u0005Q\u0007y#,\u000e^\u00166B\"\u0005U\u0012l";
      v[15] = "p-g\rw\u007f5w-l反厂桗伕桅厯栗厂厍桑\\Ua?<+2\u00122-?";
      v[16] = "}pf7u{8*,V佑优厀栌桄桏佑历厀取]*=?9r ol\u007f";
      v[17] = "#n!<v\u0017.8:\"\u001b%\u001en<8i\u0005p)o*jf";
      v[18] = "L\u007f\u0002+C=\t%HJ栣佞厱佇叺厉佧栚桫佇9sU}\u0000yW4\u0006o\u0003";
      v[19] = "7\u001e\u001b$UnrDQE栵厓及厸根桜栵桉栐伦 9\u001d*s\u001c]|Lj";
      v[20] = ":\u001atX@/\u007f@>9叺栈栝厼桖叺栠栈余伢OE\bk~\u00182\u0000Y+";
      v[21] = "=g\u0001A\u000bYjyRGr-\u00062C@\u0003\u001a<{ZH\rh;tFO\u0016\fv2E\u001er";
      v[22] = "\u0010\u000f*@huUU`!佌伖佳厩栈叢叒桒叭厩\u0011] 1T\rl\u0018qq";
      v[23] = "Vg\u0005:KA\u0001yV<2伭桴及栣伈栫伭估栐叹U\t\u001eRfCd^\u0000\u0001`";
      v[24] = "~|>[\\O8}dY;\u001c\u0017.g]\u000bJ\u0017\u001fa\n\u0007\u0000p #\u0018\u0001\b";
      v[25] = "rvo-Y\u0015rq1&7\u0015%ce;MqsahjEJ2k7g";
      v[26] = "\u0000Ua \f\u0019E\u000f+A桬古栧栩厙伜厶佺叽右Z}D\u0019\u0006@*=\u0004W\u0006";
      v[27] = "W=W?>'\u0012g\u001d^桞栀厪伅厯厝会佄厪桁l\"vc\u0013?\u0011g'#";
      v[28] = "\u0016\u0002x*;\nSX2K+4\u0012\\3*3FP\u0017\u007ftB\u000e\u0013\u0017\":0LX[|K";
      v[29] = "06ED4^ul\u000f%桔桹栗桊厽佸伐厣体厐~Y|\u001at4\u0003\u001c-Z";
      v[30] = ":Qu\\\u000f$mO&ZvQ\u0001\u00047]\u0007g;M.U\t\u0015";
      v[31] = "i4m*>u,n'K厄伖厔厒桏厈会桒桎厒V7v1-6+r'q";
      v[32] = "q~78^'4$}Y佺佄伒栂叏伄栾栀伒变\f%\u0016c5|q`G#";
      v[33] = "]DpAKa\u0018\u001e: q_S\u001a)\u0018\u00028\fD*L2b\u001eY*DV/XZ{ ";
      v[34] = "a)\u0016;\u0005[$s\\Z伡厦框休栴厙桥桼框桕-&M\u001f%+Pc\u001c_";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 3555;
      if (i[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])j.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            j.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/树树友树友友何友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = h[var5].getBytes("ISO-8859-1");
         i[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return i[var5];
   }

   public float s() {
      long a = 树树友树友友何友友树.a ^ 73735690423517L;
      return g<"ì">(this, -436202844935363354L, a);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public void c(float dragOffsetX) {
      long a = 树树友树友友何友友树.a ^ 15535308448336L;
      g<"s">(this, dragOffsetX, -2922733653432228869L, a);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 236 && var8 != 's' && var8 != 227 && var8 != 214) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'v') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'y') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 236) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 's') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 227) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public long h() {
      long a = 树树友树友友何友友树.a ^ 13504837094931L;
      return g<"ì">(this, -346010423776878000L, a);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = v[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = w[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         v[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public void a() {
      long a = 树树友树友友何友友树.a ^ 124455385829152L;

      try {
         Cherish.getConfigManager().E().h();
      } catch (Throwable var4) {
         g<"ã">(8791356462318832284L, a).info(b<"t">(8935, 2084933796418409731L ^ a), var4.getMessage());
      }
   }

   public void a(float y) {
      long a = 树树友树友友何友友树.a ^ 110298337788226L;
      g<"s">(this, y, 3774240285133530794L, a);
   }

   public float m() {
      long a = 树树友树友友何友友树.a ^ 67535225843819L;
      return g<"ì">(this, 380598438858053538L, a);
   }

   public void o(float dragOffsetY) {
      long a = 树树友树友友何友友树.a ^ 111207020619523L;
      g<"s">(this, dragOffsetY, -7913672280378976852L, a);
   }

   private void p() {
      long a = 树树友树友友何友友树.a ^ 62637863395000L;
      g<"y">(-6081935436200598237L, a);
      if (!g<"ì">(this, -6081108779816167329L, a)) {
         if (g<"ì">(this, -6081012514304064500L, a) == 0.0F && g<"ì">(this, -6081382173670311600L, a) == 0.0F) {
            g<"s">(this, g<"ì">(this, -6081493315459566149L, a), -6081012514304064500L, a);
            g<"s">(this, g<"ì">(this, -6082339835334969725L, a), -6081382173670311600L, a);
            if (mc != null) {
               int screenWidth = mc.getWindow().getGuiScaledWidth();
               int screenHeight = mc.getWindow().getGuiScaledHeight();
               g<"s">(
                  this,
                  Math.max(0.0F, Math.min(g<"ì">(this, -6081012514304064500L, a), screenWidth - g<"ì">(this, -6081216469443643023L, a))),
                  -6081012514304064500L,
                  a
               );
               g<"s">(
                  this,
                  Math.max(0.0F, Math.min(g<"ì">(this, -6081382173670311600L, a), screenHeight - g<"ì">(this, -6081893022920142603L, a))),
                  -6081382173670311600L,
                  a
               );
            }
         }

         g<"s">(this, true, -6081108779816167329L, a);
      }
   }

   public void p(float x) {
      long a = 树树友树友友何友友树.a ^ 29443558509208L;
      g<"s">(this, x, -19204716928708564L, a);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = v[var4];
      if (var5 instanceof String) {
         String var6 = w[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         v[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t(float height) {
      long a = 树树友树友友何友友树.a ^ 119958452140469L;
      g<"s">(this, height, 906792969864919032L, a);
   }

   public void t() {
      super.t();
      this.p();
   }

   public void g(float alpha) {
      long a = 树树友树友友何友友树.a ^ 73395065322276L;
      g<"s">(this, alpha, -8212965889205870301L, a);
   }

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/树树友树友友何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public float v() {
      long a = 树树友树友友何友友树.a ^ 43277340800770L;
      return g<"ì">(this, 153272498516021482L, a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = v[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(w[var4]);
            v[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public void U(int button) {
      long a = 树树友树友友何友友树.a ^ 46272204275988L;
      if (g<"y">(-849899277467288945L, a) != null) {
         g<"s">(this, false, -850926699706385582L, a);
      }

      this.a();
   }

   public float w() {
      long a = 树树友树友友何友友树.a ^ 41711363406454L;
      return g<"ì">(this, -3507126415437213323L, a);
   }

   public void u(float width) {
      long a = 树树友树友友何友友树.a ^ 57059365494292L;
      g<"s">(this, width, 7725686335073204701L, a);
   }

   public float r() {
      long a = 树树友树友友何友友树.a ^ 126193364057231L;
      return g<"ì">(this, 5308808738369988155L, a);
   }

   public boolean E() {
      long a = 树树友树友友何友友树.a ^ 66378166044108L;
      return g<"ì">(this, 8137876358225625899L, a);
   }

   private boolean X(double mouseX, double mouseY) {
      long a = 树树友树友友何友友树.a ^ 67393736423389L;
      g<"y">(4827183987800132678L, a);
      return mouseX >= g<"ì">(this, 4827545325542796649L, a)
         && mouseX <= g<"ì">(this, 4827545325542796649L, a) + g<"ì">(this, 4827340262305861652L, a)
         && mouseY >= g<"ì">(this, 4827738478690963509L, a)
         && mouseY <= g<"ì">(this, 4827738478690963509L, a) + g<"ì">(this, 4827229018863171984L, a);
   }

   public float X() {
      long a = 树树友树友友何友友树.a ^ 88801738454707L;
      return g<"ì">(this, 257475983381327028L, a);
   }

   public float P() {
      long a = 树树友树友友何友友树.a ^ 117775741262413L;
      return g<"ì">(this, -1194134081931357184L, a);
   }

   public static String[] H() {
      return 友何友树何何树友树何;
   }

   public boolean G(double mouseX, double mouseY, int button) {
      long a = 树树友树友友何友友树.a ^ 109025164854689L;
      g<"y">(8106976454010928698L, a);
      if (button == 0 && g<"ì">(mc, 8106553744928264845L, a) instanceof 树何树友树何何友何何 && this.X(mouseX, mouseY)) {
         g<"s">(this, true, 8108079742503059431L, a);
         g<"s">(this, (float)mouseX - g<"ì">(this, 8107249564535381781L, a), 8106813800929559562L, a);
         g<"s">(this, (float)mouseY - g<"ì">(this, 8107549095416898121L, a), 8110695893208610574L, a);
         return true;
      } else {
         return false;
      }
   }

   public float G() {
      long a = 树树友树友友何友友树.a ^ 43653003766283L;
      return g<"ì">(this, 2246017107958786976L, a);
   }

   public void O() {
      long a = 树树友树友友何友友树.a ^ 68867808318789L;
      String var10000 = g<"y">(2334440942397796062L, a);
      g<"s">(this, g<"ì">(this, 2334892477779426886L, a), 2334800901462233073L, a);
      g<"s">(this, g<"ì">(this, 2335739279012937086L, a), 2334994879486390957L, a);
      if (var10000 != null) {
         if (mc != null) {
            int screenWidth = mc.getWindow().getGuiScaledWidth();
            int screenHeight = mc.getWindow().getGuiScaledHeight();
            g<"s">(
               this,
               Math.max(0.0F, Math.min(g<"ì">(this, 2334800901462233073L, a), screenWidth - g<"ì">(this, 2334601344420606604L, a))),
               2334800901462233073L,
               a
            );
            g<"s">(
               this,
               Math.max(0.0F, Math.min(g<"ì">(this, 2334994879486390957L, a), screenHeight - g<"ì">(this, 2334484043123628808L, a))),
               2334994879486390957L,
               a
            );
         }

         this.a();
      }
   }

   public void O(double mouseX, double mouseY, int button) {
      long a = 树树友树友友何友友树.a ^ 18327280655478L;
      g<"y">(-1632915905795954707L, a);
      if (g<"ì">(this, -1634001742777817552L, a) && button == 0) {
         g<"s">(
            this,
            Math.max(
               0.0F,
               Math.min((float)(mouseX - g<"ì">(this, -1633043391655666211L, a)), mc.getWindow().getGuiScaledWidth() - g<"ì">(this, -1633393224886568001L, a))
            ),
            -1633171668955904318L,
            a
         );
         g<"s">(
            this,
            Math.max(
               0.0F,
               Math.min((float)(mouseY - g<"ì">(this, -1632122267043385639L, a)), mc.getWindow().getGuiScaledHeight() - g<"ì">(this, -1632855203621481925L, a))
            ),
            -1633470272400409698L,
            a
         );
      }
   }

   public void O(boolean dragging) {
      long a = 树树友树友友何友友树.a ^ 97182085964750L;
      g<"s">(this, dragging, 1651295884654156168L, a);
   }

   public static void K(String[] var0) {
      友何友树何何树友树何 = var0;
   }

   public float K() {
      long a = 树树友树友友何友友树.a ^ 34238574098172L;
      return g<"ì">(this, -8947659622465289133L, a);
   }

   private static String HE_SHU_YOU() {
      return "何炜霖诈骗";
   }
}
