package cn.cool.cherish.module;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public enum 何何友何何友何何树树 implements  {
   友树友友何何友何树友,
   友友树树何友友何树友,
   何友友友友友何何树友,
   树树何树树树何友友友,
   友何何何何友树友树树,
   何树友树何树何何树友,
   树树树何何友何树友友;

   public final String 友何何树树树友友何何;
   public final String 树友树何树树树树友友;
   private static String 友友树树树友何友友何;
   private static final long a;
   private static final Object[] b = new Object[15];
   private static final String[] c = new String[15];
   private static int _何炜霖国企变私企 _;

   private 何何友何何友何何树树(String name, String cnName) {
      this.友何何树树树友友何何 = name;
      this.树友树何树树树树友友 = cnName;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // $VF: Failed to inline enum fields
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7560405030508959890L, 9210568315783696296L, MethodHandles.lookup().lookupClass()).a(148642003824835L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 97021653881294L;
      a();
      if (a<"ý">(-3834789814421420880L, var9) == null) {
         a<"ý">("Xsm9Sb", -3834299600979273108L, var9);
      }

      Cipher var1;
      Cipher var13 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var0 = new String[21];
      int var6 = 0;
      String var5 = "}¯rÅ»<e¦\bi5º\u001eàÐ@J\u0010Á·\fA\u0087÷É\u008eÆ³\tLU\u009e\u0004[\u0010Ev\u0091e²\u0004Õ;^Òz\u009c\u0091\u0010×!\bûCÕ§o6X·\b\u0003\u008f\u009dâ\u009c}lM\b]§Mü\u0085Y\u0018\u009e\bÅ»Òõ\f0aY\u0010\f\u008fó<\u000e\u0095 KV÷ÿ¯\u008a¿\u001bú\u0010\"H\u0097ï,S\u0016y1¦\u0090\"Ì¾1i\b\u0005ÑØ\u0081\tW\\é\b\u0091`P+\u0099Û\u0096Ü\u0010$Ø\u0097¡¢\u0010YUµ\u001fwöSÒï\u009b\bGü¢\u009cA!\u0085\n\b*p|zÕÙ\u001d;\u0010LB\u0097ý\u008e&Ó¥\u0012\b\u00861\u008f\u0004_÷\b&é!~«Õ46\u0010\u0099\\z[S¾\u0001ÿ\u008a\u0007{ÐS´Yi\u0010§°X-t'Óµ¶\u0017Ëº³\u008cÃÜ";
      short var7 = 234;
      char var4 = '\b';
      int var12 = -1;

      label32:
      while (true) {
         String var14 = var5.substring(++var12, var12 + var4);
         byte var10001 = -1;

         while (true) {
            String var20 = a(var1.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var0[var6++] = var20;
                  if ((var12 += var4) >= var7) {
                     友树友友何何友何树友 = new 何何友何何友何何树树(var0[0], var0[15]);
                     友友树树何友友何树友 = new 何何友何何友何何树树(var0[20], var0[8]);
                     何友友友友友何何树友 = new 何何友何何友何何树树(var0[19], var0[17]);
                     树树何树树树何友友友 = new 何何友何何友何何树树(var0[13], var0[2]);
                     友何何何何友树友树树 = new 何何友何何友何何树树(var0[6], var0[12]);
                     何树友树何树何何树友 = new 何何友何何友何何树树(var0[4], var0[3]);
                     树树树何何友何树友友 = new 何何友何何友何何树树(var0[10], var0[9]);
                     return;
                  }

                  var4 = var5.charAt(var12);
                  break;
               default:
                  var0[var6++] = var20;
                  if ((var12 += var4) < var7) {
                     var4 = var5.charAt(var12);
                     continue label32;
                  }

                  var5 = "\b\u0004ª·7\tXU\u0010¢ª3\u0005Ó\u001a\u0080pÙÚo®Ä\u0088¹{";
                  var7 = 25;
                  var4 = '\b';
                  var12 = -1;
            }

            var14 = var5.substring(++var12, var12 + var4);
            var10001 = 0;
         }
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static 何何友何何友何何树树 h(String name) {
      return Enum.valueOf(何何友何何友何何树树.class, name);
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 231 && var8 != 'N' && var8 != 'S' && var8 != 'Q') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'j') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 253) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 231) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'N') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'S') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/何何友何何友何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 34;
               case 1 -> 55;
               case 2 -> 1;
               case 3 -> 29;
               case 4 -> 44;
               case 5 -> 12;
               case 6 -> 23;
               case 7 -> 61;
               case 8 -> 4;
               case 9 -> 5;
               case 10 -> 52;
               case 11 -> 48;
               case 12 -> 51;
               case 13 -> 38;
               case 14 -> 17;
               case 15 -> 20;
               case 16 -> 0;
               case 17 -> 40;
               case 18 -> 42;
               case 19 -> 39;
               case 20 -> 31;
               case 21 -> 63;
               case 22 -> 50;
               case 23 -> 58;
               case 24 -> 47;
               case 25 -> 13;
               case 26 -> 7;
               case 27 -> 45;
               case 28 -> 15;
               case 29 -> 11;
               case 30 -> 37;
               case 31 -> 49;
               case 32 -> 57;
               case 33 -> 18;
               case 34 -> 6;
               case 35 -> 41;
               case 36 -> 54;
               case 37 -> 16;
               case 38 -> 9;
               case 39 -> 46;
               case 40 -> 53;
               case 41 -> 33;
               case 42 -> 28;
               case 43 -> 14;
               case 44 -> 3;
               case 45 -> 25;
               case 46 -> 36;
               case 47 -> 30;
               case 48 -> 26;
               case 49 -> 35;
               case 50 -> 27;
               case 51 -> 43;
               case 52 -> 22;
               case 53 -> 21;
               case 54 -> 32;
               case 55 -> 62;
               case 56 -> 56;
               case 57 -> 24;
               case 58 -> 60;
               case 59 -> 2;
               case 60 -> 8;
               case 61 -> 19;
               case 62 -> 10;
               default -> 59;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "\u0006U\u0017H?,\t\u0015ZC51\fHQ\u0005=,\u0001NUN~伖估台佬佾厛伖估株栨";
      b[1] = "D!m&p^p\u0002bf=Uz\u001fg;6\u0013r\u0002j=2X1伸佛厃伋佨叔伸佛桙桏\u0006";
      b[2] = "`4/\\76k;>\u0013J.x<7Z";
      b[3] = void.class;
      c[3] = "java/lang/Void";
      b[4] = "\"n[\u0010 Z)aJ_AT\"jN\u0005";
      b[5] = "Xl4B3B\u0001{d+佗古叼发叉叨佗佺栦发\nLt\u0019V+o\u0015cI";
      b[6] = "6qy\u001a^Nof)s桾栲伌栖桞桪伺叨厒双G\u0014\u0019\u001586\"M\u000eE";
      b[7] = "\u00122\u007fP\u00173K%/9叭桏厶厏伜佤叭伋桬厏A^Ph\u001cu$\u0007G8";
      b[8] = "P>av>Z\t)1\u001f叄佢佪伝伂叜栞叼栮桙_xy\u0001^y:!nQ";
      b[9] = "5YYI[blN\t 伿叄伏古桾根伿叄伏栾g]\u0002<*NZFRd";
      b[10] = "S \u001bl*Q\n7K\u0005叐号栭桇佸叆叐佩栭厝%bm\n]g@;zZ";
      b[11] = "D?XS0j\u001d(\b:L\u000f\u001a!Y[ofY0\u0014Y\t5Oq\u0017Jre@-]:";
      b[12] = "\u00188q\u00114\tA/!xIlF&p\u0019k\u0005\u00057=\u001b\r";
      b[13] = "[1/E*M\u0002&\u007f,栊栱栥伒佌可低栱叿厌\u0011Km\u0016Uvt\u0012zF";
      b[14] = "u.<o\u00160,9l\u0006佲桌发桉佟栟佲伈栋厓\u0002aQk{ig8F;";
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static String L() {
      return 友友树树树友何友友何;
   }

   public static 何何友何何友何何树树[] M() {
      long var0 = a ^ 44307649053182L;
      return (何何友何何友何何树树[])a<"S">(1943605334659387719L, var0).clone();
   }

   public static void M(String var0) {
      友友树树树友何友友何 = var0;
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖国企上班";
   }
}
