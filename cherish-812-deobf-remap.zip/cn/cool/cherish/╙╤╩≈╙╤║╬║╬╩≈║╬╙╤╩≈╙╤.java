package cn.cool.cherish;

import cn.cool.cherish.config.友何何友树友树何树树;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友树友何何树何友树友 extends 何何何何何何何友树友 implements 何树友 {
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[7];
   private static final String[] i = new String[7];
   private static String HE_WEI_LIN;

   public 友树友何何树何友树友() {
      super("config", "cfg");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3592057615200068341L, 8064894049474962048L, MethodHandles.lookup().lookupClass()).a(44821929337081L);
      // $VF: monitorexit
      b = var10000;
      b();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(129320840004598L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[25];
      int var7 = 0;
      String var6 = "46»\u0006ß\u0018Ë\u0093\u0012ÕpR2\tÅíÚµTÈ 4N]~4#\u0091b~Ã!`|i`¥\u0005³\u0001$,=\u0014\u0006îç\u0087BüÝk\u0088cmõ\u000eå\u0092uØ¥f¿À\u008b\u009fôNÙ%ÒpÉYlt[qJyp\u0000çD\u0091\u001aàRC\u0010i\u0089å\u008eÚE\n\u001b+§0Oh\b\u0093k·)ïåþ\u007f=¿Ì\u007fê\u0018ÁiÒ(¯èÐÎðì\u0010\u0015¸iÅ\u0002üÕÓ¹\u009au/}êú\u0090\u00186\u0001ÑýÊ°\u0096Ò\u0019U\u008aPJéË\u008fõ©b\u0011\u00833<l(\u001fU\u0019Å\u0090·º\n¼ës1\u001d\u008cJNG\u0083ûZ\u0011\u0091j,Tl+í©î<r\t\u0099!«\u009e'\u008bS\u0010£2PcxdþVðÉäLæ\u008dí\n\u0018à¼*Ë]UèîÙ\u0011\u009a\u000fá7(õóà\u0091n\"\u0087\u0088x\u0010&FI\u0089I$]ÆÃ\u007fT\u000eD:C\u0011\u0010b\u009fÐ%A\u0087F&¶¤.£l·æ¥\u00108\u001a\u001boãG¶,5ßTÇ\u009bá\u008f{\u0010\u0007E!~½\u0011U7\u0015í\u0005B¦1,X(&\u0080\u001d\u009dN\u000bÈ\u009c3¾:»\u0083èç\u0093\u0013±Kü\u0097(¡Ö¼@ßÛ+Îý¢÷\u0005µD½\u0085\u0093\u0015`qg1Ø/7>Í~l¦1dü4¤>ôÊ-.s\u0087B¡\u0007+Öë\toèÍ>8Öxã_³SC´Ô·ö:ze©a5Ç½\u0087ð\t\u0006\\4\u0081\u0099þ¦û\u0010\u0014PwO÷\r\u0097\rÆ¨\u0098Ñµ_\u0011Ô÷\u001eS\n²\u0088Õ\bñn\u001e\u0018û¯\u00180ÔJ\u0087úÈ+f£I$U¹¿\f#k.¬E\u0088S\u0092( Ìé\u0089cMOepÿ \u009a£®UW\u0089ÎÊ\u008d¥\u008d#]ë\u0099ãÉ\u0018éVªØ\u0010e\u0099\u0092jÕ¹y\u001e\u0004U\u0006åï\u0089ì(\u0018\u0094kê¤Ù.\\\u0015!/\u0089\u008cÐX0Ü/\u001eÄ\u000b@#·Ð\u0010&¡\u0093m¤Y\u0087\u0096×\u008eµA§\u0080ýÐ\u0010\u0085+WÆlã`æÂóúA\u008e\u0096w\u008b\u0010\u00014·s\u001fö\u0000\u00058\u0006ùN\u000b\u009dõ¹\u0010\u00ad\u0000j\u009aLEá½ó\u001aÃ\u0014øîËÂ\u0010(.+\u009e¤!\u00913\u0084óòS>a`v\u0010!à\u009cPÝ\b\u0001Ð\u0000\u009dóÈäAÛ¤";
      short var8 = 662;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     d = new String[25];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "t=\u0088òµ.WÒ_Ö\u00adÌ¼\u0003Õè¦å=\u000fÁ\u008f\u000e \u0007\u0094íM±\u0091\u0015ªu¨D=\u0092¦\u0098y\u0010·_i2\u0085àøOªyçSVÎ-\u0087";
                  var8 = 57;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 44;
               case 2 -> 33;
               case 3 -> 10;
               case 4 -> 47;
               case 5 -> 6;
               case 6 -> 26;
               case 7 -> 21;
               case 8 -> 12;
               case 9 -> 22;
               case 10 -> 62;
               case 11 -> 34;
               case 12 -> 0;
               case 13 -> 60;
               case 14 -> 17;
               case 15 -> 19;
               case 16 -> 4;
               case 17 -> 59;
               case 18 -> 3;
               case 19 -> 48;
               case 20 -> 56;
               case 21 -> 35;
               case 22 -> 25;
               case 23 -> 46;
               case 24 -> 15;
               case 25 -> 14;
               case 26 -> 54;
               case 27 -> 28;
               case 28 -> 16;
               case 29 -> 24;
               case 30 -> 13;
               case 31 -> 29;
               case 32 -> 5;
               case 33 -> 43;
               case 34 -> 40;
               case 35 -> 52;
               case 36 -> 51;
               case 37 -> 30;
               case 38 -> 55;
               case 39 -> 27;
               case 40 -> 32;
               case 41 -> 7;
               case 42 -> 57;
               case 43 -> 2;
               case 44 -> 58;
               case 45 -> 1;
               case 46 -> 37;
               case 47 -> 53;
               case 48 -> 9;
               case 49 -> 39;
               case 50 -> 31;
               case 51 -> 20;
               case 52 -> 38;
               case 53 -> 49;
               case 54 -> 63;
               case 55 -> 11;
               case 56 -> 36;
               case 57 -> 41;
               case 58 -> 8;
               case 59 -> 18;
               case 60 -> 42;
               case 61 -> 23;
               case 62 -> 45;
               default -> 61;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   @Override
   public void i(String[] params) {
      友树友友何树何何树树.B();
      if (params.length < 1) {
         ClientUtils.P(125527250587045L, "Usage: .config/cfg <create/list/load/save> [config name]");
      } else {
         if (params.length == 1) {
            String configName = params[0].toLowerCase();
            byte switchModule = -1;
            switch (configName.hashCode()) {
               case 3322014:
                  if (configName.equals("list")) {
                     switchModule = 0;
                  }
               default:
                  switch (switchModule) {
                     case 0:
                        StringBuilder sb = new StringBuilder();
                        sb.append("Config list: ");
                        File[] files = Cherish.getConfigManager().e().listFiles();
                        if (files.length == 0) {
                           sb.append("empty");
                        }

                        boolean first = true;
                        int var13 = files.length;
                        int var14 = 0;
                        if (0 < var13) {
                           File file = files[0];
                           if (file.isFile() && file.getName().endsWith(".ini")) {
                              sb.append(file.getName().replace("", ""));
                              first = false;
                           }

                           var14++;
                        }

                        if (first) {
                           sb.append(".ini");
                        }

                        ClientUtils.P(125527250587045L, sb.toString());
                     default:
                        ClientUtils.P(125527250587045L, "empty");
                  }
            }
         }

         if (params.length == 2) {
            String configName = params[1];
            if (configName.isEmpty() || configName.contains("/") || configName.contains("\\")) {
               ClientUtils.P(125527250587045L, "Usage: .config/cfg <create/list/load/save> [config name]");
               return;
            }

            友何何友树友树何树树 switchModule = new 友何何友树友树何树树(new File(Cherish.getConfigManager().e(), configName + "Invalid config name."));

            try {
               String var19 = params[0].toLowerCase();
               byte var20 = -1;
               switch (var19.hashCode()) {
                  case 3327206:
                     if (!var19.equals(".ini")) {
                        break;
                     }

                     var20 = 0;
                  case -1352294148:
                     if (!var19.equals("load")) {
                        break;
                     }

                     var20 = 1;
                  case 3522941:
                     if (var19.equals("create")) {
                        var20 = 2;
                     }
               }

               switch (var20) {
                  case 0:
                     if (!switchModule.y().exists()) {
                        ClientUtils.P(125527250587045L, "save" + configName + "Config '");
                        return;
                     }

                     switchModule.k();
                     ClientUtils.P(125527250587045L, "' does not exist." + configName + "Config '");
                  case 1:
                  case 2:
                     if (switchModule.A()) {
                        ClientUtils.P(125527250587045L, "' loaded successfully." + configName + "Config '" + params[0].toLowerCase() + "' ");
                     }

                     ClientUtils.P(125527250587045L, "d successfully." + params[0].toLowerCase() + "Failed to " + configName + " config '");
                  default:
                     ClientUtils.P(125527250587045L, "'.");
               }
            } catch (Throwable var16) {
               ClientUtils.P(125527250587045L, "Usage: .config/cfg <create/list/load/save> [config name]" + var16.getMessage());
            }
         }

         ClientUtils.P(125527250587045L, "Error: ");
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 225 && var8 != 235 && var8 != 'z' && var8 != 'o') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 194) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'f') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 225) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 235) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'z') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void b() {
      h[0] = "\ri#dMY\u0002)noGD\u0007te)叩栧厥双佘栖佷佣桿栖";
      h[1] = "p\t.\u0014\u001a3D*!TW8N7$\t\\~F*)\u000fX5\u0005\b\"\u001eA<N~";
      h[2] = "\u0004w^\u0015\u0005q\u000b7\u0013\u001e\u000fl\u000ej\u0018X厡栏厬佌伥桧伿叕桶叒";
      h[3] = "|Xb&uLwWsi\u000fHdVc&9Ls";
      h[4] = "\u0002ierQX\tft=0V\u0002mpg";
      h[5] = "g<\u0015t\u001e\u0006\"(AK08$!\u001et\u0019Dc9\u001fK";
      h[6] = "[h_8Fh\u00044Oo6nb3C5\fm\frQi\f\u0007Xj@o\\i\u0019x\u001co6";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友树友何何树何友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11712;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/友树友何何树何友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[ã~Âh)\u0081ôl«âìËú¢2à, \u0017ÄPx\u0093N\u0011hÅ4ì>§\u0094½\u0014ë¨X,i\u0091.}úÓ\u0097>\u0011\u0092®\u0088©å\u008aN\u0001°¹\u000e>\"µv\t\u0098u3I\u0091Aï\u0019eµ.\u0085ÕÛãpv7\u008d, \u001eLß\u0000À4\tÆ, Fääö'}·\u0094lSlYc\u007f¾\u0007, ñ³©³hû\u0088ý\u0083ïCùv01^if\u0017¼Âbf¡, \u009cI?ýpå×¥, g'4Bý½_³Rèà\u001c\\S\u008eÃ, e\u0001ÒÜ\u008f\u0006ê@, Ï\u0088\\BþÂ")[var5]
            .getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友树友何何树何友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static String LIU_YA_FENG() {
      return "何建国230622195906030014";
   }
}
