package cn.cool.cherish.ui;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.impl.NumberValue;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 何友何友树树友何树树 implements 树何何何树友友友友友<NumberValue>, IWrapper,  {
   private static final float 友何友树何友友友友树 = 7.0F;
   private static final float 何何树树友友友友何树 = 2.0F;
   private static final float 友树树何友树友树树何 = 35.0F;
   private static final float 树树树树何何友何树何 = 10.0F;
   private static final float 树友友友何树何树友树 = 70.0F;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[24];
   private static final String[] e = new String[24];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(7046548988970599148L, 2930177704214842837L, MethodHandles.lookup().lookupClass()).a(279759268253483L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var4 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(26237910032820L << var3 * 8 >>> 56);
      }

      var4.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var5 = b(var2.doFinal("Ê¦\u0087tÒÖ#R".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      b = var5;
   }

   public boolean F(NumberValue value, int keyCode, int scanCode, int modifiers, 树何友何树树何何树树 componentsInstance) {
      return false;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 45;
               case 1 -> 10;
               case 2 -> 52;
               case 3 -> 42;
               case 4 -> 4;
               case 5 -> 60;
               case 6 -> 13;
               case 7 -> 40;
               case 8 -> 59;
               case 9 -> 33;
               case 10 -> 20;
               case 11 -> 63;
               case 12 -> 55;
               case 13 -> 8;
               case 14 -> 34;
               case 15 -> 3;
               case 16 -> 50;
               case 17 -> 44;
               case 18 -> 37;
               case 19 -> 7;
               case 20 -> 21;
               case 21 -> 9;
               case 22 -> 5;
               case 23 -> 31;
               case 24 -> 18;
               case 25 -> 43;
               case 26 -> 15;
               case 27 -> 25;
               case 28 -> 11;
               case 29 -> 22;
               case 30 -> 26;
               case 31 -> 53;
               case 32 -> 62;
               case 33 -> 29;
               case 34 -> 38;
               case 35 -> 12;
               case 36 -> 54;
               case 37 -> 27;
               case 38 -> 39;
               case 39 -> 46;
               case 40 -> 0;
               case 41 -> 49;
               case 42 -> 19;
               case 43 -> 30;
               case 44 -> 32;
               case 45 -> 17;
               case 46 -> 16;
               case 47 -> 2;
               case 48 -> 58;
               case 49 -> 35;
               case 50 -> 24;
               case 51 -> 14;
               case 52 -> 51;
               case 53 -> 28;
               case 54 -> 57;
               case 55 -> 1;
               case 56 -> 6;
               case 57 -> 41;
               case 58 -> 48;
               case 59 -> 56;
               case 60 -> 36;
               case 61 -> 47;
               case 62 -> 23;
               default -> 61;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'g' && var8 != 251 && var8 != 'u' && var8 != 'k') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 229) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'M') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'g') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public void b(NumberValue value, double mouseX, double mouseY, int button, 树何友何树树何何树树 componentsInstance) {
      友友树何何友树树友树.Z();
      if (componentsInstance.友友树树树树友何友树 == value) {
         componentsInstance.友友树树树树友何友树 = null;
      }
   }

   private String x(Number value, Number increment) {
      友友树何何友树树友树.V();
      String incrementString = Double.toString(Math.abs(increment.doubleValue()));
      int decimalPlaces = incrementString.contains(".") ? incrementString.length() - incrementString.indexOf(46) - 1 : 0;
      if (!(value instanceof Float) && !(value instanceof Double)) {
         return String.valueOf(value.intValue());
      } else {
         return decimalPlaces == 0 ? String.valueOf(value.intValue()) : String.format("%%.%df".formatted(decimalPlaces), value.doubleValue());
      }
   }

   public float x(NumberValue value, 树何友何树树何何树树 componentsInstance) {
      return 0.0F;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public boolean n(NumberValue value, char chr, int modifiers, 树何友何树树何何树树 componentsInstance) {
      return false;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      c[0] = "%\\\u0003\nR~*\u001cN\u0001Xc/AEGHxh佧另似叶栀桗叹佸桸栬";
      c[1] = "\n$!\u00008-\u0001+0OD4\u000e1>\fs\u0004\u0018&2\u0011b(\u000f+";
      c[2] = "`dgr'|o$*y-ajy!?=z-叁厂栀伝但又栛桘叚桙";
      c[3] = boolean.class;
      e[3] = "java/lang/Boolean";
      c[4] = "(4E/y>#![`\u0005<7;W'94\u000f:W+";
      c[5] = "L&o1\u000eXCf\":\u0004EF;)|\u0014^\u0001桙伔厙伴栦栾伝伔桃桰";
      c[6] = "\u000e\u0017\u001c-\ni\u0001WQ&\u0000t\u0004\nZ`\u0013g\u0001\fW`桴体伸桨佧厅桴体伸桨";
      c[7] = "|\u001d.-!Vb\u00154bGBe\u0014\u0015-\u007f";
      c[8] = "eU4\u0007\t\u000fj\u0015y\f\u0003\u0012oHrJ\u000b\u000fbNv\u0001H-i_o\b\u0003";
      c[9] = "I;QWPp}\u0018^\u0017\u001d{w\u0005[J\u0016=\u007f\u0018VL\u0012v<:]]\u000b\u007fwL";
      c[10] = "Bg\u0004\u0000y\u0000_r\\\"8\rGt";
      c[11] = void.class;
      e[11] = "java/lang/Void";
      c[12] = "v;F K7}4Wo*9v?S5";
      c[13] = "<\u0007VKOC*\u000eC)\u0016!n\u0006JOD\u001f)WWN\u007f\u0018gG]\u0012A_6Z\\)";
      c[14] = "aV\u001fmN0 \u0014O/w\u0005\\\u0016Gl\u000537EF+\u0010W";
      c[15] = "]\u0018GI,\u0011_\u0005V\u001cKsdS\u0014\\;W\u0003\u0012L\u0019\"-";
      c[16] = "L\u0013I6{+KTQ=\u0007厂厴桱栴栞栞厂伪厫栴\u0007;%FSHj{9\u0018Y";
      c[17] = "\u0004T\u0013YzA\u0006I\u0002\f\u001d/=\u001f@Lm\u0007Z^\u0018\tt}";
      c[18] = ",;\u0002\u0018J\t+|\u001a\u00136桺栎伝桿只佫桺栎伝伻)\n\u001dszZPM\u0007}y";
      c[19] = "\u001c]U)PX\u0013[\f%jgc%h\u000ej\u0007\u001a\u0005^y\n\b\u001c\\R";
      c[20] = "y\u0007-F\u00071{\u001a<\u0013`s@L~S\u0010w'\r&\u0016\t\rpH;PXh0\u001f*\u0011`";
      c[21] = "\u0007H\u001e$\u001a\u000f\u0000\u000f\u0006/f桼佡佮伧佈桿厦佡台厹\u0015Z\u001bX\tFl\u001d\u0001V\n";
      c[22] = "\u001d3FfM\u0004\u001at^m1桷佻伕栻桎栨伳栿桑使W\r\u0010Br\u001e.J\nLq";
      c[23] = "Z\u001d\u0002\u001eFe\\FM\u00027@(i<0jXa\u0016B\u0017Nq\u0004\u0010\u0019XR";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何友何友树树友何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public boolean a(
      NumberValue value, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 树何友何树树何何树树 componentsInstance
   ) {
      友友树何何友树树友树.V();
      float sliderX = x + width - 117.0F;
      if (button == 0 && mouseX >= sliderX && mouseX <= sliderX + 70.0F && mouseY >= middleY - 1.0F - 3.0F && mouseY <= middleY + 1.0F + 3.0F) {
         componentsInstance.友友树树树树友何友树 = value;
         double minValue = value.o().doubleValue();
         double maxValue = value.A().doubleValue();
         double mousePercent = Mth.clamp((mouseX - sliderX) / 70.0, 0.0, 1.0);
         double newValue = minValue + (maxValue - minValue) * mousePercent;
         if (maxValue - minValue == 0.0) {
            newValue = minValue;
         }

         value.S(this.T(newValue, value.X().doubleValue(), (Class<? extends Number>)value.getValue().getClass()));
         return true;
      } else {
         return false;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void v(NumberValue value, 树何友何树树何何树树 componentsInstance) {
      double values = value.getValue().doubleValue();
      友友树何何友树树友树.V();
      double minValue = value.o().doubleValue();
      double maxValue = value.A().doubleValue();
      float progress = 0.0F;
      if (maxValue - minValue != 0.0) {
         progress = (float)((values - minValue) / (maxValue - minValue));
      }

      componentsInstance.树树何树友何树树何何.putIfAbsent(value, progress);
      componentsInstance.树何何树树树何树树何.putIfAbsent(value, progress);
      componentsInstance.树何何何何树友何友友.putIfAbsent(value, new float[]{0.0F});
   }

   private Number T(double value, double increment, Class<? extends Number> originalType) {
      友友树何何友树树友树.V();
      if (increment == 0.0) {
         return value;
      } else {
         BigDecimal bdValue = BigDecimal.valueOf(value);
         BigDecimal bdIncrement = BigDecimal.valueOf(increment);
         BigDecimal divided = bdValue.divide(bdIncrement, 0, RoundingMode.HALF_UP);
         BigDecimal rounded = divided.multiply(bdIncrement);
         if (originalType == Double.class) {
            return rounded.doubleValue();
         } else if (originalType == Float.class) {
            return rounded.floatValue();
         } else if (originalType == Long.class) {
            return rounded.longValue();
         } else if (originalType == Integer.class) {
            return rounded.intValue();
         } else if (originalType == Short.class) {
            return rounded.shortValue();
         } else {
            return (Number)(originalType == Byte.class ? rounded.byteValue() : rounded.doubleValue());
         }
      }
   }

   public void R(
      GuiGraphics guiGraphics,
      NumberValue value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      何何友友树何树何友树 valueNameFont,
      何何友友树何树何友树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      树何友何树树何何树树 componentsInstance
   ) {
      友友树何何友树树友树.Z();
      float sliderX = x + width - 117.0F;
      float sliderY = middleY - 1.0F;
      double values = value.getValue().doubleValue();
      double minValue = value.o().doubleValue();
      double maxValue = value.A().doubleValue();
      float currentProgress = (float)((values - minValue) / (maxValue - minValue));
      if (maxValue - minValue == 0.0) {
         currentProgress = 0.0F;
      }

      float animatedProgress = componentsInstance.R(value, currentProgress, partialTicks);
      animatedProgress = Mth.clamp(animatedProgress, 0.0F, 1.0F);
      RenderUtils.drawRectangle(guiGraphics.pose(), sliderX, sliderY, 70.0F, 2.0F, darkBgColor.darker().getRGB());
      RenderUtils.drawRectangle(guiGraphics.pose(), sliderX, sliderY, 70.0F * animatedProgress, 2.0F, accentColor.getRGB());
      RenderUtils.drawRectangle(
         guiGraphics.pose(), sliderX + 70.0F * animatedProgress - 2.0F, sliderY + 1.0F - 2.0F, 4.0F, 4.0F, accentColor.brighter().getRGB()
      );
      String valueString = this.x(value.getValue(), value.X());
      float boxX = x + width - 42.0F;
      float boxY = middleY - 5.0F;
      RenderUtils.drawRoundedRect(guiGraphics.pose(), boxX, boxY, 35.0, 10.0, 2.0, darkBgColor);
      valueDisplayFont.h(guiGraphics.pose(), valueString, boxX + 17.5F, boxY + (10.0F - valueDisplayFont.x()) / 2.0F + 0.5F, Color.WHITE.getRGB());
      if (componentsInstance.友友树树树树友何友树 == value) {
         double mousePercent = Mth.clamp((mouseX - sliderX) / 70.0F, 0.0, 1.0);
         double newValue = minValue + (maxValue - minValue) * mousePercent;
         if (maxValue - minValue == 0.0) {
            newValue = minValue;
         }

         value.S(this.T(newValue, value.X().doubleValue(), (Class<? extends Number>)value.getValue().getClass()));
      }

      if (Module.Z() == null) {
         友友树何何友树树友树.v(false);
      }
   }

   private static String HE_DA_WEI() {
      return "何炜霖国企变私企";
   }
}
