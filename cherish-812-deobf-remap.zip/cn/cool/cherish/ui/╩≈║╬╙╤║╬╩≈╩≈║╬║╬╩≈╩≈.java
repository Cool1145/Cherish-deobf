package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;

public class 树何友何树树何何树树 implements IWrapper, 何树友 {
   public final HashMap<String, HashMap<String, Float>> 友友友友友树何树何树;
   public final HashMap<NumberValue, Float> 树树何树友何树树何何;
   public final HashMap<NumberValue, Float> 树何何树树树何树树何;
   public final HashMap<NumberValue, float[]> 树何何何何树友何友友;
   public final HashMap<ModeValue, Boolean> 何树何树友何何何树友;
   public final HashMap<ModeValue, Float> 树友树何何友树友友何;
   public 树何友何树树何何树树.友何树何友树树何何何 何何何友友树友何树何;
   public 树友何何树树何友友何 友友友友何树友树友树;
   public 树何何树何友树何何树<?> 友友树树树树友何友树;
   public float 友友何友友树友友何友;
   public float 树何何友何树树友友树;
   public float 树树友友树友友友树树;
   private final Module 何何友何何友何何友友;
   public Color 树树树友何友友友何何;
   public boolean 树友何友友树何树何友;
   public float 树树何树何友友友友友;
   private static final float 何树树友何何何友树友 = 16.0F;
   public 何何何友友何树何何何 何友树树友何何友树树;
   public final HashMap<树友何何树树何友友何, Float> 友何友何友树何何友树;
   public final HashMap<树友何何树树何友友何, Boolean> 友友友友树何何友树何;
   private final Map<Class<? extends 树何何树何友树何何树<?>>, 树何何何树友友友友友<?>> 何友何何友何树何何何;
   private static String[] 友树友友何树树友树何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[43];
   private static final String[] g = new String[43];
   private static String HE_JIAN_GUO;

   public 树何友何树树何何树树(Module module) {
      X();
      this.友友友友友树何树何树 = new HashMap<>();
      this.树树何树友何树树何何 = new HashMap<>();
      this.树何何树树树何树树何 = new HashMap<>();
      this.树何何何何树友何友友 = new HashMap<>();
      this.何树何树友何何何树友 = new HashMap<>();
      this.树友树何何友树友友何 = new HashMap<>();
      this.何何何友友树友何树何 = null;
      this.友友友友何树友树友树 = null;
      this.何友树树友何何友树树 = null;
      this.友何友何友树何何友树 = new HashMap<>();
      this.友友友友树何何友树何 = new HashMap<>();
      this.何友何何友何树何何何 = new HashMap<>();
      this.何何友何何友何何友友 = module;
      this.何友何何友何树何何何.put(BooleanValue.class, new 友友何树树何友何何友());
      this.何友何何友何树何何何.put(NumberValue.class, new 何友何友树树友何树树());
      this.何友何何友何树何何何.put(ModeValue.class, new 何友树树树友树友树友());
      this.何友何何友何树何何何.put(何何何友友何树何何何.class, new 树何树树何树友树何何());
      this.何友何何友何树何何何.put(树友何何树树何友友何.class, new 友友树何何友树树友树());
      if (Module.Z() == null) {
         V(new String[1]);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5026410525711563364L, 1606261522692118795L, MethodHandles.lookup().lookupClass()).a(18311879990648L);
      // $VF: monitorexit
      a = var10000;
      a();
      V(null);
      Cipher var0;
      Cipher var9 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(21673659523974L << var1 * 8 >>> 56);
      }

      var9.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[2];
      int var5 = 0;
      char var3 = 'H';
      int var2 = -1;

      while (true) {
         String var11 = b(
               var0.doFinal(
                  "PÎÜpM%ÓÜ¡\u008a\u0016\u0098^\u0096\u0018Üüp{l®Þ\u0097«\u0018Û<Â?<0aºª\u0016&Êl^\u001aI\u0097ä]ØIDjæÃoë7\u0018ï×¶.±2\u0099q\r°\u0099rÕïqí\n\u0082(¹ê Kç¶WwgàcPþÔ`´Dd\u0018Ð\u0092§åÓÑÌÎ1½Q\u009fÁV ½ôðy\u008dõ"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var11;
         if ((var2 += var3) >= 113) {
            b = var7;
            c = new String[2];
            return;
         }

         var3 = "PÎÜpM%ÓÜ¡\u008a\u0016\u0098^\u0096\u0018Üüp{l®Þ\u0097«\u0018Û<Â?<0aºª\u0016&Êl^\u001aI\u0097ä]ØIDjæÃoë7\u0018ï×¶.±2\u0099q\r°\u0099rÕïqí\n\u0082(¹ê Kç¶WwgàcPþÔ`´Dd\u0018Ð\u0092§åÓÑÌÎ1½Q\u009fÁV ½ôðy\u008dõ"
            .charAt(var2);
      }
   }

   public static void V(String[] var0) {
      友树友友何树树友树何 = var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 6;
               case 2 -> 10;
               case 3 -> 39;
               case 4 -> 33;
               case 5 -> 1;
               case 6 -> 22;
               case 7 -> 17;
               case 8 -> 62;
               case 9 -> 7;
               case 10 -> 14;
               case 11 -> 61;
               case 12 -> 45;
               case 13 -> 59;
               case 14 -> 11;
               case 15 -> 2;
               case 16 -> 28;
               case 17 -> 30;
               case 18 -> 4;
               case 19 -> 57;
               case 20 -> 47;
               case 21 -> 5;
               case 22 -> 63;
               case 23 -> 38;
               case 24 -> 40;
               case 25 -> 12;
               case 26 -> 27;
               case 27 -> 55;
               case 28 -> 53;
               case 29 -> 9;
               case 30 -> 25;
               case 31 -> 19;
               case 32 -> 58;
               case 33 -> 18;
               case 34 -> 37;
               case 35 -> 23;
               case 36 -> 24;
               case 37 -> 41;
               case 38 -> 46;
               case 39 -> 48;
               case 40 -> 35;
               case 41 -> 15;
               case 42 -> 0;
               case 43 -> 3;
               case 44 -> 52;
               case 45 -> 60;
               case 46 -> 26;
               case 47 -> 36;
               case 48 -> 54;
               case 49 -> 8;
               case 50 -> 34;
               case 51 -> 43;
               case 52 -> 16;
               case 53 -> 50;
               case 54 -> 51;
               case 55 -> 31;
               case 56 -> 21;
               case 57 -> 56;
               case 58 -> 49;
               case 59 -> 13;
               case 60 -> 20;
               case 61 -> 29;
               case 62 -> 44;
               default -> 32;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何友何树树何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'c' && var8 != 228 && var8 != 'Z' && var8 != 227) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'A') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 253) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'c') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 228) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'Z') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public void c() {
      this.何友树树友何何友树树 = null;
      this.树友何友友树何树何友 = false;
      X();
      this.友友友友何树友树友树 = null;
      this.何何何友友树友何树何 = null;
      this.友友树树树树友何友树 = null;
      this.树树何树友何树树何何.clear();
      this.树何何树树树何树树何.clear();
      this.树何何何何树友何友友.clear();
      this.何树何树友何何何树友.clear();
      this.树友树何何友树友友何.clear();
      this.友友友友友树何树何树.clear();
      this.友友友友树何何友树何.clear();
      this.友何友何友树何何友树.clear();
      Iterator var4 = this.何何友何何友何何友友.P().iterator();
      if (var4.hasNext()) {
         树何何树何友树何何树<?> value = (树何何树何友树何何树<?>)var4.next();
         树何何何树友友友友友<树何何树何友树何何树<?>> renderer = this.X(value);
         if (renderer != null) {
            renderer.Y(value, this);
         }

         null.println("" + value.getClass().getName());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   public void h(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      X();
      this.树友何友友树何树何友 = this.何友树树友何何友树树 != null;
      float yOffset = 0.0F;
      ClientUtils.D(131325480669526L);
      何何友友树何树何友树 valueNameFont = Cherish.instance.t().H(16);
      何何友友树何树何友树 defaultValueFont = Cherish.instance.t().H(14);
      Color accentC = this.树树树友何友友友何何 != null ? this.树树树友何友友友何何 : HUD.instance.getColor(0);
      Color disabledC = new Color(60, 60, 60, 200);
      Color darkBgC = new Color(45, 45, 45, 235);

      for (树何何树何友树何何树<?> value : this.何何友何何友何何友友.P()) {
         if (!value.O()) {
            float valueRowY = this.树何何友何树树友友树 + 0.0F;
            float middleValueRowY = valueRowY + 8.0F;
            树何何何树友友友友友<树何何树何友树何何树<?>> renderer = this.X(value);
            valueNameFont.q(guiGraphics.pose(), value.r(), this.友友何友友树友友何友 + 5.0F, middleValueRowY - valueNameFont.x() / 2.0F, Color.WHITE.getRGB());
            renderer.K(
               guiGraphics,
               value,
               this.友友何友友树友友何友,
               valueRowY,
               this.树树友友树友友友树树,
               16.0F,
               middleValueRowY,
               mouseX,
               mouseY,
               partialTicks,
               valueNameFont,
               defaultValueFont,
               accentC,
               disabledC,
               darkBgC,
               this
            );
            yOffset = 0.0F + (16.0F + renderer.h(value, this));
            defaultValueFont.q(
               guiGraphics.pose(),
               "Unhandled value type",
               this.友友何友友树友友何友 + this.树树友友树友友友树树 - 70.0F,
               middleValueRowY - defaultValueFont.x() / 2.0F,
               Color.RED.getRGB()
            );
            yOffset += 16.0F;
            break;
         }
      }

      this.树树何树何友友友友友 = yOffset;
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   public void d(double mouseX, double mouseY, int button) {
      X();
      if (this.友友树树树树友何友树 instanceof NumberValue ns) {
         树何何何树友友友友友<NumberValue> renderer = this.X(ns);
         renderer.o(ns, mouseX, mouseY, button, this);
      }

      if (this.友友友友何树友树友树 != null && button == 0) {
         树何何何树友友友友友<树友何何树树何友友何> renderer = this.X(this.友友友友何树友树友树);
         if (renderer != null) {
            renderer.o(this.友友友友何树友树友树, mouseX, mouseY, button, this);
         }
      }

      if (button == 0) {
         if (this.友友树树树树友何友树 != null) {
            this.友友树树树树友何友树 = null;
         }

         if (this.友友友友何树友树友树 != null) {
            this.友友友友何树友树友树 = null;
         }

         if (this.何何何友友树友何树何 != null) {
            this.何何何友友树友何树何 = null;
         }
      }
   }

   private static void a() {
      f[0] = "dX_#\u000f7k\u0018\u0012(\u0005*nE\u0019n\u00151)栧伤压伵桉栖佣伤桑桱";
      f[1] = "]Hf<_1C@|s<%G";
      f[2] = "\u0010\u0011,\u001fn-e1'\u0010\u007fb\u0018)4\u0017v+p";
      f[3] = "]M\u0013\n05VB\u0002EL,YX\f\u0006{\u001cOO\u0000\u001bj0XB";
      f[4] = "3 \u000b\u000fh\u000e<`F\u0004b\u00139=MBj\u000e4;I\t),?*P\u0000b";
      f[5] = float.class;
      g[5] = "java/lang/Float";
      f[6] = "1BB6\u000bg>\u0002\u000f=\u0001z;_\u0004{\u0012i>Y\t{\re\"@B伀伱佝厙叧伹桄伱佝伇";
      f[7] = boolean.class;
      g[7] = "java/lang/Boolean";
      f[8] = "\u0002HuKZ8\r\b8@P%\bU3\u0006@>O样伎口你框桰佳伎根栤s厪佳桊佽叾框桰佳伎佽";
      f[9] = "3~\\\"l\t<>\u0011)f\u00149c\u001aou\u0007<e\u0017oj\u000b |\\桐又伳伅栁档伔又厭伅";
      f[10] = "OAQ~1E{b^>|Nq\u007f[cw\bybVesC:@]tjJq6";
      f[11] = "M\u0002$w@_8\"/xQ\u0010E:<\u007fXY-";
      f[12] = void.class;
      g[12] = "java/lang/Void";
      f[13] = "\u0004{\u0011JtG\u001as\u000b\u0005\u0012S\u001dr*J*";
      f[14] = "qJ,\r@?~\na\u0006J\"{Wj@Y1~Qg@栾伅佇栵佗厥栾伅佇栵";
      f[15] = "<)@4\u0014\u000f!<\u0018\u0016U\u00029:";
      f[16] = "%u\b\u001e\b#.z\u0019Qi-%q\u001d\u000b";
      f[17] = "<gR[\"Bu!\nf伓叡佘佃厨伻桗使佘佃k_s@h$\t\u000ft@g";
      f[18] = "]cd,\rR\u0014%<\u0011似佯厧佇伀叒似佯厧叙]*ZL\u0000c;a\u001f]^";
      f[19] = "#m\u0018\u0002UBj+@?栠栻佇栍佼叼叺叡叙受!\u0004KAu+\u001eO\u0006]y";
      f[20] = "\n,TV?\u0013Cj\fk桊桪株厖估厨厐厰佮伈m\u0002/\u000eZk\u000f\u0011(\u000fY";
      f[21] = "a1n\u0017Hu(w6*t\u0015hs&R\u001e,48lD$";
      f[22] = "R\\Ke\u0016Q\u001b\u001a\u0013X伧史桲格厱伅伧史桲格rd\u0010T\u0004B\n%\u0017_\u0019";
      f[23] = "a\u0002wq\u0015\\(D/L桠叿桁伦伓厏桠叿厛伦N}DR4\u001fw-\u0005V6";
      f[24] = "x\u0002\u001b\t\rL1DC4\b,{F\u001fIP\u0014\u007f\u000bA\ra\u0016|F_\u0005Y\u00121\u0018\u001b4";
      f[25] = "$1k%zuotz{\u0003A\u001f4g.gtefd{l\u0013";
      f[26] = "p\"2i\u0005{9djT厪变厊厘又桍伴栂伔桂\u000beTu%?25\u0015q'";
      f[27] = "\u000b4A\u000fs\"Br\u00192叜厁栫桔桡栫叜伟叱桔x[/9\b \u0005O~3I";
      f[28] = "\u0003}lRg0J;4oUP\n?$\u00171iVtn\u0001\u000b`Heo\u000b{m[j%o";
      f[29] = "4-\u0013R\u0004C}kKo厫叠佐厗叩桶厫叠佐厗*T\u001a@bk\u0015\u001fW\\n";
      f[30] = "&D\r!lGo\u0002U\u001c栙栾叜叾栭叟參古栆栤4'rDp\u0002\u000bl?X|";
      f[31] = "M.{\u007f\u0005=\u0004h#B伴桄伩桎厁伟伴伀桭厔BsT3\u00183{#\u00157\u001a";
      f[32] = "\u0019ZLi\u001b\u0017P\u001c\u0014T桮伪佽栺桬桍伪桮根佾ueJ\u0019LGL5\u000b\u001dN";
      f[33] = "4=\u0014v\u0016S}{LK伧佮佐厇叮桒厹佮栔伙-uF\u000e\u007ftT4\u0016Nd";
      f[34] = "\u0002c\u0016lqWK%NQ叞叴司叙佲案叞栮司栃/o|\u000eQ`Ca$\bC";
      f[35] = "\u0007eB\u001e.\u0007N#\u001a#厁伺叽佁厸栺伟伺叽栅{\u0012\u007f\tRxBB>\rP";
      f[36] = "PT\u0006P:\u0017\u0019\u0012^m桏伪伴叮佢桴桏厴厪栴?V$\u0014\u0006\u0012\u0000\u001di\b\n";
      f[37] = "U\u00071bhuF\u00000aVMq7Lb*jUE.q-kV";
      f[38] = "}?3--`4yk\u0010桘參伙厅叉栉伜栙伙厅\n-~<};k}~\u007f\u007f";
      f[39] = "eNO\u007f\u0002\b,\b\u0017B厭厫原叴桯伟伳厫桅佪vsS\u00060SO#\u0012\u00022";
      f[40] = "M\u0005p$Z\u0000\u0004C(\u0019栯桹伩桥厊佄栯桹伩伡I(\u000b\u000e\u0018\u0018pxJ\n\u001a";
      f[41] = "j\u0001W \u0003\"y\u0006V#=\u001fC<v\u0004=)\u007f\u0000Cw_:x\u0001@";
      f[42] = "/.){/6fhqF桚伋佋伊位桟厀伋叕厔\u0010w~8z3)'?<x";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6452;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树何友何树树何何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何友何树树何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public float g() {
      float totalHeight = 0.0F;
      X();

      for (树何何树何友树何何树<?> value : this.何何友何何友何何友友.P()) {
         if (!value.O()) {
            树何何何树友友友友友<树何何树何友树何何树<?>> renderer = this.X(value);
            totalHeight = 16.0F + renderer.h(value, this);
            break;
         }
      }

      return totalHeight;
   }

   public void z(int keyCode, int scanCode, int modifiers) {
      X();
      if (this.何友树树友何何友树树 != null) {
         树何何何树友友友友友<何何何友友何树何何何> renderer = this.X(this.何友树树友何何友树树);
         if (renderer != null) {
            renderer.x(this.何友树树友何何友树树, keyCode, scanCode, modifiers, this);
         }
      }
   }

   private <T extends 树何何树何友树何何树<?>> 树何何何树友友友友友<T> X(T value) {
      X();
      if (value == null) {
         return null;
      } else {
         Class<?> valueClass = value.getClass();
         return 树何何树何友树何何树.class.isAssignableFrom(valueClass) ? (树何何何树友友友友友)this.何友何何友何树何何何.get(valueClass) : null;
      }
   }

   public static String[] X() {
      return 友树友友何树树友树何;
   }

   public void L(char chr, int modifiers) {
      X();
      if (this.何友树树友何何友树树 != null && this.树友何友友树何树何友) {
         树何何何树友友友友友<何何何友友何树何何何> renderer = this.X(this.何友树树友何何友树树);
         if (renderer != null) {
            renderer.V(this.何友树树友何何友树树, chr, modifiers, this);
         }
      }
   }

   public void W(double mouseX, double mouseY, int button) {
      X();

      for (树何何树何友树何何树<?> value : this.何何友何何友何何友友.P()) {
         if (!value.O()) {
            float valueRowY = this.树何何友何树树友友树 + 0.0F;
            float middleValueRowY = valueRowY + 8.0F;
            树何何何树友友友友友<树何何树何友树何何树<?>> renderer = this.X(value);
            float extraHeight = 0.0F;
            if (renderer != null) {
               extraHeight = renderer.h(value, this);
            }

            float totalValueHeight = 16.0F + extraHeight;
            if (mouseY >= valueRowY && mouseY <= valueRowY + totalValueHeight && renderer != null) {
               renderer.g(value, mouseX, mouseY, button, this.友友何友友树友友何友, valueRowY, this.树树友友树友友友树树, 16.0F, middleValueRowY, this);
            }

            float var10000 = 0.0F + totalValueHeight;
            break;
         }
      }
   }

   public float R(NumberValue value, float targetPosition, float partialTicks) {
      X();
      if (!this.树树何树友何树树何何.containsKey(value)) {
         this.树树何树友何树树何何.put(value, targetPosition);
      }

      if (!this.树何何树树树何树树何.containsKey(value)) {
         this.树何何树树树何树树何.put(value, targetPosition);
      }

      if (!this.树何何何何树友何友友.containsKey(value)) {
         this.树何何何何树友何友友.put(value, new float[]{0.0F});
      }

      this.树何何树树树何树树何.put(value, targetPosition);
      float currentPosition = this.树树何树友何树树何何.get(value);
      float[] velocity = this.树何何何何树友何友友.get(value);
      if (this.友友树树树树友何友树 == value) {
         this.树树何树友何树树何何.put(value, targetPosition);
         velocity[0] = 0.0F;
         return targetPosition;
      } else {
         float deltaTime = partialTicks * 0.05F;
         float distance = targetPosition - currentPosition;
         float springForce = distance * 8.0F;
         velocity[0] += springForce * deltaTime;
         velocity[0] *= (float)Math.pow(0.75, deltaTime * 60.0);
         float newPosition = currentPosition + velocity[0] * deltaTime * 5.0F;
         if (Math.abs(distance) < 0.001F && Math.abs(velocity[0]) < 0.001F) {
            newPosition = targetPosition;
            velocity[0] = 0.0F;
         }

         this.树树何树友何树树何何.put(value, newPosition);
         return newPosition;
      }
   }

   private static String HE_JIAN_GUO() {
      return "行走的50万——何炜霖";
   }

   public static enum 友何树何友树树何何何 implements  {
      友树友树树何友友友树,
      何何何友友树友树何何,
      友树友树友友何友友何;

      private static final long a;
      private static final Object[] b = new Object[7];
      private static final String[] c = new String[7];
      private static String HE_SHU_YOU;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-230230475925827406L, 293460074028837841L, MethodHandles.lookup().lookupClass()).a(231711665522291L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var8 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(68378706461990L << var2 * 8 >>> 56);
         }

         var8.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[3];
         int var6 = 0;
         char var4 = '\b';
         int var3 = -1;

         while (true) {
            String var10 = a(
                  var1.doFinal(
                     "B\u008f@\u000b$½/+\b\u008fB\u009cÙ¶êê\u000b\u0010\u0084\u000b<\u0019;Gq\u001a¬\u008cÛcy$\u0097{"
                        .substring(++var3, var3 + var4)
                        .getBytes("ISO-8859-1")
                  )
               )
               .intern();
            byte var10001 = -1;
            var0[var6++] = var10;
            if ((var3 += var4) >= 34) {
               友树友树树何友友友树 = new 树何友何树树何何树树.友何树何友树树何何何();
               何何何友友树友树何何 = new 树何友何树树何何树树.友何树何友树树何何何();
               友树友树友友何友友何 = new 树何友何树树何何树树.友何树何友树树何何何();
               return;
            }

            var4 = "B\u008f@\u000b$½/+\b\u008fB\u009cÙ¶êê\u000b\u0010\u0084\u000b<\u0019;Gq\u001a¬\u008cÛcy$\u0097{".charAt(var3);
         }
      }

      public static 树何友何树树何何树树.友何树何友树树何何何[] B() {
         return (树何友何树树何何树树.友何树何友树树何何何[])友友何友何树何何树树.clone();
      }

      public static 树何友何树树何何树树.友何树何友树树何何何 I(String name) {
         return Enum.valueOf(树何友何树树何何树树.友何树何友树树何何何.class, name);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 249 && var8 != 'r' && var8 != 250 && var8 != 246) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'V') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 181) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 249) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'r') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 250) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树何友何树树何何树树$友何树何友树树何何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 37;
                  case 1 -> 12;
                  case 2 -> 26;
                  case 3 -> 32;
                  case 4 -> 46;
                  case 5 -> 2;
                  case 6 -> 7;
                  case 7 -> 24;
                  case 8 -> 49;
                  case 9 -> 21;
                  case 10 -> 40;
                  case 11 -> 58;
                  case 12 -> 36;
                  case 13 -> 31;
                  case 14 -> 63;
                  case 15 -> 59;
                  case 16 -> 50;
                  case 17 -> 52;
                  case 18 -> 19;
                  case 19 -> 6;
                  case 20 -> 29;
                  case 21 -> 8;
                  case 22 -> 20;
                  case 23 -> 18;
                  case 24 -> 60;
                  case 25 -> 16;
                  case 26 -> 4;
                  case 27 -> 17;
                  case 28 -> 43;
                  case 29 -> 53;
                  case 30 -> 61;
                  case 31 -> 13;
                  case 32 -> 28;
                  case 33 -> 5;
                  case 34 -> 23;
                  case 35 -> 55;
                  case 36 -> 10;
                  case 37 -> 30;
                  case 38 -> 48;
                  case 39 -> 3;
                  case 40 -> 33;
                  case 41 -> 15;
                  case 42 -> 9;
                  case 43 -> 62;
                  case 44 -> 14;
                  case 45 -> 27;
                  case 46 -> 22;
                  case 47 -> 41;
                  case 48 -> 47;
                  case 49 -> 35;
                  case 50 -> 54;
                  case 51 -> 0;
                  case 52 -> 57;
                  case 53 -> 42;
                  case 54 -> 39;
                  case 55 -> 51;
                  case 56 -> 1;
                  case 57 -> 34;
                  case 58 -> 45;
                  case 59 -> 25;
                  case 60 -> 11;
                  case 61 -> 38;
                  case 62 -> 44;
                  default -> 56;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\u0018 \u00039 \u000b\u0017`N2*\u0016\u0012=Et:\rU桟佸厑会桵桪伛佸桋桞@厰伛格伏厄桵桪伛佸伏";
         b[1] = "g' H^fS\u0004/\b\u0013mY\u0019*U\u0018+I\u0002m样伥収佩桺桒佳伥栔栭O厈佳桡佐号桺桒佳伥佐\u0007";
         b[2] = "9F&?Nn2I7p/`9B3*";
         b[3] = "TFI\u000bH%\tL\u0012d使伅佩叾可桽叡桁佩你,\u0004Y=[WQYSf";
         b[4] = " %p\n{e}/+e叒栁厃桇栌伸叒叛厃桇\u0015\u0005j}/4hX`&";
         b[5] = "\u0003\u0012pN\u0002S^\u0018+!厫叭伾厪佈核伵佳桺桰\u0015^YO\u0007\u0014,@\u000e\u0010";
         b[6] = "GF\u0013u\u000ed\u001aLH\u001a厧栀古栤厵叙伹叚古你vz\u001f|HW\u000b'\u0015'";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static String HE_SHU_YOU() {
         return "何大伟为什么要诈骗何炜霖";
      }
   }
}
