package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.树何何何友树树何友何;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import cn.cool.cherish.value.impl.树友何友何何友树树友;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 何友树树树友何友树何 implements 何树树友树树友友何何, 何树友 {
   private 何友树树树友何友树何.友树树友何何友树友友 友树友友友树树树树友;
   private static final float 何何友友树友树树何何 = 14.0F;
   private static final float 树友友友何何友何友友 = 60.0F;
   private static final float 何树友友树何何树树何 = 45.0F;
   private static final float 树友友树树树树树树友 = 8.0F;
   private static final float 友树何友友树何何何树 = 4.0F;
   private static final float 树友何友何树树友树友 = 4.0F;
   private static final float 何友树何何何树树何何 = 4.0F;
   private long 何树何何友何何何树何;
   private float 友树友友友友何何何友;
   private boolean 何友何何友树友何何何;
   private boolean 友树何友友树何何树何;
   private static final long a;
   private static final Object[] b = new Object[41];
   private static final String[] c = new String[41];
   private static String LIU_YA_FENG;

   public 何友树树树友何友树何() {
      long a = 何友树树树友何友树何.a ^ 109105446631706L;
      super();
      a<"µ">(this, a<"g">(-2431992330532742742L, a), -2436064202001354347L, a);
      a<"µ">(this, 0L, -2435362174093724625L, a);
      a<"µ">(this, 0.0F, -2436204791685325760L, a);
      a<"µ">(this, false, -2432422181213452246L, a);
      a<"µ">(this, false, -2436428060419938654L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(2306018753130035042L, -1961669962117205532L, MethodHandles.lookup().lookupClass()).a(110397341683074L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public void V() {
      long a = 何友树树树友何友树何.a ^ 73680763108819L;
      a<"µ">(this, a<"g">(6554694469986983267L, a), 6555126404155733340L, a);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private void x(GuiGraphics g, 树友何树何树何友友友 panel, 树友何友何何友树树友 setting, float x, float y, float width, float height, int alpha) {
      long a = 何友树树树友何友树何.a ^ 19130105640343L;
      a<"a">(-3261453277320597964L, a);
      何友树树树友何友树何.友友树友友何树友何友 hsb = new 何友树树树友何友树何.友友树友友何树友何友(setting.getValue());
      if (0.0F <= width) {
         float currentSaturation = 0.0F / width;
         Color topColorFullAlpha = Color.getHSBColor(a<"Û">(hsb, -3260923402700880793L, a), currentSaturation, 1.0F);
         Color bottomColorFullAlpha = a<"g">(-3264013707672155496L, a);
         Color topColorWithPickerAlpha = a<"Û">(panel, -3260758865737455451L, a).Z(topColorFullAlpha, alpha);
         Color bottomColorWithPickerAlpha = a<"Û">(panel, -3260758865737455451L, a).Z(bottomColorFullAlpha, alpha);
         g.fillGradient(
            (int)(x + 0.0F), (int)y, (int)(x + 0.0F + 1.0F), (int)(y + height), topColorWithPickerAlpha.getRGB(), bottomColorWithPickerAlpha.getRGB()
         );
      }

      float markX = x + a<"Û">(hsb, -3260626812717958616L, a) * width;
      float markY = y + (1.0F - a<"Û">(hsb, -3264318621623610831L, a)) * height;
      PoseStack var10000 = g.pose();
      float var10001 = markX - 2.0F;
      float var10002 = markY - 2.0F;
      int var10005 = a<"Û">(panel, -3260758865737455451L, a).Z(a<"g">(-3265015098681034757L, a), alpha).getRGB();
      Object[] var10008 = new Object[]{null, null, null, null, null, null, 1.0F};
      var10008[5] = var10005;
      var10008[4] = 4.0F;
      var10008[3] = 4.0F;
      var10008[2] = var10002;
      var10008[1] = var10001;
      var10008[0] = var10000;
      RenderUtils.O(var10008);
      var10000 = g.pose();
      var10001 = markX - 3.0F;
      var10002 = markY - 3.0F;
      var10005 = a<"Û">(panel, -3260758865737455451L, a).Z(a<"g">(-3264013707672155496L, a), alpha).getRGB();
      var10008 = new Object[]{null, null, null, null, null, null, 1.0F};
      var10008[5] = var10005;
      var10008[4] = 6.0F;
      var10008[3] = 6.0F;
      var10008[2] = var10002;
      var10008[1] = var10001;
      var10008[0] = var10000;
      RenderUtils.O(var10008);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何友树树树友何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 219 && var8 != 181 && var8 != 'g' && var8 != 210) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 221) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'a') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 219) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 181) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'g') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 4;
               case 2 -> 9;
               case 3 -> 3;
               case 4 -> 48;
               case 5 -> 20;
               case 6 -> 40;
               case 7 -> 44;
               case 8 -> 15;
               case 9 -> 51;
               case 10 -> 56;
               case 11 -> 61;
               case 12 -> 1;
               case 13 -> 49;
               case 14 -> 43;
               case 15 -> 14;
               case 16 -> 53;
               case 17 -> 38;
               case 18 -> 46;
               case 19 -> 29;
               case 20 -> 35;
               case 21 -> 6;
               case 22 -> 34;
               case 23 -> 12;
               case 24 -> 22;
               case 25 -> 36;
               case 26 -> 33;
               case 27 -> 30;
               case 28 -> 23;
               case 29 -> 47;
               case 30 -> 58;
               case 31 -> 37;
               case 32 -> 39;
               case 33 -> 7;
               case 34 -> 52;
               case 35 -> 55;
               case 36 -> 62;
               case 37 -> 25;
               case 38 -> 16;
               case 39 -> 42;
               case 40 -> 19;
               case 41 -> 13;
               case 42 -> 57;
               case 43 -> 11;
               case 44 -> 21;
               case 45 -> 2;
               case 46 -> 28;
               case 47 -> 45;
               case 48 -> 59;
               case 49 -> 8;
               case 50 -> 63;
               case 51 -> 26;
               case 52 -> 54;
               case 53 -> 27;
               case 54 -> 17;
               case 55 -> 41;
               case 56 -> 0;
               case 57 -> 24;
               case 58 -> 60;
               case 59 -> 31;
               case 60 -> 5;
               case 61 -> 10;
               case 62 -> 18;
               default -> 32;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "\u001d\u0011\u0005K<j\u0012QH@6w\u0017\fC\u0006&lP伪叠根桂栔厵伪叠根伆";
      b[1] = boolean.class;
      c[1] = "java/lang/Boolean";
      b[2] = "G\f)\u000f5=HLd\u0004? M\u0011oB7=@\u0017k\tt\u001fK\u0006r\u0000?";
      b[3] = "Fr#\u0005)\u0010I2n\u000e#\rLoeH3\u0016\u000b栍叆厭厍桮栴栍栜桷伓";
      b[4] = "=G\u000ex\u000b/2\u0007Cs\u000127ZH5\u0011)p核叫低伱压桏核栱栊伱";
      b[5] = int.class;
      c[5] = "java/lang/Integer";
      b[6] = void.class;
      c[6] = "java/lang/Void";
      b[7] = "\u0010iJuO\r\u001f)\u0007~E\u0010\u001at\f8U\u000b]栖厯佃栱伷桢佒厯叝叫";
      b[8] = float.class;
      c[8] = "java/lang/Float";
      b[9] = "\u000fg40 \u001d\u0000'y;*\u0000\u0005zr}:\u001bB参住伆桞厹伹作住伆桞";
      b[10] = "f;Q\u0014\u0005\u0006{.\t6D\u000bc(";
      b[11] = "&du\u001egp-kdQ\u001bi\"qj\u0012,Y4ff\u000f=u#k";
      b[12] = ":k%\u0005\u0002C5+h\u000e\b^0vcH\u0018Ew佐叀桷桼栽厒佐叀桷伸\b厒栔栚厭伸佹厒栔叀厭";
      b[13] = "PyppQ-_9={[0Zd6=K+\u001d佂厕栂栯桓司佂厕栂佫f司叜桏变叵众栢叜伋变";
      b[14] = long.class;
      c[14] = "java/lang/Long";
      b[15] = "C[K\u0005m{HTZJ\fuC_^\u0010";
      b[16] = "bb+`k@4#{}\u0012栰桋叛叔叁发佴厑栁叔\u0002\"Snznkt\u0012>g";
      b[17] = "Tx5v)\u0005\u001e?!k\u0013桳伳厇优及叐伷桷伙桜\t*\u0003Uu=t}\u000e\u0005#";
      b[18] = "%+\u001ey\n\u0011ws\u001dxq叢栍受传伜伬核栍栍传ALZv*@;N\u001a{\u007f";
      b[19] = "\u001e\u0011p\u0004W\f\u0001\u0002uf佡桩传伱叟伻佡伭桤伱\u001cWF\u001aE\tu\u0004_\fL";
      b[20] = "8|\u0010T\u001drayG\u000em叛叆栄根厬厮栁佘栄根oW$ub\u001a\u0000\u001dca\u007f";
      b[21] = "!v\u0003\r-\u001f>e\u0006o/cr:\u0004\u0017yRse\u0011\u001eFSs`\u0017PwR,u\u001eo";
      b[22] = "E\u001f\u001a<FN\u0017G\u0019==厽伩口厺栝栤厽厷口伤\u0004\u0000\u0005\u0016\u001eD~\u0002E\u001bK";
      b[23] = "zT\u0011ohN0\u0013\u0005rR叢厃厫厢位桋核桙桱桸\u0010mC:\u0004\u0004n2\u001f:\u000e";
      b[24] = "q>_QX\u001e'\u007f\u000fL!伪桘厇厠株核厴伜桝伾3\u0011\r}&\u001aZGL-;";
      b[25] = "@\u0001>dF\u001c_\u0012;\u0006叮桹叠县厑栟栴桹栺县R6W\\A\u0005;`\u0016\f\\";
      b[26] = "f^%R'14\u0000jLH\u0012]TeW'<0\u0004l\fs]";
      b[27] = "V)e}qw\u0004w*c\u001ezm#%xqz\u0000s,#%\u001b";
      b[28] = "}6aT#\u0010b%d6压桵佃厈収栯伕伱标伖\r\u000f!W/3pX,\u0007y";
      b[29] = "\u0010)\u000byg@\u0013=Iv\nm)v\u001c<;VT!\u0011lm.";
      b[30] = "\u0002\n\u007f]\u0012cPT0C}t9\u0000?X\u0012nTP6\u0003F\u000f\u0005\u0005\"HE`UI-\n}";
      b[31] = "$\u0010Tl\u0011\u0011;\u0003Q\u000e厹桴厄厮叻反伧估会厮83\u0001\u000fyPB1A\u0002,";
      b[32] = "\u0014\"\u0013W\u0015>^e\u0007J/伌叭叝伾叫栶伌样标伾(\u00112Pw\r\u0014RjH\u007f";
      b[33] = "J\u0005YoFW\u0015YYe#f/.r\u0003\u001cK\u000f\u000bF}C\u0017\u000f\u0001";
      b[34] = "\u0007gC\u0001\u0002CU?@\u0000y桪叵厛根叺伤桪佫伅口9D\bTf\u001dCFHY3";
      b[35] = "<>kctrj\u007f;~\r但佑伙伊参佐但栕厇桎\u0001=a0&.hk `;";
      b[36] = "a\t!U5'3Q\"TN栎厓叵厁桴厍佊桉叵厁muf;Y#\u0000%o`\r";
      b[37] = ",\u0019y\u001dh\b3\n|\u007f佞厷伒伹取桦叀伩伒伹\u0015FjO~\u001ch\u0011g\u001f(";
      b[38] = "8\fWzv{gPWp\u0013OC'fU\u0013:e\u0014Asme9\u0014K";
      b[39] = "J'i5gd\u001cf9(\u001e収伧伀伈厔佃栔伧厞厖W.wF?,>x6\u0016\"";
      b[40] = "}K\u0019\u001cuy\"\u0017\u0019\u0016\u0010X\u0002h?=\u00108 S\u000f\u0015ng|S\u0005";
   }

   @Override
   public 友树何树友友何树友友 o(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      long a = 何友树树树友何友树何.a ^ 124594673644240L;
      a<"a">(1584033078955764083L, a);
      a<"µ">(this, true, 1583582600306421096L, a);
      树友何友何何友树树友 cv = (树友何友何何友树树友)value;
      String valueName = a<"Û">(a<"Û">(panel, 1583038500966936546L, a), 1583368679911272684L, a) ? value.v() : value.W();
      float nameWidth = a<"Û">(a<"Û">(panel, 1583038500966936546L, a), 1582218498898672760L, a).A(valueName) + 2.0F;
      if (!(nameWidth > vw * 0.55F) && vw - nameWidth - 4.0F < vw * 0.25F) {
      }

      Objects.requireNonNull(a<"Û">(panel, 1583038500966936546L, a));
      float previewBoxClickY = vy + 12.8F + 8.0F - 7.0F;
      float previewBoxClickX = vx + vw - 14.0F - 2.0F;
      if (a<"Û">(panel, 1583038500966936546L, a).w(mx, my, previewBoxClickX, previewBoxClickY, 14.0F, 14.0F)) {
         a<"µ">(this, !a<"Û">(this, 1581993288177353696L, a), 1581993288177353696L, a);
         a<"µ">(this, System.currentTimeMillis(), 1583518205859119077L, a);
         if (!a<"Û">(this, 1581993288177353696L, a)) {
            a<"µ">(this, a<"g">(1582383832328295008L, a), 1583946459798649439L, a);
            a<"µ">(this, false, 1583582600306421096L, a);
         }

         return null;
      } else {
         boolean clickOnPickerComponent = false;
         if (a<"Û">(this, 1581993288177353696L, a) && a<"Û">(this, 1583805595169658762L, a) > 0.8F) {
            float pickerContentStartX = vx + (vw - 84.0F) / 2.0F;
            float pickerContentY = vy + 28.8F + 4.0F + 4.0F;
            float hueSliderClickX = pickerContentStartX + 60.0F + 4.0F;
            float alphaSliderClickX = hueSliderClickX + 8.0F + 4.0F;
            if (a<"Û">(panel, 1583038500966936546L, a).w(mx, my, pickerContentStartX, pickerContentY, 60.0F, 45.0F)) {
               a<"µ">(this, a<"g">(1582137499340606813L, a), 1583946459798649439L, a);
               this.O(cv, (int)mx, (int)my, pickerContentStartX, pickerContentY, 60.0F, 45.0F, hueSliderClickX, alphaSliderClickX, 8.0F);
               clickOnPickerComponent = true;
            }

            if (a<"Û">(panel, 1583038500966936546L, a).w(mx, my, hueSliderClickX, pickerContentY, 8.0F, 45.0F)) {
               a<"µ">(this, a<"g">(1583925285094720511L, a), 1583946459798649439L, a);
               this.O(cv, (int)mx, (int)my, pickerContentStartX, pickerContentY, 60.0F, 45.0F, hueSliderClickX, alphaSliderClickX, 8.0F);
               clickOnPickerComponent = true;
            }

            if (a<"Û">(panel, 1583038500966936546L, a).w(mx, my, alphaSliderClickX, pickerContentY, 8.0F, 45.0F)) {
               a<"µ">(this, a<"g">(1583312037911885617L, a), 1583946459798649439L, a);
               this.O(cv, (int)mx, (int)my, pickerContentStartX, pickerContentY, 60.0F, 45.0F, hueSliderClickX, alphaSliderClickX, 8.0F);
               clickOnPickerComponent = true;
            }

            float pickerBgX = pickerContentStartX - 4.0F;
            float pickerBgY = vy + 28.8F + 4.0F;
            if (!a<"Û">(panel, 1583038500966936546L, a).w(mx, my, pickerBgX, pickerBgY, 92.0F, 53.0F)) {
               a<"µ">(this, a<"g">(1582383832328295008L, a), 1583946459798649439L, a);
               a<"µ">(this, false, 1583582600306421096L, a);
            }

            if (clickOnPickerComponent) {
               return null;
            }
         }

         float pickerBgXx = vx + (vw - 84.0F) / 2.0F - 4.0F;
         float pickerBgYCheck = vy + 28.8F + 4.0F;
         boolean mouseOverTotalPickerBg = a<"Û">(this, 1581993288177353696L, a)
            && a<"Û">(this, 1583805595169658762L, a) > 0.8F
            && a<"Û">(panel, 1583038500966936546L, a).w(mx, my, pickerBgXx, pickerBgYCheck, 92.0F, 53.0F);
         if (!a<"Û">(panel, 1583038500966936546L, a).w(mx, my, previewBoxClickX, previewBoxClickY, 14.0F, 14.0F)
            && !clickOnPickerComponent
            && !mouseOverTotalPickerBg) {
            a<"µ">(this, false, 1583582600306421096L, a);
            a<"µ">(this, a<"g">(1582383832328295008L, a), 1583946459798649439L, a);
         }

         return null;
      }
   }

   @Override
   public float t(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value) {
      long a = 何友树树树友何友树何.a ^ 129500575327976L;
      a<"a">(127158540283022429L, a);
      String valueName = a<"Û">(a<"Û">(panel, 126120270958148570L, a), 126459205193180372L, a) ? value.v() : value.W();
      float nameWidth = a<"Û">(a<"Û">(panel, 126120270958148570L, a), 129812473348958272L, a).A(valueName);
      Objects.requireNonNull(a<"Û">(panel, 126120270958148570L, a));
      float availableWidthForControl = 106.0F - nameWidth - 4.0F;
      if (!(nameWidth > 58.300003F) && availableWidthForControl < 26.5F) {
      }

      float baseHeight = 28.8F;
      if (a<"Û">(this, 126886231237985202L, a) > 0.01F) {
         baseHeight = 28.8F + 57.0F * a<"Û">(this, 126886231237985202L, a);
      }

      return baseHeight;
   }

   private void v() {
      long a = 何友树树树友何友树何.a ^ 75002219973612L;
      a<"a">(-5996556142462000807L, a);
      long currentTime = System.currentTimeMillis();
      float deltaTime = a<"Û">(this, -5997110197108734247L, a) == 0L ? 0.0F : (float)(currentTime - a<"Û">(this, -5997110197108734247L, a));
      a<"µ">(this, currentTime, -5997110197108734247L, a);
      float targetAnimation = a<"Û">(this, -5996424276055180580L, a) ? 1.0F : 0.0F;
      if (Math.abs(a<"Û">(this, -5996829139779998026L, a) - targetAnimation) > 0.001F) {
         float diff = targetAnimation - a<"Û">(this, -5996829139779998026L, a);
         float interpolationFactor = deltaTime / 150.0F * 2.0F;
         if (interpolationFactor >= 1.0F) {
            a<"µ">(this, targetAnimation, -5996829139779998026L, a);
         }

         a<"µ">(this, a<"Û">(this, -5996829139779998026L, a) + diff * interpolationFactor, -5996829139779998026L, a);
         a<"µ">(this, Mth.clamp(a<"Û">(this, -5996829139779998026L, a), 0.0F, 1.0F), -5996829139779998026L, a);
      }

      a<"µ">(this, targetAnimation, -5996829139779998026L, a);
   }

   @Override
   public void v(GuiGraphics g, 树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      long a = 何友树树树友何友树何.a ^ 60721310520466L;
      int var10000 = a<"a">(-5496120141235630287L, a);
      this.v();
      int ax = var10000;
      树友何友何何友树树友 cv = (树友何友何何友树树友)value;
      String name = a<"Û">(a<"Û">(panel, -5495988819461076576L, a), -5495791204904692050L, a) ? value.v() : value.W();
      float nameWidth = a<"Û">(a<"Û">(panel, -5495988819461076576L, a), -5496804699567842758L, a).A(name) + 2.0F;
      float currentSettingY = valy;
      a<"Û">(a<"Û">(panel, -5495988819461076576L, a), -5496804699567842758L, a)
         .m(
            g.pose(),
            name,
            valx + 2.0F,
            valy + 8.0F - a<"Û">(a<"Û">(panel, -5495988819461076576L, a), -5496804699567842758L, a).K() / 2.0F,
            a<"Û">(panel, -5495988819461076576L, a).Z(a<"Û">(a<"Û">(panel, -5495988819461076576L, a), -5495891127012887955L, a), alpha).getRGB()
         );
      if (nameWidth > valw * 0.55F || valw - nameWidth - 4.0F < valw * 0.25F) {
         currentSettingY = valy + 12.8F;
      }

      float previewBoxX = valx + valw - 14.0F - 2.0F;
      float previewBoxY = currentSettingY + 8.0F - 7.0F;
      RenderUtils.drawRectangle(g.pose(), previewBoxX, previewBoxY, 14.0F, 14.0F, a<"Û">(panel, -5495988819461076576L, a).Z(cv.getValue(), alpha).getRGB());
      PoseStack var30 = g.pose();
      int var10005 = a<"Û">(panel, -5495988819461076576L, a).Z(a<"g">(-5496881163075523816L, a), alpha).getRGB();
      Object[] var10008 = new Object[]{null, null, null, null, null, null, 1.0F};
      var10008[5] = var10005;
      var10008[4] = 14.0F;
      var10008[3] = 14.0F;
      var10008[2] = previewBoxY;
      var10008[1] = previewBoxX;
      var10008[0] = var30;
      RenderUtils.O(var10008);
      currentSettingY += 16.0F;
      if (a<"Û">(this, -5496493104695692856L, a) > 0.01F) {
         float pickerContentStartX = valx + (valw - 84.0F) / 2.0F;
         float pickerVisualY = currentSettingY + 4.0F + 4.0F;
         float pickerBgY = currentSettingY + 4.0F;
         float animatedPickerBgHeight = 53.0F * a<"Û">(this, -5496493104695692856L, a);
         RenderUtils.drawRectangle(
            g.pose(),
            pickerContentStartX - 4.0F,
            pickerBgY,
            92.0F,
            animatedPickerBgHeight,
            a<"Û">(panel, -5495988819461076576L, a).Z(new Color(30, 30, 30, 220), alpha).getRGB()
         );
         if (a<"Û">(this, -5496493104695692856L, a) > 0.8F) {
            int pickerAlpha = (int)(alpha * ((a<"Û">(this, -5496493104695692856L, a) - 0.8F) / 0.2F));
            this.x(g, panel, cv, pickerContentStartX, pickerVisualY, 60.0F, 45.0F, pickerAlpha);
            float hueSliderX = pickerContentStartX + 60.0F + 4.0F;
            this.R(g, panel, cv, hueSliderX, pickerVisualY, 8.0F, 45.0F, pickerAlpha);
            float alphaSliderX = hueSliderX + 8.0F + 4.0F;
            this.H(g, panel, cv, alphaSliderX, pickerVisualY, 8.0F, 45.0F, pickerAlpha);
            if (a<"Û">(this, -5496566840452232406L, a) && a<"Û">(this, -5496352520035984355L, a) != a<"g">(-5496775430258527198L, a)) {
               this.O(cv, mousex, mousey, pickerContentStartX, pickerVisualY, 60.0F, 45.0F, hueSliderX, alphaSliderX, 8.0F);
            }
         }
      }

      if (a<"a">(-5496574773314470788L, a)) {
         a<"a">(++ax, -5496417541896625525L, a);
      }
   }

   private void H(GuiGraphics g, 树友何树何树何友友友 panel, 树友何友何何友树树友 setting, float x, float y, float width, float height, int alpha) {
      long a = 何友树树树友何友树何.a ^ 73912918706906L;
      何友树树树友何友树何.友友树友友何树友何友 hsb = new 何友树树树友何友树何.友友树友友何树友何友(setting.getValue());
      a<"a">(-1301065470461308551L, a);
      Color baseColor = Color.getHSBColor(a<"Û">(hsb, -1300540638199760086L, a), a<"Û">(hsb, -1300766857406331547L, a), a<"Û">(hsb, -1297144594641998468L, a));
      int i = 0;
      if (0.0F <= height) {
         int j = 0;
         RenderUtils.drawRectangle(
            g.pose(),
            x + 0.0F,
            y + 0.0F,
            Math.min(4.0F, width - 0.0F),
            Math.min(4.0F, height - 0.0F),
            a<"Û">(panel, -1300934146261624856L, a).Z(new Color(120, 120, 120), alpha).getRGB()
         );
         j += 4;
         i += 4;
      }

      i = 0;
      if (0.0F <= height) {
         Color segmentColor = new Color(
            baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), Mth.clamp((int)((1.0F - 0.0F / height) * 255.0F), 0, 255)
         );
         RenderUtils.drawRectangle(g.pose(), x, y + 0.0F, width, 1.0F, a<"Û">(panel, -1300934146261624856L, a).Z(segmentColor, alpha).getRGB());
         i++;
      }

      float indicatorY = y + (1.0F - a<"Û">(hsb, -1297537383561492518L, a) / 255.0F) * height;
      RenderUtils.drawRectangle(
         g.pose(), x - 1.0F, indicatorY - 0.5F, width + 2.0F, 1.0F, a<"Û">(panel, -1300934146261624856L, a).Z(a<"g">(-1297876383842613066L, a), alpha).getRGB()
      );
   }

   private void R(GuiGraphics g, 树友何树何树何友友友 panel, 树友何友何何友树树友 setting, float x, float y, float width, float height, int alpha) {
      long a = 何友树树树友何友树何.a ^ 126952619328432L;
      a<"a">(2637877474811467795L, a);
      何友树树树友何友树何.友友树友友何树友何友 hsb = new 何友树树树友何友树何.友友树友友何树友何友(setting.getValue());
      int i = 0;
      if (0.0F <= height) {
         float hue = 0.0F / height;
         Color segmentColor = Color.getHSBColor(hue, 1.0F, 1.0F);
         RenderUtils.drawRectangle(g.pose(), x, y + 0.0F, 8.0F, 1.0F, a<"Û">(panel, 2636882896822115970L, a).Z(segmentColor, alpha).getRGB());
         i++;
      }

      float indicatorY = y + a<"Û">(hsb, 2637347282598523456L, a) * height;
      RenderUtils.drawRectangle(
         g.pose(), x - 1.0F, indicatorY - 0.5F, width + 2.0F, 1.0F, a<"Û">(panel, 2636882896822115970L, a).Z(a<"g">(2636633287597326812L, a), alpha).getRGB()
      );
   }

   private void O(
      树友何友何何友树树友 setting,
      int mousex,
      int mousey,
      float svboxx,
      float svboxy,
      float svboxwidth,
      float svboxheight,
      float huesliderx,
      float alphasliderx,
      float slidercommonwidth
   ) {
      long a = 何友树树树友何友树何.a ^ 18671773685859L;
      a<"a">(9171764500771140310L, a);
      何友树树树友何友树何.友友树友友何树友何友 hsb = new 何友树树树友何友树何.友友树友友何树友何友(setting.getValue());
      if (a<"Û">(this, 9171632608478122220L, a) == a<"g">(9171439931488659438L, a)) {
         float newSaturation = Mth.clamp((mousex - svboxx) / svboxwidth, 0.0F, 1.0F);
         float newBrightness = 1.0F - Mth.clamp((mousey - svboxy) / svboxheight, 0.0F, 1.0F);
         a<"µ">(hsb, newSaturation, 9172685294741379036L, a);
         a<"µ">(hsb, newBrightness, 9171244325658968005L, a);
      }

      if (a<"Û">(this, 9171632608478122220L, a) == a<"g">(9171679655334766924L, a)) {
         a<"µ">(hsb, svboxheight == 0.0F ? 0.0F : Mth.clamp((mousey - svboxy) / svboxheight, 0.0F, 1.0F), 9172388698184427923L, a);
      }

      if (a<"Û">(this, 9171632608478122220L, a) == a<"g">(9172262625263033730L, a)) {
         a<"µ">(
            hsb,
            svboxheight == 0.0F ? 0 : Mth.clamp((int)((1.0F - Mth.clamp((mousey - svboxy) / svboxheight, 0.0F, 1.0F)) * 255.0F), 0, 255),
            9171417216547329379L,
            a
         );
      }

      setting.g(hsb.H());
   }

   private static String HE_WEI_LIN() {
      return "何炜霖国企变私企";
   }

   private static class 友友树友友何树友何友 implements 何树友 {
      public float 友树友何何何树树树何;
      public float 友何友友树树友友友何;
      public float 树友友树友何树何何友;
      public int 树友友友树友何树友友;
      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static String HE_SHU_YOU;

      public 友友树友友何树友何友(Color color) {
         long a = 何友树树树友何友树何.友友树友友何树友何友.a ^ 74578896129499L;
         super();
         float[] hsbValues = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
         a<"n">(this, hsbValues[0], -6532556890081714124L, a);
         a<"n">(this, hsbValues[1], -6532731071259140326L, a);
         a<"n">(this, hsbValues[2], -6532513841239757274L, a);
         a<"n">(this, color.getAlpha(), -6532627361716640534L, a);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-6891945274463335141L, 8496674167630602275L, MethodHandles.lookup().lookupClass()).a(280086430835813L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 229 && var8 != 'n' && var8 != 'X' && var8 != 'L') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'M') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 250) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 229) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'n') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'X') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/何友树树树友何友树何$友友树友友何树友何友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 9;
                  case 1 -> 29;
                  case 2 -> 61;
                  case 3 -> 34;
                  case 4 -> 60;
                  case 5 -> 63;
                  case 6 -> 28;
                  case 7 -> 37;
                  case 8 -> 39;
                  case 9 -> 58;
                  case 10 -> 57;
                  case 11 -> 56;
                  case 12 -> 46;
                  case 13 -> 35;
                  case 14 -> 19;
                  case 15 -> 1;
                  case 16 -> 21;
                  case 17 -> 15;
                  case 18 -> 26;
                  case 19 -> 51;
                  case 20 -> 49;
                  case 21 -> 42;
                  case 22 -> 12;
                  case 23 -> 4;
                  case 24 -> 2;
                  case 25 -> 54;
                  case 26 -> 47;
                  case 27 -> 14;
                  case 28 -> 22;
                  case 29 -> 50;
                  case 30 -> 27;
                  case 31 -> 8;
                  case 32 -> 11;
                  case 33 -> 24;
                  case 34 -> 17;
                  case 35 -> 44;
                  case 36 -> 3;
                  case 37 -> 55;
                  case 38 -> 59;
                  case 39 -> 23;
                  case 40 -> 30;
                  case 41 -> 41;
                  case 42 -> 31;
                  case 43 -> 45;
                  case 44 -> 5;
                  case 45 -> 10;
                  case 46 -> 43;
                  case 47 -> 25;
                  case 48 -> 38;
                  case 49 -> 16;
                  case 50 -> 53;
                  case 51 -> 13;
                  case 52 -> 6;
                  case 53 -> 40;
                  case 54 -> 0;
                  case 55 -> 7;
                  case 56 -> 62;
                  case 57 -> 48;
                  case 58 -> 20;
                  case 59 -> 52;
                  case 60 -> 33;
                  case 61 -> 18;
                  case 62 -> 36;
                  default -> 32;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "e \n6Pvj`G=Zko=L{Jp(伛可桄栮栈反伛可桄佪=反厅栵厞叴佌栗厅佱厞";
         b[1] = float.class;
         c[1] = "java/lang/Float";
         b[2] = int.class;
         c[2] = "java/lang/Integer";
         b[3] = "R\rKW\tvY\u0002Z\u0018hxR\t^B";
         b[4] = "\\\u001bt\u0013*FPFc+历佰厯厽栝栲历叮厯伣\u0004[!P\\\u001ck\u00169\u0012";
         b[5] = "\u0010YjD\tD\u001c\u0004}|桿召口叿栃县伻栶口叿\u001aE\u001d]OQe\u0007V^\u0019";
         b[6] = "\u000bS:;\u00184\u0007\u000e-\u0003厴框司佫众佞桮框栢佫Js\u0013\"\u000bT%>\u000b`";
         b[7] = "y\u000b\bye?uV\u001fA栓厗厊桷去伜栓伉伔厭x1n)y\f\u0017|vk";
      }

      public Color H() {
         long a = 何友树树树友何友树何.友友树友友何树友何友.a ^ 44563948205963L;
         int rgb = Color.HSBtoRGB(a<"å">(this, 6847680683334687332L, a), a<"å">(this, 6847574663093085514L, a), a<"å">(this, 6847637566808986742L, a));
         return new Color(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, a<"å">(this, 6847469611373305530L, a));
      }

      private static String LIU_YA_FENG() {
         return "何树友被何大伟克制了";
      }
   }

   private static enum 友树树友何何友树友友 implements  {
      何何何何友何何树友树,
      友何何何友何树何友友,
      何树友友树树友何树何,
      何何何何树友树何友树,
      树树友友友友何友树友;

      private static final long a;
      private static final Object[] b = new Object[9];
      private static final String[] c = new String[9];
      private static String LIU_YA_FENG;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-8326774911814066708L, 6404822979953770060L, MethodHandles.lookup().lookupClass()).a(160454086294972L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 17246198752027L;
         a();
         Cipher var1;
         Cipher var13 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[5];
         int var6 = 0;
         String var5 = "ÿ\u009b\u0085ÑMt1¹\u0010õ¢\u001cÏ\u0005oò]0¥\u0010\u0018û®Æ\u0087\bå/R\u0094W±?c";
         byte var7 = 34;
         char var4 = '\b';
         int var12 = -1;

         label28:
         while (true) {
            String var14 = var5.substring(++var12, var12 + var4);
            byte var10001 = -1;

            while (true) {
               String var20 = a(var1.doFinal(var14.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var20;
                     if ((var12 += var4) >= var7) {
                        何何何何友何何树友树 = new 何友树树树友何友树何.友树树友何何友树友友();
                        友何何何友何树何友友 = new 何友树树树友何友树何.友树树友何何友树友友();
                        何树友友树树友何树何 = new 何友树树树友何友树何.友树树友何何友树友友();
                        何何何何树友树何友树 = new 何友树树树友何友树何.友树树友何何友树友友();
                        树树友友友友何友树友 = new 何友树树树友何友树何.友树树友何何友树友友();
                        return;
                     }

                     var4 = var5.charAt(var12);
                     break;
                  default:
                     var0[var6++] = var20;
                     if ((var12 += var4) < var7) {
                        var4 = var5.charAt(var12);
                        continue label28;
                     }

                     var5 = "}7¶\u0095\u0015ãPe\u0010\u0006\u0017¹â+yWDÕ>\u0084PV\u0080\u0080Â";
                     var7 = 25;
                     var4 = '\b';
                     var12 = -1;
               }

               var14 = var5.substring(++var12, var12 + var4);
               var10001 = 0;
            }
         }
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 186 && var8 != 'w' && var8 != 206 && var8 != 200) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 231) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 202) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 186) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'w') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 206) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/何友树树树友何友树何$友树树友何何友树友友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 51;
                  case 1 -> 46;
                  case 2 -> 45;
                  case 3 -> 11;
                  case 4 -> 5;
                  case 5 -> 27;
                  case 6 -> 4;
                  case 7 -> 58;
                  case 8 -> 9;
                  case 9 -> 29;
                  case 10 -> 1;
                  case 11 -> 40;
                  case 12 -> 62;
                  case 13 -> 44;
                  case 14 -> 10;
                  case 15 -> 35;
                  case 16 -> 52;
                  case 17 -> 32;
                  case 18 -> 61;
                  case 19 -> 55;
                  case 20 -> 57;
                  case 21 -> 60;
                  case 22 -> 50;
                  case 23 -> 7;
                  case 24 -> 19;
                  case 25 -> 25;
                  case 26 -> 34;
                  case 27 -> 13;
                  case 28 -> 20;
                  case 29 -> 53;
                  case 30 -> 47;
                  case 31 -> 23;
                  case 32 -> 48;
                  case 33 -> 36;
                  case 34 -> 22;
                  case 35 -> 21;
                  case 36 -> 24;
                  case 37 -> 6;
                  case 38 -> 43;
                  case 39 -> 18;
                  case 40 -> 30;
                  case 41 -> 38;
                  case 42 -> 49;
                  case 43 -> 16;
                  case 44 -> 37;
                  case 45 -> 14;
                  case 46 -> 56;
                  case 47 -> 31;
                  case 48 -> 39;
                  case 49 -> 54;
                  case 50 -> 12;
                  case 51 -> 41;
                  case 52 -> 33;
                  case 53 -> 3;
                  case 54 -> 0;
                  case 55 -> 2;
                  case 56 -> 8;
                  case 57 -> 28;
                  case 58 -> 59;
                  case 59 -> 26;
                  case 60 -> 17;
                  case 61 -> 15;
                  case 62 -> 63;
                  default -> 42;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "Y\\M#]dV\u001c\u0000(WySA\u000bnGb\u0014佧厨桑栣栚叱佧厨桑佧/叱栣桲压佧佞叱栣厨压";
         b[1] = "\u0016{bL;p\"Xm\fv{(EhQ}=8^/佷叞栂桜栦及佷叞栂优\u0013及栳栄变优佢及栳叞变v";
         b[2] = "\u0016\u001eQ6\u0000\u000f\u001d\u0011@ya\u0001\u0016\u001aD#";
         b[3] = "C\u0013Ik\u0005y\u0019\u0018\u0012\u0006桤栜叫去厱叅传叆栱去rm\u0016>E\u0000\u000e7\u001de";
         b[4] = "0Z0FEHjQk+你佩伆佬又佶你栭厘栨\u000b@V\u000f6Iw\u001a]T";
         b[5] = "B9>T\u0010~\u00182e9伵佟佴伏栜叺桱佟只桋\u0005R\u00039D*y\b\bb";
         b[6] = "\u000f\u000bhD\u0005HU\u00003)厾佩伹伽厐佴桤佩厧厣SB\u0016\u000f\t\u0018/\u0018\u001dT";
         b[7] = "t\u0003f\u0011\bF.\b=|伭叹佂桱桄伡伭栣栆伵]E\u001cXo\u000b,E\u000e\u0004n";
         b[8] = "&\u0019zX\u0015[|\u0012!5估栾厎厱桘栬厮佺桔伯A^\u0006\u001c \n=\u0004\rG";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      public static 何友树树树友何友树何.友树树友何何友树友友[] q() {
         long var0 = a ^ 106121348148042L;
         return (何友树树树友何友树何.友树树友何何友树友友[])a<"Î">(7776308173399037534L, var0).clone();
      }

      public static 何友树树树友何友树何.友树树友何何友树友友 y(String name) {
         return Enum.valueOf(何友树树树友何友树何.友树树友何何友树友友.class, name);
      }

      private static String HE_SHU_YOU() {
         return "何建国230622195906030014";
      }
   }
}
