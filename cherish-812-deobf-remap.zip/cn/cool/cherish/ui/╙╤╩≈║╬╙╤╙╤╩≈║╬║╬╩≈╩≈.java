package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.module.impl.display.友何何何何友何友友树;
import cn.cool.cherish.utils.animations.何友友何何友何友友何;
import cn.cool.cherish.utils.animations.友何树友树何何友树树;
import cn.cool.cherish.utils.animations.树友树何树树何树树何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectUtil;

public class 友树何友友树何何树树 implements IWrapper, 何树友 {
   private static final Map<MobEffect, 树友树何树树何树树何> 何何友何何友友友树友;
   private static final Map<MobEffect, 何友友何何友何友友何> 树树友何树何友树友友;
   private static final Map<MobEffect, MobEffectInstance> 何树何树友树何树何树;
   private static String[] 友何何友友友树何何友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[24];
   private static final String[] g = new String[24];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6918027420327355576L, 3841289911520187981L, MethodHandles.lookup().lookupClass()).a(252381675063236L);
      // $VF: monitorexit
      a = var10000;
      a();
      y(null);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(23060892808011L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[8];
      int var5 = 0;
      String var4 = "uL\u0004F\"\u0001\u0089,ûúÅ\u0092\u0093\u0098H»\u0018Ù0¶Á(\t¹ø\u000e\u000f\u0019G\u0006\u0019\u009aëgõæäsw.§\u0010ÛFZ;tx¬=\"\u0001\u00986mijk\u0010ê»²\u0004\u008fy[L\nL®Y|qÐb\u0010\\ð=-\b>w\u0089nM·\u001c\u0002#ù1\u0010«/ÿ#×GÄ\u001b\u008eºÖ.è\u0002H£";
      byte var6 = 109;
      char var3 = 16;
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[8];
                     何何友何何友友友树友 = new HashMap<>();
                     树树友何树何友树友友 = new HashMap<>();
                     何树何树友树何树何树 = new HashMap<>();
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "\u0090â*?3yþÓy\u0098ª\u0085BPÞf\u0010\u0094\u0087ß]Ò\u0019¼Üñ\u008dzÝPvÃ\u0098";
                  var6 = 33;
                  var3 = 16;
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   private static String B(int num) {
      z();
      if (num <= 0) {
         return "";
      } else {
         int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
         String[] symbols = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
         StringBuilder sb = new StringBuilder();
         int i = 0;
         if (0 < values.length && num > 0) {
            if (values[0] <= num) {
               int var10000 = num - values[0];
               sb.append(symbols[0]);
            }

            i++;
         }

         return sb.toString();
      }
   }

   public static void I(PoseStack poseStack, List<MobEffectInstance> effects, float x, float y, 友何何何何友何友友树 module) {
      z();
      if (mc.player != null) {
         X(effects);
         Cherish.instance.t().H(18);
         Cherish.instance.t().H(24);
         new GuiGraphics(mc, mc.renderBuffers().bufferSource());

         for (MobEffect effectKey : new HashMap<>(何何友何何友友友树友).keySet()) {
            MobEffectInstance var10000 = 何树何树友树何树何树.get(effectKey);
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 49;
               case 1 -> 0;
               case 2 -> 53;
               case 3 -> 19;
               case 4 -> 8;
               case 5 -> 4;
               case 6 -> 57;
               case 7 -> 21;
               case 8 -> 34;
               case 9 -> 30;
               case 10 -> 32;
               case 11 -> 26;
               case 12 -> 56;
               case 13 -> 38;
               case 14 -> 14;
               case 15 -> 24;
               case 16 -> 55;
               case 17 -> 13;
               case 18 -> 2;
               case 19 -> 25;
               case 20 -> 20;
               case 21 -> 15;
               case 22 -> 40;
               case 23 -> 48;
               case 24 -> 17;
               case 25 -> 12;
               case 26 -> 45;
               case 27 -> 52;
               case 28 -> 9;
               case 29 -> 28;
               case 30 -> 46;
               case 31 -> 61;
               case 32 -> 5;
               case 33 -> 60;
               case 34 -> 54;
               case 35 -> 11;
               case 36 -> 47;
               case 37 -> 39;
               case 38 -> 43;
               case 39 -> 27;
               case 40 -> 22;
               case 41 -> 63;
               case 42 -> 18;
               case 43 -> 42;
               case 44 -> 44;
               case 45 -> 6;
               case 46 -> 41;
               case 47 -> 62;
               case 48 -> 37;
               case 49 -> 1;
               case 50 -> 7;
               case 51 -> 50;
               case 52 -> 51;
               case 53 -> 59;
               case 54 -> 10;
               case 55 -> 16;
               case 56 -> 31;
               case 57 -> 35;
               case 58 -> 23;
               case 59 -> 58;
               case 60 -> 33;
               case 61 -> 3;
               case 62 -> 36;
               default -> 29;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String i(MobEffectInstance potionEffect) {
      return potionEffect.getEffect().getDisplayName().getString() + " " + B(potionEffect.getAmplifier() + 1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树何友友树何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 181 && var8 != 'N' && var8 != 223 && var8 != 206) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 220) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 221) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 181) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'N') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "v\u0010ZAahyP\u0017Jku|\r\u001c\fchq\u000b\u0018G nx\u000e\u0018\fjnf\u000e\u0018Cw)叞伫伡佷佛双佀厵县栳";
      f[1] = "<g\u0015?\u000et\"o\u000fpm`&";
      f[2] = "yT=\"g\u0000v\u0014p)m\u001dsI{o}\u00064叱栂伔參厤栋佯但桐栙";
      f[3] = "roqF\u0006ey``\tz|vznJML`mbW\\`w`";
      f[4] = "\u001aCX{v\u0015\u0015\u0003\u0015p|\b\u0010^\u001e6o\u001b\u0015X\u00136p\u0017\tAXUv\u001e\u001c{\u0017tl\u001f";
      f[5] = "7X\u0017'Mn8\u0018Z,Gs=EQjT`8C\\jKl$Z\u0017\u0006Mn8SX*t`8C\\";
      f[6] = ".n@`K\u00173{\u0018B\n\u001a+}";
      f[7] = "\u0012W\u000b h,gw\u0000/yc\u001ao\u0013(p*r";
      f[8] = "Hp\u0017\u0005|\u0002G0Z\u000ev\u001fBmQHf\u0019BrJHr\u0003BsX\u0012z\u0002Em\u0017厭但桼叠栏佬伳变桼栺";
      f[9] = "\u0004ET'bJqe_(s\u0005\f}L/zLd";
      f[10] = void.class;
      g[10] = "java/lang/Void";
      f[11] = "u<zA%i~3k\u000eDgu8oT";
      f[12] = "~\u001f\u001d\".5s^g叐厉厊栚桻桾低厉桐佞b\\yqwq\u000e\u0019r)s";
      f[13] = "\u001ea.YkY\u0011!e\u0007\u001b栲根厜栍叿但栲口伂佉<%\u0015\u001a:dN*UQd";
      f[14] = "Lg\"vI0A&X会佰休佬叙厛厄叮厏史\u001a(6\\vJc7\u007fB";
      f[15] = "\u001f\u0010$$ogC\nl=\tr&Rz8t?I\t#\"c\u0003\u0019\u0003r!w`O\u0000q\u007f\t";
      f[16] = "1I\u0017~\n\b<\bm桖伳桭厏栭估桖厭伩厏4V?\u001cOtXP7T\b";
      f[17] = "v\u001561e_&\u000f:)\u000e>\n/\u0016\u001e\u000e]1\u0012(80\r+\u001e0";
      f[18] = "{Fq3O3'\\9*)伊伟叹伔伎只厔厁栣厊SY&3\u00002*Fo-";
      f[19] = "<!\u0006&2?3aMxB桔栛佂栥伞桛伐佟叜叿C|s8zL1s3s$";
      f[20] = ";\u0003\u0006 \u0001Sg\u0019N9gE\u0002AX<\u001a\u000bm\u001a\u0001&\r7";
      f[21] = "\u0000m.LE-\\wfU#桐栠叒佋栵佾厊栠叒叕,S8H+mULqV";
      f[22] = "O\u000fE}&\b\u0013\u0015\rd@\u0005vIF~=VK\u000bG{!lLH\u001e`zQ\u000eI\u001b|@";
      f[23] = "\u000e\u0000\u0005Yu\u0010R\u001aM@\u0013伩栮伡栤叺栊伩栮伡栤9c\u0005FFF@|LX";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8904;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友树何友友树何何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树何友友树何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static String[] z() {
      return 友何何友友友树何何友;
   }

   public static void y(String[] var0) {
      友何何友友友树何何友 = var0;
   }

   private static void X(List<MobEffectInstance> currentEffects) {
      Set activeEffectsSet = currentEffects.stream().map(MobEffectInstance::getEffect).collect(Collectors.toSet());
      z();
      Iterator var7 = currentEffects.iterator();
      if (var7.hasNext()) {
         MobEffectInstance instance = (MobEffectInstance)var7.next();
         MobEffect effect = instance.getEffect();
         何树何树友树何树何树.put(effect, instance);
         何何友何何友友友树友.computeIfAbsent(effect, k -> new 树友树何树树何树树何(37618987749219L, 300, 1.0, 1.8F));
         树树友何树何友树友友.computeIfAbsent(effect, k -> new 何友友何何友何友友何(300, 16923, 1.0, 47854, '溑'));
      }

      var7 = 何何友何何友友友树友.entrySet().iterator();
      if (var7.hasNext()) {
         Entry<MobEffect, 树友树何树树何树树何> entry = (Entry<MobEffect, 树友树何树树何树树何>)var7.next();
         entry.getValue().n(new Object[]{activeEffectsSet.contains(entry.getKey()) ? 友何树友树何何友树树.树树何树何树何何友友 : 友何树友树何何友树树.树树友树友何树友何何, 59020024422499L});
      }

      何何友何何友友友树友.entrySet()
         .removeIf(
            entryx -> {
               z();
               boolean finished = ((树友树何树树何树树何)entryx.getValue()).m(new Object[]{49524715818202L}) == 友何树友树何何友树树.树树友树友何树友何何
                  && ((树友树何树树何树树何)entryx.getValue()).U(new Object[]{108461126752643L});
               if (finished) {
                  MobEffect key = (MobEffect)entryx.getKey();
                  树树友何树何友树友友.remove(key);
                  何树何树友树何树何树.remove(key);
               }

               return finished;
            }
         );
   }

   private static String LIU_YA_FENG() {
      return "我是何树友";
   }

   private static void G(
      PoseStack poseStack, GuiGraphics guiGraphics, MobEffectInstance effect, float x, float y, 友何何何何友何友友树 module, 何何友友树何树何友树 font18, 何何友友树何树何友树 font24
   ) {
      z();
      String name = i(effect);
      String time = effect.getDuration() == -1 ? "∞" : MobEffectUtil.formatDuration(effect, 1.0F).getString();
      int maxDuration = 友何何何何友何友友树.何何何何友友友友友友.getOrDefault(effect.getEffect(), Math.max(effect.getDuration(), 1));
      if (maxDuration <= 0) {
         maxDuration = 1;
      }

      float progress = effect.getDuration() == -1 ? 1.0F : Math.min(1.0F, (float)effect.getDuration() / maxDuration);
      何友友何何友何友友何 progressAnim = 树树友何树何友树友友.get(effect.getEffect());
      if (progressAnim != null) {
         double var10001 = progress;
         Object[] var10004 = new Object[]{null, 26371741931631L};
         var10004[0] = var10001;
         progressAnim.p(var10004);
      }

      float animProgress = progressAnim != null ? (float)progressAnim.D(new Object[]{124111691745592L}) : progress;
      double slideIn = 何何友何何友友友树友.get(effect.getEffect()).D(new Object[]{124111691745592L});
      float textWidth = font18.D(name);
      float width = textWidth + 50.0F;
      float finalX = x - (width + 5.0F) * (1.0F - (float)slideIn);
      何何友友树何树何友树 font16 = Cherish.instance.t().H(16);
      poseStack.pushPose();
      Color a = module.友友友树树树何友树何.K("New") ? new Color(0, 0, 0, 80) : new Color(40, 40, 40, 180);
      ShaderUtils.o(poseStack, 100739365455537L, finalX, y, width, 32.0F, 6.0F, a);
      poseStack.pushPose();
      RenderUtils.B((int)finalX, (int)y, (int)(width * animProgress), 32);
      a = module.友友友树树树何友树何.K("New") ? new Color(0, 0, 0, 120) : new Color(70, 70, 70, 200);
      ShaderUtils.o(poseStack, 100739365455537L, finalX, y, width, 32.0F, 6.0F, a);
      RenderUtils.h(new Object[0]);
      poseStack.popPose();
      TextureAtlasSprite texture = mc.getMobEffectTextures().get(effect.getEffect());
      RenderSystem.setShaderTexture(0, texture.atlasLocation());
      guiGraphics.blit((int)finalX + 7, (int)y + 8, 0, 18, 18, texture);
      int textX = (int)finalX + 30;
      font18.Q(poseStack, name, textX, y + 7.0F, HUD.instance.getColor(1).getRGB(), module.树何树友树何树友何友.getValue(), 0.5);
      if ("∞".equals(time)) {
         font24.Q(poseStack, time, textX - 1, y + font18.x() + 9.0F, Color.WHITE.getRGB(), module.树何树友树何树友何友.getValue(), 0.5);
      }

      font16.Q(poseStack, time, textX, y + font18.x() + 11.0F, Color.WHITE.getRGB(), module.树何树友树何树友何友.getValue(), 0.5);
      int barX = (int)(finalX + width - 9.0F);
      Color barColor = effect.getDuration() == -1 ? new Color(255, 217, 0, 230) : HUD.instance.getColor(1);
      ShaderUtils.o(poseStack, 100739365455537L, barX, y + font18.x() - 3.0F, 4.0F, 22.5F, 2.0F, barColor);
      poseStack.popPose();
   }
}
