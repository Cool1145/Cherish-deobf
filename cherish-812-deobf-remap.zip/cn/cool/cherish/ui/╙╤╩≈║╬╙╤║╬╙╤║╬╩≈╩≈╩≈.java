package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.何树树何友友何何树友;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友树何友何友何树树树 implements 何树友 {
   private final 树友友友何树友友树树 友树树树何友树何树何;
   private final List<何何友友树何树何友树> 何何友友树树何友友友;
   private final ConcurrentHashMap<String, 何何友友树何树何友树> 友树友友树何友友何何 = new ConcurrentHashMap<>();
   private final ConcurrentHashMap<String, Font> 树何树树何树何树何树 = new ConcurrentHashMap<>();
   private static final String 何何友友友友友树何树;
   private static final String 树友树友友友友树树何;
   private static boolean 友何树友树树何何友友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[22];
   private static final String[] f = new String[22];
   private static int _何大伟：我要教育何炜霖 _;

   public 友树何友何友何树树树() {
      this.何何友友树树何友友友 = new ArrayList<>();
      this.友树树树何友树何树何 = new 树友友友何树友友树树();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-342468128322666854L, -2603482761355351472L, MethodHandles.lookup().lookupClass()).a(112805022695150L);
      // $VF: monitorexit
      a = var10000;
      a();
      e(true);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(69840126193489L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[44];
      int var5 = 0;
      String var4 = "\u00014èMZÉ\u0097P\u0082\u009e~O\u0082ob\u000b Ùf\u001aF¡¡»LRB\u0093k!°N\n`\u0003)Ñ\u009aJè¢-plÌÝ\u0001ÈÙ h1ßuÍµoæg\u0099\u009e/zLË\u0016Ì2MµðP°ì\u0093º®HÔ\u009dÎ¯(¤ß\u007fR\u0010|OS8ç¨\u008cËû3¼O£Õ\u0082ÈvñÎæ%)\u0016ß\u0000&\u0090âY\u0000ÃµÿgÐ(¤_\u009f\u0012µc¤@³o\u009bÆêµ×\u001b\u0090â\u0096\u009b¢÷PR@>ª\u0004-ôî¿\u0088ðÊ\u001bL\u0016ÎýH%)lÚaX\u0089îïß\u0019\u0007þ\u0095\u001eµ¤À@ªIPØ\u0088ÿ\u008d×\u00adÕï\u0083eAÅ@F\u0019ìí\u0005<\u0093Â°Ë\u008eÜT¡ÇWçy\u000eô-ïåm]\u0010wÚËÝamª\u001eó¯É\u0010Þ¬¶\u0002\t¢ßçv\tGô\u009cªï@\u00107R\u0005×f&ü\u0095¤áÄ¨\u0006u\u0001µ mÑQõ\u00ads\u0016Ó¦\u0010ÜÚçà\u009e¸\t\u0090Õ±¿r!¥^\bðAYO|H(hvr\u0081`é\u0016×¡MFé?z»H\u0004w Ã\u008eÎ\u001f)\u0093\u008cOÅ@n\u001a\u0013½ß\u0005\u0085\u008bL3\u0012\u0018«\u000eIÀ\u001c\u0087ËÈKUewaCÓ\u0087©\u0091¨^B2oë\u0018ÈÚ+¬\u00038$ã\u0014¡ÀXBB\u0014·j\u000fð>:ú\u0093À \u0005vð*9[Ý\räÖR$`]ó\u000f\u007f²\u0088¿wÑ\u001a+ÆÑï\u008b\u009am<}0\u000ef°K\u0090&\u000e\u0003\u0089f¬´e Àì\u0002Ì÷ìOg§\u00adÏ4\u008fNïH|\u0000,'ÞÊ\u0003.r\u0098ÉR³â\u009a\u001fpV0H\u0007}\u009dºf\u0083L\u008crÍ`é)u ~óË\u009eÿ\u0007b\u001dh\u009aV7À0\u0081Ï\u0090\bí©\u0093\u000fÌºI\u008e`\u008bê²§ð »\u001bk\u0088£G{N\u009f85\u008b\u0082³~A\u0092\u0094ÆC¨\u0088Ò-i`Ðõ>\u0016Ý²\u0010Æk\u0090ë>\u000e\u0098[±H¡¦%Ì\u0097\u0004 å©»\u008d\fú¹üMe\u0010¨2{.@\u0084?$}ùâ\u00adÇ%H°\u0001¡\u0093 ö8û\u0007c§4e^!:\u0019Ê\u000fxÁ5ë2HÚ^e\u0012Üåá\u007f\u0083\u0087yE®.\u0098\u009a\u00adÎí:åÂàÝÖ«º\u0017\u0092h\u0084\r¶\u0081GÝ\u0093\u0080 \u0099\u008aCb\u008cV94\u0010`Fvê³¢Ãvgì\u0099¦dC{VNr%\u0087.\u0012\u0092\u0010t\u008eØêóë\u0090ù#29Ñ³|\u008cc\u0018\u0005êZ1\u0097><\u0088ÄhË²\u009ck6,k\f?-\u008bÆh\u0086\u0010¿õð$t®L\u0096E¨ç\u000f\u009d\u0004 Ô(þ\u0098v\u0017\u0010Ô³±ýP÷è²d\u0082\r\u009cuåf\u0011ÌW£NëZEç\u000b¬Üü»q\u000fR\u0091Î7(\u0084·L4¤¢£\u0012Iì\u007f®ù\u0013éj>AÚå\u0080\u001f\u0091\u0019Å\u0012Ý\u008bCBNÛ$5\u0096 v9õ£\u0010F\u0097\u00071¼Æ5ÒÎCÞ\u001aQq\"E8\u008b\u0085e[v\u0003V`\u0095á\rêNÙÏÕk×%üÔ;\u0013àÃîjm¸\u000e¹BÐ]³xg\u0019¼Õ¥UÖÿ:\n+¸Y+mwÚX,- ö´I¢£\u0010Ê\u001en\u0017µ\u008b²\\¾{1e;þ¥G¦ûÛCíÉ\u008d#Â\u008e()p\u008büEë¶\u009d7²¯O4e\u0018|ku\r\u0093$tx\u0012õ¸üXÀ\u00999\u0094Q§Íb-`õ\u000e\u0018:7á»\nÊP|FâR\u0097t\u008f \u0016è\u00ad\u007f^Ñç\u0092S\u0010Þz§êG&Eiï\u009c8.i¸Ã\u009c\u0018{:]\u0004'u\u008fò,å(£¹Ã)bêÚùÑy'å\u00020\n:\u0090ãd\u0091\f1B5Ìb\u001a\u0010m\u0017Z\u007fØì\u0002ö\u0084:\u001d`äKË\u0095¢çúãvÜ[)\u008c Î>Ø\u0080\u0092\u008arÂ\u0018$}â*\u0085eÖ²ÓèM³f-¤3\r¨sþ)\nh\u0099 \u0013\u001ao\u000f\u0015:î(\u001b\u00adÿIjç\u0099ê¥~sõuê\u001fêt\u0096m\"\u0000S\u008f`\u0010¹\u009d\u001f\u007fÚ\u001f2ô\u0090\u008a-·\u008d\u0098Õ¸0\u0086l\u009b\u0082x\u0087h1ðÓ\t¦\u0000\u0002÷\u0089\u0014BäTÌH¤SÍLQ\u0001\u009bÛcêz\rº\u000bÐÔD\u0007Ì\"\u0019|Yc®W(b\u0019¬\u0080^¼ì\u001e\u00819\nô5\u0084©ÈvTüWüCJü=u§w\u0016\u001bü:x0\u009b|Ø£»_\u0010 \u0005]Rg%²©+k*´Â?\u0014g 7Z\u0018\u0003EÓ£=b\u0094IÜ¾\u009c\u0094x\u0015¥& ¬^Y\u008b\u0094\u0012*úwÍõN\u0018N\u0017ü¹\u0001¨&Ø\u001a\u0081\u009dv\tä\u0011ÂÙ\"*GÚ\u009fg=\u0018dh\u008fÆ\u0084\u0015\u008e?óíèa.\rÙî\u0094\u0002¨ÈÍ\u00adu?";
      short var6 = 1369;
      char var3 = 16;
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = a(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[44];
                     树友树友友友友树树何 = "Custom/";
                     何何友友友友友树何树 = "HarmonyOS/";
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "d\u009céH]côT\u009bK£^\u0094e(õã\u0086\u0084ë~W\u0080Q\nÏ5¡Æ\u0082ä\u001fË±\u0097\u0004177Ñ\u0018í\r\u009b_1®/¯C¥2ãMÐøË\u008e¿÷\u001eH6±-";
                  var6 = 65;
                  var3 = '(';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   private 何何友友树何树何友树 B(String fontName, int size, boolean antiAliasing) {
      Font font = this.C(size, new File(Cherish.getResourcesManager().友友何友友何何树何何.getAbsolutePath() + File.separator + fontName));
      何何友友树何树何友树 trueTypeFont = new 何何友友树何树何友树(font, antiAliasing);
      this.何何友友树树何友友友.add(trueTypeFont);
      return trueTypeFont;
   }

   public 何何友友树何树何友树 B(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("shader_borel_" + size, k -> this.B("borel_regular.ttf", size, false));
   }

   public 何何友友树何树何友树 C(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("" + size, k -> this.B("HarmonyOS/Bold.ttf", size, true));
   }

   public Font C(int size, File file) {
      String cacheKey = file.getName() + "_" + size;
      return this.树何树树何树何树何树.computeIfAbsent(cacheKey, k -> {
         Font font;
         try (FileInputStream fis = new FileInputStream(file)) {
            font = Font.createFont(0, fis).deriveFont(0, size);
         } catch (Exception var11) {
            null.println("shader_regular_" + file.getName() + "' for size " + size + ". Using default font instead.");
            var11.printStackTrace();
            font = new Font("default", 0, size);
         }

         return font;
      });
   }

   public 何何友友树何树何友树 F(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("shader_dancing_" + size, k -> this.B("regular_", size, false));
   }

   public 何何友友树何树何友树 S(int size, String fontName) {
      return this.友树友友树何友友何何.computeIfAbsent(fontName + "_" + size, k -> this.B(fontName, size, true));
   }

   public 何何友友树何树何友树 S(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("plymouth_" + 60, k -> this.B("", size, true));
   }

   public 何何友友树何树何友树 Z(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("style_icon_" + size, k -> this.B("styles_icons.ttf", size, true));
   }

   public 何何友友树何树何友树 V(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("material_" + 18, k -> this.B("material.ttf", size, true));
   }

   public static void e(boolean var0) {
      友何树友树树何何友友 = var0;
   }

   public 何何友友树何树何友树 i(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("shader_material_" + size, k -> this.B("", size, false));
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树何友何友何树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public 何何友友树何树何友树 n(int size, String fontName) {
      return this.友树友友树何友友何何.computeIfAbsent("shader_" + fontName + "_" + size, k -> this.B(fontName, size, false));
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   public 何何友友树何树何友树 d(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("shader_regular_" + size, k -> this.B("shader_regular_", size, false));
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11425;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友树何友何友何树树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[_NT½ºBj2, ñ\tÒÇ\u009a\u001e÷³\u0019!\u009d·$q\u00197, ZbÅ\u0000Ù\u0090ßBi\u0010:\u008a\u0085\u0001íK, \u0091x!#Ê\u000b\u0098=V¥\u0094è\u001e\u008a³\u0016à\u0088}\u0016\u0086¹Fú, \u0089Æ¢\u0093J,q©")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 245 && var8 != 212 && var8 != 210 && var8 != 242) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 197) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 163) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 245) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 210) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      e[0] = "rPy0!H}\u00104;+UxM?};N?叵框伆厅佲叚佫框桂桟";
      e[1] = "8\"j\u001bad&*pT,~< i\b=t<729 \u007f16n\b*\u007f&\u000b}\t'\\33";
      e[2] = boolean.class;
      f[2] = "java/lang/Boolean";
      e[3] = void.class;
      f[3] = "java/lang/Void";
      e[4] = "oFV=lC`\u0006\u001b6f^e[\u0010pnCh]\u0014;-EaX\u0014pgE\u007fX\u0014?z\u0002余根桩伋又叧余佽桩厕";
      e[5] = "\\\t\"4/+W\u00063{S2X\u001c=8d\u0002N\u000b1%u.Y\u0006";
      e[6] = "'\bQ\u0019wN(H\u001c\u0012}S-\u0015\u0017TmHj伳伪厱叓栰休桷伪厱栉";
      e[7] = "o\u0006";
      e[8] = "\u001d7vO\u00064\u0012w;D\f)\u0017*0\u0002\u001c2P案厓叧厢伎桯厒厓栽桸";
      e[9] = "0(\u001a\u0019wK. \u0000V\u0015W)=";
      e[10] = "Q\u001d{H\ry^]6C\u0007d[\u0000=\u0005\u0017b[\u001f&\u0005\u0010sA\u001c Y\u0001sA]\u0007N\u0011yG\u00016N\u0011[S\u001d4L\u0007d";
      e[11] = "Z\u00014d@\u0018_N\u0004l\u0002\u0014";
      e[12] = "gO.<\u000ezl@?sotgK;)";
      e[13] = "\u000b/~\u000fo$Zsb\u007f<B_5c\u0002:,\u001b*k\u0016Uy\u001f\"r\u0010;=\u0000*f\u007f";
      e[14] = "GL-P@gL^0V+叞厾栩厌厭栲佀传佭伒n\u0011a\u001f\u000e$\u0014\u001as\u0002\b";
      e[15] = "\u0019\u0001-5{BH]1E,$O\u00061(,B\u0011Q }A\u001e\u001f\u0007e5(H\u0015\\.E";
      e[16] = "jl{yp};0g\t厉栂栜栔佗及桓但栜佐\n43uwpx9#%\u007f";
      e[17] = "\u0012<]E.IU}\u0015\u0000W史叮佛可叽伊佬栴佛佱>g\u000f\u0015>SL7\u000eKx";
      e[18] = "=\u000e\u000ft(dlR\u0013\u0004住佟厑厬桧栝住叁厑厬~:b?2\fO4x=-";
      e[19] = "\u0016{\f\f\u0019\u000bG'\u0010|叠桴厺叙桤伡叠厮伤佇}\u0001\\]\u0007d\u001a\u0017R\u0013";
      e[20] = "h\"5i#{?l4)\\'T.#'l}jk2i9G";
      e[21] = "J\u0004{hG\u000b\u001bXg\u0018桤估格桼佗栁传桴佸桼\ne\u0002][\u001bms\f\u0013";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 5;
               case 1 -> 4;
               case 2 -> 63;
               case 3 -> 19;
               case 4 -> 56;
               case 5 -> 2;
               case 6 -> 16;
               case 7 -> 61;
               case 8 -> 33;
               case 9 -> 41;
               case 10 -> 59;
               case 11 -> 23;
               case 12 -> 52;
               case 13 -> 34;
               case 14 -> 1;
               case 15 -> 8;
               case 16 -> 53;
               case 17 -> 27;
               case 18 -> 45;
               case 19 -> 22;
               case 20 -> 55;
               case 21 -> 21;
               case 22 -> 38;
               case 23 -> 7;
               case 24 -> 17;
               case 25 -> 6;
               case 26 -> 54;
               case 27 -> 12;
               case 28 -> 57;
               case 29 -> 9;
               case 30 -> 24;
               case 31 -> 14;
               case 32 -> 0;
               case 33 -> 48;
               case 34 -> 18;
               case 35 -> 20;
               case 36 -> 35;
               case 37 -> 60;
               case 38 -> 32;
               case 39 -> 11;
               case 40 -> 15;
               case 41 -> 25;
               case 42 -> 62;
               case 43 -> 28;
               case 44 -> 40;
               case 45 -> 44;
               case 46 -> 58;
               case 47 -> 51;
               case 48 -> 31;
               case 49 -> 3;
               case 50 -> 46;
               case 51 -> 47;
               case 52 -> 13;
               case 53 -> 29;
               case 54 -> 49;
               case 55 -> 50;
               case 56 -> 36;
               case 57 -> 42;
               case 58 -> 30;
               case 59 -> 43;
               case 60 -> 26;
               case 61 -> 10;
               case 62 -> 37;
               default -> 39;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树何友何友何树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void t() {
      this.何何友友树树何友友友.forEach(何何友友树何树何友树::close);
      this.何何友友树树何友友友.clear();
      this.友树友友树何友友何何.clear();
      this.树何树树何树何树何树.clear();
   }

   public 何何友友树何树何友树 q(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("regular_" + size, k -> this.B("icon_", size, true));
   }

   public 何何友友树何树何友树 w(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("" + size, k -> this.B("plymouth_rock.ttf", size, false));
   }

   public 树友友友何树友友树树 w() {
      return this.友树树树何友树何树何;
   }

   public 何何友友树何树何友树 r(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("icon_" + size, k -> this.B("icons.ttf", size, true));
   }

   public 何何友友树何树何友树 E(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("dancing-script-regular-2.ttf" + 60, k -> this.B("borel_regular.ttf", size, true));
   }

   public 何何友友树何树何友树 P(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("shader_icon2_" + size, k -> this.B("shader_icon2_", size, false));
   }

   public 何何友友树何树何友树 H(int size) {
      b<"£">(-1523208223547238085L, 128960939682521L);
      何树树何友友何何树友 fontSettings = b<"Ò">(-1523626837882572674L, 128960939682521L);
      String fontPath = "";
      if (fontSettings != null && fontSettings.isEnabled()) {
         String validFontName = fontSettings.N();
         if (!validFontName.equals("Regular")) {
            String customFontFileName = validFontName + ".ttf";
            fontPath = "Custom/" + customFontFileName;
         }
      }

      String finalFontPath = fontPath;
      return b<"õ">(this, -1522909874835881003L, 128960939682521L)
         .computeIfAbsent("dynamic_regular_" + size + "_" + finalFontPath.hashCode(), k -> this.B(finalFontPath, size, true));
   }

   public static boolean H() {
      return 友何树友树树何何友友;
   }

   public 何何友友树何树何友树 T(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("shader_bold_" + size, k -> this.B("HarmonyOS/Bold.ttf", size, false));
   }

   private static String HE_WEI_LIN() {
      return "解放村多种2队1144号";
   }

   public 何何友友树何树何友树 Q(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("icon2_" + 24, k -> this.B("styles_icons.ttf", size, true));
   }

   public 何何友友树何树何友树 G(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("" + size, k -> this.B("", size, false));
   }

   public static boolean G() {
      H();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public 何何友友树何树何友树 O(int size) {
      return this.友树友友树何友友何何.computeIfAbsent("dancing_" + 65, k -> this.B("dancing-script-regular-2.ttf", size, true));
   }
}
