package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.value.impl.BooleanValue;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import net.minecraft.client.gui.GuiGraphics;

public class 树何何何何树何树何树 implements 友树何树友友树树何树<BooleanValue>,  {
   private final HashMap<BooleanValue, Float> 友树何何树何何何何树 = new HashMap<>();
   private static final float 树树何友友何友树树友 = 7.0F;
   private static final long a;
   private static final Object[] b = new Object[12];
   private static final String[] c = new String[12];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-6544095688456144869L, 7453398449265436934L, MethodHandles.lookup().lookupClass()).a(227728685399211L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public boolean F(BooleanValue setting, int keyCode, int scanCode, int modifiers, 友树友树何树友友友树 componentsInstance) {
      return false;
   }

   public void I(
      GuiGraphics guiGraphics,
      BooleanValue value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      友何何树友何何何何树 settingNameFont,
      友何何树友何何何何树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      友树友树何树友友友树 componentsInstance
   ) {
      long a = 树何何何何树何树何树.a ^ 95389279223645L;
      a<"g">(6223737498256408260L, a);
      float animationProgress = a<"æ">(this, 6223092862248673783L, a).computeIfAbsent(value, k -> {
         long var10000 = 树何何何何树何树何树.a ^ 132282050098967L;
         return value.getValue() ? 1.0F : 0.0F;
      });
      float targetProgress = value.getValue() ? 1.0F : 0.0F;
      if (Math.abs(animationProgress - targetProgress) > 0.001F) {
         float var38 = animationProgress + (targetProgress - animationProgress) * 0.25F * partialTicks * 5.0F;
         animationProgress = Math.max(0.0F, Math.min(1.0F, var38));
         a<"æ">(this, 6223092862248673783L, a).put(value, animationProgress);
      }

      float boxX = x + width - 22.0F;
      float boxY = middleY - 5.0F;
      RenderUtils.drawRoundedRect(guiGraphics.pose(), boxX, boxY, 10.0, 10.0, 0.0, darkBgColor.brighter());
      友何何树友何何何何树 checkMarkFont = Cherish.instance.h().F(18);
      float checkMarkCharWidth = checkMarkFont.A("\ueb53");
      float checkMarkCharHeight = checkMarkFont.K();
      float checkMarkX = boxX + (10.0F - checkMarkCharWidth) / 2.0F;
      float checkMarkY = boxY + (10.0F - checkMarkCharHeight) / 2.0F + 1.0F;
      Color checkColor = 树树何友友友友何树友.x(new Color(100, 100, 100, 0), accentColor, animationProgress);
      int alpha = (int)(accentColor.getAlpha() * animationProgress);
      if (animationProgress < 0.01F) {
         alpha = 0;
      }

      if (alpha > 5) {
         Color finalCheckColor = new Color(checkColor.getRed(), checkColor.getGreen(), checkColor.getBlue(), alpha);
         guiGraphics.pose().pushPose();
         float charCenterX = checkMarkX + checkMarkCharWidth / 2.0F;
         float charCenterY = checkMarkY + checkMarkCharHeight / 2.0F;
         float rotationDegrees = (1.0F - animationProgress) * 180.0F;
         guiGraphics.pose().translate(charCenterX, charCenterY, 0.0F);
         guiGraphics.pose().mulPose(a<"ü">(6223779116288682022L, a).rotationDegrees(rotationDegrees));
         guiGraphics.pose().translate(-charCenterX, -charCenterY, 0.0F);
         checkMarkFont.c(guiGraphics.pose(), "\ueb53", checkMarkX, checkMarkY, finalCheckColor.getRGB());
         guiGraphics.pose().popPose();
      }
   }

   public void S(BooleanValue setting, double mouseX, double mouseY, int button, 友树友树何树友友友树 componentsInstance) {
   }

   public float Z(BooleanValue setting, 友树友树何树友友友树 componentsInstance) {
      return 0.0F;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void a() {
      b[0] = "$mYk4L+-\u0014`>Q.p\u001f&.Ji栒伢佝伎佶桖佖桦佝桊";
      b[1] = "t\fe:P\tj\u0004\u007fu6\u001dm\u0005^:\u000e";
      b[2] = "R~3pUW]>~{_JXcu=OQ\u001f叛佈但叱栩佤栁栌栂佯";
      b[3] = boolean.class;
      c[3] = "java/lang/Boolean";
      b[4] = "\u0019IL\f:$\u0010GOEy&\u001bRI\f\u00163\u0013U";
      b[5] = "^g8}/bUh)2S{Zr'qdKLe+lug[h";
      b[6] = "l+\u0010\u0014\n\u000eg$\u0001[k\u0000l/\u0005\u0001";
      b[7] = "t\nA,Z\u0013/\bD^叴桫伖伭桡伃佪伯伖桩xg\\\t5\t\u00067M\u0003 ";
      b[8] = "\u000ev\u0005d~bNb\u001bvD[7!\rv}|Ea\u0011w&\u001c";
      b[9] = "^V ;R\u0006\u0002\b'<i\u00062R}~UP^?@\u007fW\b\u001aS.#\t\u000f\u001d";
      b[10] = "\u0013YFNJ\u001aH[C<N{\u0017R\u0003M_\u001cKI\u0001@'@]_\u000eD@\u001cF]\u0003<";
      b[11] = "T\u0000\u0001\u0006{\u0007\u0014\u0014\u001f\u0014A2mW\t\u0014x\u0019\u001f\u0017\u0015\u0015#y";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 9;
               case 1 -> 28;
               case 2 -> 5;
               case 3 -> 61;
               case 4 -> 53;
               case 5 -> 52;
               case 6 -> 34;
               case 7 -> 6;
               case 8 -> 31;
               case 9 -> 62;
               case 10 -> 30;
               case 11 -> 26;
               case 12 -> 17;
               case 13 -> 38;
               case 14 -> 35;
               case 15 -> 50;
               case 16 -> 1;
               case 17 -> 58;
               case 18 -> 54;
               case 19 -> 42;
               case 20 -> 43;
               case 21 -> 18;
               case 22 -> 10;
               case 23 -> 29;
               case 24 -> 16;
               case 25 -> 24;
               case 26 -> 11;
               case 27 -> 27;
               case 28 -> 63;
               case 29 -> 40;
               case 30 -> 22;
               case 31 -> 8;
               case 32 -> 36;
               case 33 -> 55;
               case 34 -> 47;
               case 35 -> 41;
               case 36 -> 20;
               case 37 -> 56;
               case 38 -> 45;
               case 39 -> 4;
               case 40 -> 14;
               case 41 -> 57;
               case 42 -> 3;
               case 43 -> 46;
               case 44 -> 21;
               case 45 -> 59;
               case 46 -> 39;
               case 47 -> 13;
               case 48 -> 33;
               case 49 -> 15;
               case 50 -> 44;
               case 51 -> 32;
               case 52 -> 19;
               case 53 -> 2;
               case 54 -> 23;
               case 55 -> 7;
               case 56 -> 37;
               case 57 -> 12;
               case 58 -> 0;
               case 59 -> 60;
               case 60 -> 51;
               case 61 -> 49;
               case 62 -> 25;
               default -> 48;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 230 && var8 != 244 && var8 != 252 && var8 != 'X') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'B') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'g') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 230) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 252) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何何何树何树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void p(BooleanValue setting, 友树友树何树友友友树 componentsInstance) {
      long a = 树何何何何树何树何树.a ^ 66438153140474L;
      a<"æ">(this, 5907516898908038736L, a).put(setting, setting.getValue() ? 1.0F : 0.0F);
   }

   public boolean M(
      BooleanValue setting, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 友树友树何树友友友树 componentsInstance
   ) {
      long a = 树何何何何树何树何树.a ^ 24708294166104L;
      a<"g">(-1199477951217410478L, a);
      float boxX = x + width - 22.0F;
      float boxY = middleY - 5.0F;
      if (mouseX >= boxX && mouseX <= boxX + 10.0F && mouseY >= boxY && mouseY <= boxY + 10.0F && button == 0) {
         setting.g(!setting.getValue());
         return true;
      } else {
         return false;
      }
   }

   public boolean W(BooleanValue setting, char chr, int modifiers, 友树友树何树友友友树 componentsInstance) {
      return false;
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖230622200409390090";
   }
}
