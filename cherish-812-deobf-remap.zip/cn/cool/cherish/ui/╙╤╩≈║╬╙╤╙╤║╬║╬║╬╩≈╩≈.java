package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.render.MinecraftFontTextEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.Font.DisplayMode;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;
import org.joml.Matrix4f;

public class 友树何友友何何何树树 implements IWrapper, 何树友 {
   private static String[] 树树何何树何树何树树;
   private static final long a;
   private static final long[] b;
   private static final Integer[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[19];
   private static final String[] g = new String[19];
   private static String LIU_YA_FENG;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7286555817492698463L, -6555363262630195054L, MethodHandles.lookup().lookupClass()).a(230403284991955L);
      // $VF: monitorexit
      a = var10000;
      long var11 = a ^ 96293294493702L;
      a();
      String[] var14 = new String[5];
      b<"A">(var14, 1734493219425788107L, var11);
      Cipher var0;
      Cipher var15 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[4];
      int var3 = 0;
      String var4 = "·¹÷\u0086\u0099\u0080×\u009f\u009f\u000bÏCéË\u0089Ñ";
      byte var5 = 16;
      byte var2 = 0;

      label23:
      while (true) {
         int var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         long[] var16 = var6;
         var10001 = var3++;
         long var19 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte var21 = -1;

         while (true) {
            long var8 = var19;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var23 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var21) {
               case 0:
                  var16[var10001] = var23;
                  if (var2 >= var5) {
                     b = var6;
                     c = new Integer[4];
                     return;
                  }
                  break;
               default:
                  var16[var10001] = var23;
                  if (var2 < var5) {
                     continue label23;
                  }

                  var4 = "\u0013å)$VÕ\n\u0097p\u0080It5pþ\u0088";
                  var5 = 16;
                  var2 = 0;
            }

            byte var18 = var2;
            var2 += 8;
            var7 = var4.substring(var18, var2).getBytes("ISO-8859-1");
            var16 = var6;
            var10001 = var3++;
            var19 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var21 = 0;
         }
      }
   }

   public int J() {
      long a = 友树何友友何何何树树.a ^ 35066493865541L;
      return 9;
   }

   public int S(Component component) {
      long a = 友树何友友何何何树树.a ^ 140442088322478L;
      b<"A">(-162969387802445052L, a);
      MinecraftFontTextEvent minecraftFontTextEvent = new MinecraftFontTextEvent(component);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(minecraftFontTextEvent);
      }

      FormattedText finalText = minecraftFontTextEvent.getFormattedText();
      return finalText != null && finalText instanceof Component ? b<"C">(mc, -162734399590243821L, a).width(finalText) : 0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 28;
               case 1 -> 55;
               case 2 -> 10;
               case 3 -> 6;
               case 4 -> 39;
               case 5 -> 33;
               case 6 -> 38;
               case 7 -> 32;
               case 8 -> 5;
               case 9 -> 13;
               case 10 -> 54;
               case 11 -> 36;
               case 12 -> 53;
               case 13 -> 15;
               case 14 -> 11;
               case 15 -> 43;
               case 16 -> 18;
               case 17 -> 37;
               case 18 -> 44;
               case 19 -> 17;
               case 20 -> 60;
               case 21 -> 25;
               case 22 -> 23;
               case 23 -> 30;
               case 24 -> 1;
               case 25 -> 8;
               case 26 -> 47;
               case 27 -> 48;
               case 28 -> 24;
               case 29 -> 19;
               case 30 -> 45;
               case 31 -> 41;
               case 32 -> 31;
               case 33 -> 26;
               case 34 -> 21;
               case 35 -> 59;
               case 36 -> 52;
               case 37 -> 61;
               case 38 -> 20;
               case 39 -> 40;
               case 40 -> 57;
               case 41 -> 34;
               case 42 -> 51;
               case 43 -> 42;
               case 44 -> 0;
               case 45 -> 46;
               case 46 -> 14;
               case 47 -> 62;
               case 48 -> 16;
               case 49 -> 22;
               case 50 -> 29;
               case 51 -> 50;
               case 52 -> 27;
               case 53 -> 12;
               case 54 -> 2;
               case 55 -> 49;
               case 56 -> 58;
               case 57 -> 7;
               case 58 -> 35;
               case 59 -> 56;
               case 60 -> 4;
               case 61 -> 3;
               case 62 -> 63;
               default -> 9;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'C' && var8 != 'R' && var8 != 'p' && var8 != 201) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'H') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'A') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'C') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'R') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'p') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树何友友何何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public int x(PoseStack poseStack, String text, float x, float y, int color, boolean shadow) {
      long a = 友树何友友何何何树树.a ^ 21693793885105L;
      Matrix4f matrix = poseStack.last().pose();
      BufferSource bufferSource = mc.renderBuffers().bufferSource();
      int result = this.R(text, x, y, color, shadow, matrix, bufferSource, b<"p">(1415574783971367214L, a), 0, a<"x">(5368, 1051351852502016953L ^ a));
      bufferSource.endBatch();
      return result;
   }

   public int x(PoseStack poseStack, String text, float x, float y, int color) {
      long a = 友树何友友何何何树树.a ^ 139316502225468L;
      Matrix4f matrix = poseStack.last().pose();
      BufferSource bufferSource = mc.renderBuffers().bufferSource();
      int result = this.R(text, x, y, color, true, matrix, bufferSource, b<"p">(-6185609650011004765L, a), 0, a<"x">(9600, 1442979153795410767L ^ a));
      bufferSource.endBatch();
      return result;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public int c(String text) {
      long a = 友树何友友何何何树树.a ^ 40885719531362L;
      b<"A">(3995078388976284104L, a);
      MinecraftFontTextEvent minecraftFontTextEvent = new MinecraftFontTextEvent(text);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(minecraftFontTextEvent);
      }

      String finalText = minecraftFontTextEvent.getText();
      return b<"C">(mc, 3995118898921810143L, a).width(finalText);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   public static void d(String[] var0) {
      树树何何树何树何树树 = var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树何友友何何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      f[0] = "7utHnU859CdH=h2\u0005tSz叐伏佾栐叱企低伏佾栐";
      f[1] = "3\u0017\u001e\ft\u0001F7\u0015\u0003eN;/\u0006\u0004l\u0007S";
      f[2] = "d<y\u0011ITk|4\u001aCIn!?\\SR)厙框伧叭台佒伇伂档样";
      f[3] = ";lfYD]0cw\u00168D?yyU\u000ft)nuH\u001eX>c";
      f[4] = "\u0001TI\\I?\u0001T^\u0000E0\u001b\u001f^\u001eM3\u0001E\u0013?M8\nRO\u0013B\"";
      f[5] = "&$\u007f5gA&$hikN<ohwcM&5%|\u007fAf\u0007du~";
      f[6] = "[\u0016<}\u0016\u0013[\u0016+!\u001a\u001cA]+?\u0012\u001f[\u0007f4\u000e\u0013\u001b5'=\u000f^q\u001a;#\u0017\u001bL>'7\u001e";
      f[7] = "`q~\t\u001d4\u0015Qu\u0006\f{hIf\u0001\u00052\u0000";
      f[8] = void.class;
      g[8] = "java/lang/Void";
      f[9] = ":\u001a;\\yh5ZvWsu0\u0007}\u0011{h=\u0001yZ8J6\u0010`Ss";
      f[10] = boolean.class;
      g[10] = "java/lang/Boolean";
      f[11] = "eSydv\u0002n\\h+\u0017\feWlq";
      f[12] = "\u0016+Q\u0015\u0015\u001c\u0002:V~$#Gq\u0012\u0017\rY\u001e$\nFv";
      f[13] = "\u0014\u001ex.k_[X!/\u0015m*\\+<.\u0011I\u0006ygy.";
      f[14] = "[`\u0003|\u0014E\u0014&Z}j}e\"PnQ\u000b\u0006x\u00025\u00064XyFz\u001bS\u001dzH\u007fj";
      f[15] = "$CTn*egI\ny\u0014lH\u001c\r9*8H-\b9p{uUOj/a";
      f[16] = "k8(jWI.<y!4LQ?-.][+fx6\f lfk/EG)ee*4";
      f[17] = "\"S\u0016p\u0000Q&A\u0004gd(Yc+V n\"S\u0016p\u0000Q&A\u0004g";
      f[18] = "LPHA\"l\tT\u0019\nAlvP\u000e\u0010(|\u0010\u0000K\u001b{\u0005L\u0010\u001e\u00138c\u001cU\u0015@A";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25826;
      if (c[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = b[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])e.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/友树何友友何何何树树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         c[var3] = var15;
      }

      return c[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public int m(String text) {
      long a = 友树何友友何何何树树.a ^ 79662617980789L;
      b<"A">(2839013773938221535L, a);
      MinecraftFontTextEvent minecraftFontTextEvent = new MinecraftFontTextEvent(text);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(minecraftFontTextEvent);
      }

      String finalText = minecraftFontTextEvent.getText();
      return b<"C">(mc, 2839218454050715848L, a).width(finalText);
   }

   public static String[] m() {
      return 树树何何树何树何树树;
   }

   public int o(FormattedCharSequence sequence) {
      long a = 友树何友友何何何树树.a ^ 65478840834623L;
      b<"A">(-7913880064490417003L, a);
      MinecraftFontTextEvent minecraftFontTextEvent = new MinecraftFontTextEvent(sequence);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(minecraftFontTextEvent);
      }

      FormattedCharSequence finalSequence = minecraftFontTextEvent.getFormattedCharSequence();
      return b<"C">(mc, -7913776882407273086L, a).width(finalSequence);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public int U(PoseStack poseStack, String text, float x, float y, int color) {
      long a = 友树何友友何何何树树.a ^ 120948092892903L;
      Matrix4f matrix = poseStack.last().pose();
      BufferSource bufferSource = mc.renderBuffers().bufferSource();
      int result = this.R(text, x, y, color, false, matrix, bufferSource, b<"p">(4536070948098487416L, a), 0, a<"x">(9600, 1442960922644086676L ^ a));
      bufferSource.endBatch();
      return result;
   }

   public List<FormattedCharSequence> y(FormattedText text, int maxWidth) {
      long a = 友树何友友何何何树树.a ^ 56349528433276L;
      return b<"C">(mc, -1553859071926929983L, a).split(text, maxWidth);
   }

   public void T(
      Component component,
      float x,
      float y,
      int color,
      boolean shadow,
      Matrix4f matrix,
      MultiBufferSource bufferSource,
      DisplayMode displayMode,
      int backgroundLight,
      int packedLight
   ) {
      long a = 友树何友友何何何树树.a ^ 98434904527321L;
      b<"A">(6470021237183094643L, a);
      MinecraftFontTextEvent minecraftFontTextEvent = new MinecraftFontTextEvent(component);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(minecraftFontTextEvent);
      }

      if (!minecraftFontTextEvent.isCancelled()) {
         FormattedText finalText = minecraftFontTextEvent.getFormattedText();
         if (finalText != null && finalText instanceof Component) {
            b<"C">(mc, 6470265089644709476L, a)
               .drawInBatch((Component)finalText, x, y, color, shadow, matrix, bufferSource, displayMode, backgroundLight, packedLight);
         }
      }
   }

   public void T(PoseStack poseStack, String text, float x, float y, int color, boolean shadow) {
      long a = 友树何友友何何何树树.a ^ 55567056201215L;
      int shadowColor = (color & a<"x">(27067, 8407478797350019254L ^ a)) >> 2 | color & a<"x">(10542, 7033927785688522784L ^ a);
      Matrix4f matrix = poseStack.last().pose();
      BufferSource bufferSource = mc.renderBuffers().bufferSource();
      b<"A">(-5914271920447427755L, a);
      this.R(text, x + 1.0F, y, shadowColor, false, matrix, bufferSource, b<"p">(-5914632623223167136L, a), 0, a<"x">(9600, 1442895541787815052L ^ a));
      this.R(text, x - 1.0F, y, shadowColor, false, matrix, bufferSource, b<"p">(-5914632623223167136L, a), 0, a<"x">(9600, 1442895541787815052L ^ a));
      this.R(text, x, y + 1.0F, shadowColor, false, matrix, bufferSource, b<"p">(-5914632623223167136L, a), 0, a<"x">(9600, 1442895541787815052L ^ a));
      this.R(text, x, y - 1.0F, shadowColor, false, matrix, bufferSource, b<"p">(-5914632623223167136L, a), 0, a<"x">(9600, 1442895541787815052L ^ a));
      this.R(text, x, y, color, shadow, matrix, bufferSource, b<"p">(-5914632623223167136L, a), 0, a<"x">(9600, 1442895541787815052L ^ a));
      bufferSource.endBatch();
      b<"A">(!b<"A">(-5914325419704631487L, a), -5914100420828948801L, a);
   }

   public int R(
      String text,
      float x,
      float y,
      int color,
      boolean shadow,
      Matrix4f matrix,
      MultiBufferSource bufferSource,
      DisplayMode displayMode,
      int backgroundLight,
      int packedLight
   ) {
      long a = 友树何友友何何何树树.a ^ 113018110403719L;
      b<"A">(3212224619203160621L, a);
      MinecraftFontTextEvent minecraftFontTextEvent = new MinecraftFontTextEvent(text);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(minecraftFontTextEvent);
      }

      if (minecraftFontTextEvent.isCancelled()) {
         return (int)x;
      } else {
         String finalText = minecraftFontTextEvent.getText();
         return b<"C">(mc, 3212404218307818298L, a).drawInBatch(finalText, x, y, color, shadow, matrix, bufferSource, displayMode, 0, packedLight);
      }
   }

   private static String HE_DA_WEI() {
      return "何建国230622195906030014";
   }
}
