package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.animations.树友何何何友友树何友;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 何树树友何友友友何何 implements IWrapper, 何树友 {
   public static 树友何何何友友树何友 友友友树树何树何友树;
   public static 树友何何何友友树何友 友树友何友何友树何友;
   private static Module[] 友树友何友树树友友树;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[18];
   private static final String[] e = new String[18];
   private static int _何炜霖黑水 _;

   private 何树树友何友友友何何() {
      long var10000 = 何树树友何友友友何何.a ^ 4234041960100L;
      super();
      throw new UnsupportedOperationException(b);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8040259582827625737L, 2316457837141777972L, MethodHandles.lookup().lookupClass()).a(67002201346279L);
      // $VF: monitorexit
      a = var10000;
      long var3 = a ^ 133062550860926L;
      long var5 = var3 ^ 7076404091208L;
      a();
      if (a<"Þ">(-4746620440813415437L, var3) != null) {
         a<"Þ">(new Module[5], -4746332190773106118L, var3);
      }

      Cipher var0;
      Cipher var7 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var3 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var3 << var1 * 8 >>> 56);
      }

      var7.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var8 = b(
            var0.doFinal("\u008fÕg\u0093'wc§=Ò\u0090ãÔe|íqMèRÁÈI\b\"\u0014¾Fdæ_×Ãæ¦y»\u0080ÜpµY\u0092B\nm\u008d\u0017«.\u0086ç:\u0000ÞD".getBytes("ISO-8859-1"))
         )
         .intern();
      byte var10001 = -1;
      b = var8;
      a<"I">(new 树友何何何友友树何友(var5), -4746710011023999781L, var3);
      a<"I">(new 树友何何何友友树何友(var5), -4746240406508788356L, var3);
   }

   public static void D(Module[] var0) {
      友树友何友树树友友树 = var0;
   }

   public static void F(PoseStack poseStack, float progress, int y) {
      long a = 何树树友何友友友何何.a ^ 100597625400015L;
      long ax = a ^ 46112908874820L;
      long axx = a ^ 130102029844064L;
      long axxx = a ^ 41815156195029L;
      int x = mc.getWindow().getGuiScaledWidth() / 2 - 68;
      float target = 120.0F * progress;
      a<"¢">(2346777963929150058L, a).y(Math.min(target, 120.0F), axxx, 40);
      a<"¢">(2346609619165101005L, a).y(Math.min(target, 120.0F), axxx, 80);
      Color color = HUD.instance.getColor(1);
      Color color2 = HUD.instance.getColor(4);
      float var10001 = x + 9;
      float var10002 = (float)(y + 6.5);
      Object[] var10010 = new Object[]{null, null, null, null, null, null, null, a<"¢">(2346671043448977271L, a), ax};
      var10010[6] = 9.0F;
      var10010[5] = 1.0F;
      var10010[4] = 7.0F;
      var10010[3] = 122.0F;
      var10010[2] = var10002;
      var10010[1] = var10001;
      var10010[0] = poseStack;
      ShaderUtils.A(var10010);
      RenderUtils.drawRoundedRect(poseStack, x + 9, (float)(y + 6.5), 122.0, 7.0, 0.0, new Color(0, 0, 0, 150));
      RenderUtils.drawGradientRectL2R(
         poseStack,
         x + 10,
         (float)(y + 7.5),
         a<"¢">(2346609619165101005L, a).y(axx),
         5.0F,
         HUD.instance.getColor(0).getRGB(),
         HUD.instance.getColor(4).getRGB()
      );
      a<"Þ">(2346867577606425922L, a);
      RenderUtils.drawGradientRectL2R(
         poseStack,
         x + 10,
         (float)(y + 7.5),
         a<"¢">(2346777963929150058L, a).y(axx),
         5.0F,
         new Color(color.getRed(), color.getGreen(), color.getBlue(), 150).getRGB(),
         new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), 150).getRGB()
      );
      Cherish.instance.h().n(20).L(poseStack, Math.round(progress * 100.0F) + "%", x + 71, y + 5.0F, new Color(225, 225, 225).getRGB());
      a<"Þ">(!a<"Þ">(2348092965773775935L, a), 2346928669905117662L, a);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 36;
               case 1 -> 61;
               case 2 -> 7;
               case 3 -> 32;
               case 4 -> 30;
               case 5 -> 1;
               case 6 -> 9;
               case 7 -> 28;
               case 8 -> 53;
               case 9 -> 18;
               case 10 -> 25;
               case 11 -> 63;
               case 12 -> 17;
               case 13 -> 40;
               case 14 -> 10;
               case 15 -> 34;
               case 16 -> 49;
               case 17 -> 35;
               case 18 -> 22;
               case 19 -> 57;
               case 20 -> 54;
               case 21 -> 14;
               case 22 -> 55;
               case 23 -> 15;
               case 24 -> 8;
               case 25 -> 51;
               case 26 -> 23;
               case 27 -> 50;
               case 28 -> 41;
               case 29 -> 56;
               case 30 -> 16;
               case 31 -> 45;
               case 32 -> 52;
               case 33 -> 44;
               case 34 -> 43;
               case 35 -> 5;
               case 36 -> 11;
               case 37 -> 39;
               case 38 -> 62;
               case 39 -> 20;
               case 40 -> 0;
               case 41 -> 21;
               case 42 -> 59;
               case 43 -> 37;
               case 44 -> 26;
               case 45 -> 38;
               case 46 -> 12;
               case 47 -> 13;
               case 48 -> 24;
               case 49 -> 27;
               case 50 -> 46;
               case 51 -> 6;
               case 52 -> 19;
               case 53 -> 33;
               case 54 -> 48;
               case 55 -> 60;
               case 56 -> 42;
               case 57 -> 3;
               case 58 -> 29;
               case 59 -> 58;
               case 60 -> 4;
               case 61 -> 31;
               case 62 -> 2;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'i' && var8 != 235 && var8 != 162 && var8 != 'I') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 230) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 222) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'i') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 235) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 162) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树树友何友友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      c[0] = "Tp\u0013k,%[0^`&8^mU&6#\u0019佋栬栙厈伟叼叕叶佝伖";
      c[1] = "RF\u0007.;m]\u0006J%1pX[Ac!vXDZc5lXEH9=m_[\u0007桜原佗佤佽叢历桅佗叺";
      c[2] = "(#Ra%='c\u001fj/ \">\u0014,'=/8\u0010gd\u001f$)\tn/";
      c[3] = boolean.class;
      e[3] = "java/lang/Boolean";
      c[4] = void.class;
      e[4] = "java/lang/Void";
      c[5] = "6.\u000b\u000bNU\u0002\r\u0004K\u0003^\b\u0010\u0001\u0016\b\u0018\u0000\r\f\u0010\fSC/\u0007\u0001\u0015Z\bY";
      c[6] = "\u0014fc|^D\u001fir3%F\rrem\u001fZ\nbqR\u0000M\ffat\u001fF;\u007fvx\u0000\\\u0017h{";
      c[7] = "A|lYB \\i4{\u0003-Do";
      c[8] = "7\u001bTq\"@\u00038[1oK\t%^ld\r\u00018Sj`FB\u001aX{yO\tl";
      c[9] = "\u00008<+\u00196\u000b7-dx8\u0000<)>";
      c[10] = "syH[n\u0000z|F#叄栩叙优叻佾叄栩佇历8\u001a;\u000f*#\u0004\u001b~\b~";
      c[11] = "Z\b8AlFS\r69Iv\u000eFtYk\u0010W^y\u0000\u0005M\\\u00044]<\u000f\b_'9";
      c[12] = "z>}]'\u0001s;s%厍史叐栛栔佸桗佬叐栛\r\u001cr\u000e#d1\u001d7\tw";
      c[13] = "ySv+\u0018[*\f$n~n\u0000+\u0002V~\u0019u]ws\u0001J*\u000f2";
      c[14] = "ha\u0000\u0017)Kka\u0007\u0013TgQ!VR.Ol$\u0010V0.jtYQ0\u0017( \u0002BT";
      c[15] = "_;jhM\u0019V>d\u0010U)\u000bu&pJORm+)$";
      c[16] = "7O^94{>JPA4Kb\u001aB#\"p#\tI=]w7\u001fL>f6$\u0014RA";
      c[17] = "\u00124\u001fWG\u001b\u00114\u0018S:\u0013+tI\u0012@\u001f\u0016q\u000f\u0016^~";
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static Module[] y() {
      return 友树友何友树树友友树;
   }

   public static void P(PoseStack poseStack, String text, float progress, float ticks, int y) {
      long a = 何树树友何友友友何何.a ^ 103037984007565L;
      long ax = a ^ 123815024701730L;
      long axx = a ^ 36075750994327L;
      int x = mc.getWindow().getGuiScaledWidth() / 2 - 45;
      float target = 80.0F * progress;
      a<"¢">(8057899433228201256L, a).y(Math.min(target, 80.0F), axx, 40);
      RenderUtils.drawGradientRectL2R(poseStack, x, y, 90.0F, 1.0F, HUD.instance.getColor(1).getRGB(), HUD.instance.getColor(4).getRGB());
      RenderUtils.drawRectangle(poseStack, x, y, 90.0F, 25.0F, new Color(0, 0, 0, 80).getRGB());
      a<"Þ">(8057988018814419456L, a);
      RenderUtils.drawRectangle(poseStack, x + 5, y + 15, 80.0F, 7.0F, new Color(0, 0, 0, 80).getRGB());
      RenderUtils.drawGradientRectL2R(
         poseStack, x + 5, y + 15, a<"¢">(8057899433228201256L, a).y(ax), 7.0F, HUD.instance.getColor(0).getRGB(), HUD.instance.getColor(4).getRGB()
      );
      Cherish.instance.h().n(18).L(poseStack, text + ticks, x + 45, y + 5, new Color(225, 225, 225, 160).getRGB());
      if (!a<"Þ">(8058097333476219773L, a)) {
         a<"Þ">(new Module[3], 8057644204279167945L, a);
      }
   }

   private static String HE_DA_WEI() {
      return "何炜霖230622200409390090";
   }
}
