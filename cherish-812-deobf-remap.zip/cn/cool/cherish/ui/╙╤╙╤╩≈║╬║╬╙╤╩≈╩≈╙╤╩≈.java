package cn.cool.cherish.ui;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 友友树何何友树树友树 implements 树何何何树友友友友友<树友何何树树何友友何>, IWrapper,  {
   private static final float 友何友友树何树何树树 = 7.0F;
   private static final float 何友何何树何友何何何 = 10.0F;
   private static final float 何友何友树友何何何何 = 10.0F;
   private static final float 友何友树树何友树树友 = 100.0F;
   private static final float 树何友友友何何何友友 = 100.0F;
   private static final float 友树何友树树树何何友 = 10.0F;
   private static final float 树树树树友树友树树友 = 4.0F;
   private static final float 友树何友何何树友何何 = 3.0F;
   private static boolean 友树何何树树友何友何;
   private static final long a;
   private static final Object[] b = new Object[31];
   private static final String[] c = new String[31];
   private static int _何大伟为什么要诈骗何炜霖 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-1485106974554956164L, 8413233029431436308L, MethodHandles.lookup().lookupClass()).a(267816202010871L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (!Z()) {
         v(true);
      }
   }

   public boolean C(
      树友何何树树何友友何 setting, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 树何友何树树何何树树 componentsInstance
   ) {
      Z();
      if (button == 0) {
         float previewX = x + width - 17.0F;
         float previewY = middleY - 5.0F;
         if (mouseX >= previewX && mouseX <= previewX + 10.0F && mouseY >= previewY && mouseY <= previewY + 10.0F) {
            boolean currentExpanded = componentsInstance.友友友友树何何友树何.getOrDefault(setting, false);
            componentsInstance.友友友友树何何友树何.put(setting, !currentExpanded);
            if (!currentExpanded) {
               componentsInstance.友友友友何树友树友树 = null;
            }

            return true;
         }

         boolean isExpanded = componentsInstance.友友友友树何何友树何.getOrDefault(setting, false);
         float expandAnimation = componentsInstance.友何友何友树何何友树.getOrDefault(setting, 0.0F);
         if (isExpanded && expandAnimation > 0.8F) {
            float startY = y + height + 3.0F;
            float pickerBgX = previewX - 100.0F - 20.0F - 12.0F - 3.0F;
            if (mouseX >= pickerBgX && mouseX <= pickerBgX + 100.0F && mouseY >= startY && mouseY <= startY + 100.0F * expandAnimation) {
               componentsInstance.友友友友何树友树友树 = setting;
               componentsInstance.何何何友友树友何树何 = 树何友何树树何何树树.友何树何友树树何何何.友树友树树何友友友树;
               this.i(setting, (int)mouseX, (int)mouseY, pickerBgX, startY, 100.0F, 100.0F * expandAnimation, 0.0F, 0.0F, 0.0F, componentsInstance);
               return true;
            }

            float hueX = pickerBgX + 100.0F + 4.0F;
            if (mouseX >= hueX && mouseX <= hueX + 10.0F && mouseY >= startY && mouseY <= startY + 100.0F * expandAnimation) {
               componentsInstance.友友友友何树友树友树 = setting;
               componentsInstance.何何何友友树友何树何 = 树何友何树树何何树树.友何树何友树树何何何.何何何友友树友树何何;
               this.i(setting, (int)mouseX, (int)mouseY, pickerBgX, startY, 100.0F, 100.0F * expandAnimation, hueX, 0.0F, 10.0F, componentsInstance);
               return true;
            }

            float alphaX = hueX + 10.0F + 4.0F;
            if (mouseX >= alphaX && mouseX <= alphaX + 10.0F && mouseY >= startY && mouseY <= startY + 100.0F * expandAnimation) {
               componentsInstance.友友友友何树友树友树 = setting;
               componentsInstance.何何何友友树友何树何 = 树何友何树树何何树树.友何树何友树树何何何.友树友树友友何友友何;
               this.i(setting, (int)mouseX, (int)mouseY, pickerBgX, startY, 100.0F, 100.0F * expandAnimation, hueX, alphaX, 10.0F, componentsInstance);
               return true;
            }
         }
      }

      return false;
   }

   public boolean Z(树友何何树树何友友何 setting, char chr, int modifiers, 树何友何树树何何树树 componentsInstance) {
      return false;
   }

   public static boolean Z() {
      return 友树何何树树友何友何;
   }

   public static boolean V() {
      Z();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 12;
               case 1 -> 40;
               case 2 -> 0;
               case 3 -> 54;
               case 4 -> 36;
               case 5 -> 19;
               case 6 -> 5;
               case 7 -> 61;
               case 8 -> 7;
               case 9 -> 47;
               case 10 -> 38;
               case 11 -> 2;
               case 12 -> 53;
               case 13 -> 17;
               case 14 -> 33;
               case 15 -> 25;
               case 16 -> 11;
               case 17 -> 45;
               case 18 -> 6;
               case 19 -> 42;
               case 20 -> 50;
               case 21 -> 9;
               case 22 -> 3;
               case 23 -> 24;
               case 24 -> 29;
               case 25 -> 57;
               case 26 -> 49;
               case 27 -> 46;
               case 28 -> 41;
               case 29 -> 34;
               case 30 -> 20;
               case 31 -> 35;
               case 32 -> 31;
               case 33 -> 8;
               case 34 -> 4;
               case 35 -> 43;
               case 36 -> 62;
               case 37 -> 14;
               case 38 -> 30;
               case 39 -> 59;
               case 40 -> 27;
               case 41 -> 22;
               case 42 -> 58;
               case 43 -> 32;
               case 44 -> 1;
               case 45 -> 16;
               case 46 -> 18;
               case 47 -> 21;
               case 48 -> 13;
               case 49 -> 15;
               case 50 -> 26;
               case 51 -> 51;
               case 52 -> 44;
               case 53 -> 63;
               case 54 -> 23;
               case 55 -> 48;
               case 56 -> 56;
               case 57 -> 55;
               case 58 -> 52;
               case 59 -> 28;
               case 60 -> 10;
               case 61 -> 39;
               case 62 -> 37;
               default -> 60;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private void i(
      树友何何树树何友友何 setting,
      int mouseX,
      int mouseY,
      float sqX,
      float sqY,
      float sqSize,
      float sqHeight,
      float hueX,
      float alphaX,
      float sliderWidth,
      树何友何树树何何树树 componentsInstance
   ) {
      V();
      友友树何何友树树友树.何树友友友树友何友树 hsb = new 友友树何何友树树友树.何树友友友树友何友树(setting.getValue());
      if (componentsInstance.何何何友友树友何树何 == 树何友何树树何何树树.友何树何友树树何何何.友树友树树何友友友树) {
         float newSat = Mth.clamp((mouseX - sqX) / 100.0F, 0.0F, 1.0F);
         float newBri = 1.0F - Mth.clamp((mouseY - sqY) / sqHeight, 0.0F, 1.0F);
         hsb.何树树树树何何何何何 = newSat;
         hsb.树树何何友树何何友树 = newBri;
      }

      if (componentsInstance.何何何友友树友何树何 == 树何友何树树何何树树.友何树何友树树何何何.何何何友友树友树何何) {
         float hue = Mth.clamp((mouseY - sqY) / sqHeight, 0.0F, 1.0F);
         hsb.树何友友树何树树树友 = hue;
      }

      if (componentsInstance.何何何友友树友何树何 == 树何友何树树何何树树.友何树何友树树何何何.友树友树友友何友友何) {
         float alphaPercent = 1.0F - Mth.clamp((mouseY - sqY) / sqHeight, 0.0F, 1.0F);
         hsb.友友树友树何何树何树 = (int)(alphaPercent * 255.0F);
      }

      setting.G(hsb.C());
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 228 && var8 != 'C' && var8 != 192 && var8 != 'a') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 246) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'O') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 228) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'C') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 192) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public float n(树友何何树树何友友何 setting, 树何友何树树何何树树 componentsInstance) {
      V();
      float animation = componentsInstance.友何友何友树何何友树.getOrDefault(setting, 0.0F);
      return animation > 0.01F ? 108.0F * animation : 0.0F;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      b[0] = "\\.<\f#9Snq\u0007)$V3zA9?\u0011压叙桾伙伃叴桑栃厤桝";
      b[1] = "X~a*4ZSqpeHC\\k~&\u007fsJ|r;n_]q";
      b[2] = "g\u001f\u0016FJih_[M@tm\u0002P\u000bPo*桠佭叮佰栗栕伤佭栴栴";
      b[3] = "q~h Sl~>%+Yq{c.mIj<栁伓厈佩栒栃佅伓桒栭'叙佅桗伖号栒栃佅伓伖";
      b[4] = "`jx0?=o*5;5 jw>}&3oq3}9?shx桂厛伇佖栕桇伆厛厙佖";
      b[5] = boolean.class;
      c[5] = "java/lang/Boolean";
      b[6] = "b,l]\u0019+ml!V\u00136h1*\u0010\u0003-/厉厉栯伣休及桓桓叵桧`佔桓厉叵厽桕及众厉栯";
      b[7] = int.class;
      c[7] = "java/lang/Integer";
      b[8] = float.class;
      c[8] = "java/lang/Float";
      b[9] = "1uc6\u0002\n,`;\u0014C\u00074f";
      b[10] = "H@\u00117HfVH\u000bx.rQI*7\u0016";
      b[11] = void.class;
      c[11] = "java/lang/Void";
      b[12] = "[!12[mP. }:c[%$'";
      b[13] = "hGTHFfo\u001cYK#叄厗格句栻佾佚桍佸栿\"\u001fx$JBPI{.\u001c";
      b[14] = "xNC:\u001a\u0001&BT1}厹桛厽栱桙传厹厁厽栱@GJ)\u0004O;\u0019F>\u000f";
      b[15] = "+5uRiyo1,)\u007fE-f,@l~d;/\u0012\u0016|(3,S-5u0~)";
      b[16] = "}\u0016]zzGzMPy\u001f栿伜厷召栉佂栿桘桭召\u0010!\u0019zO@|}LqM";
      b[17] = "$T0\tB\tbQ7\u0007?q[{\u0011<hz@}\u0000`\u0001U{],\\GP|S";
      b[18] = "DX\u000bA\u00045\u0000\\R:)\t@NK\u0002\u001dr\u0011\\UC{";
      b[19] = "^<m\u0000rDYg`\u0003\u0017佸桻桇栆桳佊佸伿伃佂j)\u001aYep\u0006uORg";
      b[20] = "B;Al9b\u000bd\f6[佞伦伆厾厔桂叀伦桂传Wa3\u0010!\u001a,??\u0007*";
      b[21] = "T{\u0007\b\t4\u001d$JRk厖厮变司佮桲厖桴变栢3Pk\u0003 \n\u0002\u0016l\u0001g";
      b[22] = "\u0017\u001bpQD3^D=\u000b&厑佳厸休厩栿伏佳厸桕j\u0019mM\u0002q\u0000XcT\u001f";
      b[23] = "<|\u0015\u001250bp\u0002\u0019R厈栟厏桧厫厑伖叅厏伣hh{m6\u0019\u00136wz=";
      b[24] = "\u001aVyC\u001a\u000eDZnH}伨佽伻发叺桤厶根伻住9GEK\u001cuB\u0019I\\\u0017";
      b[25] = "C6O%\u0011\u001fDmB&t桧桦伉你厌桭伣伢厗栤OJADoR#\u0016\u0014Om";
      b[26] = "Z%\bEYY\u001e!Q>xe^3H\u0006@\u001e\u000f!VG&";
      b[27] = "\u001a\u001d]D\u0003\u0000SB\u0010\u001ea厢叠厾厢桦似似叠桤似\u007f^^@\u0004\\\u0015\u001fPY\u0019";
      b[28] = "+\u0016&u\u001d~m\u0013!{`\u001dU7\u001bQ`|u\u0017.a\\:p\u0010 ";
      b[29] = "\u0014\"S|.AP&\n\u0007/}\u00104\u0013?7\u0006A&\r~QM\u0014sZ<=\u001c\u0015r\b\u0007";
      b[30] = "v\u0005\u00163\u001b60\u0000\u0011=fE\u0012,&ZXj)\f\nf\u001eo.\u0002";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友树何何友树树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void g(GuiGraphics guiGraphics, 树友何何树树何友友何 setting, float x, float y, float width, float height) {
      V();
      友友树何何友树树友树.何树友友友树友何友树 hsb = new 友友树何何友树树友树.何树友友友树友何友树(setting.getValue());
      Color baseColor = Color.getHSBColor(hsb.树何友友树何树树树友, hsb.何树树树树何何何何何, hsb.树树何何友树何何友树);
      RenderUtils.y(guiGraphics, 42679067064205L, x, y, 10.0F, height, 4.0F, Color.WHITE.getRGB(), Color.LIGHT_GRAY.getRGB());
      int i = 0;
      if (0.0F < height) {
         float alpha = 1.0F - 0.0F / height;
         Color alphaColor = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), (int)(alpha * 255.0F));
         RenderUtils.q(guiGraphics.pose(), (int)x, (int)(y + 0.0F), (int)(x + width), (int)(y + 0.0F + 1.0F), 137876390830295L, alphaColor.getRGB());
         i++;
      }

      float indicatorY = y + (1.0F - hsb.友友树友树何何树何树 / 255.0F) * height;
      RenderUtils.q(
         guiGraphics.pose(),
         (int)(x - 1.0F),
         (int)(indicatorY - 1.0F),
         (int)(x + width + 1.0F),
         (int)(indicatorY + 1.0F),
         137876390830295L,
         Color.WHITE.getRGB()
      );
   }

   private void v(GuiGraphics guiGraphics, 树友何何树树何友友何 setting, float x, float y, float width, float height) {
      Z();
      友友树何何友树树友树.何树友友友树友何友树 hsb = new 友友树何何友树树友树.何树友友友树友何友树(setting.getValue());
      int indicatorY = 0;
      if (0.0F < height) {
         float hue = 0.0F / height;
         int rgb = Color.HSBtoRGB(hue, 1.0F, 1.0F);
         RenderUtils.q(guiGraphics.pose(), (int)x, (int)(y + 0.0F), (int)(x + 10.0F), (int)(y + 0.0F + 1.0F), 137876390830295L, rgb);
         indicatorY++;
      }

      float indicatorYx = y + hsb.树何友友树何树树树友 * height;
      RenderUtils.q(
         guiGraphics.pose(),
         (int)(x - 1.0F),
         (int)(indicatorYx - 1.0F),
         (int)(x + width + 1.0F),
         (int)(indicatorYx + 1.0F),
         137876390830295L,
         Color.WHITE.getRGB()
      );
   }

   public static void v(boolean var0) {
      友树何何树树友何友何 = var0;
   }

   public void j(树友何何树树何友友何 setting, 树何友何树树何何树树 componentsInstance) {
      Z();
      componentsInstance.友友友友树何何友树何.putIfAbsent(setting, false);
      componentsInstance.友何友何友树何何友树.putIfAbsent(setting, 0.0F);
      if (componentsInstance.友友友友何树友树友树 == setting) {
         componentsInstance.友友友友何树友树友树 = null;
         componentsInstance.何何何友友树友何树何 = null;
      }
   }

   public boolean q(树友何何树树何友友何 setting, int keyCode, int scanCode, int modifiers, 树何友何树树何何树树 componentsInstance) {
      return false;
   }

   private void U(GuiGraphics guiGraphics, 树友何何树树何友友何 setting, float x, float y, float size) {
      Z();
      友友树何何友树树友树.何树友友友树友何友树 hsb = new 友友树何何友树树友树.何树友友友树友何友树(setting.getValue());
      Color hueColor = Color.getHSBColor(hsb.树何友友树何树树树友, 1.0F, 1.0F);
      RenderUtils.q(guiGraphics.pose(), (int)x, (int)y, (int)(x + size), (int)(y + size), 137876390830295L, hueColor.getRGB());
      int i = 0;
      if (0.0F < size) {
         float alpha = 0.0F / size;
         int whiteColor = new Color(1.0F, 1.0F, 1.0F, alpha).getRGB();
         RenderUtils.q(guiGraphics.pose(), (int)(x + size - 0.0F - 1.0F), (int)y, (int)(x + size - 0.0F), (int)(y + size), 137876390830295L, whiteColor);
         i++;
      }

      i = 0;
      if (0.0F < size) {
         float alpha = 0.0F / size;
         int blackColor = new Color(0.0F, 0.0F, 0.0F, alpha).getRGB();
         RenderUtils.q(guiGraphics.pose(), (int)x, (int)(y + 0.0F), (int)(x + size), (int)(y + 0.0F + 1.0F), 137876390830295L, blackColor);
         i++;
      }

      float markX = x + hsb.何树树树树何何何何何 * size;
      float markY = y + (1.0F - hsb.树树何何友树何何友树) * size;
      RenderUtils.q(
         guiGraphics.pose(), (int)(markX - 2.0F), (int)(markY - 2.0F), (int)(markX + 3.0F), (int)(markY + 3.0F), 137876390830295L, Color.WHITE.getRGB()
      );
   }

   public void U(
      GuiGraphics guiGraphics,
      树友何何树树何友友何 value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      何何友友树何树何友树 settingNameFont,
      何何友友树何树何友树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      树何友何树树何何树树 componentsInstance
   ) {
      float previewX = x + width - 17.0F;
      float previewY = middleY - 5.0F;
      Z();
      RenderUtils.q(
         guiGraphics.pose(), (int)previewX, (int)previewY, (int)(previewX + 10.0F), (int)(previewY + 10.0F), 137876390830295L, value.getValue().getRGB()
      );
      RenderUtils.drawRectangle(guiGraphics.pose(), previewX - 1.0F, previewY - 1.0F, 12.0F, 1.0F, Color.GRAY.getRGB());
      RenderUtils.drawRectangle(guiGraphics.pose(), previewX - 1.0F, previewY + 10.0F, 12.0F, 1.0F, Color.GRAY.getRGB());
      RenderUtils.drawRectangle(guiGraphics.pose(), previewX - 1.0F, previewY, 1.0F, 10.0F, Color.GRAY.getRGB());
      RenderUtils.drawRectangle(guiGraphics.pose(), previewX + 10.0F, previewY, 1.0F, 10.0F, Color.GRAY.getRGB());
      componentsInstance.友友友友树何何友树何.getOrDefault(value, false);
      float expandAnimation = componentsInstance.友何友何友树何何友树.getOrDefault(value, 0.0F);
      if (Math.abs(expandAnimation - 1.0F) > 0.001F) {
         float var35 = expandAnimation + (1.0F - expandAnimation) * 0.2F * partialTicks * 5.0F;
         expandAnimation = Math.max(0.0F, Math.min(1.0F, var35));
         componentsInstance.友何友何友树何何友树.put(value, expandAnimation);
      }

      if (expandAnimation > 0.01F) {
         float startY = y + height + 3.0F;
         float pickerBgX = previewX - 132.0F - 3.0F;
         RenderUtils.drawRoundedRect(guiGraphics.pose(), pickerBgX - 4.0F, startY - 4.0F, 140.0, 108.0F * expandAnimation, 3.0, new Color(0, 0, 0, 200));
         if (expandAnimation > 0.8F) {
            this.U(guiGraphics, value, pickerBgX, startY, 100.0F * expandAnimation);
            float hueX = pickerBgX + 100.0F + 4.0F;
            this.v(guiGraphics, value, hueX, startY, 10.0F, 100.0F * expandAnimation);
            float alphaX = hueX + 10.0F + 4.0F;
            this.g(guiGraphics, value, alphaX, startY, 10.0F, 100.0F * expandAnimation);
            if (componentsInstance.友友友友何树友树友树 == value && componentsInstance.何何何友友树友何树何 != null) {
               this.i(value, mouseX, mouseY, pickerBgX, startY, 100.0F, 100.0F * expandAnimation, hueX, alphaX, 10.0F, componentsInstance);
            }
         }
      }
   }

   public void K(树友何何树树何友友何 setting, double mouseX, double mouseY, int button, 树何友何树树何何树树 componentsInstance) {
      V();
      if (componentsInstance.友友友友何树友树友树 == setting) {
         componentsInstance.友友友友何树友树友树 = null;
         componentsInstance.何何何友友树友何树何 = null;
      }
   }

   private static String HE_JIAN_GUO() {
      return "我是何树友";
   }

   private static class 何树友友友树友何友树 implements 何树友 {
      public float 树何友友树何树树树友;
      public float 何树树树树何何何何何;
      public float 树树何何友树何何友树;
      public int 友友树友树何何树何树;
      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static String HE_SHU_YOU;

      public 何树友友友树友何友树(Color color) {
         float[] hsbValues = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
         this.树何友友树何树树树友 = hsbValues[0];
         this.何树树树树何何何何何 = hsbValues[1];
         this.树树何何友树何何友树 = hsbValues[2];
         this.友友树友树何何树何树 = color.getAlpha();
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(7403015657885033636L, -5825192248806483969L, MethodHandles.lookup().lookupClass()).a(14473499733748L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public Color C() {
         int rgb = Color.HSBtoRGB(this.树何友友树何树树树友, this.何树树树树何何何何何, this.树树何何友树何何友树);
         return new Color(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, this.友友树友树何何树何树);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'w' && var8 != 'e' && var8 != 'J' && var8 != 181) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 201) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'p') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'w') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'e') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'J') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/友友树何何友树树友树$何树友友友树友何友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static void a() {
         b[0] = "SN%9E \\\u000eh2O=YSct_&\u001e叫叀桋使会叻栱栚厑栻k佥栱叀厑叡桞叻併叀桋";
         b[1] = int.class;
         c[1] = "java/lang/Integer";
         b[2] = float.class;
         c[2] = "java/lang/Float";
         b[3] = "^e*\u00141\tUj;[P\u0007^a?\u0001";
         b[4] = "\u0017\t\nzS\u007f\u0005\u000b\u0003\u0005叵受桢厰桹佘佫栍伦桪`u\rd\u001cB^<\f~";
         b[5] = "\u0003>M\u0007B3\u0011<Dx栾桁伲伙古桡佺伅厬桝'A]6\u0012>W\u0013@h\u0015";
         b[6] = "]| !#mO~)^桟佛史叅桓伃桟栟栨叅Jg<hL|:5!6K";
         b[7] = "6\u0006,4{R$\u0004%K佃栠桃桥桟伖佃佤伇伡FrdW'\u00066 y\t ";
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 24;
                  case 1 -> 4;
                  case 2 -> 40;
                  case 3 -> 41;
                  case 4 -> 11;
                  case 5 -> 51;
                  case 6 -> 54;
                  case 7 -> 48;
                  case 8 -> 57;
                  case 9 -> 8;
                  case 10 -> 22;
                  case 11 -> 46;
                  case 12 -> 34;
                  case 13 -> 53;
                  case 14 -> 56;
                  case 15 -> 50;
                  case 16 -> 17;
                  case 17 -> 0;
                  case 18 -> 3;
                  case 19 -> 59;
                  case 20 -> 45;
                  case 21 -> 33;
                  case 22 -> 13;
                  case 23 -> 60;
                  case 24 -> 52;
                  case 25 -> 29;
                  case 26 -> 37;
                  case 27 -> 1;
                  case 28 -> 61;
                  case 29 -> 43;
                  case 30 -> 27;
                  case 31 -> 25;
                  case 32 -> 31;
                  case 33 -> 15;
                  case 34 -> 12;
                  case 35 -> 10;
                  case 36 -> 5;
                  case 37 -> 18;
                  case 38 -> 14;
                  case 39 -> 42;
                  case 40 -> 55;
                  case 41 -> 26;
                  case 42 -> 16;
                  case 43 -> 38;
                  case 44 -> 20;
                  case 45 -> 28;
                  case 46 -> 39;
                  case 47 -> 36;
                  case 48 -> 44;
                  case 49 -> 58;
                  case 50 -> 62;
                  case 51 -> 47;
                  case 52 -> 23;
                  case 53 -> 7;
                  case 54 -> 63;
                  case 55 -> 35;
                  case 56 -> 32;
                  case 57 -> 21;
                  case 58 -> 2;
                  case 59 -> 30;
                  case 60 -> 49;
                  case 61 -> 6;
                  case 62 -> 9;
                  default -> 19;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static String LIU_YA_FENG() {
         return "何建国230622195906030014";
      }
   }
}
