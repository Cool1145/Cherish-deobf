package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.impl.ModeValue;
import com.mojang.math.Axis;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;

public class 何友树树树友树友树友 implements 树何何何树友友友友友<ModeValue>,  {
   private static final float 友友何友友树何树树树 = 7.0F;
   private static final float 友树何何何何树何友何 = 10.0F;
   private static final float 树友友何树友树树树何 = 12.0F;
   private static final float 何友友何树友友树树友 = 5.0F;
   private static final float 何何何树何友树树树树 = 5.0F;
   private static final float 友友树友友何何何何树 = 5.0F;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[23];
   private static final String[] f = new String[23];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-4960133981011617256L, -8191049007482632643L, MethodHandles.lookup().lookupClass()).a(72644123680122L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(17616292153842L << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 16;
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "~Ù\u008d¢ô\u001d\u0096l?\b\tXÂÌþ\u0097\u0088tdµþ\u0099ã°ÏG l\u0093\u0090\u0011 g\u0011\u0007×\u0094µG\u00136¯¬y\u009d\u009aà\u008aEÃYÿ`\r=5µ@\u008aL'\u0006ã^_\u0004L(2Â\u0081Op\u009czÑ[ªqÏ\u0012T\u0086ì´¸ì\fmê\u0002¯opfÙ*\u0098ð5\u0098Ø¨!¿¥hÔ5Â\"³öjj\u0096\u0089wÀ~cÝí\u009e¾\"xh ^ºÇ\u001f\u0007K]Q\u0016\u0013ó\u0090\u001dÑQæ´@\u0080\u00164\u008fP\u001a"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 153) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "~Ù\u008d¢ô\u001d\u0096l?\b\tXÂÌþ\u0097\u0088tdµþ\u0099ã°ÏG l\u0093\u0090\u0011 g\u0011\u0007×\u0094µG\u00136¯¬y\u009d\u009aà\u008aEÃYÿ`\r=5µ@\u008aL'\u0006ã^_\u0004L(2Â\u0081Op\u009czÑ[ªqÏ\u0012T\u0086ì´¸ì\fmê\u0002¯opfÙ*\u0098ð5\u0098Ø¨!¿¥hÔ5Â\"³öjj\u0096\u0089wÀ~cÝí\u009e¾\"xh ^ºÇ\u001f\u0007K]Q\u0016\u0013ó\u0090\u001dÑQæ´@\u0080\u00164\u008fP\u001a"
            .charAt(var4);
      }
   }

   public void B(ModeValue value, double mouseX, double mouseY, int button, 树何友何树树何何树树 componentsInstance) {
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何友树树树友树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public float d(ModeValue value, 树何友何树树何何树树 componentsInstance) {
      float animation = componentsInstance.树友树何何友树友友何.getOrDefault(value, 0.0F);
      float calculatedHeight = 0.0F;
      友友树何何友树树友树.Z();
      int displayedOptionsCount = 0;
      String[] var9 = value.n();
      int var10 = var9.length;
      int var11 = 0;
      if (0 < var10) {
         String modeValue = var9[0];
         if (!modeValue.equals(value.getValue())) {
            calculatedHeight = 12.0F;
            displayedOptionsCount++;
         }

         var11++;
      }

      if (displayedOptionsCount > 0) {
         calculatedHeight += 2.0F;
      }

      return animation > 0.01F ? calculatedHeight * animation : 0.0F;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 1887;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/何友树树树友树友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[IVó]üè9\u0087, )")[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      e[0] = "p4L q\u0002\u007ft\u0001+{\u001fz)\nmk\u0004=伏厩桒栏桼变桋厩桒叕";
      e[1] = "4\fo\u0000?'?\u0003~OC>0\u0019p\ft\u000e&\u000e|\u0011e\"1\u0003";
      e[2] = "\u0011<>M\u0006\r\u001e|sF\f\u0010\u001b!x\u0000\u001c\u000b\\厙叛栿似伷厹桃栁句桸";
      e[3] = boolean.class;
      f[3] = "java/lang/Boolean";
      e[4] = ")!9h0\r&atc:\u0010#<\u007f%*\u000bd桞佂叀伊桳桛会佂栚桎";
      e[5] = "F\u0014\n9\u001a\fX\u001c\u0010v|\u0018_\u001d19D";
      e[6] = ":\f&Vu=3\u0002%\u001f6?8\u0017#VY*0\u0010";
      e[7] = "\u0014s\u0019D,\u000b\u001b3TO&\u0016\u001en_\t.\u000b\u0013h[Bm)\u0018yBK&";
      e[8] = "\u000f\u00175/K ;4:o\u0006+1)?2\rm9424\t&z\u00169%\u0010/1`";
      e[9] = "H[\u000bF\u0003\u0015UNSdB\u0018MH";
      e[10] = "f^|!<\u0004R}saq\u000fX`v<zIP}{:~\u0002\u0013_p+g\u000bX)";
      e[11] = void.class;
      f[11] = "java/lang/Void";
      e[12] = "?!|f\u000b\u001b4.m)j\u0015?%is";
      e[13] = "5Z34\u000e\u000euPoto桦反桹佒众厬桦反厣佒JT\u001ae\u00012{\u0011\u0002p\u001e";
      e[14] = "j\u00021RM?*\bm\u0012,厍厒叻収可栵伓案佥栔,\u0017+:Y0\u001dR3/F";
      e[15] = "\u001cu6x\u0007D\u0018}cqkf!!k0\u0015F@n1n\u000f4";
      e[16] = "n\u0000=7G\u0006f\u0017u>6(WFs?\t\u000b6\u000607Qv";
      e[17] = "\u0004O!B*\u0004\fXiK[&=\toJd\t\\I,B<t";
      e[18] = ";\u0016p|#Fi\u0016rGsylWv=+\u0017'\u0011{w\u001a@j\blvt\u000b,\u0005&G";
      e[19] = "AsFc0\u0003\u0001y\u001a#Q伯档伔档叞伌伯伧桐厹\u001dj\u0017\u0011(G,/\u000f\u00047";
      e[20] = "a`|<togpap\u0006N\u001f[RM\u0006/%h2rx)5u~";
      e[21] = "82%+CO<:p\"/a\u0005fxcQMd)\"=K?5f!m@\u0003;5-l/";
      e[22] = "]s\u001e\"b9\u0005{@4\t66.\u001c|5`ZC!zng\u0005\u007f@\"f9\u0013";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 41;
               case 2 -> 12;
               case 3 -> 13;
               case 4 -> 0;
               case 5 -> 5;
               case 6 -> 8;
               case 7 -> 24;
               case 8 -> 7;
               case 9 -> 16;
               case 10 -> 4;
               case 11 -> 9;
               case 12 -> 48;
               case 13 -> 52;
               case 14 -> 44;
               case 15 -> 38;
               case 16 -> 42;
               case 17 -> 14;
               case 18 -> 56;
               case 19 -> 34;
               case 20 -> 18;
               case 21 -> 32;
               case 22 -> 57;
               case 23 -> 10;
               case 24 -> 61;
               case 25 -> 46;
               case 26 -> 43;
               case 27 -> 21;
               case 28 -> 29;
               case 29 -> 40;
               case 30 -> 54;
               case 31 -> 47;
               case 32 -> 11;
               case 33 -> 6;
               case 34 -> 36;
               case 35 -> 3;
               case 36 -> 55;
               case 37 -> 53;
               case 38 -> 58;
               case 39 -> 31;
               case 40 -> 2;
               case 41 -> 33;
               case 42 -> 51;
               case 43 -> 25;
               case 44 -> 59;
               case 45 -> 39;
               case 46 -> 20;
               case 47 -> 23;
               case 48 -> 19;
               case 49 -> 17;
               case 50 -> 35;
               case 51 -> 26;
               case 52 -> 37;
               case 53 -> 27;
               case 54 -> 60;
               case 55 -> 30;
               case 56 -> 49;
               case 57 -> 22;
               case 58 -> 15;
               case 59 -> 62;
               case 60 -> 1;
               case 61 -> 63;
               case 62 -> 45;
               default -> 28;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何友树树树友树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 't' && var8 != 244 && var8 != 'T' && var8 != 211) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 209) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 203) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 't') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'T') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private float v(ModeValue value, 何何友友树何树何友树 font) {
      友友树何何友树树友树.V();
      float maxWidth = 0.0F;
      if (value.n() == null || value.n().length == 0) {
         maxWidth = font.D("None");
      }

      String[] var7 = value.n();
      int var8 = var7.length;
      int var9 = 0;
      if (0 < var8) {
         String modeValue = var7[0];
         maxWidth = Math.max(maxWidth, (float)font.D(modeValue));
         var9++;
      }

      return maxWidth;
   }

   public void j(ModeValue value, 树何友何树树何何树树 componentsInstance) {
      友友树何何友树树友树.Z();
      componentsInstance.何树何树友何何何树友.putIfAbsent(value, false);
      componentsInstance.树友树何何友树友友何.putIfAbsent(value, 0.0F);
      ClientUtils.D(131325480669526L);
      HashMap<String, Float> optionMap = componentsInstance.友友友友友树何树何树.computeIfAbsent(value.r(), k -> new HashMap<>());
      String[] var10 = value.n();
      int var11 = var10.length;
      int var12 = 0;
      if (0 < var11) {
         String mode = var10[0];
         optionMap.putIfAbsent(mode, 0.0F);
         var12++;
      }
   }

   public boolean q(ModeValue value, int keyCode, int scanCode, int modifiers, 树何友何树树何何树树 componentsInstance) {
      return false;
   }

   private float A() {
      return Cherish.instance.t().V(18).D("\uea56");
   }

   private void M(GuiGraphics guiGraphics, float x, float y, float animationProgress, int color) {
      float rotation = animationProgress * 180.0F;
      何何友友树何树何友树 arrowFont = Cherish.instance.t().V(18);
      float charWidth = arrowFont.D("\uea56");
      float charHeight = arrowFont.x();
      guiGraphics.pose().pushPose();
      guiGraphics.pose().translate(x, y, 0.0F);
      guiGraphics.pose().mulPose(Axis.ZP.rotation((float)Math.toRadians(rotation)));
      float xOffset = -charWidth / 2.0F;
      float yOffset = -charHeight / 2.0F + 1.0F;
      arrowFont.q(guiGraphics.pose(), "\uea56", xOffset, yOffset, color);
      guiGraphics.pose().popPose();
   }

   public boolean H(
      ModeValue value, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 树何友何树树何何树树 componentsInstance
   ) {
      友友树何何友树树友树.V();
      if (button == 0) {
         友树何友何友何树树树 fm = Cherish.instance.t();
         何何友友树何树何友树 fontForMetrics = null;
         if (fm != null) {
            fontForMetrics = fm.H(18);
            if (fontForMetrics == null) {
               fontForMetrics = fm.H(18);
            }

            if (fontForMetrics == null) {
               fontForMetrics = fm.H(18);
            }

            if (fontForMetrics == null) {
               fontForMetrics = fm.H(18);
            }
         }

         if (fontForMetrics != null) {
            float maxModeNameWidth = this.v(value, fontForMetrics);
            float arrowIconActualWidth = this.A();
            float var10000 = 5.0F + maxModeNameWidth + 5.0F + arrowIconActualWidth + 5.0F;
         }

         null.println("ModeValueRenderer: Could not obtain a valid font for click metrics. Using fixed width 70f.");
         float boxX = x + width - 77.0F;
         float boxY = middleY - 5.0F;
         if (mouseX >= boxX && mouseX <= boxX + 70.0F && mouseY >= boxY && mouseY <= boxY + 10.0F) {
            boolean currentExpandedState = componentsInstance.何树何树友何何何树友.getOrDefault(value, false);
            componentsInstance.何树何树友何何何树友.put(value, !currentExpandedState);
            return true;
         }

         boolean isExpanded = componentsInstance.何树何树友何何何树友.getOrDefault(value, false);
         float expandAnimation = componentsInstance.树友树何何友树友友何.getOrDefault(value, 0.0F);
         int displayedOptionsCount = 0;
         String[] optionDisplayAreaStartY = value.n();
         int optionRenderY = optionDisplayAreaStartY.length;
         int var26 = 0;
         if (0 < optionRenderY) {
            String modeValue = optionDisplayAreaStartY[0];
            if (!modeValue.equals(value.getValue())) {
               displayedOptionsCount++;
            }

            var26++;
         }

         if (isExpanded && expandAnimation > 0.8F && displayedOptionsCount > 0) {
            float optionDisplayAreaStartYx = boxY + 10.0F;
            float optionRenderYx = optionDisplayAreaStartYx + 2.0F;
            String[] var36 = value.n();
            int var37 = var36.length;
            int var28 = 0;
            if (0 < var37) {
               String mode = var36[0];
               if (mode.equals(value.getValue())) {
               }

               if (mouseX >= boxX && mouseX <= boxX + 70.0F && mouseY >= optionRenderYx && mouseY <= optionRenderYx + 12.0F) {
                  value.G(mode);
                  componentsInstance.何树何树友何何何树友.put(value, false);
                  return true;
               }

               float var39 = optionRenderYx + 12.0F;
               var28++;
            }
         }
      }

      return false;
   }

   public void K(
      GuiGraphics guiGraphics,
      ModeValue value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      何何友友树何树何友树 settingNameFont,
      何何友友树何树何友树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      树何友何树树何何树树 componentsInstance
   ) {
      友友树何何友树树友树.V();
      float maxModeNameWidth = this.v(value, settingNameFont);
      float arrowIconActualWidth = this.A();
      float currentDynamicModeBoxWidth = 5.0F + maxModeNameWidth + 5.0F + arrowIconActualWidth + 5.0F;
      componentsInstance.何树何树友何何何树友.getOrDefault(value, false);
      float expandAnimation = componentsInstance.树友树何何友树友友何.getOrDefault(value, 0.0F);
      if (Math.abs(expandAnimation - 1.0F) > 0.001F) {
         float var54 = expandAnimation + (1.0F - expandAnimation) * 0.15F * partialTicks * 5.0F;
         expandAnimation = Math.max(0.0F, Math.min(1.0F, var54));
         componentsInstance.树友树何何友树友友何.put(value, expandAnimation);
      }

      float boxX = x + width - (currentDynamicModeBoxWidth + 7.0F);
      float boxY = middleY - 5.0F;
      float fullOptionsAreaHeight = 0.0F;
      int displayedOptionsCount = 0;
      String[] currentAnimatedOptionsHeight = value.n();
      int currentMode = currentAnimatedOptionsHeight.length;
      int currentModeTextWidth = 0;
      if (0 < currentMode) {
         String modeValue = currentAnimatedOptionsHeight[0];
         if (!modeValue.equals(value.getValue())) {
            fullOptionsAreaHeight = 12.0F;
            displayedOptionsCount++;
         }

         currentModeTextWidth++;
         Module.V(new Module[2]);
      }

      if (displayedOptionsCount > 0) {
         fullOptionsAreaHeight += 2.0F;
      }

      float currentAnimatedOptionsHeightx = fullOptionsAreaHeight * expandAnimation;
      RenderUtils.drawRoundedRect(guiGraphics.pose(), boxX, boxY, currentDynamicModeBoxWidth, 10.0F + currentAnimatedOptionsHeightx, 2.0, darkBgColor);
      String currentModex = value.getValue();
      float currentModeTextWidthx = settingNameFont.D(currentModex);
      float modeTextX = boxX + 5.0F + (maxModeNameWidth - currentModeTextWidthx) / 2.0F + 2.0F;
      float modeTextY = boxY + (10.0F - settingNameFont.x()) / 2.0F + 0.5F;
      settingNameFont.q(guiGraphics.pose(), currentModex, modeTextX, modeTextY, Color.WHITE.getRGB());
      float arrowCenterX = boxX + 5.0F + maxModeNameWidth + 5.0F + arrowIconActualWidth / 2.0F;
      float arrowY = boxY + 5.0F;
      this.M(guiGraphics, arrowCenterX, arrowY, expandAnimation, Color.WHITE.getRGB());
      if (expandAnimation > 0.01F && displayedOptionsCount > 0) {
         float optionDisplayAreaStartY = boxY + 10.0F;
         float optionContentActualStartY = optionDisplayAreaStartY + 2.0F;
         guiGraphics.enableScissor(
            (int)boxX, (int)optionDisplayAreaStartY, (int)(boxX + currentDynamicModeBoxWidth), (int)(optionDisplayAreaStartY + currentAnimatedOptionsHeightx)
         );
         ClientUtils.D(131325480669526L);
         HashMap<String, Float> optionHovers = componentsInstance.友友友友友树何树何树.computeIfAbsent(value.r(), k -> new HashMap<>());
         String[] var46 = value.n();
         int var47 = var46.length;
         int var48 = 0;
         if (0 < var47) {
            String mode = var46[0];
            if (mode.equals(value.getValue())) {
            }

            if (mouseX >= boxX
               && mouseX <= boxX + currentDynamicModeBoxWidth
               && mouseY >= optionContentActualStartY
               && mouseY <= optionContentActualStartY + 12.0F
               && mouseY < optionDisplayAreaStartY + currentAnimatedOptionsHeightx) {
            }

            float hoverAnim = optionHovers.getOrDefault(mode, 0.0F);
            if (Math.abs(hoverAnim - 1.0F) > 0.001F) {
               float var61 = hoverAnim + (1.0F - hoverAnim) * 0.2F * partialTicks * 5.0F;
               hoverAnim = Math.max(0.0F, Math.min(1.0F, var61));
               optionHovers.put(mode, hoverAnim);
            }

            if (hoverAnim > 0.01F) {
               Color hoverColor = new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), (int)(hoverAnim * 100.0F));
               RenderUtils.q(
                  guiGraphics.pose(),
                  (int)boxX,
                  (int)optionContentActualStartY,
                  (int)(boxX + currentDynamicModeBoxWidth),
                  (int)(optionContentActualStartY + 12.0F),
                  137876390830295L,
                  hoverColor.getRGB()
               );
            }

            settingNameFont.q(
               guiGraphics.pose(), mode, boxX + 5.0F, optionContentActualStartY + (12.0F - settingNameFont.x()) / 2.0F + 0.5F, Color.WHITE.getRGB()
            );
            float var10000 = optionContentActualStartY + 12.0F;
            var48++;
         }

         guiGraphics.disableScissor();
      }
   }

   private static String HE_SHU_YOU() {
      return "何建国230622195906030014";
   }

   public boolean Q(ModeValue value, char chr, int modifiers, 树何友何树树何何树树 componentsInstance) {
      return false;
   }
}
