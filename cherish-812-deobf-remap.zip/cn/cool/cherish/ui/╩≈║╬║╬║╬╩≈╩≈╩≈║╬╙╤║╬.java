package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.animations.树友何何何友友树何友;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;

public class 树何何何树树树何友何 implements IWrapper, 何树友 {
   private static final 树友何何何友友树何友 友树树友树树树友友友;
   private static final 树友树友友何何树何何 友何何何树友何友友树;
   private static final List<树何何何树树树何友何.何何何友树何树友树何> 何树何树树何友何友树;
   private static boolean 树树友何树树友何何树;
   private static String[] 何树树树何友何友何树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long f;
   private static final Object[] g = new Object[28];
   private static final String[] h = new String[28];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(756634737562329649L, 4561645208102735793L, MethodHandles.lookup().lookupClass()).a(271980797743736L);
      // $VF: monitorexit
      a = var10000;
      long var14 = a ^ 72813449378425L;
      long var16 = var14 ^ 86249817901557L;
      long var18 = var14 ^ 97654736153L;
      a();
      String[] var21 = new String[4];
      b<"T">(var21, -2128827798116502700L, var14);
      Cipher var5;
      Cipher var22 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(var14 << var6 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[2];
      int var10 = 0;
      char var8 = 24;
      int var7 = -1;

      while (true) {
         String var26 = b(
               var5.doFinal(
                  "¾\u0018Þµm®\u009d\u0086e9\"\u0018Ç¼¼\t¸\u0088à\u0011\u0080rbï \u0007R@\u0083¥Üh)W\u0007\u0010Ã0\u000e$\u0003Ð¯DÊ\u007fìy\u0082}é¢óÖ2ê\u009c"
                     .substring(++var7, var7 + var8)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var12[var10++] = var26;
         if ((var7 += var8) >= 57) {
            b = var12;
            c = new String[2];
            Cipher var0;
            Cipher var23 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(var14 << var1 * 8 >>> 56);
            }

            var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            byte[] var4 = var0.doFinal(new byte[]{103, 87, -27, 83, 36, -45, 78, 110});
            long var29 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            f = var29;
            友树树友树树树友友友 = new 树友何何何友友树何友(var18);
            友何何何树友何友友树 = new 树友树友友何何树何何(var16);
            何树何树树何友何友树 = new ArrayList<>();
            return;
         }

         var8 = "¾\u0018Þµm®\u009d\u0086e9\"\u0018Ç¼¼\t¸\u0088à\u0011\u0080rbï \u0007R@\u0083¥Üh)W\u0007\u0010Ã0\u000e$\u0003Ð¯DÊ\u007fìy\u0082}é¢óÖ2ê\u009c"
            .charAt(var7);
      }
   }

   private static void I(PoseStack poseStack, LivingEntity target, float x, float y) {
      long a = 树何何何树树树何友何.a ^ 104943298144753L;
      long ax = a ^ 129722311059003L;
      long axx = a ^ 8147075446680L;
      b<"T">(-1010621987167493402L, a);
      if (b<"Ù">(-1009157063080562594L, a).V(f, true, ax)) {
         b<"Ù">(-1008902602229232402L, a).removeIf(p -> {
            long axxx = 树何何何树树树何友何.a ^ 52315887984381L;
            b<"T">(5113270366122546666L, axxx);
            p.H();
            return b<"J">(p, 5112546269824202577L, axxx) <= 0.0F;
         });
      }

      Iterator particleColor = b<"Ù">(-1008902602229232402L, a).iterator();
      if (particleColor.hasNext()) {
         树何何何树树树何友何.何何何友树何树友树何 p = (树何何何树树树何友何.何何何友树何树友树何)particleColor.next();
         float var10002 = x + b<"J">(p, -1008860586725293429L, a);
         float var10003 = y + b<"J">(p, -1009008988535470240L, a);
         float var10004 = b<"J">(p, -1009363757197464139L, a);
         Object[] var10007 = new Object[]{null, null, null, null, null, p.n()};
         var10007[4] = var10004;
         var10007[3] = var10003;
         var10007[2] = var10002;
         var10007[1] = axx;
         var10007[0] = poseStack;
         ShaderUtils.s(var10007);
      }

      if (b<"J">(target, -1009889630683634262L, a) == 10 && !b<"Ù">(-1009285863051234758L, a)) {
         if (mc.player == null) {
            return;
         }

         Color particleColorx = b<"Ù">(-1009754111244944154L, a);
         RandomSource r = mc.player.getRandom();
         int i = 0;
         b<"Ù">(-1008902602229232402L, a)
            .add(
               new 树何何何树树树何友何.何何何友树何树友树何(
                  26.0F, 26.0F, (r.nextFloat() - 0.5F) * 2.8F, (r.nextFloat() - 0.5F) * 2.8F, r.nextFloat() * 3.0F + 1.0F, particleColorx
               )
            );
         i++;
         b<"S">(true, -1009285863051234758L, a);
      }

      if (b<"J">(target, -1009889630683634262L, a) <= 0) {
         b<"S">(false, -1009285863051234758L, a);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (h[var4] != null) {
         return var4;
      } else {
         Object var5 = g[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 33;
               case 1 -> 7;
               case 2 -> 52;
               case 3 -> 35;
               case 4 -> 0;
               case 5 -> 63;
               case 6 -> 55;
               case 7 -> 50;
               case 8 -> 47;
               case 9 -> 44;
               case 10 -> 57;
               case 11 -> 37;
               case 12 -> 42;
               case 13 -> 61;
               case 14 -> 1;
               case 15 -> 30;
               case 16 -> 43;
               case 17 -> 58;
               case 18 -> 11;
               case 19 -> 10;
               case 20 -> 17;
               case 21 -> 8;
               case 22 -> 3;
               case 23 -> 62;
               case 24 -> 41;
               case 25 -> 46;
               case 26 -> 29;
               case 27 -> 49;
               case 28 -> 15;
               case 29 -> 12;
               case 30 -> 31;
               case 31 -> 28;
               case 32 -> 24;
               case 33 -> 9;
               case 34 -> 5;
               case 35 -> 2;
               case 36 -> 21;
               case 37 -> 56;
               case 38 -> 60;
               case 39 -> 36;
               case 40 -> 53;
               case 41 -> 26;
               case 42 -> 25;
               case 43 -> 59;
               case 44 -> 48;
               case 45 -> 27;
               case 46 -> 38;
               case 47 -> 13;
               case 48 -> 32;
               case 49 -> 20;
               case 50 -> 18;
               case 51 -> 51;
               case 52 -> 23;
               case 53 -> 19;
               case 54 -> 14;
               case 55 -> 6;
               case 56 -> 22;
               case 57 -> 45;
               case 58 -> 4;
               case 59 -> 34;
               case 60 -> 16;
               case 61 -> 54;
               case 62 -> 40;
               default -> 39;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            h[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何何树树树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'J' && var8 != 'h' && var8 != 217 && var8 != 'S') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'l') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'T') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'J') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'h') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 217) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         g[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = g[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      g[0] = "#\u0011\u00030IN,QN;CS)\fE}SHn桮佸伆佳栰桑桮佸厘佳";
      g[1] = "&\u0015p\n\u0004VS5{\u0005\u0015\u0019.-h\u0002\u001cPF";
      g[2] = boolean.class;
      h[2] = "java/lang/Boolean";
      g[3] = "y_gT*iv\u001f*_ tsB!\u00190o4栠伜佢伐栗栋栠伜叼伐\"住佤伜叼桔体栋叺桘佢";
      g[4] = float.class;
      h[4] = "java/lang/Float";
      g[5] = "{j]pyyt*\u0010{sdqw\u001b=cbqh\u0000=标叝栉叏厸但佃标位佑";
      g[6] = "?\u0017UhF\u00184\u0018D':\u0001;\u0002Jd\r1-\u0015Fy\u001c\u001d:\u0018";
      g[7] = "71\u0010zF4)9\n5$(.$";
      g[8] = "/\u001f@`Et/\u001fW<I{5TC!Zq%TQ \\t5\u0003\u001a\u0002Ak(\u0014S\u000bFi(\u000eM";
      g[9] = int.class;
      h[9] = "java/lang/Integer";
      g[10] = "H\u0017\u0003\u0003\u00073U\u0002[!F>M\u0004";
      g[11] = "?\u0015\u0003rdD0UNynY5\bE?~_5\u0017^?jE5\u0016LebD2\b\u0003栀叀佾伉伮另叚栚佾厗";
      g[12] = " \u0011z;\u0000\u000bU1q4\u0011D()b3\u0018\r@";
      g[13] = void.class;
      h[13] = "java/lang/Void";
      g[14] = ":8\u001a.<T17\u000ba]Z:<\u000f;";
      g[15] = "\t\f=f\u001a\u001c^\u0007 _7nW\u001c&f\u001e_\u0003\u0018>=x";
      g[16] = "G=T77l\u00106I\u000e桌标只伋栨栗厖佃佴桏17(yT+Pe-{@";
      g[17] = "FIx+-W\u0013\t.{\u0014佦县厺叔伛栍司桥伤佊F/\u0003\u0012\u001ak>q\u0005\u0003\u0018";
      g[18] = "oHL:7\u00048CQ\u0003厖伫作佾栰叀伈厵参栺)82\tcEJjd\u0012x";
      g[19] = "7\u0007\u001f>o\u001c`\f\u0002\u0007dne\rKlc\u0013)\u0010\u0002c\rR8]\u0011ip\u001e%\u0014\u001e\u0007";
      g[20] = "\u0015G\u001b\u001b~\u0018@\u0007MKG厷佲伪厷厵会伩佲厴厷v|LA\u0014\b\u000e\"JP\u0016";
      g[21] = "@E\b[\u000b\u001a\u0015\u0005^\u000b2伫厹伨桾叵栫桯档伨厤6\tN\u0014\u0016\u001bNWH\u0005\u0014";
      g[22] = "{r\u0001\\z2.2W\fC厝伜桛桷史伞桇桘桛厭1xf/!\u0012I&`>#";
      g[23] = "@\u0005\u001eL\t\u0007\u0017\u000e\u0003u伶桬佳桷桢伨厨伨叭桷{I\u001b\u0017R^\u0017\t\f\u0014B";
      g[24] = ":u$-C}m~9\u0014叢栖桍叝桘栍核双厗叝A$\u001fq?s0rQ74";
      g[25] = "\u001fgl\u0019\tp\\'}\nbtvf7A[$v\\1\u001a\u0012wFd5\u001c\u001aj";
      g[26] = "*'c\u001asg},~#\\\u0015t7x\u001aw$ 3`A\u0011$}4mI`.8(x#";
      g[27] = "61fS=yn!`W\u0004YI\u001cC`\u00049e$a\u0014{au\"e";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何何树树树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9523;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树何何何树树树何友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (var5 instanceof String) {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         g[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void E(String[] var0) {
      何树树树何友何友何树 = var0;
   }

   public static String[] G() {
      return 何树树树何友何友何树;
   }

   private static String HE_JIAN_GUO() {
      return "何树友为什么濒天了";
   }

   private static class 何何何友树何树友树何 implements 何树友 {
      float 友何树树友何树树树友;
      float 友何何友友何何何友友;
      float 树树友友何树树友树何;
      float 何树树树友友友何树何;
      float 何友友友何树友树何何;
      float 何友何树友树树树何友;
      final Color 树何友何何何树何何友;
      private static final long a;
      private static final Object[] b = new Object[16];
      private static final String[] c = new String[16];
      private static int _解放村多种2队1144号 _;

      public 何何何友树何树友树何(float x, float y, float dX, float dY, float size, Color color) {
         long a = 树何何何树树树何友何.何何何友树何树友树何.a ^ 33232619374047L;
         super();
         a<"l">(this, 26.0F, 585428311642724744L, a);
         a<"l">(this, 26.0F, 585308106900308817L, a);
         a<"l">(this, dX, 585137834333711522L, a);
         a<"l">(this, dY, 584807027928223653L, a);
         a<"l">(this, size, 584933486753705845L, a);
         this.树何友何何何树何何友 = color;
         a<"l">(this, 255.0F, 585250889727845118L, a);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-1879983139993826039L, 1188648161014604108L, MethodHandles.lookup().lookupClass()).a(170904679581624L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public Color n() {
         long a = 树何何何树树树何友何.何何何友树何树友树何.a ^ 6830701285091L;
         return new Color(
            a<"ì">(this, 226182597248967419L, a).getRed(),
            a<"ì">(this, 226182597248967419L, a).getGreen(),
            a<"ì">(this, 226182597248967419L, a).getBlue(),
            (int)a<"ì">(this, 226062454026316226L, a)
         );
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树何何何树树树何友何$何何何友树何树友树何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 236 && var8 != 'l' && var8 != 'X' && var8 != 'w') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 235) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 170) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 236) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'l') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'X') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 46;
                  case 1 -> 57;
                  case 2 -> 24;
                  case 3 -> 16;
                  case 4 -> 38;
                  case 5 -> 52;
                  case 6 -> 55;
                  case 7 -> 9;
                  case 8 -> 45;
                  case 9 -> 34;
                  case 10 -> 48;
                  case 11 -> 32;
                  case 12 -> 22;
                  case 13 -> 44;
                  case 14 -> 15;
                  case 15 -> 12;
                  case 16 -> 53;
                  case 17 -> 4;
                  case 18 -> 5;
                  case 19 -> 2;
                  case 20 -> 35;
                  case 21 -> 60;
                  case 22 -> 1;
                  case 23 -> 25;
                  case 24 -> 8;
                  case 25 -> 43;
                  case 26 -> 13;
                  case 27 -> 0;
                  case 28 -> 19;
                  case 29 -> 62;
                  case 30 -> 50;
                  case 31 -> 54;
                  case 32 -> 39;
                  case 33 -> 11;
                  case 34 -> 14;
                  case 35 -> 37;
                  case 36 -> 31;
                  case 37 -> 51;
                  case 38 -> 47;
                  case 39 -> 10;
                  case 40 -> 27;
                  case 41 -> 21;
                  case 42 -> 49;
                  case 43 -> 63;
                  case 44 -> 36;
                  case 45 -> 61;
                  case 46 -> 41;
                  case 47 -> 7;
                  case 48 -> 42;
                  case 49 -> 30;
                  case 50 -> 23;
                  case 51 -> 26;
                  case 52 -> 58;
                  case 53 -> 33;
                  case 54 -> 56;
                  case 55 -> 29;
                  case 56 -> 40;
                  case 57 -> 28;
                  case 58 -> 6;
                  case 59 -> 3;
                  case 60 -> 59;
                  case 61 -> 18;
                  case 62 -> 17;
                  default -> 20;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "_4\u0019P\u0019\u0013PtT[\u0013\u000eU)_\u001d\u0003\u0015\u0012桋佢佦伣桭栭桋佢司伣X佩伏佢司桧伩栭厑栦佦";
         b[1] = float.class;
         c[1] = "java/lang/Float";
         b[2] = "\f}\u0015r\u000e\u0016\u0003=Xy\u0004\u000b\u0006`S?\u0014\u0010A栂佮佄伴桨桾栂佮叚伴";
         b[3] = "E\u001fk\u0016_50?`\u0019NzM's\u001eG3%";
         b[4] = "|(q\\\u001c5w'`\u0013`,x=nPW\u001cn*bMF0y'";
         b[5] = "+H:N\u0004E6]blEH.[";
         b[6] = "~2b\u001a$'u=sUE)~6w\u000f";
         b[7] = "EZ\u0013=\u0016`H\u0004V\u0007估栞桡栦只叄厮佚桡佢)~\u001cx\u0000UEz\u000b6";
         b[8] = "43'9\"\u007f6<t!L\u000b\rd$&6)}8f3.D";
         b[9] = "p\u001e4=k\\}@q\u0007位司厎厸体栞叓栢伐伦\u000e~aD5\u0011bzv\n";
         b[10] = "4+:a\u007fn9u\u007f[栝栐及厍佝桂栝及栐伓\u0000\"uvq$l&b8";
         b[11] = "\u0011M1.HT\u001c\u0013t\u0014Z3\u0017\u00131qYZQ\u0012d.3\b\u0017\u0012n~ZN\u0016G1\u0014";
         b[12] = "H+0.\rZEuu\u0014厵你伨厍叉佉伫你厶厍\nm\u0007B\r$fi\u0010\f";
         b[13] = "N\u000b\u0005'O&CU@\u001d佩厂伮桷叼栄栭桘伮厭?dE>\u000b\u0004S`Rp";
         b[14] = "\u0004\u0011ibob\tO,X受佘栠桭厐伅栍栜栠厷S!ezA\u001e?%r4";
         b[15] = "4\u001eTP{O9@\u0011j栙併及伦伳伷栙併佔厸nQa\u0015v\n\u0003\rlEi";
      }

      public void H() {
         long a = 树何何何树树树何友何.何何何友树何树友树何.a ^ 105962488801062L;
         a<"l">(this, a<"ì">(this, 3091340250888534897L, a) + a<"ì">(this, 3091630590624140891L, a), 3091340250888534897L, a);
         a<"ª">(3091507202823625099L, a);
         a<"l">(this, a<"ì">(this, 3091176858034315688L, a) + a<"ì">(this, 3090833299206597980L, a), 3091176858034315688L, a);
         a<"l">(this, a<"ì">(this, 3091630590624140891L, a) * 0.97F, 3091630590624140891L, a);
         a<"l">(this, a<"ì">(this, 3090833299206597980L, a) * 0.97F, 3090833299206597980L, a);
         a<"l">(this, a<"ì">(this, 3091234007259381767L, a) - 4.0F, 3091234007259381767L, a);
         if (a<"ì">(this, 3091234007259381767L, a) < 0.0F) {
            a<"l">(this, 0.0F, 3091234007259381767L, a);
         }
      }

      private static String LIU_YA_FENG() {
         return "行走的50万——何炜霖";
      }
   }
}
