package cn.cool.cherish.ui;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import com.mojang.blaze3d.platform.InputConstants;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;

public class 树何树树何树友树何何 implements 树何何何树友友友友友<何何何友友何树何何何>, IWrapper,  {
   private static final float 何友何树树何友友树树 = 7.0F;
   private static final float 树何友友友何何何树友 = 10.0F;
   private static final float 何友何友友何友树友树 = 70.0F;
   private long 树友树树何友树友何树 = 0L;
   private static final int 友何何何树何何树树树;
   private static final long a;
   private static final String b;
   private static final long[] c;
   private static final Long[] e;
   private static final Map f;
   private static final Object[] g = new Object[16];
   private static final String[] h = new String[16];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-1426573216959866965L, -6953258432084041208L, MethodHandles.lookup().lookupClass()).a(83537044799003L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var20;
      Cipher var22 = var20 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var21 = 1; var21 < 8; var21++) {
         var10003[var21] = (byte)(94541254978968L << var21 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var28 = b(var20.doFinal("ÜêÐÐD¾p£".getBytes("ISO-8859-1"))).intern();
      int var10001 = -1;
      b = var28;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(94541254978968L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var17 = var13.doFinal(new byte[]{-28, 109, -86, 73, -87, -49, 93, -26});
      long var30 = (var17[0] & 255L) << 56
         | (var17[1] & 255L) << 48
         | (var17[2] & 255L) << 40
         | (var17[3] & 255L) << 32
         | (var17[4] & 255L) << 24
         | (var17[5] & 255L) << 16
         | (var17[6] & 255L) << 8
         | var17[7] & 255L;
      var10001 = (byte)-1;
      友何何何树何何树树树 = (int)var30;
      f = new HashMap(13);
      Cipher var0;
      Cipher var24 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(94541254978968L << var1 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[3];
      int var3 = 0;
      byte var2 = 0;

      do {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = "\u000eìwñdôi.kH\u001cØèÂt\u0080\u0000ØécD6\u0002\u00ad".substring(var10001, var2).getBytes("ISO-8859-1");
         var10001 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         byte var34 = -1;
         var6[var10001] = var10004;
      } while (var2 < 24);

      c = var6;
      e = new Long[3];
   }

   public float D(何何何友友何树何何何 value, 树何友何树树何何树树 componentsInstance) {
      return 0.0F;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (h[var4] != null) {
         return var4;
      } else {
         Object var5 = g[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 45;
               case 1 -> 49;
               case 2 -> 32;
               case 3 -> 57;
               case 4 -> 58;
               case 5 -> 42;
               case 6 -> 13;
               case 7 -> 39;
               case 8 -> 19;
               case 9 -> 3;
               case 10 -> 28;
               case 11 -> 40;
               case 12 -> 50;
               case 13 -> 35;
               case 14 -> 23;
               case 15 -> 22;
               case 16 -> 5;
               case 17 -> 62;
               case 18 -> 12;
               case 19 -> 15;
               case 20 -> 59;
               case 21 -> 0;
               case 22 -> 36;
               case 23 -> 21;
               case 24 -> 4;
               case 25 -> 10;
               case 26 -> 54;
               case 27 -> 48;
               case 28 -> 2;
               case 29 -> 43;
               case 30 -> 14;
               case 31 -> 7;
               case 32 -> 34;
               case 33 -> 9;
               case 34 -> 47;
               case 35 -> 20;
               case 36 -> 46;
               case 37 -> 52;
               case 38 -> 55;
               case 39 -> 33;
               case 40 -> 31;
               case 41 -> 53;
               case 42 -> 27;
               case 43 -> 44;
               case 44 -> 30;
               case 45 -> 61;
               case 46 -> 17;
               case 47 -> 29;
               case 48 -> 41;
               case 49 -> 8;
               case 50 -> 60;
               case 51 -> 56;
               case 52 -> 38;
               case 53 -> 51;
               case 54 -> 18;
               case 55 -> 6;
               case 56 -> 25;
               case 57 -> 11;
               case 58 -> 1;
               case 59 -> 24;
               case 60 -> 26;
               case 61 -> 37;
               case 62 -> 16;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            h[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'u' && var8 != 193 && var8 != 'h' && var8 != 'K') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'H') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'B') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'u') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 193) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'h') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何树树何树友树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         g[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = g[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      g[0] = "I'L\u0010\u0014*Fg\u0001\u001b\u001e7C:\n]\u000e,\u0004厂厩桢伮伐叡桘桳厸桪";
      g[1] = boolean.class;
      h[1] = "java/lang/Boolean";
      g[2] = "DK['c\u001fK\u000b\u0016,i\u0002NV\u001djy\u0019\t栴传厏余桡栶佰传桕栝";
      g[3] = "\u0002e\u000bb#,\r%Fi)1\bxM/:\"\r~@/%.\u0011g\u000b佔伙伖厪叀佰栐伙伖伴";
      g[4] = "f\u001fsbI)i_>iC4l\u00025/S/+桠伈栐样伓栔厺桌佔佳";
      g[5] = "\u001fCM'\u0013\u0003\u0014L\\ho\u001a\u001bVR+X*\rA^6I\u0006\u001aL";
      g[6] = "~\u000es<{\u0013c\u001b+\u001e:\u001e{\u001d";
      g[7] = long.class;
      h[7] = "java/lang/Long";
      g[8] = "\u0016EZbAR\u001dJK- \\\u0016AOw";
      g[9] = "0PzJkd=\\`{\u0004\\p^:\u0014!ls\u0015m{";
      g[10] = "\u0018@\u001a\u001c_-\u0018\u0006A\u0012\"栊叢佢叠厮栻低核佢叠m_c\u001aPX]\\(M";
      g[11] = "\"0F7\u001d\u0015#fXoo桼叚栘栿体厬桼叚作栿\u000eS\u0017cbOmQ\u0000xc";
      g[12] = "m\u001bpz:(`\u0017jKY\u0010-\u00150$p .^gK";
      g[13] = "t\rF&K\u000bu[X~9\u0012O\u0000\u001ea\\\u0005wEX`\u0000{s\u0004XzGC6BY&9";
      g[14] = "\u0015)\u00184-\u0005GwK8Aki\b{\u000bA\bIvU*pZ\u0017%Y";
      g[15] = "\t\u0001\u0006?{!\tG]1\u0006佂右桧栦厍佛佂右桧栦N<!ZBTswuV\u001c";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何树树何树友树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25541;
      if (e[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])f.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            f.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/树何树树何树友树何何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         e[var3] = var15;
      }

      return e[var3];
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (var5 instanceof String) {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         g[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void q(何何何友友何树何何何 value, double mouseX, double mouseY, int button, 树何友何树树何何树树 componentsInstance) {
   }

   public boolean z(
      何何何友友何树何何何 value, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 树何友何树树何何树树 componentsInstance
   ) {
      友友树何何友树树友树.Z();
      float boxX = x + width - 77.0F;
      float boxY = middleY - 5.0F;
      if (button == 0) {
         if (mouseX >= boxX && mouseX <= boxX + 70.0F && mouseY >= boxY && mouseY <= boxY + 10.0F) {
            if (componentsInstance.何友树树友何何友树树 != value) {
               componentsInstance.何友树树友何何友树树 = value;
               componentsInstance.树友何友友树何树何友 = true;
            }

            return true;
         }

         if (componentsInstance.何友树树友何何友树树 == value) {
            componentsInstance.何友树树友何何友树树 = null;
            componentsInstance.树友何友友树何树何友 = false;
         }
      }

      return false;
   }

   public void M(
      GuiGraphics guiGraphics,
      何何何友友何树何何何 value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      何何友友树何树何友树 valueNameFont,
      何何友友树何树何友树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      树何友何树树何何树树 componentsInstance
   ) {
      float boxX = x + width - 77.0F;
      友友树何何友树树友树.Z();
      float boxY = middleY - 5.0F;
      RenderUtils.drawRoundedRect(guiGraphics.pose(), boxX, boxY, 70.0, 10.0, 2.0, darkBgColor);
      String displayValue = value.getValue();
      if (displayValue.isEmpty() && componentsInstance.何友树树友何何友树树 != value) {
         displayValue = "Type...";
      }

      String visibleText = displayValue;
      float textWidth = valueDisplayFont.D(displayValue);
      if (textWidth > 62.0F && !displayValue.isEmpty()) {
         visibleText = displayValue.substring(1);
         float var10000 = valueDisplayFont.D(visibleText);
      }

      float textX = boxX + 4.0F;
      float textY = boxY + (10.0F - valueDisplayFont.x()) / 2.0F + 0.5F;
      valueDisplayFont.q(guiGraphics.pose(), visibleText, textX, textY, Color.WHITE.getRGB());
      if (componentsInstance.何友树树友何何友树树 == value && System.currentTimeMillis() % 1000L < 500L) {
         float cursorX = textX + valueDisplayFont.D(visibleText);
         RenderUtils.drawRectangle(guiGraphics.pose(), cursorX, textY - 1.0F, 1.0F, valueDisplayFont.x() + 1, Color.WHITE.getRGB());
      }

      if (componentsInstance.何友树树友何何友树树 == value) {
         int borderColor = accentColor.getRGB();
         RenderUtils.drawRectangle(guiGraphics.pose(), boxX - 1.0F, boxY - 1.0F, 72.0F, 1.0F, borderColor);
         RenderUtils.drawRectangle(guiGraphics.pose(), boxX - 1.0F, boxY + 10.0F, 72.0F, 1.0F, borderColor);
         RenderUtils.drawRectangle(guiGraphics.pose(), boxX - 1.0F, boxY, 1.0F, 10.0F, borderColor);
         RenderUtils.drawRectangle(guiGraphics.pose(), boxX + 70.0F, boxY, 1.0F, 10.0F, borderColor);
      }
   }

   public boolean R(何何何友友何树何何何 value, char chr, int modifiers, 树何友何树树何何树树 componentsInstance) {
      友友树何何友树树友树.V();
      if (componentsInstance.何友树树友何何友树树 == value && chr >= ' ' && chr != 167) {
         String currentText = value.getValue();
         value.G(currentText + chr);
         return true;
      } else {
         return false;
      }
   }

   public boolean Q(何何何友友何树何何何 value, int keyCode, int scanCode, int modifiers, 树何友何树树何何树树 componentsInstance) {
      友友树何何友树树友树.Z();
      if (componentsInstance.何友树树友何何友树树 == value) {
         String currentText = value.getValue();
         if (keyCode == 256 || keyCode == 257 || keyCode == 335) {
            componentsInstance.何友树树友何何友树树 = null;
            componentsInstance.树友何友友树何树何友 = false;
            return true;
         } else if (keyCode == 259) {
            if (!currentText.isEmpty()) {
               value.G(currentText.substring(0, currentText.length() - 1));
               this.树友树树何友树友何树 = System.currentTimeMillis();
            }

            return true;
         } else if (InputConstants.isKeyDown(mc.getWindow().getWindow(), 259) && !currentText.isEmpty()) {
            if (System.currentTimeMillis() - this.树友树树何友树友何树 > 50L) {
               value.G(currentText.substring(0, currentText.length() - 1));
               this.树友树树何友树友何树 = System.currentTimeMillis();
            }

            return true;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖诈骗";
   }

   public void G(何何何友友何树何何何 value, 树何友何树树何何树树 componentsInstance) {
   }
}
