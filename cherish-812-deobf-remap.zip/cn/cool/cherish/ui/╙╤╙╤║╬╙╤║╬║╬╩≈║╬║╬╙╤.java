package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.unsafe.UnsafeUtils;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import why.tree.friend.antileak.Fucker;

public class 友友何友何何树何何友 extends Screen implements 何树友 {
   private static String 树树何何友树友树友友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long e;
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[22];
   private static final String[] j = new String[22];
   private static String HE_JIAN_GUO;

   public 友友何友何何树何何友() {
      super(Component.literal("EULA Screen"));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(1043744068739933703L, -7638156140779812913L, MethodHandles.lookup().lookupClass()).a(225295069397230L);
      // $VF: monitorexit
      a = var10000;
      a();
      E(null);
      Cipher var16;
      Cipher var26 = var16 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var17 = 1; var17 < 8; var17++) {
         var10003[var17] = (byte)(39346959869519L << var17 * 8 >>> 56);
      }

      var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var23 = new String[5];
      int var21 = 0;
      String var20 = "ö/\u001e%\u009cXd\u001b\u0005\u000eÕ\u009b\u0096éKL\u0010Ñ\u001d\u0081\u009a\u001e\u0088\u0090¿\u001d7\u0012úÿVá\u0007\u0018\u008b\u0099\u0018È¥'\u009bQ\u008bG\u009b³êJL^OU\u00026¹ÊçH";
      short var22 = 58;
      char var19 = 16;
      int var25 = -1;

      label57:
      while (true) {
         String var27 = var20.substring(++var25, var25 + var19);
         int var10001 = -1;

         while (true) {
            String var38 = a(var16.doFinal(var27.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var23[var21++] = var38;
                  if ((var25 += var19) >= var22) {
                     b = var23;
                     c = new String[5];
                     Cipher var11;
                     Cipher var29 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(39346959869519L << var12 * 8 >>> 56);
                     }

                     var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var15 = var11.doFinal(new byte[]{78, 1, 79, -44, 61, -84, 125, -63});
                     long var42 = (var15[0] & 255L) << 56
                        | (var15[1] & 255L) << 48
                        | (var15[2] & 255L) << 40
                        | (var15[3] & 255L) << 32
                        | (var15[4] & 255L) << 24
                        | (var15[5] & 255L) << 16
                        | (var15[6] & 255L) << 8
                        | var15[7] & 255L;
                     var10001 = (byte)-1;
                     e = var42;
                     h = new HashMap(13);
                     Cipher var0;
                     Cipher var30 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(39346959869519L << var1 * 8 >>> 56);
                     }

                     var30.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "·7O\u0094y¯W\u0085i>\u001f3#O\u0017\u008f".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var46 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     f = var6;
                     g = new Long[2];
                     return;
                  }

                  var19 = var20.charAt(var25);
                  break;
               default:
                  var23[var21++] = var38;
                  if ((var25 += var19) < var22) {
                     var19 = var20.charAt(var25);
                     continue label57;
                  }

                  var20 = "Ò\"?å¥:\u0010l\u0013Yð\u0004S_Ðò\u0096)È?¢ê,ÄÅ\t\u0096=\u0012Ä@ïBã\u0088{±<á+\u0091e[Û¶ \u0004§ÕÈ~M\u0096Ñ\\MÂÇÿÓ\u0094ôcxÂ<\u00863L\u009d6$À \u0084¡1f¹tP\u0099n:ëØ\u009d\t\u0097Eæ\u0010\u0086\u008eÍ§\u0085mÞ\u008a¹âaR ÞcÍÎ\u001eM\u0016ÎÈbí\\\b»[t«Hþ¡´í\u009eÐ´\u0082Õ\u0095-\u008dÝ:@ì)\u0011.Ò\u0093t<ý*\u0080»»ý\u0089z\u0012ÓíY\u0089©P ô\u001e6Hn\r\u001dZ¢+#<öiñ'ün\u00124§\u001dÝm\u000e\u009c©åRÛ\u008cÿ¶t~z\u0013qãóa®¢Ï÷$º\u0002\u0091ãÖÖÓ\u0087Ï\u0090\b>È\u000eÆse!Ô\u0019M\u0090cÿ?^õ\u0011fdEKôiÕ\u0005]6c¡;\u001d\b\u0094\u0082,W\u0094øÇn\fC\u0015E\u0016Û";
                  var22 = 265;
                  var19 = 'H';
                  var25 = -1;
            }

            var27 = var20.substring(++var25, var25 + var19);
            var10001 = 0;
         }
      }
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12109;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/友友何友何何树何何友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友何友何何树何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友何友何何树何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      i[0] = ",8\t%:O#xD.0R&%Oh Ia桇佲伓桄叫桞伃栶厍桄";
      i[1] = "PP:\u0001T\f_\u0010w\n^\u0011ZM|LN\n\u001d叵叟伷台伶佦栯佁伷台";
      i[2] = "T\u000373K _\f&|68L\u000b/5";
      i[3] = void.class;
      j[3] = "java/lang/Void";
      i[4] = int.class;
      j[4] = "java/lang/Integer";
      i[5] = "iH\u0003U$af\bN^.|cUE\u0018&anSASeCeBXZ.";
      i[6] = "h\u0010\u0012%\u0004[\\3\u001deIPV.\u00188B\u0016^3\u0015>F]\u001d\u0011\u001e/_TVg";
      i[7] = "R^Deg{YQU*\u001bbVK[i,R@\\Wt=~WQ";
      i[8] = "\tdU|\tS=GZ<DX7Z_aO\u001e?GRgKU|eYvR\\7\u0013";
      i[9] = "K\u0012\b\u0000\u0011&K\u0012\u001f\\\u001d)QY\u001fB\u0015*K\u0003RI\t&\u000b1\u0013@\b";
      i[10] = "\u001fjVIt'\u0002\u007f\u000ek5*\u001ay";
      i[11] = "8\u000feM\u0018b3\u0000t\u0002yl8\u000bpX";
      i[12] = "r6\u007f\\\u0015\u0010l!6-Kv?f;\u0011\u0019v\u000ebyTOH\u007f4>\u0014[";
      i[13] = "z*7\u001b\b\u0004%}>\rwnF.u\u0003IW6 3\u0001\u0014<";
      i[14] = "rG:*\u0001KlPs[_-?\u0017~g\u000e-\u000e\u0017&b^\u0011cR3<P";
      i[15] = "\u0014:?0[T\n-vA&eQ3\"<\u0019^\u0013%*(k_R+%#V]\u0015h'A";
      i[16] = "k\u0013&\u0005\u001etu\u0004otqE.\u001a;\t\\~l\f3\u001d.";
      i[17] = "B\u0012u=`@\\\u0005<L9q\u0003\u00137rn\u001bLLw-PLQG2r:\u0003\u000e\u0007mL";
      i[18] = "#\u0014\u001bH@g=\u0003R9\u001e\u0001nD_\u0005K\u0001_@\u001d@\u001a?.\u0016Z\u0000\u000e";
      i[19] = "_!:\t\u00075\u000f>6\nc\u001b \u000fZ8c{\u000frz\u0011\u0012+\u0010~y";
      i[20] = "\u000eT*Z\bLQ\u0003#Lw*2PhBI\u001fB^.@\u0014t\bT,@\u0015I\n\u0013oBw";
      i[21] = "JL{P\u0001\"PJm\"桼桝佽厶佟栻伸伙佽桬\u0002H\\=R\u0011dRZ+";
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'z' && var8 != 226 && var8 != 'l' && var8 != 163) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 242) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'B') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'z') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 226) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'l') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友何友何何树何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6205;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友友何友何何树何何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 41;
               case 1 -> 46;
               case 2 -> 18;
               case 3 -> 32;
               case 4 -> 7;
               case 5 -> 14;
               case 6 -> 0;
               case 7 -> 60;
               case 8 -> 45;
               case 9 -> 55;
               case 10 -> 37;
               case 11 -> 25;
               case 12 -> 20;
               case 13 -> 40;
               case 14 -> 1;
               case 15 -> 58;
               case 16 -> 9;
               case 17 -> 62;
               case 18 -> 61;
               case 19 -> 47;
               case 20 -> 21;
               case 21 -> 22;
               case 22 -> 56;
               case 23 -> 8;
               case 24 -> 51;
               case 25 -> 36;
               case 26 -> 54;
               case 27 -> 17;
               case 28 -> 34;
               case 29 -> 28;
               case 30 -> 6;
               case 31 -> 53;
               case 32 -> 3;
               case 33 -> 16;
               case 34 -> 2;
               case 35 -> 39;
               case 36 -> 52;
               case 37 -> 63;
               case 38 -> 50;
               case 39 -> 27;
               case 40 -> 29;
               case 41 -> 35;
               case 42 -> 11;
               case 43 -> 10;
               case 44 -> 44;
               case 45 -> 33;
               case 46 -> 19;
               case 47 -> 24;
               case 48 -> 57;
               case 49 -> 15;
               case 50 -> 26;
               case 51 -> 49;
               case 52 -> 59;
               case 53 -> 4;
               case 54 -> 38;
               case 55 -> 12;
               case 56 -> 48;
               case 57 -> 42;
               case 58 -> 31;
               case 59 -> 23;
               case 60 -> 30;
               case 61 -> 43;
               case 62 -> 5;
               default -> 13;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static void E(String var0) {
      树树何何友树友树友友 = var0;
   }

   public static String W() {
      return 树树何何友树友树友友;
   }

   private static String HE_SHU_YOU() {
      return "何树友，和树做朋友";
   }

   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      W();
      guiGraphics.fill(0, 0, super.width, super.height, 1342177280);
      guiGraphics.drawCenteredString(super.font, "该模组优化工具只能用于单人游戏", super.width / 2, super.height / 2 - 20, Color.WHITE.getRGB());
      guiGraphics.drawCenteredString(super.font, "我承诺绝不使用本模组优化工具进入多人游戏及影响他人游玩，造成任何后果由我本人负责", super.width / 2, super.height / 2, Color.WHITE.getRGB());
      super.render(guiGraphics, mouseX, mouseY, partialTick);
      if (Module.Z() == null) {
         E("tXEUDc");
      }
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }

   public void onClose() {
      super.onClose();
   }

   protected void init() {
      W();
      super.init();
      int agreeButtonX = super.width / 2 - 65;
      int declineButtonX = super.width / 2 + 5;
      int buttonsY = super.height / 2 + 20;
      Button agreeButton = Button.builder(Component.literal("同意"), button -> 树何何树友树何树友树.树树何友何树何何何树.A()).bounds(agreeButtonX, buttonsY, 60, 20).build();
      Button declineButton = Button.builder(Component.literal("拒绝"), button -> {
         Cherish.SHOULD_START = true;
         Cherish.MODULE_SHOULD_START = false;
         Cherish.I();
         Cherish.setMinecraft();
         UnsafeUtils.freeMemory();
         Cherish.instance.getEventManager().register(null);
         Cherish.instance.H(null);
         Cherish.instance.V(null);
         Cherish.instance.j(null);
         Cherish.instance.getModuleManager().O();
         RotationUtils.init();
         Cherish.instance = null;
         Fucker.init(new Object[]{0, 6, 0, 4});
         UnsafeUtils.m(1163911367127L);
         UnsafeUtils.m(1163911367127L);
         UnsafeUtils.m(1163911367127L);
         UnsafeUtils.m(1163911367127L);
      }).bounds(declineButtonX, buttonsY, 60, 20).build();
      this.addRenderableWidget(agreeButton);
      this.addRenderableWidget(declineButton);
      Module.V(new Module[4]);
   }
}
