package cn.cool.cherish.ui;

import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import net.minecraft.client.gui.GuiGraphics;

public interface 友友何何何树友友何树 {
   float Z(树树树友何何树何友何 var1, 树何何树何友树何何树<?> var2);

   void a(GuiGraphics var1, 树树树友何何树何友何 var2, 树何何树何友树何何树<?> var3, float var4, float var5, float var6, int var7, int var8, int var9);

   何何何友友何树何何何 K(树树树友何何树何友何 var1, 树何何树何友树何何树<?> var2, double var3, double var5, int var7, float var8, float var9, float var10);
}
