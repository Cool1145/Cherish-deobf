package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;

public class 树何何树树树友友友友 implements IWrapper, 何树友 {
   private final 友树友树何树友友友树 何友友树树树友树树友;
   public float 友何树友树树何何友友;
   public float 树何友友何树友友何何;
   public float 树友何何何友友树何友;
   public float 树何友树树树树友友树;
   public float 友友树树友树友树树友;
   public float 树友树树树友友何友树;
   public boolean 友友友友何树树何何友;
   public Module 何树友何何友友树树友;
   private boolean 何何何树树友树树友树;
   private float 树何何树何树友何何树;
   private long 何树何树友树树树何友;
   private boolean 友树树树何友树树友树;
   private static final long a;
   private static final long b;
   private static final Object[] c = new Object[32];
   private static final String[] e = new String[32];
   private static String HE_WEI_LIN;

   public 树何何树树树友友友友(Module module) {
      long a = 树何何树树树友友友友.a ^ 119275878702603L;
      a<"r">(-7432454091450741631L, a);
      super();
      a<"Û">(this, false, -7431836047768655156L, a);
      a<"Û">(this, 0.0F, -7431616094804719970L, a);
      a<"Û">(this, 0L, -7432164132469813161L, a);
      a<"Û">(this, module, -7432769942467204573L, a);
      this.何友友树树树友树树友 = new 友树友树何树友友友树(module);
      a<"Û">(this, module.isEnabled(), -7432972613651826974L, a);
      a<"Û">(this, 0.0F, -7431677724734415097L, a);
      if (module.isEnabled()) {
         a<"Û">(this, 1.0F, -7431616094804719970L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-1178260747096021844L, -409014247431903411L, MethodHandles.lookup().lookupClass()).a(103583846090023L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 75879626747626L;
      Cipher var2;
      Cipher var7 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var7.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var6 = var2.doFinal(new byte[]{-63, 55, 1, 114, 124, -124, -38, -19});
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      byte var10001 = -1;
      b = var8;
   }

   public void J(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      long a = 树何何树树树友友友友.a ^ 76908787209211L;
      long ax = a ^ 48293335256091L;
      long axx = a ^ 109446399141556L;
      a<"r">(-3086452386051505807L, a);
      a<"Û">(this, false, -3086670414267450337L, a);
      boolean currentEnabled = a<"e">(this, -3086840860787415085L, a).isEnabled();
      if (currentEnabled != a<"e">(this, -3086954470458574062L, a)) {
         a<"Û">(this, currentEnabled, -3086954470458574062L, a);
         a<"Û">(this, System.currentTimeMillis(), -3086215267115819609L, a);
         a<"Û">(this, true, -3085816814607915204L, a);
      }

      this.i(partialTicks, currentEnabled);
      this.w();
      float valuesHeight = 0.0F;
      if (!a<"e">(this, -3086840860787415085L, a).q().isEmpty()) {
         a<"Û">(a<"e">(this, -3086341516623488284L, a), HUD.instance.getColor(0), -3086886039490303093L, a);
         valuesHeight = a<"e">(this, -3086341516623488284L, a).l();
      }

      a<"Û">(this, 20.0F + valuesHeight, -3085728864864447753L, a);
      PoseStack var10000 = guiGraphics.pose();
      float var10001 = (int)a<"e">(this, -3086732230624911862L, a);
      float var10002 = (int)a<"e">(this, -3085777803368307715L, a);
      float var10003 = (int)(a<"e">(this, -3086732230624911862L, a) + a<"e">(this, -3086616224723433034L, a));
      float var10004 = (int)(a<"e">(this, -3085777803368307715L, a) + a<"e">(this, -3085728864864447753L, a));
      Object[] var10008 = new Object[]{null, null, null, null, null, null, new Color(35, 35, 35).getRGB()};
      var10008[5] = axx;
      var10008[4] = var10004;
      var10008[3] = var10003;
      var10008[2] = var10002;
      var10008[1] = var10001;
      var10008[0] = var10000;
      RenderUtils.E(var10008);
      ClientUtils.o(new Object[]{ax});
      友何何树友何何何何树 titleFont = Cherish.instance.h().n(20);
      String moduleName = a<"e">(this, -3086840860787415085L, a).i();
      titleFont.c(
         guiGraphics.pose(),
         moduleName,
         a<"e">(this, -3086732230624911862L, a) + 5.0F,
         a<"e">(this, -3085777803368307715L, a) + 10.0F - titleFont.K() / 2.0F,
         -1
      );
      Color accentColor = HUD.instance.getColor(0);
      Color disabledColor = new Color(100, 100, 100);
      Color toggleColor = 树树何友友友友何树友.x(disabledColor, accentColor, a<"e">(this, -3085615552119010450L, a));
      float toggleIndicatorX = a<"e">(this, -3086732230624911862L, a) + a<"e">(this, -3086616224723433034L, a) - 10.0F - 10.0F;
      float toggleIndicatorY = a<"e">(this, -3085777803368307715L, a) + 10.0F - 5.0F;
      var10000 = guiGraphics.pose();
      var10001 = (int)toggleIndicatorX;
      var10002 = (int)toggleIndicatorY;
      var10003 = (int)(toggleIndicatorX + 10.0F);
      var10004 = (int)(toggleIndicatorY + 10.0F);
      var10008 = new Object[]{null, null, null, null, null, null, toggleColor.getRGB()};
      var10008[5] = axx;
      var10008[4] = var10004;
      var10008[3] = var10003;
      var10008[2] = var10002;
      var10008[1] = var10001;
      var10008[0] = var10000;
      RenderUtils.E(var10008);
      if (valuesHeight > 0.0F) {
         a<"Û">(a<"e">(this, -3086341516623488284L, a), a<"e">(this, -3086732230624911862L, a), -3086431055096976962L, a);
         a<"Û">(a<"e">(this, -3086341516623488284L, a), a<"e">(this, -3085777803368307715L, a) + 20.0F, -3086114504350946095L, a);
         a<"Û">(a<"e">(this, -3086341516623488284L, a), a<"e">(this, -3086616224723433034L, a), -3087100238793846314L, a);
         a<"e">(this, -3086341516623488284L, a).T(guiGraphics, mouseX, mouseY, partialTicks);
         a<"Û">(
            this, a<"e">(this, -3086670414267450337L, a) || a<"e">(a<"e">(this, -3086341516623488284L, a), -3087175110622526028L, a), -3086670414267450337L, a
         );
      }

      a<"r">(!a<"r">(-3085590246539920786L, a), -3086559994553227606L, a);
   }

   private boolean S(float x, float y, float width, float height, double mouseX, double mouseY) {
      long a = 树何何树树树友友友友.a ^ 114571317502020L;
      a<"r">(-6443401918688362723L, a);
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + 20.0F;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 4;
               case 1 -> 61;
               case 2 -> 41;
               case 3 -> 24;
               case 4 -> 20;
               case 5 -> 16;
               case 6 -> 18;
               case 7 -> 39;
               case 8 -> 56;
               case 9 -> 9;
               case 10 -> 17;
               case 11 -> 10;
               case 12 -> 46;
               case 13 -> 55;
               case 14 -> 37;
               case 15 -> 5;
               case 16 -> 54;
               case 17 -> 28;
               case 18 -> 63;
               case 19 -> 49;
               case 20 -> 14;
               case 21 -> 53;
               case 22 -> 44;
               case 23 -> 42;
               case 24 -> 29;
               case 25 -> 26;
               case 26 -> 8;
               case 27 -> 11;
               case 28 -> 62;
               case 29 -> 48;
               case 30 -> 60;
               case 31 -> 38;
               case 32 -> 51;
               case 33 -> 15;
               case 34 -> 30;
               case 35 -> 47;
               case 36 -> 12;
               case 37 -> 50;
               case 38 -> 52;
               case 39 -> 23;
               case 40 -> 6;
               case 41 -> 2;
               case 42 -> 7;
               case 43 -> 27;
               case 44 -> 1;
               case 45 -> 3;
               case 46 -> 36;
               case 47 -> 22;
               case 48 -> 19;
               case 49 -> 58;
               case 50 -> 0;
               case 51 -> 21;
               case 52 -> 31;
               case 53 -> 43;
               case 54 -> 25;
               case 55 -> 45;
               case 56 -> 34;
               case 57 -> 57;
               case 58 -> 35;
               case 59 -> 13;
               case 60 -> 40;
               case 61 -> 33;
               case 62 -> 59;
               default -> 32;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private void i(float partialTicks, boolean enabled) {
      long a = 树何何树树树友友友友.a ^ 73813228161245L;
      a<"r">(5624064902092151383L, a);
      float animSpeed = partialTicks / 0.15F;
      if (a<"e">(this, 5623790679475425352L, a) < 1.0F) {
         a<"Û">(this, Math.min(a<"e">(this, 5623790679475425352L, a) + animSpeed, 1.0F), 5623790679475425352L, a);
      }

      if (a<"e">(this, 5623790679475425352L, a) > 1.0F) {
         a<"Û">(this, Math.max(a<"e">(this, 5623790679475425352L, a) - animSpeed, 0.0F), 5623790679475425352L, a);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'e' && var8 != 219 && var8 != 'l' && var8 != 'k') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'u') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'r') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'e') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 219) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'l') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public void s(int keyCode, int scanCode, int modifiers) {
      long a = 树何何树树树友友友友.a ^ 56503061424088L;
      a<"e">(this, 6991955172562529991L, a).k(keyCode, scanCode, modifiers);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public void n(double mouseX, double mouseY, int button) {
      long a = 树何何树树树友友友友.a ^ 80320080378939L;
      a<"r">(4245576309137728354L, a);
      if (this.S(a<"e">(this, 4245123812740346314L, a), a<"e">(this, 4246069340821556285L, a), a<"e">(this, 4245256296247191158L, a), 20.0F, mouseX, mouseY)
         && button == 0) {
         a<"e">(this, 4245023534141671443L, a).k();
      } else {
         if (mouseY > a<"e">(this, 4246069340821556285L, a) + 20.0F && mouseY < a<"e">(this, 4246069340821556285L, a) + a<"e">(this, 4246125941551480119L, a)) {
            a<"e">(this, 4245504942522447140L, a).j(mouseX, mouseY, button);
         }
      }
   }

   public void h() {
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何树树树友友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      c[0] = "Y<x\u00124\u000fV|5\u0019>\u0012S!>_.\t\u0014桃伃伤桊桱栫厙厝厺厐";
      c[1] = float.class;
      e[1] = "java/lang/Float";
      c[2] = "'}*_|=(=gTv -`l\u0012f;j变栕号栂伇桕变叏号栂";
      c[3] = int.class;
      e[3] = "java/lang/Integer";
      c[4] = "U\u000e\bU2R^\u0001\u0019\u001aNKQ\u001b\u0017Yy{G\f\u001bDhWP\u0001";
      c[5] = "I\bWH!4FH\u001aC+)C\u0015\u0011\u0005#4N\u0013\u0015N`\u0016E\u0002\fG+";
      c[6] = boolean.class;
      e[6] = "java/lang/Boolean";
      c[7] = long.class;
      e[7] = "java/lang/Long";
      c[8] = void.class;
      e[8] = "java/lang/Void";
      c[9] = "Q^<h]\u000eLKdJ\u001c\u0003TM";
      c[10] = "\u001e Juf\u001e\u0015/[:\u0007\u0010\u001e$_`";
      c[11] = "\u0002\u000eIh?M\u0004\u001e\u0012\u0014伄伪伽桥桪受桀桮厣桥s(9\b\u000b\u001b\rn+\u000f\u0006";
      c[12] = "5T,a\nx3Dw\u001d桵伟厔栿栏栄桵厁厔栿\u0016g\b=-[i}\u001d8";
      c[13] = "WJ 6?)QZ{J桀低叶叻佇桓厚叐佨佥\u001a0=lOEe*(i";
      c[14] = "-\\0[p\u0010+Lk'栏佷伒样佗栾叕佷伒样\n]rU5SuGgP";
      c[15] = ")l\u001b\u0016\u0002ao'\u0006\u0012>S\u0015k\u0000\u0007Uwk-\u0012\u0000X\u0010";
      c[16] = "m\u0004/MI4k\u0014t1召体栖厵栌栨佲体双厵\u0015KKqu\u000bjQ^t";
      c[17] = "Mx\u0005Nh\u0000\u000b3\u0018JT8q\u007f\u001e_?\u0016\u000f9\fX2qL2\u0017\u001b%\u0014\u00121G[T";
      c[18] = "8L]\u0012@RjZ\u0016\u001eq[\u0001\u0012\u0007\u000f\u0016Zp\u0017\f\u0016\u001d8";
      c[19] = "5\u0013F5h\ng\u0005\r9Y桹佑伪传桉伄桹叏桮厾P#\u0004s\r\u0000/9\u0011v";
      c[20] = "#eicxs%u2\u001f佃厊厂栎桊栆叝桐桘叔S&zr$&9tl9(";
      c[21] = "Tg\u0013d \u0010\u0006qXh\u0011*m9Iyv\u0018\u001c<B`}z";
      c[22] = "^;X\u0016`4X+\u0003j佛栗佡桐厡桳栟栗佡厊bWh3Lq\u0019[oe\u0004";
      c[23] = "5\u001f?qm\u0002g\tt}\\厫叏厸余栍企桱佑桢栝\u0014&\fs\u0001yk<\u0019v";
      c[24] = "AaW8C\u0011\u0013w\u001c4r厸伥叆厯厞桫伦桡叆桵]N\u001b\u0007n\u000b#\b\t\u0000c";
      c[25] = "4Rp\u0001B\bfD;\rs厡栔叵伖厧桪桻栔叵桒d\t\u0006rL6\u001b\u0013\u0013w";
      c[26] = "b\u001c:\u0003\u0011id\fa\u007f\u001eS;\u0003|\u001e\t9`P0\rwhm\u0012a\u0001\u001d3>^r\u007f";
      c[27] = "h<\u0007D_#n,\\8叺栀栓桗你叻栠栀叉桗=\u0004Yfa)CBKal";
      c[28] = "T^GoTw\u0006H\fce佀估叹县佗厦佀桴佧桥\n[qVE\u0005k\u0006#\u0017\u0000";
      c[29] = "f]gE4@`M<9伏档叇佲伀叺厑档栝召]\u0005i\u0001j\u0013,C\"\u001cn";
      c[30] = "\\8\r\u007f\rCZ(V\u0003桲厺佣众佪叀厨桠佣厉7y\u000f\u0006D7Hc\u001a\u0003";
      c[31] = "\u001c{q&<\u0003\u001ak*Z厙叺厽及伖桃桃佤伣及Kf:F\u0015n5 (A\u0018";
   }

   public void m() {
      long a = 树何何树树树友友友友.a ^ 80391259122015L;
      a<"e">(this, -5796396255011823552L, a).d();
      a<"Û">(this, a<"e">(this, -5796877670925296265L, a).isEnabled() ? 1.0F : 0.0F, -5797894207410081334L, a);
      a<"Û">(this, a<"e">(this, -5796877670925296265L, a).isEnabled(), -5797008290277539402L, a);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void v(char chr, int modifiers) {
      long a = 树何何树树树友友友友.a ^ 29745058688043L;
      a<"e">(this, -1514544002450004684L, a).D(chr, modifiers);
   }

   private void w() {
      long a = 树何何树树树友友友友.a ^ 32900482580266L;
      if (a<"e">(this, 8790360075672521709L, a)) {
         long currentTime = System.currentTimeMillis();
         long elapsedTime = currentTime - a<"e">(this, 8789574629301563766L, a);
         if (elapsedTime >= b) {
            a<"Û">(this, false, 8790360075672521709L, a);
         }
      }
   }

   public void M(double mouseX, double mouseY, int button) {
      long a = 树何何树树树友友友友.a ^ 106932049767725L;
      a<"e">(this, -6053620693210520526L, a).l(mouseX, mouseY, button);
   }

   public Module K() {
      long a = 树何何树树树友友友友.a ^ 134583259756965L;
      return a<"e">(this, 4573239404550163853L, a);
   }

   private static String HE_WEI_LIN() {
      return "解放村多种2队1144号";
   }
}
