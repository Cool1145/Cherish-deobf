package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 树何何树友树何树友树 implements IWrapper, 何树友 {
   public static final 树何何树友树何树友树 树树何友何树何何何树 = new 树何何树友树何树友树();
   private 友友何友何何树何何友 何何树树何树友何何树;
   private boolean 树树何友友何何树树友 = !Cherish.isDllInject;
   private static final long a;
   private static final Object[] b = new Object[15];
   private static final String[] c = new String[15];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-6107091878175853240L, -7384323492786286984L, MethodHandles.lookup().lookupClass()).a(227981233739237L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public void D() {
      if (友友何友何何树何何友.W() == null) {
         if (this.何何树树何树友何何树 == null) {
            this.何何树树何树友何何树 = new 友友何友何何树何何友();
         }

         Cherish.instance.getEventManager().register(this);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 53;
               case 1 -> 59;
               case 2 -> 57;
               case 3 -> 41;
               case 4 -> 35;
               case 5 -> 48;
               case 6 -> 5;
               case 7 -> 52;
               case 8 -> 19;
               case 9 -> 39;
               case 10 -> 10;
               case 11 -> 1;
               case 12 -> 27;
               case 13 -> 33;
               case 14 -> 32;
               case 15 -> 36;
               case 16 -> 25;
               case 17 -> 30;
               case 18 -> 9;
               case 19 -> 54;
               case 20 -> 13;
               case 21 -> 44;
               case 22 -> 4;
               case 23 -> 17;
               case 24 -> 42;
               case 25 -> 22;
               case 26 -> 29;
               case 27 -> 24;
               case 28 -> 28;
               case 29 -> 37;
               case 30 -> 58;
               case 31 -> 31;
               case 32 -> 34;
               case 33 -> 55;
               case 34 -> 2;
               case 35 -> 6;
               case 36 -> 60;
               case 37 -> 14;
               case 38 -> 3;
               case 39 -> 49;
               case 40 -> 38;
               case 41 -> 12;
               case 42 -> 0;
               case 43 -> 56;
               case 44 -> 15;
               case 45 -> 20;
               case 46 -> 50;
               case 47 -> 18;
               case 48 -> 26;
               case 49 -> 62;
               case 50 -> 51;
               case 51 -> 16;
               case 52 -> 63;
               case 53 -> 40;
               case 54 -> 21;
               case 55 -> 61;
               case 56 -> 45;
               case 57 -> 8;
               case 58 -> 47;
               case 59 -> 46;
               case 60 -> 11;
               case 61 -> 23;
               case 62 -> 7;
               default -> 43;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'w' && var8 != 'q' && var8 != 'b' && var8 != 192) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 241) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'w') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'q') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'b') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @EventTarget
   public void s(TickEvent event) {
      友友何友何何树何何友.W();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.树树何友友何何树树友) {
            Cherish.instance.getEventManager().unregister(this);
         } else {
            if (!(mc.screen instanceof 友友何友何何树何何友)) {
               mc.setScreen(this.何何树树何树友何何树);
            }
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何树友树何树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      b[0] = "p\u000b-+)\u001b\u007fK` #\u0006z\u0016kf3\u001d=桴佖伝桗县栂估栒厃桗";
      b[1] = "8L>+PX3C/d,A<Y!'\u001bq*N-:\n]=C";
      b[2] = "\u0002m\u0019\tP$\r-T\u0002Z9\bp_DJ\"O又叼伿叴伞伴栒佢伿叴";
      b[3] = "BJ'F)#IE6\tT;ZB?@";
      b[4] = "fp\u001aL\u001cxfp\r\u0010\u0010w|;\r\u000e\u0018tfa@/\u0018\u007fmv\u001c\u0003\u0017e";
      b[5] = "\b\u0015L\u0015|>\b\u0015[Ip1\u0012^[Wx2\b\u0004\u0016\\d>H\u0003[It2\b\u0003\u0016hr%\u0003\u0015V";
      b[6] = boolean.class;
      c[6] = "java/lang/Boolean";
      b[7] = "|\u001fU,pys_\u0018'zdv\u0002\u0013a\\~z\u0003\u0012<w";
      b[8] = "fD^w\u0001XmKO8`Vf@Kb";
      b[9] = "CN. \u0005.DA-ZPOYJ\u007f5F1YL$ZF$LNj$F\"\u0017!";
      b[10] = "\u0019f\u0019H;KL`\f[@- ;\u0010T,LYp\u000b\u0015)r";
      b[11] = "V;uJg\\\u00156uI[Q\u0010F-@\u001aV\tg\"X[\f[`-D2\u000b\b13";
      b[12] = "n\u0007\u001bM\u0005/i\b\u00187佤伓栒桱佽栮叺伓佖桱 \u000e^!i\u0013\u0019[X4z";
      b[13] = "|kkm1\u0006\u007fi%t^\u0019\u0010bc<nO\u0010Sae4\fz5#t9J";
      b[14] = "JI\rHLyMF\u000e2桩栁佲句叵佯伭栁栶句6\u000e@rKF_\t\u0013#U";
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void A() {
      友友何友何何树何何友.W();
      this.树树何友友何何树树友 = true;
      if (mc.screen instanceof 友友何友何何树何何友) {
         mc.setScreen(null);
      }
   }

   private static String HE_JIAN_GUO() {
      return "我是何树友";
   }
}
