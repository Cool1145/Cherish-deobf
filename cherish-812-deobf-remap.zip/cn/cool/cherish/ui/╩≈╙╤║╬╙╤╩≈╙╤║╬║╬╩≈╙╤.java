package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class 树友何友树友何何树友 implements IWrapper, 何树友 {
   private static final int 何何何何树友何友树树;
   private static final int 树树树树树友何友何树;
   private static final int 友何何何何树树友树友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[28];
   private static final String[] g = new String[28];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6538839085838973030L, -9222932666844731889L, MethodHandles.lookup().lookupClass()).a(93270391310127L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(63630816907686L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[8];
      int var18 = 0;
      String var17 = "ëXÄ\u0081\bå7{4\u0084_\u0083ï#Oè ¼Èù\u0006_\u008b\u008a\u0082:\u0011J8%\u0095Ñ31\u0093ñ\u009cûÃ\u0085\u001eªVñ9\u009a5\u009a² yö!Ö×Ì\u0097,\u0092¿1\u0082eéN}ÿÅ¾ú*\u000e\u0081K\u0007aªRÙß0\u0090 ½)î\u001c¿¾-,AÕÑ©\u000bÿ\u0015ßÓ[}ç%çÓ\u008c7(|ÖC\u0089ÍÎ(Ø\u000e\u0084\u001cæx\u0013£?\u008c¡¸âÈµx³l\u0091Î\\nn\u0011\u0099èþLC\u0006§Q\u0082\u0014_Ì\u0018\u0006\u00adx\u0018Ì2ûWÖÔ3û\u0002Ë¸ß\n«õ1àìV²u\u0007óC";
      short var19 = 181;
      char var16 = 16;
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = b(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     b = var20;
                     c = new String[8];
                     Cipher var1;
                     Cipher var26 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var2 = 1; var2 < 8; var2++) {
                        var10003[var2] = (byte)(63630816907686L << var2 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var0 = new long[3];
                     int var4 = 0;
                     byte var3 = 0;

                     do {
                        var10001 = var3;
                        var3 += 8;
                        byte[] var7 = "ÔÔ\n\u0099/Ù~;^\u0099¾TöÔ4\u0097Ý®7f9ûàê".substring(var10001, var3).getBytes("ISO-8859-1");
                        var10001 = var4++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var1.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var0[var10001] = var10004;
                     } while (var3 < 24);

                     友何何何何树树友树友 = (int)var0[0];
                     树树树树树友何友何树 = (int)var0[2];
                     何何何何树友何友树树 = (int)var0[1];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "«IæÍy«u\u0012>:1\u0001¤ÓÃ2 \u0084)\u0014e?\u001bËY¤¼\u0096>Û.}»Ö\u009bPR\u0092:Ñ$Þ\u0005\u0017É,üý>";
                  var19 = 49;
                  var16 = 16;
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 54;
               case 1 -> 20;
               case 2 -> 47;
               case 3 -> 25;
               case 4 -> 36;
               case 5 -> 26;
               case 6 -> 35;
               case 7 -> 61;
               case 8 -> 52;
               case 9 -> 32;
               case 10 -> 27;
               case 11 -> 10;
               case 12 -> 16;
               case 13 -> 46;
               case 14 -> 19;
               case 15 -> 40;
               case 16 -> 7;
               case 17 -> 45;
               case 18 -> 0;
               case 19 -> 60;
               case 20 -> 23;
               case 21 -> 12;
               case 22 -> 53;
               case 23 -> 9;
               case 24 -> 59;
               case 25 -> 49;
               case 26 -> 43;
               case 27 -> 31;
               case 28 -> 6;
               case 29 -> 29;
               case 30 -> 4;
               case 31 -> 38;
               case 32 -> 17;
               case 33 -> 50;
               case 34 -> 62;
               case 35 -> 37;
               case 36 -> 33;
               case 37 -> 21;
               case 38 -> 3;
               case 39 -> 2;
               case 40 -> 58;
               case 41 -> 56;
               case 42 -> 28;
               case 43 -> 41;
               case 44 -> 8;
               case 45 -> 44;
               case 46 -> 42;
               case 47 -> 14;
               case 48 -> 15;
               case 49 -> 22;
               case 50 -> 63;
               case 51 -> 39;
               case 52 -> 24;
               case 53 -> 55;
               case 54 -> 48;
               case 55 -> 5;
               case 56 -> 34;
               case 57 -> 13;
               case 58 -> 30;
               case 59 -> 51;
               case 60 -> 57;
               case 61 -> 18;
               case 62 -> 1;
               default -> 11;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 196 && var8 != 253 && var8 != 194 && var8 != 243) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 204) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 201) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 196) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 253) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友何友树友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      f[0] = "9\u000f4\u000b256Oy\u00008(3\u0012rF(3t桰发伽厖桋厑伴住桹厖";
      f[1] = "\u0013\u007fW\u001d-:\u0018pFRQ#\u0017jH\u0011f\u0013\u0001}D\fw?\u0016p";
      f[2] = "X%\u0005W<\fX%\u0012\u000b0\u0003Bn\u0012\u00158\u0000X4_\t=\u0004O%\u0003W\u001d\nU!\u001d)=\u0004O%\u0003";
      f[3] = "s?\u0007\u000bW\\s?\u0010W[Sit\u0004JHYyt\u001aKLPs.\u001cWC\u001bT4\u0005@TAr(\nh_[h";
      f[4] = "\u0017\b\u000e\u0005<I\u0018HC\u000e6T\u001d\u0015HH&OZ桷併伳厘样伡厭併桷伆";
      f[5] = "ZY~A\nKQVo\u000ewSBQfG";
      f[6] = "t\u0016\t_?\\t\u0016\u001e\u00033Sn]\u001e\u001d;Pt\u0007S<;[\u007f\u0010\u000f\u00104A";
      f[7] = "Qu{\u0004o<QulXc3K>lFk0Qd!Mw<\u0011clXg0Qc!ya'Zua";
      f[8] = "0z]tLD0zJ(@K*1J6HH0k\u0007=TDpYF4U";
      f[9] = "{MK\u001eF\u0007t\r\u0006\u0015L\u001aqP\rSL\u001e}M\u0011SL\u001e}M\u0011\u000e\u0007-nF\u000b\t\r;qG\u0000";
      f[10] = "|~\u0011MW`s>\\F]}vcW\u0000U`{eSK\u0016fr`S\u0000\\fl`SOA!WE{";
      f[11] = "qr8\u000b\u000fx~2u\u0000\u0005e{o~F\u0016v~isF\tzbp8%\u000fswJw\u0004\u0015r";
      f[12] = "\u0003\u001a\u0013\r\u0016L\fZ^\u0006\u001cQ\t\u0007U@\u0014L\u0004\u0001Q\u000bWn\u000f\u0010H\u0002\u001c";
      f[13] = "\u0002B~\u001alp6aqZ!{<|t\u0007*=4ay\u0001.vwCr\u00107\u007f<5";
      f[14] = "fHj)'k{]2\u000bffc[";
      f[15] = "\\h5$F7hK:d\u000b<bV?9\u0000zjK2?\u00041)i9.\u001d8b\u001f";
      f[16] = void.class;
      g[16] = "java/lang/Void";
      f[17] = "\u0010g5N\u0000\u000f\u001bh$\u0001a\u0001\u0010c [";
      f[18] = "0\t#\u0002P-zO=\u001f=G\u0000\u001e$\\\rd1\b#\b\\\u0015";
      f[19] = "U\u000bs\u000e\u001em\u0010Dd1\t\u001fVN3\u000b\tf\u0005\u00049A`&UN3X\u0019u\u001fDy1";
      f[20] = "zmDbz\tv M%\u0001+\u000bQxW\u0001E6p\\a|I{y\u001b";
      f[21] = "3iU#l\ty/K>\u0001o\u0003~R}1@2hU)`1i}\u0017r`SyxPr\u0001";
      f[22] = "0MM\u007f\u0003IdIE8m\u001c^\u0013\u0017>\\O^(\u00139W\u00160WP9\t\u001d";
      f[23] = "0;f2Q :o13;\u001b\u000bil4I~u;d7Y@";
      f[24] = "\u001eJ\f\u007fV\u0002GU\n8-\\u\u0016\f}\u001d\nu'\b$R\fGJN~O\u000e";
      f[25] = "c\u0012\u001fb\b&:\r\u0019%sx\bN\u001f`M,\b\u007f\u001b#\u000f)e\u0016@?\u0013d";
      f[26] = "i)x\u0016\u0013Dg+r\u0010sb\u0010\u0013_tM[,*c\nCY&,";
      f[27] = "viZ8e\u0002;:Gj\u0003叹伔厖栬桏佞栣厊厖叶V3\u0000*hM/zAw)";
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25259;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树友何友树友何何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[5ûu*\u0082\u0001]G, óc¥\u0082ÉÉ?\fq!ÏÉ")[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友何友树友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void m(GuiGraphics graphics, float startX, float startY, float moduleX, float moduleY, float moduleWidth, 何何友友树何树何友树 statusFont) {
      树何何友树何友何树何.S();
      if (mc.player != null) {
         boolean hasStacks = false;
         int i = 9;
         Slot slot = mc.player.inventoryMenu.getSlot(9);
         ItemStack stack = slot.getItem();
         if (!stack.isEmpty()) {
            hasStacks = true;
         }

         i++;
         if (hasStacks) {
            i = 9;
            slot = mc.player.inventoryMenu.getSlot(9);
            stack = slot.getItem();
            int itemX = (int)startX + 0;
            int itemY = (int)startY + 0;
            graphics.pose().pushPose();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            graphics.renderItem(stack, itemX, itemY);
            graphics.renderItemDecorations(mc.font, stack, itemX, itemY);
            graphics.pose().popPose();
            i++;
         }

         String statusText = "";
         if (mc.screen instanceof InventoryScreen) {
            statusText = "Already in inventory";
         }

         if (!hasStacks) {
            statusText = "Empty...";
         }

         if (!statusText.isEmpty()) {
            float statusX = moduleX + moduleWidth / 2.0F - statusFont.D(statusText) / 2.0F;
            float statusY = startY + (hasStacks ? 65 : 15);
            statusFont.q(graphics.pose(), statusText, statusX, statusY, new Color(255, 255, 255, 180).getRGB());
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void q(Render2DEvent event, float x, float y, float width, float height) {
      何何友友树何树何友树 titleFont = Cherish.instance.t().C(20);
      树何何友树何友何树何.S();
      何何友友树何树何友树 statusFont = Cherish.instance.t().H(16);
      float adjustedWidth = width + 13.0F;
      float adjustedHeight = height - 15.0F;
      float totalHeight = adjustedHeight + 22.0F + 16.0F;
      Color glassColor = new Color(0, 0, 0, 60);
      Color borderColor = new Color(255, 255, 255, 120);
      ShaderUtils.M(132138673613539L, event.poseStack(), x, y, adjustedWidth, totalHeight, 8.0F, 1.5F, borderColor, glassColor, 12.0F);
      float titleX = x + adjustedWidth / 2.0F - titleFont.D(HUD.instance.友何友树树何树友友友.K("Chinese") ? "背包显示" : "Inventory") / 2.0F;
      float titleY = y + 8.0F + 2.0F;
      titleFont.q(event.poseStack(), HUD.instance.友何友树树何树友友友.K("Chinese") ? "背包显示" : "Inventory", titleX, titleY, Color.WHITE.getRGB());
      ShaderUtils.o(
         event.poseStack(), 100739365455537L, x + 8.0F, titleY + titleFont.x() + 4.0F, adjustedWidth - 16.0F, 1.0F, 0.5F, new Color(255, 255, 255, 80)
      );
      if (event.side() == Event.Side.POST) {
         m(event.guiGraphics(), x + 8.0F, y + 8.0F + 22.0F - 3.0F, x, y, adjustedWidth, statusFont);
      }

      Module.V(new Module[5]);
   }

   private static String HE_SHU_YOU() {
      return "何炜霖国企上班";
   }
}
