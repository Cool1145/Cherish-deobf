package cn.cool.cherish.ui.dynamicisland;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.ChatFormatting;

// $VF: synthetic class
class DynamicIsland$友树树何友友友友友树 implements 何树友 {
   private static final Object[] a = new Object[27];
   private static final String[] b = new String[27];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-738857276166622201L, 3379554162042133477L, MethodHandles.lookup().lookupClass()).a(202561456931661L);
      // $VF: monitorexit
      long var0 = var10000 ^ 79955874859874L;
      a();

      try {
         a<"õ">(5339643990387929789L, var0)[a<"õ">(5339854814806687027L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var21) {
      }

      try {
         a<"õ">(5339643990387929789L, var0)[a<"õ">(5339715509755245500L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var20) {
      }

      try {
         a<"õ">(5339643990387929789L, var0)[a<"õ">(5339448346628912836L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var19) {
      }

      try {
         a<"õ">(5339643990387929789L, var0)[a<"õ">(5340595652124110991L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var18) {
      }

      何何友友何树友何何友 = new int[ChatFormatting.values().length];

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340310566496484326L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var17) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340657907875975902L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var16) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5339380231690902072L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var15) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5339898059875152052L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var14) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340929972312888919L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var13) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5339366313271939564L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var12) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340101409360968824L, var0).ordinal()] = 7;
      } catch (NoSuchFieldError var11) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340454302326792917L, var0).ordinal()] = 8;
      } catch (NoSuchFieldError var10) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5339725382245823894L, var0).ordinal()] = 9;
      } catch (NoSuchFieldError var9) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340171801930517981L, var0).ordinal()] = 10;
      } catch (NoSuchFieldError var8) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340502606105409298L, var0).ordinal()] = 11;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[ChatFormatting.AQUA.ordinal()] = 12;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340232129499174750L, var0).ordinal()] = 13;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340878729987548068L, var0).ordinal()] = 14;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5340047065963390867L, var0).ordinal()] = 15;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"õ">(5340368978690473524L, var0)[a<"õ">(5339996620630982252L, var0).ordinal()] = 16;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 214 && var8 != 'A' && var8 != 245 && var8 != 217) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'u') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'e') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 214) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'A') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 245) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland$友树树何友友友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 40;
               case 1 -> 35;
               case 2 -> 58;
               case 3 -> 7;
               case 4 -> 10;
               case 5 -> 22;
               case 6 -> 32;
               case 7 -> 39;
               case 8 -> 28;
               case 9 -> 11;
               case 10 -> 63;
               case 11 -> 48;
               case 12 -> 41;
               case 13 -> 46;
               case 14 -> 6;
               case 15 -> 23;
               case 16 -> 20;
               case 17 -> 57;
               case 18 -> 53;
               case 19 -> 37;
               case 20 -> 34;
               case 21 -> 24;
               case 22 -> 45;
               case 23 -> 29;
               case 24 -> 0;
               case 25 -> 55;
               case 26 -> 43;
               case 27 -> 59;
               case 28 -> 15;
               case 29 -> 27;
               case 30 -> 44;
               case 31 -> 8;
               case 32 -> 12;
               case 33 -> 54;
               case 34 -> 18;
               case 35 -> 16;
               case 36 -> 30;
               case 37 -> 2;
               case 38 -> 47;
               case 39 -> 51;
               case 40 -> 62;
               case 41 -> 49;
               case 42 -> 61;
               case 43 -> 25;
               case 44 -> 4;
               case 45 -> 38;
               case 46 -> 50;
               case 47 -> 14;
               case 48 -> 31;
               case 49 -> 52;
               case 50 -> 13;
               case 51 -> 21;
               case 52 -> 3;
               case 53 -> 56;
               case 54 -> 17;
               case 55 -> 42;
               case 56 -> 5;
               case 57 -> 60;
               case 58 -> 36;
               case 59 -> 19;
               case 60 -> 26;
               case 61 -> 1;
               case 62 -> 9;
               default -> 33;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "'\u0004T],\u001b'\u0004C\u0001 \u0014=Oc\u001b \u0006\u000f\u000eR\u001e \u0006=\bN\u0014";
      a[1] = "Y%%Ex+VehNr6S8c\bb-\u0014/rHv)S(bU{%T/%bn*[&bE^7V*eB3厏佯桚叀样叜厏栫伞叀";
      a[2] = "\u0002\u0010$9hn\rPi2bs\b\rbtrhO\u001as4fl\b\u001dc)k`\u000f\u001a$\u001e~o\u0000\u0013c9Nr\r\u001fd>#及桰桯佟厑双及厪厵栛";
      a[3] = "*u";
      a[4] = "gT";
      a[5] = "@H\u0005\u001ax\u0006KG\u0014U\u0019\b@L\u0010\u000f";
      a[6] = "\u0006\u0013IuMg\u0002\u0014\fKhE 6n\u001ctY5.v\u0006,m\n\r\f*Oi\rH";
      a[7] = "\u0007iduJX\u0003n!Kgr4OH\u0011fwnez0\u0015Z\ra}u";
      a[8] = "QV\u0012hCHUQWVmqqbi?GP\u0006R\n;@\u0015";
      a[9] = "\\i3\u0004\u000f\u0012Xnv:!+xA\u000e:\u0007\u0014N2)Y\u0003\u0013\u000b";
      a[10] = "J\u0017,5/;D\u000b1M桓桌佧伳厑伐桓桌栣厭R=3+B\u000b<3/6";
      a[11] = "ghY\bGUco\u001c6j\u007fTNu|bkC\rKS]\bonOT\u0018";
      a[12] = "o\"\u0014_\u0001pk%Qa*W[\no\b\u0005h8&\f\f\u0002-";
      a[13] = "\u0018\u0011\u007f;KB\u001c\u0016:\u0005pl=tm`Q\u001f\u0010\u0017ig\u0014";
      a[14] = ":=M2Y->:\b\fr\n\u001a\u0013u\fQ+(fWoU,m";
      a[15] = "$\u001ar&4}sBx S佋佀县叟伆桊叕佀伡叟[h{p\u001b&?--$\u0013";
      a[16] = "h.\u00005\u0003Kl)E\u000b.a[\b,B;uHK\u0012n\u0019\u0016`(\u0016i\\";
      a[17] = "6j[T\t\u00002m\u001ej7#\u001eSmj\u0001\u0006$1A\t\u0005\u0001a";
      a[18] = "c\u0017-}+\u0018g\u0010hC\u001b6N6\u0011\u001cJ\u0012o\th\")\u0016hL";
      a[19] = "ji6j+VnnsT\u0005rG@M=/N=m.9(\u000b";
      a[20] = ".lz#5hy4p%R佞佊佗佉桇厑栚佊叉栍^inzm.:,8.e";
      a[21] = "5#)\u0002\u0006};?4z厠栊优厙厔厹伾低历伇W\n\u001am=?9\u0004\u0006p";
      a[22] = "^\u0016-e 8Z\u0011h[\r\u0012m0\u0001\u0014\u001b\u0012fs?>:eV\u0010;9\u007f";
      a[23] = "ec\u0013X mk\u007f\u000e 桜栚取叙厮口历叀取佇mP<}m\u007f\u0003^ `";
      a[24] = "{:\b\"X\u0006\u007f=M\u001cu,H\u001c$Dd?J\u001b>\u001cP\u0000ia\u0012\u007fT\u0007,";
      a[25] = "Dk\u00027\u0012i@lG\t?CwM.F)G`Hy`\u0016q\u0013o\u001ad\u00114";
      a[26] = "\u0010b\u000b&\u0000)\u001e~\u0016^桼会伽但桬伃桼厄桹变u.\u001c9\u0018~\u001b \u0000$";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖黑水";
   }
}
