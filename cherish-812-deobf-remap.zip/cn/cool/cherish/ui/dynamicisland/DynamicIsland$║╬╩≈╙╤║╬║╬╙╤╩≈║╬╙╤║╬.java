package cn.cool.cherish.ui.dynamicisland;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.ChatFormatting;

// $VF: synthetic class
class DynamicIsland$何树友何何友树何友何 implements 何树友 {
   private static final Object[] a = new Object[27];
   private static final String[] b = new String[27];
   private static int _行走的50万——何炜霖 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-1491519678284185075L, 2964180229550528349L, MethodHandles.lookup().lookupClass()).a(17306034462196L);
      // $VF: monitorexit
      long var0 = var10000 ^ 92336724933371L;
      a();

      try {
         a<"è">(1686288946054699160L, var0)[a<"è">(1684780263351771129L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var21) {
      }

      try {
         a<"è">(1686288946054699160L, var0)[a<"è">(1686441976504750051L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var20) {
      }

      try {
         a<"è">(1686288946054699160L, var0)[a<"è">(1686207528173604577L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var19) {
      }

      try {
         a<"è">(1686288946054699160L, var0)[a<"è">(1685333631521525624L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var18) {
      }

      友友友树树树友友友树 = new int[ChatFormatting.values().length];

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1684512467660663128L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var17) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1684598117139236018L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var16) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1686460691875997232L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var15) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1685448230872501969L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var14) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1685482892635596928L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var13) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1685605145028422633L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var12) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1684729858770759734L, var0).ordinal()] = 7;
      } catch (NoSuchFieldError var11) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1686328412100956779L, var0).ordinal()] = 8;
      } catch (NoSuchFieldError var10) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1686554133528974592L, var0).ordinal()] = 9;
      } catch (NoSuchFieldError var9) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1685643113782347415L, var0).ordinal()] = 10;
      } catch (NoSuchFieldError var8) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1684483578539041709L, var0).ordinal()] = 11;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[ChatFormatting.AQUA.ordinal()] = 12;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1684403253695085670L, var0).ordinal()] = 13;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1684839114647135623L, var0).ordinal()] = 14;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1684694467224724863L, var0).ordinal()] = 15;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"è">(1686059505263433585L, var0)[a<"è">(1686174648776570681L, var0).ordinal()] = 16;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'R' && var8 != 207 && var8 != 232 && var8 != 'p') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 204) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 205) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'R') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 207) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 232) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland$何树友何何友树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 29;
               case 1 -> 49;
               case 2 -> 20;
               case 3 -> 16;
               case 4 -> 30;
               case 5 -> 11;
               case 6 -> 63;
               case 7 -> 42;
               case 8 -> 32;
               case 9 -> 15;
               case 10 -> 22;
               case 11 -> 27;
               case 12 -> 56;
               case 13 -> 5;
               case 14 -> 10;
               case 15 -> 59;
               case 16 -> 23;
               case 17 -> 34;
               case 18 -> 24;
               case 19 -> 54;
               case 20 -> 13;
               case 21 -> 47;
               case 22 -> 17;
               case 23 -> 44;
               case 24 -> 58;
               case 25 -> 52;
               case 26 -> 28;
               case 27 -> 19;
               case 28 -> 8;
               case 29 -> 40;
               case 30 -> 25;
               case 31 -> 51;
               case 32 -> 31;
               case 33 -> 14;
               case 34 -> 1;
               case 35 -> 50;
               case 36 -> 38;
               case 37 -> 2;
               case 38 -> 0;
               case 39 -> 39;
               case 40 -> 36;
               case 41 -> 6;
               case 42 -> 45;
               case 43 -> 43;
               case 44 -> 55;
               case 45 -> 60;
               case 46 -> 53;
               case 47 -> 18;
               case 48 -> 21;
               case 49 -> 48;
               case 50 -> 46;
               case 51 -> 33;
               case 52 -> 37;
               case 53 -> 12;
               case 54 -> 3;
               case 55 -> 35;
               case 56 -> 57;
               case 57 -> 26;
               case 58 -> 61;
               case 59 -> 4;
               case 60 -> 62;
               case 61 -> 41;
               case 62 -> 9;
               default -> 7;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "/P{&iJ \u00106-cW%M=ksLbZ,+gH%]<6jD\"Z{\u0001\u007fK-S<&OV _;!\"栴桝栯桄厎栗叮桝栯桄";
      a[1] = "Ib\u001a*)5Ib\rv%:S)-l%(ah\u001ci%(Sn\u0000c";
      a[2] = "\nfTqi^\u0005&\u0019zcC\u0000{\u0012<sXGl\u0003|g\\\u0000k\u0013ajP\u0007lTV\u007f_\be\u0013qOB\u0005i\u0014v\"佤桸參伯佇反栠似參伯";
      a[3] = "\u0019\u0005";
      a[4] = ";D";
      a[5] = "$s \u000f\u0004[/|1@eU$w5\u001a";
      a[6] = "\u001b \u0014sd\u0004T&\nL栝伣栿桂厥厏余伣句伆fq\u007f\f\u0019;\u001c>y\u0012";
      a[7] = "\u0016S*bbg\u0011\u0010)u\rAf7\u0012HDTr$Q&3vR\u0002;!puE";
      a[8] = "{GMt_\u0004|\u0004Nc04\u000f560\u000e\u0015?\u0016\\7M\u0016(";
      a[9] = "S\u000b%\bZATH&\u001f5d0x\u001335\u0012TN#\u001a_\u0015\u0017M4";
      a[10] = "\n\u000f\u0006\u0014'\u001c\rL\u0005\u0003H<wx6*HO\rJ\u0000\u0006\"HNI\u0017";
      a[11] = "2Ll\u001c\u0010B5\u000fo\u000b\u007fdB(T65lV?\u0017XASv\u001d}_\u0002Pa";
      a[12] = "k*RL]\u0011liQ[2*\u001fPmvm{k*RL]\u0011liQ[";
      a[13] = "j9\u000e;|Cmz\r,\u0013f\u0014C9F*\u0017(z\u001a,-T+m";
      a[14] = "-j&=\f\u001cbl8\u0002桵厥栉佌桍栛伱桿位栈T?\u0017\u0014/q.p\u0011\n";
      a[15] = "mE\u001f3KNj\u0006\u001c$$`\u00154$\u0012s|\t!<\ni$mE\u001f3KNj\u0006\u001c$";
      a[16] = "cPsx\u00158>R9ds叅厙可桛栛桪叅厙可桛\u0002Ho!\u0010\"3\u0010e$J";
      a[17] = "\u0012\u001ao;sM\u0015Yl,\u001cxkeH\u000b\u001c\u001e\u0015_i)v\u0019V\\~";
      a[18] = "C0\u001f?I\u0003\f6\u0001\u0000只厺厽伖厮參只厺桧桒m=R\u000bA+\u0017rT\u0015";
      a[19] = "(\u001b_\u0012\u0001|u\u0019\u0015\u000eg伟栈桾桷桱伺伟佌伺伳h\\+j[\u000eY\u0004!o\u0001";
      a[20] = "\u0005\u0001Fc\u0013\u0011\u0002BEt|4fvl\u001eEEGBRtB\u0006DU";
      a[21] = "s\u001f\u0017nL\u0006<\u0019\tQ佱伡伓伹伸伌佱县厍厧elW\u000eq\u0004\u001f#Q\u0010";
      a[22] = "}\u0018\u001c\u007fYLz[\u001fh6j\r|$Uy|\tk!\u0002\u000f\u0018?[\bh\b[<L";
      a[23] = ";<EB\u001c;<\u007fFUs\u001dKX}h<\u000bKS>\u0006M*\u007fmT\u0001\u000e)h";
      a[24] = "%T\th\u000e.\"\u0017\n\u007fa\bU01B;\tPjK+\u001a9s\u0000Lh\u0019.";
      a[25] = "J^!)\u000f\u0018M\u001d\">`>::\u0019\u00038/)8\u001e\u0019`KM\u001b';\nL\u000e\u00180";
      a[26] = "y\u0007t`\t\"~Dwwf\u0002\u0004dB\u001d_v;D`wX58S";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖大狗叫";
   }
}
