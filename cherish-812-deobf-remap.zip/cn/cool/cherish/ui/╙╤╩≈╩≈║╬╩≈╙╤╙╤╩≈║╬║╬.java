package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.module.impl.display.何友何友树何树友友树;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class 友树树何树友友树何何 implements IWrapper, 何树友 {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[29];
   private static final String[] g = new String[29];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(1373769936571450262L, 6614185111234426780L, MethodHandles.lookup().lookupClass()).a(10631098464914L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(81230878776285L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[5];
      int var7 = 0;
      String var6 = "ä\u0005\u000f\u0019§ûV.G\u0095Jb\u0082d\u00ad2 Ñ\u0013©é¬1ø µI\u0086\u0016>à9]H¥\u0018K\u001e\u001eR÷\u008cMÕ÷8\u008a1\u0004\u0017\u0090RÈô \u0091î(Û\u000fq¢««·Õ\u0084\u00175#\u0097§s\u00109ÁÎ\u009fQ\t0Õ÷\u00071×)ç\u0084\u0010T-k'H\u0092È\u0017";
      byte var8 = 98;
      char var5 = 24;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = b(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     b = var9;
                     c = new String[5];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ãÕµQeU\u00807\u008e8dý¡H\u0089> «\u0086\u0010`\u008c\u0088\nw.ûr(@\u007f¢\u001bk`\u0017\u0083ÃõÚ«ææ®\u0085¦¬óq";
                  var8 = 49;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public static void D(Render2DEvent event, float x, float y, float width, float height, 何友何友树何树友友树 module) {
      树何何友树何友何树何.S();
      PoseStack var10000 = event.poseStack();
      float var10002 = y + -6.0F;
      float var10004 = height - -6.0F + (module.树树友何树树何树树何.getValue() ? 9.0F : 7.0F);
      Color a = new Color(27, 27, 27, 247);
      float ax = var10004;
      float axx = var10002;
      ShaderUtils.o(var10000, 100739365455537L, x, axx, width, ax, 6.5F, a);
      Cherish.instance
         .t()
         .H(23)
         .Q(
            event.poseStack(),
            HUD.instance.友何友树树何树友友友.K("Chinese") ? "背包显示" : "Inventory",
            x + 20.0F,
            y - 1.0F,
            HUD.instance.getColor(1).getRGB(),
            module.友树友树友树树友何友.getValue(),
            0.5
         );
      if (module.树树友何树树何树树何.getValue()) {
         RenderUtils.drawGradientRectL2R(
            event.poseStack(), x, y + 13.0F, width - 1.0F, 0.5F, HUD.instance.getColor(0).getRGB(), HUD.instance.getColor(4).getRGB()
         );
      }

      Cherish.instance.t().r(51).Q(event.poseStack(), "k", x + 3.7F, y - 7.0F, HUD.instance.getColor(1).getRGB(), module.友树友树友树树友何友.getValue(), 0.5);
      ShaderUtils.o(event.poseStack(), 100739365455537L, x, y, 3.5F, 12.0F, 2.32F, HUD.instance.getColor(1));
      if (event.side() == Event.Side.POST) {
         m(event.guiGraphics(), x + 2.0F, y + -6.0F + (module.树树友何树树何树树何.getValue() ? 22 : 20), x, y);
      }

      if (Module.Z() == null) {
         树何何友树何友何树何.N("FIZEKc");
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 56;
               case 1 -> 37;
               case 2 -> 5;
               case 3 -> 43;
               case 4 -> 24;
               case 5 -> 54;
               case 6 -> 49;
               case 7 -> 46;
               case 8 -> 33;
               case 9 -> 28;
               case 10 -> 27;
               case 11 -> 58;
               case 12 -> 44;
               case 13 -> 31;
               case 14 -> 60;
               case 15 -> 4;
               case 16 -> 9;
               case 17 -> 48;
               case 18 -> 8;
               case 19 -> 11;
               case 20 -> 25;
               case 21 -> 13;
               case 22 -> 41;
               case 23 -> 38;
               case 24 -> 63;
               case 25 -> 1;
               case 26 -> 21;
               case 27 -> 22;
               case 28 -> 2;
               case 29 -> 14;
               case 30 -> 40;
               case 31 -> 61;
               case 32 -> 59;
               case 33 -> 62;
               case 34 -> 0;
               case 35 -> 20;
               case 36 -> 45;
               case 37 -> 29;
               case 38 -> 32;
               case 39 -> 51;
               case 40 -> 6;
               case 41 -> 10;
               case 42 -> 12;
               case 43 -> 18;
               case 44 -> 47;
               case 45 -> 30;
               case 46 -> 42;
               case 47 -> 35;
               case 48 -> 7;
               case 49 -> 52;
               case 50 -> 55;
               case 51 -> 23;
               case 52 -> 57;
               case 53 -> 16;
               case 54 -> 53;
               case 55 -> 17;
               case 56 -> 50;
               case 57 -> 3;
               case 58 -> 39;
               case 59 -> 34;
               case 60 -> 15;
               case 61 -> 26;
               case 62 -> 19;
               default -> 36;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'J' && var8 != 198 && var8 != 'n' && var8 != 228) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 235) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'W') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'J') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 198) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'n') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树树何树友友树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 4061;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友树树何树友友树何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u0099P\u0012E\u0013su2*\u0087\u000fBæÎ~æ, ÃÏ²P\u0089n0\u0005Ç>%\u008cã\u0018ßç, k)i¸M·\u0098Ý")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static void a() {
      f[0] = "}\u0006P\u0006JprF\u001d\r@mw\u001b\u0016KPv0厣桯桴佰栎叕厣桯估佰";
      f[1] = "\u0013EDDB\u0005\u0018JU\u000b>\u001c\u0017P[H\t,\u0001GWU\u0018\u0000\u0016J";
      f[2] = "\u0004J`\u0013'R\u0004JwO+]\u001e\u0001wQ#^\u0004[:M&Z\u0013Jf\u0013\u0006T\tNxm&Z\u0013Jf";
      f[3] = "\u00057Eu#\u000f\u00057R)/\u0000\u001f|F4<\n\u000f|X58\u0003\u0005&^)7H\"<G> \u0012\u0004 H\u0016+\b\u001e";
      f[4] = "Mk(W\u000e8B+e\\\u0004%Gvn\u001a\u0014>\u0000栔体佡厪框佻収体栥伴";
      f[5] = "\u0019K=>\r\u0011\u0012D,qp\t\u0001C%8";
      f[6] = "gn.^_;gn9\u0002S4}%9\u001c[7g\u007ft=[<lh(\u0011T&";
      f[7] = "{VGh\u001c\u000e{VP4\u0010\u0001a\u001dP*\u0018\u0002{G\u001d!\u0004\u000e;@P4\u0014\u0002{@\u001d\u0015\u0012\u0015pV]";
      f[8] = "\u00101.W=\u001f\u001019\u000b1\u0010\nz9\u00159\u0013\u0010 t\u001e%\u001fP\u00125\u0017$";
      f[9] = void.class;
      g[9] = "java/lang/Void";
      f[10] = "7gK\u0001\u0015L8'\u0006\n\u001fQ=z\rL\u001fU1g\u0011L\u001fU1g\u0011\u0011Tf\"l\u000b\u0016^p=m\u0000";
      f[11] = "%Y\u0003[A\b*\u0019NPK\u0015/DE\u0016C\b\"BA]\u0000\u000e+GA\u0016J\u000e5GAYWI伓叼佸右栿伲桗叼另栩";
      f[12] = "~e#%t\u0003q%n.~\u001etxehm\rq~hhr\u0001mg#\u0004t\u0003qnl(M\rq~h";
      f[13] = "\"AhgN)-\u0001%lD4(\\.*L)%Z*a\u000f/,_**E/2_*eXh\tz\u0002";
      f[14] = "}i|\u0012'\u0015r)1\u0019-\bwt:_>\u001brr7_!\u0017nk|<'\u001e{Q3\u001d=\u001f";
      f[15] = "\u0005G@V|i\n\u0007\r]vt\u000fZ\u0006\u001b~i\u0002\\\u0002P=K\tM\u001bYv";
      f[16] = "\\ne\u001ey\u0017hMj^4\u001cbPo\u0003?ZjMb\u0005;\u0011)oi\u0014\"\u0018b\u0019";
      f[17] = "\u0017\u001e}k(\\\u001c\u0011l$IR\u0017\u001ah~";
      f[18] = "\ts%#1Q\\a1sO~``:u&B\u001d4(?/,";
      f[19] = "Q@kYz\u0003P\u0003{)n9\u0005\u0007`\u0012~\u0006ZF4C\u0007\u0000\u0002P2P8_C\u0004c)";
      f[20] = "\u007f<$J\u0004[)9w_9S\u0011av\u0019\b\u0000\u0011ZrO_X!=sXR\r";
      f[21] = "[_\u0006`z\fY\u0003\u0006-\u0014f`TH=h\f\f\u0005\u000e`e=";
      f[22] = "\u007f^SuBI)Y\bs#M\u0014\u000f\u0000r\u0013\u001b\u0014>\u0004$L\u00128\u0000D(Y\u001e";
      f[23] = "e-^s\"\u000e3*\u0005uC\n\u000e|\rt}^\u000eM\t11\u00146.Xq\u007fX";
      f[24] = "J\u0012N\u0002/{HNNOA\fq\u0019\u0000_={\u001dHF\u00020JOEDU}/\u0001OA_A";
      f[25] = "]pe-3P\u001c9t8\u000ec%\u0010UV1\u0000\u000e04=pI\u001f%";
      f[26] = "4\r04\u0002bkL>;{叐栒县桂厇桢栊又伡厘DKoi\u0011a;\u0011}g\r";
      f[27] = "\"/Q_fs}n_P\u001f栛栄厝佧栶栆佟栄桇佧//~\u007f3\u0000Pulq/";
      f[28] = "!EiO7\u000fa@/J]右位古栋栰伀栩叓古发)4\u000biNoL-[(\u001b";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树树何树友友树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void m(GuiGraphics graphics, float startX, float startY, float moduleX, float moduleY) {
      树何何友树何友何树何.S();
      if (mc.player != null) {
         int itemX = (int)startX;
         int itemY = (int)startY;
         boolean hasStacks = false;
         int i = 9;
         Slot slot = mc.player.inventoryMenu.getSlot(9);
         ItemStack stack = slot.getItem();
         graphics.pose().pushPose();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         if (!stack.isEmpty()) {
            hasStacks = true;
         }

         graphics.renderItemDecorations(mc.font, stack, itemX, itemY);
         graphics.renderItem(stack, itemX, itemY);
         graphics.pose().popPose();
         if (itemX < moduleX + 144.0F) {
            itemX += 18;
         }

         int var10000 = (int)startX;
         itemY += 20;
         i++;
         if (mc.screen instanceof InventoryScreen) {
            Cherish.instance
               .t()
               .H(20)
               .q(graphics.pose(), "Already in inventory", 39.0F + moduleX - 2.0F, moduleY + 34.0F, new Color(255, 255, 255, 155).getRGB());
         }

         if (!hasStacks) {
            Cherish.instance.t().H(20).q(graphics.pose(), "Empty...", 70.0F + moduleX - 3.0F, moduleY + 34.0F, new Color(255, 255, 255, 155).getRGB());
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static String HE_JIAN_GUO() {
      return "我是何树友";
   }
}
