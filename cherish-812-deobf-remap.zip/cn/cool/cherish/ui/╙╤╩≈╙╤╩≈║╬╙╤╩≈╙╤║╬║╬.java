package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.module.impl.display.友树树树树树树友树友;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class 友树友树何友树友何何 implements IWrapper, 何树友 {
   private static String 友树树何友何树友何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[24];
   private static final String[] g = new String[24];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1755251037404756644L, -6142300864671156370L, MethodHandles.lookup().lookupClass()).a(44992826099075L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 24432444289588L;
      a();
      b<"ê">("eGdj8b", 3510377323658503787L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[6];
      int var5 = 0;
      String var4 = "\bÏÀ\u0084Åµh\u008eJÊ\"T+\u008d¢Ü(\u0088²ò\n£y \u0092\u008c^Å\"Z@ÌW\tÈ\n¹@UAh46ïÐ_\u0099$42ñ\u001cùÞÔ\u00983 \u000eT¿\u0098Ãü\u0091Ïyó\u0095bc\u001ckC_»n2¨¨Äú4c³Þ\u0003YÔÐ\u0010\u008f\u0083L]ëø:vÉ<Ö0\u0006î\u00828";
      byte var6 = 107;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = b(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     b = var7;
                     c = new String[6];
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "t\tLó¨/XÕ5(É4J\u0005ä¶¯Õ|\u0018¿áÁt \u0098¥ýÅê)Ó¬#\u009aìî\u0001ª\u0005ÿ}ea\u0014g¿\u008bÛF¿#\u000eXø\b¨";
                  var6 = 57;
                  var3 = 24;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 15;
               case 1 -> 50;
               case 2 -> 56;
               case 3 -> 34;
               case 4 -> 45;
               case 5 -> 28;
               case 6 -> 31;
               case 7 -> 5;
               case 8 -> 52;
               case 9 -> 16;
               case 10 -> 47;
               case 11 -> 55;
               case 12 -> 22;
               case 13 -> 51;
               case 14 -> 53;
               case 15 -> 24;
               case 16 -> 60;
               case 17 -> 63;
               case 18 -> 8;
               case 19 -> 17;
               case 20 -> 42;
               case 21 -> 54;
               case 22 -> 37;
               case 23 -> 59;
               case 24 -> 13;
               case 25 -> 9;
               case 26 -> 21;
               case 27 -> 39;
               case 28 -> 48;
               case 29 -> 29;
               case 30 -> 32;
               case 31 -> 35;
               case 32 -> 14;
               case 33 -> 11;
               case 34 -> 62;
               case 35 -> 19;
               case 36 -> 12;
               case 37 -> 18;
               case 38 -> 44;
               case 39 -> 20;
               case 40 -> 30;
               case 41 -> 38;
               case 42 -> 26;
               case 43 -> 1;
               case 44 -> 6;
               case 45 -> 33;
               case 46 -> 58;
               case 47 -> 0;
               case 48 -> 49;
               case 49 -> 57;
               case 50 -> 25;
               case 51 -> 41;
               case 52 -> 40;
               case 53 -> 10;
               case 54 -> 43;
               case 55 -> 23;
               case 56 -> 61;
               case 57 -> 36;
               case 58 -> 7;
               case 59 -> 46;
               case 60 -> 4;
               case 61 -> 2;
               case 62 -> 27;
               default -> 3;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'W' && var8 != 229 && var8 != 'h' && var8 != 'T') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'o') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 234) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'W') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 229) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'h') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树友树何友树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void b(GuiGraphics graphics, float startX, float startY, float moduleX, float moduleY) {
      long a = 友树友树何友树友何何.a ^ 93441580974032L;
      b<"ê">(4419146776790613745L, a);
      if (mc.player != null) {
         int itemX = (int)startX;
         int itemY = (int)startY;
         boolean hasStacks = false;
         int i = 9;
         Slot slot = b<"W">(mc.player, 4419074679402648394L, a).getSlot(9);
         ItemStack stack = slot.getItem();
         graphics.pose().pushPose();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         if (!stack.isEmpty()) {
            hasStacks = true;
         }

         graphics.renderItemDecorations(b<"W">(mc, 4418634671507618864L, a), stack, itemX, itemY);
         graphics.renderItem(stack, itemX, itemY);
         graphics.pose().popPose();
         if (itemX < moduleX + 144.0F) {
            itemX += 18;
         }

         int var10000 = (int)startX;
         itemY += 20;
         i++;
         if (b<"W">(mc, 4418872480435385579L, a) instanceof InventoryScreen) {
            Cherish.instance
               .h()
               .n(20)
               .c(graphics.pose(), a<"k">(19082, 4467683771491998661L ^ a), 39.0F + moduleX - 2.0F, moduleY + 34.0F, new Color(255, 255, 255, 155).getRGB());
         }

         if (!hasStacks) {
            Cherish.instance
               .h()
               .n(20)
               .c(graphics.pose(), a<"k">(19310, 1668861056942135845L ^ a), 70.0F + moduleX - 3.0F, moduleY + 34.0F, new Color(255, 255, 255, 155).getRGB());
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static void x(String var0) {
      友树树何友何树友何何 = var0;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11289;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友树友树何友树友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树友树何友树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      f[0] = "\"\u001b\u001e?\u0018r-[S4\u0012o(\u0006Xr\u0002to厾校厗桦佈厊桤叻伉伢";
      f[1] = "$BVEu\u001f/MG\n\b\u0007<JNC";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = "V\u000f=?\u001as]\u0000,pfjR\u001a\"3QZD\r..@vS\u0000";
      f[4] = "rH\u0006\t{m}\bK\u0002qpxU@DymuSD\u000f:k|VDDpkbVD\u000bm,Ysl";
      f[5] = "\u0002\\!,}H\r\u001cl'wU\bAgadF\rGja{J\u0011^!\u0002}C\u0004dn#gB";
      f[6] = "OY \u001eJy@\u0019m\u0015@dEDfS@`IYzS@`IYz\u000e\u000bSZR`\t\u0001EESk";
      f[7] = "3bJ\u0006<N<\"\u0007\r6S9\u007f\fK>N4y\b\u0000}H=|\bK7H#|\b\u0004*\u000f厛栝桵桴桂栰桁叇桵厮";
      f[8] = "+Ez/j{$\u00057$`f!X<bsu$^1bly8Gz\u000ej{$N5\"Su$^1";
      f[9] = "bD[sP!bDL/\\.x\u000fL1T-bU\u0001\u0010T&iB]<[<";
      f[10] = "B+^)[>B+IuW1X`Ik_2B:\u0004`C>\u0002=IuS2B=\u0004TU%I+D";
      f[11] = "e\u0006O!#+e\u0006X}/$\u007fMXc''e\u0017\u0015\u007f\"#r\u0006I!\u0002-h\u0002W_\"#r\u0006I";
      f[12] = "2/'gNJ2/0;BE(d$&QO8d:'UF2><;Z\r\u0015$%,MW38*\u0004FM)";
      f[13] = "-B@U&R-BW\t*]7\tW\u0017\"^-S\u001a\u001c>Rma[\u0015?";
      f[14] = "\u001br)e\u000b \u0010}8*j.\u001bv<p";
      f[15] = "j\u000f\u0005JFb2\u0019\u0011\u001c>D\u00113+$\u0002{$\u0006\u000fZZm0P";
      f[16] = "<\rx+MW;[}Z\u0002-cU}\"\u0013L:Z{br\u0014:\fs&\u0010\u0012(UpZ";
      f[17] = "=mo\u0012-_:;jc{%a%y\u0019nYb>w\u001e\u0012\u001f\".q\u001fn\u001c9 vc";
      f[18] = "\f\u00009B*8TO=B@odDjGq<d\u007fd\u0018x:\nN?\u001d8s";
      f[19] = "H\u0005/\u001eG}OS*o\u0004\u0007\u0017]*\u0017\u0019fNR,Wx";
      f[20] = "eqW\u007fW1a.Uqh#\f%\u0015xVw\f\u0014\u001dy\u0015?`hE;Q(";
      f[21] = "'(JWbN|:\u001f\u0006\u001c叱佇优叢厩栅栫栃桜核j!Q\u007fy\u001c\u0004f\u0003';";
      f[22] = "\u000e4\u0012$5BDj\u0017\"T厾佨栕样厈厗厾佨叏样Ko\u0002\fj\u0013,(\u0019[0";
      f[23] = "tr`\u001f>Fp-b\u0011\u0001T\u001d&\"\u00181\u0002\u001d\u0017$O{W'x%Eh^";
   }

   public static String t() {
      return 友树树何友何树友何何;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void R(Render2DEvent event, float x, float y, float width, float height, 友树树树树树树友树友 module) {
      long a = 友树友树何友树友何何.a ^ 108014949263677L;
      b<"ê">(-1459517756566575076L, a);
      RenderUtils.drawRoundedRect(event.poseStack(), x, y, width, height + 9.0F, 0.0, new Color(23, 23, 23));
      RenderUtils.drawGradientRectL2R(event.poseStack(), x, y, width, 1.0F, HUD.instance.getColor(0).getRGB(), HUD.instance.getColor(4).getRGB());
      if (b<"W">(module, -1459373189726368689L, a).getValue()) {
         RenderUtils.drawGradientRectL2R(event.poseStack(), x, y + 14.0F, width, 1.0F, HUD.instance.getColor(0).getRGB(), HUD.instance.getColor(4).getRGB());
      }

      Cherish.instance
         .h()
         .n(b<"W">(HUD.instance, -1459303503801150541L, a).C(a<"k">(16527, 3028742682539755311L ^ a)) ? 20 : 19)
         .L(
            event.poseStack(),
            b<"W">(HUD.instance, -1459303503801150541L, a).C(a<"k">(22178, 2321017667642822913L ^ a))
               ? a<"k">(16698, 4980800026701563549L ^ a)
               : a<"k">(16007, 5265897566731598118L ^ a),
            x + width / 2.0F - 1.0F,
            y + 4.0F,
            HUD.instance.getColor(1).getRGB()
         );
      if (event.side() == b<"h">(-1460892781006186369L, a)) {
         b(event.guiGraphics(), x + 2.0F, y + 12.0F + 5.0F, x, y);
      }
   }

   private static String LIU_YA_FENG() {
      return "职业技术教育中心学校";
   }
}
