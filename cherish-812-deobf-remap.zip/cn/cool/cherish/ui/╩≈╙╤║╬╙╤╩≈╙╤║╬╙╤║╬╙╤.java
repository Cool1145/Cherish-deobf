package cn.cool.cherish.ui;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 树友何友树友何友何友 implements 友友何何何树友友何树, 何树友 {
   private 树友何友树友何友何友.友何友树友树何何何树 友友何友树何友友友树 = 树友何友树友何友何友.友何友树友树何何何树.友树何何友何树友何树;
   private static final float 何树树何友何树树树树 = 14.0F;
   private static final float 树树友友友树友树何何 = 60.0F;
   private static final float 何何何树友树何友何友 = 45.0F;
   private static final float 友友何树树友友树树树 = 8.0F;
   private static final float 树友友树友友何树友友 = 4.0F;
   private static final float 友树何友树树树何何友 = 4.0F;
   private static final float 树友何树何友树友树树 = 4.0F;
   private long 何何友友友树何何友树 = 0L;
   private float 树友树树友友友树何友 = 0.0F;
   private boolean 树何友何友树树树树树 = false;
   private boolean 何树友何友何友树树树 = false;
   private static final long a;
   private static final Object[] b = new Object[42];
   private static final String[] c = new String[42];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3249779757342503977L, -8116943031307337757L, MethodHandles.lookup().lookupClass()).a(263628845796223L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   private void J() {
      树友树树何友何何树友.E();
      long currentTime = System.currentTimeMillis();
      float deltaTime = this.何何友友友树何何友树 == 0L ? 0.0F : (float)(currentTime - this.何何友友友树何何友树);
      this.何何友友友树何何友树 = currentTime;
      float targetAnimation = this.树何友何友树树树树树 ? 1.0F : 0.0F;
      if (Math.abs(this.树友树树友友友树何友 - targetAnimation) > 0.001F) {
         float diff = targetAnimation - this.树友树树友友友树何友;
         float interpolationFactor = deltaTime / 150.0F * 2.0F;
         if (interpolationFactor >= 1.0F) {
            this.树友树树友友友树何友 = targetAnimation;
         }

         this.树友树树友友友树何友 += diff * interpolationFactor;
         this.树友树树友友友树何友 = Mth.clamp(this.树友树树友友友树何友, 0.0F, 1.0F);
      }

      this.树友树树友友友树何友 = targetAnimation;
   }

   @Override
   public float Z(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value) {
      树友树树何友何何树友.E();
      String valueName = panel.友友何友何树何何树树.树树何树友树何树友树 ? value.r() : value.V();
      float nameWidth = panel.友友何友何树何何树树.友何何何何树友树何树.D(valueName);
      Objects.requireNonNull(panel.友友何友何树何何树树);
      float availableWidthForControl = 106.0F - nameWidth - 4.0F;
      if (!(nameWidth > 58.300003F) && availableWidthForControl < 26.5F) {
      }

      float baseHeight = 28.8F;
      if (this.树友树树友友友树何友 > 0.01F) {
         baseHeight = 28.8F + 57.0F * this.树友树树友友友树何友;
      }

      return baseHeight;
   }

   private void V(GuiGraphics g, 树树树友何何树何友何 panel, 树友何何树树何友友何 setting, float x, float y, float width, float height, int alpha) {
      树友树树何友何何树友.Y();
      树友何友树友何友何友.友何友友何友树树树何 hsb = new 树友何友树友何友何友.友何友友何友树树树何(setting.getValue());
      if (0.0F <= width) {
         float currentSaturation = 0.0F / width;
         Color topColorFullAlpha = Color.getHSBColor(hsb.友树友树何树何何友树, currentSaturation, 1.0F);
         Color bottomColorFullAlpha = Color.BLACK;
         Color topColorWithPickerAlpha = panel.友友何友何树何何树树.o(topColorFullAlpha, alpha);
         Color bottomColorWithPickerAlpha = panel.友友何友何树何何树树.o(bottomColorFullAlpha, alpha);
         g.fillGradient(
            (int)(x + 0.0F), (int)y, (int)(x + 0.0F + 1.0F), (int)(y + height), topColorWithPickerAlpha.getRGB(), bottomColorWithPickerAlpha.getRGB()
         );
      }

      float markX = x + hsb.何树何何树树树何树树 * width;
      float markY = y + (1.0F - hsb.树友树何何树树何友友) * height;
      RenderUtils.I(g.pose(), markX - 2.0F, markY - 2.0F, 4.0F, 4.0F, panel.友友何友何树何何树树.o(Color.WHITE, alpha).getRGB(), 1.0F);
      RenderUtils.I(g.pose(), markX - 3.0F, markY - 3.0F, 6.0F, 6.0F, panel.友友何友何树何何树树.o(Color.BLACK, alpha).getRGB(), 1.0F);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   public void x() {
      this.友友何友树何友友友树 = 树友何友树友何友何友.友何友树友树何何何树.友树何何友何树友何树;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友何友树友何友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 208 && var8 != 252 && var8 != 212 && var8 != 'A') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'S') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 198) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 208) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 252) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   @Override
   public void a(GuiGraphics g, 树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      int var10000 = 树友树树何友何何树友.E();
      this.J();
      int a = var10000;
      树友何何树树何友友何 cv = (树友何何树树何友友何)value;
      String name = panel.友友何友何树何何树树.树树何树友树何树友树 ? value.r() : value.V();
      float nameWidth = panel.友友何友何树何何树树.友何何何何树友树何树.D(name) + 2.0F;
      float currentSettingY = valy;
      panel.友友何友何树何何树树
         .友何何何何树友树何树
         .s(g.pose(), name, valx + 2.0F, valy + 8.0F - panel.友友何友何树何何树树.友何何何何树友树何树.x() / 2.0F, panel.友友何友何树何何树树.o(panel.友友何友何树何何树树.树友何何友树友友何树, alpha).getRGB());
      if (nameWidth > valw * 0.55F || valw - nameWidth - 4.0F < valw * 0.25F) {
         currentSettingY = valy + 12.8F;
      }

      float previewBoxX = valx + valw - 14.0F - 2.0F;
      float previewBoxY = currentSettingY + 8.0F - 7.0F;
      RenderUtils.drawRectangle(g.pose(), previewBoxX, previewBoxY, 14.0F, 14.0F, panel.友友何友何树何何树树.o(cv.getValue(), alpha).getRGB());
      RenderUtils.I(g.pose(), previewBoxX, previewBoxY, 14.0F, 14.0F, panel.友友何友何树何何树树.o(Color.GRAY, alpha).getRGB(), 1.0F);
      currentSettingY += 16.0F;
      if (this.树友树树友友友树何友 > 0.01F) {
         float pickerContentStartX = valx + (valw - 84.0F) / 2.0F;
         float pickerVisualY = currentSettingY + 4.0F + 4.0F;
         float pickerBgY = currentSettingY + 4.0F;
         float animatedPickerBgHeight = 53.0F * this.树友树树友友友树何友;
         RenderUtils.drawRectangle(
            g.pose(), pickerContentStartX - 4.0F, pickerBgY, 92.0F, animatedPickerBgHeight, panel.友友何友何树何何树树.o(new Color(30, 30, 30, 220), alpha).getRGB()
         );
         if (this.树友树树友友友树何友 > 0.8F) {
            int pickerAlpha = (int)(alpha * ((this.树友树树友友友树何友 - 0.8F) / 0.2F));
            this.V(g, panel, cv, pickerContentStartX, pickerVisualY, 60.0F, 45.0F, pickerAlpha);
            float hueSliderX = pickerContentStartX + 60.0F + 4.0F;
            this.v(g, panel, cv, hueSliderX, pickerVisualY, 8.0F, 45.0F, pickerAlpha);
            float alphaSliderX = hueSliderX + 8.0F + 4.0F;
            this.K(g, panel, cv, alphaSliderX, pickerVisualY, 8.0F, 45.0F, pickerAlpha);
            if (this.何树友何友何友树树树 && this.友友何友树何友友友树 != 树友何友树友何友何友.友何友树友树何何何树.友树何何友何树友何树) {
               this.O(cv, mousex, mousey, pickerContentStartX, pickerVisualY, 60.0F, 45.0F, hueSliderX, alphaSliderX, 8.0F);
            }
         }
      }

      if (Module.Z() == null) {
         树友树树何友何何树友.L(++a);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 63;
               case 1 -> 50;
               case 2 -> 47;
               case 3 -> 38;
               case 4 -> 39;
               case 5 -> 8;
               case 6 -> 13;
               case 7 -> 29;
               case 8 -> 15;
               case 9 -> 22;
               case 10 -> 32;
               case 11 -> 14;
               case 12 -> 56;
               case 13 -> 37;
               case 14 -> 36;
               case 15 -> 41;
               case 16 -> 45;
               case 17 -> 27;
               case 18 -> 5;
               case 19 -> 17;
               case 20 -> 53;
               case 21 -> 40;
               case 22 -> 4;
               case 23 -> 9;
               case 24 -> 25;
               case 25 -> 35;
               case 26 -> 19;
               case 27 -> 48;
               case 28 -> 44;
               case 29 -> 61;
               case 30 -> 59;
               case 31 -> 16;
               case 32 -> 3;
               case 33 -> 43;
               case 34 -> 54;
               case 35 -> 34;
               case 36 -> 18;
               case 37 -> 60;
               case 38 -> 51;
               case 39 -> 7;
               case 40 -> 26;
               case 41 -> 62;
               case 42 -> 28;
               case 43 -> 2;
               case 44 -> 24;
               case 45 -> 42;
               case 46 -> 46;
               case 47 -> 31;
               case 48 -> 23;
               case 49 -> 12;
               case 50 -> 20;
               case 51 -> 52;
               case 52 -> 57;
               case 53 -> 11;
               case 54 -> 10;
               case 55 -> 55;
               case 56 -> 1;
               case 57 -> 30;
               case 58 -> 0;
               case 59 -> 33;
               case 60 -> 49;
               case 61 -> 6;
               case 62 -> 21;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "7\u007fq?\u001b/8?<4\u00112=b7r\u0001)z栀桎桍县伕企栀伊厗伡";
      b[1] = "}\u001b5k)Rr[x`#Ow\u0006s&3T0传栊佝厍叶佋传叐參桗";
      b[2] = "C\u0000\u000b\u0016ghL@F\u001dmuI\u001dM[}n\u000e桿叮桤栙佒叫伻佰桤參";
      b[3] = int.class;
      c[3] = "java/lang/Integer";
      b[4] = "T\u001d\u0000\u0018\u001aS[]M\u0013\u0010N^\u0000FU\u0000U\u0019桢句伮厾栭叼伦句伮厾";
      b[5] = "\f{j {I\u0007t{o\u0007P\bnu,0`\u001eyy1!L\tt";
      b[6] = "`Y\u0007[&\u0007}L_yg\neJ";
      b[7] = "U4LJ9IZt\u0001A3T_)\n\u0007#O\u0018桋厩佼厝样叽伏厩佼厝\u0002叽伏厩叢伃叭栧桋桳佼";
      b[8] = float.class;
      c[8] = "java/lang/Float";
      b[9] = ")\u0018Bj\u001f\u0014&X\u000fa\u0015\t#\u0005\u0004'\u0005\u0012d桧厧作去桪厁伣厧作去_厁伣厧栘去桪伟伣伹栘";
      b[10] = long.class;
      c[10] = "java/lang/Long";
      b[11] = boolean.class;
      c[11] = "java/lang/Boolean";
      b[12] = "4To2x0;\u0014\"9r->I)\u007fb6y佯伔厚叜桎伂栫伔厚栆";
      b[13] = void.class;
      c[13] = "java/lang/Void";
      b[14] = "tlW\u000fnE{,\u001a\u0004dX~q\u0011BlEsw\u0015\t/gxf\f\u0000d";
      b[15] = "lA\u000eT\n\u0014Xb\u0001\u0014G\u001fR\u007f\u0004ILYZb\tOH\u0012\u0019@\u0002^Q\u001bR6";
      b[16] = "E~n\\z}Nq\u007f\u0013\u001bsEz{I";
      b[17] = "h#\u0001\u0016'\u007fj>\u0001\u001d\u001d叐伋桁桥桫栄低桏厛县r#h+<F\u001e!u+7";
      b[18] = "\u001e\u001c\u0014\u0004E$\u001c\u001bV\u0001!佉栻伾伻栢核栍使桺桿;\u001f)\\R\u0018RKz\u001b\u0019";
      b[19] = "\b*/\nzY\u0002)1Y\u0013H2l/IqZJ4wNj!\t27VhYQj0M\u0013";
      b[20] = "Rp^\nS\u0015Pw\u001c\u000f7格伳栖可佨佪格厭佒可5\rG_iT\u000eG@Ww";
      b[21] = "!\u0002\u0013.G\u001fw\nIkyr\u0010\u0011\u0014(\u0014Db\u0017\u0015/\u001e ";
      b[22] = "bYR\u0000\u001b_`DR\u000b!佮企使佲厧叢株企栻栶d\u001fH!F\u0015\b\u001dU!M";
      b[23] = "idGter:cFq[桕桉企栵叛桂休桉原栵\u0018d*<<\u0016##\"-2";
      b[24] = ",-#;[<&.=h2伙栏厓伛叆佯厇栏桉桟\u0005\r\"z0|>J*k>";
      b[25] = "m8@i5\u000bo%@b\u000f厤桊伞你収佒桾厐伞栤\r1\u001c.'\u0007a3\u0001.,";
      b[26] = "Y,NI0\u0015\u000e6R\u000eR2`sPA4\u000e[9WI*vQ(^\u0016c\u0014[6\\\nR";
      b[27] = "\u0001\u000f18\u0001C\u0000V>Y叺叿伷厥伏桀佤佡桳桿R`\u0001W\u0006Xl3\u0006V\u0003";
      b[28] = "f\u0017U-?\u00115\u0010T(\u0001召伂佲佣伜栘召框佲栧A1I9HU~dR1\u0017";
      b[29] = ">_qW7\riEm\u0010U#\u0007\u0000o_3\u0016<JhW-n";
      b[30] = "f5bbq@d(biK可厛伓叜栟厈可厛厍佂\u0006uW%*%jwJ%!";
      b[31] = "%f\u0001R.\u0014/e\u001f\u0001G桵叜栂桽厯厄厯栆但厧lyQa*\u001a\u0005-\u0002&a";
      b[32] = "\r\u0011t\u0000=\u0013\b\u0019v\u0002\f8u<F{\fNU\f5\tmK]\u000e7";
      b[33] = "!\u0018<K?\nr\u001f=N\u0001栭叛佽伊古栘号叛佽桎'=Pa\u0018fF8Xc\u001a";
      b[34] = "gEEs\u0015\u001f0_Y4w-^\u001a[{\u0011\u0004eP\\s\u000f|";
      b[35] = "@g3An\u0007Jd-\u0012\u0007伢伧叙厕厼栞伢伧叙桏\u007f9\u000f\u000bh$\u0015z\u0001A`";
      b[36] = "P&NX\u0003lU.LZ2R,\u0003k-21\b;\u000fQS4\u00009\r";
      b[37] = "'fi.x1-ew}\u0011厊叞但叏栉佌厊叞变栕\u0010/2`\u007f6|-/`t";
      b[38] = "GN/w4\u0015EImrP另桢史桄伕桉佸伦史桄Hn\u0018\u0005\u0000#!:KBK";
      b[39] = "\u001bLN1\u0000s\u0019K\f4d桚古株佡体桽桚佺台叿\u000eZ~Y\u0002Bg\u000e-\u001eI";
      b[40] = "I+`\u000eIrC(~] 栓伮厕佘右根栓桪桏栜0\u001fl\u001f6?\u000bXd\u000e8";
      b[41] = "\u001c\u0010[NT\u0003\u0019\u0018YLe-z=svY\u0006YL\u0013\u0017\\\u000e[N";
   }

   private void v(GuiGraphics g, 树树树友何何树何友何 panel, 树友何何树树何友友何 setting, float x, float y, float width, float height, int alpha) {
      树友树树何友何何树友.E();
      树友何友树友何友何友.友何友友何友树树树何 hsb = new 树友何友树友何友何友.友何友友何友树树树何(setting.getValue());
      int i = 0;
      if (0.0F <= height) {
         float hue = 0.0F / height;
         Color segmentColor = Color.getHSBColor(hue, 1.0F, 1.0F);
         RenderUtils.drawRectangle(g.pose(), x, y + 0.0F, 8.0F, 1.0F, panel.友友何友何树何何树树.o(segmentColor, alpha).getRGB());
         i++;
      }

      float indicatorY = y + hsb.友树友树何树何何友树 * height;
      RenderUtils.drawRectangle(g.pose(), x - 1.0F, indicatorY - 0.5F, width + 2.0F, 1.0F, panel.友友何友何树何何树树.o(Color.WHITE, alpha).getRGB());
   }

   private void K(GuiGraphics g, 树树树友何何树何友何 panel, 树友何何树树何友友何 setting, float x, float y, float width, float height, int alpha) {
      树友何友树友何友何友.友何友友何友树树树何 hsb = new 树友何友树友何友何友.友何友友何友树树树何(setting.getValue());
      树友树树何友何何树友.E();
      Color baseColor = Color.getHSBColor(hsb.友树友树何树何何友树, hsb.何树何何树树树何树树, hsb.树友树何何树树何友友);
      int i = 0;
      if (0.0F <= height) {
         int j = 0;
         RenderUtils.drawRectangle(
            g.pose(),
            x + 0.0F,
            y + 0.0F,
            Math.min(4.0F, width - 0.0F),
            Math.min(4.0F, height - 0.0F),
            panel.友友何友何树何何树树.o(new Color(120, 120, 120), alpha).getRGB()
         );
         j += 4;
         i += 4;
      }

      i = 0;
      if (0.0F <= height) {
         Color segmentColor = new Color(
            baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), Mth.clamp((int)((1.0F - 0.0F / height) * 255.0F), 0, 255)
         );
         RenderUtils.drawRectangle(g.pose(), x, y + 0.0F, width, 1.0F, panel.友友何友何树何何树树.o(segmentColor, alpha).getRGB());
         i++;
      }

      float indicatorY = y + (1.0F - hsb.树何树友何何树友何友 / 255.0F) * height;
      RenderUtils.drawRectangle(g.pose(), x - 1.0F, indicatorY - 0.5F, width + 2.0F, 1.0F, panel.友友何友何树何何树树.o(Color.WHITE, alpha).getRGB());
   }

   @Override
   public 何何何友友何树何何何 K(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      树友树树何友何何树友.Y();
      this.何树友何友何友树树树 = true;
      树友何何树树何友友何 cv = (树友何何树树何友友何)value;
      String valueName = panel.友友何友何树何何树树.树树何树友树何树友树 ? value.r() : value.V();
      float nameWidth = panel.友友何友何树何何树树.友何何何何树友树何树.D(valueName) + 2.0F;
      if (!(nameWidth > vw * 0.55F) && vw - nameWidth - 4.0F < vw * 0.25F) {
      }

      Objects.requireNonNull(panel.友友何友何树何何树树);
      float previewBoxClickY = vy + 12.8F + 8.0F - 7.0F;
      float previewBoxClickX = vx + vw - 14.0F - 2.0F;
      if (panel.友友何友何树何何树树.g(mx, my, previewBoxClickX, previewBoxClickY, 14.0F, 14.0F)) {
         this.树何友何友树树树树树 = !this.树何友何友树树树树树;
         this.何何友友友树何何友树 = System.currentTimeMillis();
         if (!this.树何友何友树树树树树) {
            this.友友何友树何友友友树 = 树友何友树友何友何友.友何友树友树何何何树.友树何何友何树友何树;
            this.何树友何友何友树树树 = false;
         }

         return null;
      } else {
         boolean clickOnPickerComponent = false;
         if (this.树何友何友树树树树树 && this.树友树树友友友树何友 > 0.8F) {
            float pickerContentStartX = vx + (vw - 84.0F) / 2.0F;
            float pickerContentY = vy + 28.8F + 4.0F + 4.0F;
            float hueSliderClickX = pickerContentStartX + 60.0F + 4.0F;
            float alphaSliderClickX = hueSliderClickX + 8.0F + 4.0F;
            if (panel.友友何友何树何何树树.g(mx, my, pickerContentStartX, pickerContentY, 60.0F, 45.0F)) {
               this.友友何友树何友友友树 = 树友何友树友何友何友.友何友树友树何何何树.友何树树树树何树友友;
               this.O(cv, (int)mx, (int)my, pickerContentStartX, pickerContentY, 60.0F, 45.0F, hueSliderClickX, alphaSliderClickX, 8.0F);
               clickOnPickerComponent = true;
            }

            if (panel.友友何友何树何何树树.g(mx, my, hueSliderClickX, pickerContentY, 8.0F, 45.0F)) {
               this.友友何友树何友友友树 = 树友何友树友何友何友.友何友树友树何何何树.何何何何友友树何树树;
               this.O(cv, (int)mx, (int)my, pickerContentStartX, pickerContentY, 60.0F, 45.0F, hueSliderClickX, alphaSliderClickX, 8.0F);
               clickOnPickerComponent = true;
            }

            if (panel.友友何友何树何何树树.g(mx, my, alphaSliderClickX, pickerContentY, 8.0F, 45.0F)) {
               this.友友何友树何友友友树 = 树友何友树友何友何友.友何友树友树何何何树.友友何友树友友友友何;
               this.O(cv, (int)mx, (int)my, pickerContentStartX, pickerContentY, 60.0F, 45.0F, hueSliderClickX, alphaSliderClickX, 8.0F);
               clickOnPickerComponent = true;
            }

            float pickerBgX = pickerContentStartX - 4.0F;
            float pickerBgY = vy + 28.8F + 4.0F;
            if (!panel.友友何友何树何何树树.g(mx, my, pickerBgX, pickerBgY, 92.0F, 53.0F)) {
               this.友友何友树何友友友树 = 树友何友树友何友何友.友何友树友树何何何树.友树何何友何树友何树;
               this.何树友何友何友树树树 = false;
            }

            if (clickOnPickerComponent) {
               return null;
            }
         }

         float pickerBgXx = vx + (vw - 84.0F) / 2.0F - 4.0F;
         float pickerBgYCheck = vy + 28.8F + 4.0F;
         boolean mouseOverTotalPickerBg = this.树何友何友树树树树树 && this.树友树树友友友树何友 > 0.8F && panel.友友何友何树何何树树.g(mx, my, pickerBgXx, pickerBgYCheck, 92.0F, 53.0F);
         if (!panel.友友何友何树何何树树.g(mx, my, previewBoxClickX, previewBoxClickY, 14.0F, 14.0F) && !clickOnPickerComponent && !mouseOverTotalPickerBg) {
            this.何树友何友何友树树树 = false;
            this.友友何友树何友友友树 = 树友何友树友何友何友.友何友树友树何何何树.友树何何友何树友何树;
         }

         return null;
      }
   }

   private static String HE_SHU_YOU() {
      return "刘凤楠230622109211173513";
   }

   private void O(
      树友何何树树何友友何 setting,
      int mousex,
      int mousey,
      float svboxx,
      float svboxy,
      float svboxwidth,
      float svboxheight,
      float huesliderx,
      float alphasliderx,
      float slidercommonwidth
   ) {
      树友树树何友何何树友.E();
      树友何友树友何友何友.友何友友何友树树树何 hsb = new 树友何友树友何友何友.友何友友何友树树树何(setting.getValue());
      if (this.友友何友树何友友友树 == 树友何友树友何友何友.友何友树友树何何何树.友何树树树树何树友友) {
         float newSaturation = Mth.clamp((mousex - svboxx) / svboxwidth, 0.0F, 1.0F);
         float newBrightness = 1.0F - Mth.clamp((mousey - svboxy) / svboxheight, 0.0F, 1.0F);
         hsb.何树何何树树树何树树 = newSaturation;
         hsb.树友树何何树树何友友 = newBrightness;
      }

      if (this.友友何友树何友友友树 == 树友何友树友何友何友.友何友树友树何何何树.何何何何友友树何树树) {
         hsb.友树友树何树何何友树 = svboxheight == 0.0F ? 0.0F : Mth.clamp((mousey - svboxy) / svboxheight, 0.0F, 1.0F);
      }

      if (this.友友何友树何友友友树 == 树友何友树友何友何友.友何友树友树何何何树.友友何友树友友友友何) {
         hsb.树何树友何何树友何友 = svboxheight == 0.0F ? 0 : Mth.clamp((int)((1.0F - Mth.clamp((mousey - svboxy) / svboxheight, 0.0F, 1.0F)) * 255.0F), 0, 255);
      }

      setting.G(hsb.W());
   }

   private static class 友何友友何友树树树何 implements 何树友 {
      public float 友树友树何树何何友树;
      public float 何树何何树树树何树树;
      public float 树友树何何树树何友友;
      public int 树何树友何何树友何友;
      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static String HE_DA_WEI;

      public 友何友友何友树树树何(Color color) {
         float[] hsbValues = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
         this.友树友树何树何何友树 = hsbValues[0];
         this.何树何何树树树何树树 = hsbValues[1];
         this.树友树何何树树何友友 = hsbValues[2];
         this.树何树友何何树友何友 = color.getAlpha();
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-3715930570311737131L, 3418875318147966340L, MethodHandles.lookup().lookupClass()).a(276519508425065L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 238 && var8 != 214 && var8 != 197 && var8 != 204) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'x') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == '$') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 238) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 214) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 197) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树友何友树友何友何友$友何友友何友树树树何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 3;
                  case 1 -> 18;
                  case 2 -> 26;
                  case 3 -> 5;
                  case 4 -> 20;
                  case 5 -> 32;
                  case 6 -> 58;
                  case 7 -> 60;
                  case 8 -> 62;
                  case 9 -> 6;
                  case 10 -> 12;
                  case 11 -> 16;
                  case 12 -> 11;
                  case 13 -> 17;
                  case 14 -> 4;
                  case 15 -> 42;
                  case 16 -> 23;
                  case 17 -> 54;
                  case 18 -> 25;
                  case 19 -> 38;
                  case 20 -> 48;
                  case 21 -> 55;
                  case 22 -> 31;
                  case 23 -> 35;
                  case 24 -> 34;
                  case 25 -> 51;
                  case 26 -> 8;
                  case 27 -> 36;
                  case 28 -> 46;
                  case 29 -> 29;
                  case 30 -> 44;
                  case 31 -> 61;
                  case 32 -> 15;
                  case 33 -> 2;
                  case 34 -> 7;
                  case 35 -> 41;
                  case 36 -> 63;
                  case 37 -> 28;
                  case 38 -> 13;
                  case 39 -> 14;
                  case 40 -> 45;
                  case 41 -> 59;
                  case 42 -> 24;
                  case 43 -> 53;
                  case 44 -> 50;
                  case 45 -> 1;
                  case 46 -> 40;
                  case 47 -> 49;
                  case 48 -> 30;
                  case 49 -> 56;
                  case 50 -> 21;
                  case 51 -> 52;
                  case 52 -> 10;
                  case 53 -> 37;
                  case 54 -> 43;
                  case 55 -> 27;
                  case 56 -> 22;
                  case 57 -> 57;
                  case 58 -> 9;
                  case 59 -> 19;
                  case 60 -> 47;
                  case 61 -> 39;
                  case 62 -> 33;
                  default -> 0;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "%'\u00175B\u001b*gZ>H\u0006/:QxX\u001dh桘史伃另桥厍伜史伃另P厍伜史厝佸县桗桘栨伃";
         b[1] = float.class;
         c[1] = "java/lang/Float";
         b[2] = int.class;
         c[2] = "java/lang/Integer";
         b[3] = "\u0006w\u001ap\u0006o\rx\u000b?ga\u0006s\u000fe";
         b[4] = "7,v&NZe1aB栻佺桅厎佑伟栻古企厎\f{EI>5r\u007f\u001f\u001b$";
         b[5] = ":5\u001c+j~h(\u000bO佛栚伌伉桿桖栟佞案桍fvjd)%\\~8s>";
         b[6] = "\u0019\tE\u0001{jK\u0014Re栎叔桫伵佢桼栎佊厱厫?\\{p\n\u0019\u0005T)g\u001d";
         b[7] = "x\u0010\u001eJp.*\r\t.叟桊叐桨伹样佁伎叐桨d\u0017p4k\u0000^\u001f\"#|";
      }

      public Color W() {
         int rgb = Color.HSBtoRGB(this.友树友树何树何何友树, this.何树何何树树树何树树, this.树友树何何树树何友友);
         return new Color(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, this.树何树友何何树友何友);
      }

      private static String HE_SHU_YOU() {
         return "何建国230622195906030014";
      }
   }

   private static enum 友何友树友树何何何树 implements  {
      友树何何友何树友何树,
      友何树树树树何树友友,
      何何何何友友树何树树,
      树何何友何树友友树友,
      友友何友树友友友友何;

      private static final long a;
      private static final Object[] b = new Object[9];
      private static final String[] c = new String[9];
      private static int _刘凤楠230622109211173513 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(1027526202622546747L, 1699560281905253037L, MethodHandles.lookup().lookupClass()).a(265440607152930L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(132072487108013L << var2 * 8 >>> 56);
         }

         var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[5];
         int var6 = 0;
         String var5 = "\u0093\u009aDj¯&¡¦\bà®u\u008eH*´#\u0010L\u0093\u009c\u0084Ç\u009cÝùÏÑ`\u0087\u0005\"\u008c\u0086";
         byte var7 = 34;
         char var4 = '\b';
         int var9 = -1;

         label28:
         while (true) {
            String var11 = var5.substring(++var9, var9 + var4);
            byte var10001 = -1;

            while (true) {
               String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var17;
                     if ((var9 += var4) >= var7) {
                        友树何何友何树友何树 = new 树友何友树友何友何友.友何友树友树何何何树();
                        友何树树树树何树友友 = new 树友何友树友何友何友.友何友树友树何何何树();
                        何何何何友友树何树树 = new 树友何友树友何友何友.友何友树友树何何何树();
                        树何何友何树友友树友 = new 树友何友树友何友何友.友何友树友树何何何树();
                        友友何友树友友友友何 = new 树友何友树友何友何友.友何友树友树何何何树();
                        return;
                     }

                     var4 = var5.charAt(var9);
                     break;
                  default:
                     var0[var6++] = var17;
                     if ((var9 += var4) < var7) {
                        var4 = var5.charAt(var9);
                        continue label28;
                     }

                     var5 = "é\u009f\u0091Wzm·\u0084\u00102:&#û\u00182\u008c\u0084\u009d\u0097ò!¦-\u0092";
                     var7 = 25;
                     var4 = '\b';
                     var9 = -1;
               }

               var11 = var5.substring(++var9, var9 + var4);
               var10001 = 0;
            }
         }
      }

      public static 树友何友树友何友何友.友何友树友树何何何树[] C() {
         return (树友何友树友何友何友.友何友树友树何何何树[])树友树何树友友友友树.clone();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public static 树友何友树友何友何友.友何友树友树何何何树 f(String name) {
         return Enum.valueOf(树友何友树友何友何友.友何友树友树何何何树.class, name);
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'g' && var8 != 'i' && var8 != 203 && var8 != 208) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 220) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 165) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'g') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'i') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 203) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树友何友树友何友何友$友何友树友树何何何树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 54;
                  case 1 -> 27;
                  case 2 -> 10;
                  case 3 -> 3;
                  case 4 -> 6;
                  case 5 -> 59;
                  case 6 -> 11;
                  case 7 -> 56;
                  case 8 -> 21;
                  case 9 -> 55;
                  case 10 -> 40;
                  case 11 -> 13;
                  case 12 -> 63;
                  case 13 -> 29;
                  case 14 -> 36;
                  case 15 -> 12;
                  case 16 -> 8;
                  case 17 -> 23;
                  case 18 -> 19;
                  case 19 -> 22;
                  case 20 -> 15;
                  case 21 -> 4;
                  case 22 -> 62;
                  case 23 -> 37;
                  case 24 -> 51;
                  case 25 -> 49;
                  case 26 -> 41;
                  case 27 -> 34;
                  case 28 -> 31;
                  case 29 -> 26;
                  case 30 -> 44;
                  case 31 -> 14;
                  case 32 -> 38;
                  case 33 -> 57;
                  case 34 -> 45;
                  case 35 -> 61;
                  case 36 -> 24;
                  case 37 -> 48;
                  case 38 -> 58;
                  case 39 -> 46;
                  case 40 -> 17;
                  case 41 -> 18;
                  case 42 -> 2;
                  case 43 -> 5;
                  case 44 -> 9;
                  case 45 -> 0;
                  case 46 -> 42;
                  case 47 -> 32;
                  case 48 -> 28;
                  case 49 -> 20;
                  case 50 -> 60;
                  case 51 -> 39;
                  case 52 -> 53;
                  case 53 -> 33;
                  case 54 -> 47;
                  case 55 -> 35;
                  case 56 -> 1;
                  case 57 -> 43;
                  case 58 -> 52;
                  case 59 -> 25;
                  case 60 -> 30;
                  case 61 -> 16;
                  case 62 -> 50;
                  default -> 7;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "[`w'W\tT :,]\u0014Q}1jM\u000f\u0016栟厒休右桷右佛厒休右B右佛厒桕右桷佭佛伌桕";
         b[1] = "\u0003\f~I(\u001c7/q\te\u0017=2tTnQ-)3栶反伪厓桑取佲反伪厓d取佲反桮厓桑佈佲体桮c";
         b[2] = "0G-/r\u0018;H<`\u0013\u00160C8:";
         b[3] = ">\u0000%a\u001cIlM#\u0010叧佥栙桫桅栉佹校參厱\\.VAqJ-|\u001bG";
         b[4] = "\u001a\u0014U=V!HYSL伳伍佹伻可厏桷伍栽桿,r\u001c)U^] Q/";
         b[5] = "Z\"\u0006\fBh\bo\u0000}厹栀伹伍厼传档叚伹桉\u007fC\b`\u0015h\u000e\u0011Ef";
         b[6] = "\u001cE\u0014wx\u001dN\b\u0012\u0006桙厯栻佪桴叅厃厯叡栮m\u007f|\u0006\u001d\u000e\t?+S";
         b[7] = "Y{i]7g\u000b6o,双叕伺及栉可双叕厤佔\u0010\u0012}o\u00161a@0i";
         b[8] = "X`,'yL\n-*V桘你伻发伈桏厂叾桿发Uh3D\u0017*$:~B";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String LIU_YA_FENG() {
         return "职业技术教育中心学校";
      }
   }
}
