package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.module.impl.display.何友何友树何树友友树;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class 树何何友树何友何树何 implements IWrapper, 何树友 {
   private static String 树何友树何友友友友何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[24];
   private static final String[] g = new String[24];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8247626364033873580L, 7067647994395116267L, MethodHandles.lookup().lookupClass()).a(140879282734651L);
      // $VF: monitorexit
      a = var10000;
      a();
      N(null);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(37393683963636L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[6];
      int var5 = 0;
      String var4 = "MæÏ¯Óz÷\u000b\u0093k+\u0083´\u009aUÌk\u001fÛpgLK¹3{\u0019ë  \u0086Ûñ\u0091 Q#\u0095ø\u000f\u0018\u0080\u0090á\b³\u0085oÌú´\u008b\u0094»\rú¶ë\u0092R\u0019\u0003³0V\u0010®í#£ÆªS\u0004µ\u000f¤@SJ4\u0088\u0010÷ãWßÀ·¡,·Os\r\u001b±\u000e\u001b";
      byte var6 = 99;
      char var3 = '(';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[6];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "l;æ1a83«¯§ç¦õ$\u008b¿Ã\u0004WpÛó[E \"*nýF\u0001P *É\u0098G\u0015}0\u0005·,ä\u008fVu\u0011Gú\u008e\u0092-÷Ò\u0097Ü";
                  var6 = 57;
                  var3 = 24;
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public static String S() {
      return 树何友树何友友友友何;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 3;
               case 1 -> 62;
               case 2 -> 40;
               case 3 -> 6;
               case 4 -> 39;
               case 5 -> 35;
               case 6 -> 36;
               case 7 -> 42;
               case 8 -> 61;
               case 9 -> 55;
               case 10 -> 47;
               case 11 -> 21;
               case 12 -> 51;
               case 13 -> 41;
               case 14 -> 24;
               case 15 -> 52;
               case 16 -> 5;
               case 17 -> 37;
               case 18 -> 28;
               case 19 -> 56;
               case 20 -> 17;
               case 21 -> 10;
               case 22 -> 33;
               case 23 -> 60;
               case 24 -> 13;
               case 25 -> 8;
               case 26 -> 19;
               case 27 -> 0;
               case 28 -> 16;
               case 29 -> 57;
               case 30 -> 44;
               case 31 -> 48;
               case 32 -> 27;
               case 33 -> 45;
               case 34 -> 7;
               case 35 -> 29;
               case 36 -> 43;
               case 37 -> 9;
               case 38 -> 15;
               case 39 -> 20;
               case 40 -> 22;
               case 41 -> 53;
               case 42 -> 30;
               case 43 -> 2;
               case 44 -> 49;
               case 45 -> 25;
               case 46 -> 46;
               case 47 -> 58;
               case 48 -> 50;
               case 49 -> 38;
               case 50 -> 54;
               case 51 -> 4;
               case 52 -> 63;
               case 53 -> 31;
               case 54 -> 18;
               case 55 -> 32;
               case 56 -> 1;
               case 57 -> 23;
               case 58 -> 11;
               case 59 -> 26;
               case 60 -> 59;
               case 61 -> 12;
               case 62 -> 34;
               default -> 14;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'K' && var8 != 192 && var8 != 'U' && var8 != 'p') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 194) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'K') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 192) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'U') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何友树何友何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void s(GuiGraphics graphics, float startX, float startY, float moduleX, float moduleY) {
      S();
      if (mc.player != null) {
         int itemX = (int)startX;
         int itemY = (int)startY;
         boolean hasStacks = false;
         int i = 9;
         Slot slot = mc.player.inventoryMenu.getSlot(9);
         ItemStack stack = slot.getItem();
         graphics.pose().pushPose();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         if (!stack.isEmpty()) {
            hasStacks = true;
         }

         graphics.renderItemDecorations(mc.font, stack, itemX, itemY);
         graphics.renderItem(stack, itemX, itemY);
         graphics.pose().popPose();
         if (itemX < moduleX + 144.0F) {
            itemX += 18;
         }

         int var10000 = (int)startX;
         itemY += 20;
         i++;
         if (mc.screen instanceof InventoryScreen) {
            Cherish.instance
               .t()
               .H(20)
               .q(graphics.pose(), "Already in inventory", 39.0F + moduleX - 2.0F, moduleY + 34.0F, new Color(255, 255, 255, 155).getRGB());
         }

         if (!hasStacks) {
            Cherish.instance.t().H(20).q(graphics.pose(), "Empty...", 70.0F + moduleX - 3.0F, moduleY + 34.0F, new Color(255, 255, 255, 155).getRGB());
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 3536;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树何何友树何友何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[ôX7\u0010\u00adßlV·\u008a\u0003»µ\u001b\u0097Ht\u0091iHÚ\u009bÙè, J\u0011¯t'\u0098Û\u0082v\u0018ýJ\u0007=«\u0085, lf.]8U½\u0014, VÔ\u00ad\u0083\u009fÈ:\u0001, drQjÁ-")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void a() {
      f[0] = "\u00015D4PF\u000eu\t?Z[\u000b(\u0002yZ_\u00075\u001eyZ_\u00075\u001e$\u0011l\u0014>\u0004#\u001bz\u000b?\u000f";
      f[1] = "_gKp\u0002\\P'\u0006{\bAUz\r=\u0000\\X|\tvCZQy\t=\tZOy\tr\u0014\u001d佩参估变桼佦栭参厮栂";
      f[2] = "0\u0019\r\u0017\u0018\r?Y@\u001c\u0012\u0010:\u0004KZ\u0001\u0003?\u0002FZ\u001e\u000f#\u001b\r6\u0018\r?\u0012B\u001a!\u0003?\u0002F";
      f[3] = "\u0002\"PME*\rb\u001dFO7\b?\u0016\u0000G*\u00059\u0012K\u0004,\f<\u0012\u0000N,\u0012<\u0012OSk)\u0019:";
      f[4] = "MP/f#\u001dB\u0010bm)\u0000GMi+:\u0013BKd+%\u001f^R/H#\u0016Kh`i9\u0017";
      f[5] = ";m\u0003@F\u001c4-NKL\u00011pE\r\\\u001av栒佸佶叢桢伍又佸栲佼";
      f[6] = "}^\u0002\u001cOJvQ\u0013S2ReV\u001a\u001a";
      f[7] = "[$ O\u000e/P+1\u0000r6_1?CE\u0006I&3^T*^+";
      f[8] = void.class;
      g[8] = "java/lang/Void";
      f[9] = "j\u0015c8\u0004xj\u0015td\bwp^tz\u0000tj\u00049f\u0005p}\u0015e8%~g\u0011{F\u0005p}\u0015e";
      f[10] = "\u0010X\u001f_5\u0004\u0010X\b\u00039\u000b\n\u0013\u001c\u001e*\u0001\u001a\u0013\u0002\u001f.\b\u0010I\u0004\u0003!C7S\u001d\u00146\u0019\u0011O\u0012<=\u0003\u000b";
      f[11] = "/q\u0015,rm/q\u0002p~b5:\u0002nva/`OOvj$w\u0013cyp";
      f[12] = "L\u0013M8;UL\u0013Zd7ZVXZz?YL\u0002\u0017q#U\f\u0005Zd3YL\u0005\u0017E5NG\u0013W";
      f[13] = "]0&J`t]01\u0016l{G{1\bdx]!|\u0003xt\u001d\u0013=\ny";
      f[14] = "`bmDn[km|\u000b\u000fU`fxQ";
      f[15] = "oN`3%G)U~jEmT\n(iyH>\u0006v<76";
      f[16] = "-\u001eoB;A#\u0007?NKODZ0\u001az\u001cDa1\u001c:Ln\u000el\u001br\u0011";
      f[17] = " [\u001c'cwl\u001f]s\u000e`GPZt>6GaS<ssm\u001fY%>m";
      f[18] = "1\u001c^Y\r\u0006>Z\u001a)$\u007f\u0004;&G\u0007@/\u0016\u0018HA\u0004";
      f[19] = "wqcki\u00101j}2\t'L5+15\u001f&9ud{aqu 28\u001f.ny{\t";
      f[20] = "1\u0005Om\u0010=}A\u000e9}*V\u000e\t>C~V?\u0001>\f$cVY9M%";
      f[21] = "\u000e\u0006\n\u000frMIBO\u0016J栯栮叻伫桱桓佫栮校伫hsI\rJ\u001d\u0004-\u000b\u000b\u0004";
      f[22] = "\u000e  \\1}H;>\u0005Qe5ecP,6S8;\r,\f\bc4AkjU;iAQ";
      f[23] = "3Af;i}3A~3\u0013叕佔另栟桀低栏及另叅Y)f2Ll7/\u007fj\u0015";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何友树何友何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void E(Render2DEvent event, float x, float y, float width, float height, 何友何友树何树友友树 module) {
      S();
      RenderUtils.drawRoundedRect(event.poseStack(), x, y, width, height + 9.0F, 0.0, new Color(23, 23, 23));
      RenderUtils.drawGradientRectL2R(event.poseStack(), x, y, width, 1.0F, HUD.instance.getColor(0).getRGB(), HUD.instance.getColor(4).getRGB());
      if (module.树树友何树树何树树何.getValue()) {
         RenderUtils.drawGradientRectL2R(event.poseStack(), x, y + 14.0F, width, 1.0F, HUD.instance.getColor(0).getRGB(), HUD.instance.getColor(4).getRGB());
      }

      Cherish.instance
         .t()
         .H(HUD.instance.友何友树树何树友友友.K("Chinese") ? 20 : 19)
         .h(
            event.poseStack(),
            HUD.instance.友何友树树何树友友友.K("Chinese") ? "背包显示" : "Inventory",
            x + width / 2.0F - 1.0F,
            y + 4.0F,
            HUD.instance.getColor(1).getRGB()
         );
      if (event.side() == Event.Side.POST) {
         s(event.guiGraphics(), x + 2.0F, y + 12.0F + 5.0F, x, y);
      }
   }

   public static void N(String var0) {
      树何友树何友友友友何 = var0;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖230622200409390090";
   }
}
