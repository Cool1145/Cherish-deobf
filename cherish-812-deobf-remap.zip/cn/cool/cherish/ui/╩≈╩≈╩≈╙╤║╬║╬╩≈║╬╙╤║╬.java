package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.config.友何何友树友树何树树;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.util.Mth;

public class 树树树友何何树何友何 implements IWrapper, 何树友 {
   public final 何树何友友何何友友树 友友何友何树何何树树;
   Map<树何何树何友树何何树<?>, 友友何何何树友友何树> 何树树友何友何何树何 = new HashMap<>();
   private final Map<Module, Boolean> 友树何友何友何何何何;
   private final Map<Module, Float> 何友树树友何树何何树;
   private final Map<Module, Long> 何树友友友树友友友何;
   Map<Module, Boolean> 友友友树何何树友树何;
   private final Map<Module, Float> 何友何树何何友友何友;
   Map<Module, Long> 友何何树树友树树何何;
   private long 何友友何树友树树树树;
   private float 何树友树树树树树何何;
   private float 友树友树何何友友友何;
   private long 友何何友何树树树树树;
   float 树何何树树树友友友友;
   float 树友何树友友树树友何;
   float 何何树树何友友友何树;
   boolean 何树友树何友友何树友;
   树何友友何树友友何何 树树树友树树树友树何;
   float 何何何友何树树树何何;
   float 树友树树友友友友友树;
   public 何何何友友何树何何何 友树树何何何树何友树;
   public NumberValue 树树友树何树何友友何;
   boolean 树友友树树友树何树何;
   String 树树何树树树何何何树;
   boolean 树何友何树友树何树树;
   List<String> 何友友树树友何树友何;
   String 友树树树树何何友何友;
   private static String[] 友何何何友友何友友树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[79];
   private static final String[] j = new String[79];
   private static int _何炜霖黑水 _;

   树树树友何何树何友何(树何友友何树友友何何 category, float initialX, float initialY, 何树何友友何何友友树 DSJ_ClickGui) {
      何树何友友何何友友树.G();
      this.友树何友何友何何何何 = new HashMap<>();
      this.何友树树友何树何何树 = new HashMap<>();
      this.何树友友友树友友友何 = new HashMap<>();
      this.友友友树何何树友树何 = new HashMap<>();
      this.何友何树何何友友何友 = new HashMap<>();
      this.友何何树树友树树何何 = new HashMap<>();
      this.何友友何树友树树树树 = 0L;
      this.何树友树树树树树何何 = 0.0F;
      this.友树友树何何友友友何 = 0.0F;
      this.友何何友何树树树树树 = 0L;
      this.树何何树树树友友友友 = 0.0F;
      this.树友何树友友树树友何 = 0.0F;
      this.何何树树何友友友何树 = 0.0F;
      this.何树友树何友友何树友 = false;
      this.树友友树树友树何树何 = false;
      this.树树何树树树何何何树 = "";
      this.树何友何树友树何树树 = false;
      this.何友友树树友何树友何 = new ArrayList<>();
      this.友树树树树何何友何友 = "default";
      this.树树树友树树树友树何 = category;
      this.何何何友何树树树何何 = 30.0F;
      this.树友树树友友友友友树 = 30.0F;
      this.友友何友何树何何树树 = DSJ_ClickGui;
      if (category == 树何友友何树友友何何.友树友树树树友何友树) {
         this.W();
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8484510972459727882L, -5186008548473883515L, MethodHandles.lookup().lookupClass()).a(31157915026383L);
      // $VF: monitorexit
      a = var10000;
      a();
      q(null);
      Cipher var11;
      Cipher var22 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(57258052526284L << var12 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[26];
      int var16 = 0;
      String var15 = "ú)§\u0018QüÚçË¿ÜÑHöXùj.\u0099ÐK\u001c\fl\u0010 å\u0002nÎ×Ö¦\u009c\u0094ºªT\u009b\u000e\u0085 m³¤ôZ\b\u009d¿a\u0097\\'(Ý8C°\u0097\u000b¨ßõnf\u00adñ¦\u0099\u000e\u0002²m \u0010Êi\u0005T\u0086\u0088\u0094G«¨F\u0001×>]£þ]\u008aÞ=ÊgZæ¡\u001alBþ|\u0010Ù\u0014zÀ_Kë\u001f\u0018ûyü\\jáÉ\u0010k\u0097\u0007\u0018*\u0000U\u008e\u001ac\u001b\f\u0092\u0096\u001bf yÃçoá\u0013}Qu\u008dß¹%±O\u0005´ÜÿU\u00adªË40\u008dÚ\u0090àÞ\u008d\u0004\u00102\u0017\u0006ß\u000fûT\u0014DÄËÞ)\u0090%\u0080 ÃÑAÓþå_/¹æë,Ç7\u0080\u007f\u0019îgÅ\u0090Ë<æ1$Ï\u008a\u001e\b´9\u0018\"\u008b\u0082óíÄpî?bR7ãÞÔD´O\u008c°@\u009a\u009f¤ \f\u0014\u008aKË8oÄ¹-l\u001b¥Ê\f\u0095¢®<R}<¯}\r$\u0000\u0095Ùi¤Ä ðg\u007f\u0093@TýÜû\u008a\u0093\u0080ÇÑÇ,ü´\f6\u0080kè\fÐÂÌ!n½öê\u0018\u0003Õ\u0018\u001czöL£õ²0}\u0086î+ûMU$<Tìr\u009f\u0010Ì»W¦\u0086qDc\u0095·áy\u0099\u0001\u0005\u008a\u0010\u001d[\u008c½H\u0080\u0018©\u0004w0ðë;X©\u0010R\u009d\u0097\u001b\u001cá\"é¶\u009bà\u0000okS6\u0010ÊÏ)\u00849\u0085\u0000_\u0098\u0012\u0019\n\u0018\u0007\u0082\u007f ²\u008e\u001búp,iå\u0003Tù\u008b\u009cU×.\u000eð5mQau^\u0018Ua&\u0010iº¦\u0010æ\u001dªrÏZ_©ËÙ>Mâsí~\u0010\u001f\u008fe\u0095\u0082ü\u0098¨z(\t¦£ãk\u009e ¹´dØ\"\u0097Àb\u009c'\u0014Yõ\u000ejFÖ\u00ad³Öô\u008fQc¨\u0097æsåºgo\u0010_ÝÐÍÙ#\u008a\u0080by¸jEÞ\u0016ó\u0010'ÃM,\u0011õØÞý³\u000bÉÙ9ûÙ\u0018uxäÑí\u0006Oý,UÄ\u001e×\u0099\u00863Ù¨_¬ \u0086(\u0016";
      short var17 = 567;
      char var14 = 24;
      int var21 = -1;

      label54:
      while (true) {
         String var23 = var15.substring(++var21, var21 + var14);
         int var10001 = -1;

         while (true) {
            String var34 = b(var11.doFinal(var23.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var34;
                  if ((var21 += var14) >= var17) {
                     b = var18;
                     c = new String[26];
                     h = new HashMap(13);
                     Cipher var0;
                     Cipher var25 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(57258052526284L << var1 * 8 >>> 56);
                     }

                     var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[5];
                     int var3 = 0;
                     String var4 = "{ó¹ø>\u009cn\u009a\u0013yÃ\b\u008d5«Fë\n'Á\u0082 9\u008d";
                     byte var5 = 24;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var26 = var6;
                        var10001 = var3++;
                        long var38 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var41 = -1;

                        while (true) {
                           long var8 = var38;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var43 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var41) {
                              case 0:
                                 var26[var10001] = var43;
                                 if (var2 >= var5) {
                                    f = var6;
                                    g = new Long[5];
                                    return;
                                 }
                                 break;
                              default:
                                 var26[var10001] = var43;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "j\u0001Þì\u0083\u00866Å=vÌÿñ\u0015\u001d¹";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var32 = var2;
                           var2 += 8;
                           var7 = var4.substring(var32, var2).getBytes("ISO-8859-1");
                           var26 = var6;
                           var10001 = var3++;
                           var38 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var41 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var21);
                  break;
               default:
                  var18[var16++] = var34;
                  if ((var21 += var14) < var17) {
                     var14 = var15.charAt(var21);
                     continue label54;
                  }

                  var15 = "\u001b\u0014\u008aì\u0007¹°7C{S%ý®e6 ª\u008e67ãV\"ZTXÂ£\u0088ó¾ Z\u0014Ìó\u0094IéÖ£2\u0013ç~=\u0085Ä";
                  var17 = 49;
                  var14 = 16;
                  var21 = -1;
            }

            var23 = var15.substring(++var21, var21 + var14);
            var10001 = 0;
         }
      }
   }

   float C(GuiGraphics guiGraphics, float startContentX, float startContentY, int mouseX, int mouseY, int baseAlpha, boolean actuallyRender) {
      float currentItemYOffset = 2.0F - this.树何何树树树友友友友;
      Objects.requireNonNull(this.友友何友何树何何树树);
      何树何友友何何友友树.G();
      float totalHeightCalculated = 2.0F;
      float panelVisibleBottomY = startContentY + this.何何树树何友友友何树;
      if (this.树树树友树树树友树何 == 树何友友何树友友何何.友树友树树树友何友树) {
         String[] actions = new String[]{"default", "Config name", "Load", "Save", "Delete"};
         int module = actions.length;
         int moduleTotalEntryHeight = 0;
         if (0 < module) {
            String action = actions[0];
            if (actuallyRender && currentItemYOffset + 18.0F > startContentY && currentItemYOffset < panelVisibleBottomY) {
               何树何友友何何友友树 var10000 = this.友友何友何树何何树树;
               Objects.requireNonNull(this.友友何友何树何何树树);
               boolean isHover = var10000.g(0.0, 0.0, 0.0F, currentItemYOffset, 106.0F, 18.0F);
               boolean isSelectedActionItem = action.equals(this.友树树树树何何友何友)
                  || action.equals("Config name") && this.树何友何树友树何树树 && this.友友何友何树何何树树.友何树友友何友何友何 == this;
               Color itemBg = isSelectedActionItem
                  ? this.友友何友何树何何树树.o(HUD.instance.getColor(4), 0)
                  : (isHover ? this.友友何友何树何何树树.o(this.友友何友何树何何树树.树树树友树何友何何树, baseAlpha) : this.友友何友何树何何树树.o(this.友友何友何树何何树树.树何何树何树何树何友, baseAlpha));
               Color fontCol = !isSelectedActionItem && !isHover
                  ? this.友友何友何树何何树树.o(this.友友何友何树何何树树.树友何何友树友友何树, baseAlpha)
                  : this.友友何友何树何何树树.o(this.友友何友何树何何树树.友树树友何树友友树友, baseAlpha);
               PoseStack var41 = guiGraphics.pose();
               Objects.requireNonNull(this.友友何友何树何何树树);
               RenderUtils.drawRectangle(var41, startContentX, currentItemYOffset, 106.0F, 18.0F, itemBg.getRGB());
               if (action.equals("Config name")) {
                  String text = this.树树何树树树何何何树;
                  if (this.树何友何树友树何树树 && this.友友何友何树何何树树.友何树友友何友何友何 == this && System.currentTimeMillis() / 500L % 2L == 0L) {
                     text = text + "_";
                  }

                  if (this.树树何树树树何何何树.isEmpty() && (!this.树何友何树友树何树树 || this.友友何友何树何何树树.友何树友友何友何友何 != this)) {
                     text = "Config name";
                     fontCol = this.友友何友何树何何树树.o(this.友友何友何树何何树树.树友何何友树友友何树, baseAlpha / 2);
                  }

                  this.友友何友何树何何树树
                     .何何友何树何友树何何
                     .s(guiGraphics.pose(), text, startContentX + 2.0F, currentItemYOffset + 9.0F - this.友友何友何树何何树树.何何友何树何友树何何.x() / 2.0F, fontCol.getRGB());
               }

               this.友友何友何树何何树树
                  .何何友何树何友树何何
                  .s(guiGraphics.pose(), action, startContentX + 2.0F, currentItemYOffset + 9.0F - this.友友何友何树何何树树.何何友何树何友树何何.x() / 2.0F, fontCol.getRGB());
            }

            Objects.requireNonNull(this.友友何友何树何何树树);
            currentItemYOffset += 20.0F;
            Objects.requireNonNull(this.友友何友何树何何树树);
            totalHeightCalculated = 22.0F;
            moduleTotalEntryHeight++;
         }

         if (!this.何友友树树友何树友何.isEmpty()) {
            Objects.requireNonNull(this.友友何友何树何何树树);
            if (currentItemYOffset - 2.0F + 1.0F > startContentY && currentItemYOffset - 2.0F < panelVisibleBottomY) {
               RenderUtils.G(
                  guiGraphics.pose(),
                  startContentX,
                  startContentX + 110.0F - 4.0F - 1.0F,
                  66867879736177L,
                  currentItemYOffset - 2.0F,
                  1,
                  this.友友何友何树何何树树.o(this.友友何友何树何何树树.何友友何树树树何友友, baseAlpha).getRGB()
               );
            }

            currentItemYOffset++;
            totalHeightCalculated++;
         }

         Iterator lineThickness = this.何友友树树友何树友何.iterator();
         if (lineThickness.hasNext()) {
            String confName = (String)lineThickness.next();
            if (currentItemYOffset + 18.0F > startContentY && currentItemYOffset < panelVisibleBottomY) {
               何树何友友何何友友树 var42 = this.友友何友何树何何树树;
               double var10001 = mouseX;
               double var10002 = mouseY;
               Objects.requireNonNull(this.友友何友何树何何树树);
               boolean isHover = var42.g(var10001, var10002, startContentX, currentItemYOffset, 106.0F, 18.0F);
               boolean isConfigSelected = confName.equals(this.树树何树树树何何何树) && (!this.树何友何树友树何树树 || this.友友何友何树何何树树.友何树友友何友何友何 != this);
               Color itemBg = isConfigSelected
                  ? this.友友何友何树何何树树.o(HUD.instance.getColor(4), baseAlpha)
                  : (isHover ? this.友友何友何树何何树树.o(this.友友何友何树何何树树.树树树友树何友何何树, baseAlpha) : this.友友何友何树何何树树.o(this.友友何友何树何何树树.树何何树何树何树何友, baseAlpha));
               Color fontCol = !isConfigSelected && !isHover
                  ? this.友友何友何树何何树树.o(this.友友何友何树何何树树.树友何何友树友友何树, baseAlpha)
                  : this.友友何友何树何何树树.o(this.友友何友何树何何树树.友树树友何树友友树友, baseAlpha);
               PoseStack var43 = guiGraphics.pose();
               Objects.requireNonNull(this.友友何友何树何何树树);
               RenderUtils.drawRectangle(var43, startContentX, currentItemYOffset, 106.0F, 18.0F, itemBg.getRGB());
               this.友友何友何树何何树树
                  .何何友何树何友树何何
                  .s(guiGraphics.pose(), confName, startContentX + 2.0F, currentItemYOffset + 9.0F - this.友友何友何树何何树树.何何友何树何友树何何.x() / 2.0F, fontCol.getRGB());
            }

            Objects.requireNonNull(this.友友何友何树何何树树);
            currentItemYOffset += 20.0F;
            Objects.requireNonNull(this.友友何友何树何何树树);
            totalHeightCalculated += 20.0F;
         }

         totalHeightCalculated -= 2.0F;
      }

      List<Module> modules = Cherish.instance.getModuleManager().Z(this.树树树友树树树友树何);
      Iterator var27 = modules.iterator();
      if (var27.hasNext()) {
         Module modulex = (Module)var27.next();
         float moduleTotalEntryHeightx = 18.0F;
         float animFactor = this.何友何树何何友友何友.getOrDefault(modulex, this.友友友树何何树友树何.getOrDefault(modulex, false) ? 1.0F : 0.0F);
         if (animFactor > 0.001F) {
            float naturalSettingsBlockHeight = 0.0F;
            List<树何何树何友树何何树<?>> visibleValues = modulex.P().stream().filter(v -> {
               何树何友友何何友友树.G();
               return !v.O();
            }).collect(Collectors.toList());
            if (!visibleValues.isEmpty()) {
               Iterator var39 = visibleValues.iterator();
               if (var39.hasNext()) {
                  树何何树何友树何何树<?> value = (树何何树何友树何何树<?>)var39.next();
                  naturalSettingsBlockHeight = 0.0F + this.J(value);
               }
            }

            moduleTotalEntryHeightx = 18.0F + naturalSettingsBlockHeight * animFactor;
         }

         if (actuallyRender && currentItemYOffset + moduleTotalEntryHeightx > startContentY && currentItemYOffset < panelVisibleBottomY) {
            this.P(guiGraphics, modulex, startContentX, currentItemYOffset, mouseX, mouseY, baseAlpha, animFactor);
         }

         float var44 = currentItemYOffset + moduleTotalEntryHeightx;
         totalHeightCalculated += moduleTotalEntryHeightx;
      }

      if (!modules.isEmpty()) {
         float var45 = totalHeightCalculated + 2.0F;
      }

      return 0.0F;
   }

   友友何何何树友友何树 F(树何何树何友树何何树<?> value) {
      return this.何树树友何友何何树何.computeIfAbsent(value, v -> {
         何树何友友何何友友树.G();
         if (v instanceof BooleanValue) {
            return new 树友何友友友树友何树();
         } else if (v instanceof NumberValue) {
            return new 友友何友树友树树何树();
         } else if (v instanceof ModeValue) {
            return new 树友树树何友何何树友();
         } else if (v instanceof 何何何友友何树何何何) {
            return new 树何何何友何树何何何();
         } else {
            return (友友何何何树友友何树)(v instanceof 树友何何树树何友友何 ? new 树友何友树友何友何友() : new 何何友友友何友何友何());
         }
      });
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   void I(GuiGraphics guiGraphics, int mouseX, int mouseY, int baseAlpha) {
      this.树友何树友友树树友何 = this.C(null, 0.0F, 0.0F, 0, 0, 0, false);
      this.何何树树何友友友何树 = Math.min(this.树友何树友友树树友何, 300.0F);
      何树何友友何何友友树.G();
      RenderUtils.drawRectangle(
         guiGraphics.pose(), this.何何何友何树树树何何, this.树友树树友友友友友树, 110.0F, 20.0F, this.友友何友何树何何树树.o(this.友友何友何树何何树树.友友友何树友何友树树, baseAlpha).getRGB()
      );
      String categoryName = this.友友何友何树何何树树.树树何树友树何树友树 ? this.树树树友树树树友树何.name() : this.树树树友树树树友树何.何何何树何何何树友友;
      Color headerFontColor = this.友友何友何树何何树树.o(this.友友何友何树何何树树.友树树友何树友友树友, baseAlpha);
      this.友友何友何树何何树树
         .树何树树树何何树何树
         .s(guiGraphics.pose(), categoryName, this.何何何友何树树树何何 + 4.0F, this.树友树树友友友友友树 + 10.0F - this.友友何友何树何何树树.树何树树树何何树何树.x() / 2.0F, headerFontColor.getRGB());

      String categorySpecificIconChar = switch (树树树友何何树何友何$友树何友何友友何何树.何何何友何何树何何树[this.树树树友树树树友树何.ordinal()]) {
         case 1 -> "D";
         case 2 -> "A";
         case 3 -> "B";
         case 4 -> "C";
         case 5 -> "L";
         case 6 -> "F";
         case 7 -> "E";
         default -> throw new IncompatibleClassChangeError();
      };
      if (this.友友何友何树何何树树.友友友何友何树何树何 != null) {
         float iconWidth = this.友友何友何树何何树树.友友友何友何树何树何.D(categorySpecificIconChar);
         float iconX = this.何何何友何树树树何何 + 110.0F - iconWidth - 4.0F;
         float iconY = this.树友树树友友友友友树 + 10.0F - this.友友何友何树何何树树.友友友何友何树何树何.x() / 2.0F + 1.0F;
         this.友友何友何树何何树树.友友友何友何树何树何.s(guiGraphics.pose(), categorySpecificIconChar, iconX, iconY, headerFontColor.getRGB());
         Module.V(new Module[2]);
      }

      float gearIconWidth = this.友友何友何树何何树树.友何友树树友何友树友.D("\ue8b8");
      float gearIconX = this.何何何友何树树树何何 + 110.0F - gearIconWidth - 4.0F;
      float gearIconY = this.树友树树友友友友友树 + 10.0F - this.友友何友何树何何树树.友何友树树友何友树友.x() / 2.0F;
      this.友友何友何树何何树树.友何友树树友何友树友.s(guiGraphics.pose(), "\ue8b8", gearIconX, gearIconY, headerFontColor.getRGB());
      RenderUtils.G(
         guiGraphics.pose(),
         this.何何何友何树树树何何,
         this.何何何友何树树树何何 + 110.0F - 1.0F,
         66867879736177L,
         this.树友树树友友友友友树 + 20.0F - 1.0F,
         1,
         this.友友何友何树何何树树.o(this.友友何友何树何何树树.何友友何树树树何友友, baseAlpha).getRGB()
      );
      float contentRenderY = this.树友树树友友友友友树 + 20.0F;
      RenderUtils.drawRectangle(
         guiGraphics.pose(), this.何何何友何树树树何何, contentRenderY, 110.0F, this.何何树树何友友友何树, this.友友何友何树何何树树.o(this.友友何友何树何何树树.友友友何树友何友树树, baseAlpha).getRGB()
      );
      guiGraphics.pose().pushPose();
      guiGraphics.enableScissor((int)this.何何何友何树树树何何, (int)contentRenderY, (int)(this.何何何友何树树树何何 + 110.0F), (int)(contentRenderY + this.何何树树何友友友何树));
      this.C(guiGraphics, this.何何何友何树树树何何 + 2.0F, contentRenderY, mouseX, mouseY, baseAlpha, true);
      guiGraphics.disableScissor();
      guiGraphics.pose().popPose();
      long currentTime = System.currentTimeMillis();
      if (this.树友何树友友树树友何 > this.何何树树何友友友何树) {
         if (currentTime - this.友何何友何树树树树树 < 1200L) {
         }

         label44:
         if (Math.abs(this.何树友树树树树树何何 - 0.0F) > 0.001F) {
            if (this.何树友树树树树树何何 < 0.0F) {
               this.何树友树树树树树何何 += 0.075F;
               if (!(this.何树友树树树树树何何 > 0.0F)) {
                  break label44;
               }

               this.何树友树树树树树何何 = 0.0F;
            }

            this.何树友树树树树树何何 -= 0.075F;
            if (this.何树友树树树树树何何 < 0.0F) {
               this.何树友树树树树树何何 = 0.0F;
            }
         }

         this.何树友树树树树树何何 = Mth.clamp(this.何树友树树树树树何何, 0.0F, 1.0F);
      }

      this.何树友树树树树树何何 = 0.0F;
      if (this.何树友树树树树树何何 > 0.01F) {
         guiGraphics.pose().pushPose();
         guiGraphics.pose().translate(0.0F, 0.0F, 150.0F);
         int finalScrollbarThumbAlpha = (int)(baseAlpha * this.何树友树树树树树何何);
         this.l(
            guiGraphics,
            this.何何何友何树树树何何 + 110.0F - 3.0F - 2.0F,
            contentRenderY + 2.0F,
            3.0F,
            this.何何树树何友友友何树 - 4.0F,
            this.树何何树树树友友友友,
            this.树友何树友友树树友何,
            this.友友何友何树何何树树.o(this.友友何友何树何何树树.友树何何何友友何树何, finalScrollbarThumbAlpha).getRGB()
         );
         guiGraphics.pose().popPose();
      }
   }

   float J(树何何树何友树何何树<?> value) {
      友友何何何树友友何树 handler = this.F(value);
      return handler.Z(this, value);
   }

   boolean Z(char typedChar, int modifiers, 何何何友友何树何何何 targetTextValue) {
      何树何友友何何友友树.G();
      if (this.树树树友树树树友树何 == 树何友友何树友友何何.友树友树树树友何友树 && this.树何友何树友树何树树 && this.友友何友何树何何树树.友何树友友何友何友何 == this) {
         if (typedChar == '\b') {
            if (this.树树何树树树何何何树.isEmpty()) {
               return true;
            }

            this.树树何树树树何何何树 = this.树树何树树树何何何树.substring(0, this.树树何树树树何何何树.length() - 1);
         }

         if (typedChar >= ' ' && typedChar != 127 && this.树树何树树树何何何树.length() < 32) {
            this.树树何树树树何何何树 = this.树树何树树树何何何树 + typedChar;
         }

         return true;
      } else if (targetTextValue != null && this.友友何友何树何何树树.友树树友何友树树友树 == targetTextValue && this.友友何友何树何何树树.友何树友友何友何友何 == this) {
         if (typedChar == '\b') {
            String current = targetTextValue.getValue();
            if (!current.isEmpty()) {
               targetTextValue.G(current.substring(0, current.length() - 1));
            }
         }

         if (typedChar >= ' ' && typedChar != 127 && targetTextValue.getValue().length() < 128) {
            targetTextValue.G(targetTextValue.getValue() + typedChar);
         }

         return true;
      } else {
         return false;
      }
   }

   void V() {
      何树何友友何何友友树.G();
      String name = this.树树何树树树何何何树.trim();
      if (!name.isEmpty() && !this.Q(name)) {
         友何何友树友树何树树 config = new 友何何友树友树何树树(new File(Cherish.getConfigManager().e(), name + ".ini"));

         try {
            config.A();
            树友何何何树友树何友.E(何树友友何友友何树树.树树友树友友友何何树, "Config", "Saved: " + name, 3.0F);
            this.W();
         } catch (Throwable var7) {
            树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", "Failed save:" + name, 3.0F);
         }
      } else {
         树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", "Invalid name", 3.0F);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 48;
               case 1 -> 23;
               case 2 -> 60;
               case 3 -> 5;
               case 4 -> 46;
               case 5 -> 20;
               case 6 -> 54;
               case 7 -> 33;
               case 8 -> 39;
               case 9 -> 56;
               case 10 -> 45;
               case 11 -> 63;
               case 12 -> 58;
               case 13 -> 2;
               case 14 -> 51;
               case 15 -> 32;
               case 16 -> 36;
               case 17 -> 62;
               case 18 -> 47;
               case 19 -> 31;
               case 20 -> 61;
               case 21 -> 30;
               case 22 -> 42;
               case 23 -> 8;
               case 24 -> 27;
               case 25 -> 38;
               case 26 -> 10;
               case 27 -> 0;
               case 28 -> 26;
               case 29 -> 17;
               case 30 -> 29;
               case 31 -> 13;
               case 32 -> 25;
               case 33 -> 28;
               case 34 -> 7;
               case 35 -> 57;
               case 36 -> 43;
               case 37 -> 24;
               case 38 -> 40;
               case 39 -> 34;
               case 40 -> 59;
               case 41 -> 3;
               case 42 -> 22;
               case 43 -> 19;
               case 44 -> 44;
               case 45 -> 6;
               case 46 -> 35;
               case 47 -> 50;
               case 48 -> 18;
               case 49 -> 37;
               case 50 -> 55;
               case 51 -> 16;
               case 52 -> 14;
               case 53 -> 15;
               case 54 -> 49;
               case 55 -> 1;
               case 56 -> 53;
               case 57 -> 9;
               case 58 -> 52;
               case 59 -> 11;
               case 60 -> 4;
               case 61 -> 12;
               case 62 -> 41;
               default -> 21;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树树友何何树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25195;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/树树树友何何树何友何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'T' && var8 != 237 && var8 != 'J' && var8 != 202) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'd') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'a') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'T') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 237) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'J') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   void x(Module module) {
      何树何友友何何友友树.G();
      boolean currentEnabledState = module.isEnabled();
      if (!this.友树何友何友何何何何.containsKey(module)) {
         this.友树何友何友何何何何.put(module, currentEnabledState);
         this.何友树树友何树何何树.put(module, 1.0F);
      }

      boolean lastRecordedState = this.友树何友何友何何何何.get(module);
      long animStartTime = this.何树友友友树友友友何.getOrDefault(module, 0L);
      if (currentEnabledState != lastRecordedState) {
         animStartTime = System.currentTimeMillis();
         this.何树友友友树友友友何.put(module, animStartTime);
         this.友树何友何友何何何何.put(module, currentEnabledState);
      }

      if (animStartTime > 0L) {
         long elapsed = System.currentTimeMillis() - animStartTime;
         if ((float)elapsed < 150.0F) {
            float var10000 = (float)elapsed / 150.0F;
            var10000 = 1.0F - (float)elapsed / 150.0F;
         }

         float animProgress = currentEnabledState ? 1.0F : 0.0F;
         this.何树友友友树友友友何.remove(module);
         animProgress = Mth.clamp(animProgress, 0.0F, 1.0F);
         this.何友树树友何树何何树.put(module, animProgress);
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树树友何何树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   void f() {
      何树何友友何何友友树.G();
      String name = this.树树何树树树何何何树.trim();
      if (name.isEmpty()) {
         name = this.友树树树树何何友何友;
      }

      if (!name.isEmpty() && !name.equals("default") && !this.Q(name)) {
         File configFile = new File(Cherish.getConfigManager().e(), name + ".ini");
         if (configFile.exists()) {
            if (configFile.delete()) {
               树友何何何树友树何友.E(何树友友何友友何树树.树树友树友友友何何树, "Config", "Deleted: " + name, 3.0F);
               this.W();
               if (!this.树树何树树树何何何树.equals(name)) {
                  return;
               }

               this.树树何树树树何何何树 = "";
            }

            树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", "Failed delete: " + name, 3.0F);
         }

         树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", "Not found:" + name, 3.0F);
      } else {
         树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", "Cannot delete", 3.0F);
      }
   }

   void l(
      GuiGraphics g,
      float scrollbarX,
      float scrollbarY,
      float scrollbarWidth,
      float trackHeight,
      float currentScrollAmount,
      float contentHeight,
      int thumbColorWithAlpha
   ) {
      何树何友友何何友友树.G();
      if (!(contentHeight <= trackHeight)) {
         float thumbHeight = Math.max(15.0F, trackHeight / contentHeight * trackHeight);
         float thumbY = scrollbarY + currentScrollAmount / (contentHeight - trackHeight) * (trackHeight - thumbHeight);
         thumbY = Mth.clamp(thumbY, scrollbarY, scrollbarY + trackHeight - thumbHeight);
         RenderUtils.drawRectangle(g.pose(), scrollbarX, thumbY, 3.0F, thumbHeight, thumbColorWithAlpha);
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16342;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树树树友何何树何友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[`Ë5\u000bÒÑ")[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树树友何何树何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      i[0] = "\u0006Mrb\u001f\r\t\r?i\u0015\u0010\fP4/\u0005\u000bK栲桍栐去伷估栲伉及伥";
      i[1] = "0\"UcHG;-D,2C(,Tc\u0004G?";
      i[2] = "K\u0015=:^cDUp1T~A\b{wDe\u0006伮栂厒叺余口厰但案栠";
      i[3] = "H(\u0001xJ\u0019GhLs@\u0004B5G5P\u001f\u0005伓栾低叮厽佾伓古叐栴";
      i[4] = "%YWE`\u001d\u0011zX\u0005-\u0016\u001bg]X&P\u0013zP^\"\u001bPX[O;\u0012\u001b.";
      i[5] = "{#y\u0013\u001dfp,h\\`~c+a\u0015";
      i[6] = "#s\nsq5={\u0010<\u0013):f";
      i[7] = "/\u0015Sj0\b1\u001dI%]\u0012(\u0004Dy\u007f\t*\u0006";
      i[8] = "\u001d!M\u0018G\u001a\u0003)WW$\u000e\u0007";
      i[9] = "\u001e\u0019\u000b<gm\u0011YF7mp\u0014\u0004Mqem\u0019\u0002I:&栓伨厼叮伊栙叉厶伢佰";
      i[10] = boolean.class;
      j[10] = "java/lang/Boolean";
      i[11] = "v#R}A:yc\u001fvK'|>\u00140X4y8\u00190G8e!R佋佻伀叞历伩栏佻伀佀";
      i[12] = ".8DW\u001d\u0014.8S\u000b\u0011\u001b4sS\u0015\u0019\u0018.)\u001e4\u0019\u0013%>B\u0018\u0016\t";
      i[13] = "\b3j\u0019G\u001f\b3}EK\u0010\u0012x}[C\u0013\b\"0|O\u000f\u00049\u007fEN>\u00078z[O\u0004";
      i[14] = "\u0001@ZHSw\u001cU\u0002j\u0012z\u0004S";
      i[15] = "S6\u0017q\f\t\\vZz\u0006\u0014Y+Q<\u0016\u000f\u001e伍佬叙厨桷佥桉佬叙桲";
      i[16] = float.class;
      j[16] = "java/lang/Float";
      i[17] = long.class;
      j[17] = "java/lang/Long";
      i[18] = "\"ZR\u0016\r'WzY\u0019\u001ch*bJ\u001e\u0015!B";
      i[19] = void.class;
      j[19] = "java/lang/Void";
      i[20] = "+IXRC?$\t\u0015YI\"!T\u001e\u001fY9f栶桧栠叧伅伝栶伣叺佹t厃栶伣叺佹厛厃佲伣栠";
      i[21] = "\u0010\u0015";
      i[22] = "%rz*>h*27!4u/o<g<h\"i8,\u007fJ)x!%4";
      i[23] = "<e:HK\u001c\bF5\b\u0006\u0017\u0002[0U\rQ\nF=S\t\u001aId6B\u0010\u0013\u0002\u0012";
      i[24] = "To\u0016!\t>`L\u0019aD5jQ\u001c<OsbL\u0011:K8!n\u001a+R1j\u0018";
      i[25] = "mZ^?\u0012/YyQ\u007f_$SdT\"Tb[yY$P)\u0018[R5I S-";
      i[26] = "'K\bNN5,D\u0019\u0001/;'O\u001d[";
      i[27] = "_N\u0010?\u000bJQ\u000e\u0006\u0006栩伦叾伨桤叅栩伦栤桬}9[BR\u0019\u0013zS\u0001]";
      i[28] = "\u0015m\u001d-)/\u001b-\u000b\u0014{\u001e\u000e-\u0015zhn\to\u0014\u0014ke\u00128\ndl'\u0013V";
      i[29] = "r:6n'z|z W栅厈位栘厘厔栅桒叓作[=#)bq2ju.(";
      i[30] = "PIbnM3\t\u0003*s+?7\u0003k.\u0015a72cwY1\u0000I )Q2";
      i[31] = "C\u000fL\u0016\\6MOZ/伺栞叢号叢栶厤叄叢佩!\u0012\u0016:^_\u001f\u0012]6\u001a";
      i[32] = "\u0002aitU~\f!\u007fM伳厌伽桃余伐厭厌伽厙\u0004p\u001fr\u001f1:pT~[";
      i[33] = "wY/\u00136*1\u00020[\fNMZ)I7u6Tr\u001d~\u0015!A%Oiu.W.Z\f";
      i[34] = "]\u000f\u007f\u0013`tR\u001f3[\u000fM3\u0002m\u00014\u007fH\f6U}\u001f";
      i[35] = "\\l\u0006$\u001e\u001bR,\u0010\u001d另佷佣厔伶栄格栳栧桎kv\u0018KE0Z%\u0019\u0016G";
      i[36] = "=D\u001f9\u0017\u00123\u0004\t\u0000栵栺伂桦桫栙佱佾伂桦r;OF=\u0002\tz^E3";
      i[37] = "@c_\u000f9A\u00068@G\u0003厽档佝佤佢叀厽伧栙佤?2\u000f\u0001\u007fHCc\u0017D>";
      i[38] = "?!7\u001bLm1a!\"伪原厞栃桃叡伪桅厞佇Z\u001eF&mu7[\ba?";
      i[39] = "\u0011U%pL6W\u000e:8v栐栲佫桚厃桯佔栲叵桚@Ib\u0012Y/.\njQV";
      i[40] = "UDNca\u001f\u0013\u001fQ+[佽厬古併桊桂根伲古叫SjQ\u0014XY/;IQ\u0019";
      i[41] = "\u0011\u001e)aL}\u001f^?X厴桕伮另伙厛伪休伮佸De\u0006q\fNzeM}H";
      i[42] = "\u000eCZ?\u001b\u000b\u000bL\u0014)x桠栮可桲厍去厺佪佱桲NA\u0016\u0006]\b<D\u0019HK";
      i[43] = "N?_\u0010u]\bd@XO厡桭桅叺佽厌桻桭原栠 p\u001eM IG>\u001cJ&";
      i[44] = ">T\u0012\blcx\u000f\r@V原余栮厷叻伋原余叴伩84gi\u000eO\t:'\u007f";
      i[45] = "?\u001ec\tqqyE|AK桗叆传佘叺桒厍叆传栜9z?~\u0002tE+';C";
      i[46] = "[z'\u0019(YU:1 低伵栠桘众口叐厫佤桘JJ,\nK1#\u001dz\r\u0001";
      i[47] = "\u007f>*\u001d\u001f\u0010q~<$佹核叞栜会叧叧佼栄叆G\u001bO\u0018ri)XG[}";
      i[48] = "\u001b\bs=}M\u0015He\u0004桟桥桠台标栝桟县桠佮\u001e:\"M\u0013\r{t B\u001d";
      i[49] = "9+2Z\u0016\u0014w)=T(厲栞厌栚栩栱厲佚厌栚0\u0016\u00156%=UX\u00179+";
      i[50] = "l\u0012z>\u001dze\u001fx3{伟作伥叆体伦桛作伥栜\u000e\u0016%oF?pK%g\u0006";
      i[51] = "#EH\u0000\u0002=e\u001eWH8栛佄佻样佭校佟栀佻叭0\tsbY_LXk'\u0018";
      i[52] = "$\u0005oSS\u000b*Eyj伵栣厅栧栛桳桱栣伛佣\u0002\u0000WX4NkW\u0001_~";
      i[53] = "+J\u0007x\u0002e%\n\u0011A叺桍厊桨伷伜叺厗厊伬j+\u00066;\u0001\u0003|P1q";
      i[54] = "}n*vA\u0004s.<O档叶栆桌厄厌厹叶叜桌G%EWm%.r\u0013P'";
      i[55] = "oo?A[-a/)x厣栅栔伉伏伥桹佁収桍RG\u001c%q$5\t\u001e\"w";
      i[56] = "_&\u0019e k\u0019}\u0006-\u001a厗伸历桦桌叙伉厦桜厼Upn\b|\u001f'~/\u001b;";
      i[57] = "UQ7\n\tF[\u0011!3叱桮栮桳桃佮佯厴佪厩Z\bQ\u0012U\u0017!I@\u0011[";
      i[58] = "S\n~\u001f\u0013L]Jh&叫厾史栨低佻栱厾栨佬\u0013\u001bY@NZ-\u001b\u0012L\n";
      i[59] = "6w\u0013H(\u000787\u0005qj6?/E\rtG(6O\t\u0013Z/ \u0012\u0014sU9+\u0007q";
      i[60] = "Z=1&~\u001bT}'\u001f桜佷佥栟桅栆历叩叻叅\\uzHJv5\",O\u0000";
      i[61] = "D\u001bf|\u0005XJ[pE佣厪栿根又优栧伴佻根\u000bxOTYK5x\u0004X\u001d";
      i[62] = "6\u0006\u0013+?up]\fc\u0005厉叏厦伨变佘桓佑桼伨\u001bopa\\\u0015ia1r\u001b";
      i[63] = " #qgjX.cg^伌厪厁佅栅厝案桰桛栁\u001c5l\b9\u007f-fmU;";
      i[64] = "`\u0004V.kwo\u0014\u001af\u0004B\u000e\tD<?|u\u0007\u001fhv\u001cb\u0012H:a|m\u0004C/\u0004";
      i[65] = "\u0000\r#;iR\u000eM5\u0002伏桺桻叵伓叁伏伾桻佫N?#^\u001d]p?hRY";
      i[66] = "\u0014=8.\r@Rf'f7桦佳桇桇标佪伢样伃桇\u001e]ECg>lS\u0004P ";
      i[67] = "Nf\u0011e\u001f,\b=\u000e-%\\te\u0017?\u001es\u000fkLkW\u0013";
      i[68] = "AwE#}\u0015Dx\u000b5\u001e桾去叛伩桋叝桾伥佅厷R'\bIi\u0017 \"\u0007\u0007\u007f";
      i[69] = "6+\n\u0015dOpp\u0015]^伭佑压伱格伃厳栕伕伱%4Jaq\fW:\u000br6";
      i[70] = " \u0004e0*mf_zx\u0010厑叙厤佞栙叓伏叙桾栚\u0000!#a\u0018r|p;$Y";
      i[71] = "e8V\u0017HL#cI_r厰框桂右佺桫厰厜桂右'C\u0002$$A[\u0012\u001aae";
      i[72] = "P2q`E\u0019^rgY厽叫佯及佁桀伣併栫栐\u001cc\u001dN\u00023#%FQJ";
      i[73] = "&-\u001c\u00032%(m\n:佔佉伙叕伬栣栐栍伙佋qP6v6f\u0018\u0007`q|";
      i[74] = "8\u001f\u001c\u0014m\u000f6_\n-厕佣伇栽桨叮桏栧伇佹q\u0010'\u0003%OO\u0010l\u000fa";
      i[75] = "Y\tz![ \u001fReia栆桺桳叟栈似叜伾伷栅\u0011Pn\u0018\u0015mm\u0001v]T";
      i[76] = "\u001d_a>x?S]n0F伇佾佦桉伉伛伇栺司厓T}9FY-/<(EW";
      i[77] = "XHc JE\u0019Y`.7u*pK\u0015vx8f@\u0019vb\"uK\u0015pd/f\\B\u000bN\fKi{\u000b^\t\u0015";
      i[78] = "$  \n!u*`63栃厇厅栂桔台栃伙桟但M\fq})w#Oy>&";
   }

   void m() {
      何树何友友何何友友树.G();
      long currentTime = System.currentTimeMillis();
      List<Module> toRemoveFromAnimationStartTimes = new ArrayList<>();
      Iterator var8 = new HashMap<>(this.友何何树树友树树何何).entrySet().iterator();
      if (var8.hasNext()) {
         Entry<Module, Long> entry = (Entry<Module, Long>)var8.next();
         Module module = entry.getKey();
         long lastUpdateTime = entry.getValue();
         boolean targetExpandedState = this.友友友树何何树友树何.getOrDefault(module, false);
         float targetAnimFactor = targetExpandedState ? 1.0F : 0.0F;
         float currentAnimFactor = this.何友何树何何友友何友.getOrDefault(module, 0.0F);
         long deltaTime = currentTime - lastUpdateTime;
         if (deltaTime <= 0L && !(Math.abs(currentAnimFactor - targetAnimFactor) < 0.001F)) {
            deltaTime = 1L;
         }

         if (Math.abs(currentAnimFactor - targetAnimFactor) > 0.001F && deltaTime > 0L) {
            float diff = targetAnimFactor - currentAnimFactor;
            float interpolationFactorRaw = (float)deltaTime / 150.0F * 2.0F;
            if (interpolationFactorRaw >= 1.0F) {
               currentAnimFactor = targetAnimFactor;
            }

            currentAnimFactor = Mth.clamp(currentAnimFactor + diff * interpolationFactorRaw, 0.0F, 1.0F);
            this.何友何树何何友友何友.put(module, currentAnimFactor);
            this.友何何树树友树树何何.put(module, currentTime);
         }

         if (Math.abs(currentAnimFactor - targetAnimFactor) <= 0.001F) {
            this.何友何树何何友友何友.put(module, targetAnimFactor);
            toRemoveFromAnimationStartTimes.add(module);
            if (targetAnimFactor == 0.0F && !this.友友友树何何树友树何.getOrDefault(module, false)) {
               this.何友何树何何友友何友.remove(module);
            }
         }
      }

      var8 = toRemoveFromAnimationStartTimes.iterator();
      if (var8.hasNext()) {
         Module m = (Module)var8.next();
         this.友何何树树友树树何何.remove(m);
      }
   }

   public static String[] o() {
      return 友何何何友友何友友树;
   }

   void t() {
      long currentTime = System.currentTimeMillis();
      何树何友友何何友友树.G();
      float maxScroll = Math.max(0.0F, this.树友何树友友树树友何 - this.何何树树何友友友何树);
      this.友树友树何何友友友何 = Mth.clamp(this.友树友树何何友友友何, 0.0F, maxScroll);
      if (this.何友友何树友树树树树 > 0L) {
         long deltaTime = currentTime - this.何友友何树友树树树树;
         if (deltaTime > 0L) {
            if (Math.abs(this.树何何树树树友友友友 - this.友树友树何何友友友何) > 0.01F) {
               float diff = this.友树友树何何友友友何 - this.树何何树树树友友友友;
               float interpolationFactorRaw = (float)deltaTime / 100.0F * 2.0F;
               if (interpolationFactorRaw >= 1.0F) {
                  this.树何何树树树友友友友 = this.友树友树何何友友友何;
               }

               this.树何何树树树友友友友 += diff * interpolationFactorRaw;
               this.树何何树树树友友友友 = Mth.clamp(this.树何何树树树友友友友, 0.0F, maxScroll);
               this.何友友何树友树树树树 = currentTime;
            }

            this.树何何树树树友友友友 = this.友树友树何何友友友何;
            this.何友友何树友树树树树 = 0L;
         }
      }

      this.树何何树树树友友友友 = Mth.clamp(this.树何何树树树友友友友, 0.0F, maxScroll);
      this.友树友树何何友友友何 = this.树何何树树树友友友友;
   }

   void g() {
      c<"a">(-6509130747517011183L, 35681453188538L);
      String name = c<"T">(this, -6506787001822492810L, 35681453188538L).trim();
      if (name.isEmpty()) {
         name = c<"T">(this, -6506448489438142970L, 35681453188538L);
      }

      if (!name.isEmpty() && !this.Q(name)) {
         友何何友树友树何树树 config = new 友何何友树友树何树树(new File(Cherish.getConfigManager().e(), name + ".ini"));
         if (!config.y().exists()) {
            树友何何何树友树何友.E(c<"J">(-6509045855669746785L, 35681453188538L), "Config", "Not found: " + name, 3.0F);
         } else {
            try {
               config.k();
               树友何何何树友树何友.E(c<"J">(-6507544365563255746L, 35681453188538L), "Config", "Loaded: " + name, 3.0F);
            } catch (Throwable var7) {
               树友何何何树友树何友.E(c<"J">(-6509045855669746785L, 35681453188538L), "Config", "Failed load:" + name, 3.0F);
            }
         }
      } else {
         树友何何何树友树何友.E(c<"J">(-6509045855669746785L, 35681453188538L), "", "No config name", 3.0F);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void q(String[] var0) {
      友何何何友友何友友树 = var0;
   }

   void u(double delta) {
      何树何友友何何友友树.G();
      float maxScroll = Math.max(0.0F, this.树友何树友友树树友何 - this.何何树树何友友友何树);
      if (!(maxScroll <= 0.0F) || !(delta < 0.0)) {
         if (!(this.友树友树何何友友友何 <= 0.0F) || !(delta > 0.0)) {
            Objects.requireNonNull(this.友友何友何树何何树树);
            float oldTargetScroll = this.友树友树何何友友友何;
            this.友树友树何何友友友何 -= (float)(delta * 27.0);
            this.友树友树何何友友友何 = Mth.clamp(this.友树友树何何友友友何, 0.0F, maxScroll);
            if (Math.abs(oldTargetScroll - this.友树友树何何友友友何) > 0.01F) {
               this.友何何友何树树树树树 = System.currentTimeMillis();
               if (this.何友友何树友树树树树 == 0L) {
                  this.何友友何树友树树树树 = System.currentTimeMillis() - 16L;
               }

               this.何友友何树友树树树树 = System.currentTimeMillis();
            }
         }
      }
   }

   void r(GuiGraphics g, 树何何树何友树何何树<?> value, float valueX, float valueY, float valueWidth, int mouseX, int mouseY, int alpha) {
      友友何何何树友友何树 handler = this.F(value);
      handler.a(g, this, value, valueX, valueY, 106.0F, mouseX, mouseY, alpha);
   }

   何何何友友何树何何何 Y(树何何树何友树何何树<?> value, double mouseX, double mouseY, int buttonValue, float valueX, float valueY, float valueWidth) {
      友友何何何树友友何树 handler = this.F(value);
      return handler.K(this, value, mouseX, mouseY, buttonValue, valueX, valueY, 106.0F);
   }

   boolean L(int keyCode, int scanCode, int modifiers, 何何何友友何树何何何 targetTextValue) {
      何树何友友何何友友树.G();
      if (this.树树树友树树树友树何 == 树何友友何树友友何何.友树友树树树友何友树 && this.树何友何树友树何树树 && this.友友何友何树何何树树.友何树友友何友何友何 == this) {
         if (keyCode == 257 || keyCode == 335) {
            this.树何友何树友树何树树 = false;
            if ("default".equals(this.友树树树树何何友何友)) {
               this.V();
            }

            if ("Config name".equals(this.友树树树树何何友何友)) {
               this.g();
            }

            return true;
         } else if (keyCode == 259) {
            if (!this.树树何树树树何何何树.isEmpty()) {
               this.树树何树树树何何何树 = this.树树何树树树何何何树.substring(0, this.树树何树树树何何何树.length() - 1);
            }

            return true;
         } else {
            return true;
         }
      } else if (targetTextValue == null || this.友友何友何树何何树树.友树树友何友树树友树 != targetTextValue || this.友友何友何树何何树树.友何树友友何友何友何 != this) {
         return false;
      } else if (keyCode == 257 || keyCode == 335) {
         this.友友何友何树何何树树.友树树友何友树树友树 = null;
         this.友树树何何何树何友树 = null;
         this.友友何友何树何何树树.友何树友友何友何友何 = null;
         return true;
      } else if (keyCode == 259) {
         String current = targetTextValue.getValue();
         if (!current.isEmpty()) {
            targetTextValue.G(current.substring(0, current.length() - 1));
         }

         return true;
      } else if (keyCode == 86 && Screen.hasControlDown()) {
         String clipboard = mc.keyboardHandler.getClipboard();
         targetTextValue.G(targetTextValue.getValue() + clipboard.replaceAll("Load", ""));
         return true;
      } else {
         return true;
      }
   }

   何何何友友何树何何何 L(double mouseX, double mouseY, int button) {
      何树何友友何何友友树.G();
      this.树友友树树友树何树何 = false;
      if (this.友友何友何树何何树树.g(mouseX, mouseY, this.何何何友何树树树何何, this.树友树树友友友友友树, 110.0F, 20.0F) && button == 0) {
         this.何树友树何友友何树友 = true;
         this.树友友树树友树何树何 = true;
         return null;
      } else if (!this.G(mouseX, mouseY)) {
         return null;
      } else {
         float currentItemYOffsetIterator = this.树友树树友友友友友树 + 20.0F + 2.0F - this.树何何树树树友友友友;
         if (this.树树树友树树树友树何 == 树何友友何树友友何何.友树友树树树友何友树) {
            String[] actions = new String[]{"default", "Config name", "Load", "Save", "Delete"};
            int module = actions.length;
            int moduleEntryHeight = 0;
            if (0 < module) {
               String action = actions[0];
               if (this.友友何友何树何何树树.g(mouseX, mouseY, this.何何何友何树树树何何 + 2.0F, currentItemYOffsetIterator, 106.0F, 18.0F) && button == 0) {
                  this.友树树树树何何友何友 = action;
                  this.树何友何树友树何树树 = action.equals("Config name");
                  if (this.树何友何树友树何树树) {
                     this.友树树何何何树何友树 = null;
                     this.友友何友何树何何树树.友树树友何友树树友树 = null;
                     this.友友何友何树何何树树.友何树友友何友何友何 = this;
                  }

                  if (action.equals("Load")) {
                     this.g();
                  }

                  if (action.equals("Save")) {
                     this.V();
                  }

                  if (action.equals("Delete")) {
                     this.f();
                  }

                  if (action.equals("default")) {
                     this.树树何树树树何何何树 = "default";
                  }

                  this.树友友树树友树何树何 = true;
                  return null;
               }

               Objects.requireNonNull(this.友友何友何树何何树树);
               currentItemYOffsetIterator += 20.0F;
               moduleEntryHeight++;
            }

            if (!this.何友友树树友何树友何.isEmpty()) {
               currentItemYOffsetIterator += 3.0F;
            }

            Iterator var11 = this.何友友树树友何树友何.iterator();
            if (var11.hasNext()) {
               String confName = (String)var11.next();
               if (this.友友何友何树何何树树.g(mouseX, mouseY, this.何何何友何树树树何何 + 2.0F, currentItemYOffsetIterator, 106.0F, 18.0F)) {
                  this.树树何树树树何何何树 = confName;
                  this.树何友何树友树何树树 = false;
                  this.友树树树树何何友何友 = "Config name";
                  this.树友友树树友树何树何 = true;
                  return null;
               }

               Objects.requireNonNull(this.友友何友何树何何树树);
               currentItemYOffsetIterator += 20.0F;
            }
         }

         List<Module> modules = Cherish.instance.getModuleManager().Z(this.树树树友树树树友树何);
         Iterator var24 = modules.iterator();
         if (var24.hasNext()) {
            Module modulex = (Module)var24.next();
            float moduleEntryHeightx = 18.0F;
            float animationFactorForLayout = this.何友何树何何友友何友.getOrDefault(modulex, this.友友友树何何树友树何.getOrDefault(modulex, false) ? 1.0F : 0.0F);
            if (animationFactorForLayout > 0.001F) {
               float naturalSettingsBlockHeight = 0.0F;
               List<树何何树何友树何何树<?>> visibleValues = modulex.P().stream().filter(v -> {
                  何树何友友何何友友树.G();
                  return !v.O();
               }).collect(Collectors.toList());
               if (!visibleValues.isEmpty()) {
                  Iterator settingClickX = visibleValues.iterator();
                  if (settingClickX.hasNext()) {
                     树何何树何友树何何树<?> v = (树何何树何友树何何树<?>)settingClickX.next();
                     naturalSettingsBlockHeight = 0.0F + this.J(v);
                  }
               }

               moduleEntryHeightx = 18.0F + naturalSettingsBlockHeight * animationFactorForLayout;
            }

            if (this.友友何友何树何何树树.g(mouseX, mouseY, this.何何何友何树树树何何 + 2.0F, currentItemYOffsetIterator, 106.0F, moduleEntryHeightx)) {
               if (this.友友何友何树何何树树.g(mouseX, mouseY, this.何何何友何树树树何何 + 2.0F, currentItemYOffsetIterator, 106.0F, 18.0F)) {
                  if (button == 0) {
                     modulex.n();
                  }

                  if (button == 1 && modulex.P().stream().filter(v -> {
                     何树何友友何何友友树.G();
                     return !v.O();
                  }).count() != 0L) {
                     boolean wasExpanded = this.友友友树何何树友树何.getOrDefault(modulex, false);
                     this.友友友树何何树友树何.put(modulex, !wasExpanded);
                     this.友何何树树友树树何何.put(modulex, System.currentTimeMillis() - 16L);
                     if (this.友树树何何何树何友树 != null && modulex.P().contains(this.友树树何何何树何友树)) {
                        this.友树树何何何树何友树 = null;
                     }

                     if (this.友友何友何树何何树树.友树树友何友树树友树 != null && modulex.P().contains(this.友友何友何树何何树树.友树树友何友树树友树)) {
                        this.友友何友何树何何树树.友树树友何友树树友树 = null;
                     }

                     if (this.友友何友何树何何树树.友何树友友何友何友何 == this && this.友树树何何何树何友树 == null && this.友友何友何树何何树树.友树树友何友树树友树 == null) {
                        this.友友何友何树何何树树.友何树友友何友何友何 = null;
                     }

                     Iterator var33 = modulex.P().iterator();
                     if (var33.hasNext()) {
                        树何何树何友树何何树<?> val = (树何何树何友树何何树<?>)var33.next();
                        if (val instanceof 树友何何树树何友友何) {
                           友友何何何树友友何树 handler = this.F(val);
                           if (handler instanceof 树友何友树友何友何友) {
                              ((树友何友树友何友何友)handler).x();
                           }
                        }
                     }

                     var33 = modulex.P().iterator();
                     if (var33.hasNext()) {
                        树何何树何友树何何树<?> val = (树何何树何友树何何树<?>)var33.next();
                        if (!val.O()) {
                           友友何何何树友友何树 handler = this.F(val);
                           if (handler instanceof 友友何友树友树树何树) {
                              ((友友何友树友树树何树)handler).d();
                           }
                        }
                     }
                  }

                  this.树友友树树友树何树何 = true;
                  return null;
               }

               float animationFactorForClick = this.何友何树何何友友何友.getOrDefault(modulex, this.友友友树何何树友树何.getOrDefault(modulex, false) ? 1.0F : 0.0F);
               if (this.友友友树何何树友树何.getOrDefault(modulex, false) && animationFactorForClick >= 0.99F) {
                  float currentSettingClickY = currentItemYOffsetIterator + 18.0F;
                  float settingClickX = this.何何何友何树树树何何 + 2.0F;
                  Objects.requireNonNull(this.友友何友何树何何树树);
                  Objects.requireNonNull(this.友友何友何树何何树树);

                  for (树何何树何友树何何树<?> val : modulex.P()) {
                     if (!val.O()) {
                        float vh = this.J(val);
                        if (this.友友何友何树何何树树.g(mouseX, mouseY, settingClickX, currentSettingClickY, 106.0F, vh)) {
                           return this.Y(val, mouseX, mouseY, button, settingClickX, currentSettingClickY, 106.0F);
                        }

                        float var40 = currentSettingClickY + vh;
                        break;
                     }
                  }
               }

               this.树友友树树友树何树何 = true;
               return null;
            }

            float var10000 = currentItemYOffsetIterator + moduleEntryHeightx;
         }

         return null;
      }
   }

   private Color P(Color c1, Color c2, float progress) {
      progress = Mth.clamp(progress, 0.0F, 1.0F);
      float r = c1.getRed() + (c2.getRed() - c1.getRed()) * progress;
      float g = c1.getGreen() + (c2.getGreen() - c1.getGreen()) * progress;
      float b = c1.getBlue() + (c2.getBlue() - c1.getBlue()) * progress;
      float a = c1.getAlpha() + (c2.getAlpha() - c1.getAlpha()) * progress;
      return new Color((int)r, (int)g, (int)b, (int)a);
   }

   void P(
      GuiGraphics guiGraphics, Module module, float moduleRenderX, float moduleRenderY, int mouseX, int mouseY, int baseAlpha, float settingsAnimationFactor
   ) {
      何树何友友何何友友树.G();
      何树何友友何何友友树 var10001 = this.友友何友何树何何树树;
      double var10002 = mouseX;
      double var10003 = mouseY;
      Objects.requireNonNull(this.友友何友何树何何树树);
      var10001.g(var10002, var10003, moduleRenderX, moduleRenderY, 106.0F, 18.0F);
      module.isEnabled();
      float highlightProgress = this.何友树树友何树何何树.getOrDefault(module, 1.0F);
      Color bgColorWhenDisabled = this.友友何友何树何何树树.树树树友树何友何何树;
      Color bgColorWhenEnabled = HUD.instance.getColor(4);
      Color interpolatedBgColor = this.P(bgColorWhenDisabled, bgColorWhenEnabled, highlightProgress);
      Color finalBgColor = this.友友何友何树何何树树.o(interpolatedBgColor, baseAlpha);
      PoseStack var10000 = guiGraphics.pose();
      Objects.requireNonNull(this.友友何友何树何何树树);
      RenderUtils.drawRectangle(var10000, moduleRenderX, moduleRenderY, 106.0F, 18.0F, finalBgColor.getRGB());
      Color fontColorWhenDisabled = this.友友何友何树何何树树.树友何何友树友友何树;
      Color fontColorWhenEnabled = this.友友何友何树何何树树.友树树友何树友友树友;
      Color interpolatedFontColor = this.P(fontColorWhenDisabled, fontColorWhenEnabled, highlightProgress);
      Color finalFontColor = this.友友何友何树何何树树.o(interpolatedFontColor, baseAlpha);
      String moduleName = this.友友何友何树何何树树.树树何树友树何树友树 ? module.A() : module.B();
      this.友友何友何树何何树树
         .何何友何树何友树何何
         .s(guiGraphics.pose(), moduleName, moduleRenderX + 2.0F, moduleRenderY + 9.0F - this.友友何友何树何何树树.何何友何树何友树何何.x() / 2.0F, finalFontColor.getRGB());
      if (module.P().stream().filter(v -> {
         何树何友友何何友友树.G();
         return !v.O();
      }).count() != 0L) {
         String arrowChar = (!(settingsAnimationFactor > 0.5F) || !this.友友友树何何树友树何.getOrDefault(module, false))
               && (!(settingsAnimationFactor > 0.0F) || !this.友友友树何何树友树何.getOrDefault(module, false) || !this.友何何树树友树树何何.containsKey(module))
            ? "+"
            : "-";
         float arrowWidth = this.友友何友何树何何树树.友何友树树友何友树友.D(arrowChar);
         Objects.requireNonNull(this.友友何友何树何何树树);
         float arrowX = moduleRenderX + 106.0F - arrowWidth - 2.0F;
         this.友友何友何树何何树树
            .友何友树树友何友树友
            .s(guiGraphics.pose(), arrowChar, arrowX, moduleRenderY + 9.0F - this.友友何友何树何何树树.友何友树树友何友树友.x() / 2.0F, finalFontColor.getRGB());
      }

      if (settingsAnimationFactor > 0.001F) {
         float naturalSettingsBlockHeight = 0.0F;
         List<树何何树何友树何何树<?>> visibleValues = module.P().stream().filter(v -> {
            何树何友友何何友友树.G();
            return !v.O();
         }).collect(Collectors.toList());
         if (!visibleValues.isEmpty()) {
            Iterator var36 = visibleValues.iterator();
            if (var36.hasNext()) {
               树何何树何友树何何树<?> value = (树何何树何友树何何树<?>)var36.next();
               naturalSettingsBlockHeight = 0.0F + this.J(value);
            }
         }

         float animatedRenderHeight = naturalSettingsBlockHeight * settingsAnimationFactor;
         float settingsStartY = moduleRenderY + 18.0F;
         Objects.requireNonNull(this.友友何友何树何何树树);
         Objects.requireNonNull(this.友友何友何树何何树树);
         int settingAlpha = (int)(baseAlpha * settingsAnimationFactor);
         guiGraphics.pose().pushPose();
         guiGraphics.pose().translate(0.0F, 0.0F, 100.0F);
         guiGraphics.enableScissor((int)moduleRenderX, (int)settingsStartY, (int)(moduleRenderX + 106.0F), (int)(settingsStartY + animatedRenderHeight + 1.0F));
         RenderUtils.drawRectangle(
            guiGraphics.pose(), moduleRenderX, settingsStartY, 106.0F, animatedRenderHeight, this.友友何友何树何何树树.o(this.友友何友何树何何树树.友友友何树友何友树树, baseAlpha).getRGB()
         );
         Iterator var31 = visibleValues.iterator();
         if (var31.hasNext()) {
            树何何树何友树何何树<?> value = (树何何树何友树何何树<?>)var31.next();
            float valueEntryHeight = this.J(value);
            if (settingsStartY < settingsStartY + animatedRenderHeight && settingsStartY + valueEntryHeight > settingsStartY) {
               this.r(guiGraphics, value, moduleRenderX, settingsStartY, 106.0F, mouseX, mouseY, settingAlpha);
            }

            float var39 = settingsStartY + valueEntryHeight;
         }

         guiGraphics.disableScissor();
         guiGraphics.pose().popPose();
      }

      if (Module.Z() == null) {
         何树何友友何何友友树.S(new Module[4]);
      }
   }

   private void W() {
      this.何友友树树友何树友何.clear();
      何树何友友何何友友树.G();
      File configDir = Cherish.getConfigManager().e();
      if (configDir.exists() && configDir.isDirectory()) {
         File[] files = configDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".ini"));
         int var7 = files.length;
         int var8 = 0;
         if (0 < var7) {
            File file = files[0];
            this.何友友树树友何树友何.add(file.getName().replace(".ini", ""));
            var8++;
         }
      }

      this.何友友树树友何树友何.sort(String.CASE_INSENSITIVE_ORDER);
      if (!this.何友友树树友何树友何.contains("default")) {
         this.何友友树树友何树友何.add(0, "default");
      }
   }

   private static String HE_WEI_LIN() {
      return "何大伟230622198107200054";
   }

   boolean Q(String word) {
      何树何友友何何友友树.G();
      return word.equals("Load") || word.equals("Save") || word.equals("Delete") || word.equals("default") || word.equals("Config name");
   }

   boolean G(double mouseX, double mouseY) {
      何树何友友何何友友树.G();
      return mouseX >= this.何何何友何树树树何何
         && mouseX <= this.何何何友何树树树何何 + 110.0F
         && mouseY >= this.树友树树友友友友友树 + 20.0F
         && mouseY <= this.树友树树友友友友友树 + 20.0F + this.何何树树何友友友何树;
   }

   void O() {
      何树何友友何何友友树.G();
      this.m();
      this.t();
      if (this.树树树友树树树友树何 != 树何友友何树友友何何.友树友树树树友何友树) {
         List<Module> modules = Cherish.instance.getModuleManager().Z(this.树树树友树树树友树何);
         if (modules != null) {
            Iterator var5 = modules.iterator();
            if (var5.hasNext()) {
               Module module = (Module)var5.next();
               this.x(module);
            }
         }
      }
   }
}
