package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.impl.ModeValue;
import com.mojang.blaze3d.vertex.PoseStack;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;

public class 友树树友友树友何树友 implements 友树何树友友树树何树<ModeValue>,  {
   private static final float 友友何何友友树何何友 = 7.0F;
   private static final float 友友友友何树树何何友 = 10.0F;
   private static final float 树树友友树何树友树树 = 12.0F;
   private static final float 友树何树树树树何何友 = 5.0F;
   private static final float 友树树何何何何树树树 = 5.0F;
   private static final float 何树何树树友树何友树 = 5.0F;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[21];
   private static final String[] f = new String[21];
   private static int _何树友为什么濒天了 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1505362396944220472L, 2841017951641268398L, MethodHandles.lookup().lookupClass()).a(101598129361672L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 5354718182902L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 144;
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "·\u0014ß\u0004Þa\u001cÆu-:\u009fsº\u009f2 \u0086.\u001dyöÝÂ\u0015\u001e=ï=~ÛQ\u009d<u\u0013\u0085Ù³+W\npiÊ\u0084®\u001fEÇ[óí2\u0091Wúsb¢\u008f5Á;\u0081\u0006k\u0099t>\u0086[õ\"Ù\u0084Ó¢0ÜË¥+`\u009dcÈ\u0016De|/~Äµ\u0002±bop\u0082MÊò\t9dS\u008f\u0086Î²ô°ÀP\u0005å\u009f\u000f\u0002¨×jym°FÈßñ°ÝÈÝ\r4Â=¥ïÊjÊ\u0010²ô.ù'zZìù·\u000e:ê\u0086{µ"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 161) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "·\u0014ß\u0004Þa\u001cÆu-:\u009fsº\u009f2 \u0086.\u001dyöÝÂ\u0015\u001e=ï=~ÛQ\u009d<u\u0013\u0085Ù³+W\npiÊ\u0084®\u001fEÇ[óí2\u0091Wúsb¢\u008f5Á;\u0081\u0006k\u0099t>\u0086[õ\"Ù\u0084Ó¢0ÜË¥+`\u009dcÈ\u0016De|/~Äµ\u0002±bop\u0082MÊò\t9dS\u008f\u0086Î²ô°ÀP\u0005å\u009f\u000f\u0002¨×jym°FÈßñ°ÝÈÝ\r4Â=¥ïÊjÊ\u0010²ô.ù'zZìù·\u000e:ê\u0086{µ"
            .charAt(var4);
      }
   }

   public void i(
      GuiGraphics guiGraphics,
      ModeValue value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      友何何树友何何何何树 settingNameFont,
      友何何树友何何何何树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      友树友树何树友友友树 componentsInstance
   ) {
      long a = 友树树友友树友何树友.a ^ 51703647186108L;
      long ax = a ^ 84330163996816L;
      long axx = a ^ 5312737305151L;
      float maxModeNameWidth = this.G(value, settingNameFont);
      b<"P">(1271851728144268103L, a);
      float arrowIconActualWidth = this.W();
      float currentDynamicModeBoxWidth = 5.0F + maxModeNameWidth + 5.0F + arrowIconActualWidth + 5.0F;
      b<"ñ">(componentsInstance, 1270110829800184538L, a).getOrDefault(value, false);
      float expandAnimation = b<"ñ">(componentsInstance, 1272163527958090677L, a).getOrDefault(value, 0.0F);
      if (Math.abs(expandAnimation - 1.0F) > 0.001F) {
         float var54 = expandAnimation + (1.0F - expandAnimation) * 0.15F * partialTicks * 5.0F;
         expandAnimation = Math.max(0.0F, Math.min(1.0F, var54));
         b<"ñ">(componentsInstance, 1272163527958090677L, a).put(value, expandAnimation);
      }

      float boxX = x + width - (currentDynamicModeBoxWidth + 7.0F);
      float boxY = middleY - 5.0F;
      float fullOptionsAreaHeight = 0.0F;
      int displayedOptionsCount = 0;
      String[] currentAnimatedOptionsHeight = value.s();
      int currentMode = currentAnimatedOptionsHeight.length;
      int currentModeTextWidth = 0;
      if (0 < currentMode) {
         String modeValue = currentAnimatedOptionsHeight[0];
         if (!modeValue.equals(value.getValue())) {
            fullOptionsAreaHeight = 12.0F;
            displayedOptionsCount++;
         }

         currentModeTextWidth++;
         b<"P">(!b<"P">(1271730718817938675L, a), 1270386774103174739L, a);
      }

      if (displayedOptionsCount > 0) {
         fullOptionsAreaHeight += 2.0F;
      }

      float currentAnimatedOptionsHeightx = fullOptionsAreaHeight * expandAnimation;
      RenderUtils.drawRoundedRect(guiGraphics.pose(), boxX, boxY, currentDynamicModeBoxWidth, 10.0F + currentAnimatedOptionsHeightx, 2.0, darkBgColor);
      String currentModex = value.getValue();
      float currentModeTextWidthx = settingNameFont.A(currentModex);
      float modeTextX = boxX + 5.0F + (maxModeNameWidth - currentModeTextWidthx) / 2.0F + 2.0F;
      float modeTextY = boxY + (10.0F - settingNameFont.K()) / 2.0F + 0.5F;
      settingNameFont.c(guiGraphics.pose(), currentModex, modeTextX, modeTextY, b<"ë">(1270331144003509071L, a).getRGB());
      float arrowCenterX = boxX + 5.0F + maxModeNameWidth + 5.0F + arrowIconActualWidth / 2.0F;
      float arrowY = boxY + 5.0F;
      this.Y(guiGraphics, arrowCenterX, arrowY, expandAnimation, b<"ë">(1270331144003509071L, a).getRGB());
      if (expandAnimation > 0.01F && displayedOptionsCount > 0) {
         float optionDisplayAreaStartY = boxY + 10.0F;
         float optionContentActualStartY = optionDisplayAreaStartY + 2.0F;
         guiGraphics.enableScissor(
            (int)boxX, (int)optionDisplayAreaStartY, (int)(boxX + currentDynamicModeBoxWidth), (int)(optionDisplayAreaStartY + currentAnimatedOptionsHeightx)
         );
         ClientUtils.o(new Object[]{ax});
         HashMap<String, Float> optionHovers = b<"ñ">(componentsInstance, 1271972129265260270L, a).computeIfAbsent(value.v(), k -> new HashMap<>());
         String[] var46 = value.s();
         int var47 = var46.length;
         int var48 = 0;
         if (0 < var47) {
            String mode = var46[0];
            if (mode.equals(value.getValue())) {
            }

            if (mouseX >= boxX
               && mouseX <= boxX + currentDynamicModeBoxWidth
               && mouseY >= optionContentActualStartY
               && mouseY <= optionContentActualStartY + 12.0F
               && mouseY < optionDisplayAreaStartY + currentAnimatedOptionsHeightx) {
            }

            float hoverAnim = optionHovers.getOrDefault(mode, 0.0F);
            if (Math.abs(hoverAnim - 1.0F) > 0.001F) {
               float var61 = hoverAnim + (1.0F - hoverAnim) * 0.2F * partialTicks * 5.0F;
               hoverAnim = Math.max(0.0F, Math.min(1.0F, var61));
               optionHovers.put(mode, hoverAnim);
            }

            if (hoverAnim > 0.01F) {
               Color hoverColor = new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), (int)(hoverAnim * 100.0F));
               PoseStack var10000 = guiGraphics.pose();
               float var10001 = (int)boxX;
               float var10002 = (int)optionContentActualStartY;
               float var10003 = (int)(boxX + currentDynamicModeBoxWidth);
               float var10004 = (int)(optionContentActualStartY + 12.0F);
               Object[] var10008 = new Object[]{null, null, null, null, null, null, hoverColor.getRGB()};
               var10008[5] = axx;
               var10008[4] = var10004;
               var10008[3] = var10003;
               var10008[2] = var10002;
               var10008[1] = var10001;
               var10008[0] = var10000;
               RenderUtils.E(var10008);
            }

            settingNameFont.c(
               guiGraphics.pose(),
               mode,
               boxX + 5.0F,
               optionContentActualStartY + (12.0F - settingNameFont.K()) / 2.0F + 0.5F,
               b<"ë">(1270331144003509071L, a).getRGB()
            );
            float var62 = optionContentActualStartY + 12.0F;
            var48++;
         }

         guiGraphics.disableScissor();
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树树友友树友何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      e[0] = "0\u007f4kKD??y`AY:br&QB}叚栋參栵佾桂叚发參栵";
      e[1] = "`L<29L~D&}_XyE\u00072g";
      e[2] = "S\u000f\u0001\u0013\u000e\u0019\\OL\u0018\u0004\u0004Y\u0012G^\u0014\u001f\u001e厪栾桡厪厽校厪佺桡厪";
      e[3] = "\\\u0017k\u0013k7W\u0018z\\\u0017.X\u0002t\u001f \u001eN\u0015x\u000212Y\u0018";
      e[4] = "6 C\u007f\u0000\u00109`\u000et\n\r<=\u00052\u001a\u0016{厅伸佉厤桮伀桟桼栍伺";
      e[5] = boolean.class;
      f[5] = "java/lang/Boolean";
      e[6] = "\u001btv\\PU\u00144;WZH\u0011i0\u0011RU\u001co4Z\u0011w\u0017~-SZ";
      e[7] = void.class;
      f[7] = "java/lang/Void";
      e[8] = "u,\u0000TGch9Xv\u0006np?";
      e[9] = "\u0016yep\u001dk\u001fwf9^i\u0014b`p1|\u001ce";
      e[10] = "\f>g\u001d\u00131\u00071vRr?\f:r\b";
      e[11] = "\u0017,\u0002(\u001b\u0003\u0018/DS伻桫伮伉叻厐厥桫伮桍8jX\u0011\u00147\t6\u0000\u0015M";
      e[12] = "W\u0001\fl=\u0007\u0016U\twT\u0015m\u0003Run\u000e\u000f\u0001\u001dd;|W\u0007\u00121&\u001eUH\u0003dT";
      e[13] = "I ?\u0018kCJnl\nZeu$lX;Z\u000eoj\u0006j&";
      e[14] = "+_\u0011!wF$\\WZ叉栮厌佺栲桃叉叴伒佺+c4T(D\u001a?lPq";
      e[15] = "\u0003@OYIDQ\u001dE\u000f*`8AG\u0003K[C\nA]\u001a'";
      e[16] = "\\Hz\u0010A\u0002_\u0006)\u0002p.`L)P\u0011\u001b\u001b\u0007/\u000e@g]\u001a!Y\u0015[\u0002L+\u001ep";
      e[17] = "<1Y\bg]\u007fn\u0006\u001eWcBOb<W\u0002=iGA6Ab6Q";
      e[18] = "O(p\"\u001br\u001dk#&a~&#ue](JNHaP(\fc*3\u0013{\b";
      e[19] = "852\u0001\u0003\u007fjh8W`W\u00034:[\u0001`x\u007f<\u0005P\u001c";
      e[20] = "/\t\u0000ex\u000f \nF\u001e叆伣厈厲叹佃佘伣厈桨:';\u001d,\u0012\u000b{c\u0019u";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 31;
               case 1 -> 16;
               case 2 -> 9;
               case 3 -> 7;
               case 4 -> 23;
               case 5 -> 44;
               case 6 -> 14;
               case 7 -> 37;
               case 8 -> 3;
               case 9 -> 43;
               case 10 -> 4;
               case 11 -> 24;
               case 12 -> 53;
               case 13 -> 34;
               case 14 -> 61;
               case 15 -> 30;
               case 16 -> 54;
               case 17 -> 40;
               case 18 -> 50;
               case 19 -> 60;
               case 20 -> 48;
               case 21 -> 41;
               case 22 -> 55;
               case 23 -> 52;
               case 24 -> 62;
               case 25 -> 8;
               case 26 -> 35;
               case 27 -> 29;
               case 28 -> 45;
               case 29 -> 20;
               case 30 -> 19;
               case 31 -> 32;
               case 32 -> 36;
               case 33 -> 10;
               case 34 -> 11;
               case 35 -> 63;
               case 36 -> 1;
               case 37 -> 39;
               case 38 -> 28;
               case 39 -> 59;
               case 40 -> 33;
               case 41 -> 47;
               case 42 -> 25;
               case 43 -> 12;
               case 44 -> 38;
               case 45 -> 26;
               case 46 -> 15;
               case 47 -> 18;
               case 48 -> 17;
               case 49 -> 27;
               case 50 -> 21;
               case 51 -> 2;
               case 52 -> 57;
               case 53 -> 0;
               case 54 -> 51;
               case 55 -> 49;
               case 56 -> 6;
               case 57 -> 56;
               case 58 -> 5;
               case 59 -> 58;
               case 60 -> 13;
               case 61 -> 42;
               case 62 -> 46;
               default -> 22;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21844;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友树树友友树友何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树树友友树友何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 241 && var8 != 164 && var8 != 235 && var8 != 212) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 162) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'P') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 241) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 164) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 235) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public float g(ModeValue value, 友树友树何树友友友树 componentsInstance) {
      long a = 友树树友友树友何树友.a ^ 20542433800264L;
      b<"P">(960036106693207987L, a);
      float animation = b<"ñ">(componentsInstance, 960283038033923905L, a).getOrDefault(value, 0.0F);
      float calculatedHeight = 0.0F;
      int displayedOptionsCount = 0;
      String[] var9 = value.s();
      int var10 = var9.length;
      int var11 = 0;
      if (0 < var10) {
         String modeValue = var9[0];
         if (!modeValue.equals(value.getValue())) {
            calculatedHeight = 12.0F;
            displayedOptionsCount++;
         }

         var11++;
      }

      if (displayedOptionsCount > 0) {
         calculatedHeight += 2.0F;
      }

      return animation > 0.01F ? calculatedHeight * animation : 0.0F;
   }

   public boolean r(ModeValue value, char chr, int modifiers, 友树友树何树友友友树 componentsInstance) {
      return false;
   }

   private void Y(GuiGraphics guiGraphics, float x, float y, float animationProgress, int color) {
      long a = 友树树友友树友何树友.a ^ 83065255878025L;
      float rotation = animationProgress * 180.0F;
      友何何树友何何何何树 arrowFont = Cherish.instance.h().F(18);
      float charWidth = arrowFont.A("\uea56");
      float charHeight = arrowFont.K();
      guiGraphics.pose().pushPose();
      guiGraphics.pose().translate(x, y, 0.0F);
      guiGraphics.pose().mulPose(b<"ë">(-2264016302256167511L, a).rotation((float)Math.toRadians(rotation)));
      float xOffset = -charWidth / 2.0F;
      float yOffset = -charHeight / 2.0F + 1.0F;
      arrowFont.c(guiGraphics.pose(), "\uea56", xOffset, yOffset, color);
      guiGraphics.pose().popPose();
   }

   public boolean N(ModeValue value, int keyCode, int scanCode, int modifiers, 友树友树何树友友友树 componentsInstance) {
      return false;
   }

   public void N(ModeValue value, double mouseX, double mouseY, int button, 友树友树何树友友友树 componentsInstance) {
   }

   private float W() {
      return Cherish.instance.h().F(18).A("\uea56");
   }

   private float G(ModeValue value, 友何何树友何何何何树 font) {
      long a = 友树树友友树友何树友.a ^ 79464252005985L;
      b<"P">(7168570810851133850L, a);
      float maxWidth = 0.0F;
      if (value.s() == null || value.s().length == 0) {
         maxWidth = font.A(a<"u">(26511, 2374264989087551906L ^ a));
      }

      String[] var7 = value.s();
      int var8 = var7.length;
      int var9 = 0;
      if (0 < var8) {
         String modeValue = var7[0];
         maxWidth = Math.max(maxWidth, (float)font.A(modeValue));
         var9++;
      }

      return maxWidth;
   }

   public boolean O(
      ModeValue value, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 友树友树何树友友友树 componentsInstance
   ) {
      long a = 友树树友友树友何树友.a ^ 13289941487339L;
      b<"P">(-867321632786170315L, a);
      if (button == 0) {
         树树树友友树友树树树 fm = Cherish.instance.h();
         友何何树友何何何何树 fontForMetrics = null;
         if (fm != null) {
            fontForMetrics = fm.n(18);
            if (fontForMetrics == null) {
               fontForMetrics = fm.n(18);
            }

            if (fontForMetrics == null) {
               fontForMetrics = fm.n(18);
            }

            if (fontForMetrics == null) {
               fontForMetrics = fm.n(18);
            }
         }

         if (fontForMetrics != null) {
            float maxModeNameWidth = this.G(value, fontForMetrics);
            float arrowIconActualWidth = this.W();
            float var10000 = 5.0F + maxModeNameWidth + 5.0F + arrowIconActualWidth + 5.0F;
         }

         null.println(a<"u">(31040, 8476775695109414886L ^ a));
         float boxX = x + width - 77.0F;
         float boxY = middleY - 5.0F;
         if (mouseX >= boxX && mouseX <= boxX + 70.0F && mouseY >= boxY && mouseY <= boxY + 10.0F) {
            boolean currentExpandedState = b<"ñ">(componentsInstance, -867096849223894899L, a).getOrDefault(value, false);
            b<"ñ">(componentsInstance, -867096849223894899L, a).put(value, !currentExpandedState);
            return true;
         }

         boolean isExpanded = b<"ñ">(componentsInstance, -867096849223894899L, a).getOrDefault(value, false);
         float expandAnimation = b<"ñ">(componentsInstance, -869050771723931166L, a).getOrDefault(value, 0.0F);
         int displayedOptionsCount = 0;
         String[] optionDisplayAreaStartY = value.s();
         int optionRenderY = optionDisplayAreaStartY.length;
         int var26 = 0;
         if (0 < optionRenderY) {
            String modeValue = optionDisplayAreaStartY[0];
            if (!modeValue.equals(value.getValue())) {
               displayedOptionsCount++;
            }

            var26++;
         }

         if (isExpanded && expandAnimation > 0.8F && displayedOptionsCount > 0) {
            float optionDisplayAreaStartYx = boxY + 10.0F;
            float optionRenderYx = optionDisplayAreaStartYx + 2.0F;
            String[] var36 = value.s();
            int var37 = var36.length;
            int var28 = 0;
            if (0 < var37) {
               String mode = var36[0];
               if (mode.equals(value.getValue())) {
               }

               if (mouseX >= boxX && mouseX <= boxX + 70.0F && mouseY >= optionRenderYx && mouseY <= optionRenderYx + 12.0F) {
                  value.g(mode);
                  b<"ñ">(componentsInstance, -867096849223894899L, a).put(value, false);
                  return true;
               }

               float var39 = optionRenderYx + 12.0F;
               var28++;
            }
         }
      }

      return false;
   }

   public void O(ModeValue value, 友树友树何树友友友树 componentsInstance) {
      long a = 友树树友友树友何树友.a ^ 23066471149112L;
      long ax = a ^ 131176894269972L;
      b<"P">(-7843652631847706906L, a);
      b<"ñ">(componentsInstance, -7844024878716266402L, a).putIfAbsent(value, false);
      b<"ñ">(componentsInstance, -7844256794020818639L, a).putIfAbsent(value, 0.0F);
      ClientUtils.o(new Object[]{ax});
      HashMap<String, Float> optionMap = b<"ñ">(componentsInstance, -7844487607527795606L, a).computeIfAbsent(value.v(), k -> new HashMap<>());
      String[] var10 = value.s();
      int var11 = var10.length;
      int var12 = 0;
      if (0 < var11) {
         String mode = var10[0];
         optionMap.putIfAbsent(mode, 0.0F);
         var12++;
      }
   }

   private static String LIU_YA_FENG() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
