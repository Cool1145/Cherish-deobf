package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class 树何树友树何何友何何 extends Screen implements IWrapper, 何树友 {
   private long 树友何树友树友友友何;
   private long 友友友何何何友何友树;
   private float 友何树友友友树树树何;
   private float 何友何何友何树何树何;
   private final List<树树友树友友何友友树> 何友何何何友友何友树;
   private boolean 何何何树树友树何友树;
   private float 友树友友树何友树友树;
   private float 友友友友树友友友何友;
   private static Module[] 何友何何树何树友树何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[33];
   private static final String[] g = new String[33];
   private static String LIU_YA_FENG;

   public 树何树友树何何友何何() {
      long a = 树何树友树何何友何何.a ^ 98674290204961L;
      super(Component.literal(a<"s">(9133, 3431735417717379824L ^ a)));
      b<"i">(this, System.currentTimeMillis(), -4140811269529762451L, a);
      b<"i">(this, 0L, -4139971790898438727L, a);
      b<"û">(-4140026970967702733L, a);
      b<"i">(this, false, -4140130977958557491L, a);
      b<"i">(this, 0.0F, -4140366601547339186L, a);
      b<"i">(this, 0.0F, -4140580800336971481L, a);
      this.何友何何何友友何友树 = Cherish.instance
         .getModuleManager()
         .k()
         .stream()
         .filter(module -> module instanceof 树树友树友友何友友树)
         .map(module -> (树树友树友友何友友树)module)
         .collect(Collectors.toList());
      if (b<"û">(-4140221654205648298L, a)) {
         b<"û">(new Module[2], -4139453420225794368L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-5100294497714173095L, -1355115319153694674L, MethodHandles.lookup().lookupClass()).a(59538894869809L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 118947226944947L;
      a();
      b<"û">(null, 7070511343775500882L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[4];
      int var5 = 0;
      String var4 = "Æ\u0097k\u001dË¾)Éèy\"\u0098\u0099\u0007\u008e\u0006l\u0082ËÊ6¿$\u001b(#\u009aa\u00851¤\u008c[ª\u0012ü:\u001cÍ¹cîþ_{\u0000\u008a\u008c\u0010\b\t>©» \u0086Ô\u008d=7\u008fj¨\u0005¿";
      byte var6 = 65;
      char var3 = 24;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = b(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     b = var7;
                     c = new String[4];
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "»ÊKù(D}\u0091\u009a\u000bû£\u0017\u001dJ\u0088\u008e5\u0000²d\u0095\u0012èN\u009d«Æú\\õÆ\u0018o¤8û4Ç\u0095ê¸zª\u0018B\u0097\rÍV\u0093\u0017\u009bK,&¥";
                  var6 = 57;
                  var3 = ' ';
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   private boolean F(double mouseX, double mouseY) {
      long a = 树何树友树何何友何何.a ^ 67023329269477L;
      b<"û">(8164971341734262007L, a);
      return mouseX >= b<"ã">(this, 8164275317818246008L, a)
         && mouseX <= b<"ã">(this, 8164275317818246008L, a) + 120.0F
         && mouseY >= b<"ã">(this, 8164135592982698051L, a)
         && mouseY <= b<"ã">(this, 8164135592982698051L, a) + 30.0F;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 49;
               case 1 -> 21;
               case 2 -> 46;
               case 3 -> 52;
               case 4 -> 51;
               case 5 -> 29;
               case 6 -> 0;
               case 7 -> 56;
               case 8 -> 28;
               case 9 -> 50;
               case 10 -> 27;
               case 11 -> 57;
               case 12 -> 8;
               case 13 -> 23;
               case 14 -> 34;
               case 15 -> 42;
               case 16 -> 54;
               case 17 -> 26;
               case 18 -> 30;
               case 19 -> 24;
               case 20 -> 32;
               case 21 -> 36;
               case 22 -> 63;
               case 23 -> 18;
               case 24 -> 4;
               case 25 -> 39;
               case 26 -> 62;
               case 27 -> 12;
               case 28 -> 48;
               case 29 -> 40;
               case 30 -> 43;
               case 31 -> 16;
               case 32 -> 20;
               case 33 -> 37;
               case 34 -> 14;
               case 35 -> 2;
               case 36 -> 38;
               case 37 -> 13;
               case 38 -> 6;
               case 39 -> 17;
               case 40 -> 3;
               case 41 -> 1;
               case 42 -> 47;
               case 43 -> 53;
               case 44 -> 55;
               case 45 -> 25;
               case 46 -> 33;
               case 47 -> 31;
               case 48 -> 10;
               case 49 -> 41;
               case 50 -> 35;
               case 51 -> 19;
               case 52 -> 59;
               case 53 -> 9;
               case 54 -> 11;
               case 55 -> 58;
               case 56 -> 45;
               case 57 -> 15;
               case 58 -> 60;
               case 59 -> 61;
               case 60 -> 22;
               case 61 -> 7;
               case 62 -> 5;
               default -> 44;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 227 && var8 != 'i' && var8 != 'y' && var8 != 225) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 244) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 251) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 227) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'i') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'y') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何树友树何何友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何树友树何何友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      f[0] = "o{\u0016\u0001v?`;[\n|\"efPLl9\"栄佭桳叒桁余佀右伷佌";
      f[1] = int.class;
      g[1] = "java/lang/Integer";
      f[2] = float.class;
      g[2] = "java/lang/Float";
      f[3] = boolean.class;
      g[3] = "java/lang/Boolean";
      f[4] = "E\\\u001d;|{q\u007f\u0012{1p{b\u0017&:6s\u007f\u001a >}0]\u00111't{+";
      f[5] = "\u0002MT\u001dtV\u001cENR\u0016J\u001bX";
      f[6] = "F\rno\u0018%M\u0002\u007f d<B\u0018qcS\fT\u000f}~B C\u0002";
      f[7] = "\u0010\u001cn@[~$?a\u0000\u0016u.\"d]\u001d3&?i[\u0019xe\u001dbJ\u0000q.k";
      f[8] = void.class;
      g[8] = "java/lang/Void";
      f[9] = "j+\u0003Ts\u0019ekN_y\u0004`6E\u0019q\u0019m0AR2;f!X[y";
      f[10] = long.class;
      g[10] = "java/lang/Long";
      f[11] = "\u0013|}k\u000b\u0010\u000ei%IJ\u001d\u0016o";
      f[12] = "\u000b\u0012p\tu\u0003\u000b\u0012gUy\f\u0011YgKq\u000f\u000b\u0003*jq\u0004\u0000\u0014vF~\u001e";
      f[13] = "@\u001c\u000e\u0007Z\u0001@\u001c\u0019[V\u000eZW\u0019E^\r@\rTdX\u001d]\u001c2HY\fB\u001c\b";
      f[14] = "~9\r.\u001b(u6\u001caz&~=\u0018;";
      f[15] = "E\u001c[\u0011]Q\u0000\u0015Brk*A\u0004KO\u0016L\u0019\u000f\u001bO,\u0017\u001b\u0013R\u001d^\u0015BP\u001ar";
      f[16] = "\u0016\r\u001f\nVeS\u0004\u0006i古标召县桿伴古标召桥fPJ#\u001e\u0015\t\u0018\u0018&^";
      f[17] = "\u000fm\u0002,N_Op\n(<Kh8K.\u0002\u001ah\tCzWTYq\u001eoG^";
      f[18] = "\"H\u007f{PKf\u0010=a:j\u001c\u0016~mYPbA3aF)";
      f[19] = "\u001fBLOztZKU,eX\u0017\r\b\u00100X&L\t\\sw\u001bA^\u001c";
      f[20] = "2FPS~]wOI0佒佻佖栮栰右栖佻又栮)\n2WhNW]\u007f[w";
      f[21] = "$\\sv;B`\u00041lQi\u001a\u0002r`2YdU?l- '_1a>R%\u0006r)Q";
      f[22] = "\u0017(Y\u001aPYR!@y叢叡叭伄佽伤叢使叭桀 F\u0011\u001f\u0010h\u0019H\u0019\u0012\u0010";
      f[23] = "q^Zm'c4WC\u000e'\u0018uFJ3l~-M\u001a3V";
      f[24] = "\nU\u0012\u0006]fO\\\u000beBJ\u0002\u001aVY\u0010J3[W\u0015Te\u000eV\u0000U";
      f[25] = "\u001c\u007f2{\\GX'pa6H\"!3mU\\\\v~aJ%";
      f[26] = "%hB-!G`a[N桉叿佁栀司桗厓叿叟佄;q`\u0001\"(\u0002\u007fh\f\"";
      f[27] = "Ti\u0006|4w\u0011`\u001f\u001f优叏估佅厼佂桜佑桴佅\u007f&(1\\q\u0010nz4\u001c";
      f[28] = "c7<n/1&>%\r伃厉伇伛优収厝众厙桟E6!1f}\"53#\"";
      f[29] = "Pg\u000eX@t\u0015n\u0017;史佒桰叕厴司栨栖桰佋w\u0002\\2X\u007f\u0018J\u000e7\u0018";
      f[30] = "\u001ct5BfEY},!~>\u00194,Q)B\u00184w[\u0017\u0002\u0014e<\u001fk\u0003\u0014>6!";
      f[31] = "Cc;\u0013\u0003W\u0006j\"p厱可厹发桛厳厱可伧发BI\u001f\u0011K{-\u0001M\u0014\u000b";
      f[32] = "Qi|e8>\u0005i+}Q\u0018.OKYQx\tef}(,\t2~";
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 14288;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树何树友树何何友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static Module[] y() {
      return 何友何何树何树友树何;
   }

   private void R() {
      long a = 树何树友树何何友何何.a ^ 31442429749699L;
      long ax = a ^ 50087249831844L;
      b<"û">(-3573062865358156847L, a);
      long now = System.currentTimeMillis();
      float delta = Math.min((float)(now - b<"ã">(this, -3572859527728362097L, a)) / 1000.0F, 0.05F);
      b<"i">(this, now, -3572859527728362097L, a);
      if (!b<"ã">(this, -3573313932138414033L, a)
         && this.F(
            b<"ã">(mc, -3573470141483229127L, a).xpos() * b<"ã">(this, -3573361787096329938L, a) / mc.getWindow().getScreenWidth(),
            b<"ã">(mc, -3573470141483229127L, a).ypos() * b<"ã">(this, -3572977691655285824L, a) / mc.getWindow().getScreenHeight()
         )) {
      }

      float var10001 = b<"ã">(this, -3572490757216161339L, a);
      Object[] var10005 = new Object[]{null, null, delta * 8.0F};
      var10005[1] = 1.0F;
      var10005[0] = var10001;
      b<"i">(this, RenderUtils.g(var10005), -3572490757216161339L, a);
      if (b<"ã">(this, -3573313932138414033L, a)) {
         b<"i">(this, Math.min(1.0F, (float)(now - b<"ã">(this, -3573156940890286757L, a)) / 1000.0F), -3573549518035213652L, a);
         if (!(b<"ã">(this, -3573549518035213652L, a) >= 1.0F)) {
            return;
         }

         Iterator var10 = b<"ã">(this, -3572710911681185998L, a).iterator();
         if (var10.hasNext()) {
            树树友树友友何友友树 dragModule = (树树友树友友何友友树)var10.next();
            if (dragModule.isEnabled()) {
               dragModule.O();
            }
         }

         ClientUtils.e(new Object[]{a<"s">(30380, 3681305309536685841L ^ a), ax});
         b<"i">(this, false, -3573313932138414033L, a);
      }

      b<"i">(this, Math.max(0.0F, b<"ã">(this, -3573549518035213652L, a) - delta * 3.0F), -3573549518035213652L, a);
   }

   public boolean isPauseScreen() {
      return false;
   }

   public static void O(Module[] var0) {
      何友何何树何树友树何 = var0;
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
      long a = 树何树友树何何友何何.a ^ 68345289185901L;
      long ax = a ^ 129993701264984L;
      b<"û">(-159933925814945665L, a);
      PoseStack poseStack = graphics.pose();
      this.R();
      Color textColor = 树树何友友友友何树友.U(new Color(200, 200, 200), b<"y">(-159297732376869079L, a), b<"ã">(this, -160488953391644053L, a));
      float var10001 = b<"ã">(this, -160625485781446672L, a);
      float var10002 = b<"ã">(this, -160769709597272885L, a);
      float var10003 = b<"ã">(this, -160625485781446672L, a) + 120.0F;
      float var10004 = b<"ã">(this, -160769709597272885L, a) + 30.0F;
      Object[] var10008 = new Object[]{null, null, null, null, null, null, new Color(0, 0, 0, 80).getRGB()};
      var10008[5] = ax;
      var10008[4] = var10004;
      var10008[3] = var10003;
      var10008[2] = var10002;
      var10008[1] = var10001;
      var10008[0] = poseStack;
      RenderUtils.E(var10008);
      if (b<"ã">(this, -160421951808335614L, a) > 0.0F) {
         var10001 = b<"ã">(this, -160625485781446672L, a);
         var10002 = b<"ã">(this, -160769709597272885L, a);
         var10003 = b<"ã">(this, -160625485781446672L, a) + 120.0F * b<"ã">(this, -160421951808335614L, a);
         var10004 = b<"ã">(this, -160769709597272885L, a) + 30.0F;
         var10008 = new Object[]{null, null, null, null, null, null, new Color(255, 255, 255, (int)(100.0F * b<"ã">(this, -160421951808335614L, a))).getRGB()};
         var10008[5] = ax;
         var10008[4] = var10004;
         var10008[3] = var10003;
         var10008[2] = var10002;
         var10008[1] = var10001;
         var10008[0] = poseStack;
         RenderUtils.E(var10008);
      }

      String buttonText = b<"ã">(this, -160111600200862847L, a)
         ? String.format(
            a<"s">(14483, 287561526480827011L ^ a), (1000.0F - (float)(System.currentTimeMillis() - b<"ã">(this, -159954745304848651L, a))) / 1000.0F
         )
         : a<"s">(30270, 5492782927912844332L ^ a);
      float textWidth = Cherish.instance.h().n(16).A(buttonText);
      float textX = b<"ã">(this, -160625485781446672L, a) + (120.0F - textWidth) / 2.0F;
      float textY = b<"ã">(this, -160769709597272885L, a) + Cherish.instance.h().n(16).Q(30.0F) + 1.0F;
      Cherish.instance.h().n(16).c(poseStack, buttonText, textX, textY, textColor.getRGB());
      super.render(graphics, mouseX, mouseY, partialTicks);
      b<"û">(!b<"û">(-160875243534286034L, a), -160020683090919158L, a);
   }

   private static String HE_WEI_LIN() {
      return "解放村多种2队1144号";
   }

   protected void init() {
      long a = 树何树友树何何友何何.a ^ 88692476742019L;
      super.init();
      b<"i">(this, (b<"ã">(this, -1285616814685802130L, a) - 120) / 2.0F, -1284870070637274082L, a);
      b<"i">(this, 60.0F, -1285009892042422491L, a);
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      long a = 树何树友树何何友何何.a ^ 13462127980578L;
      b<"û">(-2915800488053042640L, a);
      if (button == 0 && this.F(mouseX, mouseY)) {
         b<"i">(this, true, -2916052929138943538L, a);
         b<"i">(this, System.currentTimeMillis(), -2915931125484139334L, a);
         b<"i">(this, 0.0F, -2915760787119260851L, a);
         return true;
      } else {
         Iterator var9 = b<"ã">(this, -2915448554575843629L, a).iterator();
         if (var9.hasNext()) {
            树树友树友友何友友树 dragModule = (树树友树友友何友友树)var9.next();
            if (dragModule.isEnabled() && dragModule.G(mouseX, mouseY, button)) {
               return true;
            }
         }

         return super.mouseClicked(mouseX, mouseY, button);
      }
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      long a = 树何树友树何何友何何.a ^ 24329932957577L;
      b<"û">(10103383321593243L, a);
      b<"i">(this, false, 9855271420972645L, a);
      Iterator var9 = b<"ã">(this, 9329231000336760L, a).iterator();
      if (var9.hasNext()) {
         树树友树友友何友友树 dragModule = (树树友树友友何友友树)var9.next();
         dragModule.U(button);
      }

      return super.mouseReleased(mouseX, mouseY, button);
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      long a = 树何树友树何何友何何.a ^ 77468682929609L;
      b<"û">(2478022874732488667L, a);
      if (b<"ã">(this, 2477915500460862501L, a) && !this.F(mouseX, mouseY)) {
         b<"i">(this, false, 2477915500460862501L, a);
      }

      Iterator var13 = b<"ã">(this, 2477389599620225848L, a).iterator();
      if (var13.hasNext()) {
         树树友树友友何友友树 dragModule = (树树友树友友何友友树)var13.next();
         dragModule.O(mouseX, mouseY, button);
      }

      return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
   }
}
