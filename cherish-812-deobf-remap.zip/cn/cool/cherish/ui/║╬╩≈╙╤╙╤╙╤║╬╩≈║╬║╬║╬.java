package cn.cool.cherish.ui;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.animations.何何树何树何树树何何;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;

public class 何树友友友何树何何何 implements IWrapper, 何树友 {
   private static final 何何树何树何树树何何 树何树树友友何何友何;
   private static final 何友友何树何树何树友 树树友树何树何友树树;
   private static final List<何树友友友何树何何何.何友友何何树友何树树> 友友友友树友何树树树;
   private static boolean 树友友何友何何何何友;
   private static boolean 何树何何树树树何树树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long f;
   private static final Object[] g = new Object[27];
   private static final String[] h = new String[27];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8755803832317531570L, -4171510103506916366L, MethodHandles.lookup().lookupClass()).a(168563695530052L);
      // $VF: monitorexit
      a = var10000;
      a();
      F(false);
      Cipher var5;
      Cipher var14 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(88616109343426L << var6 * 8 >>> 56);
      }

      var14.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[2];
      int var10 = 0;
      char var8 = ' ';
      int var7 = -1;

      while (true) {
         String var18 = b(
               var5.doFinal(
                  ")ª3ðM&+÷ùs+°¾%\u0097Uª\u001fÞî\u001cÊ\u0017Êú4\u008c/91B-\u0018\u0083#O\u0005CWEôèÞ,\u0099¾¼×B\u001dÀä3S\u00ad`D"
                     .substring(++var7, var7 + var8)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var12[var10++] = var18;
         if ((var7 += var8) >= 57) {
            b = var12;
            c = new String[2];
            Cipher var0;
            Cipher var15 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(88616109343426L << var1 * 8 >>> 56);
            }

            var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            byte[] var4 = var0.doFinal(new byte[]{109, -22, -28, -32, -99, -65, 83, 42});
            long var21 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            f = var21;
            树何树树友友何何友何 = new 何何树何树何树树何何((short)0, 760481532, 62373);
            树树友树何树何友树树 = new 何友友何树何树何树友(51913986529303L);
            友友友友树友何树树树 = new ArrayList<>();
            return;
         }

         var8 = ")ª3ðM&+÷ùs+°¾%\u0097Uª\u001fÞî\u001cÊ\u0017Êú4\u008c/91B-\u0018\u0083#O\u0005CWEôèÞ,\u0099¾¼×B\u001dÀä3S\u00ad`D".charAt(var7);
      }
   }

   public static void F(boolean var0) {
      何树何何树树树何树树 = var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (h[var4] != null) {
         return var4;
      } else {
         Object var5 = g[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 27;
               case 1 -> 63;
               case 2 -> 18;
               case 3 -> 59;
               case 4 -> 42;
               case 5 -> 10;
               case 6 -> 48;
               case 7 -> 0;
               case 8 -> 24;
               case 9 -> 15;
               case 10 -> 14;
               case 11 -> 53;
               case 12 -> 33;
               case 13 -> 41;
               case 14 -> 58;
               case 15 -> 11;
               case 16 -> 23;
               case 17 -> 50;
               case 18 -> 25;
               case 19 -> 54;
               case 20 -> 39;
               case 21 -> 29;
               case 22 -> 60;
               case 23 -> 51;
               case 24 -> 46;
               case 25 -> 6;
               case 26 -> 34;
               case 27 -> 1;
               case 28 -> 62;
               case 29 -> 57;
               case 30 -> 52;
               case 31 -> 2;
               case 32 -> 40;
               case 33 -> 30;
               case 34 -> 4;
               case 35 -> 3;
               case 36 -> 43;
               case 37 -> 37;
               case 38 -> 17;
               case 39 -> 16;
               case 40 -> 22;
               case 41 -> 9;
               case 42 -> 56;
               case 43 -> 13;
               case 44 -> 44;
               case 45 -> 8;
               case 46 -> 12;
               case 47 -> 28;
               case 48 -> 19;
               case 49 -> 7;
               case 50 -> 26;
               case 51 -> 55;
               case 52 -> 31;
               case 53 -> 32;
               case 54 -> 5;
               case 55 -> 47;
               case 56 -> 36;
               case 57 -> 61;
               case 58 -> 35;
               case 59 -> 49;
               case 60 -> 20;
               case 61 -> 21;
               case 62 -> 38;
               default -> 45;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            h[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 't' && var8 != 217 && var8 != 206 && var8 != 'e') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 195) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'D') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 't') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 217) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 206) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树友友友何树何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         g[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = g[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树友友友何树何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void a() {
      g[0] = "\u0000\u001bf\rQ|\u000f[+\u0006[a\n\u0006 @KzM传桙厥叵变伶桤伝伻佫";
      g[1] = "`dq#\u0006\u001ao$<(\f\u0007jy7n\u001c\u0001jf,n\b\u001bjg>4\u0000\u001amyq伕似桤佖栛伊桑桸传佖";
      g[2] = "v{\u0003\\cP}t\u0012\u0013\u001fIrn\u001cP(ydy\u0010M9Ust";
      g[3] = "\n\u001f\u000b|u:\u0017\nS^47\u000f\f";
      g[4] = boolean.class;
      h[4] = "java/lang/Boolean";
      g[5] = "I6,*&[Fva!,FC+jg<]\u0004伍栓厂厂叿使桉佗伜伜\u0010使厓叉伜伜栥叡伍栓桘";
      g[6] = float.class;
      h[6] = "java/lang/Float";
      g[7] = void.class;
      h[7] = "java/lang/Void";
      g[8] = "\u0013!x\u0002X\u007f\u0013!o^Tp\tj{CGz\u0019jiBA\u007f\t=\"`\\`\u0014*ki[b\u00140u";
      g[9] = int.class;
      h[9] = "java/lang/Integer";
      g[10] = "7\u0014*\u000e\u0001{)\u001c0Acg.\u0001";
      g[11] = ")/\u0015HfG&oXClZ#2S\u0005|\\#-H\u0005作口厁伔株佾栘佽桛厊";
      g[12] = "VbD[o&]mU\u0014\u000e(VfQN";
      g[13] = "~uI4\u0017>,1F9r \u0017v\u001bjKp\u0017L\u001d'\u0016t8'\u001d7Iq";
      g[14] = "F\\G\u0012_8\u0010@[Ua厐传佢核桵厢桊传佢叢l]4\u000fG\u001a]\u001b9\u001bC";
      g[15] = "KKY\b\u00012\u000bRMx桽伄桫栰右去伹伄厱佴0\u0002Y;\u001f\u0015\b\u0006\u0014;";
      g[16] = ".\u0014\u0006\u0017MIx\b\u001aPs使佈厴伽桰桪栻取厴桹iOEg\u000f[X\tHs\u000b";
      g[17] = "\r?vCv3M&b3叐厛号厞栆台低桁栭桄\u001f\fv1Sm'\u000ez!E";
      g[18] = "wE\u00072H\f7\\\u0013B栴桾厍栾伳桛佰厤桗栾nr\u0013W)\u001e^sG\u00051";
      g[19] = "nz9@@-.c-0LFne1YO#9djK%\u007f*y9Z@(+\"+0";
      g[20] = "mXc6k\u0001;D\u007fqU伷伋佦叆伕伈伷桏栢叆Hi\r$C>y/\u00000G";
      g[21] = "Fv?8r\u0000\u0006o+H栎厨厼佉厕伕佊伶伢受Vs-S\u0005(l2l\u0013\u0014";
      g[22] = "\u0010\"$W\u0007lF>8\u00109佚佶桘厁佴栠叄栲桘伟)\u0005`Y9y\u0018CmM=";
      g[23] = "MS\u000b]Uk\rJ\u001f-N\u0000O\u000bZW\f:\u000eJ\u001aF0";
      g[24] = "F$EY2\u0011\u0018pTC\t\"<\tte\tG\u0010%Y\u0013e\u0019D4C";
      g[25] = ";\u001c{TNY{\u0005o$v29D*^\u0017\bx\u0005jO+";
      g[26] = "=Eg\u000f}\u007f}\\s\u007fV\u0014?\u001d6\u0005$.~\\v\u0014\u0018)?Ym\u000f'*oDl\u007f";
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24783;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/何树友友友何树何何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[²ú\u0004+\u008f×½´UÞ\t¯w#")[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   public static void o(PoseStack poseStack, LivingEntity target, float x, float y) {
      U();
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (var5 instanceof String) {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         g[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static boolean v() {
      return 何树何何树树树何树树;
   }

   public static boolean U() {
      v();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static void Y(PoseStack poseStack, LivingEntity target, float x, float y) {
      v();
      if (树树友树何树何友树树.u(16L, true, 77209916186210L)) {
         友友友友树友何树树树.removeIf(p -> {
            U();
            p.p();
            return p.何何友何树树树友友树 <= 0.0F;
         });
      }

      Iterator particleColor = 友友友友树友何树树树.iterator();
      if (particleColor.hasNext()) {
         何树友友友何树何何何.何友友何何树友何树树 p = (何树友友友何树何何何.何友友何何树友何树树)particleColor.next();
         ShaderUtils.B(poseStack, x + p.友何何树树友树何何友, 38709770127847L, y + p.何何何友何何何树树友, p.何何树友何树友树树何, p.x());
      }

      if (target.hurtTime == 10 && !树友友何友何何何何友) {
         if (mc.player == null) {
            return;
         }

         Color particleColorx = Color.WHITE;
         RandomSource r = mc.player.getRandom();
         int i = 0;
         友友友友树友何树树树.add(
            new 何树友友友何树何何何.何友友何何树友何树树(26.0F, 26.0F, (r.nextFloat() - 0.5F) * 2.8F, (r.nextFloat() - 0.5F) * 2.8F, r.nextFloat() * 3.0F + 1.0F, particleColorx)
         );
         i++;
         树友友何友何何何何友 = true;
      }

      if (target.hurtTime <= 0) {
         树友友何友何何何何友 = false;
      }
   }

   private static String HE_WEI_LIN() {
      return "何大伟为什么要诈骗何炜霖";
   }

   private static class 何友友何何树友何树树 implements 何树友 {
      float 友何何树树友树何何友 = 26.0F;
      float 何何何友何何何树树友 = 26.0F;
      float 友友树何树友友树树何;
      float 树树友树友何友树树何;
      float 何何树友何树友树树何;
      float 何何友何树树树友友树;
      final Color 树何何何何友树何何友;
      private static final long a;
      private static final Object[] b = new Object[16];
      private static final String[] c = new String[16];
      private static int _何炜霖黑水 _;

      public 何友友何何树友何树树(float x, float y, float dX, float dY, float size, Color color) {
         this.友友树何树友友树树何 = dX;
         this.树树友树友何友树树何 = dY;
         this.何何树友何树友树树何 = size;
         this.树何何何何友树何何友 = color;
         this.何何友何树树树友友树 = 255.0F;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(4634063752974682472L, 1132048279282551539L, MethodHandles.lookup().lookupClass()).a(169763356279085L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      public Color x() {
         return new Color(this.树何何何何友树何何友.getRed(), this.树何何何何友树何何友.getGreen(), this.树何何何何友树何何友.getBlue(), (int)this.何何友何树树树友友树);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/何树友友友何树何何何$何友友何何树友何树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'I' && var8 != 'X' && var8 != 'U' && var8 != 'P') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'A') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'H') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'I') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'X') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'U') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 27;
                  case 1 -> 8;
                  case 2 -> 43;
                  case 3 -> 62;
                  case 4 -> 51;
                  case 5 -> 14;
                  case 6 -> 45;
                  case 7 -> 26;
                  case 8 -> 17;
                  case 9 -> 50;
                  case 10 -> 6;
                  case 11 -> 21;
                  case 12 -> 4;
                  case 13 -> 34;
                  case 14 -> 12;
                  case 15 -> 32;
                  case 16 -> 59;
                  case 17 -> 23;
                  case 18 -> 52;
                  case 19 -> 46;
                  case 20 -> 28;
                  case 21 -> 9;
                  case 22 -> 55;
                  case 23 -> 63;
                  case 24 -> 20;
                  case 25 -> 33;
                  case 26 -> 39;
                  case 27 -> 24;
                  case 28 -> 16;
                  case 29 -> 25;
                  case 30 -> 61;
                  case 31 -> 48;
                  case 32 -> 44;
                  case 33 -> 0;
                  case 34 -> 30;
                  case 35 -> 37;
                  case 36 -> 2;
                  case 37 -> 31;
                  case 38 -> 1;
                  case 39 -> 13;
                  case 40 -> 54;
                  case 41 -> 11;
                  case 42 -> 7;
                  case 43 -> 36;
                  case 44 -> 41;
                  case 45 -> 40;
                  case 46 -> 53;
                  case 47 -> 47;
                  case 48 -> 42;
                  case 49 -> 22;
                  case 50 -> 60;
                  case 51 -> 18;
                  case 52 -> 58;
                  case 53 -> 38;
                  case 54 -> 57;
                  case 55 -> 49;
                  case 56 -> 56;
                  case 57 -> 10;
                  case 58 -> 15;
                  case 59 -> 29;
                  case 60 -> 19;
                  case 61 -> 3;
                  case 62 -> 5;
                  default -> 35;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "b?\u0013\u0017='m\u007f^\u001c7:h\"UZ'!/伄栬县厙厃佔桀佨伡伇l佔厚叶伡伇桙及伄栬桥";
         b[1] = float.class;
         c[1] = "java/lang/Float";
         b[2] = ";-s-|\u0012&8+\u000f=\u001f>>";
         b[3] = "\u000er\u000e#nD\u0005}\u001fl\u0012]\ng\u0011/%m\u001cp\u001d24A\u000b}";
         b[4] = "|j\u0013p\u001bXs*^{\u0011EvwU=\u0001^1佑栬变县叼佊栕佨但伡";
         b[5] = boolean.class;
         c[5] = "java/lang/Boolean";
         b[6] = "$)bnz&/&s!\u001b($-w{";
         b[7] = "D\u001e>xo\fRIa\u0019伃佬佳召余佄伃栨样召\u0004kbK\u0011V>' K";
         b[8] = "6{N|=\u0012 ,\u0011\u001d叏召桅众桭叞叏栶桅众to0Uc3N#rU";
         b[9] = ";1>\u0001\u0001)-fa`右佉伌栙栝厣栩佉伌參\u0004\u0012\fnny>^Nn";
         b[10] = "WJ)F\u000e>A\u001dv'佢佞叾伦栊栾栦叀叾桢\u0013U\u0003y\u0002\u0002)\u0019Ay";
         b[11] = "w5Z`f^ab\u0005\u0001伊伾栄叇伽栘厔桺栄余`sk\u0019\"}Z?)\u0019";
         b[12] = "zxLP@tl/\u00131桨伔位伔伫史桨伔位厊v\b\u0017s)w\u0004\r\u0003.*";
         b[13] = "\u000f7\u001e\u001a,\u0001\u0019`A{t<_o^@mMX7\u001f\u001a\u001d\u0006\f|\u001f\u000bl\u0001T=E{";
         b[14] = "\u000f;Y\u001d\u000eo\u0019l\u0006|栦桋厦栓厠伡叼桋桼佗c\u000e\u0003(ZsYBA(";
         b[15] = ",A\u0000P.)rU\u001eZG\t\u0017\u0014\u0000P)$&S\rA,T";
      }

      public void p() {
         this.友何何树树友树何何友 = this.友何何树树友树何何友 + this.友友树何树友友树树何;
         this.何何何友何何何树树友 = this.何何何友何何何树树友 + this.树树友树友何友树树何;
         何树友友友何树何何何.U();
         this.友友树何树友友树树何 *= 0.97F;
         this.树树友树友何友树树何 *= 0.97F;
         this.何何友何树树树友友树 -= 4.0F;
         if (this.何何友何树树树友友树 < 0.0F) {
            this.何何友何树树树友友树 = 0.0F;
         }
      }

      private static String HE_JIAN_GUO() {
         return "行走的50万——何炜霖";
      }
   }
}
