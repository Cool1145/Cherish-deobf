package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.config.友何何友树友树何树树;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

public class 何友友友树友何友树何 extends Screen implements IWrapper, 何树友 {
   public static final 何友友友树友何友树何 何何友友树友树友友树;
   private final float 树友树何树树何树树何 = 550.0F;
   private final float 友何何友树友树树树友 = 350.0F;
   public float 何何友树树友树何何何 = 40.0F;
   public float 友树何何树友树友何友 = 40.0F;
   private 何友友友树友何友树何.树友何树何树树友何树 树何友友树树友树树何 = 何友友友树友何友树何.树友何树何树树友何树.树树树树友友何友友何;
   private static final float 树树友友友树友树何何 = 0.1F;
   private static final float 树树树何树树友何何友 = 0.3F;
   private float 树友友树友友友树何树 = 0.0F;
   private long 树何友树树何何何友友;
   private float 树友友友何树何友何友 = 0.0F;
   private boolean 树何友友树何何树友友 = false;
   private boolean 何树何友何友何友友树 = false;
   private long 友树树树何友树友树树;
   private static final float 友友友树何何树友树何 = 0.2F;
   private boolean 树何树友何树树树友树 = false;
   private float 何何友何友何何何树树;
   private float 树友树友何友何友树何;
   private final HashMap<树何友友何树友友何何, List<友友友何友友何何树树>> 何何树树何何树树友树;
   private final 友树友树树何何友树友 树树何何何树友友何树;
   public boolean 树何何树树友友树何何;
   private 树何友友何树友友何何 友友何何树树友树友树;
   private 树何友友何树友友何何 何树树友友树友友友友 = null;
   private float 何友树何何何树树何何 = 1.0F;
   private static final float 友何友何何友树树树树 = 0.5F;
   private boolean 友树树树何友友树何何 = false;
   private long 树树何何何友树树何友;
   private boolean 何何何何友何树友友树 = false;
   private boolean 友树友何何何树友友树 = false;
   private final float 树树树树树友何友何友 = 80.0F;
   private final float 树友树友树友树树树友 = 20.0F;
   private float 友树友友何友树树树树;
   private float 何何何友树树友何何何;
   private float 友树何树树树友何树何;
   private boolean 何树树何何友友树何友 = false;
   private float 友友何友树何友友树友 = 0.0F;
   private float 友何何友何何友树树何 = 0.0F;
   private boolean 树何友何友友树友树何 = false;
   private long 树友何何何何友何何友;
   private static final float 树何友何何树何友友树 = 0.4F;
   private final List<何友友友树友何友树何.树友何友友何友何树友> 何友友何树树树何友友 = new ArrayList<>();
   private boolean 何友树友树友何树友何 = false;
   private float 树友友友树友友友何树;
   private float 友何何友树友树树友友;
   private 何友友友树友何友树何.树友何友友何友何树友 友树树何友树树友何树 = null;
   private List<Module> 友树树树树友树友友树;
   private float 树树友友友何友友何友 = 0.0F;
   private String 友何友树树友何树友树 = "";
   private boolean 何何树友友树何树树树 = false;
   private final float 友树友树友何何何友友 = 20.0F;
   private final float 树友树友友友树树树何 = 150.0F;
   private final float 友树友树何树何何何树 = 150.0F;
   private float 树何友友何友何友何友;
   private float 友何树何友何友友树树;
   private float 何何树树何树树何树何;
   private final float 何何何友友何树友树树 = 80.0F;
   private final float 友树友何树何何友友何 = 30.0F;
   private boolean 树友何友树树友友友树 = false;
   private float 友何何友何友何何树何 = 0.0F;
   private float 何友何树何何树友何树;
   private float 何树树树友友何友树何;
   private float 树树何友树友何树友友;
   private float 友何何何树树友树何友;
   private float 何树何树友树树何树何;
   private static final float 何树何树树树友树何树 = 10.0F;
   private final float 友何友何友树树友树树 = 80.0F;
   private final float 何友友树友友树何何树 = 20.0F;
   private float 树树友何友树树树友何;
   private float 何友友树树树友树树友;
   private float 何树友何友树友何友友;
   private boolean 何树友友友树树友友树 = false;
   private float 树树何友树何树友友树 = 0.0F;
   private final float 友何何树友何友何树何 = 80.0F;
   private final float 树何何树树树友友友友 = 20.0F;
   private float 友树何何树树树友友何;
   private float 树友何树友树树何何友;
   private float 何树何何树何友友树何;
   private boolean 友何何树何友友树树树 = false;
   private float 树友树树何友友何树友 = 0.0F;
   private boolean 树友何友何友友树树树 = false;
   private float 树何树何友友友何何友;
   private float 友树何何友友何树何树;
   private final float 何友树树树树何何树友 = 180.0F;
   private final float 树树友友树友友树友何 = 200.0F;
   private String 树友友何友何何何友树 = "";
   private boolean 树何友树树何友树何树 = false;
   private List<String> 树何友友何何何树树树 = new ArrayList<>();
   private float 友树何何树何友何友何 = 0.0F;
   private float 树友树何何树树何友友 = 0.0F;
   private boolean 何树何何树友树何友友 = false;
   private boolean 友何友何友何何何友树 = false;
   private long 友何何树何友何友友树;
   private static final float 友何何友何何何友何何 = 0.2F;
   private final float 友友友友树友何树树树 = 20.0F;
   private float 树友何友树友树友树友 = 20.0F;
   private boolean 树何树友友友何何友友 = false;
   private boolean 何树树友树何何友何树 = false;
   private String 何何友友友友友何友树 = "";
   private boolean 树友何树友何树友何友 = false;
   private final float 友何树树树树树树友树 = 120.0F;
   private final float 友树树树何何友树树树 = 20.0F;
   private float 友树友友友何树树树友;
   private float 友何友友何友树何何何;
   private float 树何友树友友树树何友;
   private static int[] 友友何友树树友何何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[131];
   private static final String[] j = new String[131];
   private static int _何树友，和树做朋友 _;

   protected 何友友友树友何友树何() {
      super(Component.nullToEmpty("Compact Click GUI"));
      this.树树何何何树友友何树 = new 友树友树树何何友树友();
      this.何何树树何何树树友树 = new HashMap<>();
      this.树何友树树何何何友友 = System.currentTimeMillis();
      this.树友何何何何友何何友 = System.currentTimeMillis();
      this.树树何何何友树树何友 = System.currentTimeMillis();
      this.友树树树何友树友树树 = System.currentTimeMillis();
      this.友何何树何友何友友树 = System.currentTimeMillis();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2869634951667745261L, -2530074863511285677L, MethodHandles.lookup().lookupClass()).a(223522988348146L);
      // $VF: monitorexit
      a = var10000;
      a();
      l(null);
      Cipher var11;
      Cipher var22 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(49879801827375L << var12 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[156];
      int var16 = 0;
      String var15 = "õJ\u0092J¼\u0091¿\u001d/QV5M\u000e¥·\u0010YäÖ7ih\\?ÀQMÕ\f2l\u0080\u0010M\u0093A\u009b~ëZÓ\u0000íåô¬\u00151ð(2!C\u000f\u009a-ËOz\u0006N½QS\u0082«2\bfÍ\u0012\u000f\u0093;à\u0093¤\u0013\u001aÖÿ\u0081\t>F.\u0016\u009b\u000f¤\u0010.\u001e¯Õ\u0097òý¼\u0085\b'ëñ\u0002\u0019,\u0010%\u0010\u0082\u008fMSË*\u008e[º\u0012\u0080ª¸B ûò\u0091\u0001ÿæ\u0007Ò\u0091!\u0093\u007f®e\u0003¬\u001dæù!±\u0092\u0001òÞ¹ÕLôèÝ~\u0018M4qèÙ\u0095\n\u0015ïÛivïJ\u0097W\u009fw¶F\u001e{\u0096|\u0010Y\u0016ÓÓä©Ùaøx%\u008a\u009aÈ\u001eÌ\u0010©ën\u0005hn\bÁ\fð\u0002L\u008eO\u001d¥8ö\u0003nÏÛ\f\u009d½Ú^Ý\bÖ\u0016R\n\u0087×TxX\u0098ÃÍúûP´¨écÊC\u0004à\u0010\u001bóiW:\u001bç\u0093Äô¯ÏS®=Ñ\u0096!a\u008b\u0010;X³\u0002å\u009e412Jz`\u0006úÍ\u008e\u0010\u001fÞÁÕG©\u0000\u001d&\u0097,çÆ,Õà Çþ±<I«R\u009e'±HxZ¿_»ÿ\"²4±\u009dÉÂ\t\u0011\u0081fë3\u0011ù \u0083\u0019ê\u0080\u007fðé\u0015=½¦ö Ýc¥X\u001cÌ¿MRú]d\"¹.ìgº'\u0010\u0004\u009b)¥Br\u000e}\u000bÀg\u009cªÑ\u0004ë\u0010M~\u0080;ø\u001bL6mi\bÝò\u009f\u0091l\u0018\u0080ÆQ\u0003vÃ`ªú7áUW\u008eõ®Ó¾\u0003\u0088\u009e\u0099Ñ\u0000\u0010\u0015cq\u0092- *\u001aæ´]\t\u0001µ\u008d£\u0010ü mF\u009c¦*^=µ¯\u0080N\t®¾\u0010Ö#ÊéÚ\u0090u\u0084\u0090ê\u001b,é\u0092¤\u0088\u0010J&ú\u0091\u0080|¿k\u0005E õ;Àøz\u0010\u0091þqó¹w*\u0095É£7\bÐX\u0089=\u0010âÁly°{¡æz450{}îD\u0010Ô@áxKÎ\u008a\u0094c:´)ã×Úl õ\u008aÇÆ1jç:ûëþ½Ñ\u00115°\u0099ÆÙ\u008c6J\u0091%hïÎ.*P\u0017ñ\u0018\u008c]bsè®©\u000b±Ó7ï¸¸4ÿ\u007fY\u0018D\u009aú\u0091\u0010\u0010pÖk81¦e\u0018;#l÷G\u001f\u0015Â à\u000fÛ~:°³Ì\u0001H\u0000Ó\u0012Në\u0013¸$\u001dN-=Ó\u00053a\f\u008c\u008a\u0087gQ ðié°\u001fù\no\u008aÊW1\u009b\u0017ùíË\u0085z©Ää)SÜ¡YºW`w#\u0018\u0086X?F Ê¹}4@Ê\u0083\u0018l\u009e:²\u0080G^×:\u009e\u0083\u0010sÝGÓê\u008fÃ¬q4Ç\u0095oÿ«D\u0010\u0010Z<×\u0000\f\u0096\u008d*\u0081\u000eN\u0099Å\u009b\u0006\u0010\u0004n\u009a \u008e\u0099·Í\u001d\u000f\r2Rvêw\u0010\u0012iuÂ.\u0001èÿK\u0001í\u0016\u008cZ\u009fÀ\u0010ÍLÛOÚb\u0002û÷\u000e³\u0098\u009e\"\r`\u0010&\u0088`r6¬OIË\u009e\u0096\u0013ÄDû\u0094 }\u0014Äoz²\u0094=\u0097D{Î2\u009cÌ\b\f\u0081\u0015À+\u0097jm\u0002&ºà¼¬\u009aç u·.úácVÄþh/)±Ñîb5\u001c\u0087\u0012°j\u001e\u0000\u0016\u0014ítÄÚîz\u0010\u001b\u0084Ýl\u0001ßáÐüÖ\u0007T+\u008b¦\u0088 þº\u009e*ö?\u001b.\u00adwû\u0000eQ\u0081\u000eDÈáü³qp¡¿\u0083\u0083\u0019;\u0017Úß\u0010\u0085Ì§+à)ä\u009cÎ'uâê8×«\u0010µÚ\u0001nT\u000fÔ?á~Ì0§|\u009bd\u0010\u0098«£Ï<ºë\u0085Ë\u0001Æ×ÝîÚ\r x\u0005oS\u008e@ ÒRQt\rí)\u0099{Og¡z\u0096\t§a[ÃÜ\u0010æ\u0007«U\u0010á\u0013½}\u009c\u007f\u008c\u0013nQH\u0084æQ÷<\u0010^(Ê´\u008f\u0094\u001e¯ÿ&yªv\u00ad\u0001\u0087 iöCÀªÁ\u009cûH\u0097Ø[[\tÌo\u0082\u0004ÌÐ@0éî\u0013ËLºØÓ±A\u0010/.\u008bÍ0)ãt°\u0083\u0094&E\u008a¯ï\u0010\u0015¼\u0092?åëàhLç\u008e\u008dYG\u008fk\u0010ï\u0014Æ\u008eê\u0015Ê\u0093º®\u0003*\u0089\u009bÏË\u0010À0´Wî\u009a\u0010¨\u001dÅ^¢ço÷È\u0010\"~9¯«\u0094íIIg\u0007ÀN4\u001b{(}Â\u009e\u008eL\u000eD®®öO*\u001a\u0082Ì×£\u0006\u0094]G$\u008e³ÊÔ\ft\u0017=ºDFìÕx/+\u009d)\u0010®`jÖJ\u0012å\u0085¼´\u0010\"\u0089D\u001c\"\u0018~®üPãª\u009d\u0085)áàÓ¢\u008bxj\u009f\u0094{¾/@\u009aO\u0010ì\u008eYx/!Z©Æâ}i\b.C3\u0010[Mk\u001c5®LzUc_\u0094\u0094\u0094ô\u009c\u0010ª½Âæ;CÁ\u0088Ô»\u001aûN\u007f5ê\u0010Që\u0099\u008dN\u0003:\u001cÝ²ý_\u0003³\u0015x(>\u001d\u00017L}5ë[fë\u000eZl\u0002<¾Ë\u009aY¥\u009fFäó°\u0089[«\u0082=K\u008cuo\u008c\\mP^ #\n\u0001|\\Ó\u0098Ç\u0095±\u008d\u0081/ïxþ*ÂZÑ»\u0088uM\u0004\u008bªüÓ\u0083bä øîç{@àµ³\u0088É\u0090\u0082\u000bÇ\u009d1\bÉ\u009a{T\u0090\u001d\u0001!§\u0005k\fzÃ\u000b\u0010Hä\t\u001e\u001a\u0002»¥?\u00adº/Ûxxs(@\u0082l\u001cìOÍºÃ\u0086>\u0011\u009a\u0085y=tY\u001fÇÙ;\u001br.»[E\u0019\u000f\u0017Ð\u009cê\u0093}Ê\u0093¹ó\u0010ÂúFHT/vD»8ÍÜÙke¡\u0010á8¨w}¢Õñ¼ñ\u0085¥\u0085/a%\u0018ÇÊõ\u001f¿a\u0083â=\t8ÀZz\u001f?sô\u0003?\u008fÏÙÔ\u0010\u0097c\b \u0017-g\u007f\u009fùª ×UÀÖ\u0010\u0094\u0082×Q v%\u00ad®ý\u0082Ã{GáÈ8ûF\u001cþ¹G\u0089Ù5bàã\u0012©éÒ\u009d\u0000ßë\u0086\u001e£\u001f,\t6ûOÔ\u0011'yuéêx\u00ad+È¾\u00132©±\u0002L\u0082\u0097a\u0006Ú9\u0090±® ;¯¬\f ïQ£\u0084«þÜsÓÕ=A ã'¬ë7T\u0006ÎwW«\b+!(JS´ØJcH\u0001©¯øUËú\u001c\u001enA°79î^`\u008e@\u0010ð\u008aÒMµ¥\nvZ9\u001f\u007fæ(\u007f7e_²]Ú(z\u0096\u0081\u0005\u0096àÁi¤e\u0085Épz\u0095Ò~\u0091TNì\u001f\u008eëÆÛ'½6Ïs\u0015\u0010£ô¨Ï~Ä¿\u0001S$a\u009bh\u009fB\\\u0010qJ\u001d-#0\u0095\u008ef\u001eA\u0004\u0013\u000b¡ù\u0010I^\u0016Õ\u0015\u000f$N\fèâï+¼\u009b\u0018 ÌF\u0082O@ÙÿA ut¼cíÕ\fñëö:û\u001e\u0014\u009a0Ñ;1(ªf\u009b\u0010\u001b'ìmc\u009cBFíÉÌ#ÞÑ\f£\u0010\u0002\u0003c\u009f#Ço\u0005\"\u008a\u009eçÑæÝk T\u000e\u008f\u001eãá\u0083\u0097Æå<3÷,éD\u0091\u000eZ8MÝ¦\u0094òr5á¯!\u0006¹(\u00943Úà\u0094g\u0082f\u0083µ\u00013b·\u0091ï\"ÖÖ\u001cËUÙow\u008a\u000fäYä¤\u008c<1Ò6\\\u008eý<\u0010>UÙ;A5\u001dclk\u009f\u0012+[«õ\u0010\\\u0016ÈG\\\"Ðe=\rÙyCo±:\u0010\u009f±\u007f\u0019\u008c\u0091iÑ*Q4ÚQ\u0099\u0019\u008a\u0010{Ö\u008f¨\u001dÌÂàÐ9!±ÅB\u0010< \u0080Òcúÿ\u000b\u0002;\u000f-\u0085E\u0001ª\u0083\u009f\u0005¯5~1\u008cfæê\u0081$ó~â\u008a\\\u0010·~\u0003\u0006m\u0082ùíT\u0089uFåy+B\u0010BC\u000fi\u0084îKÌ\rãO\u008fO\u0003¸-\u0010S\\¨gqÒQÜÇñ\u001bOáî\u00adÄ\u0018\tã\u0085Ç\u0090\u0094z4\u008a\u009aã¹qCÎø-ùê\u0018\u0015í\u0083\u008e\u0010«\u0014¿\\W#Ð\u0082l³ôØ7°óf\u0010êÒªP\u0091'Ö·ý´½\u0095z\u0081Ê:\u0010Ùì0\rí\"¶dDÁÓÖË\u008bq5\u0010\u0088$¬X_s\u000fcÛ\u000få\u001bQu¾\u0005 \u0086RÝ¬Ûû}Hà\u0010\u0005P\u009b¤\u008c9P\u00adè\u00145ma° ®ê£ìáW\n\u0010£\u0005|%ÌØ\u0010Äó\u0017Ìöç´Ã\u0083\u0010÷W) äÚ©\u007fäYÓõÑe\u008dn\u0010\u0094\u0087ý_\u0090ò?å¤Ùç&·Bó\u0013 »\u009eæbàJA\u0018+9ÍS[ÂubB\u0014Mcñ}Báciù\u008c¼7\u0018ä\u0010?'8\fQïEª\u0084»u%\u009bF\u0080Ô\u0010Y»RY\u0014\u0091\u00892õî\u0083\u001a\u001f\nrÀ\u0010\u0001\u0011/\u001f\u0012X»ËVÄ\u0086à[Sx\u001e\u0010(\u0082ÛÓè[\u0004pã\u000f\u0005U\u0082P&÷\u0010u\u008epÊ\u00923~a¸ÿò©Î]\u001aé0íÃ\u0001Õ²»K\u0019Öæø\u0094\u0094aõ\u000b\u0014÷PÿÎÈ:ÿ\u0005h\f' \u0000\b\u0098+X\u000b¦\u0003\u0087©=\u0096Iª\u0019Yäg\u001f\u0010\u0002Ó\u007f¶$\r\u001dÜ\u0012à@9).¢}\u0018.¶\"!³zY\u0006Ä\u008cû)\u000ehÛ½MÑ-î!$6ô\u0010\u008e+K2\u0093\u009f\u0017q^+\u0083qÒ\bºW\u0010ý\u0018³\u0089\u008bè`2\u0011laíÛ\u008fÐ¼ \u009a¡ßn\túUW?§´\u0084írØ.\u00ad\u0002Â°\u0098\u0087³§ÃD\u0000l±êã¡ ±a\u009e\bÃ0\u0097&\u0001m2ø°\u001fb,¯Ç\u0001l>$<³eö--Ëo\u0080-\u00100Å¦ó¿®>\u0011\u001b\u0091³ËáÐ¯´\u0018\u0080ªXh*Í!0\rBëê\u0014ÿÃZ\u0016\u0007ñow4û¶\u0010Ï6Í(2`ì\u0096\u0080\u0001xè\"¼Ú¦(ÝP\u0007=ëM´Üà¬\u0084¸d^µÁ³äI®\u0013Ã\u0084ÏlÕ\u001dlÅ¥#´g³\u0081Ø\u009b\u0090°[ $ú¸Â\u007f²×Ê\u0083áðîY-¢ù:»\u008f%§\u0012\u000f²\u0007\nå\rývëa\u0010L\",\u0086ÔRìü*¨t²ªaòG\u00105÷¡åpÒ<¥Kß²Ñ·¡\u00071 \u009dGÅ\u009eô5xVxGßè\u0091ëR\rêäf\u0081ýçª\u000b\rÉ³'ú\u0019\\:\u0010Xcø÷Gû¤]XC\u0014P\u001e;I\u0012\u0010&:\u0081\u0081£\u0011Ó\r\t>î?ëÊ÷ô ±Å¶Ôp¿\u001a¶Û\u0013Û¸BeW^\u00108Ö/DÚc\u000bWI,\u001dq¤\u0011©\u00186¤7\u0014\u000eÜ\u008b\u00ad\u001c#´¦Å\u0018s2\u001b\u008b#e\u0094\u0015\u0092\u0096 _\u0000?\u000eL{ïÄîEi\u000fvzø×\u001aì¯\u0099\u001c\u008bª\u001c\n·-t\u0011j¹\u0003\u0010Ø$\u0090\u0016\b¨\u0000§º\u0084\u0002\u008d\u0092è\u0003g\u0010DN\u001d¬÷\u0017Ö\u0004ªð¾6[¿\u001d\u0099\u0010\u0096/ÕL°}\u001cdo¸5ùS\n{õ\u0018Í\fâå°#fº\u001b-\u0085îæ¾\u000fj\u0006*\u0015ÝØ°±õ îz\u001b_îÐ)\rl\u000f¼Ùòõ|\u0098<íñéqh5L$èãv»RH\u001a\u0010[?ß\u007f\u0018°\u0004\u0000Ý\u0085,\u0097\u0014\u008d¶ú\u0010Bà¤\u0084Ò\u0085Àô)l1|\u009f\u0011XÆ\u0010fSÎw\u0092+\u0014\u000e\u0018´\u0089ÍÄCOn\u0010Þ÷\u0000ÁÞ®\u009d0\u001a\u0096Àð\u0094s\u0088Ú\u0018\u0084ü\u0091ogI\u0010\u008bjÉñ¦1Dó\u0005\u0013Â\u0007r\u0014j\u0085 \u00101\u008a7¯ÇZL\u0018)\u0011æ\u0088N\u0015A.\u0018\u009e\u0092\u008f\u008c\u001fÆ\u0097$Îo®\u0093ø÷z$V\u0099ªt£\u0093dï\u0010\t®\u0081È®BÒ£¤\u0002\u001cÄ!\u0019WÖ\u0010£z\u001d\u0011\u0003Ý%\u0082 $õ\u0003\u0012/æ\u009b\u0010´Ó\u0016\u008cÃ\u0088\u0003àó\t,\u0091*\u0094\u0014\n\u0018\u0018$z1\u008deFR·\u008d\u009cÉµª\u0019ÄÛ^§@>8ðu\u0018îÜ\u009béàJÙõb.ü[\u001dlð\u008bz££üw\u0086i\u0087 ]C\u0085'¨â°\u0085Îdf\u000eÎÌ/Æ\u009a1Gsx\u000fÎJ¯Æ\u0015\u001e²Q~:\u0010\u009b¦á\u009c\u008d\u009d\u0099dÝ\u0088\b\u008d\\èÜo\u0010Ú\u008e-u¸ P¹ßÚÃ°&@\u001e/\u0010våXEÛ÷?©öÀZ¾\u009e¬ÅF\u0018¨\u0081\u0085\u008f\u0094_%Â\u0080\u007fÇ\u007f r,M§a,i&fs\u009d\u0010íÖÍB¤ýc\u0097Íû\u0091A1û\u001dÀ\u0010°L]XF\u001eÑ\u0014=\u001cÝÍeb÷Z\u0010PÄÞ\u0090ÈÈmDï:\u007fÇM~\u001c6(åJ½\u0080Ý¦}\u008a\u00136kQp\u008e\u0089Z«Þ\u00adô\u0010TZÇ¡\u001aMw\\~vCAk>\u000586òs\u0018\u0092»ÑÀ_ÉX\u001a\u0090»(ôÓ\u007f}Ócz<×i\u009cõ\u009d0ßº\u0018K\t,K\u001aÑ\u008a\u0087~9±ø\u0019±\u008a6\u008cb\u0097c5³\u008f\u0080Ñk&N\u0002w¨×^ý1\u0016I?[^md{'e\u0010>]\u0095Vð\u001a\u009fùÁ_\u0083½ö¥2Ñ";
      short var17 = 3545;
      char var14 = 16;
      int var21 = -1;

      label54:
      while (true) {
         String var23 = var15.substring(++var21, var21 + var14);
         int var10001 = -1;

         while (true) {
            String var34 = b(var11.doFinal(var23.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var34;
                  if ((var21 += var14) >= var17) {
                     b = var18;
                     c = new String[156];
                     h = new HashMap(13);
                     Cipher var0;
                     Cipher var25 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(49879801827375L << var1 * 8 >>> 56);
                     }

                     var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[4];
                     int var3 = 0;
                     String var4 = "\r¹\u0012\u0005\u0081Ô¨Ü=O¶\fR\fÊë";
                     byte var5 = 16;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var26 = var6;
                        var10001 = var3++;
                        long var38 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var41 = -1;

                        while (true) {
                           long var8 = var38;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var43 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var41) {
                              case 0:
                                 var26[var10001] = var43;
                                 if (var2 >= var5) {
                                    f = var6;
                                    g = new Long[4];
                                    何何友友树友树友友树 = new 何友友友树友何友树何();
                                    return;
                                 }
                                 break;
                              default:
                                 var26[var10001] = var43;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "©ä@%Ì¤¦n¡©úC\u0087\u001f>\u009e";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var32 = var2;
                           var2 += 8;
                           var7 = var4.substring(var32, var2).getBytes("ISO-8859-1");
                           var26 = var6;
                           var10001 = var3++;
                           var38 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var41 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var21);
                  break;
               default:
                  var18[var16++] = var34;
                  if ((var21 += var14) < var17) {
                     var14 = var15.charAt(var21);
                     continue label54;
                  }

                  var15 = "\u009c\u0002\u0090¨¦QÙn!³<\u0096\u0099\u00957¾\u0087õ\u008a\u0018ú\u0080Ìó\u0001\u0016\u0006\u000eMý<\u009c \u008c\u0081ë¹¢®ú\u0099\u001d?gy\u009aãnªzU4>±n\\H\"¬oþÆE\u0019\u001a";
                  var17 = 65;
                  var14 = ' ';
                  var21 = -1;
            }

            var23 = var15.substring(++var21, var21 + var14);
            var10001 = 0;
         }
      }
   }

   private void B() {
      e();
      if (this.树何友友树何何树友友) {
         long elapsedTime = System.currentTimeMillis() - this.友树树树何友树友树树;
         this.树友友友何树何友何友 = Math.min(1.0F, (float)elapsedTime / 200.0F);
         if (this.树友友友何树何友何友 >= 1.0F) {
            this.树何友友树何何树友友 = false;
         }
      }

      if (this.何树何友何友何友友树) {
         long elapsedTime = System.currentTimeMillis() - this.友树树树何友树友树树;
         this.树友友友何树何友何友 = Math.max(0.0F, 1.0F - (float)elapsedTime / 200.0F);
         if (this.树友友友何树何友何友 <= 0.0F) {
            this.何树何友何友何友友树 = false;
            this.何友树友树友何树友何 = false;
         }
      }

      if (this.何友树友树友何树友何) {
         this.树友友友何树何友何友 = 1.0F;
      }

      this.树友友友何树何友何友 = 0.0F;
   }

   private float C(float x) {
      return 1.0F - (1.0F - x) * (1.0F - x);
   }

   private void C(GuiGraphics guiGraphics, float alpha) {
      int alphaValue = (int)(Mth.clamp(alpha, 0.0F, 0.4F) * 255.0F);
      guiGraphics.fill(0, 0, super.width, super.height, alphaValue << 24);
   }

   private void D() {
      e();
      if (this.何树何何树友树何友友) {
         long elapsedTime = System.currentTimeMillis() - this.友何何树何友何友友树;
         this.树友树何何树树何友友 = Math.min(1.0F, (float)elapsedTime / 200.0F);
         if (this.树友树何何树树何友友 >= 1.0F) {
            this.何树何何树友树何友友 = false;
         }
      }

      if (this.友何友何友何何何友树) {
         long elapsedTime = System.currentTimeMillis() - this.友何何树何友何友友树;
         this.树友树何何树树何友友 = Math.max(0.0F, 1.0F - (float)elapsedTime / 200.0F);
         if (this.树友树何何树树何友友 <= 0.0F) {
            this.友何友何友何何何友树 = false;
            this.树友何友何友友树树树 = false;
            this.树何友树树何友树何树 = false;
         }
      }

      if (this.树友何友何友友树树树) {
         this.树友树何何树树何友友 = 1.0F;
      }

      this.树友树何何树树何友友 = 0.0F;
   }

   private void I(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      c<"ä">(-1454960262080439075L, 99512695057370L);
      if (c<"ª">(this, -1450903997633411704L, 99512695057370L) || c<"ª">(this, -1455416834531334309L, 99512695057370L)) {
         if (!(c<"ª">(this, -1457023813898241460L, 99512695057370L) <= 0.01F)) {
            ClientUtils.D(131325480669526L);
            何何友友树何树何友树 textFont = Cherish.instance.t().H(14);
            何何友友树何树何友树 placeholderAndListFont = Cherish.instance.t().H(14);
            String saveTextString = "Save";
            String loadTextString = "Load";
            String availableText = "Available Configs:";
            c<"c">(this, c<"ª">(this, -1453258893083868399L, 99512695057370L) + 40.0F - 90.0F, -1452864187609643519L, 99512695057370L);
            c<"c">(this, c<"ª">(this, -1451027546498769999L, 99512695057370L) - 200.0F - 5.0F, -1452825044640537252L, 99512695057370L);
            if (c<"ª">(this, -1452864187609643519L, 99512695057370L) < 5.0F) {
               c<"c">(this, 5.0F, -1452864187609643519L, 99512695057370L);
            }

            if (c<"ª">(this, -1452864187609643519L, 99512695057370L) + 180.0F > c<"ª">(this, -1456018931798882304L, 99512695057370L) - 5) {
               c<"c">(this, c<"ª">(this, -1456018931798882304L, 99512695057370L) - 5 - 180.0F, -1452864187609643519L, 99512695057370L);
            }

            if (c<"ª">(this, -1452825044640537252L, 99512695057370L) < 5.0F) {
               c<"c">(this, 5.0F, -1452825044640537252L, 99512695057370L);
            }

            int animatedAlpha = (int)(230.0F * c<"ª">(this, -1457023813898241460L, 99512695057370L));
            if (animatedAlpha >= 4) {
               RenderUtils.drawRoundedRect(
                  guiGraphics.pose(),
                  c<"ª">(this, -1452864187609643519L, 99512695057370L),
                  c<"ª">(this, -1452825044640537252L, 99512695057370L),
                  180.0,
                  200.0,
                  5.0,
                  new Color(30, 30, 30, animatedAlpha)
               );
               float currentY = c<"ª">(this, -1452825044640537252L, 99512695057370L) + 5.0F;
               RenderUtils.drawRoundedRect(
                  guiGraphics.pose(),
                  c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F,
                  currentY,
                  170.0,
                  20.0,
                  3.0,
                  new Color(45, 45, 45, animatedAlpha)
               );
               String inputText = c<"ª">(this, -1458430460728741161L, 99512695057370L)
                  + (
                     c<"ª">(this, -1451172632640744644L, 99512695057370L)
                           && System.currentTimeMillis() / b<"e">(31914, 8832650259363416108L) % b<"e">(28813, 8906333946511934473L) == 0L
                        ? "_"
                        : ""
                  );
               if (c<"ª">(this, -1458430460728741161L, 99512695057370L).isEmpty() && !c<"ª">(this, -1451172632640744644L, 99512695057370L)) {
                  placeholderAndListFont.q(
                     guiGraphics.pose(),
                     "",
                     c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F + 4.0F,
                     currentY + (20.0F - placeholderAndListFont.x()) / 2.0F,
                     new Color(150, 150, 150, animatedAlpha).getRGB()
                  );
               }

               textFont.q(
                  guiGraphics.pose(),
                  inputText,
                  c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F + 4.0F,
                  currentY + (20.0F - textFont.x()) / 2.0F,
                  new Color(220, 220, 220, animatedAlpha).getRGB()
               );
               currentY += 25.0F;
               c<"c">(this, 20.0F, -1456352402073399166L, 99512695057370L);
               float configPopupSaveButtonX = c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F;
               float configPopupLoadButtonX = c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F + 82.5F + 5.0F;
               c<"c">(
                  this,
                  this.b(configPopupSaveButtonX, currentY, 82.5F, c<"ª">(this, -1456352402073399166L, 99512695057370L), mouseX, mouseY)
                     && c<"ª">(this, -1457023813898241460L, 99512695057370L) > 0.9F,
                  -1450816772735605925L,
                  99512695057370L
               );
               c<"c">(
                  this,
                  this.b(configPopupLoadButtonX, currentY, 82.5F, 20.0F, mouseX, mouseY) && c<"ª">(this, -1457023813898241460L, 99512695057370L) > 0.9F,
                  -1452493964244673921L,
                  99512695057370L
               );
               Color saveBtnColor = c<"ª">(this, -1450816772735605925L, 99512695057370L)
                  ? new Color(70, 100, 70, animatedAlpha)
                  : new Color(50, 80, 50, animatedAlpha);
               RenderUtils.drawRoundedRect(
                  guiGraphics.pose(), configPopupSaveButtonX, currentY, 82.5, c<"ª">(this, -1456352402073399166L, 99512695057370L), 3.0, saveBtnColor
               );
               textFont.h(
                  guiGraphics.pose(),
                  saveTextString,
                  configPopupSaveButtonX + 41.25F,
                  currentY + (c<"ª">(this, -1456352402073399166L, 99512695057370L) - textFont.x()) / 2.0F,
                  new Color(220, 220, 220, animatedAlpha).getRGB()
               );
               Color loadBtnColor = c<"ª">(this, -1452493964244673921L, 99512695057370L)
                  ? new Color(70, 70, 100, animatedAlpha)
                  : new Color(50, 50, 80, animatedAlpha);
               RenderUtils.drawRoundedRect(guiGraphics.pose(), configPopupLoadButtonX, currentY, 82.5, 20.0, 3.0, loadBtnColor);
               textFont.h(
                  guiGraphics.pose(),
                  loadTextString,
                  configPopupLoadButtonX + 41.25F,
                  currentY + (20.0F - textFont.x()) / 2.0F,
                  new Color(220, 220, 220, animatedAlpha).getRGB()
               );
               currentY += c<"ª">(this, -1456352402073399166L, 99512695057370L) + 5.0F;
               placeholderAndListFont.q(
                  guiGraphics.pose(),
                  availableText,
                  c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F,
                  currentY,
                  new Color(180, 180, 180, animatedAlpha).getRGB()
               );
               float listStartY = currentY + (placeholderAndListFont.x() + 2);
               float listHeight = c<"ª">(this, -1452825044640537252L, 99512695057370L) + 200.0F - 5.0F - listStartY;
               float listRenderY = listStartY - c<"ª">(this, -1457294734735646686L, 99512695057370L);
               guiGraphics.enableScissor(
                  (int)(c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F),
                  (int)listStartY,
                  (int)(c<"ª">(this, -1452864187609643519L, 99512695057370L) + 180.0F - 5.0F),
                  (int)(listStartY + listHeight)
               );
               Iterator totalContentHeight = c<"ª">(this, -1453898982271755643L, 99512695057370L).iterator();
               if (totalContentHeight.hasNext()) {
                  String configName = (String)totalContentHeight.next();
                  if (listRenderY + 20.0F > listStartY && listRenderY < listStartY + listHeight) {
                     boolean hoveringItem = this.b(c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F, listRenderY, 170.0F, 20.0F, mouseX, mouseY)
                        && mouseY >= listStartY
                        && mouseY <= listStartY + listHeight
                        && c<"ª">(this, -1457023813898241460L, 99512695057370L) > 0.9F;
                     if (hoveringItem) {
                        RenderUtils.drawRoundedRect(
                           guiGraphics.pose(),
                           c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F,
                           listRenderY,
                           170.0,
                           20.0,
                           2.0,
                           new Color(60, 60, 60, animatedAlpha)
                        );
                     }

                     placeholderAndListFont.q(
                        guiGraphics.pose(),
                        configName,
                        c<"ª">(this, -1452864187609643519L, 99512695057370L) + 5.0F + 4.0F,
                        listRenderY + (20.0F - placeholderAndListFont.x()) / 2.0F,
                        new Color(200, 200, 200, animatedAlpha).getRGB()
                     );
                  }

                  float var10000 = listRenderY + 20.0F;
               }

               guiGraphics.disableScissor();
               float totalContentHeightx = c<"ª">(this, -1453898982271755643L, 99512695057370L).size() * 20.0F;
               if (totalContentHeightx > listHeight) {
                  float scrollBarHeightRatio = listHeight / totalContentHeightx;
                  float scrollBarActualHeight = Math.max(10.0F, scrollBarHeightRatio * listHeight);
                  float scrollBarYPosRatio = totalContentHeightx - listHeight == 0.0F
                     ? 0.0F
                     : c<"ª">(this, -1457294734735646686L, 99512695057370L) / (totalContentHeightx - listHeight);
                  float scrollBarY = listStartY + scrollBarYPosRatio * (listHeight - scrollBarActualHeight);
                  RenderUtils.drawRectangle(
                     guiGraphics.pose(),
                     c<"ª">(this, -1452864187609643519L, 99512695057370L) + 180.0F - 5.0F - 3.0F,
                     scrollBarY,
                     2.0F,
                     scrollBarActualHeight,
                     new Color(100, 100, 100, animatedAlpha).getRGB()
                  );
               }
            }
         }
      }
   }

   private void I() {
      e();
      if (this.友树树何友树树友何树 == null) {
         this.友树树树树友树友友树 = new ArrayList<>();
      } else {
         List<Module> allModules = Cherish.instance
            .getModuleManager()
            .p()
            .stream()
            .filter(
               m -> {
                  e();
                  return this.友何友树树友何树友树.isEmpty()
                     || m.A().toLowerCase().contains(this.友何友树树友何树友树.toLowerCase())
                     || m.B().toLowerCase().contains(this.友何友树树友何树友树.toLowerCase());
               }
            )
            .collect(Collectors.toList());
         int selectedKeyCode = this.友树树何友树树友何树.何树友树树树友友友树;
         allModules.sort((m1, m2) -> {
            e();
            boolean m1BoundToKey = m1.r() == selectedKeyCode;
            boolean m2BoundToKey = m2.r() == selectedKeyCode;
            if (m1BoundToKey && !m2BoundToKey) {
               return -1;
            } else {
               return !m1BoundToKey && m2BoundToKey ? 1 : m1.A().compareToIgnoreCase(m2.A());
            }
         });
         this.友树树树树友树友友树 = allModules;
      }
   }

   private void S() {
      this.树友何友何友友树树树 = true;
      this.何树何何树友树何友友 = true;
      this.友何友何友何何何友树 = false;
      this.树友树何何树树何友友 = 0.0F;
      this.友何何树何友何友友树 = System.currentTimeMillis();
      this.友树何何树何友何友何 = 0.0F;
      this.d();
   }

   private void Z() {
      e();
      if (this.友树树树何友友树何何) {
         long elapsedTime = System.currentTimeMillis() - this.树树何何何友树树何友;
         this.何友树何何何树树何何 = Math.min(1.0F, (float)elapsedTime / 500.0F);
         if (this.何友树何何何树树何何 >= 1.0F) {
            this.何友树何何何树树何何 = 1.0F;
            this.友树树树何友友树何何 = false;
            this.何树树友友树友友友友 = null;
         }
      }
   }

   public static int[] e() {
      return 友友何友树树友何何何;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 49;
               case 1 -> 15;
               case 2 -> 13;
               case 3 -> 31;
               case 4 -> 36;
               case 5 -> 35;
               case 6 -> 33;
               case 7 -> 61;
               case 8 -> 58;
               case 9 -> 62;
               case 10 -> 14;
               case 11 -> 44;
               case 12 -> 30;
               case 13 -> 47;
               case 14 -> 3;
               case 15 -> 38;
               case 16 -> 37;
               case 17 -> 51;
               case 18 -> 18;
               case 19 -> 27;
               case 20 -> 41;
               case 21 -> 56;
               case 22 -> 2;
               case 23 -> 28;
               case 24 -> 57;
               case 25 -> 52;
               case 26 -> 63;
               case 27 -> 21;
               case 28 -> 55;
               case 29 -> 16;
               case 30 -> 32;
               case 31 -> 59;
               case 32 -> 48;
               case 33 -> 10;
               case 34 -> 5;
               case 35 -> 60;
               case 36 -> 50;
               case 37 -> 54;
               case 38 -> 45;
               case 39 -> 29;
               case 40 -> 6;
               case 41 -> 23;
               case 42 -> 17;
               case 43 -> 22;
               case 44 -> 8;
               case 45 -> 11;
               case 46 -> 34;
               case 47 -> 0;
               case 48 -> 43;
               case 49 -> 4;
               case 50 -> 39;
               case 51 -> 42;
               case 52 -> 9;
               case 53 -> 25;
               case 54 -> 12;
               case 55 -> 20;
               case 56 -> 40;
               case 57 -> 53;
               case 58 -> 26;
               case 59 -> 46;
               case 60 -> 19;
               case 61 -> 24;
               case 62 -> 7;
               default -> 1;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 170 && var8 != 'c' && var8 != 209 && var8 != 252) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 193) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 228) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 170) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'c') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 209) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private boolean b(float x, float y, float width, float height, double mouseX, double mouseY) {
      e();
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 13444;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/何友友友树友何友树何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何友友友树友何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void x() {
      this.树何友友树树友树树何 = 何友友友树友何友树何.树友何树何树树友何树.何何何友何何何友何何;
      this.树何友何友友树友树何 = true;
      this.树友何何何何友何何友 = System.currentTimeMillis();
      this.友树友何何何树友友树 = false;
      this.s();
      this.何何树友友树何树树树 = false;
   }

   private void s() {
      e();
      if (this.何友树友树友何树友何 || this.树何友友树何何树友友) {
         this.树何友友树何何树友友 = false;
         this.何树何友何友何友友树 = true;
         this.友树树树何友树友树树 = System.currentTimeMillis();
         this.何何树友友树何树树树 = false;
      }

      this.何友树友树友何树友何 = false;
      this.树友友友何树何友何友 = 0.0F;
   }

   private void c() {
      e();
      this.友树友何何何树友友树 = true;
      this.树何友友树树友树树何 = 何友友友树友何友树何.树友何树何树树友何树.树何友何友树树友友树;
      this.树何友何友友树友树何 = true;
      this.友何何友何何友树树何 = 0.0F;
      this.树友何何何何友何何友 = System.currentTimeMillis();
      this.树友何友树树友友友树 = false;
      this.友何何友何友何何树何 = 0.0F;
      this.何何树树何树树何树何 = -40.0F;
      if (super.width > 0 && super.height > 0 && this.何友友何树树树何友友.isEmpty()) {
         this.H();
      }

      if (this.友何何何树树友树何友 > 0.0F) {
         this.何树何树友树树何树何 = -this.友何何何树树友树何友 - 10.0F;
      }

      this.何树何树友树树何树何 = -500.0F;
      this.何友树友树友何树友何 = false;
      this.树友友友何树何友何友 = 0.0F;
      this.树何友友树何何树友友 = false;
      this.何树何友何友何友友树 = false;
      this.友何友树树友何树友树 = "";
      this.何何树友友树何树树树 = false;
      this.树树友友友何友友何友 = 0.0F;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何友友友树友何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private void h() {
      e();
      if (this.树友何友何友友树树树 || this.何树何何树友树何友友) {
         this.何树何何树友树何友友 = false;
         this.友何友何友何何何友树 = true;
         this.友何何树何友何友友树 = System.currentTimeMillis();
         this.树何友树树何友树何树 = false;
      }

      this.树友何友何友友树树树 = false;
      this.树友树何何树树何友友 = 0.0F;
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void l(int[] var0) {
      友友何友树树友何何何 = var0;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private void d() {
      e();
      this.树何友友何何何树树树.clear();
      File configDir = Cherish.getConfigManager().e();
      if (configDir.exists() && configDir.isDirectory()) {
         File[] files = configDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".ini"));
         int var7 = files.length;
         int var8 = 0;
         if (0 < var7) {
            File file = files[0];
            this.树何友友何何何树树树.add(file.getName().replaceAll("\\.ini$", ""));
            var8++;
         }
      }

      this.树何友友何何何树树树.sort(String.CASE_INSENSITIVE_ORDER);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27945;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/何友友友树友何友树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[.úöq9\u0001\u000e¼, Î8ºÿ/bl¤, \u0083¿þ\u008dÐ\u0004ËÁ, \u0081^rZ\u0016Êl-\tÛ\u0097UÍj\u0000<àrM\u0090\u0005«Il, Ò\u000b ÿâH¦ü, µ\u0012)M\u0010\u009a\u009a\u000b, ¨I{!\t\u0004¸ÿ\u0088½\u0081ÔÎA\u009f¹, \u0010e`Eå#p=\u009c²YRË\u001f¥\u0086, Á\u0005gHÃ\u0080/b, SgÜF\u0010n\u0005\\, íUã¸\u009e©\u0003qÒK\thÎÝø\\?\u0016Ñô\u008f\u001cò×ÅP³A²X¯ò, üþ\u0017ýÈ\u009bUÎ, ã@?ù¼.ü&, À¦\"DÌ\u0000m\u0002\u0099òØ¹Å/rw, <S\b\u00adÈ@Â8\u0088qAªÖË\u0004þ, ¡\u0014o\u0003¥\u008fWþ, \u0090\u0099/÷-)¢\u0010, ¿Úóq\u007f\u0018å\u0012\u0095\u000eLfùî\u001fD, ½e\u0002\u007fD\u0094\u0083µ, P;Úñ²\u0091Ét, MQ\"èÑ8\u008fM, /¾é\u0017hu\u0014s, \u0010\u0094Jl\u008e")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static void a() {
      i[0] = "#&C37X,f\u000e8=E);\u0005~-^n伝厦厛厓栦压伝厦桁伍";
      i[1] = "<X";
      i[2] = "mcFH]oflW\u0007'kumGH\u0011ob";
      i[3] = long.class;
      j[3] = "java/lang/Long";
      i[4] = "G\u0019HQ 1HY\u0005Z*,M\u0004\u000e\u001c\"1@\u0002\nWa桏佱厼厭佧桞厕可伢伳";
      i[5] = boolean.class;
      j[5] = "java/lang/Boolean";
      i[6] = float.class;
      j[6] = "java/lang/Float";
      i[7] = ",kI~e1#+\u0004uo,&v\u000f3\u007f7a佐厬取叁桏厄佐厬栌佟z桞収伲栌佟桏桞収伲栌";
      i[8] = "\u0006PM2E1\r_\\}8)\u001eXU4";
      i[9] = "R|V\u0005G\u0006Oi\u000e'\u0006\u000bWo";
      i[10] = int.class;
      j[10] = "java/lang/Integer";
      i[11] = "j\u0011\u000429?eQI93\"`\fB\u007f#9'伪叡厚厝桁参伪叡桀伃t栘厴使厚厝伅参伪栻厚";
      i[12] = "\u001eg\u0005\u001f\u0013 \u0000o\u001fPq<\u0007r";
      i[13] = "\\yg\f[\u001cS9*\u0007Q\u0001Vd!AA\u001a\u0011叜桘厤栥桢佪佂厂桾叿";
      i[14] = "g\u0016ZZ\"\bhV\u0017Q(\u0015m\u000b\u001c\u00178\u000e*伭桥史历伲叏厳伡栨桜";
      i[15] = "KC";
      i[16] = void.class;
      j[16] = "java/lang/Void";
      i[17] = "\u001c\u0014$0,4\u0002\u001c>\u007fA.\u001b\u00053#c5\u0019\u0007";
      i[18] = "EL\u001f\u0015hr[D\u0005Z\u000ef\\E$\u00156";
      i[19] = "S\\,rx$\\\u001cayr9YAj?b\"\u001e佧叉叚叜桚叻佧叉栀佂o佥叹栓佄叜伞佥栣叉栀";
      i[20] = "Q6n\u0010\u0017TZ9\u007f_vZQ2{\u0005";
      i[21] = "iz\u0017Y\u0005rleAa伹伟栕栅伦似桽桛叏栅{\n\u0006rw,\u001dZU\u007f`";
      i[22] = "!tOmI\u001e$k\u0019U叫样伙栋栺桌叫佳桝住#i\u0017V\u007f{E9ML9";
      i[23] = "7\u0007z\r^R2\u0018,5栦桻伏厢栏佨栦厡厑桸\u0016\t\u0000\u001ai\bpYZ\u0000/";
      i[24] = "\u0002OA\r\"x\u0007P\u00175桚伕厤栰栴佨厀桑伺栰-\u000e19\u0015XQP1-\u001a";
      i[25] = "K\u0004!qU\u001eN\u001bwI号佳佳桻伐厊号样样桻MrF_\\\u00131,FKS";
      i[26] = "aY'z1[dFqB桉厨余栦厈桛桉伶余叼K~o\u0013?V-.5\ty";
      i[27] = "-rL]\u0013 (m\u001ae伯栉伕佉根厦桫位压受 ^\u0000a:e\\\u0000\u0000u5";
      i[28] = "\"\u0005\u0003KB\u0019'\u001aUs栺只会厠伲厰叠栰桞桺oHQX5\u0012\u0013\u0016QL:";
      i[29] = "{\tl`9o4\u000bmwD佔伛伻厓佛伙佔厅伻伍\u0006yfz\u0000-`6d{\u0017";
      i[30] = "i@\u0006~9~l_PF桁厍佑句桳桟厛厍叏栿j}*?~W\u0016#*+q";
      i[31] = ":-\no\u0017V?2\\W伫桿框厈桿伊伫厥伂桒fl\u0004\u0017-:\u001a2\u0004\u0003\"";
      i[32] = "SA\u001as%\bV^LK伙校佫古伫厈伙叻叵栾vp6IDV\n.6]K";
      i[33] = "\u0004&{#Nn\u00019-\u001b召厝似伝栎栂召桇厢桙\u0017!Q>\u00049qiC=\u000b";
      i[34] = "Z\u00056,}~_\u001a`\u0014栅厍栦桺伇受叟伓栦厠Z(#6\u0004\n<xy,B";
      i[35] = "9CS\u0016]\t<\\\u0005.栥佤原另佢佳佡栠桅格?\u001e\\D \u0015\u000eAU\b8";
      i[36] = "P#\u001f\r>GU<I5框桮佨优伮栬厜厴佨桜s\u0004n\u0016R=BM8\u0010_";
      i[37] = "~|\u0010u\u001cQ{cFM传似变佇县伐传似栂栃|qB\u0019 s\u001a!\u0018\u0003f";
      i[38] = "qLC\u000b\fu8\u001aE\u0006t桝桙传叡伱桭厇桙桤使lH{8FK\n\u0018!\"\u0000";
      i[39] = "GAc$\u0016,\bCb3k桓档样框厁厨众厹叭伂BV%FH\"$\u0019'G_";
      i[40] = ";\u0007>\u001e\u0002\u0015>\u0018h&桺格伃似伏句桺格伃厢R\u001cX\u001d>\u001c.K\u0004[o";
      i[41] = "]VN\u001a\u001e\u0012XI\u0018\"伢叡叻栩栻栻厼栻校右\"\u001e@Z\u0003YDN\u001a@E";
      i[42] = "\u0002LAf`7N\u000eDc\u000bJ}\u007fg\u0000\\Afyv\\5rZ\nLey0_\u000f";
      i[43] = "\u0017\u0006v!9R\u0012\u0019 \u0019伅厡桫厣栃叚伅桻厱伽\u001a\"*\u0013\u0000\u0011f|*\u0007\u000f";
      i[44] = "nj\u0002I*\u001dkuTq伖栴栒叏厭桨厈叮又叏nK5Mnu\b\u0003'Na";
      i[45] = "\na;\u0001t\u0017\u000f~m9取栾桶佚厔栠栌古伲栞W\u0006gH\u0006m:K(NW";
      i[46] = "\u001e0S+V\u0016RrV.=dq\u0005s\u0011\u0003SFv^(O\u0011Cs";
      i[47] = "M\u0010\r.vp\u0002\u0012\f9\u000b佋厳伢佬伕又叕伭伢史H6yL\u0019L.y{M\u000e";
      i[48] = "IxDx1`Lg\u0012@桉伍栵佃叫厃厓伍佱叝(|o(\u0017wN,52Q";
      i[49] = "\u001a\nT\u001duNLI\u000e\b\n栭桪叱栬厬叉号伮佯栬oc\f\u0012@J\u00155OHU";
      i[50] = "Q\u0013\u0002A*\"\u001e\u0011\u0003VW桝伱县佣古桎桝厯县栧'j+P\u001aCA%)Q\r";
      i[51] = "K\u0000MT`JN\u001f\u001bl参档佳伻叢厯作档佳桿!P>\u0002\u0015\u000fG\u0000d\u0018S";
      i[52] = "\u0012h;4k\"\u0017wm\f栓住厴体厔叏栓发桮体W7xc\u0005\u007f+ixw\n";
      i[53] = "a\u0013Le6ed\f\u001a]伊伈余伨口伀桎厖叇桬 f%$v\u0004\\8%0y";
      i[54] = "W\u00025I-3]\u00164\tD伀佦厨栐桭桝厞栢伶栐txbCP`\u0012(8Y\u0016";
      i[55] = "B/V\r\\OG0\u00005栤伢栾厊叹叶你伢古厊:\u000eO\u000eU8FPO\u001aZ";
      i[56] = "</\u001ds\u0015\u001890KK厷併伄伔桨桒厷栱伄厊qwKPb \u0017'\u0011J$";
      i[57] = "4\u0017\u001f\u0019hR1\bI!及桻案桨桪叢栐厡厒桨s\u0011i\u001f-ABN`S5";
      i[58] = "]T3`S\fXKeX佯栥佥佯框伅叱叿校佯_d\rD\u0003[94W^E";
      i[59] = "jB6{/I<\u0001lnP株叀厹伊栐厓株佞伧厔\t9\u000bb\b(soH8\u001d";
      i[60] = "<>H%o%9!\u001e\u001d体佈伄厛栽栄反佈伄伅$!1mb1Bqkw$";
      i[61] = "*Qw!kq/N!\u0019佗桘伒栮变栀栓伜桖佪\u001b%59t^}uo#2";
      i[62] = "\bH,\u0010Po\rWz(栨框厮佳厃栱栨框厮佳@\u0014\u000e'VG&DT=\u0010";
      i[63] = "\\Z\u001c\b\b\u0011YEJ0桰佼佤栥桩右厪核佤佡p\u000b\u001bPKM\fU\u001bDD";
      i[64] = ">[BM\u0013\u000b;D\u0014u伯栢桂你佳厶厱栢伆叾.N\u0000J)LR\u0010\u0000^&";
      i[65] = "a<\u000b\u0016A\u0018d#].口栱栝桃伺叭口栱余伇g\u0015RYv+\u001bKRMy";
      i[66] = "K\t.kD|N\u0016xS佸厏样伲伟伎格桕佳伲Bo\u001a4\u0015\u0006$?@.S";
      i[67] = "RLl\u0010Z9WS:(_\t]\u00121F_6\u000fW8Y;c\fLaF[dKL=(";
      i[68] = "y\u0007=#B\u0004|\u0018k\u001b栺佩叟厢案但佾栭叟厢Q QEn\u0010-~QQa";
      i[69] = "b\t}r^rg\u0016+JQ\u00156Q,v\u0004\u0015\u0007P~sY|<Vi.\u0003";
      i[70] = "YE\u000e\u0003KQ\u0011W\r\f2栮厠佦伳厥栫叴厠佦桷f\f\u000b^Y\u0003\u0017\tI\u0005D";
      i[71] = "KyD{a\u001eNf\u0012C參佳叭叜併厀栙佳佳佂(\u007f?V\u0015vN/eLS";
      i[72] = "\u001d\t9AA\u0019T_?L9栱可佥厛栿叺併可佥厛&\u0003VL]!@KDOR";
      i[73] = "{{\u001foDZ79\u001aj/<\u0005F%\u0018/]9aC>\u0016\u0011{dF";
      i[74] = ":3\u0006=b\u0015?,P\u0005栚佸厜桌厩叆栚格伂厖j9<]d<\fifG\"";
      i[75] = "hQ\u001f\u0007g<mNI?h[<\tN\u0003:[\r\b\u001c\u0006`26\u000e\u000b[:";
      i[76] = "nT\u0000Qb\u001bkKVi叀佶佖叱伱伴叀栲栒佯lU<S0[\n\u0005fIv";
      i[77] = "5d3\u0013]\u0001}v0\u001c$伺佒佇桊伫佹伺栖叙厐v\u001a[2x>\u0007\u001f\u0019ie";
      i[78] = "rS(q6ywL~I桎厊佊叶桝厊桎厊栎叶Duh1,\\\"%2+j";
      i[79] = "U$Cj\"qP;\u0015R桚伜栩厁佲桋桚桘右桛/i10B3S71$M";
      i[80] = "CO>=_WFPh\u0005叽桾句只厑佘栧桾栿只R9\u0001\u001f\u001d@4i[\u0005[";
      i[81] = "Tw\u0000G\u0002KQ5[Zoq#\u0010pr.|1\u0006{~.f+\u0015pr(`&\u0006g%\u0005E\u001a'LO\bS\fs";
      i[82] = "\u0007\u001f \u000f4N\u0002\u0000v78~\bA}Y1AZ\u0004tFU";
      i[83] = "o^\u007f\u001dI]jA)%栱桴佗叻栊另併桴叉叻\u0013\u0019\u0017\u00151QuIM\u000fw";
      i[84] = "\u001cs1\u0012G \u0019lg*栿叓厺取伀栳佻叓伤取]\u0016\u0019hB|;FCr\u0004";
      i[85] = "2D:m\\W\u007f\u000b<<6佧栔叵桌栝栯叹収叵桌\u0004\tU4Pk?\u000fBi\n";
      i[86] = "{W9&\u001c:qC8fu伉佊栧栜栂厶厗佊叽佘\u001bIko\u0005l}\u00191uC";
      i[87] = "^?\u001a\u0000&\\[ L8厄伱佦厚伫叻会伱栢伄v\u0004x\u0014\u00000\u0010T\"\u000eF";
      i[88] = "bO!,\u001f\u0016gPw\u0014厽佻佚栰伐受伣句叄栰M.E\u001egT1y\u0019X6";
      i[89] = "4 =NZ\u00001?kvR0h&l\u0016\u0000@66<N;\t1{1MKW!+iv";
      i[90] = "rPjF!hwO<~伝桁叔叵叅桧桙厛叔栯\u0006E2)eGz\u001b2=j";
      i[91] = "&P\f]\u0006b#OZe厤桋伞佫桹厦桾厑伞叵`YX*x_\u0006\t\u00020>";
      i[92] = "k\u0018*seLn\u0007|K叇伡反伣厅伖余伡反桧Fpv\r|\u000f:.v\u0019s";
      i[93] = ".c\u0010T\u0015\\+|Fl伩伱桒叆县桵伩桵桒栜|W\u0006\u001d9t\u0000\t\u0006\t6";
      i[94] = "ys}15s|l+\t桍厀佁栌叒佔桍厀佁取\u00112&2ndml&&a";
      i[95] = "%4W3PI +\u0001\u000b栨伤厃厑栢栒史桠桙伏;6^E&/]y\\D1";
      i[96] = "\u0000ub{\u001a:\u0005j4C伦佗厦栊栗厀桢佗伸低\u000e\u007fDr^zh/\u001eh\u0018";
      i[97] = "?j\u007f\u000eWE:u)6叵桬桃栕低叵栯厶桃栕\u0013\f\rM:qo[Q\u000bk";
      i[98] = "\u0000\u0019\u0002;#c\u0005\u0006T\u0003桛伎厦桦桷佞伟伎厦厼n9yk\u0005\u0002\u0012n%-T";
      i[99] = "\u001ej\u001brG1\u001buMJ栿参厸佑厴众佻作厸栕wt\u001a<\u0019a\u0006qXg\u0004";
      i[100] = "/uD\u0016I\n*j\u0012.叫佧众叐栱叭栱栣厉叐(\u0012\u0017BqzNBMX7";
      i[101] = "K7u\u0012 ;N(#*桘又叭厒栀叩厂又佳案\u0019\u0016~s\u00158\u007fF$iS";
      i[102] = "[Jo54\b^U9\r厖校叽佱佞佐桌叻叽栵\u00036'IL]\u007fh']C";
      i[103] = "\u001e%~jf\t\u001b:(R叄栠厸厀住厑栞栠桢桚\u0012n8A@*t>b[\u0006";
      i[104] = "Sg}C\u0003\u0014Vx+{伿佹叵参叒厸厡佹叵栘\u0011E^\u0019Tl`@\u001cBI";
      i[105] = "\u0007[\u00177\u0007HN\r\u0011:\u007f伤佫厩厵伍桦桠栯伷桯PCFNQ\u001f6\u0013\u001cT\u0017";
      i[106] = "\u0015\n\u00105\u0016H\u0010\u0015F\r桮桡厳厯县佐厴去伭厯|1H\u0000K\u0005\u001aa\u0012\u001a\r";
      i[107] = "kH4d1.nWb\\厓叝体叭桁企厓叝栗叭X`of5G>05|s";
      i[108] = "\u0005\u0001\bd\u00045\u0000\u001e^\\厦佘厣桾桽原伸栜厣桾dbY8\u0002\n\u0015g\u001bc\u001f";
      i[109] = " lYC\u00125%s\u000f{伮叆历佗栬桢桪佘历叉5K\u0013x9:\u0004\u0014\u001a4!";
      i[110] = "\u001c\u000bS,t\u0004QDU}\u001e桰栺桠栥优佃厪佾桠佡E U\u001e\u001bQ4%\u0017E\u0006";
      i[111] = "eO\u0002{32`PTC桋佟參只伳厀伏叁佝只n\u007fmz;@\b/7`}";
      i[112] = "B\b\u001exJa\u0014KDm5变叨栩桦栓栬但佶右厼\n\\#JB\u0000p\n`\u0010W";
      i[113] = "O\u0007<u\u0004\u001bJ\u0018jM伸栲叩似厓桔厦佶叩厢PqZS\u0011\b6!\u0000IW";
      i[114] = "I\u007f\u001ewXtCk\u001f71栃佸栏叡桓佬佇另叕栻J\u000f&\u0018tO;\ndCi";
      i[115] = "yxiG\u007fO|g?\u007f叝桦佁佃栜伢叝伢叟佃\u0005C!\u0007'wc\u0013{\u001da";
      i[116] = "rFw\\C\nwY!d栻叹叔根变厧叡栣佊根\u001bX\u001dB,I}\bGXj";
      i[117] = "=g|\u00149i8x*,桁厚伅作位佱厛伄伅参\u0010\u0016ca8|lA?'i";
      i[118] = "\"O\r\u0000vn'P[8佊伃桞栰似校栎伃桞佴a\u0004(&|@\u0007Tr<:";
      i[119] = "P2\fRv*U-Zj栎叙栬伉伽桳栎佇叶厗`V(b\u000e=\u0006\u0006rxH";
      i[120] = "qdSSbDt{\u0005k叀伩栍佟叼伶叀厷栍栛?W<\f/kY\u0007f\u0016i";
      i[121] = "vj\u0005\u0011\u0005\u0012|~\u0004Ql县栃叀栠佱伱伡叙佞叺,PCb8PJ\u0000\u0019x~";
      i[122] = "{\u000e\u0011b\u000bM~\u0011GZ厩桤佃伵桤桃桳厾叝伵}fU\u0005%\u0001\u001b6\u000f\u001fc";
      i[123] = "|\u001b\rw\bgv\u000f\f7a佔位厱史众似及叓伯栨J_5-\u0010\\;Zwv\r";
      i[124] = "CV\"7\u0018#\n\u0000$:`栋厱桾桚厓桹住桫伺桚P\\-\n\\*6\fw\u0010\u001a";
      i[125] = "ke'BS!nzqz栫叒栗叀伖厹佯叒栗佞KF\ri5j-\u0016Wss";
      i[126] = "[Bw\u007f\u0001\u001dQVv?h伮叴叨桒桛桱厰栮栲厈BTLO\u0010\"$\u0004\u0016UV";
      i[127] = "L9C$\u0013hI&\u0015\u001c伯厛佴框佲佁桫厛佴框/ M \u00126Ip\u0017:T";
      i[128] = "N\u0005p}!V\u0007SvpY厤厼号叒叙厚厤桦佩佌\u001ab\u0015\u000eF`f<\u0015\u001aI";
      i[129] = "\u0015[\u0011&4\u001b\u0010DG\u001e伈栲桩栤厾叝伈叨桩你}\"jSKT\u001br0I\r";
      i[130] = "\u0007\u0005h\u0010\u0004]NSn\u001d|厯叵号及厴桥伱栯佩栐w@SN\u000f`\u0011\u0010\tTI";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何友友友树友何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private void a(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      ClientUtils.D(131325480669526L);
      何何友友树何树何友树 buttonFont = Cherish.instance.t().H(16);
      boolean hoveringSnakeGame = this.b(this.何树友何友树友何友友, this.何友友树树树友树树友, 80.0F, 20.0F, mouseX, mouseY);
      if (hoveringSnakeGame != this.何树友友友树树友友树) {
         this.何树友友友树树友友树 = hoveringSnakeGame;
      }

      Color baseColor = new Color(60, 60, 60, 255);
      Color hoverColor = new Color(80, 80, 80, 255);
      int r = (int)友友友树何友树友树友.B((float)baseColor.getRed(), (float)hoverColor.getRed(), this.树树何友树何树友友树);
      int g = (int)友友友树何友树友树友.B((float)baseColor.getGreen(), (float)hoverColor.getGreen(), this.树树何友树何树友友树);
      int b = (int)友友友树何友树友树友.B((float)baseColor.getBlue(), (float)hoverColor.getBlue(), this.树树何友树何树友友树);
      Color snakeGameBgColor = new Color(r, g, b, 255);
      RenderUtils.drawRectangle(guiGraphics.pose(), this.何树友何友树友何友友, this.何友友树树树友树树友, 80.0F, 20.0F, snakeGameBgColor.getRGB());
      Color accentColor = new Color(100, 100, 100, 255);
      RenderUtils.drawRectangle(guiGraphics.pose(), this.何树友何友树友何友友, this.何友友树树树友树树友 + 20.0F - 2.0F, 80.0F, 2.0F, accentColor.getRGB());
      buttonFont.h(guiGraphics.pose(), "", this.何树友何友树友何友友 + 40.0F, this.何友友树树树友树树友 + 10.0F - buttonFont.x() / 2, new Color(220, 220, 220).getRGB());
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private void m(GuiGraphics guiGraphics, float x, float y, float sidebarWidth, float rectHeight) {
      float sectionY = y + 350.0F - 65.0F;
      RenderUtils.drawRectangle(guiGraphics.pose(), x, sectionY, 90.0F, 65.0F, new Color(70, 70, 70).getRGB());
      RenderUtils.drawRectangle(guiGraphics.pose(), x + 5.0F, sectionY + 5.0F, sidebarWidth - 10.0F, 1.0F, new Color(100, 100, 100).getRGB());
      ClientUtils.D(131325480669526L);
      何何友友树何树何友树 nameFont = Cherish.instance.t().C(14);
      何何友友树何树何友树 infoFont = Cherish.instance.t().H(14);
      float avatarX = x + (sidebarWidth - 30.0F) / 2.0F - 20.0F;
      float avatarY = sectionY + 22.0F;
      RenderUtils.S(guiGraphics.pose(), avatarX, avatarY, 30.0F, 13836444665765L, 30.0F, mc.player);

      try {
         RenderUtils.drawRectangle(guiGraphics.pose(), avatarX - 1.0F, avatarY - 1.0F, 32.0F, 1.0F, new Color(90, 90, 90).getRGB());
         RenderUtils.drawRectangle(guiGraphics.pose(), avatarX - 1.0F, avatarY + 30.0F, 32.0F, 1.0F, new Color(90, 90, 90).getRGB());
         RenderUtils.drawRectangle(guiGraphics.pose(), avatarX - 1.0F, avatarY, 1.0F, 30.0F, new Color(90, 90, 90).getRGB());
         RenderUtils.drawRectangle(guiGraphics.pose(), avatarX + 30.0F, avatarY, 1.0F, 30.0F, new Color(90, 90, 90).getRGB());
      } catch (Exception var24) {
      }

      String playerName = null;
      if (mc.player != null) {
         playerName = WrapperUtils.f(111441258359257L);
      }

      nameFont.q(guiGraphics.pose(), playerName, avatarX + 30.0F + 5.0F, avatarY + 8.0F, -1);
      String timeString = this.o();
      infoFont.q(guiGraphics.pose(), timeString, avatarX + 30.0F + 5.0F, avatarY + 22.0F, new Color(200, 200, 200).getRGB());
   }

   private String o() {
      return DateTimeFormatter.ofPattern("Close").format(LocalDateTime.now());
   }

   private void o(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      e();
      ClientUtils.D(131325480669526L);
      何何友友树何树何友树 closeButtonFont = Cherish.instance.t().C(20);
      何何友友树何树何友树 virtualKeyFont = Cherish.instance.t().H(14);
      何何友友树何树何友树 contextMenuModuleFont = Cherish.instance.t().H(16);
      何何友友树何树何友树 contextMenuSearchFont = Cherish.instance.t().H(14);
      float keyboardAlpha = Mth.clamp(this.友何何友何何友树树何 * 1.5F, 0.0F, 1.0F);
      if (this.树树何友树友何树友友 > 0.0F && this.友何何何树树友树何友 > 0.0F && this.何树何树友树树何树何 + this.友何何何树树友树何友 > -20.0F && this.何树何树友树树何树何 < super.height + 20.0F) {
         RenderUtils.drawRoundedRect(
            guiGraphics.pose(), this.何友何树何何树友何树, this.何树何树友树树何树何, this.树树何友树友何树友友, this.友何何何树树友树何友, 5.0, new Color(30, 30, 30, (int)(220.0F * keyboardAlpha))
         );
         if (keyboardAlpha >= 0.1F) {
            Iterator closeButtonOpacity = this.何友友何树树树何友友.iterator();
            if (closeButtonOpacity.hasNext()) {
               何友友友树友何友树何.树友何友友何友何树友 key = (何友友友树友何友树何.树友何友友何友何树友)closeButtonOpacity.next();
               key.c(guiGraphics, mouseX, mouseY, virtualKeyFont, this.何树何树友树树何树何, keyboardAlpha);
            }
         }
      }

      if (this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.何何何友何何何友何何 || this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.树何友何友树树友友树) {
         float maxY = this.友何树何友何友友树树;
         float relativePos = (this.何何树树何树树何树何 - -40.0F) / (maxY - -40.0F);
         this.t(relativePos);
      }

      float closeButtonOpacity = this.友树友何何何树友友树 ? 1.0F : 0.0F;
      boolean hoveringClose = this.b(this.树何友友何友何友何友, this.何何树树何树树何树何, 80.0F, 30.0F, mouseX, mouseY);
      if (hoveringClose != this.树友何友树树友友友树) {
         this.树友何友树树友友友树 = hoveringClose;
      }

      Color closeBaseColor = new Color(60, 60, 60, 255);
      Color closeHoverColor = new Color(80, 80, 80, 255);
      int closeR = (int)友友友树何友树友树友.B((float)closeBaseColor.getRed(), (float)closeHoverColor.getRed(), this.友何何友何友何何树何);
      int closeG = (int)友友友树何友树友树友.B((float)closeBaseColor.getGreen(), (float)closeHoverColor.getGreen(), this.友何何友何友何何树何);
      int closeB = (int)友友友树何友树友树友.B((float)closeBaseColor.getBlue(), (float)closeHoverColor.getBlue(), this.友何何友何友何何树何);
      Color closeBgColor = new Color(closeR, closeG, closeB, (int)(255.0F * closeButtonOpacity));
      RenderUtils.drawRoundedRect(guiGraphics.pose(), this.树何友友何友何友何友, this.何何树树何树树何树何, 80.0, 30.0, 3.0, closeBgColor);
      closeButtonFont.h(
         guiGraphics.pose(),
         "Close",
         this.树何友友何友何友何友 + 40.0F,
         this.何何树树何树树何树何 + 15.0F - closeButtonFont.x() / 2,
         new Color(220, 220, 220, (int)(255.0F * closeButtonOpacity)).getRGB()
      );
      if ((this.何友树友树友何树友何 || this.何树何友何友何友友树) && this.友树树何友树树友何树 != null && this.友树树树树友树友友树 != null && this.树友友友何树何友何友 > 0.01F) {
         float menuX = this.树友友友树友友友何树;
         float menuY = this.友何何友树友树树友友;
         if (menuX + 150.0F > super.width) {
            menuX = super.width - 150.0F;
         }

         if (menuY + 150.0F + 20.0F > super.height) {
            menuY = super.height - 150.0F - 20.0F;
         }

         if (menuX < 0.0F) {
            menuX = 0.0F;
         }

         if (menuY < 0.0F) {
            menuY = 0.0F;
         }

         int animatedAlpha = (int)(230.0F * this.树友友友何树何友何友);
         float listY = menuY + 20.0F;
         RenderUtils.drawRoundedRect(guiGraphics.pose(), menuX, menuY, 150.0, 20.0, 3.0, new Color(25, 25, 25, animatedAlpha));
         contextMenuSearchFont.q(
            guiGraphics.pose(),
            this.友何友树树友何树友树 + (this.何何树友友树何树树树 && System.currentTimeMillis() / 500L % 2L == 0L ? "_" : ""),
            menuX + 4.0F,
            menuY + (20.0F - contextMenuSearchFont.x()) / 2.0F,
            new Color(200, 200, 200, animatedAlpha).getRGB()
         );
         RenderUtils.drawRoundedRect(guiGraphics.pose(), menuX, listY, 150.0, 150.0, 3.0, new Color(30, 30, 30, animatedAlpha));
         guiGraphics.enableScissor((int)menuX + 1, (int)listY + 1, (int)(menuX + 150.0F - 2.0F), (int)(listY + 150.0F - 2.0F));
         float itemHeight = contextMenuModuleFont.x() + 4;
         float currentItemY = listY + 2.0F - this.树树友友友何友友何友;
         if (this.友树树树树友树友友树 != null) {
            Iterator totalContentHeight = this.友树树树树友树友友树.iterator();
            if (totalContentHeight.hasNext()) {
               Module module = (Module)totalContentHeight.next();
               if (currentItemY + itemHeight > listY && currentItemY < listY + 150.0F) {
                  boolean isHoveringItem = mouseX >= menuX
                     && mouseX <= menuX + 150.0F
                     && mouseY >= currentItemY
                     && mouseY <= currentItemY + itemHeight
                     && mouseY >= listY + 1.0F
                     && mouseY <= listY + 150.0F - 1.0F;
                  if (isHoveringItem) {
                     RenderUtils.drawRoundedRect(
                        guiGraphics.pose(), menuX + 1.0F, currentItemY, 148.0, itemHeight, 2.0, new Color(80, 80, 80, (int)(180.0F * this.树友友友何树何友何友))
                     );
                  }

                  Color textColor = module.r() == this.友树树何友树树友何树.何树友树树树友友友树 ? Color.CYAN : Color.WHITE;
                  String moduleDisplayName = module.A();
                  contextMenuModuleFont.q(
                     guiGraphics.pose(),
                     moduleDisplayName,
                     menuX + 5.0F,
                     currentItemY + 2.0F,
                     new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), (int)(255.0F * this.树友友友何树何友何友)).getRGB()
                  );
               }

               float var10000 = currentItemY + itemHeight;
            }
         }

         guiGraphics.disableScissor();
         float totalContentHeight = this.友树树树树友树友友树.size() * itemHeight;
         if (totalContentHeight > 150.0F) {
            float scrollBarHeight = Math.max(10.0F, 150.0F / totalContentHeight * 150.0F);
            float scrollBarY = listY
               + (totalContentHeight - 150.0F == 0.0F ? 0.0F : this.树树友友友何友友何友 / (totalContentHeight - 150.0F)) * (150.0F - scrollBarHeight);
            RenderUtils.drawRectangle(
               guiGraphics.pose(), menuX + 150.0F - 5.0F, scrollBarY, 3.0F, scrollBarHeight, new Color(100, 100, 100, (int)(200.0F * this.树友友友何树何友何友)).getRGB()
            );
         }
      }
   }

   private void k(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      ClientUtils.D(131325480669526L);
      e();
      何何友友树何树何友树 regularFont = Cherish.instance.t().H(14);
      何何友友树何树何友树 placeholderFont = Cherish.instance.t().H(14);
      Color bgColor = new Color(60, 60, 60, 255);
      Color borderColor = new Color(100, 100, 100, 255);
      RenderUtils.drawRectangle(guiGraphics.pose(), this.树何友树友友树树何友, this.友何友友何友树何何何, 120.0F, 20.0F, bgColor.getRGB());
      RenderUtils.drawRectangle(guiGraphics.pose(), this.树何友树友友树树何友, this.友何友友何友树何何何 + 20.0F - 1.0F, 120.0F, 1.0F, borderColor.getRGB());
      String displaySearchText = this.何何友友友友友何友树;
      if (this.树友何树友何树友何友) {
         displaySearchText = displaySearchText + (System.currentTimeMillis() / 500L % 2L == 0L ? "_" : "");
      }

      float textX = this.树何友树友友树树何友 + 4.0F;
      float textY = this.友何友友何友树何何何 + (20.0F - regularFont.x()) / 2.0F;
      if (this.何何友友友友友何友树.isEmpty() && !this.树友何树友何树友何友) {
         placeholderFont.q(
            guiGraphics.pose(), "Search modules...", textX, this.友何友友何友树何何何 + (20.0F - placeholderFont.x()) / 2.0F, new Color(150, 150, 150).getRGB()
         );
      }

      String clippedText = regularFont.v(displaySearchText, 112);
      if (!clippedText.equals(displaySearchText) && clippedText.endsWith("...") && displaySearchText.endsWith("_")) {
         clippedText = regularFont.v(displaySearchText.substring(0, displaySearchText.length() - 1), 112 - regularFont.D("_")) + "_";
      }

      regularFont.q(guiGraphics.pose(), clippedText, textX, textY, Color.WHITE.getRGB());
   }

   private float t(float progress) {
      e();
      return 1.0F;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void v(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      ClientUtils.D(131325480669526L);
      何何友友树何树何友树 buttonFont = Cherish.instance.t().H(16);
      boolean hoveringConfig = this.b(this.何树何何树何友友树何, this.树友何树友树树何何友, 80.0F, 20.0F, mouseX, mouseY);
      if (hoveringConfig != this.友何何树何友友树树树) {
         this.友何何树何友友树树树 = hoveringConfig;
      }

      Color baseColor = new Color(60, 60, 60, 255);
      Color hoverColor = new Color(80, 80, 80, 255);
      int r = (int)友友友树何友树友树友.B((float)baseColor.getRed(), (float)hoverColor.getRed(), this.树友树树何友友何树友);
      int g = (int)友友友树何友树友树友.B((float)baseColor.getGreen(), (float)hoverColor.getGreen(), this.树友树树何友友何树友);
      int b = (int)友友友树何友树友树友.B((float)baseColor.getBlue(), (float)hoverColor.getBlue(), this.树友树树何友友何树友);
      Color configBgColor = new Color(r, g, b, 255);
      RenderUtils.drawRectangle(guiGraphics.pose(), this.何树何何树何友友树何, this.树友何树友树树何何友, 80.0F, 20.0F, configBgColor.getRGB());
      Color accentColor = new Color(100, 100, 100, 255);
      RenderUtils.drawRectangle(guiGraphics.pose(), this.何树何何树何友友树何, this.树友何树友树树何何友 + 20.0F - 2.0F, 80.0F, 2.0F, accentColor.getRGB());
      buttonFont.h(guiGraphics.pose(), "Config", this.何树何何树何友友树何 + 40.0F, this.树友何树友树树何何友 + 10.0F - buttonFont.x() / 2, new Color(220, 220, 220).getRGB());
   }

   private void q(树何友友何树友友何何 newCategory) {
      e();
      if (this.友友何何树树友树友树 != newCategory) {
         this.何树树友友树友友友友 = this.友友何何树树友树友树;
         this.友友何何树树友树友树 = newCategory;
         this.友树树树何友友树何何 = true;
         this.何友树何何何树树何何 = 0.0F;
         this.树树何何何友树树何友 = System.currentTimeMillis();
      }
   }

   private void u() {
      e();
      if (this.树友何友树树友友友树) {
         this.友何何友何友何何树何 = Math.min(1.0F, this.友何何友何友何何树何 + 0.1F);
      }

      this.友何何友何友何何树何 = Math.max(0.0F, this.友何何友何友何何树何 - 0.1F);
      if (this.树何友何友友树友树何) {
         long elapsedTime = System.currentTimeMillis() - this.树友何何何何友何何友;
         if (this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.树何友何友树树友友树) {
            this.友何何友何何友树树何 = Math.min(1.0F, (float)elapsedTime / 400.0F);
            float progress = this.t(this.友何何友何何友树树何);
            this.何何树树何树树何树何 = 友友友树何友树友树友.B(-40.0F, this.友何树何友何友友树树, progress);
            float startYKeyboard = -this.友何何何树树友树何友 - 10.0F;
            this.何树何树友树树何树何 = 友友友树何友树友树友.B(startYKeyboard, this.何树树树友友何友树何, progress);
            if (this.友何何友何何友树树何 >= 1.0F) {
               this.友何何友何何友树树何 = 1.0F;
               this.树何友何友友树友树何 = false;
               this.树何友友树树友树树何 = 何友友友树友何友树何.树友何树何树树友何树.树树树树友友何友友何;
            }
         }

         if (this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.何何何友何何何友何何) {
            this.友何何友何何友树树何 = Math.max(0.0F, 1.0F - (float)elapsedTime / 400.0F);
            float progress = this.t(1.0F - this.友何何友何何友树树何);
            this.何何树树何树树何树何 = 友友友树何友树友树友.B(this.友何树何友何友友树树, -40.0F, progress);
            float endYKeyboard = -this.友何何何树树友树何友 - 10.0F;
            this.何树何树友树树何树何 = 友友友树何友树友树友.B(this.何树树树友友何友树何, endYKeyboard, progress);
            if (this.友何何友何何友树树何 <= 0.0F) {
               this.友何何友何何友树树何 = 0.0F;
               this.树何友何友友树友树何 = false;
               this.树何友友树树友树树何 = 何友友友树友何友树何.树友何树何树树友何树.何友何何何友友何何友;
               this.树友友树友友友树何树 = 0.0F;
               this.树何友树树何何何友友 = System.currentTimeMillis();
            }
         }
      }

      if (this.友树友何何何树友友树) {
         this.何何树树何树树何树何 = this.友何树何友何友友树树;
         this.何树何树友树树何树何 = this.何树树树友友何友树何;
      }

      this.何何树树何树树何树何 = -40.0F;
      if (super.height > 0 && this.友何何何树树友树何友 > 0.0F) {
         this.何树何树友树树何树何 = -this.友何何何树树友树何友 - 10.0F;
      }

      this.何树何树友树树何树何 = -500.0F;
   }

   private void r() {
      e();
      if (mc != null && mc.getWindow() != null) {
         int screenWidth = mc.getWindow().getGuiScaledWidth();
         int screenHeight = mc.getWindow().getGuiScaledHeight();
         this.友树友友何友树树树树 = screenWidth - 80.0F - 10.0F;
         this.何何何友树树友何何何 = screenHeight - 20.0F - 10.0F;
         this.树树友何友树树树友何 = this.友树友友何友树树树树 - 80.0F - 5.0F;
         this.何友友树树树友树树友 = this.何何何友树树友何何何;
         this.友树何何树树树友友何 = this.树树友何友树树树友何 - 80.0F - 5.0F;
         this.树友何树友树树何何友 = this.何友友树树树友树树友;
         this.友树友友友何树树树友 = this.友树何何树树树友友何 - 120.0F - 5.0F;
         this.友何友友何友树何何何 = this.树友何树友树树何何友;
         this.树何友友何友何友何友 = screenWidth / 2 - 40.0F;
         this.友何树何友何友友树树 = 10.0F;
      }
   }

   private void r(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      ClientUtils.D(131325480669526L);
      何何友友树何树何友树 buttonFont = Cherish.instance.t().H(16);
      boolean hoveringKeyBind = this.b(this.友树何树树树友何树何, this.何何何友树树友何何何, 80.0F, 20.0F, mouseX, mouseY);
      if (hoveringKeyBind != this.何树树何何友友树何友) {
         this.何树树何何友友树何友 = hoveringKeyBind;
      }

      Color baseColor = new Color(60, 60, 60, 255);
      Color hoverColor = new Color(80, 80, 80, 255);
      int r = (int)友友友树何友树友树友.B((float)baseColor.getRed(), (float)hoverColor.getRed(), this.友友何友树何友友树友);
      int g = (int)友友友树何友树友树友.B((float)baseColor.getGreen(), (float)hoverColor.getGreen(), this.友友何友树何友友树友);
      int b = (int)友友友树何友树友树友.B((float)baseColor.getBlue(), (float)hoverColor.getBlue(), this.友友何友树何友友树友);
      Color keyBindBgColor = new Color(r, g, b, 255);
      RenderUtils.drawRectangle(guiGraphics.pose(), this.友树何树树树友何树何, this.何何何友树树友何何何, 80.0F, 20.0F, keyBindBgColor.getRGB());
      Color accentColor = new Color(100, 100, 100, 255);
      RenderUtils.drawRectangle(guiGraphics.pose(), this.友树何树树树友何树何, this.何何何友树树友何何何 + 20.0F - 2.0F, 80.0F, 2.0F, accentColor.getRGB());
      buttonFont.h(guiGraphics.pose(), "Key Bind", this.友树何树树树友何树何 + 40.0F, this.何何何友树树友何何何 + 10.0F - buttonFont.x() / 2, new Color(220, 220, 220).getRGB());
   }

   private void y() {
      this.何友树友树友何树友何 = true;
      this.树何友友树何何树友友 = true;
      this.何树何友何友何友友树 = false;
      this.树友友友何树何友何友 = 0.0F;
      this.友树树树何友树友树树 = System.currentTimeMillis();
      this.树树友友友何友友何友 = 0.0F;
      this.I();
   }

   private void L() {
      e();
      long elapsedTime = System.currentTimeMillis() - this.树何友树树何何何友友;
      if (this.何何何何友何树友友树) {
         this.树友友树友友友树何树 = Math.max(0.0F, 1.0F - (float)elapsedTime / 300.0F);
      }

      this.树友友树友友友树何树 = Math.min(1.0F, (float)elapsedTime / 300.0F);
   }

   private List<友友友何友友何何树树> L(树何友友何树友友何何 category) {
      e();
      if (category == null) {
         return new ArrayList<>();
      } else {
         List<友友友何友友何何树树> allRects = this.何何树树何何树树友树.computeIfAbsent(category, k -> {
            List<友友友何友友何何树树> newRects = new ArrayList<>();
            Cherish.instance.getModuleManager().Z(k).forEach(m -> {
               友友友何友友何何树树 rect = new 友友友何友友何何树树(m);
               newRects.add(rect);
            });
            newRects.forEach(友友友何友友何何树树::K);
            return newRects;
         });
         if (this.何何友友友友友何友树 != null && !this.何何友友友友友何友树.isEmpty()) {
            String searchLower = this.何何友友友友友何友树.toLowerCase();
            return allRects.stream().filter(rect -> {
               e();
               return rect.d().A().toLowerCase().contains(searchLower) || rect.d().B().toLowerCase().contains(searchLower);
            }).collect(Collectors.toList());
         } else {
            return allRects;
         }
      }
   }

   private boolean L() {
      e();
      return this.何何何何友何树友友树 ? this.树友友树友友友树何树 <= 0.0F : this.树友友树友友友树何树 >= 1.0F;
   }

   private Map<String, Integer> L() {
      e();
      Map<String, Integer> map = new HashMap<>();
      map.put("none", 0);
      Field[] var5 = GLFW.class.getFields();
      int var6 = var5.length;
      int var7 = 0;
      if (0 < var6) {
         Field field = var5[0];
         if (Modifier.isStatic(field.getModifiers()) && field.getName().startsWith("GLFW_KEY_")) {
            field.setAccessible(true);

            try {
               map.put(field.getName().substring(9).toLowerCase(), (Integer)field.get(null));
            } catch (IllegalAccessException var10) {
               var10.printStackTrace();
            }
         }

         var7++;
      }

      return map;
   }

   private void N() {
      e();
      if (mc != null && mc.getWindow() != null) {
         int screenWidth = mc.getWindow().getGuiScaledWidth();
         if (this.何树树何何友友树何友) {
            this.友友何友树何友友树友 = Math.min(1.0F, this.友友何友树何友友树友 + 0.1F);
         }

         this.友友何友树何友友树友 = Math.max(0.0F, this.友友何友树何友友树友 - 0.1F);
         if (this.何树友友友树树友友树) {
            this.树树何友树何树友友树 = Math.min(1.0F, this.树树何友树何树友友树 + 0.1F);
         }

         this.树树何友树何树友友树 = Math.max(0.0F, this.树树何友树何树友友树 - 0.1F);
         if (this.友何何树何友友树树树) {
            this.树友树树何友友何树友 = Math.min(1.0F, this.树友树树何友友何树友 + 0.1F);
         }

         this.树友树树何友友何树友 = Math.max(0.0F, this.树友树树何友友何树友 - 0.1F);
         float targetKeyBindX = this.友树友友何友树树树树;
         float targetSnakeGameX = this.树树友何友树树树友何;
         float targetConfigButtonX = this.友树何何树树树友友何;
         float targetSearchBarX = this.友树友友友何树树树友;
         float startX = screenWidth + 10;
         if (this.友树友何何何树友友树 || this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.树何友何友树树友友树 && this.树何友何友友树友树何) {
            if (this.树何友何友友树友树何 && this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.树何友何友树树友友树) {
               ;
            }

            this.友树何树树树友何树何 = 友友友树何友树友树友.B(targetKeyBindX, startX, this.t(1.0F));
            this.何树友何友树友何友友 = 友友友树何友树友树友.B(targetSnakeGameX, startX, this.t(1.0F));
            this.何树何何树何友友树何 = 友友友树何友树友树友.B(targetConfigButtonX, startX, this.t(1.0F));
            this.树何友树友友树树何友 = 友友友树何友树友树友.B(targetSearchBarX, startX, this.t(1.0F));
         }

         if (this.何何何何友何树友友树) {
            float progress = 1.0F - this.树友友树友友友树何树;
            this.友树何树树树友何树何 = 友友友树何友树友树友.B(targetKeyBindX, startX, this.t(progress));
            this.何树友何友树友何友友 = 友友友树何友树友树友.B(targetSnakeGameX, startX, this.t(progress));
            this.何树何何树何友友树何 = 友友友树何友树友树友.B(targetConfigButtonX, startX, this.t(progress));
            this.树何友树友友树树何友 = 友友友树何友树友树友.B(targetSearchBarX, startX, this.t(progress));
         }

         this.友树何树树树友何树何 = 友友友树何友树友树友.B(startX, targetKeyBindX, this.t(this.树友友树友友友树何树));
         this.何树友何友树友何友友 = 友友友树何友树友树友.B(startX, targetSnakeGameX, this.t(this.树友友树友友友树何树));
         this.何树何何树何友友树何 = 友友友树何友树友树友.B(startX, targetConfigButtonX, this.t(this.树友友树友友友树何树));
         this.树何友树友友树树何友 = 友友友树何友树友树友.B(startX, targetSearchBarX, this.t(this.树友友树友友友树何树));
      }
   }

   private void H() {
      e();
      this.何友友何树树树何友友.clear();
      if (mc != null && mc.getWindow() != null && super.width != 0 && super.height != 0) {
         Map<String, Integer> glfwKeyMap = this.L();
         if (!glfwKeyMap.isEmpty()) {
            String[][] keyLayout = new String[][]{
               {
                     "ESC",
                     "escape",
                     "F1",
                     "f1",
                     "F2",
                     "f2",
                     "F3",
                     "f3",
                     "F4",
                     "f4",
                     "F5",
                     "f5",
                     "F6",
                     "f6",
                     "F7",
                     "f7",
                     "F8",
                     "f8",
                     "F9",
                     "f9",
                     "F10",
                     "f10",
                     "F11",
                     "f11",
                     "F12",
                     "f12"
               },
               {
                     "`",
                     "grave_accent",
                     "1",
                     "1",
                     "2",
                     "2",
                     "3",
                     "3",
                     "4",
                     "4",
                     "5",
                     "5",
                     "6",
                     "6",
                     "7",
                     "7",
                     "8",
                     "8",
                     "9",
                     "9",
                     "0",
                     "0",
                     "-",
                     "minus",
                     "=",
                     "equal",
                     "Backspace",
                     "backspace"
               },
               {
                     "Tab",
                     "tab",
                     "Q",
                     "q",
                     "W",
                     "w",
                     "E",
                     "e",
                     "R",
                     "r",
                     "T",
                     "t",
                     "Y",
                     "y",
                     "U",
                     "u",
                     "I",
                     "i",
                     "O",
                     "o",
                     "P",
                     "p",
                     "[",
                     "left_bracket",
                     "]",
                     "right_bracket",
                     "\\",
                     "backslash"
               },
               {
                     "Caps",
                     "caps_lock",
                     "A",
                     "a",
                     "S",
                     "s",
                     "D",
                     "d",
                     "F",
                     "f",
                     "G",
                     "g",
                     "H",
                     "h",
                     "J",
                     "j",
                     "K",
                     "k",
                     "L",
                     "l",
                     ";",
                     "semicolon",
                     "'",
                     "apostrophe",
                     "Enter",
                     "enter"
               },
               {
                     "LShift",
                     "left_shift",
                     "Z",
                     "z",
                     "X",
                     "x",
                     "C",
                     "c",
                     "V",
                     "v",
                     "B",
                     "b",
                     "N",
                     "n",
                     "M",
                     "m",
                     ",",
                     "comma",
                     ".",
                     "period",
                     "/",
                     "slash",
                     "RShift",
                     "right_shift"
               },
               {
                     "LCtrl",
                     "left_control",
                     "LWin",
                     "left_super",
                     "LAlt",
                     "left_alt",
                     "Space",
                     "space",
                     "RAlt",
                     "right_alt",
                     "Menu",
                     "menu",
                     "RCtrl",
                     "right_control"
               }
            };
            List<List<何友友友树友何友树何.何友树何友何何树友树>> tempKeyLayoutDefinitions = new ArrayList<>();
            float currentRelativeY = 0.0F;
            float mainBlockMaxRowWidth = 0.0F;
            int i = 0;
            if (0 < keyLayout.length) {
               List<何友友友树友何友树何.何友树何友何何树友树> currentRowDefinitions = new ArrayList<>();
               float currentRelativeX = 0.0F;
               String[] row = keyLayout[0];
               int j = 0;
               if (0 < row.length) {
                  String displayName = row[0];
                  String internalName = row[1];
                  float w = 22.0F;
                  if (internalName.equals("backspace")) {
                     w = 44.0F;
                  }

                  if (internalName.equals("tab")) {
                     w = 33.0F;
                  }

                  if (internalName.equals("backslash")) {
                     w = 33.0F;
                  }

                  if (internalName.equals("caps_lock")) {
                     w = 38.5F;
                  }

                  if (internalName.equals("enter")) {
                     w = 49.5F;
                  }

                  if (internalName.equals("left_shift")) {
                     w = 49.5F;
                  }

                  if (internalName.equals("right_shift")) {
                     w = 60.5F;
                  }

                  if (internalName.equals("left_control")
                     || internalName.equals("right_control")
                     || internalName.equals("left_super")
                     || internalName.equals("menu")) {
                     w = 27.5F;
                  }

                  if (internalName.equals("left_alt") || internalName.equals("right_alt")) {
                     w = 27.5F;
                  }

                  if (internalName.equals("space")) {
                     w = 132.0F;
                  }

                  if (displayName.equals("ESC")) {
                     w = 33.0F;
                  }

                  if (displayName.startsWith("F")) {
                     w = 22.0F;
                     if (displayName.equals("F4") || displayName.equals("F8")) {
                        currentRelativeX = 11.0F;
                     }
                  }

                  currentRowDefinitions.add(new 何友友友树友何友树何.何友树何友何何树友树(displayName, internalName, currentRelativeX, 0.0F, w, 22.0F));
                  currentRelativeX += w + 3.0F;
                  j += 2;
               }

               if (currentRelativeX - 3.0F > 0.0F) {
                  mainBlockMaxRowWidth = currentRelativeX - 3.0F;
               }

               tempKeyLayoutDefinitions.add(currentRowDefinitions);
               currentRelativeY = 31.0F;
               i++;
            }

            float keysBlockHeight = currentRelativeY - 3.0F;
            float navigationBlockStartX = mainBlockMaxRowWidth + 12.0F;
            何友友友树友何友树何.何友树何友何何树友树 keyInsert = new 何友友友树友何友树何.何友树何友何何树友树("Ins", "insert", navigationBlockStartX, 0.0F, 22.0F, 22.0F);
            何友友友树友何友树何.何友树何友何何树友树 keyHome = new 何友友友树友何友树何.何友树何友何何树友树("Home", "home", navigationBlockStartX + 22.0F + 3.0F, 0.0F, 22.0F, 22.0F);
            何友友友树友何友树何.何友树何友何何树友树 keyPgUp = new 何友友友树友何友树何.何友树何友何何树友树("PgUp", "page_up", navigationBlockStartX + 50.0F, 0.0F, 22.0F, 22.0F);
            何友友友树友何友树何.何友树何友何何树友树 keyDel = new 何友友友树友何友树何.何友树何友何何树友树("Del", "delete", navigationBlockStartX, 25.0F, 22.0F, 22.0F);
            何友友友树友何友树何.何友树何友何何树友树 keyEnd = new 何友友友树友何友树何.何友树何友何何树友树("End", "end", navigationBlockStartX + 22.0F + 3.0F, 25.0F, 22.0F, 22.0F);
            何友友友树友何友树何.何友树何友何何树友树 keyPgDn = new 何友友友树友何友树何.何友树何友何何树友树("PgDn", "page_down", navigationBlockStartX + 50.0F, 25.0F, 22.0F, 22.0F);
            float arrowBlockStartY = keyDel.友树友树何何何友何友 + keyDel.何何友树树树友树何树 + 57.0F + 2.0F;
            何友友友树友何友树何.何友树何友何何树友树 keyUp = new 何友友友树友何友树何.何友树何友何何树友树("↑", "up", navigationBlockStartX + 22.0F + 3.0F, arrowBlockStartY, 22.0F, 22.0F);
            何友友友树友何友树何.何友树何友何何树友树 keyLeft = new 何友友友树友何友树何.何友树何友何何树友树("←", "left", navigationBlockStartX, arrowBlockStartY + 22.0F + 3.0F, 22.0F, 22.0F);
            何友友友树友何友树何.何友树何友何何树友树 keyDown = new 何友友友树友何友树何.何友树何友何何树友树(
               "↓", "down", navigationBlockStartX + 22.0F + 3.0F, arrowBlockStartY + 22.0F + 3.0F, 22.0F, 22.0F
            );
            何友友友树友何友树何.何友树何友何何树友树 keyRight = new 何友友友树友何友树何.何友树何友何何树友树(
               "→", "right", navigationBlockStartX + 50.0F, arrowBlockStartY + 22.0F + 3.0F, 22.0F, 22.0F
            );
            float totalKeysWidth = navigationBlockStartX + 72.0F;
            float var36 = Math.max(keysBlockHeight, keyDown.友树友树何何何友何友 + keyDown.何何友树树树友树何树);
            this.树树何友树友何树友友 = totalKeysWidth + 20.0F;
            this.友何何何树树友树何友 = var36 + 20.0F;
            this.何友何树何何树友何树 = (super.width - this.树树何友树友何树友友) / 2.0F;
            this.何树树树友友何友树何 = (super.height - this.友何何何树树友树何友) / 2.0F;
            float var10000;
            if (this.友何树何友何友友树树 > 0.0F) {
               Objects.requireNonNull(this);
               var10000 = this.友何树何友何友友树树 + 30.0F + 20.0F;
            } else {
               var10000 = 40.0F;
            }

            float topLimitY = var10000;
            if (this.何树树树友友何友树何 < topLimitY) {
               this.何树树树友友何友树何 = topLimitY;
            }

            Iterator var30 = tempKeyLayoutDefinitions.iterator();
            if (var30.hasNext()) {
               List<何友友友树友何友树何.何友树何友何何树友树> rowDefs = (List<何友友友树友何友树何.何友树何友何何树友树>)var30.next();
               Iterator var32 = rowDefs.iterator();
               if (var32.hasNext()) {
                  何友友友树友何友树何.何友树何友何何树友树 def = (何友友友树友何友树何.何友树何友何何树友树)var32.next();
                  this.何友友何树树树何友友
                     .add(new 何友友友树友何友树何.树友何友友何友何树友(def.何何友友何何友友何树, def.树何树友树何何友友树, def.何友友树树树友树树友, def.友树友树何何何友何友, def.何何树树树友友何友何, def.何何友树树树友树何树, glfwKeyMap));
               }
            }

            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyInsert.何何友友何何友友何树,
                     keyInsert.树何树友树何何友友树,
                     keyInsert.何友友树树树友树树友,
                     keyInsert.友树友树何何何友何友,
                     keyInsert.何何树树树友友何友何,
                     keyInsert.何何友树树树友树何树,
                     glfwKeyMap
                  )
               );
            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyHome.何何友友何何友友何树, keyHome.树何树友树何何友友树, keyHome.何友友树树树友树树友, keyHome.友树友树何何何友何友, keyHome.何何树树树友友何友何, keyHome.何何友树树树友树何树, glfwKeyMap
                  )
               );
            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyPgUp.何何友友何何友友何树, keyPgUp.树何树友树何何友友树, keyPgUp.何友友树树树友树树友, keyPgUp.友树友树何何何友何友, keyPgUp.何何树树树友友何友何, keyPgUp.何何友树树树友树何树, glfwKeyMap
                  )
               );
            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyDel.何何友友何何友友何树, keyDel.树何树友树何何友友树, keyDel.何友友树树树友树树友, keyDel.友树友树何何何友何友, keyDel.何何树树树友友何友何, keyDel.何何友树树树友树何树, glfwKeyMap
                  )
               );
            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyEnd.何何友友何何友友何树, keyEnd.树何树友树何何友友树, keyEnd.何友友树树树友树树友, keyEnd.友树友树何何何友何友, keyEnd.何何树树树友友何友何, keyEnd.何何友树树树友树何树, glfwKeyMap
                  )
               );
            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyPgDn.何何友友何何友友何树, keyPgDn.树何树友树何何友友树, keyPgDn.何友友树树树友树树友, keyPgDn.友树友树何何何友何友, keyPgDn.何何树树树友友何友何, keyPgDn.何何友树树树友树何树, glfwKeyMap
                  )
               );
            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyUp.何何友友何何友友何树, keyUp.树何树友树何何友友树, keyUp.何友友树树树友树树友, keyUp.友树友树何何何友何友, keyUp.何何树树树友友何友何, keyUp.何何友树树树友树何树, glfwKeyMap
                  )
               );
            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyLeft.何何友友何何友友何树, keyLeft.树何树友树何何友友树, keyLeft.何友友树树树友树树友, keyLeft.友树友树何何何友何友, keyLeft.何何树树树友友何友何, keyLeft.何何友树树树友树何树, glfwKeyMap
                  )
               );
            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyDown.何何友友何何友友何树, keyDown.树何树友树何何友友树, keyDown.何友友树树树友树树友, keyDown.友树友树何何何友何友, keyDown.何何树树树友友何友何, keyDown.何何友树树树友树何树, glfwKeyMap
                  )
               );
            this.何友友何树树树何友友
               .add(
                  new 何友友友树友何友树何.树友何友友何友何树友(
                     keyRight.何何友友何何友友何树, keyRight.树何树友树何何友友树, keyRight.何友友树树树友树树友, keyRight.友树友树何何何友何友, keyRight.何何树树树友友何友何, keyRight.何何友树树树友树何树, glfwKeyMap
                  )
               );
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "刘凤楠230622109211173513";
   }

   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      e();
      if (mc != null && mc.player != null && mc.level != null) {
         this.r();
         this.L();
         this.u();
         this.Z();
         this.N();
         this.B();
         this.D();
         if (this.何何何何友何树友友树 && this.树友友树友友友树何树 <= 0.0F) {
            super.onClose();
         } else {
            float bgAlpha = Mth.lerp(this.树友友树友友友树何树, 0.0F, 0.4F);
            if (this.友树友何何何树友友树 || this.树何友何友友树友树何) {
               bgAlpha = 0.2F;
            }

            this.C(guiGraphics, bgAlpha);
            if (this.友树友何何何树友友树 || this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.树何友何友树树友友树 || this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.何何何友何何何友何何) {
               this.o(guiGraphics, mouseX, mouseY);
               if (this.友树友何何何树友友树
                  || this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.树何友何友树树友友树 && this.树何友何友友树友树何
                  || this.树何友友树树友树树何 == 何友友友树友何友树何.树友何树何树树友何树.何何何友何何何友何何 && this.树何友何友友树友树何) {
                  return;
               }
            }

            if (this.何何何何友何树友友树) {
               float progress = 1.0F - this.树友友树友友友树何树;
               float smoothProgress = this.t(progress);
               float startX = this.何何友树树友树何何何;
               float var10000 = startX + (-550.0F - startX) * smoothProgress;
            }

            float smoothProgress = this.t(this.树友友树友友友树何树);
            float endX = this.何何友树树友树何何何;
            float animX = -550.0F + (endX - -550.0F) * smoothProgress;
            float contentAreaX = animX + 90.0F;
            Color sidebarColor = new Color(70, 70, 70, 255);
            Color contentBgColor = new Color(45, 45, 45, 235);
            Color cutoutColor = new Color(0, 0, 0, 0);
            RenderUtils.drawRectangle(guiGraphics.pose(), animX, this.友树何何树友树友何友, 90.0F, 350.0F, sidebarColor.getRGB());
            RenderUtils.v(guiGraphics.pose(), animX + 6.0F, this.友树何何树友树友何友 + 6.0F, 6.0F, 0, 360, cutoutColor.getRGB(), 19710175359653L);
            RenderUtils.drawRectangle(guiGraphics.pose(), animX, this.友树何何树友树友何友, 6.0F, 6.0F, cutoutColor.getRGB());
            RenderUtils.v(guiGraphics.pose(), animX + 6.0F, this.友树何何树友树友何友 + 6.0F, 6.0F, 180, 270, sidebarColor.getRGB(), 19710175359653L);
            RenderUtils.v(guiGraphics.pose(), animX + 6.0F, this.友树何何树友树友何友 + 350.0F - 6.0F, 6.0F, 0, 360, cutoutColor.getRGB(), 19710175359653L);
            RenderUtils.drawRectangle(guiGraphics.pose(), animX, this.友树何何树友树友何友 + 350.0F - 6.0F, 6.0F, 6.0F, cutoutColor.getRGB());
            RenderUtils.v(guiGraphics.pose(), animX + 6.0F, this.友树何何树友树友何友 + 350.0F - 6.0F, 6.0F, 90, 180, sidebarColor.getRGB(), 19710175359653L);
            RenderUtils.drawRectangle(guiGraphics.pose(), animX + 6.0F, this.友树何何树友树友何友, 84.0F, 350.0F, sidebarColor.getRGB());
            RenderUtils.drawRectangle(guiGraphics.pose(), animX + 90.0F - 1.0F, this.友树何何树友树友何友, 1.0F, 350.0F, sidebarColor.getRGB());
            RenderUtils.drawRectangle(guiGraphics.pose(), contentAreaX, this.友树何何树友树友何友, 460.0F, 350.0F, contentBgColor.getRGB());
            RenderUtils.v(guiGraphics.pose(), contentAreaX + 460.0F - 6.0F, this.友树何何树友树友何友 + 6.0F, 6.0F, 0, 360, cutoutColor.getRGB(), 19710175359653L);
            RenderUtils.drawRectangle(guiGraphics.pose(), contentAreaX + 460.0F - 6.0F, this.友树何何树友树友何友, 6.0F, 6.0F, cutoutColor.getRGB());
            RenderUtils.v(guiGraphics.pose(), contentAreaX + 460.0F - 6.0F, this.友树何何树友树友何友 + 6.0F, 6.0F, 270, 360, contentBgColor.getRGB(), 19710175359653L);
            RenderUtils.v(
               guiGraphics.pose(), contentAreaX + 460.0F - 6.0F, this.友树何何树友树友何友 + 350.0F - 6.0F, 6.0F, 0, 360, cutoutColor.getRGB(), 19710175359653L
            );
            RenderUtils.drawRectangle(guiGraphics.pose(), contentAreaX + 460.0F - 6.0F, this.友树何何树友树友何友 + 350.0F - 6.0F, 6.0F, 6.0F, cutoutColor.getRGB());
            RenderUtils.v(
               guiGraphics.pose(), contentAreaX + 460.0F - 6.0F, this.友树何何树友树友何友 + 350.0F - 6.0F, 6.0F, 0, 90, contentBgColor.getRGB(), 19710175359653L
            );
            RenderUtils.drawRectangle(guiGraphics.pose(), contentAreaX, this.友树何何树友树友何友, 454.0F, 350.0F, contentBgColor.getRGB());
            RenderUtils.drawRectangle(guiGraphics.pose(), contentAreaX, this.友树何何树友树友何友, 1.0F, 350.0F, contentBgColor.getRGB());
            boolean isEnglish = ClientUtils.D(131325480669526L);
            何何友友树何树何友树 titleAndCategoryFont = Cherish.instance.t().C(20);
            何何友友树何树何友树 iconFont = Cherish.instance.t().r(50);
            何何友友树何树何友树 cherishGuiLabelFont = Cherish.instance.t().C(22);
            iconFont.q(guiGraphics.pose(), "k", animX + 11.5F, this.友树何何树友树友何友 + 8.5F, -1);
            cherishGuiLabelFont.q(guiGraphics.pose(), "Cherish", animX + 31.0F, this.友树何何树友树友何友 + 14.5F, Color.LIGHT_GRAY.getRGB());
            RenderUtils.drawRectangle(guiGraphics.pose(), animX + 5.0F, this.友树何何树友树友何友 + 35.0F, 80.0F, 1.0F, new Color(110, 110, 110).getRGB());
            this.r(guiGraphics, mouseX, mouseY);
            this.v(guiGraphics, mouseX, mouseY);
            this.a(guiGraphics, mouseX, mouseY);
            this.k(guiGraphics, mouseX, mouseY);
            float catHeight = 240.0F / 树何友友何树友友何何.M().length;
            guiGraphics.enableScissor((int)animX, (int)this.友树何何树友树友何友 + 40, (int)(animX + 90.0F), (int)(this.友树何何树友树友何友 + 350.0F - 65.0F));
            树何友友何树友友何何[] var27 = 树何友友何树友友何何.M();
            int var28 = var27.length;
            int var29 = 0;
            if (0 < var28) {
               树何友友何树友友何何 category = var27[0];
               float catY = this.友树何何树友树友何友 + 40.0F + 0.0F;
               boolean hovering = this.b(animX, catY, 90.0F, catHeight, mouseX, mouseY);
               Color categoryColor = hovering ? new Color(200, 200, 200) : new Color(150, 150, 150);
               Color selectColor = this.友友何何树树友树友树 == category ? Color.WHITE : categoryColor;
               if (this.友友何何树树友树友树 == category) {
                  if (this.友树树树何友友树何何 && this.何友树何何何树树何何 < 1.0F) {
                     float easedProgress = this.C(this.何友树何何何树树何何);
                     float slideWidth = 90.0F * easedProgress;
                     RenderUtils.drawRectangle(guiGraphics.pose(), animX, catY, slideWidth, catHeight, new Color(40, 40, 40).getRGB());
                     float gradientWidth = Math.min(10.0F, 90.0F - slideWidth);
                     if (gradientWidth > 0.0F) {
                        int i = 0;
                        if (0.0F < gradientWidth) {
                           float alpha = 1.0F - 0.0F / gradientWidth;
                           Color gradientColor = new Color(40, 40, 40, (int)(255.0F * alpha));
                           RenderUtils.drawRectangle(guiGraphics.pose(), animX + slideWidth + 0.0F, catY, 1.0F, catHeight, gradientColor.getRGB());
                           i++;
                        }
                     }
                  }

                  RenderUtils.drawRectangle(guiGraphics.pose(), animX, catY, 90.0F, catHeight, new Color(40, 40, 40).getRGB());
               }

               if (this.友树树树何友友树何何 && this.何树树友友树友友友友 == category) {
                  float easedProgress = this.C(this.何友树何何何树树何何);
                  float remainingWidth = 90.0F * (1.0F - easedProgress);
                  if (remainingWidth > 0.0F) {
                     RenderUtils.drawRectangle(guiGraphics.pose(), animX, catY, remainingWidth, catHeight, new Color(40, 40, 40).getRGB());
                     float gradientWidth = Math.min(10.0F, remainingWidth);
                     int i = 0;
                     if (0.0F < gradientWidth) {
                        float alpha = 0.0F / gradientWidth;
                        Color gradientColor = new Color(40, 40, 40, (int)(255.0F * alpha));
                        RenderUtils.drawRectangle(guiGraphics.pose(), animX + remainingWidth - 0.0F - 1.0F, catY, 1.0F, catHeight, gradientColor.getRGB());
                        i++;
                     }
                  }
               }

               String categoryNameString = isEnglish ? category.树友何何友树友友何树 : category.何何何树何何何树友友;
               titleAndCategoryFont.q(
                  guiGraphics.pose(), categoryNameString, animX + 8.0F, catY + catHeight / 2.0F - titleAndCategoryFont.x() / 2.0F, selectColor.getRGB()
               );
               float var54 = 0.0F + catHeight;
               var29++;
            }

            guiGraphics.disableScissor();
            this.m(guiGraphics, animX, this.友树何何树友树友何友, 90.0F, 350.0F);
            this.树树何何何树友友何树.树友何友树友何友何友 = this.友友何何树树友树友树;
            this.树树何何何树友友何树.z(this.L(this.友友何何树树友树友树));
            this.树树何何何树友友何树.树友树树友树何树何树 = animX;
            this.树树何何何树友友何树.何何友友何树树树何树 = this.友树何何树友树友何友;
            this.树树何何何树友友何树.友友友友友树何树何树 = 350.0F;
            this.树树何何何树友友何树.树树何友何树友树树何 = 550.0F;
            this.树树何何何树友友何树.H(guiGraphics, mouseX, mouseY, partialTicks);
            this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.何何树友友树何树树树 || this.树何友树树何友树何树 || this.树友何树友何树友何友;
            this.I(guiGraphics, mouseX, mouseY);
            if (this.树何树友何树树树友树) {
               this.何何友树树友树何何何 = mouseX - this.何何友何友何何何树树;
               this.友树何何树友树友何友 = mouseY - this.树友树友何友何友树何;
            }
         }
      }
   }

   public boolean isPauseScreen() {
      return false;
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      e();
      if (keyCode == 256) {
         if (this.树友何树友何树友何友) {
            this.树友何树友何树友何友 = false;
            this.何何友友友友友何友树 = "";
            this.树树何何何树友友何树.c();
            this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.何何树友友树何树树树 || this.树何友树树何友树何树;
            return true;
         } else if (this.树何友树树何友树何树) {
            this.树何友树树何友树何树 = false;
            this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.何何树友友树何树树树 || this.树友何树友何树友何友;
            return true;
         } else if (this.树友何友何友友树树树 || this.友何友何友何何何友树) {
            this.h();
            return true;
         } else if (this.何何树友友树何树树树) {
            this.何何树友友树何树树树 = false;
            this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.树何友树树何友树何树 || this.树友何树友何树友何友;
            return true;
         } else if (this.何友树友树友何树友何 || this.何树何友何友何友友树) {
            this.s();
            return true;
         } else if (this.友树友何何何树友友树) {
            this.x();
            return true;
         } else {
            this.何何何何友何树友友树 = true;
            this.树何友树树何何何友友 = System.currentTimeMillis();
            return true;
         }
      } else if (this.树友何树友何树友何友) {
         if (keyCode == 257 || keyCode == 335) {
            this.树友何树友何树友何友 = false;
            this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.何何树友友树何树树树 || this.树何友树树何友树何树;
            return true;
         } else if (keyCode == 259) {
            if (!this.何何友友友友友何友树.isEmpty()) {
               this.何何友友友友友何友树 = this.何何友友友友友何友树.substring(0, this.何何友友友友友何友树.length() - 1);
               this.树树何何何树友友何树.c();
            }

            return true;
         } else {
            return true;
         }
      } else if (this.树何友树树何友树何树) {
         if (keyCode == 257 || keyCode == 335) {
            this.树何友树树何友树何树 = false;
            this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.何何树友友树何树树树 || this.树友何树友何树友何友;
            return true;
         } else if (keyCode == 259) {
            if (!this.树友友何友何何何友树.isEmpty()) {
               this.树友友何友何何何友树 = this.树友友何友何何何友树.substring(0, this.树友友何友何何何友树.length() - 1);
            }

            return true;
         } else {
            return true;
         }
      } else if (this.友树友何何何树友友树 && this.何何树友友树何树树树) {
         if (keyCode == 257 || keyCode == 335) {
            this.何何树友友树何树树树 = false;
            this.I();
            this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.树何友树树何友树何树 || this.树友何树友何树友何友;
            return true;
         } else if (keyCode == 259) {
            if (!this.友何友树树友何树友树.isEmpty()) {
               this.友何友树树友何树友树 = this.友何友树树友何树友树.substring(0, this.友何友树树友何树友树.length() - 1);
               this.I();
            }

            return true;
         } else {
            return true;
         }
      } else if (this.友树友何何何树友友树 && !this.何何树友友树何树树树) {
         return true;
      } else {
         if (!this.友树友何何何树友友树 && !this.何何树友友树何树树树 && !this.树友何树友何树友何友 && !this.树何友树树何友树何树) {
            this.树树何何何树友友何树.i(keyCode, scanCode, modifiers);
         }

         this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.何何树友友树何树树树 || this.树何友树树何友树何树 || this.树友何树友何树友何友;
         return super.keyPressed(keyCode, scanCode, modifiers);
      }
   }

   public void onClose() {
      e();
      if (this.树友何树友何树友何友) {
         this.树友何树友何树友何友 = false;
         this.何何友友友友友何友树 = "";
      }

      if (this.树何友树树何友树何树) {
         this.树何友树树何友树何树 = false;
      }

      if (!this.树友何友何友友树树树 && !this.友何友何友何何何友树) {
         if (this.何何树友友树何树树树) {
            this.何何树友友树何树树树 = false;
         }

         if (this.何友树友树友何树友何 || this.何树何友何友何友友树) {
            this.s();
         } else if (this.友树友何何何树友友树) {
            this.x();
         } else {
            if (!this.何何何何友何树友友树) {
               this.何何何何友何树友友树 = true;
               this.树何友树树何何何友友 = System.currentTimeMillis();
            }
         }
      } else {
         this.h();
      }
   }

   protected void init() {
      e();
      if (mc != null && mc.player != null && mc.level != null) {
         super.init();
         this.树友友树友友友树何树 = 0.0F;
         this.何何何何友何树友友树 = false;
         this.树何友树树何何何友友 = System.currentTimeMillis();
         this.友何何友何何友树树何 = 0.0F;
         this.树何友何友友树友树何 = false;
         this.树友何何何何友何何友 = System.currentTimeMillis();
         this.树何友友树树友树树何 = 何友友友树友何友树何.树友何树何树树友何树.树树树树友友何友友何;
         this.友友何友树何友友树友 = 0.0F;
         this.何树树何何友友树何友 = false;
         this.友何何友何友何何树何 = 0.0F;
         this.树友何友树树友友友树 = false;
         this.树树何友树何树友友树 = 0.0F;
         this.何树友友友树树友友树 = false;
         this.树友树树何友友何树友 = 0.0F;
         this.友何何树何友友树树树 = false;
         this.树友何友何友友树树树 = false;
         this.树友友何友何何何友树 = "";
         this.树何友树树何友树何树 = false;
         if (this.树何友友何何何树树树 != null) {
            this.树何友友何何何树树树.clear();
         }

         this.树何友友何何何树树树 = new ArrayList<>();
         this.友树何何树何友何友何 = 0.0F;
         this.树友树何何树树何友友 = 0.0F;
         this.何树何何树友树何友友 = false;
         this.友何友何友何何何友树 = false;
         this.树何树友友友何何友友 = false;
         this.何树树友树何何友何树 = false;
         this.何何友友友友友何友树 = "";
         this.树友何树友何树友何友 = false;
         this.r();
         this.H();
         int screenWidth = mc.getWindow().getGuiScaledWidth();
         this.友树何树树树友何树何 = screenWidth + 10;
         this.何树友何友树友何友友 = screenWidth + 10;
         this.何树何何树何友友树何 = screenWidth + 10;
         this.树何友树友友树树何友 = screenWidth + 10;
         this.何何树树何树树何树何 = -40.0F;
         if (this.友何何何树树友树何友 > 0.0F) {
            this.何树何树友树树何树何 = -this.友何何何树树友树何友 - 10.0F;
         }

         this.何树何树友树树何树何 = -500.0F;
         if (this.友友何何树树友树友树 == null && 树何友友何树友友何何.M().length > 0) {
            this.友友何何树树友树友树 = 树何友友何树友友何何.M()[0];
         }

         this.树树何何何树友友何树.g();
         this.何友树友树友何树友何 = false;
         this.友树树何友树树友何树 = null;
         if (this.友树树树树友树友友树 != null) {
            this.友树树树树友树友友树.clear();
         }

         this.友树树树树友树友友树 = null;
         this.树树友友友何友友何友 = 0.0F;
         this.树友友友何树何友何友 = 0.0F;
         this.树何友友树何何树友友 = false;
         this.何树何友何友何友友树 = false;
         this.友何友树树友何树友树 = "";
         this.何何树友友树何树树树 = false;
         this.树何何树树友友树何何 = false;
      }
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      e();
      if (mc == null || mc.player == null || mc.level == null || !this.L()) {
         return false;
      } else if (this.友树友何何何树友友树) {
         return true;
      } else {
         if (this.树友何友何友友树树树) {
            boolean clickInsidePopup = mouseX >= this.树何树何友友友何何友
               && mouseX <= this.树何树何友友友何何友 + 180.0F
               && mouseY >= this.友树何何友友何树何树
               && mouseY <= this.友树何何友友何树何树 + 200.0F;
            if (clickInsidePopup && this.树友树何何树树何友友 > 0.9F) {
               return true;
            }
         }

         if (button == 0 && this.树何树友何树树树友树) {
            this.树何树友何树树树友树 = false;
         }

         this.树树何何何树友友何树.L(mouseX, mouseY, button);
         return super.mouseReleased(mouseX, mouseY, button);
      }
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      e();
      if (this.树何树友何树树树友树 && button == 0) {
         this.何何友树树友树何何何 = (float)(mouseX - this.何何友何友何何何树树);
         this.友树何何树友树友何友 = (float)(mouseY - this.树友树友何友何友树何);
         return true;
      } else if (this.友树友何何何树友友树) {
         return true;
      } else {
         if (this.树友何友何友友树树树 && this.树友树何何树树何友友 > 0.01F) {
            boolean clickInsidePopup = mouseX >= this.树何树何友友友何何友
               && mouseX <= this.树何树何友友友何何友 + 180.0F
               && mouseY >= this.友树何何友友何树何树
               && mouseY <= this.友树何何友友何树何树 + 200.0F;
            if (clickInsidePopup && this.树友树何何树树何友友 > 0.9F) {
               return true;
            }
         }

         if (!this.树何树友何树树树友树 && button == 0) {
            this.树树何何何树友友何树.G(mouseX, mouseY, button, deltaX, deltaY);
         }

         return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
      e();
      if (mc != null && mc.player != null && mc.level != null && this.L()) {
         ClientUtils.D(131325480669526L);
         何何友友树何树何友树 popupListFont = Cherish.instance.t().H(14);
         何何友友树何树何友树 contextMenuModuleFontLocal = Cherish.instance.t().H(16);
         if ((this.树友何友何友友树树树 || this.友何友何友何何何友树) && this.树友树何何树树何友友 > 0.01F) {
            float listScreenY = this.友树何何友友何树何树 + 5.0F + 20.0F + 5.0F + this.树友何友树友树友树友 + 5.0F + popupListFont.x() + 2.0F;
            float listHeight = this.友树何何友友何树何树 + 200.0F - 5.0F - listScreenY;
            if (mouseX >= this.树何树何友友友何何友 && mouseX <= this.树何树何友友友何何友 + 180.0F && mouseY >= listScreenY && mouseY <= listScreenY + listHeight) {
               float totalContentH = this.树何友友何何何树树树.size() * 20.0F;
               float maxScroll = Math.max(0.0F, totalContentH - listHeight);
               this.友树何何树何友何友何 -= (float)delta * 20.0F * 0.8F;
               this.友树何何树何友何友何 = Mth.clamp(this.友树何何树何友何友何, 0.0F, maxScroll);
               return true;
            }
         }

         if (this.友树友何何何树友友树 && (this.何友树友树友何树友何 || this.何树何友何友何友友树) && this.树友友友何树何友何友 > 0.01F && this.友树树树树友树友友树 != null) {
            float menuX = this.树友友友树友友友何树;
            float menuListY = this.友何何友树友树树友友 + 20.0F;
            if (mouseX >= menuX && mouseX <= menuX + 150.0F && mouseY >= menuListY && mouseY <= menuListY + 150.0F) {
               float itemHeight = contextMenuModuleFontLocal.x() + 4;
               float totalContentHeight = this.友树树树树友树友友树.size() * itemHeight;
               float maxScroll = Math.max(0.0F, totalContentHeight - 150.0F);
               this.树树友友友何友友何友 -= (float)delta * 12.0F;
               this.树树友友友何友友何友 = Mth.clamp(this.树树友友友何友友何友, 0.0F, maxScroll);
               return true;
            }
         }

         if (!this.友树友何何何树友友树) {
            boolean hoveringSearchBar = this.b(this.树何友树友友树树何友, this.友何友友何友树何何何, 120.0F, 20.0F, mouseX, mouseY);
            if (!hoveringSearchBar && !this.树友何友何友友树树树 && !this.友何友何友何何何友树 && !this.树何树友何树树树友树) {
               this.树树何何何树友友何树.E(mouseX, mouseY, delta);
            }
         }

         return super.mouseScrolled(mouseX, mouseY, delta);
      } else {
         return false;
      }
   }

   public boolean charTyped(char typedChar, int modifiers) {
      e();
      if (this.树友何树友何树友何友) {
         label64: {
            if (typedChar == '\b') {
               if (this.何何友友友友友何友树.isEmpty()) {
                  break label64;
               }

               this.何何友友友友友何友树 = this.何何友友友友友何友树.substring(0, this.何何友友友友友何友树.length() - 1);
            }

            if (typedChar >= ' ' && typedChar != 127 && this.何何友友友友友何友树.length() < 64) {
               this.何何友友友友友何友树 = this.何何友友友友友何友树 + typedChar;
            }
         }

         this.树树何何何树友友何树.c();
         return true;
      } else if (this.树何友树树何友树何树) {
         if (typedChar == '\b') {
            if (this.树友友何友何何何友树.isEmpty()) {
               return true;
            }

            this.树友友何友何何何友树 = this.树友友何友何何何友树.substring(0, this.树友友何友何何何友树.length() - 1);
         }

         if (typedChar >= ' ' && typedChar != 127) {
            this.树友友何友何何何友树 = this.树友友何友何何何友树 + typedChar;
         }

         return true;
      } else if (this.友树友何何何树友友树 && this.何何树友友树何树树树) {
         if (typedChar == '\b') {
            if (!this.友何友树树友何树友树.isEmpty()) {
               this.友何友树树友何树友树 = this.友何友树树友何树友树.substring(0, this.友何友树树友何树友树.length() - 1);
            }

            this.I();
         }

         if (typedChar >= ' ' && typedChar != 127) {
            this.友何友树树友何树友树 = this.友何友树树友何树友树 + typedChar;
            this.I();
         }

         return true;
      } else {
         if (!this.友树友何何何树友友树 && !this.何何树友友树何树树树 && !this.树友何树友何树友何友 && !this.树何友树树何友树何树) {
            this.树树何何何树友友何树.O(typedChar, modifiers);
         }

         this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.何何树友友树何树树树 || this.树何友树树何友树何树 || this.树友何树友何树友何友;
         return super.charTyped(typedChar, modifiers);
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      e();
      if (mc == null || mc.player == null || mc.level == null || !this.L()) {
         return false;
      } else if (this.树何友何友友树友树何) {
         return false;
      } else {
         boolean isEnglish = ClientUtils.D(131325480669526L);
         boolean clickedInsideSearch = this.b(this.树何友树友友树树何友, this.友何友友何友树何何何, 120.0F, 20.0F, mouseX, mouseY);
         if (clickedInsideSearch && button == 0) {
            this.树友何树友何树友何友 = true;
            this.树何友树树何友树何树 = false;
            this.何何树友友树何树树树 = false;
            this.树树何何何树友友何树.q();
            this.树何何树树友友树何何 = true;
            return true;
         } else {
            if ((this.树友何友何友友树树树 || this.友何友何友何何何友树) && this.树友树何何树树何友友 > 0.01F) {
               boolean clickInsidePopup = mouseX >= this.树何树何友友友何何友
                  && mouseX <= this.树何树何友友友何何友 + 180.0F
                  && mouseY >= this.友树何何友友何树何树
                  && mouseY <= this.友树何何友友何树何树 + 200.0F;
               if (clickInsidePopup && this.树友树何何树树何友友 > 0.95F) {
                  float currentListYCheck = this.友树何何友友何树何树 + 5.0F + 20.0F + 5.0F + this.树友何友树友树友树友 + 5.0F + Cherish.instance.t().H(14).x() + 2.0F;
                  float listAreaHeightCheck = this.友树何何友友何树何树 + 200.0F - 5.0F - currentListYCheck;
                  float inputFieldX = this.树何树何友友友何何友 + 5.0F;
                  float inputFieldY = this.友树何何友友何树何树 + 5.0F;
                  if (this.b(inputFieldX, inputFieldY, 170.0F, 20.0F, mouseX, mouseY) && button == 0) {
                     this.树何友树树何友树何树 = true;
                     this.树友何树友何树友何友 = false;
                     this.何何树友友树何树树树 = false;
                     this.树树何何何树友友何树.q();
                     this.树何何树树友友树何何 = true;
                     return true;
                  }

                  if (this.树何友树树何友树何树 && !this.b(inputFieldX, inputFieldY, 170.0F, 20.0F, mouseX, mouseY)) {
                     this.树何友树树何友树何树 = false;
                  }

                  if (this.何树树友树何何友何树 && button == 0) {
                     if (!this.树友友何友何何何友树.isEmpty()) {
                        友何何友树友树何树树 switchModule = new 友何何友树友树何树树(new File(Cherish.getConfigManager().e(), this.树友友何友何何何友树 + ".ini"));

                        try {
                           if (switchModule.A()) {
                              String successMsg = "Saved config " + this.树友友何友何何何友树 + " successful.";
                              ClientUtils.P(125527250587045L, successMsg);
                              树友何何何树友树何友.E(何树友友何友友何树树.树树友树友友友何何树, "Config", successMsg, 3.0F);
                              this.d();
                           }

                           String failMsg = isEnglish ? "Save " + this.树友友何友何何何友树 + " config failed." : "保存配置 " + this.树友友何友何何何友树 + " 失败";
                           ClientUtils.P(125527250587045L, failMsg);
                           树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", failMsg, 3.0F);
                        } catch (Throwable var31) {
                           throw new RuntimeException(var31);
                        }
                     }

                     String emptyMsg = isEnglish ? "Config name cannot be empty." : "配置名称不能为空。";
                     树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", emptyMsg, 3.0F);
                     return true;
                  }

                  if (this.树何树友友友何何友友 && button == 0) {
                     if (!this.树友友何友何何何友树.isEmpty()) {
                        友何何友树友树何树树 switchModule = new 友何何友树友树何树树(new File(Cherish.getConfigManager().e(), this.树友友何友何何何友树 + ".ini"));
                        File testFile = new File(Cherish.getConfigManager().e(), this.树友友何友何何何友树 + ".ini");
                        if (!testFile.exists()) {
                           String notFoundMsg = "Config " + this.树友友何友何何何友树 + " not found.";
                           树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", notFoundMsg, 3.0F);
                           return true;
                        }

                        try {
                           switchModule.k();
                           String successMsg = isEnglish ? "Load config " + this.树友友何友何何何友树 + " successful." : "成功加载配置 " + this.树友友何友何何何友树;
                           ClientUtils.P(125527250587045L, successMsg);
                           树友何何何树友树何友.E(何树友友何友友何树树.树树友树友友友何何树, "Config", successMsg, 3.0F);
                        } catch (Throwable var32) {
                           String errorMsg = "Error: failed to load " + this.树友友何友何何何友树 + ".";
                           ClientUtils.P(125527250587045L, errorMsg);
                           树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", errorMsg, 3.0F);
                        }
                     }

                     String emptyMsg = isEnglish ? "Config name cannot be empty." : "配置名称不能为空。";
                     树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Config", emptyMsg, 3.0F);
                     return true;
                  }

                  float itemYCheck = currentListYCheck - this.友树何何树何友何友何;
                  Iterator var49 = this.树何友友何何何树树树.iterator();
                  if (var49.hasNext()) {
                     String configName = (String)var49.next();
                     if (mouseX >= this.树何树何友友友何何友 + 5.0F
                        && mouseX <= this.树何树何友友友何何友 + 180.0F - 5.0F
                        && mouseY >= itemYCheck
                        && mouseY <= itemYCheck + 20.0F
                        && mouseY >= currentListYCheck
                        && mouseY <= currentListYCheck + listAreaHeightCheck
                        && button == 0) {
                        this.树友友何友何何何友树 = configName;
                        this.树何友树树何友树何树 = false;
                        return true;
                     }

                     float var59 = itemYCheck + 20.0F;
                  }

                  return true;
               }

               if (!clickInsidePopup && button == 0) {
                  if (this.树友何友何友友树树树) {
                     this.h();
                  }

                  if (this.树何友树树何友树何树) {
                     this.树何友树树何友树何树 = false;
                  }
               }
            }

            if (this.树何友树树何友树何树 && button == 0) {
               this.树何友树树何友树何树 = false;
            }

            if (this.友树友何何何树友友树) {
               if (this.b(this.树何友友何友何友何友, this.何何树树何树树何树何, 80.0F, 30.0F, mouseX, mouseY) && button == 0) {
                  this.x();
                  return true;
               } else {
                  if ((this.何友树友树友何树友何 || this.何树何友何友何友友树) && this.树友友友何树何友何友 > 0.01F) {
                     float menuX = this.树友友友树友友友何树;
                     float menuY = this.友何何友树友树树友友;
                     if (menuX + 150.0F > super.width) {
                        menuX = super.width - 150.0F;
                     }

                     if (menuY + 150.0F + 20.0F > super.height) {
                        menuY = super.height - 150.0F - 20.0F;
                     }

                     if (menuX < 0.0F) {
                        menuX = 0.0F;
                     }

                     if (menuY < 0.0F) {
                        menuY = 0.0F;
                     }

                     float searchBoxEndX = menuX + 150.0F;
                     float searchBoxEndY = menuY + 20.0F;
                     if (mouseX >= menuX && mouseX <= searchBoxEndX && mouseY >= menuY && mouseY <= searchBoxEndY && button == 0) {
                        this.何何树友友树何树树树 = true;
                        this.树友何树友何树友何友 = false;
                        this.树何友树树何友树何树 = false;
                        this.树树何何何树友友何树.q();
                        this.树何何树树友友树何何 = true;
                        return true;
                     }

                     if (this.何何树友友树何树树树
                        && button == 0
                        && this.树友友友何树何友何友 >= 0.95F
                        && (!(mouseX >= menuX) || !(mouseX <= searchBoxEndX) || !(mouseY >= menuY) || !(mouseY <= searchBoxEndY))) {
                        this.何何树友友树何树树树 = false;
                     }

                     float listStartY = menuY + 20.0F;
                     float listEndX = menuX + 150.0F;
                     float listEndY = menuY + 20.0F + 150.0F;
                     if (mouseX >= menuX && mouseX <= listEndX && mouseY >= listStartY && mouseY <= listEndY && this.树友友友何树何友何友 >= 0.95F) {
                        float itemHeight = Cherish.instance.t().H(16).x() + 4;
                        float currentItemY = listStartY + 2.0F - this.树树友友友何友友何友;
                        if (this.友树树树树友树友友树 != null) {
                           Iterator var27 = this.友树树树树友树友友树.iterator();
                           if (var27.hasNext()) {
                              Module module = (Module)var27.next();
                              if (mouseY >= currentItemY && mouseY <= currentItemY + itemHeight && button == 0) {
                                 String moduleDisplayName = isEnglish ? module.A() : module.B();
                                 if (module.r() == this.友树树何友树树友何树.何树友树树树友友友树) {
                                    module.g(-1);
                                    String unbindMsg = "Unbound " + moduleDisplayName + " from " + this.友树树何友树树友何树.树树树树何何友何树何;
                                    树友何何何树友树何友.E(何树友友何友友何树树.友友树树树树何何友友, "Keybind", unbindMsg, 3.0F);
                                 }

                                 module.g(this.友树树何友树树友何树.何树友树树树友友友树);
                                 String bindMsg = isEnglish
                                    ? "Bound " + moduleDisplayName + " to " + this.友树树何友树树友何树.树树树树何何友何树何
                                    : "已绑定 " + moduleDisplayName + " 到 " + this.友树树何友树树友何树.树树树树何何友何树何;
                                 树友何何何树友树何友.E(何树友友何友友何树树.友友树树树树何何友友, "Keybind", bindMsg, 3.0F);
                                 this.I();
                                 return true;
                              }

                              float var58 = currentItemY + itemHeight;
                           }
                        }

                        return true;
                     }

                     if (button == 0 && (mouseX < menuX || mouseX > menuX + 150.0F || mouseY < menuY || mouseY > menuY + 150.0F + 20.0F)) {
                        if (this.何友树友树友何树友何) {
                           this.s();
                        }

                        if (this.何何树友友树何树树树) {
                           this.何何树友友树何树树树 = false;
                        }
                     }
                  }

                  if (this.友何何友何何友树树何 >= 1.0F && !this.何友树友树友何树友何 && !this.何树何友何友何友友树 && !this.树何友友树何何树友友) {
                     Iterator var35 = this.何友友何树树树何友友.iterator();
                     if (var35.hasNext()) {
                        何友友友树友何友树何.树友何友友何友何树友 key = (何友友友树友何友树何.树友何友友何友何树友)var35.next();
                        if (key.I(mouseX, mouseY, this.何树何树友树树何树何) && button == 1) {
                           if (this.何友树友树友何树友何 && this.友树树何友树树友何树 == key) {
                              this.s();
                           }

                           this.友树树何友树树友何树 = key;
                           this.树友友友树友友友何树 = (float)mouseX + 5.0F;
                           this.友何何友树友树树友友 = (float)mouseY + 5.0F;
                           this.友何友树树友何树友树 = "";
                           this.何何树友友树何树树树 = false;
                           this.y();
                           return true;
                        }
                     }
                  }

                  return true;
               }
            } else {
               if (this.树友何树友何树友何友 && !clickedInsideSearch && button == 0) {
                  this.树友何树友何树友何友 = false;
               }

               if (this.b(this.何树何何树何友友树何, this.树友何树友树树何何友, 80.0F, 20.0F, mouseX, mouseY) && button == 0) {
                  if (this.树友何友何友友树树树) {
                     this.h();
                  }

                  this.S();
                  this.树友何树友何树友何友 = false;
                  return true;
               } else if (this.b(this.何树友何友树友何友友, this.何友友树树树友树树友, 80.0F, 20.0F, mouseX, mouseY) && button == 0) {
                  mc.setScreen(new 树树何树何何树何友友());
                  return true;
               } else if (this.b(this.友树何树树树友何树何, this.何何何友树树友何何何, 80.0F, 20.0F, mouseX, mouseY) && button == 0) {
                  this.c();
                  return true;
               } else if (this.b(this.何何友树树友树何何何, this.友树何何树友树友何友, 550.0F, 20.0F, mouseX, mouseY) && button == 0) {
                  this.树何树友何树树树友树 = true;
                  this.何何友何友何何何树树 = (float)(mouseX - this.何何友树树友树何何何);
                  this.树友树友何友何友树何 = (float)(mouseY - this.友树何何树友树友何友);
                  return true;
               } else {
                  float catHeight = 240.0F / 树何友友何树友友何何.M().length;
                  树何友友何树友友何何[] searchBoxX = 树何友友何树友友何何.M();
                  int searchBoxY = searchBoxX.length;
                  int searchBoxEndXx = 0;
                  if (0 < searchBoxY) {
                     树何友友何树友友何何 category = searchBoxX[0];
                     float catY = this.友树何何树友树友何友 + 40.0F + 0.0F;
                     if (this.b(this.何何友树树友树何何何, catY, 90.0F, catHeight, mouseX, mouseY)) {
                        if (this.友友何何树树友树友树 != category) {
                           this.q(category);
                        }

                        return true;
                     }

                     float var10000 = 0.0F + catHeight;
                     searchBoxEndXx++;
                  }

                  this.树树何何何树友友何树.g(mouseX, mouseY, button);
                  this.树何何树树友友树何何 = this.树树何何何树友友何树.友友友友友友友树何何 || this.何何树友友树何树树树 || this.树何友树树何友树何树 || this.树友何树友何树友何友;
                  return super.mouseClicked(mouseX, mouseY, button);
               }
            }
         }
      }
   }

   private static class 何友树何友何何树友树 implements 何树友 {
      String 何何友友何何友友何树;
      String 树何树友树何何友友树;
      float 何友友树树树友树树友;
      float 友树友树何何何友何友;
      float 何何树树树友友何友何;
      float 何何友树树树友树何树;
      private static final long a;
      private static final Object[] b = new Object[10];
      private static final String[] c = new String[10];
      private static String HE_DA_WEI;

      public 何友树何友何何树友树(String displayName, String internalName, float x, float y, float width, float height) {
         this.何何友友何何友友何树 = displayName;
         this.树何树友树何何友友树 = internalName;
         this.何友友树树树友树树友 = x;
         this.友树友树何何何友何友 = y;
         this.何何树树树友友何友何 = 22.0F;
         this.何何友树树树友树何树 = 22.0F;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-4696954106470831307L, 897982845570721648L, MethodHandles.lookup().lookupClass()).a(247775045591195L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 249 && var8 != 193 && var8 != 'P' && var8 != 251) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'u') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 229) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 249) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 193) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'P') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/何友友友树友何友树何$何友树何友何何树友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static void a() {
         b[0] = "N0S>3rAp\u001e59oD-\u0015s)t\u0003伋厶厖厗栌另伋厶桌伉9佸厕桬伈厗佈佸桏厶桌";
         b[1] = float.class;
         c[1] = "java/lang/Float";
         b[2] = "\u007fP\"c,Wt_3,QOgX:e";
         b[3] = "\u0000SpI]5\u000b\\a\u0006<;\u0000We\\";
         b[4] = "c\u0015\n\u000br=9\u001aO1佉厗叅桭栬栨受桍栟厷5\b$*i\u0014\t\n(0v";
         b[5] = "=m\u007f|/bgb:F伔佖厛栕桙桟厊栒伅栕@\u007fyu7l|}uo(";
         b[6] = " lM\\i9zc\bf双桉历栔伯伻佒厓优収r_?.*mN]345";
         b[7] = " \n\u0019m\u007fZz\u0005\\W栀佮桜厨栿伊佄台历桲&ntN$T\u001c,bV>";
         b[8] = "\u001cx;\u0001;\fFw~;伀伸厺叚余佦厞厦伤栀\u0004\u00020\u0018\u0018&>@&\u0000\u0002";
         b[9] = "\u0003 &g`xY/c]佛佌桿桘栀厞叅佌厥伜\u0019d6o\t!%f:u\u0016";
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 22;
                  case 1 -> 41;
                  case 2 -> 46;
                  case 3 -> 21;
                  case 4 -> 60;
                  case 5 -> 17;
                  case 6 -> 30;
                  case 7 -> 16;
                  case 8 -> 63;
                  case 9 -> 36;
                  case 10 -> 51;
                  case 11 -> 54;
                  case 12 -> 0;
                  case 13 -> 37;
                  case 14 -> 10;
                  case 15 -> 50;
                  case 16 -> 44;
                  case 17 -> 49;
                  case 18 -> 34;
                  case 19 -> 38;
                  case 20 -> 26;
                  case 21 -> 8;
                  case 22 -> 18;
                  case 23 -> 7;
                  case 24 -> 59;
                  case 25 -> 58;
                  case 26 -> 33;
                  case 27 -> 53;
                  case 28 -> 27;
                  case 29 -> 43;
                  case 30 -> 19;
                  case 31 -> 20;
                  case 32 -> 57;
                  case 33 -> 48;
                  case 34 -> 47;
                  case 35 -> 9;
                  case 36 -> 29;
                  case 37 -> 35;
                  case 38 -> 25;
                  case 39 -> 40;
                  case 40 -> 52;
                  case 41 -> 42;
                  case 42 -> 45;
                  case 43 -> 31;
                  case 44 -> 55;
                  case 45 -> 2;
                  case 46 -> 32;
                  case 47 -> 28;
                  case 48 -> 11;
                  case 49 -> 3;
                  case 50 -> 12;
                  case 51 -> 6;
                  case 52 -> 56;
                  case 53 -> 5;
                  case 54 -> 13;
                  case 55 -> 24;
                  case 56 -> 61;
                  case 57 -> 4;
                  case 58 -> 1;
                  case 59 -> 23;
                  case 60 -> 14;
                  case 61 -> 62;
                  case 62 -> 39;
                  default -> 15;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static String LIU_YA_FENG() {
         return "何大伟230622198107200054";
      }
   }

   private static class 树友何友友何友何树友 implements 何树友 {
      String 树树树树何何友何树何;
      String 友树友友友树何树何树;
      int 何树友树树树友友友树;
      float 树何友何树友友何树何;
      float 树树何何友何何树何树;
      float 何友树何何何树何何树;
      float 友何友树友树树树友树;
      boolean 友友何树友树友树树树;
      Map<String, Integer> 树何友友友友何何何何;
      private static final long a;
      private static final Object[] b = new Object[35];
      private static final String[] c = new String[35];
      private static int _何大伟：我要教育何炜霖 _;

      public 树友何友友何友何树友(String displayName, String internalName, float relativeX, float relativeY, float width, float height, Map<String, Integer> glfwKeyMap) {
         this.树树树树何何友何树何 = displayName;
         this.友树友友友树何树何树 = internalName;
         何友友友树友何友树何.e();
         this.树何友何树友友何树何 = relativeX;
         this.树树何何友何何树何树 = relativeY;
         this.何友树何何何树何何树 = width;
         this.友何友树友树树树友树 = height;
         this.树何友友友友何何何何 = glfwKeyMap;
         Integer code = glfwKeyMap.get(internalName.toLowerCase());
         this.何树友树树树友友友树 = code != null ? code : -1;
         Module.V(new Module[4]);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(4463778416517057794L, -6019475458244590185L, MethodHandles.lookup().lookupClass()).a(115648706367366L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public boolean I(double mx, double my, float currentKeyboardY) {
         何友友友树友何友树何.e();
         float actualX = 何友友友树友何友树何.何何友友树友树友友树.何友何树何何树友何树 + 10.0F + this.树何友何树友友何树何;
         float actualY = currentKeyboardY + 10.0F + this.树树何何友何何树何树;
         return mx >= actualX && mx <= actualX + this.何友树何何何树何何树 && my >= actualY && my <= actualY + this.友何友树友树树树友树;
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public void c(GuiGraphics guiGraphics, int mouseX, int mouseY, 何何友友树何树何友树 font, float currentKeyboardY, float globalAlpha) {
         何友友友树友何友树何.e();
         float actualX = 何友友友树友何友树何.何何友友树友树友友树.何友何树何何树友何树 + 10.0F + this.树何友何树友友何树何;
         float actualY = currentKeyboardY + 10.0F + this.树树何何友何何树何树;
         if (!(actualY + this.友何友树友树树树友树 < currentKeyboardY + 10.0F) && !(actualY > currentKeyboardY + 何友友友树友何友树何.何何友友树友树友友树.友何何何树树友树何友 - 10.0F)) {
            int keyAlpha = (int)(255.0F * globalAlpha);
            if (keyAlpha >= 5) {
               this.友友何树友树友树树树 = mouseX >= actualX && mouseX <= actualX + this.何友树何何何树何何树 && mouseY >= actualY && mouseY <= actualY + this.友何友树友树树树友树;
               Color baseBgColor = this.友友何树友树友树树树 ? new Color(80, 80, 80) : new Color(50, 50, 50);
               Color shadowColor = new Color(30, 30, 30);
               RenderUtils.drawRectangle(
                  guiGraphics.pose(),
                  actualX,
                  actualY,
                  this.何友树何何何树何何树,
                  this.友何友树友树树树友树,
                  new Color(baseBgColor.getRed(), baseBgColor.getGreen(), baseBgColor.getBlue(), keyAlpha).getRGB()
               );
               RenderUtils.drawRectangle(
                  guiGraphics.pose(),
                  actualX,
                  actualY + this.友何友树友树树树友树 - 1.0F,
                  this.何友树何何何树何何树,
                  1.0F,
                  new Color(shadowColor.getRed(), shadowColor.getGreen(), shadowColor.getBlue(), keyAlpha).getRGB()
               );
               Color textColor = Color.WHITE;
               font.h(
                  guiGraphics.pose(),
                  this.树树树树何何友何树何,
                  actualX + this.何友树何何何树何何树 / 2.0F,
                  actualY + this.友何友树友树树树友树 / 2.0F - font.x() / 2,
                  new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), keyAlpha).getRGB()
               );
               Iterator var16 = Cherish.instance.getModuleManager().p().iterator();
               if (var16.hasNext()) {
                  Module m = (Module)var16.next();
                  if (m.r() == this.何树友树树树友友友树 && this.何树友树树树友友友树 != -1) {
                     font.q(
                        guiGraphics.pose(),
                        "*",
                        actualX + this.何友树何何何树何何树 - font.D("*") - 2.0F,
                        actualY + 2.0F,
                        new Color(Color.CYAN.getRed(), Color.CYAN.getGreen(), Color.CYAN.getBlue(), keyAlpha).getRGB()
                     );
                  }
               }

               if (Module.Z() == null) {
                  何友友友树友何友树何.l(new int[3]);
               }
            }
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static void a() {
         b[0] = "~iKH5Xq)\u0006C?Ett\r\u0005/^3佒厮叠厑栦取佒厮栺伏";
         b[1] = "\u000e{\u001d\u0001_\u001f\u0001;P\nU\u0002\u0004f[LE\u0019C佀司厩叻桡厦佀司桳佥T桼叞佦厩叻伥厦佀栢厩";
         b[2] = float.class;
         c[2] = "java/lang/Float";
         b[3] = "\u00135";
         b[4] = "{M\bv\u0000\u0000pB\u00199|\u0019\u007fX\u0017zK)iO\u001bgZ\u0005~B";
         b[5] = int.class;
         c[5] = "java/lang/Integer";
         b[6] = "%3P\u00028\u001a8&\b y\u0017  ";
         b[7] = "_xm7hKTw|x\u0015SGpu1";
         b[8] = "pL";
         b[9] = void.class;
         c[9] = "java/lang/Void";
         b[10] = "HL!\r.\rG\fl\u0006$\u0010BQg@,\rOWc\u000bo/DFz\u0002$";
         b[11] = "$fp\u0003\u001c\u0001\u0010E\u007fCQ\n\u001aXz\u001eZL\u0012Ew\u0018^\u0007Qg|\tG\u000e\u001a\u0011";
         b[12] = boolean.class;
         c[12] = "java/lang/Boolean";
         b[13] = "\u0018ZTf\u001d@\u0006RN)~T\u0002";
         b[14] = "2rL\u0011e\f\u0006QCQ(\u0007\fLF\f#A\u0004QK\n'\nGs@\u001b>\u0003\f\u0005";
         b[15] = "\u0002'9\u0014F\u0000\t((['\u000e\u0002#,\u0001";
         b[16] = "\f\b4A.Q\u0012\r~.休佩厯厴栝叭桕号厯桮\u0004N3\u0004\u0003\u0015aP6N";
         b[17] = "\"\u0005usJ\u0011(U$O伮叮桊佣佃伒桪佰伎栧\u001ev\tDoTw?KA\"";
         b[18] = "m\u0004\u0011y\u001fLs\u0001[\u0016\u0010)3DGd\fVvF\u001e*}";
         b[19] = "\u000b\u0017\f<\u0006\u0004\u0015\u0012FS厧似伶伵栥桊厧桸伶厫<j\u001e\bW\u0002U#\\\r\u001a";
         b[20] = ",\u0019U5\u0004Z&I\u0004\t叾桿厞叡叽栐你桿伀栻>4R^ KY8\f\u000bm";
         b[21] = "@VA\u001ec\u0007J\u0006\u0010\"桃佦史厮叩叡伇佦佬估*\u00130\\L\u0017R]c]N";
         b[22] = "\t\u0019~'P7\u0003I/\u001b伴栒去栻栌栂厪又去栻\u0015 \u0013q\u0006Xoz\u0015p\u0004";
         b[23] = "y#cy\u0018\f44;#||\u0014\u0011DI@L$hfr\r[|2";
         b[24] = "g\u0019NAW~mI\u001f}桷桛栏栻佸传厭伟栏使%@\u0001zkKBL_/&";
         b[25] = "e\\03w\u001f{Yz\\qz;\u001cf.d\u0005~\u001e?`\u0015DdH:`y\u000bjM1\\";
         b[26] = "EW\nN\"AAAN\u001c\u001b/{OILt\u001eAL\u000b\u0014%}";
         b[27] = "SliBXJMi#-佧召佮栊伄佰栣召佮栊Y\u0014@F\u000fy0]\u0002CB";
         b[28] = "G\u0003i@^GMS8|桾桢佫佥叁伡伺桢佫校\u0002E\u001d\u0012\nRk\f_\u0017G";
         b[29] = "(O\u000bT~6\"\u001fZh.\nc\u000fQW$w3E\u000bRG0\"E_\u000b:`h\u001fZh";
         b[30] = "uMb(. \u007f\u001d3\u0014栎佁叇伫栐受叔佁栝伫\t-mu8\u001c`d/pu";
         b[31] = "\tO7:%Z\u0003\u001ff\u0006叟厥伥桭原栟叟桿桡桭\\6a\u000fF\f5vl\u0017\u0006";
         b[32] = "\u0004\"\u0018ZAPI5@\u0000%4x\u0018%'%WC8I\u000e\u001e\u001aT`\u0013";
         b[33] = "<g&*a.67w\u0016厛住厎桅厎栏桁栋厎桅M/\"{q6$f`~<";
         b[34] = "\u0003!a\u0019r=\u00077%KK_=9\"\u001b$b\u0007:`Cu\u0001\u00031r\u001cwmL?w\u0017K";
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 236 && var8 != 'S' && var8 != 164 && var8 != 205) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 252) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 243) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 236) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'S') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 164) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/何友友友树友何友树何$树友何友友何友何树友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 22;
                  case 1 -> 42;
                  case 2 -> 11;
                  case 3 -> 58;
                  case 4 -> 20;
                  case 5 -> 30;
                  case 6 -> 56;
                  case 7 -> 23;
                  case 8 -> 52;
                  case 9 -> 5;
                  case 10 -> 44;
                  case 11 -> 32;
                  case 12 -> 24;
                  case 13 -> 53;
                  case 14 -> 51;
                  case 15 -> 17;
                  case 16 -> 39;
                  case 17 -> 59;
                  case 18 -> 12;
                  case 19 -> 38;
                  case 20 -> 45;
                  case 21 -> 2;
                  case 22 -> 63;
                  case 23 -> 55;
                  case 24 -> 57;
                  case 25 -> 28;
                  case 26 -> 34;
                  case 27 -> 61;
                  case 28 -> 21;
                  case 29 -> 25;
                  case 30 -> 14;
                  case 31 -> 27;
                  case 32 -> 60;
                  case 33 -> 54;
                  case 34 -> 16;
                  case 35 -> 26;
                  case 36 -> 10;
                  case 37 -> 36;
                  case 38 -> 7;
                  case 39 -> 37;
                  case 40 -> 15;
                  case 41 -> 48;
                  case 42 -> 33;
                  case 43 -> 35;
                  case 44 -> 47;
                  case 45 -> 62;
                  case 46 -> 4;
                  case 47 -> 9;
                  case 48 -> 29;
                  case 49 -> 46;
                  case 50 -> 50;
                  case 51 -> 13;
                  case 52 -> 43;
                  case 53 -> 6;
                  case 54 -> 18;
                  case 55 -> 31;
                  case 56 -> 49;
                  case 57 -> 1;
                  case 58 -> 3;
                  case 59 -> 0;
                  case 60 -> 19;
                  case 61 -> 41;
                  case 62 -> 40;
                  default -> 8;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String LIU_YA_FENG() {
         return "职业技术教育中心学校";
      }
   }

   private static enum 树友何树何树树友何树 implements  {
      树树树树友友何友友何,
      何友何何何友友何何友,
      树何友何友树树友友树,
      何何何友何何何友何何;

      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static String HE_DA_WEI;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(5997553909278555056L, 5428067687936111302L, MethodHandles.lookup().lookupClass()).a(71496065264006L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(27776644821447L << var2 * 8 >>> 56);
         }

         var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[4];
         int var6 = 0;
         String var5 = "¯ì6¢ê«\u009aÆ==ØÉ\u0007uÌ]\u0010®©\u0003òÆ\u001cÐüÒ PL/\u00172\n";
         byte var7 = 33;
         char var4 = 16;
         int var9 = -1;

         label28:
         while (true) {
            String var11 = var5.substring(++var9, var9 + var4);
            byte var10001 = -1;

            while (true) {
               String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var17;
                     if ((var9 += var4) >= var7) {
                        树树树树友友何友友何 = new 何友友友树友何友树何.树友何树何树树友何树();
                        何友何何何友友何何友 = new 何友友友树友何友树何.树友何树何树树友何树();
                        树何友何友树树友友树 = new 何友友友树友何友树何.树友何树何树树友何树();
                        何何何友何何何友何何 = new 何友友友树友何友树何.树友何树何树树友何树();
                        return;
                     }

                     var4 = var5.charAt(var9);
                     break;
                  default:
                     var0[var6++] = var17;
                     if ((var9 += var4) < var7) {
                        var4 = var5.charAt(var9);
                        continue label28;
                     }

                     var5 = "®©\u0003òÆ\u001cÐü\u0089\u000f\u008c+}¬DÙ\bf\u0086{S\u0019¾îÿ";
                     var7 = 25;
                     var4 = 16;
                     var9 = -1;
               }

               var11 = var5.substring(++var9, var9 + var4);
               var10001 = 0;
            }
         }
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 226 && var8 != 230 && var8 != 244 && var8 != 221) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'I') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'l') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 226) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 230) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 244) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/何友友友树友何友树何$树友何树何树树友何树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 2;
                  case 1 -> 25;
                  case 2 -> 3;
                  case 3 -> 5;
                  case 4 -> 17;
                  case 5 -> 51;
                  case 6 -> 53;
                  case 7 -> 59;
                  case 8 -> 37;
                  case 9 -> 11;
                  case 10 -> 55;
                  case 11 -> 16;
                  case 12 -> 39;
                  case 13 -> 48;
                  case 14 -> 57;
                  case 15 -> 12;
                  case 16 -> 44;
                  case 17 -> 24;
                  case 18 -> 36;
                  case 19 -> 42;
                  case 20 -> 41;
                  case 21 -> 56;
                  case 22 -> 15;
                  case 23 -> 47;
                  case 24 -> 1;
                  case 25 -> 4;
                  case 26 -> 21;
                  case 27 -> 30;
                  case 28 -> 29;
                  case 29 -> 52;
                  case 30 -> 20;
                  case 31 -> 18;
                  case 32 -> 6;
                  case 33 -> 32;
                  case 34 -> 40;
                  case 35 -> 60;
                  case 36 -> 50;
                  case 37 -> 63;
                  case 38 -> 27;
                  case 39 -> 13;
                  case 40 -> 46;
                  case 41 -> 31;
                  case 42 -> 28;
                  case 43 -> 10;
                  case 44 -> 49;
                  case 45 -> 0;
                  case 46 -> 62;
                  case 47 -> 7;
                  case 48 -> 9;
                  case 49 -> 19;
                  case 50 -> 54;
                  case 51 -> 43;
                  case 52 -> 14;
                  case 53 -> 26;
                  case 54 -> 35;
                  case 55 -> 61;
                  case 56 -> 23;
                  case 57 -> 38;
                  case 58 -> 8;
                  case 59 -> 45;
                  case 60 -> 33;
                  case 61 -> 22;
                  case 62 -> 34;
                  default -> 58;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\u0002F\u0000\u0016^H\r\u0006M\u001dTU\b[F[DNO佽句厾叺栶厪佽句桤佤\u0003桰口佻桤佤栶桰口佻桤";
         b[1] = "'3$7V\u0013\u0013\u0010+w\u001b\u0018\u0019\r.*\u0010^\t\u0016i伌厳去厷桮厌伌厳桡伩[桖厒伭桡伩桮桖厒伭桡G";
         b[2] = "5$Hokh>+Y \nf5 ]z";
         b[3] = "*\u00182w[E.\u0007w\u001a栾栣桒档及叙佺叹厈伧\t{E\u0001&\u0006v\u007fZD";
         b[4] = "&fz0'h\"y?]桂栎桞叇伜厞伆佊桞叇Adjl<c*>?t{";
         b[5] = "qSn+a\u0002uL+F佀传位史伈伛佀厾位佬U'\u007fF}M*#`\u0003";
         b[6] = "!kTU\u0003I%t\u00118伢叵伝佔伲叻厼佫伝及oY\u001d\r-u\u0010]\u0002H";
         b[7] = "QPIk\u0016:UO\f\u0006桳优右佯厱栟桳历右栫rg\b~]N\rc\u0017;";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      public static 何友友友树友何友树何.树友何树何树树友何树[] j() {
         return (何友友友树友何友树何.树友何树何树树友何树[])树树树友何友何何树友.clone();
      }

      public static 何友友友树友何友树何.树友何树何树树友何树 q(String name) {
         return Enum.valueOf(何友友友树友何友树何.树友何树何树树友何树.class, name);
      }

      private static String HE_DA_WEI() {
         return "何大伟为什么要诈骗何炜霖";
      }
   }
}
