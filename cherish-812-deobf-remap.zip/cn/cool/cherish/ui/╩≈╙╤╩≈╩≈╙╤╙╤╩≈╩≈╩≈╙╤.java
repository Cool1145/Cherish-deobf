package cn.cool.cherish.ui;

import cn.cool.cherish.module.何何友何何友何何树树;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 树友树树友友树树树友 implements IWrapper, 何树友 {
   public float 树友友友何何友友何树;
   public float 友树树树何友何友树友;
   public float 友友友友何树友树友树;
   public float 树何友树友友树何树树;
   public 何何友何何友何何树树 友何树树树树树友树树;
   public List<树何何树树树友友友友> 友何树何友树友友树何;
   private final HashMap<何何友何何友何何树树, 树友友友何树树树树友> 友树友何树树树树何友;
   private float 树友友何树友树树树友;
   private static final float 树树何何树树何何树友 = 2.0F;
   private static final float 友友友何何友友友何何 = 10.0F;
   private static final float 树树友何何树树树友友 = 15.0F;
   private static final float 友何友树何树何友友树 = 25.0F;
   private static final float 树友友友友友友树友何 = 40.0F;
   private static final float 友何树友何树友何友树 = 15.0F;
   private static final float 何树树何树友树何何树 = 0.02F;
   public boolean 何友何何友何友树友树;
   private boolean 何何树树何友何何何友;
   private float 何友何友树友何何树何;
   private static final long a;
   private static final Object[] b = new Object[31];
   private static final String[] c = new String[31];
   private static String HE_WEI_LIN;

   public 树友树树友友树树树友() {
      long a = 树友树树友友树树树友.a ^ 62725188994787L;
      super();
      this.友树友何树树树树何友 = new HashMap<>();
      a<"u">(this, 0.0F, 890750912676752524L, a);
      a<"u">(this, false, 891508180911268322L, a);
      a<"u">(this, 0.0F, 890292356328077372L, a);

      for (何何友何何友何何树树 category : 何何友何何友何何树树.M()) {
         a<"Ê">(this, 891113401516565825L, a).put(category, new 树友友友何树树树树友());
      }

      a<"Ê">(this, 891113401516565825L, a).put(null, new 树友友友何树树树树友());
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8636341770815815642L, -6001341475166544710L, MethodHandles.lookup().lookupClass()).a(1146936030106L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public void B(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      long a = 树友树树友友树树树友.a ^ 15687849125891L;
      a<"W">(7114950709758690934L, a);
      a<"u">(this, false, 7114580389670728119L, a);
      if (a<"Ê">(this, 7115134199074482666L, a) != null && a<"Ê">(this, 7114560297431426716L, a) != null) {
         树友友友何树树树树友 moduleScroll = (树友友友何树树树树友)a<"Ê">(this, 7115099868641315745L, a).get(a<"Ê">(this, 7115134199074482666L, a));
         if (moduleScroll == null) {
            moduleScroll = new 树友友友何树树树树友();
            a<"Ê">(this, 7115099868641315745L, a).put(a<"Ê">(this, 7115134199074482666L, a), moduleScroll);
         }

         moduleScroll.Q();
         this.U(partialTicks);
         float totalContentHeight = this.s();
         float visibleHeight = a<"Ê">(this, 7115441441696507179L, a);
         float maxScroll = Math.max(0.0F, totalContentHeight - visibleHeight);
         moduleScroll.t(maxScroll);
         guiGraphics.enableScissor(
            (int)(a<"Ê">(this, 7115547325439121966L, a) + 95.0F),
            (int)a<"Ê">(this, 7115668173906230798L, a) + 1,
            (int)(a<"Ê">(this, 7115547325439121966L, a) + a<"Ê">(this, 7114115039456740286L, a) - 18.0F),
            (int)(a<"Ê">(this, 7115668173906230798L, a) + a<"Ê">(this, 7115441441696507179L, a))
         );
         int count = 0;
         Iterator scrollbarWidth = a<"Ê">(this, 7114560297431426716L, a).iterator();
         if (scrollbarWidth.hasNext()) {
            树何何树树树友友友友 moduleRect = (树何何树树树友友友友)scrollbarWidth.next();
            a<"u">(moduleRect, (a<"Ê">(this, 7114115039456740286L, a) - 130.0F) / 2.0F, 7114851816617921965L, a);
            a<"u">(moduleRect, a<"Ê">(this, 7114115039456740286L, a), 7114646009395815434L, a);
            a<"u">(moduleRect, a<"Ê">(this, 7115441441696507179L, a), 7114776796826754840L, a);
            a<"u">(moduleRect, a<"Ê">(this, 7115547325439121966L, a) + 100.0F + (a<"Ê">(moduleRect, 7114851816617921965L, a) + 10.0F), 7115247980469417147L, a);
            a<"u">(moduleRect, a<"Ê">(this, 7115668173906230798L, a) + 10.0F + 0.0F + moduleScroll.l(), 7114052402998617677L, a);
            if (a<"Ê">(moduleRect, 7114052402998617677L, a) + a<"Ê">(moduleRect, 7114151759620036421L, a) >= a<"Ê">(this, 7115668173906230798L, a)
               && a<"Ê">(moduleRect, 7114052402998617677L, a) <= a<"Ê">(this, 7115668173906230798L, a) + a<"Ê">(this, 7115441441696507179L, a)) {
               moduleRect.J(guiGraphics, mouseX, mouseY, partialTicks);
            }

            if (a<"Ê">(moduleRect, 7115272364932874826L, a)) {
               a<"u">(this, true, 7114580389670728119L, a);
            }

            float var10000 = 0.0F + (a<"Ê">(moduleRect, 7114151759620036421L, a) + 10.0F);
            count++;
         }

         guiGraphics.disableScissor();
         if (maxScroll > 0.0F) {
            float scrollbarX = a<"Ê">(this, 7115547325439121966L, a) + a<"Ê">(this, 7114115039456740286L, a) + 1.0F - 2.0F - 2.0F;
            float contentRatio = visibleHeight / totalContentHeight;
            float scrollbarThumbHeight = Math.max(15.0F, visibleHeight * contentRatio);
            float currentScrollValue = moduleScroll.l();
            currentScrollValue = Mth.clamp(currentScrollValue, -maxScroll, 0.0F);
            float scrollProgressForUI = maxScroll == 0.0F ? 0.0F : -currentScrollValue / maxScroll;
            float availableScrollTrackHeight = visibleHeight - 2.0F;
            float scrollbarThumbY = a<"Ê">(this, 7115668173906230798L, a) + 1.0F + (availableScrollTrackHeight - scrollbarThumbHeight) * scrollProgressForUI;
            scrollbarThumbY = Mth.clamp(
               scrollbarThumbY,
               a<"Ê">(this, 7115668173906230798L, a) + 1.0F,
               a<"Ê">(this, 7115668173906230798L, a) + 1.0F + availableScrollTrackHeight - scrollbarThumbHeight
            );
            RenderUtils.drawRectangle(guiGraphics.pose(), scrollbarX, scrollbarThumbY, 2.0F, scrollbarThumbHeight, new Color(255, 255, 255, 180).getRGB());
         }

         guiGraphics.enableScissor(
            (int)(a<"Ê">(this, 7115547325439121966L, a) + a<"Ê">(this, 7114115039456740286L, a) - 10.0F - 2.0F - 5.0F),
            (int)a<"Ê">(this, 7115668173906230798L, a) + 1,
            (int)(a<"Ê">(this, 7115547325439121966L, a) + a<"Ê">(this, 7114115039456740286L, a)),
            (int)(a<"Ê">(this, 7115668173906230798L, a) + a<"Ê">(this, 7115441441696507179L, a))
         );
         guiGraphics.disableScissor();
      }
   }

   public void D(int keyCode, int scanCode, int modifiers) {
      long a = 树友树树友友树树树友.a ^ 140047783659272L;
      a<"W">(5599681752338377085L, a);
      if (a<"Ê">(this, 5598132660786842007L, a) != null && a<"Ê">(this, 5600050423122730684L, a)) {
         a<"Ê">(this, 5598132660786842007L, a).forEach(moduleRect -> {
            long ax = 树友树树友友树树树友.a ^ 112262766851605L;
            a<"W">(4371598480375732320L, ax);
            if (a<"Ê">(moduleRect, 4371006062006901852L, ax)) {
               moduleRect.s(keyCode, scanCode, modifiers);
            }
         });
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 19;
               case 1 -> 41;
               case 2 -> 27;
               case 3 -> 56;
               case 4 -> 61;
               case 5 -> 33;
               case 6 -> 51;
               case 7 -> 25;
               case 8 -> 36;
               case 9 -> 8;
               case 10 -> 48;
               case 11 -> 13;
               case 12 -> 29;
               case 13 -> 28;
               case 14 -> 16;
               case 15 -> 14;
               case 16 -> 3;
               case 17 -> 24;
               case 18 -> 7;
               case 19 -> 39;
               case 20 -> 62;
               case 21 -> 1;
               case 22 -> 6;
               case 23 -> 37;
               case 24 -> 5;
               case 25 -> 40;
               case 26 -> 57;
               case 27 -> 11;
               case 28 -> 59;
               case 29 -> 63;
               case 30 -> 47;
               case 31 -> 9;
               case 32 -> 38;
               case 33 -> 20;
               case 34 -> 53;
               case 35 -> 21;
               case 36 -> 55;
               case 37 -> 42;
               case 38 -> 23;
               case 39 -> 49;
               case 40 -> 4;
               case 41 -> 12;
               case 42 -> 43;
               case 43 -> 58;
               case 44 -> 50;
               case 45 -> 44;
               case 46 -> 26;
               case 47 -> 31;
               case 48 -> 2;
               case 49 -> 60;
               case 50 -> 17;
               case 51 -> 35;
               case 52 -> 15;
               case 53 -> 52;
               case 54 -> 10;
               case 55 -> 54;
               case 56 -> 22;
               case 57 -> 30;
               case 58 -> 45;
               case 59 -> 46;
               case 60 -> 34;
               case 61 -> 32;
               case 62 -> 0;
               default -> 18;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 202 && var8 != 'u' && var8 != 236 && var8 != 'a') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'T') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'W') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 202) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private float s() {
      long a = 树友树树友友树树树友.a ^ 70747718343106L;
      a<"W">(1404049848481019831L, a);
      if (a<"Ê">(this, 1403628821622363997L, a) == null) {
         return 0.0F;
      } else {
         float leftColumnHeight = 0.0F;
         float rightColumnHeight = 0.0F;
         int i = 0;
         if (0 < a<"Ê">(this, 1403628821622363997L, a).size()) {
            树何何树树树友友友友 moduleRect = (树何何树树树友友友友)a<"Ê">(this, 1403628821622363997L, a).get(0);
            leftColumnHeight = 0.0F + (a<"Ê">(moduleRect, 1403932628837279364L, a) + 10.0F);
            rightColumnHeight = 0.0F + (a<"Ê">(moduleRect, 1403932628837279364L, a) + 10.0F);
            i++;
         }

         return Math.max(leftColumnHeight, rightColumnHeight);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public void h(char chr, int modifiers) {
      long a = 树友树树友友树树树友.a ^ 16500402031037L;
      a<"W">(-4394562450785949752L, a);
      if (a<"Ê">(this, -4393824798547261662L, a) != null && a<"Ê">(this, -4394932221115494391L, a)) {
         a<"Ê">(this, -4393824798547261662L, a).forEach(moduleRect -> {
            long ax = 树友树树友友树树树友.a ^ 10140591142461L;
            a<"W">(-251244433735083960L, ax);
            if (a<"Ê">(moduleRect, -252058668776563596L, ax)) {
               moduleRect.v(chr, modifiers);
            }
         });
      }
   }

   public void h() {
      long a = 树友树树友友树树树友.a ^ 135655391798182L;
      a<"W">(7572825714828283347L, a);
      if (a<"Ê">(this, 7574645286386232633L, a) != null) {
         a<"Ê">(this, 7574645286386232633L, a).forEach(树何何树树树友友友友::h);
      }

      a<"u">(this, false, 7573194265389742610L, a);
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      b[0] = "\u0016y\u0016\u000f\\\u0017\u00199[\u0004V\n\u001cdPBF\u0011[栆右桽栢厳厾栆栩桽司";
      b[1] = "\u007fmN_RPaeT\u00100Lfx";
      b[2] = "[H\"\u001e\u0017#T\bo\u0015\u001d>QUdS\r%\u0016样余伨桩桝栩叭叇厶厳";
      b[3] = float.class;
      c[3] = "java/lang/Float";
      b[4] = "Ci\u0017\";?L)Z)1\"ItQo!9\u000e栖史桐原伅併双史伔企";
      b[5] = "elY\u0002\u00069QOVBK2[RS\u001f@tSO^\u0019D?\u0010mU\b]6[\u001b";
      b[6] = ",`08}\u0011'o!w\u0001\b(u/468>b#)'\u0014)o";
      b[7] = "\u0010\u0005%\u000f2\u0003\u000e\r?@T\u0017\t\f\u001e\u000fl";
      b[8] = "y#\u001b\u0018I\u000fvcV\u0013C\u0012s>]UK\u000f~8Y\u001e\b伵住历你伮叭伵住桜栤";
      b[9] = boolean.class;
      c[9] = "java/lang/Boolean";
      b[10] = "pOsc\fJ{@b,mDpKfv";
      b[11] = "k\u0007\\f6N=C\u0001V反佶桃伧叽桏反叨桃伧>o0K4\u0003@h~\u0013%";
      b[12] = "o@{Ob\b2D=\u001bY栭伋叭桛核桀栭厕叭桛!c^=E;]0HhU";
      b[13] = "\r/h\u007fqk[k5O厊反叿厑佗桖厊栗叿桋\nu#eW+v&50G";
      b[14] = "\u0007 DR\fdZ$\u0002\u00067桁佣厍厾佡栮厛叽伓传<\r2U%\u0004@^$\u00005";
      b[15] = "kCc^f>=\u0007>n伃厘伇叽栘厭伃伆桃佣\u0001T401G}\u0007\"e!";
      b[16] = "]$~hqL\u0000 8<J厳伹桓厄栟桓伭伹厉厄\u0006p\u001a\u000f!>z#\fZ1";
      b[17] = "!9[F\u0015\u0018jmR\u001e,F\u001a<LP\\EkcM\u001fA\"";
      b[18] = "\tFTZG\r_\u0002\tj\u0016h\u0004@P\u0013\u001cYF\u0001]U\u007fTC]O\tN\u0016\u0002P\tj";
      b[19] = "19sD.\tg}.t叕桵參伙栈桭栏桵佝厇\u0011I\u007f\u000b>=.\u0012*\u0006f";
      b[20] = "\u0019|\u000e\n)lO8S:佌及併作厯佧叒栐叫栘l\u0004}`\u0017`\u0017U/e\u0010";
      b[21] = "i\u0019JDaL4\u001d\f\u0010Z厳厓桮桪叩桃厳桉桮厰*`\u001a;\u001c\nV3\fn\f";
      b[22] = ",BBf Iz\u0006\u001fV栁可叞佢根厕栁栵栄叼 lrGvF\\?d\u0012f";
      b[23] = "n9(zZ;3=n.a栞厔桎栈栍厢叄伊厔栈\u0014[m<<hh\b{i,";
      b[24] = "Q\u0001]\u0019F\u0014\u0007E\u0000)桧伬厣桥叼只桧伬桹桥?\u0013\u0014\u001a\u000b\u0005C@\u0002O\u001b";
      b[25] = "\u0001X]Y\u0004yW\u001c\u0000i佡佁栩格佢厪佡佁佭另?WPu\u000fDD\u0006\u0002p\b";
      b[26] = "BN\u0000\\b\u0015\u0014\n]l桃厳厰台伿伱厙厳伮株bV0\u001b\u0018J\u001e\u0005&N\b";
      b[27] = "pj\u0001\\\u001aE&.\\l叡根桘栎伾厯使口桘叔cVHK*n\u001f\u0005^\u001e:";
      b[28] = "N\fU\u0004JZ\u0018H\b4厱佢桦桨栮栭桫叼桦桨7\t\u0003\u0007E\u000bPJ\u0019N\u0000";
      b[29] = "jL>U6o7Hx\u0001\r桊厐使佚佦収厐桊使叄;798I~Gd/mY";
      b[30] = "\u000f*#<\u0014mR.eh/厒叵厇叙伏栶案佫伙叙R\u0011=_{{)@oZ|";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友树树友友树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private void o(GuiGraphics guiGraphics) {
      long a = 树友树树友友树树树友.a ^ 122399388433849L;
      Color accentColor = HUD.instance.getColor(0);
      float decorX = a<"Ê">(this, -5258549043772371052L, a) + a<"Ê">(this, -5260194497573644796L, a) - 10.0F;
      int repetitions = (int)Math.ceil(a<"Ê">(this, -5258725126344265583L, a) / 125.0F) + 1;
      a<"W">(-5258233010864958516L, a);
      float startOffset = -125.0F * a<"Ê">(this, -5258300687724750890L, a);
      int i = 0;
      if (0 < repetitions) {
         float currentY = a<"Ê">(this, -5258639114445100108L, a) + startOffset + 0.0F;
         this.j(guiGraphics, decorX, currentY, 40.0F, accentColor, 1.0F);
         currentY += 55.0F;
         this.j(guiGraphics, decorX, currentY, 25.0F, accentColor, 0.8F);
         currentY += 40.0F;
         this.j(guiGraphics, decorX, currentY, 15.0F, accentColor, 0.6F);
         float var10000 = currentY + 30.0F;
         i++;
      }
   }

   private boolean p(float x, float y, float width, float height, double mouseX, double mouseY) {
      long a = 树友树树友友树树树友.a ^ 20111520334140L;
      a<"W">(5441049801124654921L, a);
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   public void t() {
      long a = 树友树树友友树树树友.a ^ 16812511667696L;
      a<"W">(-1202917433351795835L, a);
      if (a<"Ê">(this, -1203294712145583079L, a) != null) {
         树友友友何树树树树友 moduleScroll = (树友友友何树树树树友)a<"Ê">(this, -1202768220857121198L, a).get(a<"Ê">(this, -1203294712145583079L, a));
         if (moduleScroll != null) {
            moduleScroll.g();
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void j(GuiGraphics guiGraphics, float x, float y, float height, Color baseColor, float alpha) {
      Color color = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), (int)(255.0F * alpha));
      RenderUtils.drawRectangle(guiGraphics.pose(), x, y, 2.0F, height, color.getRGB());
      Color glowColor = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), (int)(120.0F * alpha));
      RenderUtils.drawRectangle(guiGraphics.pose(), x - 1.0F, y, 1.0F, height, glowColor.getRGB());
   }

   private void U(float partialTicks) {
      long a = 树友树树友友树树树友.a ^ 11609541004708L;
      a<"W">(-8711539260489374767L, a);
      a<"u">(this, a<"Ê">(this, -8711185714890840117L, a) + 0.02F * partialTicks, -8711185714890840117L, a);
      if (a<"Ê">(this, -8711185714890840117L, a) > 1.0F) {
         a<"u">(this, a<"Ê">(this, -8711185714890840117L, a) - 1.0F, -8711185714890840117L, a);
      }
   }

   public void w(List<树何何树树树友友友友> moduleRects) {
      long a = 树友树树友友树树树友.a ^ 82237919784494L;
      a<"u">(this, moduleRects, 2636499597378003121L, a);
   }

   public void u(double mouseX, double mouseY, int button) {
      long a = 树友树树友友树树树友.a ^ 117002866270929L;
      a<"W">(-1698132126010962780L, a);
      if (a<"Ê">(this, -1698863155474209992L, a) != null && a<"Ê">(this, -1699657200108311474L, a) != null) {
         树友友友何树树树树友 moduleScroll = (树友友友何树树树树友)a<"Ê">(this, -1697982887746354829L, a).get(a<"Ê">(this, -1698863155474209992L, a));
         float totalContentHeight = this.s();
         float visibleHeight = a<"Ê">(this, -1698626273019072519L, a);
         float maxScroll = Math.max(0.0F, totalContentHeight - visibleHeight);
         if (maxScroll > 0.0F && button == 0) {
            float scrollbarX = a<"Ê">(this, -1698449992678436612L, a) + a<"Ê">(this, -1700093728482277012L, a) + 1.0F - 2.0F - 2.0F;
            float contentRatio = visibleHeight / totalContentHeight;
            float scrollbarThumbHeight = Math.max(15.0F, visibleHeight * contentRatio);
            float currentScrollValue = moduleScroll.l();
            currentScrollValue = Mth.clamp(currentScrollValue, -maxScroll, 0.0F);
            float scrollProgressForUI = maxScroll == 0.0F ? 0.0F : -currentScrollValue / maxScroll;
            float availableScrollTrackHeight = visibleHeight - 2.0F;
            float scrollbarThumbY = a<"Ê">(this, -1698549005797083940L, a) + 1.0F + (availableScrollTrackHeight - scrollbarThumbHeight) * scrollProgressForUI;
            scrollbarThumbY = Mth.clamp(
               scrollbarThumbY,
               a<"Ê">(this, -1698549005797083940L, a) + 1.0F,
               a<"Ê">(this, -1698549005797083940L, a) + 1.0F + availableScrollTrackHeight - scrollbarThumbHeight
            );
            if (mouseX >= scrollbarX && mouseX <= scrollbarX + 2.0F && mouseY >= scrollbarThumbY && mouseY <= scrollbarThumbY + scrollbarThumbHeight) {
               a<"u">(this, true, -1698676667737586224L, a);
               a<"u">(this, (float)mouseY - scrollbarThumbY, -1699924915010020338L, a);
               return;
            }
         }

         if (mouseX >= a<"Ê">(this, -1698449992678436612L, a) + 90.0F
            && mouseX <= a<"Ê">(this, -1698449992678436612L, a) + a<"Ê">(this, -1700093728482277012L, a) - 20.0F
            && mouseY >= a<"Ê">(this, -1698549005797083940L, a)
            && mouseY <= a<"Ê">(this, -1698549005797083940L, a) + a<"Ê">(this, -1698626273019072519L, a)) {
         }

         Iterator var21 = a<"Ê">(this, -1699657200108311474L, a).iterator();
         if (var21.hasNext()) {
            树何何树树树友友友友 moduleRect = (树何何树树树友友友友)var21.next();
            if (this.p(
               a<"Ê">(moduleRect, -1698960443959837079L, a),
               a<"Ê">(moduleRect, -1700015560884245345L, a),
               a<"Ê">(moduleRect, -1698019603866105985L, a),
               a<"Ê">(moduleRect, -1699845558631670377L, a),
               mouseX,
               mouseY
            )) {
               moduleRect.n(mouseX, mouseY, button);
               a<"u">(this, a<"Ê">(moduleRect, -1698733742989850472L, a), -1698291339991696539L, a);
               return;
            }
         }

         this.h();
      }
   }

   public void r(double mouseX, double mouseY, double delta) {
      long a = 树友树树友友树树树友.a ^ 107289500481551L;
      a<"W">(-5570655692581742982L, a);
      if (a<"Ê">(this, -5570276489658779162L, a) != null) {
         if (mouseX >= a<"Ê">(this, -5569845224035104222L, a) + 90.0F
            && mouseX <= a<"Ê">(this, -5569845224035104222L, a) + a<"Ê">(this, -5569257019427679310L, a) - 20.0F
            && mouseY >= a<"Ê">(this, -5569966132975669758L, a)
            && mouseY <= a<"Ê">(this, -5569966132975669758L, a) + a<"Ê">(this, -5570020790942485209L, a)) {
         }

         树友友友何树树树树友 moduleScroll = (树友友友何树树树树友)a<"Ê">(this, -5570523436541305939L, a).get(a<"Ê">(this, -5570276489658779162L, a));
         if (moduleScroll != null) {
            moduleScroll.d((float)delta * 30.0F);
         }
      }
   }

   public void y(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      long a = 树友树树友友树树树友.a ^ 41551849067981L;
      a<"W">(-2345449104793125960L, a);
      if (button == 0 && a<"Ê">(this, -2345995862716583220L, a)) {
         树友友友何树树树树友 var10000 = (树友友友何树树树树友)a<"Ê">(this, -2345317486622935441L, a).get(a<"Ê">(this, -2346336556428962780L, a));
      }
   }

   public void M(double mouseX, double mouseY, int button) {
      long a = 树友树树友友树树树友.a ^ 117064743316486L;
      a<"W">(2789986315226628723L, a);
      if (button == 0 && a<"Ê">(this, 2790567673413044999L, a)) {
         a<"u">(this, false, 2790567673413044999L, a);
      }

      if (a<"Ê">(this, 2791839078023373465L, a) != null) {
         a<"Ê">(this, 2791839078023373465L, a).forEach(moduleRect -> moduleRect.M(mouseX, mouseY, button));
      }
   }

   public void R() {
      long a = 树友树树友友树树树友.a ^ 93379776471279L;
      a<"W">(3049283639123627674L, a);
      if (a<"Ê">(this, 3051087920731795056L, a) != null) {
         a<"Ê">(this, 3051087920731795056L, a).forEach(树何何树树树友友友友::m);
      }
   }

   private static String HE_WEI_LIN() {
      return "何树友，和树做朋友";
   }
}
