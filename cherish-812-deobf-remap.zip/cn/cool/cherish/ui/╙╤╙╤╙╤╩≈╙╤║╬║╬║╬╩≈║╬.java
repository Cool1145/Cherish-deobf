package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.unsafe.UnsafeUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import why.tree.friend.antileak.Fucker;

public class 友友友树友何何何树何 extends Screen implements 何树友 {
   private static String[] 友何树何友树树树何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long e;
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[23];
   private static final String[] j = new String[23];
   private static String HE_SHU_YOU;

   public 友友友树友何何何树何() {
      long a = 友友友树友何何何树何.a ^ 77967885736088L;
      super(Component.literal(a<"x">(21250, 1658586065224842405L ^ a)));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-6333573110437566568L, 503964052486577485L, MethodHandles.lookup().lookupClass()).a(236514397948173L);
      // $VF: monitorexit
      a = var10000;
      long var25 = a ^ 96465389140648L;
      a();
      String[] var29 = new String[5];
      c<"s">(var29, 469217889021258325L, var25);
      Cipher var16;
      Cipher var30 = var16 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var25 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var17 = 1; var17 < 8; var17++) {
         var10003[var17] = (byte)(var25 << var17 * 8 >>> 56);
      }

      var30.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var23 = new String[5];
      int var21 = 0;
      String var20 = "\u0013tV\fH¦3*CÎV1BËf3¤´Ì\u008fÍ\u009fº3\u009aí6\u0002\u0013rï\u008e}A¢\u008d1i\u0016\u000eØn©\u0007Ø3¼\u0003\u0082¥Nxr\u008d§à\u0089\u008aÑ§\u0007{\u0098×}FVôw`ø\u001clÖÙ)·\u0095þý\u0010\u009dø'³\u008eYv\u0096DÀÜáº\u0019vë\u0018\u0081¿úL«Îâi\u0097\u001bÓò\u009d\u009bf\f\u0096_WJ\u009dW{ª";
      short var22 = 122;
      char var19 = 'P';
      int var28 = -1;

      label57:
      while (true) {
         String var31 = var20.substring(++var28, var28 + var19);
         int var10001 = -1;

         while (true) {
            String var42 = a(var16.doFinal(var31.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var23[var21++] = var42;
                  if ((var28 += var19) >= var22) {
                     b = var23;
                     c = new String[5];
                     Cipher var11;
                     Cipher var33 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var25 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(var25 << var12 * 8 >>> 56);
                     }

                     var33.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var15 = var11.doFinal(new byte[]{-89, 124, -81, 6, 120, 90, 39, -95});
                     long var46 = (var15[0] & 255L) << 56
                        | (var15[1] & 255L) << 48
                        | (var15[2] & 255L) << 40
                        | (var15[3] & 255L) << 32
                        | (var15[4] & 255L) << 24
                        | (var15[5] & 255L) << 16
                        | (var15[6] & 255L) << 8
                        | var15[7] & 255L;
                     var10001 = (byte)-1;
                     e = var46;
                     h = new HashMap(13);
                     Cipher var0;
                     Cipher var34 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var25 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var25 << var1 * 8 >>> 56);
                     }

                     var34.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "UËí\u0084 ¿\u001d\u007fa\u008b]¨\u0081M\u000fø".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var50 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     f = var6;
                     g = new Long[2];
                     return;
                  }

                  var19 = var20.charAt(var28);
                  break;
               default:
                  var23[var21++] = var42;
                  if ((var28 += var19) < var22) {
                     var19 = var20.charAt(var28);
                     continue label57;
                  }

                  var20 = "\u0088ê í{°Û°ºùõMJ\u0015a\u0098ùÊö©æ$\u00882Ø8zoC\u0094\u001c\u009c)a\u0015\u000bÁùï=í 2jfää¼Ì\u0016^°QÄú©5Ï\u0094j\u0086ðMÌ7dq\u009d¾L¾\u001f@e\\)ÂäÏ\nq¿n\u001cô]\u0001fNÈaÏo;ÁïoÔ$µ\u0082\u0081»HûÜ\u0095\u0014\u0091´Âü\u0012ä'ÞA\tèÍÃk\u001f\u0010=°ÏTKZPgmJ¤1ÐÚÛàÚÚèOJ^oÿý0\u0099FàÚ+\u0018\u0006Ô\u001b<2jE\u0089\u008eìf%½GE·Û±\u008aV´\u000f\u0094ÿ-\u001aZ\u000b\u0084æ\u0006ø¤÷\u009aÀÅ\u0018GÅ\u000eÔs\u0010\u0010û³ëÎá\u0018¨\n÷\u00ad»õ,ôµ^";
                  var22 = 217;
                  var19 = 200;
                  var28 = -1;
            }

            var31 = var20.substring(++var28, var28 + var19);
            var10001 = 0;
         }
      }
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12501;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/友友友树友何何何树何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友友树友何何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友友树友何何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static void l(String[] var0) {
      友何树何友树树树何何 = var0;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      i[0] = "t\u0007*j\u001e`{Gga\u0014}~\u001al'\u0004f9厢叏参桠叄佂似佑栘伤";
      i[1] = "DZrG@c1zyHQ,LbjOXe$";
      i[2] = void.class;
      j[2] = "java/lang/Void";
      i[3] = "mF@.=\u001db\u0006\r%7\u0000g[\u0006c?\u001dj]\u0002(|?aL\u001b!7";
      i[4] = boolean.class;
      j[4] = "java/lang/Boolean";
      i[5] = "W\u001cs8\u0007\"\"<x7\u0016m_$k0\u001f$7";
      i[6] = int.class;
      j[6] = "java/lang/Integer";
      i[7] = "[\u0013TI}jP\u001cE\u0006\u0001s_\u0006KE6CI\u0011GX'o^\u001c";
      i[8] = "T\\\u0018uj,T\\\u000f)f#N\u0017\u000f7n TMB<r,\u0014\u007f\u00035s";
      i[9] = "iup\r\n-t`(/K lf";
      i[10] = "{,\u0001JbWtlLAhJq1G\u0007xQ6众古佼佘佭位桓栾佼栜";
      i[11] = "\u0016z(hg\f\u001du9'\u0006\u0002\u0016~=}";
      i[12] = "ew]s&2`rJr\u0017\f_\"Vzg(8cAxkO";
      i[13] = "\fG[\u0018|tM\u0018Z\u0019\u0011伐台伦厨栱叒厎佮厸伶(.q\u0003K\u0006\u0011o.\u0002J";
      i[14] = "|\u0013sOU6l\u0013m4^\b'V/\b\f\b\u0016TnSY$,\u0011uOA";
      i[15] = "x2\u0010\u0010Y\u001e}7\u0007\u0011h*Bg\u001b\u0019\u0018\u0004%&\f\u001b\u0014c{;\u0016\u0000\u0004\u0013'e\u0004\rh";
      i[16] = "{D#\u0016yGkD=mU.*E2\u001flUw\u000e/]\u001c";
      i[17] = "\u0014\u0015Ru/:G\u001eJ.WTj9\u007f_W5G\tDjffL\u0011\u001f";
      i[18] = "Jz,aI\u007fZz2\u001aH\u0016\u001b{=h\\mF0 *,/Gb=v\\s\u0019p0\u001a";
      i[19] = "_20\b_\u0003O2.sT=\u0004wlO\u0005=5t4\u0018[\r^$-\u0016\n";
      i[20] = "\u001b0|\u0016\b\u0004\u000b0bm\u0003:@u QV:qwa\n\u0004\u0016K2z\u0016\u001c";
      i[21] = "lu3oE/ip$nt?V 8f\u000451a/d\bR";
      i[22] = "\tG)\b\\\u0006\u0019G7sPo^\\1\u0017\t\b\u0012Q/K9R\u0003E,C^\u001e\u000e[ps";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 39;
               case 1 -> 43;
               case 2 -> 40;
               case 3 -> 4;
               case 4 -> 50;
               case 5 -> 35;
               case 6 -> 0;
               case 7 -> 49;
               case 8 -> 7;
               case 9 -> 9;
               case 10 -> 36;
               case 11 -> 14;
               case 12 -> 55;
               case 13 -> 31;
               case 14 -> 59;
               case 15 -> 42;
               case 16 -> 34;
               case 17 -> 25;
               case 18 -> 6;
               case 19 -> 33;
               case 20 -> 16;
               case 21 -> 15;
               case 22 -> 8;
               case 23 -> 13;
               case 24 -> 51;
               case 25 -> 54;
               case 26 -> 47;
               case 27 -> 10;
               case 28 -> 18;
               case 29 -> 23;
               case 30 -> 32;
               case 31 -> 48;
               case 32 -> 37;
               case 33 -> 41;
               case 34 -> 57;
               case 35 -> 52;
               case 36 -> 21;
               case 37 -> 1;
               case 38 -> 60;
               case 39 -> 46;
               case 40 -> 53;
               case 41 -> 2;
               case 42 -> 27;
               case 43 -> 3;
               case 44 -> 28;
               case 45 -> 22;
               case 46 -> 44;
               case 47 -> 5;
               case 48 -> 63;
               case 49 -> 30;
               case 50 -> 38;
               case 51 -> 29;
               case 52 -> 19;
               case 53 -> 61;
               case 54 -> 20;
               case 55 -> 45;
               case 56 -> 12;
               case 57 -> 62;
               case 58 -> 11;
               case 59 -> 24;
               case 60 -> 26;
               case 61 -> 56;
               case 62 -> 58;
               default -> 17;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 162 && var8 != 'G' && var8 != 'a' && var8 != 244) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'E') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 's') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 162) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'G') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'a') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友友树友何何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 19219;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友友友树友何何何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   public static String[] A() {
      return 友何树何友树树树何何;
   }

   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      long a = 友友友树友何何何树何.a ^ 128500384046257L;
      guiGraphics.fill(0, 0, c<"¢">(this, 2349313272476658440L, a), c<"¢">(this, 2349994586283097542L, a), (int)e);
      c<"s">(2349597307809000629L, a);
      guiGraphics.drawCenteredString(
         c<"¢">(this, 2349625680453715683L, a),
         a<"x">(5411, 5678182186228219567L ^ a),
         c<"¢">(this, 2349313272476658440L, a) / 2,
         c<"¢">(this, 2349994586283097542L, a) / 2 - 20,
         c<"a">(2349511049544783503L, a).getRGB()
      );
      guiGraphics.drawCenteredString(
         c<"¢">(this, 2349625680453715683L, a),
         a<"x">(17973, 8907286542191242682L ^ a),
         c<"¢">(this, 2349313272476658440L, a) / 2,
         c<"¢">(this, 2349994586283097542L, a) / 2,
         c<"a">(2349511049544783503L, a).getRGB()
      );
      super.render(guiGraphics, mouseX, mouseY, partialTick);
      if (c<"s">(2349826418585650286L, a)) {
         c<"s">(new String[1], 2349713857492077644L, a);
      }
   }

   private static String HE_DA_WEI() {
      return "何树友为什么濒天了";
   }

   public void onClose() {
      super.onClose();
   }

   protected void init() {
      long a = 友友友树友何何何树何.a ^ 116524475459354L;
      super.init();
      c<"s">(1959188335295616798L, a);
      int agreeButtonX = c<"¢">(this, 1959473609690697891L, a) / 2 - 65;
      int declineButtonX = c<"¢">(this, 1959473609690697891L, a) / 2 + 5;
      int buttonsY = c<"¢">(this, 1961254436189210221L, a) / 2 + 20;
      Button agreeButton = Button.builder(Component.literal(a<"x">(5068, 601987142030181354L ^ a)), button -> {
         long ax = 友友友树友何何何树何.a ^ 44961157051525L;
         c<"a">(-3987809048084931329L, ax).J();
      }).bounds(agreeButtonX, buttonsY, 60, 20).build();
      Button declineButton = Button.builder(Component.literal(a<"x">(24942, 4808693955790451021L ^ a)), button -> {
         long ax = 友友友树友何何何树何.a ^ 37237992350562L;
         Cherish.SHOULD_START = true;
         Cherish.MODULE_SHOULD_START = false;
         Cherish.M();
         Cherish.setMinecraft();
         UnsafeUtils.freeMemory();
         Cherish.instance.getEventManager().register(null);
         Cherish.instance.B(null);
         Cherish.instance.R(null);
         Cherish.instance.o(null);
         Cherish.instance.getModuleManager().C();
         RotationUtils.init();
         Cherish.instance = null;
         Fucker.init(new Object[]{0, 6, 0, 4});
         UnsafeUtils.p(new Object[]{b<"k">(24157, 967330407629795781L ^ ax)});
         UnsafeUtils.p(new Object[]{b<"k">(921, 8228768538085125120L ^ ax)});
         UnsafeUtils.p(new Object[]{b<"k">(921, 8228768538085125120L ^ ax)});
         UnsafeUtils.p(new Object[]{b<"k">(921, 8228768538085125120L ^ ax)});
      }).bounds(declineButtonX, buttonsY, 60, 20).build();
      this.addRenderableWidget(agreeButton);
      this.addRenderableWidget(declineButton);
      c<"s">(!c<"s">(1959405486891441885L, a), 1961178225725484355L, a);
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }
}
