package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.animations.何何树何树何树树何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 何何何友何友何树友友 implements IWrapper, 何树友 {
   public static 何何树何树何树树何何 友树友友何何友何树树;
   public static 何何树何树何树树何何 友何树友树树何何友友;
   private static String[] 友树何友友树何何树树;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[19];
   private static final String[] e = new String[19];
   private static String HE_DA_WEI;

   private 何何何友何友何树友友() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(5629936757176860117L, 1841982122410068269L, MethodHandles.lookup().lookupClass()).a(243396188329949L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (E() != null) {
         A(new String[1]);
      }

      Cipher var0;
      Cipher var2 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(38613251286931L << var1 * 8 >>> 56);
      }

      var2.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var3 = b(
            var0.doFinal(
               "\u001d\u0088\u0010=Âk$\u0019\u0099jæK{\u009aÓW\u0016k`\u008eh¯ºHÔ \u008bá§\u001fËd\u001cd>\u001anM1-F©\u0007A~íð=íî \u001d(©\u0016\u0000"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      byte var10001 = -1;
      b = var3;
      友树友友何何友何树树 = new 何何树何树何树树何何((short)0, 760481532, 62373);
      友何树友树树何何友友 = new 何何树何树何树树何何((short)0, 760481532, 62373);
   }

   public static void B(PoseStack poseStack, String text, float progress, float ticks, int y) {
      int x = mc.getWindow().getGuiScaledWidth() / 2 - 45;
      float target = 80.0F * progress;
      友树友友何何友何树树.g(Math.min(target, 80.0F), 36433523484945L, 40);
      E();
      RenderUtils.drawGradientRectL2R(poseStack, x, y, 90.0F, 1.0F, HUD.instance.getColor(1).getRGB(), HUD.instance.getColor(4).getRGB());
      RenderUtils.drawRectangle(poseStack, x, y, 90.0F, 25.0F, new Color(0, 0, 0, 80).getRGB());
      RenderUtils.drawRectangle(poseStack, x + 5, y + 15, 80.0F, 7.0F, new Color(0, 0, 0, 80).getRGB());
      RenderUtils.drawGradientRectL2R(
         poseStack, x + 5, y + 15, 友树友友何何友何树树.S(69444441903267L), 7.0F, HUD.instance.getColor(0).getRGB(), HUD.instance.getColor(4).getRGB()
      );
      Cherish.instance.t().H(18).h(poseStack, text + ticks, x + 45, y + 5, new Color(225, 225, 225, 160).getRGB());
      if (Module.Z() == null) {
         A(new String[2]);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 57;
               case 2 -> 58;
               case 3 -> 0;
               case 4 -> 36;
               case 5 -> 3;
               case 6 -> 6;
               case 7 -> 33;
               case 8 -> 15;
               case 9 -> 63;
               case 10 -> 18;
               case 11 -> 54;
               case 12 -> 8;
               case 13 -> 27;
               case 14 -> 50;
               case 15 -> 34;
               case 16 -> 61;
               case 17 -> 22;
               case 18 -> 45;
               case 19 -> 28;
               case 20 -> 51;
               case 21 -> 59;
               case 22 -> 10;
               case 23 -> 31;
               case 24 -> 35;
               case 25 -> 44;
               case 26 -> 32;
               case 27 -> 39;
               case 28 -> 25;
               case 29 -> 16;
               case 30 -> 62;
               case 31 -> 5;
               case 32 -> 13;
               case 33 -> 55;
               case 34 -> 48;
               case 35 -> 1;
               case 36 -> 30;
               case 37 -> 52;
               case 38 -> 4;
               case 39 -> 41;
               case 40 -> 43;
               case 41 -> 14;
               case 42 -> 2;
               case 43 -> 46;
               case 44 -> 49;
               case 45 -> 40;
               case 46 -> 17;
               case 47 -> 53;
               case 48 -> 26;
               case 49 -> 7;
               case 50 -> 12;
               case 51 -> 60;
               case 52 -> 23;
               case 53 -> 21;
               case 54 -> 19;
               case 55 -> 37;
               case 56 -> 47;
               case 57 -> 24;
               case 58 -> 11;
               case 59 -> 20;
               case 60 -> 9;
               case 61 -> 29;
               case 62 -> 56;
               default -> 38;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'V' && var8 != 'X' && var8 != 216 && var8 != 197) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 234) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 235) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'V') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'X') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 216) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何何友何友何树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      c[0] = "kPD\u0010=Ad\u0010\t\u001b7\\aM\u0002]'G&佫伿伦厙佻參佫桻厸厙";
      c[1] = "\rmt8\u001f\"xM\u007f7\u000em\u0005Ul0\u0007$m";
      c[2] = "\u0015a,t\u0014&\u001a!a\u007f\u001e;\u001f|j9\u000e=\u001fcq9\u001a'\u001fbcc\u0012&\u0018|,佂伮桘伣栞佗栆桪伜伣";
      c[3] = "\u001da0\n=k\u0012!}\u00017v\u0017|vG?k\u001azr\f|I\u0011kk\u00057";
      c[4] = "\u0005f\u0005!8\u000f1E\nau\u0004;X\u000f<~B3E\u0002:z\tpg\t+c\u0000;\u0011";
      c[5] = "8\u000blV@\u000fM+gYQ@03t^X\tX";
      c[6] = void.class;
      e[6] = "java/lang/Void";
      c[7] = "\fh~Z0S\u0007go\u0015KQ\u0015|xKqM\u0012lltnZ\u0014h|RqQ#qk^nK\u000fff";
      c[8] = "MF}J\r\"PS%hL/HU";
      c[9] = "l\fT~EfX/[>\bmR2^c\u0003+Z/Se\u0007`\u0019\rXt\u001eiR{";
      c[10] = "_M5\u001dd{TB$R\u0005u_I \b";
      c[11] = "r\bFO,v'\u0013Is厐栉叚厱佰伮厐位栀桫-J6/&\u0019U\u001d(we";
      c[12] = "p}Bx$()vLiY\u001aJ.\u0011/%'w(\u0012sdH";
      c[13] = "]\u000e\tk\u0016'\b\u0015\u0006W厪伜栯厷桻桎伴伜叵厷bn\f~\t\u001f\u001a9\u0012&J";
      c[14] = "U\tB`Zq\u0000\u0012M\\h\u0017\u0005\tO-\u001d/AKHa%";
      c[15] = "s\u0019sqa=*\u0012}`\u001c\u0003IJ &`2tL#z!]u\u000f,j%;8\u0014va\u001c";
      c[16] = "F~\u000bg\u0001)\u0013e\u0004[7O\u0016~\u0006*FwR<\u0001f~sVe\u0012b\u0018>M?\u0019[";
      c[17] = "mzp=&\u00018a\u007f\u00010g;:w>9Vcr~lYZ<l$ah\u0002tev\u0001";
      c[18] = ")=>!g^%$45\\uP\n\u001e\r\\\u0002j(:u=\u000es\".";
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void U(PoseStack poseStack, float progress, int y) {
      int x = mc.getWindow().getGuiScaledWidth() / 2 - 68;
      E();
      float target = 120.0F * progress;
      友树友友何何友何树树.g(Math.min(target, 120.0F), 36433523484945L, 40);
      友何树友树树何何友友.g(Math.min(target, 120.0F), 36433523484945L, 80);
      Color color = HUD.instance.getColor(1);
      Color color2 = HUD.instance.getColor(4);
      ShaderUtils.u(poseStack, x + 9, (float)(y + 6.5), 70079527892595L, 122.0F, 7.0F, 1.0F, 9.0F, Color.BLACK);
      RenderUtils.drawRoundedRect(poseStack, x + 9, (float)(y + 6.5), 122.0, 7.0, 0.0, new Color(0, 0, 0, 150));
      RenderUtils.drawGradientRectL2R(
         poseStack, x + 10, (float)(y + 7.5), 友何树友树树何何友友.S(69444441903267L), 5.0F, HUD.instance.getColor(0).getRGB(), HUD.instance.getColor(4).getRGB()
      );
      RenderUtils.drawGradientRectL2R(
         poseStack,
         x + 10,
         (float)(y + 7.5),
         友树友友何何友何树树.S(69444441903267L),
         5.0F,
         new Color(color.getRed(), color.getGreen(), color.getBlue(), 150).getRGB(),
         new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), 150).getRGB()
      );
      Cherish.instance.t().H(20).h(poseStack, Math.round(progress * 100.0F) + "%", x + 71, y + 5.0F, new Color(225, 225, 225).getRGB());
      Module.V(new Module[2]);
   }

   public static String[] E() {
      return 友树何友友树何何树树;
   }

   public static void A(String[] var0) {
      友树何友友树何何树树 = var0;
   }

   private static String HE_SHU_YOU() {
      return "何炜霖230622200409390090";
   }
}
