package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.value.树何何何友树树何友何;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.gui.GuiGraphics;

public class 树树何何树何树友何友 implements 何树树友树树友友何何, 何树友 {
   private static String 友树友何树友何友何何;
   private static final long a;
   private static final Object[] b = new Object[20];
   private static final String[] c = new String[20];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8827612564344622062L, 3592206162920950803L, MethodHandles.lookup().lookupClass()).a(201599165329770L);
      // $VF: monitorexit
      a = var10000;
      long var0 = a ^ 79881798857288L;
      a();
      if (a<"Ô">(-5926818687885484018L, var0) == null) {
         a<"Ô">("v1nkcc", -5928827917380424900L, var0);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'Q' && var8 != 'r' && var8 != 192 && var8 != 200) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 193) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 212) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'Q') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'r') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 192) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树何何树何树友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "g'h\u0007pkhg%\fzvm:.Jjm*桘厍伱栎佑栕伜厍厯叔";
      b[1] = "%#^rM<*c\u0013yG!/>\u0018?W:h桜去叚叩桂桗桜桡栀佷";
      b[2] = "NAnq7TA\u0001#z=ID\\(<-R\u0003栾桑佇伍株佸栾压佇厓";
      b[3] = "\u0015_\u0000\u007fr9\u001eP\u00110\u000f!\rW\u0018y";
      b[4] = void.class;
      c[4] = "java/lang/Void";
      b[5] = boolean.class;
      c[5] = "java/lang/Boolean";
      b[6] = "|px@\u0014\u0000s05K\u001e\u001dvm>\r\u0016\u0000{k:FU\"pz#O\u001e";
      b[7] = "}x\u0015i\u0003\u0001vw\u0004&\u007f\u0018ym\neH(oz\u0006xY\u0004xw";
      b[8] = "Gxb$=fH8//7{Me$i'`\n叝伙伒桃参佱佃伙伒桃";
      b[9] = "5:+N:)(/sl{$0)";
      b[10] = "\u0018\u0019f\u0011rr\u0013\u0016w^\u0013|\u0018\u001ds\u0004";
      b[11] = "e7\u001d!r:'}\u000bD栋佛叚佒厦厇住栟佄栖e\u007fm<|`X'#>x";
      b[12] = "&\u0006\u000f2[\u001fv\u001eL:j4\u001aD\u000e0\u000f\u0012'\u001c@2\u000b}!\u0013\rr\u0010\u0010~E\u0012jj";
      b[13] = "$y?/y\u0019cp9o\u0012L\u001e|tb\u007fGf:;sy%#q5~p]e>$x\u0012";
      b[14] = "/\u00067d\u001b;h\u000f1$p^\u0015\u0004!4\u0001wv\u0001> \u0015\u0007";
      b[15] = "dY\u0001~XFuN\u0012B司可栞栧厼厁栢佱栞栧\u007f>\u0003Tb^C|IB";
      b[16] = "b\u0000\u000f\t?v J\u0019l伂厉叝佥厴桵伂桓标佥wQ%:l^\u000b\u0010a.$";
      b[17] = "%\u0011!%d\"g[7@叇叝厚只伄桙栝标桀栰Y~kqb\u0012g~nqg";
      b[18] = ",@M\u0007\u0014^kIKG\u007f!\u0016B[W\u000e\u0012uGDC\u001ab-\u0014JC\u0005\u000frBU[\u007f";
      b[19] = "\u000f\u0018EG\u001d\u001e_\u0000\u0006O,\u00113ZDEI\u0013\u000e\u0002\nGM|";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 7;
               case 1 -> 52;
               case 2 -> 59;
               case 3 -> 61;
               case 4 -> 39;
               case 5 -> 13;
               case 6 -> 16;
               case 7 -> 12;
               case 8 -> 44;
               case 9 -> 50;
               case 10 -> 62;
               case 11 -> 26;
               case 12 -> 0;
               case 13 -> 30;
               case 14 -> 57;
               case 15 -> 10;
               case 16 -> 28;
               case 17 -> 14;
               case 18 -> 8;
               case 19 -> 60;
               case 20 -> 55;
               case 21 -> 46;
               case 22 -> 24;
               case 23 -> 63;
               case 24 -> 51;
               case 25 -> 32;
               case 26 -> 19;
               case 27 -> 29;
               case 28 -> 33;
               case 29 -> 48;
               case 30 -> 20;
               case 31 -> 34;
               case 32 -> 40;
               case 33 -> 17;
               case 34 -> 43;
               case 35 -> 21;
               case 36 -> 1;
               case 37 -> 36;
               case 38 -> 22;
               case 39 -> 9;
               case 40 -> 56;
               case 41 -> 11;
               case 42 -> 58;
               case 43 -> 37;
               case 44 -> 25;
               case 45 -> 45;
               case 46 -> 42;
               case 47 -> 35;
               case 48 -> 5;
               case 49 -> 4;
               case 50 -> 23;
               case 51 -> 47;
               case 52 -> 38;
               case 53 -> 49;
               case 54 -> 2;
               case 55 -> 53;
               case 56 -> 15;
               case 57 -> 3;
               case 58 -> 27;
               case 59 -> 31;
               case 60 -> 18;
               case 61 -> 6;
               case 62 -> 54;
               default -> 41;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   @Override
   public 友树何树友友何树友友 o(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      return null;
   }

   @Override
   public float t(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value) {
      long a = 树树何何树何树友何友.a ^ 125589090475569L;
      return 16.0F;
   }

   @Override
   public void v(GuiGraphics g, 树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      long a = 树树何何树何树友何友.a ^ 53629223349323L;
      a<"Ô">(-5495291296002048499L, a);
      String valueName = a<"Q">(a<"Q">(panel, -5495326622755895322L, a), -5495092267166521953L, a) ? value.v() : value.W();
      a<"Q">(a<"Q">(panel, -5495326622755895322L, a), -5495712435718913165L, a)
         .c(
            g.pose(),
            valueName,
            valx,
            valy + 8.0F - a<"Q">(a<"Q">(panel, -5495326622755895322L, a), -5495712435718913165L, a).K() / 2.0F,
            a<"Q">(panel, -5495326622755895322L, a).Z(a<"Q">(a<"Q">(panel, -5495326622755895322L, a), -5495789571259260011L, a), alpha).getRGB()
         );
      a<"Ô">(!a<"Ô">(-5495649240172994923L, a), -5495413219560550992L, a);
   }

   public static String Q() {
      return 友树友何树友何友何何;
   }

   public static void K(String var0) {
      友树友何树友何友何何 = var0;
   }

   private static String HE_SHU_YOU() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
