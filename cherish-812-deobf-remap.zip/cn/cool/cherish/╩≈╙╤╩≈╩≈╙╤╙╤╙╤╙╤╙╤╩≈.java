package cn.cool.cherish;

import cn.cool.cherish.config.友何友树树树友树何友;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树友树树友友友友友树 extends 友树树友树树友友何何 implements 何树友 {
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[7];
   private static final String[] i = new String[7];
   private static int _何炜霖黑水 _;

   public 树友树树友友友友友树() {
      long a = b ^ 125385342586903L;
      super(a<"l">(5804, 5883040209970273196L ^ a), a<"l">(9464, 7899507500376664561L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-4820096746477538731L, 4209084314921888209L, MethodHandles.lookup().lookupClass()).a(30924661099581L);
      // $VF: monitorexit
      b = var10000;
      b();
      long var0 = b ^ 34269395502294L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[25];
      int var7 = 0;
      String var6 = "Üýò©Âîù\u0003³\u0088SòñL\u0004¬\u0010ÆZº\bovº½×s\u0012\u008cOrû¾\u0018\u00867\u001f\n/ØúÐÚi\"\u001f\u009b\u0014Å¥Ð£ö\u0015Û\u0080JK\u0010\u001e\u008e\u0003T¦æï\ràu\u0096HÀHíM\u0010Qã\u001c\u001a®Eí7£;ÜßÙ\u009dÉ¤ \\c(\u001b=øiÄ\u001fAÞrÊX¼\u0091¾-É\u0088v¹\u0002]µs8\u001f]Öç\u000f \u0001:\u009fZ\u0080|ÎIÐM\u0016\u0093Õø\u0086I{¢tAàç68²Ô\u0010\u0086èHë¿\u0010Lk_\u0085ÉÙû·\u0083=\u0092\"¡<Ný \u00851¥©\u0094\u0089¶\u0089\u008aÓ\u008eS1\u0010Æ\u0013\u001e\u0085Cÿ\u009b\u0092LËÖ»@pÕQ'Â\u0010\u0083Zr\u0011'·\u001añý\n²2 Cü\u0003\u0010»ÛÈ\u0098XS\u0092²^©\u009d£Áù{×hô\u00adÇ6òzrÒØôÿ\"Ä\u0086XîîQO£À¥ïæ\u008b>¹8w\u0093 P\u0091mî2ÊÛk\u000bn<[y~{î9\u0090¾\u0006YDy\t\u0018$áÇ2ì¹«?ØÅ»î\nV\f%@\u009e:\u0089dh\u0094A*ÓOûÇ\u0019\u009c!UVÄ¹¼\u00ad:I\u001eË\u001eÊx¡d\u0084\u0010\u000b\u0080hñ(2²\\ÂÁ\u009e5B!µü ÔÉ\u0089âN2\u001fò©sYúÛímªnTÀ»¥¸×TJ\u0095A\u000b3`\u0010h\u0010\ro{í\u0088(Ð\u008frN3æ-'\u009e\u001d\u0010\u000f»å\u0094®Ç[u_\u001a«\u0082o<\u0005û\u0018:Ò\u0083s¸\u0010\u009d.?cÎpÏ@\u008arÓ·k\u008d!ºBo(¬ÇËR<\u0099»ð\u0090äèkØ\u0004\u0011\u001c\u0016k3ÌÃp\u0002\u0001·\u0099\u0091\u009c\u0086@×Sdµv\u0098·\u0087\u0098¹(rkb\u001eu28º\u0099ù£%\u009aPÆÓ\u0019X\u009fU\u0081@/\u0012(ïv4àÙB¤\u000f·B'i\u0004Ðñ\u0010É-õ\u000eÎ\u009e|\u0093!\u0093\u001cU\u008d\u0015\u00ad\u00adh£\u0097\u008a\u008c¨\u00adÞ£=\u0016s«§Mú\u0018]WjK¢\u009as\u00879\u0096äê:6\u0099\u0015êk$ò-ë\u001dÉ\u0094ñ\u001e§SÉö\u008bÇsBö\u001dZ\u0017c\u0003S\u001a\u001b\u008a\u0092òÙ,\u0086à\u0006Ò\u00885\u001bÀ\u0001\u0090b#¬!\u0086®\u000fc\u001e\u0094ñ%Uö²Y\u0094\u0003*¶GÇS\u0011úídåS\u00103ê\u0012RN«æ\u0003î5|þ¥õi\u0089(Kð\u001e\u009bØhé¨LiéU\u0000½ËÕCõó×³ô}ÌG\u008e\u001f@\u008bÒû\u0096éÌý)\u0093q*B";
      short var8 = 718;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     d = new String[25];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "5°¨ýÓ²0\u0010Ï{\n\u0017\u0094ð\u0092Ç\u0010[\u001f&\u0085\u001fÏ\\\u0090\u001c\u00150\u00006ÎAì";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 47;
               case 1 -> 55;
               case 2 -> 7;
               case 3 -> 18;
               case 4 -> 59;
               case 5 -> 2;
               case 6 -> 39;
               case 7 -> 17;
               case 8 -> 57;
               case 9 -> 11;
               case 10 -> 28;
               case 11 -> 20;
               case 12 -> 32;
               case 13 -> 62;
               case 14 -> 30;
               case 15 -> 16;
               case 16 -> 19;
               case 17 -> 24;
               case 18 -> 0;
               case 19 -> 9;
               case 20 -> 3;
               case 21 -> 53;
               case 22 -> 22;
               case 23 -> 10;
               case 24 -> 12;
               case 25 -> 51;
               case 26 -> 25;
               case 27 -> 61;
               case 28 -> 43;
               case 29 -> 27;
               case 30 -> 21;
               case 31 -> 50;
               case 32 -> 1;
               case 33 -> 36;
               case 34 -> 56;
               case 35 -> 54;
               case 36 -> 34;
               case 37 -> 52;
               case 38 -> 41;
               case 39 -> 46;
               case 40 -> 42;
               case 41 -> 38;
               case 42 -> 14;
               case 43 -> 63;
               case 44 -> 5;
               case 45 -> 8;
               case 46 -> 13;
               case 47 -> 6;
               case 48 -> 40;
               case 49 -> 35;
               case 50 -> 31;
               case 51 -> 29;
               case 52 -> 4;
               case 53 -> 15;
               case 54 -> 37;
               case 55 -> 45;
               case 56 -> 23;
               case 57 -> 48;
               case 58 -> 33;
               case 59 -> 58;
               case 60 -> 49;
               case 61 -> 26;
               case 62 -> 60;
               default -> 44;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'c' && var8 != 230 && var8 != 229 && var8 != 'Q') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 253) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 196) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'c') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 230) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 229) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void b() {
      h[0] = "\f*N\u0015\u001a8\u0003j\u0003\u001e\u0010%\u00067\bX桤厜桾桕厫厽厾厜厤桕";
      h[1] = "{\"qH3\u0003p-`\u0007I\u0007c,pH\u007f\u0003t";
      h[2] = "LZw(QNC\u001a:#[SFG1e栯佴栾叿案伞佫只古栥";
      h[3] = "&\"\u0019_\u0006\u0001\u0012\u0001\u0016\u001fK\n\u0018\u001c\u0013B@L\u0010\u0001\u001eDD\u0007S#\u0015U]\u000e\u0018U";
      h[4] = "cMS)m\"hBBf\f,cIF<";
      h[5] = "\u0017P):\u001e6H\u0005*e!r.\u0007wmAe^AwgA\u000f";
      h[6] = "`RD%\u0019-`I\tL\u000eSzX\tr^8wA\u0004L\u0016(7\u001d\f'\u001b1:#";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/树友树树友友友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13645;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/树友树树友友友友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/树友树树友友友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   public void W(String[] params) {
      long a = b ^ 10380228020252L;
      long ax = a ^ 10841031461261L;
      c<"Ä">(6936775218114360514L, a);
      if (params.length < 1) {
         ClientUtils.e(new Object[]{a<"l">(2088, 5226530923730951476L ^ a), ax});
      } else {
         if (params.length == 1) {
            String configName = params[0].toLowerCase();
            byte switchModule = -1;
            switch (configName.hashCode()) {
               case 3322014:
                  if (configName.equals(a<"l">(28992, 7988195682429445185L ^ a))) {
                     switchModule = 0;
                  }
               default:
                  switch (switchModule) {
                     case 0:
                        StringBuilder sb = new StringBuilder();
                        sb.append(a<"l">(6332, 229205610934816164L ^ a));
                        File[] files = Cherish.getConfigManager().G().listFiles();
                        if (files.length == 0) {
                           sb.append(a<"l">(10728, 4092585207980621043L ^ a));
                        }

                        boolean first = true;
                        int var13 = files.length;
                        int var14 = 0;
                        if (0 < var13) {
                           File file = files[0];
                           if (file.isFile() && file.getName().endsWith(a<"l">(32397, 6464533473735945090L ^ a))) {
                              sb.append(file.getName().replace(a<"l">(25300, 235051394313369540L ^ a), ""));
                              first = false;
                           }

                           var14++;
                        }

                        if (first) {
                           sb.append(a<"l">(24538, 5708132068686695126L ^ a));
                        }

                        ClientUtils.e(new Object[]{sb.toString(), ax});
                     default:
                        ClientUtils.e(new Object[]{a<"l">(23975, 1530746062805207204L ^ a), ax});
                  }
            }
         }

         if (params.length == 2) {
            String configName = params[1];
            if (configName.isEmpty() || configName.contains("/") || configName.contains("\\")) {
               ClientUtils.e(new Object[]{a<"l">(7597, 2498436599146432691L ^ a), ax});
               return;
            }

            友何友树树树友树何友 switchModule = new 友何友树树树友树何友(new File(Cherish.getConfigManager().G(), configName + a<"l">(25300, 235051394313369540L ^ a)));

            try {
               String var19 = params[0].toLowerCase();
               byte var20 = -1;
               switch (var19.hashCode()) {
                  case 3327206:
                     if (!var19.equals(a<"l">(8104, 8127350204770896565L ^ a))) {
                        break;
                     }

                     var20 = 0;
                  case -1352294148:
                     if (!var19.equals(a<"l">(18476, 6083924650164559144L ^ a))) {
                        break;
                     }

                     var20 = 1;
                  case 3522941:
                     if (var19.equals(a<"l">(16847, 5612411337649820873L ^ a))) {
                        var20 = 2;
                     }
               }

               switch (var20) {
                  case 0:
                     if (!switchModule.j().exists()) {
                        ClientUtils.e(new Object[]{a<"l">(27389, 6334613640295825405L ^ a) + configName + a<"l">(8492, 5431738660009047094L ^ a), ax});
                        return;
                     }

                     switchModule.a();
                     ClientUtils.e(new Object[]{a<"l">(13784, 9195141230964891869L ^ a) + configName + a<"l">(28813, 2420033555529966996L ^ a), ax});
                  case 1:
                  case 2:
                     if (switchModule.h()) {
                        ClientUtils.e(
                           new Object[]{
                              a<"l">(13784, 9195141230964891869L ^ a)
                                 + configName
                                 + a<"l">(12088, 926997426998573616L ^ a)
                                 + params[0].toLowerCase()
                                 + a<"l">(7560, 7144486643279841413L ^ a),
                              ax
                           }
                        );
                     }

                     ClientUtils.e(
                        new Object[]{
                           a<"l">(24370, 2208248511459101240L ^ a)
                              + params[0].toLowerCase()
                              + a<"l">(9272, 9157839777142010166L ^ a)
                              + configName
                              + a<"l">(21029, 7657767714555706L ^ a),
                           ax
                        }
                     );
                  default:
                     ClientUtils.e(new Object[]{a<"l">(23975, 1530746062805207204L ^ a), ax});
               }
            } catch (Throwable var16) {
               ClientUtils.e(new Object[]{a<"l">(32296, 2311356848037669665L ^ a) + var16.getMessage(), ax});
            }
         }

         ClientUtils.e(new Object[]{a<"l">(23975, 1530746062805207204L ^ a), ax});
      }
   }

   private static String LIU_YA_FENG() {
      return "何炜霖黑水";
   }
}
