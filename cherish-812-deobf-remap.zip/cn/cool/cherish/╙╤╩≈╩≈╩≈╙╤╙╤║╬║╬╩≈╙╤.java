package cn.cool.cherish;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.ui.何树树友树树友树友树;
import cn.cool.cherish.utils.client.ClientUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.glfw.GLFW;

public class 友树树树友友何何树友 extends 友树树友树树友友何何 implements 何树友 {
   private final Map<String, Integer> 何友树树友树友友树何;
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[17];
   private static final String[] i = new String[17];
   private static int _何大伟230622198107200054 _;

   public 友树树树友友何何树友() {
      long a = b ^ 125691435436818L;
      c<"ã">(5257652762489409060L, a);
      super(a<"c">(24750, 3809253286039769058L ^ a), "b");
      this.何友树树友树友友树何 = new HashMap<>();
      c<"F">(this, 5257850726276929100L, a).put(a<"c">(3053, 7528840798654735529L ^ a), 0);
      Field[] var4 = GLFW.class.getFields();
      int var5 = var4.length;
      int var6 = 0;
      if (0 < var5) {
         Field field = var4[0];
         if (Modifier.isStatic(field.getModifiers()) && field.getName().startsWith(a<"c">(12939, 3549344655362465225L ^ a))) {
            field.setAccessible(true);

            try {
               c<"F">(this, 5257850726276929100L, a).put(field.getName().substring(9).toLowerCase(), (Integer)field.get(null));
            } catch (IllegalAccessException var9) {
               var9.printStackTrace();
            }
         }

         var6++;
         c<"ã">(!c<"ã">(5257883663042176099L, a), 5257471915126811867L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6508307003995592122L, 5665185652996303463L, MethodHandles.lookup().lookupClass()).a(248101822142091L);
      // $VF: monitorexit
      b = var10000;
      b();
      long var0 = b ^ 100676422767901L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[11];
      int var7 = 0;
      String var6 = "Û\u001d\u0084&½»àS\u0092údX\b\u009d\u0099Î·P\u0093Îþ{Å\\¦SJQï/û=;Ü¨\u0088aò>¿\r]íM/ÕùÎàô8c·\u0098<Zd\u001aT<©C\u0083Îæ*¬.Òæ$\u0094?Í|OP.\u0082é{çê¢Ê^\u008fø\u0018\tA¹Ûú¡¶\u008f¿iðCiþÇ\u00ad[\u0002)¬pé\u00ad\u0000\u0010gÅhMOøx\u0016 Å\u001a£\u008eû\u0000\\\u0010ú¬Ô6V^Ñ\u0003·m\u0017þ44_Ë VõÁÈ\u000eÿXr\bó\u0015'./\u008az\u009c$8\u0014Þ\u001c\u0000\u008d/}¡l\u0017\u0003Ëâ T¾O\u000e\u0012|\u001c\u001cæïG\u0084ÅÕ\u0012\u0002úÊ\u008c\u0083\u000e\u00986\u007f>§éÊçÌ\u008c¹\u0010gPø\u0085Ò\u008f$)l*åÔ\u001b\u0016\u0089©0Gìû53\u0091ì\u0002iS\u000be÷j××^þ8¸=\u000e\u0085\u0093\u009f\u001a\u0084ià\u0082þ\u0000w\u0099ÙÊ8\"ØÍÿÃ\fIðÓH?\u0010e\u00917`ç\u0084A$Ëd\u0098ÌuS°å";
      short var8 = 296;
      char var5 = 'X';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     d = new String[11];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "-dU\u000f\u008b\u0089\u0080\u0010\u008e\u0018p*NÏ,7\u0010ú\n¢±\u0012|Þü6q\u008fWmrç>";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 6;
               case 1 -> 56;
               case 2 -> 13;
               case 3 -> 8;
               case 4 -> 38;
               case 5 -> 2;
               case 6 -> 34;
               case 7 -> 10;
               case 8 -> 35;
               case 9 -> 36;
               case 10 -> 5;
               case 11 -> 40;
               case 12 -> 55;
               case 13 -> 16;
               case 14 -> 0;
               case 15 -> 43;
               case 16 -> 11;
               case 17 -> 53;
               case 18 -> 3;
               case 19 -> 25;
               case 20 -> 1;
               case 21 -> 41;
               case 22 -> 27;
               case 23 -> 15;
               case 24 -> 31;
               case 25 -> 22;
               case 26 -> 7;
               case 27 -> 49;
               case 28 -> 51;
               case 29 -> 54;
               case 30 -> 23;
               case 31 -> 17;
               case 32 -> 29;
               case 33 -> 44;
               case 34 -> 21;
               case 35 -> 48;
               case 36 -> 20;
               case 37 -> 30;
               case 38 -> 58;
               case 39 -> 63;
               case 40 -> 28;
               case 41 -> 26;
               case 42 -> 61;
               case 43 -> 42;
               case 44 -> 45;
               case 45 -> 52;
               case 46 -> 19;
               case 47 -> 12;
               case 48 -> 46;
               case 49 -> 24;
               case 50 -> 32;
               case 51 -> 4;
               case 52 -> 18;
               case 53 -> 9;
               case 54 -> 59;
               case 55 -> 37;
               case 56 -> 47;
               case 57 -> 60;
               case 58 -> 50;
               case 59 -> 57;
               case 60 -> 14;
               case 61 -> 62;
               case 62 -> 33;
               default -> 39;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'F' && var8 != 'g' && var8 != 200 && var8 != 209) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 245) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 227) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'F') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'g') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 200) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void b() {
      h[0] = "dHos,Mk\b\"x&PnU)>厈栳栖样厊叛伖佷栖叭";
      h[1] = "M&\bfH.S.\u0012)+:W";
      h[2] = "TH*\u001fJw[\bg\u0014@j^UlRPq\u0019样栕厷佰位佢叭叏桭佰";
      h[3] = "\u000b\u0003ba7\u0006\u0004C/j=\u001b\u0001\u001e$,桉似桹厦桝佗伍厢厣桼";
      h[4] = "2\u001askgv\u00069|+*}\f$yv!;\u00049tp%pG\u001b\u007fa<y\fm";
      h[5] = "rGI^>ByHX\u0011UV{COKyAv";
      h[6] = "\u007f>SaT!p~\u001ej^<u#\u0015,V!x%\u0011g\u0015\u0003s4\bn^";
      h[7] = boolean.class;
      i[7] = "java/lang/Boolean";
      h[8] = void.class;
      i[8] = "java/lang/Void";
      h[9] = "'o\u0004{Z=,`\u00154;3'k\u0011n";
      h[10] = "-\u0001M}vxi\u001dQwLJ\u0011\\\u0014j=1)\u0004Fa3\t";
      h[11] = "\u0000\nlR{eE@03佞双栧桨叏株叀双栧伬\f\n8v\u0003NqLyvF";
      h[12] = "m[\u0000zpQ)G\u001cpJiQ\u0006Ym;\u0018i^\u000bf5 lA\nwu\u00190W\r$J";
      h[13] = "es-\u001fbp%\"8Z\u001a栌企低桄桾栃栌原低厞g#u,k%\u0002c$9.";
      h[14] = "f;\u00064KV;d\u0014t{B\\c[wG]a3W-\u0017?";
      h[15] = "HcG:o:\r)\u001b[~PMfM0&=\u000e~\u001bg\u0017k\brLjz(\u0010$\u001b[";
      h[16] = "Ur34\u0018P\u0015#&q`佨伱栋厀桕桹栬厯栋厀LYU\u001cj;)\u0019\u0004\t/";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友树树树友友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26547;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/友树树树友友何何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友树树树友友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   public void W(String[] params) {
      long a = b ^ 20955146511266L;
      long ax = a ^ 10841031461261L;
      c<"ã">(6937388454406022804L, a);
      if (params.length == 2) {
         Module module = Cherish.instance.getModuleManager().S(params[0]);
         if (module != null) {
            Integer key = (Integer)c<"F">(this, 6937727326902304508L, a).get(params[1]);
            module.E(key);
            何树树友树树友树友树.S(
               c<"È">(6935887752544773926L, a),
               a<"c">(7821, 5266052940566632824L ^ a),
               a<"c">(3995, 8897481850245777516L ^ a) + module.i() + a<"c">(15235, 2975865280134069363L ^ a) + params[1] + ".",
               5.0F
            );
            module.E(-1);
            ClientUtils.e(new Object[]{a<"c">(12619, 7241876967221049021L ^ a), ax});
         }

         何树树友树树友树友树.S(
            c<"È">(6937341970973977317L, a),
            a<"c">(23752, 4000831959272545078L ^ a),
            a<"c">(14645, 6010037755896676042L ^ a) + params[0] + a<"c">(25004, 397053861602977375L ^ a),
            5.0F
         );
      }

      ClientUtils.e(new Object[]{a<"c">(20318, 2595776581947607215L ^ a), ax});
   }

   private static String LIU_YA_FENG() {
      return "何炜霖黑水";
   }
}
