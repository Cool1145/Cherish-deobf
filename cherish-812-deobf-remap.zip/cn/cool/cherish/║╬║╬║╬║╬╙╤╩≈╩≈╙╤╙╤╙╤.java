package cn.cool.cherish;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import why.tree.friend.antileak.Fucker;
import why.tree.friend.antileak.client.Client;
import why.tree.friend.antileak.packet.impls.send.树树友树树何树友友何;
import why.tree.friend.antileak.utils.PacketWrapper;

public class 何何何何友树树友友友 extends 何何何何何何何友树友 implements 何树友 {
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[7];
   private static final String[] i = new String[7];
   private static int _何炜霖黑水 _;

   public 何何何何友树树友友友() {
      super("irc");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-6724704237974864236L, -9186267367160726834L, MethodHandles.lookup().lookupClass()).a(10844507396000L);
      // $VF: monitorexit
      b = var10000;
      b();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(135251288398921L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[7];
      int var7 = 0;
      String var6 = "cæFÆ$á\u0014úvù\u0092¾m¸²\u0002 ÷/ó§\u001aaãâ¿\u0015\u001bK¿1â\u008fP]i=MÃSAH\u001dæ\u0001J±REPá£ì¾\u0010¤\u008b\u0015¯yÙ\u0086^\u0081Ïó1$øy\u008cï³\u00801Oð+Ë ©MTá\u0000ì`kåXg:0\u008a\u001f¦2YTÚ}\u008bO\\8\u000eåÁ\u0092\u0084@¿½ Th$1\u0012Ibg\u001eêîu¶ü]\u0096\u0010Öy\u0082e}\u00ad\u0017E/Ðþ\u009a\u009em{3(¯LE®[\u008båxyc\u0096l[\u0017í9Sa\u0003\u0098¬TïØI]þ\u0017ó±*MiBé±c\r\u0003Õ";
      short var8 = 188;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     d = new String[7];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u0018*\u009e±üíÄã\u000f\u0092ñ~Í®.nqá£·¶¾²ØÒ¬²Æ¼\u0093Zv/6¿JDò¢ká\u00991 \u00135*\u0093\u0096Ùºjuø\u00adöEP¾+x\u0091s¨ÌauÛ§:Pcx\u009a\u001eO }\u0088S\u0000®\u0081c¨Ñ\u008dÖsxÀ$\u0090ü*s:\u001bz}¥í´+7\u0013¯åÆà\u001bÑAî\bxÛtÆØ^Ê &>ûeu\u008c\u008bk\b\u000b}\u009diJ\u009cR®_\n¤XUÅØö¶>' \u001cå\fÌp\u001dÄÈÞö\"!ÕBíÅ8U¦ÿü6ÑèàüñlÈ%\u0095\u008e\u0000eIè]T£áò";
                  var8 = 193;
                  var5 = 'H';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 12;
               case 1 -> 48;
               case 2 -> 2;
               case 3 -> 13;
               case 4 -> 61;
               case 5 -> 21;
               case 6 -> 52;
               case 7 -> 34;
               case 8 -> 24;
               case 9 -> 60;
               case 10 -> 63;
               case 11 -> 53;
               case 12 -> 23;
               case 13 -> 41;
               case 14 -> 26;
               case 15 -> 54;
               case 16 -> 5;
               case 17 -> 7;
               case 18 -> 3;
               case 19 -> 57;
               case 20 -> 62;
               case 21 -> 45;
               case 22 -> 50;
               case 23 -> 17;
               case 24 -> 15;
               case 25 -> 9;
               case 26 -> 51;
               case 27 -> 30;
               case 28 -> 32;
               case 29 -> 33;
               case 30 -> 39;
               case 31 -> 8;
               case 32 -> 19;
               case 33 -> 20;
               case 34 -> 55;
               case 35 -> 59;
               case 36 -> 47;
               case 37 -> 28;
               case 38 -> 4;
               case 39 -> 16;
               case 40 -> 14;
               case 41 -> 43;
               case 42 -> 36;
               case 43 -> 35;
               case 44 -> 46;
               case 45 -> 6;
               case 46 -> 10;
               case 47 -> 37;
               case 48 -> 49;
               case 49 -> 31;
               case 50 -> 42;
               case 51 -> 11;
               case 52 -> 0;
               case 53 -> 56;
               case 54 -> 58;
               case 55 -> 29;
               case 56 -> 18;
               case 57 -> 40;
               case 58 -> 38;
               case 59 -> 1;
               case 60 -> 22;
               case 61 -> 25;
               case 62 -> 44;
               default -> 27;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   @Override
   public void i(String[] params) {
      友树友友何树何何树树.B();
      if (params.length < 1) {
         ClientUtils.P(125527250587045L, "Usage: .irc <message> - 发送IRC消息到当前频道");
      } else if (Client.channel == null) {
         ClientUtils.P(125527250587045L, "错误: 未连接到IRC频道，请先连接");
      } else {
         String text = params[0];
         if (text.isEmpty()) {
            ClientUtils.P(125527250587045L, "消息不能为空");
         } else {
            if (text.length() <= Fucker.树友友友友何树友何树.p(34403295034695L) || Fucker.树友友友友何树友何树.p(34403295034695L) == -1) {
               try {
                  PacketWrapper.release(new 树树友树树何树友友何(Client.channel, text));
                  return;
               } catch (Throwable var11) {
                  ClientUtils.P(125527250587045L, "发送失败: " + var11.getMessage());
               }
            }

            ClientUtils.P(125527250587045L, "你发送的话超过你可以发送的字数限制，你只能最多发送" + Fucker.树友友友友何树友何树.p(34403295034695L) + "个字!");
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 208 && var8 != 'Z' && var8 != 'k' && var8 != 230) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 245) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 165) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 208) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Z') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'k') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void b() {
      h[0] = "Xd\u001fl~$W$Rgt9RyY!佄伞佮佟叺栞栀厀台叁";
      h[1] = "Y+zsxBR$k<\u0002FA%{s4BV";
      h[2] = "X\"q0\u000f\u000fWb<;\u0005\u0012R?7}厫桱台厇伊桂伵伵株桝";
      h[3] = "GtNW\u0018ksWA\u0017U`yJDJ^&qWILZm2uB]Cdy\u0003";
      h[4] = "K\u001cc\bf;@\u0013rG\u00075K\u0018v\u001d";
      h[5] = "\u0002B\u00160\u0000\u0017\u0006QNHS&\u001bCI0V]\u0007_\fHA_]B\u00183]C\u0018:";
      h[6] = "0]^X)\"8WK\u0004L\u0002\t\u0006^\tvvnBJ\u001b H";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/何何何何友树树友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 30115;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/何何何何友树树友友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[Ñ$¢ÕP\u0002ð")[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/何何何何友树树友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static String HE_JIAN_GUO() {
      return "何树友为什么濒天了";
   }
}
