package cn.cool.cherish.event.events;

public interface Cancellable {
   boolean isCancelled();

   void setCancelled(boolean var1);
}
