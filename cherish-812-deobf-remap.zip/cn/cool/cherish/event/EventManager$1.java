package cn.cool.cherish.event;

import cn.cool.cherish.module.何树何何树何友何何何;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

class EventManager$1 extends CopyOnWriteArrayList<EventManager.MethodData> implements  {
   private static final long serialVersionUID;
   private static final long a;
   private static final Object[] b = new Object[4];
   private static final String[] c = new String[4];
   private static String LIU_YA_FENG;

   EventManager$1(EventManager this$0, EventManager.MethodData var2) {
      this.this$0 = this$0;
      this.val$data = var2;
      this.add(this.val$data);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8691351833392915909L, 1170179464766179903L, MethodHandles.lookup().lookupClass()).a(253294520744688L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var4;
      Cipher var9 = var4 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var5 = 1; var5 < 8; var5++) {
         var10003[var5] = (byte)(43707602303067L << var5 * 8 >>> 56);
      }

      var9.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var8 = var4.doFinal(new byte[]{-95, -5, 47, -54, -4, -103, -66, -6});
      long var10 = (var8[0] & 255L) << 56
         | (var8[1] & 255L) << 48
         | (var8[2] & 255L) << 40
         | (var8[3] & 255L) << 32
         | (var8[4] & 255L) << 24
         | (var8[5] & 255L) << 16
         | (var8[6] & 255L) << 8
         | var8[7] & 255L;
      byte var10001 = -1;
      serialVersionUID = var10;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'q' && var8 != 'y' && var8 != 231 && var8 != 'm') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 163) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Y') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'q') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'y') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 231) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/event/EventManager$1" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "iM#K!Nf\rn@+ScPe\u0006+WoMy\u0006\u000bWoMye/OkDhZj\u0010";
      b[1] = "s=g\u001f\u0017f|}*\u0014\u001d{y !R\u001d\u007fu==R=\u007fu==1\u0019gq4,\u000e\\Du'!\u0013\u001cMq'(";
      b[2] = "Tso`BC_|~/#MTwzu";
      b[3] = "[\u0013\u0003c\n\u0018W\u001cV\u0002\u0006NZP\u0004k\u0004N>ES{\u0000AC@\u0006s@";
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 2;
               case 1 -> 33;
               case 2 -> 5;
               case 3 -> 29;
               case 4 -> 62;
               case 5 -> 25;
               case 6 -> 39;
               case 7 -> 42;
               case 8 -> 4;
               case 9 -> 60;
               case 10 -> 11;
               case 11 -> 37;
               case 12 -> 43;
               case 13 -> 22;
               case 14 -> 41;
               case 15 -> 53;
               case 16 -> 12;
               case 17 -> 19;
               case 18 -> 15;
               case 19 -> 61;
               case 20 -> 9;
               case 21 -> 55;
               case 22 -> 38;
               case 23 -> 34;
               case 24 -> 18;
               case 25 -> 47;
               case 26 -> 23;
               case 27 -> 1;
               case 28 -> 45;
               case 29 -> 17;
               case 30 -> 35;
               case 31 -> 54;
               case 32 -> 44;
               case 33 -> 32;
               case 34 -> 28;
               case 35 -> 6;
               case 36 -> 21;
               case 37 -> 50;
               case 38 -> 56;
               case 39 -> 0;
               case 40 -> 14;
               case 41 -> 13;
               case 42 -> 51;
               case 43 -> 8;
               case 44 -> 7;
               case 45 -> 16;
               case 46 -> 63;
               case 47 -> 40;
               case 48 -> 20;
               case 49 -> 36;
               case 50 -> 58;
               case 51 -> 57;
               case 52 -> 27;
               case 53 -> 52;
               case 54 -> 10;
               case 55 -> 30;
               case 56 -> 49;
               case 57 -> 26;
               case 58 -> 59;
               case 59 -> 46;
               case 60 -> 24;
               case 61 -> 31;
               case 62 -> 3;
               default -> 48;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "何大伟：我要教育何炜霖";
   }
}
