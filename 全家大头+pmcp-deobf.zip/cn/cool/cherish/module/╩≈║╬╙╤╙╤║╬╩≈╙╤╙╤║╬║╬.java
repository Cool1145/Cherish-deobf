package cn.cool.cherish.module;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public enum 树何友友何树友友何何 implements  {
   何何何何何树何何友树,
   何友树何树友友友何树,
   友树树友何友何树友树,
   友友树树何友树树友树,
   友树何友何树树树树何,
   友友友树何友何何树何,
   友树友树树树友何友树;

   public final String 树友何何友树友友何树;
   public final String 何何何树何何何树友友;
   private static int 友树树树树何树树友友;
   private static final long a;
   private static final Object[] b = new Object[15];
   private static final String[] c = new String[15];
   private static String HE_JIAN_GUO;

   private 树何友友何树友友何何(String name, String cnName) {
      this.树友何何友树友友何树 = name;
      this.何何何树何何何树友友 = cnName;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // $VF: Failed to inline enum fields
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8881456954786006199L, 8789565892160637028L, MethodHandles.lookup().lookupClass()).a(28975788599797L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (r() == 0) {
         S(126);
      }

      Cipher var1;
      Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(25402788990044L << var2 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var0 = new String[21];
      int var6 = 0;
      String var5 = "P\u0004\u0082B\u0003\u008d\u0099q\bÛï \u0092ù\u001a\u0013]\u0010\u0014Ùrâ\u001f q=sÍ\u0002æu\u0014.]\bþ!óý\u009f\u0002*ù\bßô['ÑPwð\bPG\rX3õ\u0087T\u0010.Ð<Ñð\u0090oZØ)$qñýÏZ\u0010mß\u0084ª\u0094h5©æ\"\u0094\u0010\r.«Æ\u0010åðÀ\u009aÁþ,\u0002jQu@]Ìz \u0010aÐ¾\tå\u0098dØª-<\u0007ÖÏî6\bá$~M\u009eÈS\u001e\u0010L}àB\u0086Û£tÔ7:Õ°\u0099$X\u0010Htx\u0098\u008eEµb+\u008bTp£K¸Ã\u0010£:À¤\u0085\u0093\u0090Î¦;Yü\u0014\\ÑÒ\bQ¢ð\u000eÆ'Ø¤\b~,íôÛÄ\u0088±\bxÞ¬«ø-\u001e£\b\u0013\u0013Æ@b\u001e«¥\bTgÊcæfGà";
      short var7 = 234;
      char var4 = '\b';
      int var9 = -1;

      label32:
      while (true) {
         String var11 = var5.substring(++var9, var9 + var4);
         byte var10001 = -1;

         while (true) {
            String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var0[var6++] = var17;
                  if ((var9 += var4) >= var7) {
                     何何何何何树何何友树 = new 树何友友何树友友何何(var0[3], var0[20]);
                     何友树何树友友友何树 = new 树何友友何树友友何何(var0[11], var0[7]);
                     友树树友何友何树友树 = new 树何友友何树友友何何(var0[14], var0[6]);
                     友友树树何友树树友树 = new 树何友友何树友友何何(var0[16], var0[13]);
                     友树何友何树树树树何 = new 树何友友何树友友何何(var0[18], var0[12]);
                     友友友树何友何何树何 = new 树何友友何树友友何何(var0[5], var0[8]);
                     友树友树树树友何友树 = new 树何友友何树友友何何(var0[10], var0[2]);
                     return;
                  }

                  var4 = var5.charAt(var9);
                  break;
               default:
                  var0[var6++] = var17;
                  if ((var9 += var4) < var7) {
                     var4 = var5.charAt(var9);
                     continue label32;
                  }

                  var5 = "R¢e³¿\u0003Q\u0090\u0010UðTÞ\u0094ËVÂu\f\u0084\u009a&\u0015¨/";
                  var7 = 25;
                  var4 = '\b';
                  var9 = -1;
            }

            var11 = var5.substring(++var9, var9 + var4);
            var10001 = 0;
         }
      }
   }

   public static void S(int var0) {
      友树树树树何树树友友 = var0;
   }

   public static 树何友友何树友友何何 Z(String name) {
      return Enum.valueOf(树何友友何树友友何何.class, name);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 249 && var8 != 226 && var8 != 'I' && var8 != 'x') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 252) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 195) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 249) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 226) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'I') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static void a() {
      b[0] = "\u001a61\"\u001a}\u0015v|)\u0010`\u0010+wo\u0018}\u001d-s$[栃伬厓叔伔桤叙厲伍佊";
      b[1] = int.class;
      c[1] = "java/lang/Integer";
      b[2] = void.class;
      c[2] = "java/lang/Void";
      b[3] = "\\H\u000b\u0010uihk\u0004P8bbv\u0001\r3$jk\f\u000b7o)栕伽厵厐佟栖叏厣伫伎1";
      b[4] = ">>=\u0013\r\u000551,\\l\u000b>:(\u0006";
      b[5] = "5:\"q_wh?4\u0018叻栏伅厒伏栁校栏桁伌RuSf163(Vp";
      b[6] = "^\u0018Z(c_\u0003\u001dLA叇栧台桪栳桘叇佣台桪*,oNZ\u0014KqjX";
      b[7] = "4o\u0013\u000b36ij\u0005b伉桎厚栝伾桻厗厔伄余cX?9`k\u0019\r85 ";
      b[8] = "v\u0014j'+P+\u0011|N\u00171`\u0010x2q[r\u0013$Nu_u\u0014s &ZuC\u001a";
      b[9] = "ED\u0013iJ\u0011\u0018A\u0005\u0000佰厳栱佲桺參叮厳併栶cmF\u0000AH\u00020C\u0016";
      b[10] = "[!5?t\u001a\u0006$#V叐桢栯厉优厕低桢叵桓E;x\u000b_-$f}\u001d";
      b[11] = "+2?\u0019J\u000bv7)p佰伷伛伄伒桩佰伷厅桀O\u001dF\u001a/>.@C\f";
      b[12] = "\u0014oq2,)Ijg[厈压桠栝作厘桒桑厺栝\u00016 8\u0010c`k%.";
      b[13] = "\u0019]\u000b\u001aZ4DX\u001dsGU\u000fY\u0019\u000f\u0000?\u001dZEs";
      b[14] = "{\u0013)#g\u0001&\u0016?J參厣叕桡伄厉佝伽栏伥Y'k\u0010\u007f\u001f8zn\u0006";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/树何友友何树友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 36;
               case 1 -> 34;
               case 2 -> 15;
               case 3 -> 3;
               case 4 -> 62;
               case 5 -> 46;
               case 6 -> 8;
               case 7 -> 2;
               case 8 -> 40;
               case 9 -> 33;
               case 10 -> 63;
               case 11 -> 31;
               case 12 -> 58;
               case 13 -> 60;
               case 14 -> 1;
               case 15 -> 56;
               case 16 -> 51;
               case 17 -> 44;
               case 18 -> 20;
               case 19 -> 52;
               case 20 -> 47;
               case 21 -> 29;
               case 22 -> 45;
               case 23 -> 57;
               case 24 -> 27;
               case 25 -> 50;
               case 26 -> 11;
               case 27 -> 10;
               case 28 -> 19;
               case 29 -> 59;
               case 30 -> 26;
               case 31 -> 16;
               case 32 -> 7;
               case 33 -> 6;
               case 34 -> 54;
               case 35 -> 43;
               case 36 -> 48;
               case 37 -> 30;
               case 38 -> 61;
               case 39 -> 35;
               case 40 -> 9;
               case 41 -> 37;
               case 42 -> 21;
               case 43 -> 32;
               case 44 -> 13;
               case 45 -> 55;
               case 46 -> 18;
               case 47 -> 4;
               case 48 -> 24;
               case 49 -> 22;
               case 50 -> 53;
               case 51 -> 41;
               case 52 -> 0;
               case 53 -> 14;
               case 54 -> 12;
               case 55 -> 23;
               case 56 -> 25;
               case 57 -> 28;
               case 58 -> 38;
               case 59 -> 17;
               case 60 -> 42;
               case 61 -> 5;
               case 62 -> 39;
               default -> 49;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static int r() {
      G();

      try {
         return 111;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public static 树何友友何树友友何何[] M() {
      return (树何友友何树友友何何[])何树友树何树友友何何.clone();
   }

   private static String HE_SHU_YOU() {
      return "何树友，和树做朋友";
   }

   public static int G() {
      return 友树树树树何树树友友;
   }
}
