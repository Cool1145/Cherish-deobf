package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import cn.cool.cherish.ui.友友何友树何何友友友;
import cn.cool.cherish.ui.友树何何友树何何友树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

public class 友友何友何何树何树树 extends 树树友树友友何友友树 implements 何树友 {
   private final ModeValue 友树何树树树何树友何;
   public final BooleanValue 友树友树何何何树友树;
   public final ModeValue 树友何何友友何何何友;
   public static final Map<MobEffect, Integer> 树树何树友何何何友树;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final Object[] n = new Object[11];
   private static final String[] o = new String[11];
   private static int _何炜霖大狗叫 _;

   public 友友何友何何树何树树() {
      long a = c ^ 88964728663216L;
      super(c<"q">(28616, 2017605645539034777L ^ a), c<"q">(16955, 7224732884177644389L ^ a), 90.0F, 30.0F);
      this.友树何树树树何树友何 = new ModeValue(
         c<"q">(7959, 9055655748837160517L ^ a),
         c<"q">(27415, 4305977948999467594L ^ a),
         new String[]{c<"q">(23486, 1139073211600171755L ^ a), c<"q">(8367, 6619040732556823039L ^ a)},
         c<"q">(18310, 9218467701723819742L ^ a)
      );
      this.友树友树何何何树友树 = (BooleanValue)new BooleanValue(c<"q">(20493, 3049519704123341138L ^ a), c<"q">(9804, 339888920067215120L ^ a), false).i(() -> {
         long ax = c ^ 130156640259982L;
         return d<"I">(this, 7896109247680702021L, ax).C(c<"q">(18310, 9218504506359844320L ^ ax));
      });
      this.树友何何友友何何何友 = (ModeValue)new ModeValue(
            c<"q">(7147, 6567481900166591167L ^ a),
            c<"q">(25975, 3038499228118535212L ^ a),
            new String[]{c<"q">(26025, 7828084168775585022L ^ a), c<"q">(18822, 4553512585903071445L ^ a)},
            c<"q">(22933, 8168532772197953731L ^ a)
         )
         .i(() -> {
            long ax = c ^ 92535412144032L;
            return d<"I">(this, 1565774716776423019L, ax).C(c<"q">(18310, 9218471826491635150L ^ ax));
         });
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(9024843841961194674L, 5761069899091762189L, MethodHandles.lookup().lookupClass()).a(49352842735359L);
      // $VF: monitorexit
      c = var10000;
      c();
      long var0 = c ^ 91017874524971L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[15];
      int var7 = 0;
      String var6 = "³\u008e\u000fge4\u0082?ÎUû\u000er\u0005¨£\u0018Ìâ½C\u0092º/Ç\u0010Ð8\u0083QÏ\u0014\u0014\u0082m£XI`\u007f'\u0010Õ2\u0019Û\u0017\u0015õO³bkzyø½\u0098\u0010V\u0095^5µÆ\u0019È9¦\u000e\u0014¬\u001aÞÿ\u0010Í\u001f\u0018¼\u0015¾¦Ê`¢i;¯¿ßi\u0010P0(À¨ù/´|r\u0000«;ìrú\u0010\rø!\u0091\u001c?\u007f\u0016ý\u0081\u0090ô\u0081Îbe\u0010wóp\u0007êµé804<&\u008eÉ¶9\u0010-;\u0014U²\u0080\u0088WÀõ\u000e\t\u0002c«þ\u0018ËP\u000eR!ÕÏ¢1\"<heó#\u0002º\u009e±Êþþ¥\u0080 %¥á]D\u008cMõ°yþÒÅ4QZ\u0086\u0003ç§¨¸\u009f\u0016È¤Öó§\u001e\u0094n »½ÉZ\u0010^Ñ\u0083Ö\u007ft\u0084n\u0099}\u0098'ûkÏ'ÌÞÄ\u000f\u0006OúJÁb0\u0010I.\u001cÃ´\u0098·b¨Z\u001bï¡'\u0011l";
      short var8 = 268;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = d(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     k = var9;
                     l = new String[15];
                     树树何树友何何何友树 = new HashMap<>();
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "Â÷ÏC{{\"\u001cH\u008cÃr\u0014\u0016ÎR\u0018j\b\u0094uÊ\u0095JÈS*\u00196`À~± \u001biH\bõ² ";
                  var8 = 41;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private List<MobEffectInstance> S() {
      long var10000 = c ^ 58695683688261L;
      return mc.player == null ? new ArrayList<>() : new ArrayList<>(mc.player.getActiveEffects());
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 10237;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何友何何树何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = k[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void c() {
      n[0] = "=}`\u0007x<2=-\fr!7`&Jz<:f\"\u00019:3c\"Js:-c\"\u0005n}厕变伛厯佂伆桏但桟桵";
      n[1] = "\u00012\u0018?.#\u000erU4$>\u000b/^r7-\u000e)Sr(!\u00120\u0018\u0011.(\u0007\nW04)";
      n[2] = "2\u001a[+\u001fE9\u0015Jdc\\6\u000fD'Tl \u0018H:E@7\u0015";
      n[3] = "J)\b@\u0018\u0019EiEK\u0012\u0004@4N\r\u001a\u0019M2JFY\u001fD7J\r\u0013\u001fZ7JB\u000eXa\u0012b";
      n[4] = "\u0018N";
      n[5] = "<3\fzTI\";\u001657]&";
      n[6] = ":\u0012Q.,!1\u001d@aM/:\u0016D;";
      n[7] = "\u001bfYC;!]~X>*\u001a\u001ed\u001eW?}H!ED@#Y MA'u\u001c{^>";
      n[8] = "9QWU\u007fE9H\u001c\u0004\u0000%\u0003\u0001C\u000fzM9WVS;}";
      n[9] = "l~6qdU*f7\f栆桷伍栛厈佑佂伳厓栛K7b\u0015({.f.\u00164";
      n[10] = "3\u0002\u0010\u001d\u0004\u0000u\u001a\u0011`厼栢佒桧桴桹伢栢双伣m\u001e\u0012VbN\u0007X\u0002\u0007";
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何友何何树何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void c(List<MobEffectInstance> effects) {
      long a = c ^ 68576452865743L;
      d<"G">(5536469568436395718L, a);
      ArrayList needRemove = new ArrayList();
      Iterator var6 = d<"y">(5536374316047308246L, a).entrySet().iterator();
      if (var6.hasNext()) {
         Entry<MobEffect, Integer> entry = (Entry<MobEffect, Integer>)var6.next();
         MobEffect effect = entry.getKey();
         MobEffectInstance currentEffect = mc.player.getEffect(effect);
         if (currentEffect == null || currentEffect.getDuration() <= 0 && currentEffect.getDuration() != -1) {
            needRemove.add(effect);
         }
      }

      needRemove.forEach(d<"y">(5536374316047308246L, a)::remove);
      var6 = effects.iterator();
      if (var6.hasNext()) {
         MobEffectInstance instance = (MobEffectInstance)var6.next();
         MobEffect effect = instance.getEffect();
         int currentDuration = instance.getDuration();
         if (currentDuration == -1) {
            d<"y">(5536374316047308246L, a).put(effect, -1);
         }

         d<"y">(5536374316047308246L, a).compute(effect, (key, oldDuration) -> {
            long ax = c ^ 16368201145368L;
            d<"G">(4468218444976040977L, ax);
            return oldDuration != null && oldDuration != -1 && currentDuration <= oldDuration ? oldDuration : currentDuration;
         });
      }
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何友何何树何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'I' && var8 != 227 && var8 != 'y' && var8 != 'X') {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 255) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'G') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'I') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 227) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'y') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 4;
               case 1 -> 36;
               case 2 -> 1;
               case 3 -> 46;
               case 4 -> 40;
               case 5 -> 17;
               case 6 -> 63;
               case 7 -> 5;
               case 8 -> 12;
               case 9 -> 26;
               case 10 -> 8;
               case 11 -> 31;
               case 12 -> 57;
               case 13 -> 28;
               case 14 -> 56;
               case 15 -> 11;
               case 16 -> 7;
               case 17 -> 2;
               case 18 -> 50;
               case 19 -> 24;
               case 20 -> 48;
               case 21 -> 19;
               case 22 -> 49;
               case 23 -> 62;
               case 24 -> 53;
               case 25 -> 45;
               case 26 -> 54;
               case 27 -> 27;
               case 28 -> 30;
               case 29 -> 21;
               case 30 -> 9;
               case 31 -> 58;
               case 32 -> 60;
               case 33 -> 29;
               case 34 -> 35;
               case 35 -> 18;
               case 36 -> 15;
               case 37 -> 44;
               case 38 -> 59;
               case 39 -> 32;
               case 40 -> 33;
               case 41 -> 38;
               case 42 -> 13;
               case 43 -> 42;
               case 44 -> 43;
               case 45 -> 41;
               case 46 -> 47;
               case 47 -> 52;
               case 48 -> 55;
               case 49 -> 34;
               case 50 -> 25;
               case 51 -> 22;
               case 52 -> 20;
               case 53 -> 10;
               case 54 -> 6;
               case 55 -> 14;
               case 56 -> 61;
               case 57 -> 37;
               case 58 -> 51;
               case 59 -> 23;
               case 60 -> 0;
               case 61 -> 39;
               case 62 -> 16;
               default -> 3;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   @EventTarget
   public void T(Render2DEvent event) {
      long a = c ^ 38786920081311L;
      long ax = a ^ 136075443354799L;
      d<"G">(5009516423578539926L, a);
      if (!this.w(new Object[]{ax})) {
         this.T(d<"I">(this, 5009630753319177812L, a).getValue());
         List<MobEffectInstance> effects = this.S();
         this.c(effects);
         String var8 = d<"I">(this, 5009630753319177812L, a).getValue();
         byte var9 = -1;
         switch (var8.hashCode()) {
            case -1984932033:
               if (!var8.equals(c<"q">(18310, 9218551945402492401L ^ a))) {
                  break;
               }

               var9 = 0;
            case 68884316:
               if (var8.equals(c<"q">(24695, 5097670345783738881L ^ a))) {
                  var9 = 1;
               }
         }

         switch (var9) {
            case 0:
               友友何友树何何友友友.a(event.poseStack(), effects, this.r(), this.v(), this);
            case 1:
               友树何何友树何何友树.b(event.poseStack(), effects, this.r(), this.v(), this);
            default:
               this.b(event.poseStack());
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "职业技术教育中心学校";
   }
}
