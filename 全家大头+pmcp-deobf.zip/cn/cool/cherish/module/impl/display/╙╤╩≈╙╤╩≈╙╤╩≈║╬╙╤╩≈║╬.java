package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.value.impl.BooleanValue;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友树友树友树何友树何 extends Module implements 何树友 {
   public static 友树友树友树何友树何 友树友树何友何友友友;
   public final BooleanValue 树树何何友友何树友友 = new BooleanValue("Players", "玩家", true);
   public final BooleanValue 树何何树何友何树友友 = new BooleanValue("Dead", "死亡", false);
   public final BooleanValue 友何何友何友友何友友 = new BooleanValue("Invisible", "隐身", false);
   public final BooleanValue 树树友树友何友友友友 = new BooleanValue("Mobs", "生物", false);
   public final BooleanValue 树友友友何何友友何树 = new BooleanValue("Animals", "动物", false);
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[5];
   private static final String[] k = new String[5];
   private static String HE_SHU_YOU;

   public 友树友树友树何友树何() {
      super("TargetSetting", "目标设置", 树何友友何树友友何何.友友友树何友何何树何);
      友树友树何友何友友友 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-9026071027514795899L, -12934554897626989L, MethodHandles.lookup().lookupClass()).a(54451423127082L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(121661922935342L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[12];
      int var7 = 0;
      String var6 = "»ßÙsÿ\u009c¾þ×û\u0005/®\u0006Uê»åÞ £\u009d\u0092\u0084\u0001áê\u008d=I>Ë\u0010F\u009aôÆA\u0013(\u0096%©«>g×]Ã\u0010\u000b=\u0003í0Õa¨\u009a²D\u001aB#3\u0093\u0010O\u008bpê°\u0015ÉÉ\u008e9.«Z«!Î ?$\u008aÙ\u001a³÷×UY\u0015(¶\u0099+w\u008eT³ýý^\u0086+8E\u0095«IeÚ\u0003\u0010ÿàëí«\u009ai+Ì\u0018\u000b|¨´ñ.\u0010\t\u000b\u0096Üh3×ðd\u0018Äg\u000e\u009d\u008aÉ\u0010ÏÊ\u0018\rn\\úlCßÔ\u0005øB§l\u0018\u0006Ý\u001cY6hé\u0004ãÂ\u0098i_\"D§Ã2\u0098¨\u0011\u0095\u001eÞ\u0010\u009f^z#¾/¶Îfp\u007ff\u0083Çõ\t";
      short var8 = 209;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[12];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "^*\u0016>é\u0000\u0015|-³JõÕ\u001c\u0018\u0092\u0010(²\u0011µ\u008fh\u0019M°\u0003&\u0013Ó\r\u0000Y";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 26;
               case 1 -> 58;
               case 2 -> 49;
               case 3 -> 3;
               case 4 -> 6;
               case 5 -> 2;
               case 6 -> 35;
               case 7 -> 44;
               case 8 -> 53;
               case 9 -> 16;
               case 10 -> 8;
               case 11 -> 37;
               case 12 -> 10;
               case 13 -> 20;
               case 14 -> 9;
               case 15 -> 19;
               case 16 -> 54;
               case 17 -> 46;
               case 18 -> 63;
               case 19 -> 57;
               case 20 -> 30;
               case 21 -> 31;
               case 22 -> 47;
               case 23 -> 29;
               case 24 -> 41;
               case 25 -> 40;
               case 26 -> 22;
               case 27 -> 56;
               case 28 -> 1;
               case 29 -> 38;
               case 30 -> 15;
               case 31 -> 0;
               case 32 -> 48;
               case 33 -> 50;
               case 34 -> 13;
               case 35 -> 25;
               case 36 -> 5;
               case 37 -> 23;
               case 38 -> 7;
               case 39 -> 18;
               case 40 -> 36;
               case 41 -> 33;
               case 42 -> 11;
               case 43 -> 4;
               case 44 -> 24;
               case 45 -> 45;
               case 46 -> 28;
               case 47 -> 52;
               case 48 -> 12;
               case 49 -> 55;
               case 50 -> 62;
               case 51 -> 61;
               case 52 -> 51;
               case 53 -> 60;
               case 54 -> 59;
               case 55 -> 27;
               case 56 -> 32;
               case 57 -> 39;
               case 58 -> 17;
               case 59 -> 42;
               case 60 -> 21;
               case 61 -> 43;
               case 62 -> 34;
               default -> 14;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24029;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友树友树友树何友树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树友树友树何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 253 && var8 != 'C' && var8 != 205 && var8 != 208) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 242) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 225) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 253) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'C') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 205) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树友树友树何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "v*\u0001\u0018EAyjL\u0013O\\|7GUGAq1C\u001e\u0004栿佀厏古伮栻句叞休佺";
      j[1] = "jf\u0002Sv7e&OX|*`{D\u001et7m}@U71dx@\u001e}1zx@Q`v参栙叧校叒桉作參栽佥";
      j[2] = "gy~>\u0016^lvoqwPg}k+";
      j[3] = "BvtG\u007f\u001f\u0019:07叁厼厽栝伕叴佟伢桧余H\u000bpC\u000ey(P<\u0007";
      j[4] = "?\biO<v~\u000eiIV叞栟台栓佫厕佀叅台叉6o&eJ`]. eL";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   public void M() {
      this.n();
   }

   private static String HE_WEI_LIN() {
      return "何树友被何大伟克制了";
   }
}
