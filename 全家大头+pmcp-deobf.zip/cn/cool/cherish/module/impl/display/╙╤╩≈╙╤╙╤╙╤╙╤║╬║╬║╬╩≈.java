package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import cn.cool.cherish.ui.友何何树友何何何何树;
import cn.cool.cherish.ui.树树树友友树友树树树;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友树友友友友何何何树 extends 树树友树友友何友友树 implements 何树友 {
   public static 友树友友友友何何何树 友何友何友树何何树树;
   private final BooleanValue 友树友何何何树友何树;
   private final NumberValue 友何友何何树树友何何;
   private final NumberValue 树友何何树友何何友友;
   private final NumberValue 树友何何何树友树何友;
   private final BooleanValue 友何树友何友友友何友;
   private final BooleanValue 何树树友树友树何何树;
   private final ModeValue 友树友何树何何何何树;
   private final NumberValue 友树友树友友友友树友;
   private final ModeValue 友树树树何何友树树树;
   public final ModeValue 友树友何树何何友何树;
   private final BooleanValue 树何何树树友何友树何;
   private final List<Module> 树友何何何友友何友友;
   private boolean 友树友树树友友友友树;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final Object[] n = new Object[48];
   private static final String[] o = new String[48];
   private static int _我是何树友 _;

   public 友树友友友友何何何树() {
      long a = c ^ 122125288831009L;
      super(c<"w">(5125, 8220407120395278599L ^ a), c<"w">(18500, 7436668006732121428L ^ a), 150.0F, 100.0F, 0.0F, 120.0F);
      d<"ú">(2751454348773764333L, a);
      this.友树友何何何树友何树 = new BooleanValue(c<"w">(2810, 4279556512897042423L ^ a), c<"w">(19466, 7667115516003008787L ^ a), false);
      this.友何友何何树树友何何 = new NumberValue(c<"w">(15681, 1238430366729613418L ^ a), c<"w">(27210, 7802031970317625192L ^ a), 0, -5, 10, 1);
      this.树友何何树友何何友友 = new NumberValue(c<"w">(24341, 4754472200317817350L ^ a), c<"w">(7277, 5785048151190049134L ^ a), 2, 1, 5, 1);
      this.树友何何何树友树何友 = new NumberValue(c<"w">(26356, 7976588127862221813L ^ a), c<"w">(3529, 5053011194748010718L ^ a), 18, 6, 20, 1);
      this.友何树友何友友友何友 = new BooleanValue(c<"w">(32749, 4451579386051130050L ^ a), c<"w">(11, 7967309744667626800L ^ a), false);
      this.何树树友树友树何何树 = (BooleanValue)new BooleanValue(c<"w">(14724, 1555724959530857627L ^ a), c<"w">(11401, 8055762843179721129L ^ a), true).i(() -> {
         long var0 = c ^ 28983087848286L;
         d<"ú">(-8840473255785558126L, var0);
         return HUD.instance != null && d<"o">(HUD.instance, -8840067677668448242L, var0).C(c<"w">(13048, 3515317143728725165L ^ var0));
      });
      this.友树友何树何何何何树 = new ModeValue(
         c<"w">(4863, 5566494978404261829L ^ a),
         c<"w">(2, 2386353279364074799L ^ a),
         new String[]{c<"w">(13031, 8728764595729252337L ^ a), c<"w">(15844, 9077828566591221985L ^ a), c<"w">(6024, 993637356216818323L ^ a)},
         c<"w">(13031, 8728764595729252337L ^ a)
      );
      this.友树友树友友友友树友 = new NumberValue(c<"w">(12638, 7495257566107417684L ^ a), c<"w">(16296, 8105410801656509071L ^ a), 80, 1, 255, 1);
      this.友树树树何何友树树树 = new ModeValue(
         c<"w">(14302, 8369519863029119735L ^ a),
         c<"w">(30052, 3755863647996246109L ^ a),
         new String[]{
            c<"w">(20352, 9201871791566897799L ^ a),
            c<"w">(16475, 1973721304906124627L ^ a),
            c<"w">(14932, 3226033971752417088L ^ a),
            c<"w">(18793, 6233558810469581898L ^ a),
            c<"w">(6024, 993637356216818323L ^ a)
         },
         c<"w">(19823, 5806370428052783218L ^ a)
      );
      this.友树友何树何何友何树 = new ModeValue(
         c<"w">(16802, 7338212473559207096L ^ a),
         c<"w">(3078, 7857770568001159470L ^ a),
         new String[]{
            c<"w">(2199, 7680402066648761758L ^ a),
            c<"w">(28279, 8832459338977928027L ^ a),
            c<"w">(7271, 3431455850357264761L ^ a),
            c<"w">(28311, 5052219065304376219L ^ a),
            c<"w">(7740, 1794324890583896878L ^ a)
         },
         c<"w">(29209, 1445706467843309337L ^ a)
      );
      this.树何何树树友何友树何 = new BooleanValue(c<"w">(13356, 6539963376775772458L ^ a), c<"w">(26443, 772829875523218035L ^ a), false);
      this.树友何何何友友何友友 = new ArrayList<>();
      d<"û">(this, true, 2750945364940237602L, a);
      d<"C">(this, 2747872163404414833L, a);
      this.y(true);
      if (!d<"ú">(2751202698302470277L, a)) {
         d<"ú">(new int[1], 2747775306668306087L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7032661823035628744L, -5751707070344552548L, MethodHandles.lookup().lookupClass()).a(52322171698504L);
      // $VF: monitorexit
      c = var10000;
      c();
      long var0 = c ^ 94278706485113L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[52];
      int var7 = 0;
      String var6 = "r\u0091?r8¿e\u008b®EJ\t\u000eb\u0097\u0018(×Ð\u001bQ{ÿ,*ñÎ>G\u0000\u0090¤'éüÞ\u0000ÀyG`\u0018T³Åe¯ \\Në:\u000b;\u0085\u001b§\u0010è¤H<h@ÃÌ¬í\u0086Q3\u000e;´\u0010C\r\u009dÉ0!Y\u009fu`©Õæà\u0085¼\u0010¯l\u0094\u001bÅ\u00adÅ%pD]¥äÖ\u0011\u0092\u0010ësîÒ\u008e+6ªé²³Ýx®\u0004\u0004 N(\u007f\u00899\u008du½S1A\tÂ\u001dMðØ)\u001cÁ\u0094zc\u0017ÌÉ\u0019\u008a\u009d³\u0086w\u0010\u0016MÄv`\u0085k\u0096\u0095\u0098æÕ/¨#F\u0010¯7\u001eÔ\u0091¨\u0095]\u0018f\u001f½Ï¯;?\u0018I*\u001eãð\u0082=ÄG\u001e\u001a%\u0011R½\u00adÌÓU\u007fëClØ ½l\u0001çÆÉ@\u00894ö[úw7â\u0095²A\u009e\u0007Â\u0089^M9 ß.«\u0099®H\u0010\u008a\u0014©~j\u0085h´¡¶\tÆÀ\u0082\b½\u0010Ðõ\u0086Óji\u001f8Ñ¿ÊÞ\r\u0016;å \u009e\u000f©æ\bj)\u0088¾ÿ;\u0093á\u001a@\u0017Ã\u0018çêÉþ\bqS\u000b±J\u0015BÒÌ\u0010\u009c\u008e$dé©<uç\u0010Î¥ÖL|\u0005\u0010Ö h\u0088NzN¥\u008eºÈ\u009f\u0005<\n8\u0010N´KÓ\u0081\u0000\u000b\u0095;¶¡Õy\u000f\u008f  \u0082èFY41ì5\u0099^VÄ]\u000f\u0082uñ\u0000IÅ'êÞ¶Q,\u0093\u0019Ôºr\u0090\u0018\u0089Ôc¹!®\u0081\b<M\u009e\u007fÄ\u0004\b*\u0092\u0087ªðÁÿq®\u0010Î\u0007èï`Ð\u0080d\u000fì¯î \u009f<5\u0010Í¤Px[ª\u0090Tè¡dvWr\u008e\"\u0010\u00ad\u0018ËåKLRQ`\u008a?Ï\u0007\u00ad\u0088¿\u0010«ýáaØq¨À=H\u0085Ûdîç\u007f\u0010¶Ï\u00860~:\u0017|®ý\u0015î\u0004\u0094Ù\u0093\u0010[8'\u0095\u0087z)\u0006ñjÅõ&/& \u0010\u0012m´\u008fG\f\u000e\u0096K>Y5ìD\u008aÛ\u0010g·â\u008eÍ\u001cß\u0086áÐª\u009cqí\u0096Þ\u0018\u008dPAÎ\u0014/\u009d\u00856á\u0090gÂ³\u0003 é\u0088?\u0085ìþJ\u008d\u0018'\fz5WýwÄTéä§\u0012YåkR{æØyh\u0094\u009d\u0010>@\u0087Ì°IÙC§?îé|Ï\u008b\u008b0Q2sÙ\u008di\u0095Å\u001fiíÔ$º\u0015¥HeÄmL\u0090\u0093¥½\u0015j\u0088\u0006\u0093Àò7sõj\u0002\báþ\u001eôû¾8\u009bà\u001a\u0010·\u0091ÆÛôu\u000b5m\u0010±\u0007¶\u007fß\b\u0010\u0085Ñ .\u0083\u0082\u0004\u0091PËYµ\u0094\u001c&â\u0010\u0091³\u0005:8ÍîG/A\u0098î\u0081\u001eRe êKÜ`M8Ü³ª¢¦«\\íEö¤È\u0090æ:³Ò\u0093M\tè`\u0098Í\u0018î r\u008e\u00ad\u000bÛf\u000e¯\u0016%\u0015\n»\u009dÔº¯9\u008e\u0006í\u00968ÍþÁ\u00101»Ùö\u0007 Ó;¬þ\brû*´þH\u0003\u008bØè\u0097\u009a*A\u0086?»³[Î\u0096®~÷>Ëõ\u0010RkX\u0004äHBqz\u009a\u0013Ô =aN\u0018òÖ\n\u0019/¥otÀg\u0001+úmlZr²Ç$'Ò[ì\u0010@\u009e\u0099^%F\"\u008f¼ò\u000f\u001cLEÂ0\u0010óf\u0099\u000e\u0095\u0015\u0007\u0085?'\u008aH(´\u0015Ï\u0010~N\u0083²¯ï£\u00910:xT\u0095\u001dUj\u0010¦¤\u000eÜb\u009f\u0013'\u009bZ\t\u0080ÕOø¬\u0010+Á4°dsØ§æGý0¯W\u009aW\u0018&¡\u0081Uf[®ü\u000fè´%ÅË\u0000Ï\u001d\u0005^ë$ãiâ  g\u0005s8«\u0083ù\u0086ü\u001b¾~¥\u0004\u0014N¦\fB?\u00801ò&Ê\fq_©uM\u0010\u0011¦\u001a\u001e\u009aù\ts¯w?û\u009d\r¥å\u0010.CÿmÞ#$ã®¯-DÌgÜ\u0097\u0010~\r\u008cnî\u001fÿ8Yhl\u0007Ûr\u0091> `v·ÿñ\u001f\b\u009a-s´\u0081\u0013ØÈL/(òq'«;\t\u000e{i\u0093H¸åæ";
      short var8 = 1097;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = d(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     k = var9;
                     l = new String[52];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u0010ÿ\u0085wÀap`lØ8nv.\"s\u009bx\u0098ÆüÚ>\u0011\u0018?Ø\u0014\u0093¨J\u00863¤Ú=Ï¿'\u009dX\u0097oey-\u0095·\r";
                  var8 = 49;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void V(TickEvent event) {
      long a = c ^ 52070939686532L;
      long ax = a ^ 77191938165260L;
      long axx = a ^ 126264170205609L;
      long axxx = a ^ 1655458864803L;
      d<"ú">(-6302117602572066232L, a);
      if (!this.w(new Object[]{axx})) {
         友何何树友何何何何树 font = Cherish.instance.h().n(d<"o">(this, -6301926754198079731L, a).getValue().intValue());
         boolean isNormal = d<"o">(HUD.instance, -6303174951083615942L, a).C(c<"w">(13031, 8728694531783602516L ^ a));
         Cherish.instance.getModuleManager().k().forEach(modulex -> {
            long axxxx = c ^ 7876044345567L;
            d<"ú">(1067714972495840275L, axxxx);
            if (!d<"o">(this, 1068283600353650565L, axxxx).contains(modulex)) {
               d<"o">(this, 1068283600353650565L, axxxx).add(modulex);
            }
         });
         d<"o">(this, -6302675303982710306L, a)
            .removeIf(
               modulex -> {
                  long axxxx = c ^ 114769237148528L;
                  d<"ú">(-2486507800772683844L, axxxx);
                  return (modulex.D() == d<"y">(-2490212818247121926L, axxxx) || modulex.D() == d<"y">(-2486609460885312686L, axxxx))
                     && d<"o">(this, -2489793511656557803L, axxxx).getValue();
               }
            );
         d<"o">(this, -6302675303982710306L, a).sort(Comparator.<Module>comparingDouble(modulex -> {
            long axxxx = c ^ 15338730572002L;
            d<"ú">(1651769684573166638L, axxxx);
            String name = this.v(modulex);
            return isNormal ? font.A(name) : d<"o">(mc, 1651721057123936644L, axxxx).width(name);
         }).reversed());
         d<"o">(this, -6302675303982710306L, a).forEach(modulex -> {
            long axxxx = c ^ 92087164998295L;
            long axxxxx = axxxx ^ 95075471066390L;
            modulex.V().H(modulex.isEnabled() ? d<"y">(5519373556187680254L, axxxx) : d<"y">(5519846912157385208L, axxxx), axxxxx);
         });
         float height = 0.0F;
         float maxWidth = 0.0F;
         float baseModuleHeight = font.K() + d<"o">(this, -6302795611479816480L, a).getValue().intValue() + 3;

         for (Module module : d<"o">(this, -6302675303982710306L, a)) {
            if (module.isEnabled() || !module.V().B(d<"y">(-6302485182101101077L, a), axxx)) {
               String text = this.v(module);
               float currentWidth = isNormal ? font.A(text) : d<"o">(mc, -6302166298815293470L, a).width(text);
               maxWidth = Math.max(0.0F, currentWidth);
               height = 0.0F + baseModuleHeight * (float)module.V().T(ax);
               break;
            }
         }

         d<"û">(
            this,
            maxWidth
               + d<"o">(this, -6302389800750558383L, a).getValue().intValue() * 2
               + (!d<"o">(this, -6302295055050835750L, a).C(c<"w">(14932, 3226104035694918117L ^ a)) ? 1 : 0),
            -6303791845270244262L,
            a
         );
         d<"û">(
            this,
            height
               + (
                  !d<"o">(this, -6302295055050835750L, a).C(c<"w">(14932, 3226104035694918117L ^ a))
                        && !d<"o">(this, -6302295055050835750L, a).C(c<"w">(18793, 6233629493125335791L ^ a))
                     ? 0
                     : 1
               ),
            -6303075284188723640L,
            a
         );
         d<"û">(this, d<"o">(this, -6303885544941757338L, a) > mc.getWindow().getGuiScaledWidth() / 2.0F, -6302767394206210681L, a);
      }
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11055;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友树友友友友何何何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = k[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树友友友友何何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void c() {
      n[0] = "\reZ3sq\u0002%\u00178yl\u0007x\u001c~qq\n~\u001852w\u0003{\u0018~xw\u001d{\u00181e0厥栚县厛受叕伻佞伡桁";
      n[1] = boolean.class;
      o[1] = "java/lang/Boolean";
      n[2] = "\t\u0001pi;X\u0002\u000ea&GA\r\u0014oepq\u001b\u0003cxa]\f\u000e";
      n[3] = "\f\u0001 fpk\u0003Ammzv\u0006\u001cf+rk\u000b\u001ab`1I\u0000\u000b{iz";
      n[4] = "2X\u001eI{\u0001=\u0018SBq\u001c8EX\u0004y\u00015C\\O:\u0007<F\\\u0004p\u0007\"F\\Km@\u0019ct";
      n[5] = "\u0010\u0017";
      n[6] = "\u0003p";
      n[7] = void.class;
      o[7] = "java/lang/Void";
      n[8] = "I\u0016E-\u0007EW\u001e_beYP\u0003";
      n[9] = "S:\u0019\u0003\u0014a\\zT\b\u001e|Y'_N\ro\\!RN\u0012c@8\u0019-\u0014jU\u0002V\f\u000ek";
      n[10] = "r)\bd''}iEo-:x4N)>)}2C)!%a+\bI=%s\"TQ)$d\"";
      n[11] = "\u0014\u0014`3Es\u001bT-8On\u001e\t&~_h\u001e\u0016=~Kr\u001e\u0017/$Cs\u0019\t`厛使受桦桫桟厛栻佉厼";
      n[12] = "\u001bs'\u001dt\u001a\u00143j\u0016~\u0007\u0011naPv\u001a\u001che\u001b5桤桩取栘厵叐传厳取栘";
      n[13] = float.class;
      o[13] = "java/lang/Float";
      n[14] = "m\r $l=bMm/f g\u0010fiu3b\u0016kij?~\u000f \u0005l=b\u0006o)U3b\u0016k";
      n[15] = "E8(5kKE8?igD_s?woGE)rVoLN>.z`V";
      n[16] = "~x\u0007\")Z~x\u0010~%Ud3\u0010`-V~i]k1Z>[\u001cb0";
      n[17] = "\\hVU\t\u0016S(\u001b^\u0003\u000bVu\u0010\u0018\u000b\u0016[s\u0014SH伬佪反伭佣厭伬佪栗桩";
      n[18] = "Y5}7\u0007eY5jk\u000bjC~Jq\u000bxq?{t\u000bxC9g~";
      n[19] = ",&4\u0006x_')%I\u0019Q,\"!\u0013";
      n[20] = "\u007fD\u0014\u0014P)!H\u0010\u00161伎伒叨栱栱栨伎厌叨叫(\u000000VZA\tkt\u0014";
      n[21] = "0\r\u0003SZCn\u0001\u0007Q;栠參厡叼桶栢栠栙桻佢o\nZ\u007f\u001fM\u0006\u0003\u0001;]";
      n[22] = "V\u000f\u000fXHL[\\\n4\u0012t\u0004\u0006^\u000b\u001eIA\u0004\u0015FxM^_[RE\b\\\u0014\u00164";
      n[23] = ";+\u0007L]l-:\u0005A<体案厘桥伭栥体伌桂县pV~*g\u001d\u0012@o(j";
      n[24] = "A:\u007f=?\r\u0017wuh\u0001>z;,y;I\u0006{&v~sGl$=hC\u0018ilm\u0001";
      n[25] = "\t\u00137N'r\u0004@2\"叔众厡伤原栻佊众桻桠\\I}!\u000eIdD.$";
      n[26] = "6N\u001b^\u0011\u001e;\u001d\u001e2叢佻厞佹伭栫核句伀佹p\r\u001e\u001fd\u001f\u000b\fL\u0018<";
      n[27] = "%8\u001b;`pr1\u000fw\u0003R\u0014\t7\u0005he3~\u0005h?l'2";
      n[28] = "\b\t\u0018som\u0005Z\u001d\u001f厜桌厠桺厰叜厜厖桺厠s `lZX\b!2k\u0002";
      n[29] = "%qtcam(\"q\u000f厒桌厍但佂佒案厖伓栂\u001ffi%>#/4/(0";
      n[30] = "\u0011\u0001OcCdO\rKa\"叝佼厭厰框叡佃核桷厰_\u0013}^\u0013\u00016\u001a&\u001aQ";
      n[31] = "\u000fA\u0007T\u0000xY\f\r\u0001>栟佩伡桽伳叽栟佩伡桽n\u0000v\tL\r\u001e\u0001oTF";
      n[32] = "\u007fFe/Qrr\u0015`C桸厉佉佱栗厀似众受可\u000e|^s-\u0017u}\ftu";
      n[33] = "b+3Fh`3x6K\n伇桋栏伍栢叉厙伏叕伍;:g1k2\u0001k44f";
      n[34] = "8z\u0016.S\u00165)\u0013B厠样桊栉传伟厠样桊栉}|\u0013\u0013cy\r}\nNi";
      n[35] = "PyE\u00108fFhG\u001dY栝栣佔栧栵桀余叹及叽,3tA5_N%eC8";
      n[36] = "W\u0012X\"\u0017\fZA]N栾号佡伥佮厍古佩叿去3sXN_E]t\\KU";
      n[37] = "$\u0006=x:^)U8\u0014叉桿厌桵桏受叉厥厌桵V-0\u000b+\u0014-x{\u0002+";
      n[38] = "\"\":1y</q?]桐余伔桑案厞伔叇桐伕Q4qt9paf7y7";
      n[39] = "R&\u0016\u0018KL_u\u0013t伦桭栠厏桤厷桢伩佤桕}\u001dC\u0004ItMO\u0005\tG";
      n[40] = "Dqz_Q2\u001bsl\u0002+b~)+\u000bOw\u0005|`\u0002O\u000f";
      n[41] = "Ys$#0eT !O栙厞佯佄伒桖參桄佯叚Op?d\u000b\"4qmcS";
      n[42] = "D7E\u001a\u000fB\u0012zOO1叿伢栓栿口史叿伢叉栿 \u000fLB:OP\u000eU\u001f0";
      n[43] = "<ib+\u000e|m:g&l伛栕桍栘伋伱厅叏厗参V\\{o)cl\r(j$";
      n[44] = "\u000b\u001aMb'3]WG7\u0019\u00150\u001b\u001e&#wL[\u0014)fM";
      n[45] = "A\u0018{+\u0004|O\u001b(ka(\u007fGr-_|\u007fv!s\u0018(R\u000f6\u007fY&";
      n[46] = "Qh_1Ny\\;Z]厽伜栣叁佩厞厽厂佧叁44F1J:\u0004f\u0000<D";
      n[47] = "/\u0018T9:?\"KQU叉栞厇伯栦伈佗佚伙桫?kz:t\u001bOjcg~";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   @EventTarget
   public void h(Render2DEvent event) {
      long a = c ^ 137656637794560L;
      long ax = a ^ 22392838428040L;
      long axx = a ^ 114208115180499L;
      long axxx = a ^ 36005518282285L;
      long axxxx = a ^ 92257678672167L;
      d<"ú">(8578850446131035596L, a);
      if (!this.w(new Object[]{axxx})) {
         树树树友友树友树树树 fontManager = Cherish.instance.h();
         int count = 0;

         for (Module module : d<"o">(this, 8578288964813200986L, a)) {
            float animOut = (float)module.V().T(ax);
            if (module.isEnabled() || !module.V().B(d<"y">(8578584846539995759L, a), axxxx)) {
               String moduleName = this.v(module);
               Color color = HUD.instance.getColor(0);
               boolean isNormal = d<"o">(HUD.instance, 8575642787819980478L, a).C(c<"w">(281, 3076839594679229732L ^ a));
               float stringWidth = isNormal
                  ? fontManager.n(d<"o">(this, 8579178518911248521L, a).getValue().intValue()).A(moduleName)
                  : fontManager.X().m(moduleName);
               float moduleHeight = fontManager.n(d<"o">(this, 8579178518911248521L, a).getValue().intValue()).K()
                  + d<"o">(this, 8575885727919315300L, a).getValue().intValue()
                  + 3;
               float finalX = d<"o">(this, 8578301878521002499L, a)
                  ? this.r()
                     + d<"o">(this, 8574920615491431390L, a)
                     - stringWidth
                     - (
                        !d<"o">(this, 8578673809695811422L, a).C(c<"w">(11648, 2024159795712127406L ^ a))
                           ? 4 + d<"o">(this, 8578578523333332181L, a).getValue().intValue()
                           : 3 + d<"o">(this, 8578578523333332181L, a).getValue().intValue()
                     )
                  : this.r() + (!d<"o">(this, 8578673809695811422L, a).C(c<"w">(14932, 3226053900996929121L ^ a)) ? 1 : 0);
               float startX = d<"o">(this, 8578301878521002499L, a) ? this.r() + d<"o">(this, 8574920615491431390L, a) + 30.0F : this.r() - stringWidth - 30.0F;
               float animatedX = startX + (finalX - startX) * animOut;
               float renderY = this.v()
                  + 0.0F
                  + 1.5F
                  + (
                     !d<"o">(this, 8578673809695811422L, a).C(c<"w">(14932, 3226053900996929121L ^ a))
                           && !d<"o">(this, 8578673809695811422L, a).C(c<"w">(14474, 5064477822241105034L ^ a))
                        ? 0
                        : 1
                  );
               if (animOut > 0.0F) {
                  float bgY = renderY + -1.5F;
                  float bgWidth = stringWidth + d<"o">(this, 8578578523333332181L, a).getValue().intValue() * 2;
                  int bgAlpha = (int)(d<"o">(this, 8575417756521349995L, a).getValue().intValue() * animOut);
                  String textColor = d<"o">(this, 8579038282549852591L, a).getValue();
                  byte textX = -1;
                  switch (textColor.hashCode()) {
                     case -1955878649:
                        if (!textColor.equals(c<"w">(13031, 8728784249172848336L ^ a))) {
                           break;
                        }

                        textX = 0;
                     case -1819712192:
                        if (textColor.equals(c<"w">(25125, 1781225604066393621L ^ a))) {
                           textX = 1;
                        }
                  }

                  switch (textX) {
                     case 0:
                        RenderUtils.drawRectangle(event.poseStack(), animatedX, bgY, bgWidth, moduleHeight, new Color(0, 0, 0, bgAlpha).getRGB());
                     case 1:
                        PoseStack var10000 = event.poseStack();
                        Object[] var10010 = new Object[]{null, null, null, null, null, null, null, new Color(0, 0, 0, bgAlpha), axx};
                        var10010[6] = 14.0F;
                        var10010[5] = 3.0F;
                        var10010[4] = moduleHeight;
                        var10010[3] = bgWidth;
                        var10010[2] = bgY;
                        var10010[1] = animatedX;
                        var10010[0] = var10000;
                        ShaderUtils.A(var10010);
                  }

                  if (!d<"o">(this, 8578673809695811422L, a).C(c<"w">(23557, 6696791773813997578L ^ a))) {
                     Color lineColor = 树树何友友友友何树友.z(color, 0.7F * animOut);
                     float lineY = renderY
                        + (d<"o">(this, 8578673809695811422L, a).C(c<"w">(4769, 9028049119311908517L ^ a)) ? -0.5F : (isNormal ? -1.5F : -1.0F));
                     float lineHeight = d<"o">(this, 8578673809695811422L, a).C(c<"w">(16475, 1973706049911692402L ^ a)) ? moduleHeight - 2.0F : moduleHeight;
                     float lineX = animatedX
                        + (d<"o">(this, 8578301878521002499L, a) ? stringWidth + d<"o">(this, 8578578523333332181L, a).getValue().intValue() * 2.0F : -1.0F);
                     String var35 = d<"o">(this, 8578673809695811422L, a).getValue();
                     byte var36 = -1;
                     switch (var35.hashCode()) {
                        case 79860828:
                           if (!var35.equals(c<"w">(16475, 1973706049911692402L ^ a))) {
                              break;
                           }

                           var36 = 0;
                        case 2576759:
                           if (!var35.equals(c<"w">(24767, 261053722857585813L ^ a))) {
                              break;
                           }

                           var36 = 1;
                        case 2573198:
                           if (!var35.equals(c<"w">(18793, 6233578464700634475L ^ a))) {
                              break;
                           }

                           var36 = 2;
                        case 84277:
                           if (var35.equals(c<"w">(14932, 3226053900996929121L ^ a))) {
                              var36 = 3;
                           }
                     }

                     switch (var36) {
                        case 0:
                        case 1:
                           RenderUtils.drawRectangle(event.poseStack(), lineX, lineY, 1.0F, lineHeight, lineColor.getRGB());
                        case 2:
                           RenderUtils.drawRectangle(
                              event.poseStack(),
                              animatedX + (d<"o">(this, 8578301878521002499L, a) ? 0 : -1),
                              renderY - 2.5F,
                              stringWidth + 1.0F + d<"o">(this, 8578578523333332181L, a).getValue().intValue() * 2,
                              1.0F,
                              lineColor.getRGB()
                           );
                           RenderUtils.drawRectangle(event.poseStack(), lineX, lineY, 1.0F, lineHeight, lineColor.getRGB());
                        case 3:
                           RenderUtils.drawRectangle(
                              event.poseStack(),
                              animatedX,
                              renderY - 2.5F,
                              stringWidth + d<"o">(this, 8578578523333332181L, a).getValue().intValue() * 2,
                              1.0F,
                              lineColor.getRGB()
                           );
                     }
                  }

                  Color textColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(color.getAlpha() * animOut));
                  float textX = animatedX + d<"o">(this, 8578578523333332181L, a).getValue().intValue();
                  if (isNormal) {
                     fontManager.n(d<"o">(this, 8579178518911248521L, a).getValue().intValue())
                        .N(
                           event.poseStack(),
                           moduleName,
                           textX,
                           renderY
                              + fontManager.n(d<"o">(this, 8579178518911248521L, a).getValue().intValue()).Q(moduleHeight)
                              - 1.0F
                              + (d<"o">(HUD.instance, 8579254099834313296L, a).C(c<"w">(20428, 5689949343926490057L ^ a)) ? 0.5F : 0.0F),
                           textColor.getRGB(),
                           d<"o">(this, 8578426805809939123L, a).getValue(),
                           0.5
                        );
                  }

                  fontManager.X()
                     .x(
                        event.poseStack(),
                        moduleName,
                        textX,
                        renderY + (moduleHeight - 1.0F) / 2.0F - 4.0F,
                        textColor.getRGB(),
                        d<"o">(this, 8578426805809939123L, a).getValue()
                     );
               }

               float var42 = 0.0F + moduleHeight * animOut;
               count++;
               break;
            }
         }

         this.b(event.poseStack());
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友树友友友友何何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'o' && var8 != 251 && var8 != 'y' && var8 != 'C') {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 170) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 250) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'o') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'y') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 12;
               case 1 -> 62;
               case 2 -> 20;
               case 3 -> 17;
               case 4 -> 8;
               case 5 -> 39;
               case 6 -> 58;
               case 7 -> 5;
               case 8 -> 26;
               case 9 -> 41;
               case 10 -> 43;
               case 11 -> 34;
               case 12 -> 0;
               case 13 -> 14;
               case 14 -> 35;
               case 15 -> 4;
               case 16 -> 13;
               case 17 -> 54;
               case 18 -> 47;
               case 19 -> 24;
               case 20 -> 55;
               case 21 -> 36;
               case 22 -> 18;
               case 23 -> 11;
               case 24 -> 3;
               case 25 -> 60;
               case 26 -> 21;
               case 27 -> 38;
               case 28 -> 6;
               case 29 -> 50;
               case 30 -> 19;
               case 31 -> 56;
               case 32 -> 16;
               case 33 -> 7;
               case 34 -> 46;
               case 35 -> 23;
               case 36 -> 59;
               case 37 -> 31;
               case 38 -> 2;
               case 39 -> 53;
               case 40 -> 48;
               case 41 -> 51;
               case 42 -> 15;
               case 43 -> 33;
               case 44 -> 52;
               case 45 -> 32;
               case 46 -> 1;
               case 47 -> 42;
               case 48 -> 45;
               case 49 -> 28;
               case 50 -> 61;
               case 51 -> 25;
               case 52 -> 27;
               case 53 -> 44;
               case 54 -> 10;
               case 55 -> 29;
               case 56 -> 30;
               case 57 -> 9;
               case 58 -> 37;
               case 59 -> 22;
               case 60 -> 49;
               case 61 -> 63;
               case 62 -> 57;
               default -> 40;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private String v(Module module) {
      long a = c ^ 110148436676408L;
      d<"ú">(-7983147005048742924L, a);
      String name = d<"o">(HUD.instance, -7982705959342441368L, a).C(c<"w">(5665, 3172672776509533244L ^ a))
            && d<"o">(this, -7983499823017583463L, a).getValue()
            && d<"o">(this, -7983499823017583463L, a).v().get()
         ? module.v()
            .replaceAll(c<"w">(22178, 5676775094575918237L ^ a), c<"w">(31793, 3241470177543669296L ^ a))
            .replaceAll(c<"w">(22391, 2361844977466928507L ^ a), c<"w">(23648, 5274038551175718519L ^ a))
         : module.v();
      if (d<"o">(this, -7983047505293506119L, a).getValue()) {
         name = name.toLowerCase();
      }

      String suffix = module.z() == null
         ? ""
         : d<"y">(-7981508126679430905L, a) + " " + (d<"o">(this, -7983047505293506119L, a).getValue() ? module.z().toLowerCase() : module.z());
      return name + suffix;
   }

   private static String HE_WEI_LIN() {
      return "何建国230622195906030014";
   }
}
