package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.ui.何树树友树树友树友树;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友友树何何友友友友何 extends Module implements 何树友 {
   public static final ModeValue 友友何何友树友友树树;
   public static final ModeValue 友何何友树何何何何友;
   public static final ModeValue 何友树树何树友何树树;
   public static final ModeValue 树何友友友何树树何树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[8];
   private static final String[] k = new String[8];
   private static String HE_DA_WEI;

   public 友友树何何友友友友何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/display/友友树何何友友友友何.a J
      // 03: ldc2_w 71898713833180
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 12114
      // 0c: ldc2_w 3293514001389634712
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友友树何何友友友友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 10952
      // 19: ldc2_w 2203502497394475279
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/友友树何何友友友友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w -503859647782139500
      // 26: lload 1
      // 27: invokedynamic ä (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/display/友友树何何友友友友何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7117948314568837460L, 2959645043608294058L, MethodHandles.lookup().lookupClass()).a(39604306682688L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 87171818789275L;
      a();
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[26];
      int var5 = 0;
      String var4 = "ÿà\nè)ø\u0091ix÷âµE\u008a¿¦\u0010Ï\u0085¼áÈÁ\u000e9.½]ÎËp\u0015\u009b\u0018&\u009a>'E\u0016b\u001b\u009d,\u009foÍ¥Ë){: \u0097ã*\u000e\f(8cÚ®J»|\u0098\u0016~\u007f¼2\u0015\u0016ö:0/\u008c»·WïÂ§ts\u000bA¬N#\u0084\u0092\u001bÎ\u0016\b\u0089\u0010«ìnýFÊÿÊØ£\u00874¾Ç\u00ad;\u0010®\u0088Îº\u000fZr\r5°{`Å\u0004jð\u0010²R\u0097¡û/åâGY\u008dX\fþ\u008b8\u0010å]a\u0096\u0016ØÓ6t¶`4}ì\n\u0082\u0018\u0015;\u0098\u0002FU@¶\u008fÞ ^²C\u0003\u0083\u009bë9 é\u0014`ò\u0010¢\u0091ô;ò\u0094\u0081ª8)ò\u0096\u0088\u001d\u0010³\u0010\u000eÉ}Tmï\u0093\u0013¤5hµTëõ¡\u0010\u0088^\u0091«òUå+>joi'¿ú\u0005\u0010\u008b\u008el\u008aBæ)\u008dí:8D\u008a´°5\u0010Ã¤ñmq\u0018pÉZäQ\u0001w0D\u0095\u0010G%)\u008d%ó1Ûö\u0006\u0081N·ß\u009aa\u0018\u0019µ\u0003®é¼,òñì7\u00adÿ\u0016}ÈC·\u001biôdNÃ\u0010\r$\u0005ÿa~[N\u00932¿\u0083Í\u009c\u008en\u0010\rtÆy>\fÌU¡§ñ\u001dù¦¼\f\u0018^\nM\u0019\u001a\rþ=¥\u0006Nñ$\u0017³\u0013\u0012\nk¥È\\¢\u0096\u0010²<ÚR$\nÈ·r9\u0014¬j÷æH\u0018bÃ\u0017\nY\f\u001d\u0091HU6\u000b9æÌÂÇÀDFFMF\u000b\u0018U<ÏùÝwÓ©\u008fIe,ç¨þç¸öÖý~u×Ô\u0010¨Â´JF\u0080\u0007;úP\u0018ÌJ²\u001eÞ\u0010»`\u0082Á\u0012\u0092Ëx#\u0092àÅ8\u0005\u0003ë";
      short var6 = 479;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = c(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     c = var7;
                     h = new String[26];
                     友友何何友树友友树树 = new ModeValue(
                        b<"i">(17520, 9174839039730485499L ^ var9),
                        b<"i">(30305, 5768917151775013619L ^ var9),
                        new String[]{b<"i">(32442, 6617300415361579L ^ var9), b<"i">(26247, 7119400882347649537L ^ var9)},
                        b<"i">(28905, 1470620083524942951L ^ var9)
                     );
                     友何何友树何何何何友 = new ModeValue(
                        b<"i">(2573, 2716774696722187913L ^ var9),
                        b<"i">(13597, 8700933091122608538L ^ var9),
                        new String[]{
                           b<"i">(13109, 3046208353370079142L ^ var9),
                           b<"i">(14218, 885774927757409024L ^ var9),
                           b<"i">(12596, 299394734942780856L ^ var9),
                           b<"i">(30122, 6378839971213457722L ^ var9)
                        },
                        b<"i">(9714, 5463577722991700327L ^ var9)
                     );
                     何友树树何树友何树树 = (ModeValue)new ModeValue(
                           b<"i">(3381, 1201525548582879662L ^ var9),
                           b<"i">(10638, 3071212773243708687L ^ var9),
                           new String[]{
                              b<"i">(2139, 1763312739363275983L ^ var9), b<"i">(18573, 5773072341258470402L ^ var9), b<"i">(3744, 5203314514418745893L ^ var9)
                           },
                           b<"i">(20426, 9175373010033640265L ^ var9)
                        )
                        .i(() -> {
                           long var0x = a ^ 83709109052145L;
                           return c<"ä">(7290410396235967145L, var0x).C(b<"i">(21660, 1697571624980489056L ^ var0x));
                        });
                     树何友友友何树树何树 = new ModeValue(
                        b<"i">(29654, 7976111515723972417L ^ var9),
                        b<"i">(3350, 2957452402764792204L ^ var9),
                        new String[]{b<"i">(26201, 4343220947097660123L ^ var9), b<"i">(3090, 3688145887729139867L ^ var9)},
                        b<"i">(30060, 3764526040469092836L ^ var9)
                     );
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "\u0090[âùGx\u0096£bÜøwkÂql(¾+)JXþ÷,QÙ\u0087rÜ\u0011\u0001K.Ü;IÔad.HÅg,ñ\u009ejW¢¤Y\u009a7\u0087\u0094\u0099";
                  var6 = 57;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 27;
               case 1 -> 33;
               case 2 -> 7;
               case 3 -> 63;
               case 4 -> 5;
               case 5 -> 15;
               case 6 -> 37;
               case 7 -> 19;
               case 8 -> 51;
               case 9 -> 44;
               case 10 -> 18;
               case 11 -> 4;
               case 12 -> 8;
               case 13 -> 3;
               case 14 -> 12;
               case 15 -> 11;
               case 16 -> 61;
               case 17 -> 45;
               case 18 -> 49;
               case 19 -> 59;
               case 20 -> 47;
               case 21 -> 24;
               case 22 -> 22;
               case 23 -> 23;
               case 24 -> 39;
               case 25 -> 0;
               case 26 -> 14;
               case 27 -> 57;
               case 28 -> 13;
               case 29 -> 16;
               case 30 -> 41;
               case 31 -> 1;
               case 32 -> 40;
               case 33 -> 17;
               case 34 -> 32;
               case 35 -> 28;
               case 36 -> 48;
               case 37 -> 54;
               case 38 -> 55;
               case 39 -> 46;
               case 40 -> 50;
               case 41 -> 36;
               case 42 -> 35;
               case 43 -> 53;
               case 44 -> 2;
               case 45 -> 26;
               case 46 -> 30;
               case 47 -> 38;
               case 48 -> 58;
               case 49 -> 29;
               case 50 -> 42;
               case 51 -> 62;
               case 52 -> 43;
               case 53 -> 31;
               case 54 -> 34;
               case 55 -> 56;
               case 56 -> 9;
               case 57 -> 10;
               case 58 -> 25;
               case 59 -> 60;
               case 60 -> 52;
               case 61 -> 20;
               case 62 -> 6;
               default -> 21;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友友树何何友友友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 4805;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友友树何何友友友友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   @EventTarget
   public void x(Render2DEvent event) {
      long var10000 = 友友树何何友友友友何.a ^ 64830373817328L;
      if (Cherish.instance.getModuleManager().getModule(HUD.class).isEnabled()) {
         何树树友树树友树友树.B(event.poseStack());
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 221 && var8 != 'r' && var8 != 228 && var8 != 214) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'Z') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'a') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 221) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'r') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 228) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友友树何何友友友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "m\u0000%Y1.b@hR;3g\u001dc\u00143.j\u001bg_p(c\u001eg\u0014:(}\u001eg['o叅厥栚佯伋厊叅厥叀佯";
      j[1] = "w@UJN\u0010x\u0000\u0018AD\r}]\u0013\u0007W\u001ex[\u001e\u0007H\u0012dBUdN\u001bqx\u001aET\u001a";
      j[2] = "\u001dx9\u0012\t\u000e\u0016w(]u\u0017\u0019m&\u001eB'\u000fz*\u0003S\u000b\u0018w";
      j[3] = "+\u0003\u0010*>,$C]!41!\u001eVg<,,\u0018R,\u007f伖伝厦佫伜厚伖伝桼栯";
      j[4] = "0N\\g\u0002{;AM(cu0JIr";
      j[5] = "%\\\u0019]\u0006fxWC \u0002\f\"Y\u0016CV4t@__k5~\fE\u001dScgEY ";
      j[6] = "\u0007+\u0015\u0016f\nZ Ok又伽佤厈栳伶佖伽佤厈*R3\fIzKUnP\\";
      j[7] = "Bf\"NA\rE7#P>似桡双桔佬栧似伥栖厎1\u0004\b\u0017p2]\u0003Y\u0016n";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String LIU_YA_FENG() {
      return "何树友，和树做朋友";
   }
}
