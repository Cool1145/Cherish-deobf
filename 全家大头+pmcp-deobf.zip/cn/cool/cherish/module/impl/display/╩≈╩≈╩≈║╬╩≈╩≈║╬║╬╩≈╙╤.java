package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.ui.何树友友何友友何树树;
import cn.cool.cherish.ui.树友何何何树友树何友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树树树何树树何何树友 extends Module implements 何树友 {
   public static 树树树何树树何何树友 何友友何友何何何树树;
   public HttpServer 友友友友友树树树何树;
   public NumberValue 何友树树何何树友树友 = new NumberValue("Port", "端口", 8080, 1024, 65535, 1);
   public BooleanValue 何树树何友何友何树友 = new BooleanValue("Show Notifications", "显示通知", true);
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[20];
   private static final String[] l = new String[20];
   private static int _职业技术教育中心学校 _;

   public 树树树何树树何何树友() {
      super("WebControl", "网页控制", 树何友友何树友友何何.友友友树何友何何树何);
      何友友何友何何何树树 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3360938280409605549L, 3478430346013454451L, MethodHandles.lookup().lookupClass()).a(247411390644295L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(18816374745838L << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[13];
      int var12 = 0;
      String var11 = "\u001fR\u000fTÁÏ\u0012\u0012¤èù'§¢^É \u008d·6\r¨yFÛOå?Ï\u009c\u0081\u001e<@\u0086 í\u0005\u00857oÀ\u0094å\u0084iy¶J\u0018ý\u008c_¬Ì\u0085&mBrÚO\u0086\u000bè½¶\u0083¼2BÒ!= \u001a*Ò\u0003Å\u0080ø\u009c9\u0007Z\u008c¨ò\u001f\u0099öl§\u0000£6e\u0016L¡\u0098B\u0005Ü\u00196(\u0010\u0085\u0004\u0088\u0092\u008dÔ\u009aO4s\u0013\u001dÓnt\u009bÄj\u0089ë?ØI\u001dd\u001c¨3\"~\u0007\u0011\u0082y\u0092ªß¾\u009d8O;7`åºû?ü\u0004\u0002\u0005%µZ4\u008b¼êQ\u0012/s;?Ñ\u0091w¼yCnÈYÔÂù\u001f7gVü\u0016\u007f\u0083\u008b×[¹túÎ\u0086\u0085\u0019J\u0010µDÌþ\f¯êýé\u009a\\\u0092qé\u008e\u0085\u0010*R.O\u0019ò\u0084\f\u009bK{\u000e\u0080Ä\u0098.\u0010m\u008eCþ;Ôó\u009dé°4\u000blýt\u001c@Ö\u001c¸íë\u009f\u0011<ä`#·\u0085lÐ¹»Ôð\b45:¤>\u001e\u0083R\u000e&SzÕ\u0083\u0090Öo±¤µ\u0004ìîCÒN\u009a\u009dæAæÑ\u0015·¼Ü\u0080\u0000Î%\u00adj\u0017\u00100\u0087\u0090ãGvPCøÐ\u000f3Ùð±¦Ú´\u0094¥}òå\u0098Z\u0080Éëé5V\u000e\u00966ÏíÆä\u009bb\u0090Ë[¸9XÃz\f";
      short var13 = 370;
      char var10 = 16;
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[13];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(18816374745838L << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-80, 70, -81, 88, -31, -113, -14, -59});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "3\u0002í\t\u009b\u0004Z\u0086&\u009aÊåç\u0097\u00ad¯7\u0005Q´Ú×\tK\u0018Ç#2Z\\0G~\u0095é Ú\u0013¼Yö¦N\u0018ê\u0083úÃ°";
                  var13 = 49;
                  var10 = 24;
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 14;
               case 1 -> 26;
               case 2 -> 15;
               case 3 -> 53;
               case 4 -> 39;
               case 5 -> 8;
               case 6 -> 12;
               case 7 -> 46;
               case 8 -> 6;
               case 9 -> 47;
               case 10 -> 16;
               case 11 -> 13;
               case 12 -> 50;
               case 13 -> 0;
               case 14 -> 54;
               case 15 -> 25;
               case 16 -> 7;
               case 17 -> 52;
               case 18 -> 24;
               case 19 -> 48;
               case 20 -> 56;
               case 21 -> 51;
               case 22 -> 43;
               case 23 -> 29;
               case 24 -> 62;
               case 25 -> 2;
               case 26 -> 20;
               case 27 -> 18;
               case 28 -> 38;
               case 29 -> 58;
               case 30 -> 22;
               case 31 -> 41;
               case 32 -> 27;
               case 33 -> 10;
               case 34 -> 36;
               case 35 -> 63;
               case 36 -> 40;
               case 37 -> 44;
               case 38 -> 21;
               case 39 -> 45;
               case 40 -> 30;
               case 41 -> 60;
               case 42 -> 42;
               case 43 -> 4;
               case 44 -> 5;
               case 45 -> 37;
               case 46 -> 23;
               case 47 -> 3;
               case 48 -> 57;
               case 49 -> 34;
               case 50 -> 59;
               case 51 -> 28;
               case 52 -> 31;
               case 53 -> 19;
               case 54 -> 55;
               case 55 -> 61;
               case 56 -> 9;
               case 57 -> 1;
               case 58 -> 35;
               case 59 -> 32;
               case 60 -> 33;
               case 61 -> 11;
               case 62 -> 49;
               default -> 17;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 14405;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[p\u00adÛøÇÄ]¡, äi+c\u0081\u0005º\u009aÉþ\fÖ¹\u00ad·\u0012, O¹\u001dOfý\u0013\u0018-R\u001a[1õ\u0088ÿ, ,\u008dÝ\u008a¢\u000b\u0084Ô\u0011åÙÉ\u0006C")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 198 && var8 != 163 && var8 != 202 && var8 != 'I') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 250) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 219) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 198) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 163) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   protected void h() {
      HUD.A();
      if (this.友友友友友树树树何树 != null) {
         this.友友友友友树树树何树.stop(0);
         ClientUtils.P(125527250587045L, "Web控制服务器已停止");
         if (this.何树树何友何友何树友.getValue()) {
            树友何何何树友树何友.E(何树友友何友友何树树.友友树树树树何何友友, "Web控制", "Web控制服务器已停止", 3.0F);
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "bj!xq/m*ls{2hwg5k)/佑栞叐叕伕及叏佚栊栏";
      k[1] = "k$hTg/dd%_m2a9.\u0019e/l?*R&)e:*\u0019l){:*Vqn@\u001f\u0002";
      k[2] = "S\f/-$@&,$\"5\u000f[47%<F3";
      k[3] = "C\u001c\u0000\u0010\nZL\\M\u001b\u0000GI\u0001F]\bZD\u0007B\u0016K\\M\u0002B]\u0001\\S\u0002B\u0012\u001c\u001b栱档栿伦桴栤併伧栿厸";
      k[4] = "/\n\u0014\u0017=\f JY\u001c7\u0011%\u0017RZ$\u0002 \u0011_Z;\u000e<\b\u00146=\f \u0001[\u001a\u0004\u0002 \u0011_";
      k[5] = "f3)F\u0010\u001bm<8\t{\u000fo7/SW\u0018b";
      k[6] = "C\t}8m\"NH~sjyH\u0012dfm2R\u0010ud0\u001fT\u0012`E{%V\u0003b";
      k[7] = "\u0017^\u001a1\u0005)\u0018\u001eW:\u000f4\u001dC\\|\u001c'\u0018EQ|\u0003+\u0004\\\u001a\u001c\u001f+\u0016UF\u0004\u000b*\u0001U";
      k[8] = "\u0019r\u0010Mvh\u00162]F|u\u0013oV\u0000th\u001eiRK7栖伯受叵佻栈双厱佉佫";
      k[9] = "\rbXY;2\u0006mI\u0016Z<\rfML";
      k[10] = "CY\u00180\u001bU[OIA厵厨核栫根桘伫伶叢叱 #\u001dSP_\u001e;\u000b\u0002";
      k[11] = "bAh'g2x\u0016)\u001bN]!\u001fr$`ay\u000b+i\u0007";
      k[12] = "\u0015H]A\u001c3D\n\rBg伅召桮桾伣伺桁召桮厤~ZhK\f\r\u0001^dI\u0015";
      k[13] = "DPu\u0006@\"\u0015\u0012%\u0005;伔桧桶伒叺佦厊伣桶厌9\u0000&\u0013\u0000uKJ/\u0013\f";
      k[14] = "\u001f-K,\u0000\u0001No\u001b/{\u0003%.I*\u001cRUp\u0015+\u0017j\u0019*HtC\u001aGvI\u007f{";
      k[15] = "$\u001cQo/\u001au^\u0001lT伬叝叠伶厓伉伬佃栺桲PnN$\u001c\u0010;?\ft\u001f";
      k[16] = "u,X|fnm:\t\r栒厓叔会桹収栒伍佊厄`o`hf*^wv9";
      k[17] = "RX]A[AJN\f0栯桦右株厦右叵伢佭株eR]GA^[JK\u0016";
      k[18] = "95.\r`Dhw~\u000e\u001b召叀叉受叱栂栶栚佗栍2'N|2y\u000erV9f";
      k[19] = "UfS\r *\u000bb\u0003\u001eB叐厨厘栣伡厁低伶桂佧||.\u0002*XE\"*R9";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   protected void M() {
      HUD.A();
      if (何友友何友何何何树树 != null && this.isEnabled()) {
         try {
            int port = this.何友树树何何树友树友.getValue().intValue();
            this.友友友友友树树树何树 = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
            this.友友友友友树树树何树.createContext("/api", new 树树树何树树何何树友.友树友友何友树树树树());
            this.友友友友友树树树何树.createContext("/", new 树树树何树树何何树友.树树何友树树友友树树());
            this.友友友友友树树树何树.setExecutor(Executors.newFixedThreadPool(3));
            this.友友友友友树树树何树.start();
            String message = "Web控制服务器已启动在端口: " + port;
            ClientUtils.P(125527250587045L, message);
            if (this.何树树何友何友何树友.getValue()) {
               树友何何何树友树何友.E(何树友友何友友何树树.树树友树友友友何何树, "Web控制", message, 3.0F);
            }
         } catch (IOException var8) {
            String messagex = "无法启动Web服务器: " + var8.getMessage();
            ClientUtils.P(125527250587045L, messagex);
            if (this.何树树何友何友何树友.getValue()) {
               树友何何何树友树何友.E(何树友友何友友何树树.树友友何树友树何何友, "Web控制", messagex, 3.0F);
            }

            this.J(false);
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖国企变私企";
   }

   private static class 友树友友何友树树树树 implements HttpHandler, 何树友 {
      private static final long a;
      private static final String[] b;
      private static final String[] c;
      private static final Map d = new HashMap(13);
      private static final long[] e;
      private static final Integer[] f;
      private static final Map g;
      private static final long[] h;
      private static final Long[] i;
      private static final Map j;
      private static final Object[] k = new Object[7];
      private static final String[] l = new String[7];
      private static int _我是何树友 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-5756355800072820961L, -7813450907079428184L, MethodHandles.lookup().lookupClass()).a(199657992355145L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var24;
         Cipher var35 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var25 = 1; var25 < 8; var25++) {
            var10003[var25] = (byte)(135129801303917L << var25 * 8 >>> 56);
         }

         var35.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var31 = new String[115];
         int var29 = 0;
         String var28 = "k4-PæÇXÛÝÀ.u\u0093Äöo<$´Ù$«\u0096\u0093'[(ºß\tÒÂ=zÂ\u001dÏÎö¬(\u001ek U\u0092e\u000ea§\u008bñ\u0010\u001c\u0000\u0082s]T÷iM-P\u009b \u0099\n#£d±º8Æöf7ÑG½ k©óÓ9\u0099©©¶uè6½ì8\u000e@mëÞgû\u009c¾×\u0010\u009d4~9G4 »¼\u009bg\u0089©\u008cñ¨ÏN\u0097¡¹aRÐ-ò\u0015Y\\\u008a\u0006íþ´¿´Qjè )\u0097\u0088\u001d\u0080¡³:ã2Q\u0013F\n\u0091\u007f]{\u0010ÁÅð\u008dRßÌÜ{\u009dTû\u0016\u0010»c\u000eÝoÓ \u009fúå\u009be\r\u0092\u0011\u0018hfr¢d\u0013è9ê\u0091Þ\u009a\u001f4ÚZú2]\u008f¾ýqpHkÇ±\u0098©tcÈA¼ä·¸ø>:¢\u0001¨si§Ã\u0090D/:7kEÕ·\u0085¢çS¢\u0015\u00adàV¡ïïJ.4ß!t_» îTÃÙ|8_¨\u0016Øô\r\u0003å\u0002#\u000fJów.úó'lõ\u0083\u0010Ú\u0005©è£Î\u0018¸6\u0002ÛÅO×¾\u009f\u0018k\u001aÚC\"ê\u000eæ1xµf\u00adU\t=ßïxéÆec\u0007 Ù\u0090nê`\u0013F\u0014\u008d¢aú\u0084Æò\u0095ÿ\u009c\u0086\u0012OÒ\u0091hÿ[\u0096h\u0092Ëç\u000b\u0010\bßÔ=8 »¡#3Ù>Lq\u0084>(\u0006\u0002º\u00921À\u0099ÌX²·²'\u008eØ\u0082¤¤Ò\u001c7ú\u007fóunÿ\u009a~\u001f¬õ»Pñ°7^\u0015®(sê)\u008cå|ÅºÌÕ íQJoi¯ë&|d\u000b\u009a\u0087°\f3\u009eÜ\u0083\u0018i`Ë\u0081\f\u001c±ÇO\u0010AÙM\u0098Ò>]\u0091!×IçÁz\u001ew\u0010Î©\u000e\u000f\ná£½\u001dü\u0017úF|\u0093\u0090`èÆñÈÒ\"V-3T,;Ç\n,\u0080³U¡Â\u001e~ï,\u0093G6\u008cûÚýa?\u000f_t¨A;Iz_:\u0004E\u001c®@Ë|Ì\u0002¾\u0019ÃÛ\u0083Õ2Kôù°\u0007è¶ôFÝâcÏÙ Äåæ\u0000\u000e^ÿI\u0084&\u001a¦Ñ\"B\u009dAâ8\u008d¥m8c\u00adr¥k9\u0097û\u009dÖóØ\\º\u0004¹eJ{\u001d\u0015À\u008eªid¾ÁF0¼\t_ñ§.KN\t\u0004'\tC´\u0014\u009a¿.z\n\u009fÊ\u0000\u0012\u0004Ü(\u0099:þ@\\\u009cÆåÒÃ®É«}S\u0085»YòoÌp\u001eÅè$\u0093\u008b\u0015º\u00adÞ\u009b`\u008e°¯\r¡\u0098 1ù«\u0084\u0085ÏËy´Â8MÏ\u000f±\n\u0007£\u0091s[2\u0019pÉÝµ½gGð\u0013PÆawN\u0012Âz\u0017\u00ad\u0080n,\n=Ó\u009e\u0005ôÂµR®ù\u0006\u009dó¾9±\u0081Ö\b¸GØEµ>\u008dH%s\u0090î\u0080O\u008a\f$5\u008a1x\tÔCÄQ\u00adÄËL{\u0080 \u00029D[Þæ\u00057hÁË\u001f×ýý8\u00ad\u0005Ùe\u008f\u0019\u0005\u0096\u000f\u001bô\u009f\u008ePM\u0083\u009bj\u0087Z*jûf¡í|\u009cpRM\u001b\u001a\u0083oÌëêG\u000bÐJ¿×\u009c>\u0097Ç¶ú5Âß\u0088Hô`\u0014¶Cî¸!ÿð.\u0015\u001b\u0083\u0013®\u0018èJB\u009bÔ\u0096\u001c\u0081\u000fÿ\u0000N\u001dbù¸6Â\u0095öÈ\u0018g¿ùkµZ£\u000e\u001d\u009aý>ýX 4GLäÌ\u0091Y,(ØDnç\u008e\u0086ÎÃ]IrÐ\u0093UO\u0090\u0016®w\u0003\u001cT\bà@F\u009cÚÙÌÝ`\u0084Ú3\u0010±\u0013gªØÛ\u0080\u0096>¾}QwçQO0êQ\u0087>¹u\u0082ás\u0015\u0002æ\u009f4 §VÖnR\u0092F\u009a«4\u001d|\u0087\u0097Zö\u0080¬t\u0016ü\u009e\fb\u000b&bR\u0089¯°nÑ ½\u000f\u007fTBþb / ÿ\u009a\u0087ùè|\u0085\u0015[Á\u007f\u0005\u009f\"XådÖÑ\u0001cú\u0018s¨\u0095\u0083`e\u008eª\tÒ~\u0010\u000f\u0013þÌëaÇu@¥ó\u000f r\u008d^7\u008d£\u001f\u0094»aN¢Eß\n¡£T\u0094\u0081¡1|\u0017 ÎÜ*Z\u0083§7 Rþ»ANI4û(äÍ§\u0099Ú\u001d¸'STÆ#\u0012Ç¬\u001eý\u0099ì\u008e©W:\u0018{\u0092¬7\u008f^E\u0007q÷d³ü\u001eÒÑÿÔ<\u009aE9à3\u0018SI$ñNf¯ë\u001el\\ØÏ¿L×~r©çõ\u0099X±8ljã°%ðH\u008eÙÍ\u000e¿O\u0010\u009eÒ\"3{ü\r}=ÞÌ¾ÚXÅ¦âM\u00adPÕ\u0080¥\u008eJÉRõ67á\u0094Îx\\è\u0085 m«9\u00818'\u009d\u0080q±\u009a\u009dþDË\u007f\u000b\u000b9²\u0087 ' µ\u0090__«\u008aàKã\u0011\u008c;\u008c@§j\u009c%H@\u008aqI»\u001f\f\u0017+ÇÁ»\u0091\b\u0014\u008e«: c\u001fþ\u009da\u009c\u00029òÂ\u009f>ÎéîÏ\"\u009b±wcÛG;\u009eëx#\u0004#*½(\u0002\u0083\u001dC\r\u0085z\u0098e÷)ÿZ Ð\u001a·'\u009fõBl·¡¦ÅtÌ«T¸\u0085ñ\u000f\u008a\fû£§¥(í\u0004å½ (váá_Yp\u0012\u000bwÅ\u000f\u007f\u001aG\u0016¬×ø4\u0090h{Ã\u0083ÆÎ_[\u009eMA\u0098¦  X\u0002z-n\u0094Òð\u0089¹©±\u0002\u0086k\u000bu4â`r/©´fn\u0014\u0088\u008dT\u007fa8&R\u0092\u008co\u0099ªLî\u008a¸Ø$ð4ÙoÍ4´1-`fKÍç\u001d\u009d=\u0095~¢ß\u0017+Nå\nµ\u001e}@¯\u0004r1Ò\u0098Ô\u009c+5¢\u0082T(\u0093uÎÙ}mÉ´\u008c\u0089\u009fa\u0093þ\u0001W\u0007ëÂ\u0013\u0012¤\u0087\u001a°| \u008da¡ú9Í\u00898=\\°ªe\u0010ßzìà¤)5e¶\u0094¸\tFÛ\u0005º Ñ7>Í\u00979á\u009a< \u0090,\u0089Ác\u008fâôù´\u008cf\u000fz9¨/¹ì'âõ Ë®= Ø\u0084^\u0083«#(\u0014\u001bkÍ\u000f\u000eÀì\u0084{idÂ\u001b>{\u000f\u0084ù\u0080¦\u0018÷w\u0019ß\u0080¾Z\u008f¸\u008fÍ°\u0003züÆxÜ\u0002¦£%µk Y2;vÚ'SDÝ¬\u009cy\u0095Æ\b\u007f¾Î\u0095)¿z¦\u0012®|þ5á\u0087\"wX¸\u009d\u008f¥JÅj?Sd8M*t\u0004t!ËÏ;\u009c°77XÇì]\u0012\u0093sL*A\u0088J]éÍ;½\u0092PØ@\u0014¤'\u009f\u0013FK¾-\u0000mwu°<\u0098J\u009f/f¶L»Q\u0006¯-*\tRÙ\u0018¼\u0093¨ ïÆ\u0015ùp¥\u0001\u0010ä\u008c¿Mìáª\u0089aEÜ\u0084\nn6Ã ´4iOÀ%\u0018\u0082bõû;-þÓÎF\"ï+¿N¤\u0098I\u0085\u001edØ8ìrHÃkÜ:¥\u0086~\u009a[~ÑÑRÝ>Ç2\u0093\u00139UÛö\u0093·'ßÌ3Á_àª\u007fuj¬\u0000G¿\u0089Ò\u0097ý Au\u0082_\b\u009fvBë\u009dçfëÃ áËÚÏ\u0007 `¯\u0089ÂÅ\u0098\u0018\u000f\u0099Á$Ç\u0090\u0005å¯ÒüPëK°l\u009d\føÑ\u0081\u0090Ýì\u0010r\u009fd´\u009fÓ¤$Sò\u000eÈÞ\u007f-- i\u0083V\u000e#\u001e\u0092\u0010\u00ad\u00ad4õùX¶\u0095ó,!|¤ò)\u0095Ñ\u0017n-]\u0094Åç(Âá\u0088ÇÂ\u0096Âì#;½j>LÞßÌ¥´ë,\u0096[\fw¤\u0007(Å\u0081\u0089\u0080}^÷\u000f»î§X\u0018ðÌ\u0097bt\b\u00956ò6â\u0096áÄðSÅÃ\u000fò\u0004ÓÅ\u008e\u0010!\u008fúU\u008bK¢Å\u001eÔO6i\u0088gð(²'\u0015\";\u0016ÿ'£ä\u009bbý\u0091\u0082r\u0099\u0089\t²L4¶\u0085[çHËL\u0006a\u001bÒ\u0091\u0082%£å¢ú\u0010?ôé_\u009b\u001aJÓ¶ð\u0085ð\u0081ªY½ \u0016þÂèu0\u0014\u0002åâ\u008c=È\u0019ï\u0014k\"0Âß\u0014ÑH\u0007=õîÚ1NÇ \u000e\u009fü\u009b»\u0094\u000f5\u000elzï¯ãùüq\u001dÝ\u0017\u008e\u0011½¸*¬ZDE\"2R\u0010uWðw0\u0094é`Ë¦\u0017RÞ\u008f²ë(å\u000eÁ´ÉóÛ\u0099Ùóÿ\u008e6ø\u000f;Ç4\u0085\u009f,h\r9Ý\u0011[Ñ\u0085Ý¿º}\rØë\u00adÅw \u0018X\u009b´6l¾æ\u000beê\u008b/¢\u0080\u0082¤º\u0091\u0012Óm$\u0015  eÐvÃ\u001cæû\u0007xÀT¬¯/e0\u009b5\f)úz\u008b\u008a)D!)\u0000÷\u0086`8t\u0089\rîTÖ\u0085MFà\u001e<\rï\n\u000f¡m\u000f\u0088á¶ü\u008d;¾\u008aÙ\u0012'<ÿE\u008a\u0081\u0092\u0087T§h\u0082u¶b\u008fÑ\u0098\u0098\u0089l^\u001aM\u009c_\u0089\u0018\u0090·ýVhÐî\u0088(â&l\u008f]å\u0004\u0090´\\\u0093TØ7~\u0010\u001a\u009b»(iÓ}©\u0096{U\u008bôcMy\u0010=Ø_\\\f\u0094Á\u00adS¯ªF·:\u0094½ T«3\u009fN-o\u000e¶»Ì\u0003²î7t\u0001!_ \u0081¡ØLv\u000e\u0003òâ\rGi \u008ds×\u008fµÉ#IcðKÁ`\u0004\\±ÇKûÁ£DICnÖÈà\rÝ«Ó\u0010;¯´\u0010)`¤mÝc×ÔáÔ\n\u008c \u0016)0BÊå©Ì\u001a}ÑÝýÌ\u001bU%·\u0019?m8>Ý\u001c£øÙ}¬P5\u0010\u008fSûu¬q\u001bé*\u0010\u0017\u0012`dÆf ¨·\u0097»\u000fõG\u001dþ\u009a*i\u0087>\u009elx\u00909[\u009bÑÓ\u009ey*Pòa\u0088ì\u0081(`\u0085i\u0006\u007f¿<ÉBæ\u009fBºUP»\u008376Ù`»ÜmÛ)/\"ñG^6²¼¶AÔ|ä\rX¼\u009f\u008eåðÈ÷´\u0093e\u000b>û\u001ctê§\u009bË\u009d\u0018\u0093Lx0®Ô\u001bÝ\u0017\u00ad\u008bê#\u0019ªD¦o¿$!ðÕ\u0011!þ\u0014ïÀ\u009b\fÿÉ.¶dä\u0096{Ï¾\bØ'ø\u0017ð\u0088;=K*v}=È\u0091\u0012õäëWò\tQ)>XáÞ\u0015\u0000æ9hP\u009cµ>½'Ê)¡\r*\u008d\u008a¡$!\u0091³\u0017¥\u008c\u0017Nö\u0091®VP9ÉÛü\u008e)¢&\u009e)\u0011cëª\u0014\u0002\u0002\u0094ÈÌ@Ü/\u008d\u008dBbÅ?ì\u001f\fd\u0017y\\N\u0080É_±\u0004e\u0002Jä`ºO\u009f fÕ@]\u001aÖÝâ¬Ç=µ+³Éæl>³`®\u000b{ÇQ&\u00109TP\u000b\u0086½PÔEª:óö\u001e\u0000 =e?¼²Ë ¢\u000b£\u000b\u000bù[ª¡\u0087@$¦|\u009e°\u001c\u0018ð\u0085%\u001d#½ð\u009a«®\u0082ô5»\u0087\u0086$gS`@rÀ¦8B«\u0018\u0000±\u008bñ\u0001m\u0084\u001dõú\u001aGX³|M£²²³Hø>hAmÃÛ\u001b\u0015\u0006;_\u0000\u0001¨x\u0099Qü\u0011\u0003û¤¿Ô\u001dî#_ï($\u0010\u0085N30c³ûR y\u008eùÖfiÄ`\u001dwÛ¨®\u0095ºqÐñÑ\u000b;ô\u0088\u0018q\u0098¢À\u000b*¢a-\"\u008f´~p.è\u001cß_üF¡Ê |&ÿ\\\u000eÖ)lªÊ&ï\u0080\u0082\u009bDqáû-/\u0006 §\u0010äX\u008aR]\u001f£D}S)MQ|\u00906\u0000Vñòg\t¯\b\u0016b\u007f\f¼\u0085°0 \u009e\u0086\u0089ÿ\"xDM\u0019\u0015gï)Úà\u0010\\áýöÀ\u0004\u0092ÿX½\f\t\u008eU\u0095xj?\u0017r\u0081u;±ÖÒ!»\u008bu\u0088(w\u009dñJ\u009c~oR\u000e\u0001wØ\u0085\u0012ÊK\u0019$\u0097+\u00ad\u009a:¨ó]ðF½[\u008fÎF\u008e¦\u008cµÖ¥ùX\u000f¯\"Tó³\"\r\u009c%ÖÒ\u0086\u0018°Ú.\u0002ý\u00ad\u0089sØ¿Z\u009b¥\u0090VB¢Vý\u0016\u0098\u0018¦'«I\u008eÆxâLy\b2\u0015»±\u0018u.ÄÐv¥\n\u001d\u0097ÛQ@°úÀÜÖ\u0082]c\u0017ñ\u0016~\u0017\u0081ÿ¨%þ\u0014\u001f\u001e\u0081á¼\u0010R6³ê\u0012\u008e©é\u0003W\u009f=LIa\u0097(\u001eÒ\u0016ïÿ\u009aÚýÇ\u0080\u0014\u009c\u00181\u009dÉtìy)Îx\u0084hv¸F}¼öÍbÛ\u000fûÆó%B½\u0010R\u0093\u0018í³íaFf9\u0006\u001fí|\u0086\u0092 IÇ\u009d\bï\u0013Q\u000f\b\u0088Ø\u0093«±[\u0015{S2\b\u0099 'ä$æ\u0085\u0014/Øs\u0095\u0010Õ\u0002õ>¬v\u0005Ò\u0004\u0019%E\u0016P*\u008a\u0010}·Á\u000f£\u0007|@)RIÿàÏ\u0011\u001c(\u001cJY\u0018=«\u0010O¤æã9QëC\u001cñ>ÏÎ[Ñ\u0013÷\u0084»\u0019¬¯Jõ\u0012äùË\u0091î+B\u0094\u0010@=ãÄH·S+\u008ct»¥ÔécåXm1MN\u0018\u001f¢IlÏ\u001d1\u0007MÜwkÜM\u0084\u001bw\u0080\u0015\u0084lÚ½ûî \u009e¤<=®}\u0014~Å2÷ø\u0004\u001f;\u0015\u001aµ\u009c\u0082;Ê¡\u0001\u00845Â1#\u009fy8/$hÖWw\u008e³B¢[\u0011\u00ad½õD³Øî\u000f:i%c\u00800~\u0000\u008eü§¾t\u009cNL\u001e»\u0091\u001d\u009e\u001b\u0083\u001fEÓåK¾Û«\u009egë\u001d×\u0007%\u0016ZD\u0004öÖ.·´<aKiyfr \u001bïtò\u0002\u008f!}ñ\fðJK\u0099(\u009cÒ\u0085\u0007è%Ýn4ºj@¼\u00112ÚÜ\u0010C\u000e\u009fõLBÚq\"\u0098Ïø\u009a6ÕA\u0018¹Ó\u008cGUÂü)-\u0000ª²®Ìþ\u0000EB¤^ÁÛUI\u0010@H.\u0012´@\u009a\u0086öØ³\u0085!+ÿv(\u008b\tÑ\u0097 ¬\u0010!W9\u0099~\u0017»rK\u0006ßå~x=ppp\u008a¿EØ\u0000\u008b\u0001¥Ú'%ûF\u000eó\u0010Ã\u0081\u008b^\\Û¦É\u009b1K¬¢íyì\u0010H\u009f«$¦\"\u008b£Én4mV\u0013;@\u0010ñ\u0019\u0094à\u008dÄX\u0002ª#fs\u0002-Ä8\u0010¯w\u008fÆÚV\u0018R¬ª£-\u008c\u001aº¹\u0010äÎ\u0013ß ²\u0093mã\u001d?£¢¯¦M\u0018 \u001aÎ\u0088\u0092n\u0098]\u0087A!Ô<Ð\u0019ããsg@\u009dÂ>M(À\u0017?þawu\u000e&O«1\u000fã¼Àá\u0001\u0087¤'\u000fû-5òµ\u009cØ½I\u0013ÑÍIGÖNB@8Gò\u009fsúÀ\u0091RK58_Ó\b\u009eÎn¨G$¾\u009btß¤\u0095#\u0095r\u0002z\u001c\u0015 }ÌøÈ\u0016¹O\u0089QPLM!aAæ Ç:Ü¥\b \u009eY©ã\u0084f\u0099\u0005\u001aßÑëX\u001dK@\u0011\u000eÆ\u0085\u0013N\u008a~«ÜÙ\u00adÿ\u0016¿\r @\u0088\u0007ªz\u0081iãÞ\u001bp5I\\÷Z|f{mùKÙf\u0000\u009aOú~\u0016/V8ü\u0090}^oy]µß½\nqþ¼QmÀ\u009dAÖD\u008dwå:\u0089z/\u0099«=\u009fb¸\u0083\u0003\u0019\u0001þ¡Î\u000f=S0Ã\u0091Ô¢g\u008dìù\u0096\u0095ê\u0010×ø\\\u0012\u000e\u000bòõ¥\u008b^\u000f`\u0014¨\u00930Ú6\u000e|¬Ã\u009fäÛ¹O#l/ÎqÔ\u001föC¸\u009d¶ë\u008f¸y\u009daàò»c \u0012E\u008f`\u0089\u0083üfbr\u0087f\bB ®\u0083m(§é\u008c\u00adÓkÄË\u0003òCw97À^ðzÈ´òñ]^Z\u0015á\f \u009b\u0006\u008bÐ\u001ax¡»(\"\r©ôC}B¼<\u0014\u008dÌ]\u000b\u0088\u009eN\u0080e\u0093m\u009a»\u0010\u009b\u008d¡F>\u0001¦>È<QwòÛ°Ä";
         short var30 = 4216;
         char var27 = '(';
         int var34 = -1;

         label73:
         while (true) {
            String var36 = var28.substring(++var34, var34 + var27);
            int var10001 = -1;

            while (true) {
               String var50 = a(var24.doFinal(var36.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var31[var29++] = var50;
                     if ((var34 += var27) >= var30) {
                        b = var31;
                        c = new String[115];
                        g = new HashMap(13);
                        Cipher var11;
                        Cipher var38 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                        var10002 = SecretKeyFactory.getInstance("DES");
                        var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                        for (int var12 = 1; var12 < 8; var12++) {
                           var10003[var12] = (byte)(135129801303917L << var12 * 8 >>> 56);
                        }

                        var38.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                        long[] var17 = new long[2];
                        int var14 = 0;
                        byte var13 = 0;

                        do {
                           var10001 = var13;
                           var13 += 8;
                           byte[] var18 = "\u0090\u00ad\u00174Ä\u0011RÄ\u0016\u0091HuËm\u0007ñ".substring(var10001, var13).getBytes("ISO-8859-1");
                           var10001 = var14++;
                           long var19 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var10004 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           byte var58 = -1;
                           var17[var10001] = var10004;
                        } while (var13 < 16);

                        e = var17;
                        f = new Integer[2];
                        j = new HashMap(13);
                        Cipher var0;
                        Cipher var39 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                        var10002 = SecretKeyFactory.getInstance("DES");
                        var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                        for (int var1 = 1; var1 < 8; var1++) {
                           var10003[var1] = (byte)(135129801303917L << var1 * 8 >>> 56);
                        }

                        var39.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                        long[] var6 = new long[5];
                        int var3 = 0;
                        String var4 = "wiþL\u008d¨ú\u001cÿÁ$\u000eHånU\u008e_\u0016\n~×O\u0014";
                        byte var5 = 24;
                        byte var2 = 0;

                        label44:
                        while (true) {
                           int var46 = var2;
                           var2 += 8;
                           byte[] var7 = var4.substring(var46, var2).getBytes("ISO-8859-1");
                           long[] var40 = var6;
                           var46 = var3++;
                           long var55 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           byte var60 = -1;

                           while (true) {
                              long var8 = var55;
                              byte[] var10 = var0.doFinal(
                                 new byte[]{
                                    (byte)(var8 >>> 56),
                                    (byte)(var8 >>> 48),
                                    (byte)(var8 >>> 40),
                                    (byte)(var8 >>> 32),
                                    (byte)(var8 >>> 24),
                                    (byte)(var8 >>> 16),
                                    (byte)(var8 >>> 8),
                                    (byte)var8
                                 }
                              );
                              long var63 = (var10[0] & 255L) << 56
                                 | (var10[1] & 255L) << 48
                                 | (var10[2] & 255L) << 40
                                 | (var10[3] & 255L) << 32
                                 | (var10[4] & 255L) << 24
                                 | (var10[5] & 255L) << 16
                                 | (var10[6] & 255L) << 8
                                 | var10[7] & 255L;
                              switch (var60) {
                                 case 0:
                                    var40[var46] = var63;
                                    if (var2 >= var5) {
                                       h = var6;
                                       i = new Long[5];
                                       return;
                                    }
                                    break;
                                 default:
                                    var40[var46] = var63;
                                    if (var2 < var5) {
                                       continue label44;
                                    }

                                    var4 = "B+(}\u008aþ÷AkÂLÍNil\u000e";
                                    var5 = 16;
                                    var2 = 0;
                              }

                              byte var48 = var2;
                              var2 += 8;
                              var7 = var4.substring(var48, var2).getBytes("ISO-8859-1");
                              var40 = var6;
                              var46 = var3++;
                              var55 = (var7[0] & 255L) << 56
                                 | (var7[1] & 255L) << 48
                                 | (var7[2] & 255L) << 40
                                 | (var7[3] & 255L) << 32
                                 | (var7[4] & 255L) << 24
                                 | (var7[5] & 255L) << 16
                                 | (var7[6] & 255L) << 8
                                 | var7[7] & 255L;
                              var60 = 0;
                           }
                        }
                     }

                     var27 = var28.charAt(var34);
                     break;
                  default:
                     var31[var29++] = var50;
                     if ((var34 += var27) < var30) {
                        var27 = var28.charAt(var34);
                        continue label73;
                     }

                     var28 = "gzá©ÁÌ%,\u0089\u0019{]ÆØc\bÝ\rùûÇèÓL\u0012Ëÿíõ\u0012yF\u0010MxB´ËcN.0ßYå+M\u0094V";
                     var30 = 49;
                     var27 = ' ';
                     var34 = -1;
               }

               var36 = var28.substring(++var34, var34 + var27);
               var10001 = 0;
            }
         }
      }

      private 树何何树何友树何何树<?> B(Module module, String settingName) {
         HUD.A();
         Iterator var6 = module.P().iterator();
         if (var6.hasNext()) {
            树何何树何友树何何树<?> value = (树何何树何友树何何树<?>)var6.next();
            if (value.r().equals(settingName)) {
               return value;
            }
         }

         return null;
      }

      private String C(树何何树何友树何何树<?> value) {
         StringBuilder json = new StringBuilder("{");
         HUD.A();
         json.append("\"name\":\"").append(value.r()).append("\",");
         if (value instanceof NumberValue numberValue) {
            json.append("\"type\":\"number\",");
            json.append("\"value\":").append(numberValue.getValue()).append(",");

            try {
               Object minValue = null;
               Object maxValue = null;
               Object incValue = null;

               try {
                  minValue = numberValue.getClass().getMethod("getMin").invoke(numberValue);
                  maxValue = numberValue.getClass().getMethod("getMax").invoke(numberValue);
                  incValue = numberValue.getClass().getMethod("getInc").invoke(numberValue);
               } catch (Exception var27) {
                  try {
                     minValue = numberValue.getClass().getMethod("getMinimum").invoke(numberValue);
                     maxValue = numberValue.getClass().getMethod("getMaximum").invoke(numberValue);
                     incValue = numberValue.getClass().getMethod("X").invoke(numberValue);
                  } catch (Exception var26) {
                     Field[] fields = numberValue.getClass().getDeclaredFields();
                     if (fields.length == 0) {
                        fields = numberValue.getClass().getSuperclass().getDeclaredFields();
                     }

                     int var18 = fields.length;
                     int var19 = 0;
                     if (0 < var18) {
                        Field field = fields[0];
                        field.setAccessible(true);
                        String fieldName = field.getName().toLowerCase();
                        if (fieldName.contains("min") && minValue == null) {
                           minValue = field.get(numberValue);
                        }

                        if (fieldName.contains("max") && maxValue == null) {
                           maxValue = field.get(numberValue);
                        }

                        if ((fieldName.contains("inc") || fieldName.contains("step")) && incValue == null) {
                           incValue = field.get(numberValue);
                        }

                        var19++;
                     }
                  }
               }

               json.append("\"min\":").append(minValue != null ? minValue : 0).append(",");
               json.append("\"max\":").append(maxValue != null ? maxValue : 100).append(",");
               json.append("\"step\":").append(incValue != null ? incValue : 1);
            } catch (Exception var28) {
               json.append("\"min\":0,");
               json.append("\"max\":100,");
               json.append("\"step\":1");
            }

            json.append("}");
         }

         if (value instanceof BooleanValue booleanValue) {
            json.append("\"type\":\"boolean\",");
            json.append("\"value\":").append(booleanValue.getValue());
            json.append("}");
         }

         if (value instanceof ModeValue modeValue) {
            json.append("\"type\":\"mode\",");

            try {
               String currentValue = modeValue.getValue();
               json.append("\"value\":\"").append(currentValue != null ? currentValue : "").append("\",");
               String[] modes = modeValue.n();
               json.append("\"options\":[");
               if (modes.length > 0) {
                  int i = 0;
                  if (0 < modes.length) {
                     json.append(",");
                     json.append("\"").append(modes[0]).append("\"");
                     i++;
                  }
               }

               json.append("]");
            } catch (Exception var25) {
               json.append("\"value\":\"unknown\",\"options\":[]");
            }

            json.append("}");
         }

         if (value instanceof 何何何友友何树何何何 textValue) {
            json.append("\"type\":\"text\",");

            try {
               String val = textValue.getValue();
               json.append("\"value\":\"").append(val != null ? val : "").append("\"");
            } catch (Exception var24) {
               json.append("\"value\":\"\"");
            }

            json.append("}");
         }

         if (value instanceof 树友何何树树何友友何 colorValue) {
            json.append("\"type\":\"color\",");

            try {
               Color color = colorValue.getValue();
               int red = color.getRed();
               int green = color.getGreen();
               int blue = color.getBlue();
               int alpha = color.getAlpha();
               if (alpha == 255) {
                  String.format("#%02X%02X%02X", red, green, blue);
               }

               String hexColor = String.format("#%02X%02X%02X%02X", alpha, red, green, blue);
               json.append("\"value\":\"").append(hexColor).append("\",");
               json.append("\"hex\":\"").append(hexColor).append("\",");
               json.append("\"rgb\":").append(color.getRGB() & 16777215).append(",");
               json.append("\"rgba\":").append(color.getRGB()).append(",");
               json.append("\"red\":").append(red).append(",");
               json.append("\"green\":").append(green).append(",");
               json.append("\"blue\":").append(blue).append(",");
               json.append("\"alpha\":").append(alpha);
               json.append("\"value\":\"#000000\",");
               json.append("\"hex\":\"#000000\",");
               json.append("\"rgb\":0,");
               json.append("\"rgba\":-16777216,");
               json.append("\"red\":0,");
               json.append("\"green\":0,");
               json.append("\"blue\":0,");
               json.append("\"alpha\":255");
            } catch (Exception var23) {
               json.append("\"value\":\"#000000\",");
               json.append("\"hex\":\"#000000\",");
               json.append("\"rgb\":0,");
               json.append("\"rgba\":-16777216,");
               json.append("\"red\":0,");
               json.append("\"green\":0,");
               json.append("\"blue\":0,");
               json.append("\"alpha\":255");
            }

            json.append("}");
         }

         json.append("\"type\":\"unknown\",");

         try {
            Object val = value.getValue();
            json.append("\"value\":\"").append(val != null ? String.valueOf(val) : "unknown").append("\"");
         } catch (Exception var22) {
            json.append("\"value\":\"unknown\"");
         }

         json.append("}");
         return json.toString();
      }

      private String F(String path, Map<String, String> queryParams, String requestBody) {
         HUD.A();
         byte var8 = -1;
         switch (path.hashCode()) {
            case -537362173:
               if (!path.equals("/api/modules")) {
                  break;
               }

               var8 = 0;
            case -509590952:
               if (!path.equals("/api/toggle")) {
                  break;
               }

               var8 = 1;
            case -1734438361:
               if (!path.equals("/api/settings")) {
                  break;
               }

               var8 = 2;
            case 1962120272:
               if (path.equals("/api/update-setting")) {
                  var8 = 3;
               }
         }

         switch (var8) {
            case 0:
               return this.Y();
            case 1: {
               String moduleName = queryParams.get("module");
               return this.R(moduleName);
            }
            case 2: {
               String moduleName = queryParams.get("module");
               return this.h(moduleName);
            }
            case 3:
               return this.b(requestBody);
            default:
               return "{\"status\":\"error\",\"message\":\"Unknown API endpoint\"}";
         }
      }

      private Map<String, String> S(String query) {
         HUD.A();
         HashMap params = new HashMap();
         if (query != null && !query.isEmpty()) {
            String[] var6 = query.split("&");
            int var7 = var6.length;
            int var8 = 0;
            if (0 < var7) {
               String pair = var6[0];
               String[] kv = pair.split("=");
               if (kv.length == 2) {
                  params.put(kv[0], kv[1]);
               }

               var8++;
            }

            return params;
         } else {
            return params;
         }
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static int b(int var0, long var1) {
         int var3 = var0 ^ (int)(var1 & 32767L) ^ 5552;
         if (f[var3] == null) {
            byte[] var4 = new byte[]{
               (byte)(var1 >>> 56),
               (byte)(var1 >>> 48),
               (byte)(var1 >>> 40),
               (byte)(var1 >>> 32),
               (byte)(var1 >>> 24),
               (byte)(var1 >>> 16),
               (byte)(var1 >>> 8),
               (byte)var1
            };
            long var5 = e[var3];
            byte[] var7 = new byte[]{
               (byte)(var5 >>> 56),
               (byte)(var5 >>> 48),
               (byte)(var5 >>> 40),
               (byte)(var5 >>> 32),
               (byte)(var5 >>> 24),
               (byte)(var5 >>> 16),
               (byte)(var5 >>> 8),
               (byte)var5
            };
            Long var8 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])g.get(var8);

            byte[] var10;
            try {
               Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               g.put(var8, var9);
               DESKeySpec var11 = new DESKeySpec(var4);
               SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
               Cipher var13 = (Cipher)var9[0];
               var13.init(2, var12, (IvParameterSpec)var9[2]);
               var10 = var13.doFinal(var7);
            } catch (Exception var14) {
               throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$友树友友何友树树树树", var14);
            }

            int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
            f[var3] = var15;
         }

         return f[var3];
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = k[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(l[var4]);
               k[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static CallSite b(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$友树友友何友树树树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
         int var4 = (Integer)var3[0];
         long var5 = (Long)var3[1];
         int var7 = b(var4, var5);
         MethodHandle var8 = MethodHandles.constant(int.class, var7);
         var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
         return var7;
      }

      private String b(String requestBody) {
         HUD.A();

         try {
            Map<String, String> params = this.p(requestBody);
            String moduleName = params.get("module");
            String settingName = params.get("setting");
            String valueStr = params.get("value");
            if (moduleName != null && settingName != null && valueStr != null) {
               this.t(moduleName);
               return "{\"status\":\"error\",\"message\":\"Module not found: " + moduleName + "\"}";
            } else {
               return "{\"status\":\"error\",\"message\":\"Missing required parameters\"}";
            }
         } catch (Exception var12) {
            return "{\"status\":\"error\",\"message\":\"Error updating setting: " + var12.getMessage() + "\"}";
         }
      }

      private static long c(int var0, long var1) {
         int var3 = var0 ^ (int)(var1 & 32767L) ^ 16129;
         if (i[var3] == null) {
            byte[] var4 = new byte[]{
               (byte)(var1 >>> 56),
               (byte)(var1 >>> 48),
               (byte)(var1 >>> 40),
               (byte)(var1 >>> 32),
               (byte)(var1 >>> 24),
               (byte)(var1 >>> 16),
               (byte)(var1 >>> 8),
               (byte)var1
            };
            long var5 = h[var3];
            byte[] var7 = new byte[]{
               (byte)(var5 >>> 56),
               (byte)(var5 >>> 48),
               (byte)(var5 >>> 40),
               (byte)(var5 >>> 32),
               (byte)(var5 >>> 24),
               (byte)(var5 >>> 16),
               (byte)(var5 >>> 8),
               (byte)var5
            };
            Long var8 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])j.get(var8);

            byte[] var10;
            try {
               Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var8, var9);
               DESKeySpec var11 = new DESKeySpec(var4);
               SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
               Cipher var13 = (Cipher)var9[0];
               var13.init(2, var12, (IvParameterSpec)var9[2]);
               var10 = var13.doFinal(var7);
            } catch (Exception var14) {
               throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$友树友友何友树树树树", var14);
            }

            long var15 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            i[var3] = var15;
         }

         return i[var3];
      }

      private static CallSite c(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$友树友友何友树树树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
         int var4 = (Integer)var3[0];
         long var5 = (Long)var3[1];
         long var7 = c(var4, var5);
         MethodHandle var9 = MethodHandles.constant(long.class, var7);
         var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
         return var7;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = k[var4];
         if (var5 instanceof String) {
            String var6 = l[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            k[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private String h(String moduleName) {
         HUD.A();
         if (moduleName == null) {
            return "{\"status\":\"error\",\"message\":\"Missing module parameter\"}";
         } else {
            for (Module m : Cherish.instance.getModuleManager().p()) {
               if (m.A().equalsIgnoreCase(moduleName)) {
                  break;
               }
            }

            return "{\"status\":\"error\",\"message\":\"Module not found: " + moduleName + "\"}";
         }
      }

      private static CallSite d(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$友树友友何友树树树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = l[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            k[var4] = var21;
            return var21;
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'b' && var8 != 197 && var8 != 'w' && var8 != 237) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 205) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 162) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'b') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 197) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'w') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static void a() {
         k[0] = "?oF5U60/\u000b>_+5r\u0000xW68t\u00043\u001401q\u0004x^0/q\u00047Cw\u0014T,";
         k[1] = "#;}%CNV\u001bv*R\u0001+\u0003e-[HC";
         k[2] = "2e[9K^=%\u00162AC8x\u001dtI^5~\u0019?\nX<{\u0019t@X\"{\u0019;]\u001f桀栚桤伏栵栠伄佞桤厑\u0000叺桀叀厾伏可栠桀栚桤";
         k[3] = "[<\u000b\u000342P3\u001aLN6C2\n\u0003x2T";
         k[4] = "8s\u0012.\u0012N3|\u0003as@8w\u0007;";
         k[5] = ";l1\u0000E\u0019no0mkhs\u007fkS_Slj5m";
         k[6] = "p1bOG-62b\u0018*%IjiH\u0012'09e\u0017\u0011Ls5m\u0011A5 92\u0012*";
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (l[var4] != null) {
            return var4;
         } else {
            Object var5 = k[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 22;
                  case 1 -> 33;
                  case 2 -> 8;
                  case 3 -> 3;
                  case 4 -> 51;
                  case 5 -> 28;
                  case 6 -> 0;
                  case 7 -> 14;
                  case 8 -> 6;
                  case 9 -> 39;
                  case 10 -> 44;
                  case 11 -> 37;
                  case 12 -> 50;
                  case 13 -> 58;
                  case 14 -> 54;
                  case 15 -> 25;
                  case 16 -> 2;
                  case 17 -> 42;
                  case 18 -> 53;
                  case 19 -> 26;
                  case 20 -> 38;
                  case 21 -> 27;
                  case 22 -> 55;
                  case 23 -> 13;
                  case 24 -> 59;
                  case 25 -> 61;
                  case 26 -> 1;
                  case 27 -> 21;
                  case 28 -> 5;
                  case 29 -> 10;
                  case 30 -> 34;
                  case 31 -> 52;
                  case 32 -> 20;
                  case 33 -> 16;
                  case 34 -> 36;
                  case 35 -> 41;
                  case 36 -> 63;
                  case 37 -> 19;
                  case 38 -> 31;
                  case 39 -> 30;
                  case 40 -> 17;
                  case 41 -> 15;
                  case 42 -> 23;
                  case 43 -> 43;
                  case 44 -> 45;
                  case 45 -> 62;
                  case 46 -> 12;
                  case 47 -> 57;
                  case 48 -> 35;
                  case 49 -> 7;
                  case 50 -> 49;
                  case 51 -> 56;
                  case 52 -> 11;
                  case 53 -> 4;
                  case 54 -> 18;
                  case 55 -> 40;
                  case 56 -> 32;
                  case 57 -> 24;
                  case 58 -> 9;
                  case 59 -> 46;
                  case 60 -> 29;
                  case 61 -> 48;
                  case 62 -> 60;
                  default -> 47;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               l[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Throwable a(Throwable var0) {
         return var0;
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static String a(int var0, long var1) {
         int var5 = var0 ^ (int)(var1 & 32767L) ^ 30525;
         if (c[var5] == null) {
            Object[] var4;
            try {
               Long var3 = Thread.currentThread().getId();
               Object[] var10000 = (Object[])d.get(var3);
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               d.put(var3, var4);
            } catch (Exception var10) {
               throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$友树友友何友树树树树", var10);
            }

            byte[] var6 = new byte[8];
            var6[0] = (byte)(var1 >>> 56);

            for (int var7 = 1; var7 < 8; var7++) {
               var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
            }

            DESKeySpec var11 = new DESKeySpec(var6);
            SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
            ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
            byte[] var9 = ((Object[])"[ñ©}îéù\u001d<pÉ\u007fi3w¸\u0094{\u0005m\u00143ßt\u0092, \u0004\u0000Ïæè&bTA\"ëtED\u0092Å\u0084\u0097\u0000\u001a\u0014Ù!w, ü\u008d\u0086v\u009d,eÀÞ¾\u001azÆùD!, }ãä\u0089\u0091Ð'\u0080Ë}")[var5]
               .getBytes("ISO-8859-1");
            c[var5] = a(((Cipher)var4[0]).doFinal(var9));
         }

         return c[var5];
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
         int var4 = (Integer)var3[0];
         long var5 = (Long)var3[1];
         String var7 = a(var4, var5);
         MethodHandle var8 = MethodHandles.constant(String.class, var7);
         var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
         return var7;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$友树友友何友树树树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private Map<String, String> p(String json) {
         HUD.A();
         HashMap result = new HashMap();
         if (json != null && !json.isEmpty()) {
            json = json.trim();
            if (json.startsWith("{")) {
               json = json.substring(1);
            }

            if (json.endsWith("}")) {
               json = json.substring(0, json.length() - 1);
            }

            String[] pairs = json.split(",");
            int var8 = pairs.length;
            int var9 = 0;
            if (0 < var8) {
               String pair = pairs[0];
               String[] keyValue = pair.split(":");
               if (keyValue.length == 2) {
                  String key = keyValue[0].trim();
                  String value = keyValue[1].trim();
                  if (key.startsWith("\"") && key.endsWith("\"")) {
                     key = key.substring(1, key.length() - 1);
                  }

                  if (value.startsWith("\"") && value.endsWith("\"")) {
                     value = value.substring(1, value.length() - 1);
                  }

                  result.put(key, value);
               }

               var9++;
            }

            return result;
         } else {
            return result;
         }
      }

      private Module t(String moduleName) {
         HUD.A();
         Iterator var5 = Cherish.instance.getModuleManager().p().iterator();
         if (var5.hasNext()) {
            Module m = (Module)var5.next();
            if (m.A().equalsIgnoreCase(moduleName)) {
               return m;
            }
         }

         return null;
      }

      @Override
      public void handle(HttpExchange exchange) throws IOException {
         HUD.A();
         exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
         exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET");
         exchange.getResponseHeaders().add("POST", "OPTIONS");
         if (exchange.getRequestMethod().equalsIgnoreCase("Access-Control-Allow-Headers")) {
            exchange.sendResponseHeaders(204, -1L);
         } else {
            try {
               String path = exchange.getRequestURI().getPath();
               String query = exchange.getRequestURI().getQuery();
               Map<String, String> queryParams = this.S(query);
               String requestBody = "";
               if ("Content-Type".equalsIgnoreCase(exchange.getRequestMethod())) {
                  InputStream is = exchange.getRequestBody();
                  requestBody = new String(is.readAllBytes(), StandardCharsets.UTF_8);
               }

               String response = this.F(path, queryParams, requestBody);
               exchange.getResponseHeaders().set("Authorization", "OPTIONS");
               byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
               exchange.sendResponseHeaders(200, responseBytes.length);
               OutputStream os = exchange.getResponseBody();
               os.write(responseBytes);
               os.close();
            } catch (Exception var12) {
               String error = "Content-Type" + var12.getMessage().replace("\"", "POST") + "application/json";
               exchange.getResponseHeaders().set("\\\"", "{\"status\":\"error\",\"message\":\"");
               exchange.sendResponseHeaders(500, error.getBytes().length);
               OutputStream os = exchange.getResponseBody();
               os.write(error.getBytes());
               os.close();
            }
         }
      }

      private String Y() {
         StringBuilder json = new StringBuilder("{\"status\":\"success\",\"modules\":[");
         HUD.A();
         树何友友何树友友何何[] var6 = 树何友友何树友友何何.M();
         int var7 = var6.length;
         int var8 = 0;
         if (0 < var7) {
            树何友友何树友友何何 category = var6[0];
            Iterator var10 = Cherish.instance.getModuleManager().Z(category).iterator();
            if (var10.hasNext()) {
               Module module = (Module)var10.next();
               json.append("{");
               json.append("\"name\":\"").append(module.A()).append("\",");
               json.append("\"cnName\":\"").append(module.B()).append("\",");
               json.append("\"category\":\"").append(module.Z().name()).append("\",");
               json.append("\"enabled\":\"").append(module.isEnabled()).append("\",");
               json.append("\"hasSettings\":").append(!module.P().isEmpty()).append(",");
               json.append("\"key\":").append(module.r());
               json.append("}");
            }

            var8++;
         }

         json.append("]}");
         return json.toString();
      }

      private void P(HttpExchange exchange, int code, String message) throws IOException {
         HUD.A();
         exchange.getResponseHeaders().set("Content-Type", "text/plain");
         byte[] responseBytes = message.getBytes(StandardCharsets.UTF_8);
         exchange.sendResponseHeaders(code, responseBytes.length);

         try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
         }
      }

      private void H(树何何树何友树何何树<?> value, String valueStr) throws Exception {
         HUD.A();
         if (value instanceof NumberValue numberValue) {
            try {
               double numValue = Double.parseDouble(valueStr);
               numberValue.S(numValue);
            } catch (NumberFormatException var23) {
               throw new Exception("Invalid number format: " + valueStr);
            }
         } else {
            if (value instanceof BooleanValue booleanValue) {
               booleanValue.G(Boolean.parseBoolean(valueStr));
            }

            if (value instanceof ModeValue modeValue) {
               String[] availableValues = modeValue.n();
               boolean isValidValue = false;
               int i = availableValues.length;
               int alpha = 0;
               if (0 < i) {
                  String availableValue = availableValues[0];
                  if (availableValue.equals(valueStr)) {
                     isValidValue = true;
                  }

                  alpha++;
               }

               if (!isValidValue) {
                  StringBuilder optionsStr = new StringBuilder();
                  i = 0;
                  if (0 < availableValues.length) {
                     optionsStr.append("");
                     optionsStr.append(availableValues[0]);
                     i++;
                  }

                  throw new Exception("" + optionsStr);
               }

               modeValue.G(valueStr);
            }

            if (value instanceof 何何何友友何树何何何 textValue) {
               textValue.G(valueStr);
            }

            if (value instanceof 树友何何树树何友友何) {
               try {
                  if (valueStr.startsWith("#")) {
                     String hexValue = valueStr.substring(1);
                     if (hexValue.length() == 6) {
                        int rgb = Integer.parseInt(hexValue, 16);
                        new Color(rgb | 0xFF000000, true);
                     }

                     if (hexValue.length() == 8) {
                        long argb = Long.parseLong(hexValue, 16);
                        int alphax = (int)(argb >> 24 & 255L);
                        int red = (int)(argb >> 16 & 255L);
                        int green = (int)(argb >> 8 & 255L);
                        int blue = (int)(argb & 255L);
                        new Color(red, green, blue, alphax);
                     }

                     throw new Exception("Invalid mode value. Available options: ");
                  }

                  try {
                     long rgb = Long.parseLong(valueStr);
                     if (rgb >= -2147483648L && rgb <= 2147483647L) {
                        new Color((int)rgb, true);
                     }

                     throw new Exception("Invalid hex color format. Use #RRGGBB or #AARRGGBB");
                  } catch (NumberFormatException var19) {
                     throw new Exception("Color value out of range" + valueStr);
                  }
               } catch (Exception var20) {
                  throw new Exception("Invalid color format: " + valueStr + "Invalid color format: " + var20.getMessage());
               }
            }

            try {
               value.getClass().getMethod("G", Object.class).invoke(value, valueStr);
            } catch (Exception var22) {
               try {
                  Field valueField = value.getClass().getDeclaredField(" - ");
                  valueField.setAccessible(true);
                  valueField.set(value, valueStr);
               } catch (Exception var21) {
                  throw new Exception("友树树树树树树何何树" + value.getClass().getSimpleName());
               }
            }
         }
      }

      private String R(String moduleName) {
         HUD.A();
         if (moduleName == null) {
            return "{\"status\":\"error\",\"message\":\"Missing module parameter\"}";
         } else {
            Module module = null;

            for (Module m : Cherish.instance.getModuleManager().p()) {
               if (m.A().equalsIgnoreCase(moduleName)) {
                  module = m;
                  break;
               }
            }

            if (module != null) {
               module.n();
               return "{\"status\":\"success\",\"module\":\"" + moduleName + "\",\"enabled\":" + module.isEnabled() + "}";
            } else {
               return "{\"status\":\"error\",\"message\":\"Module not found: " + moduleName + "\"}";
            }
         }
      }

      private static String HE_WEI_LIN() {
         return "解放村多种2队1144号";
      }
   }

   private static class 树树何友树树友友树树 implements HttpHandler, 何树友 {
      private static final long a;
      private static final String[] b;
      private static final String[] c;
      private static final Map d = new HashMap(13);
      private static final long e;
      private static final Object[] f = new Object[10];
      private static final String[] g = new String[10];
      private static int _行走的50万——何炜霖 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-5047868479145969732L, 2975057538812829826L, MethodHandles.lookup().lookupClass()).a(49762405631140L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var7;
         Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var8 = 1; var8 < 8; var8++) {
            var10003[var8] = (byte)(126414039403328L << var8 * 8 >>> 56);
         }

         var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var14 = new String[31];
         int var12 = 0;
         String var11 = "¤Å\u0002-Ý\u000b\fýí\u0003ÐJP\u0002e\u0091y\tâD\u008c\\I´>?\u0010ø\u0013\u0007ù\u0088\u0010+±9Ò:\u0011ê\u0086÷\u0081c¹<¦\u0002ò \u009bmA579xã\\¨übR#\u008bTÝõ\u009e¦\u008c¤ªÜ\u0007ëÉå³\n±Ù\u0010g\u001155²\u0099¦\u0002 \u0091Yv\bu_x(Ú\u001cAÝ`\u0003ïæØÆ,£)Æ\u008cÕ\u00109\u008c´D·5_`ø\u000f\u008ft\"8«)\u0002H*\u0097\u001c\u0014Y ¦÷ó\u0006³Ö=b·Ò\u0093@\u008cç\u008aÏdh~=ä\t\u0094_Ê5/È0\u009bË2\u0018kCQÊ\\îî\t¾\u0001òéª²õ×\u0095\u0015\u009chsç\u0084¼\u0010\u0084ð]ý%df¡eÒ\\\u009f\u001f:ðH\u0018f\rð\u0014Fá½áøèT»\u001b=ï\u0084¿¬Fè·î[ \u0010\u0085C8\u0083Ï\u0019Õ¤ó\u0006é'g\n,ò(\u009fh/d\\o\u0094a/R\u0087â<Ç\u0090Ï\u0090iW\u0084Ç\u0091¹¶\u0092ÖæþÝ\u008c\u0016Õxâ8ÇSÚG\u0010\u0010°½üÉ\u0000\u0084©Ñ\u0089>\u008e9\r\u0086ë50-z\u009f\u001fÅ\u001fC\u0002^\u0091Û¥\u0013/#ËÓª\u008a\u001aL\u0086\u001bÍ\u0098\u009c´7 Ò©¢XV½94Ô&±©i³LØ~[L\u0010(\u001dD6^.«²\u009f¯\u008bè[fy\u00920\u0097íA´\u0080Á:Í\u000fÙ\u008f\"\u0095G©í\u008f\u0094\fæ`ÿ\u001b\u0014¸\u0099}z\u0012¢í\u0012HM \u009cØFr®¹Â?ge¬ä¤(>ð:EÑÇ\u0005è82¸\u001eQ¢\u000e\u0094Æõõ-ö¥v½Fó3øfÊÆâ54,\u0017g\u007f\r\u008f\u0010.¼%\u0006á\u0084fþZ\u007f)Ù]\u0081QÔ0\u000e9á\u000el¢C\u000e\u00985\u008dÑhdÛÖÂÊú àoÉ¾\u000fä\u008b7tl·åÝ\u0000åg>áñÌáAÌ¤\rªjV vØ`\u009d\u0089\u001a³\u0093\fDÏ#\u0015!\báÀºá¦\u008c\u0085±80üÇ±\u0096í¿Ê8&ÔÝ¨:\u001cï\u008c\u000fà\u0090yoX@¬ÖeM>âydÈ2%\u009d\u001e\u009c¢¨Üd\u0000¸\u0080Û¢\u0011Í?Ã\u009d3Øýq{\u0096Lêõ\u0010~\u001c\u009e0s,\np×(,\u0001!Ú&Ù¤\u0086\u00adx\u001a ±*\u001b¶ËÎ®£Ì,¤\u009b\u0089¨ßåí«¶\b\u008d+8º°\u001d\u009eÝé\u001d gÅ&µ6\u0082\u0088¢\u0005\u0010\u0010Frn-\u00917¼ýnq\u008f\u0011ºB\u0001\u008fi÷÷\u0090\u0016(\u0012\u00039©°\u0084t\u009bÔ+<v\u0089¬YíäÚg~ÝúãÎ¯Tv³ \u0089aµkJTØøTl\u0080\u0010Ô¶\u008cÓd1¦@ømn¿äC\u0019z\u0010wÊô÷oÑ¾w \u00153[ É\u0014\u0088\u0018\u0094½ùc,Hf¡H£ØI\u0097*©î}\u008f\u0096GAÕ2ë\u0010\u0090\u008e8HkÍ\u0019\u0080Ië¼\u0017d\u009fYz\u0010\u0001_\u0011K\u0096[Dhäq£\u0080\"Ç\u0098q Ðß\u0018Ú\u008a×\\Ç 5>|w\u008fÈêlní\u0001uiH\b¹\u008ei¶)q|¨";
         short var13 = 876;
         char var10 = ' ';
         int var16 = -1;

         label37:
         while (true) {
            String var18 = var11.substring(++var16, var16 + var10);
            byte var10001 = -1;

            while (true) {
               String var26 = a(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var14[var12++] = var26;
                     if ((var16 += var10) >= var13) {
                        b = var14;
                        c = new String[31];
                        Cipher var0;
                        Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                        var10002 = SecretKeyFactory.getInstance("DES");
                        var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                        for (int var1 = 1; var1 < 8; var1++) {
                           var10003[var1] = (byte)(126414039403328L << var1 * 8 >>> 56);
                        }

                        var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                        byte[] var4 = var0.doFinal(new byte[]{-33, 102, 44, 50, 58, -79, 8, -22});
                        long var30 = (var4[0] & 255L) << 56
                           | (var4[1] & 255L) << 48
                           | (var4[2] & 255L) << 40
                           | (var4[3] & 255L) << 32
                           | (var4[4] & 255L) << 24
                           | (var4[5] & 255L) << 16
                           | (var4[6] & 255L) << 8
                           | var4[7] & 255L;
                        var10001 = -1;
                        e = var30;
                        return;
                     }

                     var10 = var11.charAt(var16);
                     break;
                  default:
                     var14[var12++] = var26;
                     if ((var16 += var10) < var13) {
                        var10 = var11.charAt(var16);
                        continue label37;
                     }

                     var11 = "Ê\u0001\u009d\u009cu|Âïd\u0092\u0014f-(S\fä\u0093fØ³Üüd(c\u0092gè\u0097Cæ\u0017WÛI ]E×Aåë<(\tSzU\u0098Ë\u0000!FK\u0089CVæ¼\u0085S\u0084»\"";
                     var13 = 65;
                     var10 = 24;
                     var16 = -1;
               }

               var18 = var11.substring(++var16, var16 + var10);
               var10001 = 0;
            }
         }
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = f[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(g[var4]);
               f[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static CallSite b(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$树树何友树树友友树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = f[var4];
         if (var5 instanceof String) {
            String var6 = g[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            f[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = g[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            f[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 208 && var8 != 'w' && var8 != 'r' && var8 != 239) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'C') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 229) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 208) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'w') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'r') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
         int var4 = (Integer)var3[0];
         long var5 = (Long)var3[1];
         String var7 = a(var4, var5);
         MethodHandle var8 = MethodHandles.constant(String.class, var7);
         var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
         return var7;
      }

      private static String a(int var0, long var1) {
         int var5 = var0 ^ (int)(var1 & 32767L) ^ 26954;
         if (c[var5] == null) {
            Object[] var4;
            try {
               Long var3 = Thread.currentThread().getId();
               Object[] var10000 = (Object[])d.get(var3);
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               d.put(var3, var4);
            } catch (Exception var10) {
               throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$树树何友树树友友树树", var10);
            }

            byte[] var6 = new byte[8];
            var6[0] = (byte)(var1 >>> 56);

            for (int var7 = 1; var7 < 8; var7++) {
               var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
            }

            DESKeySpec var11 = new DESKeySpec(var6);
            SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
            ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
            byte[] var9 = ((Object[])"[ö«Á\u0084ó\u009e°£ò\u0084\u0097ß24ÐO, Sâ Ks\u0082\u000bF, \u008dïûb\u0013Ë\u0081T\bû\u008f\u0006\u0091[VM, Spø-\u0094ý\t*, yñ(1éñ\u0080êb2\u0006¬")[var5]
               .getBytes("ISO-8859-1");
            c[var5] = a(((Cipher)var4[0]).doFinal(var9));
         }

         return c[var5];
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static Throwable a(Throwable var0) {
         return var0;
      }

      private static void a() {
         f[0] = "<gR,Z\\3'\u001f'PA6z\u0014a@G6e\u000faGV,f\t=VV,'.*F\\*{\u001f*F~>g\u001d(PA";
         f[1] = "Z\u0014\u001d\u0018aO_[-\u0010#C";
         f[2] = "\u001e\u0005\u0002\u001d=I\u0011EO\u00167T\u0014\u0018DP?I\u0019\u001e@\u001b|O\u0010\u001b@P6O\u000e\u001b@\u001f+\b5>h";
         f[3] = "%\u0006ssX\u001bP&x|IT->k{@\u001dE";
         f[4] = "\t'\u001cTA\u0005\u0006gQ_K\u0018\u0003:Z\u0019C\u0005\u000e<^R\u0000\u0003\u00079^\u0019J\u0003\u00199^VWD桻桘栣佢栿桻伿伜栣叼\n桻桻伜叹栦栿厡厡桘栣";
         f[5] = "]\u000fYy\u001a\u001aV\u0000H6`\u001eE\u0001XyV\u001aR";
         f[6] = "x;?Jv\u0018s4.\u0005\u0017\u0016x?*_";
         f[7] = "h#|7\u0018:ja$<i\u0013Qe{|\f1<&$m\u0000Z";
         f[8] = "SBTl7B\u001dJ_\u00114S\u0016IYk%S\u0016._csX\u0002NO~w";
         f[9] = "\u0005\u001dJXd\\@\u000bC@\u0016^?VJA{]\u0005\u0016]Oq7\u0004\u0016QL|\rD\u0001_F\u0016";
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (g[var4] != null) {
            return var4;
         } else {
            Object var5 = f[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 44;
                  case 1 -> 38;
                  case 2 -> 11;
                  case 3 -> 4;
                  case 4 -> 45;
                  case 5 -> 59;
                  case 6 -> 22;
                  case 7 -> 55;
                  case 8 -> 58;
                  case 9 -> 13;
                  case 10 -> 21;
                  case 11 -> 50;
                  case 12 -> 41;
                  case 13 -> 10;
                  case 14 -> 48;
                  case 15 -> 53;
                  case 16 -> 36;
                  case 17 -> 16;
                  case 18 -> 27;
                  case 19 -> 18;
                  case 20 -> 9;
                  case 21 -> 40;
                  case 22 -> 46;
                  case 23 -> 14;
                  case 24 -> 51;
                  case 25 -> 37;
                  case 26 -> 60;
                  case 27 -> 25;
                  case 28 -> 35;
                  case 29 -> 30;
                  case 30 -> 15;
                  case 31 -> 6;
                  case 32 -> 54;
                  case 33 -> 56;
                  case 34 -> 3;
                  case 35 -> 28;
                  case 36 -> 47;
                  case 37 -> 7;
                  case 38 -> 62;
                  case 39 -> 57;
                  case 40 -> 33;
                  case 41 -> 2;
                  case 42 -> 49;
                  case 43 -> 20;
                  case 44 -> 52;
                  case 45 -> 32;
                  case 46 -> 31;
                  case 47 -> 1;
                  case 48 -> 17;
                  case 49 -> 29;
                  case 50 -> 23;
                  case 51 -> 42;
                  case 52 -> 0;
                  case 53 -> 43;
                  case 54 -> 34;
                  case 55 -> 26;
                  case 56 -> 8;
                  case 57 -> 19;
                  case 58 -> 39;
                  case 59 -> 12;
                  case 60 -> 5;
                  case 61 -> 61;
                  case 62 -> 24;
                  default -> 63;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               g[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树树树何树树何何树友$树树何友树树友友树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      @Override
      public void handle(HttpExchange exchange) throws IOException {
         HUD.A();
         exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
         exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET");
         exchange.getResponseHeaders().add("POST", "OPTIONS");
         if (exchange.getRequestMethod().equalsIgnoreCase("Access-Control-Allow-Headers")) {
            exchange.sendResponseHeaders(204, -1L);
         } else {
            String path = exchange.getRequestURI().getPath();
            if (path.equals("/")) {
               path = "Content-Type";
            }

            String fileName = path.substring(1);
            if (fileName.contains("Authorization")) {
               this.O(exchange, 403, "OPTIONS");
            } else {
               try {
                  File file = new File(Cherish.getResourcesManager().resources.getAbsolutePath() + "/ui.html" + fileName);
                  if (!file.exists()) {
                     this.O(exchange, 404, ".." + fileName);
                     return;
                  }

                  String mimeType = this.X(fileName);
                  exchange.getResponseHeaders().set("访问被拒绝", mimeType);
                  exchange.sendResponseHeaders(200, file.length());

                  try (
                     FileInputStream fis = new FileInputStream(file);
                     OutputStream os = exchange.getResponseBody();
                  ) {
                     byte[] buffer = new byte[4096];
                     int count;
                     if ((count = fis.read(buffer)) != -1) {
                        os.write(buffer, 0, count);
                     }
                  }
               } catch (IOException var17) {
                  this.O(exchange, 500, "\\webui\\" + var17.getMessage());
               }
            }
         }
      }

      private String X(String fileName) {
         HUD.A();
         if (fileName.endsWith(".html")) {
            return "text/html";
         } else if (fileName.endsWith(".css")) {
            return "text/css";
         } else if (fileName.endsWith(".js")) {
            return "application/javascript";
         } else if (fileName.endsWith(".json")) {
            return "application/json";
         } else if (fileName.endsWith(".png")) {
            return "image/png";
         } else if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) {
            return "image/jpeg";
         } else {
            return fileName.endsWith(".svg") ? "image/svg+xml" : "application/octet-stream";
         }
      }

      private static String HE_SHU_YOU() {
         return "何树友为什么濒天了";
      }

      private void O(HttpExchange exchange, int code, String message) throws IOException {
         HUD.A();
         exchange.getResponseHeaders().set("Content-Type", "text/plain");
         byte[] responseBytes = "OPTIONS".getBytes(StandardCharsets.UTF_8);
         exchange.sendResponseHeaders(code, responseBytes.length);

         try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
         }
      }
   }
}
