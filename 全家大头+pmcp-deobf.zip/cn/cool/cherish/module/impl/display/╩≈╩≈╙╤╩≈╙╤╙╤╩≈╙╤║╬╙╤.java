package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import cn.cool.cherish.ui.友何友何何何友树友树;
import cn.cool.cherish.ui.友友树何树树何树树树;
import cn.cool.cherish.ui.友树何树友友何何友树;
import cn.cool.cherish.ui.树何何何树树树何友何;
import cn.cool.cherish.ui.树何树友树何何友何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.animations.何何友树友树友树树何;
import cn.cool.cherish.utils.animations.友何友树树树树何树友;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.LivingEntity;

public class 树树友树友友树友何友 extends 树树友树友友何友友树 implements 何树友 {
   private final ModeValue 友友友何树何树何何友;
   private final 友何友树树树树何树友 友友树树何友何何友何;
   public static final 树友树友友何何树何何 友何友友树友何友何树;
   private static LivingEntity 何友何何树友树何友友;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final long n;
   private static final Object[] o = new Object[28];
   private static final String[] p = new String[28];
   private static String HE_JIAN_GUO;

   public 树树友树友友树友何友() {
      long a = c ^ 16379313644947L;
      long ax = a ^ 6431861178765L;
      super(c<"r">(2850, 2929447958417184209L ^ a), c<"r">(7786, 5446597458590105747L ^ a), 100.0F, 40.0F);
      this.友友友何树何树何何友 = new ModeValue(
         c<"r">(6076, 3687944611312240961L ^ a),
         c<"r">(7418, 9184466966583050766L ^ a),
         new String[]{
            c<"r">(29042, 7177601468244356996L ^ a),
            c<"r">(3635, 8970609767943442639L ^ a),
            c<"r">(4992, 4186153575373540727L ^ a),
            c<"r">(17108, 6609883327592881190L ^ a),
            c<"r">(31059, 4023498146852693928L ^ a)
         },
         c<"r">(438, 8578028274575023948L ^ a)
      );
      this.友友树树何友何何友何 = new 何何友树友树友树树何(150, 1.0, ax, 1.0F);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-6776440257333528081L, -6280787399408607890L, MethodHandles.lookup().lookupClass()).a(234429207681550L);
      // $VF: monitorexit
      c = var10000;
      long var14 = c ^ 94194353872466L;
      long var16 = var14 ^ 69360931267789L;
      c();
      Cipher var5;
      Cipher var20 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(var14 << var6 * 8 >>> 56);
      }

      var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[14];
      int var10 = 0;
      String var9 = "\u008e\u001d\u00101w6D\u0010\u0015\u008aå\u0002»íf\u009c\u0010æÙ¡\u0081qÂ÷aÊYjhM=\u0094Ë\u0010\u0083Ö·&RÚÄÌ8PêgÐÊ[, m\u008b\u0004í«¥¥Ü§2\u0010^×Äy×ô¶\u008b¤io\u009e\u009d\u001d\u000eïÓt7³2\u0010W\tî\u0001\u00891÷\u0090VûÀÍ©n¤\u000f\u0010?[»\u008ff\u0099ôXÝg\u0083\u0003\u0011\u009bÃ\u0013\u0010 \u0018\u007f}üra\u009d(\u009eæ?\u008f»\u008a\u0002 \rp\u0083L\u0087\u0014h\nÓ{Ê\u0085\u009d}\u0090\u0002á\u0090\u0081\u00997H>Ýc°Ë{ÈãÞ*\u0018ÁelMun@¯\u0013e:?Ì\u0015tÌC\u008a´±ýÂÐi\u0010ÁG\u0084¸¹\u00838W\fÚ\u0082W\\h\u0095x\u0018\"A\u0014!Ó\u0016àõàXiâµBj\f\u0094\u001b\fk\u0099wÓü ¼Æy\u0089Pð\u0005°!K\u0097\u001a\u0080èÉ(\u0010-\u009eÔ_´\u0081\u0089N@\u0083{&mðµ";
      short var11 = 267;
      char var8 = 16;
      int var19 = -1;

      label37:
      while (true) {
         String var21 = var9.substring(++var19, var19 + var8);
         byte var10001 = -1;

         while (true) {
            String var29 = d(var5.doFinal(var21.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var12[var10++] = var29;
                  if ((var19 += var8) >= var11) {
                     k = var12;
                     l = new String[14];
                     Cipher var0;
                     Cipher var23 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var14 << var1 * 8 >>> 56);
                     }

                     var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-38, -96, 119, -109, -92, 3, -5, 60});
                     long var33 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     n = var33;
                     友何友友树友何友何树 = new 树友树友友何何树何何(var16);
                     return;
                  }

                  var8 = var9.charAt(var19);
                  break;
               default:
                  var12[var10++] = var29;
                  if ((var19 += var8) < var11) {
                     var8 = var9.charAt(var19);
                     continue label37;
                  }

                  var9 = "«ÿ´%oq°rIû\u0090\u0089¬!K\u0096 \u0090J¡+Ñyö\u0015>¿,\u0004\u000fãÎéõò\u000bµìIú¹=8ª\u008baÂ\u0001¹";
                  var11 = 49;
                  var8 = 16;
                  var19 = -1;
            }

            var21 = var9.substring(++var19, var19 + var8);
            var10001 = 0;
         }
      }
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27253;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树树友树友友树友何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = k[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树树友树友友树友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void c() {
      o[0] = "%;jnj7*{'e`*/&,#h7\" (h+1+%(#a15%(l|v桗桄厏栜収厓桗厞休叆";
      o[1] = "oKmYv\b`\u000b R|\u0015eV+\u0014l\u0013eI0\u0014栈厬栝叮厈佯佌桶余佰";
      o[2] = "E2\u0010>\u0000pE2\u0007b\f\u007f_y\u0013\u007f\u001fuOy\u0001~\u0019p_.J\\\u0004oB9\u0003U\u0003mB#\u001d";
      o[3] = "%c\u000b%\u0000\u0012*#F.\n\u000f/~Mh\u001a\t/aVh\u000e\u0013/`D2\u0006\u0012(~\u000b厍伺厶桗栜栴厍桾伨厍";
      o[4] = "{\u0005\u0011M\u007f/tE\\Fu2q\u0018W\u0000}/|\u001eSK>桑栉厠栮句叛伕叓厠栮";
      o[5] = float.class;
      p[5] = "java/lang/Float";
      o[6] = "\u0012g-'[F\u0019h<h'_\u0016r2+\u0010o\u0000e>6\u0001C\u0017h";
      o[7] = "iqS\u001bwHf1\u001e\u0010}Ucl\u0015VuHnj\u0011\u001d6Ngo\u0011V{Hg}\u001c\f6lcs\u00119mUk";
      o[8] = "VY\u0002b\njY\u0019Oi\u0000w\\DD/\u0013dYBI/\fhE[\u0002L\naPaMm\u0010`";
      o[9] = "\fYBk\u0014\u0002\u0003\u0019\u000f`\u001e\u001f\u0006D\u0004&\u000e\u0019\u0006[\u001f&\u001a\u0003\u0006Z\r|\u0012\u0002\u0001DB參伮厦桾栦桽栙伮桼厤";
      o[10] = "\u0014\u0019d\u0019p1\u0014\u0019sE|>\u000eRs[t=\u0014\b>zt6\u001f\u001fbV{,";
      o[11] = "x2}5N-x2jiB\"byjwJ!x#'|V-8$jiF!x$'H@6s2g";
      o[12] = "+o`\b\r\f$/-\u0003\u0007\u0011!r&E\u000f\f,t\"\u000eL\n%q\"E\u0006\n;q\"\n\u001bM\u0000T\n";
      o[13] = "Xq";
      o[14] = "J4`O8OA;q\u0000YAJ0uZ";
      o[15] = "\f\u001cT\u0001tX\u0010\u0001\b|伕叫伶伽栩县桑併厨厣0E/\u0012\u0015\u001c\b\u0011%\u0015\u0016";
      o[16] = "-\u0000m\u0003`;x\u0007s\u0011\u0003佗栎栦佞桤叀叉佊叼佞}95yA`Ll2gS";
      o[17] = "PQ*E!\r\t\u0011~J_佭伷召桙栲框佭厩召厃+c\u000bS\u0010{U-\u000e\u0010\u001e";
      o[18] = "u\u0000Vl9Ri\u001d\n\u0011o\".\u0004Mui^i\u0018U)\u0005\u001ej\u0003V}yYv\u001b\n\u0011";
      o[19] = "Bx\u001e~lW\u001b8Jq\u0012桳去叅厷栉栋桳桡栟伩\u0010.QA9On`T\u00027";
      o[20] = "^owM\u000f~S?aHe{\u0005uaB\u0003q\u000e\u000e J\u000f|\tj-\u001a\u0019y";
      o[21] = "M\"SCzEQ?\u000f>厅叶叩伃栮佣桟佨佷厝7\u0003=\rRgXD ZL";
      o[22] = "\u001b\u001eo$l3\u0007\u00033Y厓厀桥桻佖厚伍伞县伿\u000bg2\"\u0000\u0005{74*\u0012";
      o[23] = "+R\u001aGQD~U\u0004U2伨栈桴桭佤佯厶叒厮厷9\bJ\u007f\u0013\u0017\b]Ma\u0001";
      o[24] = "_\u001bSJX\u0015\u0006[\u0007E&併伸伸叺栽句叫桼厦叺$\u001a\u0013\\Z\u0002ZT\u0016\u001fT";
      o[25] = ">OJ2k/?HXeS?VD\u00116ciVu\u0018>6neNPwhj";
      o[26] = "0\u0005t%bsx\u0006%(\u0013\u001b\u0000L}*/}o\r%/)C";
      o[27] = "z1\n\u0006\\Ff,V{厣佫叞厎桷厸伽叵佀桔nB\f\u000fo}\r\u0005Q\u000b|";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = o[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'U' && var8 != 230 && var8 != 'd' && var8 != 237) {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 235) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'q') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'U') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 230) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'd') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树树友树友友树友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (p[var4] != null) {
         return var4;
      } else {
         Object var5 = o[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 3;
               case 1 -> 53;
               case 2 -> 10;
               case 3 -> 20;
               case 4 -> 16;
               case 5 -> 2;
               case 6 -> 43;
               case 7 -> 32;
               case 8 -> 50;
               case 9 -> 35;
               case 10 -> 44;
               case 11 -> 58;
               case 12 -> 0;
               case 13 -> 45;
               case 14 -> 49;
               case 15 -> 48;
               case 16 -> 39;
               case 17 -> 14;
               case 18 -> 5;
               case 19 -> 54;
               case 20 -> 19;
               case 21 -> 1;
               case 22 -> 23;
               case 23 -> 26;
               case 24 -> 9;
               case 25 -> 57;
               case 26 -> 41;
               case 27 -> 15;
               case 28 -> 60;
               case 29 -> 30;
               case 30 -> 8;
               case 31 -> 47;
               case 32 -> 21;
               case 33 -> 46;
               case 34 -> 18;
               case 35 -> 40;
               case 36 -> 24;
               case 37 -> 29;
               case 38 -> 25;
               case 39 -> 13;
               case 40 -> 31;
               case 41 -> 42;
               case 42 -> 59;
               case 43 -> 28;
               case 44 -> 6;
               case 45 -> 56;
               case 46 -> 36;
               case 47 -> 27;
               case 48 -> 37;
               case 49 -> 61;
               case 50 -> 52;
               case 51 -> 34;
               case 52 -> 7;
               case 53 -> 22;
               case 54 -> 38;
               case 55 -> 12;
               case 56 -> 55;
               case 57 -> 33;
               case 58 -> 51;
               case 59 -> 63;
               case 60 -> 62;
               case 61 -> 4;
               case 62 -> 11;
               default -> 17;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            p[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      if (var5 instanceof String) {
         String var6 = p[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         o[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = p[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         o[var4] = var21;
         return var21;
      }
   }

   @Override
   public void t() {
      long a = c ^ 4887455500045L;
      long ax = a ^ 97152478078338L;
      d<"d">(-7632574351544739360L, a).U(ax);
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   @EventTarget
   public void W(Render2DEvent event) {
      long a = c ^ 77673684894610L;
      long ax = a ^ 30905377026055L;
      long axx = a ^ 45050801843106L;
      long axxx = a ^ 100804744750248L;
      long axxxx = a ^ 46825508081279L;
      long axxxxx = a ^ 29176544944413L;
      long axxxxxx = a ^ 124023199095566L;
      d<"q">(-7886766621267538206L, a);
      if (!this.w(new Object[]{axx})) {
         this.T(d<"U">(this, -7885992340976470732L, a).getValue());
         LivingEntity target = null;
         PoseStack poseStack = event.poseStack();
         if (d<"d">(-7886046143443297601L, a) != null && d<"d">(-7886046143443297601L, a).isEnabled()) {
            target = d<"d">(-7886046143443297601L, a).B();
         }

         boolean inGUI = d<"U">(mc, -7886790127309347989L, a) instanceof 树何树友树何何友何何;
         if (target == null) {
         }

         d<"d">(-7886677308964987521L, a).U(axxxxx);
         d<"U">(this, -7885936066049268630L, a).H(d<"d">(-7885860695819125611L, a), axxxxxx);
         if (target != null) {
            d<"í">(target, -7887558179326464937L, a);
            d<"U">(this, -7885936066049268630L, a).H(d<"d">(-7886303378160890056L, a), axxxxxx);
         }

         if (!d<"U">(this, -7885936066049268630L, a).B(d<"d">(-7886303378160890056L, a), axxx) || inGUI) {
            if (target == null) {
               target = mc.player;
               if (d<"d">(-7887558179326464937L, a) != null && !d<"d">(-7886677308964987521L, a).Y(n, axxxx)) {
                  target = d<"d">(-7887558179326464937L, a);
               }
            }

            poseStack.pushPose();
            poseStack.translate(
               (d<"U">(this, -7886117232075944183L, a) + d<"U">(this, -7886239839073802148L, a) / 2.0) * (1.0 - d<"U">(this, -7885936066049268630L, a).T(ax)),
               (d<"U">(this, -7886873374884954297L, a) + 20.0F) * (1.0 - d<"U">(this, -7885936066049268630L, a).T(ax)),
               0.0
            );
            poseStack.scale((float)d<"U">(this, -7885936066049268630L, a).T(ax), (float)d<"U">(this, -7885936066049268630L, a).T(ax), 0.0F);
            if (target != null) {
               String var20 = d<"U">(this, -7885992340976470732L, a).getValue();
               byte var21 = -1;
               switch (var20.hashCode()) {
                  case -352259601:
                     if (!var20.equals(c<"r">(10375, 163084378501337203L ^ a))) {
                        break;
                     }

                     var21 = 0;
                  case 75041004:
                     if (!var20.equals(c<"r">(14825, 1418881114207142167L ^ a))) {
                        break;
                     }

                     var21 = 1;
                  case 75677:
                     if (!var20.equals(c<"r">(28428, 5926926528617551859L ^ a))) {
                        break;
                     }

                     var21 = 2;
                  case 65078532:
                     if (!var20.equals(c<"r">(30232, 4942180625407610593L ^ a))) {
                        break;
                     }

                     var21 = 3;
                  case -1984932033:
                     if (var20.equals(c<"r">(438, 8577966430346246477L ^ a))) {
                        var21 = 4;
                     }
               }

               switch (var21) {
                  case 0:
                     友何友何何何友树友树.W(poseStack, target, (int)this.r(), (int)this.v());
                  case 1:
                     cn.cool.cherish.ui.友何何树友何何何友何.Z(poseStack, target, (int)this.r(), (int)this.v(), (float)d<"U">(this, -7885936066049268630L, a).T(ax));
                  case 2:
                     友树何树友友何何友树.U(poseStack, target, (int)this.r(), (int)this.v());
                  case 3:
                     友友树何树树何树树树.q(poseStack, target, (int)this.r(), (int)this.v());
                  case 4:
                     树何何何树树树何友何.A(poseStack, target, (int)this.r(), (int)this.v());
               }
            }

            poseStack.popPose();
         }

         this.b(poseStack);
      }
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖国企变私企";
   }
}
