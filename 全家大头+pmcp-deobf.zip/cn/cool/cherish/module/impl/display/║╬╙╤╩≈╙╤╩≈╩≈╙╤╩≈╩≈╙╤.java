package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import cn.cool.cherish.ui.友何何树友何何何何树;
import cn.cool.cherish.utils.animations.何树友友何友友何树树;
import cn.cool.cherish.utils.animations.友何友树树树树何树友;
import cn.cool.cherish.utils.player.树树树何友友树友友友;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Rectangle;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何友树友树树友树树友 extends 树树友树友友何友友树 implements 何树友 {
   private final 友树何树友友何树友友 友树友何何何树友何友;
   private final BooleanValue 友何友树友友树何树友;
   private final ModeValue 友友何何树友友友何树;
   private final NumberValue 树何友何何友树友树友;
   private final BooleanValue 何树何树友树友树何树;
   private final NumberValue 何树何友何何树何树友;
   private final 友何友树树树树何树友 树何树友树何友树何何;
   private final Rectangle 树友何友友友树何何友;
   private final List<Long> 友友友树友何树何友友;
   private int 何何树树友友何友何何;
   private boolean 树何何友树友何树何树;
   private int 树树友友树友何友树树;
   private final DecimalFormat 树何树树树树树何友树;
   private int 友何树树树何友树树何;
   private long 何友树友友树友友友树;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final long n;
   private static final long[] o;
   private static final Long[] p;
   private static final Map q;
   private static final Object[] x = new Object[51];
   private static final String[] y = new String[51];
   private static String HE_WEI_LIN;

   public 何友树友树树友树树友() {
      long a = c ^ 79116986803750L;
      long ax = a ^ 52911111057529L;
      super(c<"c">(30184, 7235052045907358773L ^ a), c<"c">(16098, 3972111103813369604L ^ a), 150.0F, 20.0F);
      this.友树友何何何树友何友 = new 友树何树友友何树友友(c<"c">(26418, 1720667599032116956L ^ a), c<"c">(17472, 7887294051211167149L ^ a), c<"c">(28886, 339206999543607552L ^ a));
      this.友何友树友友树何树友 = new BooleanValue(c<"c">(4387, 7833759849256980703L ^ a), c<"c">(16983, 3902905413713052577L ^ a), true);
      this.友友何何树友友友何树 = new ModeValue(
         c<"c">(19290, 9171989215712627371L ^ a),
         c<"c">(18484, 8316586889583512010L ^ a),
         new String[]{c<"c">(22390, 7389830211018217092L ^ a), c<"c">(16115, 7494311986838290203L ^ a), c<"c">(10157, 7479610356226401878L ^ a)},
         c<"c">(14926, 8211803125853993873L ^ a)
      );
      this.树何友何何友树友树友 = new NumberValue(c<"c">(7905, 4648369953227054869L ^ a), c<"c">(21731, 7284129140478465282L ^ a), 80, 0, 255, 1);
      this.何树何树友树友树何树 = new BooleanValue(c<"c">(30892, 4892608008449522001L ^ a), c<"c">(2119, 2825405378393147831L ^ a), false);
      this.何树何友何何树何树友 = new NumberValue(c<"c">(4299, 8880391262897901863L ^ a), c<"c">(6089, 116499890008233501L ^ a), 4, 0, 10, 1);
      this.树友何友友友树何何友 = new Rectangle();
      this.友友友树友何树何友友 = new ArrayList<>();
      h<"ä">(this, 0, 1789008156886802565L, a);
      h<"ä">(this, false, 1788948777368464638L, a);
      h<"ä">(this, 0, 1792143947703450265L, a);
      this.树何树树树树树何友树 = new DecimalFormat("#");
      h<"ä">(this, 0, 1788695767841709768L, a);
      h<"ä">(this, System.currentTimeMillis(), 1791779495330626558L, a);
      this.树何树友树何友树何何 = new 何树友友何友友何树树(ax, 200, 1.0);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2624108699562398016L, 149135739767643730L, MethodHandles.lookup().lookupClass()).a(88320870801157L);
      // $VF: monitorexit
      c = var10000;
      c();
      long var16 = c ^ 13293816951498L;
      Cipher var18;
      Cipher var29 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(var16 << var19 * 8 >>> 56);
      }

      var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[44];
      int var23 = 0;
      String var22 = "\u001dê!<µñÁ\u0091::¼}\u001aã\u0011í\u0001¡\u0000t\u0097Ã0\u008d\u0010Î\u0010sL\f\u009dE.¼M\u00ad\nvâã\u0094\u0018'ìÍO\u0001\u008fW]\u0096\u009f\u0080!Ujï\u001aª¥\f^\u0083\u0011Åñ\u0010¦\u0014ÆR²G½\u009cæÿ¡\u0017+¡àÛ\u0010TjÂ\u001f]\u000b\\U\u0089µ\u008eÀ\rÏÂ\u0081\u0010ôÝDý\u008dnkA\u0091Ò\"4aÒ§\f\u0010b\u0097!\u008539ö\u008cÙqó\u0007Í\u0016ÿ\u0007\u0010i©K²\u007fQ°2#0)\u008bÞÛ>\u0001(\u0094¼\u0013kq\"Z\u0098?YS\u00adìê\u009e±ó\u0083©\u0019g\u009f|\u009c³³¢o$Ô\u0001yn\u0011/W(ê\u0001\u0088\u0010©ó\u0007\u0087\u001cô\u0085/è¬»h|\u009cÈ  \u0016\u0091|U»úWô!_&*bî.L£«2ç,jÝ\u009d¬Qå\u009b\u0088¢\"L óê\u0091;´A$\r¡\u0086\f\u001a¸\u0011¿\u008dm÷\u0006µÎ\u000e\u008aru¥_RH1Ñz\u0010\u007f¯{¾è2ÖÊªé\u0085 \u0013è±\f \u00819j®):Øñ\u0088\u001c¬\\¼pÝ¯%9ô¹ïM\u0081ï\u0091\u0080q\u0005Mr¾¶\u0010\u0097X7É¨n\u0010'\u0084\u0091i\u009c\u0007I\u009bw\u0018ôçðö\u0013Q\u0080\u0000\n¿\f\u008c¬§+yã\u0006&\u0000&\u0090ì\u008e\u0010ÅyX£Ôð\u000e6:t\u008bëË\u0080 0 É\u0003Û\u00832ø¼«\u009d¯ÕüÆ\u0083°]\u0080«¥¤uá~Ñ\u0013JGq\u008fø;× Ó¤e¿ëB\u008d´ÙÄN\n(\u0091ÒÛb\u008c\u0013Þ?H\u0004R\u0096R\u0084\u0006ë=µX\u0010W\u007fÊ\u0006\u0086}$!I-\\pé_Ö&\u00102\u008b¡»·x|¼\u0006Tð¦¨\u0095ç©\u0010¬\u0096Â\u0098\\Ý_Wío¯C¥!¿.\u00107\fu¾J\u0089\u009bÊ\n\u0081\u0096L*\u0017åU\u0010æã¶É=\u0087éîA9\u009c\u0000÷êX\u008b\u0010ù{\u0088´$ñ[Y\u0092ËÜ^t)¨\u0001\u0010*äücìIÀ¬\u0011\u0006~âÙ9\u0013\u0092 eî\u0080\u0094±à\u008cÆ^\u008c\u00adg@\u009c>Ñ\fp\u009c\u009fp\u009eÉØ\u008aÔÚ\u0000xùýQ\u0010\u001dÖ\u0013Ø\u00822÷\u0019\u008fÚ®\u0083æ\u008ex\u008d\u0010z\u007fK\u0080\u0093YÊ©ËËQø\u0005Q¥L Xõ\u0006\u0011\u00982\u009bC\\V\u008a\u0093\u0090ÀëþH\u007f¦2\nz÷ã\u008c\u001bç½Y\u0002\u0098\u008f\u0010LÁ÷\u0005\u0018\bþ\u008eü\\X\u0089ÌÀ3Ì\u0010Èt\u009d/\u0094g\u0081º\u0013è\u0007/\r\u0082å\u0085\u0010\u0011?À2\u0007±Ùß\u0087ê\u009fõ² >\u0081\u0018\u001fkÈß\f:¨úwÍè;\u0001¬\\½8ØpÕ\u0011Qtº\u0010Ì\u0012ß3Òó\u0091\u0012TâmÀ£\u0002<\u0097\u0010ýY\u001b£e\u0007>\u0091F\u009f\u0086;eR¾\u0091\u0010\u0002r\u001fk\u008e\u000eÛc²Ú-A\u0005>¡Ä\u0010KSûô\u001a³\u0096É´\u008aç\u0098áoÄf\u0010\u0018E/:WwÖá\u0094yS\u009bz\u0007Â¦ l4Ê\u0088±s\u00051TÆ\u0098ËR^r\u0005[\u0013\u0003á¤`s\u001dP¼W\u008a\u009eU«ê \u0004X5@\u0015\u0012á{÷à\u001av° \u000bµ\u0000\u001a?C\u0082\u0006\u008còG*\u008dê\u0084æ\u0005 \u0010~¼d¨\\\u0086È±(Éõ³±z\u0014å";
      short var24 = 913;
      char var21 = 24;
      int var28 = -1;

      label66:
      while (true) {
         String var30 = var22.substring(++var28, var28 + var21);
         int var10001 = -1;

         while (true) {
            String var43 = d(var18.doFinal(var30.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var43;
                  if ((var28 += var21) >= var24) {
                     k = var25;
                     l = new String[44];
                     Cipher var11;
                     Cipher var32 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(var16 << var12 * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var15 = var11.doFinal(new byte[]{86, -56, 69, 118, 116, 65, 31, 64});
                     long var47 = (var15[0] & 255L) << 56
                        | (var15[1] & 255L) << 48
                        | (var15[2] & 255L) << 40
                        | (var15[3] & 255L) << 32
                        | (var15[4] & 255L) << 24
                        | (var15[5] & 255L) << 16
                        | (var15[6] & 255L) << 8
                        | var15[7] & 255L;
                     var10001 = (byte)-1;
                     n = var47;
                     q = new HashMap(13);
                     Cipher var0;
                     Cipher var33 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var16 << var1 * 8 >>> 56);
                     }

                     var33.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[5];
                     int var3 = 0;
                     String var4 = "\u0012\u0007ë®(?\u009dî ·:`_aL\u00121\u0081·ÐôlXã";
                     byte var5 = 24;
                     byte var2 = 0;

                     label42:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var34 = var6;
                        var10001 = var3++;
                        long var49 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var53 = -1;

                        while (true) {
                           long var8 = var49;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var55 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var53) {
                              case 0:
                                 var34[var10001] = var55;
                                 if (var2 >= var5) {
                                    o = var6;
                                    p = new Long[5];
                                    return;
                                 }
                                 break;
                              default:
                                 var34[var10001] = var55;
                                 if (var2 < var5) {
                                    continue label42;
                                 }

                                 var4 = "¿ã.>Ì\u008có%üì\u0086\u0000íá\u0014\u0085";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var41 = var2;
                           var2 += 8;
                           var7 = var4.substring(var41, var2).getBytes("ISO-8859-1");
                           var34 = var6;
                           var10001 = var3++;
                           var49 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var53 = 0;
                        }
                     }
                  }

                  var21 = var22.charAt(var28);
                  break;
               default:
                  var25[var23++] = var43;
                  if ((var28 += var21) < var24) {
                     var21 = var22.charAt(var28);
                     continue label66;
                  }

                  var22 = "[õ\u0001\u0019Ê\t®&sg{º;$¼\u0001·{Ùihù%ê-\ns\u0083ÂiÔv\u001c2.\u0017\u0012×\u001aLcÉÔ¢s/\u007fôy²øö³Kµý¯»PGµ\føù\u0010ik+ØCÉ.\u009d0Z\u0087~6~O\u0082";
                  var24 = 81;
                  var21 = '@';
                  var28 = -1;
            }

            var30 = var22.substring(++var28, var28 + var21);
            var10001 = 0;
         }
      }
   }

   private void Z() {
      long a = c ^ 22803500812708L;
      h<"O">(3989486106874210557L, a);

      try {
         try {
            Field fpsField = mc.getClass().getDeclaredField(c<"c">(21338, 8591896123742551359L ^ a));
            fpsField.setAccessible(true);
            h<"ä">(this, fpsField.getInt(mc), 3989250447382598939L, a);
            return;
         } catch (Exception var13) {
            try {
               String debugText = h<"F">(mc, 3989420709584741995L, a);
               if (debugText != null && debugText.contains(c<"c">(18285, 1464566058477218104L ^ a))) {
                  String[] parts = debugText.split(" ");
                  int var7 = parts.length;
                  int var8 = 0;
                  if (0 < var7) {
                     String part = parts[0];

                     try {
                        int fps = Integer.parseInt(part);
                        if (fps > 0 && fps < 1000) {
                           h<"ä">(this, fps, 3989250447382598939L, a);
                           return;
                        }
                     } catch (NumberFormatException var11) {
                     }

                     var8++;
                  }
               }
            } catch (Exception var12) {
            }

            if (mc.getDeltaFrameTime() > 0.0F) {
               h<"ä">(this, Math.round(1.0F / mc.getDeltaFrameTime()), 3989250447382598939L, a);
               return;
            }

            h<"ä">(this, h<"F">(this, 3985943073720316234L, a) + 1, 3985943073720316234L, a);
            long currentTime = System.currentTimeMillis();
            if (currentTime - h<"F">(this, 3990187881207862396L, a) >= d<"h">(31713, 328730118348259876L ^ a)) {
               h<"ä">(
                  this, (int)(h<"F">(this, 3985943073720316234L, a) * 1000.0 / (currentTime - h<"F">(this, 3990187881207862396L, a))), 3989250447382598939L, a
               );
               h<"ä">(this, 0, 3985943073720316234L, a);
               h<"ä">(this, currentTime, 3990187881207862396L, a);
            }
         }
      } catch (Exception var14) {
         h<"ä">(this, (int)n, 3989250447382598939L, a);
      }
   }

   @EventTarget
   public void i(AttackEvent event) {
      this.j();
   }

   private String b(String rawText) {
      long a = c ^ 104445165349907L;
      long ax = a ^ 37066630788762L;
      long axx = a ^ 41245346754775L;
      h<"O">(5974810203147570506L, a);
      if (rawText == null) {
         return "";
      } else {
         String processedText = rawText;
         if (rawText.contains(c<"c">(19977, 9155738012550989251L ^ a))) {
            processedText = rawText.replace(c<"c">(32022, 9110441420445300426L ^ a), String.valueOf(h<"F">(this, 5975116059565666476L, a)));
         }

         if (processedText.contains(c<"c">(32438, 4138256557895693661L ^ a))) {
            processedText = processedText.replace(c<"c">(24116, 435519354055267801L ^ a), String.valueOf(h<"F">(this, 5973686782135233200L, a)));
         }

         if (processedText.contains(c<"c">(7935, 42722757999777085L ^ a))) {
            String username = mc.player != null ? WrapperUtils.E(new Object[]{ax}) : c<"c">(13401, 4033687196061990787L ^ a);
            processedText = processedText.replace(c<"c">(21118, 4105458570497825208L ^ a), username);
         }

         if (processedText.contains(c<"c">(20188, 2300222501849040145L ^ a))) {
            String worldName = mc.level != null ? mc.level.dimension().location().getPath() : c<"c">(14764, 6886693893313983075L ^ a);
            processedText = processedText.replace(c<"c">(6242, 6337632998832919435L ^ a), worldName);
         }

         if (mc.player != null) {
            if (processedText.contains(c<"c">(10930, 3397827684289372519L ^ a))) {
               processedText = processedText.replace(c<"c">(28718, 3416741815338122224L ^ a), h<"F">(this, 5974917050338364784L, a).format(mc.player.getX()));
            }

            if (processedText.contains(c<"c">(16869, 5093175590678137381L ^ a))) {
               processedText = processedText.replace(c<"c">(17594, 5607654334601138005L ^ a), h<"F">(this, 5974917050338364784L, a).format(mc.player.getY()));
            }

            if (processedText.contains(c<"c">(20862, 2435355640855173806L ^ a))) {
               processedText = processedText.replace(c<"c">(19313, 3599406688351125693L ^ a), h<"F">(this, 5974917050338364784L, a).format(mc.player.getZ()));
            }
         }

         if (processedText.contains(c<"c">(8934, 3700713743967807792L ^ a))) {
            long worldTime = mc.level != null ? mc.level.getDayTime() : 0L;
            int hours = (int)(
               (worldTime / d<"h">(31713, 328666077405161363L ^ a) + d<"h">(5125, 7463121188853368947L ^ a)) % d<"h">(1590, 7286117472623680071L ^ a)
            );
            int minutes = (int)(
               worldTime % d<"h">(31713, 328666077405161363L ^ a) * d<"h">(18518, 5986774694724965414L ^ a) / d<"h">(31713, 328666077405161363L ^ a)
            );
            processedText = processedText.replace(
               c<"c">(12854, 9130173899662195162L ^ a), String.format(c<"c">(18121, 5825807356654783783L ^ a), hours, minutes)
            );
         }

         if (processedText.contains(c<"c">(19674, 1985341584011659019L ^ a))) {
            processedText = processedText.replace(c<"c">(8371, 3389238151014214483L ^ a), String.valueOf(树树树何友友树友友友.d(axx, mc.player)));
         }

         return processedText;
      }
   }

   public int s() {
      long a = c ^ 123701968607191L;
      return h<"F">(this, 7579503307295263592L, a);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/何友树友树树友树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6440;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/何友树友树树友树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = k[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static void c() {
      x[0] = "i@8*\b\"f\u0000u!\u0002?c]~g\n\"n[z,I$g^zg\u0003$y^z(\u001ec佟句标厂桶桜叁栿标厂";
      x[1] = long.class;
      y[1] = "java/lang/Long";
      x[2] = int.class;
      y[2] = "java/lang/Integer";
      x[3] = boolean.class;
      y[3] = "java/lang/Boolean";
      x[4] = "b8!I\u0004\u0017mxlB\u000e\nh%g\u0004\u0006\u0017e#cOE\u0011l&c\u0004\u000f\u0011r&cK\u0012VI\u0003K";
      x[5] = "\u000b>(`rQ\u0004~ekxL\u0001#n-k_\u0004%c-tS\u0018<(NrZ\r\u0006goh[";
      x[6] = "G\u007f";
      x[7] = "H\u001b*FEOC\u0014;\t.[A\u001f,S\u0002LL";
      x[8] = "\u0002\t|'\u001b\f\u0002\tk{\u0017\u0003\u0018Bke\u001f\u0000\u0002\u0018&D\u001f\u000b\t\u000fzh\u0010\u0011";
      x[9] = "X\u001d,\u000b\"\u0007X\u001d;W.\bBV;I&\u000bX\fvB:\u0007\u0018>7K;";
      x[10] = "JN?\tm7TF%F\u000f+S[";
      x[11] = "_s\u0015;\u001d\u007fP3X0\u0017bUnSv\u0007dUqHv\u0013~UpZ,\u001b\u007fRn\u0015厓伧叛栭栌株厓档佅号";
      x[12] = "69DM-r9y\tF'o<$\u0002\u0000/r1\"\u0006Kl栌桄厜桻句厉佈厞厜桻";
      x[13] = float.class;
      y[13] = "java/lang/Float";
      x[14] = "^\u0019\u0017\u000bdHQYZ\u0000nUT\u0004QF~ST\u001bJFjIT\u001aX\u001cbHS\u0004\u0017厣佞召栬桦栨桹佞栶叶";
      x[15] = "V\u0000iz40Y@$q>-\\\u001d/7->Y\u001b\"722E\u0002iW.2W\u000b5O:3@\u000b";
      x[16] = "(!4dup'ayo\u007fm\"<r)l~':\u007f)sr;#4双栋佊桚厄发佒栋叔厀";
      x[17] = "W\u0012\u001d,\u0014A\\\u001d\fciYO\u001a\u0005*";
      x[18] = ".HPUQR3]\bf\u001aP0HHS\u0013V";
      x[19] = "iDs2\u0001uf\u0004>9\u000bhcY5\u007f\u0018{f_8\u007f\u0007wzFs\u0013\u0001ufO<?8{f_8";
      x[20] = "<G6l/A<G!0#N&\f!.+M<Vl\r2\\;M,1";
      x[21] = "\u0010\u000e}{/s\u0010\u000ej'#|\nEj9+\u007f\u0010\u001f'\u001e'c3\ny%+t\u0019";
      x[22] = "qD\u0016wA\u0011~]\u00148+\u0000xL\rw\u0003#tW\rw\u001b";
      x[23] = "\u0017%\\\u0006/W\u001c*MINY\u0017!I\u0013";
      x[24] = ">~l[\u0005\u001ecxrIo厺反栜佑栽厬桠反叆栕$U\u001aazb\u0019\u001f\u00191`";
      x[25] = "jq\u00106;Q7w\u000e$Q佫伇叉桩桐案佫厙叉厳I`\u0006=u\u00173 O:m";
      x[26] = "v3'*\u0007C.7b$z]\u001f>&|D\r\u001f\u000frt\u0005H:da \u0007^";
      x[27] = "WV\u0010\t\u001fkU\u000e\u0010{厸佖栫桶桢伦厸栒栫伲{B\u000b4\b\u0003D\u001b\u0018i\u000f";
      x[28] = "\u000ei+\nse\f1+x栎佘厨伍伝去栎叆桲厓@\u0011hjT+2@)9\f";
      x[29] = "GbFVMlE:F$只佑叡桂叮叧栰佑栻厘-HQ6S`V^Kj\u0012";
      x[30] = "_NuS'D]\u0016u!伞佹栣桮叝叢伞叧佧伪\u001e\u00183\u001b\u0000\u001b!A F\u0007";
      x[31] = "\u001f\t\u00012*`\u001dQ\u0001@桗佝伧右桳厃伓栙伧栩jz-o\u0005^W0.?\u001f";
      x[32] = "_B+\be\b]\u001a+z参桱叹伦伝伧栘厫佧厸@\u0010f\u0011\u0005J\"Gq\u0004D";
      x[33] = "\n\u0003!!\u0006\nW\u0005?3l厮佧去厂桇厯估栣桡厂^]]]\u0007&$\u001d\u0014Z\u001f";
      x[34] = "4OMI\u000e\u0018t\u0004O\r6桭佒伫根伫叵桭佒伫根v\r\u000f~\r]M\u000bKw\u0018";
      x[35] = "k\fI+U^4\u0003\u0015po佪桂栫伩栈厬叴伆叱伩\u0011_\tf\bNx\u0000\u0006:S";
      x[36] = "r'\u0014s-&p\u007f\u0014\u0001桐厅佊叝厼参桐伛佊叝\u007fmq!(d\u0015=0(,";
      x[37] = "k;)\u0019tvic)k栉佋栗叁桛伶叓栏体佟B\u0002-rd;r\u0017iyg";
      x[38] = "fvH:#%d.HH厄历佞伒栺压厄历佞桖#s<4x2\u0018ux=m";
      x[39] = "fq\u0000tf\u0006d)\u0000\u0006佟厥栚压厨栟叁厥叀桑kxz\u0017i,Zaa\t";
      x[40] = "9\u0013]Dv\u0013;K]6住桪企叩佫佫栋伮桅叩6_m\u001ccQD\u000e,O;";
      x[41] = "Dnu!XnF6uS栥体核桎标桊栥体叢桎\u001e=\rn^/c?^qD";
      x[42] = "O\u0000?\u0003~sMX?q栃栊叩叺桍厲佇叐栳栠THj,\u0010Uk\u0011yq\u0017";
      x[43] = "Z.wY{&\u0005!+\u0002A伒桳栉桓伾伜厌厩叓厉cqqW*p\n.~\u000bq";
      x[44] = "Nef\f}\u0014]1d\u001a\u000f\u0011td#O>AtUt\u00141B\u0019)$\u00194\u0003";
      x[45] = "g%Q:\u0011\u0007?!\u00144l\u0019\u000e(QeSH\u000e\u0019\u0003*\u001c\fcw\u0000m\u0014\r";
      x[46] = "#9\u001cw\u0000xcr\u001e38L\u0018<\u001c%\u0004+inM(\b\u0014";
      x[47] = "2!fA9+0yf34KjvuYl)4zl_]v9`g\u0002?(5ya3";
      x[48] = "_CMI\u0010\u001d]\u001bM;伩桤佧档句栢厷桤佧档&W\fGKA]A\u0016\u001b\n";
      x[49] = "l\b\u0004PQrnP\u0004\"叶发及栨厬使栬住及史o\u001dT)x\nW\u0018\u0005\"{";
      x[50] = "s\u0012\ro)-+\u0016HaT3\u001a\u001f\f9jg\u001a.\u000by8`+\u0015V};=";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = x[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(y[var4]);
            x[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/何友树友树树友树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void l() {
      long a = c ^ 47334698025879L;
      h<"O">(9038372383762391758L, a);
      boolean isLeftClickPressed = h<"F">(h<"F">(mc, 9035228698155413256L, a), 9038223500212952659L, a).isDown();
      if (!h<"F">(this, 9035051633940285775L, a)) {
         this.j();
      }

      h<"ä">(this, isLeftClickPressed, 9035051633940285775L, a);
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 3731;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])q.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            q.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/何友树友树树友树树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/何友树友树树友树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'F' && var8 != 228 && var8 != 195 && var8 != 241) {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'T') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'O') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'F') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 228) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 195) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private float a(String text) {
      long a = c ^ 70944626034395L;
      h<"O">(4045028792366589826L, a);
      if (h<"F">(HUD.instance, 4044792611412836359L, a).C(c<"c">(14926, 8211795078111763308L ^ a))) {
         友何何树友何何何何树 ttFont = Cherish.instance.h().n(18);
         return ttFont.A(text);
      } else {
         return h<"F">(mc, 4045863269007785000L, a).width(text);
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (y[var4] != null) {
         return var4;
      } else {
         Object var5 = x[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 0;
               case 2 -> 38;
               case 3 -> 61;
               case 4 -> 30;
               case 5 -> 59;
               case 6 -> 20;
               case 7 -> 21;
               case 8 -> 27;
               case 9 -> 46;
               case 10 -> 18;
               case 11 -> 45;
               case 12 -> 43;
               case 13 -> 36;
               case 14 -> 7;
               case 15 -> 63;
               case 16 -> 31;
               case 17 -> 54;
               case 18 -> 2;
               case 19 -> 32;
               case 20 -> 49;
               case 21 -> 13;
               case 22 -> 11;
               case 23 -> 5;
               case 24 -> 56;
               case 25 -> 29;
               case 26 -> 51;
               case 27 -> 4;
               case 28 -> 19;
               case 29 -> 14;
               case 30 -> 28;
               case 31 -> 62;
               case 32 -> 33;
               case 33 -> 57;
               case 34 -> 8;
               case 35 -> 16;
               case 36 -> 50;
               case 37 -> 48;
               case 38 -> 23;
               case 39 -> 6;
               case 40 -> 52;
               case 41 -> 44;
               case 42 -> 3;
               case 43 -> 10;
               case 44 -> 12;
               case 45 -> 1;
               case 46 -> 15;
               case 47 -> 37;
               case 48 -> 40;
               case 49 -> 60;
               case 50 -> 58;
               case 51 -> 17;
               case 52 -> 25;
               case 53 -> 47;
               case 54 -> 39;
               case 55 -> 35;
               case 56 -> 55;
               case 57 -> 24;
               case 58 -> 53;
               case 59 -> 41;
               case 60 -> 26;
               case 61 -> 34;
               case 62 -> 22;
               default -> 9;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            y[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      if (var5 instanceof String) {
         String var6 = y[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         x[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = y[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         x[var4] = var21;
         return var21;
      }
   }

   public int k() {
      long a = c ^ 67278026184080L;
      return h<"F">(this, -1484587314205338829L, a);
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private void j() {
      long a = c ^ 30911477529431L;
      long currentTime = System.currentTimeMillis();
      h<"F">(this, -4203757824918377080L, a).add(currentTime);
      h<"F">(this, -4203757824918377080L, a).removeIf(clickTime -> {
         long ax = c ^ 49019710761553L;
         h<"O">(-7734729697472984312L, ax);
         return currentTime - clickTime > d<"h">(16700, 8578935162920491789L ^ ax);
      });
   }

   private void L() {
      long a = c ^ 75841089272924L;
      h<"F">(this, -9032117283478934206L, a).setRect(this.r(), this.v(), h<"F">(this, -9031947380476544908L, a), h<"F">(this, -9032519261253792589L, a));
   }

   @EventTarget
   public void M(TickEvent event) {
      long a = c ^ 3545841555383L;
      long ax = a ^ 98311191519425L;
      h<"F">(this, -6247487127122134804L, a).H(this.isEnabled() ? h<"Ã">(-6246506787313869009L, a) : h<"Ã">(-6247076689073607006L, a), ax);
      this.Z();
      this.l();
      this.P();
      String processedText = this.b(h<"F">(this, -6247278594126174287L, a).getValue());
      float textWidth = this.a(processedText);
      h<"ä">(this, Math.max(50.0F, textWidth + h<"F">(this, -6246761983279919764L, a).getValue().floatValue() * 2.0F), -6250058990984375393L, a);
      this.L();
   }

   private void P() {
      long a = c ^ 14437128866750L;
      long currentTime = System.currentTimeMillis();
      h<"F">(this, -774529269628166815L, a).removeIf(clickTime -> {
         long ax = c ^ 41354233162308L;
         h<"O">(6106231677647293213L, ax);
         return currentTime - clickTime > d<"h">(31713, 328713762287559108L ^ ax);
      });
      h<"ä">(this, h<"F">(this, -774529269628166815L, a).size(), -771347379749696227L, a);
   }

   private static String HE_JIAN_GUO() {
      return "我是何树友";
   }
}
