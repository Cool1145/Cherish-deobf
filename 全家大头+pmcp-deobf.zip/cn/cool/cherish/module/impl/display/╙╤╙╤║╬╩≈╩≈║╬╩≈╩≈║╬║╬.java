package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.友友友何树友何树树树;
import cn.cool.cherish.ui.何何友友树何树何友树;
import cn.cool.cherish.utils.animations.何友友何何友何友友何;
import cn.cool.cherish.utils.animations.何友友友树何何友树何;
import cn.cool.cherish.utils.animations.友何树友树何何友树树;
import cn.cool.cherish.utils.animations.树何何树友友树何友友;
import cn.cool.cherish.utils.animations.树友树何树树何树树何;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友友何树树何树树何何 extends 友友友何树友何树树树 implements 何树友 {
   private final NumberValue 友友树树树友何树友树 = new NumberValue("Animation Speed", "动画速度", 1.0, 0.5, 3.0, 0.1);
   private final ModeValue 树何树友树何树友树何 = new ModeValue("Animation Type", "动画类型", new String[]{"Classic", "Collect", "Release", "Cycle"}, "Classic");
   private 友友何树树何树树何何.何何何友友何友树何友 何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.友树友友何何友友友何;
   private long 何树友树树树树何友何 = 0L;
   private boolean 何友树树友树友友树何 = false;
   private 何友友友树何何友树何 友友友树友何何何树何;
   private 树友树何树树何树树何 何树树何友友树友树树;
   private 树何何树友友树何友友 树树树何何何何何树何;
   private 何友友何何友何友友何 何树树树树何树友何友;
   private 何友友友树何何友树何 友树何树树何何友何何;
   private float 友何何何何何友何树树;
   private float 树何何何何友何友何友;
   private final float 何树何何树友树友何何 = 35.0F;
   private float 何友友友树友何友树何 = 0.0F;
   private float 友何树树何何树树树友 = 0.0F;
   private final float[] 树何树树树友何何何何 = new float[6];
   private final float[] 树友何树树树何友何友 = new float[6];
   private 何何友友树何树何友树 树何友友何树树树树友;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final long[] n;
   private static final Integer[] o;
   private static final Map p;
   private static final long q;
   private static final Object[] x = new Object[54];
   private static final String[] y = new String[54];
   private static int _何炜霖黑水 _;

   public 友友何树树何树树何何() {
      super("Determination", "决心", 140.0F, 140.0F);
      this.p();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-612543140978398277L, 8570665466502011181L, MethodHandles.lookup().lookupClass()).a(174475396039550L);
      // $VF: monitorexit
      c = var10000;
      c();
      Cipher var18;
      Cipher var29 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(128051290779180L << var19 * 8 >>> 56);
      }

      var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[15];
      int var23 = 0;
      String var22 = "ÔSlü\u001d\u001cÌ\u0006[/aËýõè\u0013§\u00163\u000fðÍa\u0003'¢\u0016OJ\u00866Q\u0010\u0091¢\u008döÆÕÕ¨¨k³\r\u000eXÍþ t\u0087,Bè¯\u0090\rR\u0000ûæ×Ca\u0000)¼\u0018*\u009bR\u001fö\u0082ô<Q\u001f\u0099Q\u000e\u00182\u009dWÊ\n\u009e\u008e»\u0083p\u00063\u0097caën\u0005×Ç\u009aú\u0095É\u0010\u001e¢½®Ì{ow\u001e*ä\u0095#Å]í\u0010,w*5Ì`Á\u0090\u0096\u009e\u001b\r*# B\u0010ª{®ýzÄ:]·BÞÒ® `\u001b\u0010ó\u0097Á\u0003£X\u009cR\u009cLr7+\u0018ÔÙ n{\u00adÂ#F\u001dî<û©Ä\u0092q\u0003\u008fö\u0004×zCË\u008cÎ\u0000÷ýô$\u009cLt\u0010³Ûb\u0093\u0091#¾FFmâ\u008a»g¿ü\u0010}Ò¨\u001cùSÓþ\u001c¢Î\u0092\u0012ö\u0098\u0007\u0010\u009cçvÌ^$£Í\u0088\u0011¬å~\u001a\u0082D\u0010Á¦Ës\u0089rº\u001f\u0006é£o\u008eF\u00ad+";
      short var24 = 276;
      char var21 = ' ';
      int var28 = -1;

      label64:
      while (true) {
         String var30 = var22.substring(++var28, var28 + var21);
         int var10001 = -1;

         while (true) {
            String var43 = d(var18.doFinal(var30.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var43;
                  if ((var28 += var21) >= var24) {
                     k = var25;
                     l = new String[15];
                     p = new HashMap(13);
                     Cipher var5;
                     Cipher var32 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(128051290779180L << var6 * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[6];
                     int var8 = 0;
                     String var9 = "\u001ew M^\u0095äM\u009b¬Ï\u009eDa\u008fâ1å\u0082Å/\u0017ß\u001bBuÏê\u0003N÷j";
                     byte var10 = 32;
                     byte var7 = 0;

                     label46:
                     while (true) {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = var9.substring(var10001, var7).getBytes("ISO-8859-1");
                        long[] var33 = var11;
                        var10001 = var8++;
                        long var47 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        byte var52 = -1;

                        while (true) {
                           long var13 = var47;
                           byte[] var15 = var5.doFinal(
                              new byte[]{
                                 (byte)(var13 >>> 56),
                                 (byte)(var13 >>> 48),
                                 (byte)(var13 >>> 40),
                                 (byte)(var13 >>> 32),
                                 (byte)(var13 >>> 24),
                                 (byte)(var13 >>> 16),
                                 (byte)(var13 >>> 8),
                                 (byte)var13
                              }
                           );
                           long var55 = (var15[0] & 255L) << 56
                              | (var15[1] & 255L) << 48
                              | (var15[2] & 255L) << 40
                              | (var15[3] & 255L) << 32
                              | (var15[4] & 255L) << 24
                              | (var15[5] & 255L) << 16
                              | (var15[6] & 255L) << 8
                              | var15[7] & 255L;
                           switch (var52) {
                              case 0:
                                 var33[var10001] = var55;
                                 if (var7 >= var10) {
                                    n = var11;
                                    o = new Integer[6];
                                    Cipher var0;
                                    Cipher var34 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(128051290779180L << var1 * 8 >>> 56);
                                    }

                                    var34.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    byte[] var4 = var0.doFinal(new byte[]{97, 100, -88, -88, -51, 89, 64, 93});
                                    long var50 = (var4[0] & 255L) << 56
                                       | (var4[1] & 255L) << 48
                                       | (var4[2] & 255L) << 40
                                       | (var4[3] & 255L) << 32
                                       | (var4[4] & 255L) << 24
                                       | (var4[5] & 255L) << 16
                                       | (var4[6] & 255L) << 8
                                       | var4[7] & 255L;
                                    byte var41 = -1;
                                    q = var50;
                                    return;
                                 }
                                 break;
                              default:
                                 var33[var10001] = var55;
                                 if (var7 < var10) {
                                    continue label46;
                                 }

                                 var9 = "Á\u0006\u0011m¨Òh\u001a-&ä=\u009c\u0005¸z";
                                 var10 = 16;
                                 var7 = 0;
                           }

                           byte var40 = var7;
                           var7 += 8;
                           var12 = var9.substring(var40, var7).getBytes("ISO-8859-1");
                           var33 = var11;
                           var10001 = var8++;
                           var47 = (var12[0] & 255L) << 56
                              | (var12[1] & 255L) << 48
                              | (var12[2] & 255L) << 40
                              | (var12[3] & 255L) << 32
                              | (var12[4] & 255L) << 24
                              | (var12[5] & 255L) << 16
                              | (var12[6] & 255L) << 8
                              | var12[7] & 255L;
                           var52 = 0;
                        }
                     }
                  }

                  var21 = var22.charAt(var28);
                  break;
               default:
                  var25[var23++] = var43;
                  if ((var28 += var21) < var24) {
                     var21 = var22.charAt(var28);
                     continue label64;
                  }

                  var22 = "³\u008eX\u0002\u009aZþX©z¼H¥\u0000Á\u0082Ìl\u009amöþ\u0080å{ês\u0007¡Xa/\u0010\u0002·ÿGWó\u0095\u00020]G¨Vá¶Ç";
                  var24 = 49;
                  var21 = ' ';
                  var28 = -1;
            }

            var30 = var22.substring(++var28, var28 + var21);
            var10001 = 0;
         }
      }
   }

   @Override
   public boolean C(double mouseX, double mouseY, int button) {
      HUD.A();
      boolean dragHandled = super.C(mouseX, mouseY, button);
      if (!dragHandled && button == 0 && this.何树树友何树友友树友 == 友友何树树何树树何何.何何何友友何友树何友.友树友友何何友友友何 && !this.何友树树友树友友树何) {
         this.u();
         return true;
      } else {
         return dragHandled;
      }
   }

   private int S(int color, float alpha) {
      int a = (int)(255.0F * Math.max(0.0F, Math.min(1.0F, alpha)));
      return a << 24 | color & 16777215;
   }

   private void x(PoseStack poseStack, String soulText, float x, float y, int color) {
      int width = this.树何友友何树树树树友.D("");
      int height = this.树何友友何树树树树友.x();
      float drawX = x - width / 2.0F;
      float drawY = y - height / 2.0F;
      this.树何友友何树树树树友.q(poseStack, soulText, drawX, drawY, color);
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25892;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何树树何树树何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[")[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static void c() {
      x[0] = "Wo>\u0004\u0010\u0003X/s\u000f\u001a\u001e]rxI\u0012\u0003Pt|\u0002Q\u0005Yq|I\u001b\u0005Gq|\u0006\u0006B叿及佅桶桮伹栥栐佅伲[伹佡佔叛厬伪厧栥佔叛";
      x[1] = ";\u007fCa\u0002T4?\u000ej\bI1b\u0005,\u0000T<d\u0001gCR5a\u0001,\tR+a\u0001c\u0014\u0015厓叚伸栓桼佮桉栀伸佗";
      x[2] = float.class;
      y[2] = "java/lang/Float";
      x[3] = long.class;
      y[3] = "java/lang/Long";
      x[4] = boolean.class;
      y[4] = "java/lang/Boolean";
      x[5] = "%u1\u0016K;*5|\u001dA&/hw[Q=h低佊厾可桅伓栊佊厾栵";
      x[6] = "\bZP\u0014K\u007f\u0003UA[7f\fOO\u0018\u0000V\u001aXC\u0005\u0011z\rU";
      x[7] = "\t\n";
      x[8] = "e\u0000Dk\u001azj@\t`\u0010go\u001d\u0002&\u0000ao\u0002\u0019&\u0014{o\u0003\u000b|\u001czh\u001dD佝厾叞反桿伿佝厾栄体";
      x[9] = "\u001a*";
      x[10] = "$N\f\u000e\u0010\u0015+\u000eA\u0005\u001a\b.SJC\u0012\u0015#UN\bQ\u0013*PNC\u001b\u00134PN\f\u0006T\u000fuf";
      x[11] = "\u0010\\oQI.e|d^Xa\u0018dwYQ(p";
      x[12] = "\nf\u001b@uG\u0005&VK\u007fZ\u0000{]\ro\\\u0000dF\r{F\u0000eTWsG\u0007{\u001b佶发口似佝叾佶发口似";
      x[13] = "kX]r\u00155d\u0018\u0010y\u001f(aE\u001b?\u00175lC\u001ftT厑參叽伦栀厱伏栙栧桢";
      x[14] = ";<\\6\u001cJ4|\u0011=\u0016W1!\u001a{\u001eJ<'\u001e0]L5\"\u001e{\u0017L+\"\u001e4\n\u000b厓厙伧桄桢佰桉桃伧伀W佰厓桃档桄厸栴桉伇档";
      x[15] = "0;";
      x[16] = "[\u0013\u0016tjnTS[\u007f`sQ\u000eP9s`T\b]9llH\u0011\u0016Zje]+Y{pd";
      x[17] = "I\u001b\r\u000ez^F[@\u0005pCC\u0006KC`EC\u0019PCt_C\u0018B\u0019|^D\u0006\r桼叞栠使桤栲伸栄栠使";
      x[18] = "%@w\u0016We*\u0000:\u001d]x/]1[M~/B*[Yd/C8\u0001Qe(]w厾佭栛厍栿伌传右栛桗";
      x[19] = " &#-{\u001c/fn&q\u0001*;e`a\u0007*$~`u\u001d*%l:}\u001c-;#桟佁伦桒厃叆桟佁厸厈";
      x[20] = "\u0011~*n]r\u001e>geWo\u001bcl#D|\u001eea#[p\u0002|*CGp\u0010uv[Sq\u0007u";
      x[21] = "{ulA~fpz}\u000e\u001fh{qyT";
      x[22] = "}\u000f'/lj|Af6]佐休栦栁桎伀佐桕叼栁Wg4 \u0007a+`<6D";
      x[23] = "V9&\u000fE\u0016Mo-Jt桡栦栚厗桫桭去栦叀伉r\u001d\u001eOh,\u0000\u0011\u0014C2";
      x[24] = "\"Z\u007fOZ|xVj0台桔厀台佚佭台厎厀佮\u0007QZ5<Z6\u000bV ";
      x[25] = "\u0016k<I\u0000D\u0017%}P1栺古桂佞栨佬叠佺桂佞1\u000b\u001aKczM\f\u0012] ";
      x[26] = "u\u0005\u0019P\u001d\u0003/\t\f/厷叱佉桵似佲伩叱受伱aN\u001dJk\u0005P\u0014\u0011_";
      x[27] = ">IY4\bj/\bOO叻栕伙栠栲伒佥叏伙佤+r\\h$WYpFw\"";
      x[28] = "nJ\u0002IHqo\u0004CPy佋框档叾史伤栏伂伧叾1C/3BDMD'%\u0001";
      x[29] = "q{kn\u0015\u0006`:}\u0015格厣佖栒栀栌佸厣佖又\u0019+G\\65&*H\u00001";
      x[30] = "F\u001e\u001abpRW_\f\u0019桙佩栥厭桱佄桙号栥伳hs'\u0004VP\u000ff~M\f";
      x[31] = "d0%;\u000e\bb0all<[5km\u000e\f%vc6\u000bu";
      x[32] = "G\r|V2%VLj-佟桚叾桤栗栴栛伞叾传\u000e\u0017dxADh@;~Q";
      x[33] = "\u0016\u0001\u0019mN\\\u0007@\u000f\u0016桧佧伱伬伶叕伣叹伱厲k,GVT\b\u0017+O@\u0017";
      x[34] = "\b[\u0005\u0000q\u0001\u0019\u001a\u0013{伜桾桫栲桮伦桘厤伯叨wK!\u0003NT\fE+[K";
      x[35] = "'9\r6\u007f\u001c7<\u001b9\u0010桥桕伟桨伆栉伡休厁厲[{\u00070/\u001e;k\u0002& ";
      x[36] = "\u0011{Amj\u0004\u0000:W\u0016桃桻桲佖佮佋伇伿桲佖3z!\u001c\u0006j\u000ew<\u001eT";
      x[37] = "tL^\u0015*He\rHn佇叭栗栥可桷叙叭栗佡,U\"\u0011vCJ\u0013s\u00106";
      x[38] = "u\u0003Y\f\u001dtdBOw栴住双厰佶桮栴栋栖厰+LPpf\f\u0016\r\u001d+h";
      x[39] = "1#W\nZT0m\u0016\u0013k台參低桱伯伶佮參叐伵rQ\nl+\u0011\u000eV\u0002zh";
      x[40] = "4{6K-inw#4桝桁伈发桗佩桝厛厖栋NU- *{\u007f\u000f!5";
      x[41] = ")o_D\"vscJ;伖桞伕佛佺司伖厄压佛'Z\"?7o\u0016\u0000.*";
      x[42] = "]!$@axL`2;厒佃栾案伋佦案标栾厒V\u0001hr\u001f(*\u0006`d\\";
      x[43] = "\u0015<\u0003(\u0019lO0\u0016W厳厞伩桌厸桎厳桄桭伈{6\u0019%\u000b<Jl\u00150";
      x[44] = "6\u0007H_HE'F^$去叠桕桮栣叧伥栺厏桮:I\u0019E-\u0019\u0001\u001eG\u0012*";
      x[45] = "e\f<A\f\u0011tM*:叿厴叜桥厍佧佡伪栆伡N\u0007X\u0013\u007f\u0012<\u0005B\fy";
      x[46] = "@'?hgJQf)\u0013伊栵栣厔伐栊厔可栣厔Mr>TE>|(2A";
      x[47] = "Ww-(P&F6;S\t@\u0011ia6^2D6o>`|C9:m\u0012)\u001c72S";
      x[48] = "\u0004'8u^p\u0015f.\u000e桷佋桧桎桓反伳佋伣伊J0\f*Ciu1\u0003vD";
      x[49] = "gt\u0019\u001d7Vv5\u000ff佚右叞叇桲厥佚右栄余k\\>\\%}\u0017[6Jf";
      x[50] = "\u0013EA~u\u0005\u0002\u0004W\u0005历伾伴佨佮佘历伾桰栬3?|\u000fQLO8t\u0019\u0012";
      x[51] = "aK|\u0004pu;Gi{佄桝佝使栝厸佄桝參栻\u0004\u001ap<\u007fK5@|)";
      x[52] = "\\fx^u\u0004\u0006jm!佁栬叾栖栙佼叟栬叾双\u0000@uMBf1\u001ayX";
      x[53] = "A*VQFUPk@*伫株栢伇叧叩桯台栢桃$A\u001cC\u000bgYA\f\nY";
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何树树何树树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = x[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(y[var4]);
            x[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何树树何树树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = d(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static int d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20080;
      if (o[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = n[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])p.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            p.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何树树何树树何何", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         o[var3] = var15;
      }

      return o[var3];
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何树树何树树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 196 && var8 != 'V' && var8 != 'Y' && var8 != 231) {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'x') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'N') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 196) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'V') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'Y') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (y[var4] != null) {
         return var4;
      } else {
         Object var5 = x[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 41;
               case 1 -> 34;
               case 2 -> 29;
               case 3 -> 56;
               case 4 -> 25;
               case 5 -> 14;
               case 6 -> 63;
               case 7 -> 11;
               case 8 -> 36;
               case 9 -> 50;
               case 10 -> 18;
               case 11 -> 42;
               case 12 -> 31;
               case 13 -> 15;
               case 14 -> 44;
               case 15 -> 46;
               case 16 -> 6;
               case 17 -> 30;
               case 18 -> 21;
               case 19 -> 9;
               case 20 -> 2;
               case 21 -> 4;
               case 22 -> 39;
               case 23 -> 37;
               case 24 -> 40;
               case 25 -> 60;
               case 26 -> 3;
               case 27 -> 32;
               case 28 -> 54;
               case 29 -> 20;
               case 30 -> 28;
               case 31 -> 49;
               case 32 -> 10;
               case 33 -> 53;
               case 34 -> 22;
               case 35 -> 61;
               case 36 -> 17;
               case 37 -> 12;
               case 38 -> 43;
               case 39 -> 5;
               case 40 -> 19;
               case 41 -> 59;
               case 42 -> 13;
               case 43 -> 52;
               case 44 -> 58;
               case 45 -> 35;
               case 46 -> 48;
               case 47 -> 62;
               case 48 -> 26;
               case 49 -> 47;
               case 50 -> 45;
               case 51 -> 27;
               case 52 -> 33;
               case 53 -> 16;
               case 54 -> 55;
               case 55 -> 57;
               case 56 -> 23;
               case 57 -> 38;
               case 58 -> 0;
               case 59 -> 51;
               case 60 -> 8;
               case 61 -> 7;
               case 62 -> 24;
               default -> 1;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            y[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      if (var5 instanceof String) {
         String var6 = y[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         x[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void o(PoseStack poseStack) {
      HUD.A();
      if (this.树何友友何树树树树友 != null) {
         this.x(poseStack, "", this.友何何何何何友何树树, this.树何何何何友何友何友, this.j(0));
         if (!this.何友树树友树友友树何 && this.何树树友何树友友树友 != 友友何树树何树树何何.何何何友友何友树何友.友树友友何何友友友何 && this.何友友友树友何友树何 > 0.0F) {
            int i = 1;
            if (this.何树树友何树友友树友 == 友友何树树何树树何何.何何何友友何友树何友.何树友树树何友树友友) {
               float progress = (float)this.何树树树树何树友何友.D(new Object[]{124111691745592L});
               float startX = this.树何树树树友何何何何[0];
               float startY = this.树友何树树树何友何友[0];
               float targetAngle = (float)Math.toRadians(0.0);
               float targetX = this.友何何何何何友何树树 + 35.0F * (float)Math.cos(targetAngle);
               float targetY = this.树何何何何友何友何友 + 35.0F * (float)Math.sin(targetAngle);
               float var10000 = startX + (targetX - startX) * progress;
               var10000 = startY + (targetY - startY) * progress;
               Math.min(1.0F, progress * 2.0F);
            }

            if (this.何树树友何树友友树友 == 友友何树树何树树何何.何何何友友何友树何友.友友何树友树友树树何) {
               float angle = (float)Math.toRadians(0.0F + this.友何树树何何树树树友);
               float var23 = this.友何何何何何友何树树 + this.何友友友树友何友树何 * (float)Math.cos(angle);
               var23 = this.树何何何何友何友何友 + this.何友友友树友何友树何 * (float)Math.sin(angle);
               var23 = 1.0F - (float)this.友树何树树何何友何何.D(new Object[]{124111691745592L});
            }

            float angle = (float)Math.toRadians(0.0F + this.友何树树何何树树树友);
            float x = this.友何何何何何友何树树 + this.何友友友树友何友树何 * (float)Math.cos(angle);
            float y = this.树何何何何友何友何友 + this.何友友友树友何友树何 * (float)Math.sin(angle);
            float alpha = Math.min(1.0F, this.何友友友树友何友树何 / 35.0F);
            int color = this.S(this.j(1), alpha);
            this.x(poseStack, "", x, y, color);
            i++;
         }
      }
   }

   private void o() {
      this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.友树友友何何友友友何;
      this.何友友友树友何友树何 = 0.0F;
      this.友何树树何何树树树友 = 0.0F;
      this.何友树树友树友友树何 = false;
      this.何树友树树树树何友何 = 0L;
      this.u();
   }

   private void p() {
      double speed = this.友友树树树友何树友树.getValue().doubleValue();
      int expandDuration = (int)(800.0 / speed);
      int rotateDuration = (int)(2000.0 / speed);
      int contractDuration = (int)(600.0 / speed);
      int collectDuration = (int)(1200.0 / speed);
      int releaseDuration = (int)(1000.0 / speed);
      this.友友友树友何何何树何 = new 何友友友树何何友树何(expandDuration, 47697109727437L, 1.0);
      this.何树树何友友树友树树 = new 树友树何树树何树树何(37618987749219L, contractDuration, 1.0, 1.5F);
      this.树树树何何何何何树何 = new 树何何树友友树何友友(72395284945359L, rotateDuration, 360.0);
      this.何树树树树何树友何友 = new 何友友何何友何友友何(collectDuration, 16923, 1.0, 47854, '溑');
      this.友树何树树何何友何何 = new 何友友友树何何友树何(releaseDuration, 47697109727437L, 1.0);
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = y[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         x[var4] = var21;
         return var21;
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private int j(int index) {
      int[] colors = new int[]{-65536, -29696, -10496, -13447886, -16724271, -12490271, -6737204};
      return colors[index % colors.length];
   }

   public void u() {
      HUD.A();
      if (this.何树树友何树友友树友 == 友友何树树何树树何何.何何何友友何友树何友.友树友友何何友友友何) {
         this.p();
         this.何友树树友树友友树何 = false;
         String var8 = this.树何树友树何树友树何.getValue();
         byte var9 = -1;
         switch (var8.hashCode()) {
            case -1776693134:
               if (!var8.equals("Classic")) {
                  break;
               }

               var9 = 0;
            case -1539719193:
               if (!var8.equals("Release")) {
                  break;
               }

               var9 = 1;
            case -1680869110:
               if (!var8.equals("Collect")) {
                  break;
               }

               var9 = 2;
            case 65579206:
               if (var8.equals("Cycle")) {
                  var9 = 3;
               }
         }

         switch (var9) {
            case 0:
            case 1:
               this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.何树何何何友何友友何;
               this.友友友树友何何何树何.L(new Object[]{49833953704096L});
               this.友友友树友何何何树何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
            case 2:
            case 3:
               this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.何树友树树何友树友友;
               this.何树树树树何树友何友.L(new Object[]{49833953704096L});
               this.何树树树树何树友何友.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
               this.E();
         }
      }
   }

   private void E() {
      HUD.A();
      int i = 0;
      float angle = (float)Math.toRadians(0.0);
      this.树何树树树友何何何何[0] = this.友何何何何何友何树树 + 80.0F * (float)Math.cos(angle);
      this.树友何树树树何友何友[0] = this.树何何何何友何友何友 + 80.0F * (float)Math.sin(angle);
      i++;
   }

   @EventTarget
   public void L(Render2DEvent event) {
      HUD.A();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.树何友友何树树树树友 == null) {
            this.树何友友何树树树树友 = Cherish.instance.t().H(20);
         }

         this.友何何何何何友何树树 = super.友友何树何何何友友何 + super.树友树何树何友何树何 / 2.0F;
         this.树何何何何友何友何友 = super.何树树友友何树何何友 + super.何何树树树何何树友树 / 2.0F;
         this.L();
         if (this.何友树树友树友友树何 && System.currentTimeMillis() >= this.何树友树树树树何友何) {
            this.o();
         }

         this.o(event.poseStack());
         this.S(event.poseStack());
      }
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private void L() {
      HUD.A();
      if (!this.何友树树友树友友树何) {
         switch (友友何树树何树树何何$何友树树树友树树何树.树树树友树树友树友何[this.何树树友何树友友树友.ordinal()]) {
            case 1:
               this.何友友友树友何友树何 = 35.0F * (float)this.何树树树树何树友何友.D(new Object[]{124111691745592L});
               if (!this.何树树树树何树友何友.U(new Object[]{108461126752643L})) {
                  break;
               }

               if (this.树何树友树何树友树何.K("Collect")) {
                  this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.友树友友何何友友友何;
                  this.H();
               }

               this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.何树何何树友何树友树;
               this.树树树何何何何何树何.L(new Object[]{49833953704096L});
               this.树树树何何何何何树何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
            case 2:
               this.何友友友树友何友树何 = (float)(35.0 * this.友友友树友何何何树何.D(new Object[]{124111691745592L}));
               if (!this.友友友树友何何何树何.U(new Object[]{108461126752643L})) {
                  break;
               }

               if (this.树何树友树何树友树何.K("Release")) {
                  this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.友友何树友树友树树何;
                  this.友树何树树何何友何何.L(new Object[]{49833953704096L});
                  this.友树何树树何何友何何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
               }

               this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.何树何何树友何树友树;
               this.树树树何何何何何树何.L(new Object[]{49833953704096L});
               this.树树树何何何何何树何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
            case 3:
               this.友何树树何何树树树友 = (float)this.树树树何何何何何树何.D(new Object[]{124111691745592L});
               if (!this.树树树何何何何何树何.U(new Object[]{108461126752643L})) {
                  break;
               }

               if (this.树何树友树何树友树何.K("Classic")) {
                  this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.友友何树何何何友友何;
                  this.何树树何友友树友树树.L(new Object[]{49833953704096L});
                  this.何树树何友友树友树树.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
               }

               if (this.树何树友树何树友树何.K("Cycle")) {
                  this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.友友何树友树友树树何;
                  this.友树何树树何何友何何.L(new Object[]{49833953704096L});
                  this.友树何树树何何友何何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
               }

               this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.友树友友何何友友友何;
               this.H();
            case 4:
               this.何友友友树友何友树何 = (float)(35.0 * (1.0 - this.何树树何友友树友树树.D(new Object[]{124111691745592L})));
               if (!this.何树树何友友树友树树.U(new Object[]{108461126752643L})) {
                  break;
               }

               this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.树树何友树何树友友树;
               this.友友友树友何何何树何.L(new Object[]{49833953704096L});
               this.友友友树友何何何树何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
            case 5:
               this.何友友友树友何友树何 = (float)(35.0 * this.友友友树友何何何树何.D(new Object[]{124111691745592L}));
               if (!this.友友友树友何何何树何.U(new Object[]{108461126752643L})) {
                  break;
               }

               this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.友树友友何何友友友何;
               this.H();
            case 6:
               float releaseProgress = (float)this.友树何树树何何友何何.D(new Object[]{124111691745592L});
               this.何友友友树友何友树何 = 35.0F + 50.0F * releaseProgress;
               if (this.友树何树树何何友何何.U(new Object[]{108461126752643L})) {
                  this.何树树友何树友友树友 = 友友何树树何树树何何.何何何友友何友树何友.友树友友何何友友友何;
                  this.H();
               }
         }
      }
   }

   @Override
   public void M() {
      this.树何友友何树树树树友 = Cherish.instance.t().H(20);
      this.o();
   }

   private void H() {
      this.何树友树树树树何友何 = System.currentTimeMillis() + 500L;
      this.何友树树友树友友树何 = true;
   }

   private static String HE_JIAN_GUO() {
      return "解放村多种2队1144号";
   }

   private static enum 何何何友友何友树何友 implements  {
      友树友友何何友友友何,
      何树友树树何友树友友,
      何树何何何友何友友何,
      何树何何树友何树友树,
      友友何树何何何友友何,
      友友何树友树友树树何,
      树树何友树何树友友树;

      private static final long a;
      private static final Object[] b = new Object[11];
      private static final String[] c = new String[11];
      private static String HE_JIAN_GUO;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-4670723863839065551L, -1647801132448867667L, MethodHandles.lookup().lookupClass()).a(100513510054794L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(136317424369200L << var2 * 8 >>> 56);
         }

         var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[7];
         int var6 = 0;
         String var5 = "·¤\u001b\u0001´ÍQ%û°@#ØÕþ9\u0010!r<[\u0002ß\f\u0091\u000fþF\u0017otdA\u0010y¥AºWÏ\u008d6\u0003ÛznIk R\u0010y¥AºWÏ\u008d6*¸\u001a\u0096\\dJï\u0010ôecÿx&cÙ\u008au!5S\u0014£\u009f";
         byte var7 = 84;
         char var4 = 16;
         int var9 = -1;

         label28:
         while (true) {
            String var11 = var5.substring(++var9, var9 + var4);
            byte var10001 = -1;

            while (true) {
               String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var17;
                     if ((var9 += var4) >= var7) {
                        友树友友何何友友友何 = new 友友何树树何树树何何.何何何友友何友树何友();
                        何树友树树何友树友友 = new 友友何树树何树树何何.何何何友友何友树何友();
                        何树何何何友何友友何 = new 友友何树树何树树何何.何何何友友何友树何友();
                        何树何何树友何树友树 = new 友友何树树何树树何何.何何何友友何友树何友();
                        友友何树何何何友友何 = new 友友何树树何树树何何.何何何友友何友树何友();
                        友友何树友树友树树何 = new 友友何树树何树树何何.何何何友友何友树何友();
                        树树何友树何树友友树 = new 友友何树树何树树何何.何何何友友何友树何友();
                        return;
                     }

                     var4 = var5.charAt(var9);
                     break;
                  default:
                     var0[var6++] = var17;
                     if ((var9 += var4) < var7) {
                        var4 = var5.charAt(var9);
                        continue label28;
                     }

                     var5 = "UÊñ#\nc\u0088\u0002ø²qP¬?\u0084\"\bW½i\u0092³ð4ÿ";
                     var7 = 25;
                     var4 = 16;
                     var9 = -1;
               }

               var11 = var5.substring(++var9, var9 + var4);
               var10001 = 0;
            }
         }
      }

      public static 友友何树树何树树何何.何何何友友何友树何友[] I() {
         return (友友何树树何树树何何.何何何友友何友树何友[])树树友友友树何何树何.clone();
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'Y' && var8 != 255 && var8 != 234 && var8 != 192) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 209) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 248) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'Y') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 255) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 234) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友友何树树何树树何何$何何何友友何友树何友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 61;
                  case 1 -> 10;
                  case 2 -> 37;
                  case 3 -> 46;
                  case 4 -> 39;
                  case 5 -> 49;
                  case 6 -> 34;
                  case 7 -> 58;
                  case 8 -> 53;
                  case 9 -> 11;
                  case 10 -> 38;
                  case 11 -> 17;
                  case 12 -> 56;
                  case 13 -> 6;
                  case 14 -> 27;
                  case 15 -> 31;
                  case 16 -> 52;
                  case 17 -> 41;
                  case 18 -> 22;
                  case 19 -> 30;
                  case 20 -> 50;
                  case 21 -> 0;
                  case 22 -> 5;
                  case 23 -> 51;
                  case 24 -> 35;
                  case 25 -> 57;
                  case 26 -> 24;
                  case 27 -> 54;
                  case 28 -> 28;
                  case 29 -> 32;
                  case 30 -> 15;
                  case 31 -> 14;
                  case 32 -> 62;
                  case 33 -> 29;
                  case 34 -> 25;
                  case 35 -> 42;
                  case 36 -> 33;
                  case 37 -> 12;
                  case 38 -> 40;
                  case 39 -> 4;
                  case 40 -> 16;
                  case 41 -> 55;
                  case 42 -> 26;
                  case 43 -> 47;
                  case 44 -> 36;
                  case 45 -> 7;
                  case 46 -> 9;
                  case 47 -> 63;
                  case 48 -> 1;
                  case 49 -> 20;
                  case 50 -> 19;
                  case 51 -> 23;
                  case 52 -> 59;
                  case 53 -> 3;
                  case 54 -> 43;
                  case 55 -> 13;
                  case 56 -> 21;
                  case 57 -> 8;
                  case 58 -> 60;
                  case 59 -> 44;
                  case 60 -> 45;
                  case 61 -> 48;
                  case 62 -> 18;
                  default -> 2;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "l-P?YScm\u001d4SNf0\u0016r[Sk6\u00129\u0018Ub3\u0012rRU|3\u0012=O\u0012叄厈伫桍栧佩栞桒伫伉\u0012佩佚伖厵厗佣号栞伖厵";
         b[1] = "%|~\u001cJM\u0011_q\\\u0007F\u001bBt\u0001\f\u0000\u0013_y\u0007\bKPYp\u0002\b\u0000\u001aYn\u0002\bO\u0007\u001e取厹伱栿桯佥栌档伱佻Z佥佈伧厯句伫叻栌伧厯\u0015";
         b[2] = "c@\n[GKhO\u001b\u0014&EcD\u001fN";
         b[3] = "@H QJiNI}n栯桌伣叴桛伳栯厖厽栮BPI7AK~^Hj";
         b[4] = "i\"\r|?Yg#PC伞桼伊伀桶厀伞桼厔桄o}<\u0007h!Ss=Z";
         b[5] = "\u001eL\u001csax\u0010MAL佀桝佽佮伣厏佀厇口佮~rb&\u001fOB|c{";
         b[6] = "Ey#/k+Kx~\u0010栎栎厸叅厂栉佊佊桢佛A)/x\u001d\u007f+zrg\u0007";
         b[7] = ">\u0002S\u0006P&0\u0003\u000e9可栃參厾佬佤可叙參传1\u0007Sx?\u0001\r\tR%";
         b[8] = "\u0002{$\u0015xz\fzy*余桟叿栝桟佷叇桟叿叇F\u0014{$\u0003xz\u001azy";
         b[9] = "mMJC\u0019HcL\u0017|厦厷伎栫叫桥厦桭桊佯(B\u001a\u0016lN\u0014L\u001bK";
         b[10] = "v1nc\u0005\u000ex03\\厺叱伕桗佑企伤叱压伓\fb\u0006Pw20l\u0007\r";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public static 友友何树树何树树何何.何何何友友何友树何友 P(String name) {
         return Enum.valueOf(友友何树树何树树何何.何何何友友何友树何友.class, name);
      }

      private static String HE_DA_WEI() {
         return "何炜霖国企变私企";
      }
   }
}
