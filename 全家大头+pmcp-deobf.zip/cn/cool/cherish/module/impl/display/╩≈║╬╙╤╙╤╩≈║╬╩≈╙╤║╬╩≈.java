package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何何友何何友何何树树;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.ui.何树树友树树友树友树;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.value.树何何何友树树何友何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import cn.cool.cherish.value.impl.树友何友何何友树树友;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树何友友树何树友何树 extends Module implements 何树友 {
   public static 树何友友树何树友何树 树何友何友友何友何何;
   public HttpServer 树何树友树何友树何何;
   public NumberValue 何树树树友树友友友树;
   public BooleanValue 何树何何友何何友何友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[20];
   private static final String[] l = new String[20];
   private static int _何炜霖大狗叫 _;

   public 树何友友树何树友何树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/display/树何友友树何树友何树.a J
      // 03: ldc2_w 37273602650334
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 25935
      // 0c: ldc2_w 4907796075123837752
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 7511
      // 19: ldc2_w 7725378014965068588
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w -7213956800336029915
      // 26: lload 1
      // 27: invokedynamic ó (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/NumberValue
      // 33: dup
      // 34: sipush 26638
      // 37: ldc2_w 7761430272492603000
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 16026
      // 44: ldc2_w 4033739806386442467
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: sipush 8080
      // 51: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 54: sipush 1024
      // 57: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5a: getstatic cn/cool/cherish/module/impl/display/树何友友树何树友何树.j J
      // 5d: l2i
      // 5e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 61: bipush 1
      // 62: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 65: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 68: ldc2_w -7213292787331431720
      // 6b: lload 1
      // 6c: invokedynamic m (Ljava/lang/Object;Lcn/cool/cherish/value/impl/NumberValue;JJ)V bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 71: aload 0
      // 72: new cn/cool/cherish/value/impl/BooleanValue
      // 75: dup
      // 76: sipush 23769
      // 79: ldc2_w 2659337079878103721
      // 7c: lload 1
      // 7d: lxor
      // 7e: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 83: sipush 10423
      // 86: ldc2_w 8111349572255663812
      // 89: lload 1
      // 8a: lxor
      // 8b: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 90: bipush 1
      // 91: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 94: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 97: ldc2_w -7213251100058169717
      // 9a: lload 1
      // 9b: invokedynamic m (Ljava/lang/Object;Lcn/cool/cherish/value/impl/BooleanValue;JJ)V bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // a0: aload 0
      // a1: ldc2_w -7214119000183824918
      // a4: lload 1
      // a5: invokedynamic T (Lcn/cool/cherish/module/impl/display/树何友友树何树友何树;JJ)V bsm=cn/cool/cherish/module/impl/display/树何友友树何树友何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // aa: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1826304816586767355L, -3863161481099946540L, MethodHandles.lookup().lookupClass()).a(170331626628150L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var5 = a ^ 44075783779480L;
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(var5 << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[13];
      int var12 = 0;
      String var11 = "×C´¸nû\u0094\n¦Æ^\u0001\u007f;T\u008f\u0010àLGÈsBï\u0015é¼\u001cýÂ\u001a\u0091\u0092G\rÙÅ\\O!Õ¿|¢ämôR(X\u0097\u0001ka\u0083 \u008dåw\u001fì\u001c\u008f\u000ebÎsX½òK\u0090Qã\u000fzc\u0005ë\u0015\u0014\u008cÖ\u008cõ\u0097£u« \u0005ç\u0015z\u000eOão,T\u008dÛ}\u001f\u00944\"¨«)\u008cíE\"¨±RfúË\u0006À8W^ôW\u0005bóñÆ(ç5\u0018äaC\nR«sB\u0080|BåóÐ§>\u0013\u009d\u00853I\u00ad©\u0084©^\u0089¥\u0000þÏ:ôÄ6\u0015=·m5\u008e`Æ\u0010ï¶>E+\u001d\u0087ì!Ü\u0002\u0007Z\b`/H/áRØ\u0015dÑ\nÿ;.Ï2?ãE\u00ad\u0096[^\u0088õ{\u0005øWÒ\u009e&¸ªQ\u008eRs\u0010\u0019§\u001b!²Òmÿ\u0091¿HÕ¬gë\u000e,\u0083l\u0018\u0005µò\u0004&¼!;+q3à`4\u008d¾ r\u009a\u0013^ç\u001c±Þ\b¥ÞÌhô7\u0089¶8NÃpJ³z²Â+wÞlÉ#\u0010µ«\u0084ò\u008eT\u0084\u0007½\u0006\u001a,\u0001Ð$Î\u0010r\u0017Ë5ï××\u0000`Ùî)ºci·\u0018\u0002C¥'*_5\u0098ñÅ^ñé\u0019\u0097¹*\u0092\u0014\u0007ÎÊy\"\u0018\u0099\u0097ä»\u0088\u0016\u0099\u0080´Þ%N³8\u009d1]V\u0082!<}ìØ";
      short var13 = 386;
      char var10 = '0';
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[13];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var5 << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-102, -20, -107, 97, -50, 32, -56, 64});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "Ã\u0097ý\u008e\u0003ò\u0012'\u0018\u0019ÐM\u0019e×\u0098idÆ\u0003ETø\u0019\u0010w®\u000f-\\0[©jÓ\u0003\u0018¿*\u0099\u009a";
                  var13 = 41;
                  var10 = 24;
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   protected void F() {
      long a = 树何友友树何树友何树.a ^ 3660741918410L;
      long ax = a ^ 37971359923258L;
      c<"û">(6192650438206906281L, a);
      if (c<"p">(this, 6192948668984223680L, a) != null) {
         c<"p">(this, 6192948668984223680L, a).stop(0);
         String message = b<"e">(2805, 1943336998592522896L ^ a);
         ClientUtils.e(new Object[]{message, ax});
         if (c<"p">(this, 6192802317917913247L, a).getValue()) {
            何树树友树树友树友树.S(c<"ó">(6194317880167123739L, a), b<"e">(11979, 959165793927171749L ^ a), message, 3.0F);
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 26;
               case 1 -> 41;
               case 2 -> 55;
               case 3 -> 25;
               case 4 -> 24;
               case 5 -> 57;
               case 6 -> 0;
               case 7 -> 44;
               case 8 -> 23;
               case 9 -> 46;
               case 10 -> 35;
               case 11 -> 61;
               case 12 -> 56;
               case 13 -> 18;
               case 14 -> 31;
               case 15 -> 38;
               case 16 -> 14;
               case 17 -> 11;
               case 18 -> 6;
               case 19 -> 1;
               case 20 -> 54;
               case 21 -> 2;
               case 22 -> 5;
               case 23 -> 51;
               case 24 -> 50;
               case 25 -> 19;
               case 26 -> 40;
               case 27 -> 30;
               case 28 -> 59;
               case 29 -> 33;
               case 30 -> 15;
               case 31 -> 37;
               case 32 -> 10;
               case 33 -> 32;
               case 34 -> 16;
               case 35 -> 39;
               case 36 -> 42;
               case 37 -> 12;
               case 38 -> 17;
               case 39 -> 58;
               case 40 -> 22;
               case 41 -> 48;
               case 42 -> 9;
               case 43 -> 53;
               case 44 -> 43;
               case 45 -> 49;
               case 46 -> 7;
               case 47 -> 3;
               case 48 -> 52;
               case 49 -> 47;
               case 50 -> 20;
               case 51 -> 60;
               case 52 -> 8;
               case 53 -> 63;
               case 54 -> 62;
               case 55 -> 34;
               case 56 -> 13;
               case 57 -> 29;
               case 58 -> 45;
               case 59 -> 4;
               case 60 -> 28;
               case 61 -> 21;
               case 62 -> 36;
               default -> 27;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 30103;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'p' && var8 != 'm' && var8 != 243 && var8 != 'T') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 234) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 251) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'p') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'm') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 243) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "q8\u000f^\rK~xBU\u0007V{%I\u0013\u000fKv#MXLM\u007f&M\u0013\u0006Ma&M\\\u001b\n栃伃只叶桳佱栃厝佴栬";
      k[1] = "\u0018~U\\\u0016\u0018\u0017>\u0018W\u001c\u0005\u0012c\u0013\u0011\u000f\u0016\u0017e\u001e\u0011\u0010\u001a\u000b|Uq\f\u001a\u0019u\ti\u0018\u001b\u000eu";
      k[2] = "y\u001d,\u0014\u0012\u0011v]a\u001f\u0018\fs\u0000jY\u0010\u0011~\u0006n\u0012S伫住厸佗伢厶伫住桢栓";
      k[3] = "BvKT8@M6\u0006_2]Hk\r\u0019!NMm\u0000\u0019>BQtKu8@M}\u0004Y\u0001NMm\u0000";
      k[4] = "FHsK?;MGb\u0004T/OLu^x8B";
      k[5] = "4\u001c2_\u0005\u0002;\\\u007fT\u000f\u001f>\u0001t\u0012\u0007\u00023\u0007pYD\u0004:\u0002p\u0012\u000e\u0004$\u0002p]\u0013C\u001f'X";
      k[6] = "\u0003s";
      k[7] = "Q\u00189I\\?\\Y:\u0002[dZ\u0003 \u0017\\/@\u00011\u0015\u0001\u0002F\u0003$4J8D\u0012&";
      k[8] = "MOCg2yB\u000f\u000el8dGR\u0005*(\u007f\u0000栰桼叏伈佃佻只厦栕伈";
      k[9] = "n}\b}a\u0002er\u00192\u0000\fny\u001dh";
      k[10] = "_\u0000\u001cpZS\b\u0001@jkzdFFiZO\u0002@I{U\"";
      k[11] = "Qc?U\u000f}\b'3Os叞桵叞原栧厰佀厯栄原>Nc\u000fv ^\u0017'\u0003l";
      k[12] = "K_\rNgx\u0010L\u0012\"体栃档栥厾栻反叙厹栥}SgaG]\u0017]lu";
      k[13] = "r*49}5)9+U佉桎伞伔厇伈佉厔伞厊Dow9'y/%f8x";
      k[14] = "\u000fH\u001b\u0011A|T[\u0004}A\u001e\u0005F\n\u0004O&XM\u0016\u0010(%SJ\u0012\u001a\u0010xXV\u0006}";
      k[15] = "o\u001b(\u0005Ti4\b7i栤佖桇去桁伴叾栒伃伥XT\u0006pcGf\u0012Tlo";
      k[16] = ">MV\u007fM5g\tZe1桌佞佮栬栍栨桌叀佮叶\u0014\f+`XItUolB";
      k[17] = "W&_b\u000f\u0004\f5@\u000e桿伻厥优召反伻厥伻优/?\u0005\u0016\n,Md\u0016\t";
      k[18] = "#x\u00131S;z<\u001f+/伆佃栟厳桃栶桂叝栟厳Z\u0012%}m\f:Kaqw";
      k[19] = "~\u0002fY]6 \bbCm佚桞厮桂佧桴佚会桴厘:Thz\u000ek\u000b\nb~\u0014";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 树何友友树何树友何树.a ^ 75909790268717L;
      long ax = a ^ 110872706334685L;
      c<"û">(-7631366486349538226L, a);
      if (c<"ó">(-7633275837698502631L, a) != null && this.isEnabled()) {
         try {
            int port = c<"p">(this, -7631815206486405333L, a).getValue().intValue();
            c<"m">(this, HttpServer.create(new InetSocketAddress(b<"e">(14254, 276907177708770336L ^ a), port), 0), -7631771374060198873L, a);
            c<"p">(this, -7631771374060198873L, a).createContext(b<"e">(23666, 6322659563948359668L ^ a), new 树何友友树何树友何树.树友友友何友友友树何());
            c<"p">(this, -7631771374060198873L, a).createContext("/", new 树何友友树何树友何树.友何何何何友树何友树());
            c<"p">(this, -7631771374060198873L, a).setExecutor(Executors.newFixedThreadPool(3));
            c<"p">(this, -7631771374060198873L, a).start();
            String message = b<"e">(28777, 938672974540116974L ^ a) + port;
            ClientUtils.e(new Object[]{message, ax});
            if (c<"p">(this, -7631905114972011656L, a).getValue()) {
               何树树友树树友树友树.S(c<"ó">(-7631454588784780761L, a), b<"e">(5599, 5078911891330004564L ^ a), message, 3.0F);
            }
         } catch (IOException var8) {
            String messagex = b<"e">(24095, 3772956233481305502L ^ a) + var8.getMessage();
            ClientUtils.e(new Object[]{messagex, ax});
            if (c<"p">(this, -7631905114972011656L, a).getValue()) {
               何树树友树树友树友树.S(c<"ó">(-7633247525615376621L, a), b<"e">(11979, 959234196429196610L ^ a), messagex, 3.0F);
            }

            this.y(false);
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_JIAN_GUO() {
      return "何树友被何大伟克制了";
   }

   private static class 友何何何何友树何友树 implements HttpHandler, 何树友 {
      private static final long a;
      private static final String[] b;
      private static final String[] c;
      private static final Map d = new HashMap(13);
      private static final long e;
      private static final Object[] f = new Object[10];
      private static final String[] g = new String[10];
      private static String HE_DA_WEI;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-6534314951984234311L, -3922249368378273379L, MethodHandles.lookup().lookupClass()).a(254874724445042L);
         // $VF: monitorexit
         a = var10000;
         a();
         long var5 = a ^ 56383734875324L;
         Cipher var7;
         Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var8 = 1; var8 < 8; var8++) {
            var10003[var8] = (byte)(var5 << var8 * 8 >>> 56);
         }

         var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var14 = new String[31];
         int var12 = 0;
         String var11 = "\\3í×0\u000fSÞ,×Lk},G4×4neltÄ#µIqyF\"UÓ8$zhh\u0018t[\u0082\u0014#f¯\u001d¦\"*>gÔ\u000faW\u0012\u0015\u0001¿*mê«\u0088àYk\u0088Ù{;æÁ\u0095i-¡Ó¿\u0017\u0092¶Ä\u008eK,é\u0087ã\u0010G+BO_ Fê\u000bßId¤\u0010íé0\u0010¼\u0096*®jùþAòû\u0018=12÷\u00805ªTÅv/M\u009euø\u009ap\u000fPÞîJ\t°%\u001d~¼W6\u009c=í¸M\u0013\u0010Só\u0098*S¸GÀ5Iá\u0006ñôÕ\t\u0010\\\u0087 óµ¸\u008c+O8\u0080\u008cü\u0090(\u0088 ¬\bLèñæ5(½\u001c¹Ð\u001e\u0019ôô\t|Ó±F\bäâIÝ\u0001rJ56Ý\u0010Ï\u0099xV3t\\í¨n¤&l*õ\u0095(\u0010\u0002D\u009aÚµà\u0014Ý\u0016Xó¨×\u0087ñ<ÒÍ@&ü/aú@ø>B\u0081vf\u00804Búà\u0096\u0089/8HÄèca×\u0081v¢ ÖÍ\u0004##VÈJ\u0095\u0084ÝÙõNí\u0081taª¡G@¢\u001c\u0011ÏWS\u001b\u0084ú\u007f®ÎWüs.º¸àc\u00ad\u0001ãb W×ðFí±S\t\u0081}>þÈÇ8ÒãpPwZ;RÛ7°ñ{WëK\u0003 Z^\u000f÷\u0014?\u0007ó\fÀJO±\u0099¶\u0096òä8(Y<\u0090cõx¾s\u008br#Í\u0010ÕM\r\u00013\u0094ø\u0093\u0093Ñm:ä|±&\u0010=\u001aÀ\u0082d¿úU¹\u0091:TI\u008f\u0091û\u0018,ø¨\u001b!\u0080ê\u001aTPXP\u0093êþ¸\u0099þÕ\u0096Ð:\u0017ç\u0010\u0085\u009aýTP\u0006EQ,%¶å\u0094%jÞ\u0010\u0087ë\u0002mÜ\u008b\u001ef\n\u001a\u0080°2íT©8b\u008e=·\u0012éÒÙaæ\u0089p\u0091\u008f\u0003\u009d,âíX\by\u009c1K2+Ë\u0005\u0011¦\u0003æàÅ\u0013ª=±û&Rw¼³³ä\u0019\u00ad6yç£í4\u0006\u0010\u0090\u0010R\u0088µ\u001fù\u009d\u0080\u0091\u001a±zX\u0006Ï0è\u008aÍ\u00ad\u009e\u001e~£\u001dê\u0006\u009c´¾8¡aÛ À\u0087mfëzxaïáús©ð\u0094«\u009e9ÑO\"Ï*+ír\u0013[]\u0010+\u0018âñ!\\ Lº§\u008d\u008d\u0096\u0093A\t([\u0086Èà\u001c\u0002Ö¬j)#\rÖÇçj-\u0013Àäî\u008aË±\u009aÀ\u009df\u0011ûõö\n\u0004Æ,\u008büT'0y1\u0099½©d¯;LËj£lÍ\u001eåÉãzw\u0095\r\t{µÂ\u0013M÷Å\u0080µ¾Km\u0091ò\u000e\"\u001c;7A?|Ï±M Mo÷ÕË<\u0098_B\u0012\u0090ò\u009bK%\u0099üÍFYÍ6í\u001f\u0017\u0097îL>íE\u001b \u0004¶\u009e\u0014ßíëîL\u0086\u0091+\u008fv\u0005\u007fé¼ØMè\u0003Ñ\u0005å8vÍ\u008fÉ\u000f¬\u0010\u0092à\u009f\u0007-[·vAÄ¯Ç\u0003\u001a\u008cç P\u000e\u007f5Ô\u008fDX¼~\u009a #äàBî\u008a,\u0084H¡\u0083É·\u008cà\nWÙ\u0007\u0013(\u0017\u001að\u0086Á\u009c\u0010/À\u0090\u00905z+æ\u001a¿ªPJ÷»`Ô\tôTÛÆôþ\u001c3&×Úáu°Ý\u0018\u009b)¿\bF\u0086¢e\u0090/\u0001å\u0019WÏ\nãM®«ÝT³B";
         short var13 = 908;
         char var10 = ' ';
         int var16 = -1;

         label37:
         while (true) {
            String var18 = var11.substring(++var16, var16 + var10);
            byte var10001 = -1;

            while (true) {
               String var26 = a(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var14[var12++] = var26;
                     if ((var16 += var10) >= var13) {
                        b = var14;
                        c = new String[31];
                        Cipher var0;
                        Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                        var10002 = SecretKeyFactory.getInstance("DES");
                        var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                        for (int var1 = 1; var1 < 8; var1++) {
                           var10003[var1] = (byte)(var5 << var1 * 8 >>> 56);
                        }

                        var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                        byte[] var4 = var0.doFinal(new byte[]{-78, 86, 88, -93, 84, 67, 12, 82});
                        long var30 = (var4[0] & 255L) << 56
                           | (var4[1] & 255L) << 48
                           | (var4[2] & 255L) << 40
                           | (var4[3] & 255L) << 32
                           | (var4[4] & 255L) << 24
                           | (var4[5] & 255L) << 16
                           | (var4[6] & 255L) << 8
                           | var4[7] & 255L;
                        var10001 = -1;
                        e = var30;
                        return;
                     }

                     var10 = var11.charAt(var16);
                     break;
                  default:
                     var14[var12++] = var26;
                     if ((var16 += var10) < var13) {
                        var10 = var11.charAt(var16);
                        continue label37;
                     }

                     var11 = "$U\u0004r\u001c¸¯_Ù&8\u0092\u0018\u0087R÷\u0014(mÁ\u0018>Ì\u0002(|\u0005´\u0087-Á\u0084}J-Ãû\u0080Í¾Éz³6pûo\u0012t\u009b\u0001\u0013\u0016L\u008f¿¿\u0007ÂÂ¥\u009aØ\u0016\u0080";
                     var13 = 65;
                     var10 = 24;
                     var16 = -1;
               }

               var18 = var11.substring(++var16, var16 + var10);
               var10001 = 0;
            }
         }
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = f[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(g[var4]);
               f[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static CallSite b(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$友何何何何友树何友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = f[var4];
         if (var5 instanceof String) {
            String var6 = g[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            f[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = g[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            f[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 199 && var8 != 224 && var8 != 'W' && var8 != 233) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 181) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 207) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 199) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 224) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'W') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
         int var4 = (Integer)var3[0];
         long var5 = (Long)var3[1];
         String var7 = a(var4, var5);
         MethodHandle var8 = MethodHandles.constant(String.class, var7);
         var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
         return var7;
      }

      private static String a(int var0, long var1) {
         int var5 = var0 ^ (int)(var1 & 32767L) ^ 5841;
         if (c[var5] == null) {
            Object[] var4;
            try {
               Long var3 = Thread.currentThread().getId();
               Object[] var10000 = (Object[])d.get(var3);
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               d.put(var3, var4);
            } catch (Exception var10) {
               throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$友何何何何友树何友树", var10);
            }

            byte[] var6 = new byte[8];
            var6[0] = (byte)(var1 >>> 56);

            for (int var7 = 1; var7 < 8; var7++) {
               var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
            }

            DESKeySpec var11 = new DESKeySpec(var6);
            SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
            ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
            byte[] var9 = b[var5].getBytes("ISO-8859-1");
            c[var5] = a(((Cipher)var4[0]).doFinal(var9));
         }

         return c[var5];
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static Throwable a(Throwable var0) {
         return var0;
      }

      private static void a() {
         f[0] = "E\"r\u001d\u0002>Jb?\u0016\b#O?4P\u0000>B90\u001bC8K<0P\t8U<0\u001f\u0014\u007f样伙厗厵桼伄样厇伉桯I厚佳伙伉伫厦桀佳厇桍";
         f[1] = "\u0017~o+i\u001e\u001cq~d\u0013\u001a\u000fpn+%\u001e\u0018";
         f[2] = "\u00190\u0006\u007f[q\u0016pKtQl\u0013-@2Yq\u001e+Dy\u001aw\u0017.D2Pw\t.D}M02\u000bl";
         f[3] = "re";
         f[4] = "\u0011[\u0017J=,\u001e\u001bZA71\u001bFQ\u0007'7\u001bYJ\u0007 &\u0001ZL[1&\u0001\u001bkL!,\u0007GZL!\u000e\u0013[XN71";
         f[5] = "d\u0016\u0016\u0011^waY&\u0019\u001c{";
         f[6] = "\b\u001f\u000eh4}\u0003\u0010\u001f'Us\b\u001b\u001b}";
         f[7] = "A{\u0016\u0016FDU|\u0005r\u0015;Q9V\u0002\u000e\u000bS<\u0000r\u0007A\u00103\u001eB\u0005DFC";
         f[8] = "6vBV\u001dknaU\u0018%M\u000f=@\u0005Hovw]QF\u0015";
         f[9] = "-xh\r4y,uk\u0011Uezrk\f/tzr\fJ.$ih=\u000f:!i";
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (g[var4] != null) {
            return var4;
         } else {
            Object var5 = f[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 39;
                  case 1 -> 40;
                  case 2 -> 41;
                  case 3 -> 55;
                  case 4 -> 62;
                  case 5 -> 30;
                  case 6 -> 51;
                  case 7 -> 53;
                  case 8 -> 46;
                  case 9 -> 56;
                  case 10 -> 14;
                  case 11 -> 10;
                  case 12 -> 45;
                  case 13 -> 23;
                  case 14 -> 42;
                  case 15 -> 37;
                  case 16 -> 15;
                  case 17 -> 29;
                  case 18 -> 59;
                  case 19 -> 5;
                  case 20 -> 57;
                  case 21 -> 50;
                  case 22 -> 31;
                  case 23 -> 25;
                  case 24 -> 47;
                  case 25 -> 22;
                  case 26 -> 49;
                  case 27 -> 1;
                  case 28 -> 13;
                  case 29 -> 2;
                  case 30 -> 7;
                  case 31 -> 26;
                  case 32 -> 3;
                  case 33 -> 44;
                  case 34 -> 0;
                  case 35 -> 33;
                  case 36 -> 34;
                  case 37 -> 63;
                  case 38 -> 21;
                  case 39 -> 20;
                  case 40 -> 54;
                  case 41 -> 18;
                  case 42 -> 4;
                  case 43 -> 8;
                  case 44 -> 43;
                  case 45 -> 27;
                  case 46 -> 60;
                  case 47 -> 52;
                  case 48 -> 36;
                  case 49 -> 48;
                  case 50 -> 11;
                  case 51 -> 9;
                  case 52 -> 17;
                  case 53 -> 19;
                  case 54 -> 58;
                  case 55 -> 24;
                  case 56 -> 6;
                  case 57 -> 38;
                  case 58 -> 12;
                  case 59 -> 16;
                  case 60 -> 32;
                  case 61 -> 61;
                  case 62 -> 35;
                  default -> 28;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               g[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$友何何何何友树何友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private void p(HttpExchange exchange, int code, String message) throws IOException {
         long a = 树何友友树何树友何树.友何何何何友树何友树.a ^ 76408859925150L;
         exchange.getResponseHeaders().set(a<"z">(32339, 6676406522728351220L ^ a), a<"z">(15016, 7690158657932574981L ^ a));
         b<"Ï">(7887050131100295075L, a);
         byte[] responseBytes = message.getBytes(StandardCharsets.UTF_8);
         exchange.sendResponseHeaders(code, responseBytes.length);

         try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
         }
      }

      @Override
      public void handle(HttpExchange exchange) throws IOException {
         long a = 树何友友树何树友何树.友何何何何友树何友树.a ^ 3608971859236L;
         exchange.getResponseHeaders().add(a<"z">(8923, 7007195887531431631L ^ a), "*");
         b<"Ï">(2507986540909957145L, a);
         exchange.getResponseHeaders().add(a<"z">(12202, 2244380582017604516L ^ a), a<"z">(27595, 5364972581059846110L ^ a));
         exchange.getResponseHeaders().add(a<"z">(18975, 6624193721477398017L ^ a), a<"z">(14060, 4878911624938095328L ^ a));
         if (exchange.getRequestMethod().equalsIgnoreCase(a<"z">(16044, 6603084721203022524L ^ a))) {
            exchange.sendResponseHeaders(204, 树何友友树何树友何树.友何何何何友树何友树.e);
         } else {
            String path = exchange.getRequestURI().getPath();
            if (path.equals("/")) {
               path = a<"z">(1212, 1954059078683865277L ^ a);
            }

            String fileName = path.substring(1);
            if (fileName.contains(a<"z">(19666, 7691916926979012829L ^ a))) {
               this.p(exchange, 403, a<"z">(1817, 2324109541119800094L ^ a));
            } else {
               try {
                  File file = new File(
                     b<"Ç">(Cherish.getResourcesManager(), 2508055325564380548L, a).getAbsolutePath() + a<"z">(25969, 5356563818674540899L ^ a) + fileName
                  );
                  if (!file.exists()) {
                     this.p(exchange, 404, a<"z">(6044, 2064013801428165527L ^ a) + fileName);
                     return;
                  }

                  String mimeType = this.N(fileName);
                  exchange.getResponseHeaders().set(a<"z">(28207, 8413572716995467818L ^ a), mimeType);
                  exchange.sendResponseHeaders(200, file.length());

                  try (
                     FileInputStream fis = new FileInputStream(file);
                     OutputStream os = exchange.getResponseBody();
                  ) {
                     byte[] buffer = new byte[4096];
                     int count;
                     if ((count = fis.read(buffer)) != -1) {
                        os.write(buffer, 0, count);
                     }
                  }
               } catch (IOException var17) {
                  this.p(exchange, 500, a<"z">(15027, 7607176804957523632L ^ a) + var17.getMessage());
               }
            }
         }
      }

      private String N(String fileName) {
         long a = 树何友友树何树友何树.友何何何何友树何友树.a ^ 82978704851880L;
         b<"Ï">(8377364115510806165L, a);
         if (fileName.endsWith(a<"z">(4157, 1824900764952883872L ^ a))) {
            return a<"z">(3745, 9061074589156338750L ^ a);
         } else if (fileName.endsWith(a<"z">(24692, 7952079362474050272L ^ a))) {
            return a<"z">(29312, 6362289978552553478L ^ a);
         } else if (fileName.endsWith(a<"z">(30868, 4868340194426690055L ^ a))) {
            return a<"z">(31980, 205218508238364264L ^ a);
         } else if (fileName.endsWith(a<"z">(15407, 2313069619272310439L ^ a))) {
            return a<"z">(21067, 6126280523203719361L ^ a);
         } else if (fileName.endsWith(a<"z">(3669, 493891800439811264L ^ a))) {
            return a<"z">(30265, 2598739114739438766L ^ a);
         } else if (fileName.endsWith(a<"z">(24527, 577397334382263641L ^ a)) || fileName.endsWith(a<"z">(28714, 5324912824304538283L ^ a))) {
            return a<"z">(11718, 9126946338881326922L ^ a);
         } else {
            return fileName.endsWith(a<"z">(4032, 6116057790521699653L ^ a)) ? a<"z">(32603, 8316321602696912321L ^ a) : a<"z">(32281, 687383350966754441L ^ a);
         }
      }

      private static String LIU_YA_FENG() {
         return "何炜霖黑水";
      }
   }

   private static class 树友友友何友友友树何 implements HttpHandler, 何树友 {
      private static final long a;
      private static final String[] b;
      private static final String[] c;
      private static final Map d = new HashMap(13);
      private static final long[] e;
      private static final Integer[] f;
      private static final Map g;
      private static final long[] h;
      private static final Long[] i;
      private static final Map j;
      private static final Object[] k = new Object[7];
      private static final String[] l = new String[7];
      private static int _职业技术教育中心学校 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(8862553546950133693L, -4679897053223143526L, MethodHandles.lookup().lookupClass()).a(242048275329588L);
         // $VF: monitorexit
         a = var10000;
         a();
         long var22 = a ^ 86854453528392L;
         Cipher var24;
         Cipher var35 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var22 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var25 = 1; var25 < 8; var25++) {
            var10003[var25] = (byte)(var22 << var25 * 8 >>> 56);
         }

         var35.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var31 = new String[115];
         int var29 = 0;
         String var28 = ":w5×7ûE¼âå;È\u0089\u0098s\u0015\u001c§¶\u000bZ8Ü\u0095Ú\t¶È8ðÚô¾¶ê\u0082Ûxå¦\u0010\u009bì)Â\u0095héhØ¯\u009d%¤ÑÁU\u0018÷\u0015AM!Ã\u0010\u0002\u0089\u007f\u0087ëô\u009a\u0002ÊîH²þMÍr\u00848Ë¨ùæ3\u0014\u008fÓ °·,¶Ç\u0080>Eûä¯Ï¶;Ib>µ\u008aï8õÓõ©§Ìö\u008b\u001eòä\u0005òfKfÀÚt\u009d¬\u00979O\f\u0014`1b\u0016w¤§fI¨zMlµ\u0093§éë·Cr\u009eésÍdÂZIæ\u007f\u000bj\u000f3\u0089H\u0092lÿë\u008c\u001f·Iid\u001eÿ\u009cµs\u000fÝ7µ\f'ùÐiÎ\u001fÊãî\u0005¾n¸¸<°Ë\u0091VhÎ\u0085\u0001EÇÝ\u0010þàB»TF\u0099leöx&Þ\u0010»Jß\u000fì\u0088£\u0093áÆÁ\u00ad¤#\u009dO(y«\u0081ïêK»ÚA\u0004\u0095¢úìx\b«L8Õ\u0081ð\t\u0091\u000b\f\u0006ôsý³«hV$J\u0081çôÔ\u0010XÞ¥û\u001dT\u0007l\u0013}\u007f,ûÓ,¢8î\u0083Å®*ô\fàÈz>\f\u0098\u008f¥¸ülBÉy\u0016n5½êµàÒ# ë»Û×\u009d2íÚâæ2\u0019\u0088ù®R)kÕ¹Ð,àE\u0004\u0018\u0095UQ\u0088\u0095\u0083\u0084î¸Af\u008882R²*\u001dÓËµW±¤ N\u00ad\u0012\u0084EÖÜEÔ]ðÇU°//2ÅØ¾Ýî\u0088\u0004tèÒ¥Q/»Ò rµç\u0083\u0090å ë<\u00140°z\u0082Tø\u0018CE9\u0003\u0004\u0018+lºÂ`ÌP.ú \u00adÈv=\u0014÷Uñ\u008fiREÌ5\\Çö9\u0013Í\u0082Ö½áI2û§C\u0097FÚ8`\u008b[3Bî-\u0080íf\u0001Í#\u001b\u0090ìÄ¦\u001cF;\u009aA\u009eEñ\rjÂÒ|l\u0000Ào\u0085ñ§\u0093c7ª\u0094A'¥ÏöIÍ\u0086¸O²H\u009e\u0018®¹XÁ¡ÿÄ0\u0011#\f\u0006öìd¾ô\u0014³W+\u0081ï·\u0010ë\b \u001dQÛ|\u0087l\u0090\u0011\u0094\u0085h\rØ\u0010$Áü\u0085ùU\u001f\u000eÔ®¶\u000fqúæ·(\u00010Þ³yJ ù@jd\u001bD!%ì\u009eåè«dBG\u0002G¦¾°ï\u0016÷mEãè\u0014\u0001m/·(\u0014\u0015\u008f*þ\u0082\u0005{^\u0098¦ÎnÛûÖ3·\u0090sL\u0080æ}&k\u0096\u0095æ\u0095À«\u0092\u0082\u009aµ6EK\u007f\u0010L\u008bL´ \u008d¬ö×\u000b|'\u0005¦©ö([Ù\u0090ãÎ\\]\u008c\u009auã+X\u0091\u001f\u0015Î\u0092_®¸\u001364Ì\u001fN;Á¸¹Î\u0093\u009f\u0090\u0007\u001bl¹:(C{\u0010±Á¡1àâE\u0098ÄðKó½è]ø9\n6{\u008aY,\u008a³Ú^ß\"\u0085\u001e\u0096A§\u00adÎê\u0018\u009f\u0019x··xdgÇ\u0092\u009d@¬j{G:B\u0012yÍuG=\u0018ëÌË>!\t!\u009dÐË¡q Ø¸Ò\u0000Cä@\u0096²ÐY\u0010ô\u0001ï\"L¾\u00883£\u008f¬^´z\u009b|8\u0015É¶h\u0095éXTrÔ¸\u0089{\u000bÓ¹\u008cû»g\u008f«o\u00158\u008dEÕ·\u0096KA£}W»Ï\u000b÷\u009dBä\u0011M8ig)7\u009eÛEIª\\¿\u0010\\ô( OÜº\u009aîöÚ\u0018\u0091¢Õò\u0010¹¸y÷»\u001aú<3\u0089+ÁÝDÔT`\u007fPñk38q34øQÚ\u0018¥\u001e\u008ew¾ò\u0017@AãÝ\u001ckÄ¼Ö-Ñ \u009e³y!\u0082u\u007fù\u0087-½\u0085¿/!Òi eY1I¤\u009a\u008fÒK¡\u009b%Ç\u0094Ïg\u001bÐc\u008b=ô>\u0002K3\\\f\u0097×àC\t¶7\u0004\u008c5ÙU1»äfe÷\u0010¦\bÁïe\u0019\u00ad±\u0001ó|\t§µ¢y æ\u0013Ð}4\u0016W£\u00112ç0o'Gé\u001bYf\u0097){,«\"\u0001Á´ÁCÄ X\"\u0082\u0086évI³!A \u0085j\u0000\u0090\u0089¬Ê] ±[Ð\u0095]êk\u008b3\u0081üj1\u008d\u008b\u0080ÄL\u0095Áã\fq!n±\u0092ß¿;\u008a6Or\u008e\u0000k(iKMR\b}\u001fè%¤âö«=¡\u0086\u0016Ìw\u009dãpk\u0017ùÖîóÿBÊ\u0010\u000fz\u0003¸ÙD\u00ad\u0094½wùcê\u0096ôã\u0018RqÎOßÆ°B³\u009bCäy?\u008d1\u008fý\u0006W\u009cââv(xCCÉ \u0004\u001a\u0003oô\u0090Ç\u008dZL\u0085\u0099m)h\u0016Hy©àÈt(E\u0007¤ì\u0097öí´+MèM8îy:è\u00adngg\u00152úå$bØ:$\u00838NÙ\u0013jÌs4\u0084\"ý´\u001c1¼r\u0085-^íÄª?ik÷¾Ï¦\u0098ôQéâã¬Þ(\u0010©±fÛ1\u008a\u0019Î\u008a\u0011>ÈãW#Ê0\u008e\r@\u0097\u00ad\u008f~\u0080\u0098\u009e\u008b\u00841Ieî5\u001fê\u00ad\u008aPN\u0094GøL#è\u008aþë#8të8ÁçVü¥Ðî\u009cN\u0086\n\u0018\u0019\u0084ùÊF-e\u0097.Â5\u0095ã\u007fBUÃÏ/õÜzdÑ\u0010µL\u0097B\u008dÇôC\t¢\u00ad¾ÏàX0 Àx\u008f\u001d\u009c%\u0097½ÒI\"¯M{\fcþ;s²\u008c´\u008b÷4´³p;^\u0095ó\u0018\u0018\u0002@to\u0016õ\u0003\u0080£a\u0010Ý\u0016²!\u009a\u007f³ÔQü#i0H\u0014º}1\u0019í_G®fÙÏ/Ú\u0090\u0094ïU±\u000e\u0003\u0082aÍ\ry\u0004\fþ\u0081É½¬\u001bÚÍ)õàu9}ë7 {= %®²:q;<ÈZHKÞ¹\u000e\u0013Vë\u0011Ê3\u0098\u001cÒD\u0090\u0099þ]-·èEPá4\u0081¼Sàéeß¬*\u0084.ù%)c\u0004M\u0091Y\u0098\u001a\u0002L³\"÷\u0002\u0094îýh_j\"³Á±\u0099è9¦«í\u0007ù/ywqÜ\u0018ó\u0094¤\u0012\u0002ö±ok\rc´\u008aà3½kÎ\u0007îüyû\tã<þX,\u0080a_%\u0097ôC}ë\u0095º \u008fßÁt\u000bì\u0097zB×¿Ç±ü°Ül\u0085Ä>dÛÝçÛ\\\u0005²\u0018CXÏ:H¼ÏP\u0002Ôõ&Æm\u008dv\u009eäÿ\u0087\u008fj\u0006x\u0018ßAõKdéÀÌFÌ\u0010\u0082\u009b »\u0099E\u0099¬t[\u0018\u0092zê¸\u009fõ\fZ\u0096\u0000<îUF½2M\u0099Y\t£\u001búµ(Qv\tÏ.\u0089kóoÒ\"Æ\u001eìáÐ8{\u007f¢hÔ (\u001b¨.tw©w\u0084q¨^BA\u008e\u00923(>¨Ò\f\u0081\u0092=\u001a\u0018êë\u0086\r\u0006Ec\u0007ßR\u0094\u0093\u0015Ê\u0094\u008aÁv\fòåF¯Ñø¨\u000e\u001c<\u0001ë(F(Íã\u0016g\u0010\u007f/\u008a&,aq26ß\u0002\nô2\\ÚÔ\u008acÆð\u000ftê\u009fÍ\u0092Ugo1Ô28-\u007fNu¿]\"\u0095\u008e\u00105sÐ\u001cò\u0018\u0014\u0013»\u0085¿@|>\"\u0093\u0012g|.\u0000\u009anÑ\u008aÑÍÙ\r\u0001a?Ë1Ú¬¼\u0002F§CÇ-{7\u0017\u0018äBí!Á\u0093æ\b®\\\u0092¡\u0086\u0081^pPÛ\u0084§Â-ë<86\ng\u008d(\u008eôjÏG\tç¢Äk6ûsÓ¹Bÿw\u00164òX¿7 \u008c~®Y£Bm¨1¼¤\u0002®¤é\tXÌ{\u0098\u0094@´Ë\u0012ã ²¢J½n¹F{ÈD°0}X\u0012\u000b\u000eu\u001bJæ÷ió\u001a?Ý³Ìp\u0015[\u0010!\u0083y£\u0096Ày±~|U\u0085`²\\~ <þ×\u0018<é%!®·ì£êp\nNN,L&\u0002¹âa\u0015À\u0018íãµO@ KKR\u0013\b°¾W¸ñU\u0002¥k\u0003\n¾|]E\u0019,\u0018vKó¶¹_5´\t ÷áÚÍ\u0094éÏù²\u0018äG\t\u0094r\u00ad\u0084\u009föª\u0010>>aùzöðõ\u009e\u0099>(\u0085ð=Pw\u0093\u0010\u0085\n?\u008b\u001b\u0082\u0013±a·\u0007è\u001a$«Ç--\u0011Ï9%\u009c\u0095Í,\u0001\u0092]ãî\u008d\u0093(f\u001cV9[Ã\u0012|î\"\u008avÚ{ÝûT\u007fÅÊ\\ÂÉ\r\u001cª\u0005\u001d\u008c\u001749M°ÓC+\u009bÔk\u0010¶S+\n\u0010:\u008dV.VqÄ`á[d \u008d\u0007\u0005èWØæ.Tg®\u0016ÆP>[\u0088\u0082ôh$!Cå\u0001\u0085ÖÍÂrÅ÷\u0010Eji\u007f:\u001bT\\\u0084Ò\u0015\u0005CO\u0081â8Ïï\bl@»\u008c¥\\¹í½VJOD?Ø\u0098\u009c\u009füý\u0081Ê\u0094ºß¶þé\n\u001b\u008d,\u0099\u008bÓâm\u007ff\u00102¡À½¨\u008b\"ÎdæL\u009a£ vÝçªáPY~\u0006ö\u009d\u0012\u001dY5¿ßÊK\u0005yâ\u0007²øÝmèì:ü¹\u0010¢ÆqE£\u009fì\t¬\u0001î±¹}á#\u0010ãá\tÛ¢\u0094]W\\iR1éÃ\u001dÁXÀ:ÕGVÞv\u0004ÑZ[\u0014û\u0013øÞ\u008f¶ò;\u008a;\u0000N%\u0081\u009e\u008f¢(Ü\u0083ÙÔGt.ÊéTpéÓ\u0089Ã\u007fÚ½_ØË\rA\u0012¥+hÍ¤\u008c\u0011Ëà¬éçJ¡ý\\\u001awËÀÎ*ª\u0095ÙÏy\u009dí\u009dJÏê\u0003 ¥K°É\u0002K·òH\u000fu\t«1ÜFËýTú\u009cÓÄ\u0011ü±H\u008c ,¤]\u0010Zàw2\"+\u000e\u008b{%\u0018\u0085\b¡Ä!\u0010ó´«÷\u008d\u008b\u0002ýÞÆnÍ2PW²\u0018_`öÏ\u008ep\u0006Jðcú\u0097$Åu\u0085üµ4¿\u0010\u0088Ö\u008f\u0010%Ë\fzôÚLàwö½ ÅÓ®h(Kxyé<n\u000e\u000e\u0019'ëb\"¿ÝÊ<Ó\u008bJ)z\u001fÎ\u009cúÐôiîçÊê\u0017ÍÉ#\u001c\u001f\u007f\u00101à³\u0096ºAPì^ù·PÝ ^\u001d\u0010Á¢¿L.¿\u008dý¸É\u009c\u0099}â¡\u0098\u0018\u0085ÄÏx{F<=ú\u0000ébÞ\u000b\u000fé\u00065\u000fñ»X\u009bs \u0000¾#\u0098$\u0010;]8{C\u001e\u009fº\u0089c\u008dÔY¨\u0002\u001fü\u0017,Ft\u009eµ\u008cÏô0\u0000\u0084Sh\u0010¦Þ7goA¿Åò´`R\u008dØG\u000e©èb¸\u0097\u001b6¬r\u0016?Lg<&Öf*þ\u0094\u00ad,\bbhº¡ \u000fLS\n\u0086\u008f¸\u0014Ü|k(V¸\u0086µ,s·è\u0083äu\rq \u009dn\u001d\u0007£Å\u0010>É\u0094NsO>~bå¬øàÁÄ\u0014 \u0005«sßÖ\u0097lÞ\u009fMÐ@D%h\u0007ñ'¥\u0088\u0089³Z]:Ãs¹w,&J\u0010ùî;\u009cøEÃpeB\tH\u0012|\u008d,(q±Â\u009dú\u0098@ÚÁ\u0098Ê1\fÆûÎ»|$$Ý|:ÒE×&´©\u0011mOM\u000föØ\u001b\u0088\u0088ø \u008b%yX·Ïâ{åJô\u0091\u001b\u0017ªÿ%j\u0097r¨\\óÇ\u0089\u000e}c\u008cÑ+\u0006`Ù\u0094\u0001³yá1[ Ö=Ð\u008a.\u001fw\u008aP\u0012~ÿØf\u0097\u0087FûN\u008d8§ð¦Cr°T4¸`¯ú\u0007\u0015\u0094¿érB\f`[,\u009e\u001c¬mÃ2·Qì\t\u009d&qñ\u008d¾4d\u0083\u0085wí\u0099×I]&ÑY\u0019Ó,ð\u0091\u007f\u009aé6¤áÛÃ\u0007\u0010BÏJß9#Ç Ôí\u0085ÐòêH9(%+\u0001Xî½Öée\u0090V\u001aD·Wæv¥~WËåº;\u0012xÊÙ\u0015×âç$\u001fN±e¥C\u001e(aÖ\u0099sSãØÙ0!Ý±\u00963AÆVoÖu\u0006IÁPgî\u0001\u0000N\u008d\u0019\u0084\u0095á\u00165ÂÂ·\u009a ò 'Ê\nn¸nHT\u0081|057¨ßÏ\u0093Óä¿>YÃ¦=p¢\nU^ GIO\u0088Æ%Ü½ÖÏ\u0086D;kC©\u0018(6\u0088\u00ad¬\u0091bW¾³\u0099\u009eg\u009c\"\u0018ÏÍï\u001f^v\u0011 \u0001g½è\u0012\u0005F\u00adUìj\u007fÏ^~â $¥D\u0089¨ç ôæ\u0099s¤¸#ò\u0005\u008aK\u0084¾Çl^\u0087\u0094×Y¼N\u008c\u001a-\u0010àKÞÁ!`ÿñ´åU\u0001zåü\u0089X±ã}b\u0096P¸ë$\u00adÔd\u009d©y¯\u001eRb\u009eÜ#A\u009dt\u0006\u009dcjSúô\u0007Éz(À\u0089fð¦oÜsÊ±uy\u0011ngh\u009b»ÄB>D}5P\u0003uÅ Fßùyä\toÕ\u0088+xÑ?©\nÕÎ\u0095w,½\u008bd\u0010\\Ö²î¼xåhPÙó§\u0097|v§`ù+dÄ!\u0014\u001e\u0089\b\u0082áV\u007fWWKé¿&\u0003ì\u0086\u000eõÕ\u0001àõ*»×\\¾ô\t\u0016/'\u009f;¦ú'\u001b\u0091Ð\u0098¾ý\u0006s?\u001c¾Úwa\u008e\u0098ÖÝ\u009f\u0001\u0005Îþ#\u001bÿ±dg.ôìg.\u0092\u001dâõÍäÊÑ\u008aÏ\u008b½U¤\u0095OH2\u0002\u0018rg\u008acNq(\t«\u0094ù+:Ý&\u009cn3¯_Ä\u0082\u00ad¨ 1÷\u0099óDº&\u0002¯q\nÚ¾d{D8\u001b\u0003ãÊ\u0005®hÿ\u0093\u0098d\bJAÐ\u0010~iU\u001c>2Ù~¿\u009e9\u00150[\\¼\u0018À\u008e/4\u007f\u009fÿÚ\u0013ÆQ?\u0081Þ2HN\u009f¡\u008e\u0086ô\n×XÉC}rê\u001cC!\u007fÎ`\u001e~Ï]òÝ\u0098\u0090Ù\u009aF\u00955ew¨½É\u008c$\u00855HÍÖ'â\u001b³È@\u0006]»øWðÄ9K6\u001b\u008e\u0092Â\u0005ÅÝÇ\u000f\u0085Ô£A¢\r\u0095eÞÄä\u0010\u0014ºåÖy¦Ëq\u0002{Ú\réÒú d£f¡^äèÆ\u008f\u00ad©á¡\u009cE9\u001dÑC\nt\u001bßWGe ÙÝûÅv\u0010Àñ%V\u0006k\u000fÐ\u0007\u001f{yª¢·ì\u0018¡\u0099\b±Î\u001ajAø\u0015Ù\u0006\u0092K@~¨Í\u0089\u00ad\u0083)\u0087±8\u0000ê\bó³g\u008bê\u0090×Æ\blêû\u0003Z\fÿ\u009eÍß¬®Ú\u009a\u0093\u0016è\u0003¦¨°\u0001\u001f8bó\u0081ìhÌ÷\u008eµ\u0093@ÛzsB$\bfÑh\u0018Ð÷\u000fgåyZÖÎ\u0019l\u0098½\nÕáÉk(½«i#\u00120W\u008b\u00008\u0005O!\u00190\u0085D\u001fÉ!á<`/}X¿\fy\u0098\\W¬Ö\u0011Çã\u0084ÿ\u000e\fN\u009a\u0083ÉY\"\u0004óÀc\u001f\u0093c0\u0086ÉWI\u008cËÞ§ÓØæ]\u0080-ákÚE«)¿wMÞXJ]b'5¤a\u0006\u0092ÜÌòó]fº\u0004¹í\u0001'b\u0081\u0010\t¸PwôÈb¶0÷\u0015HÇ®\u0095X\u0018\u008bô¶±_ðñ\u0018zïT&k\u001c+<h<\u009dÍ`ôº.P©\u0082Z\u0093è\u001e/¼æÑGÇ\u0017mN\u000f\u0003çOUr!ü,SR\u000f5\u0011Äªà¶7\u0090\u008b»ìÂ6ÂGB&Çx\u009c+Q\"IÊ·\u001e/a¦89\u001d\u0015Ô»Ã\u000fê©è.C{ôæní \u0091\u009cþâ\u0010A\u001eÖÒòf\u009aNÀÑô\u0015@Uªè";
         short var30 = 4128;
         char var27 = '(';
         int var34 = -1;

         label73:
         while (true) {
            String var36 = var28.substring(++var34, var34 + var27);
            int var10001 = -1;

            while (true) {
               String var50 = a(var24.doFinal(var36.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var31[var29++] = var50;
                     if ((var34 += var27) >= var30) {
                        b = var31;
                        c = new String[115];
                        g = new HashMap(13);
                        Cipher var11;
                        Cipher var38 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                        var10002 = SecretKeyFactory.getInstance("DES");
                        var10003 = new byte[]{(byte)(var22 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                        for (int var12 = 1; var12 < 8; var12++) {
                           var10003[var12] = (byte)(var22 << var12 * 8 >>> 56);
                        }

                        var38.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                        long[] var17 = new long[2];
                        int var14 = 0;
                        byte var13 = 0;

                        do {
                           var10001 = var13;
                           var13 += 8;
                           byte[] var18 = "\u0080\u0004¤\u0093´\u0084VC\u0005QB\u0011ò-\u001bè".substring(var10001, var13).getBytes("ISO-8859-1");
                           var10001 = var14++;
                           long var19 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var10004 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           byte var58 = -1;
                           var17[var10001] = var10004;
                        } while (var13 < 16);

                        e = var17;
                        f = new Integer[2];
                        j = new HashMap(13);
                        Cipher var0;
                        Cipher var39 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                        var10002 = SecretKeyFactory.getInstance("DES");
                        var10003 = new byte[]{(byte)(var22 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                        for (int var1 = 1; var1 < 8; var1++) {
                           var10003[var1] = (byte)(var22 << var1 * 8 >>> 56);
                        }

                        var39.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                        long[] var6 = new long[5];
                        int var3 = 0;
                        String var4 = "\u007f\u008e\u001e\f4#\u007fÔþ;\u001aÓ \u009a\u001e:ë]£\u001a@6\u0017\u00ad";
                        byte var5 = 24;
                        byte var2 = 0;

                        label44:
                        while (true) {
                           int var46 = var2;
                           var2 += 8;
                           byte[] var7 = var4.substring(var46, var2).getBytes("ISO-8859-1");
                           long[] var40 = var6;
                           var46 = var3++;
                           long var55 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           byte var60 = -1;

                           while (true) {
                              long var8 = var55;
                              byte[] var10 = var0.doFinal(
                                 new byte[]{
                                    (byte)(var8 >>> 56),
                                    (byte)(var8 >>> 48),
                                    (byte)(var8 >>> 40),
                                    (byte)(var8 >>> 32),
                                    (byte)(var8 >>> 24),
                                    (byte)(var8 >>> 16),
                                    (byte)(var8 >>> 8),
                                    (byte)var8
                                 }
                              );
                              long var63 = (var10[0] & 255L) << 56
                                 | (var10[1] & 255L) << 48
                                 | (var10[2] & 255L) << 40
                                 | (var10[3] & 255L) << 32
                                 | (var10[4] & 255L) << 24
                                 | (var10[5] & 255L) << 16
                                 | (var10[6] & 255L) << 8
                                 | var10[7] & 255L;
                              switch (var60) {
                                 case 0:
                                    var40[var46] = var63;
                                    if (var2 >= var5) {
                                       h = var6;
                                       i = new Long[5];
                                       return;
                                    }
                                    break;
                                 default:
                                    var40[var46] = var63;
                                    if (var2 < var5) {
                                       continue label44;
                                    }

                                    var4 = "]ðíõ¶ (ðÙ¿ýÒDè\u001f\u0012";
                                    var5 = 16;
                                    var2 = 0;
                              }

                              byte var48 = var2;
                              var2 += 8;
                              var7 = var4.substring(var48, var2).getBytes("ISO-8859-1");
                              var40 = var6;
                              var46 = var3++;
                              var55 = (var7[0] & 255L) << 56
                                 | (var7[1] & 255L) << 48
                                 | (var7[2] & 255L) << 40
                                 | (var7[3] & 255L) << 32
                                 | (var7[4] & 255L) << 24
                                 | (var7[5] & 255L) << 16
                                 | (var7[6] & 255L) << 8
                                 | var7[7] & 255L;
                              var60 = 0;
                           }
                        }
                     }

                     var27 = var28.charAt(var34);
                     break;
                  default:
                     var31[var29++] = var50;
                     if ((var34 += var27) < var30) {
                        var27 = var28.charAt(var34);
                        continue label73;
                     }

                     var28 = "¡!..GÂ¡ö\u001eå)ÉÌõ\u0015kOÌMçh\u008c\u0010æwjß\u0017Ç\u00122v0iql\u00ad\u009db\u001aBJnXÕ\u009cà~-]\u0090}V+|lZ»\u0000ñ ícàü£ÎUï³\u001aç\u0090Ñôd9\u00adM\u0096õ";
                     var30 = 81;
                     var27 = ' ';
                     var34 = -1;
               }

               var36 = var28.substring(++var34, var34 + var27);
               var10001 = 0;
            }
         }
      }

      private Map<String, String> C(String query) {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 118844910965546L;
         d<"ä">(7944164181199244547L, a);
         HashMap params = new HashMap();
         if (query != null && !query.isEmpty()) {
            String[] var6 = query.split("&");
            int var7 = var6.length;
            int var8 = 0;
            if (0 < var7) {
               String pair = var6[0];
               String[] kv = pair.split("=");
               if (kv.length == 2) {
                  params.put(kv[0], kv[1]);
               }

               var8++;
            }

            return params;
         } else {
            return params;
         }
      }

      private 树何何何友树树何友何<?> D(Module module, String settingName) {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 104407036519049L;
         d<"ä">(2277807490150317216L, a);
         Iterator var6 = module.q().iterator();
         if (var6.hasNext()) {
            树何何何友树树何友何<?> value = (树何何何友树树何友何<?>)var6.next();
            if (value.v().equals(settingName)) {
               return value;
            }
         }

         return null;
      }

      private Module F(String moduleName) {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 88299110743236L;
         d<"ä">(-4480682078755495187L, a);
         Iterator var5 = Cherish.instance.getModuleManager().k().iterator();
         if (var5.hasNext()) {
            Module m = (Module)var5.next();
            if (m.i().equalsIgnoreCase(moduleName)) {
               return m;
            }
         }

         return null;
      }

      private Map<String, String> I(String json) {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 100497130596601L;
         d<"ä">(-3031942569950578992L, a);
         HashMap result = new HashMap();
         if (json != null && !json.isEmpty()) {
            json = json.trim();
            if (json.startsWith("{")) {
               json = json.substring(1);
            }

            if (json.endsWith("}")) {
               json = json.substring(0, json.length() - 1);
            }

            String[] pairs = json.split(",");
            int var8 = pairs.length;
            int var9 = 0;
            if (0 < var8) {
               String pair = pairs[0];
               String[] keyValue = pair.split(":");
               if (keyValue.length == 2) {
                  String key = keyValue[0].trim();
                  String value = keyValue[1].trim();
                  if (key.startsWith("\"") && key.endsWith("\"")) {
                     key = key.substring(1, key.length() - 1);
                  }

                  if (value.startsWith("\"") && value.endsWith("\"")) {
                     value = value.substring(1, value.length() - 1);
                  }

                  result.put(key, value);
               }

               var9++;
            }

            return result;
         } else {
            return result;
         }
      }

      private String J() {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 66689841264220L;
         d<"ä">(-8410182538420770699L, a);
         StringBuilder json = new StringBuilder(a<"f">(3322, 8324598365559119962L ^ a));
         何何友何何友何何树树[] var6 = 何何友何何友何何树树.M();
         int var7 = var6.length;
         int var8 = 0;
         if (0 < var7) {
            何何友何何友何何树树 category = var6[0];
            Iterator var10 = Cherish.instance.getModuleManager().o(category).iterator();
            if (var10.hasNext()) {
               Module module = (Module)var10.next();
               json.append("{");
               json.append(a<"f">(11509, 7850985596522807346L ^ a)).append(module.i()).append(a<"f">(5027, 3606884069688737616L ^ a));
               json.append(a<"f">(27377, 2579498821411997240L ^ a)).append(module.Q()).append(a<"f">(1142, 7419552568678148253L ^ a));
               json.append(a<"f">(16025, 5974380981709328988L ^ a)).append(module.D().name()).append(a<"f">(1142, 7419552568678148253L ^ a));
               json.append(a<"f">(29132, 484129742913641787L ^ a)).append(module.isEnabled()).append(a<"f">(1142, 7419552568678148253L ^ a));
               json.append(a<"f">(31595, 1679805414149003168L ^ a)).append(!module.q().isEmpty()).append(",");
               json.append(a<"f">(31616, 2658722283261695803L ^ a)).append(module.W());
               json.append("}");
            }

            var8++;
         }

         json.append(a<"f">(32359, 5570644529556263652L ^ a));
         return json.toString();
      }

      private String S(String requestBody) {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 79175740824382L;
         d<"ä">(-1861267372391217897L, a);

         try {
            Map<String, String> params = this.I(requestBody);
            String moduleName = params.get(a<"f">(15696, 1569955553232272542L ^ a));
            String settingName = params.get(a<"f">(1682, 4730158991020525347L ^ a));
            String valueStr = params.get(a<"f">(30079, 2952663423041991907L ^ a));
            if (moduleName != null && settingName != null && valueStr != null) {
               this.F(moduleName);
               return a<"f">(7641, 7070508088739273780L ^ a) + moduleName + a<"f">(11980, 5946237224989372230L ^ a);
            } else {
               return a<"f">(21218, 6207400925525988159L ^ a);
            }
         } catch (Exception var12) {
            return a<"f">(30330, 6761926405358942174L ^ a) + var12.getMessage() + a<"f">(11980, 5946237224989372230L ^ a);
         }
      }

      private static int b(int var0, long var1) {
         int var3 = var0 ^ (int)(var1 & 32767L) ^ 31419;
         if (f[var3] == null) {
            byte[] var4 = new byte[]{
               (byte)(var1 >>> 56),
               (byte)(var1 >>> 48),
               (byte)(var1 >>> 40),
               (byte)(var1 >>> 32),
               (byte)(var1 >>> 24),
               (byte)(var1 >>> 16),
               (byte)(var1 >>> 8),
               (byte)var1
            };
            long var5 = e[var3];
            byte[] var7 = new byte[]{
               (byte)(var5 >>> 56),
               (byte)(var5 >>> 48),
               (byte)(var5 >>> 40),
               (byte)(var5 >>> 32),
               (byte)(var5 >>> 24),
               (byte)(var5 >>> 16),
               (byte)(var5 >>> 8),
               (byte)var5
            };
            Long var8 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])g.get(var8);

            byte[] var10;
            try {
               Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               g.put(var8, var9);
               DESKeySpec var11 = new DESKeySpec(var4);
               SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
               Cipher var13 = (Cipher)var9[0];
               var13.init(2, var12, (IvParameterSpec)var9[2]);
               var10 = var13.doFinal(var7);
            } catch (Exception var14) {
               throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$树友友友何友友友树何", var14);
            }

            int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
            f[var3] = var15;
         }

         return f[var3];
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = k[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(l[var4]);
               k[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static CallSite b(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$树友友友何友友友树何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
         int var4 = (Integer)var3[0];
         long var5 = (Long)var3[1];
         int var7 = b(var4, var5);
         MethodHandle var8 = MethodHandles.constant(int.class, var7);
         var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
         return var7;
      }

      private String x(String moduleName) {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 20614852867361L;
         d<"ä">(-8632228874936407288L, a);
         if (moduleName == null) {
            return a<"f">(8156, 6046650025054072930L ^ a);
         } else {
            for (Module m : Cherish.instance.getModuleManager().k()) {
               if (m.i().equalsIgnoreCase(moduleName)) {
                  break;
               }
            }

            return a<"f">(12492, 5937043071721725821L ^ a) + moduleName + a<"f">(20082, 2354996324388479469L ^ a);
         }
      }

      private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
         int var4 = (Integer)var3[0];
         long var5 = (Long)var3[1];
         long var7 = c(var4, var5);
         MethodHandle var9 = MethodHandles.constant(long.class, var7);
         var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
         return var7;
      }

      private static long c(int var0, long var1) {
         int var3 = var0 ^ (int)(var1 & 32767L) ^ 13459;
         if (i[var3] == null) {
            byte[] var4 = new byte[]{
               (byte)(var1 >>> 56),
               (byte)(var1 >>> 48),
               (byte)(var1 >>> 40),
               (byte)(var1 >>> 32),
               (byte)(var1 >>> 24),
               (byte)(var1 >>> 16),
               (byte)(var1 >>> 8),
               (byte)var1
            };
            long var5 = h[var3];
            byte[] var7 = new byte[]{
               (byte)(var5 >>> 56),
               (byte)(var5 >>> 48),
               (byte)(var5 >>> 40),
               (byte)(var5 >>> 32),
               (byte)(var5 >>> 24),
               (byte)(var5 >>> 16),
               (byte)(var5 >>> 8),
               (byte)var5
            };
            Long var8 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])j.get(var8);

            byte[] var10;
            try {
               Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var8, var9);
               DESKeySpec var11 = new DESKeySpec(var4);
               SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
               Cipher var13 = (Cipher)var9[0];
               var13.init(2, var12, (IvParameterSpec)var9[2]);
               var10 = var13.doFinal(var7);
            } catch (Exception var14) {
               throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$树友友友何友友友树何", var14);
            }

            long var15 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            i[var3] = var15;
         }

         return i[var3];
      }

      private static CallSite c(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$树友友友何友友友树何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = k[var4];
         if (var5 instanceof String) {
            String var6 = l[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            k[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private void n(HttpExchange exchange, int code, String message) throws IOException {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 93757089129042L;
         exchange.getResponseHeaders().set(a<"f">(6273, 2119981900832514106L ^ a), a<"f">(16490, 8708481768502622452L ^ a));
         d<"ä">(-2357794484255785861L, a);
         byte[] responseBytes = message.getBytes(StandardCharsets.UTF_8);
         exchange.sendResponseHeaders(code, responseBytes.length);

         try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = l[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            k[var4] = var21;
            return var21;
         }
      }

      private static CallSite d(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$树友友友何友友友树何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static void a() {
         k[0] = "\n)\b*63\u0005iE!<.\u00004Ng43\r2J,w5\u00047Jg=5\u001a7J( r!\u0012b";
         k[1] = "h*";
         k[2] = "\u001cF9\u00036#\u0013\u0006t\b<>\u0016[\u007fN4#\u001b]{\u0005w%\u0012X{N=%\fX{\u0001 b桮佽叜厫案伙桮口佂桱}桝厴口叜伵厒厇厴根佂";
         k[3] = "ou\\\u007fs:dzM0\t>w{]\u007f?:`";
         k[4] = "c\u0011!Xs~h\u001e0\u0017\u0012pc\u00154M";
         k[5] = "\ni,yxg\u000fs\u007fEC\u0002\u001f}};{9\u0019vxE";
         k[6] = "4\u000b\u0014\u007fD\u001ev\u0001\u001f/'\f\rQ\u001d$\\UnQ\u00135\u0019e7\u0006\u0010?\u0017\u00067\b\u0001z'";
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 218 && var8 != 'k' && var8 != 219 && var8 != 224) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 252) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 228) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 218) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'k') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 219) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Throwable a(Throwable var0) {
         return var0;
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static String a(int var0, long var1) {
         int var5 = var0 ^ (int)(var1 & 32767L) ^ 26603;
         if (c[var5] == null) {
            Object[] var4;
            try {
               Long var3 = Thread.currentThread().getId();
               Object[] var10000 = (Object[])d.get(var3);
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               d.put(var3, var4);
            } catch (Exception var10) {
               throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$树友友友何友友友树何", var10);
            }

            byte[] var6 = new byte[8];
            var6[0] = (byte)(var1 >>> 56);

            for (int var7 = 1; var7 < 8; var7++) {
               var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
            }

            DESKeySpec var11 = new DESKeySpec(var6);
            SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
            ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
            byte[] var9 = b[var5].getBytes("ISO-8859-1");
            c[var5] = a(((Cipher)var4[0]).doFinal(var9));
         }

         return c[var5];
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (l[var4] != null) {
            return var4;
         } else {
            Object var5 = k[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 55;
                  case 1 -> 26;
                  case 2 -> 29;
                  case 3 -> 60;
                  case 4 -> 33;
                  case 5 -> 39;
                  case 6 -> 40;
                  case 7 -> 16;
                  case 8 -> 34;
                  case 9 -> 35;
                  case 10 -> 21;
                  case 11 -> 44;
                  case 12 -> 58;
                  case 13 -> 15;
                  case 14 -> 43;
                  case 15 -> 20;
                  case 16 -> 23;
                  case 17 -> 30;
                  case 18 -> 13;
                  case 19 -> 24;
                  case 20 -> 12;
                  case 21 -> 45;
                  case 22 -> 42;
                  case 23 -> 54;
                  case 24 -> 47;
                  case 25 -> 49;
                  case 26 -> 2;
                  case 27 -> 17;
                  case 28 -> 14;
                  case 29 -> 41;
                  case 30 -> 51;
                  case 31 -> 5;
                  case 32 -> 22;
                  case 33 -> 11;
                  case 34 -> 48;
                  case 35 -> 4;
                  case 36 -> 38;
                  case 37 -> 37;
                  case 38 -> 59;
                  case 39 -> 9;
                  case 40 -> 1;
                  case 41 -> 50;
                  case 42 -> 25;
                  case 43 -> 31;
                  case 44 -> 28;
                  case 45 -> 32;
                  case 46 -> 6;
                  case 47 -> 3;
                  case 48 -> 62;
                  case 49 -> 46;
                  case 50 -> 63;
                  case 51 -> 8;
                  case 52 -> 7;
                  case 53 -> 10;
                  case 54 -> 27;
                  case 55 -> 56;
                  case 56 -> 18;
                  case 57 -> 36;
                  case 58 -> 52;
                  case 59 -> 57;
                  case 60 -> 19;
                  case 61 -> 0;
                  case 62 -> 61;
                  default -> 53;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               l[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树何友友树何树友何树$树友友友何友友友树何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
         int var4 = (Integer)var3[0];
         long var5 = (Long)var3[1];
         String var7 = a(var4, var5);
         MethodHandle var8 = MethodHandles.constant(String.class, var7);
         var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
         return var7;
      }

      private void p(树何何何友树树何友何<?> value, String valueStr) throws Exception {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 5071919118053L;
         d<"ä">(860257561501182156L, a);
         if (value instanceof NumberValue numberValue) {
            try {
               double numValue = Double.parseDouble(valueStr);
               numberValue.J(numValue);
            } catch (NumberFormatException var23) {
               throw new Exception(a<"f">(16420, 6994637225150688273L ^ a) + valueStr);
            }
         } else {
            if (value instanceof BooleanValue booleanValue) {
               booleanValue.g(Boolean.parseBoolean(valueStr));
            }

            if (value instanceof ModeValue modeValue) {
               String[] availableValues = modeValue.s();
               boolean isValidValue = false;
               int i = availableValues.length;
               int alpha = 0;
               if (0 < i) {
                  String availableValue = availableValues[0];
                  if (availableValue.equals(valueStr)) {
                     isValidValue = true;
                  }

                  alpha++;
               }

               if (!isValidValue) {
                  StringBuilder optionsStr = new StringBuilder();
                  i = 0;
                  if (0 < availableValues.length) {
                     optionsStr.append(a<"f">(30928, 7042423270435263705L ^ a));
                     optionsStr.append(availableValues[0]);
                     i++;
                  }

                  throw new Exception(a<"f">(1068, 5741505078025971771L ^ a) + optionsStr);
               }

               modeValue.g(valueStr);
            }

            if (value instanceof 友树何树友友何树友友 textValue) {
               textValue.g(valueStr);
            }

            if (value instanceof 树友何友何何友树树友) {
               try {
                  if (valueStr.startsWith("#")) {
                     String hexValue = valueStr.substring(1);
                     if (hexValue.length() == 6) {
                        int rgb = Integer.parseInt(hexValue, 16);
                        new Color(rgb | b<"x">(11109, 6571804232927828527L ^ a), true);
                     }

                     if (hexValue.length() == 8) {
                        long argb = Long.parseLong(hexValue, 16);
                        int alphax = (int)(argb >> 24 & c<"a">(23672, 1067234886701376282L ^ a));
                        int red = (int)(argb >> 16 & c<"a">(26598, 3136293862939154566L ^ a));
                        int green = (int)(argb >> 8 & c<"a">(26598, 3136293862939154566L ^ a));
                        int blue = (int)(argb & c<"a">(26598, 3136293862939154566L ^ a));
                        new Color(red, green, blue, alphax);
                     }

                     throw new Exception(a<"f">(1114, 8766153765231847519L ^ a));
                  }

                  try {
                     long rgb = Long.parseLong(valueStr);
                     if (rgb >= c<"a">(32156, 555894919645577983L ^ a) && rgb <= c<"a">(26305, 6035650589725874592L ^ a)) {
                        new Color((int)rgb, true);
                     }

                     throw new Exception(a<"f">(10743, 8701337497373427154L ^ a));
                  } catch (NumberFormatException var19) {
                     throw new Exception(a<"f">(8681, 3121836037078306291L ^ a) + valueStr);
                  }
               } catch (Exception var20) {
                  throw new Exception(a<"f">(6587, 3279798050828940724L ^ a) + valueStr + a<"f">(3600, 6379888800807772764L ^ a) + var20.getMessage());
               }
            }

            try {
               value.getClass().getMethod("g", Object.class).invoke(value, valueStr);
            } catch (Exception var22) {
               try {
                  Field valueField = value.getClass().getDeclaredField(a<"f">(26986, 8955090383061681476L ^ a));
                  valueField.setAccessible(true);
                  valueField.set(value, valueStr);
               } catch (Exception var21) {
                  throw new Exception(a<"f">(575, 7725600377533427215L ^ a) + value.getClass().getSimpleName());
               }
            }
         }
      }

      private String z(树何何何友树树何友何<?> value) {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 92430119897926L;
         d<"ä">(8526280830363260271L, a);
         StringBuilder json = new StringBuilder("{");
         json.append(a<"f">(31166, 2133698763249018938L ^ a)).append(value.v()).append(a<"f">(1142, 7419649014852687239L ^ a));
         if (value instanceof NumberValue numberValue) {
            json.append(a<"f">(7529, 1027720601518640264L ^ a));
            json.append(a<"f">(13959, 7092695749518173974L ^ a)).append(numberValue.getValue()).append(",");

            try {
               Object minValue = null;
               Object maxValue = null;
               Object incValue = null;

               try {
                  minValue = numberValue.getClass().getMethod(a<"f">(21781, 3772348023250273457L ^ a)).invoke(numberValue);
                  maxValue = numberValue.getClass().getMethod(a<"f">(30102, 8781310879898330175L ^ a)).invoke(numberValue);
                  incValue = numberValue.getClass().getMethod(a<"f">(12282, 7629253940216479268L ^ a)).invoke(numberValue);
               } catch (Exception var27) {
                  try {
                     minValue = numberValue.getClass().getMethod(a<"f">(534, 2624920832183899057L ^ a)).invoke(numberValue);
                     maxValue = numberValue.getClass().getMethod(a<"f">(7887, 953887877007773528L ^ a)).invoke(numberValue);
                     incValue = numberValue.getClass().getMethod("I").invoke(numberValue);
                  } catch (Exception var26) {
                     Field[] fields = numberValue.getClass().getDeclaredFields();
                     if (fields.length == 0) {
                        fields = numberValue.getClass().getSuperclass().getDeclaredFields();
                     }

                     int var18 = fields.length;
                     int var19 = 0;
                     if (0 < var18) {
                        Field field = fields[0];
                        field.setAccessible(true);
                        String fieldName = field.getName().toLowerCase();
                        if (fieldName.contains(a<"f">(8824, 4185898079410959243L ^ a)) && minValue == null) {
                           minValue = field.get(numberValue);
                        }

                        if (fieldName.contains(a<"f">(16606, 7814382432067113305L ^ a)) && maxValue == null) {
                           maxValue = field.get(numberValue);
                        }

                        if ((fieldName.contains(a<"f">(30270, 6754838427070130048L ^ a)) || fieldName.contains(a<"f">(6187, 8799112146534107597L ^ a)))
                           && incValue == null) {
                           incValue = field.get(numberValue);
                        }

                        var19++;
                     }
                  }
               }

               json.append(a<"f">(9887, 9050529263418455877L ^ a)).append(minValue != null ? minValue : 0).append(",");
               json.append(a<"f">(3622, 2923049778759933829L ^ a)).append(maxValue != null ? maxValue : 100).append(",");
               json.append(a<"f">(1991, 7897306231814362714L ^ a)).append(incValue != null ? incValue : 1);
            } catch (Exception var28) {
               json.append(a<"f">(29712, 8258411132219188643L ^ a));
               json.append(a<"f">(4461, 6478895417608667373L ^ a));
               json.append(a<"f">(8885, 2004421049238172423L ^ a));
            }

            json.append("}");
         }

         if (value instanceof BooleanValue booleanValue) {
            json.append(a<"f">(26308, 6345114502905952070L ^ a));
            json.append(a<"f">(2598, 7640901628806110162L ^ a)).append(booleanValue.getValue());
            json.append("}");
         }

         if (value instanceof ModeValue modeValue) {
            json.append(a<"f">(8812, 2914666571309953924L ^ a));

            try {
               String currentValue = modeValue.getValue();
               json.append(a<"f">(5150, 6181256062229022149L ^ a))
                  .append(currentValue != null ? currentValue : "")
                  .append(a<"f">(1142, 7419649014852687239L ^ a));
               String[] modes = modeValue.s();
               json.append(a<"f">(17582, 8327575230698607974L ^ a));
               if (modes.length > 0) {
                  int i = 0;
                  if (0 < modes.length) {
                     json.append(",");
                     json.append("\"").append(modes[0]).append("\"");
                     i++;
                  }
               }

               json.append("]");
            } catch (Exception var25) {
               json.append(a<"f">(30903, 8611914226776107324L ^ a));
            }

            json.append("}");
         }

         if (value instanceof 友树何树友友何树友友 textValue) {
            json.append(a<"f">(15061, 5747069949527960391L ^ a));

            try {
               String val = textValue.getValue();
               json.append(a<"f">(2797, 5690581141112724237L ^ a)).append(val != null ? val : "").append("\"");
            } catch (Exception var24) {
               json.append(a<"f">(19425, 3336136817508244058L ^ a));
            }

            json.append("}");
         }

         if (value instanceof 树友何友何何友树树友 colorValue) {
            json.append(a<"f">(933, 1138728331401335360L ^ a));

            try {
               Color color = colorValue.getValue();
               int red = color.getRed();
               int green = color.getGreen();
               int blue = color.getBlue();
               int alpha = color.getAlpha();
               if (alpha == 255) {
                  String.format(a<"f">(1311, 6420323565521900743L ^ a), red, green, blue);
               }

               String hexColor = String.format(a<"f">(9266, 1485602565894813159L ^ a), alpha, red, green, blue);
               json.append(a<"f">(2797, 5690581141112724237L ^ a)).append(hexColor).append(a<"f">(1142, 7419649014852687239L ^ a));
               json.append(a<"f">(32264, 908540590823305130L ^ a)).append(hexColor).append(a<"f">(1142, 7419649014852687239L ^ a));
               json.append(a<"f">(10502, 6392325466165426413L ^ a)).append(color.getRGB() & b<"x">(31930, 2546521685047636050L ^ a)).append(",");
               json.append(a<"f">(4395, 6931970571813421220L ^ a)).append(color.getRGB()).append(",");
               json.append(a<"f">(11203, 8297807305401678459L ^ a)).append(red).append(",");
               json.append(a<"f">(27826, 7756174699021040997L ^ a)).append(green).append(",");
               json.append(a<"f">(6096, 6133195072662865455L ^ a)).append(blue).append(",");
               json.append(a<"f">(21625, 3503941733463016908L ^ a)).append(alpha);
               json.append(a<"f">(201, 4224013070825623905L ^ a));
               json.append(a<"f">(16612, 2079904366851314047L ^ a));
               json.append(a<"f">(12970, 6518933772784935752L ^ a));
               json.append(a<"f">(23852, 6793464394314403036L ^ a));
               json.append(a<"f">(7431, 39796597506346143L ^ a));
               json.append(a<"f">(11940, 1301169842058084167L ^ a));
               json.append(a<"f">(27499, 2839847115415124711L ^ a));
               json.append(a<"f">(5496, 5604359006667048168L ^ a));
            } catch (Exception var23) {
               json.append(a<"f">(30108, 4134149345781671026L ^ a));
               json.append(a<"f">(27920, 9029200680786820249L ^ a));
               json.append(a<"f">(12412, 8259802996953653714L ^ a));
               json.append(a<"f">(7181, 6593021948263927218L ^ a));
               json.append(a<"f">(10739, 3481492633908262979L ^ a));
               json.append(a<"f">(15413, 8101691813416021440L ^ a));
               json.append(a<"f">(29899, 8615114190144595253L ^ a));
               json.append(a<"f">(13730, 2524673133187802147L ^ a));
            }

            json.append("}");
         }

         json.append(a<"f">(25129, 5016084640691254177L ^ a));

         try {
            Object val = value.getValue();
            json.append(a<"f">(2797, 5690581141112724237L ^ a))
               .append(val != null ? String.valueOf(val) : a<"f">(29517, 5009440948101472945L ^ a))
               .append("\"");
         } catch (Exception var22) {
            json.append(a<"f">(10070, 7244009545222698749L ^ a));
         }

         json.append("}");
         return json.toString();
      }

      @Override
      public void handle(HttpExchange exchange) throws IOException {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 133615303251219L;
         exchange.getResponseHeaders().add(a<"f">(24208, 898106493554954519L ^ a), "*");
         d<"ä">(2884065903280851770L, a);
         exchange.getResponseHeaders().add(a<"f">(16694, 9194933746796826307L ^ a), a<"f">(25403, 3517216592766872741L ^ a));
         exchange.getResponseHeaders().add(a<"f">(28262, 4420702793372017092L ^ a), a<"f">(29690, 3993467729935187071L ^ a));
         if (exchange.getRequestMethod().equalsIgnoreCase(a<"f">(30199, 6568591950447786535L ^ a))) {
            exchange.sendResponseHeaders(204, c<"a">(9192, 6117930700011126648L ^ a));
         } else {
            try {
               String path = exchange.getRequestURI().getPath();
               String query = exchange.getRequestURI().getQuery();
               Map<String, String> queryParams = this.C(query);
               String requestBody = "";
               if (a<"f">(2678, 5052596853156627928L ^ a).equalsIgnoreCase(exchange.getRequestMethod())) {
                  InputStream is = exchange.getRequestBody();
                  requestBody = new String(is.readAllBytes(), StandardCharsets.UTF_8);
               }

               String response = this.T(path, queryParams, requestBody);
               exchange.getResponseHeaders().set(a<"f">(29984, 1807247710718573192L ^ a), a<"f">(15450, 8031323503214195618L ^ a));
               byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
               exchange.sendResponseHeaders(200, responseBytes.length);
               OutputStream os = exchange.getResponseBody();
               os.write(responseBytes);
               os.close();
            } catch (Exception var12) {
               String error = a<"f">(5395, 4629992957268712154L ^ a)
                  + var12.getMessage().replace("\"", a<"f">(29447, 7520472066044116206L ^ a))
                  + a<"f">(11980, 5946289481642795371L ^ a);
               exchange.getResponseHeaders().set(a<"f">(29984, 1807247710718573192L ^ a), a<"f">(3133, 3227727000149115778L ^ a));
               exchange.sendResponseHeaders(500, error.getBytes().length);
               OutputStream os = exchange.getResponseBody();
               os.write(error.getBytes());
               os.close();
            }
         }
      }

      private String r(String moduleName) {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 41198381949831L;
         d<"ä">(2202856518621805998L, a);
         if (moduleName == null) {
            return a<"f">(27431, 3091863834310742642L ^ a);
         } else {
            Module module = null;

            for (Module m : Cherish.instance.getModuleManager().k()) {
               if (m.i().equalsIgnoreCase(moduleName)) {
                  module = m;
                  break;
               }
            }

            if (module != null) {
               module.k();
               return a<"f">(16462, 7228737963680774421L ^ a) + moduleName + a<"f">(25345, 5561957468919110198L ^ a) + module.isEnabled() + "}";
            } else {
               return a<"f">(7641, 7070388494083253389L ^ a) + moduleName + a<"f">(11980, 5946205315345274879L ^ a);
            }
         }
      }

      private String T(String path, Map<String, String> queryParams, String requestBody) {
         long a = 树何友友树何树友何树.树友友友何友友友树何.a ^ 7531352397949L;
         d<"ä">(7307158516322879060L, a);
         byte var8 = -1;
         switch (path.hashCode()) {
            case -537362173:
               if (!path.equals(a<"f">(9788, 1569710008679507096L ^ a))) {
                  break;
               }

               var8 = 0;
            case -509590952:
               if (!path.equals(a<"f">(29743, 8023995576326715043L ^ a))) {
                  break;
               }

               var8 = 1;
            case -1734438361:
               if (!path.equals(a<"f">(30523, 2057771691695732217L ^ a))) {
                  break;
               }

               var8 = 2;
            case 1962120272:
               if (path.equals(a<"f">(14363, 663049803088673443L ^ a))) {
                  var8 = 3;
               }
         }

         switch (var8) {
            case 0:
               return this.J();
            case 1: {
               String moduleName = queryParams.get(a<"f">(17071, 7431627031514234944L ^ a));
               return this.r(moduleName);
            }
            case 2: {
               String moduleName = queryParams.get(a<"f">(15696, 1570019707198783453L ^ a));
               return this.x(moduleName);
            }
            case 3:
               return this.S(requestBody);
            default:
               return a<"f">(631, 6736916247913496817L ^ a);
         }
      }

      private static String LIU_YA_FENG() {
         return "何大伟230622198107200054";
      }
   }
}
