package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.友友友何树友何树树树;
import cn.cool.cherish.ui.何何友友树何树何友树;
import cn.cool.cherish.ui.友树何友何友何树树树;
import cn.cool.cherish.utils.animations.何何何何何友树树树友;
import cn.cool.cherish.utils.animations.何友友何何友何友友何;
import cn.cool.cherish.utils.animations.友何树友树何何友树树;
import cn.cool.cherish.utils.player.何树何树友树树友友何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.awt.Rectangle;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友何树树友何树树树友 extends 友友友何树友何树树树 implements 何树友 {
   private final 何何何友友何树何何何 树何友树友友何友树何 = new 何何何友友何树何何何("Display Text", "显示文本", "Cherish Client [fps] | [cps] CPS");
   private final BooleanValue 友树友何树树树何树何 = new BooleanValue("Text Shadow", "文字阴影", true);
   private final ModeValue 友友友何树何友友友树 = new ModeValue("Background Mode", "背景模式", new String[]{"Normal", "Rounded", "Off"}, "Normal");
   private final NumberValue 何何树何树何树树何何 = new NumberValue("Background Alpha", "背景透明度", 80, 0, 255, 1);
   private final BooleanValue 何何友何何树树树何树 = new BooleanValue("Outline", "轮廓", false);
   private final NumberValue 何树友何友树何树树友 = new NumberValue("Padding", "内边距", 4, 0, 10, 1);
   private final 何何何何何友树树树友 何何何何何何友树友友;
   private final Rectangle 何树友友何何树何友友 = new Rectangle();
   private final List<Long> 友何友树树何树友友何 = new ArrayList<>();
   private int 树友树树友友友友何何 = 0;
   private boolean 友何树何何何树何友树 = false;
   private int 树友友友何何友何友友 = 0;
   private final DecimalFormat 树树何友树友何友树何 = new DecimalFormat("#");
   private int 友树树树友友树树友何 = 0;
   private long 友树树树树树友树树何 = System.currentTimeMillis();
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final long n;
   private static final long[] o;
   private static final Long[] p;
   private static final Map q;
   private static final Object[] x = new Object[51];
   private static final String[] y = new String[51];
   private static int _职业技术教育中心学校 _;

   public 友何树树友何树树树友() {
      super("CustomText", "自定义文本", 150.0F, 20.0F);
      this.何何何何何何友树友友 = new 何友友何何友何友友何(200, 16923, 1.0, 47854, '溑');
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(2485104765739422763L, -635418817023765535L, MethodHandles.lookup().lookupClass()).a(62998977099083L);
      // $VF: monitorexit
      c = var10000;
      c();
      Cipher var18;
      Cipher var29 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(13098985531057L << var19 * 8 >>> 56);
      }

      var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[44];
      int var23 = 0;
      String var22 = "\u008d\u009fñ¢7;Yg¬\u0092#²]D\u008a¼1\u008fy\u009cÅçÓq$\u0017¸ú\u0086-Ú<\u0010Le5Ô\u001bÎ|ª2ò¯Õ\u0003*áS\u0010ò\u0086Æî/¹f?ÑÐ¿ú\u001ciJ9\u0010õ\u001dVßÂhÎK[\u0092×Ã\u008au<¶\u0010ô=ÉB\u0094Çuò©ÚÝ$\u0019çIx@â7\u009dÔÎÏü\u008cÁ\u000eYOÕn¢\u00884 t\u0019 #\u0005\u0093Ôlr\u00000ª\u0018Ù\u008eí\u009c\u008d/ Ò¿ÙCX\u0002;û[\fa\u00ad{\u000bêj\u000eã«\u000e\u00800æ\u00150D\u00100å\u0099Y%Wë\u0010m@Tä )Aê\u0010\u0081(>&kÄ\u001bj\u0013:ê\u0001{\u007f¤Ä\u0018G\u008bþ.c8\u008dPÛ\u0082\u008c¬\u001cn.\u007f:ç\u0089ÄÇ2ß¯\u0010\u0084¯ý³Ádú*Ïô\u009f\r\u0015\u008b2â\u0018oRÅ\u001e\u000e'\u0001Õ,Y\u00079\u0002ðh\u0002l³âò¼¸\u008dì\u0018Ö\r´\u0015\u0086\u001bÇP{Â2å--Ü>Z0Ok(æf)\u0010â&ß\"íÍ\u0090Z^N$¯\u0018»bj\u0010]ßI\u007fAìT4V@F\u0093Iúî- %ÝØJ0BÿxÎ\fSæEÀ\u0098xpØa\u001fG§Ê±1\u001bÑµh\u0018ÐÐ\u0010RªY\"\u0004j\u0011\u0096\t_ï\u008b\u0096?dÊ\u0010Ç\r5\u0083ÏÁÄÉ0Ú\u0011|¬\u001b¥\u001b\u0010-}s\u0016x\u0007É§1bÉâ¦?|\u009b(ð\u009aý\u0001!(\u0004j\u008c\u0092\u0086v(Qål%}§\u000fì|\u000e\u0002ÚrñTÿCWJP$Ä¯Í\u0019ø:\u0010.Ð\u0015\u0093\u0005eÑb\u0081/\b< XÀÂ\u0010³Ò3\u0001c\f·å£\u009bâÈ\u0013´\u0017x\u0010x@s.\u0080S+\u008eæý\u009a'\u0004àP³\u0010¼Ú¯FV,,+\u009dj\u0094\u000e\u0002W\u0094\t\u0010Õ\u001a`AFE@?[\u0084\u0002\u008a×úk\u0000\u0010\u0013ó\u009f\u0085j»\u007f\u0088aöTÉ\u008eS£¯ ,c´#T\u009dÈlwqD\u008a\u0010Vwihæ\u0082hòfV\u0004Ï½ë\u009a·ùõ\u0088\u0010\u009b\u0094Iw\u008b\u0001«ò*;\u0014\u0086Æðy-\u0010£y`«¡´i'zµ[m\u001d}Ù\u009f\u0010ÐjÕ\u008a\u008fwGb\bA\fÐ<öÿ\u009e\u0010\u0099¤\u0006ÔÒ_®\u0000¾l\u0088ù»R:y zã¤ëKá¾+_CpýÄÄ:[EA\u001f/\u000ba°0\"í=\u001dg\u0098`(\u0018ïa7\u001fJÈ<ÈÛÅØ=å\u0017\u000e&8 \u0082«b\t\u0096[\u0010\u009b6\u0011¢íJ\u0018W®YÚÈ\u0088\u000f¾X\u00184µ7HqQë;ÞæòZ²%,ïèî\u001b~)Úo\u0006\u0010\u0007w\u0084\"\u0014¡^×4ºû\u001câ\u0091\u00adÆ\u0010Ïzõ~v5\u0001b79Ñ©\u0080ä\u0001\u0001\u0010\u009e\u0017G§¼Þ¦å\u009a4\u0007W:O\b³\u0010ÁY¼½\u0011ú\u0090v\u008e¥ègLId*\u0018\u0080Ò\u0090òY\u001a\u0081\u0094»×åAµá\r1ó\u0093\u0091À¾ûw( \u0017Ò\u0017©æÍ£Þðö_&ðB.Ä\u0098aJEzá¨´á:\u0018+E²f²\u0010\u0084\u001fÄë¬ÞP+A\u000f\u000byÐ\u0007ÉÙ L\u0093\u0095>î\u0088^\u008cî¤Ê¯\u009d\u0085\u001fïóý\u008f\u0083økè\u0080\u0094\u001f¬Æÿ\u009eû\u0099";
      short var24 = 929;
      char var21 = ' ';
      int var28 = -1;

      label66:
      while (true) {
         String var30 = var22.substring(++var28, var28 + var21);
         int var10001 = -1;

         while (true) {
            String var43 = d(var18.doFinal(var30.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var43;
                  if ((var28 += var21) >= var24) {
                     k = var25;
                     l = new String[44];
                     Cipher var11;
                     Cipher var32 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(13098985531057L << var12 * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var15 = var11.doFinal(new byte[]{-85, 98, 15, 27, 92, 4, 69, 90});
                     long var47 = (var15[0] & 255L) << 56
                        | (var15[1] & 255L) << 48
                        | (var15[2] & 255L) << 40
                        | (var15[3] & 255L) << 32
                        | (var15[4] & 255L) << 24
                        | (var15[5] & 255L) << 16
                        | (var15[6] & 255L) << 8
                        | var15[7] & 255L;
                     var10001 = (byte)-1;
                     n = var47;
                     q = new HashMap(13);
                     Cipher var0;
                     Cipher var33 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(13098985531057L << var1 * 8 >>> 56);
                     }

                     var33.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[5];
                     int var3 = 0;
                     String var4 = "\u008dl\u0082j\u008bÚU\u000f½ì~õ¢¾ý'ÑG\u0015ãñWm\u001c";
                     byte var5 = 24;
                     byte var2 = 0;

                     label42:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var34 = var6;
                        var10001 = var3++;
                        long var49 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var53 = -1;

                        while (true) {
                           long var8 = var49;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var55 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var53) {
                              case 0:
                                 var34[var10001] = var55;
                                 if (var2 >= var5) {
                                    o = var6;
                                    p = new Long[5];
                                    return;
                                 }
                                 break;
                              default:
                                 var34[var10001] = var55;
                                 if (var2 < var5) {
                                    continue label42;
                                 }

                                 var4 = "4¶ÙÝ\u009eX&î¼Aí{\u008am3<";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var41 = var2;
                           var2 += 8;
                           var7 = var4.substring(var41, var2).getBytes("ISO-8859-1");
                           var34 = var6;
                           var10001 = var3++;
                           var49 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var53 = 0;
                        }
                     }
                  }

                  var21 = var22.charAt(var28);
                  break;
               default:
                  var25[var23++] = var43;
                  if ((var28 += var21) < var24) {
                     var21 = var22.charAt(var28);
                     continue label66;
                  }

                  var22 = "\u001d\u0001±J´¶r\u0011ß$/Ð6Vrk 6\u008e²y¦Mn3q1¢lr\u0006\u009aùÆØ\u0094\u009c£JxGïÚÐÕ\u0012[G9";
                  var24 = 49;
                  var21 = 16;
                  var28 = -1;
            }

            var30 = var22.substring(++var28, var28 + var21);
            var10001 = 0;
         }
      }
   }

   private void V() {
      long currentTime = System.currentTimeMillis();
      this.友何友树树何树友友何.removeIf(clickTime -> {
         HUD.A();
         return currentTime - clickTime > 1000L;
      });
      this.树友树树友友友友何何 = this.友何友树树何树友友何.size();
   }

   private void x() {
      long currentTime = System.currentTimeMillis();
      this.友何友树树何树友友何.add(currentTime);
      this.友何友树树何树友友何.removeIf(clickTime -> {
         HUD.A();
         return currentTime - clickTime > 1000L;
      });
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友何树树友何树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28614;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友何树树友何树树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[6½ªC\u000e©²V\u0088\u0085Óýò\u0097\u001fw, «oFñ\u0082ÐM*, \u0018c~ÜI\t»\u0018, ÝA\u0012üÓ¶Ä\u0092, \u0011&-\u0004'ÞiE, tç\u0014s;\u008e<\u0092µ\u0003a<I¸Ó{9î-Ú}ä")[var5]
            .getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void c() {
      x[0] = "kt?\u000b\u001d d4r\u0000\u0017=aiyF\u001f lo}\r\\&ej}F\u0016&{j}\t\u000ba參住栀桹厹会栙栋栀厣";
      x[1] = int.class;
      y[1] = "java/lang/Integer";
      x[2] = "\u001czq:F>\u0017u`u-*\u0015~w/\u0001=\u0018";
      x[3] = "m\u0005pdKTb\u001cr+!Ed\rkd\tfh\u0016kd\u0011";
      x[4] = "sw3V\u0015$|7~]\u001f9yju\u001b\u0017$tlqPT\"}iq\u001b\u001e\"ciqT\u0003eXLY";
      x[5] = "8\n\u0002T~AM*\t[o\u000e02\u001a\\fGX";
      x[6] = "INg\u001f>fINpC2iS\u0005p]:jI_=~#{ND}B";
      x[7] = "{Y\u0015\u0015\u00020{Y\u0002I\u000e?a\u0012\u0002W\u0006<{HOp\n X]\u0011K\u00067r";
      x[8] = boolean.class;
      y[8] = "java/lang/Boolean";
      x[9] = "\u000f!#n\t\u0019\u000f!42\u0005\u0016\u0015j4,\r\u0015\u000f0y\r\r\u001e\u0004'%!\u0002\u0004";
      x[10] = ".SmM87!\u0013 F2*$N+\u0000:7)H/Ky厓历叶伖栿厜伍桜栬桒";
      x[11] = float.class;
      y[11] = "java/lang/Float";
      x[12] = "\n}hAe\u0016\u0017h0r.\u0014\u0014}pG'\u0012";
      x[13] = "&:\u0017\u001c<i)zZ\u00176t,'QQ%g)!\\Q:k58\u00172<b \u0002X\u0013&c";
      x[14] = "fu\u0005\\MRfu\u0012\u0000A]|>\u0012\u001eI^fd_\u0015UR&V\u001e\u001cT";
      x[15] = "D_)H)\u000fZW3\u0007K\u0013]J";
      x[16] = long.class;
      y[16] = "java/lang/Long";
      x[17] = "\u0004!4YMI\u000f.%\u00160Q\u001c),_";
      x[18] = ".\u000fi\u0016U~!O$\u001d_c$\u0012/[Oe$\r4[[\u007f$\f&\u0001S~#\u0012i传佯佄优伴厌桤栫栀历";
      x[19] = "(<\u000f>5\u0004'|B5?\u0019\"!Is,\n''Ds3\u0006;>\u000f伈伏伾厀厙佴桌伏伾伞";
      x[20] = "C3O\u0019]lLs\u0002\u0012WqI.\tTDbL(\u0004T[nP1O4GnB8\u0013,SoU8";
      x[21] = "5\u001f:\u000e\t\t:_w\u0005\u0003\u0014?\u0002|C\u0010\u0007:\u0004qC\u000f\u000b&\u001d:/\t\t:\u0014u\u00030\u0007:\u0004q";
      x[22] = "w5TW$|xu\u0019\\.a}(\u0012\u001a>g}7\t\u001a*}}6\u001b@\"|z(T叿伞栂叟桊伯佡厀栂栅";
      x[23] = "x)\u0017E\u0017\u001fs&\u0006\nv\u0011x-\u0002P";
      x[24] = "Jq\u0010.\u0010|\u000b8\u000e/p佃伨桓桨桚伭佃桬厉桨COgD*\u0013 \u0013dM%";
      x[25] = "5\u0017U4:GoI\u0005N桑口案栵厧厍压口伌佱dwsD)N\u0002 (R5";
      x[26] = "\u0016J\naw\u0011L\u0014Z\u001b叆桯桫桨栢栂叆桯桫伬;qi\u0006\f\u001eFek\u000b\u0011";
      x[27] = "YO\u0011DL0\u0003\u0011A>栧伊叾桭口叽佣厔栤伩 RQ7\\\u0012JUA(\u0007";
      x[28] = "\b{g\u0006=2R%7|伒桌厯伝厕桥伒桌桵厃V\u0010=mP{n\u0016*4\u0001";
      x[29] = "+T\u001c\u0007cqj\u001d\u0002\u0006\u0003栊受桶传桳佞叐佉桶传j<j%\u000f\u001f\t`i,\u0000";
      x[30] = "Jx$68F\u0010&tL厉佼样伞佈休桓佼叭桚\u0015rv\u001dK:(!tPH";
      x[31] = "ca\u007f\u000f:>9?/u压桀叄伇桗桬桑伄栞伇N\u001856b:/\u001e)hb";
      x[32] = "t\u0014\u001a@\u000e\u0007.JJ:县厣叓佲栲佧县厣叓栶+\u000b\u001a\t!N\u0011C\u0001\u0006.";
      x[33] = "2+fJaDm?<K\u001e栺桅厃桃叮佃栺原伝伇-pH`'%J/\\:&";
      x[34] = "Y\n[zu4\u0018CE{\u0015伋厥史叹栎栌桏伻史佧\u0017+jZTC*xh\u0017W";
      x[35] = "\u0016it o\u0016Stn;\u0017=,,s1}ILsv8et";
      x[36] = "\u0017\u0014\u0002+IFMJRQ栢叢厰召佮伌司佼厰召3h\u0000E\u000bMU?[S\u0017";
      x[37] = "\n\u000f\u0011M\u0006\u001cPQA7伩伦桷佩根佪桭桢伳佩 [\u0006CR\u000f\u0018]\u0011\u001a\u0003";
      x[38] = "\u0000\u0006].\r\u0016_\u0012\u0007/r桨桷估桸伔桫伬伳厮厢I\u001c\u001aR\n\u001e.C\u000e\b\u000b";
      x[39] = "\u007fG\f@(~%\u0019\\:厙栀栂桥叾叹桃栀变伡=\u0003a}c\u001e[T:k\u007f";
      x[40] = "2&_\f\u0011\u0001hx\u000fv厠伻厕栄桷伫桺厥厕佀n\u001f\u0004\r+zVL\u0001\t&";
      x[41] = "\u00038\u001dYO6YfM#你伌伺佞佱佾叾案厤叀,HO-_:OEB;^";
      x[42] = "St(L\u0014*\t*x6\u000fM\rwrL\u001bsM+t\u0006fw\u000f$cKX7S\")6";
      x[43] = "xg\u0010h\\.;{\u0005w=$\u00130V>\ft\u0013\u0001Q?\\#u`\u000ekL+";
      x[44] = "@\u0016_@U\"\u001aH\u000f:栾桜佹叮桷叹佺历栽佰n\u0000\u0016'UKSF\u001a<\u0015";
      x[45] = "M9\u0014 \te\u0017gDZ伦栛只叁佸伇桢佟只叁%j\u001boM\u007f\u001a'D=T";
      x[46] = "7u\u001d\u001b@arh\u0007\u00008栚収又厦厢校佞栔佖厦a\ted:\u0004[A~k5";
      x[47] = "e\u000e?_$|?Po%伋但参佨体格桏栂作栬\u000eH+tdUoN7*d";
      x[48] = "\u001b\boM\u0018c\u001e\u0014pBwur\\5\u0004I%rm0Z\u000buD\tsF\u001ej";
      x[49] = "\rJ?G1\u0002\bV H^\u0014d\u001ed\u0007aEd/6Fd\u0018\r@6\u000b<\u001c";
      x[50] = "m\b\u000b8/ h\u0014\u00147@6\u0004\\Qq~b\u0004mY2.57\rQu}g";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = x[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(y[var4]);
            x[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友何树树友何树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   @EventTarget
   public void f(AttackEvent event) {
      this.x();
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14198;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])q.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            q.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/友何树树友何树树树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/友何树树友何树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != '$' && var8 != 'g' && var8 != 198 && var8 != 236) {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'C') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 't') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == '$') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'g') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 198) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (y[var4] != null) {
         return var4;
      } else {
         Object var5 = x[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 30;
               case 1 -> 58;
               case 2 -> 51;
               case 3 -> 19;
               case 4 -> 63;
               case 5 -> 22;
               case 6 -> 26;
               case 7 -> 54;
               case 8 -> 48;
               case 9 -> 13;
               case 10 -> 50;
               case 11 -> 53;
               case 12 -> 34;
               case 13 -> 59;
               case 14 -> 2;
               case 15 -> 18;
               case 16 -> 10;
               case 17 -> 15;
               case 18 -> 14;
               case 19 -> 46;
               case 20 -> 49;
               case 21 -> 44;
               case 22 -> 20;
               case 23 -> 41;
               case 24 -> 36;
               case 25 -> 35;
               case 26 -> 31;
               case 27 -> 40;
               case 28 -> 27;
               case 29 -> 25;
               case 30 -> 28;
               case 31 -> 39;
               case 32 -> 42;
               case 33 -> 8;
               case 34 -> 0;
               case 35 -> 37;
               case 36 -> 29;
               case 37 -> 7;
               case 38 -> 38;
               case 39 -> 3;
               case 40 -> 9;
               case 41 -> 32;
               case 42 -> 57;
               case 43 -> 43;
               case 44 -> 60;
               case 45 -> 61;
               case 46 -> 62;
               case 47 -> 11;
               case 48 -> 45;
               case 49 -> 4;
               case 50 -> 12;
               case 51 -> 56;
               case 52 -> 33;
               case 53 -> 17;
               case 54 -> 23;
               case 55 -> 52;
               case 56 -> 1;
               case 57 -> 24;
               case 58 -> 16;
               case 59 -> 6;
               case 60 -> 5;
               case 61 -> 47;
               case 62 -> 55;
               default -> 21;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            y[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      if (var5 instanceof String) {
         String var6 = y[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         x[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = y[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         x[var4] = var21;
         return var21;
      }
   }

   public int t() {
      return this.树友友友何何友何友友;
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   @EventTarget
   public void g(TickEvent event) {
      this.何何何何何何友树友友.n(this.isEnabled() ? 友何树友树何何友树树.树树何树何树何何友友 : 友何树友树何何友树树.树树友树友何树友何何, 59020024422499L);
      this.L();
      this.Y();
      this.V();
      String processedText = this.M(this.树何友树友友何友树何.getValue());
      float textWidth = this.P(processedText);
      super.树友树何树何友何树何 = Math.max(50.0F, textWidth + this.何树友何友树何树树友.getValue().floatValue() * 2.0F);
      this.U();
   }

   private void U() {
      this.何树友友何何树何友友.setRect(this.N(), this.C(), super.树友树何树何友何树何, super.何何树树树何何树友树);
   }

   public int A() {
      return this.树友树树友友友友何何;
   }

   private void Y() {
      HUD.A();
      boolean isLeftClickPressed = mc.options.keyAttack.isDown();
      if (!this.友何树何何何树何友树) {
         this.x();
      }

      this.友何树何何何树何友树 = isLeftClickPressed;
   }

   private void L() {
      HUD.A();

      try {
         try {
            Field fpsField = mc.getClass().getDeclaredField("fps");
            fpsField.setAccessible(true);
            this.树友友友何何友何友友 = fpsField.getInt(mc);
            return;
         } catch (Exception var13) {
            try {
               String debugText = mc.fpsString;
               if (debugText != null && debugText.contains(" fps")) {
                  String[] parts = debugText.split(" ");
                  int var7 = parts.length;
                  int var8 = 0;
                  if (0 < var7) {
                     String part = parts[0];

                     try {
                        int fps = Integer.parseInt(part);
                        if (fps > 0 && fps < 1000) {
                           this.树友友友何何友何友友 = fps;
                           return;
                        }
                     } catch (NumberFormatException var11) {
                     }

                     var8++;
                  }
               }
            } catch (Exception var12) {
            }

            if (mc.getDeltaFrameTime() > 0.0F) {
               this.树友友友何何友何友友 = Math.round(1.0F / mc.getDeltaFrameTime());
               return;
            }

            this.友树树树友友树树友何++;
            long currentTime = System.currentTimeMillis();
            if (currentTime - this.友树树树树树友树树何 >= 1000L) {
               this.树友友友何何友何友友 = (int)(this.友树树树友友树树友何 * 1000.0 / (currentTime - this.友树树树树树友树树何));
               this.友树树树友友树树友何 = 0;
               this.友树树树树树友树树何 = currentTime;
            }
         }
      } catch (Exception var14) {
         this.树友友友何何友何友友 = 60;
      }
   }

   private String M(String rawText) {
      HUD.A();
      if (rawText == null) {
         return "";
      } else {
         String processedText = rawText;
         if (rawText.contains("[fps]")) {
            processedText = rawText.replace("[fps]", String.valueOf(this.树友友友何何友何友友));
         }

         if (processedText.contains("[cps]")) {
            processedText = processedText.replace("[cps]", String.valueOf(this.树友树树友友友友何何));
         }

         if (processedText.contains("[username]")) {
            String username = mc.player != null ? WrapperUtils.f(111441258359257L) : "Player";
            processedText = processedText.replace("[username]", username);
         }

         if (processedText.contains("[world]")) {
            String worldName = mc.level != null ? mc.level.dimension().location().getPath() : "Unknown";
            processedText = processedText.replace("[world]", worldName);
         }

         if (mc.player != null) {
            if (processedText.contains("[x]")) {
               processedText = processedText.replace("[x]", this.树树何友树友何友树何.format(mc.player.getX()));
            }

            if (processedText.contains("[y]")) {
               processedText = processedText.replace("[y]", this.树树何友树友何友树何.format(mc.player.getY()));
            }

            if (processedText.contains("[z]")) {
               processedText = processedText.replace("[z]", this.树树何友树友何友树何.format(mc.player.getZ()));
            }
         }

         if (processedText.contains("[time]")) {
            long worldTime = mc.level != null ? mc.level.getDayTime() : 0L;
            int hours = (int)((worldTime / 1000L + 6L) % 24L);
            int minutes = (int)(worldTime % 1000L * 60L / 1000L);
            processedText = processedText.replace("[time]", String.format("%02d:%02d", hours, minutes));
         }

         if (processedText.contains("[ping]")) {
            processedText = processedText.replace("[ping]", String.valueOf(何树何树友树树友友何.u(mc.player, 86055205822349L)));
         }

         return processedText;
      }
   }

   private float P(String text) {
      HUD.A();
      if (HUD.instance.树友友友友树何树何友.K("Normal")) {
         何何友友树何树何友树 ttFont = Cherish.instance.t().H(18);
         return ttFont.D(text);
      } else {
         return mc.font.width(text);
      }
   }

   @EventTarget
   public void W(Render2DEvent event) {
      HUD.A();
      if (event.poseStack() != null && mc != null && mc.level != null && mc.player != null) {
         友树何友何友何树树树 fontManager = Cherish.instance.t();
         this.U();
         float animationProgress = (float)this.何何何何何何友树友友.D(124111691745592L);
         if (!(animationProgress <= 0.01F)) {
            String text = this.M(this.树何友树友友何友树何.getValue());
            if (text != null && !text.isEmpty()) {
               何何友友树何树何友树 ttFont = null;
               float textHeight;
               if (HUD.instance.树友友友友树何树何友.K("Normal")) {
                  ttFont = Cherish.instance.t().H(18);
                  textHeight = ttFont.x();
               } else {
                  textHeight = 9.0F;
               }

               float paddingValue = this.何树友何友树何树树友.getValue().floatValue();
               float textX = this.N() + paddingValue;
               float textY = this.C() + (super.何何树树树何何树友树 - textHeight) / 2.0F;
               if (!this.友友友何树何友友友树.K("Off")) {
                  float bgX = this.N();
                  float bgY = this.C();
                  float bgWidth = super.树友树何树何友何树何;
                  float bgHeight = super.何何树树树何何树友树;
                  int bgAlpha = (int)(this.何何树何树何树树何何.getValue().intValue() * animationProgress);
                  if (super.何友友友树树树何友何) {
                     bgAlpha = (int)(bgAlpha + 50.0F * animationProgress);
                  }

                  Color finalBgColor = new Color(0, 0, 0, Math.min(255, bgAlpha));
                  String dragColor = this.友友友何树何友友友树.getValue();
                  byte var25 = -1;
                  switch (dragColor.hashCode()) {
                     case -1955878649:
                        if (!dragColor.equals("Normal")) {
                           break;
                        }

                        var25 = 0;
                     case -1244845427:
                        if (dragColor.equals("Rounded")) {
                           var25 = 1;
                        }
                  }

                  switch (var25) {
                     case 0:
                        RenderUtils.drawRectangle(event.poseStack(), bgX, bgY, bgWidth, bgHeight, finalBgColor.getRGB());
                     case 1:
                        ShaderUtils.o(event.poseStack(), 100739365455537L, bgX, bgY, bgWidth, bgHeight, 4.0F, finalBgColor);
                     default:
                        if (this.何何友何何树树树何树.getValue()) {
                           Color lineColor = HUD.instance.getColor(0);
                           Color var29 = 何树友友树树友何树何.j(lineColor, animationProgress * 0.8F);
                           RenderUtils.drawRectangle(event.poseStack(), bgX, bgY, bgWidth, 1.0F, var29.getRGB());
                        }

                        if (super.何友友友树树树何友何) {
                           Color dragColor = new Color(255, 255, 255, (int)(100.0F * animationProgress));
                           RenderUtils.drawRectangle(event.poseStack(), bgX - 1.0F, bgY - 1.0F, bgWidth + 2.0F, bgHeight + 2.0F, dragColor.getRGB());
                        }
                  }
               }

               Color textColor = HUD.instance.getColor(0);
               textColor = new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), (int)(textColor.getAlpha() * animationProgress));
               if (HUD.instance.树友友友友树何树何友.K("Normal") && ttFont != null) {
                  ttFont.Q(event.poseStack(), text, textX, textY + 1.0F, textColor.getRGB(), this.友树友何树树树何树何.getValue(), 0.5);
               }

               fontManager.w().t(event.poseStack(), text, textX, textY, textColor.getRGB(), this.友树友何树树树何树何.getValue());
               this.S(event.poseStack());
            }
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "刘凤楠230622109211173513";
   }
}
