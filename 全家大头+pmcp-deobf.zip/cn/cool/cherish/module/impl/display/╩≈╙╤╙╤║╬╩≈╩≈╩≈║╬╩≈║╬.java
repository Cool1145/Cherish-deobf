package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.友友友何树友何树树树;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.ui.何何友友树何树何友树;
import cn.cool.cherish.ui.友树何友何友何树树树;
import cn.cool.cherish.utils.animations.友何树友树何何友树树;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.ChatFormatting;

public class 树友友何树树树何树何 extends 友友友何树友何树树树 implements 何树友 {
   public static 树友友何树树树何树何 何友树树何友友何树友;
   private final BooleanValue 何友何树何树树树友何 = new BooleanValue("Important", "重要的模块", false);
   private final NumberValue 树树友友何何何何友友;
   private final NumberValue 树何友树树何友树树友;
   private final NumberValue 树树友友树友友友何友;
   private final BooleanValue 友友友树何友友友友何;
   private final BooleanValue 树树友友何树树友树何;
   private final ModeValue 何何友友何树树树何树;
   private final NumberValue 树树何树何树树何树何;
   private final ModeValue 树友友友友何何何何何;
   public final ModeValue 友友友树树树树树友友;
   private final BooleanValue 友树友何友友树何树友;
   private final List<Module> 树何何何友树树何树何;
   private boolean 友何友树树树友树何友;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final Object[] n = new Object[49];
   private static final String[] o = new String[49];
   private static int _解放村多种2队1144号 _;

   public 树友友何树树树何树何() {
      super("ModuleList", "模块列表", 150.0F, 100.0F, 0.0F, 120.0F);
      HUD.A();
      this.树树友友何何何何友友 = new NumberValue("Height", "高度", 0, -5, 10, 1);
      this.树何友树树何友树树友 = new NumberValue("Width", "宽度", 2, 1, 5, 1);
      this.树树友友树友友友何友 = new NumberValue("Font Size", "字体大小", 18, 6, 20, 1);
      this.友友友树何友友友友何 = new BooleanValue("Lowercase", "小写", false);
      this.树树友友何树树友树何 = new BooleanValue("Space", "空格", true).A(() -> {
         HUD.A();
         return HUD.instance != null && HUD.instance.友何友树树何树友友友.K("English");
      });
      this.何何友友何树树树何树 = new ModeValue("Background Mode", "背景模式", new String[]{"Normal", "Shadow", "None"}, "Normal");
      this.树树何树何树树何树何 = new NumberValue("Background Alpha", "背景透明度", 80, 1, 255, 1);
      this.树友友友友何何何何何 = new ModeValue("Line Mode", "线条模式", new String[]{"Side", "Short", "Top", "Semi", "None"}, "Right");
      this.友友友树树树树树友友 = new ModeValue("Suffix Mode", "后缀模式", new String[]{"Simple", "Dash", "Bracket", "Right", "Off"}, "Simple");
      this.友树友何友友树何树友 = new BooleanValue("Text Shadow", "文字阴影", false);
      this.树何何何友树树何树何 = new ArrayList<>();
      this.友何友树树树友树何友 = true;
      何友树树何友友何树友 = this;
      this.J(true);
      if (Module.Z() == null) {
         HUD.U(new String[1]);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5026432848302753187L, -4496600155827146311L, MethodHandles.lookup().lookupClass()).a(231522114133707L);
      // $VF: monitorexit
      c = var10000;
      c();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(33107475850327L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[52];
      int var7 = 0;
      String var6 = "\u001cõ<\u001db\u008cÑg\råð\u0007 ½²ò\u0018G°\u0081óþHK?ô(\u008b\u0095[cCo*¥í5Õ\u0010QË\u0010a}\u0005RÅû\u008a³Bl3\u001bÓ_ïô\u0010Z\u008e\u000eË\u009b]ÛF\u008eØ²PÌ\u009cù\u0095\u0010]2\u0085ÝiòÂ\u0006^HQÒ: ø^\u0010.ä\u0010WE9V\u0082R[àW\u0094`P\u0016 ÔÐ(\u0017Xz,1~¯1¾YÒ\u0002Ê~¡°%bK-\u009aÀ/\n6*q\u0096.(½¶Î\u008b\u0007\u0099\u00172\b\u0093ïyÏ÷ß\u000f'%t,\u0092\u0088·ÄàÝ¯²ì^Þ*_\b\u0019ùc3\u0084\u0081\u0018OÊÆ\u000bë\u0012_dx\u0005\u0012\u008d\u0086wÕî\u000bLd¾L#M\u0014\u0010u\u0016ù4\u0080½\u009e8\u0099\u0000\u008c&Ê\u0082óG\u0010Ã\u00842\náê'ÍmZ k¿Ue¥\u0018Mr3E¼î÷ÒÉ7#\u0087Ö\u0097\u0095\\\u008aÓ\u00ad\u0010ÉÐ\u001dõ\u0010mê\u001e³Ý\u0090\u0095¦NK\u0014>fïm\u001a\u0010ît{\u0018,\u0089Á\u0087\u000b\u0017I[9køÃ\u0010\u0080âèÄ\u008anÎ:\u000bR\u0017²\u000fRö\n\u0010\u0084ñ\u0086!¹bÜW3\u0090z¼ÚÚå«\u0018á=\u009d#È\u009bZ\në\u0080\u009cÙ\u001b\r`\u0096In\u008b±ô«½\u0011\u0010µ\f²û8P-h¯IG@(\u0083®\u0082\u00102\u0088¢³©=)²\u0018RÖ0ï\u0096¨¬ ô\t\u0082[n×È¾\"\u008fw\u001cnÁïª\u0002c¬IØ÷Ñ\bPKYs =\u0086÷\u0010»Ëiæèz&\u001aJ\u0084Ï\u0098¶\u0099\u009au Îµø¤¯Z3/\u001e¾$\u0004ç\u0089\u0089Àâ²VÞ§7¢Ñ0¶\u0085\\súCE\u00100Í¶ËÒ'¤>Y±ä\u008bÐðcy Ï\u008a\u001cK\u008fUS\u0091\u008d\u0088W\u0083j°b]\u0014\u008f~¶.\u0000\u0018\u009cke\\îhsN¶\u0010Ò\u000b\u0097Â\u0093áPy-nÚ¹\u0004Ä\u009a= \u0099ï®\u00175ã·\u009cw¸Å\u0011æð\u00865\u0091~SJÖÿòÈÀ8\u0014ÓWiRß\u0010éþ:\u0016»\u007f\u0092hhdpZÖ\u0099\u0082w µæ]],o¥\u0088RP\u0003V¶\u0082\u009c0\u008a\u0015~\u0005rW'\u0091JÚ\u001a®\u008a\u001bÂv \f¥T&q\u00918v³¼[\u0003Ò&Ýp\u000e7*Êü°\u0094\u0016Âr£öÉ¡ÇF n+ë/±\\gô*\u0000¬xk\u0084Bß\u0000ô¼fBYÄ\bþwUÊ³-_\u0087 \u0001w\u0005¶ÿ\u001dv\u0092\b¬^Å\u001b¾\u0016Ú\u008e^Þ»ôé\n\u0093\u000eØ.·¹1ºÊ\u0010\u0086\u00adUôtæqx\u0085\u009cï©ö\u0097\u009f¹ Û)¥oí´\nI½\"öz{¥\u0000\u0080É(,Í\u0011Y[q\u0092\u0083ã[ÓC±\u009f\u0010ÛBØ¹ZÌ\u008b\u007fº\u0016W\u008dr\u009a£¤\u0010û\u008e1/¼¿\u00995VÂ\u0000\u0000\u008as\u0019\u0013\u0010çÆÂïü.mÌ\tLÒà} ·ü\u0018?\u001buuú\u000f\u009aLþÖ<\u0096%\u008asÌÓö\u00adÑª\u009eê@ à\r\u0016ü\u0014¤`1\u0005¿\u008eY6æë>\u007f°°ÕV<*{±S£U\u0092rcV\u0010ÑÑ²iS\u0087Ät@\u0081\u008f\u0082\tì®\u008a\u0010tr\u0004\u000e\u0019rÓøuL\u0007\u0084BÞué\u0010þT\u0088\u000bÒ\u0089\u00954cåãj\u008fô\u001d\"\u0010\ta¸£TÐÃ¹\u0089\u0018£jCÒ÷´\u0010øùÔ\u001eË\u001dÌ©>è¦Ò)\u009f\f!\u0018Îg¹\u0000ÒiÔ8\u0083g§\u0013\u0089\u0011\u0095LªäT\u000ee\u008f\u0099ñ\u0010R\tü1ëaL%\u001dªE\r½\u0014¦o\u0010\u000bÅnèëê\u008cnµ~rÊ$z9Ê\u00106\u0098«â\u0000E{RNÛl¢\u0013¹W:\u0010®j\u009b¹\u0094\u0011[\u0096\"\u0003î\u0005]0\u0092å\u0010ùXùð\u008b\u0098µGÿ\u009bJÓ¸q´j\u0010á\u000b\u0086\u0083Ä\u008a\rÇ»ÄJk\u0017\u009b\u00ad\u009e";
      short var8 = 1097;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = d(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     k = var9;
                     l = new String[52];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "gCU\u0005õöþZìF\u0097\u00893¸\u0084B(Å5\u0010tÌ\u0083l;\u000e¯±(\u0015\u001dv\u0087/)úDö³\u000e5\u0003¨d\u008aÂN?\u009e%K,§y\u008dM$";
                  var8 = 57;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void c() {
      n[0] = "A-E%\u001fZNm\b.\u0015GK0\u0003h\u001dZF6\u0007#^\\O3\u0007h\u0014\\Q3\u0007'\t\u001b栳厈厠伓桡栤栳伖桺伓";
      n[1] = "_\\+S{#TS:\u001c\u0007:[I4_0\nM^8B!&ZS";
      n[2] = "a\u0001eZc]nA(Qi@k\u001c#\u0017yFk\u00038\u0017m\\k\u0002*Me]l\u001ce史余栣叉桾伞佬叇栣栓";
      n[3] = boolean.class;
      o[3] = "java/lang/Boolean";
      n[4] = "n&\u001eN`^afSEjCd;X\u0003yPa=U\u0003f\\}$\u001ecz\\o-B{n]x-";
      n[5] = "\u0016r#@4;\u00192nK>&\u001coe\r6;\u0011iaFu原厾受佘栲厐企桤栍栜";
      n[6] = float.class;
      o[6] = "java/lang/Float";
      n[7] = "\u0016*)5[s\u0019jd>Qn\u001c7oxB}\u00191bx]q\u0005()\u0014[s\u0019!f8b}\u00191b";
      n[8] = "\u0016\u000f\u001c\u001d\\$\b\u0007\u0006R>8\u000f\u001a";
      n[9] = "O\u0011,.|h@Qa%vuE\fjc~hH\nn(=nA\u000fncwn_\u000fn,j)d*F";
      n[10] = "z-0\nB%um}\u0001H8p0vG[+u6{GD'i/0$B.|\u0015\u007f\u0005X/";
      n[11] = "tXow/ \u0001xdx>o|`w\u007f7&\u0014";
      n[12] = "\u001b\u0019\u001f\u0019\u0013,\u001b\u0019\bE\u001f#\u0001R\b[\u0017 \u001b\bEz\u0017+\u0010\u001f\u0019V\u00181";
      n[13] = ";\u001e$ntP;\u001e32x_!U3,p\\;\u000f~'lP{=?.m";
      n[14] = "VGc\u000bl8VGtW`7L\fTM`%~MeH`%LKyB";
      n[15] = "MoGc\r<8OLl\u001csEW_k\u0015:-";
      n[16] = void.class;
      o[16] = "java/lang/Void";
      n[17] = "2\u000b\u001d5\u001b2=KP>\u0011/8\u0016[x\u001925\u0010_3Z\u0010>\u0001F:\u0011";
      n[18] = "?\u001fG9A{\u000b<Hy\fp\u0001!M$\u00076\t<@\"\u0003}J\u001eK3\u001at\u0001h";
      n[19] = "~#GL\u0017\u0019qc\nG\u001d\u0004t>\u0001\u0001\u0015\u0019y8\u0005JV桧佈历厢佺桩厽取优似";
      n[20] = "\u007ffHfe\ftiY)\u0004\u0002\u007fb]s";
      n[21] = "\u001eyv|\u0006IB$v\u000e叵伮厺栍栊栗叵桪伤受\u00134\u0006\f@p+i\u0006\u0001\u0002";
      n[22] = "\u0002lw$\u0006~@9f.t伝佣桌栍桖伩伝栧厖栍OH D7t!\u001d>C0";
      n[23] = "t|Lo\u007f:(!L\u001d桖栙低栈佴栄桖佝栊佌)&!px)\u0012aszv";
      n[24] = "\u0017\u0018]@\u0011|C\u0017]V/T|,|/\u001efV\n\u0013HJiV\u001c";
      n[25] = "*f6!\u0001Iv;6S栨伮厎栒桊伎史桪桔又Sh_\u0003&3h/\r\t(";
      n[26] = "9Z\u0016\u001bGt}KRV+\u0015\u0007NVNT:kY\u0013[QHm@\u0014TV*jY\u0014T+";
      n[27] = "\n\u001cd\"\"qVAdP住厈桴桨作厓发伖桴厲\u00017\u007f.\u001fA;k\".";
      n[28] = "GZq\u0014!}\u0005\u000f`\u001eS桚厸桺住桦伎厀伦桺住\u007fo#\u0001\u0001r\u0011:=\u0006\u0006";
      n[29] = "\"\u0002;\u00007\u0018~_;r栞栻历厬伃桫栞叡桜伲^Oh@?\u0017<\u0017{\u001cu";
      n[30] = "D18Lkw\u0018l8>桂伐佾企厞栧桂伐栺企]\u0003)q\u00192mB`|^";
      n[31] = "/\u0014Rmg@+Y\u001e!\u0002桩栏厦桻厒佟桩叕伸伿Q;\u0001&Y\u0007a?Lj\u0015";
      n[32] = "O\u0012q\u0012Hv@\u0015u\u000f:\u0015$\u0010a\u0014\u0000(\\\u001cc\nJG";
      n[33] = "\u000e\u0017\u0013O\u001bJJ\u0006W\u0002w?0\u0003S\u001a\b\u0004\\\u0014\u0016\u000f\rv";
      n[34] = "_\u0017APhb\u0003JA\"桁桁叻厹佹使伅伅叻厹$\u00196(SB\u001f^d\"]";
      n[35] = "*\u0000D{Vl.M\b73桅栊伬桭会株企低厲厷G\n-#M\u0011w\u000e`o\u0001";
      n[36] = "k\bK\u000e-t?\u0018A\u0019A叅叄厩桩伸厂佛佚桳伭e-d<\u0001\u001c\u0017yt6\u0016";
      n[37] = "AUHyqn\u0003\u0000Ys\u0003厓厾伱栲住佞伍厾厯佶\u0012?0\u0007\u000eK|j.\u0000\t";
      n[38] = "8\r|-3\u0018dP|_叀叡厜桹佄厜叀叡厜伽\u0019bl@%\u0018{:\u007f\u001co";
      n[39] = "r\u0012u\u0012\u0012\u000e.Ou`K4h\u0015s[ILv\u0019v`_^vD{\u0018ARs\u007f";
      n[40] = "/2Ik-gsoI\u0019佀厞伕框佱栀栄桄压伂,$r?2'N|acx";
      n[41] = "s\u001co'VQ/AoU厥桲受伬叉厖桿伶栍厲\nh\t\tn\th0\u001aU$";
      n[42] = "t9a\b-k0(%EA厔众厇桀栠伜桎厉厇厚9~g6%3R\u007f6:&";
      n[43] = "_d}8I<\u001bu9u%栙厢叚历及格佝桸佄历\t\u001a0\u001dx/b\u001ba\u0011{";
      n[44] = "\u0011h-M\u0001aM5-?佬伆厵叆伕栦栨桂伫栜H\u0000\u0001'\u0017o#\u0001P+\u0014";
      n[45] = ",b\u001f^\\mp?\u001f,桵厔厈双厹佱伱伊伖佒z\u0013\\+*e\u0011\u0012\r')";
      n[46] = "\nc9D\rU\u0004}1\u001blCm=nFR\u0017m\ff\u0014\u0002\u0015Wj=\u000e\\\u0012";
      n[47] = ")o\u000buI\u000f}\u007f\u0001b%厾历栔栩佃另桤桜収栩\u001eI\u001f~f\\l\u001d\u000ftq";
      n[48] = "Bd\u0003\u001c ~\u001e9\u0003n栉桝另及桿厭叓厇佸及fU~4N1]\u0012,>@";
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7215;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/树友友何树树树何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u001d4ù¸²{å*, ¸\u0081m\u0013AÓö\u0001~CZ\u00adpsò¡, _\u001aPÂèÍÃ£, 6b§¯\u0003\u0006ï\u00ad, N_hÆ\u0010«\"Ô, àÃ}PZ\u007fïg, -\u008eÂ\u0095\u0014\u00adm\u000eû¬¶kü2\u0011à, ê\u0001ÍþSá6Csµ\u009bInG\u0093µ \u0015®î´!3Ä, :\u00adª\u000e¥¾%F*\u0097\u001fB\u008b9Ë\u0004, ûÍ²].±\u0089\t, Ö\u0018Þé\u009e\u00adê\u009d, \u0016ä¹o\u0099\u0001y\u0013½q\u001dP(\u009f\u0014X, ¥ï¦?\u007fpví, %Ïõ\u000e\u0094Ð<\u009a, %WÃ´gC")[var5]
            .getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树友友何树树树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @EventTarget
   public void c(TickEvent event) {
      HUD.A();
      if (!this.Q(new Object[]{52406761729175L})) {
         何何友友树何树何友树 font = Cherish.instance.t().H(this.树树友友树友友友何友.getValue().intValue());
         boolean isNormal = HUD.instance.树友友友友树何树何友.K("Normal");
         Cherish.instance.getModuleManager().p().forEach(modulex -> {
            HUD.A();
            if (!this.树何何何友树树何树何.contains(modulex)) {
               this.树何何何友树树何树何.add(modulex);
            }
         });
         this.树何何何友树树何树何.removeIf(modulex -> {
            HUD.A();
            return (modulex.Z() == 树何友友何树友友何何.友友友树何友何何树何 || modulex.Z() == 树何友友何树友友何何.友友树树何友树树友树) && this.何友何树何树树树友何.getValue();
         });
         this.树何何何友树树何树何.sort(Comparator.<Module>comparingDouble(modulex -> {
            HUD.A();
            String name = this.K(modulex);
            return isNormal ? font.D(name) : mc.font.width(name);
         }).reversed());
         this.树何何何友树树何树何.forEach(modulex -> modulex.D().n(modulex.isEnabled() ? 友何树友树何何友树树.树树何树何树何何友友 : 友何树友树何何友树树.树树友树友何树友何何, 59020024422499L));
         float height = 0.0F;
         float maxWidth = 0.0F;
         float baseModuleHeight = font.x() + this.树树友友何何何何友友.getValue().intValue() + 3;

         for (Module module : this.树何何何友树树何树何) {
            if (module.isEnabled() || !module.D().A(14032659181055L, 友何树友树何何友树树.树树友树友何树友何何)) {
               String text = this.K(module);
               float currentWidth = isNormal ? font.D(text) : mc.font.width(text);
               maxWidth = Math.max(0.0F, currentWidth);
               height = 0.0F + baseModuleHeight * (float)module.D().D(124111691745592L);
               break;
            }
         }

         super.树友树何树何友何树何 = maxWidth + this.树何友树树何友树树友.getValue().intValue() * 2 + (!this.树友友友友何何何何何.K("Top") ? 1 : 0);
         super.何何树树树何何树友树 = height + (!this.树友友友友何何何何何.K("Top") && !this.树友友友友何何何何何.K("Semi") ? 0 : 1);
         this.友何友树树树友树何友 = super.友友何树何何何友友何 > mc.getWindow().getGuiScaledWidth() / 2.0F;
      }
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/树友友何树树树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'E' && var8 != 234 && var8 != 165 && var8 != 245) {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 242) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 218) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'E') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 234) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 165) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 6;
               case 1 -> 59;
               case 2 -> 9;
               case 3 -> 45;
               case 4 -> 5;
               case 5 -> 40;
               case 6 -> 43;
               case 7 -> 25;
               case 8 -> 19;
               case 9 -> 1;
               case 10 -> 33;
               case 11 -> 17;
               case 12 -> 8;
               case 13 -> 31;
               case 14 -> 61;
               case 15 -> 49;
               case 16 -> 36;
               case 17 -> 18;
               case 18 -> 60;
               case 19 -> 4;
               case 20 -> 53;
               case 21 -> 2;
               case 22 -> 14;
               case 23 -> 62;
               case 24 -> 41;
               case 25 -> 44;
               case 26 -> 26;
               case 27 -> 23;
               case 28 -> 54;
               case 29 -> 58;
               case 30 -> 39;
               case 31 -> 63;
               case 32 -> 46;
               case 33 -> 24;
               case 34 -> 12;
               case 35 -> 29;
               case 36 -> 11;
               case 37 -> 55;
               case 38 -> 52;
               case 39 -> 13;
               case 40 -> 32;
               case 41 -> 42;
               case 42 -> 37;
               case 43 -> 28;
               case 44 -> 56;
               case 45 -> 3;
               case 46 -> 50;
               case 47 -> 35;
               case 48 -> 16;
               case 49 -> 51;
               case 50 -> 10;
               case 51 -> 57;
               case 52 -> 15;
               case 53 -> 7;
               case 54 -> 38;
               case 55 -> 22;
               case 56 -> 27;
               case 57 -> 0;
               case 58 -> 34;
               case 59 -> 48;
               case 60 -> 21;
               case 61 -> 47;
               case 62 -> 20;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   @EventTarget
   public void W(Render2DEvent event) {
      HUD.A();
      if (!this.Q(new Object[]{52406761729175L})) {
         友树何友何友何树树树 fontManager = Cherish.instance.t();
         int count = 0;

         for (Module module : this.树何何何友树树何树何) {
            float animOut = (float)module.D().D(124111691745592L);
            if (module.isEnabled() || !module.D().A(14032659181055L, 友何树友树何何友树树.树树友树友何树友何何)) {
               String moduleName = this.K(module);
               Color color = HUD.instance.getColor(0);
               boolean isNormal = HUD.instance.树友友友友树何树何友.K("Normal");
               float stringWidth = isNormal ? fontManager.H(this.树树友友树友友友何友.getValue().intValue()).D(moduleName) : fontManager.w().Y(moduleName);
               float moduleHeight = fontManager.H(this.树树友友树友友友何友.getValue().intValue()).x() + this.树树友友何何何何友友.getValue().intValue() + 3;
               float finalX = this.友何友树树树友树何友
                  ? this.N()
                     + super.树友树何树何友何树何
                     - stringWidth
                     - (!this.树友友友友何何何何何.K("Top") ? 4 + this.树何友树树何友树树友.getValue().intValue() : 3 + this.树何友树树何友树树友.getValue().intValue())
                  : this.N() + (!this.树友友友友何何何何何.K("Top") ? 1 : 0);
               float startX = this.友何友树树树友树何友 ? this.N() + super.树友树何树何友何树何 + 30.0F : this.N() - stringWidth - 30.0F;
               float animatedX = startX + (finalX - startX) * animOut;
               float renderY = this.C() + 0.0F + 1.5F + (!this.树友友友友何何何何何.K("Top") && !this.树友友友友何何何何何.K("Semi") ? 0 : 1);
               if (animOut > 0.0F) {
                  float bgY = renderY + -1.5F;
                  float bgWidth = stringWidth + this.树何友树树何友树树友.getValue().intValue() * 2;
                  int bgAlpha = (int)(this.树树何树何树树何树何.getValue().intValue() * animOut);
                  String textColor = this.何何友友何树树树何树.getValue();
                  byte textX = -1;
                  switch (textColor.hashCode()) {
                     case -1955878649:
                        if (!textColor.equals("Normal")) {
                           break;
                        }

                        textX = 0;
                     case -1819712192:
                        if (textColor.equals("Shadow")) {
                           textX = 1;
                        }
                  }

                  switch (textX) {
                     case 0:
                        RenderUtils.drawRectangle(event.poseStack(), animatedX, bgY, bgWidth, moduleHeight, new Color(0, 0, 0, bgAlpha).getRGB());
                     case 1:
                        ShaderUtils.u(event.poseStack(), animatedX, bgY, 70079527892595L, bgWidth, moduleHeight, 3.0F, 14.0F, new Color(0, 0, 0, bgAlpha));
                  }

                  if (!this.树友友友友何何何何何.K("None")) {
                     Color lineColor = 何树友友树树友何树何.j(color, 0.7F * animOut);
                     float lineY = renderY + (this.树友友友友何何何何何.K("Short") ? -0.5F : (isNormal ? -1.5F : -1.0F));
                     float lineHeight = this.树友友友友何何何何何.K("Short") ? moduleHeight - 2.0F : moduleHeight;
                     float lineX = animatedX + (this.友何友树树树友树何友 ? stringWidth + this.树何友树树何友树树友.getValue().intValue() * 2.0F : -1.0F);
                     String var35 = this.树友友友友何何何何何.getValue();
                     byte var36 = -1;
                     switch (var35.hashCode()) {
                        case 79860828:
                           if (!var35.equals("Short")) {
                              break;
                           }

                           var36 = 0;
                        case 2576759:
                           if (!var35.equals("Side")) {
                              break;
                           }

                           var36 = 1;
                        case 2573198:
                           if (!var35.equals("Semi")) {
                              break;
                           }

                           var36 = 2;
                        case 84277:
                           if (var35.equals("Top")) {
                              var36 = 3;
                           }
                     }

                     switch (var36) {
                        case 0:
                        case 1:
                           RenderUtils.drawRectangle(event.poseStack(), lineX, lineY, 1.0F, lineHeight, lineColor.getRGB());
                        case 2:
                           RenderUtils.drawRectangle(
                              event.poseStack(),
                              animatedX + (this.友何友树树树友树何友 ? 0 : -1),
                              renderY - 2.5F,
                              stringWidth + 1.0F + this.树何友树树何友树树友.getValue().intValue() * 2,
                              1.0F,
                              lineColor.getRGB()
                           );
                           RenderUtils.drawRectangle(event.poseStack(), lineX, lineY, 1.0F, lineHeight, lineColor.getRGB());
                        case 3:
                           RenderUtils.drawRectangle(
                              event.poseStack(), animatedX, renderY - 2.5F, stringWidth + this.树何友树树何友树树友.getValue().intValue() * 2, 1.0F, lineColor.getRGB()
                           );
                     }
                  }

                  Color textColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(color.getAlpha() * animOut));
                  float textX = animatedX + this.树何友树树何友树树友.getValue().intValue();
                  if (isNormal) {
                     fontManager.H(this.树树友友树友友友何友.getValue().intValue())
                        .Q(
                           event.poseStack(),
                           moduleName,
                           textX,
                           renderY
                              + fontManager.H(this.树树友友树友友友何友.getValue().intValue()).f(moduleHeight)
                              - 1.0F
                              + (HUD.instance.友何友树树何树友友友.K("Chinese") ? 0.5F : 0.0F),
                           textColor.getRGB(),
                           this.友树友何友友树何树友.getValue(),
                           0.5
                        );
                  }

                  fontManager.w()
                     .t(event.poseStack(), moduleName, textX, renderY + (moduleHeight - 1.0F) / 2.0F - 4.0F, textColor.getRGB(), this.友树友何友友树何树友.getValue());
               }

               float var10000 = 0.0F + moduleHeight * animOut;
               count++;
               break;
            }
         }

         this.S(event.poseStack());
      }
   }

   private String K(Module module) {
      HUD.A();
      String name = HUD.instance.友何友树树何树友友友.K("English") && this.树树友友何树树友树何.getValue() && this.树树友友何树树友树何.P().get()
         ? module.G().replaceAll("([a-z])([A-Z])", "$1 $2").replaceAll("([A-Z])([A-Z][a-z])", "$1 $2")
         : module.G();
      if (this.友友友树何友友友友何.getValue()) {
         name = name.toLowerCase();
      }

      String suffix = module.q() == null ? "" : ChatFormatting.GRAY + " " + (this.友友友树何友友友友何.getValue() ? module.q().toLowerCase() : module.q());
      return name + suffix;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖黑水";
   }
}
