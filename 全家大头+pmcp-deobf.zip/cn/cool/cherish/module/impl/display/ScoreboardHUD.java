package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.友友友何树友何树树树;
import cn.cool.cherish.module.impl.misc.何树何树树友何何友树;
import cn.cool.cherish.ui.何树友树友树友树树何;
import cn.cool.cherish.ui.何树树树友树树树树树;
import cn.cool.cherish.ui.树何何何何何树友树友;
import cn.cool.cherish.utils.player.何树何树友树树友友何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.lzq.injection.asm.invoked.render.MinecraftFontTextEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.ChatFormatting;
import net.minecraft.world.scores.Score;
import net.minecraft.world.scores.Scoreboard;
import why.tree.friend.antileak.utils.CryptUtil;

public class ScoreboardHUD extends 友友友何树友何树树树 implements 何树友 {
   public static ScoreboardHUD instance;
   private final ModeValue 树友友树树树树友友友 = new ModeValue("Mode", new String[]{"Normal", "Modern", "Glass"}, "Normal");
   private final 何何何友友何树何何何 树友树友树何友友友树 = new 何何何友友何树何何何("Server Name", "Cherish.top");
   private final BooleanValue 友何何树何友何树树树 = new BooleanValue("Red Number", false);
   private final NumberValue 树友何树友树友何何树 = new NumberValue("Glass Spacing", "Glass间距", 2, 0, 10, 1).A(() -> this.树友友树树树树友友友.K("Glass"));
   private final NumberValue 何何友何友树友友何何 = new NumberValue("Glass Corner Radius", "Glass圆角", 6, 2, 12, 1).A(() -> this.树友友树树树树友友友.K("Glass"));
   private final NumberValue 友友树树友友树友友友 = new NumberValue("Glass Padding", "Glass内边距", 8, 4, 15, 1).A(() -> this.树友友树树树树友友友.K("Glass"));
   private List<Score> 友友何友友树树友友树 = null;
   private List<Score> 友树何友树友树友何何 = null;
   private boolean 树何友树何树树友友树 = false;
   private boolean 树友友友树何树何树树 = false;
   private long 何树何何何友何树友何 = 0L;
   private float 树何友何友友树树树树 = 1.0F;
   private float 树何树何何何树树树友 = 0.0F;
   private static final long c;
   private static final String[] k;
   private static final String[] l;
   private static final Map m = new HashMap(13);
   private static final long n;
   private static final Object[] o = new Object[33];
   private static final String[] p = new String[33];
   private static int _何建国230622195906030014 _;

   public ScoreboardHUD() {
      super("ScoreboardHUD", "自定义计分板显示", 140.0F, 20.0F);
      instance = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7942948748611428688L, 8831298878982544124L, MethodHandles.lookup().lookupClass()).a(37894713656698L);
      // $VF: monitorexit
      c = var10000;
      c();
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(75529463736439L << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[24];
      int var12 = 0;
      String var11 = " 8>\u0092°K`Û3\u0017Ëä¶yô\u0092Í#\u008e³\u0016ÁÑë\u0018Y4~\u0095\b\u0002\u0007\u0082#\u008f\u009f\u009f\n\f\u009fÃÜ%jÒ\tî\u009c\u0097\u0010\u0018\u008d\u0003\u0016æj\u0095} \u0089Ô§¸sûr Å×^\u0017Ô*M¶{öýì¢N\u009c\u000f\u0088\u00112©KG°½D5hÑðéØ½ ¹©7\u000eä«i\u0084>\u008eI\u0001¼;²Þ:S\u0016\u008dÁ]¶»\u0010F´\u0005éÊeU\u0010©ê\u0099\u0002\u0019}«?²¢)BÆ*\u0086\u0017 Ï\u0012\u009efiÇ\u0097¤Ñù\u0001\u0016'N=\u0004\u001d«\u0084N\u0000\u0092à0µ®\u008f\u001cÇrí¸  ßh¡íb®\u001aµ4ÿ'zÊCùõ\u000e\u009f»e÷\u007f¦·u\u0099*\u0095ÛÉ\u009f ©½î·Õ©+}\u008aO\u009b»\u00836\"Á]ïÖKJ%±\u00ad`¸\u0098¨\u0016\u009d1\u008e Á\u008aío\u009dÿ¹j\u0091\u0003dÀ\u008c\u0082\u0088_¬OËpv\u001eñW\u0015w\u0085ä\u0015?{\u0004\u0018º|Å1ù\u00913ùoÂ!¥-\u0018\u0086\u0006³a\u0088\u0016\u0097\u0007<\u0019\u00100Ñ¨\"Ë\u0086èh\u0015Ô?·\u0099\u0087ý\u00828 U\u0096Ð}0ÞúA*0T\u0090Í\u0091l´\u008f¼IîËSÈ ½üT_À\u0004è\u0095gìIÔº°\u0003ãêåiz\u009bÎ´Èµ\u009d®åB§q çÖ#y\u0084\b³8\u0011\u0096Ä\u0085Ä]\u00107©^°LåÎ.\u0092ðödø!\u009cI\u0007\u0010\u008a.½Q_u\u0092a¸\u0091\u008d\u0082\bhº\u0082 \u000b\u0092\u0004ú\u008c\\Ó¦Ì7é´\bÉ\u0090d ¥>NNßì¸;½i/\u00ad\"ºÈ à}hv\u008f>\u00ad(\u009aËªkàÒ\u009a\u0099·>%\u0001\u0080WÌWò¡LÏ\u0012h\"þ(â·¶\u0096JùmÜi%[ó-¬²y¿c\u001cGcZ\u0080\"\u008a\u0080¡\f\u0017\u0089\u008b\n¶U\u0098êwõTH\u0010\u0093Q\u00910\u0004}Å\u00840Wþ2=v§Â \u009a\u000b^Ú©\u0093c\u0010$Ö\u008b£W´+}\u0094ú·¤º\u0002s'Ñ:OO\u00812ø\u00ad YÓ\u001d1èl÷\u008c|æ{M\u0006fn\u000e´H©_\u009dF\u008a_°9ïÚÄÔ+K \u00943ÂìÌ\u0086\u0010¿¯J²ÆxÞ*K\u0000Úc3«n'I£¦3\tµ'@Ê";
      short var13 = 653;
      char var10 = 24;
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = d(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     k = var14;
                     l = new String[24];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(75529463736439L << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{112, 108, 34, -63, -73, -48, -121, 75});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     n = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "Ø|±5 A\u0089ò¤Ä\u0000,\u0019Ûõ\u001e\u0010ý\u0004¿Ø\u0012\u009a«[%\u008c#é\u0001K´9";
                  var13 = 33;
                  var10 = 16;
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void J(Render2DEvent event) {
      HUD.A();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.S(event.poseStack());
         this.d();
         this.o();
         PoseStack poseStack = event.poseStack();
         float x = this.N();
         float y = this.C();
         String var10 = this.树友友树树树树友友友.getValue();
         byte var11 = -1;
         switch (var10.hashCode()) {
            case -1955878649:
               if (!var10.equals("Normal")) {
                  break;
               }

               var11 = 0;
            case -1984932033:
               if (!var10.equals("Modern")) {
                  break;
               }

               var11 = 1;
            case 68884316:
               if (var10.equals("Glass")) {
                  var11 = 2;
               }
         }

         switch (var11) {
            case 0:
               树何何何何何树友树友.G(poseStack, x, y, this.友友何友友树树友友树, this.树何友何友友树树树树, this.树友树友树何友友友树.getValue(), this.友何何树何友何树树树.getValue(), this);
            case 1:
               何树友树友树友树树何.D(poseStack, x, y, this.友友何友友树树友友树, this.树何友何友友树树树树, this.树友树友树何友友友树.getValue(), this.友何何树何友何树树树.getValue(), this);
            case 2:
               何树树树友树树树树树.o(
                  poseStack,
                  x,
                  y,
                  this.友友何友友树树友友树,
                  this.树何友何友友树树树树,
                  this.树友树友树何友友友树.getValue(),
                  this.友何何树何友何树树树.getValue(),
                  this.友友树树友友树友友友.getValue().floatValue(),
                  this.何何友何友树友友何何.getValue().floatValue(),
                  this.树友何树友树友何何树.getValue().floatValue(),
                  this
               );
            default:
               this.j();
         }
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void c() {
      o[0] = ":=T\u001e|?5}\u0019\u0015v\"0 \u0012S~?=&\u0016\u0018=94#\u0016Sw9*#\u0016\u001cj~\n0\u0015\u000fv262\b\u0019[\u0005\u001d";
      o[1] = "\u0007~/u\u0006\u001a\b>b~\f\u0007\rci8\u001f\u0014\bed8\u0000\u0018\u0014|/X\u001c\u0018\u0006us@\b\u0019\u0011u";
      o[2] = float.class;
      p[2] = "java/lang/Float";
      o[3] = "%\u0007YY\u0002e*G\u0014R\bx/\u001a\u001f\u0014\u0000e\"\u001c\u001b_Cc+\u0019\u001b\u0014\tc5\u0019\u001b[\u0014$\u000e<3";
      o[4] = "\u0018\t\rq\u0005}m)\u0006~\u00142\u00101\u0015y\u001d{x";
      o[5] = "mz3D\u0005zb:~O\u000fgggu\t\u001ctbax\t\u0003x~x3j\u0005qkB|K\u001fp";
      o[6] = "Gq>MJVH1sF@KMlx\u0000SXHju\u0000LTTs>佻佰佬可叔佅栿佰佬佱";
      o[7] = "uO\u0017\u001eB=z\u000fZ\u0015H \u007fRQS[3zT\\SD?fM\u0017?B=zDX\u0013{3zT\\";
      o[8] = "#mL\u000bTU(b]D(L'xS\u0007\u001f|1o_\u001a\u000eP&b";
      o[9] = "8\u00079\u0014y.&\u000f#[\u001b2!\u0012";
      o[10] = long.class;
      p[10] = "java/lang/Long";
      o[11] = boolean.class;
      p[11] = "java/lang/Boolean";
      o[12] = "7\b90@l8Ht;Jq=\u0015\u007f}Bl0\u0013{6\u0001又原厭佂桂古佖桅桷栆";
      o[13] = "q(\u0018\u00024\u0013q(\u000f^8\u001ckc/D8\u000eY\"\u001eA8\u000ek$\u0002K";
      o[14] = "\u0012\u0019K\t|a\u0019\u0016ZF\u001do\u0012\u001d^\u001c";
      o[15] = "x.} 8w6-|*I厊压伈桘会伔伔压厖伜Gp017{69p.;";
      o[16] = "D.7&T\u001dDw&_佣伭古佋厝框叽厳佺佋^f\u0003\r\u0018-&4^\u0010\u0017";
      o[17] = "\u0016K%\u0014\u001b\u001f\u0016\u00124m伬桫伨伮休厮伬桫厶伮LR\u0015\u0000\u0007B>\u000e\u001b\u0003\u001f";
      o[18] = "cF\u000bM\u0011=c\u001f\u001a4厸桉佝厽桻号桢厓佝伣b\n\u001d.;C\u0010^\u001c b";
      o[19] = ")(P\u001cy5)qAe栊厛众栉叺桼叐伅众栉9\\.%u+A\u000es8z";
      o[20] = "~bt)ku~;eP栘佅叞伇叞厓栘栁栄桃\u001dixa\u007f`l 8~s";
      o[21] = "xl,1\u0018k<z\"{\u007f_B8&4\u0001\u007fsdr{\u0010\u0016";
      o[22] = "\u0006\r1\u0003(@\u0006T z桛叮厦栬桁档桛叮厦叶XA8V\u0015\\?C3OT";
      o[23] = "\u0004EZ,B-\u0004\u001cKU叫厃桾桤台厖栱厃厤厾3l\u0015=XFK>H W";
      o[24] = "Tc\u0005f\u0005~T:\u0014\u001f桶低叴桂伱栆桶叐叴桂l \u0011tW'\u0013.\u0006.O";
      o[25] = "!\u00124<DZ!K%EOQ9V4#EZBIe,W]/I<=";
      o[26] = "Z{z_R\u000fZ\"k&校伿栠伞低佻校桻栠厀\u0013\u001fA\u001b[ybV\u0001\u0004W";
      o[27] = "*E~u\u001b&*\u001co\f桨厈桐厾栎佑厲厈厊桤\u00170\u00112v\u001eo|\u001btv";
      o[28] = "u\b\u0015|KZuQ\u0004\u0005叢佪佋栩伡叆佼栮栏栩|8ORk\n\u0000eE^,";
      o[29] = "\u0001\u00104\b.E\b\u0012f\u0018GqysI?\u001f`jqN%G\f\t\u0017j\u0001?\u0005\u000bEz";
      o[30] = " j%\u007fAd 34\u0006B\t}n68Ro; .v+7\u007f(r\u007fMq10<\u0006";
      o[31] = "{{zYvu{\"k 栅叛叛厀栊佽栅佅栁桚\u0013\u001fb\u007fx?l\u0011u%`";
      o[32] = "/\u0014N+Y5/M_R台厛休可古桋株厛厏栵'lU&w\u0011U8T(.";
   }

   private static String c(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 31178;
      if (l[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])m.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/ScoreboardHUD", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u000f-%Í°FNÃt{öãGyá\u001e, q\u0015\u0015i?aò\u0003\u0082(*")[var5].getBytes("ISO-8859-1");
         l[var5] = d(((Cipher)var4[0]).doFinal(var9));
      }

      return l[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/ScoreboardHUD" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, 0L);
      Object var6 = o[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field h(Class var0, String var1, Class var2) {
      return g(var0, var1, var2);
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return g(var0, var1, var2, var3, var4);
   }

   private void d() {
      HUD.A();
      if (!this.Q(new Object[]{52406761729175L})) {
         Scoreboard scoreboard = mc.level.getScoreboard();
         scoreboard.getDisplayObjective(1);
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 207 && var8 != 255 && var8 != 'y' && var8 != 'k') {
            Method var11 = p(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'A') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 212) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = o(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 207) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 255) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'y') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String d(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("d".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/ScoreboardHUD" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (p[var4] != null) {
         return var4;
      } else {
         Object var5 = o[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 6;
               case 1 -> 20;
               case 2 -> 23;
               case 3 -> 10;
               case 4 -> 18;
               case 5 -> 33;
               case 6 -> 1;
               case 7 -> 61;
               case 8 -> 59;
               case 9 -> 12;
               case 10 -> 15;
               case 11 -> 56;
               case 12 -> 17;
               case 13 -> 4;
               case 14 -> 5;
               case 15 -> 44;
               case 16 -> 43;
               case 17 -> 60;
               case 18 -> 55;
               case 19 -> 21;
               case 20 -> 8;
               case 21 -> 37;
               case 22 -> 19;
               case 23 -> 0;
               case 24 -> 63;
               case 25 -> 28;
               case 26 -> 7;
               case 27 -> 35;
               case 28 -> 39;
               case 29 -> 32;
               case 30 -> 14;
               case 31 -> 22;
               case 32 -> 26;
               case 33 -> 31;
               case 34 -> 50;
               case 35 -> 54;
               case 36 -> 41;
               case 37 -> 47;
               case 38 -> 36;
               case 39 -> 58;
               case 40 -> 38;
               case 41 -> 9;
               case 42 -> 3;
               case 43 -> 51;
               case 44 -> 16;
               case 45 -> 29;
               case 46 -> 45;
               case 47 -> 13;
               case 48 -> 25;
               case 49 -> 46;
               case 50 -> 34;
               case 51 -> 57;
               case 52 -> 11;
               case 53 -> 53;
               case 54 -> 24;
               case 55 -> 52;
               case 56 -> 30;
               case 57 -> 49;
               case 58 -> 48;
               case 59 -> 62;
               case 60 -> 2;
               case 61 -> 40;
               case 62 -> 27;
               default -> 42;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            p[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      if (var5 instanceof String) {
         String var6 = p[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = g(var8, var10, var11);
         o[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void o() {
      HUD.A();
      if (!this.Q(new Object[]{52406761729175L})) {
         int screenWidth = mc.getWindow().getGuiScaledWidth();
         float scoreboardX = this.N();
         this.树何友树何树树友友树 = scoreboardX > screenWidth / 2.0F;
      }
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = p[var4];
         int var7 = var6.indexOf(8);
         Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = g(var8, var10, var15, var13, var14);
         o[var4] = var21;
         return var21;
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field g(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private void j() {
      HUD.A();
      if (!this.Q(new Object[]{52406761729175L})) {
         float currentWidth = this.B();
         int screenWidth = mc.getWindow().getGuiScaledWidth();
         if (this.树何友树何树树友友树 && Math.abs(currentWidth - this.树何树何何何树树树友) > 0.1F) {
            float rightEdge = this.N() + this.树何树何何何树树树友;
            float newX = rightEdge - currentWidth;
            newX = Math.max(0.0F, Math.min(newX, screenWidth - currentWidth));
            this.u(newX);
            super.友友何树何何何友友何 = newX / screenWidth * 100.0F;
         }

         this.树何树何何何树树树友 = currentWidth;
      }
   }

   private boolean H(List<Score> scores1, List<Score> scores2) {
      HUD.A();
      if (scores1.size() != scores2.size()) {
         return false;
      } else {
         int i = 0;
         if (0 < scores1.size()) {
            Score score1 = scores1.get(0);
            Score score2 = scores2.get(0);
            if (!score1.getOwner().equals(score2.getOwner()) || score1.getScore() != score2.getScore()) {
               return false;
            }

            i++;
         }

         return true;
      }
   }

   private static String HE_WEI_LIN() {
      return "何大伟为什么要诈骗何炜霖";
   }

   @EventTarget
   public void G(MinecraftFontTextEvent event) {
      HUD.A();
      if (event.getText() != null && !event.getText().isEmpty()) {
         String text = event.getText();
         if (text.contains(何树何树友树树友友何.f(38856877526439L))) {
            text = text.replace(何树何树友树树友友何.f(38856877526439L), ChatFormatting.DARK_PURPLE + this.树友树友树何友友友树.getValue() + ChatFormatting.RESET);
         }

         if (text.contains(CryptUtil.Base64Crypt.decrypt("5biD5ZCJ5bKb"))) {
            text = text.replace(CryptUtil.Base64Crypt.decrypt("5biD5ZCJ5bKb"), ChatFormatting.DARK_PURPLE + this.树友树友树何友友友树.getValue() + ChatFormatting.RESET);
         }

         if (text.contains("mc.loyisa.cn")) {
            text = text.replace("mc.loyisa.cn", ChatFormatting.DARK_PURPLE + this.树友树友树何友友友树.getValue() + ChatFormatting.RESET);
         }

         if (text.contains(CryptUtil.Base64Crypt.decrypt("6Iqx6Zuo5bqt"))) {
            text = text.replace(CryptUtil.Base64Crypt.decrypt("6Iqx6Zuo5bqt"), ChatFormatting.DARK_PURPLE + this.树友树友树何友友友树.getValue() + ChatFormatting.RESET);
         }

         if (何树何树树友何何友树.友友友何友树树树何友.isEnabled() && text.contains(WrapperUtils.f(111441258359257L))) {
            text = text.replace(WrapperUtils.f(111441258359257L), 何树何树树友何何友树.友友友何友树树树何友.树友何树友树何树友何.getValue());
         }

         if (!text.equals(event.getText())) {
            event.setText(text);
         }
      }
   }
}
