package cn.cool.cherish.module.impl.display;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.ui.何何何友何友何树友友;
import cn.cool.cherish.ui.何何友友树何树何友树;
import cn.cool.cherish.ui.友树何友何友何树树树;
import cn.cool.cherish.ui.树友友友何树友友树树;
import cn.cool.cherish.utils.player.何树何树友树树友友何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.ChatFormatting;
import net.minecraft.world.phys.Vec3;
import why.tree.friend.antileak.Fucker;
import why.tree.friend.antileak.client.Client;
import why.tree.friend.antileak.packet.impls.send.CPacketPlayer;
import why.tree.friend.antileak.utils.CryptUtil;
import why.tree.friend.antileak.utils.PacketWrapper;
import why.tree.friend.antileak.utils.友树何友友友树树树友;

public class HUD extends Module implements 何树友 {
   public static HUD instance;
   public final ModeValue 树友树友树树友友树何 = new ModeValue(
      "Water Mark", "水印样式", new String[]{"None", "Simple", "Cherish", "Cherish Signature", "Modern", "GameSense", "Glass Panel"}, "None"
   );
   public final ModeValue 友友树树树树友树友树 = new ModeValue("Modern Water Mark", "现代水印样式", new String[]{"A", "B", "C", "D", "E"}, "A")
      .A(() -> this.树友树友树树友友树何.K("Modern"));
   public final ModeValue 树友何何友何树何树友 = new ModeValue("Count Mode", "进度条样式", new String[]{"Modern", "Simple", "None"}, "Simple");
   public final ModeValue hotBarMode;
   public final BooleanValue hotBarAnimation;
   private final ModeValue 树何友树何友何树树友;
   private final BooleanValue 何友友友友树树何何何;
   private final BooleanValue 树何树何树何友何何何;
   private final BooleanValue 树何友友友友树友树何;
   private final BooleanValue 友友树何树树友树树何;
   public static final BooleanValue 何友树树友树树何友树;
   public final BooleanValue 友友何友何树何何树树;
   public final BooleanValue mcEffect;
   public final 何何何友友何树何何何 树何树何何友何友何树;
   public final BooleanValue ircName;
   public final BooleanValue 何树何何树友何树何何;
   public final BooleanValue 何何树树何何树树树何;
   public final ModeValue 树友友友友树何树何友;
   public final ModeValue 友何友树树何树友友友;
   private Vec3 何友何何友何树何树何;
   private long 树友友树友树树何友何;
   private double 友何友友友树何树树友;
   private boolean 树树树树友友何友树友;
   private static String[] 何何友友树何何友友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[63];
   private static final String[] l = new String[63];
   private static String HE_JIAN_GUO;

   public HUD() {
      super("HUD", "显示器", 树何友友何树友友何何.友友友树何友何何树何);
      A();
      this.hotBarMode = new ModeValue("HotBar Mode", "快捷栏样式", new String[]{"Cherish", "Minecraft", "Simple"}, "Cherish");
      this.hotBarAnimation = new BooleanValue("HotBar Animation", "快捷栏动画", true);
      this.树何友树何友何树树友 = new ModeValue(
            "Cherish Signature Font",
            "珍惜艺术字字体样式",
            new String[]{"getDancingScriptFont(65)", "getBorelFont(60)", "getPlymouthRockFont(60)"},
            "getDancingScriptFont(65)"
         )
         .A(() -> this.树友树友树树友友树何.K("Cherish Signature"));
      this.何友友友友树树何何何 = new BooleanValue("Show FPS", "显示帧数", true).A(() -> this.树友树友树树友友树何.K("Simple"));
      this.树何树何树何友何何何 = new BooleanValue("Show Time", "显示时间", true).A(() -> this.树友树友树树友友树何.K("Simple"));
      this.树何友友友友树友树何 = new BooleanValue("Show Ping", "显示延迟", true).A(() -> this.树友树友树树友友树何.K("Simple"));
      this.友友树何树树友树树何 = new BooleanValue("Show IP", "显示IP", true).A(() -> this.树友树友树树友友树何.K("Simple"));
      this.友友何友何树何何树树 = new BooleanValue("Info", "游戏信息", false);
      this.mcEffect = new BooleanValue("Minecraft Effect", "显示我的世界自带药水效果", true);
      this.树何树何何友何友何树 = new 何何何友友何树何何何("Client Name", "客户端名称", "Cherish");
      this.ircName = new BooleanValue("IRC Name Render", "IRC名称渲染", true);
      this.何树何何树友何树何何 = new BooleanValue("Display IRC Message (ChatBar)", "显示IRC消息(聊天栏)", true).A(() -> {
         A();
         return 友友何何友何友树何树.何树树何何友何友何何 != null && !友友何何友何友树何树.何树树何何友何友何何.isEnabled();
      });
      this.何何树树何何树树树何 = new BooleanValue("Message With", "显示玩家IRC消息", true).A(this.何树何何树友何树何何::getValue);
      this.树友友友友树何树何友 = new ModeValue("Font Mode", "字体模式", new String[]{"Minecraft", "Normal"}, "Minecraft");
      this.友何友树树何树友友友 = new ModeValue("Language", "语言", new String[]{"Chinese", "English"}, "English");
      this.何友何何友何树何树何 = null;
      this.树友友树友树树何友何 = 0L;
      this.友何友友友树何树树友 = 0.0;
      this.树树树树友友何友树友 = true;
      instance = this;
      this.J(true);
      Module.V(new Module[1]);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(2744894224641574961L, 152789345833766007L, MethodHandles.lookup().lookupClass()).a(22374471898058L);
      // $VF: monitorexit
      a = var10000;
      a();
      U(null);
      Cipher var5;
      Cipher var15 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(68094494316888L << var6 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[129];
      int var10 = 0;
      String var9 = "`ßaAGG\u0010\u008a\u008eò\u001ey¶\n`\u0015\u0010Ë\u0000\u0014¶\u0002ÂâqD\u00ad4á.8Ë\u0006 Ôÿv!\u0013\u0096V\u0007A!±ìîò-xÅö\u008bé\u001f¿µ«\u00876¥\u009b.êUÝ\u0010þ \u0010yPNiS\u00141\u0019è2\u00851ñ\u0010µçy\u008eÁÄöQß\u0007Ù¤\u0098\u00181/\u0018¨g6\u00197\u009d£»\u0013\u0097BBCâ\u0098\"Z>\u001c)r°ºµ\u0010bÁcÄÞÂ.3ª0\u0005¨¿K\u0015\u008e(Oæ\u0097²ß\u0016\u000f\u0019\u009d>£º\u0087¼Z\u000f\u0010\u0010è·#m<íSß±\u001cCæ5·þý:ÑæôÖ\u0010 ê\"§9û89\tlõG}p|\tð,Hû\u00ad8\u0097Vh)\"R\u001eÀ¿Îz ®D\u008e\u0091gÁ`&\u0003¸|Î\u0010ì[æº\t»\u0012xUé²âÆ¢\"³v\u001cð\u0018H\u001c0D\u0098\u0012p²4½$xV#K\u0006rO\n\u008e\u009a¥í+\u0010\u0014cx`ã\u001b\u000b:\t)8£ú]\u0014o Xõp\bBxQ\u0098Ðß\u009c¯³òxG²\u0081áK5 #\u009f42àÑ½àÕ\u00ad\u0010F=çC£8xÈ\u0092pèÐ\u008aµ\u008b&\u0010EîwÆ_(\u0002Ç]#Ù\u008fBµ'V(Ð\u0018\u0014\u001c\rÛ\u0082µ.\u0091]¦o§\u0080ÚÈÑö\u001b \u0092³\u0019C?\u0080\u000f\u000bÈµX?gí\u008c\u000f\u0001\u0095«\u0010+\u001e¾·^Î\u009bp\bÛè\u000eÙþX((\u00861½ó\u0003÷Hê\u0014Y¨\u001d¾ímÖÆ++\u000eá)(*9/\u008fpåæ¢U*\u0011Ò$ªý%»\u0010ÊFñï\u008c\u0083\u0019Y_\u0011x\u0088,vz\u0095\u0010gCÌá~³BsÑí¨ê\u00109j) Ð°µ¡¦¿3\u0007tÿ\u0086o<î\u0085_°\u008c|·`@:úëðä\u0087\u0082³'\u0098\u0018½Ð+U\u0007ñ³F\u001bèí\u0016A-r\u0083\u001ddgäbpyà(%ö\u001d\\zL\u0003M\u008a®\u0084\u0002d-iú\u008c\u008crhY<\u009dwëÁ4;Ý\u009a\" zZ?ßíVÞÏ8étü»:u^·\u0018ù¾\u009b)ñ\u0094^h.ÚÕC/|è!Zç;SB<ç¯\u009d0\u008e¨ö\u008d g-\u000f5\u0099ÿ\u0018Jú^1d>Âûú ³Ë\u0081\u001c'Ý0²\u0006*c§\u001e¦¥-d\u009e\u0015\u0007\u008d\u0092\u0085a×ç$õ\u0005÷\u0097\u0017 s[ÿÉ\u008ao\r\u0015e&¿\u000få\u0085\u0085f°\u0094©¬t¼ô1Ø`d9#\u0015Ú1\u0010\n°£hêy¤4q¡c6¥\u0005e\u0081\u0010<¹\u009d\u009b: ,\u009bO\u009bZ\u009a\u0007äÊ¥\u0010v\u0098»[æO4ª¡\u0012{~¨o\"\u0080\u0010dT\u009d:b#0£éKsÑV\u0094\u0092P \rFWÜrÚ\u009eÎ\u009aoç\u0082± Z«b\u0018\u001dU>Ý:ûNûë¶ª\u0098>4\u0010½$O\u0086Úh~v\u0090\u0010\u001f5óEz¢\u0018\u000f²\u0083¾ÖÞQ&É\u0002~\u008fx@!ãb;C¦\u0088ôIæ0\u0004{§\u0007\u0018¹-ã¿ðA\u008f\u0014ßvä\u0083\nÅ]\fýö¿\u009dJ»\u0094\u008f\u0007\u0096| Ø7lÕeô~)Ý\u0098ös÷z©\u0018EºYr~ßÝ\u009e\u001b\u0003ùãÈ²J¨\u008b\u000f{\n\u0091h*I\u0010Í\rLîê\u000bð\u0094é\u0081\u0001&µ}-\u007f\u0010Î\u0090Á²\u008c_ÁÖ.;b\u007fÖòE`\u0010ý5\u0088\u0015\u001b\u0007c\u00add¡7dåÚkô\u0010ûe\u0014)ÏõXñò#üó\f\u009e¢O ä\u0092Éc\u0082]Êè\u00112÷XR®\r~°\u0085ïÍU+:iPIÊrRcØ\u0093\u0010á\u000f6:þñQÊòêÙ*nvh'\u0010x\u008e½<\u00863zþ©]2·f·úg\u0018ð\u0007A¼%(ñjM\u0099\u0000º\u00adH\u0099\u0003® \u009e\u0091¬\u0082zô\u0010y\u000b\u0015\u008b5\u001fy\f\u0095Ð\u0004isx°q\u0010\u000fE\u0097ËúX\u000f\u0013ä\u0014Ã\u0092ñ0\u000bB0\u0010ÈæHgÅ\u0099\u009eäÌÏ\\P=Æ®[Ì¶Î\u0081\u0084\u009a\u008c·Í4\u0003Xb&\u0015tQX°8½ Z\u0018ÊåP=\u0083\u007f\u0095 ógV¼#ìm\u009c\u0092ñ\u0099lºª6b¿\u008féÖ9}\u0094êV\u0081QË¶Ôó®\u0010©©@\u0087\u009fp\u001eºW^DYF^\u0099\u000b\u0010\u008aÜÎ\u008e4õ¸ \u0087À@a'\u001a\u0017â\u0010_Ûa¹0JÒ\u0018©\u000b1/dkYÐ\u0010¢\u0010\u0011AjæçþmK\u0082ÅD:]2 \u0087\u0001~Ö¾¨\u0000´§\u0080\rQ+A\u0018}\u0002(¸?Ys\u008cöÃ6Uµ\u001e/\u008dU(\u0091s\u0013-\u0011Ë\u0013½\u000f\b`É\u0014È«\u00997©7twÎ\u008de»\u0085Â8\u0090Lìã\r\u0094|Ä9X)) aJ×¥ò©:Ynë·ÃâS¦Ã¥\u001aývjã\r\u0095\u0099è\u0098w%<öÿ\u0010¤¡·EJÖÏ\u0095ïø\u0013±¾¢óx T\u0097¥`ÿ¦Z\u0011îPÔ»¢Ä2§}ÜÔ+èqæÔ\u001d\u0095g_¾×^È\u0010\u009a\u0080Þ´\u0004\u0081ÓH-\u001a\u0014\u0012ëo¬å\u0010ý]U*\u0092±¸\u009a\u0019\u0019\u0094 6ù1Q\u0018\\½µðá«Ïî4×nó\tn§[\u008eçË\u0007¯Ú\u0086±\u00183Ì²\u0080¯E\u00928³ó]4\"Y©Þ\u007f\u0097\u008cÄ\"ô}Ç\u0018ÒlÉÂo\u0080àº\u0091\u0012(e\u0005\u008c«/æ.n?\u001d\u0010åÊ\u0010\u0096s\\1<2h\u0092\u0019<ÐM)·f\\\u00106°·¤öLy\b¾|\u0082X\u001asÂÀ\u0010çj\u0083dû8]È®\u0007\u009fRD*\u000f+\u0010\u0018\u008e0\u008daâÃ\u001b\u0011\u008ef<I5XÌ ÿ\u0097ÇlBùÍq÷è3K6\u0001% ö9¼\u0013PbNk~\u001e:(Àà:5 \u0015âÎ\u001eO¾\u009dW4\u008dW\u0015¸\u009c\u009f\u001dÓ7Ù\u0003ìáGï\u009ee\u009f\u00ad\u009eY\u0093D\u0018íU\u009cÛ\u0083;\u0017ÃÜ8gåéÆ8}\u0001n|jAñù[(Wäé\u0011· x\u009a\u0080ÜCK\u0014*ì\u0085Ú2.Ú+;Î\nËçÂÿÞ7ìÜû\u00adý 8\u0085¿¶\u0018³Ð´|\bGÉe\u0098sâ>âg´1\u0092ÈÂ6½\\{M\u0010\u009f<C\u00929¼Û\u009eôóv\u0001r\u007f\u009e \u0018\u0082Êð0`\"Õx\u008c\bËæ¶n³E\u0004%\u0018ç*\u00804ÿ(Ç.\u0085\u0093\u008c\u00828 \u009e@XRÝû\u00961ñ®\u0083øÚy)U°³%\u0014\u008aÔääü!ÁÚº¶Áà\u0010u¥5¦\u0087s\u009eáü\u0088\u0099çÚ\u0093ê[\u0010\u0010\u0092\\Ø\u0017\u0011A\u009a{\f\u009f\u000f¡\u001fà{@D\u0015Ò!ã)ÓEºx»-\u0003\u001fø@\u0002]Èx\u0095±©\u0007d\u0096[<÷0õªÏÒÇ\u007fÚï5\u000f¶<¥NêA)êÎ\u008fïÎÈc©\u008b \u009e\u001a \b:æ\u009f8 \u009b½\u0014Üõ\u00140!º\u0011%\u009d©õGðy$¶\u0099:Õ\r±ÂÛ\u00884\u009e©q§hþ«xÍ\u0097g<qÒ×v$A§Û ÙÂB¿£u\u00103E\u0003áÐu\u0015\u000faWÉÌªo;ù\u0010\u009d\u001abOBw\u0086\u0003ß\u0016¾UNf\u0011T\u0018ViÏÙi \u000b5¼¬¡ã£\u0084\u0001n\u008ct\u007f\u000e\u0090,D¢8k\u000bþ¼üwóW^\u0011\u0093/.°n\u0081ÆW5\u001a3ã8?Ò\u0017\nt7 q\u0096thß¨>b\u0001ÆÛ\u0018ç\u0006ä\u009b\u0014\u008a£ÃòAn\u000bÖ]\u0018Å\u001a\u007f7\u001eg\u0011\u0010i:ÄD4Ìe\u0003ÄÑ\u0017é\n\u000fá\u0091\u00105Í¿Xé\u0002\tR\u008d\u0007ÛR]}Kâ8Ù\u001d\u0011Z³<Ùã¹Òckv@ \fl¼v±~<û\u0098Ë\u0007]EÇô\u008d\u008bDéD\u008a\u00adpãº»\u001aI\u0083\u0018\u0084$\u008b\u001bfB\u0004Ò\u0093\tª\u0010(¼\u0082Â:ÎvÚÆRE\u0016\u0007¾b\u0091\u0018$<\bDüï\u0002Ô\u009dÁA'ÏªdS4*S±\u009e³,F\u0010Ã»ÍO¦\u0096ß\u008b\u009c\u0087\u009cs 3$H #Ù!\u009d²\u001e@¡¼ÁÂc\u000f¤Ûë$÷\u0087â\u00adwÔöà\\6|\u001b\u0098%H(~\u0088Of\u008fÆ\u0002¨\u0002=9\u007f¼ûF.n\u0082\"SÒ\rW|\u0011pm\u0016\u001d7\u0092ä\u008a§\u0088s\u0018¡t\u0006\u0010\u009d\u0080\u0091FPì#¾\u0003Åz®j6\u001bº \u0096ý\u0090#ðÜ_4´\u0081O½\u009d\u0098[òñÊx¤#²'ÌT¡£f7ó\u008eâ\u0010\u0010ûU¤\u0090<÷òaÔÃç\u0083vj6 ª!ÝáEÓ\u0001Rî\u009e©\u009bÁ+ \u0014h\u0014¤\u0092\u0016m]\u000b\u001d@Ã\u0015?çXà\u0010a6!ûµ\u0014^â(àV¹\u009fsôÛ\u0010êÞ\tãMex9¾ä¾\u001a\u0016=yn\u0010Üõü\u0094Üs.R\u00071\u0080ÅQSºù ðdFÜã[Ð¢@\n\u0083\u00ad¤\u0096Nl>ÉmU&§±(J\u0087\u007f\u001d\u008d×Éµ Ø\u0010íH;´D\u0082\u0017Ñ\u0006Dº¿fJhQôãº,\u0011\n\u0080\u0002¸\u008dÙùZ±\u0010ú¥½HwÝÁoVHË\u001bg\u0090{~ ð)d®ôt+³°\u0006\u001bRâ\t.«\u0017ðÅ\u0018\u0019R°,ÿÂ³\u009aÐUün\u0010Ùø#ÎÝø\u000fÓ\u009cá»\u00911)©\u001d\u0018ÁòÐ\u0001ËNx<¯f\u001dgFèHØYúYs\u0012\u0011ÐÇ(Ic<`h¡'\u0095\u0089Úméï\u0085¨Q\u000f<\u0095+#¤²Ü1\u000b\u00adÇ\u000fnÓ×T\u001dÎÃìÏ\u0088(\u0018\u0017Í®v\f\u007fX¡]ÛVµ\u009eÔ_r·î\u0012o^/\nI \n\u008c\u0099q3.ÌGL\u009f\u000f!Î×ð~O\u009dÞ*EI\u0085¶¶tvÇ\u0088\u0094(Ý\u0018\u001d¥O\u008cþ¤âv¡>\u0002Öx\u001eµ\u001fI/yö¯¨¼\u001f rx\u0010µ³ßùÖÿ\u0006§\u0003\u0004þ\u00ad\\·Çf\u0001Ä\u0090\u0007©1¥\b[¥>\u0082¹\u0010ÈKõç³³w\n#ëÃ\u0018o¤\tQ(^Ä\u0082\u008dbàôG\u0097µú\u001a\u000e¿J;ã\u007f\u0087÷RØ\u0018×4Ei».°vè\u0007.¸\u007fó\u0005) \u0010\u0017\u0092FDç\u009e\u0096ÖUºk?\u0004¾s\u008d\u0010åK'-ÛðÕã\u008dú õ\u0087\u001fä\u0094 CÙ{ÕR\u0014\u0091ucu>\u0002!Èä]rÒÈÚ$\u001b\u0005%·?\röÄ´â~\u0010,\u0007\tZ*\";U\u0007Ì\u001dî¾ÌsË\u0010 xÒD½M\u0086[V\u008d\u0084\u0005\u007fqÓµ §Ð\u0002\u001bké\u009bn\u008aàà&÷Ø7\u0000\u0093\u001aï Éoö\u000b\u0084ïwÌ?»\u0012l0cÕüA'M\u008a\u0002¾\u0019ó\u0080+GÌ\u0007QÍ/4\u0083jÇ\u0093Þâ=ä$C\u008bÛ\u0016R]Ï±\\CÝ|ð¬EÎ\u0087\u0004\u0018\u0010S Üdxk\t«öÐ\u0082rÁua@\u0010ìµ\f\u0005ê\u0093eÙ|½÷H\u0094\u001cPÛ(MÏò'\u0099\u001a|B\u0096Ýhely¦Ã\u0011\u001eÛ\u009bÊ|ñ\u001cðBáÁZL\u0096~À\u0096%\u0004Z\u009bßð0\u009b-'ÝÛ\u0082dGÁ\u0099 \u008cåeXCIV¯þ\u0019ú\u000b?â3ºzj`{Ç~\u0012\u00918BÛ\u0017M,íÚ\u0003\\ø%Ð\u0010:re\u007f§\u0094\u001aE\u0087\u001aÉ\tÍBiC\u0010\u009cÙ\u009aBu\u009d¹ker¡|ûê\u0018I [H?n+7ò\u008e\u009d\u0001ã\u009f\u0018Äþ\u0082ÿJø\u0082Õ\u0001&©I1\u000b*\u0088\u0092oþ0\u009e\u008aRjñ\u0099,\táÝD¶\tfc0~z¬MëõÜ\\å\u0081\u001aã\u0098{\u001fDèæâ®[Ë¡cÙ\u0011Ú$@7\f\u0016\u0018\u0096W\u001föL]'ô\u0096#\u009fìâ8\u001c²(Ï8ZyÇA>\u0010)ödWvnt\tf\u0090\u0084IÑeË¼\u0010\u0083¦¢®'9z\u00ad\u0018â]ë\u0084ë=Ü";
      short var11 = 3358;
      char var8 = 16;
      int var14 = -1;

      label37:
      while (true) {
         String var16 = var9.substring(++var14, var14 + var8);
         byte var10001 = -1;

         while (true) {
            String var24 = c(var5.doFinal(var16.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var12[var10++] = var24;
                  if ((var14 += var8) >= var11) {
                     c = var12;
                     h = new String[129];
                     Cipher var0;
                     Cipher var18 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(68094494316888L << var1 * 8 >>> 56);
                     }

                     var18.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{44, 93, 39, -30, 91, 39, -81, 84});
                     long var28 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var28;
                     何友树树友树树何友树 = new BooleanValue("Shadow", "阴影", true);
                     return;
                  }

                  var8 = var9.charAt(var14);
                  break;
               default:
                  var12[var10++] = var24;
                  if ((var14 += var8) < var11) {
                     var8 = var9.charAt(var14);
                     continue label37;
                  }

                  var9 = "kÖÛÉ´Ë½×d1¸¶È\u0084Ö¡\u0010a\u009b¯<Ñ¶AlÍO\u0088\u008a\u001e&à¤";
                  var11 = 33;
                  var8 = 16;
                  var14 = -1;
            }

            var16 = var9.substring(++var14, var14 + var8);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 44;
               case 1 -> 52;
               case 2 -> 20;
               case 3 -> 22;
               case 4 -> 59;
               case 5 -> 42;
               case 6 -> 35;
               case 7 -> 26;
               case 8 -> 41;
               case 9 -> 3;
               case 10 -> 27;
               case 11 -> 2;
               case 12 -> 63;
               case 13 -> 15;
               case 14 -> 18;
               case 15 -> 40;
               case 16 -> 11;
               case 17 -> 51;
               case 18 -> 12;
               case 19 -> 58;
               case 20 -> 57;
               case 21 -> 31;
               case 22 -> 54;
               case 23 -> 53;
               case 24 -> 10;
               case 25 -> 21;
               case 26 -> 50;
               case 27 -> 13;
               case 28 -> 56;
               case 29 -> 36;
               case 30 -> 47;
               case 31 -> 37;
               case 32 -> 23;
               case 33 -> 0;
               case 34 -> 25;
               case 35 -> 5;
               case 36 -> 60;
               case 37 -> 48;
               case 38 -> 29;
               case 39 -> 30;
               case 40 -> 9;
               case 41 -> 28;
               case 42 -> 16;
               case 43 -> 61;
               case 44 -> 46;
               case 45 -> 1;
               case 46 -> 14;
               case 47 -> 33;
               case 48 -> 62;
               case 49 -> 7;
               case 50 -> 43;
               case 51 -> 17;
               case 52 -> 39;
               case 53 -> 55;
               case 54 -> 45;
               case 55 -> 49;
               case 56 -> 32;
               case 57 -> 8;
               case 58 -> 4;
               case 59 -> 19;
               case 60 -> 34;
               case 61 -> 24;
               case 62 -> 38;
               default -> 6;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Throwable b(Throwable var0) {
      return var0;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/HUD" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26723;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/display/HUD", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[D\u0003\u009cü[I\u0015@, Ì\u0013àã\u0082\u0017ùN, \u00866÷ù\u0086WÙü£¤`³dê¼\u0001, ®´E\u0019ý\u0017®V, \u00ad¤Ü÷\u0019Ïù\u00ad, ñ!÷j-³\u00028W\u0010}u§¹m\u0087, hü2Í¯Kï\u008b, \u009f\u0081\u00198h¸{\u0003\u0095J=@à=\u0095¨'Í_8\u001dí1\u001a, t'\u0014»¹=U")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   public void b(PoseStack poseStack, String message, float progress, int rawValue, int y) {
      A();
      String var9 = this.树友何何友何树何树友.getValue();
      byte var10 = -1;
      switch (var9.hashCode()) {
         case -1818419758:
            if (!var9.equals("Simple")) {
               break;
            }

            var10 = 0;
         case -1984932033:
            if (var9.equals("Modern")) {
               var10 = 1;
            }
      }

      switch (var10) {
         case 0:
            何何何友何友何树友友.B(poseStack, "Stuck now...", progress, rawValue, y);
         case 1:
            何何何友何友何树友友.U(poseStack, progress, y);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/display/HUD" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'x' && var8 != 'b' && var8 != 'X' && var8 != 165) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'A') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'o') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'x') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'b') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'X') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private String n() {
      String clientText = this.树何树何何友何友何树.getValue();
      A();
      Date currentDate = new Date();
      SimpleDateFormat sdf = new SimpleDateFormat("h:mm a", Locale.US);
      String formattedTime = sdf.format(currentDate);
      String text = clientText.charAt(0) + "§7" + clientText.substring(1);
      String ip = 何树何树友树树友友何.f(38856877526439L);
      if (ip.contains(CryptUtil.Base64Crypt.decrypt("Ympk"))) {
         ip = CryptUtil.Base64Crypt.decrypt("5biD5ZCJ5bKb");
      }

      if (ip.contains("loyisa")) {
         ip = "福瑞控";
      }

      int ping = 0;
      if (mc.getConnection() != null && mc.getConnection().getPlayerInfo(mc.player.getUUID()) != null) {
         ping = Objects.requireNonNull(mc.getConnection().getPlayerInfo(mc.player.getUUID())).getLatency();
      }

      if (this.树何树何树何友何何何.getValue()) {
         text = text + " (§f" + formattedTime + "§7)";
      }

      if (this.何友友友友树树何何何.getValue()) {
         text = text + " (§f" + WrapperUtils.s(112298472615430L) + " FPS§7)";
      }

      if (this.树何友友友友树友树何.getValue()) {
         text = text + " (§f" + ping + "ms§7)";
      }

      if (this.友友树何树树友树树何.getValue()) {
         text = text + " (§f" + ip + "§7)";
      }

      return text;
   }

   @Override
   public void h() {
      A();
      if (Client.channel != null && Client.channel.isActive()) {
         try {
            PacketWrapper.release(new CPacketPlayer(Client.channel, true));
         } catch (Throwable var4) {
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "\u0015bdY\u0006}\u001a\")R\f`\u001f\u007f\"\u0014\u0004}\u0012y&_G{\u001b|&\u0014\r{\u0005|&[\u0010<>Y\u000e";
      k[1] = "\u0015\u0014}5K;\u001aT0>A&\u001f\t;xR5\u001a\u000f6xM9\u0006\u0016}\u0014K;\u001a\u001f28r5\u001a\u000f6";
      k[2] = "F&c\u007f\u00186If.t\u0012+L;%2\u00018I=(2\u001e4U$c佉伢伌叮厃优栍伢伌佰";
      k[3] = ")\u0010llb?7\u0018v#\u0000% \u0010vh";
      k[4] = "87\f \u0003!M\u0017\u0007/\u0012n0\u000f\u0014(\u001b'X";
      k[5] = "Tcx\u001cSD_liS)@Lmy\u001c\u001fD[";
      k[6] = "\u0000i\u001a*s]\u0000i\rv\u007fR\u001a\"\u0019klX\n\"\u001elgG@Z\u000bg-";
      k[7] = double.class;
      l[7] = "java/lang/Double";
      k[8] = boolean.class;
      l[8] = "java/lang/Boolean";
      k[9] = long.class;
      l[9] = "java/lang/Long";
      k[10] = "-\u000fN\fLE\"O\u0003\u0007FX'\u0012\bAUK\"\u0014\u0005AJG>\rN\"LN+7\u0001\u0003VO";
      k[11] = "\u0005$(P\u0003-\nde[\t0\u000f9n\u001d\u0001-\u0002?jVB\u000f\t.s_\t";
      k[12] = "L73FU:x\u0014<\u0006\u00181r\t9[\u0013wz\u00144]\u0017<96?L\u000e5r@";
      k[13] = "2?\u000b3s\u0000\u0006\u001c\u0004s>\u000b\f\u0001\u0001.5M\u0004\u001c\f(1\u0006G>\u00079(\u000f\fH";
      k[14] = void.class;
      l[14] = "java/lang/Void";
      k[15] = "<K\u0019)sp3\u000bT\"ym6V_dqp;P[/2栎伊叮叼伟栍叔厔佰佢";
      k[16] = " {2%\u00041U[9*\u0015~(C*-\u001c7@";
      k[17] = ",\u0019+{\u0005\u000e#Yfp\u000f\u0013&\u0004m6\u0007\u000e+\u0002i}D\b\"\u0007i6\u000e\b<\u0007iy\u0013O桞桦佐栉伿伴桞伢佐栉";
      k[18] = "\\B\u000e\n\u001e^S\u0002C\u0001\u0014CV_HG\u0007PSYEG\u0018\\O@\u000e桸厺佤佪栽栱似厺叺佪";
      k[19] = "\u0017&\bV$q\u0017&\u001f\n(~\rm\u001f\u0014 }\u00177R\b%y\u0000&\u000eV\u0005w\u001a\"\u0010(%y\u0000&\u000e";
      k[20] = int.class;
      l[20] = "java/lang/Integer";
      k[21] = "tfAw)YtfV+%Vn-v1%D\\lG4%Dnj[>";
      k[22] = "\\h\u0012j\u0007]S(_a\r@VuT'\rDZhH'\rDZhHzFwIcR}LaVbY";
      k[23] = "\t|gG\u0006,\u0014i?eG!\fo";
      k[24] = "C=y-\u000e+L}4&\u00046I ?`\f+D&;+O-M#;`\u0011(A*2<O桕叫伆伂厅伴桕併桂厜";
      k[25] = "\u000f(n+GJ\u0004'\u007fd&D\u000f,{>";
      k[26] = "}+\u0002uZtl;\u001a\u001a桾叒栏厕桡栃厤叒栏伋x%\u000ec)9\u001fw\u001bkp";
      k[27] = "\r:V\u001a\u0007S\u001c*Nu栣佫厥厄可厶栣叵桿会,L\n\t\u001d)R\u000e\u0005\n\r";
      k[28] = "Xi\u001f1cOIy\u0007^厝叩株栍桼桇厝栳台栍ea7X\f{\u00023\"PU";
      k[29] = "m-\u0017\u001a\"GdjB\u0002L4Z\u001e|z!\u0001:7CF(Fo/";
      k[30] = "HK)\u0019O@Y[1v/%IW\"\u000eIUG\n3IrL\u001fO=\u000e\u001cU\u001cI9v";
      k[31] = "=bzBzKn?eC\u001a叩桏反栛栾栃叩桏反栛'%C$1m@wV,h";
      k[32] = "\u001bv!A\u001di\nf9.根佑桩佖伆叭佽叏伭栒[\u0017PiO{eI_7\n";
      k[33] = "t-#\u000f3\u0011!-fJI<\u0015F%Yu\\46pY0\u0019";
      k[34] = "\u007fw{\u0013Q\u0003ngc|伱厥受叉参桥桵伻佉佗\u0001E\\Yod\u007f\u0007SZ\u007f";
      k[35] = "Xp\u00118@p\u000b-\u000e9 叒佮佁厪伀根栈株栅桰]Ku\r~\u000eg\u001fxBm";
      k[36] = ";O\u0013\u0000DG*_\u000bo桠叡厓栫厪桶桠使厓佯iQ\u0004L0\u000eXWCPk";
      k[37] = "G-y.P>@::34\u0004n\u0010ZNZ:V+b,]-\u00156";
      k[38] = "mQH\u001fdj|APp伄双栟栵叱桩桀佒叅栵2Ii0}BL\u000bf3m";
      k[39] = "\u0019\u0011K\u0004 9\b\u0001Sk叞原桫伱栨桲叞桅桫伱1R-c\t\u0002O\u0010\"`\u0019";
      k[40] = "V\u000b{z\\`G\u001bc\u0015桸佘栤伫栘佈厢佘你伫\u0001,Q:F\u0018\u007fn^9V";
      k[41] = "Z9~8SPQj,j5>jbu8IW[k85\u000fl";
      k[42] = "\u001a\u0010bZ@U\u000b\u0000z540\u001b\fiMF@\u0015Qx\n}";
      k[43] = "aV~\"N\u001aj\u0005,p(xQ\ru\"T\u001d`\u00048/\u0012&8\u0000<qPH!\u0003:u(";
      k[44] = "+O[\u00159lt\nI\u000bZ栕厇史栩厭厙叏厇栨佭n5r/JS\u000ej7=T";
      k[45] = "\t*WvQm\u0007(Pc<叄厣厄栯低叿佚伽桞佫\u0013Uj\u0001\"[y[h\u00067";
      k[46] = "\u0002E}H<hUT:\u0011Zx9\u00155\u0017k)9,i\u0011=,\u001cS:D\".";
      k[47] = "@k1n\u0006\u001d\u00136.of桥栲佚伔又桿伡佶叄桐\u000b\r\u0018\u0015e.1Y\u0015Zv";
      k[48] = "vD3`2:gT+\u000f佒框佀佤桐双佒框佀佤I6?`fW7t0cv";
      k[49] = "\fv\u000eCL|\u000e,\u0016\u0010v,gvWOIsgFPJ\u0018zO:U\rO{";
      k[50] = "I\fk8}\u000eX\u001csW桙伶叡桨佌厔伝桲栻厲\u0011h)\u0019\u001d\u001ev:<\u0011D";
      k[51] = "p\u0012!\u00023oa\u00029m反叉但厬伆桴体佗栂桶[T>5`\u0001%\u001616p";
      k[52] = "UO(\u0011{DW\u00150BA\u0014>Oq\u001dqC>\u007fv\u0018/B\u0016\u0003s_xC";
      k[53] = "\u000fJ3C\u001e\u000b\\\u0017,B~桳桽句厈句厽桳厧佻伖&\u0015\u0006\u001cC+GF[\u0003B";
      k[54] = "r}gJw5cm\u007f%桓桉栀栙叞另众厓栀參\u001d\u001br?`0wZz+i";
      k[55] = "U\nq}U#Z]`b<Y~,SZ<|U\f|p\fs\u0002\u001dc";
      k[56] = "q\u0016?\u000e\u001a_`\u0006'a栾叹叙厨历桸佺栣佇厨E^NH%\u0004\"\f[@|";
      k[57] = ",Fw+Lo%\u0001\"3\"\f\u0001}\u0011\u0006\">;\u0006-%\u001e7|S5";
      k[58] = "Hf\u001f\u00148-Yv\u0007{佘压佾但厦伦栜伕栺但eG5+\u0013![Eo3@";
      k[59] = "I\u001eI?M[FIX $4f0|\u0016$\u0004I\u0018D2\u0014\u000b\u001e\t[";
      k[60] = "Tv\r^\u0003aEf\u00151叽余叼又厴栨佣栝栦又w\f\u0007j\u0007t\u000b\t@=\u0006";
      k[61] = "sK\u0004\u0012]sb[\u001c}桹叕佅佫厽传桹佋栁叵~B\td'Y\u0019\u0010\u001cl~";
      k[62] = "K\u0000zzr\u007fZ\u0010b\u0015%\u001a\u001b\rgy/&L\u001cglO!P\u001alusvA\u001ay\u0015";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void U(String[] var0) {
      何何友友树何何友友何 = var0;
   }

   @EventTarget
   public void r(LivingUpdateEvent event) {
      A();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.ircName.getValue() != this.树树树树友友何友树友) {
            if (Client.channel != null && Client.channel.isActive()) {
               try {
                  PacketWrapper.release(new CPacketPlayer(Client.channel, !this.ircName.getValue()));
               } catch (Throwable var18) {
               }
            }

            this.树树树树友友何友树友 = this.ircName.getValue();
         }

         long currentTime = System.currentTimeMillis();
         Vec3 currentPosition = mc.player.position();
         if (this.何友何何友何树何树何 == null) {
            this.何友何何友何树何树何 = currentPosition;
            this.树友友树友树树何友何 = currentTime;
         } else {
            double timeDiff = (currentTime - this.树友友树友树树何友何) / 1000.0;
            if (!(timeDiff <= 0.0)) {
               double dx = currentPosition.x - this.何友何何友何树何树何.x;
               double dz = currentPosition.z - this.何友何何友何树何树何.z;
               double distance = Math.sqrt(dx * dx + dz * dz);
               if (distance > 100.0) {
                  this.何友何何友何树何树何 = currentPosition;
                  this.树友友树友树树何友何 = currentTime;
               } else {
                  this.友何友友友树何树树友 = distance / timeDiff;
                  this.何友何何友何树何树何 = currentPosition;
                  this.树友友树友树树何友何 = currentTime;
               }
            }
         }
      }
   }

   public static String[] A() {
      return 何何友友树何何友友何;
   }

   @Override
   public void M() {
      A();
      this.树树树树友友何友树友 = this.ircName.getValue();
      if (Client.channel != null && Client.channel.isActive()) {
         try {
            PacketWrapper.release(new CPacketPlayer(Client.channel, !this.ircName.getValue()));
         } catch (Throwable var4) {
         }
      }
   }

   private static String HE_DA_WEI() {
      return "何大伟为什么要诈骗何炜霖";
   }

   @EventTarget
   public void O(Render2DEvent event) {
      String[] a = c<"o">(861515544688102575L, 69566334569470L);
      if (!this.Q(new Object[]{52406761729175L})) {
         友树何友何友何树树树 fontManager = Cherish.instance.t();
         PoseStack poseStack = event.poseStack();
         String userID = c<"x">(this, 862640515068448716L, 69566334569470L).getValue();
         int ping = -1;
         switch (userID.hashCode()) {
            case -1301369156:
               if (!userID.equals("GameSense")) {
                  break;
               }

               ping = 0;
            case -1887554740:
               if (!userID.equals("Cherish")) {
                  break;
               }

               ping = 1;
            case -836935484:
               if (!userID.equals("Cherish Signature")) {
                  break;
               }

               ping = 2;
            case -1818419758:
               if (!userID.equals("Simple")) {
                  break;
               }

               ping = 3;
            case -1984932033:
               if (!userID.equals("Modern")) {
                  break;
               }

               ping = 4;
            case 823873568:
               if (userID.equals("Glass Panel")) {
                  ping = 5;
               }
         }

         label165: {
            label166: {
               switch (ping) {
                  case 0: {
                     String var10000 = c<"x">(this, 861902615594232417L, 69566334569470L).getValue();
                     String var10001 = WrapperUtils.f(111441258359257L);
                     int ax = 何树何树友树树友友何.u(mc.player, 86055205822349L);
                     String axx = var10001;
                     String axxx = var10000;
                     String text = "§f" + axxx + "§asense§f - " + axx + " - 吉吉岛 - " + ax + "ms ";
                     int width = c<"x">(this, 860247393433971256L, 69566334569470L).K("Minecraft") ? fontManager.w().Y(text) : fontManager.H(19).D(text);
                     Color lineColor = new Color(104, 104, 104);
                     Color darkest = new Color(0, 0, 0);
                     Color dark = new Color(70, 70, 70);
                     Color bgColor = new Color(23, 23, 23);
                     int fontColor = new Color(255, 255, 255).getRGB();
                     RenderUtils.drawRectangle(poseStack, 3.5F, 3.5F, width + 7, 18.0F, darkest.getRGB());
                     RenderUtils.drawRectangle(poseStack, 4.0F, 4.0F, width + 6, 17.0F, lineColor.getRGB());
                     RenderUtils.drawRectangle(poseStack, 5.0F, 5.0F, width + 4, 15.0F, darkest.getRGB());
                     RenderUtils.drawRectangle(poseStack, 5.5F, 5.5F, width + 3, 14.0F, dark.getRGB());
                     RenderUtils.drawRectangle(poseStack, 6.0F, 6.0F, width + 2, 13.0F, bgColor.getRGB());
                     RenderUtils.drawGradientRectL2R(poseStack, 6.0F, 18.0F, width + 2, 1.0F, this.getColor(1).getRGB(), this.getColor(4).getRGB());
                     if (c<"x">(this, 860247393433971256L, 69566334569470L).K("Minecraft")) {
                        fontManager.w().t(poseStack, text, 8.0F, 9.0F, fontColor, c<"X">(862324663314496361L, 69566334569470L).getValue());
                     }

                     fontManager.H(19).e(poseStack, text, 8.0, 8.0, fontColor, c<"X">(862324663314496361L, 69566334569470L).getValue());
                     if (a == null) {
                        break label165;
                     }
                  }
                  case 1: {
                     String text = "      | Cherish B3.7 | Name: " + mc.player.getDisplayName().getString() + " | FPS: " + WrapperUtils.s(112298472615430L);
                     float height = fontManager.H(20).x() + 8;
                     float width = fontManager.H(20).D(text) + 6;
                     RenderUtils.drawRectangle(poseStack, 4.0F, 5.0F, width, height, new Color(0, 0, 0, 135).getRGB());
                     RenderUtils.drawGradientRectL2R(poseStack, 4.0F, 5.0F, width, 1.0F, this.getColor(1).getRGB(), this.getColor(4).getRGB());
                     RenderUtils.e(poseStack, Cherish.instance.B(), 7, 14231920094600L, 7, 15, 15, 0.0F, 0.0F, 15.0F, 15.0F);
                     fontManager.H(20)
                        .Q(poseStack, text, 7.2F, 10.26F, new Color(255, 255, 255).getRGB(), c<"X">(862324663314496361L, 69566334569470L).getValue(), 1.5);
                  }
                  case 2:
                     String var92 = c<"x">(this, 860932432024975742L, 69566334569470L).getValue();
                     byte var96 = -1;
                     switch (var92.hashCode()) {
                        case 1748032758:
                           if (!var92.equals("getDancingScriptFont(65)")) {
                              break;
                           }

                           var96 = 0;
                        case -1227903508:
                           if (!var92.equals("getBorelFont(60)")) {
                              break;
                           }

                           var96 = 1;
                        case -1213907621:
                           if (var92.equals("getPlymouthRockFont(60)")) {
                              var96 = 2;
                           }
                     }

                     switch (var96) {
                        case 0:
                           ShaderUtils.u(
                              poseStack,
                              10.0F,
                              23.0F,
                              70079527892595L,
                              fontManager.O(65).D("cherish"),
                              7.0F,
                              26.0F,
                              26.0F,
                              何树友友树树友何树何.j(this.getColor(1), 0.3F)
                           );
                           fontManager.O(65).q(poseStack, "cherish", 10.0F, 10.0F, this.getColor(1).getRGB());
                        case 1:
                           ShaderUtils.u(
                              poseStack,
                              10.0F,
                              23.0F,
                              70079527892595L,
                              fontManager.E(60).D("cherish"),
                              7.0F,
                              26.0F,
                              26.0F,
                              何树友友树树友何树何.j(this.getColor(1), 0.3F)
                           );
                           fontManager.E(60).q(poseStack, "cherish", 10.0F, 10.0F, this.getColor(1).getRGB());
                        case 2:
                           ShaderUtils.u(
                              poseStack,
                              10.0F,
                              23.0F,
                              70079527892595L,
                              fontManager.S(60).D("cherish"),
                              7.0F,
                              26.0F,
                              26.0F,
                              何树友友树树友何树何.j(this.getColor(1), 0.3F)
                           );
                           fontManager.S(60).q(poseStack, "cherish", 10.0F, 10.0F, this.getColor(1).getRGB());
                     }
                  case 3:
                     if (c<"x">(this, 860247393433971256L, 69566334569470L).K("Minecraft")) {
                        fontManager.w().t(poseStack, this.n(), 1.0F, 4.0F, this.getColor(1).getRGB(), c<"X">(862324663314496361L, 69566334569470L).getValue());
                     }

                     fontManager.H(20).Z(poseStack, this.n(), 1.0, 4.0, this.getColor(4).getRGB(), c<"X">(862324663314496361L, 69566334569470L).getValue());
                  case 4:
                     break;
                  case 5:
                     break label166;
                  default:
                     break label165;
               }

               String var93 = c<"x">(this, 862730800476485967L, 69566334569470L).getValue();
               byte var97 = -1;
               switch (var93.hashCode()) {
                  case 65:
                     if (!var93.equals("A")) {
                        break;
                     }

                     var97 = 0;
                  case 66:
                     if (!var93.equals("B")) {
                        break;
                     }

                     var97 = 1;
                  case 67:
                     if (!var93.equals("C")) {
                        break;
                     }

                     var97 = 2;
                  case 68:
                     if (!var93.equals("D")) {
                        break;
                     }

                     var97 = 3;
                  case 69:
                     if (var93.equals("E")) {
                        var97 = 4;
                     }
               }

               switch (var97) {
                  case 0: {
                     String ver = new SimpleDateFormat("yyMMdd").format(new Date()) + "-B3.7";
                     String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
                     String var128 = c<"x">(this, 861902615594232417L, 69566334569470L).getValue();
                     String var10002 = WrapperUtils.f(111441258359257L);
                     int axxxx = WrapperUtils.s(112298472615430L);
                     String axxxxx = var10002;
                     String textxx = var128 + " " + ver + " | " + axxxxx + " | " + axxxx + " FPS | " + time;
                     float widthxxxx = fontManager.H(20).D(textxx) + 14.0F;
                     float height = fontManager.H(20).x() + 8.0F;
                     ShaderUtils.u(poseStack, 4.0F, 4.0F, 70079527892595L, widthxxxx, 4.5F + height, 6.0F, 10.0F, c<"X">(861268289671419873L, 69566334569470L));
                     RenderUtils.B(4, 4, (int)widthxxxx, 4);
                     ShaderUtils.o(poseStack, 100739365455537L, 4.0F, 4.0F, widthxxxx, 10.5F, 6.0F, new Color(140, 40, 40, 255));
                     RenderUtils.h(new Object[0]);
                     RenderUtils.B(4, 8, (int)widthxxxx, (int)height);
                     ShaderUtils.o(poseStack, 100739365455537L, 4.0F, 2.5F, widthxxxx, 22.0F, 6.0F, new Color(35, 39, 47, 200));
                     RenderUtils.h(new Object[0]);
                     fontManager.H(20)
                        .Z(
                           poseStack,
                           textxx,
                           11.0,
                           8.5F + (height - fontManager.H(20).x()) / 2.0F,
                           c<"X">(860413773040872699L, 69566334569470L).getRGB(),
                           c<"X">(862324663314496361L, 69566334569470L).getValue()
                        );
                     if (a == null) {
                        break;
                     }
                  }
                  case 1:
                     float widthx = fontManager.C(20).D(c<"x">(this, 861902615594232417L, 69566334569470L).getValue() + " vB3.7");
                     float fpsWidth = fontManager.C(20).D(WrapperUtils.s(112298472615430L) + "FPS");
                     ShaderUtils.w(58805847566642L, poseStack, 6.0F, 6.0F, 16.0F, 16.0F, 5.0F, 6.0F, instance.getColor(1));
                     ShaderUtils.o(poseStack, 100739365455537L, 6.0F, 6.0F, 16.0F, 16.0F, 5.0F, new Color(35, 39, 47, 200));
                     ShaderUtils.w(58805847566642L, poseStack, 26.0F, 6.0F, widthx + 8.0F, 16.0F, 5.0F, 6.0F, instance.getColor(1));
                     ShaderUtils.o(poseStack, 100739365455537L, 26.0F, 6.0F, widthx + 8.0F, 16.0F, 5.0F, new Color(35, 39, 47, 200));
                     ShaderUtils.w(58805847566642L, poseStack, 38.0F + widthx, 6.0F, fpsWidth + 8.0F, 16.0F, 5.0F, 6.0F, instance.getColor(1));
                     ShaderUtils.o(poseStack, 100739365455537L, 38.0F + widthx, 6.0F, fpsWidth + 8.0F, 16.0F, 5.0F, new Color(35, 39, 47, 200));
                     fontManager.r(50).q(poseStack, "k", 5.5F, 3.5F, instance.getColor(4).getRGB());
                     fontManager.C(20)
                        .Q(
                           poseStack,
                           c<"x">(this, 861902615594232417L, 69566334569470L).getValue()
                              + c<"X">(862829296234854230L, 69566334569470L)
                              + " B3.7"
                              + ChatFormatting.RESET,
                           30,
                           10,
                           instance.getColor(4).getRGB()
                        );
                     fontManager.C(20)
                        .q(
                           poseStack,
                           "" + c<"X">(860301878308744964L, 69566334569470L) + WrapperUtils.s(112298472615430L) + "FPS" + ChatFormatting.RESET,
                           42.0F + widthx,
                           10.0F,
                           instance.getColor(4).getRGB()
                        );
                  case 2:
                     String clientNameString = c<"x">(this, 861902615594232417L, 69566334569470L).getValue();
                     boolean drawShadow = c<"X">(862324663314496361L, 69566334569470L).getValue();
                     if (c<"x">(this, 860247393433971256L, 69566334569470L).K("Minecraft")) {
                        int i = 0;
                        if (0 < clientNameString.length()) {
                           char character = clientNameString.charAt(0);
                           String charStr = String.valueOf(character);
                           fontManager.w().t(poseStack, charStr, 1.0F, 4.0F, this.getColor(1).getRGB(), drawShadow);
                           float var129 = 1.0F + fontManager.w().Y(charStr);
                           i++;
                        }
                     }

                     int i = 0;
                     if (0 < clientNameString.length()) {
                        char character = clientNameString.charAt(0);
                        String charStr = String.valueOf(character);
                        fontManager.H(20).Z(poseStack, charStr, 1.0, 4.0, this.getColor(4).getRGB(), drawShadow);
                        float var130 = 1.0F + fontManager.H(20).D(charStr);
                        i++;
                     }
                  case 3:
                     String var103 = String.format("| %s | %s | %sFPS", "B3.7", WrapperUtils.f(111441258359257L), WrapperUtils.s(112298472615430L));
                     String mark = b<"a">(8819, 2143714104036772468L);
                     float widthxx = Cherish.instance.t().H(22).D(var103.toUpperCase()) + Cherish.instance.t().H(22).D(mark.toUpperCase()) - 22;
                     RenderUtils.drawRectangle(poseStack, 4.0F, 4.0F, widthxx + 10.0F, Cherish.instance.t().H(22).x() + 8, new Color(0, 0, 0, 65).getRGB());
                     Cherish.instance.t().H(22).Q(poseStack, mark, 8, 9, instance.getColor(1).getRGB());
                     Cherish.instance.t().H(19).Q(poseStack, var103, 12 + Cherish.instance.t().H(18).D(mark.toUpperCase()), 10, -1);
                  case 4: {
                     String textx = "      | Cherish B3.7 | Name: " + mc.player.getDisplayName().getString() + " | FPS: " + WrapperUtils.s(112298472615430L);
                     float height = fontManager.H(20).x() + 7;
                     float widthxxx = fontManager.H(20).D(textx) + 6;
                     ShaderUtils.o(poseStack, 100739365455537L, 5.0F, 5.0F, widthxxx, height + 3.0F, 5.0F, new Color(0, 0, 0, 95));
                     RenderUtils.r(
                        poseStack,
                        Cherish.instance.B(),
                        8,
                        7,
                        15,
                        15,
                        0.0F,
                        0.0F,
                        15.0F,
                        15.0F,
                        c<"X">(862324663314496361L, 69566334569470L).getValue(),
                        126226580076042L,
                        1.2
                     );
                     ShaderUtils.u(poseStack, 5.0F, 5.0F, 70079527892595L, widthxxx, height + 3.0F, 5.0F, 6.0F, new Color(0, 0, 0, 110));
                     fontManager.H(20)
                        .Q(poseStack, textx, 7.25, 10.75, new Color(255, 255, 255).getRGB(), c<"X">(862324663314496361L, 69566334569470L).getValue(), 1.2);
                  }
               }
            }

            String versionText = " | B3.7" + ((Boolean)Fucker.isBeta ? " - Beta" : "");
            String clientText = c<"x">(this, 861902615594232417L, 69566334569470L).getValue();
            float clientTextWidth = fontManager.C(22).D(clientText);
            float versionTextWidth = fontManager.C(20).D(versionText);
            float totalWidth = 32.0F + clientTextWidth + versionTextWidth + 12.0F;
            Color glassColor = new Color(0, 0, 0, 80);
            Color borderColor = new Color(255, 255, 255, 100);
            ShaderUtils.M(132138673613539L, poseStack, 8.0F, 8.0F, totalWidth, 26.0F, 6.0F, 1.0F, borderColor, glassColor, 10.0F);
            fontManager.r(55).q(poseStack, "k", 19.0F, 9.0F, c<"X">(860413773040872699L, 69566334569470L).getRGB());
            float textY = 8.0F + (26.0F - fontManager.C(22).x()) / 2.0F;
            fontManager.C(22).q(poseStack, clientText, 40.0F, textY, c<"X">(860413773040872699L, 69566334569470L).getRGB());
            float currentX = 40.0F + clientTextWidth;
            float versionY = 8.0F + (26.0F - fontManager.C(20).x()) / 2.0F;
            fontManager.C(20).q(poseStack, versionText, currentX, versionY, new Color(220, 220, 220).getRGB());
         }

         label111:
         if (c<"x">(this, 861027090914479479L, 69566334569470L).getValue()) {
            userID = "Unknown ID";
            ping = 0;
            if (mc.getConnection() != null && mc.getConnection().getPlayerInfo(mc.player.getUUID()) != null) {
               ping = Objects.requireNonNull(mc.getConnection().getPlayerInfo(mc.player.getUUID())).getLatency();
            }

            if (Fucker.W(51167843857826L, WrapperUtils.f(111441258359257L))) {
               userID = Fucker.x(10046672269524L, WrapperUtils.f(111441258359257L)).何树何树友何何何友友;
            }

            ChatFormatting var131 = c<"X">(862829296234854230L, 69566334569470L);
            ChatFormatting var140 = c<"X">(860301878308744964L, 69566334569470L);
            ChatFormatting var141 = c<"X">(862829296234854230L, 69566334569470L);
            ChatFormatting var10003 = c<"X">(860301878308744964L, 69566334569470L);
            String var10004 = Fucker.树树何树何何树友何树.何何何树何树何树何树;
            ChatFormatting var10005 = c<"X">(862829296234854230L, 69566334569470L);
            ChatFormatting var10006 = c<"X">(860301878308744964L, 69566334569470L);
            ChatFormatting var10008 = c<"X">(862829296234854230L, 69566334569470L);
            ChatFormatting var10009 = c<"X">(860301878308744964L, 69566334569470L);
            String var10010 = 友树何友友友树树树友.N(Fucker.树树何树何何树友何树.何何树树树何友树树友.树友何友友友友树树何, 45078101587872L);
            String axxxx = (Boolean)Fucker.isBeta ? " - Beta" : "";
            String axxxxx = var10010;
            ChatFormatting axxxxxx = var10009;
            ChatFormatting axxxxxxx = var10008;
            ChatFormatting axxxxxxxx = var10006;
            ChatFormatting axxxxxxxxx = var10005;
            String axxxxxxxxxx = var10004;
            ChatFormatting axxxxxxxxxxx = var10003;
            ChatFormatting axxxxxxxxxxxx = var141;
            ChatFormatting axxxxxxxxxxxxx = var140;
            String info = var131
               + "Build - "
               + axxxxxxxxxxxxx
               + "B3.7"
               + axxxxxxxxxxxx
               + " | UID - "
               + axxxxxxxxxxx
               + axxxxxxxxxx
               + axxxxxxxxx
               + " | IRC: "
               + axxxxxxxx
               + userID
               + axxxxxxx
               + " | TimeLeft: "
               + axxxxxx
               + axxxxx
               + axxxx;
            int yPos1 = mc.getWindow().getGuiScaledHeight() - 10;
            int yPos2 = mc.getWindow().getGuiScaledHeight() - 20;
            int yPos3 = mc.getWindow().getGuiScaledHeight() - 30;
            int yPos4 = mc.getWindow().getGuiScaledHeight() - 40;
            if (c<"x">(this, 860247393433971256L, 69566334569470L).K("Minecraft")) {
               树友友友何树友友树树 var132 = fontManager.w();
               var141 = c<"X">(860301878308744964L, 69566334569470L);
               String axxxxxxxxxxxxxx = String.format("%d %d %d", (int)mc.player.getX(), (int)mc.player.getY(), (int)mc.player.getZ());
               ChatFormatting axxxxxxxxxxxxxxx = var141;
               var132.t(
                  poseStack,
                  "XYZ: " + axxxxxxxxxxxxxxx + axxxxxxxxxxxxxx,
                  1.0F,
                  yPos1,
                  this.getColor(1).getRGB(),
                  c<"X">(862324663314496361L, 69566334569470L).getValue()
               );
               树友友友何树友友树树 var133 = fontManager.w();
               var141 = c<"X">(860301878308744964L, 69566334569470L);
               String axxxxxxxxxxxxxxxx = String.format("%.2f", c<"x">(this, 860470926210327754L, 69566334569470L));
               ChatFormatting axxxxxxxxxxxxxxxxx = var141;
               var133.t(
                  poseStack,
                  "Speed: " + axxxxxxxxxxxxxxxxx + axxxxxxxxxxxxxxxx + " b/s",
                  1.0F,
                  yPos2,
                  this.getColor(2).getRGB(),
                  c<"X">(862324663314496361L, 69566334569470L).getValue()
               );
               树友友友何树友友树树 var134 = fontManager.w();
               var141 = c<"X">(860301878308744964L, 69566334569470L);
               int axxxxxxxxxxxxxxxxxx = WrapperUtils.s(112298472615430L);
               ChatFormatting axxxxxxxxxxxxxxxxxxx = var141;
               var134.t(
                  poseStack,
                  "FPS: " + axxxxxxxxxxxxxxxxxxx + axxxxxxxxxxxxxxxxxx,
                  1.0F,
                  yPos3,
                  this.getColor(3).getRGB(),
                  c<"X">(862324663314496361L, 69566334569470L).getValue()
               );
               树友友友何树友友树树 var135 = fontManager.w();
               ChatFormatting axxxxxxxxxxxxxxxxxxxx = c<"X">(860301878308744964L, 69566334569470L);
               var135.t(
                  poseStack,
                  "Ping: " + axxxxxxxxxxxxxxxxxxxx + ping + "ms",
                  1.0F,
                  yPos4,
                  this.getColor(4).getRGB(),
                  c<"X">(862324663314496361L, 69566334569470L).getValue()
               );
               fontManager.w()
                  .t(
                     poseStack,
                     info,
                     mc.getWindow().getGuiScaledWidth() - fontManager.w().Y(info) - 1,
                     yPos1,
                     this.getColor(4).getRGB(),
                     c<"X">(862324663314496361L, 69566334569470L).getValue()
                  );
               if (a == null) {
                  break label111;
               }
            }

            何何友友树何树何友树 var136 = fontManager.H(20);
            var141 = c<"X">(860301878308744964L, 69566334569470L);
            String axxxxxxxxxxxxxx = String.format("%d %d %d", (int)mc.player.getX(), (int)mc.player.getY(), (int)mc.player.getZ());
            ChatFormatting axxxxxxxxxxxxxxx = var141;
            var136.Z(
               poseStack,
               "XYZ: " + axxxxxxxxxxxxxxx + axxxxxxxxxxxxxx,
               1.0,
               yPos1,
               this.getColor(1).getRGB(),
               c<"X">(862324663314496361L, 69566334569470L).getValue()
            );
            何何友友树何树何友树 var137 = fontManager.H(20);
            var141 = c<"X">(860301878308744964L, 69566334569470L);
            String axxxxxxxxxxxxxxxx = String.format("%.2f", c<"x">(this, 860470926210327754L, 69566334569470L));
            ChatFormatting axxxxxxxxxxxxxxxxx = var141;
            var137.Z(
               poseStack,
               "Speed: " + axxxxxxxxxxxxxxxxx + axxxxxxxxxxxxxxxx + " b/s",
               1.0,
               yPos2,
               this.getColor(2).getRGB(),
               c<"X">(862324663314496361L, 69566334569470L).getValue()
            );
            何何友友树何树何友树 var138 = fontManager.H(20);
            var141 = c<"X">(860301878308744964L, 69566334569470L);
            int axxxxxxxxxxxxxxxxxx = WrapperUtils.s(112298472615430L);
            ChatFormatting axxxxxxxxxxxxxxxxxxx = var141;
            var138.Z(
               poseStack,
               "FPS: " + axxxxxxxxxxxxxxxxxxx + axxxxxxxxxxxxxxxxxx,
               1.0,
               yPos3,
               this.getColor(3).getRGB(),
               c<"X">(862324663314496361L, 69566334569470L).getValue()
            );
            何何友友树何树何友树 var139 = fontManager.H(20);
            ChatFormatting var88 = c<"X">(860301878308744964L, 69566334569470L);
            var139.Z(poseStack, "Ping: " + var88 + ping + "ms", 1.0, yPos4, this.getColor(4).getRGB(), c<"X">(862324663314496361L, 69566334569470L).getValue());
            fontManager.H(20)
               .Z(
                  poseStack,
                  info,
                  mc.getWindow().getGuiScaledWidth() - fontManager.H(20).D(info) - 1,
                  yPos1,
                  this.getColor(4).getRGB(),
                  c<"X">(862324663314496361L, 69566334569470L).getValue()
               );
         }

         if (event.side() == c<"X">(862229818707802887L, 69566334569470L)) {
            c<"X">(861611510777004861L, 69566334569470L).n(poseStack);
         }
      }
   }

   public Color getColor(int tick) {
      A();
      String var9 = 树树何树何何树何何树.树树友友友友树友何何.友树友树树树友树友树.getValue();
      byte var10 = -1;
      switch (var9.hashCode()) {
         case 2181788:
            if (!var9.equals("Fade")) {
               break;
            }

            var10 = 0;
         case -1808614770:
            if (!var9.equals("Static")) {
               break;
            }

            var10 = 1;
         case -1656737386:
            if (!var9.equals("Rainbow")) {
               break;
            }

            var10 = 2;
         case 2052876273:
            if (var9.equals("Double")) {
               var10 = 3;
            }
      }
      return switch (var10) {
         case 0 -> 何树友友树树友何树何.F(5, tick * 20, 树树何树何何树何何树.树树友友友友树友何何.树树何何友树何何友树.getValue(), 23681914207379L, 1.0F);
         case 1 -> (Color)树树何树何何树何何树.树树友友友友树友何何.树树何何友树何何友树.getValue();
         case 2 -> new Color(Color.HSBtoRGB((float)((mc.player == null ? 0.0 : mc.player.tickCount / 50.0) + Math.sin(tick / 50.0 * 1.6)) % 1.0F, 0.5F, 1.0F));
         case 3 -> {
            tick *= 100;
            yield new Color(
               何树友友树树友何树何.g(
                  树树何树何何树何何树.树树友友友友树友何何.树树何何友树何何友树.getValue(),
                  34677312445214L,
                  树树何树何何树何何树.树树友友友友树友何何.友何何友何树树树树树.getValue(),
                  2000.0F,
                  -tick / 40,
                  75L,
                  2.0,
                  255.0
               )
            );
         }
         default -> new Color(255, 255, 255, 255);
      };
   }
}
