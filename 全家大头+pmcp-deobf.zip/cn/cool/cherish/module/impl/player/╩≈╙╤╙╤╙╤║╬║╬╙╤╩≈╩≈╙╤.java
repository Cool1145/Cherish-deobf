package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.ui.何树树友树树友树友树;
import cn.cool.cherish.utils.友树友友何友树友树友;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.item.友何树何友树友树何何;
import cn.cool.cherish.utils.player.树何何何树何友何树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import org.apache.commons.lang3.tuple.Pair;

public class 树友友友何何友树树友 extends Module implements 何树友 {
   public static 树友友友何何友树树友 树何何友何友何何友树;
   private final NumberValue 友友树树树友树树何何;
   private final NumberValue 友友何何何何友何友何;
   private final NumberValue 何何何何树树树何何友;
   private final BooleanValue 何何友友树友友友树友;
   private final BooleanValue 友树友树何友何友友友;
   private final ModeValue 何何友树树树何何何何;
   private final ModeValue 树何友何友友树何友友;
   private final BooleanValue 友树何友何友友何何树;
   private final BooleanValue 树友何何树树树何树何;
   private final NumberValue 树友树树友树何树何树;
   public final NumberValue 友友友何何何友何友树;
   private final NumberValue 何树树友友树友友友友;
   private final NumberValue 树树友何何何友何树友;
   private final NumberValue 何友树友友友何树树友;
   private final NumberValue 树树何何何何友树友何;
   private final NumberValue 何树何何友友树树友友;
   private final NumberValue 友友何友友何树树何友;
   private final NumberValue 树何树友树何树友何友;
   private final NumberValue 树何树树友友何何友何;
   private final NumberValue 树树何友树树友树树何;
   private final NumberValue 友友树友树何树树何何;
   private final NumberValue 友何树何友何友何何何;
   private final NumberValue 何树友何友树树树何何;
   private final NumberValue 何树树友何友树树树友;
   private static final 树友树友友何何树何何 何何树树何友何树何友;
   private boolean 何友何何友何树何何何;
   private boolean 何何树树友树友何友树;
   private int 何树树树友友树何何友;
   private int 树树何树树树何树树友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[88];
   private static final String[] k = new String[88];
   private static String LIU_YA_FENG;

   public 树友友友何何友树树友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;I)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:200)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/树友友友何何友树树友.a J
      // 003: ldc2_w 64856154071918
      // 006: lxor
      // 007: lstore 1
      // 008: ldc2_w 2917226392372895721
      // 00b: lload 1
      // 00c: invokedynamic b (JJ)[Lcn/cool/cherish/module/Module; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 011: aload 0
      // 012: sipush 6418
      // 015: ldc2_w 1222288919643250327
      // 018: lload 1
      // 019: lxor
      // 01a: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01f: sipush 23989
      // 022: ldc2_w 6561297049758276102
      // 025: lload 1
      // 026: lxor
      // 027: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: ldc2_w 2917504909017798240
      // 02f: lload 1
      // 030: invokedynamic û (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 035: bipush 66
      // 037: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;I)V
      // 03a: aload 0
      // 03b: new cn/cool/cherish/value/impl/NumberValue
      // 03e: dup
      // 03f: sipush 30071
      // 042: ldc2_w 3608591268317377261
      // 045: lload 1
      // 046: lxor
      // 047: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04c: sipush 20397
      // 04f: ldc2_w 3289557164303452212
      // 052: lload 1
      // 053: lxor
      // 054: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 059: bipush 75
      // 05b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 05e: bipush 0
      // 05f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 062: sipush 500
      // 065: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 068: bipush 10
      // 06a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 06d: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 070: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.友友树树树友树树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 073: aload 0
      // 074: new cn/cool/cherish/value/impl/NumberValue
      // 077: dup
      // 078: sipush 29735
      // 07b: ldc2_w 8176007413783180166
      // 07e: lload 1
      // 07f: lxor
      // 080: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 085: sipush 27603
      // 088: ldc2_w 6141861758285229182
      // 08b: lload 1
      // 08c: lxor
      // 08d: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 092: bipush 1
      // 093: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 096: bipush 0
      // 097: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09a: bipush 10
      // 09c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09f: bipush 1
      // 0a0: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0a3: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0a6: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.友友何何何何友何友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 0a9: aload 0
      // 0aa: new cn/cool/cherish/value/impl/NumberValue
      // 0ad: dup
      // 0ae: sipush 20760
      // 0b1: ldc2_w 7087798698884732595
      // 0b4: lload 1
      // 0b5: lxor
      // 0b6: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bb: sipush 30099
      // 0be: ldc2_w 5854524837094437419
      // 0c1: lload 1
      // 0c2: lxor
      // 0c3: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c8: bipush 75
      // 0ca: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0cd: bipush 0
      // 0ce: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0d1: sipush 500
      // 0d4: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0d7: bipush 10
      // 0d9: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0dc: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0df: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.何何何何树树树何何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 0e2: aload 0
      // 0e3: new cn/cool/cherish/value/impl/BooleanValue
      // 0e6: dup
      // 0e7: sipush 27331
      // 0ea: ldc2_w 2417308805472890225
      // 0ed: lload 1
      // 0ee: lxor
      // 0ef: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f4: sipush 745
      // 0f7: ldc2_w 2057352090151208270
      // 0fa: lload 1
      // 0fb: lxor
      // 0fc: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 101: bipush 1
      // 102: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 105: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 108: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.何何友友树友友友树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 10b: aload 0
      // 10c: new cn/cool/cherish/value/impl/BooleanValue
      // 10f: dup
      // 110: sipush 21997
      // 113: ldc2_w 6967948632687317600
      // 116: lload 1
      // 117: lxor
      // 118: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11d: sipush 15207
      // 120: ldc2_w 8713833949400169680
      // 123: lload 1
      // 124: lxor
      // 125: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 12a: bipush 1
      // 12b: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 12e: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 131: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.友树友树何友何友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 134: aload 0
      // 135: new cn/cool/cherish/value/impl/ModeValue
      // 138: dup
      // 139: sipush 15942
      // 13c: ldc2_w 308451243043682770
      // 13f: lload 1
      // 140: lxor
      // 141: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 146: sipush 1097
      // 149: ldc2_w 9004392243595297743
      // 14c: lload 1
      // 14d: lxor
      // 14e: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 153: bipush 5
      // 154: anewarray 156
      // 157: dup
      // 158: bipush 0
      // 159: sipush 28473
      // 15c: ldc2_w 8342221630878132410
      // 15f: lload 1
      // 160: lxor
      // 161: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 166: aastore
      // 167: dup
      // 168: bipush 1
      // 169: sipush 10156
      // 16c: ldc2_w 5494568437956665406
      // 16f: lload 1
      // 170: lxor
      // 171: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 176: aastore
      // 177: dup
      // 178: bipush 2
      // 179: sipush 18761
      // 17c: ldc2_w 2887588146391158501
      // 17f: lload 1
      // 180: lxor
      // 181: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 186: aastore
      // 187: dup
      // 188: bipush 3
      // 189: sipush 13953
      // 18c: ldc2_w 1571127549253841175
      // 18f: lload 1
      // 190: lxor
      // 191: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 196: aastore
      // 197: dup
      // 198: bipush 4
      // 199: sipush 17166
      // 19c: ldc2_w 6507244944544760972
      // 19f: lload 1
      // 1a0: lxor
      // 1a1: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1a6: aastore
      // 1a7: sipush 10156
      // 1aa: ldc2_w 5494568437956665406
      // 1ad: lload 1
      // 1ae: lxor
      // 1af: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b4: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 1b7: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.何何友树树树何何何何 Lcn/cool/cherish/value/impl/ModeValue;
      // 1ba: aload 0
      // 1bb: new cn/cool/cherish/value/impl/ModeValue
      // 1be: dup
      // 1bf: sipush 31193
      // 1c2: ldc2_w 1829509175366434407
      // 1c5: lload 1
      // 1c6: lxor
      // 1c7: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1cc: sipush 28723
      // 1cf: ldc2_w 7753816704198686665
      // 1d2: lload 1
      // 1d3: lxor
      // 1d4: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1d9: bipush 3
      // 1da: anewarray 156
      // 1dd: dup
      // 1de: bipush 0
      // 1df: sipush 2076
      // 1e2: ldc2_w 5932834511946108802
      // 1e5: lload 1
      // 1e6: lxor
      // 1e7: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ec: aastore
      // 1ed: dup
      // 1ee: bipush 1
      // 1ef: sipush 10892
      // 1f2: ldc2_w 2542662188781792549
      // 1f5: lload 1
      // 1f6: lxor
      // 1f7: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1fc: aastore
      // 1fd: dup
      // 1fe: bipush 2
      // 1ff: sipush 27056
      // 202: ldc2_w 5340932941633859130
      // 205: lload 1
      // 206: lxor
      // 207: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 20c: aastore
      // 20d: sipush 2076
      // 210: ldc2_w 5932834511946108802
      // 213: lload 1
      // 214: lxor
      // 215: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 21a: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 21d: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.树何友何友友树何友友 Lcn/cool/cherish/value/impl/ModeValue;
      // 220: aload 0
      // 221: new cn/cool/cherish/value/impl/BooleanValue
      // 224: dup
      // 225: sipush 18120
      // 228: ldc2_w 2681250823460520295
      // 22b: lload 1
      // 22c: lxor
      // 22d: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 232: sipush 24653
      // 235: ldc2_w 6324549298842249209
      // 238: lload 1
      // 239: lxor
      // 23a: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23f: bipush 1
      // 240: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 243: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 246: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.友树何友何友友何何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 249: aload 0
      // 24a: new cn/cool/cherish/value/impl/BooleanValue
      // 24d: dup
      // 24e: sipush 2611
      // 251: ldc2_w 5876098192151137702
      // 254: lload 1
      // 255: lxor
      // 256: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 25b: sipush 32718
      // 25e: ldc2_w 3347074261821536349
      // 261: lload 1
      // 262: lxor
      // 263: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 268: bipush 0
      // 269: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 26c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 26f: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.树友何何树树树何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 272: aload 0
      // 273: new cn/cool/cherish/value/impl/NumberValue
      // 276: dup
      // 277: sipush 14889
      // 27a: ldc2_w 1520451504880287116
      // 27d: lload 1
      // 27e: lxor
      // 27f: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 284: sipush 11612
      // 287: ldc2_w 1815529101883796135
      // 28a: lload 1
      // 28b: lxor
      // 28c: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 291: bipush 64
      // 293: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 296: bipush 16
      // 298: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 29b: sipush 256
      // 29e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2a1: bipush 16
      // 2a3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2a6: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 2a9: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.树友树树友树何树何树 Lcn/cool/cherish/value/impl/NumberValue;
      // 2ac: aload 0
      // 2ad: new cn/cool/cherish/value/impl/NumberValue
      // 2b0: dup
      // 2b1: sipush 10432
      // 2b4: ldc2_w 1728945259611746170
      // 2b7: lload 1
      // 2b8: lxor
      // 2b9: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2be: sipush 523
      // 2c1: ldc2_w 8459267669423539629
      // 2c4: lload 1
      // 2c5: lxor
      // 2c6: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2cb: sipush 256
      // 2ce: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2d1: bipush 64
      // 2d3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2d6: sipush 512
      // 2d9: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2dc: bipush 64
      // 2de: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2e1: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 2e4: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.友友友何何何友何友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 2e7: aload 0
      // 2e8: new cn/cool/cherish/value/impl/NumberValue
      // 2eb: dup
      // 2ec: sipush 10936
      // 2ef: ldc2_w 666113121960979736
      // 2f2: lload 1
      // 2f3: lxor
      // 2f4: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2f9: sipush 21401
      // 2fc: ldc2_w 4547674574732170241
      // 2ff: lload 1
      // 300: lxor
      // 301: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 306: sipush 128
      // 309: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 30c: bipush 32
      // 30e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 311: sipush 256
      // 314: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 317: bipush 32
      // 319: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 31c: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 31f: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.何树树友友树友友友友 Lcn/cool/cherish/value/impl/NumberValue;
      // 322: aload 0
      // 323: new cn/cool/cherish/value/impl/NumberValue
      // 326: dup
      // 327: sipush 27906
      // 32a: ldc2_w 1517724929485384350
      // 32d: lload 1
      // 32e: lxor
      // 32f: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 334: sipush 13596
      // 337: ldc2_w 6087803012539249303
      // 33a: lload 1
      // 33b: lxor
      // 33c: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 341: bipush 1
      // 342: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 345: bipush 1
      // 346: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 349: bipush 16
      // 34b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 34e: bipush 1
      // 34f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 352: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 355: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.树树友何何何友何树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 358: astore 3
      // 359: aload 0
      // 35a: new cn/cool/cherish/value/impl/NumberValue
      // 35d: dup
      // 35e: sipush 23428
      // 361: ldc2_w 4727308846176377888
      // 364: lload 1
      // 365: lxor
      // 366: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 36b: sipush 24298
      // 36e: ldc2_w 7590674884394981713
      // 371: lload 1
      // 372: lxor
      // 373: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 378: bipush 0
      // 379: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 37c: bipush 0
      // 37d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 380: bipush 9
      // 382: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 385: bipush 1
      // 386: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 389: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 38c: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.何友树友友友何树树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 38f: aload 0
      // 390: new cn/cool/cherish/value/impl/NumberValue
      // 393: dup
      // 394: sipush 15872
      // 397: ldc2_w 8723723476037466536
      // 39a: lload 1
      // 39b: lxor
      // 39c: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3a1: sipush 25586
      // 3a4: ldc2_w 2405135543743718505
      // 3a7: lload 1
      // 3a8: lxor
      // 3a9: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3ae: bipush 0
      // 3af: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 3b2: bipush 0
      // 3b3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 3b6: bipush 9
      // 3b8: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 3bb: bipush 1
      // 3bc: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 3bf: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 3c2: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.树树何何何何友树友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 3c5: aload 0
      // 3c6: new cn/cool/cherish/value/impl/NumberValue
      // 3c9: dup
      // 3ca: sipush 21412
      // 3cd: ldc2_w 782502592639177771
      // 3d0: lload 1
      // 3d1: lxor
      // 3d2: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3d7: sipush 6902
      // 3da: ldc2_w 4597808149080300918
      // 3dd: lload 1
      // 3de: lxor
      // 3df: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3e4: bipush 0
      // 3e5: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 3e8: bipush 0
      // 3e9: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 3ec: bipush 9
      // 3ee: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 3f1: bipush 1
      // 3f2: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 3f5: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 3f8: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.何树何何友友树树友友 Lcn/cool/cherish/value/impl/NumberValue;
      // 3fb: aload 0
      // 3fc: new cn/cool/cherish/value/impl/NumberValue
      // 3ff: dup
      // 400: sipush 7741
      // 403: ldc2_w 8644066458371381636
      // 406: lload 1
      // 407: lxor
      // 408: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 40d: sipush 25594
      // 410: ldc2_w 8281825898386498562
      // 413: lload 1
      // 414: lxor
      // 415: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41a: bipush 0
      // 41b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 41e: bipush 0
      // 41f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 422: bipush 9
      // 424: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 427: bipush 1
      // 428: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 42b: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 42e: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.友友何友友何树树何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 431: aload 0
      // 432: new cn/cool/cherish/value/impl/NumberValue
      // 435: dup
      // 436: sipush 27980
      // 439: ldc2_w 5770321403111975676
      // 43c: lload 1
      // 43d: lxor
      // 43e: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 443: sipush 13767
      // 446: ldc2_w 8795186153972527734
      // 449: lload 1
      // 44a: lxor
      // 44b: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 450: bipush 0
      // 451: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 454: bipush 0
      // 455: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 458: bipush 9
      // 45a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 45d: bipush 1
      // 45e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 461: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 464: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.树何树友树何树友何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 467: aload 0
      // 468: new cn/cool/cherish/value/impl/NumberValue
      // 46b: dup
      // 46c: sipush 12070
      // 46f: ldc2_w 3411779297940564136
      // 472: lload 1
      // 473: lxor
      // 474: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 479: sipush 8368
      // 47c: ldc2_w 7494429070816929541
      // 47f: lload 1
      // 480: lxor
      // 481: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 486: bipush 0
      // 487: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 48a: bipush 0
      // 48b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 48e: bipush 9
      // 490: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 493: bipush 1
      // 494: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 497: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 49a: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.树何树树友友何何友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 49d: aload 0
      // 49e: new cn/cool/cherish/value/impl/NumberValue
      // 4a1: dup
      // 4a2: sipush 31533
      // 4a5: ldc2_w 7883063000090885281
      // 4a8: lload 1
      // 4a9: lxor
      // 4aa: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4af: sipush 5956
      // 4b2: ldc2_w 1242052174308167910
      // 4b5: lload 1
      // 4b6: lxor
      // 4b7: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4bc: bipush 0
      // 4bd: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 4c0: bipush 0
      // 4c1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 4c4: bipush 9
      // 4c6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 4c9: bipush 1
      // 4ca: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 4cd: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 4d0: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.树树何友树树友树树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 4d3: aload 0
      // 4d4: new cn/cool/cherish/value/impl/NumberValue
      // 4d7: dup
      // 4d8: sipush 6056
      // 4db: ldc2_w 6095387652519940098
      // 4de: lload 1
      // 4df: lxor
      // 4e0: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e5: sipush 12015
      // 4e8: ldc2_w 7730921216904784211
      // 4eb: lload 1
      // 4ec: lxor
      // 4ed: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4f2: bipush 0
      // 4f3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 4f6: bipush 0
      // 4f7: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 4fa: bipush 9
      // 4fc: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 4ff: bipush 1
      // 500: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 503: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 506: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.友友树友树何树树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 509: aload 0
      // 50a: new cn/cool/cherish/value/impl/NumberValue
      // 50d: dup
      // 50e: sipush 26076
      // 511: ldc2_w 226462695372628579
      // 514: lload 1
      // 515: lxor
      // 516: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 51b: sipush 10448
      // 51e: ldc2_w 9001307874680565592
      // 521: lload 1
      // 522: lxor
      // 523: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 528: bipush 0
      // 529: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 52c: bipush 0
      // 52d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 530: bipush 9
      // 532: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 535: bipush 1
      // 536: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 539: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 53c: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.友何树何友何友何何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 53f: aload 0
      // 540: new cn/cool/cherish/value/impl/NumberValue
      // 543: dup
      // 544: sipush 24488
      // 547: ldc2_w 7055696430815385655
      // 54a: lload 1
      // 54b: lxor
      // 54c: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 551: sipush 18199
      // 554: ldc2_w 8355660840293859478
      // 557: lload 1
      // 558: lxor
      // 559: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 55e: bipush 0
      // 55f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 562: bipush 0
      // 563: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 566: bipush 9
      // 568: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 56b: bipush 1
      // 56c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 56f: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 572: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.何树友何友树树树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 575: aload 0
      // 576: new cn/cool/cherish/value/impl/NumberValue
      // 579: dup
      // 57a: sipush 5150
      // 57d: ldc2_w 3476091813579314074
      // 580: lload 1
      // 581: lxor
      // 582: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 587: sipush 25347
      // 58a: ldc2_w 827077274866656404
      // 58d: lload 1
      // 58e: lxor
      // 58f: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 594: bipush 0
      // 595: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 598: bipush 0
      // 599: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 59c: bipush 9
      // 59e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5a1: bipush 1
      // 5a2: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5a5: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 5a8: putfield cn/cool/cherish/module/impl/player/树友友友何何友树树友.何树树友何友树树树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 5ab: aload 0
      // 5ac: bipush 0
      // 5ad: ldc2_w 2910659417255860853
      // 5b0: lload 1
      // 5b1: invokedynamic p (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5b6: aload 0
      // 5b7: bipush 0
      // 5b8: ldc2_w 2916984312637925499
      // 5bb: lload 1
      // 5bc: invokedynamic p (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5c1: aload 0
      // 5c2: bipush 0
      // 5c3: ldc2_w 2911088393952638036
      // 5c6: lload 1
      // 5c7: invokedynamic p (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5cc: aload 0
      // 5cd: bipush 0
      // 5ce: ldc2_w 2917431756745456453
      // 5d1: lload 1
      // 5d2: invokedynamic p (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5d7: aload 0
      // 5d8: ldc2_w 2910826962947056474
      // 5db: lload 1
      // 5dc: invokedynamic a (Lcn/cool/cherish/module/impl/player/树友友友何何友树树友;JJ)V bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5e1: aload 3
      // 5e2: ifnull 602
      // 5e5: ldc2_w 2911472037823316705
      // 5e8: lload 1
      // 5e9: invokedynamic b (JJ)Z bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5ee: ifeq 5f8
      // 5f1: goto 5f4
      // 5f4: bipush 0
      // 5f5: goto 5f9
      // 5f8: bipush 1
      // 5f9: ldc2_w 2911290057162483778
      // 5fc: lload 1
      // 5fd: invokedynamic b (ZJJ)V bsm=cn/cool/cherish/module/impl/player/树友友友何何友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 602: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(5692591089352724301L, -2929389323227766240L, MethodHandles.lookup().lookupClass()).a(176919012807088L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 48033312551511L;
      long var11 = var9 ^ 50220240245450L;
      a();
      Cipher var0;
      Cipher var15 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[67];
      int var5 = 0;
      String var4 = "Ã\u0082Ø©\u0007½©\u008eu\u001bHNÍX¬7ÊÈ4Výt½?\u001fÚ\u001ahÄ¹\u0087° \u009a\u0011\u001dQÕ´\r¨\u009ea$&Ú\u0016f¼>\u0089óc'µë\u0001\u0081\u0085\u0000\"?\u0014\u008dA \u009dK~tèb½\u009f\u0088\u0017\u0095\u009bÊ\u0094\ba\u0012\u000bK£(ñÍ'\u0019\u0082\u0011)4AîJ l\u0097»\u0081\u0012ûÕé¶Zxª¨\\òZ\u008cÓñÂ}èàSÀjí\u001b#Hã¬\u0018k\u0091à¬\u0012¿Ûe¯'ó{½\u0003Íu86>mºÕ\u009b×(Y$\u0090\u0098\u00ada\u0007\u0089¿ÜÈ2\u0090O\u0001A<\u0018\u0007þ¡ß\u009d\u00011\u0090å\u000f\u0094Ùi\u0084ti7{áDiE\u0018df½\f1\u001fÿ\u001a¢\u0017'~¢ãW\u001cÑÍ(QÀÝ)= 7åJyH\u008c\u000b\u0086¬£\u008b\u001ccbePqù\u0094\u008eÌÊ^æöÎY\u007fr\u001d8\u0093 çT\u001cúNÜ\u0000?'þ Ç0\u0080mL\u007fý\u009dc¿¿ÐMaê³{¹L\u0005Ù *¡ªQ\u009eO²\u009c\\\u0013\u0084M\u008b ÃÂ+j\u0099Å¼\u00ads¨®8\u0007\u008dztáú ¾\u0014×GÊñ/ÊÍ6\u008e¢ö_ë\u008c\u0010|\u009c\u008bÖÒÏ\u0088¾.õ%2ý¥\u0082\u0018é\u0018\u0084ñ\u0092¸ïq&\u0081<5¦\u0098\u000e]ÙC\u0004wÌ\u001aYy \u0099Èì\nú ºÔ\u0081bYÕû\u008eº¶*`\u0083h>3ÿI¸\u009f\u000eGøn\n¶(\u0007³r]R\u0088v\"\"ÓÈ9´éZ\u0018\u0080{ú¤\u008b½] bË\u0095\u0018Á\u0095I°\u00adÆ\u0089à\u008eÀ¾¯\u0018`?ýjC¹Â\u007f#\f\u0084tÌþA\u008a\u0006\u009eÒÑóªÅ\u0089 |k\u0081\u0011½/¬\u0001÷PZ\u001aÐ±@rÍÏE8)µump\r\u009eÿñ¨\"\u0094(«ºðxCv\u0093~0pE÷gÞÂ2³\u000bÏÐ-#)Ü\u0094 ©G\u00838Ì\u0018ë\u008b\u0098\u0007)Ý\u0084\u0016\u0018é ×\u0093ÆÈo\u001cR¹\u0080\u0006\u007f\u009dwÅZ½b.\u001e|;È\u0018Ç`JÁìl\u0015\u008f\u001f\u000eµ\u0012LÐ\u009cB\u008a\n®Ì£\u007fÐ¦ \u0083¥wuÆó\u001f\u0003EÌ\u0095É³I\u007f\u0085aâè\fÙ»|âvO\u001f®Á}ÔE\u0018Ô?ù\u001fñÜa\u0086¶\u0012Â\u008fsß.ônù28¦Îva\u0018ZQ\u008fÚÝ\"\u009cQ *§\u00867z%\u000fíâ°¿\u0080À·\u0091\u0018À\n\u008aR6\u0006±ñ¡\u0091\u001f\u0089hÒ¢ð\u0013Ù\u0082\u0011I93\u000e ÅìXº¥B\u0013ç\u0085v¬\u0090\u0014\u000b\u0014T¥AÑÇ\u0010\u0085GÙ\u009c\u0099`xrÊßc(òì_\u0089V\u0019Tó×\u0092Õ\u0007\u0014`×Â\u0093\u009f\u0017ý$=!Bzî@LyRD{4¯ò\u0005ã3N© /!\u000f\u009c\u00932A4á\u0091/JÆ^\u00ad\u0094ßÁ\u008dÙ?\u00ad]\u0094Ï\u007f\u001cS±g\u008a#\u0018ËÊÉX¸4\u0087|\u0015\u0098wêø\u0015p0ò³\u0015¿²\u000e\u0004Ò \u008c\u0096{ÕÍEq\u0094ß\"\u0019À?ÿp\u009ca\u008dæ<\u001bÁ\u001bê;5#\t:6!M(AJ\u0080â¢ûòsN\nÔH0Ô7MÎr\r¬\u008eÎËú«#\u0093J©ÈT\u0085\\ÐÏóÆÒû{()ÑxOUúë\u0013¥Ä\u0014zÀ÷\u0012¼£m}\u0013ÇC×LâÂ\u009dÚJØEpÓ©\u0080¥\u0007êçô\u0018\u008dO\u00adäÿW\u0017\u008dóÃãAuTÃ¡ªTøP\u001dyÖV8\r\u0084\u001cÆbÌ+µô\u0096Ä@Y`(\u0091¸»\u0015Êà\u009dÑ\u0080k Øîö7\u0007/'`cO\f+}y6ÆaÅ«\u009d)\u001aN£²\u0088÷ñ\u0091\u0083\u0010ÅÁ.6\u008b\u0001ÿµß\u0006þ®ù\u0014§þ\u0018ÅJá |\u0014}\u008dã/\u0012±\u0001cÌË\u0094\bLðjI@\r(6\u0087\u009bÄOdÏsÚä \u0000\u008a\u0011édG$G?S¸gT'\u0086*\u0087x\u000f\u0091Hî4yg§¬;È\u0010²²ç»\u00823ß\fÃ{A\u0010Ê\u0013Ç- ú\u0091Frpõy\b\u0017c\u0097\u0094'\u0098,³`\u0011\u0086zu\u0018\u0006Ìù\u009b\u0004\u001d\u008f=\u008b\u0084\u0018\u0001 òÀe$=Ê¾ó£åê![êHò\u008b\u0097üóì\u001a gÁÝ\u0011!JÛ\u009d,ÞØ\u0006Ê`ÁSFl\u0087v¬\u0002uwt\u001bAc¥µÄE ý-Ôêãï\r\u0011\u0018ÈK\u008dR\u0094%HbÜÏ¡\u0017×²Ö¾áÖ°Åc7¯\u0018OÚ5 l\u000b\u0096\u008cüá±r¦\u0094\u009dr-¦\u009eê|\u0001RR \u0082Ú\u0016\u008b´§I\u008d\u008a_Â\u008f\u0085B¥\u0011\r¨\u0081¨\u0006s]L ¿<Ò»I\u008eN\u0018\u009e\u008dì,¢¢,-\u001aÏ¹·\u0000Ðz'/¨\u0095ä\u001a!)Å\u0010\u009f$2A¨Ì\u001d¯'}\u0094sþ¦\u0018½\u0010ØâÒ/\u0099õr\u0080'\u0099\u0096Ý\u0013\u0094Ù¹ Ó³oE\u007f5äëÉ+:\u0002Ëó¾¬¼+Gò X»JéEoáÉ\u0094Þc\u0018\u008a\n_Ù8åK'KzY\u0085<\u000eO\b\f\u00ad\u001cu\u001b\u0097\bv ])®\u0097oÐ\bÖué*Ñ\u0016\rêÜ\u0096\u0019\u009eã\u0097\u0002ü©\u0094?~Ø\\@\u0018Ä G¦jë+\u0087ªÂ·õ\u008d\u0004.x\u009d6\b-\u0001éÂÐâçâh\u008fn.e3m(ÕJ\u0006\u001d[£û\u001ff<7à+\u001cJp!Åu<g÷£q\"\u009c\u0018\u0081]\u0001\u0019\u0007¯\u0091ÎÝ¦Ñ\f&05ÝÅ\u008f+\u0001ÐÇxñ\u0092\u009cRM\u0098u}\u0005pJVÎ\u0016\u009fñ½Wá¦xMTþj\u0015vú£ÖÏ+@wX æuf(\u008d\u0018;T£@\u0085êî'Ðl¸|iÇ^¹\u0002\u0081fÝU\u0014v~+êjTc\u0093\u0019\u009a ¬\u0088\"°m(\\Oê5áeFÁ4Þç\"êÆPP\u0010»í\u0085é\u00ad\t\u001e7'ô\tës¹÷A¸ËÝ])7¶ \u0017k\u0003\u0014}ÃAÇA\u0013¡âSß.ü1É\u000e\u000fh\u0084¯÷cA\u0004)É+¥X(\u001e\u0098\u001d\u008dj¹r\\Â_\u0086î¦¢Äó\u0099I¨÷K}§\u001a>\u009d[\u00ad0Q¼\u008a\u001däÌáÉpà:\u0018\n½S\u0010\u0004\u008eâ©#Õ\n7¤\f6\u0016Ü¨¦R\u009f\u001a4\u008e\u0010g\u0007û+³ç\u009fN\u009fËz\u001d1Üï¡\u0018Ã(×\u009dqh]×°,j\u001f\u0000\u008bEº®k£>é\u0088\"®\u0018|\u0007\u0099\u0016\u001b\u008d\u008fiÉ©7c\u008cì¨t§¸LF\u001e¥×h\u0018\u0016\u009b\u001e \u0011\u000eK,`ØzÚZ×Ûu\u009fÐ|zà\u0015A* \u000fSVCÕWDj:ýIÂomÙùJ\u009d.-HH,\u008eO/ Iïò\u000fF j®/Ì¥Âµ\u0088ÏÚ\u0087`\u0089\u0012òÝ\u0014Ñ«#\t°\u0012h?RÞw\u0086\u001c\u0081f \u0089W\u0010\u0016ªÃ\u0098\u0002\u0092c\u0094äç=ªPPN0pþ\u0089dB\u008e\b>qF}2¤ b/\u0000ö\u0088'*\u0014\u0085Oz\u0003\u0090\u0097\u0098\"d\u0016µ¡¸:ÜÐ\"\u0003\u0099\u0006-\u008ak\u0014 Q=\u001e\u001e\u0090\f\u0006ô»ÖÓ%ysßQ\u001eêýÅ\u0085eó[EòØC©4\u0004Ê";
      short var6 = 2032;
      char var3 = ' ';
      int var14 = -1;

      label27:
      while (true) {
         String var16 = var4.substring(++var14, var14 + var3);
         byte var10001 = -1;

         while (true) {
            String var22 = c(var0.doFinal(var16.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var22;
                  if ((var14 += var3) >= var6) {
                     c = var7;
                     h = new String[67];
                     何何树树何友何树何友 = new 树友树友友何何树何何(var11);
                     return;
                  }

                  var3 = var4.charAt(var14);
                  break;
               default:
                  var7[var5++] = var22;
                  if ((var14 += var3) < var6) {
                     var3 = var4.charAt(var14);
                     continue label27;
                  }

                  var4 = ";A©$Ô\u0003l.#h\u0018iG\u009fY\u0099þV\u001büð9a\b]ÓµA½\u00ad\\\u0095ç\u0094@G\u009bÄ´¹¤\u0090»\u008ayf\u001c<\u0018\u0001Ü\u008fâD}½Öâ+r\r3ý·\u0001\u00adW¢>ñÑ\u0015¬";
                  var6 = 73;
                  var3 = '0';
                  var14 = -1;
            }

            var16 = var4.substring(++var14, var14 + var3);
            var10001 = 0;
         }
      }
   }

   private void J(int slot) {
      long a = 树友友友何何友树树友.a ^ 109310595597462L;
      long ax = a ^ 92334707620891L;
      Module[] var6 = c<"b">(-3493587813277288431L, a);
      Minecraft var10000 = mc;
      if (var6 == null) {
         if (c<"h">(mc, -3493056398300129580L, a) == null) {
            return;
         }

         var10000 = mc;
      }

      if (var10000.player != null) {
         label18: {
            if (slot < 9) {
               c<"h">(mc, -3493056398300129580L, a)
                  .handleInventoryMouseClick(
                     c<"h">(c<"h">(mc.player, -3487869519375221237L, a), -3486879703271080028L, a),
                     slot + 36,
                     40,
                     c<"û">(-3485897891611981326L, a),
                     mc.player
                  );
               if (var6 == null) {
                  break label18;
               }
            }

            c<"h">(mc, -3493056398300129580L, a)
               .handleInventoryMouseClick(
                  c<"h">(c<"h">(mc.player, -3487869519375221237L, a), -3486879703271080028L, a), slot, 40, c<"û">(-3485897891611981326L, a), mc.player
               );
         }

         c<"p">(this, true, -3486660464777052787L, a);
         c<"û">(-3494064283927708381L, a).U(ax);
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 52;
               case 1 -> 48;
               case 2 -> 30;
               case 3 -> 35;
               case 4 -> 20;
               case 5 -> 27;
               case 6 -> 60;
               case 7 -> 39;
               case 8 -> 54;
               case 9 -> 32;
               case 10 -> 26;
               case 11 -> 61;
               case 12 -> 36;
               case 13 -> 18;
               case 14 -> 9;
               case 15 -> 45;
               case 16 -> 55;
               case 17 -> 33;
               case 18 -> 29;
               case 19 -> 25;
               case 20 -> 24;
               case 21 -> 8;
               case 22 -> 13;
               case 23 -> 58;
               case 24 -> 63;
               case 25 -> 22;
               case 26 -> 5;
               case 27 -> 17;
               case 28 -> 2;
               case 29 -> 4;
               case 30 -> 10;
               case 31 -> 42;
               case 32 -> 21;
               case 33 -> 56;
               case 34 -> 3;
               case 35 -> 11;
               case 36 -> 19;
               case 37 -> 16;
               case 38 -> 31;
               case 39 -> 44;
               case 40 -> 38;
               case 41 -> 62;
               case 42 -> 49;
               case 43 -> 7;
               case 44 -> 50;
               case 45 -> 41;
               case 46 -> 34;
               case 47 -> 46;
               case 48 -> 53;
               case 49 -> 28;
               case 50 -> 57;
               case 51 -> 59;
               case 52 -> 51;
               case 53 -> 0;
               case 54 -> 23;
               case 55 -> 15;
               case 56 -> 47;
               case 57 -> 40;
               case 58 -> 14;
               case 59 -> 1;
               case 60 -> 43;
               case 61 -> 6;
               case 62 -> 12;
               default -> 37;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               if (var10 < 0) {
                  var10 += 128;
               }

               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var15 = var7[var13 % var7.length];
               if (var15 == 0) {
                  break;
               }

               var12[var13] = (char)(var12[var13] ^ var15);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28622;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            var4 = (Object[])i.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               i.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树友友友何何友树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友友友何何友树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static int x() {
      return 256;
   }

   @EventTarget
   public void x(MotionEvent e) {
      long a;
      树友友友何何友树树友 var119;
      label935: {
         a = 树友友友何何友树树友.a ^ 68148512547022L;
         long ax = a ^ 53430826237535L;
         long axx = a ^ 14715727203316L;
         long axxx = a ^ 121819141761908L;
         long axxxx = a ^ 19442850057026L;
         long axxxxx = a ^ 67572015150881L;
         long axxxxxx = a ^ 55450453366597L;
         long axxxxxxx = a ^ 38152170798565L;
         long axxxxxxxx = a ^ 93808960610966L;
         long axxxxxxxxx = a ^ 65850911045422L;
         long var10001 = a ^ 15117893783177L;
         int axxxxxxxxxx = (int)((a ^ 15117893783177L) >>> 48);
         int axxxxxxxxxxx = (int)((a ^ 15117893783177L) << 16 >>> 32);
         int axxxxxxxxxxxx = (int)(var10001 << 48 >>> 48);
         long axxxxxxxxxxxxx = a ^ 25555774180937L;
         long axxxxxxxxxxxxxx = a ^ 14755589511235L;
         long axxxxxxxxxxxxxxx = a ^ 102289064723515L;
         long axxxxxxxxxxxxxxxx = a ^ 109287885316992L;
         long axxxxxxxxxxxxxxxxx = a ^ 46672100871411L;
         long axxxxxxxxxxxxxxxxxx = a ^ 8014896607775L;
         long axxxxxxxxxxxxxxxxxxx = a ^ 125076275448502L;
         long axxxxxxxxxxxxxxxxxxxx = a ^ 68781706668761L;
         long axxxxxxxxxxxxxxxxxxxxx = a ^ 10543483169375L;
         long axxxxxxxxxxxxxxxxxxxxxx = a ^ 89878262829544L;
         long axxxxxxxxxxxxxxxxxxxxxxx = a ^ 10691975833918L;
         long axxxxxxxxxxxxxxxxxxxxxxxx = a ^ 115574811230972L;
         long axxxxxxxxxxxxxxxxxxxxxxxxx = a ^ 102768498171004L;
         long axxxxxxxxxxxxxxxxxxxxxxxxxx = a ^ 16261154564909L;
         long axxxxxxxxxxxxxxxxxxxxxxxxxxx = a ^ 127353657772221L;
         long axxxxxxxxxxxxxxxxxxxxxxxxxxxx = a ^ 128279845983234L;
         long axxxxxxxxxxxxxxxxxxxxxxxxxxxxx = a ^ 44587824005827L;
         long axxxxxxxxxxxxxxxxxxxxxxxxxxxxxx = a ^ 36632112409407L;
         Module[] axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx = c<"b">(-6062945756537398199L, a);
         if (e.isPre()) {
            Minecraft var10000 = mc;
            if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
               if (mc.player == null) {
                  return;
               }

               var10000 = mc;
            }

            if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
               if (var10000.getConnection() == null) {
                  return;
               }

               var10000 = mc;
            }

            if (c<"h">(var10000, -6062279235308670324L, a) != null) {
               boolean var117 = this.j();
               if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                  if (!var117) {
                     何树树友树树友树友树.p(c<"û">(-6069230613429091459L, a), b<"i">(20728, 8876039380957861073L ^ a), b<"i">(721, 3895736234369337031L ^ a));
                     this.y(false);
                     return;
                  }

                  var117 = 友何树何友树友树何何.d(axxxxxxxxxxxxxxxxxxxxxxxx);
               }

               if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                  if (var117) {
                     return;
                  }

                  var117 = 树何何何树何友何树何.x(axxxxxxxxxxxxxxxxxxxxxxxxx);
               }

               label875: {
                  if (var117) {
                     c<"p">(this, 0, -6069088131546040332L, a);
                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        break label875;
                     }
                  }

                  c<"p">(this, c<"h">(this, -6069088131546040332L, a) + 1, -6069088131546040332L, a);
               }

               label887: {
                  int var118 = 树何友何友何何何友树.j();
                  if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                     if (var118 != 0) {
                        break label887;
                     }

                     var118 = c<"û">(-6063832463920909489L, a).isEnabled();
                  }

                  if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                     if (var118 != 0) {
                        break label887;
                     }

                     var118 = c<"h">(this, -6062093668265318767L, a).getValue();
                  }

                  label866: {
                     label865: {
                        if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                           if (var118 != 0) {
                              var120 = c<"h">(mc, -6070718218960803878L, a);
                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                 break label866;
                              }

                              if (!(var120 instanceof InventoryScreen)) {
                                 break label887;
                              }
                              break label865;
                           }

                           var119 = this;
                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                              break label935;
                           }

                           var118 = c<"h">(this, -6069088131546040332L, a);
                        }

                        if (var118 <= 1) {
                           break label887;
                        }
                     }

                     var120 = c<"h">(mc, -6070718218960803878L, a);
                  }

                  Screen currentBow = var120;
                  var121 = currentBow instanceof AbstractContainerScreen;
                  label847:
                  if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                     if (var121 != 0) {
                        AbstractContainerScreen<?> container = (AbstractContainerScreen<?>)currentBow;
                        var121 = c<"h">(container.getMenu(), -6070525026027633203L, a);
                        if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                           break label847;
                        }

                        if (var121 != c<"h">(c<"h">(mc.player, -6070632708795311533L, a), -6069651684469466116L, a)) {
                           return;
                        }
                     }

                     var121 = c<"h">(this, -6062093668265318767L, a).getValue();
                  }

                  label840:
                  if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                     if (var121 != 0) {
                        var121 = c<"h">(mc, -6070718218960803878L, a) instanceof InventoryScreen;
                        if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                           break label840;
                        }

                        if (var121 != 0) {
                           c<"p">(this, c<"h">(this, -6062746980593551131L, a) + 1, -6062746980593551131L, a);
                           var121 = c<"h">(this, -6062746980593551131L, a);
                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                              break label840;
                           }

                           if (var121 < c<"h">(this, -6070393711062101952L, a).getValue().intValue()) {
                              return;
                           }
                        }
                     }

                     var121 = c<"h">(this, -6061924655811136189L, a).getValue();
                  }

                  int i;
                  label943: {
                     label774:
                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           i = 0;

                           label824: {
                              while (i < c<"h">(mc.player.getInventory(), -6068748598713955057L, a).size()) {
                                 ItemStack stack = (ItemStack)c<"h">(mc.player.getInventory(), -6068748598713955057L, a).get(i);
                                 Item stackx = stack.getItem();
                                 label820:
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                    var122 = stackx instanceof ArmorItem;
                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                       break label824;
                                    }

                                    if (var122 != 0) {
                                       ArmorItem item = (ArmorItem)stackx;
                                       if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                          break label820;
                                       }

                                       label815:
                                       if (!stack.isEmpty()) {
                                          int var123 = c<"û">(-6063312284589844101L, a).Y(c<"h">(this, -6069144440460961146L, a).getValue().intValue(), axxxxx);
                                          if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                             if (var123 == 0) {
                                                break label815;
                                             }

                                             float var149;
                                             var123 = (var149 = 友何树何友树友树何何.r(item.getEquipmentSlot(), axxxxxxxxxxxxxxxxxxx) - 友何树何友树友树何何.C(stack)) == 0.0F
                                                ? 0
                                                : (var149 < 0.0F ? -1 : 1);
                                          }

                                          if (var123 > 0) {
                                             c<"h">(mc, -6062279235308670324L, a)
                                                .handleInventoryMouseClick(
                                                   c<"h">(c<"h">(mc.player, -6070632708795311533L, a), -6069651684469466116L, a),
                                                   4 + (4 - i),
                                                   1,
                                                   c<"û">(-6065310397003984039L, a),
                                                   mc.player
                                                );
                                             c<"p">(this, true, -6069521518784030251L, a);
                                             c<"û">(-6063312284589844101L, a).U(axxxxxxxxxxxxxx);
                                             return;
                                          }
                                       }
                                    }

                                    i++;
                                 }

                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                    break;
                                 }
                              }

                              var122 = 0;
                           }

                           i = var122;

                           while (i < c<"h">(mc.player.getInventory(), -6063965080963268634L, a).size()) {
                              ItemStack stackxx = (ItemStack)c<"h">(mc.player.getInventory(), -6063965080963268634L, a).get(i);
                              label798:
                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                 var121 = stackxx.isEmpty();
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                    break label774;
                                 }

                                 if (var121 == 0) {
                                    Item var106 = stackxx.getItem();
                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                       break label798;
                                    }

                                    if (var106 instanceof ArmorItem itemx) {
                                       float currentItemScore = 友何树何友树友树何何.C(stackxx);
                                       float var150;
                                       int var124 = (var150 = 友何树何友树友树何何.r(itemx.getEquipmentSlot(), axxxxxxxxxxxxxxxxxxx) - currentItemScore) == 0.0F
                                          ? 0
                                          : (var150 < 0.0F ? -1 : 1);
                                       if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                          var124 = !var124;
                                       }

                                       boolean isBestItem = (boolean)var124;
                                       float var151;
                                       int var125 = (var151 = 友何树何友树友树何何.X(itemx.getEquipmentSlot(), axxxxxxxxxxxxxxx) - currentItemScore) == 0.0F
                                          ? 0
                                          : (var151 < 0.0F ? -1 : 1);
                                       if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                          var125 = var125 < 0 ? 1 : 0;
                                       }

                                       boolean isBetterItem = (boolean)var125;
                                       if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                          break label798;
                                       }

                                       label789:
                                       if (isBestItem) {
                                          var126 = isBetterItem;
                                          if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                             if (isBetterItem == 0) {
                                                break label789;
                                             }

                                             var126 = c<"û">(-6063312284589844101L, a).Y(c<"h">(this, -6069144440460961146L, a).getValue().intValue(), axxxxx);
                                          }

                                          if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                             break label943;
                                          }

                                          if (var126 != 0) {
                                             var126 = i;
                                             break label943;
                                          }
                                       }
                                    }
                                 }

                                 i++;
                              }

                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                 break;
                              }
                           }
                        }

                        var121 = c<"h">(this, -6063196670864380965L, a);
                     }

                     label752:
                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           var121 = c<"û">(-6063312284589844101L, a).Y(c<"h">(this, -6069144440460961146L, a).getValue().intValue(), axxxxx);
                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                              break label752;
                           }

                           if (var121 != 0) {
                              c<"h">(mc, -6062279235308670324L, a)
                                 .handleInventoryMouseClick(
                                    c<"h">(c<"h">(mc.player, -6070632708795311533L, a), -6069651684469466116L, a),
                                    45,
                                    0,
                                    c<"û">(-6070707512929078735L, a),
                                    mc.player
                                 );
                              c<"p">(this, true, -6069521518784030251L, a);
                              c<"p">(this, false, -6063196670864380965L, a);
                              c<"û">(-6063312284589844101L, a).U(axxxxxxxxxxxxxx);
                           }
                        }

                        var121 = c<"h">(this, -6062783798358591812L, a).C(b<"i">(12087, 6290059715475041066L ^ a));
                     }

                     label745: {
                        label899: {
                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                              if (var121 != 0) {
                                 ItemStack offHand = (ItemStack)c<"h">(mc.player.getInventory(), -6069286200718695574L, a).get(0);
                                 int slot = 友何树何友树友树何何.c(axxxx, c<"û">(-6063630770530471846L, a));
                                 int var133 = slot;
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                    if (slot == -1) {
                                       break label899;
                                    }

                                    var133 = c<"û">(-6063312284589844101L, a).Y(c<"h">(this, -6069144440460961146L, a).getValue().intValue(), axxxxx);
                                 }

                                 if (var133 != 0) {
                                    label900: {
                                       var119 = offHand.getItem();
                                       if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                          if (var119 != c<"û">(-6063630770530471846L, a)) {
                                             break label900;
                                          }

                                          var119 = (树友友友何何友树树友)c<"h">(mc.player.getInventory(), -6063965080963268634L, a).get(slot);
                                       }

                                       label901: {
                                          ItemStack goldenAppleStack = (ItemStack)var119;
                                          int var135 = offHand.getCount() + goldenAppleStack.getCount();
                                          byte var146 = 64;
                                          if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                             if (var135 > 64) {
                                                break label901;
                                             }

                                             var135 = slot;
                                             var146 = 9;
                                          }

                                          label724: {
                                             if (var135 < var146) {
                                                c<"h">(mc, -6062279235308670324L, a)
                                                   .handleInventoryMouseClick(
                                                      c<"h">(c<"h">(mc.player, -6070632708795311533L, a), -6069651684469466116L, a),
                                                      slot + 36,
                                                      0,
                                                      c<"û">(-6070707512929078735L, a),
                                                      mc.player
                                                   );
                                                if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                                   break label724;
                                                }
                                             }

                                             c<"h">(mc, -6062279235308670324L, a)
                                                .handleInventoryMouseClick(
                                                   c<"h">(c<"h">(mc.player, -6070632708795311533L, a), -6069651684469466116L, a),
                                                   slot,
                                                   0,
                                                   c<"û">(-6070707512929078735L, a),
                                                   mc.player
                                                );
                                          }

                                          c<"p">(this, true, -6069521518784030251L, a);
                                          c<"p">(this, true, -6063196670864380965L, a);
                                          c<"û">(-6063312284589844101L, a).U(axxxxxxxxxxxxxx);
                                       }

                                       if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                          break label899;
                                       }
                                    }

                                    this.J(slot);
                                 }
                                 break label899;
                              }

                              var121 = c<"h">(this, -6062783798358591812L, a).C(b<"i">(31649, 7284570048151142289L ^ a));
                           }

                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                              if (var121 != 0) {
                                 label903: {
                                    ItemStack offHandx = (ItemStack)c<"h">(mc.player.getInventory(), -6069286200718695574L, a).get(0);
                                    ItemStack bestProjectile = 友何树何友树友树何何.x(ax);
                                    ItemStack var127 = bestProjectile;
                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                       if (bestProjectile == null) {
                                          break label903;
                                       }

                                       var127 = bestProjectile;
                                    }

                                    int slotx;
                                    label703: {
                                       boolean shouldSwap;
                                       label702: {
                                          label904: {
                                             slotx = 友何树何友树友树何何.N(var127, axxxxxxxxxxxxxxxxxxxxxxxxxx);
                                             shouldSwap = false;
                                             var128 = offHandx;
                                             label700:
                                             if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                                if (offHandx.getItem() != c<"û">(-6069401566293390772L, a)) {
                                                   var128 = offHandx;
                                                   if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                                      break label700;
                                                   }

                                                   if (offHandx.getItem() != c<"û">(-6063709956017128480L, a)) {
                                                      break label904;
                                                   }
                                                }

                                                var128 = offHandx;
                                             }

                                             var129 = var128.getCount();
                                             if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                                break label703;
                                             }

                                             if (var129 >= bestProjectile.getCount()) {
                                                break label702;
                                             }

                                             shouldSwap = (boolean)1;
                                             if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                                break label702;
                                             }
                                          }

                                          shouldSwap = (boolean)1;
                                       }

                                       var129 = shouldSwap;
                                    }

                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                       if (var129 == 0) {
                                          break label903;
                                       }

                                       var129 = slotx;
                                    }

                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                       if (var129 == -1) {
                                          break label903;
                                       }

                                       var129 = c<"û">(-6063312284589844101L, a).Y(c<"h">(this, -6069144440460961146L, a).getValue().intValue(), axxxxx);
                                    }

                                    if (var129 != 0) {
                                       this.J(slotx);
                                    }
                                 }

                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                    break label899;
                                 }
                              }

                              var121 = c<"h">(this, -6062783798358591812L, a).C(b<"i">(30775, 390515771719728138L ^ a));
                           }

                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                              if (var121 != 0) {
                                 ItemStack offHandxx = (ItemStack)c<"h">(mc.player.getInventory(), -6069286200718695574L, a).get(0);
                                 int slotxx = 友何树何友树友树何何.c(axxxx, c<"û">(-6070299914236749090L, a));
                                 int var132 = slotxx;
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                    if (slotxx == -1) {
                                       break label899;
                                    }

                                    var132 = c<"û">(-6063312284589844101L, a).Y(c<"h">(this, -6069144440460961146L, a).getValue().intValue(), axxxxx);
                                 }

                                 if (var132 != 0 && offHandxx.getItem() != c<"û">(-6070299914236749090L, a)) {
                                    this.J(slotxx);
                                 }
                                 break label899;
                              }

                              var121 = c<"h">(this, -6062783798358591812L, a).C(b<"i">(878, 8681858352830891871L ^ a));
                           }

                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                              break label745;
                           }

                           label660:
                           if (var121 != 0) {
                              ItemStack offHandxxx = (ItemStack)c<"h">(mc.player.getInventory(), -6069286200718695574L, a).get(0);
                              ItemStack bestBlock = 友何树何友树友树何何.j(axxxxxxxxxxxxxxxxxxxx);
                              ItemStack var130 = bestBlock;
                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                 if (bestBlock == null) {
                                    break label660;
                                 }

                                 var130 = bestBlock;
                              }

                              int slotxxx;
                              label653: {
                                 boolean shouldSwap;
                                 label652: {
                                    slotxxx = 友何树何友树友树何何.N(var130, axxxxxxxxxxxxxxxxxxxxxxxxxx);
                                    shouldSwap = false;
                                    byte var131 = 友树友友何友树友树友.h(axxxxxx, offHandxxx);
                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                       if (var131 != 0) {
                                          var121 = offHandxxx.getCount();
                                          if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                             break label653;
                                          }

                                          if (var121 >= bestBlock.getCount()) {
                                             break label652;
                                          }

                                          shouldSwap = (boolean)1;
                                          if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                             break label652;
                                          }
                                       }

                                       var131 = 1;
                                    }

                                    shouldSwap = (boolean)var131;
                                 }

                                 var121 = shouldSwap;
                              }

                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                 break label745;
                              }

                              if (var121 != 0) {
                                 var121 = slotxxx;
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                    break label745;
                                 }

                                 if (slotxxx != -1) {
                                    var121 = c<"û">(-6063312284589844101L, a).Y(c<"h">(this, -6069144440460961146L, a).getValue().intValue(), axxxxx);
                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                       break label745;
                                    }

                                    if (var121 != 0) {
                                       this.J(slotxxx);
                                    }
                                 }
                              }
                           }
                        }

                        var121 = c<"h">(this, -6062783798358591812L, a).C(b<"i">(28473, 8342216101307198234L ^ a));
                     }

                     label629:
                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 == 0) {
                           var121 = c<"h">(this, -6063007430029067667L, a).getValue().intValue();
                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                              break label629;
                           }

                           if (var121 != 0) {
                              this.d(c<"h">(this, -6063007430029067667L, a).getValue().intValue() - 1, c<"û">(-6063630770530471846L, a));
                           }
                        }

                        var121 = c<"h">(this, -6063511986482719204L, a).getValue().intValue();
                     }

                     label610:
                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           var121 = c<"h">(this, -6063511986482719204L, a).getValue().intValue() - 1;
                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                              break label610;
                           }

                           i = var121;
                           ItemStack currentBlock = (ItemStack)c<"h">(mc.player.getInventory(), -6063965080963268634L, a).get(i);
                           ItemStack bestBlockx = 友何树何友树友树何何.j(axxxxxxxxxxxxxxxxxxxx);
                           label618:
                           if (bestBlockx != null) {
                              var121 = bestBlockx.getCount();
                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                 if (var121 <= currentBlock.getCount()) {
                                    var121 = 友树友友何友树友树友.h(axxxxxx, currentBlock);
                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                       break label610;
                                    }

                                    if (var121 != 0) {
                                       break label618;
                                    }
                                 }

                                 var121 = c<"h">(this, -6062783798358591812L, a).C(b<"i">(13953, 1571126425916633783L ^ a));
                              }

                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                 break label610;
                              }

                              if (var121 == 0) {
                                 this.o(i, bestBlockx);
                              }
                           }
                        }

                        var121 = 友何树何友树友树何何.l(axxxxxxxx);
                     }

                     int var147 = c<"h">(this, -6063432954139384960L, a).getValue().intValue();
                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 > var147) {
                           ItemStack worstBlock = 友何树何友树友树何何.U(axxxxxxxxxxxxxxxxxxxxxx);
                           this.W(worstBlock);
                        }

                        var121 = 友何树何友树友树何何.z(axxxxxxxxxxxxxxxxxxxxx);
                        var147 = c<"h">(this, -6065428310347840653L, a).getValue().intValue();
                     }

                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 > var147) {
                           ItemStack worstFood = 友何树何友树友树何何.K(axxx);
                           this.W(worstFood);
                        }

                        var121 = 友何树何友树友树何何.t(axxxxxxxxxxxxxxxxxxxxxxxxxxxxx);
                        var147 = c<"h">(this, -6069694424270768004L, a).getValue().intValue();
                     }

                     label910: {
                        if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                           if (var121 > var147) {
                              ItemStack worstFood = 友何树何友树友树何何.T(axxxxxxxxxxxxxxxxxx);
                              this.W(worstFood);
                           }

                           var121 = 友何树何友树友树何何.T(c<"û">(-6069401566293390772L, a), axxxxxxxxx) + 友何树何友树友树何何.T(c<"û">(-6063709956017128480L, a), axxxxxxxxx);
                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                              break label910;
                           }

                           var147 = c<"h">(this, -6062039042997012520L, a).getValue().intValue();
                        }

                        if (var121 > var147) {
                           ItemStack worstProjectile = 友何树何友树友树何何.e(axxxxxxxxxxxxxxxxxxxxxxxxxxx);
                           this.W(worstProjectile);
                        }

                        var121 = c<"h">(this, -6063077687010578592L, a).getValue().intValue();
                     }

                     label572:
                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        label591: {
                           if (var121 != 0) {
                              ItemStack bestSword = 友何树何友树友树何何.S(axxxxxxxxxxxxxxxxxxxxxxxxxxxx);
                              int slotxxxx = c<"h">(this, -6063077687010578592L, a).getValue().intValue() - 1;
                              ItemStack currentSword = (ItemStack)c<"h">(mc.player.getInventory(), -6063965080963268634L, a).get(slotxxxx);
                              ItemStack bestShapeAxe = 友何树何友树友树何何.w(axxxxxxx);
                              var119 = bestShapeAxe;
                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                 if (友何树何友树友树何何.t((char)axxxxxxxxxx, axxxxxxxxxxx, (short)axxxxxxxxxxxx, bestShapeAxe) > 友何树何友树友树何何.A(bestSword)) {
                                    bestSword = bestShapeAxe;
                                 }

                                 var119 = bestSword;
                              }

                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                 break label591;
                              }

                              if (var119 != null) {
                                 label586: {
                                    ItemStack var137 = currentSword;
                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                       if (currentSword.getItem() instanceof SwordItem) {
                                          var138 = 友何树何友树友树何何.A(currentSword);
                                          break label586;
                                       }

                                       var137 = currentSword;
                                    }

                                    ItemStack axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx = var137;
                                    var138 = 友何树何友树友树何何.t((char)axxxxxxxxxx, axxxxxxxxxxx, (short)axxxxxxxxxxxx, axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx);
                                 }

                                 float currentDamage;
                                 label580: {
                                    currentDamage = var138;
                                    ItemStack var139 = bestSword;
                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                       if (bestSword.getItem() instanceof SwordItem) {
                                          var140 = 友何树何友树友树何何.A(bestSword);
                                          break label580;
                                       }

                                       var139 = bestSword;
                                    }

                                    ItemStack var69 = var139;
                                    var140 = 友何树何友树友树何何.t((char)axxxxxxxxxx, axxxxxxxxxxx, (short)axxxxxxxxxxxx, var69);
                                 }

                                 float bestWeaponDamage = var140;
                                 float var152;
                                 var121 = (var152 = bestWeaponDamage - currentDamage) == 0.0F ? 0 : (var152 < 0.0F ? -1 : 1);
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                    break label572;
                                 }

                                 if (var121 > 0) {
                                    this.o(slotxxxx, bestSword);
                                 }
                              }
                           }

                           var119 = c<"h">(this, -6064042364681439500L, a).getValue();
                        }

                        var121 = ((Number)var119).intValue();
                     }

                     label548:
                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        label565: {
                           if (var121 != 0) {
                              i = c<"h">(this, -6064042364681439500L, a).getValue().intValue() - 1;
                              ItemStack bestPickaxe = 友何树何友树友树何何.D(axxxxxxxxxxxxxxxx);
                              ItemStack currentPickaxe = (ItemStack)c<"h">(mc.player.getInventory(), -6063965080963268634L, a).get(i);
                              var119 = bestPickaxe;
                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                 break label565;
                              }

                              if (bestPickaxe != null) {
                                 var121 = bestPickaxe.getItem() instanceof PickaxeItem;
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                    break label548;
                                 }

                                 label560:
                                 if (var121 != 0) {
                                    label916: {
                                       float var153;
                                       var121 = (var153 = 友何树何友树友树何何.K(bestPickaxe) - 友何树何友树友树何何.K(currentPickaxe)) == 0.0F ? 0 : (var153 < 0.0F ? -1 : 1);
                                       if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                          if (var121 > 0) {
                                             break label916;
                                          }

                                          var121 = currentPickaxe.getItem() instanceof PickaxeItem;
                                       }

                                       if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                          break label548;
                                       }

                                       if (var121 != 0) {
                                          break label560;
                                       }
                                    }

                                    this.o(i, bestPickaxe);
                                 }
                              }
                           }

                           var119 = c<"h">(this, -6063114091460091760L, a).getValue();
                        }

                        var121 = ((Number)var119).intValue();
                     }

                     label520:
                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           ItemStack bestBow;
                           float bestBowScore;
                           float currentBowScore;
                           label919: {
                              i = c<"h">(this, -6063114091460091760L, a).getValue().intValue() - 1;
                              currentBow = (ItemStack)c<"h">(mc.player.getInventory(), -6063965080963268634L, a).get(i);
                              boolean var142 = c<"h">(this, -6062532403629320932L, a).C(b<"i">(23698, 2667286470074243228L ^ a));
                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                 if (var142) {
                                    bestBow = 友何树何友树友树何何.I(axxxxxxxxxxxxxxxxx);
                                    bestBowScore = 友何树何友树友树何何.u(bestBow);
                                    currentBowScore = 友何树何友树友树何何.u(currentBow);
                                    if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                       break label919;
                                    }
                                 }

                                 var142 = c<"h">(this, -6062532403629320932L, a).C(b<"i">(17604, 468987729617551587L ^ a));
                              }

                              if (var142) {
                                 bestBow = 友何树何友树友树何何.b(axxxxxxxxxxxxx);
                                 bestBowScore = 友何树何友树友树何何.Y(bestBow);
                                 currentBowScore = 友何树何友树友树何何.Y(currentBow);
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                    break label919;
                                 }
                              }

                              bestBow = 友何树何友树友树何何.z(axxxxxxxxxxxxxxxxxxxxxxxxxxxxxx);
                              bestBowScore = 友何树何友树友树何何.E(bestBow);
                              currentBowScore = 友何树何友树友树何何.E(currentBow);
                           }

                           ItemStack var143 = bestBow;
                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                              if (bestBow == null) {
                                 bestBow = 友何树何友树友树何何.I(axxxxxxxxxxxxxxxxx);
                                 bestBowScore = 友何树何友树友树何何.u(bestBow);
                                 currentBowScore = 友何树何友树友树何何.u(currentBow);
                              }

                              var143 = bestBow;
                           }

                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                              if (var143 == null) {
                                 bestBow = 友何树何友树友树何何.b(axxxxxxxxxxxxx);
                                 bestBowScore = 友何树何友树友树何何.Y(bestBow);
                                 currentBowScore = 友何树何友树友树何何.Y(currentBow);
                              }

                              var143 = bestBow;
                           }

                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                              if (var143 == null) {
                                 bestBow = 友何树何友树友树何何.z(axxxxxxxxxxxxxxxxxxxxxxxxxxxxxx);
                                 bestBowScore = 友何树何友树友树何何.E(bestBow);
                                 currentBowScore = 友何树何友树友树何何.E(currentBow);
                              }

                              var143 = bestBow;
                           }

                           label525: {
                              if (var143 != null) {
                                 float var154;
                                 var121 = (var154 = bestBowScore - currentBowScore) == 0.0F ? 0 : (var154 < 0.0F ? -1 : 1);
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                    break label525;
                                 }

                                 if (var121 > 0) {
                                    this.o(i, bestBow);
                                 }
                              }

                              var121 = 友何树何友树友树何何.T(c<"û">(-6070442227160387807L, a), axxxxxxxxx);
                           }

                           if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                              break label520;
                           }

                           if (var121 > 256) {
                              ItemStack worstArrow = 友何树何友树友树何何.X(axxxxxxxxxxxxxxxxxxxxxxx);
                              this.W(worstArrow);
                           }
                        }

                        var121 = c<"h">(this, -6065252095618698598L, a).getValue().intValue();
                     }

                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           ItemStack bestAxe = 友何树何友树友树何何.n(axx);
                           this.o(c<"h">(this, -6065252095618698598L, a).getValue().intValue() - 1, bestAxe);
                        }

                        var121 = c<"h">(this, -6068965084859480750L, a).getValue().intValue();
                     }

                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           this.o(c<"h">(this, -6068965084859480750L, a).getValue().intValue() - 1, 友何树何友树友树何何.x(ax));
                        }

                        var121 = c<"h">(this, -6070848284265506765L, a).getValue().intValue();
                     }

                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           this.d(c<"h">(this, -6070848284265506765L, a).getValue().intValue() - 1, c<"û">(-6063376486515733442L, a));
                        }

                        var121 = c<"h">(this, -6063797758705071589L, a).getValue().intValue();
                     }

                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           this.d(c<"h">(this, -6063797758705071589L, a).getValue().intValue() - 1, c<"û">(-6061902417252774084L, a));
                        }

                        var121 = c<"h">(this, -6065514924593340115L, a).getValue().intValue();
                     }

                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           this.d(c<"h">(this, -6065514924593340115L, a).getValue().intValue() - 1, c<"û">(-6063953565220098794L, a));
                        }

                        var121 = c<"h">(this, -6068816752935953856L, a).getValue().intValue();
                     }

                     if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                        if (var121 != 0) {
                           this.d(c<"h">(this, -6068816752935953856L, a).getValue().intValue() - 1, c<"û">(-6063597466232699727L, a));
                        }

                        var121 = 0;
                     }

                     List<Integer> slots = IntStream.range(var121, c<"h">(mc.player.getInventory(), -6063965080963268634L, a).size())
                        .boxed()
                        .collect(Collectors.toList());
                     Collections.shuffle(slots);

                     for (Integer slotxxxxx : slots) {
                        label512: {
                           label921: {
                              ItemStack stackxxx = (ItemStack)c<"h">(mc.player.getInventory(), -6063965080963268634L, a).get(slotxxxxx);
                              boolean var144 = stackxxx.isEmpty();
                              if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                                 if (var144) {
                                    break label512;
                                 }

                                 var119 = this;
                                 var148 = stackxxx;
                                 if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                                    break label921;
                                 }

                                 var144 = this.K(stackxxx);
                              }

                              if (var144) {
                                 break label512;
                              }

                              var119 = this;
                              var148 = stackxxx;
                           }

                           var119.W(var148);
                        }

                        if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx != null) {
                           return;
                        }
                     }

                     return;
                  }

                  label496: {
                     if (var126 < 9) {
                        c<"h">(mc, -6062279235308670324L, a)
                           .handleInventoryMouseClick(
                              c<"h">(c<"h">(mc.player, -6070632708795311533L, a), -6069651684469466116L, a),
                              i + 36,
                              0,
                              c<"û">(-6062371259617182226L, a),
                              mc.player
                           );
                        if (axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx == null) {
                           break label496;
                        }
                     }

                     c<"h">(mc, -6062279235308670324L, a)
                        .handleInventoryMouseClick(
                           c<"h">(c<"h">(mc.player, -6070632708795311533L, a), -6069651684469466116L, a), i, 0, c<"û">(-6062371259617182226L, a), mc.player
                        );
                  }

                  c<"p">(this, true, -6069521518784030251L, a);
                  c<"û">(-6063312284589844101L, a).U(axxxxxxxxxxxxxx);
                  return;
               }

               c<"p">(this, false, -6063196670864380965L, a);
               var119 = this;
               break label935;
            }
         }

         return;
      }

      c<"p">(var119, 0, -6062746980593551131L, a);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         MethodHandle var9;
         if (var8 != 'h' && var8 != 'p' && var8 != 251 && var8 != 'a') {
            var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'Q') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'b') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'h') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'p') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName())
            .append(" : ")
            .append(var10 != null ? var10.toString() : (var11 != null ? var11.toString() : " null "))
            .append(" : ")
            .append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友友友何何友树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      Method var5 = e(var0, var1, var2, var3, var4);
      if (var5 != null) {
         return var5;
      } else {
         Class[] var6 = var0.getInterfaces();
         if (var6 != null) {
            for (int var7 = 0; var7 < var6.length; var7++) {
               var5 = f(var6[var7], var1, var2, var3, var4);
               if (var5 != null) {
                  return var5;
               }
            }
         }

         return null;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      Field var3 = e(var0, var1, var2);
      if (var3 != null) {
         return var3;
      } else {
         Class[] var4 = var0.getInterfaces();
         if (var4 != null) {
            for (int var5 = 0; var5 < var4.length; var5++) {
               var3 = f(var4[var5], var1, var2);
               if (var3 != null) {
                  return var3;
               }
            }
         }

         return null;
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Class var23 = var8;

         while (true) {
            Method var25 = e(var23, var10, var15, var13, var14);
            if (var25 != null) {
               j[var4] = var25;
               return var25;
            }

            if (var23.getName().equals("java.lang.Object")) {
               break;
            }

            if ((var23 = var23.getSuperclass()) == null) {
               j(1858348326363031L, 0L);
               break;
            }
         }

         var23 = var8;

         while (true) {
            Class[] var26;
            if ((var26 = var23.getInterfaces()) != null) {
               for (int var18 = 0; var18 < var26.length; var18++) {
                  Method var19 = f(var26[var18], var10, var15, var13, var14);
                  if (var19 != null) {
                     j[var4] = var19;
                     return var19;
                  }
               }
            }

            if (var23.getName().equals("java.lang.Object")) {
               StringBuffer var27 = new StringBuffer();
               var27.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
               int var28 = 0;

               while (var28 < var13) {
                  var27.append(var14[var28].getName());
                  if (++var28 < var13) {
                     var27.append(", ");
                  }
               }

               var27.append(')');
               throw new RuntimeException(var27.toString());
            }

            if ((var23 = var23.getSuperclass()) == null) {
               var23 = j(1858348326363031L, 0L);
            }
         }
      }
   }

   private void d(int targetSlot, Item item) {
      long a = 树友友友何何友树树友.a ^ 92043410057075L;
      long ax = a ^ 57230760453669L;
      long axx = a ^ 140614763580671L;
      long axxx = a ^ 91505835831452L;
      long axxxx = a ^ 109014935969790L;
      Module[] axxxxx = c<"b">(-1413716073797968908L, a);
      Minecraft var10000 = mc;
      if (axxxxx == null) {
         if (c<"h">(mc, -1413255715261221583L, a) == null) {
            return;
         }

         var10000 = mc;
      }

      ItemStack var17 = var10000.player;
      if (axxxxx == null) {
         if (var10000.player == null) {
            return;
         }

         var17 = (ItemStack)c<"h">(mc.player.getInventory(), -1412694670513997733L, a).get(targetSlot);
      }

      ItemStack currentSlot = var17;
      int var18 = 友何树何友树友树何何.l(ax, currentSlot);
      if (axxxxx == null) {
         if (var18 == 0) {
            return;
         }

         var18 = c<"û">(-1411975413816500538L, a).Y(c<"h">(this, -1406390799323964101L, a).getValue().intValue(), axxx);
      }

      if (axxxxx == null) {
         if (var18 == 0) {
            return;
         }

         var18 = 友何树何友树友树何何.c(axx, item);
      }

      int bestItemSlot = var18;
      if (bestItemSlot != -1) {
         int var22;
         label61: {
            label88: {
               ItemStack bestItemStack;
               label89: {
                  bestItemStack = (ItemStack)c<"h">(mc.player.getInventory(), -1412694670513997733L, a).get(bestItemSlot);
                  Item var19 = currentSlot.getItem();
                  Item var10001 = item;
                  if (axxxxx == null) {
                     if (var19 != item) {
                        break label88;
                     }

                     var17 = currentSlot;
                     if (axxxxx != null) {
                        break label89;
                     }

                     var19 = currentSlot.getItem();
                     var10001 = item;
                  }

                  if (var19 != var10001) {
                     return;
                  }

                  var17 = currentSlot;
               }

               var21 = var17.getCount();
               var22 = bestItemStack.getCount();
               if (axxxxx != null) {
                  break label61;
               }

               if (var21 >= var22) {
                  return;
               }
            }

            var21 = bestItemSlot;
            var22 = 9;
         }

         label43: {
            if (var21 < var22) {
               c<"h">(mc, -1413255715261221583L, a)
                  .handleInventoryMouseClick(
                     c<"h">(c<"h">(mc.player, -1405780615059464722L, a), -1407043114409141183L, a),
                     bestItemSlot + 36,
                     targetSlot,
                     c<"û">(-1406624421991060969L, a),
                     mc.player
                  );
               if (axxxxx == null) {
                  break label43;
               }
            }

            c<"h">(mc, -1413255715261221583L, a)
               .handleInventoryMouseClick(
                  c<"h">(c<"h">(mc.player, -1405780615059464722L, a), -1407043114409141183L, a),
                  bestItemSlot,
                  targetSlot,
                  c<"û">(-1406624421991060969L, a),
                  mc.player
               );
         }

         c<"p">(this, true, -1406860193640571288L, a);
         c<"û">(-1411975413816500538L, a).U(axxxx);
      }
   }

   private static void a() {
      j[0] = "O9\u0010\rRW@y]\u0006XJE$V@PWH\"R\u000b\u0013QA'R@MTM.[\u001c\u0013栩叧厜叵伻佨右栽框叵";
      j[1] = "Lp\u0012oL+G\u007f\u0003 02He\rc\u0007\u0002^r\u0001~\u0016.I\u007f";
      j[2] = "7t\\[o67tK\u0007c9-?K\u0019k:7e\u00068k1<rZ\u0014d+";
      j[3] = "\u0002=\"V\u001e\r\u0002=5\n\u0012\u0002\u0018v5\u0014\u001a\u0001\u0002,x\u0015\u0006\b\u00181&\u0014\u0012\u001d\t*x5\u0006\b\u00181\u0006\u0014\u0012\u001d\t*\u0011\u0019\u001e\u0001!72\u001d";
      j[4] = "rwz=:\u0016}7760\u000bxj<p \rxu'p桄厲栀叒原伋伀桨佄佌";
      j[5] = "\u0007.~>1y\bn35;d\r38s3y\u00005<8p\u007f\t0<s.z\u000595/p佃伱压伅厖桏叝厯伕伅";
      j[6] = "\u00117\u000bIM7%\u0014\u0004\t\u0000</\t\u0001T\u000bz'\u0014\fR\u000f1d6\u0007C\u00168/@";
      j[7] = "*v{'J\u000f*vl{F\u00000=xfU\n =fgQ\u0003*g`{^H\u0007\u007ffjL2=cj";
      j[8] = "\u0000\r\u001a\u001f\f\\\u0000\r\rC\u0000S\u001aF\u0019^\u0013Y\nF\u0007_\u0017P\u0000\u001c\u0001C\u0018\u001b'\u0006\u0018T\u000fA\u0001\u001a\u0017|\u0004[\u001b";
      j[9] = int.class;
      k[9] = "java/lang/Integer";
      j[10] = boolean.class;
      k[10] = "java/lang/Boolean";
      j[11] = "mh\u0000a(\u0001mh\u0017=$\u000ew#\u0017#,\rmyZ?)\tzh\u0006a\t\u0007`l\u0018\u001f)\tzh\u0006";
      j[12] = "@T\u001ch\f+@T\u000b4\u0000$Z\u001f\u001f)\u0013.J\u001f\r(\u0015+ZHF6\r#WT\u001ah(,XT\u00062\u000e0W";
      j[13] = "^Im|[\b^Iz W\u0007D\u0002z=D\u0004\u001ebv<x\u0014\\@U;E\u0015";
      j[14] = "O=\u0011|Z\r@}\\wP\u0010E W1C\u0003@&Z1\\\u000f\\?\u0011Q@\u000fN6MIT\u000eY6";
      j[15] = "/U\b\u0002\u00179/U\u001f^\u001b65\u001e\u000bC\b<%\u001e\u0015X\u001f=oy\bI\u0017#";
      j[16] = "\b#Hx4.\b#_$8!\u0012hK9++\u0002hU\"<*H\u000fH34";
      j[17] = "JL7\u0007m\u001eE\fz\fg\u0003@QqJt\u0010EW|Jk\u001cYN7&m\u001eEGx\nT\u0010EW|";
      j[18] = ">\u0003tt\u0003D1C9\u007f\tY4\u001e29\u001aJ1\u0018?9\u0005F-\u0001tZ\u0003O8;;{\u0019N";
      j[19] = "\u0006;?fLO\t{rmFR\f&y+VIK桄栀収佶併估厞叚栔佶";
      j[20] = "\tV*!V*\tV=}Z%\u0013\u001d=cR&\tGphN*I@=}^&\t@p\\X1\u0002V0";
      j[21] = "t\u001d\u0015z\u001bTt\u001d\u0002&\u0017[nV\u0016;\u0004Q~V\b:\u0000Xt\f\u000e&\u000f\u0013[\u001a\u0012 \u0004\\y\f\";\u0018I{\u0011\u000f1\u0004p\u007f\u0016\u0014";
      j[22] = "\u001aY:rT%\u0015\u0019wy^8\u0010D|?V%\u001dBxt\u0015\u0007\u0016Sa}^";
      j[23] = void.class;
      k[23] = "java/lang/Void";
      j[24] = "e|nDK\u000fj<#OA\u0012oa(\tI\u000fbg,B\n伵体叙伕佲可伵体栃桑";
      j[25] = "Zk=T\u001d\u0011U+p_\u0017\fPv{\u0019\u0017\b\\kg\u0019\u0017\b\\kgD\\;O`}CV-Pav";
      j[26] = "L\u0006)2\u000e\u0014G\t8}o\u001aL\u0002<'";
      j[27] = "^\rR\u0017X'\u000e\t\u0017,伸桀叱伷厩栵桼桀佯伷jE\f8MQ\u0011\u0014Z!T";
      j[28] = "\u0007[pW'fW_5ls\u0018\u001aLv\u0000hs\r\r7lkhUP:\u0007|)\u0014<";
      j[29] = "f\n\u0014?|i6\u000eQ\u0004伜栎栓厮可栝厂叔叉厮,m(vuVW<~ol";
      j[30] = "IB\u0007\u001e!\u0017\nX\u000b_C34zq?CR\u0016\u0011H\u0002;\u0011\f\u001d\t";
      j[31] = "\u0019u\u0019\u000b\u0019>Iq\\0佹桙伨住叢右栽桙厶发!YM!\n)Z\b\u001b8\u0013";
      j[32] = "uB\u000eV\b\u000f7Q\u0017M7\u001aN\u001f\bUG\u00177D\u000b[He";
      j[33] = "-S>\u000eo?}\ft\\_=\u0010Wt\u0003fj\u0010k$\u0003/+\"\r Y&-";
      j[34] = "Z\u001d =-0\n\u0019e\u0006位伓叵档栁栟位伓佫伧\u0018j,%F\u0005#m}.\u0007";
      j[35] = ",=Zl:l|9\u001fW栞栋伝桃桻桎佚栋桙厙bi~xq6\u000b.nc0";
      j[36] = "\u0003Ax\u001ap*\u0015\u0002:\u001dH伍厯司叇厤压伍伱栢叇g'*\u0010F<\u001d1iRA";
      j[37] = "L\u0011^sT\"\u001c\u0015\u001bH伴企佽伫桿桑桰企佽厵f!\u0000=_M\u001dpV$F";
      j[38] = ",-+\rdj|)n6桀佉厃众叐叵桀佉厃厉\u0013Ze\u007f05(]4tq";
      j[39] = "30#8a\u000ec4f\u0003原桩厜桎但叀企厳厜厔\u001bi O 3jdm\u0015g";
      j[40] = "WDn\u0017bf\u0014^bV\u0000G7g\u0014*W[-x\u0012i=|[X=\u0011~fW\u0019";
      j[41] = "G<\u0001~or\u001b=\u0006j\u0014$)c^<+p)R]net\u0006+\u0017ch%";
      j[42] = "L}%\u0016\u00022\u001cy`-栦厏佽佇栄栴栦休根佇\u001dGCs_~lJ\u000e)\u0018";
      j[43] = "2VI`Ukb\t\u00032ei\u000fR\u0003mY7\u000fnSm\u0015\u007f=\bW7\u001cy";
      j[44] = "\u0016SXbBTFW\u001dY厼栳伧号伽厚厼佷伧栭`3\u0003\u0015\u0005P\u0011>NOB";
      j[45] = "E\u0013~SK$\u0015\u0017;h桯厙栰桭厅桱伫桃佴桭F\u0001\u001f;VO=PI\"O";
      j[46] = "zj?XJ/*nzc伪伌叕収栞厠厴厒栏収\u0007\t\u000bniiv\u0004F4.";
      j[47] = "^e!*\n5\u000e:kx:7cak'\u0006fc];'J!Q;?}C'";
      j[48] = "\u0001\n_S1\u001cQ\u000e\u001ah叏厡估厮厤伵栕桻估厮g\u0001e\u0003\u0012V\u001cP3\u001a\u000b";
      j[49] = "\u0006@\u001dX\u007fiPA\u0015O\u001aza\u0016\u0019\u0003%(a-\u0015\u000epjL\u0010X\r *";
      j[50] = "2\f\u0015$BKbS_vrI\u000f\b_(K\u0017\u000f4\u000f)\u0002_=R\u000bs\u000bY";
      j[51] = ":4rZ5\u000ex'kA\n桽参厖叚栢栓伹栘厖佄;1\u0005j4&Qs\u0016s/";
      j[52] = "\u0012<<]:mB8yf栞低桧桂叇厥佚低厽伆\u0004\u000fnr\u0001`\u007f^8k\u0018";
      j[53] = "^\u0001\u001fK?\u007f\u000e^U\u0019\u000f}c\u0005UF2)c9\u0005F\u007fkQ_\u0001\u001cvm";
      j[54] = "On\u000ep6\u0001\u001f1D\"\u0006\u0003rjD}=SrV\u0014}v\u0015@0\u0010'\u007f\u0013";
      j[55] = "\r\u000bM f\u0001]T\u0007rV\u00030\u000f\u0007.l\\03W-&\u0015\u0002USw/\u0013";
      j[56] = "G\u0007bnrb\u0017\u0003'U桖栅佶伽伇伈厌栅叨伽Z<&}T[!mpdM";
      j[57] = "Rj\u000fGFA\u0002nJ|厸叼叽佐佪伡厸佢叽栔7\u0015\u0012^A6LDDGX";
      j[58] = "@\u00186s\u001bZ\u0010G|!+X}\u001c|\u007f\u001b\n} ,~[NOF($RH";
      j[59] = "`{\u001b~{n0\u007f^E伛位栕栅佾历伛栉佑叟#~(`1yH.~~e";
      j[60] = "^#4\u001b\u007f/\u000e'q 伟伌栫桝叏根厁伌叱桝\f\u001fz4\u000bztXr2R";
      j[61] = "fNyB0E6J<y栔佦栓只桘伤栔司佗只A\u0010dZu\u0012:A2Cl";
      j[62] = "\u000f\u0007ZdK__\u0003\u001f_伫叢桺厣厡厜伫核桺厣b6\u001f@\u001c[\u0019gIY\u0005";
      j[63] = "\\wU@]\b\fs\u0010{厣厵栩叓桴伦桹桯佭位m\u0012\t\u0017O+\u0016C_\u000eV";
      j[64] = "\u0003F\u0012-1sSBW\u0016栕栔厬佼佷佋叏佐桶叢*\u007fel\u0010\u001aQ.3u\t";
      j[65] = "\b-c\u001d1{Uin\u001d@va)bL| a\u0012l\u0005*)Z{+\u00151h";
      j[66] = "UUu+\u0006&\u0005Q0\u0010佦厛佤佯厎位栢伅佤佯M/\u0003=\u0000\f5h\u000b;Y";
      j[67] = "[\u0014\u0010\u000f\u00040DL\u0016\u0017b\n|+7u\u00026@\n\r\u0017\u001dnF\u0012";
      j[68] = "Q\u007f1m\tb\u0001 {?9`l{{a\u00037lG+`Iv^!/:@p";
      j[69] = "#\u007f\\@j\u0001s{\u0019{桎伢伒叛伹厸伊伢厌栁d\u00170Gt%\u001aG4\u0002";
      j[70] = "6OW\f\u0011\\`N_\u001btOQ\u0019SWK\u001fQ\"_Z\u001e_|\u001f\u0012YN\u001f";
      j[71] = "&\u0000i[l\u001e5\u000b?E\u0016桧众伶栟栢栏桧厉伶叅;z\u0015%\u000b|[i\u001es\u0015";
      j[72] = ")\u0006\u0006'\u001bhy\u0002C\u001c句叕桜桸栧叟栿栏优似>uOw:ZE$\u0019n#";
      j[73] = "{\u00029w\u0005n+\u0006|L佥栉栎桼参厏校位佊厦\u0001rAz&\th5Qag";
      j[74] = "\u0003(3P*>S,vk叔伝桶伒又伶叔伝伲伒\u000b\u0002~!\u0010tpS(8\t";
      j[75] = "uVh,\u001a]~\u0005$8wt\u001bY 3N\u0003c\u001e(5\u0017=tY$1\t[#\u000ft<w";
      j[76] = "L\u0010\\'|\f\u001c\u0014\u0019\u001c伜桫根厴伹叟桘桫根厴du(\u0013_L\u001f$~\nF";
      j[77] = "D+*\u0004%#\u0012*\"\u0013@0#}._\u007fc#F\"R* \u000e{oQz`";
      j[78] = "})syI\u0004vz?m$\t\u0013&;f\u001dZka3`Dd";
      j[79] = "\u0005\u001fr@f\u000eF\u0005~\u0001\u0004-g4\u001b>9\u0014\t\u0003!Fz\u000e\u0005B";
      j[80] = ",6H+f%|2\r\u0010桂桂伝厒桩栉厘桂桙伌py2:?j\u000b(d#&";
      j[81] = " mgt`9|l``\u001boN286+9N\u0003l1cape\u007fd }";
      j[82] = "\u007f6$aJ\"<,( (\u0002\u0003\u001fVBpZ\u007f6$aJ\"<,( ";
      j[83] = "i\u000b\u001f\u000bWm'\u0014J\u0013ka\u0001I\u0011SZ2\u0001r\u0011TZn'\u0011L\u0010Wn";
      j[84] = "v/1\u0017g!vgfP[vLmgYg LVi\u00101)w?.\u0000*h";
      j[85] = "B\u001f\"6K;\u0012@hd{9\u007f\u001bh;Bm\u007f'8;\u000b/MA<a\u0002)";
      j[86] = "<G=\bp\u0014lCx3厎厩伍佽佘佮厎伷厓佽\u0005Z$\u000b/\u001b~\u000br\u00126";
      j[87] = "^>Z)\u0002\u0006\u000ea\u0010{2\u0004c:\u0010%\bQc\u0006@$B\u0012Q`D~K\u0014";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private void o(int targetSlot, ItemStack bestItem) {
      long a = 树友友友何何友树树友.a ^ 1630329864788L;
      long ax = a ^ 112974867759874L;
      long axx = a ^ 55295565695415L;
      long axxx = a ^ 2148778628539L;
      long axxxx = a ^ 54885746850521L;
      Module[] axxxxx = c<"b">(-3943417739401871661L, a);
      Minecraft var10000 = mc;
      if (axxxxx == null) {
         if (c<"h">(mc, -3943946391072976874L, a) == null) {
            return;
         }

         var10000 = mc;
      }

      Object var16 = var10000.player;
      if (axxxxx == null) {
         if (var10000.player == null) {
            return;
         }

         var16 = c<"h">(mc.player.getInventory(), -3944507432866816644L, a).get(targetSlot);
      }

      ItemStack currentSlot = (ItemStack)var16;
      var16 = currentSlot;
      if (axxxxx == null) {
         if (!友何树何友树友树何何.l(ax, currentSlot)) {
            return;
         }

         var16 = bestItem;
      }

      if (var16 != currentSlot) {
         int var18 = c<"û">(-3944883779375924255L, a).Y(c<"h">(this, -3937221629040134116L, a).getValue().intValue(), axxx);
         if (axxxxx == null) {
            if (var18 == 0) {
               return;
            }

            var18 = 友何树何友树友树何何.N(bestItem, axx);
         }

         int bestItemSlot = var18;
         int var19 = bestItemSlot;
         byte var10001 = -1;
         if (axxxxx == null) {
            if (bestItemSlot == -1) {
               return;
            }

            var19 = bestItemSlot;
            var10001 = 9;
         }

         label36: {
            if (var19 < var10001) {
               c<"h">(mc, -3943946391072976874L, a)
                  .handleInventoryMouseClick(
                     c<"h">(c<"h">(mc.player, -3937558707877365559L, a), -3936568892041528986L, a),
                     bestItemSlot + 36,
                     targetSlot,
                     c<"û">(-3936717513761730768L, a),
                     mc.player
                  );
               if (axxxxx == null) {
                  break label36;
               }
            }

            c<"h">(mc, -3943946391072976874L, a)
               .handleInventoryMouseClick(
                  c<"h">(c<"h">(mc.player, -3937558707877365559L, a), -3936568892041528986L, a),
                  bestItemSlot,
                  targetSlot,
                  c<"û">(-3936717513761730768L, a),
                  mc.player
               );
         }

         c<"p">(this, true, -3936560768369837233L, a);
         c<"û">(-3944883779375924255L, a).U(axxxx);
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Field)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Class var12 = var8;

         while (true) {
            Field var13 = e(var12, var10, var11);
            if (var13 != null) {
               j[var4] = var13;
               return var13;
            }

            Class[] var14 = var12.getInterfaces();
            if (var14 != null) {
               for (int var15 = 0; var15 < var14.length; var15++) {
                  var13 = f(var14[var15], var10, var11);
                  if (var13 != null) {
                     j[var4] = var13;
                     return var13;
                  }
               }
            }

            if (var12.getName().equals("java.lang.Object")) {
               StringBuffer var19 = new StringBuffer();
               var19.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
               throw new RuntimeException(var19.toString());
            }

            var12 = var12.getSuperclass();
            if (var12 == null) {
               var12 = j(1858348326363031L, 0L);
            }
         }
      }
   }

   public static int t() {
      return 1;
   }

   private boolean j() {
      long a = 树友友友何何友树树友.a ^ 121475782956963L;
      Module[] var10000 = c<"b">(2067510074198584100L, a);
      ArrayList pairs = new ArrayList();
      Module[] ax = var10000;
      int var10001 = c<"h">(this, 2069066993484863501L, a).getValue().intValue();
      if (ax == null) {
         var10001 = var10001 != 0 ? 1 : 0;
      }

      pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2069066993484863501L, a)));
      var10001 = c<"h">(this, 2071293929821668855L, a).getValue().intValue();
      if (ax == null) {
         var10001 = var10001 != 0 ? 1 : 0;
      }

      pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2071293929821668855L, a)));
      var10001 = c<"h">(this, 2068667464723169689L, a).getValue().intValue();
      if (ax == null) {
         var10001 = var10001 != 0 ? 1 : 0;
      }

      pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2068667464723169689L, a)));
      var10001 = c<"h">(this, 2068892050670917629L, a).getValue().intValue();
      if (ax == null) {
         var10001 = var10001 != 0 ? 1 : 0;
      }

      pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2068892050670917629L, a)));
      var10001 = c<"h">(this, 2068352417268153718L, a).getValue().intValue();
      if (ax == null) {
         var10001 = var10001 != 0 ? 1 : 0;
      }

      pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2068352417268153718L, a)));
      var10001 = c<"h">(this, 2066395929045708638L, a).getValue().intValue();
      if (ax == null) {
         var10001 = var10001 != 0 ? 1 : 0;
      }

      pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2066395929045708638L, a)));
      var10001 = c<"h">(this, 2071556667539789376L, a).getValue().intValue();
      if (ax == null) {
         var10001 = var10001 != 0 ? 1 : 0;
      }

      pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2071556667539789376L, a)));
      var10001 = c<"h">(this, 2065578627928796461L, a).getValue().intValue();
      if (ax == null) {
         var10001 = var10001 != 0 ? 1 : 0;
      }

      pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2065578627928796461L, a)));
      var10001 = c<"h">(this, 2065999840880783935L, a).getValue().intValue();
      if (ax == null) {
         var10001 = var10001 != 0 ? 1 : 0;
      }

      pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2065999840880783935L, a)));
      boolean var9 = c<"h">(this, 2067708314012221905L, a).C(b<"i">(28473, 8342305710380424311L ^ a));
      if (ax == null) {
         if (!var9) {
            var10001 = c<"h">(this, 2068996512911035648L, a).getValue().intValue();
            if (ax == null) {
               var10001 = var10001 != 0 ? 1 : 0;
            }

            pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2068996512911035648L, a)));
         }

         var9 = c<"h">(this, 2067708314012221905L, a).C(b<"i">(13953, 1571070901736752602L ^ a));
      }

      if (!var9) {
         var10001 = c<"h">(this, 2069193442861932913L, a).getValue().intValue();
         if (ax == null) {
            var10001 = var10001 != 0 ? 1 : 0;
         }

         pairs.add(Pair.of(Boolean.valueOf((boolean)var10001), c<"h">(this, 2069193442861932913L, a)));
      }

      Set<Integer> usedSlot = new HashSet<>();

      for (Pair<Boolean, NumberValue> pair : pairs) {
         int var10 = (Boolean)pair.getKey();
         if (ax != null) {
            return (boolean)var10;
         }

         label166: {
            if (ax == null) {
               if (var10 == 0) {
                  break label166;
               }

               var10 = ((NumberValue)pair.getValue()).getValue().intValue() - 1;
            }

            int targetSlot = var10;
            boolean var11 = usedSlot.contains(targetSlot);
            if (ax != null) {
               return var11;
            }

            if (var11) {
               return false;
            }

            usedSlot.add(targetSlot);
            if (ax != null) {
               return false;
            }
         }

         if (ax != null) {
            break;
         }
      }

      return (boolean)1;
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static int q() {
      long var0 = a ^ 14184057101296L;
      return c<"h">(c<"û">(1223681303992310724L, var0), 1216392491441556710L, var0).getValue().intValue();
   }

   public static int y() {
      return 1;
   }

   @EventTarget
   public void P(PacketEvent e) {
      long a = 树友友友何何友树树友.a ^ 124347878728438L;
      long ax = a ^ 19358878391876L;
      Module[] var6 = c<"b">(-6204735319399309711L, a);
      if (e.getSide() == c<"û">(-6197904239959398813L, a)) {
         Minecraft var10000 = mc;
         if (var6 == null) {
            if (mc.player == null) {
               return;
            }

            var10000 = mc;
         }

         if (var10000.getConnection() != null) {
            boolean var7 = e.getPacket() instanceof ServerboundContainerClosePacket;
            if (var6 == null) {
               if (var7) {
                  c<"p">(this, false, -6197807704475706387L, a);
                  c<"p">(this, 0, -6204685597091284259L, a);
               }

               var7 = c<"h">(this, -6197807704475706387L, a);
            }

            if (var6 == null) {
               if (!var7) {
                  return;
               }

               var7 = c<"h">(this, -6203900894205664087L, a).getValue();
            }

            if (var6 == null) {
               if (var7) {
                  return;
               }

               var7 = e.getPacket() instanceof ServerboundMovePlayerPacket;
            }

            if (var6 == null) {
               if (var7) {
                  if (!树何何何树何友何树何.x(ax)) {
                     return;
                  }

                  mc.getConnection().send(new ServerboundContainerClosePacket(c<"h">(c<"h">(mc.player, -6199051659979433877L, a), -6198062359268124220L, a)));
                  if (var6 == null) {
                     return;
                  }
               }

               var7 = e.getPacket() instanceof ServerboundUseItemOnPacket;
            }

            label97: {
               if (var6 == null) {
                  if (var7) {
                     break label97;
                  }

                  var7 = e.getPacket() instanceof ServerboundUseItemPacket;
               }

               if (var6 == null) {
                  if (var7) {
                     break label97;
                  }

                  var7 = e.getPacket() instanceof ServerboundInteractPacket;
               }

               if (var6 == null) {
                  if (var7) {
                     break label97;
                  }

                  var7 = e.getPacket() instanceof ServerboundPlayerActionPacket;
               }

               if (!var7) {
                  return;
               }
            }

            mc.getConnection().send(new ServerboundContainerClosePacket(c<"h">(c<"h">(mc.player, -6199051659979433877L, a), -6198062359268124220L, a)));
         }
      }
   }

   private void W(ItemStack item) {
      long a = 树友友友何何友树树友.a ^ 92584091038119L;
      long ax = a ^ 56693505175793L;
      long axx = a ^ 113273293584964L;
      long axxx = a ^ 93165152364104L;
      long axxxx = a ^ 110659489597738L;
      Module[] axxxxx = c<"b">(-381258704359912160L, a);
      Minecraft var10000 = mc;
      if (axxxxx == null) {
         if (c<"h">(mc, -380803857442577435L, a) == null) {
            return;
         }

         var10000 = mc;
      }

      Object var14 = var10000.player;
      if (axxxxx == null) {
         if (var10000.player == null) {
            return;
         }

         var14 = c<"h">(this, -381476733700669936L, a).getValue();
      }

      int var15 = (Boolean)var14;
      if (axxxxx == null) {
         if (var15 == 0) {
            return;
         }

         var15 = 友何树何友树友树何何.l(ax, item);
      }

      if (axxxxx == null) {
         if (var15 == 0) {
            return;
         }

         var15 = c<"û">(-381785254367016942L, a).Y(c<"h">(this, -381660380376561180L, a).getValue().intValue(), axxx);
      }

      label56:
      if (axxxxx == null) {
         if (var15 == 0) {
            var15 = c<"h">(this, -380621391154637221L, a).getValue();
            if (axxxxx != null) {
               break label56;
            }

            if (var15 == 0) {
               return;
            }
         }

         var15 = 友何树何友树友树何何.N(item, axx);
      }

      int itemSlot = var15;
      int var16 = itemSlot;
      byte var10001 = -1;
      if (axxxxx == null) {
         if (itemSlot == -1) {
            return;
         }

         var16 = itemSlot;
         var10001 = 9;
      }

      label42: {
         if (var16 < var10001) {
            c<"h">(mc, -380803857442577435L, a)
               .handleInventoryMouseClick(
                  c<"h">(c<"h">(mc.player, -384584461127709894L, a), -383603952129488235L, a), itemSlot + 36, 1, c<"û">(-379751958142893520L, a), mc.player
               );
            if (axxxxx == null) {
               break label42;
            }
         }

         c<"h">(mc, -380803857442577435L, a)
            .handleInventoryMouseClick(c<"h">(c<"h">(mc.player, -384584461127709894L, a), -383603952129488235L, a), itemSlot, 1, c<"û">(-379751958142893520L, a), mc.player);
      }

      c<"p">(this, true, -383417737118775108L, a);
      c<"û">(-381785254367016942L, a).U(axxxx);
   }

   public static int T() {
      long var0 = a ^ 31203294196652L;
      return c<"h">(c<"û">(8694044250495841176L, var0), 8698837098041061602L, var0).getValue().intValue();
   }

   public boolean K(ItemStack stack) {
      long a = 树友友友何何友树树友.a ^ 26035035187428L;
      long ax = a ^ 85074607979577L;
      long axx = a ^ 80484993526698L;
      long axxx = a ^ 43106629485534L;
      long axxxx = a ^ 156751201497L;
      long axxxxx = a ^ 19459738631940L;
      long axxxxxx = a ^ 100705575633564L;
      long axxxxxxx = a ^ 104443743902760L;
      long axxxxxxxx = a ^ 94531628323932L;
      long axxxxxxxxx = a ^ 12128365568789L;
      long axxxxxxxxxx = a ^ 67520714262115L;
      long axxxxxxxxxxx = a ^ 84164069418417L;
      long axxxxxxxxxxxx = a ^ 120094616522094L;
      long axxxxxxxxxxxxx = a ^ 131248995027985L;
      long axxxxxxxxxxxxxx = a ^ 86088635518932L;
      long axxxxxxxxxxxxxxx = a ^ 16826297124720L;
      Module[] axxxxxxxxxxxxxxxx = c<"b">(7203011328557421667L, a);
      int var10000 = stack.isEmpty();
      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000) {
            return false;
         }

         var10000 = 友何树何友树友树何何.P(axxxxxxxxxxxxxxx, stack);
      }

      label273: {
         if (axxxxxxxxxxxxxxxx == null) {
            if (var10000) {
               return true;
            }

            var39 = stack;
            if (axxxxxxxxxxxxxxxx != null) {
               break label273;
            }

            var10000 = stack.getDisplayName().getString().contains(b<"i">(23171, 1224978480824473258L ^ a));
         }

         if (var10000) {
            return true;
         }

         var39 = stack;
      }

      Item protection = var39.getItem();
      var10000 = protection instanceof ArmorItem;
      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000) {
            ArmorItem item = (ArmorItem)protection;
            float protectionx = 友何树何友树友树何何.C(stack);
            float var43 = 友何树何友树友树何何.X(item.getEquipmentSlot(), axxxxxxxxxxxxx);
            if (axxxxxxxxxxxxxxxx == null) {
               if (var43 >= protectionx) {
                  return false;
               }

               var43 = 友何树何友树友树何何.r(item.getEquipmentSlot(), axxxxxx);
            }

            float bestArmor = var43;
            float var45;
            var10000 = (var45 = protectionx - bestArmor) == 0.0F ? 0 : (var45 < 0.0F ? -1 : 1);
            if (axxxxxxxxxxxxxxxx == null) {
               var10000 = var10000 >= 0 ? 1 : 0;
            }

            return (boolean)var10000;
         }

         var10000 = stack.getItem() instanceof SwordItem;
      }

      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000) {
            return 友何树何友树友树何何.S(axxxxxxx) == stack;
         }

         var10000 = stack.getItem() instanceof PickaxeItem;
      }

      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000) {
            return 友何树何友树友树何何.D(axx) == stack;
         }

         var10000 = stack.getItem() instanceof AxeItem;
      }

      label258:
      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000) {
            var10000 = 友何树何友树友树何何.e(axxxxxxxx, stack);
            if (axxxxxxxxxxxxxxxx != null) {
               break label258;
            }

            if (!var10000) {
               return 友何树何友树友树何何.n(axxx) == stack;
            }
         }

         var10000 = stack.getItem() instanceof ShovelItem;
      }

      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000) {
            return 友何树何友树友树何何.a(axxxxxxxxxxx) == stack;
         }

         var10000 = stack.getItem() instanceof CrossbowItem;
      }

      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000) {
            return 友何树何友树友树何何.I(axxxx) == stack;
         }

         var10000 = stack.getItem() instanceof BowItem;
      }

      label248:
      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000) {
            var10000 = 友何树何友树友树何何.j(stack, ax);
            if (axxxxxxxxxxxxxxxx != null) {
               break label248;
            }

            if (var10000) {
               return 友何树何友树友树何何.z(axxxxxxxxx) == stack;
            }
         }

         var10000 = stack.getItem() instanceof BowItem;
      }

      label276: {
         label240:
         if (axxxxxxxxxxxxxxxx == null) {
            if (var10000) {
               var10000 = 友何树何友树友树何何.n(axxxxxxxxxxxxxx, stack);
               if (axxxxxxxxxxxxxxxx != null) {
                  break label240;
               }

               if (var10000) {
                  return 友何树何友树友树何何.b(axxxxxxxxxx) == stack;
               }
            }

            var41 = stack.getItem();
            if (axxxxxxxxxxxxxxxx != null) {
               break label276;
            }

            var10000 = var41 instanceof BowItem;
         }

         if (var10000) {
            var41 = c<"û">(7203080064744285420L, a);
            if (axxxxxxxxxxxxxxxx != null) {
               break label276;
            }

            if (友何树何友树友树何何.T(var41, axxxxx) > 1) {
               return false;
            }
         }

         var41 = stack.getItem();
      }

      label225: {
         label278: {
            Item var10001 = c<"û">(7202911156006471446L, a);
            if (axxxxxxxxxxxxxxxx == null) {
               label221: {
                  if (var41 == var10001) {
                     var41 = c<"û">(7202911156006471446L, a);
                     if (axxxxxxxxxxxxxxxx != null) {
                        break label221;
                     }

                     if (友何树何友树友树何何.T(var41, axxxxx) > y()) {
                        return false;
                     }
                  }

                  var41 = stack.getItem();
               }

               if (axxxxxxxxxxxxxxxx != null) {
                  break label278;
               }

               var10001 = c<"û">(7202620225894641088L, a);
            }

            if (var41 == var10001) {
               var10000 = 友何树何友树友树何何.T(c<"û">(7202620225894641088L, a), axxxxx);
               if (axxxxxxxxxxxxxxxx != null) {
                  break label225;
               }

               if (var10000 > t()) {
                  return false;
               }
            }

            var41 = stack.getItem();
         }

         var10000 = var41 instanceof FishingRodItem;
      }

      label207:
      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000 != 0) {
            var10000 = 友何树何友树友树何何.T(c<"û">(7200090549560431348L, a), axxxxx);
            if (axxxxxxxxxxxxxxxx != null) {
               break label207;
            }

            if (var10000 > 1) {
               return false;
            }
         }

         var10000 = stack.getItem() instanceof ItemNameBlockItem;
      }

      if (axxxxxxxxxxxxxxxx == null) {
         if (var10000 != 0) {
            return false;
         }

         var10000 = 友何树何友树友树何何.I(stack, axxxxxxxxxxxx);
      }

      return (boolean)var10000;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖230622200409390090";
   }
}
