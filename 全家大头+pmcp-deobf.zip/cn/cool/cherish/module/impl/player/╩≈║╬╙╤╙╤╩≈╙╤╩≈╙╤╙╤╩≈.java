package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.render.CameraEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.CameraType;
import net.minecraft.world.phys.Vec3;

public class 树何友友树友树友友树 extends Module implements 何树友 {
   private final NumberValue 何何友树树树何何何树;
   private long 何何树何树友友友何友;
   private long 何树树何友树何何树友;
   private Rotation 树树友友树友友树友何;
   private Vec3 树友何友树何树友友友;
   private Vec3 何友树何友何树友友友;
   private CameraType 友友何友友何友树树友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[30];
   private static final String[] k = new String[30];
   private static String HE_WEI_LIN;

   public 树何友友树友树友友树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/player/树何友友树友树友友树.a J
      // 03: ldc2_w 128244908548883
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 32411
      // 0c: ldc2_w 2676198068000228891
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友友树友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 4582
      // 19: ldc2_w 2626027118131865959
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友友树友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 3941090051328307242
      // 26: lload 1
      // 27: invokedynamic I (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/树何友友树友树友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/NumberValue
      // 33: dup
      // 34: sipush 29719
      // 37: ldc2_w 1186036365142625429
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友友树友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 11930
      // 44: ldc2_w 891419777460524569
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友友树友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: ldc2_w 0.01
      // 51: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 54: ldc2_w 0.35
      // 57: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 5a: bipush 10
      // 5c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5f: ldc2_w 0.01
      // 62: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 65: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 68: putfield cn/cool/cherish/module/impl/player/树何友友树友树友友树.何何友树树树何何何树 Lcn/cool/cherish/value/impl/NumberValue;
      // 6b: aload 0
      // 6c: lconst_0
      // 6d: ldc2_w 3940752458425530780
      // 70: lload 1
      // 71: invokedynamic Ú (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/player/树何友友树友树友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 76: aload 0
      // 77: lconst_0
      // 78: ldc2_w 3941174554239632389
      // 7b: lload 1
      // 7c: invokedynamic Ú (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/player/树何友友树友树友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 81: aload 0
      // 82: ldc2_w 3941606245106727153
      // 85: lload 1
      // 86: invokedynamic I (JJ)Lnet/minecraft/client/CameraType; bsm=cn/cool/cherish/module/impl/player/树何友友树友树友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 8b: ldc2_w 3941384707372176595
      // 8e: lload 1
      // 8f: invokedynamic Ú (Ljava/lang/Object;Lnet/minecraft/client/CameraType;JJ)V bsm=cn/cool/cherish/module/impl/player/树何友友树友树友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 94: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-6270337199997073056L, -941166758426918545L, MethodHandles.lookup().lookupClass()).a(215087598785637L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 18696445881077L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "\"\u00805\u001c\u0096¬ÉBÑu\u008b,c\\ØÅ\u0010*Ò\u009a¥3§\u001d\u001b·îHÖ\u0019Ñ\u0087Q";
      byte var8 = 33;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[4];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\b»/Ì\u00884ß\u008d\u0095eMÄÙ÷Ò\u0085\u0018\u0096\u0016ò\u008aÑ.\"4SEò¡èâÕ\u0089\u009aÊ\u001b\u00079¯°Ç";
                  var8 = 41;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 树何友友树友树友友树.a ^ 101606170656853L;
      long ax = a ^ 48869803994330L;
      long axx = a ^ 45585018957497L;
      c<"j">(6194467634102430927L, a);
      if (!this.w(new Object[]{ax}) && c<"È">(this, 6194544920355980724L, a) != null) {
         c<"È">(mc, 6192963904785765850L, a).setCameraType(c<"È">(this, 6193773609166649237L, a));
         RenderSystem.enableCull();
         mc.player.setYRot(c<"È">(this, 6194544920355980724L, a).getYaw());
         mc.player.setXRot(c<"È">(this, 6194544920355980724L, a).J(new Object[]{axx}));
      }
   }

   @EventTarget
   public void V(TickEvent event) {
      long a = 树何友友树友树友友树.a ^ 46921218177441L;
      long ax = a ^ 2553613271914L;
      c<"j">(7783167642565301563L, a);
      if (mc.player != null && mc.level != null) {
         RotationUtils.D(new Object[]{ax, c<"È">(this, 7783072334620654656L, a)});
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 54;
               case 2 -> 37;
               case 3 -> 15;
               case 4 -> 39;
               case 5 -> 35;
               case 6 -> 27;
               case 7 -> 63;
               case 8 -> 22;
               case 9 -> 0;
               case 10 -> 19;
               case 11 -> 48;
               case 12 -> 55;
               case 13 -> 25;
               case 14 -> 11;
               case 15 -> 36;
               case 16 -> 32;
               case 17 -> 58;
               case 18 -> 57;
               case 19 -> 60;
               case 20 -> 47;
               case 21 -> 28;
               case 22 -> 53;
               case 23 -> 4;
               case 24 -> 31;
               case 25 -> 1;
               case 26 -> 44;
               case 27 -> 7;
               case 28 -> 43;
               case 29 -> 2;
               case 30 -> 52;
               case 31 -> 30;
               case 32 -> 9;
               case 33 -> 59;
               case 34 -> 45;
               case 35 -> 41;
               case 36 -> 17;
               case 37 -> 10;
               case 38 -> 26;
               case 39 -> 56;
               case 40 -> 20;
               case 41 -> 24;
               case 42 -> 46;
               case 43 -> 62;
               case 44 -> 33;
               case 45 -> 8;
               case 46 -> 51;
               case 47 -> 49;
               case 48 -> 3;
               case 49 -> 12;
               case 50 -> 38;
               case 51 -> 18;
               case 52 -> 6;
               case 53 -> 23;
               case 54 -> 16;
               case 55 -> 40;
               case 56 -> 13;
               case 57 -> 14;
               case 58 -> 21;
               case 59 -> 61;
               case 60 -> 5;
               case 61 -> 34;
               case 62 -> 29;
               default -> 50;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   @EventTarget(4)
   public void i(MoveInputEvent event) {
      long a = 树何友友树友树友友树.a ^ 45143775371344L;
      c<"j">(3887272892161854666L, a);
      if (mc.player != null && mc.level != null) {
         double speed = c<"È">(this, 3887540414039579687L, a).getValue().doubleValue();
         float yRot = mc.player.getYRot();
         double yRotRad = Math.toRadians(yRot);
         double forwardX = -Math.sin(yRotRad);
         double forwardZ = Math.cos(yRotRad);
         double strafeX = -Math.cos(yRotRad);
         double strafeZ = -Math.sin(yRotRad);
         Vec3 offset = new Vec3(
            (event.getForwardImpulse() * forwardX - event.getLeftImpulse() * strafeX) * speed,
            event.isKeyJump() != event.isKeyShift() ? (event.isKeyJump() ? speed : -speed) : 0.0,
            (event.getForwardImpulse() * forwardZ - event.getLeftImpulse() * strafeZ) * speed
         );
         c<"Ú">(this, c<"È">(this, 3887654023792930162L, a), 3886728869146959912L, a);
         c<"Ú">(this, c<"È">(this, 3887654023792930162L, a).add(offset), 3887654023792930162L, a);
         c<"Ú">(this, c<"È">(this, 3887451826277415647L, a), 3887311049380398918L, a);
         c<"Ú">(this, System.nanoTime(), 3887451826277415647L, a);
         event.setForwardImpulse(0.0F);
         event.setLeftImpulse(0.0F);
         event.setKeyJump(false);
         event.setKeyShift(false);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20022;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友友树友树友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友友树友树友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友友树友树友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 200 && var8 != 218 && var8 != 'I' && var8 != 'x') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 164) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'j') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 200) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 218) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'I') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "]RJH\u007fnR\u0012\u0007CusWO\f\u0005}nZI\bN>hSL\b\u0005`m_E\u0001Y>栐佫号厯栺叛栐叵号桵";
      j[1] = "H\u001e\bK*8G^E@ %B\u0003N\u000636G\u0005C\u0006,:[\u001c\bf0:I\u0015T~$;^\u0015";
      j[2] = long.class;
      k[2] = "java/lang/Long";
      j[3] = "\u007f\r\u000eQe\u0014t\u0002\u001f\u001e\u0019\r{\u0018\u0011].=m\u000f\u001d@?\u0011z\u0002";
      j[4] = "%p{E\u001eY%pl\u0019\u0012V?;x\u0004\u0001\\/;\u007f\u0003\nCeCj\b@";
      j[5] = "T\u0006\u001deLq[FPnFl^\u001b[(NqS\u001d_c\rwZ\u0018_(SrV\u0011Vt\r佋佢厣佦反栲叕叼伽佦";
      j[6] = "5\u0019Py\u007fY\u0001:_92R\u000b'Zd9\u0014\u0003:Wb=_@\u0018\\s$V\u000bn";
      j[7] = "'\u0003mjp;'\u0003z6|4=Hz(t7'\u00127\u0007|?,\u0014x\u0010d\",";
      j[8] = "w\u0012\u0007Z\\Iw\u0012\u0010\u0006PFmY\u0010\u0018XEw\u0003]9XN|\u0014\u0001\u0015WT";
      j[9] = "\u001f\u0010lSX]\u001f\u0010{\u000fTR\u0005[{\u0011\\Q\u001f\u000162E@\u0018\u001av\u000e";
      j[10] = double.class;
      k[10] = "java/lang/Double";
      j[11] = "5FA\u0016(|:\u0006\f\u001d\"a?[\u0007[2g?D\u001c[/v:X\n\u0007iA9\\\u000e\u0001.|8";
      j[12] = "=I\"-4\n2\to&>\u00177Td`6\n:R`+u估伋召余伛厐估伋栶栝";
      j[13] = "DRSY\u0018QO]B\u0016y_DVFL";
      j[14] = "(Yr \f5k]s0t\u0012U%\u0011\u001d#\u0016X>\u0010\u00162\u0019_-\u0000\u0012ts(]:)\u000f0,\\*";
      j[15] = "\u000e|m\u001a\u0019\u001a\t!7\u0000rDgvdBL\u0014gGc\u0013\u0011TVz4C\u0014[";
      j[16] = "|\u001ea'k7-\f~\u001f伆伅厏桵栘栆伆伅休桵\u0001&e *\u000bxs1?!";
      j[17] = "I\u007fPC$A\u0018mO{佉佳桠佐栩厸受叭伤収0BdL\u0015rJDeP\u0004";
      j[18] = "Ub,n-+\u0004p3VtD_t2h\u007f.\u0015b!2\u001d~\u0001nr4w4\u0017}(V";
      j[19] = "Tk'L'\u0014\u0005y8t栎厸伹叚桞伩栎厸厧叚GOx\u001a\u0000x'\u001dh\u0014\u0007";
      j[20] = "$6\u0019|lY&9\u0002<W]\u001fj\u0018:nY}2\u001f83\"";
      j[21] = "i\n\\GM|8\u0018C\u007f桤栊厚去栥厼厾栊厚伥<@\u0003r0\n\u0002\u0006\u001dl ";
      j[22] = "!I\u000ez?\u0019xS\u0006uR伾叒叺叴叟厑伾佌栠叴\u001cb\u0013(_Zf;\t P";
      j[23] = "vj7\"{h'x(\u001a伖栞桟佅厔栃伖佚桟叛W#;e*g-%:y;";
      j[24] = "f\u0000h\u0003hX4\u0010f\u0004\tV\n_3[9\u0001\no6^y\u0003&^o\u001ejQ";
      j[25] = "\u0001I4\rGVSY:\n&Xm\u0016oU\u0016\u000em&jPV\rA\u00173\u0010E_";
      j[26] = "|w+]\u00048-e4e号厔休叆厈伸号桎桕叆KX\tn=}0\u001b\ro-";
      j[27] = "P^Kh>\\\u0002NEo_R<\u0001\u00100`\r<1\u00155/\u0007\u0010\u0000Lu<U";
      j[28] = "P(^?(#\u0001:A\u0007佅厏桹伇叽佚栁厏厣厙><w-\u0004;^ng#\u0003";
      j[29] = "\u00121n5\u0010zQ5o%hOnV\f\u0018?YbV\f\u0003.\u0001\u00121n5\u0010zQ5o%";
   }

   @EventTarget
   public void o(WorldEvent event) {
      this.k();
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 树何友友树友树友友树.a ^ 28825448104882L;
      long ax = a ^ 116737586720573L;
      long axx = a ^ 1639183964586L;
      c<"j">(-7633481383608209624L, a);
      if (!this.w(new Object[]{ax})) {
         long var10003 = System.nanoTime();
         c<"Ú">(this, var10003, -7633262790574286531L, a);
         c<"Ú">(this, var10003, -7633403507337550684L, a);
         Vec3 var7 = mc.player.getPosition(1.0F).add(0.0, mc.player.getEyeHeight(), 0.0);
         c<"Ú">(this, var7, -7633166490037776752L, a);
         c<"Ú">(this, var7, -7632936808507309110L, a);
         c<"Ú">(this, new Rotation(axx, mc.player.getYRot(), mc.player.getXRot()), -7633540248757533101L, a);
         RenderSystem.disableCull();
         c<"Ú">(this, c<"È">(mc, -7631748131230607811L, a).getCameraType(), -7632490765469551502L, a);
         c<"È">(mc, -7631748131230607811L, a).setCameraType(c<"I">(-7631659634226700721L, a));
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void M(CameraEvent event) {
      long a = 树何友友树友树友友树.a ^ 89767707621757L;
      c<"j">(-1378340406471502361L, a);
      if (mc.player != null && mc.level != null) {
         c<"È">(mc, -1379827643121865486L, a).setCameraType(c<"I">(-1379880028007717760L, a));
         double smoothness = Math.max(
            Math.min(
               1.0,
               (System.nanoTime() - c<"È">(this, -1378531959468743694L, a))
                  * 1.0
                  / Math.max(c<"È">(this, -1378531959468743694L, a) - c<"È">(this, -1378109836412592533L, a), 1L)
            ),
            0.0
         );
         event.setPosition(
            new Vec3(
               (
                        c<"È">(c<"È">(this, -1378453231462943649L, a), -1378984741335186848L, a)
                           - c<"È">(c<"È">(this, -1378919547437811451L, a), -1378984741335186848L, a)
                     )
                     * smoothness
                  + c<"È">(c<"È">(this, -1378919547437811451L, a), -1378984741335186848L, a),
               (
                        c<"È">(c<"È">(this, -1378453231462943649L, a), -1379136848790309480L, a)
                           - c<"È">(c<"È">(this, -1378919547437811451L, a), -1379136848790309480L, a)
                     )
                     * smoothness
                  + c<"È">(c<"È">(this, -1378919547437811451L, a), -1379136848790309480L, a),
               (
                        c<"È">(c<"È">(this, -1378453231462943649L, a), -1379214478601373892L, a)
                           - c<"È">(c<"È">(this, -1378919547437811451L, a), -1379214478601373892L, a)
                     )
                     * smoothness
                  + c<"È">(c<"È">(this, -1378919547437811451L, a), -1379214478601373892L, a)
            )
         );
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖国企变私企";
   }
}
