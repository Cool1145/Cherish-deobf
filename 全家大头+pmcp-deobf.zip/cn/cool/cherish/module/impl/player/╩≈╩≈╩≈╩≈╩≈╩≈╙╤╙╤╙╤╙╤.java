package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.item.SpoofItemUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.item.ItemStack;

public class 树树树树树树友友友友 extends Module implements 何树友 {
   private final BooleanValue 何友树友树何何树树树;
   private final NumberValue 友何树友友何友何友何;
   private boolean 树友何友树友何树树友;
   private int 友树何何何何树友树友;
   private int 树何友树友友树何树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[32];
   private static final String[] k = new String[32];
   private static String HE_JIAN_GUO;

   public 树树树树树树友友友友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/player/树树树树树树友友友友.a J
      // 03: ldc2_w 132001275278084
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 22307
      // 0c: ldc2_w 6623919078377460889
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 16655
      // 19: ldc2_w 2241463629498548915
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w -7529431676802546550
      // 26: lload 1
      // 27: invokedynamic £ (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/BooleanValue
      // 33: dup
      // 34: sipush 29076
      // 37: ldc2_w 6461794923748143657
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 15219
      // 44: ldc2_w 4419391753863002312
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: bipush 1
      // 4f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 52: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 55: putfield cn/cool/cherish/module/impl/player/树树树树树树友友友友.何友树友树何何树树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 58: aload 0
      // 59: new cn/cool/cherish/value/impl/NumberValue
      // 5c: dup
      // 5d: sipush 5195
      // 60: ldc2_w 7587551437188683764
      // 63: lload 1
      // 64: lxor
      // 65: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6a: sipush 14717
      // 6d: ldc2_w 8958016193876196035
      // 70: lload 1
      // 71: lxor
      // 72: invokedynamic u (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 77: bipush 0
      // 78: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 7b: bipush 0
      // 7c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 7f: bipush 20
      // 81: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 84: bipush 1
      // 85: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 88: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 8b: putfield cn/cool/cherish/module/impl/player/树树树树树树友友友友.友何树友友何友何友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 8e: aload 0
      // 8f: bipush 0
      // 90: ldc2_w -7529032726348351053
      // 93: lload 1
      // 94: invokedynamic ¥ (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 99: aload 0
      // 9a: bipush 0
      // 9b: ldc2_w -7528901762622630018
      // 9e: lload 1
      // 9f: invokedynamic ¥ (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // a4: aload 0
      // a5: bipush 0
      // a6: ldc2_w -7529146155298190557
      // a9: lload 1
      // aa: invokedynamic ¥ (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树树树树树树友友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // af: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-993851298178336739L, 6772921187454825490L, MethodHandles.lookup().lookupClass()).a(13980719514773L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 41278161182297L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[6];
      int var7 = 0;
      String var6 = "Ó\u0082\"!\u0082º!»KÌu|«Y\u009e¿\u0010¦FZAº\u009aßVÌ9ðk\u0014\u00130Ä0_Ì7#±\u008fÎµEbD\n2\u0085(Py)¬Üp\u0086n+ÿ«¨û\u0093é eí7f4/\u001e|ã\u0006õ_ME+\u0083\u0098 J\u0014Á\u0012é\u0001¢â>\u0004÷\u0086\u000f\u0099äv¬=B¼Äé\u001cìõ^\u008c\u009a Î\u00ad½";
      byte var8 = 115;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[6];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ì\u0088ç>ý9YëáÕf¬\u0097\u0094È' WtÊ,\u0018Öoiv4üpp]$Ìæ\u009dT\bv49\u0018¾ÓØ\u0097b\u0007²·]\fËîYMZòkÀ7\u009eÙïÌâ";
                  var8 = 65;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 树树树树树树友友友友.a ^ 116271503421810L;
      c<"õ">(6194562454682403843L, a);
      if (c<"Û">(this, 6194016370540215237L, a)) {
         this.o();
      }

      c<"¥">(this, false, 6194016370540215237L, a);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 16;
               case 1 -> 11;
               case 2 -> 29;
               case 3 -> 39;
               case 4 -> 5;
               case 5 -> 55;
               case 6 -> 1;
               case 7 -> 20;
               case 8 -> 48;
               case 9 -> 35;
               case 10 -> 31;
               case 11 -> 42;
               case 12 -> 7;
               case 13 -> 8;
               case 14 -> 46;
               case 15 -> 61;
               case 16 -> 3;
               case 17 -> 34;
               case 18 -> 22;
               case 19 -> 19;
               case 20 -> 40;
               case 21 -> 18;
               case 22 -> 26;
               case 23 -> 58;
               case 24 -> 36;
               case 25 -> 33;
               case 26 -> 47;
               case 27 -> 15;
               case 28 -> 49;
               case 29 -> 2;
               case 30 -> 56;
               case 31 -> 62;
               case 32 -> 13;
               case 33 -> 41;
               case 34 -> 60;
               case 35 -> 59;
               case 36 -> 44;
               case 37 -> 25;
               case 38 -> 57;
               case 39 -> 38;
               case 40 -> 23;
               case 41 -> 52;
               case 42 -> 21;
               case 43 -> 0;
               case 44 -> 51;
               case 45 -> 32;
               case 46 -> 10;
               case 47 -> 9;
               case 48 -> 30;
               case 49 -> 28;
               case 50 -> 14;
               case 51 -> 4;
               case 52 -> 17;
               case 53 -> 45;
               case 54 -> 37;
               case 55 -> 6;
               case 56 -> 43;
               case 57 -> 50;
               case 58 -> 63;
               case 59 -> 53;
               case 60 -> 24;
               case 61 -> 12;
               case 62 -> 27;
               default -> 54;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21563;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树树树树友友友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树树树树友友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 219 && var8 != 165 && var8 != 163 && var8 != 170) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 232) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 245) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 219) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 165) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 163) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树树树树友友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "\u0016\t\f2&r\u0016\t\u001bn*}\fB\u000fs9w\u001cB1r?~\n\r\u001bh\"t\u0016$\u0019r/";
      j[1] = "F\u0019!FHpF\u00196\u001aD\u007f\\R6\u0004L|F\b{%LwM\u001f'\tCm";
      j[2] = "_a`R\u0006\n_aw\u000e\n\u0005E*w\u0010\u0002\u0006_p:\u0011\u001e\u000fEmd\u0010\n\u001aTv:1\u001e\u000fEmD\u0010\n\u001aTvS\u001d\u0006\u0006|kp\u0019";
      j[3] = " \u000036-! \u0000$j!.:K$t)- \u0011iW0<'\n)k";
      j[4] = "iPo@\u0007,f\u0010\"K\r1cM)\r\u0005,nK-FF*gN-\r\u0018/kG$QF伖佟叵伔叨桹厈叁佫伔";
      j[5] = "N\u000f\"rLXz,-2\u0001Sp1(o\n\u0015x,%i\u000e^;\u000e.x\u0017Wpx";
      j[6] = "\u001fW\u001cCcT\u0010\u0017QHiI\u0015JZ\u000eaT\u0018L^E\"R\u0011I^\u000e|W\u001d@WR\"株桭栨栣栱栝台厷史叹";
      j[7] = "O|ik\u001a\u0010@<$`\u0010\rEa/&\u0003\u001e@g\"&\u001c\u0012\\~iJ\u001a\u0010@w&f#\u001e@g\"";
      j[8] = "\u0017Cr9\u000b}\u001cLcvwd\u0013Vm5@T\u0005Aa(Qx\u0012L";
      j[9] = "~&\u0011\u0013\nE~&\u0006O\u0006Jdm\u0006Q\u000eI~7Kv\u0002U]\"\u0015M\u000eBw";
      j[10] = "4\u0001ip_H;A${UU>\u001c/=FF;\u001a\"=YJ'\u0003i]EJ5\n5EQK\"\n";
      j[11] = int.class;
      k[11] = "java/lang/Integer";
      j[12] = "\u001bA#'Kd\u001bA4{Gk\u0001\n fTa\u0011\n2gRd\u0001]yyJl\fA%'oc\u0003A9}I\u007f\f";
      j[13] = boolean.class;
      k[13] = "java/lang/Boolean";
      j[14] = "h\t\u0002]0Jh\t\u0015\u0001<ErB\u0001\u001c/ObB\u001f\u00078N(%\u0002\u00160P";
      j[15] = "\u0018n2R$a\u0018n%\u000e(n\u0002%1\u0013;d\u0012%/\b,eXB2\u0019$";
      j[16] = "}8mG\u0000{rx L\nfw%+\n\u0002{z#/AA佁佋厝伖佱厤佁佋桇桒";
      j[17] = "zk{\u0014e\u0001qdj[\u0004\u000fzon\u0001";
      j[18] = "i!,\u0018S\u0000k#i#i3A\u001aEce<L\\{^\u0012A\u007f&y\\W";
      j[19] = "`#2f\u0001J%00*zD\u000ex{/E\u0010\u000eI{j\u0010[08\u007f.\u0014A";
      j[20] = ".oOv{>k|M:\u00000@4\u0006?>`@\u0005\u0005h{f{5\u0004ab8";
      j[21] = "83bg5o \u007f(b^;\u0006>(%ni\u0006\u0002{x431x`jb0";
      j[22] = "VwxYo\u0005\u0012e8\t\u001e\u0013m%~\rl\f\u0000f;\u001eql";
      j[23] = "B\u001a,\u000b\u001e'D\u001d{Qs伙厽桺历株伮伙桧桺桜3Nx\u000fS<\\\u001a\"\u0010\u0004";
      j[24] = "]\u0015\u0001{isY]\u0002|\u0013佖叴叧厸叟叐佖佪栽厸\u001cy:MC\u0001d}rND";
      j[25] = "i!N^2to&\u0019\u0004_~Uf\u001c\u0018'z7;Y\f#\u0017kcY\u001e2u6&M\u001a_";
      j[26] = "dK\fCU\u0016eB\u0015\u001d9H\t\u0015MC\b\u0019\t$IK@LnJ\u000f\u000bZH";
      j[27] = "us\u0013\u001ar~stD@\u001f叞伔栓厹叡佂叞伔叉伧\" p\"`E\\re#u";
      j[28] = "tI}\u0011yarN*K\u0014栛伕右栍只受栛伕栩佉)+\u007f'_r\u0014oi.\r";
      j[29] = "vTt\u0015C\u0011\u007f@7\u0014=\u0010\u0011\u0015tZ\u0002A\u0011.v\u0016R\u0011 \u00132\u0000[C";
      j[30] = "\u000ft\u00126U`\tsEl8栚台佐厸栗叻佞株栔厸\u000e\tlV0\u001a|\u0005~Zr";
      j[31] = "f8\u0001K*#`?V\u0011G厃桃伜伵伮会桙厙桘厫sx=5.\u000eN<+<|";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private int m() {
      long a = 树树树树树树友友友友.a ^ 116735714181361L;
      long ax = a ^ 52666300423513L;
      c<"õ">(2626867622334920064L, a);
      if (this.w(new Object[]{ax})) {
         return 0;
      } else {
         int i = 0;
         ItemStack stack = mc.player.getInventory().getItem(0);
         if (!stack.isEmpty() && stack.getItem() == c<"£">(2626801893947381774L, a)) {
            return 0;
         } else {
            i++;
            return -1;
         }
      }
   }

   private void o() {
      long a = 树树树树树树友友友友.a ^ 139562351063994L;
      long ax = a ^ 65024038923794L;
      long axx = a ^ 30061783487420L;
      long axxx = a ^ 90847513663237L;
      c<"õ">(1675223520581404363L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"Û">(this, 1675274497131549031L, a).getValue()) {
            if (!SpoofItemUtils.n(new Object[]{axx})) {
               return;
            }

            SpoofItemUtils.n(new Object[]{axxx});
         }

         int i = 0;
         if (0 == c<"Û">(this, 1674760027033065408L, a)) {
            c<"¥">(mc.player.getInventory(), 0, 1674604562740563138L, a);
            c<"Û">(mc, 1675017818847308828L, a).tick();
         }

         i++;
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 树树树树树树友友友友.a ^ 52647248097941L;
      c<"¥">(this, 0, -7632862150573500689L, a);
      c<"¥">(this, false, -7632801696247367646L, a);
      c<"¥">(this, 0, -7632951993313654094L, a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void r(LivingUpdateEvent event) {
      long a = 树树树树树树友友友友.a ^ 36953464023701L;
      long ax = a ^ 110320882202429L;
      long axx = a ^ 74916303882899L;
      long axxx = a ^ 26923160343167L;
      c<"õ">(5625217619555590116L, a);
      if (!this.w(new Object[]{ax})) {
         label33: {
            if (c<"Û">(c<"Û">(mc, 5625070630875913446L, a), 5626080159254421711L, a).isDown()) {
               if (c<"Û">(this, 5625797711240421410L, a) || c<"Û">(this, 5625630217108443826L, a) > 0) {
                  break label33;
               }

               c<"¥">(this, c<"Û">(mc.player.getInventory(), 5625625472489821677L, a), 5625750382318128879L, a);
               if (c<"Û">(this, 5625165478227822664L, a).getValue() && !SpoofItemUtils.n(new Object[]{axx})) {
                  int var10000 = c<"Û">(this, 5625750382318128879L, a);
                  Object[] var10003 = new Object[]{null, axxx};
                  var10003[0] = var10000;
                  SpoofItemUtils.I(var10003);
               }

               int pearlSlot = this.m();
               if (pearlSlot != -1) {
                  c<"¥">(mc.player.getInventory(), pearlSlot, 5625625472489821677L, a);
                  c<"Û">(mc, 5625423238308082995L, a).useItem(mc.player, c<"£">(5625518946570053131L, a));
                  c<"¥">(this, true, 5625797711240421410L, a);
                  c<"¥">(this, c<"Û">(this, 5626031221349509842L, a).getValue().intValue(), 5625630217108443826L, a);
               }
            }

            if (c<"Û">(this, 5625797711240421410L, a)) {
               this.o();
               c<"¥">(this, false, 5625797711240421410L, a);
            }
         }

         if (c<"Û">(this, 5625630217108443826L, a) > 0) {
            c<"¥">(this, c<"Û">(this, 5625630217108443826L, a) - 1, 5625630217108443826L, a);
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "我是何树友";
   }
}
