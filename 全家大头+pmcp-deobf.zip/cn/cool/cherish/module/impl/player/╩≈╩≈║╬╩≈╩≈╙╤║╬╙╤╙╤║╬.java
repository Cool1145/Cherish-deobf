package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.module.impl.display.树树何树何何树何何树;
import cn.cool.cherish.ui.何何何友何友何树友友;
import cn.cool.cherish.utils.animations.何何何何何友树树树友;
import cn.cool.cherish.utils.animations.友何树友树何何友树树;
import cn.cool.cherish.utils.animations.树友树何树树何树树何;
import cn.cool.cherish.utils.packet.BlinkUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.RemotePlayer;

public class 树树何树树友何友友何 extends Module implements 何树友 {
   private final ModeValue 何何友何何友何何友友 = new ModeValue("Mode", "模式", new String[]{"Vanilla", "Pulse", "Heypixel"}, "Vanilla");
   private final NumberValue 友何树何树友友树友友 = new NumberValue("Pulse Tick", "脉冲刻数", 20, 5, 60, 1).A(() -> this.何何友何何友何何友友.K("Pulse"));
   private final BooleanValue 何树何何何友树友何何 = new BooleanValue("Auto Disable", "自动关闭", true);
   private final NumberValue 树树友何友树树树友何 = new NumberValue("Max Ticks", "最大刻数", 40, 10, 100, 1).A(this.何树何何何友树友何何::getValue);
   private final BooleanValue 友友何树树何友何何友 = new BooleanValue("Slow Release", "缓慢释放", false);
   private final NumberValue 何友何何树树树树何友 = new NumberValue("Release Ticks", "释放刻数", 5, 1, 20, 1).A(this.友友何树树何友何何友::getValue);
   private final BooleanValue 何树友友友何树友友树 = new BooleanValue("Render Ghost", "渲染幽灵", true);
   private final BooleanValue 何何何何何友树树友何 = new BooleanValue("Rainbow", "彩虹", true).A(this.何树友友友何树友友树::getValue);
   private final BooleanValue 何何友何树友树树友友 = new BooleanValue("Fill Mode", "填充模式", true).A(this.何树友友友何树友友树::getValue);
   private final BooleanValue 何树树友友何何友何友 = new BooleanValue("Wireframe Mode", "线框模式", true).A(this.何树友友友何树友友树::getValue);
   private final NumberValue 树树友树友树何友友何 = new NumberValue("Fill Alpha", "填充透明度", 0.3, 0.0, 1.0, 0.05).A(() -> {
      树友何何友何树何树友.E();
      return this.何树友友友何树友友树.getValue() && this.何何友何树友树树友友.getValue();
   });
   private final BooleanValue 树何友何树友树友友何 = new BooleanValue("Damage Effect", "伤害效果", true).A(this.何树友友友何树友友树::getValue);
   private final 何何何何何友树树树友 树何树树友友友友何树 = new 树友树何树树何树树何(37618987749219L, 500, 1.0, 1.8F);
   private int 友树友树何树友友树何 = 1;
   private RemotePlayer 树友树何树友树友树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[57];
   private static final String[] k = new String[57];
   private static String LIU_YA_FENG;

   public 树树何树树友何友友何() {
      super("Blink", "瞬移", 树何友友何树友友何何.友树树友何友何树友树, 86);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2711031424905605477L, -6346031347955224400L, MethodHandles.lookup().lookupClass()).a(204404842712779L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(118909697196177L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[37];
      int var7 = 0;
      String var6 = "óà;z$ë\u0095b\tÃ³ä¤Q\u009c\n Î¼\u0000üÞo\"?½\r\u001aæ3¨\u0090\u0081P<?PB¹Î\u0001w!ûÏ\u0002äWJ \u009c½e³\u0006¥^Ç«åq¦}·ûK\u000et);\u0003¥´yR9;F\u0084\u0095U\u0087\u0010\u0013JýhþQ\u007f\u0010'F\\ô¾_Uõ\u0018m³Kþ\u0084íSx63â\u001c\u001c §f\u0095U\u001bÀÃèÉ\u008c\u0018 ãÃk!Üá\u008c\u009eLÀÚrÅkm\u0097ùc\u0006Aø*Â\u0010x?\u0083é\u0096\u0017\u0082®¨ûÇ\u0019\u0092$\u0086é\u0010\u0097Ê ;¹@ÐÂþ\u0088¿\u008fX\u0090\u0087Ó\u0010t=Ï{«\u008b«\u008b\u001c\u008eß\u0011²¸O'\u0010mË3\r.\u001d¢Æ\u0019Ö\u001bÅûöN\u0097\u0010Ùf\u00836êtÕc8BHñ\u00038Ã\u0086\u0010)\nüÂ~Á¥\u009a»tõ]\u0087ä%ä\u0010ÿ¥_p múcÈ¿!\u0087\u0000z~/\u0010?óûXq\".nVp\u0086xw2³û Wí\u0084ÓqMÚ\u008c\u001dúå©ñ{\f\u0003*¬\u0090¶ô¯Ãt\u0093\u0086+0\u00adË<\u0005 g\u0013\u008b\u0087¼µé,Áü4(\u008e!\u001a\u009eíW·o!´\u0092åí\u008dâhô$Ê\u0086 \u0088¸B\u0011ÝåkbÊ\u0011\u0085!1uR\u009ftHû\r\u008a\u001b\u001böQä*õ¸\u0006ó¨ ¹ù'bªWÀ-\u0094Ee´g\u001eø\u0012\u0084Ê þ¬£\u0013^30\u0019#\u001cñk² ²«þ7w\u008fØ\u0091\u0013Éªÿ0Ä!ªEm²\u00041ô.Ô\u008b|»ý\u0087Ð\u009dj\u0010~Ã\u0018H=77r5:û+û\u0004ÄE\u0018\u001b,÷\u0016\nê\u0083q1³L â#&6j\u001dþäiAdß\u0010&º\n¬\b÷z§\u0099Ç¥\u0014\u008b\u001b°C Ya¡9¶\u0001(\u0099\u009c²~züÔËÄ\u0010ñ\u008b.\u00adtJ¥z¨ª÷Ïu\u008aá\u0018o*\u0096¢\u009a1\u008a$ôDÆ×à:æÙé\u001a²\u0092+RxÂ\u0018\u0095\u0096â÷\rly°Ë¦³t*.Áyk\u009cÄÀ2Q÷á +¥*\u0098\u0010z.Ö\u008f\u0097¤ë:J\u008f=\u0091ìÿÆ´ú\u0081\u0013\u0018E\u0013d\u0089Ü°$\u0018\u007fµñP\u0016è\u0093´%5ù\u0098*Ékg\u0095\bÌÑvÞ\u008e¸\u0018\u0098D×\\6¦\u0015±µ~ZV-\u001e]=Ëï{ï\u001ae\u0014ü\u0010\u0014]Y\u0082]cÄp0öÛ:À|íñ º=õ¼:\u008cù\u0010\fÉ\u0014h\u008a\u0017¯0J[!D\u0084\u0083ùüû-ZÁ*-½É /p\u008a\u001eaA\u009b\u0089\u0017-ä\t®\u009a\u0000\u008a<÷\u0093û\u0017\u008d\u0081\u00176âÏQÍt°»\u0018×Ã\u009cR\u0096û\u0016,ÔY¿\u0096!.\u0017ûÍW1¹\u0010Éô¹\u0010åm\u0087Ef\u0004±i\u0080Ø\u0096B{ Sê\u0018ï\b¡+\u0012n\u0004Áz\u0095áÞ¼½²\u0082+\u0082¨=¡µ7n \r\u009f»Ê\u0083¦óÑÛ\u0081¦°\u0019Ã+\\)q¨ìc Ä\u0085¼j~ñ`E\u0015e";
      short var8 = 858;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[37];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "-0*î\u0003ø\u000føÒWº\u0087f\u009e\u0014Â·\u0082ãã\u0088×!Î*gÌõö.º\u008a\u0018\u0089\u0012``cÕþ.rÑ©Øt²\u0007«\u0094Ê\u001dãy¬a\u008e";
                  var8 = 57;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void C(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.何树何何何友树友何何.getValue() && BlinkUtils.INSTANCE.友何友何树树何树树树 >= this.树树友何友树树树友何.getValue().intValue()) {
            this.J(false);
         } else {
            String var13 = this.何何友何何友何何友友.getValue();
            byte var14 = -1;
            switch (var13.hashCode()) {
               case 77474681:
                  if (!var13.equals("Pulse")) {
                     break;
                  }

                  var14 = 0;
               case -352307958:
                  if (var13.equals("Heypixel")) {
                     var14 = 1;
                  }
            }

            switch (var14) {
               case 0:
                  int pulseTicks = this.友何树何树友友树友友.getValue().intValue();
                  if (BlinkUtils.INSTANCE.友何友何树树何树树树 < pulseTicks) {
                     break;
                  }

                  if (this.友友何树树何友何何友.getValue()) {
                     int ticks = this.何友何何树树树树何友.getValue().intValue();
                     BlinkUtils.INSTANCE.a(ticks, 107622092269185L);
                     this.树友树何树友树友树何.setPos(BlinkUtils.INSTANCE.树何友何友友何树何树);
                     this.树友树何树友树友树何.setYRot(BlinkUtils.INSTANCE.树树何树树何友树何树.getYaw());
                     this.树友树何树友树友树何.setXRot(BlinkUtils.INSTANCE.树树何树树何友树何树.l(5377274095808L));
                     this.树友树何树友树友树何.xo = BlinkUtils.INSTANCE.树何友何友友何树何树.x;
                     this.树友树何树友树友树何.yo = BlinkUtils.INSTANCE.树何友何友友何树何树.y;
                     this.树友树何树友树友树何.zo = BlinkUtils.INSTANCE.树何友何友友何树何树.z;
                  }

                  BlinkUtils.W(138430676960977L);
               case 1:
                  if (BlinkUtils.INSTANCE.友何友何树树何树树树 >= this.友树友树何树友友树何 * 4) {
                     this.友树友树何树友友树何 = BlinkUtils.INSTANCE.友何友何树树何树树树;
                     BlinkUtils.INSTANCE.a(1, 107622092269185L);
                  }
            }

            this.X("Delay " + BlinkUtils.INSTANCE.友何友何树树何树树树 + "ticks");
         }
      }
   }

   @EventTarget
   public void D(Render2DEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         int y = mc.getWindow().getGuiScaledHeight() / 2 + 70;
         this.树何树树友友友友何树.n(友何树友树何何友树树.树树何树何树何何友友, 59020024422499L);
         if (BlinkUtils.INSTANCE.友何友何树树何树树树 != 0 && !this.树何树树友友友友何树.A(14032659181055L, 友何树友树何何友树树.树树友树友何树友何何)) {
            float progress = Math.min(BlinkUtils.INSTANCE.友何友何树树何树树树 / this.树树友何友树树树友何.getValue().floatValue(), 1.0F);
            event.poseStack().pushPose();
            String var13 = HUD.instance.树友何何友何树何树友.getValue();
            byte var14 = -1;
            switch (var13.hashCode()) {
               case -1818419758:
                  if (!var13.equals("Simple")) {
                     break;
                  }

                  var14 = 0;
               case -1984932033:
                  if (var13.equals("Modern")) {
                     var14 = 1;
                  }
            }

            switch (var14) {
               case 0:
                  何何何友何友何树友友.B(event.poseStack(), "Blink now...", progress, BlinkUtils.INSTANCE.友何友何树树何树树树, y);
               case 1:
                  何何何友何友何树友友.U(event.poseStack(), progress, y);
               default:
                  event.poseStack().popPose();
            }
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 18;
               case 1 -> 41;
               case 2 -> 62;
               case 3 -> 27;
               case 4 -> 24;
               case 5 -> 48;
               case 6 -> 6;
               case 7 -> 42;
               case 8 -> 17;
               case 9 -> 9;
               case 10 -> 14;
               case 11 -> 30;
               case 12 -> 25;
               case 13 -> 2;
               case 14 -> 29;
               case 15 -> 20;
               case 16 -> 22;
               case 17 -> 0;
               case 18 -> 46;
               case 19 -> 51;
               case 20 -> 38;
               case 21 -> 8;
               case 22 -> 5;
               case 23 -> 12;
               case 24 -> 61;
               case 25 -> 59;
               case 26 -> 54;
               case 27 -> 16;
               case 28 -> 57;
               case 29 -> 58;
               case 30 -> 52;
               case 31 -> 43;
               case 32 -> 37;
               case 33 -> 49;
               case 34 -> 36;
               case 35 -> 26;
               case 36 -> 34;
               case 37 -> 11;
               case 38 -> 56;
               case 39 -> 53;
               case 40 -> 55;
               case 41 -> 31;
               case 42 -> 23;
               case 43 -> 40;
               case 44 -> 47;
               case 45 -> 50;
               case 46 -> 19;
               case 47 -> 10;
               case 48 -> 4;
               case 49 -> 45;
               case 50 -> 15;
               case 51 -> 63;
               case 52 -> 44;
               case 53 -> 1;
               case 54 -> 28;
               case 55 -> 21;
               case 56 -> 32;
               case 57 -> 60;
               case 58 -> 33;
               case 59 -> 39;
               case 60 -> 3;
               case 61 -> 13;
               case 62 -> 7;
               default -> 35;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27830;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树树何树树友何友友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\b\u008c\u008b\u00194.\u008dÎ, 5ô.\u0088Ëú·")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树何树树友何友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @EventTarget
   public void b(Render3DEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && this.何树友友友何树友友树.getValue()) {
         PoseStack poseStack = event.poseStack();
         int primaryColor = this.何何何何何友树树友何.getValue() ? 何树友友树树友何树何.t(94608897312632L, 10, 1).getRGB() : 树树何树何何树何何树.树树友友友友树友何何.树树何何友树何何友树.O();
         友友何何友友树何何友.Z(
            24488542601285L,
            poseStack,
            this.树友树何树友树友树何,
            primaryColor,
            this.树何友何树友树友友何.getValue(),
            this.何何友何树友树树友友.getValue(),
            this.何树树友友何何友何友.getValue(),
            this.树树友树友树何友友何.getValue().floatValue()
         );
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'b' && var8 != 'Z' && var8 != 'a' && var8 != 'N') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'u') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'W') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'b') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Z') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'a') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树何树树友何友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @Override
   public void h() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         BlinkUtils.l(102729178478887L);
         this.树友树何树友树友树何 = null;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "\u001b8N#R%\u0014x\u0003(X8\u0011%\bnP%\u001c#\f%\u0013#\u0015&\fnM&\u0019/\u00052\u0013桛桩伃桱桑叶伟厳厝伵";
      j[1] = int.class;
      k[1] = "java/lang/Integer";
      j[2] = "{\u0007*tH.{\u0007=(D!aL=6L\"{\u0016p*I&l\u0007,tw\"x\r*?u+t\u001b;(";
      j[3] = float.class;
      k[3] = "java/lang/Float";
      j[4] = " \fpQ:Z/L=Z0G*\u00116\u001c8Z'\u00172W{\\.\u00122\u001c%Y\"\u001b;@{栤厈伷伋叹伀栤伖桳厕";
      j[5] = "\u001b<\u001c#!\u0014/\u001f\u0013cl\u001f%\u0002\u0016>gY-\u001f\u001b8c\u0012n=\u0010)z\u001b%K";
      j[6] = "\u0015(!]\u001b\u0017\u0015(6\u0001\u0017\u0018\u000fc6\u001f\u001f\u001b\u00159{\u0003\u001a\u001f\u0002(']:\u0011\u0018,9#\u001a\u001f\u0002('";
      j[7] = "[%w{W\u0014P*f4+\r_0hw\u001c=I'dj\r\u0011^*";
      j[8] = "#_\u0005dF`,\u001fHoL})BC)_n,DN)@b0]\u0005JFk%gJk\\j";
      j[9] = "01\u0003]A\u0011?qNVK\f:,E\u0010X\u001f?*H\u0010G\u0013#3\u0003|A\u0011?:LPx\u001f?*H";
      j[10] = "R\nJ/6&]J\u0007$<;X\u0017\fb,=X\b\u0017b)(R\u000f\u00018w\u000b]\r\n'\f=X\b\u0017";
      j[11] = "\u007f\u000b\u0007^6\u0010pKJU<\ru\u0016A\u0013,\u000bu\tZ\u00138\u0011u\bHI0\u0010r\u0016\u0007佨伌伪佉估叢栬案桮受";
      j[12] = "Z7@W[3Uw\r\\Q.P*\u0006\u001aA(P5\u001d\u001aU2P4\u000f@]3W*@叿佡桍史案伻佡叿桍栨";
      j[13] = "\bOcx/\u0006\u0007\u000f.s%\u001b\u0002R%5-\u0006\u000fT!~n\u0000\u0006Q!5$\u0000\u0018Q!z9G#t\t";
      j[14] = "\u0007\f@M\ne\bL\rF\u0000x\r\u0011\u0006\u0000\u0013k\b\u0017\u000b\u0000\fg\u0014\u000e@`\u0010g\u0006\u0007\u001cx\u0004f\u0011\u0007";
      j[15] = "`\u0003S316oC\u001e8;+j\u001e\u0015~36g\u0018\u00115p案佖厦厶伅桏厒又伸伨";
      j[16] = "(\u007fh%}%'?%.w8\"b.h\u007f%/d*#<#&a*hv#8a*'kd桚栀伓桗佇伟桚佄伓桗";
      j[17] = "\u0011\u001ce;g0\u001e\\(0m-\u001b\u0001#v~>\u001e\u0007.va2\u0002\u001ee桉參伊伧档桚伍參厔伧";
      j[18] = "\b\u0011^\u001a]V\b\u0011IFQY\u0012Z][BS\u0002ZZ\\ILH\"OW\u0003";
      j[19] = double.class;
      k[19] = "java/lang/Double";
      j[20] = "\u0004.w\":L\u000bn:)0Q\u000e31o W\u000e,*o=F\u000b0<3{q\b485<L\t";
      j[21] = "1\u000bHg \u001a:\u0004Y(A\u00141\u000f]r";
      j[22] = "\u000f2qyK;U37\u0000佼桀厦厛又佝核厚厦桁\u000b>Kc\u0006'vaQ5\u001c";
      j[23] = "LHe\u0001k\u0005\u0016I#x作伺句使佂去作伺句叡\u001fE}\u001dK\u001a&\u0004d\u000bV";
      j[24] = "\u000e\u0004\u001aa\u0013sREA;c'c\u0005\u00145^tc<Ij]t\fM\u001ce\u00074";
      j[25] = "?k\u0003t}\u0017ejE\r佊桬桌参厺佐佊厶伈参y3}O6~\u0004lg\u0019,";
      j[26] = "ozYrO\u001a3;\u0002(?N\u0002{W&\u0002\u001e\u0002B\ny\u0001\u001dm3_v[]";
      j[27] = " V!'%_zWg^桖你厉佡桂厝桖叾厉佡[`%\u0007)C&??Q3";
      j[28] = "\u0017), -\u0017Khwz]Cz++tm\u0010z\u0011)--\u0011\u001c(|*>\u001d";
      j[29] = "\b ?,&{W0?-C厃佪厂伝桎桚伝栮桘桙W?%R&y,r>\n";
      j[30] = "M\r>m\u00128\u0014\u000e%fy+&Nf9Ix&td`\ty@M1g\u001au";
      j[31] = "\u001c/;bWX\u0010|.9j根栵厏桏及伷根可休伋\tZCA'kqV\u0010T|";
      j[32] = "F8\u0018h g\u0019(\u0018iE桅伤厚伺叐历企桠伄桾\u0013.'I3\u0004\"+!\u0004\"";
      j[33] = "E\u000fT\u00067G\u001f\u000e\u0012\u007f4%\u0012U\u0014\u0019gUD\\VC]\u0018\u001f_HE-N\u0016\u001d\u0012\u007f";
      j[34] = "\u001a\u007fR\u001cH\"@~\u0014e使桙伭佈併厦栻厃伭佈([Hz\u0013jU\u0004R,\t";
      j[35] = "I6{su9\u00137=\n佂伆佾企作叉栆桂叠企\u00014ua@#|ko7Z";
      j[36] = "R>{TZn\b?=-栩叏校伉栘叮栩叏校伉\u0001\u0017\b3\\$;KIh\u0006";
      j[37] = "\"\u0019\b\u0013\u0000;.J\u001dH=桚栋伧桼伥栤伞住厹厦x\r \u007f\u0011X\u0000\u0001sjJ";
      j[38] = "4_\u0002@&\u0001n^D9桕桺厝栬去栠休厠厝佨x\b6[,S\u0019P(\u001d0";
      j[39] = "-\u001f~;<}\u007f\u00102#[厁桝桻厃伃厘伟桝厡桙^2?z\u0007'a`06\u001f";
      j[40] = "]R\u001c\b\fzXTQ\u0019o%a\u0019\u0016^_sa)@\rQv\u000eX\u0015\u0002\u000b6";
      j[41] = "fI3a\u001axgN$&v桙栕佶伔叝桯伝佑叨桐\u001e\u001dq3R9&\b&bY";
      j[42] = "rtV\\(t(u\u0010%伟叕佅佃栵格桛栏佅叝,\u00148.jxML&hv";
      j[43] = "\u0010;6\u001f\u0019f\u0015={\u000ez9,p<IEf,@j\u001aDjC1?\u0015\u001e*";
      j[44] = "$YI'6!~X\u000f^原厀伓株株伃原伞伓台3`6y-LN?,/7";
      j[45] = "[t\\fK{\u0001u\u001a\u001f叢栀史标佻栆叢叚栨佃&cD|V']._$";
      j[46] = "n%:Q1xo\"-\u0016]桙栝厄厃叭厞桙叇会伝.7\"~8,\u00166%i\u007f";
      j[47] = "l\bpV})i\u000e=G\u001evPCz\u0000.!Ps,S %?\u0002y\\ze";
      j[48] = "Wf\u0003\u00006.\rgEy原休栤佑桠厺原桕叾叏yH&tOj\u0018\u001082S";
      j[49] = " BFmM?xLV0tC\u001b\u0012\\-\u000eipT\tf\u001d\u000e";
      j[50] = "C8{.\f:\u00199=W桿伅栰桋参厔厥厛佴桋\u0001h\u0003#\u00136x>\u00043[";
      j[51] = "rfSd/o-vSeJ\u0015\u000b\\pV\f\u001f\u0000\u0007\u0013~5/(<Ln5.";
      j[52] = "\b\u0006Px0&W\u0016PyU栄栮伺栶栚伈叞栮伺栶\u00038'Q\u0018@9jw\u0006X";
      j[53] = "(\u0014A5b+tU\u001ao\u0012\u007fE\u0015Oa/-E,\u0012>,,*]G1vl";
      j[54] = "&\u001ce[i@v\u001abI\u0002栤叔使佀古佟栤佊栻叞'?AmO%\u001e~X{R";
      j[55] = "`{\u0003\u0000\u0001w:zEy伶佈叉佌桠厺桲栌叉叒yG\u0001/in\u0004\u0018\u001bys";
      j[56] = "\u0001\u000e\u001df?[[\u000f[\u001f桌栠厨伹厤栆桌栠厨伹g./\u0001\u0019\u0002\u0006v1G\u0005";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   public void M() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.树友树何树友树友树何 = new RemotePlayer(mc.level, mc.player.getGameProfile());
         this.树友树何树友树友树何.yHeadRot = mc.player.yHeadRot;
         this.树友树何树友树友树何.copyPosition(mc.player);
         this.树友树何树友树友树何.setUUID(mc.player.getUUID());
         this.友树友树何树友友树何 = 1;
         WrapperUtils.P(32009361208983L);
         this.J(false);
      }
   }

   private static String HE_WEI_LIN() {
      return "何树友为什么濒天了";
   }
}
