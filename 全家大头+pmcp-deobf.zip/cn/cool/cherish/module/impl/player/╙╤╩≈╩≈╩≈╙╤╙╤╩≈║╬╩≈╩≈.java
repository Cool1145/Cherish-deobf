package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.item.友何树何友树友树何何;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TieredItem;

public class 友树树树友友树何树树 extends Module implements 何树友 {
   private final BooleanValue 何何何何何何何友友友;
   private final BooleanValue 友何友何友友友友友树;
   public final BooleanValue 树树树友树友友何何友;
   private final NumberValue 何树友友树友何何友树;
   private boolean 友友树树何何树树友何;
   private int 树友友何树树何树何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[27];
   private static final String[] k = new String[27];
   private static String HE_DA_WEI;

   public 友树树树友友树何树树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/友树树树友友树何树树.a J
      // 003: ldc2_w 71310494285958
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 17777
      // 00c: ldc2_w 5402404829583775004
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 21156
      // 019: ldc2_w 1090109268993737419
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w 3132562105365495649
      // 026: lload 1
      // 027: invokedynamic ò (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/BooleanValue
      // 033: dup
      // 034: sipush 28253
      // 037: ldc2_w 8013536175566405175
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 2371
      // 044: ldc2_w 5800054842042833197
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 1
      // 04f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 052: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 055: putfield cn/cool/cherish/module/impl/player/友树树树友友树何树树.何何何何何何何友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 058: aload 0
      // 059: new cn/cool/cherish/value/impl/BooleanValue
      // 05c: dup
      // 05d: sipush 4984
      // 060: ldc2_w 483182637747979034
      // 063: lload 1
      // 064: lxor
      // 065: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 06a: sipush 6190
      // 06d: ldc2_w 7716512914823071813
      // 070: lload 1
      // 071: lxor
      // 072: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 077: bipush 1
      // 078: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 07b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 07e: putfield cn/cool/cherish/module/impl/player/友树树树友友树何树树.友何友何友友友友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 081: aload 0
      // 082: new cn/cool/cherish/value/impl/BooleanValue
      // 085: dup
      // 086: sipush 1735
      // 089: ldc2_w 2772468102628136622
      // 08c: lload 1
      // 08d: lxor
      // 08e: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 093: sipush 8553
      // 096: ldc2_w 9109026209714008330
      // 099: lload 1
      // 09a: lxor
      // 09b: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a0: bipush 0
      // 0a1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0a4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0a7: putfield cn/cool/cherish/module/impl/player/友树树树友友树何树树.树树树友树友友何何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0aa: aload 0
      // 0ab: new cn/cool/cherish/value/impl/NumberValue
      // 0ae: dup
      // 0af: sipush 15739
      // 0b2: ldc2_w 6344264287532346647
      // 0b5: lload 1
      // 0b6: lxor
      // 0b7: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bc: sipush 4607
      // 0bf: ldc2_w 6919460260714529175
      // 0c2: lload 1
      // 0c3: lxor
      // 0c4: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c9: bipush 10
      // 0cb: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ce: bipush 1
      // 0cf: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0d2: bipush 20
      // 0d4: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0d7: bipush 1
      // 0d8: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0db: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0de: aload 0
      // 0df: ldc2_w 3133129178054972042
      // 0e2: lload 1
      // 0e3: invokedynamic H (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e8: dup
      // 0e9: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 0ec: pop
      // 0ed: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 0f2: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0f5: checkcast cn/cool/cherish/value/impl/NumberValue
      // 0f8: putfield cn/cool/cherish/module/impl/player/友树树树友友树何树树.何树友友树友何何友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 0fb: aload 0
      // 0fc: bipush 0
      // 0fd: ldc2_w 3134147396042022110
      // 100: lload 1
      // 101: invokedynamic O (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 106: aload 0
      // 107: bipush 0
      // 108: ldc2_w 3132789786202685282
      // 10b: lload 1
      // 10c: invokedynamic O (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/友树树树友友树何树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 111: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-9031899093522798396L, -8280719918568064607L, MethodHandles.lookup().lookupClass()).a(177151478978990L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 14003967881188L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[10];
      int var7 = 0;
      String var6 = "W¸%r\u007f\u0010Ò¸\u0012L<(«E\u009bÈ¿w¦®ç±ªÂ(]$iø\u0007v{K\u0096ñ²«PÝ®n\u0089åÌ¸&5l¦q×&è\u0083XÎ%wÝ#Ø$lÇ\u0081(Àý e\u0097°M\u008cÃ2(Ä/vÖ¤6\u0094\u0083_Ð¼\u0003\u0093Áx!\u0084\u0004Öµ\u0083ú¢\u008fI9þBp ,«_o\u007f\u0007\u0006¾\u008c«®+tá0Éum-\u008bm¶ý@¾êD¶3³Ø~ m/Ò²*\u0081z|ë\u0007\u009dlP\u0095jÍ\u009eEµ\u001dé9Fk#\u0010\u009f¥\u001f¾Åæ\u0018Ò3\u0000)sHy<\u0003Âr\f\u008aec\u0095o®ÙOóev\u0084\u0018¦\u0001Jä¾¦/#\u0012KK!¶\u0094¥)GÉLexÜ)ò W\u0013ªÁY¼Ã,¡m¦ \u008f§x\u0011iÑ¬E¯\u00953CÙ\u009cHV§\u001c4µ";
      short var8 = 255;
      char var5 = 24;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[10];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "#µÏ\tBù\u008d'\t{Bl£X\u0085K?Qcf9Ï\u0091~:¤Ùâ§\u0080b×ª\u001b{YÉ×Îö\u0018\u0004\u001d\u00978\u0016\u0092áî\u000bv\u008fö\u0090¼â¦`\f\u0096\u0013Ú¬\u009d8";
                  var8 = 65;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 20;
               case 1 -> 60;
               case 2 -> 47;
               case 3 -> 37;
               case 4 -> 34;
               case 5 -> 39;
               case 6 -> 13;
               case 7 -> 38;
               case 8 -> 27;
               case 9 -> 26;
               case 10 -> 22;
               case 11 -> 30;
               case 12 -> 8;
               case 13 -> 62;
               case 14 -> 45;
               case 15 -> 54;
               case 16 -> 0;
               case 17 -> 15;
               case 18 -> 61;
               case 19 -> 4;
               case 20 -> 56;
               case 21 -> 32;
               case 22 -> 16;
               case 23 -> 5;
               case 24 -> 52;
               case 25 -> 6;
               case 26 -> 21;
               case 27 -> 49;
               case 28 -> 42;
               case 29 -> 2;
               case 30 -> 58;
               case 31 -> 53;
               case 32 -> 36;
               case 33 -> 28;
               case 34 -> 41;
               case 35 -> 40;
               case 36 -> 50;
               case 37 -> 35;
               case 38 -> 31;
               case 39 -> 3;
               case 40 -> 1;
               case 41 -> 59;
               case 42 -> 18;
               case 43 -> 11;
               case 44 -> 25;
               case 45 -> 57;
               case 46 -> 29;
               case 47 -> 23;
               case 48 -> 48;
               case 49 -> 44;
               case 50 -> 51;
               case 51 -> 33;
               case 52 -> 17;
               case 53 -> 43;
               case 54 -> 19;
               case 55 -> 46;
               case 56 -> 9;
               case 57 -> 10;
               case 58 -> 14;
               case 59 -> 7;
               case 60 -> 24;
               case 61 -> 12;
               case 62 -> 55;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 31511;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友树树树友友树何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友树树树友友树何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'H' && var8 != 'O' && var8 != 242 && var8 != 216) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 249) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 234) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'H') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'O') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 242) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友树树树友友树何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   @EventTarget
   public void d(AttackEvent event) {
      long a = 友树树树友友树何树树.a ^ 133685278085144L;
      c<"O">(this, true, 8926278767079427136L, a);
   }

   private static void a() {
      j[0] = "j\u007fBl%ze?\u000fg/g`b\u0004!'zmd\u0000jd|da\u0000!:yhh\t}d叞栘栀桽叄厁栄作栀桽";
      j[1] = int.class;
      k[1] = "java/lang/Integer";
      j[2] = boolean.class;
      k[2] = "java/lang/Boolean";
      j[3] = "Pm\u0017[7I_-ZP=TZpQ\u00165IWvU]v佳佦又佬佭厓佳佦栒栨";
      j[4] = ";\u001c\u0019k \u000b4\\T`*\u00161\u0001_&9\u00054\u0007R&&\t(\u001e\u0019J \u000b4\u0017Vf\u0019\u00054\u0007R";
      j[5] = "\u000e g\u001f%j\u0005/vPYs\n5x\u0013nC\u001c\"t\u000e\u007fo\u000b/";
      j[6] = "Y\t\u0005\"\u0013jVIH)\u0019wS\u0014Co\u0011j^\u0012G$RlW\u0017Go\fi[\u001eN3R佐佯厬佾厊桭収叱伲佾";
      j[7] = "M&\n'\u0013sy\u0005\u0005g^xs\u0018\u0000:U>{\u0005\r<Qu8'\u0006-H|sQ";
      j[8] = "\u0012(\r\u001d-!\u0012(\u001aA!.\bc\u000e\\2$\u0018c\u001c]4!\b4WC,)\u0005(\u000b\u001d\t&\n(\u0017G/:\u0005";
      j[9] = "\u0004da\u0005jK\u0004dvYfD\u001e/vGnG\u0004u;fnL\u000fbgJaV";
      j[10] = "^F\u0007\u0011u.^F\u0010My!D\r\u0010Sq\"^W]Rm+DJ\u0003Sy>UQ]rm+DJ#Sy>UQ4^u\"}L\u0017Z";
      j[11] = "0gj+iC0g}weL*,}imO0v0uhK'gl+HE=crUhK'gl";
      j[12] = "47r\u0005zV47eYvY.|eG~Z4&(FbS.;vGvF? (h{V?<r{v\\17rg~L.7hNe";
      j[13] = "{\u0000%lV:t@hg\\'q\u001dc!O4t\u001bn!P8h\u0002%AL8z\u000byYX9m\u000b";
      j[14] = "BI_\u0003dTIFNL\u0005ZBMJ\u0016";
      j[15] = "\u0005oP_[FZq[?叴厸桲标佼佢栮桢厨佃!\u0006Q\t\ndG\u0006E\u0004\u0010";
      j[16] = "W\u001fInze\b\u0001B\u000e叕伅叺伳叻反叕厛叺桷84j;I\u0017Q|*'F";
      j[17] = "'\"\u0013+\f\u0007qwT2|伽叞叝叩厈县伽佀标叩KF\\$~Z,\u0010\tcg";
      j[18] = "NaA\u0015A)\u0011\u007fJu栴受口位栩桬佰栍佽位0\u0004\u0011*Zm\u0000NQ-";
      j[19] = "83z\r{ne#{\t\u0005>Qx,\t:jQI*]xj6quVo<";
      j[20] = "HtX=YJ\u0017jS]佨伪佻佘佴伀佨厴句叆)gI\u0014V|@/\t\bY";
      j[21] = "wPg\u0002\u0018{)\n=\u0018z-\u001f\u000eeYDzw`]Y\u0011$x[0\u0012\u0016'&";
      j[22] = "W>0\r{V\b ;m~k\u0002-&\n|T^1$\u0001\u0017P[(&\u0006(\fG*-m";
      j[23] = " l#\u001b\t\u001fe**\u0012o[\u001c**_^\u0015|/|\u001a\u0011$";
      j[24] = "(/\bE<Hi:VWL\u0016BsP\u0006sGBH\u001c\u000br\u0002hxVKu";
      j[25] = "-?\u00079\tDr!\fY桼桠桚厍桯厚厦伤伞厍vc\u0019\u001a37\u001f+Y\u0006<";
      j[26] = "tgJ\u001a\u0016=+yAz伧栙叙叕栢厹伧佝叙栏;K@j+hIA\u0015j}";
   }

   @EventTarget
   public void a(PacketEvent event) {
      long a = 友树树树友友树何树树.a ^ 94857693445528L;
      long ax = a ^ 72749328805707L;
      long axx = a ^ 70682510950526L;
      long axxx = a ^ 21283951841266L;
      long axxxx = a ^ 107985231458422L;
      long axxxxx = a ^ 13927589318989L;
      c<"ê">(6225828650848934144L, (long)a);
      if (!this.w(new Object[]{ax})) {
         if (event.getPacket() instanceof ServerboundInteractPacket wrapper
            && WrapperUtils.Y((long)wrapper, (ServerboundInteractPacket)axxxx)
            && c<"H">(this, 6224164819025371584L, (long)a)) {
            c<"O">(this, false, 6224164819025371584L, (long)a);
            int slot = -1;
            int i = 0;
            ItemStack stack = mc.player.getInventory().getItem(0);
            if (stack.isEmpty()) {
            }

            if (stack.getItem() instanceof SwordItem && !友何树何友树友树何何.L(axxxxx, stack)
               || stack.getItem() instanceof TieredItem && c<"H">(this, 6225784908397035248L, (long)a).getValue()) {
               double damage = 友何树何友树友树何何.p(stack, axxx);
               if (damage > 0.0) {
                  slot = 0;
               }
            }

            i++;
            if (slot != -1) {
               if (c<"H">(this, 6225394144585559956L, (long)a).getValue()) {
                  PacketUtils.v(new Object[]{axx, new ServerboundSetCarriedItemPacket(slot)});
                  c<"O">(this, c<"H">(this, 6225652517020114628L, (long)a).getValue().intValue(), 6226210167607018108L, (long)a);
               }

               c<"O">(mc.player.getInventory(), slot, 6225494311511781372L, (long)a);
               c<"H">(mc, 6226117929422816403L, (long)a).tick();
            }

            if (c<"H">(this, 6226036581292801125L, (long)a).getValue()) {
               c<"H">(mc.player, 6225685379878602211L, (long)a).send(event.getPacket());
               event.setCancelled(true);
            }
         }
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void R(LivingUpdateEvent event) {
      long a = 友树树树友友树何树树.a ^ 58623051946016L;
      long ax = a ^ 36553339849459L;
      long axx = a ^ 38886445540806L;
      c<"ê">(-5485677671071597384L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"H">(this, -5485505034180057148L, a) > 0) {
            if (c<"H">(this, -5485505034180057148L, a) == 1) {
               PacketUtils.v(new Object[]{axx, new ServerboundSetCarriedItemPacket(c<"H">(mc.player.getInventory(), -5486223258914190780L, a))});
            }

            c<"O">(this, c<"H">(this, -5485505034180057148L, a) - 1, -5485505034180057148L, a);
         }
      }
   }

   private static String HE_SHU_YOU() {
      return "何树友被何大伟克制了";
   }
}
