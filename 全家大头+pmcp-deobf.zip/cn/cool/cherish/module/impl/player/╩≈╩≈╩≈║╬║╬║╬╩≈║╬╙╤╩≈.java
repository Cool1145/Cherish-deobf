package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.友何何何何友友何友友;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import cn.lzq.injection.asm.invoked.render.RenderPickEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class 树树树何何何树何友树 extends Module implements 何树友 {
   public static 树树树何何何树何友树 树友树何树何何树何友;
   private final ModeValue 友树树何友友树树友何 = new ModeValue("Mode", "模式", new String[]{"Normal", "Instant"}, "Normal");
   private final BooleanValue 树何友友友友何何何何 = new BooleanValue("Bed", "床", true);
   private final BooleanValue 何树友何树何友友树树 = new BooleanValue("Keep Break Progress", "保持破坏进度", true);
   private final BooleanValue 树友树树友友何何友友 = new BooleanValue("Cancel Velocity", "取消击退", true);
   private final BooleanValue 何树何树何树友何友树 = new BooleanValue("Through Walls", "穿墙", true);
   private final BooleanValue 何何友树树友友树友树 = new BooleanValue("Empty Surrounding", "土地平旷屋舍俨然", false);
   private final BooleanValue 友友树何友树树树友何 = new BooleanValue("Rotate", "转头", true);
   private final BooleanValue 何何树何友友友友树友 = new BooleanValue("Important Rotations Only", "仅重要转头", true);
   private final BooleanValue 树树友树何树何友树树 = new BooleanValue("Whitelist Own Bed", "不挖自己的床", true);
   private final BooleanValue 友友何友何友何友友友 = new BooleanValue("Slow Down In Air", "空中减速", true);
   private final BooleanValue 树何友树树友何树树何 = new BooleanValue("Without Attack", "不攻击时破坏", true);
   private final BooleanValue 友友何树树何树树何何 = new BooleanValue("Visual", "可视化", true);
   private final 树友何何树树何友友何 树友树树友树友何友友 = new 树友何何树树何友友何("Color", "颜色", Color.RED);
   private final NumberValue 树树友何何何友何树友 = new NumberValue("Progress Alpha", "进度透明度", 0.5, 0.1, 1.0, 0.1);
   private BlockPos 树友何树树树何友何友;
   private BlockPos 友友友树友友友树何友;
   private Vec3 树树何何何友何何何何;
   private final 何友友何树何树何树友 何树何友何树何树树何 = new 何友友何树何树何树友(51913986529303L);
   private boolean 友树友友树友友友友友;
   private float 何树何树友树树友友何;
   private Rotation 树友友何何树友友树树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[74];
   private static final String[] l = new String[74];
   private static String LIU_YA_FENG;

   public 树树树何何何树何友树() {
      super("Breaker", "自动挖床", 树何友友何树友友何何.友树树友何友何树友树);
      树友树何树何何树何友 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(843920283304581537L, 5253814947788397206L, MethodHandles.lookup().lookupClass()).a(184104207140274L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(79723034994257L << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[33];
      int var12 = 0;
      String var11 = "Å§-¡ÜÇ{c¥\u001f\u008e\u0082\u009e¦ÿ\"\u0010ò\u0085\u009fKäg\u0099Añ\u009c\u0099ªù!l\u0096\u0010\u00052â\u0084{c¦Ï\u001e\u0014V\u0005\u001a\u0010\u009c\u000e\u0010ýaz\u00ad¤Kõ\u00ad\u0002ÅCò\u0097Yå\t \u0005\u00862\u0099/c0\u001få\u0080\u009ecë¬\u009aÆ\u0089`\u008c±\u0086\u00066¢b\u0016ûq\u0002Ý#\u008d\u0010s?Ü\u0085\u0092\u009bkÍ¬?Á'\u008du¹v J\u0093»xP¥óx|\u0091\u0091H¡ï\u0012\u009c2RÍc\u0085A\u0017¤ß'd\u001f©\u0097Ï\u00068\u000f÷\"\u009656ðU\u0013^jL\u0085\u001fàqlü\u0089ÊE\u0007-v×Y7\u0097«§\u0018¸\u000e \u001aÝÐ\u008f\u0003Ò¡<@f!/X/Áé®ÑUp\fO ÅÒÝÆ\u008cn\u0086õ52\u007f\u0084bß\u0083D»ª\u0099¿\u008aÕ\u0080¬\u0013FZ\u008a\u0017\u0016\u00875\u0010ÆU\u0004\u0085rY}³a0\u0088\u0086\u0015´'ù(Å$\u0084½JÜk\n\u0011yõ\u000fgV\bÙDòI}õãÞô¤³\u0005?DÔ;\u008a@Æe^pã4f0\u009f\u0082\u008f¦'\u008b\u009e\u0098o¡ì\u001bþ\u0098¥çÛ{h äxmÖÔºâ\u001aÁF1Y<RÂ\u0099á#;¾ïtÝ\u001cùÏ^\u0099 ;$q\u001f³\u001aÉÜ\u009fGÞõ\u0005ÏÎ*¥Ê§à\u009b/²Î\u001b1ËV>þ\b®(µ\u001fÂÙ×yêK¥ý,@ßÃ}âë\"\u0090R¸8']Ý\u0011\u009eß\u0080ºsûÄ½Êm\u0093\u008b~³\u0018p-Ú£Ý¶ìsMz\u008a\rÀ\u0097ÎH\u0090WZÂ\u000fRy;(×ùÖÓFiÀ\u001fU\u000b\u009f%ß}9ü\u0007\u00adW¦\r\bN/òÄWõùÚÅ\u0010\u008aÄP:ùh±®\u0010wS¬\rS\u009f\u000eî\u0093\u0000Ø\u0099nÔ\u0018U\u0010\u0093özñü'º°\fÖÀ¦¹åÇÈ\u0018#G\u008429{\u009d=öý¹\bü\u0016\u0082qÌ\u009e{ôÖ·åË\u0010²©Â\riíj)e\u009c ä\u001d¨¦\u008503ÍÂZióDt_\u0080bZ\u0091î\t\u0019t?S:_>B\u0080K\u0098rAÝ]âÖ\u0086ÇPù×ýà\u0013¢ÅÄ¦é\u0080tô\u0010\u0003woÕÝ\u0085ÕN\t\u0090© ý!úP \\\u0016\u0010\n\u00845\u008aÒÙ\u000b'·Åð6Ô±\u001d\u0010T\u008c\u0005´M*å>\u009aà?½-\u00105èäT×\u0018Ñ\u0013¸Û:¸ð\u0016\u0088q\u0018¨ÙôÄ\u009fÊòË\u0093bF}å\u007f5£â\u0085ó\u0088,Ïïõ\u0010Ì\u0099\u0015*¨_ü\u0089Â°\u0011\u0083dÂ\u008f.(ö4\u0014¸¹\u007f\u0089î/En\u0014\f\u0004§s{J<ª-¡U\u0085ê¹\u0012wSÄ«Øüò3\u0013<\u0013\u0005«\u0010*tQ2\u001f\u0001²õâG©À\u0014³÷\u0081 m\u008eÑ7\u0098s\u001c²»¼\u0012X\u008d\u009d½Å·\u001büÎ}ØµZ\u0005ÄÄòtíX¯\u0010\u008eÒú\u0019|×\u001cÂ,ëóY\u008f\u0004+à(f\\Dýú\u0017\u008cnþÑÁ%%\u000eI\u0018«·ô\u0080g\u0003Q\u008fÎ-\u0082\u0091);¶þ\u008d¢û6\u0087\u0084_\u009b";
      short var13 = 870;
      char var10 = 16;
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[33];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(79723034994257L << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-91, -117, -27, -38, 68, 71, -37, 77});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "PX\u0083j¿(g7ã^bp¨\bí´b%¼I~\u0088\u001cS.\u008f\u009dlY/\u0088\u0087\u0085¿dG\u007f&_h ´ðA\fÃ@m´¶á\u000b\u0012µ£t¢¢\u009b©\u007fÎøfgíÁ\u001d*hßõù";
                  var13 = 73;
                  var10 = '(';
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   private double F(BlockPos pos) {
      return mc.player.position().distanceTo(Vec3.atCenterOf(pos));
   }

   private void Z() {
      mc.options.keyAttack.setDown(true);
      this.友树友友树友友友友友 = true;
      this.何树何树友树树友友何 = Math.min(1.0F, this.何树何树友树树友友何 + 0.05F);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 20;
               case 1 -> 18;
               case 2 -> 58;
               case 3 -> 15;
               case 4 -> 1;
               case 5 -> 14;
               case 6 -> 54;
               case 7 -> 50;
               case 8 -> 48;
               case 9 -> 26;
               case 10 -> 27;
               case 11 -> 23;
               case 12 -> 42;
               case 13 -> 22;
               case 14 -> 45;
               case 15 -> 30;
               case 16 -> 13;
               case 17 -> 19;
               case 18 -> 53;
               case 19 -> 59;
               case 20 -> 8;
               case 21 -> 33;
               case 22 -> 60;
               case 23 -> 32;
               case 24 -> 34;
               case 25 -> 38;
               case 26 -> 16;
               case 27 -> 7;
               case 28 -> 25;
               case 29 -> 24;
               case 30 -> 6;
               case 31 -> 39;
               case 32 -> 35;
               case 33 -> 55;
               case 34 -> 57;
               case 35 -> 44;
               case 36 -> 12;
               case 37 -> 49;
               case 38 -> 28;
               case 39 -> 3;
               case 40 -> 17;
               case 41 -> 9;
               case 42 -> 46;
               case 43 -> 21;
               case 44 -> 51;
               case 45 -> 5;
               case 46 -> 31;
               case 47 -> 36;
               case 48 -> 47;
               case 49 -> 43;
               case 50 -> 4;
               case 51 -> 61;
               case 52 -> 0;
               case 53 -> 56;
               case 54 -> 40;
               case 55 -> 63;
               case 56 -> 11;
               case 57 -> 10;
               case 58 -> 62;
               case 59 -> 29;
               case 60 -> 2;
               case 61 -> 52;
               case 62 -> 37;
               default -> 41;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private void b() {
      c<"H">(-5838827254001968616L, 42810905505526L);
      if (c<"ø">(this, -5838598744767690764L, 42810905505526L) != null) {
         c<"ø">(this, -5837801883724410906L, 42810905505526L).getValue();
         boolean wasOnGround = mc.player.onGround();
         mc.player.setOnGround(true);
         String var6 = c<"ø">(this, -5837873108516532972L, 42810905505526L).getValue();
         byte var7 = -1;
         switch (var6.hashCode()) {
            case -672743999:
               if (!var6.equals("")) {
                  break;
               }

               var7 = 0;
            case -1955878649:
               if (var6.equals("Normal")) {
                  var7 = 1;
               }
         }

         switch (var7) {
            case 0:
               this.E();
            case 1:
               this.Z();
            default:
               mc.player.setOnGround(wasOnGround);
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8145;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树何何何树何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[V¯r\u008dÂ`\u0003\u00ad, {²=£Ü¿«û, ÉJîò%Pø\u009c, »\u007f\u0080ß¥úïâ, ö\u00ad\u0005\u0011\u008f{Á\u000b¯\u008eNØ\u0089\b\u0092Ú, \u0083ÞÛ&fß\u008aÅ, ±í\u0018\u009d,ÎOÉ\u0083\u001fÀ56Ò\u0087j, \u0019æ\u0011ñ+¥ï»éG·Í$\u0091\u009dù\u009cØ\b&´\u0080éÔ42Ê\u001eO\u001d~\u001a, \u0081î\u0099¥ª9ôDwp«\u0006\u0099éP\u0080, \t\u0000OÇ\u0004'òØ, \f\u0019×è¹Æ,Ë\u00056[Q5\u00805\u0096\u008b\u0084\u0089")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树何何何树何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private void c() {
      this.树友何树树树何友何友 = null;
      this.树友友何何树友友树树 = null;
      this.何树何树友树树友友何 = 0.0F;
      this.友树友友树友友友友友 = false;
      this.何树何友何树何树树何.D(11747522392279L);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 248 && var8 != 214 && var8 != 'O' && var8 != 'y') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 232) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'H') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 248) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 214) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'O') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树何何何树何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @Override
   public void h() {
      树友何何友何树何树友.E();
      this.c();
      if (this.友树友友树友友友友友) {
         mc.options.keyAttack.setDown(false);
         this.友树友友树友友友友友 = false;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private boolean a(BlockPos pos) {
      return false;
   }

   private static void a() {
      k[0] = "N\u0014Q/(qN\u0014Fs$~T_Rn7tD_Ui<k\u000e'@bv";
      k[1] = double.class;
      l[1] = "java/lang/Double";
      k[2] = "\fD\"*-)\u0003\u0004o!'4\u0006Ydg/)\u000b_`,l/\u0002Z`g2*\u000eSi;l桗厤使余厂众桗伺栻叇";
      k[3] = ".TP'_\"\u001aw_g\u0012)\u0010jZ:\u0019o\u0018wW<\u001d$[U\\-\u0004-\u0010#";
      k[4] = "lKZr }c\u000b\u0017y*`fV\u001c?\"}kP\u0018ta{bU\u0018??~n\\\u0011ca栃栞栴伡佄会栃佚叮桥";
      k[5] = "&\u007f9\u0001.C&\u007f.]\"L<4.@1OfX!@ A\u0018u>";
      k[6] = "Y\u000feV\u001aqVO(]\u0010lS\u0012#\u001b\u0003\u007fV\u0014.\u001b\u001csJ\rew\u001aqV\u0004*[#\u007fV\u0014.";
      k[7] = "]s~1\u0019.R33:\u00133Wn8|\u0000 Rh5|\u001f,Nq~桃厽伔佫栌桁伇厽厊佫";
      k[8] = float.class;
      l[8] = "java/lang/Float";
      k[9] = "NQ\u001bh+mNQ\f4'bT\u001a\f*/aN@A\u000b/jEW\u001d' p";
      k[10] = "L~f*\u001a\u000eL~qv\u0016\u0001V5qh\u001e\u0002Lo<v\u0012\tF~`a\u0005Iez\u007fa%\u0002L\u007fwv\u0012\u0015";
      k[11] = "\u001ca:el5\u0013!wnf(\u0016||(u;\u0013zq(j7\u000fc:Hv7\u001djfPb6\nj";
      k[12] = "y=\r!i%r2\u001cn\u0015<}(\u0012-\"\fk?\u001e03 |2";
      k[13] = "@Ih]p/@I\u007f\u0001| Z\u0002\u007f\u001ft#@X2<m2GCr\u0000";
      k[14] = "\u001a3gF1Z\u001a3p\u001a=U\u0000xp\u00045V\u001a\"=#9J97c\u00185]\u0013";
      k[15] = boolean.class;
      l[15] = "java/lang/Boolean";
      k[16] = "Ev\u000bhF7J6FcL*OkM%\\,OtV%A=Jh@y\u0007\nIlD\u007f@7H";
      k[17] = "A\u0017\u000e44YNWC?>DK\nHy.BK\u0015Sy伎叽叩伬栱伂桊佣栳厲";
      k[18] = "\u0010@\u000fe\u001bJ\u001f\u0000Bn\u0011W\u001a]I(\u0002D\u001f[D(\u001dH\u0003B\u000fK\u001bA\u0016x@j\u0001@";
      k[19] = "\u0003y;G\u001e?\u0003y,\u001b\u00120\u001928\u0006\u0001:\t2?\u0001\n%CT&\u001d!3\u001ei#\u001dW\u0002\u0014l*";
      k[20] = "E/S89\u0015X:\u000b\u001ax\u0018@<";
      k[21] = "G\u001a~va?HZ3}k\"M\u00078;c?@\u0001<p 桁佱县厛佀栟厛可伡伅";
      k[22] = "xWv\b#\bxWaT/\u0007b\u001clC:\u0016y@i\b>\u0013yFmE!\r8UcK+OEWpP+\u0013t]wH*1zS{C< uFkI 1wQiC:EWQvO!\u000f";
      k[23] = "L\u0017BoSoL\u0017U3_`V\\A.LjF\\\u007f/JcP\u0013U5WiL:W/Z";
      k[24] = "!+\u0000bN\u000b!+\u0017>B\u0004;`\u0017#Q\u0007a\n\u001d>F\u0001;'\u001b\"";
      k[25] = "F/|jQ\u0007F/k6]\b\\d\u007f+N\u0002Ldd!J\u000bDdj(S\rCdJ(S\rC9";
      k[26] = "1'\u0004(I11'\u0013tE>+l\u0007iV4;l\u001ccR=3l\u0012jK;4l2jK;4";
      k[27] = "c\u0014\u0002(9+c\u0014\u0015t5$y_\u0015j='c\u0005Xk!.y\u0018\u0006j5;h\u0003XK!.y\u0018&j5;h\u00031g9'@\u001e\u0012c";
      k[28] = "<pk_.J30&T$W6m-\u00124Q6r6\u00121I>g Now0j$H(J1K1U-V";
      k[29] = "\u001d\u0010'P0\u0014\u0016\u001f6\u001fQ\u001a\u001d\u00142E";
      k[30] = ".\u001e\u001eh{'y_\u001f=A伆栍似桻佑桘厘佉厢桻\f}kp\u0002\u0019c?\"*\u001d";
      k[31] = "\u0014yyw2\u001b\u0013cv\u007f\u000e|&U\\EBj!N^U_p0VCYM'\u0014yyw2\u001b\u0013cv\u007f";
      k[32] = "\u00133sS\u0000nDrr\u0006:栋佴厏双叴叹住佴休佒7\u0006\"M/tXDk\u00170";
      k[33] = "B;]b)&P{F?W\u0003j\u0019\u007fCW*U=B}48\u0015&\u001f";
      k[34] = "\u0013*Ym\"7F6^$\u0012gzx^$-3zI\u0006m.9\u0013;\u001el~l";
      k[35] = "z\u001cn~0\u0013h\\u#N=\\?L\u001f!\bk\u0005n|3HpX";
      k[36] = "E\u000f}X#H\u0012N|\r\u0019号厼厳栘叿叚号桦伭参<%\u000eB\t9]cL\u0001\u0015";
      k[37] = "D}@\u0001n2\u0013<ATT桗桧叁栥伸桍伓厽栛栥eh~\u001aaG\n*7@~";
      k[38] = "\u0018\u0012O\u001aw6OSNOM桓叡桴株厽桔厉使厮台~q:MRRC*w]\u0016";
      k[39] = "\u001d\u0002\u0014\"\u000bKJC\u0015w1栮古桤桱厅史佪佺厾厫F\r\u0007C\u001e\u0013)ON\u0019\u0001";
      k[40] = "W\u0003ZccR\u0000B[6Y叭厮桥佻叄桀样桴县佻\u0007e\u001e\t\u001f]h'WS\u0000";
      k[41] = "\b4}\u0012'd_u|G\u001d栁叱厈作伫栄叛叱桒栘vw%Y \u007f\n`(\f*";
      k[42] = "e\u0011\b[h80\r\u000f\u0012Xh\fC\u000f\u0012f=\fr\tN?i'\u0018LE)=";
      k[43] = "}\u000e\u0018\\<,oN\u0003\u0001B\u0003U) =-7l\u0017\u0018^?wwJ";
      k[44] = "\u000f+rDT\u0000Xjs\u0011n桥栬伉体佽厭伡佨伉体 \u0007\u0011V&aF\f\u0010\\";
      k[45] = "\b\u0014\nN\bq\u0003\u0015\u0000<\t@QCU\f_@a\b\u000b\u0005\u0015h\u0001\u0010\u0012E";
      k[46] = "\u001a\u0017m*eo\u0019\u0001ijT叝桮桾厓佊厗佃桮厤桉\u00179nJZaf:xN\u001a";
      k[47] = "{\u0016bL{A,Wc\u0019A栤桘厪佃併伜叾伜桰叝(q\r'\u0005wW0D?R";
      k[48] = ":\u0007[$\fumFZq6`\u0000HW0Yvy\u0003B-K\t0\bW/Ip{\u001dJ=6";
      k[49] = " \u0000{ ?-'\u0007v8FY\b)R\u0006F\u007f\"\f|<xx%\u0001d";
      k[50] = "oiH3\u0002 8(If8企桌叕佩桎佥原厖栏栭W\u0004l1uO8F%kj";
      k[51] = "a\u0001S\u0007Ze?\u0007\u000b\u0017a6\u0007[UNPf\u0007j\u0006F\fg<SU\u0010\r)";
      k[52] = "\"j&T \t)k,&!8{=y\u0019~8Kv'\u001f=\u0010+n>_";
      k[53] = "!P\nmWzv\u0011\u000b8m佛但召桯栐厮叅栂召桯\tQ6\u007fL\rf\u0013\u007f%S";
      k[54] = "Yqf\u0016\t\"\u000e0gC3厝桺栗佇厱台桇桺反佇rX>Rc{N\u000b`\n6";
      k[55] = ",Rn.pd{\u0013o{J叛叕佰发众厉佅叕叮发Jv(rNi%4a(Q";
      k[56] = "\u0019\ti,\u000e\u001c\u0012\bc^\u000f-@^6nX-p\u0015hg\u0013\u0005\u0010\rq'";
      k[57] = "eV:}(%5\u0014;qY\u0013\\\u0015f4\".,\u001fopf^";
      k[58] = "3wvs~>6&laG\u0017\u0015\bTG\u0007\u001b\u001a\u0005\u0012\u007fy6?p~z(,-";
      k[59] = "VZQhWVOB\\=-Aa\u0000\u001bj\u0014\u0011a=BjN@H\rB#KQ";
      k[60] = "m\u0011@\u0012r\u0004:PAGH桡厔伳栥桯桑伥厔伳叿vtBj\u0017\u0004\u00172\u0000)\u000b";
      k[61] = "t+_E\u0017D#j^\u0010-叻厍伉栺核佰校桗伉佾!\u0011\b*7XNSAp(";
      k[62] = "CR=|!JQ@#?K|cuCm XRS/\u007f2F\u0011";
      k[63] = "\u0013-\u000fI\\j\u0001m\u0014\u0014\"T$U\u001eP\\h\u00026\f\u0010G5";
      k[64] = "sz\u001e;R\u0015a:\u0005f,)QY<ZC\u000ebc\u001e9QNy>";
      k[65] = "\u001a\u00074[\u0007zMF5\u000e=叅根去压栦叾叅口去压?T|I\nyMCy\u0019\u0004";
      k[66] = "d\u0000=j)\u001a3A<?\u0013桿厝桦伜栗低伻桇伢厂\u000e)\u0019\"\u001b{r~X#N";
      k[67] = "K*\n<=\u0007L0\u00054\u0001`y\b-\u0005Vwh\u001a+\u0003Fjr\u000b3\u001eJx%/\u001c$d\u0007\u0019(\u0006+l";
      k[68] = "{&(\u0016z0,g)C@休桘伄桍厱桙桕厂厚伉r}*8eeI1&{g";
      k[69] = "la\u000f\u0012AQ9}\b[q\u0001\u00053\b[OQ\u0005\u0002\u0000\bM\u001ei?^\u000e\u0015\u000e";
      k[70] = "\u001fJ\f\u001bVT\u0010Q\u0002_&N\u001aH\u0004\\GS\u001b4\u0007\u001dM_\u0003H\u0010\u0010\u0018U";
      k[71] = ".\fB*Bj<LYw<R\u0006)`\u000b<f9\n]5_ty\u0011\u0000";
      k[72] = "p_\u00109KJ'\u001e\u0011lq佫桓佽厯伀桨佫桓根伱]\u001bKz_\u0017`\b\b#\u0019";
      k[73] = "\ty\u0019\u001bH ^8\u0018Nr企佮栟伸厼厱原台栟厦\u007fNlWe\u001e\u0010\f%\rz";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private BlockPos k() {
      树友何何友何树何树友.E();
      if (!this.树何友友友友何何何何.getValue()) {
         return null;
      } else {
         List<BlockPos> bedPositions = new ArrayList<>();
         int bedCount = 0;
         int x = -5;
         int y = -5;
         int z = -5;
         BlockPos pos = mc.player.blockPosition().offset(-5, -5, -5);
         Block block = mc.level.getBlockState(pos).getBlock();
         if (block instanceof BedBlock) {
            if (++bedCount > 1) {
               double distance = this.F(pos);
               label36:
               if (!(distance > 4.5)) {
                  if (!this.何树何树何树友何友树.getValue()) {
                     HitResult result = 友何何何何友友何友友.b(
                        69754157170270L, RotationUtils.O(134222166779889L, Vec3.atCenterOf(pos)), 4.5, 0.0F, mc.player, null, false
                     );
                     if (result.getType() != Type.BLOCK) {
                        break label36;
                     }

                     BlockPos hitPos = ((BlockHitResult)result).getBlockPos();
                     if (!hitPos.equals(pos)) {
                        break label36;
                     }
                  }

                  if (this.何何友树树友友树友树.getValue()) {
                     BlockPos resultPos = this.g(pos);
                     if (resultPos != null) {
                        return resultPos;
                     }
                  }

                  bedPositions.add(pos);
               }
            }
         }

         z++;
         y++;
         x++;
         return bedPositions.isEmpty() ? null : bedPositions.stream().min((a, b) -> Double.compare(this.F(a), this.F(b))).orElse(null);
      }
   }

   private BlockPos g(BlockPos bedPos) {
      树友何何友何树何树友.E();
      BlockPos targetPos = bedPos;
      boolean foundEmpty = false;
      int addX = -4;
      int addY = 0;
      int addZ = -4;
      BlockPos checkPos = bedPos.offset(-4, 0, -4);
      Block block = mc.level.getBlockState(checkPos).getBlock();
      if (block instanceof BedBlock) {
      }

      double distanceToCheck = mc.player.position().distanceTo(Vec3.atCenterOf(checkPos));
      if (distanceToCheck > 4.5) {
      }

      if (!this.L(checkPos)) {
      }

      if (block == Blocks.AIR || block instanceof LiquidBlock) {
         foundEmpty = true;
      }

      double eyeDistance = mc.player.getEyePosition(1.0F).distanceTo(Vec3.atCenterOf(checkPos));
      if (eyeDistance > 4.5) {
      }

      BlockState blockState = mc.level.getBlockState(checkPos);
      float destroySpeed = blockState.getDestroySpeed(mc.level, checkPos);
      if (destroySpeed > Double.MIN_VALUE) {
         double var10000 = destroySpeed;
         targetPos = checkPos;
      }

      addZ++;
      addY++;
      addX++;
      if (!foundEmpty) {
         return targetPos.equals(bedPos) ? null : targetPos;
      } else {
         return bedPos;
      }
   }

   @EventTarget
   public void g(Render3DEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && this.友友何树树何树树何何.getValue() && this.树友何树树树何友何友 != null) {
         PoseStack poseStack = event.poseStack();
         Vec3 cameraPos = mc.gameRenderer.getMainCamera().getPosition();
         double renderX = this.树友何树树树何友何友.getX() - cameraPos.x;
         double renderY = this.树友何树树树何友何友.getY() - cameraPos.y;
         double renderZ = this.树友何树树树何友何友.getZ() - cameraPos.z;
         poseStack.pushPose();
         poseStack.translate(renderX, renderY, renderZ);
         Color color = this.树友树树友树友何友友.getValue();
         Color progressColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(this.树树友何何何友何树友.getValue().floatValue() * 255.0F));
         友友何何友友树何何友.w(poseStack, new AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0), 135390467466526L, true, color.getRGB());
         if (this.何树何树友树树友友何 > 0.0F) {
            友友何何友友树何何友.w(poseStack, new AABB(0.0, 0.0, 0.0, 1.0, this.何树何树友树树友友何, 1.0), 135390467466526L, false, progressColor.getRGB());
         }

         poseStack.popPose();
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void q(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.X(this.友树树何友友树树友何.getValue());
         if (this.何树何友何树何树树何.A(50L, 118344821288830L)) {
            if (!this.a(this.树友何树树树何友何友) || this.F(this.树友何树树树何友何友) > 4.5) {
               this.X();
               if (this.友树友友树友友友友友) {
                  mc.options.keyAttack.setDown(false);
                  this.友树友友树友友友友友 = false;
               }

               if (this.树友何树树树何友何友 == null) {
                  return;
               }
            }

            if (this.友友树何友树树树友何.getValue()) {
               this.K();
            }

            this.b();
         }
      }
   }

   private void E() {
      PacketUtils.a(112543050219290L, new ServerboundPlayerActionPacket(Action.START_DESTROY_BLOCK, this.树友何树树树何友何友, Direction.UP));
      mc.player.swing(InteractionHand.MAIN_HAND);
      PacketUtils.a(112543050219290L, new ServerboundPlayerActionPacket(Action.STOP_DESTROY_BLOCK, this.树友何树树树何友何友, Direction.UP));
      mc.player.swing(InteractionHand.MAIN_HAND);
      this.树友何树树树何友何友 = null;
      this.何树何友何树何树树何.D(11747522392279L);
      this.何树何树友树树友友何 = 0.0F;
   }

   @EventTarget
   public void A(PacketEvent event) {
      树友何何友何树何树友.E();
      if (this.树友树树友友何何友友.getValue() && this.树友何树树树何友何友 != null) {
         if (event.getPacket() instanceof ClientboundPlayerPositionPacket) {
            Vec3 newPos = new Vec3(
               ((ClientboundPlayerPositionPacket)event.getPacket()).getX(),
               ((ClientboundPlayerPositionPacket)event.getPacket()).getY(),
               ((ClientboundPlayerPositionPacket)event.getPacket()).getZ()
            );
            double distance = mc.player.position().distanceTo(newPos);
            if (distance > 40.0) {
               this.树树何何何友何何何何 = newPos;
            }
         }
      }
   }

   @EventTarget
   public void X(RenderPickEvent event) {
      树友何何友何树何树友.E();
      if (this.树友何树树树何友何友 != null && !this.Q(new Object[]{52406761729175L})) {
         Vec3 eye = mc.player.getEyePosition(1.0F);
         Rotation rotation = this.何何树何友友友友树友.getValue() ? this.P() : RotationUtils.rotation;
         Vec3 rotationVector = RotationUtils.e(rotation, 50307048148560L);
         double range = mc.gameMode.getDestroyStage();
         Vec3 forward = eye.add(rotationVector.x * range, rotationVector.y * range, rotationVector.z * range);
         BlockHitResult hitResult = 友树友友树何树友树友.g(mc.level, this.树友何树树树何友何友, mc.player.getEyePosition(1.0F), forward);
         event.setHitResult(hitResult);
      }
   }

   private void X() {
      树友何何友何树何树友.E();
      if (this.树树何何何友何何何何 == null || !(mc.player.position().distanceTo(this.树树何何何友何何何何) < 35.0) || !this.树树友树何树何友树树.getValue()) {
         this.友友友树友友友树何友 = this.树友何树树树何友何友;
         this.树友何树树树何友何友 = this.k();
         if (this.友友友树友友友树何友 != this.树友何树树树何友何友 && !this.何树友何树何友友树树.getValue()) {
            this.何树何树友树树友友何 = 0.0F;
         }
      }
   }

   private boolean L(BlockPos pos) {
      树友何何友何树何树友.E();
      Direction[] directions = new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.DOWN};
      int var7 = directions.length;
      int var8 = 0;
      if (0 < var7) {
         Direction direction = directions[0];
         BlockPos neighborPos = pos.relative(direction);
         Block neighborBlock = mc.level.getBlockState(neighborPos).getBlock();
         if (neighborBlock instanceof BedBlock) {
            return true;
         }

         var8++;
      }

      return false;
   }

   @Override
   public void M() {
      this.c();
   }

   public Rotation P() {
      return this.树友友何何树友友树树;
   }

   private void K() {
      树友何何友何树何树友.E();
      if (this.树友何树树树何友何友 != null) {
         if (this.何何树何友友友友树友.getValue() && this.何树何树友树树友友何 != 0.0F && this.何树何树友树树友友何 >= 0.99F) {
         }

         this.树友友何何树友友树树 = RotationUtils.O(134222166779889L, Vec3.atCenterOf(this.树友何树树树何友何友));
         RotationUtils.d(this.树友友何何树友友树树, true, true, false, 46171034731712L, 0.0F);
      }
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖大狗叫";
   }
}
