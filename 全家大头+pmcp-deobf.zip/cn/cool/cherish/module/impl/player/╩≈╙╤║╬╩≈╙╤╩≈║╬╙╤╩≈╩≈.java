package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.ui.何树友友何友友何树树;
import cn.cool.cherish.ui.树友何何何树友树何友;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.item.友何树树何树何何何友;
import cn.cool.cherish.utils.player.友友何树树友友树树树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import org.apache.commons.lang3.tuple.Pair;

public class 树友何树友树何友树树 extends Module implements 何树友 {
   public static 树友何树友树何友树树 树何友友树树何友友树;
   private final NumberValue 友友友树树友何树树树 = new NumberValue("Delay", "延迟", 75, 0, 500, 10);
   private final NumberValue 友树友树何友何树友友 = new NumberValue("Open Delay", "开包延迟", 1, 0, 10, 1);
   private final NumberValue 何树树树何何何树友友 = new NumberValue("Drop Delay", "丢东西延迟", 75, 0, 500, 10);
   private final BooleanValue 友友何何友友树友何何 = new BooleanValue("Auto Armor", "自动穿戴盔甲", true);
   private final BooleanValue 友友树何何何树何树何 = new BooleanValue("Throw Items", "自动丢弃物品", true);
   private final ModeValue 树树友友树友友何何何 = new ModeValue(
      "Offhand Items", "副手物品", new String[]{"Golden Apple", "Projectile", "Fishing Rod", "Block", "None"}, "Projectile"
   );
   private final ModeValue 何树友树树何树树友树 = new ModeValue("Bow Priority", "弓箭优先级", new String[]{"Crossbow", "Power Bow", "Punch Bow"}, "Crossbow");
   private final BooleanValue 树树何何友友友何友友 = new BooleanValue("Inventory Only", "仅在背包中", true);
   private final BooleanValue 友何友树友树树树友树 = new BooleanValue("Fast Throw", "快速丢弃", false);
   private final NumberValue 友树友何友友何树树树 = new NumberValue("Max Eggs & Snowballs Size", "最大鸡蛋和雪球数量", 64, 16, 256, 16);
   public final NumberValue 友友树友树树何树树何 = new NumberValue("Max Block Size", "最大方块数量", 256, 64, 512, 64);
   private final NumberValue 树何何树树何友友友友 = new NumberValue("Max Food Size", "最大食物数量", 128, 32, 256, 32);
   private final NumberValue 何友何友何树树树何友;
   private final NumberValue 树何友友树何树友树友;
   private final NumberValue 树树友何树何树友树友;
   private final NumberValue 友友友树何树何友友何;
   private final NumberValue 友树何树何友何友友树;
   private final NumberValue 友树何何友树友何树何;
   private final NumberValue 树友何树树树友友友树;
   private final NumberValue 何树树友友友友友树何;
   private final NumberValue 何友何友树何友何树树;
   private final NumberValue 何友何树树友何何何何;
   private final NumberValue 友友何友友友何何树友;
   private final NumberValue 何何何何树树友友树树;
   private static final 何友友何树何树何树友 何友树树树树树何友树;
   private boolean 友树友友树何何树树何;
   private boolean 友友何友何友何友友树;
   private int 友何友何友友友友树友;
   private int 友何何何树树友树何友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[90];
   private static final String[] k = new String[90];
   private static int _我是何树友 _;

   public 树友何树友树何友树树() {
      super("InventoryManager", "背包管理", 树何友友何树友友何何.友树树友何友何树友树, 66);
      树友何何友何树何树友.E();
      this.何友何友何树树树何友 = new NumberValue("Max Rod Size", "最大鱼竿数量", 1, 1, 16, 1);
      this.树何友友树何树友树友 = new NumberValue("Sword Slot", "剑槽位", 0, 0, 9, 1);
      this.树树友何树何树友树友 = new NumberValue("Block Slot", "方块槽位", 0, 0, 9, 1);
      this.友友友树何树何友友何 = new NumberValue("Axe Slot", "斧槽位", 0, 0, 9, 1);
      this.友树何树何友何友友树 = new NumberValue("Pickaxe Slot", "镐槽位", 0, 0, 9, 1);
      this.友树何何友树友何树何 = new NumberValue("Bow Slot", "弓槽位", 0, 0, 9, 1);
      this.树友何树树树友友友树 = new NumberValue("Water Bucket Slot", "水桶槽位", 0, 0, 9, 1);
      this.何树树友友友友友树何 = new NumberValue("Ender Pearl Slot", "末影珍珠槽位", 0, 0, 9, 1);
      this.何友何友树何友何树树 = new NumberValue("Golden Apple Slot", "金苹果槽位", 0, 0, 9, 1);
      this.何友何树树友何何何何 = new NumberValue("Eggs & Snowballs Slot", "鸡蛋和雪球槽位", 0, 0, 9, 1);
      this.友友何友友友何何树友 = new NumberValue("Slime Ball Slot", "粘液球槽位", 0, 0, 9, 1);
      this.何何何何树树友友树树 = new NumberValue("Crystal Slot", "水晶槽位", 0, 0, 9, 1);
      this.友树友友树何何树树何 = false;
      this.友友何友何友何友友树 = false;
      this.友何友何友友友友树友 = 0;
      this.友何何何树树友树何友 = 0;
      树何友友树树何友友树 = this;
      Module.V(new Module[3]);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(5668287650787737953L, -563633641502164501L, MethodHandles.lookup().lookupClass()).a(140067114415817L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(110718170237397L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[67];
      int var5 = 0;
      String var4 = "uñ¬\nAc\u007ft}§ü\u0013\u0080\rKJÓ\u0084øÓtÊ¬%¬\u009e+¦\b×®á\u0018\u0014rÂF\u00848m¡\u001ftK}®\b)za¶*\u0098\u0000-¢« \u0084W¨ª@¯ë\u0098\u0087\u0017NÂ\u0007C6\u0096\u0095<-ûjèo®fÖÞo\u0093²ÇÜ 7\u0004\u001b\u0011J(Ö\u0015¦^-\u0080'\u008e\u0084÷\u0001À\u009bõÿ\u000ff¿;Â\u0000]|°\rY\u00188\u009bÂò\u0018j@Öíg\\àT\u008aiN\bx-N£Ó[K\u0018¡ß?\u009bH\u0098\u0014Ûè\u0098&dI\u0014_·Ò\u0007Í\u0094\r¸µ\u0088(6¸\u0083ñÞ )\u0081¯p¼\"\u0017\t =¶Ñ\u0005ÈÌ\bUÂ\u0095/Ö \u008cß¸\u0097äGr8uk\u0093?\u0018;¥nZ\u0096§8\u0097\u009d5ï5\u0013PÓ\u0000ÑÄ¦\fe=.\u0086 \u008b|\u0083á~üpÌ\u0082\u0011m\u0004<µy#¦ÏN\u0017}ô@D\u0018\u000b\u0095ûééc\u0017\u0018\u0095m.)\bCàî²)H\u0082kLÐª\u0093^E\u009d¸^Ú¶ ±\u009c¹jx\u0005\u000b\u0099·ê\u009aé'Ò;*8\u0005½\u0083\u000blÔ/\u001dàJà\u0003¡\u001d\u009b\u0018kZY}\"\t\u0080MM\u000f,¦ê\u0094ãtÙ\u0086:â\u009eu~\u0091\u001898\u0002\u00adçÖ{\u0089\r3\u009e-g\u0097\u0083¸QÔä\u0011e\u001e×\u0091\u0010rÙÐäÏb?ÕwsõRÊ¤\u009eH\u0018Y\u0093¿gþ^Ì°'\u0088zc³<B\u000eÄ¥å\u0091øÒP\u001c('U\nßµ©Wv´5c \u0003Ö0\u008câì¹`\t¹]¯¿n¥Å»F\u0085\u0095J5>Æ\u0087<âj mNòNÇ\u009f°ækäÏQ^5Ãý½éïûÊ¼þ>(T\u009f\u0083\u009cÙ4R\u0018rWæ\u0001\u001fáä[¾ã\u008cIòAÉÐ\u0000\u009c¥\u0018å\u0005ÿu \u008bÄäÜ2\u0006á\u0080\u0014g»¤ÿWÞ±ÐDt@Á\u0002ßú$\u007fk\u0001r:ÚF \u0014±FöÃ\u0090z\u0011\u0094+\u0088°-S*êh\u008eÓíq\u009aXüv\u0088 \u001e-¶@Ê \u001e¦uç©ÖÕ¿jFìº\u008buw8\u0001T(\u0080\u008a~î·\u0007\u0090»\u0011?\u009a¾\n\u0018ÿ\"Ñ\u0011ÙL¢\u001a\u0088:Å¶\u0019\r¯aÄ\u007f\u0002¦Ò\u0093Å¬(Oá\"í\u0093 £U\u0086¼\u000f\u009a\u0089G%ú3¯û\u009f~\u0090Õ\u009cð%ù¾2é\u0019y\u0014Î¥\u008e;ø\"\b \u0097\fî\u000b>× <ù\u0006[\u009a\ná¡Ï\\|0Û!Ì\u008c23r\u009aïõ\u008a\u009d0 \u0086\u009aKïk¦-\u0085¬ l\u0016\nÁ][ÃYÛ·V]Í$%>£Ö0ü¿R ;Ï·¸ \u008d¤&\u009fñ\u0083\u0014\u0084íÜ\u009d6²\u0099oÙ!\u0094½õ\u0010À=´\u009f¤À(Î\u0013Êxà\u008cxn,!,\u0081Ý3ÍCfï®ÀÔ\u0007\u0013\u0097.CèGÅ\u001eAf\u0092èx<³\u008bºÇ üS\u0096¹\u008aÆÜ\u0099¬à¼\u0000\u000fòU¾ooø\u0019ÿ`DêÚõS\u000bk \u0014<\u0018â*L{3'æ4\u001fÍ½h\u009bÓò{<\u0010Ç¸÷¿ïÕ0©êÊ7¸óõ<©Fm;ö\u0098\u0082§\u009cº\u001a~¿_¬\u001af¯\u0010ôP\u009d<¾\u001a2W\u001c\u0017~\u008dºNíæØW«ÄØ )Ð¶¨é5¤\u000f©\u0000ãn93\u0093~ì]Èdc\u0095\u0002y\u008d3Å~NyÑ\u0015\u0010F¡²ÿ\u0016!\u0088ÝÙÝ/äÔÒª`(T\u0001(Q\u0004¶]øWRù ß°Ä@Ü^±´ÞK4NX\u008e¿N´]¤²\u00ad\u009dJ!\t\t4ê\u0018\u0082¤[Ò¶RÔ2-É2\u0011òBªFÀ\u0086Ô0É*\u0011ü\u0018\u007f\t¥\u0006Vå\u0081º<z\u008fòà2[m:\u0000ï¦Ý\u009bÇä \u009cÅI-¤¦+võ&C\u001aG§\u001dA\r\u00185@w/J\u0004·=úb;+6Ù(Ò3u\u001cÛ\u009cÍ1\u00194ÕZ\u009fzD9\u0094Ú2\u0010ík=\u0092éÍòx\u001a\u0086}ôîK]Ù\u0000ÃR\u0087 \u009b_¯3£\f³\u009e\u0014Ö\u001f«~r²\u00036¼$\r\u0003¸+¾\u0083¡NùýLr\u009b\u00104©å7\u0016\u00138è\u0016èp'\u0087\u008dû¹(\u00009\fks'r\u0014û\u0092ãZõô%¢ïõ\u008dÓ\u009f\tÇdÙ à-ùHg\u008fRþ)8²¹®° [c¡8®Þ¬8m\u009b»\u007ft\u009b9qS¿*{<g\u0003ôD*\u000bæþÚÆè NØM9»§\u001aCwª\u009eÈõSÆ[¥Çç\u000bªZW=¿\u008d¨5MØ\u0085\u0096 É\u001f\u0001ÇÚ¯B_ðÖ\u0099É\u008a\u001eàü¬äOq\u001a\u0092¼j~\u0084\fRS\u0087f\u008b \u0098æë\u0007Qv¦0+©B\u0092(óm½¸9\\üW\r'\u0095\"©'ß!\u0090\"¾ eh\u0003\u00816UÞ¹ö\u008f\u0014\\`EûUÜ\u000f!ÖQ+»\u009c¦øðYï;/e \u0011\u008c\u0081}P\u0090´¯4\u001bM®o¶t>,b#aÊ\u009f\u001bé\u0088B\u009c,Ø0\u0086P(\u0018¦Ý=\u0018!ÓØ»vB1[CvßzGþ³¥\u0081*Ý\u0082\u0080\u0090\u008c\u0014y\u009e;¾:\u0016\u0090h\u0095¹\u0084\u0010B9¡%ãdß\u0018tjé×1\u0006\"\n ÃÃÜùÁÙ\u0089Ä\u000fu®Þ0\u0017\u008e\\·6iOª\u0095\bÿ\u0002\u009c_Âq\u0019aR8Àr\u009ckÀ\u0084¨ÉJ±¬óCô®\u0098\u001fhn>>\u0004\u0081\u008f\u0080a\"ýrE\r\u0011\u0018G\u007f±÷\u0001\u0016\u007f\u0088ã\u009cÃóÞ^\u008bÐ\u001a8\u008bÇÜµ\u0099 'J|ÿs1§\u0002[O\u00ad\u0007ª\u008b¿\u001d¦Yÿ¦\noÝ-\u0089ÅÜ²¥h@² þ0p\u0010i\u0016CV\u0098.\u0095U\u0011©\\>j,HwÎÜ9±\u008emP²«Ø\u0094d\u0018\u0005ÇC(3Ñ?\u009b86\u001bQ¾Ì\u0089y\u0098¸ß\u0081<r\u0013\u0081(ûÙx6ìÜÂ\r\u0093Ö¶\u0080rå\u008a\u009cïz\u00039êT\u0090ï¤Ý\u0084\u0017(k\u009bs¶\u0003Ý\u0086ey!Q zt\u0092n\u0016yâ\u0088ò÷ÝûÍUÌ\u0011©[ã\u009c\u0096\u0007^U@LÏ£ìV¦} \u007f\u008a\u001f\u0005³wH\u00820\u0084Í®»Ã1Â¼\u0092Å¿ün\u008aw,\u0004][HR`)\u0018,\u008cÎ\u0019Ö\u009ekËQ~ËÝB\u0089û©>ç\u009e\u000bd|e; \u008fL~z\u0019R\u008dÓ\u00158\u000f\u0015í\u0098v\u001f\u001ee)N\u001cöÔ\u0007\u0000\rèâó\u0018ú¦ a MÕÉh\u0092\u0095Ö\u0087 ó ÃO¸\u000ei¸è+] ¼\u008cOr/ö1¿\u00ad ãÃ¤'U-àJ(\u0013Uò\u0012\u009c\u001dýöá\u0082[ìÞÈ\u000bÒ³l\u001bÑF¢ù0Îö*¯\u0092d£õÓX\u0014%¸B\u0015\u0012\u00adO\u00122\u0013Ü\u001aJá;Jyõ$·XSðÂ \u000fO\u0087éZX\u00adAÊ¬u-\u0010»£FfÔøN\u0085ü\u0092ù7âþá=\u0018ã\n\u001d°<UHnB¯\u0082±F\u00995\u0007ÉÍ\u0080þA\u0097ì\u00ad(\u0019¯ï n\u008d/v4¨\u0094\u009d\\³ýÅ\u0001à¯\u000f\u001e\u009d³\u0094\f\u001dL7¤í\u0094°jÄ\u0004í5 æ/ ,§{à\t1K\\æx\u0093mýsÞ7\u008a:\u0018\u0089\u0094Á\u0096\u0014=ÃëÅ*~òÞ";
      short var6 = 2072;
      char var3 = ' ';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = c(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     c = var7;
                     h = new String[67];
                     何友树树树树树何友树 = new 何友友何树何树何树友(51913986529303L);
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "\u0013\u0087AðtãÂ\u0092dS[Q\u0013C\u008dRo¸\u0088A¬Û\u000e5L\u0011y¥òr\f\u0018Íg?,\u000f÷*ù(®ò\u0016j_\u001142ÃÄ=BËÉT¸ËÐF¾Rõ\u0005¸J\u0096\u0003Ö\u0001Ä\u0011ô!\u0010T\u0095/fã4";
                  var6 = 81;
                  var3 = '(';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   private void J(ItemStack item) {
      树友何何友何树何树友.E();
      if (mc.gameMode != null && mc.player != null) {
         if (this.友友树何何何树何树何.getValue()
            && 友何树树何树何何何友.e(11871436426037L, item)
            && (何友树树树树树何友树.A(this.何树树树何何何树友友.getValue().intValue(), 118344821288830L) || this.友何友树友树树树友树.getValue())) {
            int itemSlot = 友何树树何树何何何友.V(item, 53473195738333L);
            if (itemSlot != -1) {
               if (itemSlot < 9) {
                  mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, itemSlot + 36, 1, ClickType.THROW, mc.player);
               }

               mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, itemSlot, 1, ClickType.THROW, mc.player);
               this.友树友友树何何树树何 = true;
               何友树树树树树何友树.D(11747522392279L);
            }
         }
      }
   }

   private void V(int slot) {
      树友何何友何树何树友.E();
      if (mc.gameMode != null && mc.player != null) {
         if (slot < 9) {
            mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, slot + 36, 40, ClickType.SWAP, mc.player);
         }

         mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, slot, 40, ClickType.SWAP, mc.player);
         this.友树友友树何何树树何 = true;
         何友树树树树树何友树.D(11747522392279L);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 49;
               case 1 -> 60;
               case 2 -> 39;
               case 3 -> 24;
               case 4 -> 20;
               case 5 -> 1;
               case 6 -> 25;
               case 7 -> 52;
               case 8 -> 4;
               case 9 -> 57;
               case 10 -> 13;
               case 11 -> 17;
               case 12 -> 45;
               case 13 -> 56;
               case 14 -> 0;
               case 15 -> 29;
               case 16 -> 15;
               case 17 -> 9;
               case 18 -> 32;
               case 19 -> 21;
               case 20 -> 31;
               case 21 -> 30;
               case 22 -> 48;
               case 23 -> 51;
               case 24 -> 46;
               case 25 -> 7;
               case 26 -> 23;
               case 27 -> 16;
               case 28 -> 54;
               case 29 -> 55;
               case 30 -> 63;
               case 31 -> 26;
               case 32 -> 11;
               case 33 -> 37;
               case 34 -> 28;
               case 35 -> 14;
               case 36 -> 44;
               case 37 -> 27;
               case 38 -> 22;
               case 39 -> 2;
               case 40 -> 53;
               case 41 -> 6;
               case 42 -> 34;
               case 43 -> 8;
               case 44 -> 61;
               case 45 -> 36;
               case 46 -> 41;
               case 47 -> 18;
               case 48 -> 5;
               case 49 -> 3;
               case 50 -> 10;
               case 51 -> 43;
               case 52 -> 62;
               case 53 -> 19;
               case 54 -> 12;
               case 55 -> 47;
               case 56 -> 59;
               case 57 -> 40;
               case 58 -> 42;
               case 59 -> 35;
               case 60 -> 33;
               case 61 -> 58;
               case 62 -> 38;
               default -> 50;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   @EventTarget
   public void i(PacketEvent e) {
      树友何何友何树何树友.E();
      if (e.getSide() == Event.Side.POST && mc.player != null && mc.getConnection() != null) {
         if (e.getPacket() instanceof ServerboundContainerClosePacket) {
            this.友树友友树何何树树何 = false;
            this.友何何何树树友树何友 = 0;
         }

         if (this.友树友友树何何树树何 && !this.树树何何友友友何友友.getValue()) {
            if (e.getPacket() instanceof ServerboundMovePlayerPacket) {
               if (!友友何树树友友树树树.I(112951582722913L)) {
                  return;
               }

               mc.getConnection().send(new ServerboundContainerClosePacket(mc.player.inventoryMenu.containerId));
            }

            if (e.getPacket() instanceof ServerboundUseItemOnPacket
               || e.getPacket() instanceof ServerboundUseItemPacket
               || e.getPacket() instanceof ServerboundInteractPacket
               || e.getPacket() instanceof ServerboundPlayerActionPacket) {
               mc.getConnection().send(new ServerboundContainerClosePacket(mc.player.inventoryMenu.containerId));
            }
         }
      }
   }

   public static int b() {
      return 256;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友何树友树何友树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private boolean b() {
      c<"þ">(-5509622741639989591L, 10010808726402L);
      ArrayList pairs = new ArrayList();
      pairs.add(Pair.of(c<"U">(this, -5510080117717359512L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5510080117717359512L, 10010808726402L)));
      pairs.add(Pair.of(c<"U">(this, -5509894092707619631L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5509894092707619631L, 10010808726402L)));
      pairs.add(Pair.of(c<"U">(this, -5507296307746967258L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5507296307746967258L, 10010808726402L)));
      pairs.add(Pair.of(c<"U">(this, -5506092379132130250L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5506092379132130250L, 10010808726402L)));
      pairs.add(Pair.of(c<"U">(this, -5508826159151672153L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5508826159151672153L, 10010808726402L)));
      pairs.add(Pair.of(c<"U">(this, -5509173675217088408L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5509173675217088408L, 10010808726402L)));
      pairs.add(Pair.of(c<"U">(this, -5508129652997362716L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5508129652997362716L, 10010808726402L)));
      pairs.add(Pair.of(c<"U">(this, -5507558989227468252L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5507558989227468252L, 10010808726402L)));
      pairs.add(Pair.of(c<"U">(this, -5509781263197833227L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5509781263197833227L, 10010808726402L)));
      if (!c<"U">(this, -5505854383417999365L, 10010808726402L).K("")) {
         pairs.add(
            Pair.of(c<"U">(this, -5510871274070542800L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5510871274070542800L, 10010808726402L))
         );
      }

      if (!c<"U">(this, -5505854383417999365L, 10010808726402L).K("Block")) {
         pairs.add(
            Pair.of(c<"U">(this, -5509156313010039893L, 10010808726402L).getValue().intValue() != 0, c<"U">(this, -5509156313010039893L, 10010808726402L))
         );
      }

      Set<Integer> usedSlot = new HashSet<>();
      Iterator var6 = pairs.iterator();
      if (var6.hasNext()) {
         Pair<Boolean, NumberValue> pair = (Pair<Boolean, NumberValue>)var6.next();
         if ((Boolean)pair.getKey()) {
            int targetSlot = ((NumberValue)pair.getValue()).getValue().intValue() - 1;
            if (!usedSlot.contains(targetSlot)) {
               usedSlot.add(targetSlot);
            }

            return false;
         }
      }

      return true;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13052;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树友何树友树何友树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[Ö\u0003 M³\u0083j0Ã£ÿ")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友何树友树何友树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'U' && var8 != 'Q' && var8 != 'I' && var8 != 196) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 213) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 254) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'U') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Q') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'I') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   public boolean l(ItemStack stack) {
      树友何何友何树何树友.E();
      if (stack.isEmpty()) {
         return false;
      } else if (友何树树何树何何何友.A(90513947799501L, stack)) {
         return true;
      } else if (stack.getDisplayName().getString().contains("")) {
         return true;
      } else if (stack.getItem() instanceof ArmorItem item) {
         float protection = 友何树树何树何何何友.X(stack);
         if (友何树树何树何何何友.o(87138280477963L, item.getEquipmentSlot()) >= protection) {
            return false;
         } else {
            float bestArmor = 友何树树何树何何何友.N(item.getEquipmentSlot(), 129159117886604L);
            return !(protection < bestArmor);
         }
      } else if (stack.getItem() instanceof SwordItem) {
         return 友何树树何树何何何友.T(52004926425717L) == stack;
      } else if (stack.getItem() instanceof PickaxeItem) {
         return 友何树树何树何何何友.t(57525699236832L) == stack;
      } else if (stack.getItem() instanceof AxeItem && !友何树树何树何何何友.r(124830374301047L, stack)) {
         return 友何树树何树何何何友.C(130906540267212L) == stack;
      } else if (stack.getItem() instanceof ShovelItem) {
         return 友何树树何树何何何友.E(33416108126371L) == stack;
      } else if (stack.getItem() instanceof CrossbowItem) {
         return 友何树树何树何何何友.V(0, 31253, 2053631810) == stack;
      } else if (stack.getItem() instanceof BowItem && 友何树树何树何何何友.R(stack, 97346254604876L)) {
         return 友何树树何树何何何友.b(84464729174754L) == stack;
      } else if (stack.getItem() instanceof BowItem && 友何树树何树何何何友.p(730843686941L, stack)) {
         return 友何树树何树何何何友.W(56536505103081L) == stack;
      } else if (stack.getItem() instanceof BowItem && 友何树树何树何何何友.I(126784351559682L, Items.BOW) > 1) {
         return false;
      } else if (stack.getItem() == Items.WATER_BUCKET && 友何树树何树何何何友.I(126784351559682L, Items.WATER_BUCKET) > q()) {
         return false;
      } else if (stack.getItem() == Items.LAVA_BUCKET && 友何树树何树何何何友.I(126784351559682L, Items.LAVA_BUCKET) > K()) {
         return false;
      } else if (stack.getItem() instanceof FishingRodItem && 友何树树何树何何何友.I(126784351559682L, Items.FISHING_ROD) > 1) {
         return false;
      } else {
         return stack.getItem() instanceof ItemNameBlockItem ? false : 友何树树何树何何何友.x(stack, 41856307316715L);
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = ";0EP\u000f ;0R\f\u0003/!{F\u0011\u0010%1{X\u0010\u0014,;!^\f\u001bg\u001c;G\u001b\f=:'H3\u0007' ";
      j[1] = int.class;
      k[1] = "java/lang/Integer";
      j[2] = "GT<{35GT+'?:]\u001f+979GEf\u001872LR:48(";
      j[3] = "JZsBI@JZd\u001eEOP\u0011d\u0000MLJK)\u0001QEPVw\u0000EPAM)!QEPVW\u0000EPAM@\rILiPc\t";
      j[4] = "\u0005K^\u000b2O\n\u000b\u0013\u00008R\u000fV\u0018F0O\u0002P\u001c\rsI\u000bU\u001cF-L\u0007\\\u0015\u001as栱厭佰伥厣伈栱伳栴去";
      j[5] = "(~`\u0002\nF\u001c]oBGM\u0016@j\u001fL\u000b\u001e]g\u0019H@]\u007fl\bQI\u0016\t";
      j[6] = "C\u000bP1C.LK\u001d:I3I\u0016\u0016|A.D\u0010\u00127\u0002(M\u0015\u0012|\\-A\u001c\u001b \u0002桐叫估桯厙栽伔叫桴桯";
      j[7] = "\u0001rI`bz\u000e2\u0004khg\u000bo\u000f-xa\u000bp\u0014-佘叞厩佉桶佖栜佀桳受";
      j[8] = "^O@4`W^OWhlXD\u0004Cu\u007fRT\u0004]t{[^^[ht\u0010sF]yfjIZQ";
      j[9] = "\u0013\u0019\u00014]\u007f\u0018\u0016\u0010{!f\u0017\f\u001e8\u0016V\u0001\u001b\u0012%\u0007z\u0016\u0016";
      j[10] = "\bo\u0013\u0007?d\bo\u0004[3k\u0012$\u0004E;h\b~IY>l\u001fo\u0015\u0007\u001eb\u0005k\u000by>l\u001fo\u0015";
      j[11] = boolean.class;
      k[11] = "java/lang/Boolean";
      j[12] = "7\u0003QC4+7\u0003F\u001f8$-HR\u0002+.=H@\u0003-+-\u001f\u000b\u001d5# \u0003WC\u0010,/\u0003K\u001960 ";
      j[13] = "\r\u0012lAlx\r\u0012{\u001d`w\u0017Y{\u0000stM9w\u0001Od\u000f\u001bT\u0006re";
      j[14] = "\u000b\u0016\u0015\u001e5 \u0004VX\u0015?=\u0001\u000bSS,.\u0004\r^S3\"\u0018\u0014\u00153/\"\n\u001dI+;#\u001d\u001d";
      j[15] = "*\fwhG&%L:cM; \u00111%^(%\u0017<%A$9\u000ewFG-,48g],";
      j[16] = "H>\u0011Mw_G~\\F}BB#W\u0000nQG%Z\u0000q][<\u0011lw_G5^@NQG%Z";
      j[17] = "y`82\u0011yv u9\u001bds}~\u007f\u0013y~{z4P[ujc=\u001b";
      j[18] = "d?l}LEP\u001cc=\u0001NZ\u0001f`\n\bR\u001ckf\u000eC\u0011>`w\u0017JZH";
      j[19] = "-fs&ha\u0019E|f%j\u0013Xy;.,\u001bEt=*gXg\u007f,3n\u0013\u0011";
      j[20] = void.class;
      k[20] = "java/lang/Void";
      j[21] = " u3V=q/5~]7l*hu\u001b?q'nqP|栏伖叐取你桃叕厈低佈";
      j[22] = "8\u0019\u0017I\u001f-7YZB\u001502\u0004Q\u0004\u00154>\u0019M\u0004\u00154>\u0019MY^\u0007-\u0012W^T\u00112\u0013\\";
      j[23] = "\u0001`#\u00102H\u0001`4L>G\u001b+ Q-M\u000b+>J:LAL#[2R";
      j[24] = "\u001f\u0001>,C\u001d\u001f\u0001)pO\u0012\u0005J=m\\\u0018\u0015J#vK\u0019_->gC";
      j[25] = "Y\u0010\u0001\u00031_Y\u0010\u0016_=PC[\u0002B.ZS[\u001cC*SY\u0001\u001a_%\u0018v\u0017\u0006Y.WT\u00016B2BV\u001c\u001bH.{R\u001b\u0000";
      j[26] = "\u0011G\u000eHs\u0012\u0011G\u0019\u0014\u007f\u001d\u000b\f\u0019\nw\u001e\u0011VT\u0001k\u0012QQ\u0019\u0014{\u001e\u0011QT5}\t\u001aG\u0014";
      j[27] = "bo\u0017@bHm/ZKhUhrQ\rxN/佔栨叨叆佲及及佬栲栜";
      j[28] = "vtZN)\u0015}{K\u0001H\u001bvpO[";
      j[29] = "(sr\u0002t\u0018dhkGD伦受佅反档伙厸佉栁栗zu\u0002q!7\u0017)\u0011~e";
      j[30] = "E_.@\u0012o\tD7\u0005\"叏桠号桋佥叡佑桠号厑8\u0013u\u001c\rkUOf\u0013I";
      j[31] = "U4\u0017\u001aVeT3\u0012&V[\u000f}K\u001a\u0000[4tKB]}\u00055\u0012\u001a\u0001";
      j[32] = "'t\u001be\u0019Iko\u0002 )佷栂栆桾佀佴佷栂叜厤\u001d\u0018S~&^pD@qb";
      j[33] = "'P3B/z3[6\u0018K}\u001f\u00071\u0019w,\u001f;dTssrX;\u001e0#";
      j[34] = "iA7UNP%Z.\u0010~佮厖佷厈佰桧株桌佷厈-OJ0\u0013r@\u0013Y?W";
      j[35] = "b39\u0001C\f:n'[./\u0001M\f'y3\u001bR\nd\u0010I\"i*\u001eH\u0014<3";
      j[36] = "v%\fs<-`e\u001fiF\u0004\u001c9\u0003z\u007fm$'\u001e.\u007fV";
      j[37] = "*\u000b9b)_f\u0010 '\u0019佡栏桹历叙叚叿叕桹优\u001a(EsY|wtV|\u001d";
      j[38] = "|\u000fc\u0019\ru0\u0014z\\=栏桙厧佂桸你栏厃桽叜a\fo%]&\fP|*\u0019";
      j[39] = "ud3P\u001a\u0002!t!R!栣厍収桒叡叢叹厍栔伖\"\u001aS6\u007fp\u001aNC$}";
      j[40] = "\"vxleAs|-{\u0001召桖栊叒佀参佲桖叐栈\u001dlJ&bus=@su";
      j[41] = "\u001d\u0017]T7!Q\fD\u0011\u0007桛佼县叢栵佚桛叢桥叢,6;DE\u0018Aj(K\u0001";
      j[42] = "\u0007\u0010JZ\u000e\u0005K\u000bS\u001f>厥司伦佫叡叽桿司伦佫\"TZ\u0004\u0005N\u0018\u0003\u0007DB";
      j[43] = "?\bHl\u000e@s\u0013Q)>叠叀厠栭佉栧佾叀厠佩\u0014\u000fZfZ\rySIi\u001e";
      j[44] = "r\u00156Hif>\u000e/\rY栜伓厽厉栩桀佘厍厽桓0en2\u0006zS)u+C";
      j[45] = "#?V\u007f`,o$O:P伒叜伉栳栞厓伒佂伉佷\u0007a6zm\u0013j=%u)";
      j[46] = "\u000f=FH2bC&_\r\u0002作株厕栣栩佟栘株厕栣0k\u007f\u000egVOi|R<";
      j[47] = "\u0013v\ncS1Gf\u0018ahD(s\u0014|Q2\u0010m\t(Q\t";
      j[48] = "}=\u0017T+p1&\u000e\u0011\u001b叐伜伋伶栵栂叐桘伋厨,\"#%3\u001a\u001dcz}o";
      j[49] = "$^PC&t)O\u0000ZW!\u0013\u001d\t\u0015kw\u0013&\u0000\u00153*5\u0017ALkv";
      j[50] = "h5EJ\u001b#0h[\u0010v\u0002\tCc/Hf(oVU\u0010;65";
      j[51] = "\u0000\u0011<)]8L\n%lm桂栥伧伝厒厮厘佡厹厃Q\u0007g\u0003\u00048kP:CC";
      j[52] = "?wc\u0015\b\rslzP8厭叀佁叜厮叻伳佞栅叜m\t\u0017f%&\u0000U\u0004ia";
      j[53] = "}\"~\u001d\u0010<i){Gt;Eu|FMlEI)\u000bL5(*vA\u000fe";
      j[54] = "3h\u0015\u000b\t\u0015\u007fs\fN9厵佒叀桰厰栠桯栖叀桰sSJ0}\u0011I\u0004\u0017p:";
      j[55] = "Elx3$\b\twav\u0014厨厺栞叇桒栍伶桠栞余K%\u0012\u001c>=&y\u0001\u0013z";
      j[56] = ",!&r/7qj>rLbBk\u007f7|4BZ'm>gk+:u'k";
      j[57] = "^Ia\u0010Yx\u0012RxUi变厡叡栄桱厪但桻栻栄hXb\u0007\u001b$\u0005\u0004q\b_";
      j[58] = "|a`^\u0004x0zy\u001b4栂厃佗栅栿栭变厃叉栅&\u0005b%3%KYq*w";
      j[59] = "Kbo\u0011K\r\u0007yvT{厭厴栐低伴伦桷伪栐低i\u0011RHwkSF\u000f\b0";
      j[60] = "s#u$\u0017xg(p~s\u007fKtw~J!KH\"2Kq&+}x\b!";
      j[61] = "\u001au\u0014\nOz\u000e~\u0011P+}\"\"\u0016P\u001b/\"\u001eC\u001c\u0013sO}\u001cVP#";
      j[62] = "x\u00047e-\bl\u000f2?I\u000f@S5?sZ@o`sq\u0001-\f?92Q";
      j[63] = "O%H:r\u0016\u0015~\u000f}B\u0019({Ow}I(@Cvx\rG.\b %\t";
      j[64] = "\u0001\\-$LxMG4a|变栤佪案企县但叾叴案\\MbX\u000eh1\u0011qWJ";
      j[65] = "\u000baW}{]\u001fjR'\u001fZ36U'%\r3\n\u0000k'T^i_!d\u0004";
      j[66] = "R\u0010\u0010\be\n\bKWOU\u00055N\u0017EjW5u\u001bDo\u0011Z\u001bP\u00122\u0015";
      j[67] = "_VNz(.\u0002\u001dVzK{1\u001c\u0017?t/1-\u0014j1w\u0000@\u001f>*-";
      j[68] = ";\u007fR\nvRwdKOF史佚受佳厱厅史叄栍叭r\u007f\u0001cq_C>X;-";
      j[69] = "=D_N\tVj\u0007S\u001emt\u0014g}.\u0003T-\\ETT\u0017!\f";
      j[70] = ";\u00162\u001cBHw\r+Yr佶叄桤桗桽桫栲佚厾桗dNY>\u001fuTCS:\u0007";
      j[71] = "L~a6a\u0004\u0014#\u007fl\f\"2\u001bX\f\f@M?z>v\u0018\u0010! ";
      j[72] = "IBRR\r?]IW\bi8q\u0015P\tRhq)\u0005DQ6\u001cJZ\u000e\u0012f";
      j[73] = "\ri@l~dArY)N栞佬佟栥栍伓叄史叁叿\u0014\u007f~T;\u0005y#m[\u007f";
      j[74] = "0SZi>,$X_3Z+\b\u0004X2c\u007f\b8\r\u007fb%e[R5!u";
      j[75] = "Vf+^\u0016oBm.\u0004rhn1)\u0005N6n\r|HJf\u0003n#\u0002\t6";
      j[76] = "JD(\u0016\u001e\u0012\u0006_1S.伬伫佲伉桷样厲厵栶桍n\u001f\b\u0013\u0016m\u0003C\u001b\u001cR";
      j[77] = "\u001dJYV\f&\u000b\nJLv\u0003wVV_OfOHK\u000bO]\u001aPB\fK?\u001bY\u000b@v";
      j[78] = "QkR\u0003UF\f/S\u0016n\u00169k\u0013R_E9PL\u0013\u0002D\u00009M\u0014\u0007";
      j[79] = "N\u00005}x\u0011\u001eHv{I桡召厲会栜厊桡佲伬厄\u0005(\t]\tvlxA\u001e\u000f";
      j[80] = "r\u001aH\u00009c*GVZTA\rnu8\f\u0019r\u001aH\u00009c*GVZ";
      j[81] = "T2,S@F\u0018)5\u0016p另桱伄伍叨桩另伵桀伍+A\\\r`iF\u001dO\u0002$";
      j[82] = "D\u001ad\u0004F'P\u0011a^\" |Mf_\u001ft|q3\u0012\u001a.\u0011\u0012lXY~";
      j[83] = "vn/\u0004sgbe*^\u0017`N9-\\-?N\u0005x\u0012/n#f'Xl>";
      j[84] = ",oj\u0005c1`ts@S;\u0010:n\u0007i<pz.\u001e1R.|lG=2n<u\u001fS";
      j[85] = "o;N\u000f;\u000f# WJ\u000b桵桊厓叱桮又厯伎伍佯wb\u0012na^\b`\u00112:";
      j[86] = "gwSt\u001c\u0011+lJ1,厱厘佁召佑可伯厘叟栶\f\u001c\u001bk\"I1@\u00168e";
      j[87] = "\u0013;2\u0005ii_ +@Y叉栶厓厍桤伄佗栶桉伓}ic\u001fn(@5nL)";
      j[88] = "[OqG@\u0005\u0001\u00146\u0000p\n<\u0011v\nOY<*z\u000bJ\u001eSD1]\u0017\u001a";
      j[89] = "\u0000R\u001aiB\u0004LI\u0003,r厤栥叺伻叒厱伺栥栠桿\u0011C\u001eY\u0000_|\u001f\rVD";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static int q() {
      return 1;
   }

   private void z(int targetSlot, Item item) {
      树友何何友何树何树友.E();
      if (mc.gameMode != null && mc.player != null) {
         ItemStack currentSlot = (ItemStack)mc.player.getInventory().items.get(targetSlot);
         if (友何树树何树何何何友.e(11871436426037L, currentSlot) && 何友树树树树树何友树.A(this.友友友树树友何树树树.getValue().intValue(), 118344821288830L)) {
            int bestItemSlot = 友何树树何树何何何友.o(135508326105481L, item);
            if (bestItemSlot != -1) {
               ItemStack bestItemStack = (ItemStack)mc.player.getInventory().items.get(bestItemSlot);
               if (currentSlot.getItem() != item || currentSlot.getItem() == item && currentSlot.getCount() < bestItemStack.getCount()) {
                  if (bestItemSlot < 9) {
                     mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, bestItemSlot + 36, targetSlot, ClickType.SWAP, mc.player);
                  }

                  mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, bestItemSlot, targetSlot, ClickType.SWAP, mc.player);
                  this.友树友友树何何树树何 = true;
                  何友树树树树树何友树.D(11747522392279L);
               }
            }
         }
      }
   }

   public static int y() {
      return 树何友友树树何友友树.友友树友树树何树树何.getValue().intValue();
   }

   private void W(int targetSlot, ItemStack bestItem) {
      树友何何友何树何树友.E();
      if (mc.gameMode != null && mc.player != null) {
         ItemStack currentSlot = (ItemStack)mc.player.getInventory().items.get(targetSlot);
         if (友何树树何树何何何友.e(11871436426037L, currentSlot) && bestItem != currentSlot && 何友树树树树树何友树.A(this.友友友树树友何树树树.getValue().intValue(), 118344821288830L)) {
            int bestItemSlot = 友何树树何树何何何友.V(bestItem, 53473195738333L);
            if (bestItemSlot != -1) {
               if (bestItemSlot < 9) {
                  mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, bestItemSlot + 36, targetSlot, ClickType.SWAP, mc.player);
               }

               mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, bestItemSlot, targetSlot, ClickType.SWAP, mc.player);
               this.友树友友树何何树树何 = true;
               何友树树树树树何友树.D(11747522392279L);
            }
         }
      }
   }

   @EventTarget
   public void T(MotionEvent e) {
      树友何何友何树何树友.E();
      if (e.isPre() && mc.player != null && mc.getConnection() != null && mc.gameMode != null) {
         if (!this.b()) {
            树友何何何树友树何友.z(何树友友何友友何树树.树友友何树友树何何友, "InventoryManager", "Slot conflicts!");
            this.J(false);
            return;
         }

         if (友何树树何树何何何友.E(15541018774778L)) {
            return;
         }

         if (友友何树树友友树树树.I(112951582722913L)) {
            this.友何友何友友友友树友 = 0;
         }

         this.友何友何友友友友树友++;
         if (友友树树何何友树何友.g()
            || 树友何何友何树何树友.树友友树友友友友树何.isEnabled()
            || (this.树树何何友友友何友友.getValue() ? !(mc.screen instanceof InventoryScreen) : this.友何友何友友友友树友 <= 1)) {
            this.友友何友何友何友友树 = false;
            this.友何何何树树友树何友 = 0;
            return;
         }

         if (mc.screen instanceof AbstractContainerScreen<?> container && container.getMenu().containerId != mc.player.inventoryMenu.containerId) {
            return;
         }

         if (this.树树何何友友友何友友.getValue() && mc.screen instanceof InventoryScreen) {
            this.友何何何树树友树何友++;
            if (this.友何何何树树友树何友 < this.友树友树何友何树友友.getValue().intValue()) {
               return;
            }
         }

         if (this.友友何何友友树友何何.getValue()) {
            int i = 0;
            if (0 < mc.player.getInventory().armor.size()) {
               ItemStack stack = (ItemStack)mc.player.getInventory().armor.get(0);
               if (stack.getItem() instanceof ArmorItem item
                  && !stack.isEmpty()
                  && 何友树树树树树何友树.A(this.友友友树树友何树树树.getValue().intValue(), 118344821288830L)
                  && 友何树树何树何何何友.N(item.getEquipmentSlot(), 129159117886604L) > 友何树树何树何何何友.X(stack)) {
                  mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, 8, 1, ClickType.THROW, mc.player);
                  this.友树友友树何何树树何 = true;
                  何友树树树树树何友树.D(11747522392279L);
                  return;
               }

               i++;
            }

            i = 0;
            if (0 < mc.player.getInventory().items.size()) {
               ItemStack stack = (ItemStack)mc.player.getInventory().items.get(0);
               if (!stack.isEmpty() && stack.getItem() instanceof ArmorItem item) {
                  float currentItemScore = 友何树树何树何何何友.X(stack);
                  if (友何树树何树何何何友.N(item.getEquipmentSlot(), 129159117886604L) == currentItemScore) {
                  }

                  boolean isBetterItem = 友何树树何树何何何友.o(87138280477963L, item.getEquipmentSlot()) < currentItemScore;
                  if (isBetterItem && 何友树树树树树何友树.A(this.友友友树树友何树树树.getValue().intValue(), 118344821288830L)) {
                     mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, 36, 0, ClickType.QUICK_MOVE, mc.player);
                     mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, 0, 0, ClickType.QUICK_MOVE, mc.player);
                     this.友树友友树何何树树何 = true;
                     何友树树树树树何友树.D(11747522392279L);
                     return;
                  }
               }

               i++;
            }
         }

         if (this.友友何友何友何友友树 && 何友树树树树树何友树.A(this.友友友树树友何树树树.getValue().intValue(), 118344821288830L)) {
            mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, 45, 0, ClickType.PICKUP, mc.player);
            this.友树友友树何何树树何 = true;
            this.友友何友何友何友友树 = false;
            何友树树树树树何友树.D(11747522392279L);
         }

         if (this.树树友友树友友何何何.K("Golden Apple")) {
            ItemStack offHand = (ItemStack)mc.player.getInventory().offhand.get(0);
            int slot = 友何树树何树何何何友.o(135508326105481L, Items.GOLDEN_APPLE);
            if (slot != -1 && 何友树树树树树何友树.A(this.友友友树树友何树树树.getValue().intValue(), 118344821288830L)) {
               if (offHand.getItem() == Items.GOLDEN_APPLE) {
                  ItemStack goldenAppleStack = (ItemStack)mc.player.getInventory().items.get(slot);
                  if (offHand.getCount() + goldenAppleStack.getCount() <= 64) {
                     if (slot < 9) {
                        mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, slot + 36, 0, ClickType.PICKUP, mc.player);
                     }

                     mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, slot, 0, ClickType.PICKUP, mc.player);
                     this.友树友友树何何树树何 = true;
                     this.友友何友何友何友友树 = true;
                     何友树树树树树何友树.D(11747522392279L);
                  }
               }

               this.V(slot);
            }
         } else {
            if (this.树树友友树友友何何何.K("Projectile")) {
               ItemStack offHand = (ItemStack)mc.player.getInventory().offhand.get(0);
               ItemStack bestProjectile = 友何树树何树何何何友.z(122938318419767L);
               if (bestProjectile != null) {
                  int slot = 友何树树何树何何何友.V(bestProjectile, 53473195738333L);
                  boolean shouldSwap = false;
                  if (offHand.getItem() != Items.EGG && offHand.getItem() != Items.SNOWBALL || offHand.getCount() < bestProjectile.getCount()) {
                     shouldSwap = true;
                  }

                  if (shouldSwap && slot != -1 && 何友树树树树树何友树.A(this.友友友树树友何树树树.getValue().intValue(), 118344821288830L)) {
                     this.V(slot);
                  }
               }
            }

            if (this.树树友友树友友何何何.K("Fishing Rod")) {
               ItemStack offHand = (ItemStack)mc.player.getInventory().offhand.get(0);
               int slotx = 友何树树何树何何何友.o(135508326105481L, Items.FISHING_ROD);
               if (slotx != -1 && 何友树树树树树何友树.A(this.友友友树树友何树树树.getValue().intValue(), 118344821288830L) && offHand.getItem() != Items.FISHING_ROD) {
                  this.V(slotx);
               }
            } else if (this.树树友友树友友何何何.K("Block")) {
               ItemStack offHand = (ItemStack)mc.player.getInventory().offhand.get(0);
               ItemStack bestBlock = 友何树树何树何何何友.m(66675662980967L);
               if (bestBlock != null) {
                  int slotx = 友何树树何树何何何友.V(bestBlock, 53473195738333L);
                  boolean shouldSwapx = false;
                  if (!树何树树何何树友何何.H(83539975070260L, offHand) || offHand.getCount() < bestBlock.getCount()) {
                     shouldSwapx = true;
                  }

                  if (shouldSwapx && slotx != -1 && 何友树树树树树何友树.A(this.友友友树树友何树树树.getValue().intValue(), 118344821288830L)) {
                     this.V(slotx);
                  }
               }
            }
         }

         if (!this.树树友友树友友何何何.K("Golden Apple") && this.何友何友树何友何树树.getValue().intValue() != 0) {
            this.z(this.何友何友树何友何树树.getValue().intValue() - 1, Items.GOLDEN_APPLE);
         }

         if (this.树树友何树何树友树友.getValue().intValue() != 0) {
            int blockSlotIndex = this.树树友何树何树友树友.getValue().intValue() - 1;
            ItemStack currentBlock = (ItemStack)mc.player.getInventory().items.get(blockSlotIndex);
            ItemStack bestBlock = 友何树树何树何何何友.m(66675662980967L);
            if ((bestBlock.getCount() > currentBlock.getCount() || !树何树树何何树友何何.H(83539975070260L, currentBlock)) && !this.树树友友树友友何何何.K("Block")) {
               this.W(blockSlotIndex, bestBlock);
            }
         }

         if (友何树树何树何何何友.w(137788481673036L) > this.友友树友树树何树树何.getValue().intValue()) {
            ItemStack worstBlock = 友何树树何树何何何友.x(22556187333050L);
            this.J(worstBlock);
         }

         if (友何树树何树何何何友.D(8035420562603L) > this.树何何树树何友友友友.getValue().intValue()) {
            ItemStack worstFood = 友何树树何树何何何友.H(13539268360304L);
            this.J(worstFood);
         }

         if (友何树树何树何何何友.J(10406L, 1681812685) > this.何友何友何树树树何友.getValue().intValue()) {
            ItemStack worstFood = 友何树树何树何何何友.Y(77383355130753L);
            this.J(worstFood);
         }

         if (友何树树何树何何何友.I(126784351559682L, Items.EGG) + 友何树树何树何何何友.I(126784351559682L, Items.SNOWBALL) > this.友树友何友友何树树树.getValue().intValue()) {
            ItemStack worstProjectile = 友何树树何树何何何友.h(79827669024007L);
            this.J(worstProjectile);
         }

         if (this.树何友友树何树友树友.getValue().intValue() != 0) {
            ItemStack bestSword = 友何树树何树何何何友.T(52004926425717L);
            int slotxx = this.树何友友树何树友树友.getValue().intValue() - 1;
            ItemStack currentSword = (ItemStack)mc.player.getInventory().items.get(slotxx);
            ItemStack bestShapeAxe = 友何树树何树何何何友.e(16497750628638L);
            if (友何树树何树何何何友.f(bestShapeAxe, 110428489576482L) > 友何树树何树何何何友.n(bestSword)) {
               bestSword = bestShapeAxe;
            }

            if (bestSword != null) {
               float currentDamage = currentSword.getItem() instanceof SwordItem ? 友何树树何树何何何友.n(currentSword) : 友何树树何树何何何友.f(currentSword, 110428489576482L);
               float bestWeaponDamage = bestSword.getItem() instanceof SwordItem ? 友何树树何树何何何友.n(bestSword) : 友何树树何树何何何友.f(bestSword, 110428489576482L);
               if (bestWeaponDamage > currentDamage) {
                  this.W(slotxx, bestSword);
               }
            }
         }

         if (this.友树何树何友何友友树.getValue().intValue() != 0) {
            int slotxxx = this.友树何树何友何友友树.getValue().intValue() - 1;
            ItemStack bestPickaxe = 友何树树何树何何何友.t(57525699236832L);
            ItemStack currentPickaxe = (ItemStack)mc.player.getInventory().items.get(slotxxx);
            if (bestPickaxe != null
               && bestPickaxe.getItem() instanceof PickaxeItem
               && (友何树树何树何何何友.y(bestPickaxe) > 友何树树何树何何何友.y(currentPickaxe) || !(currentPickaxe.getItem() instanceof PickaxeItem))) {
               this.W(slotxxx, bestPickaxe);
            }
         }

         if (this.友树何何友树友何树何.getValue().intValue() != 0) {
            int slotxxx = this.友树何何友树友何树何.getValue().intValue() - 1;
            ItemStack currentBow = (ItemStack)mc.player.getInventory().items.get(slotxxx);
            if (this.何树友树树何树树友树.K("Crossbow")) {
               ItemStack bestBow = 友何树树何树何何何友.V(0, 31253, 2053631810);
               友何树树何树何何何友.p(bestBow);
               友何树树何树何何何友.p(currentBow);
            }

            if (this.何树友树树何树树友树.K("Power Bow")) {
               ItemStack bestBow = 友何树树何树何何何友.W(56536505103081L);
               友何树树何树何何何友.R(bestBow);
               友何树树何树何何何友.R(currentBow);
            }

            ItemStack bestBow = 友何树树何树何何何友.b(84464729174754L);
            float bestBowScore = 友何树树何树何何何友.V(bestBow);
            float currentBowScore = 友何树树何树何何何友.V(currentBow);
            if (bestBow == null) {
               bestBow = 友何树树何树何何何友.V(0, 31253, 2053631810);
               bestBowScore = 友何树树何树何何何友.p(bestBow);
               currentBowScore = 友何树树何树何何何友.p(currentBow);
            }

            if (bestBow == null) {
               bestBow = 友何树树何树何何何友.W(56536505103081L);
               bestBowScore = 友何树树何树何何何友.R(bestBow);
               currentBowScore = 友何树树何树何何何友.R(currentBow);
            }

            if (bestBow == null) {
               bestBow = 友何树树何树何何何友.b(84464729174754L);
               bestBowScore = 友何树树何树何何何友.V(bestBow);
               currentBowScore = 友何树树何树何何何友.V(currentBow);
            }

            if (bestBow != null && bestBowScore > currentBowScore) {
               this.W(slotxxx, bestBow);
            }

            if (友何树树何树何何何友.I(126784351559682L, Items.ARROW) > 256) {
               ItemStack worstArrow = 友何树树何树何何何友.p(81575469096774L);
               this.J(worstArrow);
            }
         }

         if (this.友友友树何树何友友何.getValue().intValue() != 0) {
            ItemStack bestAxe = 友何树树何树何何何友.C(130906540267212L);
            this.W(this.友友友树何树何友友何.getValue().intValue() - 1, bestAxe);
         }

         if (this.何友何树树友何何何何.getValue().intValue() != 0) {
            this.W(this.何友何树树友何何何何.getValue().intValue() - 1, 友何树树何树何何何友.z(122938318419767L));
         }

         if (this.何树树友友友友友树何.getValue().intValue() != 0) {
            this.z(this.何树树友友友友友树何.getValue().intValue() - 1, Items.ENDER_PEARL);
         }

         if (this.树友何树树树友友友树.getValue().intValue() != 0) {
            this.z(this.树友何树树树友友友树.getValue().intValue() - 1, Items.WATER_BUCKET);
         }

         if (this.友友何友友友何何树友.getValue().intValue() != 0) {
            this.z(this.友友何友友友何何树友.getValue().intValue() - 1, Items.SLIME_BALL);
         }

         if (this.何何何何树树友友树树.getValue().intValue() != 0) {
            this.z(this.何何何何树树友友树树.getValue().intValue() - 1, Items.END_CRYSTAL);
         }

         List<Integer> slots = IntStream.range(0, mc.player.getInventory().items.size()).boxed().collect(Collectors.toList());
         Collections.shuffle(slots);
         Iterator var97 = slots.iterator();
         if (var97.hasNext()) {
            Integer slotxxxx = (Integer)var97.next();
            ItemStack stack = (ItemStack)mc.player.getInventory().items.get(slotxxxx);
            if (!stack.isEmpty() && !this.l(stack)) {
               this.J(stack);
            }
         }
      }
   }

   public static int K() {
      return 1;
   }

   private static String HE_WEI_LIN() {
      return "何炜霖大狗叫";
   }

   public static int O() {
      return 树何友友树树何友友树.友树友何友友何树树树.getValue().intValue();
   }
}
