package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class 树友树友树树何何树何 extends Module implements 何树友 {
   private final NumberValue 何树树树友何何树何何;
   private final NumberValue 友友树友何树何树何何;
   private final BooleanValue 树友树友何友树友树友;
   private final BooleanValue 何友何友何树友树友树;
   private final BooleanValue 友树树树何友何何友树;
   private final NumberValue 树友树何树何友树何树;
   private final BooleanValue 友友何友何树何友友树;
   private final BooleanValue 友树树何何何何何何友;
   private final BooleanValue 友友何何友何友何何树;
   private final BooleanValue 树友友何友友树何树何;
   private final NumberValue 何树何树友友树树何树;
   private final BooleanValue 树友友友友何何友何何;
   private final BooleanValue 友树何何友友树何何友;
   private final BooleanValue 何何何树树友树何何树;
   private Rotation 树树友友友何友友何友;
   private BlockPos 何何友友友何树友树友;
   private boolean 何树树何树何何何树何;
   private boolean 友友树何何树何树何友;
   private final 树友树友友何何树何何 树友友何树树何树何何;
   private final long 何友树树何友友友何何;
   private final 树友树友友何何树何何 何树何树何树友何何何;
   private int 何何何何友树友树树树;
   private int 友树友友友何树友树友;
   private InteractionHand 树树何友友友树何友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final long[] k;
   private static final Long[] l;
   private static final Map m;
   private static final Object[] n = new Object[72];
   private static final String[] o = new String[72];
   private static String HE_JIAN_GUO;

   public 树友树友树树何何树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/树友树友树树何何树何.a J
      // 003: ldc2_w 111011339645502
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 13512679932420
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 27118
      // 014: ldc2_w 4437876768124062356
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 11427
      // 021: ldc2_w 4184160985136664551
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w 2993470224707752839
      // 02e: lload 1
      // 02f: invokedynamic à (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/NumberValue
      // 03b: dup
      // 03c: sipush 6770
      // 03f: ldc2_w 4734254179707369756
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 10866
      // 04c: ldc2_w 6622680872678230289
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: ldc2_w 4.0
      // 059: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 05c: bipush 1
      // 05d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 060: ldc2_w 6.0
      // 063: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 066: ldc2_w 0.1
      // 069: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 06c: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 06f: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.何树树树友何何树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 072: aload 0
      // 073: new cn/cool/cherish/value/impl/NumberValue
      // 076: dup
      // 077: sipush 18734
      // 07a: ldc2_w 1444078626955749969
      // 07d: lload 1
      // 07e: lxor
      // 07f: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 084: sipush 819
      // 087: ldc2_w 3303722102368280640
      // 08a: lload 1
      // 08b: lxor
      // 08c: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 091: ldc2_w 2.0
      // 094: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 097: bipush 1
      // 098: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09b: ldc2_w 3.0
      // 09e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0a1: ldc2_w 0.1
      // 0a4: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0a7: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0aa: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.友友树友何树何树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 0ad: aload 0
      // 0ae: new cn/cool/cherish/value/impl/BooleanValue
      // 0b1: dup
      // 0b2: sipush 25547
      // 0b5: ldc2_w 507319549972594828
      // 0b8: lload 1
      // 0b9: lxor
      // 0ba: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bf: sipush 28320
      // 0c2: ldc2_w 6378530000293285314
      // 0c5: lload 1
      // 0c6: lxor
      // 0c7: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0cc: bipush 1
      // 0cd: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0d0: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0d3: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.树友树友何友树友树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0d6: aload 0
      // 0d7: new cn/cool/cherish/value/impl/BooleanValue
      // 0da: dup
      // 0db: sipush 16985
      // 0de: ldc2_w 4599361569409589529
      // 0e1: lload 1
      // 0e2: lxor
      // 0e3: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e8: sipush 3703
      // 0eb: ldc2_w 327433090290560305
      // 0ee: lload 1
      // 0ef: lxor
      // 0f0: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f5: bipush 1
      // 0f6: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0f9: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0fc: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.何友何友何树友树友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0ff: aload 0
      // 100: new cn/cool/cherish/value/impl/BooleanValue
      // 103: dup
      // 104: sipush 14309
      // 107: ldc2_w 6087655867397117083
      // 10a: lload 1
      // 10b: lxor
      // 10c: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 111: sipush 32524
      // 114: ldc2_w 2067541970180955238
      // 117: lload 1
      // 118: lxor
      // 119: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11e: bipush 0
      // 11f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 122: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 125: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.友树树树何友何何友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 128: aload 0
      // 129: new cn/cool/cherish/value/impl/NumberValue
      // 12c: dup
      // 12d: sipush 24332
      // 130: ldc2_w 4312436507273362531
      // 133: lload 1
      // 134: lxor
      // 135: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 13a: sipush 21175
      // 13d: ldc2_w 8311405091358405072
      // 140: lload 1
      // 141: lxor
      // 142: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 147: ldc2_w 180.0
      // 14a: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 14d: dconst_0
      // 14e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 151: ldc2_w 180.0
      // 154: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 157: ldc2_w 10.0
      // 15a: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 15d: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 160: aload 0
      // 161: ldc2_w 2994220588099931439
      // 164: lload 1
      // 165: invokedynamic z (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16a: dup
      // 16b: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 16e: pop
      // 16f: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 174: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 177: checkcast cn/cool/cherish/value/impl/NumberValue
      // 17a: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.树友树何树何友树何树 Lcn/cool/cherish/value/impl/NumberValue;
      // 17d: aload 0
      // 17e: new cn/cool/cherish/value/impl/BooleanValue
      // 181: dup
      // 182: sipush 7598
      // 185: ldc2_w 8306146133544156888
      // 188: lload 1
      // 189: lxor
      // 18a: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 18f: sipush 18562
      // 192: ldc2_w 8529907187825994738
      // 195: lload 1
      // 196: lxor
      // 197: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 19c: bipush 1
      // 19d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1a0: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1a3: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.友友何友何树何友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1a6: aload 0
      // 1a7: new cn/cool/cherish/value/impl/BooleanValue
      // 1aa: dup
      // 1ab: sipush 3546
      // 1ae: ldc2_w 4354513782006066866
      // 1b1: lload 1
      // 1b2: lxor
      // 1b3: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b8: sipush 15459
      // 1bb: ldc2_w 2830184347800805128
      // 1be: lload 1
      // 1bf: lxor
      // 1c0: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c5: bipush 1
      // 1c6: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1c9: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1cc: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.友树树何何何何何何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1cf: aload 0
      // 1d0: new cn/cool/cherish/value/impl/BooleanValue
      // 1d3: dup
      // 1d4: sipush 12307
      // 1d7: ldc2_w 883136816173847406
      // 1da: lload 1
      // 1db: lxor
      // 1dc: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e1: sipush 2945
      // 1e4: ldc2_w 3071178541843589357
      // 1e7: lload 1
      // 1e8: lxor
      // 1e9: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ee: bipush 1
      // 1ef: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1f2: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1f5: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.友友何何友何友何何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1f8: aload 0
      // 1f9: new cn/cool/cherish/value/impl/BooleanValue
      // 1fc: dup
      // 1fd: sipush 2279
      // 200: ldc2_w 7607585493800168336
      // 203: lload 1
      // 204: lxor
      // 205: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 20a: sipush 5366
      // 20d: ldc2_w 7570417513368500115
      // 210: lload 1
      // 211: lxor
      // 212: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 217: bipush 1
      // 218: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 21b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 21e: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.树友友何友友树何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 221: aload 0
      // 222: new cn/cool/cherish/value/impl/NumberValue
      // 225: dup
      // 226: sipush 11586
      // 229: ldc2_w 7392593745241247235
      // 22c: lload 1
      // 22d: lxor
      // 22e: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 233: sipush 25985
      // 236: ldc2_w 4487508021939717875
      // 239: lload 1
      // 23a: lxor
      // 23b: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 240: sipush 200
      // 243: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 246: bipush 0
      // 247: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 24a: sipush 1000
      // 24d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 250: bipush 10
      // 252: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 255: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 258: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.何树何树友友树树何树 Lcn/cool/cherish/value/impl/NumberValue;
      // 25b: aload 0
      // 25c: new cn/cool/cherish/value/impl/BooleanValue
      // 25f: dup
      // 260: sipush 23692
      // 263: ldc2_w 3539295799911514063
      // 266: lload 1
      // 267: lxor
      // 268: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 26d: sipush 17272
      // 270: ldc2_w 6452290192008011777
      // 273: lload 1
      // 274: lxor
      // 275: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 27a: bipush 1
      // 27b: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 27e: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 281: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.树友友友友何何友何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 284: aload 0
      // 285: new cn/cool/cherish/value/impl/BooleanValue
      // 288: dup
      // 289: sipush 31339
      // 28c: ldc2_w 2292486994371467551
      // 28f: lload 1
      // 290: lxor
      // 291: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 296: sipush 13445
      // 299: ldc2_w 3680831231205513189
      // 29c: lload 1
      // 29d: lxor
      // 29e: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2a3: bipush 1
      // 2a4: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2a7: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2aa: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.友树何何友友树何何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2ad: aload 0
      // 2ae: new cn/cool/cherish/value/impl/BooleanValue
      // 2b1: dup
      // 2b2: sipush 27363
      // 2b5: ldc2_w 2200567419790772646
      // 2b8: lload 1
      // 2b9: lxor
      // 2ba: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2bf: sipush 20947
      // 2c2: ldc2_w 2262041466834481826
      // 2c5: lload 1
      // 2c6: lxor
      // 2c7: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2cc: bipush 1
      // 2cd: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2d0: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2d3: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.何何何树树友树何何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2d6: aload 0
      // 2d7: aconst_null
      // 2d8: ldc2_w 2994828231647351995
      // 2db: lload 1
      // 2dc: invokedynamic n (Ljava/lang/Object;Lcn/cool/cherish/utils/helper/Rotation;JJ)V bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2e1: aload 0
      // 2e2: aconst_null
      // 2e3: ldc2_w 2994149905144485160
      // 2e6: lload 1
      // 2e7: invokedynamic n (Ljava/lang/Object;Lnet/minecraft/core/BlockPos;JJ)V bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2ec: aload 0
      // 2ed: bipush 0
      // 2ee: ldc2_w 2993635967426011372
      // 2f1: lload 1
      // 2f2: invokedynamic n (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2f7: aload 0
      // 2f8: bipush 0
      // 2f9: ldc2_w 2994280285533467607
      // 2fc: lload 1
      // 2fd: invokedynamic n (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 302: aload 0
      // 303: new cn/cool/cherish/utils/树友树友友何何树何何
      // 306: dup
      // 307: lload 3
      // 308: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 30b: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.树友友何树树何树何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 30e: aload 0
      // 30f: sipush 510
      // 312: ldc2_w 4500094400808329741
      // 315: lload 1
      // 316: lxor
      // 317: invokedynamic p (IJ)J bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 31c: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.何友树树何友友友何何 J
      // 31f: aload 0
      // 320: new cn/cool/cherish/utils/树友树友友何何树何何
      // 323: dup
      // 324: lload 3
      // 325: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 328: putfield cn/cool/cherish/module/impl/player/树友树友树树何何树何.何树何树何树友何何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 32b: aload 0
      // 32c: bipush -1
      // 32d: ldc2_w 2995545435359865015
      // 330: lload 1
      // 331: invokedynamic n (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 336: aload 0
      // 337: bipush -1
      // 338: ldc2_w 2994011329303844608
      // 33b: lload 1
      // 33c: invokedynamic n (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 341: aload 0
      // 342: ldc2_w 2991727646672496839
      // 345: lload 1
      // 346: invokedynamic à (JJ)Lnet/minecraft/world/InteractionHand; bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 34b: ldc2_w 2992934015686739801
      // 34e: lload 1
      // 34f: invokedynamic n (Ljava/lang/Object;Lnet/minecraft/world/InteractionHand;JJ)V bsm=cn/cool/cherish/module/impl/player/树友树友树树何何树何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 354: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2190255048706177380L, 4953801650089905507L, MethodHandles.lookup().lookupClass()).a(112462858897928L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var16 = a ^ 38142943341723L;
      Cipher var18;
      Cipher var28 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(var16 << var19 * 8 >>> 56);
      }

      var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[40];
      int var23 = 0;
      String var22 = "õÄ\u0091\u009f\u001dªÅEû&\u009dÞào¶+xUEéºg \u008b\u009c\u009aÿ\u0095g«\b¬@Q\u008dôìE\n°Í×\u000e\u007f~\\â\u008f\u001c\u0089)\u0096_G\u0014j`\u0001KÏ\u0096ñÆÝ×\u0087í-æ\u001c%\u007f\u001a\u009aXAîx\u009b´\u0003óþ2¾µ\u009d=ïìÙ¥\u008aD\u009bº\u0098(e\u0005Z²A{Ïu:QXÙ5ô°\u0087\u000eFÎ\u001cOnÅeA\u0096á\u0098\u009ej¼\u0014v\u0015ßÿ\u001a\u0019MA\u0018|Ëz>0\u0088\r\u001e^\u001ef\"\u0002\u000bõ\u0098\u0006ßW'\u001ce\u0003ô\u0010kW\u001aYÆ-\u0081ÕW=³ìV\u0007Ó2 \u0019\u001c»<´(±eî\u008b÷q\u001f;v~¿µ\\q\u0080\u0089h\u009aù¹Ù¶1\u0000Þ¾\u0010\u0092ý\u0090lµüº6)ï°ºz9¬u \u0011¤×ëo\nã\u0014è]É\u0081\u009d×Ä.\n\u0010@X\u0088¥\n'âßA§\\fß×HÐj\u0092l\u0086~R»ùiVrÉaLé8£\u0084\"Ä\u0013Ü\u0095\u001dëYí\u0013÷L6ÑÈ¼\u0092ç¡\u0096{l\u001c0\u009eÀ\\\u008fIz\u009cñG&_Ï\u009b¦I}\u0005ÎË\u009d9d¥V|ªoÃÛ Lül\"çãjF\u008a\u001e\u008c\u009d\u0014Í\u001f\tXUHÐH|²à\u0081ëýYý§¼\u0081(\u0098]{UÜK®4øX¡W\"#V3Ï¥·våOw3\u0010l\u0091.Ä\u0099\u0082q%ºë¸ÎÖÀ'\u0010n¯Fþ\u0088\tá\u0003qÞx\u0092ýY\u0099g\u0010\u0015}/\u0086Qºi¼¨5»\u001a±·óê \u0081\u0085Ì\tÿ«×\u0014\u008eå\u0019©ó\u0013Ûl[»ë\u0089ÉÂð&aW\u0098°\u0094Û4Q\u0018ãºkOýlõ@rñ\u008fõó\u0096\u009a.\u0013$}»òy!\u0084 ³`Âl®wù?Q],)Ð1BK\u0087×\u0001m\r\u0011e¹¢JI\f\"\u0093J `àlÏ\u0092a^=\u0018TßìbÎª ´\u007fåAhGßu\u000fï\u007f\b<d}¬}ô>üÒë1\u0083¥ÍoZòÃyfç\u0002z_y\u008fÕD\u00914\u008c^\u0000\u0091\u0016¥gm¤\u0091a\u0096áé]\u0018W\u0017\u0017\rÑ\u000eÓ`\u001daèª\u009eG·M\u0090\u0000©Yª»m ×ùë\u009d}\u0090×\u0083æÚXÖ@\u0098t\r\u0007\b\u0014Jve?£\u007f\u0005àg\u0005¦\u0010  ¾ò8÷¼\u0002H\u0001Ô0í[\u0004\u000bKï±\u0095LµO.X9Ôu\u0086Aíª1ü P'sã\u0089\u008fÚ%¦©\u0090Â\\ô¾\u001b\u0099íºÆ\u001d\u009f|µB©\u00859Ú\u0080\u0019\u00ad ãUÁY\n\u00838\u009b.ú\u009dõ\u0002Hô0Éû-\u007f\u00965\u0099{B¬×¦Ê\u008dW\u000f zr\u0082\u0019°OÊê'ZþZÓ¯¯2u\u0003\u0004\u008fÌa®YßuiùPà<+\u0018.\u0005\u001e(l\u009b\u0090+híÝ¼þ·Dû¬\u000bvÉë\u0090g·\u0018I\u008d»\ry\u00957Z\u008f*BÎ*ßóa'H\u0089yì\u0017:á\u0018Ø_6Î\u0099\u009fzó©]Éêá\u000fnLÌ\u001e¸\u007fù£\u0084}0©\u0083¤£¾ÂU\u0007IVù\u0095?\"Ï·\fZ\u0080r!¨\fowõZ8tå³\u0091)\u0086ä6æ¿\u0005[®QøßÿÒt\u0005 ûÝ¬m[*\u0087@p¥¢\u000f\u0006m\u0081ÈÁY£d³<Ì\u0096¡gí\u0091\u0013&Ð\u0097\u0018\u009eá÷<\u0092á>A«kÓk\u009e´CL\u0093Jt=+2¦¡\u0018Õ\u00842iþ\u0003\u009bEõ\týk@¸/a®\u0011¯4\u008bMqê@\u0017ñ\u0097ãa\u0089¤»\nq§ð\u007früÔ´g\u001b\u001dÃÐi1¿â(\u00860\u009c9]\u0089N@\u009cc1ÓG\u0089\u0082Õ°ÏöBJã2\ng\u001cç×hÛÃ´\u000f\u0000Ìwn\u0018P;)\u0012\u0088{\u0013úù£\u0006ì|\u00adÚù\u009aqq¶RM\tB(}\u008eÛf\u009d³B´(ãÜNn\u0089¸sÙ\u009eß%\u001b\u008a\u008b\thJI¾\u0096_\u0001\u0006\u0004\u0015´\u009b\u008d\u0003\u009f\u009c Ò\fú\u0097\u0003\u008b¾AÞ\u001b¦\u001a\u009c\u001c\u000bùÌDõÖºÂ\u0004¢ \u0000-6î\u0013\u0087ì Z%³\u009dK¢¡ÞNõÁ\u0001=\u0000\u0088¦\u0012fÙ\u0087»Á\u001fÖ\u008d\u0084ÖF¨)ïî\u0018\u009e#\u0002\u009b\u009d\u000fW\u001f\f'ûP¾øNB\u000f\u0011Ê¯\u0017_áÈ \u0082©&[ÿ]!\u0081Sª\u0082P±V\u0001jsZkñ\u0015\u001cÒü§§;\u0011w9Å\f \f6\u007f¨\u000b\u008d\tèÜB#\u000f$ãç>\u008eSÊê\u0016Y$Bz\u0019ä\u0018_\u0012ì\u0087 ¶O{\u000e\u0091GYÂ\u0080Ig4õ±øú`Ì\b\u0017g\u008cI\u0094)0x«IàTY";
      short var24 = 1325;
      char var21 = ' ';
      int var27 = -1;

      label57:
      while (true) {
         String var29 = var22.substring(++var27, var27 + var21);
         int var10001 = -1;

         while (true) {
            String var40 = c(var18.doFinal(var29.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var40;
                  if ((var27 += var21) >= var24) {
                     c = var25;
                     h = new String[40];
                     Cipher var11;
                     Cipher var31 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(var16 << var12 * 8 >>> 56);
                     }

                     var31.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var15 = var11.doFinal(new byte[]{-66, -101, 45, -39, -93, -50, 117, -58});
                     long var44 = (var15[0] & 255L) << 56
                        | (var15[1] & 255L) << 48
                        | (var15[2] & 255L) << 40
                        | (var15[3] & 255L) << 32
                        | (var15[4] & 255L) << 24
                        | (var15[5] & 255L) << 16
                        | (var15[6] & 255L) << 8
                        | var15[7] & 255L;
                     var10001 = (byte)-1;
                     j = var44;
                     m = new HashMap(13);
                     Cipher var0;
                     Cipher var32 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var16 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var16 << var1 * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0005Ø\u008búh9ÑZÝ6ê\u001ah).\u0098".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var48 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     k = var6;
                     l = new Long[2];
                     return;
                  }

                  var21 = var22.charAt(var27);
                  break;
               default:
                  var25[var23++] = var40;
                  if ((var27 += var21) < var24) {
                     var21 = var22.charAt(var27);
                     continue label57;
                  }

                  var22 = "\u000e§\\Q\u001a\u0088\u0081Ü\u000bÀV\u0012_·ù¼#\bZ\u00907î¿É_+v#\u00966Â\u00180Û\u0095\u0004m¹¥YÂ:?Ç\u0014 \u0006i\u008c+])!0X,Ãq@yK\u008aBÖj û\u0091ÐÊ$\u009aþW\u0092ñÜÜXüg";
                  var24 = 81;
                  var21 = ' ';
                  var27 = -1;
            }

            var29 = var22.substring(++var27, var27 + var21);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void B(LivingUpdateEvent event) {
      long a = 树友树友树树何何树何.a ^ 112715615283145L;
      long ax = a ^ 11943011829084L;
      long axx = a ^ 126471920222878L;
      long axxx = a ^ 132827976108003L;
      long axxxx = a ^ 61949341857096L;
      long axxxxx = a ^ 107258258355147L;
      long axxxxxx = a ^ 105624254894424L;
      long var10001 = a ^ 40360534363226L;
      int axxxxxxx = (int)((a ^ 40360534363226L) >>> 48);
      int axxxxxxxx = (int)((a ^ 40360534363226L) << 16 >>> 32);
      int axxxxxxxxx = (int)(var10001 << 48 >>> 48);
      d<"Z">(-4864617954939883277L, a);
      if (!this.w(new Object[]{ax}) && d<"z">(mc, -4865718001595680755L, a) != null) {
         if (d<"z">(this, -4865478535366934305L, a) != null && d<"z">(this, -4864861247989861093L, a)) {
            Vec3 hitVec = new Vec3(
               d<"z">(this, -4865478535366934305L, a).getX() + 0.5 + cn.cool.cherish.utils.友树树何何树树何何树.Q(axxxx, -0.3, 0.3),
               d<"z">(this, -4865478535366934305L, a).getY() + 0.5 + cn.cool.cherish.utils.友树树何何树树何何树.Q(axxxx, -0.3, 0.3),
               d<"z">(this, -4865478535366934305L, a).getZ() + 0.5 + cn.cool.cherish.utils.友树树何何树树何何树.Q(axxxx, -0.3, 0.3)
            );
            Vec3 eyePos = mc.player.getEyePosition();
            double diffX = d<"z">(hitVec, -4864106937662782315L, a) - d<"z">(eyePos, -4864106937662782315L, a);
            double diffY = d<"z">(hitVec, -4871523629504886670L, a) - d<"z">(eyePos, -4871523629504886670L, a);
            double diffZ = d<"z">(hitVec, -4864359187822603493L, a) - d<"z">(eyePos, -4864359187822603493L, a);
            double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
            float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
            float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
            d<"n">(
               this,
               new Rotation(
                  axxxxx,
                  cn.cool.cherish.utils.友树树何何树树何何树.g(yaw, (char)axxxxxxx, axxxxxxxx, (char)axxxxxxxxx),
                  cn.cool.cherish.utils.友树树何何树树何何树.w(pitch, axx, -90.0F, 90.0F)
               ),
               -4865921566298062516L,
               a
            );
            if (d<"z">(this, -4871625118509633252L, a).getValue()) {
               Rotation var10000 = d<"z">(this, -4865921566298062516L, a);
               boolean var10002 = d<"z">(this, -4865694345914190120L, a).getValue();
               boolean var10004 = d<"z">(this, -4865407433115625256L, a).getValue();
               Object[] var10007 = new Object[]{null, null, null, null, null, d<"z">(this, -4871432620539341293L, a).getValue().floatValue()};
               var10007[4] = var10004;
               var10007[3] = true;
               var10007[2] = var10002;
               var10007[1] = axxxxxx;
               var10007[0] = var10000;
               RotationUtils.y(var10007);
            }

            Rotation var32 = d<"z">(this, -4865921566298062516L, a);
            LocalPlayer var33 = mc.player;
            var32.A(new Object[]{axxx, var33});
         }
      }
   }

   protected void F() {
      long a = 树友树友树树何何树何.a ^ 70564022668879L;
      long ax = a ^ 48869803994330L;
      long axx = a ^ 97275980997850L;
      d<"Z">(6195617252480833909L, a);
      if (!this.w(new Object[]{ax})) {
         if (d<"z">(this, 6196383176379657073L, a) != -1) {
            d<"n">(mc.player.getInventory(), d<"z">(this, 6196383176379657073L, a), 6196430686127367867L, a);
            d<"n">(this, -1, 6196383176379657073L, a);
         }

         if (d<"z">(this, 6196098584356261798L, a)) {
            d<"z">(d<"z">(mc, 6195271223630381287L, a), 6195354611916368263L, a).setDown(false);
            d<"n">(this, false, 6196098584356261798L, a);
         }

         ClientUtils.n(new Object[]{b<"c">(11883, 3862382756860784994L ^ a), axx});
      }
   }

   private String S(BlockPos pos) {
      long a = 树友树友树树何何树何.a ^ 97397881709000L;
      d<"Z">(4214341933625226994L, a);
      if (mc.level.getBlockState(pos).is(d<"à">(4213865022888770632L, a))) {
         return b<"c">(19222, 4280741838867069833L ^ a);
      } else {
         return mc.level.getBlockState(pos).is(d<"à">(4214910137050336331L, a))
            ? b<"c">(27532, 8520442704699841281L ^ a)
            : b<"c">(31431, 8082893705029143120L ^ a);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   @EventTarget
   public void e(TickEvent event) {
      long a = 树友树友树树何何树何.a ^ 122845757434376L;
      long ax = a ^ 4283516061853L;
      long axx = a ^ 1692380228928L;
      long axxx = a ^ 131872179896477L;
      long axxxx = a ^ 54517393949218L;
      d<"Z">(-1027825086492803790L, a);
      if (!this.w(new Object[]{ax}) && d<"z">(mc, -1028942256043444788L, a) != null) {
         this.L();
         if (!d<"z">(this, -1027520821560706854L, a)) {
            if (d<"z">(this, -1026907250410233524L, a).getValue() && this.j(mc.player.getOffhandItem())) {
            }

            d<"n">(this, d<"à">(-1034538511610586769L, a), -1027098969328722065L, a);
            d<"n">(this, (int)j, -1034600862105325439L, a);
            d<"n">(this, d<"à">(-1030537901686001423L, a), -1027098969328722065L, a);
            d<"n">(this, this.j(), -1034600862105325439L, a);
            if (d<"z">(this, -1034600862105325439L, a) == -1) {
               ClientUtils.n(new Object[]{b<"c">(13585, 8435282367683939907L ^ a), axxx});
               this.y(false);
            } else {
               if (d<"z">(this, -1028139901181965026L, a) == null
                  && d<"z">(this, -1027419001528315468L, a).Y(d<"z">(this, -1027802467093149465L, a).getValue().longValue(), axx)) {
                  d<"n">(this, this.b(), -1028139901181965026L, a);
                  if (d<"z">(this, -1028139901181965026L, a) != null) {
                     String liquidType = this.S(d<"z">(this, -1028139901181965026L, a));
                     ClientUtils.n(new Object[]{b<"c">(13780, 7111949068970184350L ^ a) + liquidType + b<"c">(28012, 8121086883355268668L ^ a), axxx});
                     d<"z">(this, -1027419001528315468L, a).U(axxxx);
                  }
               }

               if (d<"z">(this, -1028139901181965026L, a) != null
                  && !d<"z">(this, -1027520821560706854L, a)
                  && d<"z">(this, -1027419001528315468L, a).Y(d<"z">(this, -1027802467093149465L, a).getValue().longValue(), axx)) {
                  d<"n">(this, true, -1027520821560706854L, a);
                  this.G();
               }
            }
         }
      }
   }

   private boolean i(BlockPos pos) {
      long a = 树友树友树树何何树何.a ^ 18440774739169L;
      d<"Z">(-48112462587464741L, a);
      Vec3 eyePos = mc.player.getEyePosition();
      Vec3 blockCenter = new Vec3(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
      HitResult result = mc.level.clip(new ClipContext(eyePos, blockCenter, d<"à">(-50583865356552323L, a), d<"à">(-48603266742764773L, a), mc.player));
      return result.getType() == d<"à">(-49095898197377668L, a) || result instanceof BlockHitResult blockHit && blockHit.getBlockPos().equals(pos);
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 22;
               case 1 -> 30;
               case 2 -> 8;
               case 3 -> 4;
               case 4 -> 38;
               case 5 -> 57;
               case 6 -> 14;
               case 7 -> 21;
               case 8 -> 26;
               case 9 -> 3;
               case 10 -> 37;
               case 11 -> 49;
               case 12 -> 12;
               case 13 -> 45;
               case 14 -> 2;
               case 15 -> 58;
               case 16 -> 62;
               case 17 -> 34;
               case 18 -> 31;
               case 19 -> 20;
               case 20 -> 23;
               case 21 -> 16;
               case 22 -> 25;
               case 23 -> 15;
               case 24 -> 61;
               case 25 -> 11;
               case 26 -> 43;
               case 27 -> 0;
               case 28 -> 35;
               case 29 -> 63;
               case 30 -> 9;
               case 31 -> 60;
               case 32 -> 51;
               case 33 -> 59;
               case 34 -> 55;
               case 35 -> 56;
               case 36 -> 6;
               case 37 -> 1;
               case 38 -> 29;
               case 39 -> 19;
               case 40 -> 7;
               case 41 -> 53;
               case 42 -> 41;
               case 43 -> 28;
               case 44 -> 46;
               case 45 -> 52;
               case 46 -> 44;
               case 47 -> 17;
               case 48 -> 36;
               case 49 -> 32;
               case 50 -> 39;
               case 51 -> 47;
               case 52 -> 40;
               case 53 -> 13;
               case 54 -> 24;
               case 55 -> 18;
               case 56 -> 48;
               case 57 -> 10;
               case 58 -> 27;
               case 59 -> 5;
               case 60 -> 33;
               case 61 -> 50;
               case 62 -> 54;
               default -> 42;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友树友树树何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2790;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树友树友树树何何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private BlockPos b() {
      long a = 树友树友树树何何树何.a ^ 519388652316L;
      d<"Z">(-529171559812795354L, a);
      if (mc.player != null && mc.level != null) {
         BlockPos playerPos = mc.player.blockPosition();
         List<BlockPos> liquidBlocks = new ArrayList<>();
         int horizontalRange = (int)Math.ceil(d<"z">(this, -529475205521614333L, a).getValue().doubleValue());
         int verticalRangeValue = (int)Math.ceil(d<"z">(this, -527527045323922823L, a).getValue().doubleValue());
         int x = -horizontalRange;
         if (x <= horizontalRange) {
            int y = -verticalRangeValue;
            if (y <= verticalRangeValue) {
               int z = -horizontalRange;
               if (z <= horizontalRange) {
                  BlockPos pos = playerPos.offset(x, y, z);
                  double distance = mc.player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                  if (distance
                     > d<"z">(this, -529475205521614333L, a).getValue().doubleValue() * d<"z">(this, -529475205521614333L, a).getValue().doubleValue()) {
                  }

                  if (this.K(pos)) {
                     if (d<"z">(this, -526595052618367187L, a).getValue() && !this.i(pos)) {
                     }

                     liquidBlocks.add(pos);
                  }

                  z++;
               }

               y++;
            }

            x++;
         }

         if (liquidBlocks.isEmpty()) {
            return null;
         } else {
            if (d<"z">(this, -528468763921423426L, a).getValue()) {
               BlockPos belowFeet = playerPos.below();
               Iterator var19 = liquidBlocks.iterator();
               if (var19.hasNext()) {
                  BlockPos posx = (BlockPos)var19.next();
                  if (posx.equals(playerPos) || posx.equals(belowFeet)) {
                     return posx;
                  }
               }
            }

            Vec3 eyePos = mc.player.getEyePosition();
            return liquidBlocks.stream().min(Comparator.comparingDouble(posx -> Vec3.atCenterOf(posx).distanceToSqr(eyePos))).orElse(null);
         }
      } else {
         return null;
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 2672;
      if (l[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = k[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])m.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树友树友树树何何树何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         l[var3] = var15;
      }

      return l[var3];
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'z' && var8 != 'n' && var8 != 224 && var8 != 240) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'u') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'z') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'n') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 224) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友树友树树何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友树友树树何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      n[0] = "WFs\"iwX\u0006>)cj][5okwP]1$(qYX1ovtUQ83(栉叿根厖桐栗位佡根伈";
      n[1] = "m4sS>Jbt>X4Wg)5\u001e$Qg6.\u001e9@b*8B\u007fwa.<D8J`";
      n[2] = "a\\e\u0007v.a\\r[z!{\u0017fFi+k\u0017XGo\"}Xr]r(aqpG\u007f";
      n[3] = boolean.class;
      o[3] = "java/lang/Boolean";
      n[4] = "juMek5juZ9g:p>Z$t9*RU$e7T\u007fJ";
      n[5] = "83\u0015g_d7sXlUy2.S*Fj7(^*Yf+1\u0015F_d78Zjfj7(^";
      n[6] = int.class;
      o[6] = "java/lang/Integer";
      n[7] = "z6@\u0012JPuv\r\u0019@Mp+\u0006_HP}-\u0002\u0014\u000b佪佌厓伻伤叮佪佌桉桿";
      n[8] = "0\u0003U\n\u00108;\fDEl!4\u0016J\u0006[\u0011\"\u0001F\u001bJ=5\f";
      n[9] = "8k;o%\u001d8k,3)\u0012\" ,-!\u00118za\f!\u001a3m= .\u0000";
      n[10] = "&`erN!&`r.B.<+r0J-&q?\u0013S<!j\u007f/";
      n[11] = "d-\u0019Wc\u001ad-\u000e\u000bo\u0015~f\u000e\u0015g\u0016d<C2k\nG)\u001d\tg\u001dm";
      n[12] = "9\u0011\b3h(6QE8b53\fN~j(>\nJ5).7\u000fJ~w+;\u0006C\")伒伏厴佳厛栖厌厑伪佳";
      n[13] = "mA\u0019M$/Yb\u0016\ri$S\u007f\u0013Pbb[b\u001eVf)\u0018@\u0015G\u007f S6";
      n[14] = "x\u000b1)U8x\u000b&uY7b@2hJ=r@ iL8b\u0017kwT0o\u000b7)q?`\u000b+sW#o";
      n[15] = "\tZ\u000b\u007f /\u0006\u001aFt*2\u0003GM2:4\u0003XV2桞压桻叿叮佉会桑伿佡";
      n[16] = "S\u0015IWrh\\U\u0004\\xuY\b\u000f\u001akf\\\u000e\u0002\u001atj@\u0017IzhjR\u001e\u0015b|kE\u001e";
      n[17] = "}\u0012K0!h}\u0012\\l-ggYHq>mwYS{:d\u007fY]r#bxY}r#bx\u0004";
      n[18] = "_\u0013X`_\u000e_\u0013O<S\u0001EX[!@\u000bUX@+D\u0002]XN\"]\u0004ZXn\"]\u0004Z";
      n[19] = "V`S2j\"V`Dnf-L+Dpn.Vq\tlk*A`U2K$[dKLk*A`U";
      n[20] = "\u001bZ_N#l\u001bZH\u0012/c\u0001\u0011H\f'`\u001bK\u0005\r;i\u0001V[\f/|\u0010M\u0005#\"l\u0010Q_0/f\u001eZ_,'v\u0001ZE\u0005<";
      n[21] = "V\u0012KW+\u0019V\u0012\\\u000b'\u0016LYH\u00164\u001c\\YV\r#\u001d\u0016>K\u001c+\u0003";
      n[22] = "Q;Bx4\u001cQ;U$8\u0013KpA9+\u0019[p_\"<\u0018\u0011\u0017B34";
      n[23] = "Qwj-C<Qw}qO3K<il\\9[<nkW&\u0011Zww|0Lgrw\n\u0001Fb{";
      n[24] = "Tw',),Tw0p%#N<$m6)^<?g2 V<\u0010n-5y}=v!=N6\u0015n1,^";
      n[25] = "&&B\u0010S3&&UL_<<mAQL6,mZ[H?$muRW*\u000b,XJ[\"<gtRQ9#";
      n[26] = "k8\u0003v7sk8\u0014*;|qs\u001443\u007fk)Y5/vq4\u00074;c`/Y\u0015/vq4'4;c`/097\u007fH2\u0013=";
      n[27] = "@oK\u0015\u0011j@o\\I\u001deZ$HT\u000eoJ$OS\u0005p\u0000\\ZXO";
      n[28] = double.class;
      o[28] = "java/lang/Double";
      n[29] = "tHwTE@\u007fGf\u001b$NtLbA";
      n[30] = "5\u0010X_Fb9QR0佼栗桁桱号佭佼栗伅伵4ZFoa\u0015SSL?7";
      n[31] = "t\u001d}\u0014\u000bB/\u0014b\u0010pw\u0007dU=0{\bi\u0013PH\\0^c\u000bAC4";
      n[32] = "F'\r cA\u0019j\u00053\u0004\u0011/&Mb:A/\u0017K1v\u0003\u0002{\u0005kmB";
      n[33] = "[\u001705\u0013:\u0015M+ti83MxqXk3|rs\u00076_\u001d'(\u0005/";
      n[34] = "&\u0010\n!\u00197*Q\u0000N伣桂桒伵桿伓伣伆桒伵ft\u0010b3T\u001d*\u0003a&";
      n[35] = "N} 1p\u0004B<*^佊桱佾栜休桇叔伵佾佘L7t\r\u0012a6g.\u0002H";
      n[36] = "'\u0019*et%+X \n叐厊众似厅佗叐伔众桸F1h9)\r 0,9t";
      n[37] = "\u0011\u0018/\u000b( [\u0016'\u001cS>!X5\\.{\u001b\f8\u0015!A";
      n[38] = "][{J9RQ\u001aq%伃栧佭栺叔另桇栧佭栺\u0017O9_\t^pF3\u000f_";
      n[39] = "_'{\u0004\u000e\u001a\u0004,q_o伢厡厄叕司厬伢伿桞叕;R\u001f\u000fxw^\t\u0014\u0005#";
      n[40] = "\\y<\u001cCMP86s栽核佬参厓厰栽佼史作PI\u001cOOz \u0012\u0015PK";
      n[41] = "Y.L'|\u0002Bz\u001f\"\u0017Vlu\u0014#'\u0001lELztQVx\u001f`}Z";
      n[42] = "n6wHa\u0002bw}'栟厭叀厍变佺佛厭佞伓\u001b\u001c}\u001e`\"}\u001d9\u001e=";
      n[43] = "#{B,\u000eb4l\u001a(r~\u00188\u001adL)pV\"9\u001b|#jA&\u0002r$";
      n[44] = "\u0001!7\\?~\u001audYT*4zoXku4J7\u00017-\u000ewd\u001b>&";
      n[45] = "\u0018\u0006\" ~d\u000eCa1Bz%Diks-%x4a3/\u0013\u0003)%=v";
      n[46] = "zv&\u000fF9v7,`核厖叔体厉厣核伈栎体J[Z%tb,Z\u001e%)";
      n[47] = "x\u0001@\u0013}\u001ft@J|叙桪佈伤可县栃伮佈厺,Ga\u0003v\u0015JF%\u0003+";
      n[48] = "74.\u0016Pq8g\"\u001dk \t2pETq\t\tq\u0018\b0`pwH\u000e1";
      n[49] = "tZ};\u0002\u000fx\u001bwT\fc$Xr(Y\u0011x\u001buee^cAmh\u0017\u0002 F T";
      n[50] = "Q=#*w_]|)E叓台栥历伒桜位株佡优O/wR\u00058(&}\u0002S";
      n[51] = "F\u0002a$%lJCkK桛栙叨厹収伖厁參佶厹\r6{eO\b\u007fz%1";
      n[52] = "E(Z\u001f1<IiPp桏厓叫伍栯桩伋桉併伍6\u001955\u00194LIo:C";
      n[53] = "is\u001f@\u0000V6>\u0017Sg\u0006\u0000r_\u0002XR\u0000C\u0007\u0006\u000b\u0016>|\u0004VW\u0018";
      n[54] = "?\u0002ir\b\u001a3Cc\u001d桶厵桋厹佘叞桶厵桋厹\u0005&\u0014\u00061\u0016c'P\u0006l";
      n[55] = "bp\ru\u0015\u0013||\u00036h1LK2O\u0007\u0014i*\u0014(\u0019\u0018gi";
      n[56] = "\\\u001b9\fL\u0016PZ3c佶伧佬桺桌厠栲伧佬桺UXP\nR\u000f3Y\u0014\n\u000f";
      n[57] = "\u0010\u000b\u0003kR\u000b\u001cJ\t\u0004佨伺厾厰厬余栬厤桤厰o?\u0004\u0004\u0005\u001a\u001dv\\\u0002\u0019";
      n[58] = "p\u00011\u0012W\u007f|@;}右栊栄桠伀厾佭低叞桠]FKc~\u0015;G\u000fc#";
      n[59] = "\bj3LmF\u0004+9#叉叩桼住伂栺佗栳伸发_\u0019d\u0013\u001d.$Gw\u0010\b";
      n[60] = "s\u0013\b\u0003\u001e\u0001w\\\u0015\u000ez\u007f[+8g\u0015Ga\t\u0011_\u0011\b|\u0004";
      n[61] = " L7;`-,\r=T叄桘桔佩伆伉佚伜伐号[o|1.X=n81s";
      n[62] = "|\u0001lNOTjD/_sJAC'\u0005B\u001cA\u007fz\u000f\u0002\u001fw\u0004gK\fF";
      n[63] = "_\u001a+[()S[!4厌桜叱厡厄佩桖历栫厡G\b#&L\\>\u000es M";
      n[64] = "y\u000f\tCvr~\u001f\u0006\u0004\n\\D9+}LV\u0019\u0005\u0005Zugp\u0002\u0015U2";
      n[65] = "W\u0007n?\u000b\u0005[FdP厯厪佧厼佟桉伱厪叹桦\u0002k\u0017\u0019Y\u0013djS\u0019\u0004";
      n[66] = "vtW;\nWz5]T估司但叏佦桍厮栢变栕;o\u0016Kx`]nRK%";
      n[67] = "VLYZQbM\u0018\n_:6c\u0017\u0001^\n`c'Y\u0007Y1Y\u001a\n\u001dP:";
      n[68] = "\u0014%i@tJ\u0018dc/栊句桠伀栜佲叐栿伤桄\u0005EtG@ bL~\u0017\u0016";
      n[69] = "l#\u001ec,\u0011`b\u0014\f伖传作伆厱栕厈桤栘桂r0'\u001e\u007fe\u000b6w\u0018~";
      n[70] = "GDCtVV\u001cM\\p-a32zJd`1|\u00172CX\u0006\fL;\\\\";
      n[71] = "\t\u0002[,\u000f\u0006]\u001b\u0003,fS3[\u0001*Z\u00033gUk\bR[\u0001Wm\u0016\u0000";
   }

   public Rotation p() {
      long a = 树友树友树树何何树何.a ^ 19947159389997L;
      return d<"z">(this, -7161652794040491608L, a);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 树友树友树树何何树何.a ^ 7091035868584L;
      long ax = a ^ 116737586720573L;
      long axx = a ^ 97152478078338L;
      long axxx = a ^ 33151265482557L;
      d<"Z">(-7630215633605813614L, a);
      if (!this.w(new Object[]{ax})) {
         d<"n">(this, null, -7630884556303930579L, a);
         d<"n">(this, null, -7630441387918120258L, a);
         d<"n">(this, false, -7629684319621406854L, a);
         d<"n">(this, false, -7630311028358198207L, a);
         d<"z">(this, -7629741988870588908L, a).U(axx);
         d<"z">(this, -7631258591991833212L, a).U(axx);
         d<"n">(this, d<"à">(-7632859248351078575L, a), -7629261438746707761L, a);
         ClientUtils.n(new Object[]{b<"c">(25457, 8991318981962006418L ^ a), axxx});
      }
   }

   private int j() {
      long a = 树友树友树树何何树何.a ^ 114045550194941L;
      d<"Z">(-1492549082203920441L, a);
      int i = 0;
      ItemStack stack = mc.player.getInventory().getItem(0);
      if (this.j(stack)) {
         return 0;
      } else {
         i++;
         return -1;
      }
   }

   private boolean j(ItemStack stack) {
      long a = 树友树友树树何何树何.a ^ 135767069729713L;
      d<"Z">(-5186604948505152373L, a);
      return !stack.isEmpty() && stack.getItem() == d<"à">(-5179736198302254271L, a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void L() {
      long a = 树友树友树树何何树何.a ^ 111738137961795L;
      long ax = a ^ 12714580009483L;
      long axx = a ^ 65485372132713L;
      long axxx = a ^ 138494237134806L;
      d<"Z">(9148891797221732985L, a);
      if (d<"z">(this, 9147043222099272874L, a) && d<"z">(this, 9147709613171553647L, a).Y(c<"p">(1850, 1636270050480255925L ^ a), ax)) {
         d<"z">(d<"z">(mc, 9148539103605976043L, a), 9148631344859726475L, a).setDown(false);
         d<"n">(this, false, 9147043222099272874L, a);
         d<"z">(mc.player, 9148170829653553991L, a).send(new ServerboundSwingPacket(d<"z">(this, 9147946602433040420L, a)));
         d<"n">(this, false, 9148650720980957073L, a);
         d<"n">(this, null, 9146910002627887701L, a);
         d<"z">(this, 9148734742715539199L, a).U(axx);
         if (d<"z">(this, 9147334374735528061L, a) != -1) {
            d<"n">(mc.player.getInventory(), d<"z">(this, 9147334374735528061L, a), 9147375358230105527L, a);
            d<"n">(this, -1, 9147334374735528061L, a);
         }

         String message = b<"c">(27269, 4532914957130669717L ^ a);
         if (d<"z">(this, 9146837499862126674L, a).getValue() && this.b() != null) {
            message = message + b<"c">(1658, 525510569178657349L ^ a);
         }

         ClientUtils.n(new Object[]{message, axxx});
         if (d<"z">(this, 9148404171905453675L, a).getValue() && (!d<"z">(this, 9146837499862126674L, a).getValue() || this.b() == null)) {
            this.y(false);
         }
      }
   }

   private void G() {
      long a = 树友树友树树何何树何.a ^ 139187385029502L;
      long ax = a ^ 35974763068244L;
      d<"Z">(5245145087826183236L, a);
      if (d<"z">(this, 5245920713864082536L, a) != null
         && (d<"z">(this, 5247338781894871543L, a) != -1 || d<"z">(this, 5244744958700840473L, a) == d<"à">(5247403408618610713L, a))
         && !d<"z">(this, 5246069523932385943L, a)) {
         if (d<"z">(this, 5244744958700840473L, a) == d<"à">(5243555629988202887L, a)) {
            d<"n">(this, d<"z">(mc.player.getInventory(), 5246441070678948746L, a), 5245786542503753280L, a);
            d<"n">(mc.player.getInventory(), d<"z">(this, 5247338781894871543L, a), 5246441070678948746L, a);
         }

         d<"z">(d<"z">(mc, 5245348729930997206L, a), 5245405537775875254L, a).setDown(true);
         d<"n">(this, true, 5246069523932385943L, a);
         d<"z">(this, 5246177182893802322L, a).U(ax);
      }
   }

   private boolean K(BlockPos pos) {
      long a = 树友树友树树何何树何.a ^ 65387383083762L;
      d<"Z">(-3943400351891569208L, a);
      if (mc.level.getBlockState(pos).getBlock() instanceof LiquidBlock) {
         FluidState fluidState = mc.level.getFluidState(pos);
         if (fluidState.isSource()) {
            if (mc.level.getBlockState(pos).is(d<"à">(-3944937749615505550L, a))) {
               return d<"z">(this, -3945092039755114350L, a).getValue();
            }

            if (mc.level.getBlockState(pos).is(d<"à">(-3943959628101058703L, a))) {
               return d<"z">(this, -3943359614251071989L, a).getValue();
            }
         }
      }

      if (mc.level.getBlockState(pos).is(d<"à">(-3944937749615505550L, a)) && d<"z">(this, -3945092039755114350L, a).getValue()) {
         return mc.level.getFluidState(pos).isSource();
      } else {
         return mc.level.getBlockState(pos).is(d<"à">(-3943959628101058703L, a)) && d<"z">(this, -3943359614251071989L, a).getValue()
            ? mc.level.getFluidState(pos).isSource()
            : false;
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖国企变私企";
   }
}
