package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.item.友何树何友树友树何何;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.树友友何树友树树树何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.move.MoveMathEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class 何树何树友何何何树友 extends Module implements 何树友 {
   private final BooleanValue 树何何何树何友树何树;
   private final NumberValue 树树何树何树何树友友;
   private final BooleanValue 何友何友何树何树友树;
   private final BooleanValue 树树友友树树何友何友;
   private boolean 树何树友树何树树友树;
   private boolean 何何友友树树友何树何;
   private boolean 友树何树树树友树何友;
   private int 树何树树友友何友友友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[56];
   private static final String[] k = new String[56];
   private static int _我是何树友 _;

   public 何树何树友何何何树友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/何树何树友何何何树友.a J
      // 003: ldc2_w 3871414949175
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 25664
      // 00c: ldc2_w 1158045412764321480
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 1907
      // 019: ldc2_w 8338588067568281078
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w 3404701291495898715
      // 026: lload 1
      // 027: invokedynamic î (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/BooleanValue
      // 033: dup
      // 034: sipush 7025
      // 037: ldc2_w 6178248578922871286
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 15650
      // 044: ldc2_w 3892063659341340578
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 1
      // 04f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 052: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 055: putfield cn/cool/cherish/module/impl/player/何树何树友何何何树友.树何何何树何友树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 058: aload 0
      // 059: new cn/cool/cherish/value/impl/NumberValue
      // 05c: dup
      // 05d: sipush 17869
      // 060: ldc2_w 6406362143035664199
      // 063: lload 1
      // 064: lxor
      // 065: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 06a: bipush 20
      // 06c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 06f: bipush 1
      // 070: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 073: bipush 20
      // 075: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 078: bipush 1
      // 079: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 07c: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 07f: putfield cn/cool/cherish/module/impl/player/何树何树友何何何树友.树树何树何树何树友友 Lcn/cool/cherish/value/impl/NumberValue;
      // 082: aload 0
      // 083: new cn/cool/cherish/value/impl/BooleanValue
      // 086: dup
      // 087: sipush 28895
      // 08a: ldc2_w 3433729863063016028
      // 08d: lload 1
      // 08e: lxor
      // 08f: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 094: sipush 31022
      // 097: ldc2_w 948801521141095343
      // 09a: lload 1
      // 09b: lxor
      // 09c: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a1: bipush 1
      // 0a2: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0a5: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0a8: putfield cn/cool/cherish/module/impl/player/何树何树友何何何树友.何友何友何树何树友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0ab: aload 0
      // 0ac: new cn/cool/cherish/value/impl/BooleanValue
      // 0af: dup
      // 0b0: sipush 13782
      // 0b3: ldc2_w 4817522620911966034
      // 0b6: lload 1
      // 0b7: lxor
      // 0b8: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bd: sipush 14712
      // 0c0: ldc2_w 3377084942388845562
      // 0c3: lload 1
      // 0c4: lxor
      // 0c5: invokedynamic r (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ca: bipush 1
      // 0cb: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0ce: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0d1: putfield cn/cool/cherish/module/impl/player/何树何树友何何何树友.树树友友树树何友何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0d4: aload 0
      // 0d5: bipush 0
      // 0d6: ldc2_w 3403383502268526847
      // 0d9: lload 1
      // 0da: invokedynamic g (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0df: aload 0
      // 0e0: bipush 0
      // 0e1: ldc2_w 3403628868097540449
      // 0e4: lload 1
      // 0e5: invokedynamic g (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ea: aload 0
      // 0eb: bipush 0
      // 0ec: ldc2_w 3403713713656623989
      // 0ef: lload 1
      // 0f0: invokedynamic g (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f5: aload 0
      // 0f6: bipush 0
      // 0f7: ldc2_w 3400536553048162283
      // 0fa: lload 1
      // 0fb: invokedynamic g (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/何树何树友何何何树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 100: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-342488524603832568L, -1682209216168106094L, MethodHandles.lookup().lookupClass()).a(176678425597280L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 11650187396261L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[11];
      int var7 = 0;
      String var6 = "\u0006«ø%èÆ\u008cG\u0087^¡ÞË\u0016 ëúªsÀl^÷ûÞîìh~[È\u0088\nøe¥ÚïÌã\u0018¨\u000eÈ\u0018åª(H´\u001b \u0005\u0002aï-\u001c\u0098\u001b=\u0093íâ\u008a \u007f¢ò[\"WMÿÅ\u0018àx\u0010çÞD\u009a\u008a¶hK¤\u0096(M¤I\u0089\u008eÞbG\u0018\n\u0083Aá\u0093Ö>^ \u0012\u001aïÚ\u0088Yñ'BäeÃ}°\u001e0\u008bÝÅn\u001fÃ\u0011ù*Ï\u0096\tË\u008eÓ\u008aô-\u009a\u0098¬¿ö/¬d·¤Ìuz\u0012\u009bÔNN\u009aåúäã¦VÂ\u000f¯ôè\u0018è½ñÃï#ÄîËoÔni;:Ð\u001dIpzE3_K(*Î\u0096FND\u0001u4\u0081øD\u0092r\u000eÈO¸W\nÞ½[ä³7\u0014\rt.À\u009c;åG°êæ\u0011ð ¼ðj®¯Â8A\u000eY\u0003¶³\u001a¨o\u00ad7\u008e}U·Ý{É\u008f72/ú,\u0082\u0018F©Ò\u0095 \u000f}\u0095aÐáñ\u0091\u0013¤A'~,KH\u001d\u0019Á";
      short var8 = 296;
      char var5 = '(';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[11];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ûR¹\u008b/¯,\u0094Â\u0084¼l9,\u0090äÖ°!\u0080¡«\u0090\nF½3gï©\u0089Ñ\u0006¥\u000b\u009bd°\u0011\"\u00104Ö4/\u0080\u008e(7\u0092j\u0015`~ò/Q";
                  var8 = 57;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void F(MoveInputEvent event) {
      long a = 何树何树友何何何树友.a ^ 125513730567712L;
      long ax = a ^ 115631491181833L;
      c<"$">(1452286752199993969L, a);
      if (!this.w(new Object[]{ax}) && c<"Í">(this, 1453284118898133090L, a) && c<"Í">(this, 1453939974297252882L, a).getValue()) {
         event.setForwardImpulse(0.0F);
         event.setLeftImpulse(0.0F);
      }
   }

   public void F() {
      long a = 何树何树友何何何树友.a ^ 61021283250163L;
      c<"$">(6193797779443723170L, a);
      Module scaffold = Cherish.instance.getModuleManager().getModule(何何友何友树友友何何.class);
      if (scaffold.isEnabled() && c<"Í">(this, 6194748114998492069L, a)) {
         scaffold.y(false);
         c<"g">(this, false, 6194748114998492069L, a);
      }

      c<"g">(this, false, 6194806205951084977L, a);
      c<"g">(this, 0, 6193879954805212463L, a);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 26;
               case 1 -> 15;
               case 2 -> 11;
               case 3 -> 52;
               case 4 -> 17;
               case 5 -> 24;
               case 6 -> 20;
               case 7 -> 23;
               case 8 -> 56;
               case 9 -> 43;
               case 10 -> 0;
               case 11 -> 35;
               case 12 -> 55;
               case 13 -> 47;
               case 14 -> 54;
               case 15 -> 36;
               case 16 -> 27;
               case 17 -> 3;
               case 18 -> 30;
               case 19 -> 4;
               case 20 -> 39;
               case 21 -> 53;
               case 22 -> 37;
               case 23 -> 57;
               case 24 -> 51;
               case 25 -> 40;
               case 26 -> 46;
               case 27 -> 29;
               case 28 -> 62;
               case 29 -> 19;
               case 30 -> 14;
               case 31 -> 9;
               case 32 -> 7;
               case 33 -> 41;
               case 34 -> 22;
               case 35 -> 44;
               case 36 -> 13;
               case 37 -> 38;
               case 38 -> 2;
               case 39 -> 32;
               case 40 -> 28;
               case 41 -> 18;
               case 42 -> 49;
               case 43 -> 59;
               case 44 -> 31;
               case 45 -> 42;
               case 46 -> 60;
               case 47 -> 10;
               case 48 -> 6;
               case 49 -> 33;
               case 50 -> 12;
               case 51 -> 1;
               case 52 -> 8;
               case 53 -> 50;
               case 54 -> 63;
               case 55 -> 61;
               case 56 -> 16;
               case 57 -> 5;
               case 58 -> 48;
               case 59 -> 45;
               case 60 -> 25;
               case 61 -> 34;
               case 62 -> 21;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树何树友何何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 19892;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何树何树友何何何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   @EventTarget
   private void x(MoveMathEvent event) {
      long a = 何树何树友何何何树友.a ^ 14979841948488L;
      long ax = a ^ 24817269979233L;
      long axx = a ^ 86274648600101L;
      long axxx = a ^ 138278755274486L;
      c<"$">(4706244722750504729L, a);
      if (!this.w(new Object[]{ax}) && c<"Í">(this, 4702714089583451402L, a)) {
         if (!c<"Í">(this, 4705956060382567265L, a).getValue() || !mc.player.onGround()) {
            if (!mc.player.isSpectator()) {
               if (c<"Í">(this, 4705751303195906452L, a) >= c<"Í">(this, 4705773043170089756L, a).getValue().intValue()) {
                  RotationUtils.D(new Object[]{axx, new Rotation(axxx, mc.player.getYRot() + (float)(Math.random() - 0.5), mc.player.getXRot())});
                  event.setCancelled(false);
                  c<"g">(this, 0, 4705751303195906452L, a);
               }

               KeyMapping.set(c<"Í">(c<"Í">(mc, 4706011807942312355L, a), 4702233147054432896L, a).getKey(), false);
               event.setCancelled(true);
            }

            if (!c<"Í">(this, 4705956060382567265L, a).getValue() || mc.player.onGround() || mc.player.isSpectator()) {
               c<"g">(this, 0, 4705751303195906452L, a);
            }
         }
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何树何树友何何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 205 && var8 != 'g' && var8 != 238 && var8 != 227) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 248) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == '$') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 205) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'g') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 238) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private boolean n(BlockPos blockPosition) {
      long a = 何树何树友何何何树友.a ^ 79933601457866L;
      long ax = a ^ 80741673616606L;
      long axx = a ^ 118429197304160L;
      long axxx = a ^ 62597836919668L;
      Vec3 eyesPos = mc.player.getEyePosition();
      Direction[] prioritizedSides = new Direction[]{
         c<"î">(-7147840744368586481L, a),
         c<"î">(-7151495371711814485L, a),
         c<"î">(-7151590663218545440L, a),
         c<"î">(-7150941536596161999L, a),
         c<"î">(-7151271542826388517L, a),
         c<"î">(-7150848976124390219L, a)
      };
      c<"$">(-7147857408782867813L, a);
      int var14 = prioritizedSides.length;
      int var15 = 0;
      if (0 < var14) {
         Direction side = prioritizedSides[0];
         BlockPos neighbor = blockPosition.relative(side);
         if (友何树何友树友树何何.h(neighbor, ax)) {
            Vec3 dirVec = new Vec3(side.getNormal().getX(), side.getNormal().getY(), side.getNormal().getZ());
            Vec3 posVec = new Vec3(blockPosition.getX() + 0.5, blockPosition.getY() + 0.5, blockPosition.getZ() + 0.5);
            Vec3 hitVec = posVec.add(
               c<"Í">(dirVec, -7151102216837259321L, a) * 0.5, c<"Í">(dirVec, -7149751525995725785L, a) * 0.5, c<"Í">(dirVec, -7150706574308422460L, a) * 0.5
            );
            if (!(eyesPos.distanceToSqr(hitVec) > 25.0)) {
               if (mc.level.clip(new ClipContext(eyesPos, hitVec, c<"î">(-7148004524748687544L, a), c<"î">(-7149548836377758174L, a), mc.player)).getType()
                  != c<"î">(-7149704636038761595L, a)) {
               }

               Vec3 rotationVector = RotationUtils.l(
                  new Object[]{
                     new Rotation(
                        axxx,
                        (float)Math.toDegrees(
                              Math.atan2(
                                 c<"Í">(hitVec, -7150706574308422460L, a) - c<"Í">(eyesPos, -7150706574308422460L, a),
                                 c<"Í">(hitVec, -7151102216837259321L, a) - c<"Í">(eyesPos, -7151102216837259321L, a)
                              )
                           )
                           - 90.0F,
                        (float)(
                           -Math.toDegrees(
                              Math.atan2(
                                 c<"Í">(hitVec, -7149751525995725785L, a) - c<"Í">(eyesPos, -7149751525995725785L, a),
                                 Math.sqrt(
                                    (c<"Í">(hitVec, -7151102216837259321L, a) - c<"Í">(eyesPos, -7151102216837259321L, a))
                                          * (c<"Í">(hitVec, -7151102216837259321L, a) - c<"Í">(eyesPos, -7151102216837259321L, a))
                                       + (c<"Í">(hitVec, -7150706574308422460L, a) - c<"Í">(eyesPos, -7150706574308422460L, a))
                                          * (c<"Í">(hitVec, -7150706574308422460L, a) - c<"Í">(eyesPos, -7150706574308422460L, a))
                                 )
                              )
                           )
                        )
                     ),
                     axx
                  }
               );
               Vec3 vector = eyesPos.add(
                  c<"Í">(rotationVector, -7151102216837259321L, a) * 4.5,
                  c<"Í">(rotationVector, -7149751525995725785L, a) * 4.5,
                  c<"Í">(rotationVector, -7150706574308422460L, a) * 4.5
               );
               BlockHitResult obj = mc.level
                  .clip(new ClipContext(eyesPos, vector, c<"î">(-7148004524748687544L, a), c<"î">(-7149548836377758174L, a), mc.player));
               if (obj.getType() == c<"î">(-7151013534779960577L, a) && obj.getBlockPos().equals(neighbor)) {
                  return true;
               }
            }
         }

         var15++;
      }

      return false;
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   @EventTarget
   public void f(LivingUpdateEvent event) {
      long a = 何树何树友何何何树友.a ^ 32283710927304L;
      long ax = a ^ 6946568073953L;
      long axx = a ^ 93513857331755L;
      long axxx = a ^ 102549099370604L;
      long axxxx = a ^ 9534183383553L;
      c<"$">(851145560112952729L, a);
      if (!this.w(new Object[]{ax})) {
         Module scaffold;
         scaffold = Cherish.instance.getModuleManager().getModule(何何友何友树友友何何.class);
         label57:
         if ((c<"Í">(mc.player, 847666166996694316L, a) > 0.0F || c<"Í">(mc.player, 846978144212021245L, a) > 0) && !mc.player.onGround() && 树友友何树友树树树何.R(axx)) {
            if (this.y()) {
               c<"g">(this, false, 847839578087543808L, a);
               if (!scaffold.isEnabled()) {
                  scaffold.y(true);
                  c<"g">(this, true, 847521936013993374L, a);
                  WrapperUtils.z(new Object[]{5});
                  c<"g">(c<"î">(848047639311361107L, a), true, 847874687304907291L, a);
               }

               if (c<"Í">(this, 847650137087924106L, a)) {
                  break label57;
               }

               c<"g">(this, true, 847650137087924106L, a);
               c<"g">(this, 0, 850686802051570452L, a);
            }

            if (c<"Í">(this, 847650137087924106L, a)) {
               c<"g">(this, false, 847650137087924106L, a);
               c<"g">(this, 0, 850686802051570452L, a);
            }

            if (!c<"Í">(this, 847839578087543808L, a)) {
               if (c<"Í">(this, 850827364796798559L, a).getValue()) {
                  cn.cool.cherish.utils.树友树友树树何何树何.I(
                     c<"Í">(Cherish.getResourcesManager(), 847511864920404310L, a).getAbsolutePath() + b<"r">(7527, 4217916838031874835L ^ a), axxx, 1.0F
                  );
               }

               c<"g">(this, true, 847839578087543808L, a);
               ClientUtils.e(new Object[]{b<"r">(14406, 728768445414342207L ^ a), axxxx});
            }
         }

         if (mc.level.getBlockState(new BlockPos((int)mc.player.getX(), (int)mc.player.getY() - 1, (int)mc.player.getZ())).isSolid()) {
            if (scaffold.isEnabled() && c<"Í">(this, 847521936013993374L, a)) {
               scaffold.y(false);
               c<"g">(this, false, 847521936013993374L, a);
            }

            if (c<"Í">(this, 847650137087924106L, a)) {
               c<"g">(this, false, 847650137087924106L, a);
               c<"g">(this, 0, 850686802051570452L, a);
            }

            c<"g">(this, false, 847839578087543808L, a);
         }

         if (c<"Í">(this, 847650137087924106L, a)) {
            c<"g">(this, c<"Í">(this, 850686802051570452L, a) + 1, 850686802051570452L, a);
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   @EventTarget
   public void l(PacketEvent event) {
      long a = 何树何树友何何何树友.a ^ 23314484608246L;
      c<"$">(-8722935880401848153L, a);
      if (event.getSide() == c<"î">(-8719993576955801476L, a)
         && event.getPacket() instanceof ClientboundSetEntityMotionPacket s12
         && s12.getId() == mc.player.getId()) {
         c<"g">(this, true, -8719675692995683660L, a);
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "k<&\u0007Fed|k\fLxa!`JDel'd\u0001\u0007ce\"dJYfi+m\u0016\u0007佟栙伇栙厯佼佟佝桃參";
      j[1] = int.class;
      k[1] = "java/lang/Integer";
      j[2] = boolean.class;
      k[2] = "java/lang/Boolean";
      j[3] = "SYs3*\u001a\\\u0019>8 \u0007YD5~(\u001aTB15k传佥叼伈伅厎传佥栦桌";
      j[4] = "b7\u001eA|\u0007i8\u000f\u000e\u0000\u001ef\"\u0001M7.p5\rP&\u0002g8";
      j[5] = "l\u001b40h\"c[y;b?f\u0006r}j\"k\u0000v6)$b\u0005v}w!n\f\u007f!)优佚厾住厘栖历叄传住";
      j[6] = "S@|mSWgcs-\u001e\\m~vp\u0015\u001aec{v\u0011Q&Apg\bXm7";
      j[7] = "M-I(SQBm\u0004#YLG0\u000feYHK-\u0013eYHK-\u00138\u0012{X&\t?\u0018mG'\u0002";
      j[8] = "_'rQsqPg?ZylU:4\u001cj\u007fP<9\u001cusL%rpsqP,=\\J\u007fP<9";
      j[9] = "V2'\u001d\u0014rV20A\u0018}Ly0\\\u000b~\u0016\u0013:A\u001cxL><]";
      j[10] = ">^U\u0017Y\u000f>^BKU\u0000$\u0015VVF\n4\u0015QQM\u0015~sHMf\u0003#NMM\u00102)KD";
      j[11] = "P[O\u0011x\tP[XMt\u0006J\u0010LPg\fZ\u0010WZc\u0005R\u0010xS|\u0010}QUKp\u0018J\u001aySz\u0003U";
      j[12] = "1J\u0013\f1\u00151J\u0004P=\u001a+\u0001\u0010M.\u0010;\u0001\u000bG*\u00193\u0001$N5\f\u001c@\tV9\u0004+\u000b!N)\u0015;";
      j[13] = "d\u0019\u001f`?&d\u0019\b<3)~R\u001c! #nR\u001b&+<$*\u000e-a";
      j[14] = double.class;
      k[14] = "java/lang/Double";
      j[15] = "QTD\u0002\u0014SQTS^\u0018\\K\u001fS@\u0010_QE\u001ea\u0010TZRBM\u001fN";
      j[16] = "[H^\fxd[HIPtkA\u0003IN|h[Y\u0004mey\\BDQ";
      j[17] = "e9C\u0010\\Wjy\u000e\u001bVJo$\u0005]EYj\"\b]ZUv;C=FUd2\u001f%RTs2";
      j[18] = "`\u0015LM$z`\u0015[\u0011(uz^[\u000f v`\u0004\u0016(,jC\u0011H\u0013 }i";
      j[19] = "E>yd\u001e\\J~4o\u0014AO#?)\u0004GO<$)\u0003VU?\"u\u0012VU~\u0005b\u0002\\S\"4b\u0002~G>6`\u0014A";
      j[20] = "9WbDCw<\u0018RL\u0001{";
      j[21] = "`s\\J|0`sK\u0016p?z8K\bx<`b\u0006\u0014}8wsZJ]6mwD4}8wsZ";
      j[22] = float.class;
      k[22] = "java/lang/Float";
      j[23] = "}Aa7*(vNpxK&}Et\"";
      j[24] = "4$F`1Oc+\\f^Y\ns\u0014b`\t\nBGkd^e8_$3O";
      j[25] = "%\u0006\u0001CU,%\tE\u00018\u001fR}9zt\u0019O9M\u0004D,xAM\u000b\u0000n";
      j[26] = "X\u0003zo\u0017l\u001cAr%wF! AUw>\u001f\u001dgu\u001bz]\u0015-";
      j[27] = "2S\u0019/\u0017}5\u0012\u001f*x3\t\u0016\fw\u0003|9\u0014^q\u0019L";
      j[28] = "#}\t\u000bs\",\u007f\u001an栘伐桜栔厨厭作厎历収kW;2>o\u001b\u0001h-\u007f";
      j[29] = "1\u0013sF\\ >\u0011`#样桖伊桺佌栺佳桖厔厠\u0011HCs<\u0007)\u001c\u001f(2";
      j[30] = "V\u001a3;o\u0017Y\u0018 ^栄伥佭伷案伃叞桡佭桳Q`#\u0002O\u0017)2t\u0006W";
      j[31] = "<IV\u001cVG3KEy佹叫伇叺佩桠佹栱厙栠4G\u001aR%DL\u0015MV=";
      j[32] = "j!^Wp\u000b~%\u000f\u0005\u001a\u0018Px\f\u0004#HPB\r\u000fe\re2[\\zL";
      j[33] = "K\u0002Su\n4\u000f@[?j\u00142$r\u000fT!\u0012\u0001Tc\u0010c\u001aK";
      j[34] = "e%hR\u0001A}j?C9UX%h\u0003\b\u0002X\u00149^UWmn+PGI";
      j[35] = "}M\u0005\f\u001b+vB\u001c\u0014x9\u001b\u0011_QHn\u001b!\fQ\u0014i.M\t\u0012\u0003;";
      j[36] = "s\b\u0014[vx-\u0000D\u0019\nX\b-1#\n-.\u0004A\u001c`s&T\u0003";
      j[37] = "s?!\u001a4\u0011x08\u0002W\u0003\u0015c{Gh\\\u0015S(G;S ?-\u0004,\u0001";
      j[38] = "\u0015]^ K\u0014Q\u001fVj+'f\u007feZ\u0015\u0001L^Y6QCD\u0014";
      j[39] = "\u0016\\)QUMS\u0006 Mk句可桻桗佴厨句佱桻厍)Q\u0018K\u001apB\u0014BB\u0006";
      j[40] = "y\u00021Y&0v\u0000\"<伉伂叜厱桊栥厗伂栆伯S\u0006l:t\u000fb]9$%";
      j[41] = "\u0001f\u0014s\u0005m\u000ed\u0007\u0016厴栛伺栏桯栏厴栛伺叕v,Og\fkGw\u001ay]";
      j[42] = ")\tlb.A=\r=0DR\u0013S7?t\r\u0013jho?S%\u0000fn*U";
      j[43] = "78c\\F\u0004szk\u0016&5QA:_A\u0012i-~\u001dIX";
      j[44] = "s\u0004:Rd\u00137F2\u0018\u00042\u0004&\u0001(:\u0006*\u0007=D~D\"M";
      j[45] = "1\u0014\u0018\u0014F:s\t[\u0014,RV9)\u0016L;3\u001e\u0019TQx3";
      j[46] = "KA$s.R\u000f\u0003,9Ne2e\u001fIN\u0000\f_9i\"DNWs";
      j[47] = "WY\u000eA@R_K\u001b\u00130\u0010VI\u0010QJ\u0001VIw@@\u000fBC\tU_\u0013\u0006";
      j[48] = "V\"=\\:TY .9桑栢右厑框栠伕司佭厑_\u0007vAO/'U!EW";
      j[49] = "P9%~MK\u000e1u<1d.\u0000\u0010E\u000eC\u0001`7/PKQ\"";
      j[50] = "-L>s7~\"N-\u0016,\u0011pVm/~w3P${E*!\re-#i'D1\u0016";
      j[51] = "aY\u0002\u001b,\u0000.\u0019\u0004H\\&\u0016d.&l\u001b0\u001f\u0013F#[6L";
      j[52] = "Iz\"=NYFx1X栥佫栶叉桙伅栥栯召栓@b\u0004SDwq9QM\u0015";
      j[53] = "1vX<R\u001d67^9=栵佗栖根原叾佱佗双佽\\\u0007\u0014od]m\\Aq5";
      j[54] = "\u0007\u001caRs7\f\u0013xJ\u0010%a@;\u000f saph\u000f|uT\u001cmLk'";
      j[55] = "\n+\u001c*ZA\rj\u001a/5桩史厑厧桓栬伭栨厑伹J\u000e\tI2\u000b{\tHO7";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 何树何树友何何何树友.a ^ 124390486617108L;
      c<"g">(this, false, -7629259634965170110L, a);
      c<"g">(this, false, -7631263910158972452L, a);
      c<"g">(this, false, -7629351539941553578L, a);
      c<"g">(this, 0, -7632946751443433784L, a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean y() {
      long a = 何树何树友何何何树友.a ^ 121884831475244L;
      long ax = a ^ 122077352330296L;
      c<"$">(6641564694754927229L, a);
      double yLevel = mc.player.getY() - 1.0;
      BlockPos basePos = BlockPos.containing(mc.player.getX(), yLevel, mc.player.getZ());
      if (友何树何友树友树何何.h(basePos, ax)) {
         return false;
      } else if (this.n(basePos)) {
         return true;
      } else {
         List<BlockPos> candidates = this.A(basePos);
         Iterator var10 = candidates.iterator();
         if (var10.hasNext()) {
            BlockPos pos = (BlockPos)var10.next();
            if (this.n(pos)) {
               return true;
            }
         }

         return false;
      }
   }

   private List<BlockPos> A(BlockPos basePos) {
      long a = 何树何树友何何何树友.a ^ 134227402936945L;
      c<"$">(-1696019601758218720L, a);
      List<BlockPos> positions = new ArrayList<>();
      int x = -6;
      int z = -6;
      positions.add(basePos.offset(-6, 0, -6));
      z++;
      x++;
      positions.sort((pos1, pos2) -> {
         double dist1 = basePos.distSqr(pos1);
         double dist2 = basePos.distSqr(pos2);
         return Double.compare(dist1, dist2);
      });
      return positions;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖诈骗";
   }
}
