package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友何友友友何何何友树 extends Module implements 何树友 {
   private final NumberValue 何友友何树树树树友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[11];
   private static final String[] k = new String[11];
   private static String HE_JIAN_GUO;

   public 友何友友友何何何友树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/player/友何友友友何何何友树.a J
      // 03: ldc2_w 122031085833985
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 19534
      // 0c: ldc2_w 7981480349606010306
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何友友友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 20731
      // 19: ldc2_w 2252864151750787446
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何友友友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 6307626588518714533
      // 26: lload 1
      // 27: invokedynamic Ë (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/友何友友友何何何友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/NumberValue
      // 33: dup
      // 34: sipush 9396
      // 37: ldc2_w 7912254959533208891
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic n (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何友友友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: ldc2_w 0.8
      // 44: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 47: ldc2_w 0.1
      // 4a: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 4d: bipush 1
      // 4e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 51: ldc2_w 0.1
      // 54: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 57: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 5a: putfield cn/cool/cherish/module/impl/player/友何友友友何何何友树.何友友何树树树树友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 5d: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-8527922134471795037L, 8402151283958496142L, MethodHandles.lookup().lookupClass()).a(169910872354785L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 140651332182216L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[3];
      int var7 = 0;
      char var5 = 24;
      int var4 = -1;

      while (true) {
         String var13 = c(
               var2.doFinal(
                  "1\u001dcÍZ\fsä%Q\u008d2Æ\u0092\u0099\fY;\u001fT\u0000÷\"g \u001a¾þ»\u0093Ó\u0000Ü\n\u0096Ð+òË¯\u0001\u009eO\u0080iû\u0000\"ÞÐröO´\u0093» \u0018aÎ\u0087v±\u0019ª\u001cQ}Ut¿¢ ¶ÚÉº`·©ëq"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 82) {
            c = var9;
            h = new String[3];
            return;
         }

         var5 = "1\u001dcÍZ\fsä%Q\u008d2Æ\u0092\u0099\fY;\u001fT\u0000÷\"g \u001a¾þ»\u0093Ó\u0000Ü\n\u0096Ð+òË¯\u0001\u009eO\u0080iû\u0000\"ÞÐröO´\u0093» \u0018aÎ\u0087v±\u0019ª\u001cQ}Ut¿¢ ¶ÚÉº`·©ëq"
            .charAt(var4);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 4;
               case 1 -> 22;
               case 2 -> 62;
               case 3 -> 44;
               case 4 -> 50;
               case 5 -> 21;
               case 6 -> 12;
               case 7 -> 18;
               case 8 -> 29;
               case 9 -> 61;
               case 10 -> 31;
               case 11 -> 25;
               case 12 -> 32;
               case 13 -> 7;
               case 14 -> 30;
               case 15 -> 0;
               case 16 -> 57;
               case 17 -> 1;
               case 18 -> 55;
               case 19 -> 60;
               case 20 -> 8;
               case 21 -> 42;
               case 22 -> 36;
               case 23 -> 15;
               case 24 -> 16;
               case 25 -> 48;
               case 26 -> 45;
               case 27 -> 24;
               case 28 -> 38;
               case 29 -> 56;
               case 30 -> 17;
               case 31 -> 28;
               case 32 -> 54;
               case 33 -> 6;
               case 34 -> 9;
               case 35 -> 2;
               case 36 -> 37;
               case 37 -> 3;
               case 38 -> 41;
               case 39 -> 10;
               case 40 -> 51;
               case 41 -> 47;
               case 42 -> 63;
               case 43 -> 13;
               case 44 -> 53;
               case 45 -> 14;
               case 46 -> 34;
               case 47 -> 59;
               case 48 -> 5;
               case 49 -> 52;
               case 50 -> 43;
               case 51 -> 27;
               case 52 -> 33;
               case 53 -> 39;
               case 54 -> 11;
               case 55 -> 20;
               case 56 -> 35;
               case 57 -> 23;
               case 58 -> 46;
               case 59 -> 26;
               case 60 -> 40;
               case 61 -> 58;
               case 62 -> 19;
               default -> 49;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友友友何何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 17926;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友友友何何何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 249 && var8 != 236 && var8 != 203 && var8 != 'a') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 199) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 219) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 249) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 203) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友友友何何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @EventTarget
   public void n(LivingUpdateEvent event) {
      long a = 友何友友友何何何友树.a ^ 130614338512129L;
      long ax = a ^ 10927599119138L;
      long axx = a ^ 52299180428939L;
      long axxx = a ^ 79520717580271L;
      c<"Û">(9045897317968856422L, a);
      Object[] var10004 = new Object[]{null, axxx};
      var10004[0] = 0;
      WrapperUtils.x(var10004);
      if (WrapperUtils.E(new Object[]{ax}) > c<"ù">(this, 9046303702594961850L, a).getValue().floatValue()) {
         Object[] var10003 = new Object[]{null, axx};
         var10003[0] = 1.0F;
         WrapperUtils.w(var10003);
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "7+\"\u0010RC8ko\u001bX^=6d]PC00`\u0016\u0013E95`]M@5<i\u0001\u0013佹企厎余厸栬叧原伐余";
      j[1] = "\u00134?P/\u0004'\u00170\u0010b\u000f-\n5MiI%\u00178Km\u0002f53Zt\u000b-C";
      j[2] = "\u000bh%\ry\u001c\u0004(h\u0006s\u0001\u0001uc@{\u001c\fsg\u000b8\u001a\u0005vg@f\u001f\t\u007fn\u001c8厸伽反叀厥佃伦伽反栚";
      j[3] = "x#L.8Bwc\u0001%2_r>\nc!Lw8\u0007c>@k!L\u0003\"@y(\u0010\u001b6An(";
      j[4] = "p{o@`={t~\u000f\u001c$tnpL+\u0014by|Q:8ut";
      j[5] = "\u001ea\u0010AaY\u0011!]JkD\u0014|V\fcY\u0019zRG 佣伨叄佫佷叅佣伨栞栯";
      j[6] = "{B!b>QpM0-__{F4w";
      j[7] = "~YG50&+N]cV佂厄叨佾桇桏栆桞叨栺^lx{W\u0018;nv:E";
      j[8] = "\n{}e$x\u000b}pr\u001f佚史叚参叏叜佚佬栀参\f$eMp:s%c@g";
      j[9] = "KXyFY:GPe7\u0017T\u0015_{MSkHZhLh";
      j[10] = "M\u001c3\u0000rz\u0018\u000b)V\u0014*tUf\tn2\u0019SiQ.CO_5\u0011e.IPmQ\u0014";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖大狗叫";
   }
}
