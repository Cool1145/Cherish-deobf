package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class 友何友何树何树何树何 extends Module implements 何树友 {
   private final NumberValue 何友友何友友树树何何 = new NumberValue("Range", "范围", 4.0, 1, 6.0, 0.1);
   private final NumberValue 何树树友何友树树树友 = new NumberValue("Vertical Range", "垂直范围", 2.0, 1, 3.0, 0.1);
   private final BooleanValue 何友何友何树友树友树 = new BooleanValue("Move Fix", "移动修复", true);
   private final BooleanValue 何友树友树友友何树友 = new BooleanValue("Silent Rotation", "静默转头", true);
   private final BooleanValue 何树树友何友何何树何 = new BooleanValue("Smooth Rotation", "平滑转头", false);
   private final NumberValue 友何树树友友友何友树 = new NumberValue("Smooth Rotation Speed", "平滑转头速度", 180.0, 0.0, 180.0, 10.0).A(this.何树树友何友何何树何::getValue);
   private final BooleanValue 何树友友树友友何树友 = new BooleanValue("Wall Check", "墙壁检测", true);
   private final BooleanValue 树树何树何树何何友友 = new BooleanValue("Collect Water", "收集水", true);
   private final BooleanValue 何何何友树何友友友何 = new BooleanValue("Collect Lava", "收集岩浆", true);
   private final BooleanValue 何友友何友友何何何友 = new BooleanValue("Auto Disable", "自动关闭", true);
   private final NumberValue 树友何何树树友友何树 = new NumberValue("Action Delay", "操作延迟", 200, 0, 1000, 10);
   private final BooleanValue 友友友何树树树何友友 = new BooleanValue("Use Offhand", "使用副手", true);
   private final BooleanValue 何树友树友友树何友树 = new BooleanValue("Prioritize Feet", "优先脚底", true);
   private final BooleanValue 何树友树何何树何友友 = new BooleanValue("Auto Switch", "自动切换", true);
   private Rotation 何友树友何树树何树何 = null;
   private BlockPos 树树友友何树何友何友 = null;
   private boolean 友友树树何树树树友何 = false;
   private boolean 何树何友树树友何友友 = false;
   private final 何友友何树何树何树友 友友友何树何友树树何 = new 何友友何树何树何树友(51913986529303L);
   private final long 何友树树树树友树友树 = 100L;
   private final 何友友何树何树何树友 友友何树何树树友友树 = new 何友友何树何树何树友(51913986529303L);
   private int 友友树何何何友何友何 = -1;
   private int 友友友友友何何何友友 = -1;
   private InteractionHand 何何何友何何何树何友 = InteractionHand.MAIN_HAND;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final long[] k;
   private static final Long[] l;
   private static final Map m;
   private static final Object[] n = new Object[72];
   private static final String[] o = new String[72];
   private static int _何炜霖国企变私企 _;

   public 友何友何树何树何树何() {
      super("AutoFluidCollector", "自动收液体", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(2538179821246773453L, 9048516332317545717L, MethodHandles.lookup().lookupClass()).a(59235241941637L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var18;
      Cipher var28 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(24307326313724L << var19 * 8 >>> 56);
      }

      var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[40];
      int var23 = 0;
      String var22 = "îS:ÀÌ#P\u000bÌ\u009c÷\f½Î\u0007Ýó\u00ad3i¯\f\u008aÞ ¿ä§\u0080\u0089\u0086\u009dû\u0019\u0011C\u0005GJ\f½_#nÙ\u0086\u0091L.J\u0015\u0014A\u0081ßd& °öô\u000e|Í¸Y\u0094§\u008e+³\u008eå®\u001c\u0092\u0087º² PÚ'\u0014\u0002Ó\\\u0082²Í\u0010ç\u0096½4©\u0082.¿\u0010\u0094\u0001\u0001Â#9º(\u0094Tcb;\u0094\u009e\u009eÎÎÖ\u0010ÈÝV\u0081^\u0089\u0007¼\u0006ºPù\u0086\u0094LÇ¾/\u008by\u0099âæV«ì¤¬ \u00adû8ýòØ\u0088\u008b\u0016\u009aþ(°R.\u0090©\u0010ç\u0016|\u0092TÍù³±\u000e\u008e\u001aå\u001e`f©\u0005+XE\f2\u0005©À\u0019ÿ\u0085¼wÆ(ÿ\u0099&\u0088¾µÕ3\u007fóIás¦9\u0087N\u008czºLÊ\u0081!§4Nô\u009bZ\r\u0006\u0002;gÿ\u0011/\u0018ì¤^@>\u0018 «á&Û¿ß,\u0094ck\u008aÒâ\u00adà¹ôT\u009d\u001b_Æ\td@å\u008fó_\u0090\u0093n\u0018Q9í4{Þè\u008e\u0006è\u0014TÚºO\u0003µB³lÀõ\u0080\u00ad0Z\u0011òk+\u0019«¢t°]!Ì\u0085b\u009d=wfwC\u0000¼O!ÔxÈ@8\u0082Í)Ð*½ÝðáÓ¸^µ\u008f\u008c\u0095h8\u0018À<LäDA®ÉJÜ©\\5\u0004s^§\u009dË&2Ø«ü\u0018\u0000¶jbÙNä´Ê.MÎ48\u0001ÞÈ\u0014b\u009eEg¼$\u0018\u0099Ø¹\u0010|æ©3L/\u008e<)IÊ\u001aÕÈ\u0003\u001aòN\u0019r\u0018[<ôe¡\u0016¡ù\u00954ªÑLêq1\u001cW¢\u0083Ì\u0097®w ø²Yv×\u0005\\\u00994Z0\u001d\u0095)@ïµq&c&³qo\u0098f2¨xÝ\u0012m(v7(£5a\u008eù\u009f\u0016vV\u0096^\u008bÆgÓû\r\u0006§ÞbD¾w\u0080_Ñ\u0019ð¦\u001bwÖ}p\u009c\u0014\u0018?\u009f¾´a9\u0003ÞiG½\u0085\u0006m[\u00947¤c\u0005Bçs{\u0010{gK\u0085èFÔ!\u008eç2Ykâg9 W®\u000eC?yó)\u0003k\nÐÖ)\u0085©À\f\u0003&\u008eZ\t\u001fµ¸¾&\u008e\u0014o\u0007\u0010aêB³PËõ\u0088\u00adwèïhÙàß ¾\u009cå\u001f\u0097g\u001e 8©¾4§TDÄ\u0017\u0014W±:\u0018Ò7Â\u0006\u001c]\bÜ¢î ¥9ú7·í\u001c\tYÈ\u0013\nóL\u0000ÏÑgóD\u00100¡\u0017<æeõß\u0017IÂ ÖnuÏÝÀà(j\u008f\u008f\u008a\u0015y{ãP¾°\u0083ä\u00ad,KÎ\u0085Ö/è\u0094\u0091& P«·eH\u00ad¹\u000bïêZ¯\u0018ú\u0087\u0003JK`÷[\u009a¾\u0095ÑÒk\u0019¥è°\"\u0018 ë\rfèsÔW#\u008e¸31HÛÑF§õ\u0082Ö\u0089\u009fd ÀBÏp×K\u0012è6ÚÎgI<²\u001c\\\u009cÃùâ\u008bÏo¬\u001båà(×e< .7ç©µ\r\u0083LrfAþ\r>y$iË\u0083Á!\u000e\nýòR5¿F`1°(Ì\u0082»âÚ¦~uA¯Âüb4\u001d¢}|Ã\u0006¸\u0097\t\u00adp3\u0081\f\u009a¶íVâ\u0098ÎxÑtH\u009d ùíI_Q£ô)lPcW\u0002zÀÇp§\u0086\bZûQÎ,\u001a §¹\u009f¿Ñ º\tR\u008d²ê\u0090i\u0084\u008b\u001d¡\u0094üÎP\u001cD7`ñ½ÓpB«½\u0004½zÞ¡\u0010JWLS$\u008aiÎî¤\u0085Ä\u0000\u0004xê@²±Kã'ÖñÞ\u009882\u0098ÌôÛ\u0088rê¨+aÆ¬`\u0019Zdu@½²}\b!X\u0013\u0000\u0082Æw\u0014SFaÝÒ9\u0087à\u008dñþ,h£\u008bâÔ(\u009cW]Ø«@tÈ$\u0097Xú¡\u001aSn&µ\u0012l¬Í\u009fôNØ3\u0082R\u008c8\u008c¼Éi\u0094u\u009aÂ\"\u0006\u0083\u0094b Cë5\u0000Ú(s_u\u008e\nWA\u0007\u001dOÖe\u0093\u0083ë\u0098(ø\u0087 O¿eÊ¬Ff\u001fÏ)¬¤\u0098Oñ(\u0096M¹\u0086¡*ï\u0083\u0015l\"SÏÉÖÈ\u0018hDV\u0085qã¤T\u001dö£\u0081öìÆô0\"ÃGIqr¿\u0018¿A]\u0085eø\u0011{°\u0083\u009bQç\u0012:-:\u001bç¬ë*~ºHqd\u0012ªÞc\u0081Í?èøR\u007f\u0013Åc¦Ï\nPTä1?\\ì/\u0098\t0©xº\u008b\u0010\u000f,Û·´áÉÈ¦¦Ð\u0099d°\u00951¡\\zÝÈ\t3©ÑQàáA®\\\u0080ç½w*0 $I¹Þh\r:\u0004à\u0087<H\u009c\u0093\u001dÛ\\\u0096ý\u000b\u0087Ï<<\rc®=íM\u009c.0$O\u0085¹¹ÕéÓâaª\u00810\n# û\u009e\u0092á4\u00adÔxn9\u0097 WÁ@Ç7&\"dÁ·êw½ÏVÉÐ\\\u0084Ò";
      short var24 = 1333;
      char var21 = 24;
      int var27 = -1;

      label57:
      while (true) {
         String var29 = var22.substring(++var27, var27 + var21);
         int var10001 = -1;

         while (true) {
            String var40 = c(var18.doFinal(var29.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var40;
                  if ((var27 += var21) >= var24) {
                     c = var25;
                     h = new String[40];
                     Cipher var11;
                     Cipher var31 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(24307326313724L << var12 * 8 >>> 56);
                     }

                     var31.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var15 = var11.doFinal(new byte[]{112, -38, -77, -6, -55, 121, 90, -110});
                     long var44 = (var15[0] & 255L) << 56
                        | (var15[1] & 255L) << 48
                        | (var15[2] & 255L) << 40
                        | (var15[3] & 255L) << 32
                        | (var15[4] & 255L) << 24
                        | (var15[5] & 255L) << 16
                        | (var15[6] & 255L) << 8
                        | var15[7] & 255L;
                     var10001 = (byte)-1;
                     j = var44;
                     m = new HashMap(13);
                     Cipher var0;
                     Cipher var32 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(24307326313724L << var1 * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0084aMû ¢ÇZ\u009f\u0010R®d\u0001v\u0086".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var48 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     k = var6;
                     l = new Long[2];
                     return;
                  }

                  var21 = var22.charAt(var27);
                  break;
               default:
                  var25[var23++] = var40;
                  if ((var27 += var21) < var24) {
                     var21 = var22.charAt(var27);
                     continue label57;
                  }

                  var22 = "Ä\u0019&\u0091R³æsTO\u0012\r\u00ad{S\u007f¯96Ù\u000elVé\u0018Sè\u0002Új\u008c\u0000Øá\u0083Ä^þ\u0080Ì\u001f¬´¾\u0013\u0015Í>©";
                  var24 = 49;
                  var21 = 24;
                  var27 = -1;
            }

            var29 = var22.substring(++var27, var27 + var21);
            var10001 = 0;
         }
      }
   }

   private void D() {
      树友何何友何树何树友.E();
      if (this.何树何友树树友何友友 && this.友友友何树何友树树何.A(100L, 118344821288830L)) {
         mc.options.keyUse.setDown(false);
         this.何树何友树树友何友友 = false;
         mc.player.connection.send(new ServerboundSwingPacket(this.何何何友何何何树何友));
         this.友友树树何树树树友何 = false;
         this.树树友友何树何友何友 = null;
         this.友友何树何树树友友树.D(11747522392279L);
         if (this.友友友友友何何何友友 != -1) {
            mc.player.getInventory().selected = this.友友友友友何何何友友;
            this.友友友友友何何何友友 = -1;
         }

         String message = "§a[AutoFluidCollector] 液体收集完成";
         if (this.何树友树何何树何友友.getValue() && this.Y() != null) {
            message = "§a[AutoFluidCollector] 液体收集完成" + "，继续寻找下一个目标";
         }

         ClientUtils.C(message, 108932807550871L);
         if (this.何友友何友友何何何友.getValue() && (!this.何树友树何何树何友友.getValue() || this.Y() == null)) {
            this.J(false);
         }
      }
   }

   private boolean I(BlockPos pos) {
      树友何何友何树何树友.E();
      Vec3 eyePos = mc.player.getEyePosition();
      Vec3 blockCenter = new Vec3(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
      BlockHitResult result = mc.level.clip(new ClipContext(eyePos, blockCenter, Block.OUTLINE, Fluid.NONE, mc.player));
      return result.getType() == Type.MISS || result instanceof BlockHitResult blockHit && blockHit.getBlockPos().equals(pos);
   }

   @EventTarget
   public void Z(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && mc.gameMode != null) {
         if (this.树树友友何树何友何友 != null && this.友友树树何树树树友何) {
            Vec3 hitVec = new Vec3(
               this.树树友友何树何友何友.getX() + 0.5 + 友友友树何友树友树友.S(35411192288882L, -0.3, 0.3),
               this.树树友友何树何友何友.getY() + 0.5 + 友友友树何友树友树友.S(35411192288882L, -0.3, 0.3),
               this.树树友友何树何友何友.getZ() + 0.5 + 友友友树何友树友树友.S(35411192288882L, -0.3, 0.3)
            );
            Vec3 eyePos = mc.player.getEyePosition();
            double diffX = hitVec.x - eyePos.x;
            double diffY = hitVec.y - eyePos.y;
            double diffZ = hitVec.z - eyePos.z;
            double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
            float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
            float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
            this.何友树友何树树何树何 = new Rotation(21273681362686L, 友友友树何友树友树友.N(0, 572919893, 49115, yaw), 友友友树何友树友树友.o(pitch, -90.0F, 90.0F, 78498738705762L));
            if (this.何友树友树友友何树友.getValue()) {
               RotationUtils.d(
                  this.何友树友何树树何树何, this.何友何友何树友树友树.getValue(), true, this.何树树友何友何何树何.getValue(), 46171034731712L, this.友何树树友友友何友树.getValue().floatValue()
               );
            }

            this.何友树友何树树何树何.E(119944978516366L, mc.player);
         }
      }
   }

   private int e() {
      树友何何友何树何树友.E();
      int i = 0;
      ItemStack stack = mc.player.getInventory().getItem(0);
      if (this.q(stack)) {
         return 0;
      } else {
         i++;
         return -1;
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 35;
               case 1 -> 38;
               case 2 -> 16;
               case 3 -> 15;
               case 4 -> 2;
               case 5 -> 37;
               case 6 -> 6;
               case 7 -> 17;
               case 8 -> 46;
               case 9 -> 0;
               case 10 -> 58;
               case 11 -> 36;
               case 12 -> 5;
               case 13 -> 61;
               case 14 -> 57;
               case 15 -> 13;
               case 16 -> 22;
               case 17 -> 25;
               case 18 -> 62;
               case 19 -> 12;
               case 20 -> 53;
               case 21 -> 3;
               case 22 -> 63;
               case 23 -> 50;
               case 24 -> 45;
               case 25 -> 60;
               case 26 -> 49;
               case 27 -> 21;
               case 28 -> 8;
               case 29 -> 10;
               case 30 -> 52;
               case 31 -> 40;
               case 32 -> 51;
               case 33 -> 48;
               case 34 -> 32;
               case 35 -> 56;
               case 36 -> 47;
               case 37 -> 18;
               case 38 -> 54;
               case 39 -> 29;
               case 40 -> 4;
               case 41 -> 11;
               case 42 -> 24;
               case 43 -> 43;
               case 44 -> 7;
               case 45 -> 19;
               case 46 -> 1;
               case 47 -> 33;
               case 48 -> 42;
               case 49 -> 59;
               case 50 -> 27;
               case 51 -> 44;
               case 52 -> 9;
               case 53 -> 26;
               case 54 -> 23;
               case 55 -> 20;
               case 56 -> 14;
               case 57 -> 31;
               case 58 -> 34;
               case 59 -> 39;
               case 60 -> 55;
               case 61 -> 41;
               case 62 -> 28;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 1032;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友何树何树何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[éOè^)g\tS,Ç\u009cÎ¹\u0015u¥, \u001dd\u0000åÏä\u007f3nÄàÂ\u0094uP¬, @\u0091\u001cÃ\u0083æu\u008diÊ\u009b\u009c®ú\u008c\u001d, \u009aq\u0081ÏÑ\u0096ª#, \u008d¢[^4ÜXe¡HW\u0011rÞ|\u0016}ã%Êk\u0005\u0004·, ]¸\u0081ó\u009eÈ\u0019\u0085B®Nzú[êK, Í \u009cp\u0017¦ÃÞRµ½¨«\u001dLDl\u0016K\u0019%æ\u0003\fÙù)ôÐ\u0019Ð´®\"\u0019F|\u001fÐ\u0001\\ô*\u0013ü\u0012\u008d\u0094á\f-ÃRÌ»\u0006Èq7h4äD\u001f, Çöo")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友何树何树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private boolean b(BlockPos pos) {
      树友何何友何树何树友.E();
      if (mc.level.getBlockState(pos).getBlock() instanceof LiquidBlock) {
         FluidState fluidState = mc.level.getFluidState(pos);
         if (fluidState.isSource()) {
            if (mc.level.getBlockState(pos).is(Blocks.WATER)) {
               return this.树树何树何树何何友友.getValue();
            }

            if (mc.level.getBlockState(pos).is(Blocks.LAVA)) {
               return this.何何何友树何友友友何.getValue();
            }
         }
      }

      if (mc.level.getBlockState(pos).is(Blocks.WATER) && this.树树何树何树何何友友.getValue()) {
         return mc.level.getFluidState(pos).isSource();
      } else {
         return mc.level.getBlockState(pos).is(Blocks.LAVA) && this.何何何友树何友友友何.getValue() ? mc.level.getFluidState(pos).isSource() : false;
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 248 && var8 != 'p' && var8 != 181 && var8 != 'I') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'E') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'o') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 248) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'p') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 181) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友何树何树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 30882;
      if (l[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = k[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])m.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            m.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友何树何树何树何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         l[var3] = var15;
      }

      return l[var3];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @Override
   protected void h() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.友友友友友何何何友友 != -1) {
            mc.player.getInventory().selected = this.友友友友友何何何友友;
            this.友友友友友何何何友友 = -1;
         }

         if (this.何树何友树树友何友友) {
            mc.options.keyUse.setDown(false);
            this.何树何友树树友何友友 = false;
         }

         ClientUtils.C("§c[AutoFluidCollector] 模块已禁用", 108932807550871L);
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   @EventTarget
   public void f(TickEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && mc.gameMode != null) {
         this.D();
         if (!this.友友树树何树树树友何) {
            if (this.友友友何树树树何友友.getValue() && this.q(mc.player.getOffhandItem())) {
            }

            this.何何何友何何何树何友 = InteractionHand.OFF_HAND;
            this.友友树何何何友何友何 = -2;
            this.何何何友何何何树何友 = InteractionHand.MAIN_HAND;
            this.友友树何何何友何友何 = this.e();
            if (this.友友树何何何友何友何 == -1) {
               ClientUtils.C("§c[AutoFluidCollector] 没有找到桶", 108932807550871L);
               this.J(false);
            } else {
               if (this.树树友友何树何友何友 == null && this.友友何树何树树友友树.A(this.树友何何树树友友何树.getValue().longValue(), 118344821288830L)) {
                  this.树树友友何树何友何友 = this.Y();
                  if (this.树树友友何树何友何友 != null) {
                     String liquidType = this.m(this.树树友友何树何友何友);
                     ClientUtils.C("§a[AutoFluidCollector] 找到" + liquidType + "，准备收集", 108932807550871L);
                     this.友友何树何树树友友树.D(11747522392279L);
                  }
               }

               if (this.树树友友何树何友何友 != null && !this.友友树树何树树树友何 && this.友友何树何树树友友树.A(this.树友何何树树友友何树.getValue().longValue(), 118344821288830L)) {
                  this.友友树树何树树树友何 = true;
                  this.G();
               }
            }
         }
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何友何树何树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      n[0] = "\u0003Sx>+\f\u0003Sob'\u0003\u0019\u0018{\u007f4\t\t\u0018i~2\f\u0019O\"`*\u0004\u0014S~>\u000f\u000b\u001bSbd)\u0017\u0014";
      n[1] = int.class;
      o[1] = "java/lang/Integer";
      n[2] = "{^WJ\u001aet\u001e\u001aA\u0010xqC\u0011\u0007\u0018e|E\u0015L[cu@\u0015\u0007\u0005fyI\u001c[[叁位叻伬核传栛位校伬";
      n[3] = boolean.class;
      o[3] = "java/lang/Boolean";
      n[4] = "<r-e<.32`n636ok(>.;ioc}(2lo(#->eft}桐厔佉佖反伆桐伊栍又";
      n[5] = "\bt8\u0004\u0012{<W7D_p6J2\u0019T6>W?\u001fP}}u4\u000eIt6\u0003";
      n[6] = "#~\u0005\u0005>e(q\u0014JB|'k\u001a\tuL1|\u0016\u0014d`&q";
      n[7] = "*TCsWc*TT/[l0\u001fT1So*E\u0019\u0012J~-^Y.";
      n[8] = "a\\F\u0011U$a\\QMY+{\u0017QSQ(aM\u001ct]4BXBOQ#h";
      n[9] = "'a\u000ek$R'a\u00197(]=*\u0019) ^'pT\b U,g\b$/O";
      n[10] = "i\u0013\u0013G8<i\u0013\u0004\u001b43sX\u0010\u0006'9cX\u000b\f#0kX\u0005\u0005:6lX%\u0005:6l\u0005";
      n[11] = ">\u0002\u00059f\b>\u0002\u0012ej\u0007$I\u0006xy\r4I\u001dr}\u0004<I\u0013{d\u0002;I3{d\u0002;";
      n[12] = "\u00074Bm\u001e\u0005\bt\u000ff\u0014\u0018\r)\u0004 \u0007\u000b\b/\t \u0018\u0007\u00146BL\u001e\u0005\b?\r`'\u000b\b/\t";
      n[13] = "\u000b\u001f\\v~E\u000b\u001fK*rJ\u0011T_7a@\u0001TX0j_K,M; ";
      n[14] = double.class;
      o[14] = "java/lang/Double";
      n[15] = " 8x\u0002hA 8o^dN:soCwM`\u001f`CfC\u001e2\u007f";
      n[16] = "A01zhVA0&&dY[{&8lZA!k9pS[<58dFJ'k\u0019pS[<\u00158dFJ'\u00025hZb:!1";
      n[17] = "G~\u0003$%CH>N//^McEi<MHeHi#AT|\u0003\t?AFu_\u0011+@Qu";
      n[18] = "l\u0005\u0019p+BcET{!_f\u0018_=1Yf\u0007D=,Hc\u001bRaj\u007f`\u001fVg-Ba";
      n[19] = "\fbF\u00124<\fbQN83\u0016)QP00\fs\u001cL54\u001bb@\u0012\u0015:\u0001f^l54\u001bb@";
      n[20] = "\f41#\r0\f4&\u007f\u0001?\u0016\u007f&a\t<\f%k`\u00155\u001685a\u0001 \u0007#kN\f0\u0007?1]\u0001:\t41A\t*\u00164+h\u0012";
      n[21] = "o!\u000f%\u000bd`aB.\u0001ye<Ih\u0011\u007fe#Rh伱叀叇会栰伓桵佞栝厄";
      n[22] = "\u0006E~PYe\u0006Ei\fUj\u001c\u000e}\u0011F`\f\u000eC\u0010@i\u001aAi\n]c\u0006hk\u0010P";
      n[23] = "\u0015.!H@a\u0015.6\u0014Ln\u000fe\"\t_d\u001fe9\u0003[m\u0017e\u0016\nDx8$;\u0012Hp\u000fo\u0017\nBk\u0010";
      n[24] = "{L|pL}{Lk,@ra\u0007\u007f1Sxq\u0007d;Wqy\u0007K2HdVFf*Dla\rN2T}q";
      n[25] = "6g.\u0015rI6g9I~F,,-TmL<,*SfSvJ3OME+w6O;t!r?";
      n[26] = "W\"EogtW\"R3k{MiF.xq]iX5op\u0017\u000eE$gn";
      n[27] = "]<4\u001f_W]<#CSXGw7^@RWw)EWS\u001d\u00104T_";
      n[28] = "_\u0001x\u000eU%PA5\u0005_8U\u001c>CW%X\u001a:\b\u0014桛佩厤厝伸栫厁号伺伃";
      n[29] = "+\u0012qnZ\u0016 \u001d`!;\u0018+\u0016d{";
      n[30] = "#\u001fu\u001a[P+\u001eb\u001e8佧叙厧佃厽叻栣栃伹佃~SQd\b.\u001e@Q#\u0005";
      n[31] = "1iSv_\r<}Uz0\u0006\n?\u0011-\u000eQbQ)pR\rljR&LY<";
      n[32] = "}~>\u0015\u001en &;\u0013yx\u0015 cOH.\u0015\u001cm\u0000\u0016l0p.\u001c\u0006|";
      n[33] = "$\u0018\u0005\u001fLo(X@\u0016/\u0015\u0004(,of\u0014\u0006f\u0015QQb)[\u0019\u0011\u0014k";
      n[34] = "b!\u007f\u0019T\u001fj h\u001d7桬桂厙受传栮伨厘伇受}^\u000f!k+\u0012T\u0010j;";
      n[35] = "SI$zQ\u000b]H.~`\u0019:\u0017,%_M:&\u007f\u007f\u0011\n\u001fKsb\u001dN";
      n[36] = "OO_cebG\u000f\u001el\u0007E})e\u001dAO \u001a\u001b\"8`@\u0012[c7";
      n[37] = "v\u0005(x##~\u0004?|@伔桖伣厀栅桙厊伒厽厀\u001cz*/\u0000\u007fq%,q\u0018";
      n[38] = "/a\u001aC\u001aX'`\rGy佯栏叙桨佺伤栫佋叙厲'I^.'\u000b\u0017\u0013N.\"";
      n[39] = "CC]\u0006C9KBJ\u0002 厐厹叻佫桻根桊伧叻叵b\u0010?B\u0005LRJ/B\u0000";
      n[40] = "w<4\u0006\u0004\u0019\u007f=#\u0002g伮伓会厜伿伺伮桗会厜b\t\r0w<_\u0005Mu~";
      n[41] = "opl6/|gq{2L佋厕栒叄桋厏叕伋栒叄R|zn6}b&jn3";
      n[42] = "a\u007f+-C\u0011fo%:$A\u000b.uk\u0015\u0012\u000b\u001fr)VN5q.#\u001eV";
      n[43] = ">@{W#I6AlS@叠叄司位株伝叠栞栢位3-\\u@uY1\u0018jT";
      n[44] = "T\u000f\u000f7\u001dd\\\u000e\u00183~体厮伩厧伎桧反桴厷桽SNbUI\u001ec\u0014rUL";
      n[45] = "V]C\u0014!'^\\T\u0010B伐厬栿叫伭桛桔伲栿併p)/\u0005LH\u001c06Q\u001b";
      n[46] = "(t<!\u0019ou,9'~y@*a{O.@\u0016o4\u0011mez,(\u0001}";
      n[47] = "\"\u000e^$5S\u007f\u0002^{K\\D[\tw{\nDk\u00020{Sw\u0012\b!zL";
      n[48] = "KH-y/GA\u001cuuU叿栱桩叓佖厖佡栱厳栉\u000b6\u0004\u0015\u0002jp<PM\u000e";
      n[49] = "9^\u0000\u001a(\u00061_\u0017\u001eK厯參另厨厽伖伱佝另厨~1\u0010:O\b\u0007)\fl";
      n[50] = "\u0007t-pY#\u0018?f? \u001e/@\u0010\u0001O*\u0018w$zPaS8";
      n[51] = "DEX;}(LDO?\u001e桛厾佣佮框标厁厾佣株_u)\u0003R\u0003?f)D_";
      n[52] = "G3_\u00139IO2H\u0017Z叠厽桑佩伪伇叠伣压佩w _D\"W\u000e8C\u0012";
      n[53] = "yT}Sw:qUjW\u0014厓厃佲栏佪栍桉厃召栏7y/2Ts]ek-@";
      n[54] = "\u001e\u0005g7N3\u0016\u0004p3-伄佺伣叏桊佰厚古厽佑S\u001d5\u001fCvcG%\u001fF";
      n[55] = "\u0000-\u0004+#:]!\u0004t]5fxSxbjfHX?m:U1R.l%";
      n[56] = "b( oguj)7k\u0004叜厘桊桒佖栝栆桂厐伖\u000b>|;-wfaze5";
      n[57] = "9\u0003\u0019\u0006\u0006z*\u0016\u000ba\u0017HiQC^FHR\u0016\u000e[\u0013|+\u000e\u0012\r";
      n[58] = "%9B_\u000bax5B\u0000unCl\u0015\fE9C\\\u001eKEap%\u0014ZD~";
      n[59] = "^gr\f9MVfe\bZ佺桾栅叚伵厙栾桾栅叚h1L\u0019p)\b\"L^}";
      n[60] = ",h\u007f\u0007V&}'']:\u0005\u0016!<\u0000\u00040nap\u0006JH";
      n[61] = "ab;\\\f&m\"~Uo^F]\u0003;/RIPE\u0002\u0011e?\u007fx\u000eQ 6";
      n[62] = "G\u0017#\u001a[EO\u00164\u001e8佲桧厯桑厽叻栶伣厯桑~\bCFQ2NRSFT";
      n[63] = "PU`\u0001qMXTw\u0005\u0012Ni\u0012v\u000e~M\u001bMa\u0017\u007f'US`\txU\nDy\b\u0012";
      n[64] = "=\"]N^\u000f5#JJ=伸栝桀叵佷叾伸余桀佫*\r\t<dL\u001aW\u0019<a";
      n[65] = "\u0014<s!VnMnwvg`\"n$r[0\"R|'\u00193\u0004)#>\u001fl";
      n[66] = "\u0016Kb\u001bsI\u001eJu\u001f\u0010叠佲栩栐厼叓叠佲右栐\u007f{HQ\\9\u001fhH\u0016Q";
      n[67] = "\u0019_\u000b9P5\u0011^\u001c=3伂根叧厣桄台厜佽栽厣]\u00033\u0018\u0019\u001amY#\u0018\u001c";
      n[68] = ":\u000bnB$=4\ndF\u0015/SUf\u001d+\u007fSdbEq?cZeU\u007f(";
      n[69] = "QUUY5_YTB]V佨厫叭佣叾厕佨伵佳叽=fYP\u0013D\r<IP\u0016";
      n[70] = "VjG\"]0^kP&>桃桶佌栵伛栧伇伲叒可F\u000e6W,VvT&W)";
      n[71] = "\u001a\u001apXD`D\u001c#\u0016=C;?D&]x\u0015\u001af@\u0003~FT";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private String m(BlockPos pos) {
      树友何何友何树何树友.E();
      if (mc.level.getBlockState(pos).is(Blocks.WATER)) {
         return "水源";
      } else {
         return mc.level.getBlockState(pos).is(Blocks.LAVA) ? "岩浆源" : "液体";
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean q(ItemStack stack) {
      树友何何友何树何树友.E();
      return !stack.isEmpty() && stack.getItem() == Items.BUCKET;
   }

   private BlockPos Y() {
      树友何何友何树何树友.E();
      if (mc.player != null && mc.level != null) {
         BlockPos playerPos = mc.player.blockPosition();
         List<BlockPos> liquidBlocks = new ArrayList<>();
         int horizontalRange = (int)Math.ceil(this.何友友何友友树树何何.getValue().doubleValue());
         int verticalRangeValue = (int)Math.ceil(this.何树树友何友树树树友.getValue().doubleValue());
         int x = -horizontalRange;
         if (x <= horizontalRange) {
            int y = -verticalRangeValue;
            if (y <= verticalRangeValue) {
               int z = -horizontalRange;
               if (z <= horizontalRange) {
                  BlockPos pos = playerPos.offset(x, y, z);
                  double distance = mc.player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                  if (distance > this.何友友何友友树树何何.getValue().doubleValue() * this.何友友何友友树树何何.getValue().doubleValue()) {
                  }

                  if (this.b(pos)) {
                     if (this.何树友友树友友何树友.getValue() && !this.I(pos)) {
                     }

                     liquidBlocks.add(pos);
                  }

                  z++;
               }

               y++;
            }

            x++;
         }

         if (liquidBlocks.isEmpty()) {
            return null;
         } else {
            if (this.何树友树友友树何友树.getValue()) {
               BlockPos belowFeet = playerPos.below();
               Iterator var19 = liquidBlocks.iterator();
               if (var19.hasNext()) {
                  BlockPos posx = (BlockPos)var19.next();
                  if (posx.equals(playerPos) || posx.equals(belowFeet)) {
                     return posx;
                  }
               }
            }

            Vec3 eyePos = mc.player.getEyePosition();
            return liquidBlocks.stream().min(Comparator.comparingDouble(posx -> Vec3.atCenterOf(posx).distanceToSqr(eyePos))).orElse(null);
         }
      } else {
         return null;
      }
   }

   @Override
   protected void M() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.何友树友何树树何树何 = null;
         this.树树友友何树何友何友 = null;
         this.友友树树何树树树友何 = false;
         this.何树何友树树友何友友 = false;
         this.友友何树何树树友友树.D(11747522392279L);
         this.友友友何树何友树树何.D(11747522392279L);
         this.何何何友何何何树何友 = InteractionHand.MAIN_HAND;
         ClientUtils.C("§a[AutoFluidCollector] 模块已启用，寻找液体中...", 108932807550871L);
      }
   }

   private static String LIU_YA_FENG() {
      return "何建国230622195906030014";
   }

   public Rotation G() {
      return this.何友树友何树树何树何;
   }

   private void G() {
      树友何何友何树何树友.E();
      if (this.树树友友何树何友何友 != null && (this.友友树何何何友何友何 != -1 || this.何何何友何何何树何友 == InteractionHand.OFF_HAND) && !this.何树何友树树友何友友) {
         if (this.何何何友何何何树何友 == InteractionHand.MAIN_HAND) {
            this.友友友友友何何何友友 = mc.player.getInventory().selected;
            mc.player.getInventory().selected = this.友友树何何何友何友何;
         }

         mc.options.keyUse.setDown(true);
         this.何树何友树树友何友友 = true;
         this.友友友何树何友树树何.D(11747522392279L);
      }
   }
}
