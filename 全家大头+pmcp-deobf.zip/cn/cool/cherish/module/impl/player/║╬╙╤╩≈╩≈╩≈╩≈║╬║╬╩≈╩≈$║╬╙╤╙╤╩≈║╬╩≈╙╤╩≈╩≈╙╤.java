package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// $VF: synthetic class
class 何友树树树树何何树树$何友友树何树友树树友 implements 何树友 {
   private static final Object[] a = new Object[11];
   private static final String[] b = new String[11];
   private static int _刘凤楠230622109211173513 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7282006959498482320L, -816412984777606564L, MethodHandles.lookup().lookupClass()).a(253477800704597L);
      // $VF: monitorexit
      long var0 = var10000 ^ 113679467235983L;
      a();

      try {
         a<"å">(1154313463252325205L, var0)[a<"å">(1154941049384750360L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"å">(1154313463252325205L, var0)[a<"å">(1154162460917702562L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"å">(1154313463252325205L, var0)[a<"å">(1155032674891694934L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"å">(1154313463252325205L, var0)[a<"å">(1155000533758468409L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"å">(1154313463252325205L, var0)[a<"å">(1154054372128109835L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"å">(1154313463252325205L, var0)[a<"å">(1155173062444230305L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 248 && var8 != 'a' && var8 != 229 && var8 != 'r') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 237) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 207) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 248) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'a') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 229) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树何何树树$何友友树何树友树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 40;
               case 2 -> 50;
               case 3 -> 60;
               case 4 -> 10;
               case 5 -> 20;
               case 6 -> 47;
               case 7 -> 3;
               case 8 -> 34;
               case 9 -> 0;
               case 10 -> 24;
               case 11 -> 49;
               case 12 -> 53;
               case 13 -> 21;
               case 14 -> 62;
               case 15 -> 11;
               case 16 -> 41;
               case 17 -> 56;
               case 18 -> 15;
               case 19 -> 2;
               case 20 -> 7;
               case 21 -> 36;
               case 22 -> 28;
               case 23 -> 23;
               case 24 -> 31;
               case 25 -> 30;
               case 26 -> 8;
               case 27 -> 58;
               case 28 -> 4;
               case 29 -> 25;
               case 30 -> 18;
               case 31 -> 26;
               case 32 -> 5;
               case 33 -> 46;
               case 34 -> 6;
               case 35 -> 55;
               case 36 -> 16;
               case 37 -> 48;
               case 38 -> 39;
               case 39 -> 33;
               case 40 -> 14;
               case 41 -> 1;
               case 42 -> 35;
               case 43 -> 19;
               case 44 -> 57;
               case 45 -> 54;
               case 46 -> 51;
               case 47 -> 9;
               case 48 -> 27;
               case 49 -> 17;
               case 50 -> 13;
               case 51 -> 61;
               case 52 -> 59;
               case 53 -> 32;
               case 54 -> 38;
               case 55 -> 22;
               case 56 -> 44;
               case 57 -> 12;
               case 58 -> 29;
               case 59 -> 43;
               case 60 -> 45;
               case 61 -> 52;
               case 62 -> 63;
               default -> 42;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "\\\u0002`\u001fMVSB-\u0014GKV\u001f&ROV[\u0019\"\u0019\fPR\u001c\"RRU^\u0015+\u000e\f佬叴桽桟桭栳佬佪桽桟X叩栨佪伹桟厷叩佬栮伹";
      a[1] = "{F@EK8t\u0006\rNA%q[\u0006\bI8|]\u0002C\n>uX\u0002\bT;yQ\u000bT\n伂叓根桿样栵伂位根桿\u0002佱厜叓根伻样可框栉口";
      a[2] = "Qx";
      a[3] = "\t\u000b5d( \u0002\u0004$+I.\t\u000f q";
      a[4] = "]\u001f\u001a\u001a\u001a{\f\u0001Ft格叁栨桠厺厷格栛栨厺y\u0018Ca_F\u0000I]=";
      a[5] = "wG\u000f5\u0017u&YS[栱栕变佼桵厘併佑栂核l7Nou\u001e\u0015fP3";
      a[6] = "^\u001a\u0000%me\u000f\u0004\\K厑佁佯伡厠伖厑栅佯桥c'4\u007f\\C\u001av*#";
      a[7] = "\u001fZ\r!\\dNDQO厠叞伮佡厭厌厠叞厰栥n#\u0005~\u001d\u0003\u0017r\u001b\"";
      a[8] = "\u0007\u0017StV\u0017V\t\u000f\u001a厪厭厨厲右叙厪伳桲厲0v\u000f\r\u0005NI'\u0011Q";
      a[9] = "?\u001b\bt\u0011\u0018n\u0005T\u001a样似桊厾厨佇样似桊传kvH\u0002=B\u0012'V^";
      a[10] = "M*\\+\r7E~\u00116p桔伩伜可伇桩伐伩厂可ZI.\u001b{\u00115\u00164\u00183";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String HE_WEI_LIN() {
      return "刘凤楠230622109211173513";
   }
}
