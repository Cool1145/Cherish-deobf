package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.item.SpoofItemUtils;
import cn.cool.cherish.utils.item.友何树何友树友树何何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class 何何友何树何树友树何 extends Module implements 何树友 {
   private final BooleanValue 友何友友树何友友何何;
   private boolean 树友何树何友友何友何;
   private int 何何友何何友何何树树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[27];
   private static final String[] k = new String[27];
   private static int _刘凤楠230622109211173513 _;

   public 何何友何树何树友树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/player/何何友何树何树友树何.a J
      // 03: ldc2_w 13717314828527
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 5370
      // 0c: ldc2_w 2811546270957289527
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友何树何树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 22468
      // 19: ldc2_w 3099897782988964619
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友何树何树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w -834096813448777923
      // 26: lload 1
      // 27: invokedynamic Î (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/何何友何树何树友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/BooleanValue
      // 33: dup
      // 34: sipush 26457
      // 37: ldc2_w 5455006581638902677
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友何树何树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 24359
      // 44: ldc2_w 7048820151735978985
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友何树何树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: bipush 1
      // 4f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 52: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 55: putfield cn/cool/cherish/module/impl/player/何何友何树何树友树何.友何友友树何友友何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 58: aload 0
      // 59: bipush 0
      // 5a: ldc2_w -834210947633465244
      // 5d: lload 1
      // 5e: invokedynamic Ó (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/何何友何树何树友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 63: aload 0
      // 64: bipush 0
      // 65: ldc2_w -834332040725636528
      // 68: lload 1
      // 69: invokedynamic Ó (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/何何友何树何树友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6e: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-7858842167540129093L, -2725826332142107206L, MethodHandles.lookup().lookupClass()).a(146117943897520L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 39131084354876L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "\u000ed3q¯Ãòu\u0099Â<¦¬¿º%Xc>\u008f`ºRl\n¥KäF{÷\u001d(\u0099ÙKHÇ\u0000\u0083êJtkáAÅ\u008f+\u0011\u0013ðÞ\\\u001eÝFÊp?\u0010\u0096\u0095½ÃÞS\u0094|Ë\u0080ò{";
      byte var8 = 73;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[4];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "}¸\u0019ÝùíÌæG\u0096Ñ\u0082jô&\u000fmg*/ãý,#\u009e\u0098V´\u0098É\u00992(\u0080\u009dóã¥4D\u0083óë\u001a7W\u0080\u0095*¤_\u0010¹\u0007/\u0002¬·dÉÂ¢\u0090Ês»\u0010\u007fÇ\u0099wÌð";
                  var8 = 73;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 4;
               case 1 -> 50;
               case 2 -> 21;
               case 3 -> 8;
               case 4 -> 9;
               case 5 -> 19;
               case 6 -> 51;
               case 7 -> 62;
               case 8 -> 26;
               case 9 -> 52;
               case 10 -> 61;
               case 11 -> 49;
               case 12 -> 6;
               case 13 -> 13;
               case 14 -> 7;
               case 15 -> 38;
               case 16 -> 2;
               case 17 -> 16;
               case 18 -> 39;
               case 19 -> 11;
               case 20 -> 42;
               case 21 -> 22;
               case 22 -> 24;
               case 23 -> 12;
               case 24 -> 30;
               case 25 -> 57;
               case 26 -> 20;
               case 27 -> 5;
               case 28 -> 28;
               case 29 -> 59;
               case 30 -> 0;
               case 31 -> 29;
               case 32 -> 54;
               case 33 -> 10;
               case 34 -> 3;
               case 35 -> 23;
               case 36 -> 45;
               case 37 -> 1;
               case 38 -> 63;
               case 39 -> 46;
               case 40 -> 32;
               case 41 -> 47;
               case 42 -> 53;
               case 43 -> 58;
               case 44 -> 44;
               case 45 -> 60;
               case 46 -> 48;
               case 47 -> 56;
               case 48 -> 40;
               case 49 -> 37;
               case 50 -> 43;
               case 51 -> 27;
               case 52 -> 25;
               case 53 -> 34;
               case 54 -> 17;
               case 55 -> 18;
               case 56 -> 15;
               case 57 -> 14;
               case 58 -> 33;
               case 59 -> 35;
               case 60 -> 55;
               case 61 -> 36;
               case 62 -> 31;
               default -> 41;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何何友何树何树友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8359;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何何友何树何树友树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何何友何树何树友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != '$' && var8 != 211 && var8 != 206 && var8 != 'z') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 231) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 218) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == '$') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 211) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 206) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "B\f\u000b\u007f \fMLFt*\u0011H\u0011M2\"\fE\u0017Iya\nL\u0012I2?\u000f@\u001b@na伶佴厩佰栍会桲只桳佰";
      j[1] = boolean.class;
      k[1] = "java/lang/Boolean";
      j[2] = "wJ|\u001a'(wJkF+'m\u0001kX#$w[&y#/|LzU,5";
      j[3] = "\u0003\u001e\u0015<FC\u0003\u001e\u0002`JL\u0019U\u0002~BO\u0003\u000fO][^\u0004\u0014\u000fa";
      j[4] = "9\u007fMf\u001bF9\u007fZ:\u0017I#4N'\u0004C34I \u000f\\yRP<$J$oU<";
      j[5] = "B(\u0018\u0003|\u000bB(\u000f_p\u0004Xc\u000fAx\u0007B9Bft\u001ba,\u001c]x\fK";
      j[6] = "*bB\u0006MI%\"\u000f\rGT \u007f\u0004KOI-y\u0000\u0000\fO$|\u0000KRJ(u\t\u0017\f佳伜叇伹厮栳叭厂余伹";
      j[7] = "#0HxB\u0016\u0017\u0013G8\u000f\u001d\u001d\u000eBe\u0004[\u0015\u0013Oc\u0000\u0010V1Dr\u0019\u0019\u001dG";
      j[8] = int.class;
      k[8] = "java/lang/Integer";
      j[9] = "-/E\u0013:F& T\\F_):Z\u001fqo?-V\u0002`C( ";
      j[10] = "NO\u0005Fw|NO\u0012\u001a{sT\u0004\u0006\u0007hyD\u0004\u0001\u0000cf\u000eb\u0018\u001cHpS_\u001d\u001c>AYZ\u0014";
      j[11] = "~\u001f[\u001eL[q_\u0016\u0015FFt\u0002\u001dSUUq\u0004\u0010SJYm\u001d[?L[q\u0014\u0014\u0013uUq\u0004\u0010";
      j[12] = "-\u0017&rl\u0006-\u00171.`\t7\\%3s\u0003'\\72u\u00067\u000b|,m\u000e:\u0017 rH\u00015\u0017<(n\u001d:";
      j[13] = "\u001c\u0015_6!z\u0013U\u0012=+g\u0016\b\u0019{#z\u001b\u000e\u001d0`佀伪厰伤伀厅佀伪桪桠";
      j[14] = "{Wbp)@pXs?HN{Swe";
      j[15] = "\u0000ht0Y`\u0012? U佦佚厨伏佌厖佦佚桲桋\u0011hFi\u0006.{d]yU";
      j[16] = "\u000e\u0004BE\u0003\u0001\u001cS\u0016 \bf[EJR\u0004\u0016\u0003O@\u001eaX\u001eSUE\u0011\u0000\u0014Y\u0019 ";
      j[17] = "-e.eyh?2z\u0000栂双伛框伖參变佒厅伂Kp#kxn6<{b";
      j[18] = "pR%OS6+Y=X=企厂号厀口叾企伜栭厀 \f:'[-JW1?L";
      j[19] = "r\u0015\u0001|h/q\r\u0006*Wq\u001cCR\"i!\u001crQs+ '\u0002\u000bwkd";
      j[20] = "\u001d]\u0010\u0019\u000e5\u001eE\u0017O1ks\u000bCG\u000e:s:@\u0003^:_[D\u0002Ca";
      j[21] = "+\u0004\u0013:\u000f!q\u0000S~c?F\\U=RlFmTt\f#!W\u0016c\u00033";
      j[22] = "hq2\u0014Q\u0002iwrC68\u0013\t\b86Mh?,\u001cFLn\u007f{";
      j[23] = ":\nI\u0005h7o\b\u0018NS8\u0006[\u001fRh,y\fRQ-G";
      j[24] = "tAC^=3f\u0016\u0017;厜伉叜厸栿佦厜厗佂伦&\u0004\"$m\u001b\u001c^ e~";
      j[25] = "}#\u001cbKH*i@;.\u001a\u001ai\u001bc\u0011K\u001aR\u001b/@\u001918\u00174PJ";
      j[26] = "}\u001d\u001cpL\u0019'\u0019\\4 \u0007\u0010EZw\u0011W\u0010t[>O\u001bwN\u0019)@\u000b";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public void o() {
      long a = 何何友何树何树友树何.a ^ 23497612124141L;
      long ax = a ^ 18080827615810L;
      long axx = a ^ 52798538274796L;
      long axxx = a ^ 134081466897237L;
      c<"Ú">(6012268966223717940L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"$">(this, 6011248827181416074L, a).getValue()) {
            if (!SpoofItemUtils.n(new Object[]{axx})) {
               return;
            }

            c<"Ó">(mc.player.getInventory(), c<"$">(this, 6010548804387732818L, a), 6011295007975165304L, a);
            SpoofItemUtils.n(new Object[]{axxx});
         }

         c<"Ó">(mc.player.getInventory(), c<"$">(this, 6010548804387732818L, a), 6011295007975165304L, a);
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 何何友何树何树友树何.a ^ 122059313060498L;
      c<"Ó">(this, 0, -7631710109516679123L, a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void H(LivingUpdateEvent event) {
      long a = 何何友何树何树友树何.a ^ 132108328604870L;
      long ax = a ^ 137481607700841L;
      long axx = a ^ 102792344837319L;
      long axxx = a ^ 1251780969515L;
      c<"Ú">(1748720179974761759L, a);
      if (!this.w(new Object[]{ax})) {
         if (!c<"$">(c<"$">(mc, 1749003979484376804L, a), 1748546871739442600L, a).isDown()
            && c<"$">(c<"$">(mc, 1749003979484376804L, a), 1749606421339803045L, a).isDown()
            && c<"$">(mc, 1748626946295527636L, a) != null
            && c<"$">(mc, 1748626946295527636L, a).getType() == c<"Î">(1748755788416842821L, a)) {
            if (!c<"$">(this, 1748871989784892493L, a)) {
               c<"Ó">(this, c<"$">(mc.player.getInventory(), 1749373086850680403L, a), 1748152238909470329L, a);
               if (c<"$">(this, 1749458848324580769L, a).getValue() && !SpoofItemUtils.n(new Object[]{axx})) {
                  int var10000 = c<"$">(this, 1748152238909470329L, a);
                  Object[] var10003 = new Object[]{null, axxx};
                  var10003[0] = var10000;
                  SpoofItemUtils.I(var10003);
               }
            }

            this.O();
            c<"Ó">(this, true, 1748871989784892493L, a);
         }

         if (c<"$">(this, 1748871989784892493L, a)) {
            this.o();
            c<"Ó">(this, false, 1748871989784892493L, a);
         }

         c<"Ó">(this, c<"$">(mc.player.getInventory(), 1749373086850680403L, a), 1748152238909470329L, a);
      }
   }

   public void O() {
      long a = 何何友何树何树友树何.a ^ 39419979067712L;
      long ax = a ^ 42834216682735L;
      long axx = a ^ 114854381763305L;
      c<"Ú">(-161311266955786087L, a);
      if (!this.w(new Object[]{ax})) {
         int bestSlot = -1;
         if (c<"$">(mc, -161561080643445422L, a) != null && !mc.level.isEmptyBlock(((BlockHitResult)c<"$">(mc, -161561080643445422L, a)).getBlockPos())) {
            BlockState blockState = mc.level.getBlockState(((BlockHitResult)c<"$">(mc, -161561080643445422L, a)).getBlockPos());
            int i = 0;
            ItemStack item = mc.player.getInventory().getItem(0);
            if (!item.isEmpty() && !友何树何友树友树何何.L(axx, item)) {
               float speed = item.getDestroySpeed(blockState);
               if (speed > 1.0F) {
                  bestSlot = 0;
               }
            }

            i++;
            if (bestSlot != -1) {
               c<"Ó">(mc.player.getInventory(), bestSlot, -161744271152782379L, a);
            }
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "行走的50万——何炜霖";
   }
}
