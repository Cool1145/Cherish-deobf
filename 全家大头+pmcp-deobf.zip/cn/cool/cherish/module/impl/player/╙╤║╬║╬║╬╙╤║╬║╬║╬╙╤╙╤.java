package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.EggItem;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SnowballItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import why.tree.friend.antileak.Fucker;

public class 友何何何友何何何友友 extends Module implements 何树友 {
   private final NumberValue 树树何友友树何友何友;
   private final NumberValue 何何树树何树树树友树;
   private final NumberValue 树何树友何友友何树树;
   private final NumberValue 何何树友树树树何何何;
   private final BooleanValue 树友树树树何何何何何;
   private final BooleanValue 何何友友友友友何友树;
   private final BooleanValue 友何友何何树友树何树;
   private final NumberValue 何树何树友树树树何友;
   private final BooleanValue 友友树友何何何树树何;
   private final BooleanValue 友树何何友友树何树何;
   private final BooleanValue 何树树友友何何树友何;
   private final BooleanValue 友友树树友树友树友友;
   private final BooleanValue 树友何树友何树友何友;
   private final BooleanValue 友树树友友树友何树友;
   private final BooleanValue 友何友友树友树树友树;
   private final NumberValue 何友友友何何友友树树;
   private final BooleanValue 树树树友友何何友树何;
   private Rotation 友友树树树树树何何树;
   private final 树友树友友何何树何何 友树友树友何友友何树;
   private final 树友树友友何何树何何 何友树何何树友何何何;
   private boolean 何树何何何友友何友何;
   private long 何何何树树友何树树何;
   private Map<ThrowableItemProjectile, Long> 何树何何树何友树何友;
   private int 友树友树何友何何树友;
   private int 何友友友友树友树友何;
   private boolean 何友何友何何树何友何;
   private boolean 友何何何树友友友树树;
   private long 树树何何何树友树何树;
   private long 友何何何友树友何树友;
   private final Map<Integer, List<Vec3>> 何树何友何树树何树树;
   private final Map<Integer, List<Vec3>> 何树树树友何树何何友;
   private final Map<Integer, Boolean> 何何树何树何树树何何;
   private final Map<Integer, List<Double>> 树何树友何友何何树友;
   private final int 友何友友友友友何树友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[99];
   private static final String[] n = new String[99];
   private static int _何炜霖230622200409390090 _;

   public 友何何何友何何何友友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:200)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/友何何何友何何何友友.a J
      // 003: ldc2_w 126916569736334
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 91257518379761
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 22234
      // 014: ldc2_w 7069707856645347942
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 619
      // 021: ldc2_w 3358527335061556990
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -5080888825422207370
      // 02e: lload 1
      // 02f: invokedynamic Õ (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/NumberValue
      // 03b: dup
      // 03c: sipush 8770
      // 03f: ldc2_w 3707439209159732985
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 32597
      // 04c: ldc2_w 3023381777563153394
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: sipush 500
      // 059: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 05c: bipush 100
      // 05e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 061: sipush 3000
      // 064: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 067: bipush 100
      // 069: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 06c: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 06f: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.树树何友友树何友何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 072: aload 0
      // 073: new cn/cool/cherish/value/impl/NumberValue
      // 076: dup
      // 077: sipush 14526
      // 07a: ldc2_w 496067448798852096
      // 07d: lload 1
      // 07e: lxor
      // 07f: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 084: sipush 16468
      // 087: ldc2_w 1221060694680161483
      // 08a: lload 1
      // 08b: lxor
      // 08c: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 091: bipush 10
      // 093: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 096: bipush 5
      // 097: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09a: bipush 30
      // 09c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09f: ldc2_w 0.1
      // 0a2: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0a5: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0a8: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何何树树何树树树友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 0ab: ldc2_w -5081024695333773183
      // 0ae: lload 1
      // 0af: invokedynamic g (JJ)[Lcn/cool/cherish/module/Module; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b4: aload 0
      // 0b5: new cn/cool/cherish/value/impl/NumberValue
      // 0b8: dup
      // 0b9: sipush 11715
      // 0bc: ldc2_w 5303641634739888501
      // 0bf: lload 1
      // 0c0: lxor
      // 0c1: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c6: sipush 5349
      // 0c9: ldc2_w 6561695497252345937
      // 0cc: lload 1
      // 0cd: lxor
      // 0ce: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d3: sipush 180
      // 0d6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0d9: bipush 0
      // 0da: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0dd: sipush 180
      // 0e0: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0e3: bipush 10
      // 0e5: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0e8: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0eb: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.树何树友何友友何树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 0ee: aload 0
      // 0ef: new cn/cool/cherish/value/impl/NumberValue
      // 0f2: dup
      // 0f3: sipush 14372
      // 0f6: ldc2_w 8535695779277714580
      // 0f9: lload 1
      // 0fa: lxor
      // 0fb: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 100: sipush 15558
      // 103: ldc2_w 3675280884629287000
      // 106: lload 1
      // 107: lxor
      // 108: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 10d: bipush 0
      // 10e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 111: bipush 0
      // 112: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 115: bipush 3
      // 116: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 119: ldc2_w 0.01
      // 11c: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 11f: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 122: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何何树友树树树何何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 125: aload 0
      // 126: new cn/cool/cherish/value/impl/BooleanValue
      // 129: dup
      // 12a: sipush 16010
      // 12d: ldc2_w 5071254419236729407
      // 130: lload 1
      // 131: lxor
      // 132: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 137: sipush 9566
      // 13a: ldc2_w 569623406021421512
      // 13d: lload 1
      // 13e: lxor
      // 13f: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 144: bipush 0
      // 145: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 148: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 14b: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.树友树树树何何何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 14e: aload 0
      // 14f: new cn/cool/cherish/value/impl/BooleanValue
      // 152: dup
      // 153: sipush 26975
      // 156: ldc2_w 3528489511315400156
      // 159: lload 1
      // 15a: lxor
      // 15b: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 160: sipush 9852
      // 163: ldc2_w 5363092332399733470
      // 166: lload 1
      // 167: lxor
      // 168: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16d: bipush 1
      // 16e: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 171: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 174: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何何友友友友友何友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 177: aload 0
      // 178: new cn/cool/cherish/value/impl/BooleanValue
      // 17b: dup
      // 17c: sipush 27830
      // 17f: ldc2_w 6475113114200629282
      // 182: lload 1
      // 183: lxor
      // 184: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 189: sipush 16035
      // 18c: ldc2_w 1488211325108204048
      // 18f: lload 1
      // 190: lxor
      // 191: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 196: bipush 1
      // 197: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 19a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 19d: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.友何友何何树友树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1a0: pop
      // 1a1: aload 0
      // 1a2: new cn/cool/cherish/value/impl/NumberValue
      // 1a5: dup
      // 1a6: sipush 8136
      // 1a9: ldc2_w 6682496355688584026
      // 1ac: lload 1
      // 1ad: lxor
      // 1ae: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b3: sipush 25313
      // 1b6: ldc2_w 5083249792500330049
      // 1b9: lload 1
      // 1ba: lxor
      // 1bb: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c0: bipush 100
      // 1c2: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1c5: bipush 0
      // 1c6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1c9: sipush 1000
      // 1cc: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1cf: bipush 10
      // 1d1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1d4: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1d7: aload 0
      // 1d8: invokedynamic get (Lcn/cool/cherish/module/impl/player/友何何何友何何何友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/player/友何何何友何何何友友.G ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 1dd: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 1e0: checkcast cn/cool/cherish/value/impl/NumberValue
      // 1e3: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何树何树友树树树何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 1e6: aload 0
      // 1e7: new cn/cool/cherish/value/impl/BooleanValue
      // 1ea: dup
      // 1eb: sipush 15444
      // 1ee: ldc2_w 79805684374122710
      // 1f1: lload 1
      // 1f2: lxor
      // 1f3: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f8: sipush 5181
      // 1fb: ldc2_w 999475509374687392
      // 1fe: lload 1
      // 1ff: lxor
      // 200: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 205: bipush 1
      // 206: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 209: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 20c: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.友友树友何何何树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 20f: aload 0
      // 210: new cn/cool/cherish/value/impl/BooleanValue
      // 213: dup
      // 214: sipush 25334
      // 217: ldc2_w 8952333898453413452
      // 21a: lload 1
      // 21b: lxor
      // 21c: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 221: sipush 31358
      // 224: ldc2_w 5462064975887398642
      // 227: lload 1
      // 228: lxor
      // 229: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 22e: bipush 1
      // 22f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 232: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 235: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.友树何何友友树何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 238: aload 0
      // 239: new cn/cool/cherish/value/impl/BooleanValue
      // 23c: dup
      // 23d: sipush 19489
      // 240: ldc2_w 8630080964363436207
      // 243: lload 1
      // 244: lxor
      // 245: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 24a: sipush 16868
      // 24d: ldc2_w 4159279856436956535
      // 250: lload 1
      // 251: lxor
      // 252: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 257: bipush 1
      // 258: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 25b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 25e: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何树树友友何何树友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 261: aload 0
      // 262: new cn/cool/cherish/value/impl/BooleanValue
      // 265: dup
      // 266: sipush 20276
      // 269: ldc2_w 7863664169796158396
      // 26c: lload 1
      // 26d: lxor
      // 26e: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 273: sipush 2840
      // 276: ldc2_w 3773234707000133564
      // 279: lload 1
      // 27a: lxor
      // 27b: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 280: bipush 0
      // 281: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 284: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 287: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.友友树树友树友树友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 28a: aload 0
      // 28b: new cn/cool/cherish/value/impl/BooleanValue
      // 28e: dup
      // 28f: sipush 15162
      // 292: ldc2_w 193697388694419353
      // 295: lload 1
      // 296: lxor
      // 297: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 29c: sipush 4888
      // 29f: ldc2_w 1205647199971712927
      // 2a2: lload 1
      // 2a3: lxor
      // 2a4: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2a9: bipush 1
      // 2aa: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2ad: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2b0: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.树友何树友何树友何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2b3: aload 0
      // 2b4: new cn/cool/cherish/value/impl/BooleanValue
      // 2b7: dup
      // 2b8: sipush 18204
      // 2bb: ldc2_w 9223169015433448356
      // 2be: lload 1
      // 2bf: lxor
      // 2c0: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c5: sipush 20378
      // 2c8: ldc2_w 7555712288901481255
      // 2cb: lload 1
      // 2cc: lxor
      // 2cd: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2d2: bipush 0
      // 2d3: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2d6: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2d9: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.友树树友友树友何树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2dc: aload 0
      // 2dd: new cn/cool/cherish/value/impl/BooleanValue
      // 2e0: dup
      // 2e1: sipush 32345
      // 2e4: ldc2_w 4864590253676425951
      // 2e7: lload 1
      // 2e8: lxor
      // 2e9: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2ee: sipush 4179
      // 2f1: ldc2_w 1417142389193252074
      // 2f4: lload 1
      // 2f5: lxor
      // 2f6: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2fb: bipush 1
      // 2fc: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2ff: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 302: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.友何友友树友树树友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 305: aload 0
      // 306: new cn/cool/cherish/value/impl/NumberValue
      // 309: dup
      // 30a: sipush 5880
      // 30d: ldc2_w 1092356780205316679
      // 310: lload 1
      // 311: lxor
      // 312: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 317: sipush 21824
      // 31a: ldc2_w 6802768155125864896
      // 31d: lload 1
      // 31e: lxor
      // 31f: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 324: bipush 8
      // 326: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 329: bipush 3
      // 32a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 32d: bipush 15
      // 32f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 332: ldc2_w 0.5
      // 335: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 338: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 33b: aload 0
      // 33c: ldc2_w -5082103864270173777
      // 33f: lload 1
      // 340: invokedynamic ¥ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 345: dup
      // 346: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 349: pop
      // 34a: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 34f: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 352: checkcast cn/cool/cherish/value/impl/NumberValue
      // 355: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何友友友何何友友树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 358: aload 0
      // 359: new cn/cool/cherish/value/impl/BooleanValue
      // 35c: dup
      // 35d: sipush 5612
      // 360: ldc2_w 6385683726547949933
      // 363: lload 1
      // 364: lxor
      // 365: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 36a: sipush 9007
      // 36d: ldc2_w 3870092525887827896
      // 370: lload 1
      // 371: lxor
      // 372: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 377: bipush 1
      // 378: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 37b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 37e: aload 0
      // 37f: ldc2_w -5082103864270173777
      // 382: lload 1
      // 383: invokedynamic ¥ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 388: dup
      // 389: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 38c: pop
      // 38d: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 392: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 395: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 398: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.树树树友友何何友树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 39b: aload 0
      // 39c: aconst_null
      // 39d: ldc2_w -5085120362958456509
      // 3a0: lload 1
      // 3a1: invokedynamic s (Ljava/lang/Object;Lcn/cool/cherish/utils/helper/Rotation;JJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3a6: aload 0
      // 3a7: new cn/cool/cherish/utils/树友树友友何何树何何
      // 3aa: dup
      // 3ab: lload 3
      // 3ac: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 3af: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.友树友树友何友友何树 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 3b2: aload 0
      // 3b3: new cn/cool/cherish/utils/树友树友友何何树何何
      // 3b6: dup
      // 3b7: lload 3
      // 3b8: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 3bb: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何友树何何树友何何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 3be: aload 0
      // 3bf: bipush 0
      // 3c0: ldc2_w -5087079409276119542
      // 3c3: lload 1
      // 3c4: invokedynamic s (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3c9: aload 0
      // 3ca: lconst_0
      // 3cb: ldc2_w -5088266286462828685
      // 3ce: lload 1
      // 3cf: invokedynamic s (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3d4: aload 0
      // 3d5: new java/util/HashMap
      // 3d8: dup
      // 3d9: invokespecial java/util/HashMap.<init> ()V
      // 3dc: ldc2_w -5080816312295381335
      // 3df: lload 1
      // 3e0: invokedynamic s (Ljava/lang/Object;Ljava/util/Map;JJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3e5: aload 0
      // 3e6: bipush -1
      // 3e7: ldc2_w -5086933892016937990
      // 3ea: lload 1
      // 3eb: invokedynamic s (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3f0: aload 0
      // 3f1: bipush 0
      // 3f2: ldc2_w -5087610572441269069
      // 3f5: lload 1
      // 3f6: invokedynamic s (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3fb: aload 0
      // 3fc: bipush 0
      // 3fd: ldc2_w -5086823544993854343
      // 400: lload 1
      // 401: invokedynamic s (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 406: aload 0
      // 407: bipush 0
      // 408: ldc2_w -5081119386114683942
      // 40b: lload 1
      // 40c: invokedynamic s (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 411: aload 0
      // 412: lconst_0
      // 413: ldc2_w -5087671445874518881
      // 416: lload 1
      // 417: invokedynamic s (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41c: aload 0
      // 41d: lconst_0
      // 41e: ldc2_w -5087009205920118876
      // 421: lload 1
      // 422: invokedynamic s (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 427: aload 0
      // 428: new java/util/HashMap
      // 42b: dup
      // 42c: invokespecial java/util/HashMap.<init> ()V
      // 42f: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何树何友何树树何树树 Ljava/util/Map;
      // 432: aload 0
      // 433: new java/util/HashMap
      // 436: dup
      // 437: invokespecial java/util/HashMap.<init> ()V
      // 43a: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何树树树友何树何何友 Ljava/util/Map;
      // 43d: aload 0
      // 43e: new java/util/HashMap
      // 441: dup
      // 442: invokespecial java/util/HashMap.<init> ()V
      // 445: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.何何树何树何树树何何 Ljava/util/Map;
      // 448: aload 0
      // 449: new java/util/HashMap
      // 44c: dup
      // 44d: invokespecial java/util/HashMap.<init> ()V
      // 450: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.树何树友何友何何树友 Ljava/util/Map;
      // 453: aload 0
      // 454: sipush 20647
      // 457: ldc2_w 5804865467433830789
      // 45a: lload 1
      // 45b: lxor
      // 45c: invokedynamic m (IJ)I bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 461: putfield cn/cool/cherish/module/impl/player/友何何何友何何何友友.友何友友友友友何树友 I
      // 464: ldc2_w -5082190236044357706
      // 467: lload 1
      // 468: invokedynamic g (JJ)Z bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 46d: ifeq 47d
      // 470: bipush 4
      // 471: anewarray 4
      // 474: ldc2_w -5088346375954455021
      // 477: lload 1
      // 478: invokedynamic g (Ljava/lang/Object;JJ)V bsm=cn/cool/cherish/module/impl/player/友何何何友何何何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 47d: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(5076882365390806187L, -6258013975919376472L, MethodHandles.lookup().lookupClass()).a(121189282761009L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 118948015573138L;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[55];
      int var18 = 0;
      String var17 = "?zò[<\u009c2hK\u0019É\u0019\u0004AX\u0084Ù\u0016µ\u0003ên.³\u0018½a°\u0092\u0080\u000eí[\tczùV\u009a<{\u001f#1Â\u00824d28\u008b\u0010¦\u0089·â»¤\u008b5_\u008bå×\u009at¢\u00adr\u000e\"z\u0011n1·\u001f>èLpoñ\u0083FÒ!\u000fÕ\f\u001c+\u0086\u009d\u0016#\u008a\u0096_ÉV\u008aE¥2\u0017hßë\u0017*ó\"\u00184=,Ö\u001fp(^5æ\\xNÔ\u008am²°tB>¬ñ\u000f\u009a»M¾CÅ=\u008aÍ0úCªö\u0087ÄW\u0019E\u001fBgI\fÞ\u0088ù¶Mò\u001e0\u0099Ö!»\u009fÀ÷?\u007f»\u008b&ì0\u009b3Fª\r\u0011ø8ê\u000f\u000f²,ý\u009a\u0017-å\u0017Í\u0094ê]0í&¦(½\u001a\u0094ÉçÝ\u0098R³\u009a\u008f\u007f\u0081\u0001\u009aÎ®EÛÝ\u0084?|ú¨ X\u0087¹ÿ~K_NTÿ\u0001\u007f¤¹ \b=\u0003Ù`\u008c\u0004\u0016ÄTrÇéh\u0086v©ù\u009aØ\u009f\u0092\u0092Y¬wyÍÊ\u0006\n\u0094\u0018\u0018£¨Y\u001dëÍþ\u0099¥\u008b¬{/ãBHµX\b12Ç?\u0018Kß#Þ\u0083ú\u0094CáHü³9\u001eDaì\u008b\u0005Ø%¹j¶(\u008c¿»\u009dîgS\u0000d¼Q\b\u0090\u0012²\u0096\u0082B1©t\nó} 5ÖH*¥ªVºgÅàýRj¿(µnåi\u008d´A\u009dKn`\u0092è\u001a\u0081î\b\u0018´\u009aXÛ`to<Õÿ¤\u00ad}\u001aÉIm*Àg,´`¤\u0015\u008f\u0004T#\u0010él6Ûª}\u0001 `¹\u009eÚE<P>·\u000e¡\u0093¢\n\u0098\u0097-åÎI;AFÁiýÂgÆZ\u0000\u0012\u0096\u0003\u0002íÛ\u0004¸DÅ\u0017ix¶BPJ\u001bó\"\u0093VÅ'\"õ<!\u0084$\u0094p±çþ\u008f\u001cfzíc8u\rÜpÉÕ\u0010±@aÇÏ5\u0018W\u0099VÎËGép\u0010\u001e,\u0011þ\u00196\u0004g\u0094Ý ÖNo\u0086¨Ö\u0000Bªô=\u0000\u0000Gç\u0012Ê\u0092\u0011Ô·p6\tQ=´î½&WÈoúè^M[\u007f \u0082Í\u008eEýj\u008d-è\u0096\"gIfx\u0091\u0005Ü\u001d{8\u008c\u0003ö\"\u0096K\u009e\nw}°\u00101¨wG65ß¯Á\u008d\u0084YT/>©(¾Â0\bð\u0096\u0012\u0099Á2@ÀhÖß\u0093\u0091.B©\u008c\rN \t\u001dZû\u007fLÂ¿ãî\tf³\u0094\u009ed \u0087¯ùó&¦£Ê\u009båcèû¡KËx¦ATX\u001bü§wY?PÜ gF\u0018jÈüÖ\u0097aöTrCpÝ\u0095Ó.&s\u0089\"\u001f|\u001a«D l6¤CßuÛ\u0002N}í\u0097ØÞ\u00022¢Pþ.\\\u0005¾R*æÄipÙöº ¤¹\u001aÇ/¶×kAy\u0091¡ñ2¬ÀV2;\u009dÿ=¶Ë\t\u0012ÃXv|\u0018þ0E\u001b\u0080MUF\u001b_±/_\u009aèïø§ÃÃÍãä/qt\u0095®¾yù¦¬µ\u001aiKÑþ$î'yÞigÙ\u0004\u001eé ïé\u0010\u0096´þ$\\Ï\u001aàp½äÕ\fu\u0007ª\u0088\u0013lYè3!\u000eµQÓ8c ãÁ<pà[ßZ.ì\u0013SN7+\u0089\u0084Üì-k§]U3\u008dª\u008f\u00070¾ú\u0010ÆR\n¨Em\u0015Ü\u0018\u0004§\u0081¾Ê%ð`³\u0004v\u0002,\u0003Ø\u0096nÅ5dÖ\u008f\u008a»U\u009c\u009d.p¤]\u0001çÝ\bÈ¬÷°GA«\u0019\u0019\"Á2b1²qù5Fà\u001e)\f\u0018\u008a¿\u0088[²®,Ë\u0098?>Dö\u0089<#à\u00844\u0085ÑJ0,û,\u00042\u0017Þ\u001b«\u008e79Z\b©Á\u001a\f..¬\u00808\u0001¦\u0082A*\u008a\u0093óùtë»þÍ¿¬®\u009c\u0089úÄÙ/G¾.ù¢\n ©\u0096\u0094\u0092_°V\u0098\u0092Å\u0089º\u0092zv-¢ge¨Ï¨=\u0000¹´\u0080èîjÍÖ(\u0090É\u008aÙ\u00ad\u001dÖ ©¤£Á,\u000e$I²ZP\u0004Z÷ó\u0007\u0095ç÷\u0082\u000e¡÷\u00ads¹·Îñ\u000fÕêM«NÖ³\u0084\u00938\u0092ióù*î\u009cHè\u0014ftÓf±D@{\u001fñê\u008e·\u0081zYMÓò\nu:\rY\u0091Ó»¨\u001am£2¿\u0084;\u0097ó\u0096_J\u0006\u0014+ó\u0018ÆÆ\u0002ÕÈ \u0091±Ô{Û\u008b\u0089*#á\u0088¿Í\u0010\u00ad]'\u0083¯{-êóÑÏÂ\u008b&[\u0005\u0010z^aékiSkôÁ3xª±L\u008d ã\u0014(KzV\u0007àü\u0019<1óÓ\u0082Bì\u0005À ëß\u001f±Ù\u0012Ú\u008dÈ{}'Xþ\bw¡µ\u0082#\u0092Û\u001e_;\u0088£;\rý^¿9\u009fGëd\u0097N\u0007\\\u008dÉ\u0004\u00adW»[UÁr»Á\u0088<v\u0001\bÀØ{iãúÅ\u0091`ÞÊødN²Éæ\u0007\u008b´¬\u0019\u0015ÉîN³å\u0083nt3þÞÓ\u0095\u0017ù|}R\u008d(\u0018\u0096\u0004ÒÒ,F\u00070RÇQ\u0089\u0016µ}]\u001bQìz\u009fªkmXª\u0018K\u0018\u0099\u009d\u008a\u000eßñ÷\u0097\u0017\u0095°\u0086@\u008bqÝÌ\u001d§ã\u008a\u001fMhÅ\u007fOn×\u0086\"\u0003èßww\u001a\u0082\u009bo¼Î\u0098`¯,ü;ë\u00adÝä\u0012\u0000xûéûq\u0092N\u0006:¶\u0095©sgOA4Ö\u001aÐú\u0087\u008cên/U\u0093\u001cª`µöÒh4²y_úº)R%\u0091Å\u000b«Þ2É¥5Ûê3\u0085Ø\u007f}ª;¡\u0082® ç\f\u007fy\u0084Sû\u0003\u0016j\t\u0005Á\u008cÓ#\u009eÛ·M\u0010ák¾Ê¤fÚÈÁ\u0097ï\u0015IMÝ2YhÕ2æÔÎ\u0015i3\u0016-Sõß½þêlÙ£\u0087Uø\u0018÷\u0083Û\n}2õ\u009f\u0083/h3Kzs\"\u0015\r×éÀ°Kq('\u0092#Êå\u009f¬·¿%¿\u0001\r\u0086\u0000«\u001d\u0010AØ\u00982\u0000ì\\Ú\u0011Ô4Í+EÆ_\u0081\u0013·RlâX«\u001aS\b³eT\u007fO\t<?\u000e/y~\u0089nöüñi\u009a\rP\f|Z·\u0007³Q#·j\r\u0002Ñ\u008e\u0015\t?VÉÝ\r¨f§\u0001ÂSÍ6zÞnHì\u0098\u001e½\u009eÃÊ³\u0092Ø6¢\u009f®~\u0094\u0015ªG«a3»D0*\u001aoÒ\u000e\u0010QÌ×Å2|&\u0000&E]ÝóÉ\u0090ÉXÀ.½Ê\u0093M\r¢õ[°æÈ·I\u00016×l|\u009a\u0013nLÜ&Yzö\t&áßÃá\t\u0085\u0092t\u00108¨íTòaÖ\u001f\u0085\u009ebe\b±õZú\bìAEÎhkr1+w\n\u00ad&\u001bºv\u0087Ð³ô@¸\u0094aÆÛ\u00028*Æ\u0010SÚXUÙ\u0098ÜzL\u0003õÍ¶ÕB· lC^º/\u00adØÌ\u0083¥E8\u0082Ê\u0091¯\u0084X\u0083\u0001µv;yæÊ§±]á¶a Ø9zkó\u001et>*Ë\u008cÈmYW\u0004\u0007p\u008c£@«ìa=1¥*~ý¤ã\u0010J¡fÏæ*lïDHcðcå~\u009b äå\u0002\u008dÁ>ì\u00916ÜAä\u009d-§â\u0080\u008eqú¸¦bë7»Ækê\u001aÌh \u0087®µE\u0004\u0012÷\u0097»½f¿íØú\u0016f\u0087\u007fÔoahökz³\u001dS¾J¬\u0010xOL+uÉÁ\u0000ÀÎ\u007fkÍó\u0095â ª|ß\u0097û\u0016£K\"ü_\u0005C`\u0099L¿±\u008e\t\u0088(>ñ{\u0080\u009fKÄ\u000b\u0093S \u0011\u0096Bî\u0011\u0094¨yÆ\u0019\u0094DÝìp}Ë¤\u0091\u0087ÔUÆOZÈ¾\f7L\u0089ë +õÈ\u008d\u001d\u0080\u0000\u00887?%sq£Z\"¿°°¨\u0013¥Ù`Å\"\b½\u0094á¤» Õ\u001b\u0089\u0099Òé³\u001b\u0016\u0017\u0081\u0017#^[\u00142ùåN×\u0012$s\u0094Ñ¶,ô»t8\u0018P\u0080\u0010Z¶\u0082|\fÿ\u008e\u0090a\u0004\u0000\u000bv9®\u0080cÀ#\u000e« jÙTÜ\u0016C\u0000Èþ0í\u0004NcûHhÐÏ§ÆØ«\u000eè¬âYãRsª`\u0089´\u0090\u001ew2j[\u0099è¢DN\u0005uÐ \\d+\u0006*PíþC¼\u009b\u0091\u0084Á\u00052''Ý\u001f\u0081*RR\u0084\u001e]\u0098½\u0003\t\u008b!\u009fè¨â\u008701¾\u008a¯\u0080 \u0001°Óóýæ2_¢%\u0085säp\u000e\u0098ûö\u0088ek¶\u0019=I¿´\u000f\u009e\u0002Ê§cN(à\u001bW\u008dü$a0\u0000Ôª\u00ad¶\u001fù\u009f§´R'ÄÀ\u009e÷\u0092w¥_\u0012\u0016A\f\u001cÛýÑêäMè";
      short var19 = 2348;
      char var16 = 24;
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[55];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "¶<õpÏâf\u007fzâ7ïèhé5".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Integer[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "1¢ï\u0081\u00841¹¼\fh\"Ù\u0095ÞWÓ\u0010Ég\u0080×¾¶c?ÄJEûâÁ\u0012:";
                  var19 = 33;
                  var16 = 16;
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void D(PacketEvent event) {
      long a = 友何何何友何何何友友.a ^ 94614041023716L;
      long ax = a ^ 126991436296244L;
      long axx = a ^ 138014367342804L;
      d<"g">(-3956773363985886997L, a);
      if (!this.w(new Object[]{ax})) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ServerboundInteractPacket) {
            d<"s">(this, true, -3959264900789027821L, a);
            d<"s">(this, System.currentTimeMillis(), -3958997612849257227L, a);
            if (d<"¥">(this, -3956717485082922499L, a).getValue()) {
               ClientUtils.e(new Object[]{b<"i">(19515, 2980477711252533453L ^ a), axx});
            }
         }

         if (packet instanceof ServerboundUseItemPacket wrapper) {
            if (wrapper.getHand() == d<"Õ">(-3957331887404955004L, a)) {
               if (!mc.player.getMainHandItem().isEmpty() && mc.player.getMainHandItem().getItem() instanceof FishingRodItem) {
                  return;
               }
            } else if (!mc.player.getOffhandItem().isEmpty() && mc.player.getOffhandItem().getItem() instanceof FishingRodItem) {
               return;
            }

            d<"s">(this, true, -3956946954129704016L, a);
            d<"s">(this, System.currentTimeMillis(), -3959379342039107634L, a);
            if (d<"¥">(this, -3956717485082922499L, a).getValue()) {
               ClientUtils.e(new Object[]{b<"i">(9703, 6211783971583580439L ^ a), axx});
            }
         }

         if (packet instanceof ServerboundPlayerActionPacket
            && ((ServerboundPlayerActionPacket)event.getPacket()).getAction() == d<"Õ">(-3960597684487336160L, a)) {
            d<"s">(this, true, -3956946954129704016L, a);
            d<"s">(this, System.currentTimeMillis(), -3959379342039107634L, a);
            if (d<"¥">(this, -3956717485082922499L, a).getValue()) {
               ClientUtils.e(new Object[]{b<"i">(29087, 8431933113761500526L ^ a), axx});
            }
         }
      }
   }

   protected void F() {
      long a = 友何何何友何何何友友.a ^ 9895880673290L;
      long ax = a ^ 48869803994330L;
      d<"g">(6194957043134712837L, a);
      if (!this.w(new Object[]{ax})) {
         this.Y();
      }
   }

   private double I(Entity target, double time, double velocity, double airResistance, double gravity) {
      long a = 友何何何友何何何友友.a ^ 94651740663000L;
      long ax = a ^ 126888909228040L;
      d<"g">(-5680526159431096105L, a);
      Vec3 predictedTargetPos = this.m(target, time);
      if (this.w(new Object[]{ax})) {
         return Double.MAX_VALUE;
      } else {
         double dx = d<"¥">(predictedTargetPos, -5677957497261862410L, a) - mc.player.getX();
         double dy = d<"¥">(predictedTargetPos, -5676839344906749598L, a) - (mc.player.getY() + mc.player.getEyeHeight());
         double dz = d<"¥">(predictedTargetPos, -5678080069036191356L, a) - mc.player.getZ();
         double horizontalDist = Math.sqrt(dx * dx + dz * dz);
         double initialYVelocity = this.k(dy, time, 0.03, 0.99);
         double horizontalVelocity = this.Z(horizontalDist, time, airResistance);
         if (Math.sqrt(horizontalVelocity * horizontalVelocity + initialYVelocity * initialYVelocity) > 1.6500000000000001) {
            return 100.0;
         } else {
            double vx = dx / horizontalDist * horizontalVelocity;
            double vz = dz / horizontalDist * horizontalVelocity;
            double snowballX = 0.0;
            double snowballY = 0.0;
            double snowballZ = 0.0;
            int tick = 0;
            if (0.0 < Math.ceil(time)) {
               snowballX = 0.0 + vx;
               snowballY = 0.0 + initialYVelocity;
               snowballZ = 0.0 + vz;
               double var10000 = vx * airResistance;
               double motionY = initialYVelocity * airResistance;
               var10000 = vz * airResistance;
               var10000 = motionY - gravity;
               tick++;
            }

            double finalX = mc.player.getX() + snowballX;
            double finalY = mc.player.getY() + mc.player.getEyeHeight() + snowballY;
            double finalZ = mc.player.getZ() + snowballZ;
            return Math.sqrt(
               Math.pow(finalX - d<"¥">(predictedTargetPos, -5677957497261862410L, a), 2.0)
                  + Math.pow(finalY - d<"¥">(predictedTargetPos, -5676839344906749598L, a), 2.0)
                  + Math.pow(finalZ - d<"¥">(predictedTargetPos, -5678080069036191356L, a), 2.0)
            );
         }
      }
   }

   private List<Entity> I(double range) {
      long a = 友何何何友何何何友友.a ^ 87982128106411L;
      long ax = a ^ 129152288255867L;
      long axx = a ^ 135841668579227L;
      d<"g">(-7612858397597855836L, a);
      if (!this.w(new Object[]{ax}) && mc.level != null) {
         List<Entity> crystals = new ArrayList<>();

         for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity != null && !entity.isRemoved()) {
               if (!(entity instanceof EndCrystal)) {
                  break;
               }

               double distance = mc.player.distanceTo(entity);
               if (distance < 1.5) {
                  if (!d<"¥">(this, -7612793794504790350L, a).getValue()) {
                     continue;
                  }

                  ClientUtils.e(
                     new Object[]{String.format(b<"i">(15368, 3705385784081653685L ^ a), entity.getX(), entity.getY(), entity.getZ(), distance), axx}
                  );
               }

               double heightDifference = entity.getY() - mc.player.getY();
               if (heightDifference > 2.0) {
                  if (!d<"¥">(this, -7612793794504790350L, a).getValue()) {
                     continue;
                  }

                  ClientUtils.e(
                     new Object[]{String.format(b<"i">(31395, 7566011241740589351L ^ a), entity.getX(), entity.getY(), entity.getZ(), heightDifference), axx}
                  );
               }

               if (distance <= range) {
                  crystals.add(entity);
               }
               break;
            }
         }

         crystals.sort(Comparator.comparingDouble(mc.player::distanceTo));
         if (d<"¥">(this, -7612793794504790350L, a).getValue() && !crystals.isEmpty()) {
            ClientUtils.e(new Object[]{String.format(b<"i">(26923, 8544351030456076951L ^ a), crystals.size(), range), axx});
         }

         return crystals;
      } else {
         return new ArrayList<>();
      }
   }

   private double Z(double distance, double time, double airResistance) {
      long a = 友何何何友何何何友友.a ^ 129224147715213L;
      d<"g">(6449036041641869442L, a);
      double minV = 0.0;
      int iter = 0;
      double d = 0.0;
      int t = 0;
      if (0.0 < time) {
         d = 2.5;
         t++;
      }

      if (d < distance) {
         minV = 2.5;
      }

      iter++;
      return (minV + 2.5) / 2.0 * 1.02;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private List<Vec3> e(Vec3 targetPos, double ticks) {
      long a = 友何何何友何何何友友.a ^ 2790879256457L;
      long ax = a ^ 43962184285017L;
      d<"g">(4790672295623875462L, a);
      if (this.w(new Object[]{ax})) {
         return new ArrayList<>();
      } else {
         List<Vec3> points = new ArrayList<>();
         Vec3 eyePos = new Vec3(mc.player.getX(), mc.player.getY() + mc.player.getEyeHeight(), mc.player.getZ());
         points.add(eyePos);
         double dx = d<"¥">(targetPos, 4783529933518152359L, a) - d<"¥">(eyePos, 4783529933518152359L, a);
         double dy = d<"¥">(targetPos, 4784656984981097011L, a) - d<"¥">(eyePos, 4784656984981097011L, a);
         double dz = d<"¥">(targetPos, 4783452681905873621L, a) - d<"¥">(eyePos, 4783452681905873621L, a);
         double horizontalDist = Math.sqrt(dx * dx + dz * dz);
         double horizontalVelocity = this.Z(horizontalDist, ticks, 0.99);
         double initialYVelocity = this.k(dy, ticks, 0.03, 0.99);
         double vx = dx / horizontalDist * horizontalVelocity;
         double vz = dz / horizontalDist * horizontalVelocity;
         double x = d<"¥">(eyePos, 4783529933518152359L, a);
         double y = d<"¥">(eyePos, 4784656984981097011L, a);
         double z = d<"¥">(eyePos, 4783452681905873621L, a);
         int numSteps = Math.max(10, (int)(ticks * 2.0));
         double stepSize = ticks / numSteps;
         int i = 0;
         if (0 < numSteps) {
            x += vx * stepSize;
            y += initialYVelocity * stepSize;
            z += vz * stepSize;
            double var10000 = vx * Math.pow(0.99, stepSize);
            var10000 = initialYVelocity * Math.pow(0.99, stepSize) - 0.03 * stepSize;
            var10000 = vz * Math.pow(0.99, stepSize);
            points.add(new Vec3(x, y, z));
            i++;
         }

         return points;
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 62;
               case 1 -> 56;
               case 2 -> 6;
               case 3 -> 14;
               case 4 -> 15;
               case 5 -> 42;
               case 6 -> 11;
               case 7 -> 19;
               case 8 -> 45;
               case 9 -> 35;
               case 10 -> 30;
               case 11 -> 51;
               case 12 -> 54;
               case 13 -> 17;
               case 14 -> 59;
               case 15 -> 4;
               case 16 -> 2;
               case 17 -> 3;
               case 18 -> 39;
               case 19 -> 40;
               case 20 -> 8;
               case 21 -> 60;
               case 22 -> 10;
               case 23 -> 44;
               case 24 -> 37;
               case 25 -> 57;
               case 26 -> 23;
               case 27 -> 1;
               case 28 -> 55;
               case 29 -> 50;
               case 30 -> 41;
               case 31 -> 5;
               case 32 -> 16;
               case 33 -> 46;
               case 34 -> 20;
               case 35 -> 53;
               case 36 -> 52;
               case 37 -> 13;
               case 38 -> 49;
               case 39 -> 12;
               case 40 -> 48;
               case 41 -> 32;
               case 42 -> 29;
               case 43 -> 7;
               case 44 -> 21;
               case 45 -> 34;
               case 46 -> 18;
               case 47 -> 36;
               case 48 -> 61;
               case 49 -> 26;
               case 50 -> 28;
               case 51 -> 0;
               case 52 -> 58;
               case 53 -> 27;
               case 54 -> 24;
               case 55 -> 9;
               case 56 -> 63;
               case 57 -> 22;
               case 58 -> 43;
               case 59 -> 33;
               case 60 -> 47;
               case 61 -> 38;
               case 62 -> 31;
               default -> 25;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何何何友何何何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13796;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友何何何友何何何友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private int s() {
      long a = 友何何何友何何何友友.a ^ 123009047422148L;
      long ax = a ^ 81991826276372L;
      d<"g">(-489046848104177461L, a);
      if (this.w(new Object[]{ax})) {
         return -1;
      } else {
         if (d<"¥">(this, -489485943125131782L, a).getValue()) {
            ItemStack offhandStack = mc.player.getOffhandItem();
            if (!offhandStack.isEmpty()) {
               if (offhandStack.getItem() instanceof EggItem || offhandStack.getItem() instanceof SnowballItem) {
                  return -2;
               }

               if (d<"¥">(this, -489441030477271410L, a).getValue() && offhandStack.getItem() instanceof FishingRodItem) {
                  return -2;
               }
            }
         }

         if (d<"¥">(this, -490005015007868499L, a).getValue()) {
            int i = 0;
            ItemStack stack = mc.player.getInventory().getItem(0);
            if (stack.isEmpty()) {
            }

            if (stack.getItem() instanceof EggItem || stack.getItem() instanceof SnowballItem) {
               return 0;
            }

            if (d<"¥">(this, -489441030477271410L, a).getValue() && stack.getItem() instanceof FishingRodItem) {
               return 0;
            }

            i++;
         }

         return -1;
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何何何友何何何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 165 && var8 != 's' && var8 != 213 && var8 != 'L') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'R') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'g') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 165) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 's') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 8276;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友何何何友何何何友友", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友何何何友何何何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "\f&\u0016\u000fb~\u0003f[\u0004hc\u0006;PB`~\u000b=T\t#x\u00028TB}}\u000e1]\u001e#叚伺伝佭厧佘佄伺厃右";
      m[1] = "\u0011\u001dK@\u001c\u0019\u001e]\u0006K\u0016\u0004\u001b\u0000\r\r\u0005\u0017\u001e\u0006\u0000\r\u001a\u001b\u0002\u001fKa\u001c\u0019\u001e\u0016\u0004M%\u0017\u001e\u0006\u0000";
      m[2] = "\u0016\u000bN0\u0007\u0012\u0019K\u0003;\r\u000f\u001c\u0016\b}\u0005\u0012\u0011\u0010\f6F\u0014\u0018\u0015\f}\u0018\u0011\u0014\u001c\u0005!F伨传厮伵厘桹厶厾估伵";
      m[3] = "xA0+d\"Lb?k))F\u007f:6\"oNb70&$\r@<!?-F6";
      m[4] = "w:\n6Js|5\u001by6js/\u0015:\u0001Ze8\u0019'\u0010vr5";
      m[5] = "s1\u0014fl3s1\u0003:`<iz\u0017's6yz\u0005&u3i-N\ro.t \u0019";
      m[6] = double.class;
      n[6] = "java/lang/Double";
      m[7] = int.class;
      n[7] = "java/lang/Integer";
      m[8] = "\u001an,&\u0015\u0000\u001an;z\u0019\u000f\u0000%/g\n\u0005\u0010%=f\f\u0000\u0000rvx\u0014\b\rn*&1\u0007\u0002n6|\u0017\u001b\r";
      m[9] = "x\u0000S=v8w@\u001e6|%r\u001d\u0015pt8\u007f\u001b\u0011;7>v\u001e\u0011pi;z\u0017\u0018,7厜低伻伨厕佌伂低厥厶z栈伂栊桿厶伋佌框叐伻";
      m[10] = boolean.class;
      n[10] = "java/lang/Boolean";
      m[11] = "$S\u001e}nh+\u0013Svdu.NX0lh#H\\{/n*M\\0qk&DUl/双伒佨佥叕佔佒伒叶叻:佔佒桖佨叻叕佔双厌叶";
      m[12] = "a%";
      m[13] = "\u001bXi/,\u0017\u0014\u0018$$&\n\u0011E/b.\u0017\u001cC+)m\u0011\u0015F+b3\u0014\u0019O\">m厳伭佣伒厇伖伭伭叽厌h桒厳伭栧伒伙伖桩桩栧";
      m[14] = "\u000bu&\u0018/\b\u000bu1D#\u0007\u0011>%Y0\r\u0001>\"^;\u0012KF7Uq";
      m[15] = "Cp\u0012!I\u0006]x\bn*\u0012Y";
      m[16] = "Z\f+!}\u0016ULf*w\u000bP\u0011mld\u0018U\u0017`l{\u0014I\u000e+\fg\u0014[\u0007w\u0014s\u0015L\u0007";
      m[17] = long.class;
      n[17] = "java/lang/Long";
      m[18] = " \u00145d\u007fP \u0014\"8s_:_6%`U*_\b$f\\<\u0010\">{V 9 $v";
      m[19] = "_$\u0019I:u_$\u000e\u00156zEo\u000e\u000b>y_5C*>rT\"\u001f\u00061h";
      m[20] = "/D(z>\u001d/D?&2\u00125\u000f?8:\u0011/Ur9&\u00185H,82\r$Sr\u0019&\u00185H\f82\r$S\u001b5>\u0011\fN81";
      m[21] = "U<iTP(Z|$_Z5_!/\u0019J3_>4\u0019栮厌栧厙厌佢佪桖佣伇";
      m[22] = "_)'P2rPij[8oU4a\u001d(iU+z\u001d5xP7lAsOS3hG4rR";
      m[23] = "UzQBl>UzF\u001e`1O1R\u0003s;_1I\tw2W1f\u0000h'xpK\u0018d/O;g\u0000n4P";
      m[24] = "\u000ed\u0002N\u007f?\u000ed\u0015\u0012s0\u0014/\u0001\u000f`:\u0004/\u001a\u0005d3\f/5\f{&#n\u0018\u0014w.\u0014%0\fg?\u0004";
      m[25] = "0{^din0{I8ea*0]%vk:0Z\"}tpVC>Vb-kF> S'nO";
      m[26] = "\bo2K>4<L=\u000bs?6Q8Vxy>L5P|2}n>Ae;6\u0018";
      m[27] = void.class;
      n[27] = "java/lang/Void";
      m[28] = "\u0010\u0006\u0017\u007f+]\u001fFZt!@\u001a\u001bQ2)]\u0017\u001dUyj\u007f\u001c\fLp!";
      m[29] = "\u000f\b\u001eIf\u0006\u0000HSBl\u001b\u0005\u0015X\u0004d\u0006\b\u0013\\O'似伹厭佥使参似伹桷校";
      m[30] = "\u0014'u*Wu\u0014'bv[z\u000eloaNk\u00150j*Jn\u00156ngUpT%`i_2)'sr_n\u0018-tj^L\u0016#xaH]\u00196hkTL\u001b!jaN8;!umUr";
      m[31] = "xg\u000eH\u000e'sh\u001f\u0007o)xc\u001b]";
      m[32] = ">Kq\u0002hif\\i\r\u0017栜双核栍厥叔栜双佼佉f&ojEk\n~xrJ";
      m[33] = "XY|\u0011\u0002XNX-t伡栺佬栽叞桭桥栺佬叧\u001d\u001e\u001d\u0012\t\u001d \u0011\f\u001c^";
      m[34] = "-\u0019\u0003E.f;\u0018R 厓栄伙伹厡口桉佀桝伹b\u0019o|y\b\rB(-{";
      m[35] = "%5f\u007fDlp\u007fn,yO\u0000NE\u00199C\u000fC\u0003\"Cox2ew\tg+";
      m[36] = "\u0018r7\b)\u000e\u000esfm厔桬桨双厕桴厔伨桨双VTh\u0014Lc9\u000f/EN";
      m[37] = "\u0005\u007f$J[C\u0013~u/格叻伱栛历佲格叻伱叁E\u0016\u001aYQn*M]\bS";
      m[38] = ")|\u001d\u001ctiqk\u0005\u0013\u000b叆叛佋伥去佖叆栁佋伥x:o}r\u0007\u0014bxe}";
      m[39] = "g4(0&:?#0?Y厕伋伃厎伉伄厕桏桇伐Th<3:280++5";
      m[40] = "\u000bK\r&!0\u001dJ\\C伂厈厡叵伱伞厜厈桻栯l)>zZ\u000fQ&/t\r";
      m[41] = "ncj\f\u0014Zxb;i厩佼佚佃栒厪厩叢栞标\u000bVPK{y2\t\u0005Jv";
      m[42] = "&Ae09L0@4U厄叴桖栥叇桌厄栮厌叿\u0004lxVrPk7?\u0007p";
      m[43] = "\u001a\nM\u0018m J\u0014\u0010J\u0000;#\u0014NA|}_\u0016MXkD";
      m[44] = "\bD\u0003wW2\u001eER\u0012佴桐似佤桻住只桐似叺bx\u0013\"\u0001I\r/M)\u0006";
      m[45] = "Lwt\u0002;:K*oP\u0004伛召厊叞厫叇伛佲桐叞hgxF#\"\u0014`%]q";
      m[46] = "4BBY`h3I\u0013\u001eZH\u0010`6`Zb1\u0018\u0007\u00190e:I@";
      m[47] = "T\na@;PB\u000b0%优佶栤桮佝格桜栲叾桮\u0000O$\u001a\u0005N=@5\u0014R";
      m[48] = "q=k\u001f!,)*s\u0010^厃伝厔栗伦桇桙伝伊栗{o*%3q\u00177==<";
      m[49] = "d\u0010t\u000f7o\"\u0019pL[s\u000e[7\u0002d\"\u000e`6M`p7\u001cqX#!";
      m[50] = "%R!\u000fO3vX+\u00153佒但叶伛桩佮双栂佨伛p\u000fi*W)\u001c\b1dU";
      m[51] = "8}_V\u0015\u0012.|\u000e3伶桰案栙叽佮桲伴伌參>YQ\u00021pQ\u000e\u000f\t6";
      m[52] = "W_\\\u0019T?\u0010\u0003Q\u001a&7;\u0000\u0000X\u0017a;9\r\u0001\u0017;\u0003U\nYY9";
      m[53] = "$`A<y\u0010wjK&\u0005佱叙叄佻伞叆可叙栞佻C4F\u007fcY/lQgl";
      m[54] = "y\n\\(jo!\u001dD'\u0015栚伕伽叺休取栚压伽佤L$i-\u0004F |~5\u000b";
      m[55] = " U\u001aT>Ts_\u0010NB桱叝佯桤佶伟伵叝栫桤+}RtN\u001a\u0012\"\u0007uC";
      m[56] = "A'\tm0tE?^lK]#{Tv7y\u001a$\u0001w:\u001e";
      m[57] = "\u0007\u001ay?3K\u0011\u001b(Z桔佭桷厤佅厙厎佭桷桾\u00180,\u0001V^%?=\u000f\u0001";
      m[58] = "\u0015h\b\u0015'(\u0017k\r\nF=.!M@yi.\u0010\u0019B}n\u001cv\u0013\u0012;)";
      m[59] = "m\t\u0017$1L{\bFA厌佪叇厷桯厂桖栮叇桭vxpV9\u0018\u0019#7\u0007;";
      m[60] = "#\u0000r\u0001u!5\u0001#d佖桃桓厾叐伹佖桃厉传\u0013]4;w\u0011|\u0006sju";
      m[61] = "\u0017i)w)|\u0001hx\u0012厔叄桧受伕住伊栞桧佉H+hfCx'p/7A";
      m[62] = "j\u0013Z_@%|\u0012\u000b:佣伃栚伳栢佧栧桇佞伳;P\u00045c\u001eT\u0007Z>d";
      m[63] = "K_b)(Q]^3L桏栳使叡叀桕伋叩使叡\u0003&7\u001b\u001a\u001b>)&\u0015M";
      m[64] = "\u0004\\\r2Tz\u0012]\\W栳作桴叢伱厔佷作桴叢l=\u0010j\rQ\u0003jNa\n";
      m[65] = "-\u0001^IZF;\u0000\u000f,栽叾桝桥栦佱佹你伙伡?\u0015\u001b\\y\u0010PN\\\r{";
      m[66] = "\u0001\t>i4\u001bY\u001e&fK厴栩厠桂収桒伪右厠桂\rz\u001dU\u0007$a\"\nM\b";
      m[67] = "\u007fN&)Y3/P{{4桎厅史历栉栭伊桟史优\u0010\r(%\b(t]6xZ";
      m[68] = "\rg|x)G\u001bf-\u001d厔佡伹佇叞栄厔佡桽叙\u001dvh\u0004\b&{y6BZ";
      m[69] = "\u00197EP1\u0016\u000f6\u00145伒桴伭众佹叶厌估厳众$\nu\u0007\f-\u001dU \u0006\u0001";
      m[70] = "d\fy\n,\fr\r(o伏厴佐厲佅伲桋伪収伬\u0018Ph\u001dq\u0016!\u000f=\u001c|";
      m[71] = "\u0018[W7b\u0018\u000eZ\u0006R叟桺厲栿佫厑佁伾桨句6nbX\u001cHJ)w\u001bM";
      m[72] = "8C%I\u001dEf\u0001 \u000eau\u00109\u0003u-s\r}(\n\u0003C+\u0006vH\u0006\u0004";
      m[73] = "AL$(f\u0012\u0019[<'\u0019伣伭栿伜厏佄桧桩句厂L(\u0014\u0015B> p\u0003\rM";
      m[74] = "\u001a\u0012l\u007fPG\f\u0013=\u001a样栥伮伲佐栃叭栥伮桶\rq\u0011\u0004\u001fSk~OBM";
      m[75] = "\u00141I<\u0012T\u00020\u0018Y伱召桤休併桀厯佲传休(7TD\u00041R!VBC";
      m[76] = "\u007fbaF\u0007g{\"bC8uAk*B\b\"A[,\u0018\tyy7+@G{";
      m[77] = "\u0011yI\u0018Yz\u0007x\u0018}佺参去叇叫桤古栘去余(AY:\u0015jT\u0006LyD";
      m[78] = "]9%\u0015\u001a6Yy&\u0010%$c0n\u0011\u001a{c\u0000hK\u0014([lo\u0013Z*";
      m[79] = "6_<)q\bnH$&\u000e桽叄佨桀桔体伹叄叶厚M?\u000ebQ&!g\u0019z^";
      m[80] = "nU]\u00026DxT\fg伕佢栞叫栥桾桑佢佚併<\r)\u000e?\u0011\u0001\u00028\u0000h";
      m[81] = "\u0011?\nCEjVc\u0007@7b}`V\u0002\u00066}Y[[\u0006nE5\\\u0003Hl";
      m[82] = "\u0001\u0006s^*&\u0017\u0007\";伉伀伵桢栋司伉桄桱伦\u0012Pke\u0004Gt_5#V";
      m[83] = "~\u0007%G}S.\u0019x\u0015\u0010gG\u0019&\u001el\u000e;\u001b%\u0007{7%Av\u0011+H,\u0004 B\u0010";
      m[84] = "}yp\u001df\u0003.sz\u0007\u001a栦伞标叔桻佇栦厀佃叔bs\u00062&(\u001ewF1#";
      m[85] = "h\u000b/\"mOgKs'\u000fdW2\u0016\u001fXsF \u0010\u0019Hn\\1\b\u0004D|\u000b\u0018< n]{\u0017||k";
      m[86] = "\u000b\u0010\u0014AmK\u001d\u0011E$叐佭厡估伨栽叐栩伿桴u\u001d,Q_\u0001\u001aFk\u0000]";
      m[87] = "m&N'10{'\u001fB厌桒叇桂召伟厌厈余桂/,w }&U:u&:";
      m[88] = "\u0013kB{\u00175\u000ep[(&\u0015;Pl\u0014I.\u001fy\u0010rT5\u0006*";
      m[89] = "\u00042o\u0012,m\u00123>w桋栏桴厌反伪伏叕桴伒\u000eNmwP#a\u0015*&R";
      m[90] = "I&\u0003lK\u0012\u001a,\tv7佳伪桘桽低叴佳厴厂伹\u0013\u000bHF#\u000b\u007f\f\u0010\b!";
      m[91] = "] c?ihK!2Z佊栊佩厞佟桃栎低栭桄\u00020-xT-mgssS";
      m[92] = "\f\u0004.\u0015\u0011\u001dKX#\u0016c\u0015`[rTRB`b\u007f\rR\u0019X\u000exU\u001c\u001b";
      m[93] = "\u0016o\u0010`\n\u001d\u0000nA\u0005\u001dfD*\u001fc\u001f\u001d\u0000*\u0017it]G|\u0017n\u000f\u0019Gt\u001d\u0005";
      m[94] = "\u001d\u0018Ualy\u0019XVdSk#\u0011\u001eec=#!\u0018?bg\u001bM\u001fg,e";
      m[95] = "\u0004:^\u0003L\u001b\u00051R_s桤佩栘佯栫伮厾佩作佯2C\u0007F`\fR\u0012F\u000fb";
      m[96] = "\u0014Z\u0015,u|A\u0010\u001d\u007fH]6.']\u0001\\4`\u001c'-+E\u0006Im%x";
      m[97] = "S\u00014S\rCE\u0000e6厰叻栣桥桌栯桪佥佧桥UX\u0011WS\u000e)\u000bBQ_";
      m[98] = "\u0014V\u0014r\u007f~\u0002WE\u0017作佘厾叨厶叔参佘厾栲u.>d@G\u001auy5B";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private boolean a(Vec3 targetPos, double ticks) {
      long a = 友何何何友何何何友友.a ^ 39687409060595L;
      long ax = a ^ 1554825752099L;
      long axx = a ^ 17113380290243L;
      d<"g">(-2953862711407948036L, a);
      if (this.w(new Object[]{ax})) {
         return true;
      } else {
         List<Vec3> trajectoryPoints = this.e(targetPos, ticks);
         int i = 0;
         if (0 < trajectoryPoints.size() - 1) {
            Vec3 current = trajectoryPoints.get(0);
            Vec3 next = trajectoryPoints.get(1);
            BlockHitResult result = mc.level.clip(new ClipContext(current, next, d<"Õ">(-2947289727976843033L, a), d<"Õ">(-2946159943979480734L, a), null));
            if (result.getType() == d<"Õ">(-2954199503566590939L, a) && 0 < trajectoryPoints.size() - 2) {
               BlockPos blockPos = result.getBlockPos();
               BlockState blockState = mc.level.getBlockState(blockPos);
               if (!blockState.isAir() && !blockState.getCollisionShape(mc.level, blockPos).isEmpty()) {
                  if (d<"¥">(this, -2953912220948680726L, a).getValue()) {
                     ClientUtils.e(
                        new Object[]{
                           String.format(b<"i">(9070, 18814116593680796L ^ a), blockPos.getX(), blockPos.getY(), blockPos.getZ(), 0, trajectoryPoints.size()),
                           axx
                        }
                     );
                  }

                  return true;
               }
            }

            i++;
         }

         return false;
      }
   }

   private Vec3 m(Entity target, double ticks) {
      long a = 友何何何友何何何友友.a ^ 103341056001421L;
      d<"g">(-7458035306726063742L, a);
      Vec3 basePosition = this.P(target, ticks);
      if (basePosition == null) {
         return null;
      } else {
         List<Vec3> posHistory = (List<Vec3>)d<"¥">(this, -7465952152995035710L, a).get(target.getId());
         List<Vec3> motionHistory = (List<Vec3>)d<"¥">(this, -7459748141050752667L, a).get(target.getId());
         if (posHistory != null && posHistory.size() >= 2 && motionHistory != null && motionHistory.size() >= 2) {
            Vec3 latestMotion = motionHistory.get(motionHistory.size() - 1);
            Vec3 prevMotion = motionHistory.get(motionHistory.size() - 2);
            double motionChange = Math.sqrt(
               Math.pow(d<"¥">(latestMotion, -7465037077365720925L, a) - d<"¥">(prevMotion, -7465037077365720925L, a), 2.0)
                  + Math.pow(d<"¥">(latestMotion, -7465169742281475887L, a) - d<"¥">(prevMotion, -7465169742281475887L, a), 2.0)
            );
            if (motionChange > 0.05) {
               double currentSpeed = Math.sqrt(
                  d<"¥">(latestMotion, -7465037077365720925L, a) * d<"¥">(latestMotion, -7465037077365720925L, a)
                     + d<"¥">(latestMotion, -7465169742281475887L, a) * d<"¥">(latestMotion, -7465169742281475887L, a)
               );
               double moveAngle = Math.atan2(d<"¥">(latestMotion, -7465169742281475887L, a), d<"¥">(latestMotion, -7465037077365720925L, a));
               double extraDistance = currentSpeed * ticks * 0.3;
               double newX = d<"¥">(basePosition, -7465037077365720925L, a) + Math.cos(moveAngle) * extraDistance;
               double newZ = d<"¥">(basePosition, -7465169742281475887L, a) + Math.sin(moveAngle) * extraDistance;
               return new Vec3(newX, d<"¥">(basePosition, -7466164060110647241L, a), newZ);
            } else {
               return basePosition;
            }
         } else {
            return basePosition;
         }
      }
   }

   private double k(double targetY, double time, double gravity, double airResistance) {
      long a = 友何何何友何何何友友.a ^ 51075219580358L;
      d<"g">(8661776579535004105L, a);
      double minVy = -10.0;
      int iter = 0;
      double y = 0.0;
      if (0.0 < time) {
         y = 0.0;
      }

      if (y < targetY) {
         minVy = 0.0;
      }

      iter++;
      return (minVy + 0.0) / 2.0;
   }

   private void k(Entity entity) {
      long a = 友何何何友何何何友友.a ^ 6619183660776L;
      d<"g">(-6693783226235897113L, a);
      if (entity != null) {
         int entityId = entity.getId();
         Vec3 currentPosition = new Vec3(entity.getX(), entity.getY(), entity.getZ());
         Vec3 currentMotion = new Vec3(
            entity.getX() - d<"¥">(entity, -6693190449584669361L, a),
            entity.getY() - d<"¥">(entity, -6699374279736266053L, a),
            entity.getZ() - d<"¥">(entity, -6700137669862144098L, a)
         );
         List<Vec3> positionHistory = d<"¥">(this, -6699447581751951705L, a).getOrDefault(entityId, new ArrayList<>());
         positionHistory.add(currentPosition);
         if (positionHistory.size() > 8) {
            positionHistory.remove(0);
         }

         d<"¥">(this, -6699447581751951705L, a).put(entityId, positionHistory);
         List<Vec3> motionHistory = d<"¥">(this, -6693196292959360512L, a).getOrDefault(entityId, new ArrayList<>());
         motionHistory.add(currentMotion);
         if (motionHistory.size() > 8) {
            motionHistory.remove(0);
         }

         d<"¥">(this, -6693196292959360512L, a).put(entityId, motionHistory);
         double currentSpeed = Math.sqrt(
            d<"¥">(currentMotion, -6700362640536452154L, a) * d<"¥">(currentMotion, -6700362640536452154L, a)
               + d<"¥">(currentMotion, -6700449894757743692L, a) * d<"¥">(currentMotion, -6700449894757743692L, a)
         );
         List<Double> speedHistory = d<"¥">(this, -6701345514869404079L, a).getOrDefault(entityId, new ArrayList<>());
         speedHistory.add(currentSpeed);
         if (speedHistory.size() > 8) {
            speedHistory.remove(0);
         }

         d<"¥">(this, -6701345514869404079L, a).put(entityId, speedHistory);
         d<"¥">(this, -6692449736334816541L, a).put(entityId, entity.onGround());
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 友何何何友何何何友友.a ^ 87266846182381L;
      long ax = a ^ 97152478078338L;
      d<"¥">(this, -7637957366347967467L, a).U(ax);
      d<"¥">(this, -7635993859077740204L, a).U(ax);
      d<"s">(this, null, -7634382259456223712L, a);
      d<"s">(this, 0, -7636397341799488560L, a);
      d<"s">(this, false, -7636762603206974694L, a);
      d<"s">(this, false, -7629378252995779399L, a);
      d<"s">(this, false, -7636930643872138903L, a);
      d<"s">(this, -1, -7636793646754345831L, a);
      d<"¥">(this, -7637103655835268190L, a).clear();
      d<"¥">(this, -7630869957072707835L, a).clear();
      d<"¥">(this, -7630525798015664154L, a).clear();
      d<"¥">(this, -7636626566486394028L, a).clear();
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void w() {
      long a = 友何何何友何何何友友.a ^ 97329097660753L;
      d<"g">(4946000358055894366L, a);
      if (mc.level != null) {
         Iterator var4 = mc.level.entitiesForRendering().iterator();
         if (var4.hasNext()) {
            Entity entity = (Entity)var4.next();
            if (entity instanceof Player && entity != mc.player) {
               this.k(entity);
            }
         }
      }
   }

   private double A(Entity target) {
      long a = 友何何何友何何何友友.a ^ 26960537555859L;
      long ax = a ^ 68132383160131L;
      long axx = a ^ 56134289008547L;
      d<"g">(1036383300541290396L, a);
      if (this.w(new Object[]{ax})) {
         return 0.0;
      } else {
         友何何何友何何何友友.树何树树友何何树友何 pattern = this.L(target.getId());
         double offsetX = target.getX() - mc.player.getX();
         double offsetZ = target.getZ() - mc.player.getZ();
         double horizontalDist = Math.sqrt(offsetX * offsetX + offsetZ * offsetZ);
         double baseFlightTime = horizontalDist / 1.5;
         double targetMotionX = target.getX() - d<"¥">(target, 1037547823700332596L, a);
         double targetMotionZ = target.getZ() - d<"¥">(target, 1044635869395544805L, a);
         double targetSpeed = Math.sqrt(targetMotionX * targetMotionX + targetMotionZ * targetMotionZ);
         double targetAngle = Math.atan2(targetMotionZ, targetMotionX);
         double throwAngle = Math.atan2(offsetZ, offsetX);
         double angleDiff = Math.abs(targetAngle - throwAngle);
         if (angleDiff > Math.PI) {
            angleDiff = (Math.PI * 2) - angleDiff;
         }

         double targetSpeedAlongThrow = targetSpeed * Math.cos(angleDiff);
         if (Math.abs(angleDiff) < Math.PI / 2) {
         }

         if (Math.abs(angleDiff) > Math.PI * 3.0 / 4.0) {
            double var10000 = 1.4 + Math.min(targetSpeed * 2.0, 0.8);
         }

         double distanceFactor = Math.min(1.0 + horizontalDist / 20.0 * 0.5, 1.8);
         double speedAdjustedTime = baseFlightTime * (1.0 + targetSpeedAlongThrow * 0.8);
         double adjustedTime = speedAdjustedTime * 1.15 * distanceFactor;
         adjustedTime = this.M(adjustedTime, pattern, targetSpeed, horizontalDist);
         double bestHitTime = adjustedTime;
         double minError = Double.MAX_VALUE;
         double searchRadius = Math.max(adjustedTime * 0.25, 5.0);
         double searchStep = Math.max(adjustedTime * 0.05, 0.5);
         double timeGuess = adjustedTime - searchRadius;
         if (timeGuess <= adjustedTime + searchRadius) {
            if (!(timeGuess <= 0.0)) {
               double error = this.I(target, timeGuess, 1.5, 0.99, 0.03);
               if (error < Double.MAX_VALUE) {
                  minError = error;
                  bestHitTime = timeGuess;
               }
            }

            double var66 = timeGuess + searchStep;
         }

         timeGuess = searchStep * 2.0;
         double refinedStep = searchStep / 4.0;
         double timeGuessx = bestHitTime - timeGuess;
         if (timeGuessx <= bestHitTime + timeGuess) {
            if (!(timeGuessx <= 0.0)) {
               double error = this.I(target, timeGuessx, 1.5, 0.99, 0.03);
               if (error < minError) {
                  bestHitTime = timeGuessx;
               }
            }

            double var67 = timeGuessx + refinedStep;
         }

         timeGuessx = bestHitTime * 1.05;
         if (d<"¥">(this, 1036290675546781322L, a).getValue()) {
            ClientUtils.e(
               new Object[]{
                  String.format(b<"i">(30323, 5064206986664562149L ^ a), targetSpeed * 20.0, angleDiff * 180.0 / Math.PI, 1.15 * distanceFactor, timeGuessx),
                  axx
               }
            );
         }

         return Math.max(timeGuessx, 1.0);
      }
   }

   private void Y() {
      long a = 友何何何友何何何友友.a ^ 58386351501015L;
      long ax = a ^ 18040246815239L;
      d<"g">(3685585524666870488L, a);
      if (!this.w(new Object[]{ax})) {
         if (d<"¥">(this, 3692620636265179555L, a) != -1) {
            if (d<"¥">(this, 3685654583042128415L, a).getValue()) {
               mc.getConnection().send(new ServerboundSetCarriedItemPacket(d<"¥">(this, 3692620636265179555L, a)));
            }

            d<"s">(mc.player.getInventory(), d<"¥">(this, 3692620636265179555L, a), 3684914240763383442L, a);
            d<"s">(this, -1, 3692620636265179555L, a);
         }
      }
   }

   private 友何何何友何何何友友.树何树树友何何树友何 L(int entityId) {
      long a = 友何何何友何何何友友.a ^ 105160000978874L;
      d<"g">(2470433576259828661L, a);
      List motionHistory = d<"¥">(this, 2472094451697560402L, a).getOrDefault(entityId, new ArrayList());
      List<Double> speedHistory = d<"¥">(this, 2473127532377591555L, a).getOrDefault(entityId, new ArrayList<>());
      List<Vec3> positionHistory = d<"¥">(this, 2473776136883322869L, a).getOrDefault(entityId, new ArrayList<>());
      if (motionHistory.size() >= 3 && speedHistory.size() >= 3 && !positionHistory.isEmpty()) {
         Vec3 currentMotion = (Vec3)motionHistory.get(motionHistory.size() - 1);
         Vec3 prevMotion = (Vec3)motionHistory.get(motionHistory.size() - 2);
         double currentSpeed = speedHistory.get(speedHistory.size() - 1);
         double prevSpeed = speedHistory.get(speedHistory.size() - 2);
         double prevPrevSpeed = speedHistory.get(speedHistory.size() - 3);
         boolean isInAir = !d<"¥">(this, 2471910827843439537L, a).getOrDefault(entityId, true);
         double currentAngle = Math.atan2(d<"¥">(currentMotion, 2472865368406672102L, a), d<"¥">(currentMotion, 2473001817518195348L, a));
         double prevAngle = Math.atan2(d<"¥">(prevMotion, 2472865368406672102L, a), d<"¥">(prevMotion, 2473001817518195348L, a));
         double angleDiff = Math.abs(currentAngle - prevAngle);
         if (angleDiff > Math.PI) {
            angleDiff = (Math.PI * 2) - angleDiff;
         }

         double acceleration = currentSpeed - prevSpeed;
         double prevAcceleration = prevSpeed - prevPrevSpeed;
         if (angleDiff > 0.3) {
            d<"Õ">(2470858814238820085L, a);
         }

         if (acceleration > 0.01 && prevAcceleration > 0.0) {
            d<"Õ">(2471222412227006245L, a);
         }

         if (acceleration < -0.01 && prevAcceleration < 0.0) {
            d<"Õ">(2472490071030017986L, a);
         }

         if (Math.abs(acceleration) < 0.01) {
            d<"Õ">(2472462510220262633L, a);
         }

         if (acceleration > 0.01 && prevAcceleration <= 0.0) {
            d<"Õ">(2473280931118554742L, a);
         }

         if (acceleration < -0.01 && prevAcceleration >= 0.0) {
            d<"Õ">(2472913459556674886L, a);
         }

         友何何何友何何何友友.树友何树何何何树树树 type = d<"Õ">(2471994961575188121L, a);
         double turnTrend = angleDiff > 0.1 ? currentAngle - prevAngle : 0.0;
         if (turnTrend > Math.PI) {
            turnTrend -= Math.PI * 2;
         }

         if (turnTrend < -Math.PI) {
            turnTrend += Math.PI * 2;
         }

         Vec3 lastPosition = positionHistory.get(positionHistory.size() - 1);
         return new 友何何何友何何何友友.树何树树友何何树友何(type, currentAngle, turnTrend, isInAir, lastPosition);
      } else {
         return new 友何何何友何何何友友.树何树树友何何树友何(
            d<"Õ">(2471325182889439731L, a),
            0.0,
            0.0,
            false,
            positionHistory.isEmpty() ? new Vec3(0.0, 0.0, 0.0) : positionHistory.get(positionHistory.size() - 1)
         );
      }
   }

   private double M(double time, 友何何何友何何何友友.树何树树友何何树友何 pattern, double targetSpeed, double distance) {
      long a = 友何何何友何何何友友.a ^ 9889205323576L;
      long ax = a ^ 50083373474792L;
      d<"g">(-7292760025226247369L, a);
      if (this.w(new Object[]{ax})) {
         return time;
      } else {
         double adjustFactor = 1.0;
         switch (d<"Õ">(-7289118372114394291L, a)[d<"¥">(pattern, -7292032108594621463L, a).ordinal()]) {
            case 1:
               double var10000 = 1.5 + Math.min(targetSpeed * 4.0, 0.6);
            case 2:
            case 3:
            case 4:
            case 5:
               double turnFactor = 1.05;
               double targetToPlayerAngle = Math.atan2(
                  mc.player.getZ() - d<"¥">(d<"¥">(pattern, -7289875768703745387L, a), -7290423269634835868L, a),
                  mc.player.getX() - d<"¥">(d<"¥">(pattern, -7289875768703745387L, a), -7290332368986703338L, a)
               );
               double turnRelativeToPlayer = Math.cos(targetToPlayerAngle - d<"¥">(pattern, -7289478108680396006L, a));
               if (turnRelativeToPlayer > 0.3) {
                  turnFactor = 0.9;
               }

               if (turnRelativeToPlayer < -0.3) {
                  turnFactor = 1.3;
               }

               adjustFactor = turnFactor;
            case 6:
               if (!(targetSpeed > 0.15)) {
                  break;
               }

               double var21 = 1.0 + Math.min(distance / 15.0, 0.5);
            default:
               adjustFactor = 1.05;
         }

         return time * adjustFactor;
      }
   }

   private Vec3 P(Entity target, double ticks) {
      long a = 友何何何友何何何友友.a ^ 66596624260272L;
      d<"g">(4702563997802256575L, a);
      if (mc.level == null) {
         return null;
      } else {
         this.k(target);
         友何何何友何何何友友.树何树树友何何树友何 pattern = this.L(target.getId());
         double motionX = target.getX() - d<"¥">(target, 4703227143667130135L, a);
         double motionY = target.getY() - d<"¥">(target, 4710536523703423203L, a);
         double motionZ = target.getZ() - d<"¥">(target, 4709761207325795782L, a);
         double predictedX = target.getX();
         double predictedY = target.getY();
         double predictedZ = target.getZ();
         boolean onGround = target.onGround();
         double turnMultiplier = 0.0;

         double speedMultiplier = switch (d<"Õ">(4710744435454560453L, a)[d<"¥">(pattern, 4703247856256567393L, a).ordinal()]) {
            case 1 -> 1.05 + Math.min(ticks * 0.01, 0.15);
            case 2 -> 1.03 + Math.min(ticks * 0.008, 0.12);
            case 3 -> 0.97 - Math.min(ticks * 0.01, 0.15);
            case 4 -> 0.98 - Math.min(ticks * 0.008, 0.12);
            case 5 -> {
               turnMultiplier = d<"¥">(pattern, 4703072221575209691L, a) * 0.8;
               yield 0.95;
            }
            default -> 1.0;
         };
         motionX *= speedMultiplier;
         motionZ *= speedMultiplier;
         if (Math.abs(turnMultiplier) > 0.01) {
            double currentAngle = d<"¥">(pattern, 4710384947526744210L, a);
            double speed = Math.sqrt(motionX * motionX + motionZ * motionZ);
            double newAngle = currentAngle + turnMultiplier;
            motionX = Math.cos(newAngle) * speed;
            motionZ = Math.sin(newAngle) * speed;
         }

         if (d<"¥">(pattern, 4703405102318187721L, a)) {
            motionY = Math.max(motionY - 0.08, -3.92);
         }

         int i = 0;
         if (0.0 < Math.min(ticks, 20.0)) {
            motionX *= 0.91;
            motionZ *= 0.91;
            if (onGround) {
               if (Math.abs(motionY) < 0.005) {
                  motionY = 0.0;
               }

               motionY *= 0.98;
            }

            motionY = (motionY - 0.08) * 0.98;
            if (motionY < -3.92) {
               motionY = -3.92;
            }

            predictedX += motionX;
            predictedY += motionY;
            predictedZ += motionZ;
            if (predictedY <= target.getY() && Math.abs(motionY) < 0.005) {
               predictedY = target.getY();
            }

            if (motionY < 0.0) {
               BlockPos pos = new BlockPos((int)predictedX, (int)(predictedY - 0.2), (int)predictedZ);
               if (!mc.level.isEmptyBlock(pos)) {
                  predictedY = Math.floor(predictedY) + 1.0;
               }
            }

            i++;
         }

         return new Vec3(predictedX, predictedY + target.getEyeHeight(), predictedZ);
      }
   }

   @EventTarget
   public void W(LivingUpdateEvent event) {
      long a = 友何何何友何何何友友.a ^ 79854808231739L;
      long ax = a ^ 120752305540075L;
      long axx = a ^ 115264638486920L;
      long axxx = a ^ 58512738672047L;
      long axxxx = a ^ 122859863928374L;
      long axxxxx = a ^ 73899064432313L;
      long axxxxxx = a ^ 105152926548308L;
      long axxxxxxx = a ^ 7161436323196L;
      long axxxxxxxx = a ^ 109024798497547L;
      long axxxxxxxxx = a ^ 88392056603605L;
      d<"g">(-952043773333804236L, a);
      if (!this.w(new Object[]{ax})
         && (Boolean)Fucker.isLogin
         && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)
         && (d<"Õ">(-949234886119518371L, a) == null || !d<"Õ">(-949234886119518371L, a).isEnabled() || !d<"¥">(this, -949364627711679371L, a).getValue())) {
         long currentTime = System.currentTimeMillis();
         if (d<"¥">(this, -949482023142553652L, a)
            && currentTime - d<"¥">(this, -949751511658520790L, a) > d<"¥">(this, -951657495474127087L, a).getValue().longValue()) {
            d<"s">(this, false, -949482023142553652L, a);
         }

         if (d<"¥">(this, -952222044718841745L, a)
            && currentTime - d<"¥">(this, -949577983154648047L, a) > d<"¥">(this, -951657495474127087L, a).getValue().longValue()) {
            d<"s">(this, false, -952222044718841745L, a);
         }

         if (d<"¥">(this, -946948192651559330L, a).getValue() && d<"¥">(this, -949482023142553652L, a)) {
            if (d<"¥">(this, -951960721007441374L, a).getValue()) {
               ClientUtils.e(new Object[]{b<"i">(22232, 6445652590948815335L ^ a), axxxxxxxx});
            }
         } else if (d<"¥">(this, -948311522336592234L, a).getValue() && d<"¥">(this, -952222044718841745L, a)) {
            if (d<"¥">(this, -951960721007441374L, a).getValue()) {
               ClientUtils.e(new Object[]{b<"i">(3035, 8966888246052506878L ^ a), axxxxxxxx});
            }
         } else {
            this.w();
            if (d<"¥">(this, -947094893342936330L, a) != null) {
               RotationUtils.D(new Object[]{axxx, d<"¥">(this, -947094893342936330L, a)});
            }

            if (d<"¥">(this, -949648242745745985L, a) && currentTime >= d<"¥">(this, -948039556853320506L, a)) {
               if (d<"¥">(this, -951960721007441374L, a).getValue()) {
                  ClientUtils.e(new Object[]{b<"i">(27664, 1980082076758551299L ^ a), axxxxxxxx});
               }

               this.Y();
               if (mc.player.getOffhandItem().getItem() instanceof FishingRodItem) {
                  d<"¥">(mc, -950823423840302148L, a).useItem(mc.player, d<"Õ">(-947028246559338738L, a));
               }

               d<"s">(this, false, -949648242745745985L, a);
               d<"s">(this, 0, -950234312225487098L, a);
               d<"s">(this, null, -947094893342936330L, a);
            } else if (!d<"¥">(this, -949648242745745985L, a)) {
               Map<ThrowableItemProjectile, Long> shouldAdd = new HashMap<>();
               Iterator throwableSlot = mc.level.entitiesForRendering().iterator();
               if (throwableSlot.hasNext()) {
                  Entity entity = (Entity)throwableSlot.next();
                  if (entity instanceof ThrowableItemProjectile snowball) {
                     if (d<"¥">(this, -952392895838819044L, a).containsKey(snowball)) {
                        shouldAdd.put(snowball, (Long)d<"¥">(this, -952392895838819044L, a).get(snowball));
                     }

                     shouldAdd.put(snowball, System.currentTimeMillis());
                  }
               }

               throwableSlot = d<"¥">(this, -952392895838819044L, a).keySet().iterator();
               if (throwableSlot.hasNext()) {
                  ThrowableItemProjectile snowball = (ThrowableItemProjectile)throwableSlot.next();
                  if (!shouldAdd.containsKey(snowball) && d<"¥">(this, -951960721007441374L, a).getValue()) {
                     ClientUtils.e(
                        new Object[]{
                           String.format(
                              b<"i">(27794, 8551068715991870357L ^ a),
                              snowball.getId(),
                              System.currentTimeMillis() - (Long)d<"¥">(this, -952392895838819044L, a).get(snowball)
                           ),
                           axxxxxxxx
                        }
                     );
                  }
               }

               d<"s">(this, shouldAdd, -952392895838819044L, a);
               if (d<"¥">(this, -950234312225487098L, a) == 1) {
                  int throwableSlotx = this.s();
                  if (throwableSlotx == -1) {
                     d<"s">(this, 0, -950234312225487098L, a);
                     return;
                  }

                  if (throwableSlotx == -2) {
                     d<"s">(this, -1, -949503757352490929L, a);
                     ItemStack offhandStack = mc.player.getOffhandItem();
                     boolean var10000 = offhandStack.getItem() instanceof FishingRodItem;
                  }

                  d<"s">(this, d<"¥">(mc.player.getInventory(), -950527523161305218L, a), -949503757352490929L, a);
                  if (d<"¥">(this, -951826418327356429L, a).getValue() && mc.getConnection() != null) {
                     mc.getConnection().send(new ServerboundSetCarriedItemPacket(throwableSlotx));
                  }

                  d<"s">(mc.player.getInventory(), throwableSlotx, -950527523161305218L, a);
                  ItemStack mainHandStack = mc.player.getInventory().getItem(throwableSlotx);
                  boolean isFishingRod = mainHandStack.getItem() instanceof FishingRodItem;
                  d<"¥">(mc, -950823423840302148L, a).useItem(mc.player, d<"Õ">(-947028246559338738L, a));
                  if (isFishingRod) {
                     d<"s">(this, true, -949648242745745985L, a);
                     if (d<"¥">(this, -951960721007441374L, a).getValue()) {
                        ClientUtils.e(
                           new Object[]{
                              String.format(b<"i">(10095, 4951939833383510103L ^ a), d<"¥">(this, -948039556853320506L, a), System.currentTimeMillis()),
                              axxxxxxxx
                           }
                        );
                     }

                     d<"s">(this, 0, -950234312225487098L, a);
                     d<"s">(this, null, -947094893342936330L, a);
                  }

                  d<"s">(this, c<"m">(7529, 2141025674018574335L ^ a), -950234312225487098L, a);
               } else {
                  if (d<"¥">(this, -950234312225487098L, a) == 2) {
                     this.Y();
                     d<"s">(this, 0, -950234312225487098L, a);
                     d<"s">(this, null, -947094893342936330L, a);
                  }

                  if (!d<"¥">(this, -948428005831331645L, a).Y(d<"¥">(this, -951194289726255872L, a).getValue().intValue(), axxxx)) {
                     return;
                  }

                  int throwableSlotxx = this.s();
                  if (throwableSlotxx == -1) {
                     return;
                  }

                  if (throwableSlotxx == -2) {
                     boolean var55 = mc.player.getOffhandItem().getItem() instanceof FishingRodItem;
                  }

                  boolean var44 = mc.player.getInventory().getItem(throwableSlotxx).getItem() instanceof FishingRodItem;
                  Entity targetEntity = null;
                  Vec3 targetPos = null;
                  double finalTick = 0.0;
                  boolean isCrystalTarget = false;
                  List<LivingEntity> entityList = Cherish.instance
                     .S()
                     .e(axxxxx, d<"¥">(this, -952370471135905885L, a).getValue().floatValue())
                     .filter(entity -> {
                        long axxxxxxxxxx = 友何何何友何何何友友.a ^ 33646716980065L;
                        long axxxxxxxxxxx = axxxxxxxxxx ^ 5158720366897L;
                        return RotationUtils.r(axxxxxxxxxxx, d<"¥">(this, -7595495101124334221L, axxxxxxxxxx).getValue().floatValue(), entity);
                     })
                     .toList();
                  if (!entityList.isEmpty() && entityList.get(0) instanceof Player) {
                     targetEntity = (Entity)entityList.get(0);
                     double tick = (float)this.A(targetEntity);
                     PlayerInfo playerInfo = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                     if (playerInfo == null) {
                        return;
                     }

                     playerInfo.getLatency();
                     finalTick = tick + 2.0 + d<"¥">(this, -948180975680830425L, a).getValue().doubleValue();
                     targetPos = this.P(targetEntity, finalTick);
                     if (targetPos == null) {
                        targetEntity = null;
                     }
                  }

                  if (d<"¥">(this, -950955818805820902L, a).getValue()
                     && !var44
                     && (targetEntity == null || d<"¥">(this, -948786180222094588L, a).getValue() && targetEntity != null)) {
                     List<Entity> crystals = this.I(d<"¥">(this, -952120756997984077L, a).getValue().doubleValue());
                     if (!crystals.isEmpty()) {
                        Entity crystal = crystals.get(0);
                        if (targetEntity != null && d<"¥">(this, -948786180222094588L, a).getValue()) {
                           double playerDist = mc.player.distanceTo(targetEntity);
                           double crystalDist = mc.player.distanceTo(crystal);
                           if (crystalDist < playerDist * 0.7) {
                           }
                        }

                        targetEntity = crystal;
                        isCrystalTarget = true;
                        double distance = mc.player.distanceTo(crystal);
                        finalTick = Math.max(5.0, distance * 0.8);
                        targetPos = new Vec3(crystal.getX(), crystal.getY() + 0.5, crystal.getZ());
                        if (d<"¥">(this, -951960721007441374L, a).getValue()) {
                           ClientUtils.e(
                              new Object[]{
                                 String.format(
                                    b<"i">(5843, 6797274446608224759L ^ a),
                                    d<"¥">(targetPos, -950038484307176939L, a),
                                    d<"¥">(targetPos, -948907104595051903L, a),
                                    d<"¥">(targetPos, -950128715046317465L, a),
                                    distance,
                                    finalTick
                                 ),
                                 axxxxxxxx
                              }
                           );
                        }
                     }
                  }

                  if (targetEntity == null || targetPos == null) {
                     return;
                  }

                  d<"¥">(this, -948428005831331645L, a).U(axxxxxx);
                  d<"s">(this, (long)(System.currentTimeMillis() + finalTick * 60.0), -948039556853320506L, a);
                  if (d<"¥">(this, -951300716862146013L, a).getValue() && this.a(targetPos, finalTick)) {
                     if (d<"¥">(this, -951960721007441374L, a).getValue()) {
                        ClientUtils.e(new Object[]{b<"i">(9147, 8930344453648835775L ^ a), axxxxxxxx});
                     }

                     return;
                  }

                  if (d<"¥">(this, -951960721007441374L, a).getValue()) {
                     String var50 = isCrystalTarget ? b<"i">(26804, 2529171918952509320L ^ a) : b<"i">(27705, 2787820656290474760L ^ a);
                     ClientUtils.e(new Object[]{String.format(b<"i">(3795, 1828033161177352675L ^ a), var50, finalTick), axxxxxxxx});
                  }

                  Rotation calculatedRotation = RotationUtils.L(new Object[]{targetPos, axxxxxxxxx});
                  calculatedRotation = new Rotation(axxxxxxx, calculatedRotation.getYaw(), calculatedRotation.J(new Object[]{axx}) + -1.0F);
                  if (d<"¥">(this, -951960721007441374L, a).getValue()) {
                     ClientUtils.e(
                        new Object[]{
                           String.format(
                              b<"i">(30715, 1824454886182957305L ^ a), calculatedRotation.J(new Object[]{axx}) - -1.0F, calculatedRotation.J(new Object[]{axx})
                           ),
                           axxxxxxxx
                        }
                     );
                  }

                  d<"s">(this, calculatedRotation, -947094893342936330L, a);
                  RotationUtils.D(new Object[]{axxx, calculatedRotation});
                  d<"s">(this, 1, -950234312225487098L, a);
               }
            }
         }
      }
   }

   private static String HE_SHU_YOU() {
      return "何炜霖诈骗";
   }

   private record 树何树树友何何树友何(友何何何友何何何友友.树友何树何何何树树树 何友友何何友友友树何, double 何何树树何友何友友何, double 何何友何树何友树何何, boolean 树友何树何何何友树树, Vec3 树何树友树何树友何友) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[11];
      private static final String[] c = new String[11];
      private static String HE_WEI_LIN;

      private 树何树树友何何树友何(友何何何友何何何友友.树友何树何何何树树树 何友友何何友友友树何, double 何何树树何友何友友何, double 何何友何树何友树何何, boolean 树友何树何何何友树树, Vec3 树何树友树何树友何友) {
         this.何友友何何友友友树何 = 何友友何何友友友树何;
         this.何何树树何友何友友何 = 0.0;
         this.何何友何树何友树何何 = 0.0;
         this.树友何树何何何友树树 = false;
         this.树何树友树何树友何友 = 树何树友树何树友何友;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(5659768694683185069L, 4178775630774760285L, MethodHandles.lookup().lookupClass()).a(94286188116426L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public double C() {
         long a = 友何何何友何何何友友.树何树树友何何树友何.a ^ 64370128918629L;
         return a<"õ">(this, -8645580186182728978L, a);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      public 友何何何友何何何友友.树友何树何何何树树树 b() {
         long a = 友何何何友何何何友友.树何树树友何何树友何.a ^ 54768906516244L;
         return a<"õ">(this, 2843660923471684008L, a);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友何何何友何何何友友$树何树树友何何树友何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 245 && var8 != 232 && var8 != 162 && var8 != 'o') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'J') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 222) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 245) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 232) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 162) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 3;
                  case 1 -> 49;
                  case 2 -> 59;
                  case 3 -> 39;
                  case 4 -> 31;
                  case 5 -> 20;
                  case 6 -> 6;
                  case 7 -> 36;
                  case 8 -> 14;
                  case 9 -> 45;
                  case 10 -> 25;
                  case 11 -> 9;
                  case 12 -> 18;
                  case 13 -> 47;
                  case 14 -> 54;
                  case 15 -> 1;
                  case 16 -> 35;
                  case 17 -> 55;
                  case 18 -> 40;
                  case 19 -> 30;
                  case 20 -> 21;
                  case 21 -> 46;
                  case 22 -> 41;
                  case 23 -> 15;
                  case 24 -> 34;
                  case 25 -> 52;
                  case 26 -> 38;
                  case 27 -> 5;
                  case 28 -> 24;
                  case 29 -> 17;
                  case 30 -> 56;
                  case 31 -> 8;
                  case 32 -> 63;
                  case 33 -> 2;
                  case 34 -> 50;
                  case 35 -> 33;
                  case 36 -> 4;
                  case 37 -> 42;
                  case 38 -> 26;
                  case 39 -> 10;
                  case 40 -> 53;
                  case 41 -> 12;
                  case 42 -> 61;
                  case 43 -> 51;
                  case 44 -> 22;
                  case 45 -> 13;
                  case 46 -> 28;
                  case 47 -> 23;
                  case 48 -> 57;
                  case 49 -> 27;
                  case 50 -> 11;
                  case 51 -> 58;
                  case 52 -> 16;
                  case 53 -> 29;
                  case 54 -> 60;
                  case 55 -> 7;
                  case 56 -> 0;
                  case 57 -> 44;
                  case 58 -> 19;
                  case 59 -> 62;
                  case 60 -> 48;
                  case 61 -> 37;
                  case 62 -> 32;
                  default -> 43;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = ";SkkSf4\u0013&`Y{1N-&Qf<H)m\u0012`5M)&Le9D z\u0012参伍佨伐參佩作伍叶厎,栭作桉栬厎佝佩栘厓佨";
         b[1] = double.class;
         c[1] = "java/lang/Double";
         b[2] = "t\u0010sl\u001e5t\u0010d0\u0012:n[p-\u00010~[w*\n/4#b!@";
         b[3] = boolean.class;
         c[3] = "java/lang/Boolean";
         b[4] = "a^a-1\nn\u001e,&;\u0017kC'`3\nfE#+p\fo@#`.\tcI*<p厮佗佥会厅伋估佗叻厄j桏厮佗校会伛伋桴栓校";
         b[5] = "W\u001dMPj-\\\u0012\\\u001f\u000b#W\u0019XE";
         b[6] = "\u000f\u0001sre\r\b]z\u0011佞伴桵桴众叒佞厪厯估J(=\bS\u0011$tb\u0014\u0003";
         b[7] = "\u000f\fS5XD\bPZV栧口伱桹伷伋佣口桵桹jlU_\rZ\u001b$@\u0010R";
         b[8] = "0=UzFq7a\\\u0019根佈桊厒桵佄根取伎厒l Fk1n]%\u001ce2";
         b[9] = " (W\u0013\u000bo't^p估佖厀伙桷伭厮栒伞伙nISj|8\u0000\u0015\fv,";
         b[10] = "\u0002\u0013)l\u001d.\u0005O \u000f伦厉厢伢位双厸厉桸伢\u00104\u00123\n\u000etp\u0012w\u0013";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public Vec3 t() {
         long a = 友何何何友何何何友友.树何树树友何何树友何.a ^ 120544086034833L;
         return a<"õ">(this, 1869933652571173691L, a);
      }

      public boolean v() {
         long a = 友何何何友何何何友友.树何树树友何何树友何.a ^ 121304874003014L;
         return a<"õ">(this, 4190499427512603619L, a);
      }

      public double U() {
         long a = 友何何何友何何何友友.树何树树友何何树友何.a ^ 124627862679528L;
         return a<"õ">(this, 9190158547416713856L, a);
      }

      private static String LIU_YA_FENG() {
         return "何树友被何大伟克制了";
      }
   }

   private static enum 树友何树何何何树树树 implements  {
      友何何友何何友树树何,
      何何树何友何树树友友,
      树何何友何友树友何何,
      树友树树友友树友何何,
      友树友树友树何友友树,
      树友何树树何何友友友,
      友何友树何树树何何树,
      友友何何友何友树何何;

      private static final long a;
      private static final Object[] b = new Object[12];
      private static final String[] c = new String[12];
      private static String HE_JIAN_GUO;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-4920806616551797989L, 2123773627085964070L, MethodHandles.lookup().lookupClass()).a(199808084090686L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 109189600866657L;
         a();
         Cipher var1;
         Cipher var13 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[8];
         int var6 = 0;
         String var5 = " ¼¿æ_\u007fX4?f]ÖxL4\u008b\b!\u009b¿\u0096Ø\b][\u0018\u0014§\fßâXé\u001b\u001fL7ú0êëe\u000fË6Ko£\u0016\u0004\u0018ºP\u0005ø\u0089\u0000\u001eøðCPãsìÎ¬;\u0017»s|§w¦\bå\r§î¢¼\u0088Õ\u0010\u009fcö¡³\u0099ë®ÖÇþ¦=\u000f\u001f\b";
         byte var7 = 101;
         char var4 = 16;
         int var12 = -1;

         label28:
         while (true) {
            String var14 = var5.substring(++var12, var12 + var4);
            byte var10001 = -1;

            while (true) {
               String var20 = a(var1.doFinal(var14.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var20;
                     if ((var12 += var4) >= var7) {
                        友何何友何何友树树何 = new 友何何何友何何何友友.树友何树何何何树树树();
                        何何树何友何树树友友 = new 友何何何友何何何友友.树友何树何何何树树树();
                        树何何友何友树友何何 = new 友何何何友何何何友友.树友何树何何何树树树();
                        树友树树友友树友何何 = new 友何何何友何何何友友.树友何树何何何树树树();
                        友树友树友树何友友树 = new 友何何何友何何何友友.树友何树何何何树树树();
                        树友何树树何何友友友 = new 友何何何友何何何友友.树友何树何何何树树树();
                        友何友树何树树何何树 = new 友何何何友何何何友友.树友何树何何何树树树();
                        友友何何友何友树何何 = new 友何何何友何何何友友.树友何树何何何树树树();
                        return;
                     }

                     var4 = var5.charAt(var12);
                     break;
                  default:
                     var0[var6++] = var20;
                     if ((var12 += var4) < var7) {
                        var4 = var5.charAt(var12);
                        continue label28;
                     }

                     var5 = "aRÕcN\u0012n]\u0001{!\u0014Ò¦V\u0096\u0010E[\u0005Ú\u0093<y\u0019!Îe\u0085nø,Õ";
                     var7 = 33;
                     var4 = 16;
                     var12 = -1;
               }

               var14 = var5.substring(++var12, var12 + var4);
               var10001 = 0;
            }
         }
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'B' && var8 != 'N' && var8 != 210 && var8 != 'e') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 217) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 231) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'B') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'N') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 210) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友何何何友何何何友友$树友何树何何何树树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 1;
                  case 1 -> 57;
                  case 2 -> 15;
                  case 3 -> 37;
                  case 4 -> 46;
                  case 5 -> 0;
                  case 6 -> 47;
                  case 7 -> 62;
                  case 8 -> 18;
                  case 9 -> 12;
                  case 10 -> 40;
                  case 11 -> 4;
                  case 12 -> 2;
                  case 13 -> 42;
                  case 14 -> 23;
                  case 15 -> 14;
                  case 16 -> 35;
                  case 17 -> 16;
                  case 18 -> 24;
                  case 19 -> 19;
                  case 20 -> 58;
                  case 21 -> 41;
                  case 22 -> 6;
                  case 23 -> 39;
                  case 24 -> 56;
                  case 25 -> 55;
                  case 26 -> 34;
                  case 27 -> 48;
                  case 28 -> 61;
                  case 29 -> 52;
                  case 30 -> 59;
                  case 31 -> 28;
                  case 32 -> 26;
                  case 33 -> 30;
                  case 34 -> 29;
                  case 35 -> 36;
                  case 36 -> 53;
                  case 37 -> 9;
                  case 38 -> 44;
                  case 39 -> 33;
                  case 40 -> 5;
                  case 41 -> 3;
                  case 42 -> 8;
                  case 43 -> 31;
                  case 44 -> 38;
                  case 45 -> 60;
                  case 46 -> 10;
                  case 47 -> 7;
                  case 48 -> 22;
                  case 49 -> 17;
                  case 50 -> 11;
                  case 51 -> 21;
                  case 52 -> 25;
                  case 53 -> 45;
                  case 54 -> 50;
                  case 55 -> 27;
                  case 56 -> 13;
                  case 57 -> 51;
                  case 58 -> 63;
                  case 59 -> 54;
                  case 60 -> 20;
                  case 61 -> 43;
                  case 62 -> 32;
                  default -> 49;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\u000e\u0003 m)w\u0001Cmf#j\u0004\u001ef +w\t\u0018bkhq\u0000\u001db 6t\f\u0014k|h叓伸伸佛叅伓位伸厦叅*桗叓伸桼佛佛伓栉桼桼";
         b[1] = "\u0007\f{d\u000b\u001f3/t$F\u001492qyMR1/|\u007fI\u0019r)uzIR,,ys@\u000er压位佟佰厷伉伕位叁叮X桍压位栛佰伩伉桑栉栛\u001e";
         b[2] = "f<jr\u0019\u0003m3{=x\rf8\u007fg";
         b[3] = "\u00033>S\u001c3W6l/桤厑桷栓叆召桤厑伳佗\u0005BDi\u0012kd\u0016A;";
         b[4] = ")M\u0007\u0016(\u0000}HUj桐厢伙桭叿厩厊似桝伩<SwQ6M\u0003U,\u001e/";
         b[5] = "%^T{\u0007kq[\u0006\u0007厥叉伕伺厬佚厥栓伕伺oj_14\u0006\u000e>Zc";
         b[6] = "]\u001c,:o^\t\u0019~F反佢佭另佊伛反栦栩佸\u0017+7\u0004LDv\u007f2V";
         b[7] = "zVm\u0000\u0006\u0017.S?|桾厵佊桶桏伡伺厵叔厬V\u0011^Mk\u000e7E[\u001f";
         b[8] = "bG\u001fg(q6BM\u001b伔位栖伣叧但桐栉双厽$vp+s\u001fE\"uy";
         b[9] = "J\u00154\u0006\u0001\r\u001e\u0010fz厣桵古栵双档伽厯古栵\u000f\u0017YW[MnC\\\u0005";
         b[10] = "\u0010\r\u0002-}@D\bPQ叟佼厾栭佤案栅佼传栭9<%\u001a\u0001UXh H";
         b[11] = "\u001b3<SUmO6n/栭佑伫叉佚召栭叏伫佗\u0007B\r7\nkf\u0016\be";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public static 友何何何友何何何友友.树友何树何何何树树树[] Y() {
         long var0 = a ^ 23955552799082L;
         return (友何何何友何何何友友.树友何树何何何树树树[])a<"Ò">(7245206988218537859L, var0).clone();
      }

      public static 友何何何友何何何友友.树友何树何何何树树树 P(String name) {
         return Enum.valueOf(友何何何友何何何友友.树友何树何何何树树树.class, name);
      }

      private static String HE_DA_WEI() {
         return "我是何树友";
      }
   }
}
