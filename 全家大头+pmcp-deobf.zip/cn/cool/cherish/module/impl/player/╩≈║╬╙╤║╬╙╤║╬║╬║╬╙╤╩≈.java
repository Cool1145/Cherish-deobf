package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.友树友友何友树友树友;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.item.友何树何友树友树何何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.AbstractFurnaceMenu;
import net.minecraft.world.inventory.BrewingStandMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.FurnaceMenu;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;

public class 树何友何友何何何友树 extends Module implements 何树友 {
   public static 树何友何友何何何友树 树树友何友树何树友何;
   private static final 树友树友友何何树何何 何树友树何树何何树友;
   private final NumberValue 树树友友友树何树友树;
   private final NumberValue 何树友友友树何树树友;
   private final BooleanValue 友树友树友树何树何何;
   private final BooleanValue 树何友树树树友树何何;
   private final BooleanValue 何树友友树友何友何友;
   private final BooleanValue 何树友何友树何树树友;
   private final BooleanValue 树何何何友何树何何何;
   private final BooleanValue 何何树友何树友何树何;
   private final BooleanValue 友何树友友友何何友何;
   private final 树友树友友何何树何何 何树何友何友何何树树;
   private final 树友树友友何何树何何 树树何何友何友何友何;
   private final Random 友何何友何树树何树树;
   private AbstractContainerMenu 树友何何何友友树何友;
   private boolean 友树何树树友树友友何;
   private int 友友友树何树何友友何;
   private int 何树何友树树友何友友;
   private int 友何友何友友友友何何;
   private long 树何树树树何树友友树;
   private int 友友何树友树友友树何;
   private AbstractContainerMenu 树树树友何友友何树何;
   private int 何树何树友树何树何树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[63];
   private static final String[] n = new String[63];
   private static int _何大伟：我要教育何炜霖 _;

   public 树何友何友何何何友树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/树何友何友何何何友树.a J
      // 003: ldc2_w 94240759476133
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 100007458334231
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 27555
      // 014: ldc2_w 4839869738303732514
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 5472
      // 021: ldc2_w 7528434066409506286
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -8243648881643659344
      // 02e: lload 1
      // 02f: invokedynamic L (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/NumberValue
      // 03b: dup
      // 03c: sipush 12447
      // 03f: ldc2_w 7333493739339243540
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 6248
      // 04c: ldc2_w 560640201948678383
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 100
      // 058: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 05b: bipush 0
      // 05c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 05f: sipush 1000
      // 062: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 065: bipush 10
      // 067: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 06a: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 06d: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.树树友友友树何树友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 070: aload 0
      // 071: new cn/cool/cherish/value/impl/NumberValue
      // 074: dup
      // 075: sipush 25539
      // 078: ldc2_w 7344208246022681418
      // 07b: lload 1
      // 07c: lxor
      // 07d: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 082: sipush 30021
      // 085: ldc2_w 1445995327951873479
      // 088: lload 1
      // 089: lxor
      // 08a: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 08f: bipush 1
      // 090: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 093: bipush 0
      // 094: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 097: bipush 10
      // 099: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09c: bipush 1
      // 09d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0a0: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0a3: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.何树友友友树何树树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 0a6: aload 0
      // 0a7: new cn/cool/cherish/value/impl/BooleanValue
      // 0aa: dup
      // 0ab: sipush 10926
      // 0ae: ldc2_w 8357818477690583590
      // 0b1: lload 1
      // 0b2: lxor
      // 0b3: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b8: sipush 4949
      // 0bb: ldc2_w 9152846083033940944
      // 0be: lload 1
      // 0bf: lxor
      // 0c0: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c5: bipush 1
      // 0c6: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0c9: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0cc: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.友树友树友树何树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0cf: aload 0
      // 0d0: new cn/cool/cherish/value/impl/BooleanValue
      // 0d3: dup
      // 0d4: sipush 21679
      // 0d7: ldc2_w 1528701330043175973
      // 0da: lload 1
      // 0db: lxor
      // 0dc: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e1: sipush 15193
      // 0e4: ldc2_w 819719531191102429
      // 0e7: lload 1
      // 0e8: lxor
      // 0e9: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ee: bipush 0
      // 0ef: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0f2: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0f5: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.树何友树树树友树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0f8: aload 0
      // 0f9: new cn/cool/cherish/value/impl/BooleanValue
      // 0fc: dup
      // 0fd: sipush 16328
      // 100: ldc2_w 1026521470751305543
      // 103: lload 1
      // 104: lxor
      // 105: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 10a: sipush 15735
      // 10d: ldc2_w 695805901374483956
      // 110: lload 1
      // 111: lxor
      // 112: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 117: bipush 1
      // 118: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 11b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 11e: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.何树友友树友何友何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 121: aload 0
      // 122: new cn/cool/cherish/value/impl/BooleanValue
      // 125: dup
      // 126: sipush 591
      // 129: ldc2_w 910612941116396245
      // 12c: lload 1
      // 12d: lxor
      // 12e: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 133: sipush 23379
      // 136: ldc2_w 1065782320947301323
      // 139: lload 1
      // 13a: lxor
      // 13b: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 140: bipush 1
      // 141: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 144: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 147: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.何树友何友树何树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 14a: aload 0
      // 14b: new cn/cool/cherish/value/impl/BooleanValue
      // 14e: dup
      // 14f: sipush 20244
      // 152: ldc2_w 2314062178957238159
      // 155: lload 1
      // 156: lxor
      // 157: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 15c: sipush 6162
      // 15f: ldc2_w 3290342438886557844
      // 162: lload 1
      // 163: lxor
      // 164: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 169: bipush 0
      // 16a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 16d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 170: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.树何何何友何树何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 173: aload 0
      // 174: new cn/cool/cherish/value/impl/BooleanValue
      // 177: dup
      // 178: sipush 16614
      // 17b: ldc2_w 3287087242191114367
      // 17e: lload 1
      // 17f: lxor
      // 180: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 185: sipush 4491
      // 188: ldc2_w 1205540881674518790
      // 18b: lload 1
      // 18c: lxor
      // 18d: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 192: bipush 0
      // 193: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 196: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 199: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.何何树友何树友何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 19c: aload 0
      // 19d: new cn/cool/cherish/value/impl/BooleanValue
      // 1a0: dup
      // 1a1: sipush 11197
      // 1a4: ldc2_w 7718787220574599997
      // 1a7: lload 1
      // 1a8: lxor
      // 1a9: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ae: sipush 25517
      // 1b1: ldc2_w 5642540570144322337
      // 1b4: lload 1
      // 1b5: lxor
      // 1b6: invokedynamic a (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1bb: bipush 0
      // 1bc: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1bf: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1c2: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.友何树友友友何何友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1c5: aload 0
      // 1c6: new cn/cool/cherish/utils/树友树友友何何树何何
      // 1c9: dup
      // 1ca: lload 3
      // 1cb: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 1ce: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.何树何友何友何何树树 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 1d1: aload 0
      // 1d2: new cn/cool/cherish/utils/树友树友友何何树何何
      // 1d5: dup
      // 1d6: lload 3
      // 1d7: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 1da: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.树树何何友何友何友何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 1dd: aload 0
      // 1de: new java/util/Random
      // 1e1: dup
      // 1e2: invokespecial java/util/Random.<init> ()V
      // 1e5: putfield cn/cool/cherish/module/impl/player/树何友何友何何何友树.友何何友何树树何树树 Ljava/util/Random;
      // 1e8: aload 0
      // 1e9: aconst_null
      // 1ea: ldc2_w -8243808575405401154
      // 1ed: lload 1
      // 1ee: invokedynamic ª (Ljava/lang/Object;Lnet/minecraft/world/inventory/AbstractContainerMenu;JJ)V bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f3: aload 0
      // 1f4: bipush 0
      // 1f5: ldc2_w -8242563566941954532
      // 1f8: lload 1
      // 1f9: invokedynamic ª (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1fe: aload 0
      // 1ff: bipush 0
      // 200: ldc2_w -8243047311704380680
      // 203: lload 1
      // 204: invokedynamic ª (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 209: aload 0
      // 20a: bipush -1
      // 20b: ldc2_w -8242648304684465827
      // 20e: lload 1
      // 20f: invokedynamic ª (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 214: aload 0
      // 215: bipush 0
      // 216: ldc2_w -8243965243660494597
      // 219: lload 1
      // 21a: invokedynamic ª (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 21f: aload 0
      // 220: bipush 0
      // 221: ldc2_w -8242242943934598753
      // 224: lload 1
      // 225: invokedynamic ª (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 22a: aload 0
      // 22b: ldc2_w -8244336651100255376
      // 22e: lload 1
      // 22f: invokedynamic ä (Lcn/cool/cherish/module/impl/player/树何友何友何何何友树;JJ)V bsm=cn/cool/cherish/module/impl/player/树何友何友何何何友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 234: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-8290310564256792051L, -2092959277880292486L, MethodHandles.lookup().lookupClass()).a(91157552736207L);
      // $VF: monitorexit
      a = var10000;
      long var20 = a ^ 111288570762224L;
      long var22 = var20 ^ 117053096778306L;
      b();
      Cipher var11;
      Cipher var26 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(var20 << var12 * 8 >>> 56);
      }

      var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[20];
      int var16 = 0;
      String var15 = " ê\bN\u008b\\\u0001\u0004)áIÓI\u0014Å\u001a Ít\u0099ìo\u0011ÝoA\u001e\u001c\"Ò)\u0004ä\u009eß^×öKtõ=ü\u0010ü_þ-\u0013 \u00004\u0080F\nlµó%ÂÍ\u009aY \u001f\u001d\u001b\u0085\u008b´A\\æ\f)»\u009b\u0007\u007f\u009d\tÕ\u0010\f\u0090©õ¼\u009cÖüÉ\u001d.8\u008e\u0087ô\u0083\u0018A\b[ï¿¼\u0093\u0084\u0080&ê¼¡)\u0093Á\u009ek\u0089ëh\u000böî \u001et¢Dâ\u0014nH\u008d\u0080\\1\u0005\u0003¥ :b\u000eýû\"q½ØRÇ\u001a\u0082ùìg ×¾\u009cê1·0«}óü0\u0002ñw\u0013\u000b\u009f\u001c1\u00906M\u0003XnZÛ\u009b\t\u0018\u008f\u0010\txb¨`´P\u009aÇ\u000eöý¶øcN )ê9t,w@F±R\u0098Ï\u0097\u0094\u0003Eý\u0005\nvëuÓx+ñi\"\u009f¹^÷ 5\u0013÷ª{³ ÓX\t\u0099\u0015ïú\u0090fÎ-AÆä!;\u001e(\u0097`PHµ^\u008c 2Î¨üh\u0017züà\u0012&ë\u0014Rñm÷^\u008dmÊæ-¨w_B«@þo\b\u0010ûÑrcC^\u0000±Ùg&º\u009cÿ\u0089Â +ê0ùxéG\u009aÌkÔ-\u0097¡\u0018?nø\u0007\u0097\u0098¼àÇìI½s\u0083°)þ\u0010SæqCò%1ÓOÊ¾`5»ïð Í\u009b1SNLâDäfC´ õqï%þë/Z·ð\u0017ë\u001c£kþ\u0095M \u0010öCØÒ;\u0003\f\u000f\u0094´l¾\u0007ÇÅ,\u0018ð\u0087AG2y-[U\u009cÎxÀ\u0091\u0086}Çc8Kz\u0012Ô# öAfàw\u0084ÔS(¿,Hµ¢(²}$9¿V!\u0014Fw\u0095!@W\u0012Ë'";
      short var17 = 481;
      char var14 = 16;
      int var25 = -1;

      label45:
      while (true) {
         String var27 = var15.substring(++var25, var25 + var14);
         int var10001 = -1;

         while (true) {
            String var36 = c(var11.doFinal(var27.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var36;
                  if ((var25 += var14) >= var17) {
                     c = var18;
                     h = new String[20];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var29 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var20 << var1 * 8 >>> 56);
                     }

                     var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0083µìÝ~\u0092ü\u0094O\u0019\u0018\u009aùÈ\b_b® ÎnÌúP".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var41 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 24);

                     j = var6;
                     k = new Long[3];
                     何树友树何树何何树友 = new 树友树友友何何树何何(var22);
                     return;
                  }

                  var14 = var15.charAt(var25);
                  break;
               default:
                  var18[var16++] = var36;
                  if ((var25 += var14) < var17) {
                     var14 = var15.charAt(var25);
                     continue label45;
                  }

                  var15 = "$ØÑîxè±\u0001I\"8¥Ï\u0018þm^ |U\u007f¦\u00adaY÷\t\u0017\u000f`.@ \u009dîÉe}I.O!ÄR\u0014XÕ cf~ñ\u000b1~\u009câFýW\u0016×\u0091íI";
                  var17 = 65;
                  var14 = ' ';
                  var25 = -1;
            }

            var27 = var15.substring(++var25, var25 + var14);
            var10001 = 0;
         }
      }
   }

   private boolean C(FurnaceMenu c) {
      long a = 树何友何友何何何友树.a ^ 92133249970730L;
      d<"ÿ">(-8063628193885532505L, a);

      try {
         this.H(c);
         return false;
      } catch (Exception var8) {
         var8.printStackTrace();
         return false;
      }
   }

   private void D(FurnaceMenu container) {
      long a = 树何友何友何何何友树.a ^ 47297721161005L;
      long var10001 = a ^ 38250998410221L;
      d<"ÿ">(3971968361878546848L, a);
      d<"ª">(this, d<"E">(this, 3969384209516965282L, a) + 1, 3969384209516965282L, a);

      try {
         this.H(container);
      } catch (Exception var11) {
         var11.printStackTrace();
      }
   }

   public void F() {
      this.z();
   }

   @EventTarget
   public void I(MotionEvent event) {
      long a = 树何友何友何何何友树.a ^ 25072515471261L;
      long ax = a ^ 32352384208000L;
      long axx = a ^ 34101982832989L;
      long axxx = a ^ 51800070473279L;
      d<"ÿ">(-5354927395765556464L, a);
      if (!this.w(new Object[]{ax})
         && d<"L">(-5355036234761471556L, a).B() == null
         && !d<"L">(-5357318394782831004L, a).isEnabled()
         && d<"E">(this, -5358347580631372180L, a).Y((int)d<"E">(this, -5357768986776297252L, a), axx)
         && mc.player.isAlive()
         && !mc.player.isDeadOrDying()
         && !mc.player.isSpectator()
         && !event.isPost()) {
         AbstractContainerMenu container = d<"E">(mc.player, -5355096064964360571L, a);
         this.M();
         if (container instanceof ChestMenu && d<"E">(this, -5358771879413380465L, a).getValue()) {
            this.o((ChestMenu)container);
         }

         if (container instanceof FurnaceMenu && d<"E">(this, -5355450543344101149L, a).getValue()) {
            this.D((FurnaceMenu)container);
         }

         if (container instanceof BrewingStandMenu && d<"E">(this, -5359118477455484483L, a).getValue()) {
            this.g((BrewingStandMenu)container);
         }

         if (container != null && (container instanceof ChestMenu || container instanceof FurnaceMenu || container instanceof BrewingStandMenu)) {
            if (container != d<"E">(this, -5357187309404690300L, a)) {
               d<"L">(-5355374316228689570L, a).U(axxx);
               d<"ª">(this, 0, -5357620211521173081L, a);
            }

            d<"ª">(this, d<"E">(this, -5357620211521173081L, a) + 1, -5357620211521173081L, a);
            if (d<"E">(this, -5357620211521173081L, a) < d<"E">(this, -5358796975636868017L, a).getValue().intValue()) {
               return;
            }

            if (container instanceof ChestMenu menu
               && (d<"E">(this, -5358771879413380465L, a).getValue() || d<"E">(this, -5358502827329175241L, a).getValue())
               && this.u(menu)) {
               this.o(menu);
            }
         }

         d<"ª">(this, 0, -5357620211521173081L, a);
         d<"ª">(this, container, -5357187309404690300L, a);
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 5;
               case 1 -> 57;
               case 2 -> 14;
               case 3 -> 43;
               case 4 -> 20;
               case 5 -> 23;
               case 6 -> 36;
               case 7 -> 39;
               case 8 -> 48;
               case 9 -> 6;
               case 10 -> 19;
               case 11 -> 24;
               case 12 -> 35;
               case 13 -> 44;
               case 14 -> 18;
               case 15 -> 52;
               case 16 -> 46;
               case 17 -> 0;
               case 18 -> 45;
               case 19 -> 22;
               case 20 -> 41;
               case 21 -> 40;
               case 22 -> 58;
               case 23 -> 38;
               case 24 -> 32;
               case 25 -> 28;
               case 26 -> 25;
               case 27 -> 50;
               case 28 -> 9;
               case 29 -> 13;
               case 30 -> 29;
               case 31 -> 1;
               case 32 -> 37;
               case 33 -> 26;
               case 34 -> 60;
               case 35 -> 51;
               case 36 -> 7;
               case 37 -> 54;
               case 38 -> 8;
               case 39 -> 49;
               case 40 -> 62;
               case 41 -> 2;
               case 42 -> 11;
               case 43 -> 59;
               case 44 -> 53;
               case 45 -> 30;
               case 46 -> 3;
               case 47 -> 34;
               case 48 -> 10;
               case 49 -> 17;
               case 50 -> 4;
               case 51 -> 63;
               case 52 -> 16;
               case 53 -> 42;
               case 54 -> 27;
               case 55 -> 47;
               case 56 -> 12;
               case 57 -> 56;
               case 58 -> 15;
               case 59 -> 61;
               case 60 -> 21;
               case 61 -> 55;
               case 62 -> 31;
               default -> 33;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23832;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友何友何何何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友何友何何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   @EventTarget
   public void b(WorldEvent event) {
      this.z();
   }

   private static void b() {
      m[0] = "T3\u0012^'\u001a[s_U-\u0007^.T\u0013%\u001aS(PXf\u001cZ-P\u00138\u0019V$YOf桤佢厖佩叶伝传佢厖栭";
      m[1] = int.class;
      n[1] = "java/lang/Integer";
      m[2] = boolean.class;
      n[2] = "java/lang/Boolean";
      m[3] = "u^Ro\u000fKu^E3\u0003Do\u0015Q.\u0010N\u007f\u0015O/\u0014GuOI3\u001b\fZYU5\u0010CxOe.\fVzRH$\u0010o~US";
      m[4] = "i#\u001bx>\"b,\n7U6`'\u001dmy!m";
      m[5] = "Z\u007f\u0002^UsU?OU_nPbD\u0013L}UdI\u0013SqI}\u0002\u007fUsUtMSl}UdI";
      m[6] = "\u0001\u001a&\u00147\u0004\u000eZk\u001f=\u0019\u000b\u0007`Y5\u0004\u0006\u0001d\u0012v\u0002\u000f\u0004dY(\u0007\u0003\rm\u0005v伾伷县佝厼桉厠厩伡佝";
      m[7] = "M!]*\u0015\u0000y\u0002RjX\u000bs\u001fW7SM{\u0002Z1W\u00068 Q N\u000fsV";
      m[8] = "\u00051l'5A\nq!,?\\\u000f,*j/Z\u000f31j桋句桷厔厉休伏栿伳伊";
      m[9] = "BF8;\u0001\u0017M\u0006u0\u000b\nH[~v\u0003\u0017E]z=@\u0011LXzv\u001e\u0014@Qs*@桩只口叝伍伻厳栰根叝";
      m[10] = "\u0018R/L\u001f2\u0017\u0012bG\u0015/\u0012Oi\u0001\u0006<\u0017Id\u0001\u00190\u000bP/a\u00050\u0019Ysy\u00111\u000eY";
      m[11] = "'\u0002X)IA'\u0002OuEN=I[hVD-IEsAEg.XbI[";
      m[12] = "\u001c&=\f/\u000f\u001c&*P#\u0000\u0006m>M0\n\u0016m V'\u000b\\\n=G/";
      m[13] = "\t\u001f\u0007+`+\u0017\u0017\u001dd\u001c?\r\u001a\u001e'";
      m[14] = "Z(u/~!Uh8$t<P53b|!]37)?伛佬厍伎伙叚伛佬桗桊";
      m[15] = "3'\\\u000bp\u007f3'KW|p)l_Joz9lAKks36GWd8\u001e.AFvB$2M";
      m[16] = "\u0019<BO\u0012_\u0019<U\u0013\u001eP\u0003wU\r\u0016S\u0019-\u0018,\u0016X\u0012:D\u0000\u0019B";
      m[17] = "\u001e]\u0001\"M\u0003\u001e]\u0016~A\f\u0004\u0016\u0016`I\u000f\u001eL[aU\u0006\u0004Q\u0005`A\u0013\u0015J[AU\u0006\u0004Q%`A\u0013\u0015J2mM\u000f=W\u0011i";
      m[18] = long.class;
      n[18] = "java/lang/Long";
      m[19] = "A)I\u0013K]A)^OGR[b^QOQA8\u0013MJUV)O\u0013j[L-QmJUV)O";
      m[20] = "\u001f:e)d\u0004\u0010z(\"n\u0019\u0015'#df\u0004\u0018!'/%\u0002\u0011$'dh\u0004\u00116*>% \u00158'\u000b~\u0019\u001d";
      m[21] = "\u001bb?\u0012\u0013,\u0010m.]r\"\u001bf*\u0007";
      m[22] = "\rrTmmqX\u007f\r\u0004佊栁厡叐桷叇佊叛伿叐n?p%\u0003uSiqi\u000e";
      m[23] = "\u001cnrB+\u0007Ic++伌桷厰栖伕栲伌伳桪双H\u0015o\u0013\u0013p\"I8\u0002\u0018";
      m[24] = "\u0001;9P8\u000fO(7\u0007F厭叼厑伋佢伛厭佢厑桏?x\u001c\u000e9mU,\u0013Si";
      m[25] = "^j)j\u0012R\u000bgp\u0003桱栢史佖叐栚伵栢史佖\u0013l\t\u0001Xqz9\u0004X";
      m[26] = "'7#?=\u0004r:zV桞估伕伋叚伋桞估伕伋\u0019m P)0$;!\u001c$";
      m[27] = "\u0002\u001dJ$$(\u001e\u000bK~^{9^\u0014&o+9e\u0010g/y\u0010\u0001G.c{";
      m[28] = "P~\u000bDu{\u0000|\rD\u001ag[?\bT|mPD\u0019\u0007e\u007fR9I\u0005c\u007f";
      m[29] = "\u00192\u0015\u007fj:\u001ea\u0014}\u0018|%c^ (c\u0019b\u0005zz\u0003";
      m[30] = "k\u0017HlS5?\u0004\u0007',a\u0003T\u0003`\u00165\u0003h\t0C19\u0005\u00048V?";
      m[31] = "\u0018VYH{+M[\u0000!参伟厴佪厠叢参厁伪佪c\u001880\n^\r\u0018s%\u0012";
      m[32] = "{s\u0004EJo.~],佭佛栍发佣栵右佛栍住>\u0017W;ut\u0003AVwx";
      m[33] = "?s'\u001fatj~~v栂叞伍住佀厵变栄伍发\u001dLbl<ly\u001b+ >";
      m[34] = "G$?/$r\u0012)fF伃栂叫优叆桟伃栂栱历\u0005}9&I#8+8jD";
      m[35] = "C/T\u0012\u0017\u0018\u0018,\u0000\u0017}伤厱厕叻可厾伤伯桏叻,L\u0000\u001ehRM\u0017\u0003Jm";
      m[36] = "u&{~<f!545C2\u001de0rye\u001dY:\",b'47*9l";
      m[37] = "Vx\u0003aIb\u0018k\r67栚伵佌厯体叴佞伵叒桵\u000e\tj\u0007~\u0012oGy\t)";
      m[38] = "\u001cr4?uJI\u007fmV佒栺厰叐反桏佒栺桪叐\u000eh}\u0012\u0018(d<rOH";
      m[39] = "&d(}\u0000zsiq\u0014厹栊厊栜发栍伧栊伔佘\u0012/\u001d.(c/y\u001cb%";
      m[40] = "FuMA\u001eX\u0013x\u0014(伹栨佴受伪叫伹佬栰栍w\u0016ZLIk\u001dJ\r]B";
      m[41] = "5d|@w\u001c`i%)収伨伇叆伛栰栔伨桃栜F\u0018<\u0007k|~\u00166Ej";
      m[42] = "($w]bK}).4叛叡厄桜伐栭佅叡厄优M\r!P:,#\rjE\"";
      m[43] = "\nE\u00125@\t_HK\\栣伽厦栽栱桅叹桹伸佹(g]]\u0004B\u00151\\\u0011\t";
      m[44] = "|e\tO'\u0015)hP&桄桥叐叇台栿伀桥叐栝3\u0018/Mx?YL \u0010(";
      m[45] = "\tO\u0006!eE\\B_H栆栵伻佳叿伕叜佱厥佳<v!Q\u0006QV*v@\r";
      m[46] = "\u001dT\r(BgDP\u0003%!\u0001){+\u0019v\u001d3d-ZH6\u0019H\u0003e\u00112\u0017E";
      m[47] = "oF\u0006\nU\u001c:K_cFu;KBXQN=[\u0006S/NlY\u0007\u001d\u0014H|\u001d\fc";
      m[48] = "5\u007f8Y `et`\u0007Jj\b$;\u0006u>\b\u0015iSs4gp8_tj";
      m[49] = "\\FRn\u001eA\tK\u000b\u0007伹栱佮古桱栞厧併台古h>]ZNN\u0006>\u0016OV";
      m[50] = "\f\u001dF\u0017R\tX\u000e\t\\-]d^\r\u001a\u0011\u0003db\u0007KB\r^\u000f\nCW\u0003";
      m[51] = "\f?$\"z\fY2}K參桼伾桇标厈栙厦厠伃\u001er\u007f\u0019[e`u>\f\u0018";
      m[52] = "\u007f\u001aZ2\b/*\u0017\u0003[厱伛栉厸厣厘伯伛叓伦``\u0015{q\u001d]6\u00147|";
      m[53] = "G\u001a\u0010\bs*\u0012\u0017Ia栐伞栱桢栳似栐厀叫桢*\r1#\u0017\u001eQ\u001b1}C";
      m[54] = "'w|//Bp>0-QHJ5=sm\u001eJ\u000e4z#[t`416C";
      m[55] = "\u0003a\u001cC/\u0015VlE*伈桥伱栙句栳伈桥伱栙&\u0013l\u000e\u0011iH\u0013'\u001b\t";
      m[56] = "YTf{cw\fY?\u0012叚叝佫栬原栋叚叝栯佨\\+ lK\\2+kyS";
      m[57] = "f\u0017\\\u001cl-2\u0004\u0013W\u0013y\u000eT\u0017\u0011/(\u000eh\u001d@|)4\u0005\u0010Hi'";
      m[58] = "\u0012\u0015TT.VF\u0006\u001b\u001fQ\u0002zV\u001fYhVzj\u0015\b>R@\u0007\u0018\u0000+\\";
      m[59] = "?F;sIy8\u0015:q;桙叀叩厂桑栢伝栚叩伜H\u0007,y\u00113q\u0000\u007fx\u0013";
      m[60] = "A:/w/\u0004\u0015)`<PP)yd{j\u0005)En+?\u0000\u0013(c#*\u000e";
      m[61] = "o\n&n~\u001f:\u0007\u007f\u0007栝桯栙厨佁叄叇伫栙伶\u001c=}\u0007l\u0015xj4Kn";
      m[62] = "V{;-z\u001c\u0002htf\u0005H>8p 8\u001c>\u0004zqj\u0018\u0004iwy\u007f\u0016";
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 17279;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友何友何何何友树", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友何友何何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'E' && var8 != 170 && var8 != 'L' && var8 != 228) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'P') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 255) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'E') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 170) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'L') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private boolean f(ItemStack stack) {
      long a = 树何友何友何何何友树.a ^ 65562247194308L;
      long ax = a ^ 58267495208971L;
      d<"ÿ">(357566176290036297L, a);
      if (stack.getItem() instanceof FishingRodItem) {
         int existingRods = 友何树何友树友树何何.T(d<"L">(359749756957702069L, a), ax);
         if (existingRods > 0) {
            return false;
         }
      }

      if (stack.getItem() instanceof BlockItem) {
         int maxBlockCount = d<"E">(d<"L">(358170008467056982L, a), 357800061707549155L, a).getValue().intValue();
         if (d<"E">(this, 359089719337198489L, a) + stack.getCount() > maxBlockCount) {
            return false;
         }
      }

      if (d<"E">(this, 358345098617912374L, a).getValue()) {
         Item item = stack.getItem();
         if (item instanceof SwordItem) {
            return this.K(stack);
         }

         if (item instanceof DiggerItem) {
            return this.K(stack);
         }

         if (item instanceof ArmorItem) {
            return this.K(stack);
         }

         if (item instanceof BowItem) {
            return this.K(stack);
         }
      }

      return true;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何友何友何何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   public boolean a() {
      long a = 树何友何友何何何友树.a ^ 116991436352816L;
      d<"ÿ">(1081432689564930493L, a);
      AbstractContainerMenu container = d<"E">(mc.player, 1081880043104549928L, a);
      if (container instanceof ChestMenu) {
         return this.M((ChestMenu)container);
      } else if (container instanceof FurnaceMenu) {
         return this.C((FurnaceMenu)container);
      } else {
         return container instanceof BrewingStandMenu ? this.A((BrewingStandMenu)container) : true;
      }
   }

   private void o() {
      long a = 树何友何友何何何友树.a ^ 68631358277982L;
      d<"ª">(this, false, 7739404924213000423L, a);
      d<"ª">(this, -1, 7739243358665074598L, a);
      d<"ª">(this, null, 7738151843399908677L, a);
      d<"ª">(this, 0, 7740815397229035008L, a);
   }

   private void o(ChestMenu container) {
      long a = 树何友何友何何何友树.a ^ 116482566699429L;
      d<"ÿ">(-2623620721712003800L, a);
      d<"ª">(this, d<"E">(this, -2621562153088237270L, a) + 1, -2621562153088237270L, a);
      List<Integer> availableSlots = this.z(container);
      if (d<"E">(this, -2621866756643141271L, a).getValue() && !availableSlots.isEmpty() && d<"E">(this, -2621562153088237270L, a) > 1) {
         int randomSlot = availableSlots.get(d<"E">(this, -2622748470719938497L, a).nextInt(availableSlots.size()));
         this.U(container, randomSlot);
      }

      int i = 0;
      if (0 < container.getRowCount() * 9) {
         ItemStack stack = container.getSlot(0).getItem();
         if (!stack.isEmpty() && d<"E">(this, -2621562153088237270L, a) > 1 && this.O(container, 0)) {
            return;
         }

         i++;
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private boolean k(ItemStack stack) {
      long a = 树何友何友何何何友树.a ^ 129673613515199L;
      long ax = a ^ 42177745003597L;
      long axx = a ^ 44456486006899L;
      long axxx = a ^ 72066705973024L;
      long axxxx = a ^ 126701036046107L;
      long var10001 = a ^ 69814053222561L;
      int axxxxx = (int)((a ^ 69814053222561L) >>> 32);
      int axxxxxx = (int)((a ^ 69814053222561L) << 32 >>> 48);
      int axxxxxxx = (int)(var10001 << 48 >>> 48);
      long axxxxxxxx = a ^ 4151393659298L;
      long axxxxxxxxx = a ^ 15934934606245L;
      long axxxxxxxxxx = a ^ 134902482036592L;
      long axxxxxxxxxxx = a ^ 22011362046664L;
      long axxxxxxxxxxxx = a ^ 129866903718481L;
      long axxxxxxxxxxxxx = a ^ 53416044501736L;
      long axxxxxxxxxxxxxx = a ^ 125931746908354L;
      long axxxxxxxxxxxxxxx = a ^ 69245080423464L;
      long axxxxxxxxxxxxxxxx = a ^ 3056295920356L;
      long axxxxxxxxxxxxxxxxx = a ^ 6846324577562L;
      long axxxxxxxxxxxxxxxxxx = a ^ 41024164566944L;
      long axxxxxxxxxxxxxxxxxxx = a ^ 110286459444996L;
      d<"ÿ">(-320570561259789006L, a);
      if (stack.isEmpty()) {
         return false;
      } else if (!友何树何友树友树何何.P(axxxxxxxxxxxxxxxxxxx, stack) && !友何树何友树友树何何.e(axxxxxxxxxxxxxxx, stack)) {
         if (stack.getItem() instanceof ArmorItem item) {
            float protection = 友何树何友树友树何何.C(stack);
            float bestArmor = 友何树何友树友树何何.r(item.getEquipmentSlot(), axxxxxxxxxxxxx);
            return !(protection <= bestArmor);
         } else if (stack.getItem() instanceof SwordItem) {
            float damage = 友何树何友树友树何何.A(stack);
            float bestDamage = 友何树何友树友树何何.e(axxxxxxxx);
            return !(damage <= bestDamage);
         } else if (stack.getItem() instanceof PickaxeItem) {
            float score = 友何树何友树友树何何.K(stack);
            float bestScore = 友何树何友树友树何何.n(axx);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof AxeItem) {
            float score = 友何树何友树友树何何.K(stack);
            float bestScore = 友何树何友树友树何何.F(axxxxxxxxxxxx);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof ShovelItem) {
            float score = 友何树何友树友树何何.K(stack);
            float bestScore = 友何树何友树友树何何.l(axxxxxxxxx);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof CrossbowItem) {
            float score = 友何树何友树友树何何.u(stack);
            float bestScore = 友何树何友树友树何何.G(axxx);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof BowItem && 友何树何友树友树何何.j(stack, ax)) {
            float score = 友何树何友树友树何何.E(stack);
            float bestScore = 友何树何友树友树何何.d(axxxxx, (short)axxxxxx, (char)axxxxxxx);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof BowItem && 友何树何友树友树何何.n(axxxxxxxxxxxxxxxxxx, stack)) {
            float score = 友何树何友树友树何何.Y(stack);
            float bestScore = 友何树何友树友树何何.y(axxxxxxxxxxxxxx);
            return !(score <= bestScore);
         } else if (stack.getItem() == d<"L">(-320383924090628425L, a)) {
            return !友何树何友树友树何何.c(axxxxxxxxxxxxxxxx, stack.getItem());
         } else if (stack.getItem() == d<"L">(-323124625992803763L, a) && 友何树何友树友树何何.T(d<"L">(-323124625992803763L, a), axxxxxxxxxx) >= 树友友友何何友树树友.y()) {
            return false;
         } else if (stack.getItem() == d<"L">(-322313162001240140L, a) && 友何树何友树友树何何.T(d<"L">(-322313162001240140L, a), axxxxxxxxxx) >= 树友友友何何友树树友.t()) {
            return false;
         } else if (stack.getItem() instanceof BlockItem && 友树友友何友树友树友.h(axxxx, stack) && 友何树何友树友树何何.l(axxxxxxxxxxx) + stack.getCount() >= 树友友友何何友树树友.T()) {
            return false;
         } else if (stack.getItem() == d<"L">(-322888268796396131L, a)
            && 友何树何友树友树何何.T(d<"L">(-322888268796396131L, a), axxxxxxxxxx) + stack.getCount() >= 树友友友何何友树树友.x()) {
            return false;
         } else if (stack.getItem() instanceof FishingRodItem && 友何树何友树友树何何.T(d<"L">(-322754833282971442L, a), axxxxxxxxxx) >= 1) {
            return false;
         } else if ((stack.getItem() == d<"L">(-322573683325132829L, a) || stack.getItem() == d<"L">(-323287729843862002L, a))
            && 友何树何友树友树何何.T(d<"L">(-322573683325132829L, a), axxxxxxxxxx) + 友何树何友树友树何何.T(d<"L">(-323287729843862002L, a), axxxxxxxxxx) + stack.getCount()
               >= 树友友友何何友树树友.q()) {
            return false;
         } else {
            return stack.getItem() instanceof ItemNameBlockItem ? false : 友何树何友树友树何何.I(stack, axxxxxxxxxxxxxxxxx);
         }
      } else {
         return true;
      }
   }

   private void g(BrewingStandMenu container) {
      long a = 树何友何友何何何友树.a ^ 6350550204440L;
      long var10001 = a ^ 13231732588248L;
      long ax = a ^ 113348777650302L;
      d<"ÿ">(7073583728819715221L, a);
      d<"ª">(this, d<"E">(this, 7071560894309333143L, a) + 1, 7071560894309333143L, a);
      WrapperUtils.g(new Object[]{container, ax});
   }

   public static boolean j() {
      long var0 = a ^ 65492484535317L;
      long var2 = var0 ^ 55383380249301L;
      d<"ÿ">(-3015348264585885544L, var0);
      return !d<"L">(-3015777652723801386L, var0).Y(c<"d">(25414, 3095936760665110040L ^ var0), var2);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void U(AbstractContainerMenu container, int slot) {
      long a = 树何友何友何何何友树.a ^ 40695404279276L;
      d<"ÿ">(-2891792369762465439L, a);
      if (!d<"E">(this, -2894133757827529643L, a)) {
         d<"ª">(this, container, -2895414947057761801L, a);
         d<"ª">(this, slot, -2894323911213786348L, a);
         d<"ª">(this, true, -2894133757827529643L, a);
         d<"ª">(this, 0, -2891594638813871438L, a);
      }
   }

   private void z() {
      long a = 树何友何友何何何友树.a ^ 94640826021179L;
      this.o();
      d<"ª">(this, 0, -7565018147944404223L, a);
   }

   private List<Integer> z(ChestMenu container) {
      long a = 树何友何友何何何友树.a ^ 43187548291411L;
      d<"ÿ">(-2062287519265079842L, a);
      ArrayList slots = new ArrayList();
      int i = 0;
      if (0 < container.getRowCount() * 9) {
         ItemStack stack = container.getSlot(0).getItem();
         if (!stack.isEmpty() && (this.k(stack) || d<"E">(this, -2062453927879564932L, a).getValue()) && this.f(stack)) {
            slots.add(0);
         }

         i++;
      }

      return slots;
   }

   private boolean u(ChestMenu menu) {
      long a = 树何友何友何何何友树.a ^ 89494792622123L;
      long ax = a ^ 97493536780011L;
      d<"ÿ">(-5613386950471783258L, a);
      if (this.M(menu) && d<"E">(this, -5614751561165852077L, a).Y(c<"d">(2595, 1248438040946998082L ^ a), ax)) {
         mc.player.closeContainer();
         return false;
      } else {
         return true;
      }
   }

   private void r() {
      long a = 树何友何友何何何友树.a ^ 116487444022414L;
      long ax = a ^ 88102027973932L;
      d<"ÿ">(-6432258626773387261L, a);
      if (d<"E">(this, -6434756008637009771L, a) != null && d<"E">(this, -6433665510205052298L, a) >= 0) {
         d<"ª">(this, d<"E">(this, -6435567716198017223L, a).getValue().longValue(), -6433921747824659505L, a);
         d<"E">(mc, -6433593765312636034L, a)
            .handleInventoryMouseClick(
               d<"E">(d<"E">(this, -6434756008637009771L, a), -6433733526341951629L, a),
               d<"E">(this, -6433665510205052298L, a),
               0,
               d<"L">(-6435392971975951136L, a),
               mc.player
            );
         d<"E">(this, -6435594940860023425L, a).U(ax);
         d<"E">(this, -6435259446610778378L, a).U(ax);
         d<"L">(-6431531339435453875L, a).U(ax);
      }
   }

   private boolean A(BrewingStandMenu c) {
      long a = 树何友何友何何何友树.a ^ 85698955762065L;
      long ax = a ^ 51818180276727L;
      d<"ÿ">(-4926055242198227684L, a);
      WrapperUtils.g(new Object[]{c, ax});
      return true;
   }

   private List<Integer> X(Container container) {
      long a = 树何友何友何何何友树.a ^ 2309829623320L;
      d<"ÿ">(-7193817385410706795L, a);
      List<Integer> slots = new ArrayList<>();
      int i = 0;
      if (0 < container.getContainerSize()) {
         ItemStack stack = container.getItem(0);
         if (!stack.isEmpty() && this.f(stack)) {
            slots.add(0);
         }

         i++;
      }

      return slots;
   }

   private void M() {
      long a = 树何友何友何何何友树.a ^ 85330897245051L;
      d<"ª">(this, 0, -1061503670229445082L, a);
      d<"ÿ">(-1060278090530050058L, a);
      int i = 0;
      if (0 < mc.player.getInventory().getContainerSize()) {
         ItemStack stack = mc.player.getInventory().getItem(0);
         if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) {
            d<"ª">(this, d<"E">(this, -1061503670229445082L, a) + stack.getCount(), -1061503670229445082L, a);
         }

         i++;
      }
   }

   private boolean M(ChestMenu c) {
      long a = 树何友何友何何何友树.a ^ 93753646757531L;
      d<"ÿ">(-3122900619668649450L, a);
      int i = 0;
      if (0 < c.getRowCount() * 9) {
         ItemStack stack = c.getSlot(0).getItem();
         if (!stack.isEmpty() && (this.k(stack) || d<"E">(this, -3123031835117414732L, a).getValue()) && this.f(stack)) {
            return false;
         }

         i++;
      }

      return true;
   }

   private Container H(AbstractFurnaceMenu container) throws Exception {
      long a = 树何友何友何何何友树.a ^ 48067249711200L;
      Field[] fields = AbstractFurnaceMenu.class.getDeclaredFields();
      d<"ÿ">(5355418350553535725L, a);
      int var7 = fields.length;
      int var8 = 0;
      if (0 < var7) {
         Field field = fields[0];
         if (Container.class.isAssignableFrom(field.getType())) {
            field.setAccessible(true);
            return (Container)field.get(container);
         }

         var8++;
      }

      return null;
   }

   @EventTarget
   public void T(LivingUpdateEvent event) {
      long a = 树何友何友何何何友树.a ^ 133783066281877L;
      d<"ÿ">(-1898523949589415144L, a);
      if (d<"E">(this, -1896961015757638100L, a) && d<"E">(this, -1898205817044388978L, a) != null && d<"E">(this, -1897115972119565971L, a) >= 0) {
         d<"ª">(this, d<"E">(this, -1898371349183041333L, a) + 1, -1898371349183041333L, a);
         if (d<"E">(this, -1898371349183041333L, a) >= 1) {
            this.r();
            this.o();
         }
      }
   }

   private boolean O(ChestMenu container, int slot) {
      long a = 树何友何友何何何友树.a ^ 112653257478058L;
      d<"ÿ">(7897072251267658535L, a);
      ItemStack stack = container.getSlot(0).getItem();
      if ((this.k(stack) || d<"E">(this, 7897607468446756741L, a).getValue()) && this.f(stack)) {
         this.U(container, slot);
         return true;
      } else {
         return false;
      }
   }

   private boolean K(ItemStack stack) {
      long a = 树何友何友何何何友树.a ^ 3526750968992L;
      long ax = a ^ 88539049271634L;
      long axx = a ^ 104127356532076L;
      long axxx = a ^ 4750671928797L;
      long var10001 = a ^ 80968836791742L;
      int axxxx = (int)((a ^ 80968836791742L) >>> 32);
      int axxxxx = (int)((a ^ 80968836791742L) << 32 >>> 48);
      int axxxxxx = (int)(var10001 << 48 >>> 48);
      long axxxxxxx = a ^ 128764416535741L;
      long axxxxxxxx = a ^ 132649981797562L;
      long axxxxxxxxx = a ^ 91901325152959L;
      long axxxxxxxxxx = a ^ 850969530190L;
      long axxxxxxxxxxx = a ^ 77301816303607L;
      d<"ÿ">(9120471076814397485L, a);
      if (stack.getItem() instanceof SwordItem) {
         return 友何树何友树友树何何.A(stack) >= 友何树何友树友树何何.e(axxxxxxx);
      } else {
         if (stack.getItem() instanceof DiggerItem) {
            if (stack.getItem() instanceof PickaxeItem) {
               return 友何树何友树友树何何.K(stack) >= 友何树何友树友树何何.n(axx);
            }

            if (stack.getItem() instanceof AxeItem) {
               return 友何树何友树友树何何.K(stack) >= 友何树何友树友树何何.F(axxxxxxxxxx);
            }

            if (stack.getItem() instanceof ShovelItem) {
               return 友何树何友树友树何何.K(stack) >= 友何树何友树友树何何.l(axxxxxxxx);
            }
         } else {
            if (stack.getItem() instanceof ArmorItem item) {
               float protection = 友何树何友树友树何何.C(stack);
               float bestArmor = 友何树何友树友树何何.r(item.getEquipmentSlot(), axxxxxxxxxxx);
               return protection >= bestArmor;
            }

            if (stack.getItem() instanceof BowItem) {
               if (友何树何友树友树何何.j(stack, ax)) {
                  return 友何树何友树友树何何.E(stack) >= 友何树何友树友树何何.d(axxxx, (short)axxxxx, (char)axxxxxx);
               }

               if (友何树何友树友树何何.n(axxxxxxxxx, stack)) {
                  return 友何树何友树友树何何.Y(stack) >= 友何树何友树友树何何.y(axxx);
               }
            }
         }

         return true;
      }
   }

   private static String LIU_YA_FENG() {
      return "何炜霖国企上班";
   }
}
