package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.何树何树友树树友树友;
import cn.cool.cherish.utils.player.树友友何树友树树树何;
import cn.cool.cherish.utils.render.友友树何树树友树友何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.树友何友何何友树树友;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import cn.lzq.injection.asm.invoked.render.RenderPickEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class 友树何何何何何树树何 extends Module implements 何树友 {
   public static 友树何何何何何树树何 树树何树何友树树友树;
   private final ModeValue 友树何树友友树何友树;
   private final BooleanValue 友树友树何何友友友何;
   private final BooleanValue 何何树友何树友何树友;
   private final BooleanValue 树友友何何何树友友树;
   private final BooleanValue 友友何树友树友友树树;
   private final BooleanValue 树树何树何友树树树何;
   private final BooleanValue 树友树树树友何树树何;
   private final BooleanValue 树何何树友何何友何友;
   private final BooleanValue 树何树何树何友何何何;
   private final BooleanValue 友友友树树友何树树树;
   private final BooleanValue 何何何何友何树友友树;
   private final BooleanValue 树友友友何友树友何树;
   private final 树友何友何何友树树友 何树友树友友树何友树;
   private final NumberValue 友友何树友友友树何何;
   private BlockPos 树何树树树何树友树何;
   private BlockPos 树树友树友何树树何树;
   private Vec3 何友何友树树树树何友;
   private final 树友树友友何何树何何 友友树何树友何友何何;
   private boolean 何友何树何友何树树何;
   private float 树友树树树何树何何树;
   private Rotation 树何何友何树何树树友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[74];
   private static final String[] l = new String[74];
   private static String HE_SHU_YOU;

   public 友树何何何何何树树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/友树何何何何何树树何.a J
      // 003: ldc2_w 56409810095144
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 935547786898
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 146
      // 014: ldc2_w 8396920025739006471
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 15915
      // 021: ldc2_w 5565095725715172533
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -4818890577866694158
      // 02e: lload 1
      // 02f: invokedynamic ÿ (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/ModeValue
      // 03b: dup
      // 03c: sipush 14585
      // 03f: ldc2_w 1703594139485579892
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 18119
      // 04c: ldc2_w 1499755195477742660
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 2
      // 057: anewarray 109
      // 05a: dup
      // 05b: bipush 0
      // 05c: sipush 3680
      // 05f: ldc2_w 3216676141680860403
      // 062: lload 1
      // 063: lxor
      // 064: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 069: aastore
      // 06a: dup
      // 06b: bipush 1
      // 06c: sipush 28223
      // 06f: ldc2_w 8631766639627009208
      // 072: lload 1
      // 073: lxor
      // 074: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 079: aastore
      // 07a: sipush 13689
      // 07d: ldc2_w 7629932956215846904
      // 080: lload 1
      // 081: lxor
      // 082: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 087: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 08a: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.友树何树友友树何友树 Lcn/cool/cherish/value/impl/ModeValue;
      // 08d: aload 0
      // 08e: new cn/cool/cherish/value/impl/BooleanValue
      // 091: dup
      // 092: sipush 4664
      // 095: ldc2_w 2248436056866619561
      // 098: lload 1
      // 099: lxor
      // 09a: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09f: ldc "床"
      // 0a1: bipush 1
      // 0a2: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0a5: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0a8: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.友树友树何何友友友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0ab: aload 0
      // 0ac: new cn/cool/cherish/value/impl/BooleanValue
      // 0af: dup
      // 0b0: sipush 27205
      // 0b3: ldc2_w 703277740795525335
      // 0b6: lload 1
      // 0b7: lxor
      // 0b8: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bd: sipush 26008
      // 0c0: ldc2_w 5482878614794106631
      // 0c3: lload 1
      // 0c4: lxor
      // 0c5: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ca: bipush 1
      // 0cb: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0ce: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0d1: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.何何树友何树友何树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0d4: aload 0
      // 0d5: new cn/cool/cherish/value/impl/BooleanValue
      // 0d8: dup
      // 0d9: sipush 15360
      // 0dc: ldc2_w 3566777174613175959
      // 0df: lload 1
      // 0e0: lxor
      // 0e1: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e6: sipush 14921
      // 0e9: ldc2_w 5779145227065501917
      // 0ec: lload 1
      // 0ed: lxor
      // 0ee: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f3: bipush 1
      // 0f4: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0f7: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0fa: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.树友友何何何树友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0fd: aload 0
      // 0fe: new cn/cool/cherish/value/impl/BooleanValue
      // 101: dup
      // 102: sipush 30574
      // 105: ldc2_w 5121944390375138794
      // 108: lload 1
      // 109: lxor
      // 10a: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 10f: sipush 18042
      // 112: ldc2_w 4490840814407898367
      // 115: lload 1
      // 116: lxor
      // 117: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11c: bipush 1
      // 11d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 120: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 123: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.友友何树友树友友树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 126: aload 0
      // 127: new cn/cool/cherish/value/impl/BooleanValue
      // 12a: dup
      // 12b: sipush 822
      // 12e: ldc2_w 2876489675295560124
      // 131: lload 1
      // 132: lxor
      // 133: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 138: sipush 17891
      // 13b: ldc2_w 3537355450566498149
      // 13e: lload 1
      // 13f: lxor
      // 140: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 145: bipush 0
      // 146: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 149: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 14c: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.树树何树何友树树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 14f: aload 0
      // 150: new cn/cool/cherish/value/impl/BooleanValue
      // 153: dup
      // 154: sipush 9304
      // 157: ldc2_w 4619151110848427712
      // 15a: lload 1
      // 15b: lxor
      // 15c: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 161: sipush 22965
      // 164: ldc2_w 9198075674512739133
      // 167: lload 1
      // 168: lxor
      // 169: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16e: bipush 1
      // 16f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 172: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 175: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.树友树树树友何树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 178: aload 0
      // 179: new cn/cool/cherish/value/impl/BooleanValue
      // 17c: dup
      // 17d: sipush 5792
      // 180: ldc2_w 6081878536448934946
      // 183: lload 1
      // 184: lxor
      // 185: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 18a: sipush 27723
      // 18d: ldc2_w 1335856423666581195
      // 190: lload 1
      // 191: lxor
      // 192: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 197: bipush 1
      // 198: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 19b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 19e: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.树何何树友何何友何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1a1: aload 0
      // 1a2: new cn/cool/cherish/value/impl/BooleanValue
      // 1a5: dup
      // 1a6: sipush 8102
      // 1a9: ldc2_w 7785705314114899216
      // 1ac: lload 1
      // 1ad: lxor
      // 1ae: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b3: sipush 18653
      // 1b6: ldc2_w 841286719709174349
      // 1b9: lload 1
      // 1ba: lxor
      // 1bb: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c0: bipush 1
      // 1c1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1c4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1c7: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.树何树何树何友何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1ca: aload 0
      // 1cb: new cn/cool/cherish/value/impl/BooleanValue
      // 1ce: dup
      // 1cf: sipush 4438
      // 1d2: ldc2_w 2967427011950674909
      // 1d5: lload 1
      // 1d6: lxor
      // 1d7: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1dc: sipush 21939
      // 1df: ldc2_w 5836821486925432622
      // 1e2: lload 1
      // 1e3: lxor
      // 1e4: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e9: bipush 1
      // 1ea: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1ed: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1f0: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.友友友树树友何树树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1f3: aload 0
      // 1f4: new cn/cool/cherish/value/impl/BooleanValue
      // 1f7: dup
      // 1f8: sipush 19915
      // 1fb: ldc2_w 8798477865350913861
      // 1fe: lload 1
      // 1ff: lxor
      // 200: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 205: sipush 7055
      // 208: ldc2_w 6261192826315442454
      // 20b: lload 1
      // 20c: lxor
      // 20d: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 212: bipush 1
      // 213: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 216: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 219: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.何何何何友何树友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 21c: aload 0
      // 21d: new cn/cool/cherish/value/impl/BooleanValue
      // 220: dup
      // 221: sipush 3002
      // 224: ldc2_w 8223844401545091379
      // 227: lload 1
      // 228: lxor
      // 229: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 22e: sipush 15119
      // 231: ldc2_w 345852544052275584
      // 234: lload 1
      // 235: lxor
      // 236: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23b: bipush 1
      // 23c: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 23f: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 242: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.树友友友何友树友何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 245: aload 0
      // 246: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 249: dup
      // 24a: sipush 14509
      // 24d: ldc2_w 2651152142335814177
      // 250: lload 1
      // 251: lxor
      // 252: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 257: sipush 7296
      // 25a: ldc2_w 5207942377577188886
      // 25d: lload 1
      // 25e: lxor
      // 25f: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 264: ldc2_w -4818954158245176219
      // 267: lload 1
      // 268: invokedynamic ÿ (JJ)Ljava/awt/Color; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 26d: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 270: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.何树友树友友树何友树 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 273: aload 0
      // 274: new cn/cool/cherish/value/impl/NumberValue
      // 277: dup
      // 278: sipush 8797
      // 27b: ldc2_w 3414632176246141121
      // 27e: lload 1
      // 27f: lxor
      // 280: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 285: sipush 10215
      // 288: ldc2_w 1354352325139248509
      // 28b: lload 1
      // 28c: lxor
      // 28d: invokedynamic j (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 292: ldc2_w 0.5
      // 295: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 298: ldc2_w 0.1
      // 29b: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 29e: dconst_1
      // 29f: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 2a2: ldc2_w 0.1
      // 2a5: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 2a8: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 2ab: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.友友何树友友友树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 2ae: aload 0
      // 2af: new cn/cool/cherish/utils/树友树友友何何树何何
      // 2b2: dup
      // 2b3: lload 3
      // 2b4: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 2b7: putfield cn/cool/cherish/module/impl/player/友树何何何何何树树何.友友树何树友何友何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 2ba: aload 0
      // 2bb: ldc2_w -4826296927672809334
      // 2be: lload 1
      // 2bf: invokedynamic ü (Lcn/cool/cherish/module/impl/player/友树何何何何何树树何;JJ)V bsm=cn/cool/cherish/module/impl/player/友树何何何何何树树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c4: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(3745787020786624720L, -1267886013458771080L, MethodHandles.lookup().lookupClass()).a(228344854835672L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var5 = a ^ 91563377895290L;
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(var5 << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[33];
      int var12 = 0;
      String var11 = "<¿\u001dï\u0011è\u009b®$\u0081\u001a¢\u0010Yk[ \u0084ª²êë¤m-ÁGq-@\u0013©GèÖÞ\u0098oà5J¤KXV\u008d6\u0096\u0001 \u0005Ú\u000f\u0090>Ón\u0097çÂä÷x\u000f\u0014)GÆ\u0097¤*£Óí*i\u009a¹8]´f\u0010\u0098\u0004¬þ\b\u001a«$G\u008f\u0001Xn\u0094¸a(\u000b'\u009c\r%>Á\u008dÖ'ßEQ\u000b¿\u0007\t¯±\u001c0N©ÿx®@Å¦hº\u0019\u0093\u0093i;ïÕãI\u0010M\u00131ïÀXÃ1¤\u0005â\u000bpLJO(pÄ\u0006\u008f\u0098\u008fN\u008bï\u0091 \u0005Pæ]ó\u008d¯\bnÆªÐrº7¾LöÍ\u0081i´@D\u009d2\u0099Æ\u0014\u0010]°\u001aF·Q´~Z,üChW¤¦ ñÈ\u0093ææp÷ñ\\Tî\u000fo2ýÃÝqåÎ\u00ad±Ö\u0014õ\u001e\u0019]j?§` f\u0003\u0089R\u000e¼\u0096º\u0080ÊfV\u00872\u0018aü#Ð\u0083\u0016Y'\u008bC)\u0085'¨Ê\u009e© 4yüj\u000fÃó*Õ\u0095\tF\u008b\u0084E¾YE\u0006\u0086\tÃÒ\u0088\u0082tõ2ÈK\u008aý \u009d\u001dÂþïï\u001e©¾°²\"Ø6þ£b,§[\u009c¼¤¿\u001cO\u001b£\u0010Ëw< î\u0000\u0019UáÁÇ÷ñb\u0014×Viü\u0092ñ\u0082í\u0089eT\u0003\u00809\u0002SÆ\u0080¨ùÎ\u0010å¢°\u0080¿þ\u0006ôßìÄÅG1dû\u0010\u0011\u009e ðZ·}\u0005ÅB¤à¦o\u001a\u0096(¦\"\u0086k³ä\u0006\u0006®:\u0092\u001f®\u0095\u0011<|Íe±\u0098ÝÙ@Ú\" D«>íÌ\u007f½4\u001d¿\u009cµµ0µÁâ«\u008cí\u0086Òs{\u009c\u0005q\u0096]Yá NÛ\u0081HNùÑ\u009aocÏ8¡}µ\u0000w1æ\u0014\u001eÛ\u008fÞ\u00adPG1÷¦\u0010è\u0003g\u001d-D½\u0083µ!|\u0010b\u000fés\u0018\f\u0086¤È n\u001a£{!#Êà!¢§Ð\u001aC]\u0016*n¾\u0010Â9ô~s\tUÊ¦\u0098+x\u0089àO\u00938\\üz&k8\nVH[\u001a\u00833\u0013ä\u009eó£Êôî\u0097V-Ý5µcé\u001f¥Â¢\u0019\u0092gÅ{A\u008f\nßá5N¹\u009fË\u0091\n\u0000c\b\u0018\u00905\u0010\u008f¿kl\u009dÍä\u0091ðåRÕ\u009d\u0093E\u0082\u0018mrö\u000f\u0003¶V\u0080¿\u009dI Ò~\u0005û\tfU\u0094\u0096Ùé\u0099\u0010%¬&Kví\tY\u008b\u008c\u00187ó\u009cÚ\u001c  \u001e`v\u0084³§wL\r/cýÒíV\u0092\u0012ô\u0094ËÓo\u0090w -û\u000f½\u0004K TPÇ.?\u0017E\u0093\u0099µ?\u0083\u0087%+ÂkÒAÝxP+\u0088\n\u0098\u0089:©²\u0094\u008e\u0010\u0099Xö\u009b:\u008déC\u000fão2ó÷\tð\u0010\u0083÷6´Ú°Tù3ð\u001d;}æ\u00006(\u000bD¢Îõä\u0083w¸å&Íc¿\\RÀ\u0098\u0001tº·\u001fÍ¤\u008eÌ~\u0006?Ð\u009b1>R¡\u0085ÞjÅ(u\u0091°d\u0007l\u0082@\u007f\n°ìÓ\u001b¦\u009aÃÎr³#ì\u0014Þ÷\u0097\u0001|\u0098¨\u0018´\u0013hl7àÀ§8\u0018\u0003ú8áý\u0014á\u0000Xe\u001aö¶KO¢©x\u0014æÒ\u0010þß";
      short var13 = 886;
      char var10 = 16;
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[33];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var5 << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{17, 119, 92, 19, -26, 22, -52, 105});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "+oÁËw\u008a\u009fõ÷T?`ÓÒkÈ t\u0092LàCÇ®Xsc:`ÅYØèÓÃéj\u0010\u0098Ò0\u008c\u0091Ë»wÙ\"J";
                  var13 = 49;
                  var10 = 16;
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void C(LivingUpdateEvent event) {
      long a = 友树何何何何何树树何.a ^ 104261201337846L;
      long ax = a ^ 116156959921635L;
      long axx = a ^ 118522753151038L;
      c<"y">(7836871628054727800L, a);
      if (!this.w(new Object[]{ax})) {
         this.T(c<"Ý">(this, 7838164138380710482L, a).getValue());
         if (c<"Ý">(this, 7843847249014057008L, a).Y(j, axx)) {
            if (!this.m(c<"Ý">(this, 7837014504879544578L, a)) || this.j(c<"Ý">(this, 7837014504879544578L, a)) > 4.5) {
               this.u();
               if (c<"Ý">(this, 7837500513963029881L, a)) {
                  c<"Ý">(c<"Ý">(mc, 7837307864579302357L, a), 7843988261743703098L, a).setDown(false);
                  c<"D">(this, false, 7837500513963029881L, a);
               }

               if (c<"Ý">(this, 7837014504879544578L, a) == null) {
                  return;
               }
            }

            if (c<"Ý">(this, 7836650401238129384L, a).getValue()) {
               this.D();
            }

            this.I();
         }
      }
   }

   private void D() {
      long a = 友树何何何何何树树何.a ^ 2167149146434L;
      long ax = a ^ 45471939598639L;
      long axx = a ^ 101444500303187L;
      c<"y">(4645029888639836364L, a);
      if (c<"Ý">(this, 4645168350158452150L, a) != null) {
         if (c<"Ý">(this, 4643823997962756583L, a).getValue()
            && c<"Ý">(this, 4642884661243750070L, a) != 0.0F
            && c<"Ý">(this, 4642884661243750070L, a) >= 0.99F) {
         }

         c<"D">(this, RotationUtils.Q(new Object[]{ax, Vec3.atCenterOf(c<"Ý">(this, 4645168350158452150L, a))}), 4642377612477823108L, a);
         Rotation var10000 = c<"Ý">(this, 4642377612477823108L, a);
         Object[] var10007 = new Object[]{null, null, null, null, null, 0.0F};
         var10007[4] = false;
         var10007[3] = true;
         var10007[2] = true;
         var10007[1] = axx;
         var10007[0] = var10000;
         RotationUtils.y(var10007);
      }
   }

   public void F() {
      long a = 友树何何何何何树树何.a ^ 29711355192527L;
      c<"y">(6195665489915622721L, a);
      this.j();
      if (c<"Ý">(this, 6196144842208054336L, a)) {
         c<"Ý">(c<"Ý">(mc, 6195528309615680236L, a), 6188566104077110531L, a).setDown(false);
         c<"D">(this, false, 6196144842208054336L, a);
      }
   }

   private BlockPos F(BlockPos bedPos) {
      long a = 友树何何何何何树树何.a ^ 36187853651210L;
      BlockPos targetPos = bedPos;
      c<"y">(-8341133785361945468L, a);
      boolean foundEmpty = false;
      int addX = -4;
      int addY = 0;
      int addZ = -4;
      BlockPos checkPos = bedPos.offset(-4, 0, -4);
      Block block = mc.level.getBlockState(checkPos).getBlock();
      if (block instanceof BedBlock) {
      }

      double distanceToCheck = mc.player.position().distanceTo(Vec3.atCenterOf(checkPos));
      if (distanceToCheck > 4.5) {
      }

      if (!this.V(checkPos)) {
      }

      if (block == c<"ÿ">(-8342139225772522880L, a) || block instanceof LiquidBlock) {
         foundEmpty = true;
      }

      double eyeDistance = mc.player.getEyePosition(1.0F).distanceTo(Vec3.atCenterOf(checkPos));
      if (eyeDistance > 4.5) {
      }

      BlockState blockState = mc.level.getBlockState(checkPos);
      float destroySpeed = blockState.getDestroySpeed(mc.level, checkPos);
      if (destroySpeed > Double.MIN_VALUE) {
         double var10000 = destroySpeed;
         targetPos = checkPos;
      }

      addZ++;
      addY++;
      addX++;
      if (!foundEmpty) {
         return targetPos.equals(bedPos) ? null : targetPos;
      } else {
         return bedPos;
      }
   }

   private void I() {
      long a = 友树何何何何何树树何.a ^ 90454705738995L;
      c<"y">(7333871951608153469L, a);
      if (c<"Ý">(this, 7334014948079161351L, a) != null) {
         c<"Ý">(this, 7332309463004565712L, a).getValue();
         boolean wasOnGround = mc.player.onGround();
         mc.player.setOnGround(true);
         String var6 = c<"Ý">(this, 7332929292124773207L, a).getValue();
         byte var7 = -1;
         switch (var6.hashCode()) {
            case -672743999:
               if (!var6.equals(b<"j">(12026, 1777277414162392250L ^ a))) {
                  break;
               }

               var7 = 0;
            case -1955878649:
               if (var6.equals(b<"j">(13689, 7629826265907822371L ^ a))) {
                  var7 = 1;
               }
         }

         switch (var7) {
            case 0:
               this.f();
            case 1:
               this.S();
            default:
               mc.player.setOnGround(wasOnGround);
         }
      }
   }

   private void S() {
      long a = 友树何何何何何树树何.a ^ 25241728954932L;
      c<"Ý">(c<"Ý">(mc, 4828419399537445911L, a), 4834959334763273208L, a).setDown(true);
      c<"D">(this, true, 4829597229123771067L, a);
      c<"D">(this, Math.min(1.0F, c<"Ý">(this, 4834825364446717376L, a) + 0.05F), 4834825364446717376L, a);
   }

   @EventTarget
   public void V(RenderPickEvent event) {
      long a = 友树何何何何何树树何.a ^ 116099832422889L;
      long ax = a ^ 104317454264828L;
      long axx = a ^ 113158425333119L;
      c<"y">(-3396525018290474905L, a);
      if (c<"Ý">(this, -3396386539847654115L, a) != null && !this.w(new Object[]{ax})) {
         Vec3 eye = mc.player.getEyePosition(1.0F);
         Rotation rotation = c<"Ý">(this, -3397608313508875956L, a).getValue() ? this.o() : c<"ÿ">(-3403250452674091610L, a);
         Vec3 rotationVector = RotationUtils.l(new Object[]{rotation, axx});
         double range = c<"Ý">(mc, -3397156427257863817L, a).getDestroyStage();
         Vec3 forward = eye.add(
            c<"Ý">(rotationVector, -3395763099952499509L, a) * range,
            c<"Ý">(rotationVector, -3403416820845498653L, a) * range,
            c<"Ý">(rotationVector, -3395914059254547974L, a) * range
         );
         BlockHitResult hitResult = 树友友何树友树树树何.f(mc.level, c<"Ý">(this, -3396386539847654115L, a), mc.player.getEyePosition(1.0F), forward);
         event.setHitResult(hitResult);
      }
   }

   private boolean V(BlockPos pos) {
      long a = 友树何何何何何树树何.a ^ 96516700446292L;
      c<"y">(-1197922168920240166L, a);
      Direction[] directions = new Direction[]{
         c<"ÿ">(-1197877210152327578L, a),
         c<"ÿ">(-1195855687319188119L, a),
         c<"ÿ">(-1196785197736191354L, a),
         c<"ÿ">(-1196487839599467616L, a),
         c<"ÿ">(-1197097483951814882L, a)
      };
      int var7 = directions.length;
      int var8 = 0;
      if (0 < var7) {
         Direction direction = directions[0];
         BlockPos neighborPos = pos.relative(direction);
         Block neighborBlock = mc.level.getBlockState(neighborPos).getBlock();
         if (neighborBlock instanceof BedBlock) {
            return true;
         }

         var8++;
      }

      return false;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 7;
               case 1 -> 16;
               case 2 -> 28;
               case 3 -> 35;
               case 4 -> 38;
               case 5 -> 54;
               case 6 -> 9;
               case 7 -> 31;
               case 8 -> 30;
               case 9 -> 12;
               case 10 -> 26;
               case 11 -> 6;
               case 12 -> 32;
               case 13 -> 14;
               case 14 -> 61;
               case 15 -> 0;
               case 16 -> 59;
               case 17 -> 1;
               case 18 -> 11;
               case 19 -> 2;
               case 20 -> 63;
               case 21 -> 23;
               case 22 -> 41;
               case 23 -> 39;
               case 24 -> 52;
               case 25 -> 51;
               case 26 -> 50;
               case 27 -> 56;
               case 28 -> 45;
               case 29 -> 34;
               case 30 -> 47;
               case 31 -> 57;
               case 32 -> 18;
               case 33 -> 36;
               case 34 -> 60;
               case 35 -> 5;
               case 36 -> 46;
               case 37 -> 17;
               case 38 -> 43;
               case 39 -> 44;
               case 40 -> 25;
               case 41 -> 29;
               case 42 -> 3;
               case 43 -> 15;
               case 44 -> 53;
               case 45 -> 21;
               case 46 -> 48;
               case 47 -> 37;
               case 48 -> 49;
               case 49 -> 4;
               case 50 -> 13;
               case 51 -> 58;
               case 52 -> 10;
               case 53 -> 24;
               case 54 -> 8;
               case 55 -> 22;
               case 56 -> 33;
               case 57 -> 20;
               case 58 -> 40;
               case 59 -> 55;
               case 60 -> 42;
               case 61 -> 19;
               case 62 -> 62;
               default -> 27;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12163;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友树何何何何何树树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友树何何何何何树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @EventTarget
   public void s(PacketEvent event) {
      long a = 友树何何何何何树树何.a ^ 46560443849696L;
      c<"y">(-6137177369256670610L, a);
      if (c<"Ý">(this, -6136967340699896054L, a).getValue() && c<"Ý">(this, -6137034509624533228L, a) != null) {
         if (event.getPacket() instanceof ClientboundPlayerPositionPacket) {
            Vec3 newPos = new Vec3(
               ((ClientboundPlayerPositionPacket)event.getPacket()).getX(),
               ((ClientboundPlayerPositionPacket)event.getPacket()).getY(),
               ((ClientboundPlayerPositionPacket)event.getPacket()).getZ()
            );
            double distance = mc.player.position().distanceTo(newPos);
            if (distance > 40.0) {
               c<"D">(this, newPos, -6137311885359390250L, a);
            }
         }
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友树何何何何何树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 221 && var8 != 'D' && var8 != 255 && var8 != 252) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 233) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'y') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 221) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'D') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 255) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private void f() {
      long a = 友树何何何何何树树何.a ^ 30299719752973L;
      long ax = a ^ 51239657208365L;
      long axx = a ^ 33575455023015L;
      PacketUtils.v(
         new Object[]{
            ax, new ServerboundPlayerActionPacket(c<"ÿ">(-6035300655084878131L, a), c<"Ý">(this, -6036531630758487559L, a), c<"ÿ">(-6035671102620206477L, a))
         }
      );
      mc.player.swing(c<"ÿ">(-6036948027921980390L, a));
      PacketUtils.v(
         new Object[]{
            ax, new ServerboundPlayerActionPacket(c<"ÿ">(-6043189734578832930L, a), c<"Ý">(this, -6036531630758487559L, a), c<"ÿ">(-6035671102620206477L, a))
         }
      );
      mc.player.swing(c<"ÿ">(-6036948027921980390L, a));
      c<"D">(this, null, -6036531630758487559L, a);
      c<"Ý">(this, -6043350358535788341L, a).U(axx);
      c<"D">(this, 0.0F, -6043323317347890439L, a);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "\u001aYYF\u001fc\u001aYN\u001a\u0013l\u0000\u0012Z\u0007\u0000f\u0010\u0012A\r\u0004o\u0018\u0012O\u0004\u001di\u001f\u0012o\u0004\u001di\u001fO";
      k[1] = "pJ\u0013(-/pJ\u0004t! j\u0001\u0010i2*z\u0001\u000bc6#r\u0001\u0005j/%u\u0001%j/%u";
      k[2] = "4&H\u007f6X;f\u0005t<E>;\u000e24X3=\nyw^:8\n2)[61\u0003nw佢伂厃伳受案叼厜伝伳";
      k[3] = " q\u0007)\"R\u0014R\bioY\u001eO\r4d\u001f\u0016R\u00002`TUp\u000b#y]\u001e\u0006";
      k[4] = "sI\u0001rF$|\tLyL9yTG?D$tRCt\u0007\"}WC?Y'q^Jc\u0007厀栁佲佺佄佼伞栁栶佺";
      k[5] = "\u00060a\u0014W?\r?p[+&\u0002%~\u0018\u001c\u0016\u00142r\u0005\r:\u0003?";
      k[6] = "T\u0012\u000e\u001c)$T\u0012\u0019@%+NY\u0019^-(T\u0003T\u007f-#_\u0014\bS\"9";
      k[7] = "_{U\f\u0018(_{BP\u0014'E0BN\u001c$_j\u000fm\u00055XqOQ";
      k[8] = boolean.class;
      l[8] = "java/lang/Boolean";
      k[9] = "\u001dRRn^<\u001dRE2R3\u0007\u0019E,Z0\u001dC\b\u000bV,>VV0Z;\u0014";
      k[10] = "O+I'\u0004\tO+^{\b\u0006U`^f\u001b\u0005\u000f\fQf\n\u000bq!N";
      k[11] = float.class;
      l[11] = "java/lang/Float";
      k[12] = "r-Xz\u001f>}m\u0015q\u0015#x0\u001e7\u0005%x/\u00057\u00184}3\u0013k^\u0003~7\u0017m\u0019>\u007f";
      k[13] = "sT]>)e|\u0014\u00105#xyI\u001bs0k|O\u0016s/g`V]\u001f)e|_\u00123\u0010k|O\u0016";
      k[14] = "9w\u001aW5(9w\r\u000b9'#<\r\u0016*$yV\u0007\u000b=\"#{\u0001\u0017";
      k[15] = "lm)U\u0010\u000eqxqwQ\u0003i~";
      k[16] = "\u001b>i)<?\u0014~$\"6\"\u0011#/d>?\u001c%+/}伅伭厛伒伟厘伅伭桁桖";
      k[17] = "\u0002=~4(L\u0002=ih$C\u0018v}u7I\bvzr<VB\u000eoyv";
      k[18] = "\u0000<3a.N\u0000<$=\"A\u001aw$#*B\u0000-i=&I\n<5*1\t)8**\u0011B\u0000=\"=&U";
      k[19] = "\u001f\rC\u0013G`\u0010M\u000e\u0018M}\u0015\u0010\u0005^^n\u0010\u0016\b^Ab\f\u000fC>]b\u001e\u0006\u001f&Ic\t\u0006";
      k[20] = double.class;
      l[20] = "java/lang/Double";
      k[21] = "NZA~I\u0005A\u001a\fuC\u0018DG\u00073P\u000bAA\n3O\u0007]XA栌叭伿另佡伺取样桻另";
      k[22] = "JH\u0011\u000b} E\b\\\u0000w=@UWFg;@JLF栃厄核叭叴伽佇桞佼佳";
      k[23] = "\u00005BJTF\u00005U\u0016XI\u001a~A\u000bKC\n~F\f@\\@\u0018_\u0010kJ\u001d%Z\u0010\u001d{\u0017 S";
      k[24] = "\u0012\u000f]K'g\u001dO\u0010@-z\u0018\u0012\u001b\u0006>i\u001d\u0014\u0016\u0006!e\u0001\r]e'l\u00147\u0012D=m";
      k[25] = "p\u0015W\u0005U\u0001p\u0015@YY\u000ej^TDJ\u0004z^jEL\rl\u0011@_Q\u0007p8BE\\";
      k[26] = ":#hLz\u000e:#\u007f\u0010v\u0001 hr\u0007c\u0010;4wLg\u0015;2s\u0001x\u000bz!}\u000frI\u0007#n\u0014r\u00156)i\fs78'e\u0007e&72u\ry75%w\u0007cC\u0015%h\u000bx\t";
      k[27] = "F^=r7QF^*.;^\\\u0015*03]FOg1/T\\R90;AMIg\u0011/T\\R\u00190;AMI\u000e=7]eT-9";
      k[28] = "+=&7\u0015I$}k<\u001fT! `z\u000fR!?{z\nJ)*m&Tt''i \u0013I&\u0006|=\u0016U";
      k[29] = "ZF\u0004\u0015WIQI\u0015Z6GZB\u0011\u0000";
      k[30] = "Evf\u0013A\u0004\u001e;;N.桺桧会桀佷叭桺桧桞伄*\u001f\u000f\u001d<$HC\u001e\u001d*";
      k[31] = "\u001b6\u001al} @{G1\u0012桞根叄格厖住桞根佚格U-vI}\u00186s?G|";
      k[32] = "A\f\u000ecR>\u001aAS>=桀厹叾佬伇你桀厹叾栨Z\f5\u0019FL8P$\u0019P";
      k[33] = "\u0017\u000eqNT\u0013M\u0016pZk0>7\rr+<1:KE\u0013O\u001cI-\u001f\u000bN\b";
      k[34] = "$_<\u001eZ?\u007f\u0012aC5厛栆厭栚佺佨厛叜厭佞'\u00044|\u0015~EX%|\u0003";
      k[35] = "\"E\u0019O\u001e\u0010eF\u0001\u0017|\u0012I\u0012XHBBI#\\L\u001a\u001agZ[N\u0010\u0018";
      k[36] = "UnG!x\u0011\\o\u0014l\n1#O*\u001d\nF\u001f$\n/lO\u001ewG";
      k[37] = "\u0011Er_b\u001eA\u0003y\\\u0001\f(\u0000zH|N\u0013\u0002yPas";
      k[38] = "bSo_7L9\u001e2\u0002X栲厚厡厓伻厛栲厚伿桉fiG:\u0019-\u00045V:\u000f";
      k[39] = "P-V\u0002S}\u000b`\u000b_<栃伶栅桰栢佡栃厨栅伴;\u0003+\u0002fTX]b\fg";
      k[40] = "@\u0019Y\u0002\u0007x\u001bT\u0004_h栆厸栱桿栢厫佂桢栱伻;Ys\u0018S\u001bY\u0005b\u0018E";
      k[41] = "g\u0003\f-oRn\u0002_`\u001dx\u0011'{Q,Og\u0004O7%N4I";
      k[42] = ">5vxoG2ydr\u000ef\u001a\b\u000f!\u007fEg%t-3Wm";
      k[43] = "(B,\nJ%([9\u001d.企厁句厔厧叭企伟栿厔dD89H3\u001dD!,_";
      k[44] = "unC\u001al\u0015zx[\u000e\u001d\u0017I5\u0019@-@I\u0005N\u0012l\u001e'y\u0013\u0012-\u0003";
      k[45] = "\u000b\u0010H]64P]\u0015\u0000Y厐右佼桮厧桀厐右核桮dh?SZ\n\u00064.SL";
      k[46] = "\u0003\u0017S\nVb\f\u0001K\u001e'`?L\tP\u0018??|^\u0002ViQ\u0000\u0003\u0002\u0017t";
      k[47] = "\u001fh/3>\u001dK>-f\u000ej4F\b\u0019\u000eO\u0019m*j3\u001bOo\u007f";
      k[48] = "\u0002^6\"wsY\u0013k\u007f\u0018}9Tw'{wASlk\"\u0014\u0002\u00115x{l\u0005\ny!\u0018";
      k[49] = "\u001fx\u000f@\rI\u0016y\\\r\u007fpcXb<NT\u001f\u007fLZGUL2";
      k[50] = "K~Fb@}\u00103\u001b?/佇伭桖厺伆栶叙伭桖厺[\u001ev\u00134\u00049Bg\u0013\"";
      k[51] = "e6T$kFl7\u0007i\u0019}\fMT#(\\&+]\"{\u0011";
      k[52] = "\u0011je\u001eReJ'8C=栛佷伆桃古你佟叩伆厙'\fnI 'EP\u007fI6";
      k[53] = "^(\u0005`BRW)V-0y&\bh\u001c\u0001O^/Fz\bN\rb";
      k[54] = "p\u007f\u0007\u001d>\u001a+2Z@Q厾桒伓校叧厒桤伖厍校$1@(~]\u001d4\u0012w)";
      k[55] = ";\u0018oz7pl\u0003dGdC:Q,~4C\u0007\u0010j:sxv\u0000d|";
      k[56] = "H\u001a\u0005\\}-A\u001bV\u0011\u000f\u0010><h`\u000fz\u0002PHRis\u0003\u0003\u0005";
      k[57] = "{'\u0011\u000e9\u0017g'\u0018_[(F\u0016&3\f?W\u0004 5\u001c\"M\u00158(\u00100\u001a>\u0004\u0002:\u0011~\"\u0004\u000bk";
      k[58] = "V\r\u000f\"_\u0011\u0011\u000e\u0017z=\u0013=ZN%\u0002G=k\u0015,\u0003\u000f\u0015\u000b\u0013lP\u0014";
      k[59] = "HQ3Fkn\u0013\u001cn\u001b\u0004佔厰伽叏桦栝栐桪伽叏\u007fob\u0013\u0006}\u0013`t\u000b\u0012";
      k[60] = "\bsSZr{S>\u000e\u0007\u001d佁台伟桵伾叞佁株桛伱c#!NrVRx|V;";
      k[61] = "cd\u0007\u0014\u0019x8)ZIv栆伅桌佥栴伫叜伅伈佥-Gs;.EO\u001bb;8";
      k[62] = "U\u00041G`\u001e\u0012\u0007)\u001f\u0002\u001c>Sp@<I>b\"\u0019x\u0002X\u0002v\nnM";
      k[63] = "G\r8\u0017\u0007{\u001c@eJh叟县叿栞样厫佁桥栥栞.Yp\u001fGzL\u0005a\u001fQ";
      k[64] = "\f\u0006KeR\u0012\u000b\u0004Ag+\u0005f\u000b\u0017;\u001aUf:\u0013gDU@QVxI\u0017";
      k[65] = "oO1IA14\u0002l\u0014.厕厗伣栗厳叭厕桍伣体pB.o\u001bu\nS:j\u001e";
      k[66] = "\f6|u)mW{!(F栓栮佚桚休厅栓栮叄桚L};\b>,+&vUc";
      k[67] = "3,\n\u007f\u000bI<:\u0012kzK\u000fwP%J\u001d\u000fG\u0007w\u000bBa;ZwJ_";
      k[68] = "\u0006cG\u000ei-].\u001aS\u0006众栤厑桡叴叅桓你厑桡7hw\u0004\"\u0012\t`(Sj";
      k[69] = "\u007f;q\u0005f\u0002\"0eDW\u0015z b\u00036\b{\\;\u0013>\r%-y\u0013<\u001f";
      k[70] = "\t\u000b\u001cV\u0013\tRFA\u000b|厭叱栣佾桶县伳叱佧佾o\u0012\u0010UWF\u001f\u0011\u000bXX";
      k[71] = "s4\u001djt`(y@7\u001b栞压栜栻桊但栞伕佘栻S${(=\u001flak\"b";
      k[72] = "I F\u000f,:\u0012m\u001bRC桄伯佌厺佫桚伀桫栈厺6s1\u001bsAG11\u0019a";
      k[73] = "`\u0011*|@\u0001|\u0011#-\">].\u001fJn(Z5\u001dZs2K-\u0000Vae`\u0011*|@\u0001|\u0011#-";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private boolean m(BlockPos pos) {
      long var10000 = 友树何何何何何树树何.a ^ 63987492909554L;
      return false;
   }

   public Rotation o() {
      long a = 友树何何何何何树树何.a ^ 101116061508456L;
      return c<"Ý">(this, -7906258425489806674L, a);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      this.j();
   }

   private void j() {
      long a = 友树何何何何何树树何.a ^ 20850086845570L;
      long ax = a ^ 26325383159336L;
      c<"D">(this, null, -1317611790301505418L, a);
      c<"D">(this, null, -1320369594177301180L, a);
      c<"D">(this, 0.0F, -1319902076219061386L, a);
      c<"D">(this, false, -1319509520842574835L, a);
      c<"Ý">(this, -1319909119906027196L, a).U(ax);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private double j(BlockPos pos) {
      return mc.player.position().distanceTo(Vec3.atCenterOf(pos));
   }

   private void u() {
      long a = 友树何何何何何树树何.a ^ 139935959753184L;
      c<"y">(-3399082270131703698L, a);
      if (c<"Ý">(this, -3399172878770005034L, a) == null
         || !(mc.player.position().distanceTo(c<"Ý">(this, -3399172878770005034L, a)) < 35.0)
         || !c<"Ý">(this, -3399626039906645235L, a).getValue()) {
         c<"D">(this, c<"Ý">(this, -3398939273664174828L, a), -3397258333068359746L, a);
         c<"D">(this, this.Y(), -3398939273664174828L, a);
         if (c<"Ý">(this, -3397258333068359746L, a) != c<"Ý">(this, -3398939273664174828L, a) && !c<"Ý">(this, -3399717545591246602L, a).getValue()) {
            c<"D">(this, 0.0F, -3401156985540790764L, a);
         }
      }
   }

   private BlockPos Y() {
      long a = 友树何何何何何树树何.a ^ 85380834258320L;
      long ax = a ^ 137747519838440L;
      long axx = a ^ 111070280861181L;
      c<"y">(2063838631916698654L, a);
      if (!c<"Ý">(this, 2064300171240988705L, a).getValue()) {
         return null;
      } else {
         List<BlockPos> bedPositions = new ArrayList<>();
         int bedCount = 0;
         int x = -5;
         int y = -5;
         int z = -5;
         BlockPos pos = mc.player.blockPosition().offset(-5, -5, -5);
         Block block = mc.level.getBlockState(pos).getBlock();
         if (block instanceof BedBlock) {
            if (++bedCount > 1) {
               double distance = this.j(pos);
               label36:
               if (!(distance > 4.5)) {
                  if (!c<"Ý">(this, 2064371087201792715L, a).getValue()) {
                     HitResult result = 何树何树友树树友树友.s(RotationUtils.Q(new Object[]{axx, Vec3.atCenterOf(pos)}), ax, 4.5, 0.0F, mc.player, null, false);
                     if (result.getType() != c<"ÿ">(2064545873796041725L, a)) {
                        break label36;
                     }

                     BlockPos hitPos = ((BlockHitResult)result).getBlockPos();
                     if (!hitPos.equals(pos)) {
                        break label36;
                     }
                  }

                  if (c<"Ý">(this, 2065732713099084585L, a).getValue()) {
                     BlockPos resultPos = this.F(pos);
                     if (resultPos != null) {
                        return resultPos;
                     }
                  }

                  bedPositions.add(pos);
               }
            }
         }

         z++;
         y++;
         x++;
         return bedPositions.isEmpty() ? null : bedPositions.stream().min((axxx, b) -> Double.compare(this.j(axxx), this.j(b))).orElse(null);
      }
   }

   @EventTarget
   public void L(Render3DEvent event) {
      long a = 友树何何何何何树树何.a ^ 63456980639978L;
      long ax = a ^ 16223958018303L;
      long axx = a ^ 82050346580771L;
      c<"y">(-3324133313922289308L, a);
      if (!this.w(new Object[]{ax}) && c<"Ý">(this, -3324074569286670997L, a).getValue() && c<"Ý">(this, -3323994835413015522L, a) != null) {
         PoseStack poseStack = event.poseStack();
         Vec3 cameraPos = c<"Ý">(mc, -3325742102093849000L, a).getMainCamera().getPosition();
         double renderX = c<"Ý">(this, -3323994835413015522L, a).getX() - c<"Ý">(cameraPos, -3324638034036738616L, a);
         double renderY = c<"Ý">(this, -3323994835413015522L, a).getY() - c<"Ý">(cameraPos, -3330426974653567008L, a);
         double renderZ = c<"Ý">(this, -3323994835413015522L, a).getZ() - c<"Ý">(cameraPos, -3324753807909340935L, a);
         poseStack.pushPose();
         poseStack.translate(renderX, renderY, renderZ);
         Color color = c<"Ý">(this, -3330942748392155499L, a).getValue();
         Color progressColor = new Color(
            color.getRed(), color.getGreen(), color.getBlue(), (int)(c<"Ý">(this, -3330597279091034665L, a).getValue().floatValue() * 255.0F)
         );
         友友树何树树友树友何.A(poseStack, new AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0), true, color.getRGB(), axx);
         if (c<"Ý">(this, -3330711755161159906L, a) > 0.0F) {
            友友树何树树友树友何.A(poseStack, new AABB(0.0, 0.0, 0.0, 1.0, c<"Ý">(this, -3330711755161159906L, a), 1.0), false, progressColor.getRGB(), axx);
         }

         poseStack.popPose();
      }
   }

   private static String LIU_YA_FENG() {
      return "何炜霖诈骗";
   }
}
