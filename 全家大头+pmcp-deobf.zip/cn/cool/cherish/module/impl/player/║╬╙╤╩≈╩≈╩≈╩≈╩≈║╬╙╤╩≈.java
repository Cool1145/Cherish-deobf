package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;
import why.tree.friend.antileak.Fucker;

public class 何友树树树树树何友树 extends Module implements 何树友 {
   public static 何友树树树树树何友树 友友树树何树何树友友;
   public final ModeValue 何友友何树树树树友树 = new ModeValue("Mode", "模式", new String[]{"Grim 1.17+", "Extra", "Semi Ground", "No Ground"}, "Grim 1.17+");
   private final BooleanValue 何何何树友何树树何友 = new BooleanValue("Grim Auto Disable", "Grim自动关闭", false).A(() -> this.何友友何树树树树友树.K("Grim 1.17+"));
   private final BooleanValue 友何何何树树友树何何 = new BooleanValue("Skip Tick", "跳过间隔", true).A(() -> this.何友友何树树树树友树.K("Grim 1.17+"));
   private final BooleanValue 友树何何何友树何友何 = new BooleanValue("Meme Suffix", "搞笑后缀", false).A(() -> this.何友友何树树树树友树.K("Grim 1.17+"));
   private final NumberValue 友友树树树树友友树何 = new NumberValue("Distance", "工作距离", 3.3, 0, 5, 0.1).A(() -> {
      树友何何友何树何树友.E();
      return !this.何友友何树树树树友树.K("No Ground");
   });
   public boolean 何何何树何何友友何树 = false;
   private boolean 何何树树树何友友树友 = false;
   private boolean 友友友树何树友何何树 = false;
   public boolean 友何何树友友树友友何 = false;
   private boolean 友树友树友何友友何何 = false;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[35];
   private static final String[] k = new String[35];
   private static int _解放村多种2队1144号 _;

   public 何友树树树树树何友树() {
      super("NoFall", "防止掉落伤害", 树何友友何树友友何何.友树树友何友何树友树);
      友友树树何树何树友友 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6881930294033049163L, -3911923918855857006L, MethodHandles.lookup().lookupClass()).a(16118159278136L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(80988835924928L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[21];
      int var7 = 0;
      String var6 = "´ßÌ\r\t\u0080¡´}J \b\u0003Bz\u0097\n1ãdy¯\u0093fU\u0005ÕÜö<Ó\n(\u008eÉ\u008d»\bZ¹rNo\u001eët\u0090~a5½AÒõÃÄS\u0005¢\u000e³Ù³#\u0013ÖãçÝ\u0080©Î\t\u0010\u001eÇº¤øQ\u0013©úz»\u0007gxY\u0093\u0010\u0097\u0015ógqPû=\u0086ÁZJ½\u0088Ú© js\u0093\u0080\u0080¶Ñ\u0080BjÁ¾dÜ\u0001\n0\u008dÛy«\u0087î\u008eÜBã¬£+tÈ \u0080Un·ë¬<i\u0013C¢Ë¸Ë:7\u0097ìÏG\u0090¸þÑ-v2\u0014ÇKwr b´ËÂ^ÏÙÇ`0'Í8i\\!(\u0091NFÄc\u000fqÿHs¯\u0094¦\u009eé\u0018BG\u009e'\u000f´^\u0012\u0013F7BcHÂ<SO\"$õÉ^7 I5½·¦!øq¥\u0090\u008a\u009cÂà\u0005\u008e0 ÖÎ,\t²Â\u0096ÈÂWË\u009fhÒ\u0010KÔZÖà\u0015\u0089æ\u008e¥;\u00975ÃD\u0010\u0010/9@/\\\u0005hg)ìsAé\u0004\u008e¡\u0018½hbA\u001bÔ³à\u001b\u0010äÎ\u0084CÊJBdý\u0081\u0013ñ:M\u0018àêâ»\u0019\u0086gS¦\u0085°fcÕ\n³bëæ\u0082\u0088¯\u0011\u0013 b\u0091\u0092\u0010ë\u0085\u000efØ&ªt'/º\u001cþùNþ\u001ep\u0003ÿ\u0014ãlLÓ»<ÊPó:\u0004\u0093t\u008b\u00ad\"\u0010BûØ`f\u008eí;\u0017%Øw\u008cØ\u0003·\u008aaÓ\u008d\u009d5X\u0094Y\u0001¦%ñ¸IóNfC¬×¸À\u0093±K\u0010óèôd\u0003Ì{<ÙÛNÃ=!z\u0006$\u0088ÁÉÔ\u0091ü]óºZ  §\n\u001e2Ï@Í !(\u001dbøðh\u0080·\"5Ò\u000eï \u0097\rÄYwÜ\u001bp@\u0010íÉÑÉâ\u0016·eûç@á=]J£ \u000bÐ»¤ä²¡1·#\t\u0011 wM\u0090¸÷>õr\u009f\u001d¦\n.ë^\f\u0083¸r \u0016ÐM.¶{«¨lä1£\u0089ú\u0092\u001cçÜ\u0003~Í\b\tn°\u0006&Ü\fD\u0098=";
      short var8 = 578;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[21];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\tÏz1K4ó¼®p£>¨//j|u\u0080êºÓ\u0012ÒàÄ\u0005&\u0014\\N&(1½N%xB\u009dãmB¼Ü\u0011ÃÃ\u0085¼#9r\u0095\u008bsð\u0018\u0089T\u0018ÈÜZ¼\u0097Ç]\u009c\u001d\b\u001aþ";
                  var8 = 73;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void F(TickEvent event) {
      树友何何友何树何树友.E();
      if (this.友树何何何友树何友何.getValue()) {
         if (this.何友友何树树树树友树.K("Grim 1.17+")) {
            this.X("Latest Grim 1.17+ NoGround NoFall Disabler");
         }

         this.X(this.何友友何树树树树友树.getValue());
      }

      this.X(this.何友友何树树树树友树.getValue());
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin) {
         if (this.何友友何树树树树友树.K("Grim 1.17+") && this.何何树树树何友友树友 && this.友何何树友友树友友何) {
            this.友树友树友何友友何何 = true;
            this.友何何树友友树友友何 = false;
            this.何何树树树何友友树友 = false;
            PacketUtils.a(112543050219290L, new StatusOnly(false));
            if (this.友何何何树树友树何何.getValue()) {
               WrapperUtils.s(1);
            }
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 0;
               case 1 -> 22;
               case 2 -> 34;
               case 3 -> 59;
               case 4 -> 29;
               case 5 -> 39;
               case 6 -> 28;
               case 7 -> 47;
               case 8 -> 36;
               case 9 -> 54;
               case 10 -> 26;
               case 11 -> 40;
               case 12 -> 63;
               case 13 -> 12;
               case 14 -> 8;
               case 15 -> 18;
               case 16 -> 9;
               case 17 -> 19;
               case 18 -> 6;
               case 19 -> 10;
               case 20 -> 14;
               case 21 -> 33;
               case 22 -> 31;
               case 23 -> 32;
               case 24 -> 41;
               case 25 -> 61;
               case 26 -> 23;
               case 27 -> 58;
               case 28 -> 53;
               case 29 -> 35;
               case 30 -> 11;
               case 31 -> 25;
               case 32 -> 62;
               case 33 -> 44;
               case 34 -> 49;
               case 35 -> 55;
               case 36 -> 27;
               case 37 -> 50;
               case 38 -> 51;
               case 39 -> 7;
               case 40 -> 24;
               case 41 -> 3;
               case 42 -> 37;
               case 43 -> 56;
               case 44 -> 21;
               case 45 -> 13;
               case 46 -> 57;
               case 47 -> 17;
               case 48 -> 20;
               case 49 -> 60;
               case 50 -> 43;
               case 51 -> 30;
               case 52 -> 45;
               case 53 -> 5;
               case 54 -> 16;
               case 55 -> 42;
               case 56 -> 15;
               case 57 -> 1;
               case 58 -> 4;
               case 59 -> 2;
               case 60 -> 52;
               case 61 -> 46;
               case 62 -> 38;
               default -> 48;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树树何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5373;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树树何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[ù~\u0002\u0080¯Ì4\u008b\u0001ó#Ä\u001cFå\u0018, µc4ãüá ?R)\u0005S\u0088î;-")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何友树树树树树何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 231 && var8 != 'F' && var8 != 'N' && var8 != 165) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 232) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 192) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 231) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'F') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'N') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @Override
   public void h() {
      this.k();
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "E#x>*fJc55 {O>>s(fB8:8k`K=:s5eG43/k作叭桜桇桌桔栘佳历桇";
      j[1] = boolean.class;
      k[1] = "java/lang/Boolean";
      j[2] = "$\rO\u001bd-/\u0002^T\u00184 \u0018P\u0017/\u00046\u000f\\\n>(!\u0002";
      j[3] = "C\u001c>~*`L\\su }I\u0001x3(`D\u0007|xkfM\u0002|35cA\u000buok栞叫伧佅取伐栞併档叛";
      j[4] = "MT\u001b\rBkyw\u0014M\u000f`sj\u0011\u0010\u0004&{w\u001c\u0016\u0000m8U\u0017\u0007\u0019ds#";
      j[5] = "kXY6\u001a\u0002d\u0018\u0014=\u0010\u001faE\u001f{\u0018\u0002lC\u001b0[\u0004eF\u001b{\u0005\u0001iO\u0012'[伸參栧桦桄桤桼佝叽桦q厾桼佝叽桦厞桤伸參栧";
      j[6] = "\u000b-";
      j[7] = "RWB(uW]\u0017\u000f#\u007fJXJ\u0004elY]L\tesUAUB\u0006u\\To\r'o]";
      j[8] = "\u000fgyQ\u0011!\u0000'4Z\u001b<\u0005z?\u001c\b/\u0000|2\u001c\u0017#\u001ceyp\u0011!\u0000l6\\(/\u0000|2";
      j[9] = "Gr/\u0014p>H2b\u001fz#MoiYi0HidYv<Tp/9j<Fys!~=Qy";
      j[10] = "1?\u0015d-\u001f1?\u00028!\u0010+t\u0002&)\u00131.O:,\u0017&?\u0013d\f\u0019<;\r\u001a,\u0017&?\u0013";
      j[11] = float.class;
      k[11] = "java/lang/Float";
      j[12] = "%7B\u0000)q*w\u000f\u000b#l/*\u0004M+q\",\u0000\u0006h栏伓厒厧伶桗叕厍伌伹";
      j[13] = "}zzQ;,}zm\r7#g1m\u0013? }k 2?+v||\u001e01";
      j[14] = "g^m{\u00037g^z'\u000f8}\u0015z9\u0007;gO7\u001a\u001e*`Tw&";
      j[15] = "\rM@mw\u0014\rMW1{\u001b\u0017\u0006W/s\u0018\r\\\u001a\b\u007f\u0004.ID3s\u0013\u0004";
      j[16] = "@\u0006cN/KK\tr\u0001NE@\u0002v[";
      j[17] = "\u001e\u0001z9OH\u0018R?]佾佾伯桴佛伀叠叠伯桴\u0006&\u001fE\r\u0015`9RX";
      j[18] = "J\u000e5Bg)L]p&bB\u001f\u001a4It{W\u001erM\u000b{^\u001f&Y23ZY\"&";
      j[19] = "?\u0017<\u00169\r9Dyr厖伻伎伦桙桫厖桿伎伦@O1Z-\u0018\"\u0015>\u0016k";
      j[20] = "u\u00054fKTsVq\u0002佺叼叚伴桑栛栾栦叚桰H?E\u0001{\u0000'g\u001cOz";
      j[21] = "V :j\fn]~u{q\u001al+0iA,\n!ly\u001bW";
      j[22] = "uIS\u001b3(s\u001a\u0016\u007f厜伞佄格召厼框厀叚佸/\u0004c%f]I\u001b.8";
      j[23] = "p\u001drk\u0005(vN7\u000f厪桚叟桨反佒厪厀佁伬\u000etU%c\thk\u00188";
      j[24] = "9l\u001ak2\u000e??_\u000f厝厦桌栙伻栖伃桼厖參fc2\u00191l\rea\\";
      j[25] = "Z\nh^:`\\Y-:厕又栯桿栍栣厕又栯伻\u0014\u000467J\trS1b_";
      j[26] = "p/z7n\nv|?S佟似栅桚栟伎叁厢栅厀\u0006(>\u0007c;`7s\u001a";
      j[27] = "W)y+\u001f1Qz<O伮伇佦桜叆伒桪桃佦历\u0005r\u0017fE&g(\u0018*\u0003";
      j[28] = "sqk6\u000ee)oj\"ll\u0015\"/\u007fR<\u0015\u0013\u007fv\u00169})y7\u001d`";
      j[29] = "9B2\u0001\u001aR=\u001f:['根佟栽栛史栾根栛佹栛1\u001bIlOsKV_8^";
      j[30] = "1\u0006[o\u0017Mj\u0017@nrIYR\u0014oB\u0016Yk\u0015o\u0003Je\bU?\u000fY";
      j[31] = "RL.\u001b~ET\u001fk\u007f发样佣佽伏厼栋佳叽佽RBv\u0012@C0\u0018y^\u0006";
      j[32] = "\u0018o\\|%`I>_oK叛栱栗句佐厈佅栱反栿\r{yR\u007fHu*(Ql";
      j[33] = ";\u0004\u0007&\u0006[=WBB厩右厔桱伦桛厩佭伊桱{9VV(\u0010\u001d&\u001bK";
      j[34] = "NSf(L\u0005H\u0012mqsQpS&+C\u000epbuhKF\u001c\u0002#rOD";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void k() {
      树友何何友何树何树友.E();
      if (this.友友友树何树友何何树) {
         this.友友友树何树友何何树 = false;
         WrapperUtils.M(1.0F);
      }

      this.何何树树树何友友树友 = false;
      this.友何何树友友树友友何 = false;
      this.何何何树何何友友何树 = false;
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public boolean r() {
      return this.友树友树友何友友何何;
   }

   @Override
   public void M() {
      this.k();
   }

   @EventTarget
   public void R(MotionEvent event) {
      树友何何友何树何树友.E();
      if (event.isPre()) {
         String var9 = this.何友友何树树树树友树.getValue();
         byte var10 = -1;
         switch (var9.hashCode()) {
            case 563981207:
               if (!var9.equals("Grim 1.17+")) {
                  break;
               }

               var10 = 0;
            case 1407612102:
               if (!var9.equals("No Ground")) {
                  break;
               }

               var10 = 1;
            case -2146931079:
               if (!var9.equals("Semi Ground")) {
                  break;
               }

               var10 = 2;
            case 67412976:
               if (var9.equals("Extra")) {
                  var10 = 3;
               }
         }

         switch (var10) {
            case 0:
               if (this.Q(new Object[]{52406761729175L}) || !(Boolean)Fucker.isLogin) {
                  return;
               }

               if (!this.友何何树友友树友友何 && mc.player.fallDistance > this.友友树树树树友友树何.getValue().doubleValue() && !event.isOnGround()) {
                  this.友何何树友友树友友何 = true;
                  this.何何树树树何友友树友 = false;
                  this.何何何树何何友友何树 = false;
               }

               if (!this.友何何树友友树友友何 || !event.isOnGround()) {
                  break;
               }

               event.setOnGround(false);
               if (this.何何何树何何友友何树) {
                  break;
               }

               PacketUtils.F(new Pos(event.getX() + 10000.0, event.getY(), event.getZ() + 10000.0, false), 123291986768823L);
               this.何何何树何何友友何树 = true;
            case 1:
               event.setOnGround(false);
            case 2:
               if (!(mc.player.fallDistance > this.友友树树树树友友树何.getValue().doubleValue()) || event.isOnGround()) {
                  break;
               }

               PacketUtils.F(new StatusOnly(true), 123291986768823L);
               WrapperUtils.s(1);
            case 3:
               if (mc.player.fallDistance >= this.友友树树树树友友树何.getValue().doubleValue() && !event.isOnGround()) {
                  WrapperUtils.M(0.5F);
                  this.友友友树何树友何何树 = true;
                  PacketUtils.F(new StatusOnly(true), 123291986768823L);
                  mc.player.fallDistance = 0.0F;
               }

               if (this.友友友树何树友何何树) {
                  WrapperUtils.M(1.0F);
                  this.友友友树何树友何何树 = false;
               }
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "何大伟：我要教育何炜霖";
   }

   @EventTarget
   public void G(StrafeEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin) {
         if (mc.player.onGround() && this.友树友树友何友友何何 && !mc.options.keyJump.isDown()) {
            mc.player.jumpFromGround();
            if (this.何何何树友何树树何友.getValue() && this.isEnabled()) {
               this.J(false);
            }

            this.友树友树友何友友何何 = false;
         }
      }
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   @EventTarget
   public void O(PacketEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin) {
         switch (何友树树树树树何友树$友树何友树友树何友树.树何树树友树树树何树[event.getSide().ordinal()]) {
            case 1:
               if (!this.友何何树友友树友友何 || !this.何何何树何何友友何树 || this.何何树树树何友友树友 || !(event.getPacket() instanceof ServerboundMovePlayerPacket)) {
                  break;
               }

               event.setCancelled(true);
            case 2:
               if (this.友何何树友友树友友何 && event.getPacket() instanceof ClientboundPlayerPositionPacket) {
                  this.何何树树树何友友树友 = true;
               }
         }
      }
   }
}
