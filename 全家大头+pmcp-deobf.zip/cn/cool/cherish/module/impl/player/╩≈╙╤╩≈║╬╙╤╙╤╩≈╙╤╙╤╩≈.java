package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.world.item.ItemStack;

public class 树友树何友友树友友树 extends Module implements 何树友 {
   private final ModeValue 何何友友何友友友何友;
   private final NumberValue 友何何友何友友友友树;
   private final NumberValue 友树何树友树树树何何;
   private final NumberValue 友友友友树树树何友树;
   private final BooleanValue 友树友友树树友树何友;
   private final BooleanValue 友何何树树何何树树友;
   private final 树友树友友何何树何何 友何何树何树树树树友;
   private final 树友树友友何何树何何 树友何友何友树何友树;
   private int 树树何何友何何树何树;
   private boolean 友树友树树友友友友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[36];
   private static final String[] l = new String[36];
   private static String HE_WEI_LIN;

   public 树友树何友友树友友树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/树友树何友友树友友树.a J
      // 003: ldc2_w 121644478440246
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 8462074163435
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 6121
      // 014: ldc2_w 8757769274782752224
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 24816
      // 021: ldc2_w 2380821272012286659
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w 6587279798688990307
      // 02e: lload 1
      // 02f: invokedynamic D (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/ModeValue
      // 03b: dup
      // 03c: sipush 17075
      // 03f: ldc2_w 5267840305751181494
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 6823
      // 04c: ldc2_w 6533516933957619893
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 2
      // 057: anewarray 83
      // 05a: dup
      // 05b: bipush 0
      // 05c: sipush 16394
      // 05f: ldc2_w 8209384272158935580
      // 062: lload 1
      // 063: lxor
      // 064: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 069: aastore
      // 06a: dup
      // 06b: bipush 1
      // 06c: sipush 21005
      // 06f: ldc2_w 4636041134334892051
      // 072: lload 1
      // 073: lxor
      // 074: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 079: aastore
      // 07a: sipush 16394
      // 07d: ldc2_w 8209384272158935580
      // 080: lload 1
      // 081: lxor
      // 082: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 087: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 08a: putfield cn/cool/cherish/module/impl/player/树友树何友友树友友树.何何友友何友友友何友 Lcn/cool/cherish/value/impl/ModeValue;
      // 08d: aload 0
      // 08e: new cn/cool/cherish/value/impl/NumberValue
      // 091: dup
      // 092: sipush 19011
      // 095: ldc2_w 4625777311165661298
      // 098: lload 1
      // 099: lxor
      // 09a: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09f: sipush 30327
      // 0a2: ldc2_w 5182039737789709383
      // 0a5: lload 1
      // 0a6: lxor
      // 0a7: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ac: sipush 500
      // 0af: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0b2: bipush 0
      // 0b3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0b6: sipush 3000
      // 0b9: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0bc: bipush 50
      // 0be: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0c1: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0c4: putfield cn/cool/cherish/module/impl/player/树友树何友友树友友树.友何何友何友友友友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 0c7: aload 0
      // 0c8: new cn/cool/cherish/value/impl/NumberValue
      // 0cb: dup
      // 0cc: sipush 23213
      // 0cf: ldc2_w 5189498038684602545
      // 0d2: lload 1
      // 0d3: lxor
      // 0d4: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d9: sipush 2658
      // 0dc: ldc2_w 7346287259319599217
      // 0df: lload 1
      // 0e0: lxor
      // 0e1: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e6: bipush 15
      // 0e8: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0eb: bipush 1
      // 0ec: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ef: bipush 120
      // 0f1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0f4: bipush 1
      // 0f5: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0f8: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0fb: putfield cn/cool/cherish/module/impl/player/树友树何友友树友友树.友树何树友树树树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 0fe: aload 0
      // 0ff: new cn/cool/cherish/value/impl/NumberValue
      // 102: dup
      // 103: sipush 5453
      // 106: ldc2_w 2387954586933632860
      // 109: lload 1
      // 10a: lxor
      // 10b: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 110: sipush 24614
      // 113: ldc2_w 2363196276268362291
      // 116: lload 1
      // 117: lxor
      // 118: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11d: bipush 100
      // 11f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 122: bipush 50
      // 124: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 127: sipush 500
      // 12a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 12d: bipush 10
      // 12f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 132: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 135: putfield cn/cool/cherish/module/impl/player/树友树何友友树友友树.友友友友树树树何友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 138: aload 0
      // 139: new cn/cool/cherish/value/impl/BooleanValue
      // 13c: dup
      // 13d: sipush 21755
      // 140: ldc2_w 943177365288312560
      // 143: lload 1
      // 144: lxor
      // 145: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14a: sipush 25650
      // 14d: ldc2_w 9017497358726458927
      // 150: lload 1
      // 151: lxor
      // 152: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 157: bipush 0
      // 158: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 15b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 15e: putfield cn/cool/cherish/module/impl/player/树友树何友友树友友树.友树友友树树友树何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 161: aload 0
      // 162: new cn/cool/cherish/value/impl/BooleanValue
      // 165: dup
      // 166: sipush 13994
      // 169: ldc2_w 4131116623935650990
      // 16c: lload 1
      // 16d: lxor
      // 16e: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 173: sipush 32219
      // 176: ldc2_w 4969551739057174491
      // 179: lload 1
      // 17a: lxor
      // 17b: invokedynamic t (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 180: bipush 0
      // 181: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 184: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 187: putfield cn/cool/cherish/module/impl/player/树友树何友友树友友树.友何何树树何何树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 18a: aload 0
      // 18b: new cn/cool/cherish/utils/树友树友友何何树何何
      // 18e: dup
      // 18f: lload 3
      // 190: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 193: putfield cn/cool/cherish/module/impl/player/树友树何友友树友友树.友何何树何树树树树友 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 196: aload 0
      // 197: new cn/cool/cherish/utils/树友树友友何何树何何
      // 19a: dup
      // 19b: lload 3
      // 19c: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 19f: putfield cn/cool/cherish/module/impl/player/树友树何友友树友友树.树友何友何友树何友树 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 1a2: aload 0
      // 1a3: bipush -1
      // 1a4: ldc2_w 6586706745843040604
      // 1a7: lload 1
      // 1a8: invokedynamic Z (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ad: aload 0
      // 1ae: bipush 0
      // 1af: ldc2_w 6587035682567932841
      // 1b2: lload 1
      // 1b3: invokedynamic Z (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/树友树何友友树友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b8: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6919893361143070929L, -2796122431777534656L, MethodHandles.lookup().lookupClass()).a(3469872259382L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var5 = a ^ 112711108987308L;
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(var5 << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[37];
      int var12 = 0;
      String var11 = "\u009a2Z\u0096 Å\u0091¾fS\u009a76Þ!¯¿L\u0017¶½&V\u0015:äÝôÂÅÑå _F\u0089X\f^¼Ñ4¤hcmJýx\u0000jÜó2ê\u0016rQò\u0098?f\u008f¥¸ Ëv\u0088E\bNZs6N\u0017C\u0007\u008d>\b^3ÕRÏ\u000f\u0084G\u008b!\u009cÞãF\u0011\u0094 RI\u009bNª\u0093SÂ-\u0084n°1\f\u008b\u0098VÇ\u0093í~\"\t¾ØE¯\u0010Ùæ\u0006Þ(\u009dGyp\u0097;\u0098&VlÒma\u0005y\u0086\u00adD\u007f¶äÖ\u0016Ý\u001e¬é\u0080\u0004-\u00ad:q¦o+i÷)o\u0018\u0005\u0002\u0096ÌÝÄ+(ê\u0007Í\u009e\u008f¨OÔ[l»\u0000\u008béÏ\u0003\u0018\u001d/Õ°\u0003¸àK\u0081\u000bÈ\u0095O¯²\u008c$s³+ÐH\u0088\u008a ¼¯\u009e\u0004íÉßé\u001a\u0092*ý\u0086\u0003üaJýß%swË©·*Ç½\u0013\u0090¬\u0098@\nª\u0013`ý*¨:TS.GJåÔÉ\u0089aw\"w\u0088Ú¼¢ \u001f\u007f²A×r\u0090w\u009f0Ì\u0011øg®°×ÃµT#\u00975Ï4ÿ=Uô.ó\u008c¥H7m³ù\u0010ÏwO%\u0090_¼ïÐC\u0006\u0087|B®*\u0018Éì\u0019\u0099Ôóq\u0095Hè\u008bº\u0088Cu\u0083@=qÍh@DÝ\u0018û\u0015ì>az\u0092Î;á7âL\u0080G\u0003\u008dpnob×cG\u0010L\u0013qôÊñ¸Ú\u00958N\u0001G\u0093\u0007\u0019\u0018¸\u0000]i^\u0017Â\u008aÀg\u0086\u0005|Ïy\u0013\u0012ÿ5ÐéWóy\u0018[Ä2¼fO\u008aÊ\u000bhM\u008fAd\\\\»ÙÂÇûqNÀ\u0018Ô\u0017ió\u000eB5¥U¿\u0095ª¦\u0006R«î´N.\u0091@\rm\u0018¸\u0007\u00105u6\u0085Ö$0\u0096³\u008dôm,\u0017P¿VB\u001a\u009f·\u0010aÚ\n\u008ei\\:*'b\u0015U9Iß\u0015\u0010\u00959bÊ±åxM\u007fâ|¤\u0093\u00adp\u0083\u0018=~õæ¨ÿêÉ\u00adÇ6\u0015·\u0086¡{\u001aeu ®7¸\u001e\u0018:7TðÜ£\tGßás\u0001jC#\u0087ÄÚØ\u0006ÍA\u008bÂ ¸~E®¸_\u0005ÿ]XdNãkùt}w88E\u0090úÖë*I/g\u008c\u0096\u008f\u0018Ù¹\u000f\tO\u000f`ü_³\u0002ú`\u008a\u0087í\u008b\u00140õÿ\r«18\u00adk£Z,Ä²½À%rø.Tð{»\u0095¡á¨0\u0007IÁ#/¬¹y®\f\u0090PLúk^¤\u0016V¡\u0016\u009bæT\u008fÕ27G\u008f\u0082\u001fq3 \ràÿÖü¶ö\u0011ë(Ù\u0096p\u007f¥oXß\u008b3\u00ad4-\u009e:\u0014Ê\u0099l,\u0093Þ\u0018á!~ïA\u001aÚ\nCû«fªër¨\u008dsWâ\u001cûÔ\u0004\u00104I°~\u0098hÝ\u0000Û!ã\tyg\u009c·\u0018º©5\u009a¢ÞÈ\u0091÷\u0087\u0091\u009c¶8\u009fµÉW¿s¯Äùh\u0010£t\"\u009fm.ä\u0003\u000eUüú±\r\u000bV\u0010ÜÁj\u008f^t\u009eß¨c·q\u0082qè¶ k¦ðþgÊ\u0093\u0090YV\u0082Ä¾åg\fµÂÉ\u0004o\u0080\u0098h¾¼\u009fÊyµ\u0090o\u0010:®Í%\f9\nºÝèÊÔy7p\u0083 \u008c°s7ä\u0089d\u001f\u0096\u0082íyÈ\u001e«+³ÐÂYà|¸¤³¥M^è{êÿ 3a1áú\r\u009e0âf\u0012é\u0005Fäìç!ã\u009eAÓZP\u001ap-§=Î«Í ]§+°ÏÔ(û³mWùFwÂå\u009eG¬½)ác@¶èöQò\u0004¶U";
      short var13 = 986;
      char var10 = ' ';
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[37];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var5 << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-51, 6, 121, -87, -65, 67, 26, -70});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "Ì[\u0090Ûl\u0002é\u00adgÂt¨f\u001bvÙx\u009a\u008aIDiÓ®{\"\u0080Y§y\u001dë pó7\u0095bó\"37U!Ã¯=>\u0010uB\u0000ø\u009d³\t\u001f\u0006ñ\\Þ\"\u001fÊC";
                  var13 = 65;
                  var10 = ' ';
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   private boolean F(ItemStack stack) {
      long a = 树友树何友友树友友树.a ^ 113301800766067L;
      return stack.getItem() == c<"D">(3616151345958040698L, a);
   }

   protected void F() {
      long a = 树友树何友友树友友树.a ^ 72023372672424L;
      this.U();
      this.y(b<"t">(31144, 8590328448019823906L ^ a));
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 43;
               case 1 -> 36;
               case 2 -> 48;
               case 3 -> 20;
               case 4 -> 62;
               case 5 -> 28;
               case 6 -> 35;
               case 7 -> 59;
               case 8 -> 15;
               case 9 -> 58;
               case 10 -> 10;
               case 11 -> 56;
               case 12 -> 13;
               case 13 -> 8;
               case 14 -> 5;
               case 15 -> 25;
               case 16 -> 9;
               case 17 -> 52;
               case 18 -> 26;
               case 19 -> 23;
               case 20 -> 19;
               case 21 -> 11;
               case 22 -> 31;
               case 23 -> 51;
               case 24 -> 7;
               case 25 -> 22;
               case 26 -> 50;
               case 27 -> 54;
               case 28 -> 4;
               case 29 -> 41;
               case 30 -> 44;
               case 31 -> 34;
               case 32 -> 53;
               case 33 -> 27;
               case 34 -> 2;
               case 35 -> 39;
               case 36 -> 37;
               case 37 -> 61;
               case 38 -> 32;
               case 39 -> 21;
               case 40 -> 17;
               case 41 -> 16;
               case 42 -> 63;
               case 43 -> 18;
               case 44 -> 46;
               case 45 -> 38;
               case 46 -> 55;
               case 47 -> 42;
               case 48 -> 30;
               case 49 -> 49;
               case 50 -> 40;
               case 51 -> 47;
               case 52 -> 6;
               case 53 -> 57;
               case 54 -> 24;
               case 55 -> 0;
               case 56 -> 3;
               case 57 -> 29;
               case 58 -> 33;
               case 59 -> 12;
               case 60 -> 45;
               case 61 -> 14;
               case 62 -> 60;
               default -> 1;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友树何友友树友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20860;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树友树何友友树友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友树何友友树友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 246 && var8 != 'Z' && var8 != 'D' && var8 != 233) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'm') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 214) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 246) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Z') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'D') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "\u0002G\nqMN\r\u0007GzGS\bZL<ON\u0005\\Hw\fH\fYH<RM\u0000PA`\f佴伴叢佱叙栳只厪佼佱";
      k[1] = "UvM\u000b4!aUBKy*kHG\u0016rlcUJ\u0010v' wA\u0001o.k\u0001";
      k[2] = "}D4j@|r\u0004yaJawYr'B|z_vl\u0001zsZv'_\u007f\u007fS\u007f{\u0001栂叕栻住参古栂叕叡栋";
      k[3] = "%K\u0006`\"@.D\u0017/IT,O\u0000ueC!";
      k[4] = "]\u0019 HU\u0003]\u00197\u0014Y\fGR#\tJ\u0006WR=\u0012]\u0007\u001d5 \u0003U\u0019";
      k[5] = "!\u001cL!\t1!\u001c[}\u0005>;WO`\u00164+WQ{\u00015a0Lj\t";
      k[6] = "]^\ff5gR\u001eAm?zWCJ+,iREG+3eN\\\fH5l[fCi/m";
      k[7] = "\bBF}Gm\u0007\u0002\u000bvMp\u0002_\u00000^c\u0007Y\r0Ao\u001b@F\\Gm\u0007I\tp~c\u0007Y\r";
      k[8] = int.class;
      l[8] = "java/lang/Integer";
      k[9] = boolean.class;
      l[9] = "java/lang/Boolean";
      k[10] = "d\u001a$#\u001e{kZi(\u0014fn\u0007bn\u001c{c\u0001f%_佁佒县佟伕厺佁佒桥栛";
      k[11] = "Ob>Kf0@\"s@l-E\u007fx\u0006|+E`c\u0006栘厔栽叇叛佽作桎佹余";
      k[12] = "\u0015I$\t>w\u0015I3U2x\u000f\u0002'H!r\u001f\u0002\u0019I'{\tM3S:q\u0015d1I7";
      k[13] = "2_x\u000fKV2_oSGY(\u0014oMOZ2N\"lOQ9Y~@@K";
      k[14] = "tWfEfYtWq\u0019jVn\u001cq\u0007bUtF<\u0006~\\n[b\u0007jI\u007f@<&~\\n[B\u0007jI\u007f@U\nfUW]v\u000e";
      k[15] = "l\u0018RLx+cX\u001fGr6f\u0005\u0014\u0001a%c\u0003\u0019\u0001~)\u007f\u001aRab)m\u0013\u000eyv(z\u0013";
      k[16] = "/\u001c\u0001j\u0012\u0012/\u001c\u00166\u001e\u001d5W\u0002+\r\u0017%W\u0010*\u000b\u00125\u0000[4\u0013\u001a8\u001c\u0007j6\u00157\u001c\u001b0\u0010\t8";
      k[17] = "TbK\u0015t\u0005_mZZ\u0015\u000bTf^\u0000";
      k[18] = "y\fm6O\u000f.T&5w桪桙伲佁収伪伮桙伲栅\rJ\n)QrgI\u0013}\u001d";
      k[19] = "\u0018.k+e+\u0012o?|\u0018(t(o{(~t\u0014ixx-Ou$&a'";
      k[20] = "\n\u0004\u0003/h.J\tU&\u000e\u0010s'(\u001cN\u001c|*n{l8^\u0000\u0015;anW";
      k[21] = "'~\u0005#xUt+S6\u001aAA%\u0000\u007f%\u0015A\u0014P,#\u0010/,\u0002wtE";
      k[22] = "T*1:w\u001a\u0003)+]mcS((1`]\bh11\u0012";
      k[23] = "c\rQO#C4U\u001aL\u001b叼桃厭根桭变叼厙厭根t%[0TC\u0013\"\u000e1_";
      k[24] = "\u0003Z\u001bs\u0014M\t\u001bO$iNo\\\u001f!Q\u0018o`\u0019 \tKT\u0001T~\u0010A";
      k[25] = "\u0000A\u00040(4W\u0019O3\u0010压佤使桬栒位伕栠栻厶\u000b-'FPEbnqP\u001c";
      k[26] = "Q>Q\u0004q=U:\u0017L\t伇厭厐叭叾及伇伳桊叭=67\u0011jVZ23W\"";
      k[27] = "t\u000e\u0017\u001f\u0010,#V\\\u001c(厓桔厮厥栽栱厓桔估厥$\u0015?2\u001fVMVi$S";
      k[28] = "\u0001jW/]\u0010V2\u001c,e厯校佔栿受桼桵校佔佻\u0014\f\u0014\tdZ,Y\u0007Ub";
      k[29] = "\u0010BR)I2G\u001a\u0019*q伓佴叢叠住厲厍只佼叠\u0012M3CE\u001bl\u001c$R@";
      k[30] = "\"\u007fk\u0014+Vu' \u0017\u0013C\u001b&uE+ApwbA(*!sp\u0017xApdt\u0014\u0013";
      k[31] = "Q\u0002\u000ee&\u0010\u0006ZEf\u001e厯伵似厼伃叝厯厫厢桦^w\u0014Y\f\u0003f\"\u0007\u0005\n";
      k[32] = "yR5H\u000eP.\n~K6可伝佬桝伮栯栵桙栨厇s\u0006\u001d \u0000yMIW#[";
      k[33] = "&>kvkdqf uS栁叜伀叙伐厐栁佂厞栃Mc)\u007fl's,c|7";
      k[34] = "}Sg\t7)&\u000el\u000b\u000e.@\t?B1\u007f@2?\ng~yX<\u001332";
      k[35] = "?{e6f\u0015h#.5^厪叅叛受栔桇桰佛叛栍\r7\u00117uh5b\u0002ks";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 树友树何友友树友友树.a ^ 8655611555407L;
      c<"Ö">(-7633384988707966539L, a);
      this.N();
      String mode = c<"ö">(this, -7633008925065691028L, a).getValue().equals(b<"t">(16394, 8209498061903071077L ^ a))
         ? b<"t">(25115, 1931312916302538088L ^ a)
         : b<"t">(16547, 3855991387240007616L ^ a);
      this.y(b<"t">(6073, 6947279044507979992L ^ a) + mode);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void U() {
      long a = 树友树何友友树友友树.a ^ 50791158824334L;
      long ax = a ^ 74504264957180L;
      long axx = a ^ 72162567033801L;
      c<"Ö">(-4192309034329611660L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"ö">(this, -4192589088232874012L, a) != -1) {
            if (c<"ö">(this, -4192125920507161331L, a).getValue()) {
               PacketUtils.v(new Object[]{axx, new ServerboundSetCarriedItemPacket(c<"ö">(this, -4192589088232874012L, a))});
            }

            c<"Z">(mc.player.getInventory(), c<"ö">(this, -4192589088232874012L, a), -4189197031766236079L, a);
            c<"Z">(this, -1, -4192589088232874012L, a);
         }

         c<"Z">(this, false, -4192399772337875695L, a);
      }
   }

   private boolean U(ItemStack stack) {
      long a = 树友树何友友树友友树.a ^ 139759274734071L;
      c<"Ö">(-3915673130684027379L, a);
      return stack.hasTag() && stack.getTag() != null && stack.getTag().contains(b<"t">(25927, 5253915764582743424L ^ a));
   }

   @EventTarget
   public void z(TickEvent event) {
      long a = 树友树何友友树友友树.a ^ 45639112304973L;
      long ax = a ^ 75254065408063L;
      long axx = a ^ 77044126156554L;
      long axxx = a ^ 77095453248994L;
      long axxxx = a ^ 129748668031616L;
      c<"Ö">(-3381382437149444425L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"ö">(this, -3381467553087471150L, a)
            && c<"ö">(this, -3377963387233725781L, a).Y(c<"ö">(this, -3377787860741959035L, a).getValue().longValue(), axxx)) {
            this.U();
         } else if (!c<"ö">(this, -3381467553087471150L, a)) {
            float currentHealth = mc.player.getHealth();
            float maxHealth = mc.player.getMaxHealth();
            float healthPercent = currentHealth / maxHealth * 100.0F;
            if (c<"ö">(this, -3381881789056137536L, a).getValue() && c<"ö">(this, -3377851225086530104L, a).Y(j, axxx)) {
               String var10001 = String.format(b<"t">(28011, 8178896548575276316L ^ a), currentHealth);
               String var10002 = String.format(b<"t">(29572, 7288174108090659837L ^ a), maxHealth);
               String axxxxx = String.format(b<"t">(29572, 7288174108090659837L ^ a), healthPercent);
               String axxxxxx = var10002;
               String var21 = var10001;
               this.y(
                  b<"t">(10716, 8971690458079177107L ^ a)
                     + var21
                     + "/"
                     + axxxxxx
                     + b<"t">(18476, 415969985949976666L ^ a)
                     + axxxxx
                     + b<"t">(27564, 4306191464444816342L ^ a)
               );
            }

            if (!(healthPercent > c<"ö">(this, -3382066656422734441L, a).getValue().floatValue())) {
               if (c<"ö">(this, -3377851225086530104L, a).Y(c<"ö">(this, -3382056754261245849L, a).getValue().longValue(), axxx)) {
                  int healingItemSlot = this.Y();
                  if (healingItemSlot == -1) {
                     String itemName = c<"ö">(this, -3382145528893044882L, a).getValue().equals(b<"t">(6739, 5844406091585329690L ^ a))
                        ? b<"t">(23602, 5450187864785509456L ^ a)
                        : b<"t">(26108, 6521942269146195344L ^ a);
                     this.y(b<"t">(13166, 2112124421640991506L ^ a) + itemName);
                  } else {
                     c<"Z">(this, c<"ö">(mc.player.getInventory(), -3377703237559062382L, a), -3381101869058602201L, a);
                     if (c<"ö">(this, -3381758996298890802L, a).getValue()) {
                        PacketUtils.v(new Object[]{axx, new ServerboundSetCarriedItemPacket(healingItemSlot)});
                     }

                     c<"Z">(mc.player.getInventory(), healingItemSlot, -3377703237559062382L, a);

                     try {
                        c<"ö">(mc, -3381596933563005527L, a).useItem(mc.player, c<"D">(-3381565818857350800L, a));
                        String itemName = c<"ö">(this, -3382145528893044882L, a).getValue().equals(b<"t">(16394, 8209447084437848167L ^ a))
                           ? b<"t">(25115, 1931279529870058090L ^ a)
                           : b<"t">(16547, 3855949766246351042L ^ a);
                        this.y(b<"t">(3772, 7398327182255460055L ^ a) + itemName);
                     } catch (Exception var22) {
                        String itemNamex = c<"ö">(this, -3382145528893044882L, a).getValue().equals(b<"t">(16394, 8209447084437848167L ^ a))
                           ? b<"t">(25115, 1931279529870058090L ^ a)
                           : b<"t">(16547, 3855949766246351042L ^ a);
                        this.y(b<"t">(835, 6583075950645904183L ^ a) + itemNamex + b<"t">(7260, 5087760342401031228L ^ a) + var22.getMessage());
                     }

                     if (c<"ö">(this, -3381101869058602201L, a) != -1 && c<"ö">(this, -3381101869058602201L, a) != healingItemSlot) {
                        c<"Z">(this, true, -3381467553087471150L, a);
                        c<"ö">(this, -3377963387233725781L, a).U(axxxx);
                     }

                     c<"ö">(this, -3377851225086530104L, a).U(axxxx);
                  }
               }
            }
         }
      }
   }

   private void y(String message) {
      long a = 树友树何友友树友友树.a ^ 105257429227991L;
      long ax = a ^ 66739451562053L;
      if (c<"ö">(this, -6806255877112449446L, a).getValue()) {
         ClientUtils.e(new Object[]{b<"t">(21408, 2683068552246436687L ^ a) + message, ax});
      }
   }

   private boolean E(ItemStack stack) {
      long a = 树友树何友友树友友树.a ^ 34525842806482L;
      c<"Ö">(-1257106337901491928L, a);
      if (stack.isEmpty()) {
         return false;
      } else {
         String var5 = c<"ö">(this, -1256783112156956431L, a).getValue();
         byte var6 = -1;
         switch (var5.hashCode()) {
            case 964847273:
               if (!var5.equals(b<"t">(16394, 8209470876400484344L ^ a))) {
                  break;
               }

               var6 = 0;
            case 1265266539:
               if (var5.equals(b<"t">(12223, 5543150060384030808L ^ a))) {
                  var6 = 1;
               }
         }
         return switch (var6) {
            case 0 -> this.P(stack);
            case 1 -> this.F(stack);
            default -> false;
         };
      }
   }

   private int Y() {
      long a = 树友树何友友树友友树.a ^ 32188134926165L;
      long ax = a ^ 123923741845031L;
      c<"Ö">(6848530631345633455L, a);
      if (this.w(new Object[]{ax})) {
         return -1;
      } else {
         int i = 0;
         ItemStack stack = mc.player.getInventory().getItem(0);
         if (this.E(stack)) {
            return 0;
         } else {
            i++;
            return -1;
         }
      }
   }

   private void N() {
      long a = 树友树何友友树友友树.a ^ 20708852457108L;
      long ax = a ^ 85036050961753L;
      c<"ö">(this, 2794005704552323601L, a).U(ax);
      c<"ö">(this, 2793968334967694706L, a).U(ax);
      c<"Z">(this, -1, 2795278052261805310L, a);
      c<"Z">(this, false, 2795511039153583627L, a);
   }

   private boolean P(ItemStack stack) {
      long a = 树友树何友友树友友树.a ^ 29566759428418L;
      c<"Ö">(1809842252585156280L, a);
      if (stack.getItem() != c<"D">(1809499760679485202L, a)) {
         return false;
      } else {
         String displayName = stack.getDisplayName().getString().toLowerCase();
         return displayName.contains(b<"t">(2656, 3616406769485398556L ^ a))
            || displayName.contains(b<"t">(30925, 3748645683372437670L ^ a))
            || displayName.contains(b<"t">(25115, 1931336043534068325L ^ a))
            || this.U(stack);
      }
   }

   private static String HE_SHU_YOU() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
