package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;
import why.tree.friend.antileak.Fucker;

public class 友友友友何何友树友友 extends Module implements 何树友 {
   public static 友友友友何何友树友友 树友何友树友树友何树;
   public final ModeValue 树友树树何何何友树友;
   private final BooleanValue 树友树友何何友何树友;
   private final BooleanValue 何友何树树树何树何树;
   private final BooleanValue 友友树何友树树树树友;
   private final NumberValue 友何何何友树友何树友;
   public boolean 友树友友友何友友树友;
   private boolean 树何何树树友友树何何;
   private boolean 友树树树何树树树友何;
   public boolean 树何何友何友何何友树;
   private boolean 何树树友何树何树友友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[35];
   private static final String[] k = new String[35];
   private static String HE_JIAN_GUO;

   public 友友友友何何友树友友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/友友友友何何友树友友.a J
      // 003: ldc2_w 140727084087016
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 5755
      // 00c: ldc2_w 2291318802761923152
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 4573
      // 019: ldc2_w 6234881913895140855
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w 722801316441771444
      // 026: lload 1
      // 027: invokedynamic k (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/ModeValue
      // 033: dup
      // 034: sipush 22735
      // 037: ldc2_w 535837793220228341
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 4585
      // 044: ldc2_w 1412169132233670090
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 4
      // 04f: anewarray 94
      // 052: dup
      // 053: bipush 0
      // 054: sipush 14728
      // 057: ldc2_w 3254364623037207980
      // 05a: lload 1
      // 05b: lxor
      // 05c: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 061: aastore
      // 062: dup
      // 063: bipush 1
      // 064: sipush 8392
      // 067: ldc2_w 8516462449724787949
      // 06a: lload 1
      // 06b: lxor
      // 06c: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 071: aastore
      // 072: dup
      // 073: bipush 2
      // 074: sipush 8449
      // 077: ldc2_w 2310711769348967715
      // 07a: lload 1
      // 07b: lxor
      // 07c: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 081: aastore
      // 082: dup
      // 083: bipush 3
      // 084: sipush 4632
      // 087: ldc2_w 6317972653045726782
      // 08a: lload 1
      // 08b: lxor
      // 08c: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 091: aastore
      // 092: sipush 7087
      // 095: ldc2_w 8616009919010289539
      // 098: lload 1
      // 099: lxor
      // 09a: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09f: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 0a2: putfield cn/cool/cherish/module/impl/player/友友友友何何友树友友.树友树树何何何友树友 Lcn/cool/cherish/value/impl/ModeValue;
      // 0a5: aload 0
      // 0a6: new cn/cool/cherish/value/impl/BooleanValue
      // 0a9: dup
      // 0aa: sipush 479
      // 0ad: ldc2_w 8190121837954149878
      // 0b0: lload 1
      // 0b1: lxor
      // 0b2: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b7: sipush 10818
      // 0ba: ldc2_w 4013099316629276266
      // 0bd: lload 1
      // 0be: lxor
      // 0bf: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c4: bipush 0
      // 0c5: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0c8: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0cb: aload 0
      // 0cc: invokedynamic get (Lcn/cool/cherish/module/impl/player/友友友友何何友树友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/player/友友友友何何友树友友.G ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 0d1: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0d4: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 0d7: putfield cn/cool/cherish/module/impl/player/友友友友何何友树友友.树友树友何何友何树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0da: aload 0
      // 0db: new cn/cool/cherish/value/impl/BooleanValue
      // 0de: dup
      // 0df: sipush 12042
      // 0e2: ldc2_w 5704330924669928241
      // 0e5: lload 1
      // 0e6: lxor
      // 0e7: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ec: sipush 8484
      // 0ef: ldc2_w 3911244444168097034
      // 0f2: lload 1
      // 0f3: lxor
      // 0f4: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f9: bipush 1
      // 0fa: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0fd: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 100: aload 0
      // 101: invokedynamic get (Lcn/cool/cherish/module/impl/player/友友友友何何友树友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/player/友友友友何何友树友友.z ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 106: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 109: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 10c: putfield cn/cool/cherish/module/impl/player/友友友友何何友树友友.何友何树树树何树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 10f: aload 0
      // 110: new cn/cool/cherish/value/impl/BooleanValue
      // 113: dup
      // 114: sipush 15983
      // 117: ldc2_w 1530357220725789265
      // 11a: lload 1
      // 11b: lxor
      // 11c: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 121: sipush 23347
      // 124: ldc2_w 8307147476434712338
      // 127: lload 1
      // 128: lxor
      // 129: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 12e: bipush 0
      // 12f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 132: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 135: aload 0
      // 136: invokedynamic get (Lcn/cool/cherish/module/impl/player/友友友友何何友树友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/player/友友友友何何友树友友.J ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 13b: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 13e: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 141: putfield cn/cool/cherish/module/impl/player/友友友友何何友树友友.友友树何友树树树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 144: aload 0
      // 145: new cn/cool/cherish/value/impl/NumberValue
      // 148: dup
      // 149: sipush 29149
      // 14c: ldc2_w 4709699272538611197
      // 14f: lload 1
      // 150: lxor
      // 151: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 156: sipush 3177
      // 159: ldc2_w 5079550776833581137
      // 15c: lload 1
      // 15d: lxor
      // 15e: invokedynamic y (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 163: ldc2_w 3.3
      // 166: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 169: bipush 0
      // 16a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 16d: bipush 5
      // 16e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 171: ldc2_w 0.1
      // 174: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 177: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 17a: aload 0
      // 17b: invokedynamic get (Lcn/cool/cherish/module/impl/player/友友友友何何友树友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/player/友友友友何何友树友友.b ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 180: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 183: checkcast cn/cool/cherish/value/impl/NumberValue
      // 186: putfield cn/cool/cherish/module/impl/player/友友友友何何友树友友.友何何何友树友何树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 189: aload 0
      // 18a: bipush 0
      // 18b: ldc2_w 721730179723963083
      // 18e: lload 1
      // 18f: invokedynamic Ê (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 194: aload 0
      // 195: bipush 0
      // 196: ldc2_w 721894691425242020
      // 199: lload 1
      // 19a: invokedynamic Ê (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 19f: aload 0
      // 1a0: bipush 0
      // 1a1: ldc2_w 722625361150832659
      // 1a4: lload 1
      // 1a5: invokedynamic Ê (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1aa: aload 0
      // 1ab: bipush 0
      // 1ac: ldc2_w 722517366623003105
      // 1af: lload 1
      // 1b0: invokedynamic Ê (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b5: aload 0
      // 1b6: bipush 0
      // 1b7: ldc2_w 722707011165856473
      // 1ba: lload 1
      // 1bb: invokedynamic Ê (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c0: aload 0
      // 1c1: ldc2_w 721799089162351003
      // 1c4: lload 1
      // 1c5: invokedynamic a (Lcn/cool/cherish/module/impl/player/友友友友何何友树友友;JJ)V bsm=cn/cool/cherish/module/impl/player/友友友友何何友树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ca: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-6269515145576201929L, -3206338446002798958L, MethodHandles.lookup().lookupClass()).a(31140379234370L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 132071163621784L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[21];
      int var7 = 0;
      String var6 = "KÚÐãìÆÃ=f\u001b\u0096\u00ad$\u009b\bÓí\u008fä@þ\u0011æ¨\u001d\u0095¼tûdÜg$fT\u009cmµèëùù}mÄ\u0096\u008dR\u0010\u0091\u0092\u0094Pôª\u0017\fUèö\u0012>¢4¿(\u0092àQØÑ3ß\u0000hÌ]«sT5¨x\u0006\u0017:²wy\u007f\u0019õ¢F\r\t\u0083DDãF&ª»Ñ÷(Ú\u007f\u0094\u0006K6}\u0097cÉ[cvøâ\u0011Oývûú\u000es\u0098¶A»x\u0017 \u001d\u0091\n\u009d¦R?% \r\u0018.®\u001b}Dç\u0090ïuá8Ò\u001e?ð»\u008aíð\\)\u0000|J ¿òÇÿ4q)Åè%×`Dã\fP·ï\u0099±\u0098\u001fWÃ©ch\u0001i\u001bê\u0093 ø\u001dë¸m\u0087Bñ\u001fÓr[\u0001À[\u0098\u0095\u0081\u001cgÐ|?3Õ\u000eC·ÃS=ú\u0010z=/H6¢\u008c\u00131\u0013Jh°N<¦\u0018\u0082ßg\u0007ò¬ÌU¼÷ïf·\u0082NN\u0098\u008ef\u0092HÉT\r\u0010·¥{È±&×\"\u0004\u0004åeb>H?\u0018<a\u0086\u0090Î#Í`5gûç\u0006£c>c÷\u0081v\u0083¹mY z\u0005'E-\u009a¡²¨`J®@\u009aXÆD$ÊëÆ«±\u0004ýÿûý=§îÔ ß5ë\u0006ä±xG(è$÷i\u001b>-â\u008bÏå\u0018Ó#Wh(\u009ay\u0011ë\u0095ÌPÉWstR\u0098\u0083!ÂJ.ñÔ+ofØ2~\u0019r.Í\u009cû\u009b\u009b,\u0013J1]^\u0010HX\f¡ÇØ\u000b\u0013^I^ò{Ù\u0005|\u001b¹£v\t«ÊLÌ\u008d/ÑËO\u009e/\u0014«±Gó»¦*\u0083îJü\u0005\u009f\u0018\u000b6\u0091>\u0010À\u0090àÆ9«.é\u0085zt-aå¹L\u0016\u0088¯\u00101\u009aâ÷4A\u0091'$þt\u009c¿ ¦h\u0010ÿ\u0003H\u0002µ9wI\u0007Q>ÅÚu-\u0004\u00183p\u000b¥\u001aáu)vî·º\u008duxìâÏ,\u0084©Bhò îým\u0012\u001bçÃ\u0087tÚö\u0003f®}T½\u009c[Ãú(\u0002©\u0097R\u0016\tçÃ\u001fã";
      short var8 = 586;
      char var5 = '0';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[21];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ö\u0007Ý@Î@d0(úý\u0001¢É\u0088[/F\u0090r¿Y\u008eE\u0091=Jâ'\u0096î\u009d\u0018\u008b´rgWù\u0080Z08\"ÊR7k9àqè\u009c\u0000P\u0098\u0005";
                  var8 = 57;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public void F() {
      this.Q();
   }

   @EventTarget
   public void S(StrafeEvent event) {
      long a = 友友友友何何友树友友.a ^ 65032341979743L;
      long ax = a ^ 77916851603358L;
      c<"z">(-93526708975661342L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin) {
         if (mc.player.onGround() && c<"Ó">(this, -94339289461664146L, a) && !c<"Ó">(c<"Ó">(mc, -93808551669108941L, a), -94041325557243088L, a).isDown()) {
            mc.player.jumpFromGround();
            if (c<"Ó">(this, -94256937187693040L, a).getValue() && this.isEnabled()) {
               this.y(false);
            }

            c<"Ê">(this, false, -94339289461664146L, a);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 59;
               case 1 -> 1;
               case 2 -> 38;
               case 3 -> 47;
               case 4 -> 24;
               case 5 -> 11;
               case 6 -> 41;
               case 7 -> 10;
               case 8 -> 62;
               case 9 -> 63;
               case 10 -> 33;
               case 11 -> 31;
               case 12 -> 7;
               case 13 -> 43;
               case 14 -> 37;
               case 15 -> 29;
               case 16 -> 20;
               case 17 -> 19;
               case 18 -> 8;
               case 19 -> 39;
               case 20 -> 14;
               case 21 -> 45;
               case 22 -> 16;
               case 23 -> 61;
               case 24 -> 17;
               case 25 -> 53;
               case 26 -> 15;
               case 27 -> 6;
               case 28 -> 42;
               case 29 -> 55;
               case 30 -> 46;
               case 31 -> 28;
               case 32 -> 50;
               case 33 -> 56;
               case 34 -> 12;
               case 35 -> 23;
               case 36 -> 40;
               case 37 -> 36;
               case 38 -> 9;
               case 39 -> 52;
               case 40 -> 51;
               case 41 -> 35;
               case 42 -> 57;
               case 43 -> 58;
               case 44 -> 0;
               case 45 -> 48;
               case 46 -> 54;
               case 47 -> 34;
               case 48 -> 4;
               case 49 -> 27;
               case 50 -> 60;
               case 51 -> 32;
               case 52 -> 26;
               case 53 -> 3;
               case 54 -> 25;
               case 55 -> 22;
               case 56 -> 13;
               case 57 -> 18;
               case 58 -> 2;
               case 59 -> 21;
               case 60 -> 5;
               case 61 -> 30;
               case 62 -> 49;
               default -> 44;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9771;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友友友友何何友树友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友友友友何何友树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 211 && var8 != 202 && var8 != 'k' && var8 != 'a') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'l') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 211) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'k') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友友友友何何友树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   @EventTarget
   public void a(PacketEvent event) {
      long a = 友友友友何何友树友友.a ^ 97436893549744L;
      long ax = a ^ 41122710294897L;
      c<"z">(-1703246522311272435L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin) {
         switch (c<"k">(-1702920775336308753L, a)[event.getSide().ordinal()]) {
            case 1:
               if (!c<"Ó">(this, -1702709391747480647L, a)
                  || !c<"Ó">(this, -1703417678203008877L, a)
                  || c<"Ó">(this, -1703336997569779204L, a)
                  || !(event.getPacket() instanceof ServerboundMovePlayerPacket)) {
                  break;
               }

               event.setCancelled(true);
            case 2:
               if (c<"Ó">(this, -1702709391747480647L, a) && event.getPacket() instanceof ClientboundPlayerPositionPacket) {
                  c<"Ê">(this, true, -1703336997569779204L, a);
               }
         }
      }
   }

   private static void a() {
      j[0] = ">DE?\u000bg1\u0004\b4\u0001z4Y\u0003r\tg9_\u00079Ja0Z\u0007r\u0014d<S\u000e.J參厖叡厠伉伱參桌叡厠";
      j[1] = "k\u001cnJ\u001f%d\\#A\u00158a\u0001(\u0007\u0006+d\u0007%\u0007\u0019'x\u001end\u001f.m$!E\u0005/";
      j[2] = boolean.class;
      k[2] = "java/lang/Boolean";
      j[3] = "y\\:@1rv\u001cwK;osA|\r3r~GxFptwBx\r.q{KqQp佈住叹佁叨桏取发佧佁";
      j[4] = "\u0018VNj\u0001\u0007,uA*L\f&hDwGJ.uIqC\u0001mWB`Z\b&!";
      j[5] = "CY`&lkHVqi\u0010rGL\u007f*'BQ[s76nFV";
      j[6] = "\u0007(*\u0003se\bhg\byx\r5lNjk\b3aNug\u0014**\"se\b#e\u000eJk\b3a";
      j[7] = "HP\u001cCw/G\u0010QH}2BMZ\u000eu/OK^E6伕佾叵佧併叓伕佾栯栣";
      j[8] = "\u0013)uHG\r\u001ci8CM\u0010\u001943\u0005^\u0003\u001c2>\u0005A\u000f\u0000+ue]\u000f\u0012\")}I\u000e\u0005\"";
      j[9] = "=K>\u007f9e=K)#5j'\u0000)==i=Zd!8m*K8\u007f\u0018c0O&\u00018m*K8";
      j[10] = float.class;
      k[10] = "java/lang/Float";
      j[11] = "]\u001d\u0012g\u000fe]\u001d\u0005;\u0003jGV\u0005%\u000bi]\fH\u0004\u000bbV\u001b\u0014(\u0004x";
      j[12] = "-pR\n1m-pEV=b7;EH5a-a\bk,p*zHW";
      j[13] = "9qS\u0001yG9qD]uH#:DC}K9`\tdqW\u001auW_}@0";
      j[14] = "\u001bB+\u000b|V\u0014\u0002f\u0000vK\u0011_mF~V\u001cYi\r=P\u0015\\iFcU\u0019U`\u001a=史厳叧収伽但史桩叧収L栂佬桩栽佐厣但史桩栽";
      j[15] = "Q\u0013";
      j[16] = "\nhYAQM\u0001gH\u000e0C\nlLT";
      j[17] = "\u001dOd\u0000_CM\u001fy`桿古桤桪佀伽伻古桤厰\u001d\u001dY\u001e\u0017\u0012{\u0007\u0016K";
      j[18] = "y9vk\u0014P)ik\u000b叮佩佄佘双栒叮佩栀叆\u000f5\u0016L~uqfF\ba";
      j[19] = ">\u000by\bf^p\u001f!R\u0001\rVK~T?]Vzw\u0010f^dA(\u0002c\\";
      j[20] = "`bS%'s02NE叝栎參厝叩优叝叔栙厝*|zya,\u00175x-?";
      j[21] = "&\"s\fq\u000fvrnl桑厨伛叝栓厯桑厨伛标\n\ft\u0012&'n\\$\u000f";
      j[22] = "]9\u001e_`\u001f\ri\u0003?桀伦你栜桾叼厚桢你佘g\u0006=\u0015\\wZO?A\u0002";
      j[23] = "&iaQ.Wb\u007f6\u0019NM\u001c?f\u0007?^}>mT,2";
      j[24] = "Plnn{\u000e\u0000<s\u000e+j\u000b5{k'\nY`ggBQU<rk\"\u0003\u0000 ~\u000e";
      j[25] = "\u000f?TvTo_oI\u0016厮栒桶栚佰栏桴栒厬佞-/\te\u000eq\u0010f\u000b1P";
      j[26] = "C\u001eb\u0014\u001eZ\u0013N\u007ft佺栧栺叡但桭佺栧叠叡\u001bMCPBP&\u0004A\u0004\u001c";
      j[27] = "\fUG\u00196\nW\u0004X@[伬史厩叾厾厘伬佬桳叾}fNK\u000eP\u0006=\u001fTW";
      j[28] = "n\f[6JamJ\b|!叛叄栯桽休核栁栞栯伹LH~v\u000f\u00032C`aS";
      j[29] = "JR\fY(r\u001a\u0002\u00119栈叕栳厭伨佤叒佋栳厭u\u0005{kEW\u001bWl)\u0017";
      j[30] = ".\u0013vuI\\q\u0001sw,\tI^+p\u001cVIo )^\u001d\"\u001e.pF\f";
      j[31] = "iU\u00059*H9\u0005\u0018Y栊佱佔厪伡厚低佱及桰|`wBh\u001bA)u\u00166";
      j[32] = "J-\u0004\rW&H!\u000e]2t#v\u000f\t\u0002+#O\u0001\n\teD0\u0006KPp";
      j[33] = "\u001bhF\u0012r\u0016K8[r厈厱桢伉叼桫桒桫桢厗?N!\u000f\u0014mQ\u001c6MF";
      j[34] = "N\u0000)+,\"\u001eP4K佈厅佳栥桉桒佈桟佳栥Pw\u007f;A\u0005>%hy\u0013";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public boolean m() {
      long a = 友友友友何何友树友友.a ^ 112587681570560L;
      return c<"Ó">(this, 7201127895109389105L, a);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      this.Q();
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void U(TickEvent event) {
      long a = 友友友友何何友树友友.a ^ 14982861732513L;
      long ax = a ^ 123525738348384L;
      long axx = a ^ 125601416646741L;
      c<"z">(-4157509161808251364L, a);
      if (c<"Ó">(this, -4161302012471581750L, a).getValue()) {
         if (c<"Ó">(this, -4157927595710608226L, a).C(b<"y">(7087, 8616024915229047754L ^ a))) {
            this.T(b<"y">(18025, 8820979653916042759L ^ a));
         }

         this.T(c<"Ó">(this, -4157927595710608226L, a).getValue());
      }

      this.T(c<"Ó">(this, -4157927595710608226L, a).getValue());
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin) {
         if (c<"Ó">(this, -4157927595710608226L, a).C(b<"y">(7087, 8616024915229047754L ^ a))
            && c<"Ó">(this, -4157423647124256787L, a)
            && c<"Ó">(this, -4156936897909707352L, a)) {
            c<"Ê">(this, true, -4157138636543594864L, a);
            c<"Ê">(this, false, -4156936897909707352L, a);
            c<"Ê">(this, false, -4157423647124256787L, a);
            PacketUtils.v(new Object[]{axx, new StatusOnly(false)});
            if (c<"Ó">(this, -4161093032146019283L, a).getValue()) {
               WrapperUtils.z(new Object[]{1});
            }
         }
      }
   }

   @EventTarget
   public void Y(MotionEvent event) {
      long a = 友友友友何何友树友友.a ^ 95959579774756L;
      long ax = a ^ 46998741699301L;
      long axx = a ^ 20893613253408L;
      c<"z">(3731467139944563609L, a);
      if (event.isPre()) {
         String var9 = c<"Ó">(this, 3731592964165400859L, a).getValue();
         byte var10 = -1;
         switch (var9.hashCode()) {
            case 563981207:
               if (!var9.equals(b<"y">(7087, 8615984105196654159L ^ a))) {
                  break;
               }

               var10 = 0;
            case 1407612102:
               if (!var9.equals(b<"y">(4632, 6317945668784424946L ^ a))) {
                  break;
               }

               var10 = 1;
            case -2146931079:
               if (!var9.equals(b<"y">(8256, 4388237321824351651L ^ a))) {
                  break;
               }

               var10 = 2;
            case 67412976:
               if (var9.equals(b<"y">(16994, 7928169307707398019L ^ a))) {
                  var10 = 3;
               }
         }

         switch (var10) {
            case 0:
               if (this.w(new Object[]{ax}) || !(Boolean)Fucker.isLogin) {
                  return;
               }

               if (!c<"Ó">(this, 3732020693775964205L, a)
                  && c<"Ó">(mc.player, 3730432104481709948L, a) > c<"Ó">(this, 3731665120215543198L, a).getValue().doubleValue()
                  && !event.isOnGround()) {
                  c<"Ê">(this, true, 3732020693775964205L, a);
                  c<"Ê">(this, false, 3731381680453546600L, a);
                  c<"Ê">(this, false, 3731286706588029703L, a);
               }

               if (!c<"Ó">(this, 3732020693775964205L, a) || !event.isOnGround()) {
                  break;
               }

               event.setOnGround(false);
               if (c<"Ó">(this, 3731286706588029703L, a)) {
                  break;
               }

               PacketUtils.e(new Object[]{axx, new Pos(event.getX() + 10000.0, event.getY(), event.getZ() + 10000.0, false)});
               c<"Ê">(this, true, 3731286706588029703L, a);
            case 1:
               event.setOnGround(false);
            case 2:
               if (!(c<"Ó">(mc.player, 3730432104481709948L, a) > c<"Ó">(this, 3731665120215543198L, a).getValue().doubleValue()) || event.isOnGround()) {
                  break;
               }

               PacketUtils.e(new Object[]{axx, new StatusOnly(true)});
               WrapperUtils.z(new Object[]{1});
            case 3:
               if (c<"Ó">(mc.player, 3730432104481709948L, a) >= c<"Ó">(this, 3731665120215543198L, a).getValue().doubleValue() && !event.isOnGround()) {
                  WrapperUtils.D(new Object[]{0.5F});
                  c<"Ê">(this, true, 3732199123619957215L, a);
                  PacketUtils.e(new Object[]{axx, new StatusOnly(true)});
                  c<"Ê">(mc.player, 0.0F, 3730432104481709948L, a);
               }

               if (c<"Ó">(this, 3732199123619957215L, a)) {
                  WrapperUtils.D(new Object[]{1.0F});
                  c<"Ê">(this, false, 3732199123619957215L, a);
               }
         }
      }
   }

   private void Q() {
      long a = 友友友友何何友树友友.a ^ 92906857054859L;
      c<"z">(4496798796636507702L, a);
      if (c<"Ó">(this, 4495837547573298288L, a)) {
         c<"Ê">(this, false, 4495837547573298288L, a);
         WrapperUtils.D(new Object[]{1.0F});
      }

      c<"Ê">(this, false, 4496708883381321671L, a);
      c<"Ê">(this, false, 4496226532283405698L, a);
      c<"Ê">(this, false, 4496618021830074024L, a);
   }

   private static String LIU_YA_FENG() {
      return "行走的50万——何炜霖";
   }
}
