package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.树树何友树何友友何友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.item.友何树树何树何何何友;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.move.MoveMathEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class 树树树树何友树何树友 extends Module implements 何树友 {
   private final BooleanValue 树何树何友何树树树树 = new BooleanValue("Meme Wav", "搞笑音频", true);
   private final NumberValue 友何树树何何树友何树 = new NumberValue("Freeze Tick", 20, 1, 20, 1);
   private final BooleanValue 友友树友友友何友何何 = new BooleanValue("Only Air", "仅空中", true);
   private final BooleanValue 友友树树何树树树树树 = new BooleanValue("No Move When Stuck", "卡空时禁止移动", true);
   private boolean 树树何何树何树何树树 = false;
   private boolean 友何何何何树树友树友 = false;
   private boolean 何树友树树树树何友何 = false;
   private int 友何友树树何树友友友 = 0;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[56];
   private static final String[] k = new String[56];
   private static String HE_DA_WEI;

   public 树树树树何友树何树友() {
      super("Clutch", "自动自救", 树何友友何树友友何何.何友树何树友友友何树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3173349166358731135L, 4061927205357915436L, MethodHandles.lookup().lookupClass()).a(56158910369659L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(104298662503949L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[11];
      int var7 = 0;
      String var6 = "W\t\u00adzÃg&^\u0002=\u009a2@\u001aïÞô\u0081Ó1þ\u0098vòHb;Ù{Ï¡8\u0010¤ý6Ó\u0093ø×å\u0088\u009c\u009dÜEjÇ\u0084( \u009aÏrõé0%V{@µTéÄ\u001f\u000e\t,_®Óz$záë\u00004uG_Í$mnå¥5 \u0018Ýã\u009ctcá\u0015r\u0019«÷a\u0095Àw\u0084iH\u008e\u0010\u009b\u000ff÷0ülÂù\u0002~3\u001d\u0006\u0087|ÿâ»4nØ\u0005\u00911\u008dÇ¦Qp\u007fÁu\u007f\u009aA\u008e¦\u0091 µQ\u0088W\u008fF\u007fô8(\u0089\u009a\u00990×Ç<Ö\u0096þ\u009b÷r%\u007fD>úÕÙë3C\u0017ÉaÞ\u000fIt\u0017ô¢çqà¾¤ÿÞë½EÐ»JË\u0089§is4\u0018\u001f§1`_ß*ð\u008f³$,Ví\u0088¾%CR~½¼\u0018s\u0018\u0003Q\u000f\u0011'ÚSó<^}:7y\u0097Ð%\u0089E\u0017)úYB uOD£\t7<\u001aÔ©8\u00058Ý+\u009bö+\u0087)g@\u0091êbÇ\u0010/«\\NF";
      short var8 = 296;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[11];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "øÍ5¼\u000f)ß\u009b\u009aÈZx\u008aÖ-a0uyþ¹)O\u0006\u0091ø§\"$\u0082Æ5ß\u000fÝr,Ù\u001d³ \u009e@®Öð=»âäà\u001fîÅ|=\u0019ËrêÖþ»²\u001fÊµ\u009bÒº\"ÔF";
                  var8 = 73;
                  var5 = '(';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   private void S(MoveMathEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && this.何树友树树树树何友何) {
         if (!this.友友树友友友何友何何.getValue() || !mc.player.onGround()) {
            if (!mc.player.isSpectator()) {
               if (this.友何友树树何树友友友 >= this.友何树树何何树友何树.getValue().intValue()) {
                  RotationUtils.F(new Rotation(21273681362686L, mc.player.getYRot() + (float)(Math.random() - 0.5), mc.player.getXRot()), 3052380832273L);
                  event.setCancelled(false);
                  this.友何友树树何树友友友 = 0;
               }

               KeyMapping.set(mc.options.keySprint.getKey(), false);
               event.setCancelled(true);
            }

            if (!this.友友树友友友何友何何.getValue() || mc.player.onGround() || mc.player.isSpectator()) {
               this.友何友树树何树友友友 = 0;
            }
         }
      }
   }

   private boolean Z() {
      树友何何友何树何树友.E();
      double yLevel = mc.player.getY() - 1.0;
      BlockPos basePos = BlockPos.containing(mc.player.getX(), yLevel, mc.player.getZ());
      if (友何树树何树何何何友.L(67499386939589L, basePos)) {
         return false;
      } else if (this.z(basePos)) {
         return true;
      } else {
         List<BlockPos> candidates = this.e(basePos);
         Iterator var10 = candidates.iterator();
         if (var10.hasNext()) {
            BlockPos pos = (BlockPos)var10.next();
            if (this.z(pos)) {
               return true;
            }
         }

         return false;
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private List<BlockPos> e(BlockPos basePos) {
      树友何何友何树何树友.E();
      List<BlockPos> positions = new ArrayList<>();
      int x = -6;
      int z = -6;
      positions.add(basePos.offset(-6, 0, -6));
      z++;
      x++;
      positions.sort((pos1, pos2) -> {
         double dist1 = basePos.distSqr(pos1);
         double dist2 = basePos.distSqr(pos2);
         return Double.compare(dist1, dist2);
      });
      return positions;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 51;
               case 1 -> 40;
               case 2 -> 49;
               case 3 -> 11;
               case 4 -> 38;
               case 5 -> 37;
               case 6 -> 8;
               case 7 -> 55;
               case 8 -> 28;
               case 9 -> 1;
               case 10 -> 34;
               case 11 -> 21;
               case 12 -> 17;
               case 13 -> 36;
               case 14 -> 6;
               case 15 -> 30;
               case 16 -> 56;
               case 17 -> 18;
               case 18 -> 29;
               case 19 -> 48;
               case 20 -> 59;
               case 21 -> 52;
               case 22 -> 4;
               case 23 -> 53;
               case 24 -> 50;
               case 25 -> 41;
               case 26 -> 61;
               case 27 -> 46;
               case 28 -> 26;
               case 29 -> 33;
               case 30 -> 7;
               case 31 -> 32;
               case 32 -> 12;
               case 33 -> 43;
               case 34 -> 39;
               case 35 -> 31;
               case 36 -> 63;
               case 37 -> 15;
               case 38 -> 45;
               case 39 -> 16;
               case 40 -> 47;
               case 41 -> 19;
               case 42 -> 0;
               case 43 -> 3;
               case 44 -> 23;
               case 45 -> 25;
               case 46 -> 24;
               case 47 -> 14;
               case 48 -> 54;
               case 49 -> 9;
               case 50 -> 2;
               case 51 -> 57;
               case 52 -> 13;
               case 53 -> 5;
               case 54 -> 62;
               case 55 -> 22;
               case 56 -> 42;
               case 57 -> 27;
               case 58 -> 58;
               case 59 -> 35;
               case 60 -> 20;
               case 61 -> 60;
               case 62 -> 44;
               default -> 10;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 3394;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树树何友树何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[ô´O\u0015\u0006s§þèÄ:ìgf·¹, [M#£ÇÛ ¨, \u0016!7ä_¢}¾cu¶\u0093²ãê3z·sC\u001a\u0091¹\u0014, Ä+2F+)Égõ-\u0005Y\u000f\u001cxa, ÚÂËËð¼\u0094Ê\u000b}×\u0099CÁ\u0012\u0091\u00001KÊ¡\u0011\u0011ñ, ÕÖ¢kÃbÕÎZ\u0093¶'\u0085:1`Ô\u000b\u009f\u000b:")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树树何友树何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树树树树何友树何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 194 && var8 != 'n' && var8 != 245 && var8 != 'w') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'z') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'i') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 194) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'n') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 245) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @Override
   public void h() {
      树友何何友何树何树友.E();
      Module scaffold = Cherish.instance.getModuleManager().getModule(树友何何友何树何树友.class);
      if (scaffold.isEnabled() && this.友何何何何树树友树友) {
         scaffold.J(false);
         this.友何何何何树树友树友 = false;
      }

      this.何树友树树树树何友何 = false;
      this.友何友树树何树友友友 = 0;
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "6j9z+\u001b9*tq!\u0006<w\u007f7)\u001b1q{|j\u001d8t{74\u00184}rkj桥桄栕栆佌厏桥伀栕叜";
      j[1] = boolean.class;
      k[1] = "java/lang/Boolean";
      j[2] = "\"jL)\u0017O-*\u0001\"\u001dR(w\nd\u0015O%q\u000e/V栱伔叏厩伟桩叫厊佑伷";
      j[3] = int.class;
      k[3] = "java/lang/Integer";
      j[4] = "/8\u001d5$#$7\fzX:+-\u00029o\n=:\u000e$~&*7";
      j[5] = "jD%iX\u0010e\u0004hbR\r`Yc$A\u001ee_n$^\u0012yF%DB\u0012kOy\\V\u0013|O";
      j[6] = "YfR\u00159zV&\u001f\u001e3gS{\u0014X tV}\u0019X?xJdR49zVm\u001d\u0018\u0000tV}\u0019";
      j[7] = "C\nT.\u0004 LJ\u0019%\u000e=I\u0017\u0012c\u0006 D\u0011\u0016(E&M\u0014\u0016c\u001b#A\u001d\u001f?E桞叫伱伯历伾桞併桵厱";
      j[8] = "hf&Xz8\\E)\u001873VX,E<u^E!C8>\u001dg*R!7V\u0011";
      j[9] = "\u000e=C%Vu\u000e=TyZz\u0014vTgRy\u000e,\u0019FRr\u0005;Ej]h";
      j[10] = "w@W3\u000b w@@o\u0007/m\u000b@q\u000f,wQ\rR\u0016=pJMn";
      j[11] = "NF0qZ9NF'-V6T\r'3^5NWj\u0014R)mB4/^>G";
      j[12] = "&!eH\u0005\u0002&!r\u0014\t\r<jf\t\u001a\u0007,ja\u000e\u0011\u0018f\fx\u0012:\u000e;1}\u0012L?14t";
      j[13] = ";rZcx';rM?t(!9Y\"g\"19^%l={AK.&";
      j[14] = double.class;
      k[14] = "java/lang/Double";
      j[15] = "\u0011\u001fVLc\u001c\u0011\u001fA\u0010o\u0013\u000bTA\r|\u0010Q>K\u0010k\u0016\u000b\u0013M\f";
      j[16] = "Pv\u0000\u00055\rPv\u0017Y9\u0002J=\u0003D*\bZ=\u0018N.\u0001R=7G1\u0014}|\u001a_=\u001cJ76G7\u0007U";
      j[17] = "Kvpa\u001bVKvg=\u0017YQ=s \u0004SA=h*\u0000ZI=G#\u001fOf|j;\u0013GQ7B#\u0003VA";
      j[18] = "JL%\u0006\u0014hE\fh\r\u001eu@QcK\u000es@NxK\tbZM~\u0017\u0018bZ\fY\u0000\bh\\Ph\u0000\bJHLj\u0002\u001eu";
      j[19] = "M#\u0004$9FHl4,{J";
      j[20] = "J\u0010\u0012NtVJ\u0010\u0005\u0012xYP[\u0005\fpZJ\u0001H\u0010u^]\u0010\u0014NUPG\u0014\n0u^]\u0010\u0014";
      j[21] = float.class;
      k[21] = "java/lang/Float";
      j[22] = "bXn\u001f<,m\u0018#\u001461hE(R65dX4R65dX4\u000f}\u0006wS.\bw\u0010hR%";
      j[23] = "r\u0000g\u001fmvy\u000fvP\fxr\u0004r\n";
      j[24] = "=\u000ey%'V`\u0005g8HH<Nz'2Y<N\u001d62_.\fljyO#";
      j[25] = "]$w\u001c:K\u00070te压佹校桍佌伸桑叧佥桍\u0011^)A\u0000(r\b1M\t";
      j[26] = "! \u0002o\u001f<\"0\u0007)vJ\u000f\u0001?\u0012ve3:^;Ff#?\u0018";
      j[27] = "3\u007f\u001c\u0016=,ik\u001fo厌厀桏双厹厬伒厀伋佒zS63&k\u0014T117";
      j[28] = "6l\u001b\u00152>5|\u001eS[C\u0016L&(2u>*\u0013\u00181e;l";
      j[29] = "6S2`\u00163b\u000e2cp\u0007\u001b(\u0015F<\u0001\u0006l;8\u0013+:\u0013oe\u0013(";
      j[30] = "f\rEL\u000bLr\u0012\u001f\u0012q\u001e\\ZM@HN\\`O\u0011\u001b\u001du\n\u000eJI\t";
      j[31] = "bQ*2z\u001faA/t\u0013cLu\r\u000fzTj\u0017\"?yDoQ";
      j[32] = "q\u0005 $3=+\u0011#]伜桋受桬桟桄桘伏受伨Fdzh+N,%=hz";
      j[33] = "|Z-^@N<\u0005!\t9桨厂司桕右叺厲厂栢休0\u0004\u0010 U5\u000fDO,\u0002";
      j[34] = "\rY0\u00036\u0012R_.V\u000e09uW\bo\u000f\u0006\u0000-Wi\u0011S";
      j[35] = "lZCX!/m\u000bS\t\u001fy\n\u0004\u0004[//\n4W\u000et(dR_\tgo";
      j[36] = "#Hn_`i,L.\u001b\u0006|K\u001b*[7+K*/\u001byc{Ks\rj\u007f";
      j[37] = "t1\u0018\u0016cY$u\u0004\u0015ZfXO%{1\u0018odQ\u0002a\\sg";
      j[38] = "Kc\u00184m\u001d\u0011w\u001bM叜厱样栊伣桔栆桫样栊~qf\u0002^w\u0010va\u0000O";
      j[39] = "~bB\u0012i0r%ZNY@\nYljY:2{\u001c\u0019c6uc@";
      j[40] = "\u000fe5Zj\u0010\u000e4%\u000bTFi;rYk\u0019i\u000b!\f?\u0017\u0007m)\u000b,P";
      j[41] = "|\u0004\u0005``}&\u0010\u0006\u0019发住佄伩伾栀栋发栀厷c )(&O\tan(w";
      j[42] = ")(-2\u001c=s<.K\u0007Rv%-0\u001em>gr9nh1>0;Q sa9K";
      j[43] = "~H\u001d+(\u0012*\u0010\u0018'X伿厄栲佼桔厛厡厄佶核Ma\u0001{MQ=5Y~A";
      j[44] = "PN3\u000e\u00032Q\u001f#_=d6\u0010t\r\r36 'XV5XF/_Er";
      j[45] = ">G<P\u0006A~\u00180\u0007\u007f3\u0003\u001b\"L\u001a\u0002~G2L\u0015~";
      j[46] = "\u0001\u007f\u000b:T.A \u0007m-叒叿标桳厗佰栈栥标桳T\u0014*\u0006!Q>Um\u0006p";
      j[47] = "D\u001bwGj&\u001e\u000ft>叛伔叢桲栈佣栁厊叢厨\u0011\u0004x#L\u0015{E#qX";
      j[48] = "S\u000fUqj\u0013P\u001fP7\u0003~bt]7b\u001eSD^'gX";
      j[49] = "EN\u00016\u000e\u0012F^\u0004pg}an<\u000b\u000eYM\b\t;\rIHN";
      j[50] = "\u001e,qAXrD8r8栳栄伦企栎佥栳佀桢桅\u0017\u0001\u0011'Dg}@V'\u0015";
      j[51] = "\u0010\u00042{aA\u0016\u00196}\fFyRe92\u0016ycccr\u0014H\u0018lg2P";
      j[52] = "G\t\u001ad2\u0014D\u0019\u001f\"[\u007fi/'\u0019[MU\u0013F0kNE\u0016\u0000";
      j[53] = "oLM-(,5XNT桃伞栓佡叨伉桃桚栓栥+h#3zXEo$1k";
      j[54] = "}L@j\u0005\u0013iS\u001a4\u007fAG\u0018AhO\u001eG!\u001egDM+S\t;EK";
      j[55] = "xhYX\u0001/t/A\u00041P\tOgc\u0001i-/\fY\r.5s";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean z(BlockPos blockPosition) {
      Vec3 eyesPos = mc.player.getEyePosition();
      树友何何友何树何树友.E();
      Direction[] prioritizedSides = new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP, Direction.DOWN};
      int var14 = prioritizedSides.length;
      int var15 = 0;
      if (0 < var14) {
         Direction side = prioritizedSides[0];
         BlockPos neighbor = blockPosition.relative(side);
         if (友何树树何树何何何友.L(67499386939589L, neighbor)) {
            Vec3 dirVec = new Vec3(side.getNormal().getX(), side.getNormal().getY(), side.getNormal().getZ());
            Vec3 posVec = new Vec3(blockPosition.getX() + 0.5, blockPosition.getY() + 0.5, blockPosition.getZ() + 0.5);
            Vec3 hitVec = posVec.add(dirVec.x * 0.5, dirVec.y * 0.5, dirVec.z * 0.5);
            if (!(eyesPos.distanceToSqr(hitVec) > 25.0)) {
               if (mc.level.clip(new ClipContext(eyesPos, hitVec, Block.COLLIDER, Fluid.NONE, mc.player)).getType() != Type.MISS) {
               }

               Vec3 rotationVector = RotationUtils.e(
                  new Rotation(
                     21273681362686L,
                     (float)Math.toDegrees(Math.atan2(hitVec.z - eyesPos.z, hitVec.x - eyesPos.x)) - 90.0F,
                     (float)(
                        -Math.toDegrees(
                           Math.atan2(
                              hitVec.y - eyesPos.y,
                              Math.sqrt((hitVec.x - eyesPos.x) * (hitVec.x - eyesPos.x) + (hitVec.z - eyesPos.z) * (hitVec.z - eyesPos.z))
                           )
                        )
                     )
                  ),
                  50307048148560L
               );
               Vec3 vector = eyesPos.add(rotationVector.x * 4.5, rotationVector.y * 4.5, rotationVector.z * 4.5);
               BlockHitResult obj = mc.level.clip(new ClipContext(eyesPos, vector, Block.COLLIDER, Fluid.NONE, mc.player));
               if (obj.getType() == Type.BLOCK && obj.getBlockPos().equals(neighbor)) {
                  return true;
               }
            }
         }

         var15++;
      }

      return false;
   }

   @EventTarget
   public void A(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         Module scaffold;
         scaffold = Cherish.instance.getModuleManager().getModule(树友何何友何树何树友.class);
         label57:
         if ((mc.player.fallDistance > 0.0F || mc.player.hurtTime > 0) && !mc.player.onGround() && 友树友友树何树友树友.J(30105215056637L)) {
            if (this.Z()) {
               this.树树何何树何树何树树 = false;
               if (!scaffold.isEnabled()) {
                  scaffold.J(true);
                  this.友何何何何树树友树友 = true;
                  WrapperUtils.s(5);
                  树友何何友何树何树友.树友友树友友友友树何.友友树树友何树树树树 = true;
               }

               if (this.何树友树树树树何友何) {
                  break label57;
               }

               this.何树友树树树树何友何 = true;
               this.友何友树树何树友友友 = 0;
            }

            if (this.何树友树树树树何友何) {
               this.何树友树树树树何友何 = false;
               this.友何友树树何树友友友 = 0;
            }

            if (!this.树树何何树何树何树树) {
               if (this.树何树何友何树树树树.getValue()) {
                  树树何友树何友友何友.d(Cherish.getResourcesManager().resources.getAbsolutePath() + "\\sound\\other\\SFX.wav", 44432082049881L, 1.0F);
               }

               this.树树何何树何树何树树 = true;
               ClientUtils.P(125527250587045L, "§c[AntiVoid] Can't Place!");
            }
         }

         if (mc.level.getBlockState(new BlockPos((int)mc.player.getX(), (int)mc.player.getY() - 1, (int)mc.player.getZ())).isSolid()) {
            if (scaffold.isEnabled() && this.友何何何何树树友树友) {
               scaffold.J(false);
               this.友何何何何树树友树友 = false;
            }

            if (this.何树友树树树树何友何) {
               this.何树友树树树树何友何 = false;
               this.友何友树树何树友友友 = 0;
            }

            this.树树何何树何树何树树 = false;
         }

         if (this.何树友树树树树何友何) {
            this.友何友树树何树友友友++;
         }
      }
   }

   @Override
   public void M() {
      this.友何何何何树树友树友 = false;
      this.树树何何树何树何树树 = false;
      this.何树友树树树树何友何 = false;
      this.友何友树树何树友友友 = 0;
   }

   @EventTarget
   public void T(MoveInputEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L}) && this.何树友树树树树何友何 && this.友友树树何树树树树树.getValue()) {
         event.setForwardImpulse(0.0F);
         event.setLeftImpulse(0.0F);
      }
   }

   private static String HE_WEI_LIN() {
      return "何树友为什么濒天了";
   }

   @EventTarget
   public void G(PacketEvent event) {
      树友何何友何树何树友.E();
      if (event.getSide() == Event.Side.PRE && event.getPacket() instanceof ClientboundSetEntityMotionPacket s12 && s12.getId() == mc.player.getId()) {
         this.何树友树树树树何友何 = true;
      }
   }
}
