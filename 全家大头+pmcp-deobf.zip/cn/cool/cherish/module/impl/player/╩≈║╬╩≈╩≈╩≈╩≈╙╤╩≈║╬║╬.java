package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.item.SpoofItemUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class 树何树树树树友树何何 extends Module implements 何树友 {
   private final BooleanValue 友树何何树何树何何何 = new BooleanValue("Spoof Slot (Visual)", "切换欺骗(视觉)", true);
   private final NumberValue 树友树何树何树友友何 = new NumberValue("Delay", "延迟", 0, 0, 20, 1);
   private boolean 何树友何树何友友何树 = false;
   private int 树友何友何树友友树树 = 0;
   private int 树树树树何树树友树树 = 0;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[32];
   private static final String[] k = new String[32];
   private static String HE_WEI_LIN;

   public 树何树树树树友树何何() {
      super("MidPearl", "中键珍珠", 树何友友何树友友何何.友树树友何友何树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8252755559677038480L, -3238769549713145108L, MethodHandles.lookup().lookupClass()).a(65788008366384L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(60446572762678L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[6];
      int var7 = 0;
      String var6 = "½£`a¨²_\u0084q\u0084äm|D¸M TºÐ¾\u008dÖ\u000bÛ\u0097{éå\u0005\u0083,³u¬ö:8c+}\u0015ß«êë.\u0086\u0093(ëR\u0095\t*9jyRbc\u000e\u001boêåI0ûWÕâÈ\u0098\u0090\u0081\u0095]®Ô\u0092\u0018+2à\u0081\r¡\u0001×(\u001f\u0006)s0õ\u0085þè\u0000(?Ñ¼-w.Ï\u001f\u0088\u009dç\u009eh\u0085Ýk\u0018\u0085n\u0093áSù¼Ñìv\u0093\u0001";
      short var8 = 131;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[6];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "=\u0097££\u001c´\f¼5Î\u0084\u001e±yM<3þlq²ï\u0010\u0012\u0010e\u007f\u008f]tîaAÄÂïâ³bf)";
                  var8 = 41;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private int B() {
      树友何何友何树何树友.E();
      if (this.Q(new Object[]{52406761729175L})) {
         return 0;
      } else {
         int i = 0;
         ItemStack stack = mc.player.getInventory().getItem(0);
         if (!stack.isEmpty() && stack.getItem() == Items.ENDER_PEARL) {
            return 0;
         } else {
            i++;
            return -1;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 33;
               case 1 -> 2;
               case 2 -> 27;
               case 3 -> 61;
               case 4 -> 29;
               case 5 -> 57;
               case 6 -> 35;
               case 7 -> 28;
               case 8 -> 13;
               case 9 -> 12;
               case 10 -> 31;
               case 11 -> 8;
               case 12 -> 37;
               case 13 -> 21;
               case 14 -> 26;
               case 15 -> 9;
               case 16 -> 36;
               case 17 -> 40;
               case 18 -> 56;
               case 19 -> 16;
               case 20 -> 48;
               case 21 -> 54;
               case 22 -> 15;
               case 23 -> 46;
               case 24 -> 38;
               case 25 -> 7;
               case 26 -> 53;
               case 27 -> 22;
               case 28 -> 1;
               case 29 -> 4;
               case 30 -> 63;
               case 31 -> 44;
               case 32 -> 59;
               case 33 -> 30;
               case 34 -> 18;
               case 35 -> 11;
               case 36 -> 20;
               case 37 -> 3;
               case 38 -> 41;
               case 39 -> 49;
               case 40 -> 14;
               case 41 -> 23;
               case 42 -> 34;
               case 43 -> 10;
               case 44 -> 58;
               case 45 -> 50;
               case 46 -> 55;
               case 47 -> 47;
               case 48 -> 60;
               case 49 -> 43;
               case 50 -> 25;
               case 51 -> 6;
               case 52 -> 19;
               case 53 -> 45;
               case 54 -> 42;
               case 55 -> 24;
               case 56 -> 5;
               case 57 -> 32;
               case 58 -> 52;
               case 59 -> 39;
               case 60 -> 51;
               case 61 -> 17;
               case 62 -> 62;
               default -> 0;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 196;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树何树树树树友树何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[4¶\u001dq*²Z³, \u009e\u0012¼¶45©cÌ87\u0007\u008eRú¬, #\u00adÿ\u0088J.?")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何树树树树友树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树何树树树树友树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'Z' && var8 != 210 && var8 != 225 && var8 != 233) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 228) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 229) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'Z') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 210) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 225) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   public void h() {
      树友何何友何树何树友.E();
      if (this.何树友何树何友友何树) {
         this.u();
      }

      this.何树友何树何友友何树 = false;
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "geKV\u0006\u0003h%\u0006]\f\u001emx\r\u001b\u0004\u0003`~\tPG\u0005i{\t\u001b\u0019\u0000er\u0000GG桽佑栚桴栤桸厧栕佞估";
      j[1] = "'N;W\u0010T,A*\u0018lM#[$[[}5L(FJQ\"A";
      j[2] = "K^Mu\u0012wK^Z)\u001exQ\u0015Z7\u0016{KO\u0017\u0014\u000fjLTW(";
      j[3] = "]xr3&S]xeo*\\G3eq\"_]i(V.C~|vm\"TT";
      j[4] = "\u0004\u0006\\?Z\u0000\u000bF\u00114P\u001d\u000e\u001b\u001arC\u000e\u000b\u001d\u0017r\\\u0002\u0017\u0004\\\u0012@\u0002\u0005\r\u0000\nT\u0003\u0012\r";
      j[5] = "_Vif*gP\u0016$m zUK/+3iPM\"+,eLTiG*gP]&k\u0013iPM\"";
      j[6] = "1f\u0002\u007f\u000f~1f\u0015#\u0003q+-\u0015=\u000br1wX\u001c\u000by:`\u00040\u0004c";
      j[7] = "q5]=\u0001%q5Ja\r*k~J\u007f\u0005)q$\u0007~\u0019 k9Y\u007f\r5z\"\u0007^\u0019 k9y\u007f\r5z\"nr\u0001)R?Mv";
      j[8] = "\u001cIMC\u001bU\u001cIZ\u001f\u0017Z\u0006\u0002N\u0002\u0004P\u0016\u0002\\\u0003\u0002U\u0006U\u0017\u001d\u001a]\u000bIKC?R\u0004IW\u0019\u0019N\u000b";
      j[9] = int.class;
      k[9] = "java/lang/Integer";
      j[10] = "\u0007\u0007&'(@\u0007\u00071{$O\u001dL%f7E\rL\u001bg1L\u001b\u00031},F\u0007*3g!";
      j[11] = "O\"\u00153z\u007f@bX8pbE?S~x\u007fH9W5;yA<W~e|M5^\";栁叧伙佮厛佀栁佹桝台";
      j[12] = "DmeEI\u0004pNj\u0005\u0004\u000fzSoX\u000fIrNb^\u000b\u00021liO\u0012\u000bz\u001a";
      j[13] = boolean.class;
      k[13] = "java/lang/Boolean";
      j[14] = "\u0012<?oQ{\u001d|rd[f\u0018!y\"S{\u0015'}i\u0010栅伤厙叚余栯叟厺伇佄";
      j[15] = "E\u001f_u hE\u001fH),g_T\\4?mOTB/(l\u00053_> r";
      j[16] = "dJ\u0018>/SdJ\u000fb#\\~\u0001\u001b\u007f0Vn\u0001\u0005d'W$f\u0018u/";
      j[17] = "r93-KQy6\"b*_r=&8";
      j[18] = "<\u0017b\nb6)J8\f\u00136\u0002JcP#d\u0002v3Sti?H9\bv$";
      j[19] = "\u007f\u0015\ng\\mj\u001c\t\nHT+\u0019\r1@1m\u001fTl!m.\u001d\u000ekD+(DS\n";
      j[20] = "\u000e\u0013\u001eTjI\t\u0002TSUI`R^\fd\u0018`c^T+BX\u0006XW?J";
      j[21] = "zmE\u0000WaodFm栳厛栎伀档估栳厛叔伀zV\u0010!-$C\n\u001agy";
      j[22] = "J*@\\sk_#C1反桋佺佇桦佬栗伏佺佇\u007f\n\u007f,I~\u0004\t?jJ";
      j[23] = "1\u0012e&<Qp\u001a'6\rDZY&s2\u0010Zh\"!2Dt\r!*<Q";
      j[24] = " 8rI\u001f\f}0cOy\u0005Jq$\u0000FTJJ'S\u0010\u001ap#\u007fT\u001bP";
      j[25] = "ufhf\u001d\u001371>:vk\u0003\u0017I\b6g\f\u001a\u000f`FIs=2\"\u0011\u001f/";
      j[26] = "7-\u001e\u0011\u001a\r<j\u0013Js~\u0007&H\u0012\u0003N`(]C\u00183";
      j[27] = "\u0019\u001c};\\g\f\u0015~V佼桇厷佱桛伋叢厝伩栵Bg\u001f9OQ2i\u00192E";
      j[28] = "Tzbf\b\u0019Asa\u000b桬根栠桓伀栒桬口栠桓]5\u0017IH'4m\u0010B\u0002";
      j[29] = "X[lZlI\u0019S.J]\\3\u0010/\u000fc\f3!/G'R[O(VmU";
      j[30] = "l\u001eph=yy\u0017s\u0005桙厃作叭伒栜厃厃栘样O;\")pC&c%\":";
      j[31] = "V<2\u0005bP\u001b3f\u0017X厭桾桔原伴厛伳桾厎桅ii\u001f\t!fW$\u0010]3";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void u() {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.友树何何树何树何何何.getValue()) {
            if (!SpoofItemUtils.e(96871185550697L)) {
               return;
            }

            SpoofItemUtils.z(29996098265021L);
         }

         int i = 0;
         if (0 == this.树友何友何树友友树树) {
            mc.player.getInventory().selected = 0;
            mc.gameMode.tick();
         }

         i++;
      }
   }

   @Override
   public void M() {
      this.树友何友何树友友树树 = 0;
      this.何树友何树何友友何树 = false;
      this.树树树树何树树友树树 = 0;
   }

   private static String HE_DA_WEI() {
      return "何炜霖230622200409390090";
   }

   @EventTarget
   public void Q(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})) {
         label33: {
            if (mc.options.keyPickItem.isDown()) {
               if (this.何树友何树何友友何树 || this.树树树树何树树友树树 > 0) {
                  break label33;
               }

               this.树友何友何树友友树树 = mc.player.getInventory().selected;
               if (this.友树何何树何树何何何.getValue() && !SpoofItemUtils.e(96871185550697L)) {
                  SpoofItemUtils.m(this.树友何友何树友友树树, 18080999206181L);
               }

               int pearlSlot = this.B();
               if (pearlSlot != -1) {
                  mc.player.getInventory().selected = pearlSlot;
                  mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                  this.何树友何树何友友何树 = true;
                  this.树树树树何树树友树树 = this.树友树何树何树友友何.getValue().intValue();
               }
            }

            if (this.何树友何树何友友何树) {
               this.u();
               this.何树友何树何友友何树 = false;
            }
         }

         if (this.树树树树何树树友树树 > 0) {
            this.树树树树何树树友树树--;
         }
      }
   }
}
