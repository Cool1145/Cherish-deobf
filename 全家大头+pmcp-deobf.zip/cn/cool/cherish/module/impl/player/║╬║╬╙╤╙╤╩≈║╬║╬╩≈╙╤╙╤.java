package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.ui.何树树友何友友友何何;
import cn.cool.cherish.utils.animations.友何友树树树树何树友;
import cn.cool.cherish.utils.packet.BlinkUtils;
import cn.cool.cherish.utils.render.友友树何树树友树友何;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.RemotePlayer;

public class 何何友友树何何树友友 extends Module implements 何树友 {
   private final ModeValue 友何何何树何何树树树;
   private final NumberValue 何友何友何树何树友树;
   private final BooleanValue 友何友树何何树何何何;
   private final NumberValue 何友友何何树树何树树;
   private final BooleanValue 何友友友何友树友树何;
   private final NumberValue 树树何何何何友友友何;
   private final BooleanValue 树树友树树友友友树友;
   private final BooleanValue 树何何友友树友树何何;
   private final BooleanValue 何友友何何树友何树树;
   private final BooleanValue 树树何友友树树友何何;
   private final NumberValue 友友何友何友何树何树;
   private final BooleanValue 树友友树友何树友友树;
   private final 友何友树树树树何树友 树何何友树友友何友友;
   private int 树友何何树何何友树何;
   private RemotePlayer 友何树何友树树何何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[57];
   private static final String[] k = new String[57];
   private static String HE_WEI_LIN;

   public 何何友友树何何树友友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;I)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/何何友友树何何树友友.a J
      // 003: ldc2_w 110435244646803
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 83467187983686
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 9229
      // 014: ldc2_w 967255840479449597
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 15944
      // 021: ldc2_w 6800969728003804041
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -2285369251330107284
      // 02e: lload 1
      // 02f: invokedynamic Ñ (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: bipush 86
      // 036: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;I)V
      // 039: aload 0
      // 03a: new cn/cool/cherish/value/impl/ModeValue
      // 03d: dup
      // 03e: sipush 23864
      // 041: ldc2_w 4768244414477494479
      // 044: lload 1
      // 045: lxor
      // 046: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04b: sipush 18569
      // 04e: ldc2_w 8037445424101227884
      // 051: lload 1
      // 052: lxor
      // 053: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 058: bipush 3
      // 059: anewarray 87
      // 05c: dup
      // 05d: bipush 0
      // 05e: sipush 12431
      // 061: ldc2_w 145208397229589832
      // 064: lload 1
      // 065: lxor
      // 066: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 06b: aastore
      // 06c: dup
      // 06d: bipush 1
      // 06e: sipush 1250
      // 071: ldc2_w 4925542856324985096
      // 074: lload 1
      // 075: lxor
      // 076: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07b: aastore
      // 07c: dup
      // 07d: bipush 2
      // 07e: sipush 3844
      // 081: ldc2_w 3901811243115395820
      // 084: lload 1
      // 085: lxor
      // 086: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 08b: aastore
      // 08c: sipush 18303
      // 08f: ldc2_w 4248339001955414658
      // 092: lload 1
      // 093: lxor
      // 094: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 099: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 09c: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.友何何何树何何树树树 Lcn/cool/cherish/value/impl/ModeValue;
      // 09f: aload 0
      // 0a0: new cn/cool/cherish/value/impl/NumberValue
      // 0a3: dup
      // 0a4: sipush 22252
      // 0a7: ldc2_w 157240058337223436
      // 0aa: lload 1
      // 0ab: lxor
      // 0ac: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b1: sipush 13858
      // 0b4: ldc2_w 1560720029160113104
      // 0b7: lload 1
      // 0b8: lxor
      // 0b9: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0be: bipush 20
      // 0c0: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0c3: bipush 5
      // 0c4: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0c7: bipush 60
      // 0c9: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0cc: bipush 1
      // 0cd: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0d0: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0d3: aload 0
      // 0d4: invokedynamic get (Lcn/cool/cherish/module/impl/player/何何友友树何何树友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/player/何何友友树何何树友友.b ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 0d9: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0dc: checkcast cn/cool/cherish/value/impl/NumberValue
      // 0df: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.何友何友何树何树友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 0e2: aload 0
      // 0e3: new cn/cool/cherish/value/impl/BooleanValue
      // 0e6: dup
      // 0e7: sipush 10603
      // 0ea: ldc2_w 3326543103496035480
      // 0ed: lload 1
      // 0ee: lxor
      // 0ef: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f4: sipush 27915
      // 0f7: ldc2_w 595434425932667108
      // 0fa: lload 1
      // 0fb: lxor
      // 0fc: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 101: bipush 1
      // 102: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 105: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 108: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.友何友树何何树何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 10b: aload 0
      // 10c: new cn/cool/cherish/value/impl/NumberValue
      // 10f: dup
      // 110: sipush 3672
      // 113: ldc2_w 4841774018257763258
      // 116: lload 1
      // 117: lxor
      // 118: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11d: sipush 11458
      // 120: ldc2_w 2964123189483444541
      // 123: lload 1
      // 124: lxor
      // 125: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 12a: bipush 40
      // 12c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 12f: bipush 10
      // 131: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 134: bipush 100
      // 136: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 139: bipush 1
      // 13a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 13d: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 140: aload 0
      // 141: ldc2_w -2286050305141755348
      // 144: lload 1
      // 145: invokedynamic Þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14a: dup
      // 14b: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 14e: pop
      // 14f: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 154: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 157: checkcast cn/cool/cherish/value/impl/NumberValue
      // 15a: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.何友友何何树树何树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 15d: aload 0
      // 15e: new cn/cool/cherish/value/impl/BooleanValue
      // 161: dup
      // 162: sipush 23223
      // 165: ldc2_w 4427680069710344055
      // 168: lload 1
      // 169: lxor
      // 16a: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16f: sipush 4268
      // 172: ldc2_w 4244143837717898607
      // 175: lload 1
      // 176: lxor
      // 177: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 17c: bipush 0
      // 17d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 180: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 183: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.何友友友何友树友树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 186: aload 0
      // 187: new cn/cool/cherish/value/impl/NumberValue
      // 18a: dup
      // 18b: sipush 11097
      // 18e: ldc2_w 6600087598455103166
      // 191: lload 1
      // 192: lxor
      // 193: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 198: sipush 2426
      // 19b: ldc2_w 5278634598070664332
      // 19e: lload 1
      // 19f: lxor
      // 1a0: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1a5: bipush 5
      // 1a6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1a9: bipush 1
      // 1aa: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1ad: bipush 20
      // 1af: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1b2: bipush 1
      // 1b3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1b6: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1b9: aload 0
      // 1ba: ldc2_w -2284313018059949659
      // 1bd: lload 1
      // 1be: invokedynamic Þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c3: dup
      // 1c4: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 1c7: pop
      // 1c8: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 1cd: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 1d0: checkcast cn/cool/cherish/value/impl/NumberValue
      // 1d3: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.树树何何何何友友友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 1d6: aload 0
      // 1d7: new cn/cool/cherish/value/impl/BooleanValue
      // 1da: dup
      // 1db: sipush 28872
      // 1de: ldc2_w 6118118107190510908
      // 1e1: lload 1
      // 1e2: lxor
      // 1e3: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e8: sipush 15123
      // 1eb: ldc2_w 3130398455929409271
      // 1ee: lload 1
      // 1ef: lxor
      // 1f0: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f5: bipush 1
      // 1f6: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1f9: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1fc: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.树树友树树友友友树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1ff: aload 0
      // 200: new cn/cool/cherish/value/impl/BooleanValue
      // 203: dup
      // 204: sipush 14706
      // 207: ldc2_w 7622700371554733198
      // 20a: lload 1
      // 20b: lxor
      // 20c: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 211: sipush 26994
      // 214: ldc2_w 1561703148628892809
      // 217: lload 1
      // 218: lxor
      // 219: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 21e: bipush 1
      // 21f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 222: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 225: aload 0
      // 226: ldc2_w -2284536241282441770
      // 229: lload 1
      // 22a: invokedynamic Þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 22f: dup
      // 230: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 233: pop
      // 234: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 239: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 23c: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 23f: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.树何何友友树友树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 242: aload 0
      // 243: new cn/cool/cherish/value/impl/BooleanValue
      // 246: dup
      // 247: sipush 27027
      // 24a: ldc2_w 7373639255155498098
      // 24d: lload 1
      // 24e: lxor
      // 24f: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 254: sipush 7834
      // 257: ldc2_w 1081078677742037860
      // 25a: lload 1
      // 25b: lxor
      // 25c: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 261: bipush 1
      // 262: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 265: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 268: aload 0
      // 269: ldc2_w -2284536241282441770
      // 26c: lload 1
      // 26d: invokedynamic Þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 272: dup
      // 273: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 276: pop
      // 277: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 27c: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 27f: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 282: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.何友友何何树友何树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 285: aload 0
      // 286: new cn/cool/cherish/value/impl/BooleanValue
      // 289: dup
      // 28a: sipush 486
      // 28d: ldc2_w 6496266834865402885
      // 290: lload 1
      // 291: lxor
      // 292: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 297: sipush 20414
      // 29a: ldc2_w 5277519190046997116
      // 29d: lload 1
      // 29e: lxor
      // 29f: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2a4: bipush 1
      // 2a5: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2a8: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2ab: aload 0
      // 2ac: ldc2_w -2284536241282441770
      // 2af: lload 1
      // 2b0: invokedynamic Þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2b5: dup
      // 2b6: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 2b9: pop
      // 2ba: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 2bf: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 2c2: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 2c5: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.树树何友友树树友何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2c8: aload 0
      // 2c9: new cn/cool/cherish/value/impl/NumberValue
      // 2cc: dup
      // 2cd: sipush 9440
      // 2d0: ldc2_w 2879794998983299341
      // 2d3: lload 1
      // 2d4: lxor
      // 2d5: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2da: sipush 4608
      // 2dd: ldc2_w 8927505435578116073
      // 2e0: lload 1
      // 2e1: lxor
      // 2e2: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2e7: ldc2_w 0.3
      // 2ea: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 2ed: dconst_0
      // 2ee: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 2f1: dconst_1
      // 2f2: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 2f5: ldc2_w 0.05
      // 2f8: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 2fb: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 2fe: aload 0
      // 2ff: invokedynamic get (Lcn/cool/cherish/module/impl/player/何何友友树何何树友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/player/何何友友树何何树友友.E ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 304: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 307: checkcast cn/cool/cherish/value/impl/NumberValue
      // 30a: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.友友何友何友何树何树 Lcn/cool/cherish/value/impl/NumberValue;
      // 30d: aload 0
      // 30e: new cn/cool/cherish/value/impl/BooleanValue
      // 311: dup
      // 312: sipush 26819
      // 315: ldc2_w 4036119004377570605
      // 318: lload 1
      // 319: lxor
      // 31a: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 31f: sipush 19532
      // 322: ldc2_w 8716097767951530410
      // 325: lload 1
      // 326: lxor
      // 327: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 32c: bipush 1
      // 32d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 330: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 333: aload 0
      // 334: ldc2_w -2284536241282441770
      // 337: lload 1
      // 338: invokedynamic Þ (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 33d: dup
      // 33e: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 341: pop
      // 342: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 347: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 34a: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 34d: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.树友友树友何树友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 350: aload 0
      // 351: new cn/cool/cherish/utils/animations/何何友树友树友树树何
      // 354: dup
      // 355: sipush 500
      // 358: dconst_1
      // 359: lload 3
      // 35a: ldc 1.8
      // 35c: invokespecial cn/cool/cherish/utils/animations/何何友树友树友树树何.<init> (IDJF)V
      // 35f: putfield cn/cool/cherish/module/impl/player/何何友友树何何树友友.树何何友树友友何友友 Lcn/cool/cherish/utils/animations/友何友树树树树何树友;
      // 362: aload 0
      // 363: bipush 1
      // 364: ldc2_w -2284606337087864819
      // 367: lload 1
      // 368: invokedynamic Y (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/player/何何友友树何何树友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 36d: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-3128821071544377195L, -5863377751663945007L, MethodHandles.lookup().lookupClass()).a(125117841742444L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 121025476310567L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[37];
      int var7 = 0;
      String var6 = "\u00943C\u0004naÃÜªBÞç\u0011%h\u0099\u009e±>·®3\u0090$ÍÔ\u0087\u0090U&ÓE Î\u0097Óó6vû$\u001f>\u009cWå\u008fr\u009f°=1©òÚ±6!:F¨w£>¯\u0018\u0081Þ\u009c³w¹¤´Èß}ÕP\u0087»|ÚD\u008fÎTSÈ\b\u0018CÑGêÓÎ~å2ì¶õí\u001eWN_\u0018A\u000fìæhµ \u0099CdðHWì<\u008eÝ±\u0086\u0092Ò@º½÷)r\u0093ÿÿ\u001a£í²í\u0000RXû\u0018Ã4b7{ìÿIÚ°K\u009d\u0086\t~{7`\u0019\u0081¹sk\u0080\u0010Õª£ýêQ\u0096¾\u008b¾\u0014wOö}[\u0018¹\u0006\býº\u0017¢t\u0012\u0002?½õPC*\u001d]\u001b'ËË¼%\u0010P·GV\u001fÑxU\u000e\u0012\u0082\u0084ñq\u0081\u009c\u0010Á«j'©-â¢¨zq)\u000e.\u0086Z \fVx°Ø«Ì³Ý\u009d\u0001{¡|(~\u00171º~#ëÛÚm-\u0003Ü\f¿\u0006; fog8\n\u008eÆ;h;l|'yá]tÌù<ºqC©iMä¸ñ¯\u00adÑ \u001a\u008fU1ve\u0016_ª\u009dpÚQg§nuÝ\u0019JFU\u0011\u0086 Ù]U\u008e\u0019\u008ao\u00189Ò\u0003ÃfÎÞ\u0012Â¶ÇCA-\u0019UÅPcqT\u0014Tg Ý\u00106\u0011+ð\tø¢\u00922yÛ'ç\u00969Ý¢¨-Æ\u008dno\u0003g\u009eè°\u0002ç\u0010·fýv\u0083\u0012²·àøIÃ\u0006½\u008a\u009c\u0018vY\u008f\u001etQ Úã\"¢\u008aé\u0018Dè}*>ªÿwæ\u000e å\u0089îÌ\u0097\u007f\t\f,ÄJÞìxëN ³Q\u001bY\u0011¾Ò\u008fUÖL\u0019\u0012Ut\u0018>úJÛÖ\u0001\u0010×ì\rè.`{M§¢\u0080\u000f²8\u008fpð\u0010\u0089²Òl³}kj\u009bz\u009dønø\u000bö\u0010É\u0007Zw£Øc'¸\u0096ÊY\u00adî\u0016ó\u0018á\\7\u0090\u001cb¹;\u0011\u00064\f<Ä×ÊÜ§\u008e®\u0087\u00ad\u008e\u0088 µ\u001cÿ#¾¢\u0098ùÿX\u009cìTvæ\u0002t\u009c\u0012\u0085\u009dS:²ÞÞªq\t\u0085~\b\u0018Å\u0011h·È\u0015t%í¥R¡¾\u0016Û\u001c\u0088°\u008d\u0082.z\u008d\u0011\u0010ën\u001fv\u009b\u0091*øE\u009d~Ýu\b\u0000\u001b\u0010\u008a\u008ci'|â5°rLæ¬\tòËÏ\u0010\u009cÔÞpR\"ª\u0080;î|Ê\u001d\u0091G±\u0010K\nÚ\u0006\u0092@^'B)¶\u0086W3®' {¨_Hô¢º\u009dDÕ\u0086\u0011á*\u0088\u001ck;,\u0098\u009b2]yI¤\u0097\\IÃå® \u000fl@=P\u008a×\u0095\u0087\u0088X\u0003nfý\u0092\u007fäü`pµ;××\u0088\u001dv\u0012ÒXà\u0010F\u000f¾\u009f;¡yI%ú\u007fË\n\u0086e\u000f\u0010\u0097\u0093~²«á¤G^è±}úã\u001cF ß\u0007¢-ùÔ\u0001\u001e9\"J7»G\u0002·\u0003äA\u0002Íü\u0006å\u0000§¿ma\u0002²\u0091 |96ÓÆAB\u0018\u001c\u0011·¸\u0096\u00871pÕ\n%8»ué\u009b\u0002\u0091öÙó\u0007/¨\u0010«$%Í¬\u0090\u0016Óöõ\u009f\u0081Ò%G ";
      short var8 = 874;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[37];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u0003'k®¤ì\u0088\u0019\u0014Í\u009f×\u0098\u0018É(|æ\u001cßß\u0094¨l\u0010¸\u00990Â\u008f×©\u008f\u0011\u009e\u001d\u001a\u009a\u0081\u001d'";
                  var8 = 41;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 何何友友树何何树友友.a ^ 112745447396385L;
      long ax = a ^ 48869803994330L;
      long axx = a ^ 99393616585799L;
      c<"Z">(6193991653937796834L, a);
      if (!this.w(new Object[]{ax})) {
         BlinkUtils.M(new Object[]{axx});
         c<"Y">(this, null, 6196758717525175240L, a);
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 53;
               case 1 -> 36;
               case 2 -> 63;
               case 3 -> 23;
               case 4 -> 17;
               case 5 -> 38;
               case 6 -> 54;
               case 7 -> 1;
               case 8 -> 2;
               case 9 -> 6;
               case 10 -> 8;
               case 11 -> 42;
               case 12 -> 43;
               case 13 -> 25;
               case 14 -> 59;
               case 15 -> 15;
               case 16 -> 33;
               case 17 -> 5;
               case 18 -> 47;
               case 19 -> 39;
               case 20 -> 9;
               case 21 -> 11;
               case 22 -> 57;
               case 23 -> 21;
               case 24 -> 29;
               case 25 -> 60;
               case 26 -> 22;
               case 27 -> 37;
               case 28 -> 62;
               case 29 -> 40;
               case 30 -> 28;
               case 31 -> 4;
               case 32 -> 50;
               case 33 -> 14;
               case 34 -> 26;
               case 35 -> 45;
               case 36 -> 35;
               case 37 -> 3;
               case 38 -> 12;
               case 39 -> 27;
               case 40 -> 19;
               case 41 -> 48;
               case 42 -> 34;
               case 43 -> 7;
               case 44 -> 18;
               case 45 -> 30;
               case 46 -> 32;
               case 47 -> 13;
               case 48 -> 51;
               case 49 -> 55;
               case 50 -> 16;
               case 51 -> 24;
               case 52 -> 20;
               case 53 -> 10;
               case 54 -> 61;
               case 55 -> 41;
               case 56 -> 0;
               case 57 -> 46;
               case 58 -> 44;
               case 59 -> 52;
               case 60 -> 49;
               case 61 -> 31;
               case 62 -> 56;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21923;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/何何友友树何何树友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何何友友树何何树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/何何友友树何何树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 222 && var8 != 'Y' && var8 != 209 && var8 != 203) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 254) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 222) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Y') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 209) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "\bK\u00070+r\u0007\u000bJ;!o\u0002VA})r\u000fPE6jt\u0006UE}4q\n\\L!j佈伾叮叢桂休佈桺叮叢";
      j[1] = "n\u0012b\u001by\faR/\u0010s\u0011d\u000f$V`\u0002a\t)V\u007f\u000e}\u0010b:y\fa\u0019-\u0016@\u0002a\t)";
      j[2] = "Qji,<\u0010^*$'6\r[w/a>\u0010Vq+*}\u0016_t+a7\u0016At+.*Q叹栕桖桞桂伪栣栕厌厄";
      j[3] = "\u0015ITrZl\u001a\t\u0019yPq\u001fT\u0012?Cb\u001aR\u001f?\\n\u0006KT栀叾佖厽佲伯叚栤栒厽";
      j[4] = "\ftI*Z_\u00034\u0004!PB\u0006i\u000fgCQ\u0003o\u0002g\\]\u001fvI\u0007@]\r\u007f\u0015\u001fT\\\u001a\u007f";
      j[5] = "F\u0003N%;qIC\u0003.1lL\u001e\bh9qA\u0018\f#zwH\u001d\fh$rD\u0014\u00054z佋佰厦伵厍桅叕叮伸伵";
      j[6] = " \b\u0015t&\"\u0014+\u001a4k)\u001e6\u001fi`o\u0016+\u0012od$U\t\u0019~}-\u001e\u007f";
      j[7] = "$Z\u0006\u0000:z$Z\u0011\\6u>\u0011\u0011B>v$K\\^;r3Z\u0000\u0000\u0005v'P\u0006K\u0007\u007f+F\u0017\\";
      j[8] = "\u001bh\u0014\u0013;7\u0010g\u0005\\G.\u001f}\u000b\u001fp\u001e\tj\u0007\u0002a2\u001eg";
      j[9] = int.class;
      k[9] = "java/lang/Integer";
      j[10] = "8M]DB~7\r\u0010OHc2P\u001b\t@~?V\u001fB\u0003佄伎叨伦佲另佄伎栲桢";
      j[11] = float.class;
      k[11] = "java/lang/Float";
      j[12] = "\u0010\u0018DZE\u001c\u0010\u0018S\u0006I\u0013\nSS\u0018A\u0010\u0010\t\u001e\u0004D\u0014\u0007\u0018BZd\u001a\u001d\u001c\\$D\u0014\u0007\u0018B";
      j[13] = "J\u0010:Tf\u000eEPw_l\u0013@\r|\u0019\u007f\u0000E\u000bq\u0019`\fY\u0012:zf\u0005L(u[|\u0004";
      j[14] = "N`e\u0004\u0018\u000bA (\u000f\u0012\u0016D}#I\u0002\u0010Db8I\u0007\u0005Ne.\u0013Y&Ag%\f\"\u0010Db8";
      j[15] = "#Ws,`H,\u0017>'jU)J5azS)U.anI)T<;fH.Js厄佚召桑栨桌厄栞佲压";
      j[16] = "\u000fy\u000f+\u0005m\u00009B \u000fp\u0005dIf\u0007m\bbM-Dk\u0001gMf\u000ek\u001fgM)\u0013,$Be";
      j[17] = "aX/(-cn\u0018b#'~kEie7xkZre#bk[`?+clE/厀众叇栓栧栐桚众栝叉";
      j[18] = double.class;
      k[18] = "java/lang/Double";
      j[19] = "\u0003w1$H)\u0003w&xD&\u0019<2eW,\t<5b\\3CD i\u0016";
      j[20] = "[[\r\u0016FeT\u001b@\u001dLxQFK[\\~QYP[AoTEF\u0007\u0007XWAB\u0001@eV";
      j[21] = "\u001b6cgZ7\u00109r(;9\u001b2vr";
      j[22] = "ks.-{')b:F桛桎伊佖伜伛厁厔厔佖A}-/kg |9:h";
      j[23] = "F\u000eH'j!\u0004\u001f\\L伎厒伧厵佺桕伎案厹桯'w<)F\u001aFv(<E";
      j[24] = "\u0003\u0002PQd{F\u001bV\u0014\u000e,iZX\u001d3|ic\u0002_d+G\n\u0013O2:";
      j[25] = "\u001c\u001dmq*\u001b^\fy\u001a叐伶口桼佟佇栊伶佽伸\u0002h.\u000f\u0019\\e}vW";
      j[26] = "o\u0015\u0004\u0017i\u0017;]\u0010\u0001\u0000伦伋估厾伭佝伦桏估厾p:\u001d=\u001c\u001b\u001ce\u001d3\u0014";
      j[27] = "0\u0011e}t!0B1fL厁桀佰及栜厏桛伄叮栐\u0005r$7N5?20#H";
      j[28] = "\nn<4MEH\u007f(_厷叶佫叕伎厜伩栬佫栏Sd\u001bM\nz2e\u000fX\t";
      j[29] = "O`N=\f\u0002N0\u000f%b\u0003seQ)\u0004\u0006\u00100\\1\u0001|";
      j[30] = "\u0001K\u0000%^zCZ\u0014N厤佗你佮桶伓伺栓栤株o\u007f\u0003kC_T5\u000b7\u0000";
      j[31] = "Qiad!-\u0013xu\u000f栁伀估叒栗双叛伀厮叒\u000ed eTtulg%\u000f";
      j[32] = "]\u0000vdI\r]S\"\u007fq桷栭佡叙栅桨厭栭栥佇\u001c\u001d\bT]yw\u001f\u0002\u0005C";
      j[33] = "\u0006c/\u0002*,Dr;i栊原叹栂厃伴栊原叹栂@\u001b.8\u0003\"'\u000ev`";
      j[34] = "Bx;L\u0006gD!4Nk佊厾厃厑厶厨佊传桙厑uT/\u0014y?\u0005Rv\u001b{";
      j[35] = "&krNc\u0000$a#P\u0000\u0005\u001d=(\u00130R\u001d\ry]j\u00023dhM<\u0013";
      j[36] = "\u001cY\u0013V!_@\u000e\u000e\u0012G\u0001{\u0005W\\wR{?P\u0017&\u0005\u0014_\u000f\u000ey\u000f";
      j[37] = "hSV%+bjY\u0007;HgS\u0005\fxw8S5]6\"`}\\L&tq";
      j[38] = "tEX5P41\\^p:c\u001e\u001dPy\u00070\u001e$\n;Pd0M\u001b+\u0006u";
      j[39] = "9@]\u0010A3{QI{\u0011C;\u0002V\u0003H1\u007fQX\u0002x}?\\JK\n9lRK{";
      j[40] = "K8\u001b4[\u0001KkO/c桻叡余厴厏厠厡栻栝伪L\u000eZCc\u000b'\b\u0004\u001et";
      j[41] = "\u0003\"i\u00169\\\u0003q=\r\u0001~,EY'Gt'\u001elRmGR}l\u00019\\";
      j[42] = "\u000b\f|bC:\u001f\u001d#5y伅桻桴伐框厺厛伿厮伐_\u00109SPw=\u0004(\f\u0007";
      j[43] = "&@SNp\tdQG%桐伤佇叻叿格厊桠佇佥<Wt\u001d#\u0001[B,E";
      j[44] = "q\u0019{\u0004\u000bP3\boo栫根伐厢受桶栫口伐似\u0014\u001d\u000fDtXs\bW\u001c";
      j[45] = "$HZD3wfYN/栓叄佅佭栬佲佗叄栁佭5\u0011li{\f\u000fQx}}";
      j[46] = "p/RdX|2>F\u000f桸栕厏桎栤双厢叏桕厔=}\\hunZh\u00040";
      j[47] = "P\u000f//cS\u0012\u001e;D伇叠厯伪伝桝厙佾桵桮@6gGUN'#?\u001f";
      j[48] = "\u001d1A\u0001rTX(GD\u0018\u0003wj@M(PwPG\u0006y\u0007\u00180\u0018\u001f&\r";
      j[49] = "\u0007Y_\u001d\u001e\u0019EHKv佺厪司叢佭厵栾厪栢佼0\u0004\u001a\r\u0002\u0018W\u0011BU";
      j[50] = "SOL\b\u0013\u001d_UUM\"栿叺叭栴桨叡佻佤佳佰q\u0013BXPAJYJ\u0004\u0013";
      j[51] = "N,},P\u0006\u001adi:9桳厴厗栝厈叺厩伪桍叇K\u0000\u0012\u000e3m'TZ\u001a%";
      j[52] = "ZrFDty\u0018cR/伐及厥佗佴栶桔佔桿栓)\u0014\"qZfH\u00156dY";
      j[53] = "O\u0001^\u001fdk\r\u0010Jt厞但桪伤史桭桄但伮伤1I<\"\u000f\u0013\b\f%$J";
      j[54] = "\u001e2{VM\u0017[+}\u0013'@tjs\u001a\u001a\u0012tS)XMGZ:8H\u001bV";
      j[55] = "p=\u001cA\u0007\u0014d,C\u0016=伫栀桅栴伡你厵叚原叮|T\u0017(a\u0017\u001e@\u0006w6";
      j[56] = "\u0015\u0018\u00060M[\u0017\u0012W..^.N\\m\u001e\b.~\r#DY\u0000\u0017\u001c3\u0012H";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 何何友友树何何树友友.a ^ 36098889373638L;
      long ax = a ^ 116737586720573L;
      long axx = a ^ 59489672262362L;
      long var10001 = a ^ 10868738659576L;
      c<"Z">(-7632971580567481083L, a);
      if (!this.w(new Object[]{ax})) {
         c<"Y">(this, new RemotePlayer(mc.level, mc.player.getGameProfile()), -7631339231905224657L, a);
         c<"Y">(c<"Þ">(this, -7631339231905224657L, a), c<"Þ">(mc.player, -7630142666358954645L, a), -7630980895965662799L, a);
         c<"Þ">(this, -7631339231905224657L, a).copyPosition(mc.player);
         c<"Þ">(this, -7631339231905224657L, a).setUUID(mc.player.getUUID());
         c<"Y">(this, 1, -7629601343703288232L, a);
         WrapperUtils.s(new Object[]{axx});
         this.y(false);
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void N(Render3DEvent event) {
      long a = 何何友友树何何树友友.a ^ 33929452701221L;
      long ax = a ^ 92510036754142L;
      long axx = a ^ 45005322851247L;
      long axxx = a ^ 77665813561598L;
      c<"Z">(572241680738813158L, a);
      if (!this.w(new Object[]{ax}) && c<"Þ">(this, 575837119170509408L, a).getValue()) {
         PoseStack poseStack = event.poseStack();
         int primaryColor = c<"Þ">(this, 575536254315359103L, a).getValue()
            ? 树树何友友友友何树友.w(axx, 10, 1).getRGB()
            : c<"Þ">(c<"Ñ">(574978511706502627L, a), 572183206236230887L, a).a();
         友友树何树树友树友何.N(
            poseStack,
            c<"Þ">(this, 575114303884687820L, a),
            primaryColor,
            c<"Þ">(this, 575945776236631467L, a).getValue(),
            c<"Þ">(this, 575796044925779998L, a).getValue(),
            c<"Þ">(this, 575753976113326266L, a).getValue(),
            c<"Þ">(this, 572358870639138453L, a).getValue().floatValue(),
            axxx
         );
      }
   }

   @EventTarget
   public void W(LivingUpdateEvent event) {
      long a = 何何友友树何何树友友.a ^ 44230508777089L;
      long ax = a ^ 108588800063098L;
      long axx = a ^ 114096767284249L;
      long axxx = a ^ 50195176393764L;
      long axxxx = a ^ 1152292179391L;
      c<"Z">(5716532645151001666L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"Þ">(this, 5716225809599864126L, a).getValue()
            && c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5716382276558173738L, a) >= c<"Þ">(this, 5719375275170427492L, a).getValue().intValue()) {
            this.y(false);
         } else {
            String var13 = c<"Þ">(this, 5716697976639680962L, a).getValue();
            byte var14 = -1;
            switch (var13.hashCode()) {
               case 77474681:
                  if (!var13.equals(b<"m">(20160, 8637812954837079080L ^ a))) {
                     break;
                  }

                  var14 = 0;
               case -352307958:
                  if (var13.equals(b<"m">(26286, 956441251747494985L ^ a))) {
                     var14 = 1;
                  }
            }

            switch (var14) {
               case 0:
                  int pulseTicks = c<"Þ">(this, 5717210500812404927L, a).getValue().intValue();
                  if (c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5716382276558173738L, a) < pulseTicks) {
                     break;
                  }

                  if (c<"Þ">(this, 5719062604022339255L, a).getValue()) {
                     int ticks = c<"Þ">(this, 5717275476398892089L, a).getValue().intValue();
                     BlinkUtils var10000 = c<"Ñ">(5717324218157044532L, a);
                     Object[] var10004 = new Object[]{null, axxx};
                     var10004[0] = ticks;
                     var10000.N(var10004);
                     c<"Þ">(this, 5719291737213546856L, a).setPos(c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5717955267523675951L, a));
                     c<"Þ">(this, 5719291737213546856L, a).setYRot(c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5717427730379949510L, a).getYaw());
                     c<"Þ">(this, 5719291737213546856L, a).setXRot(c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5717427730379949510L, a).J(new Object[]{axx}));
                     c<"Y">(
                        c<"Þ">(this, 5719291737213546856L, a),
                        c<"Þ">(c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5717955267523675951L, a), 5718211286865178991L, a),
                        5719529659667912315L,
                        a
                     );
                     c<"Y">(
                        c<"Þ">(this, 5719291737213546856L, a),
                        c<"Þ">(c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5717955267523675951L, a), 5718559246080022546L, a),
                        5718431240754548928L,
                        a
                     );
                     c<"Y">(
                        c<"Þ">(this, 5719291737213546856L, a),
                        c<"Þ">(c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5717955267523675951L, a), 5718049140395568626L, a),
                        5716334085755656103L,
                        a
                     );
                  }

                  BlinkUtils.g(new Object[]{axxxx});
               case 1:
                  if (c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5716382276558173738L, a) >= c<"Þ">(this, 5717670396128472863L, a) * 4) {
                     c<"Y">(this, c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5716382276558173738L, a), 5717670396128472863L, a);
                     BlinkUtils var17 = c<"Ñ">(5717324218157044532L, a);
                     Object[] var18 = new Object[]{null, axxx};
                     var18[0] = 1;
                     var17.N(var18);
                  }
            }

            this.T(
               b<"m">(24496, 5353777603008644442L ^ a)
                  + c<"Þ">(c<"Ñ">(5717324218157044532L, a), 5716382276558173738L, a)
                  + b<"m">(11231, 5566090794242093345L ^ a)
            );
         }
      }
   }

   @EventTarget
   public void H(Render2DEvent event) {
      long a = 何何友友树何何树友友.a ^ 89477385835999L;
      long ax = a ^ 30347850247460L;
      long axx = a ^ 115236973552174L;
      long axxx = a ^ 74409157516680L;
      c<"Z">(-7779038735958960356L, a);
      if (!this.w(new Object[]{ax})) {
         int y = mc.getWindow().getGuiScaledHeight() / 2 + 70;
         c<"Þ">(this, -7778910758034865160L, a).H(c<"Ñ">(-7781660725770537342L, a), axxx);
         if (c<"Þ">(c<"Ñ">(-7780393529776093078L, a), -7779174234167087756L, a) != 0
            && !c<"Þ">(this, -7778910758034865160L, a).B(c<"Ñ">(-7780349155357417857L, a), axx)) {
            float progress = Math.min(
               c<"Þ">(c<"Ñ">(-7780393529776093078L, a), -7779174234167087756L, a) / c<"Þ">(this, -7781880571392644806L, a).getValue().floatValue(), 1.0F
            );
            event.poseStack().pushPose();
            String var13 = c<"Þ">(HUD.instance, -7782009467472480700L, a).getValue();
            byte var14 = -1;
            switch (var13.hashCode()) {
               case -1818419758:
                  if (!var13.equals(b<"m">(4916, 7636405905658434195L ^ a))) {
                     break;
                  }

                  var14 = 0;
               case -1984932033:
                  if (var13.equals(b<"m">(15498, 2547824685180058943L ^ a))) {
                     var14 = 1;
                  }
            }

            switch (var14) {
               case 0:
                  何树树友何友友友何何.P(
                     event.poseStack(),
                     b<"m">(13799, 4544433111250695258L ^ a),
                     progress,
                     c<"Þ">(c<"Ñ">(-7780393529776093078L, a), -7779174234167087756L, a),
                     y
                  );
               case 1:
                  何树树友何友友友何何.F(event.poseStack(), progress, y);
               default:
                  event.poseStack().popPose();
            }
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "何建国230622195906030014";
   }
}
