package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.move.MoveMathEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;

public class 友友友树树友友树树友 extends Module implements 何树友 {
   public final ModeValue 友何何何树树何树何何;
   private final NumberValue 树何何树友树何友树树;
   private final BooleanValue 树何树何树何树树树何;
   private final BooleanValue 何何何树何何友树何何;
   private final BooleanValue 何友何友树树友何树树;
   private final 树友树友友何何树何何 友树树友何树友何友友;
   private int 友何友友树树树友树友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[28];
   private static final String[] k = new String[28];
   private static String HE_DA_WEI;

   public 友友友树树友友树树友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;I)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/player/友友友树树友友树树友.a J
      // 003: ldc2_w 57342175820950
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 52116031431159
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 16554
      // 014: ldc2_w 131826118748212617
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 19339
      // 021: ldc2_w 3189482215717340843
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -8469661910087163652
      // 02e: lload 1
      // 02f: invokedynamic F (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: bipush 88
      // 036: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;I)V
      // 039: aload 0
      // 03a: new cn/cool/cherish/value/impl/ModeValue
      // 03d: dup
      // 03e: sipush 12296
      // 041: ldc2_w 6567412747821219106
      // 044: lload 1
      // 045: lxor
      // 046: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04b: sipush 4573
      // 04e: ldc2_w 5350450651069504767
      // 051: lload 1
      // 052: lxor
      // 053: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 058: bipush 2
      // 059: anewarray 83
      // 05c: dup
      // 05d: bipush 0
      // 05e: sipush 9531
      // 061: ldc2_w 274654527353055250
      // 064: lload 1
      // 065: lxor
      // 066: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 06b: aastore
      // 06c: dup
      // 06d: bipush 1
      // 06e: sipush 16510
      // 071: ldc2_w 3152844207246216536
      // 074: lload 1
      // 075: lxor
      // 076: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07b: aastore
      // 07c: sipush 9531
      // 07f: ldc2_w 274654527353055250
      // 082: lload 1
      // 083: lxor
      // 084: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 089: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 08c: putfield cn/cool/cherish/module/impl/player/友友友树树友友树树友.友何何何树树何树何何 Lcn/cool/cherish/value/impl/ModeValue;
      // 08f: aload 0
      // 090: new cn/cool/cherish/value/impl/NumberValue
      // 093: dup
      // 094: sipush 7408
      // 097: ldc2_w 3710252080522285527
      // 09a: lload 1
      // 09b: lxor
      // 09c: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a1: bipush 20
      // 0a3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0a6: bipush 1
      // 0a7: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0aa: bipush 20
      // 0ac: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0af: bipush 1
      // 0b0: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0b3: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0b6: putfield cn/cool/cherish/module/impl/player/友友友树树友友树树友.树何何树友树何友树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 0b9: aload 0
      // 0ba: new cn/cool/cherish/value/impl/BooleanValue
      // 0bd: dup
      // 0be: sipush 15689
      // 0c1: ldc2_w 2279783260413030509
      // 0c4: lload 1
      // 0c5: lxor
      // 0c6: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0cb: bipush 1
      // 0cc: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0cf: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0d2: putfield cn/cool/cherish/module/impl/player/友友友树树友友树树友.树何树何树何树树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0d5: aload 0
      // 0d6: new cn/cool/cherish/value/impl/BooleanValue
      // 0d9: dup
      // 0da: sipush 18205
      // 0dd: ldc2_w 2095687792096315960
      // 0e0: lload 1
      // 0e1: lxor
      // 0e2: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e7: bipush 1
      // 0e8: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0eb: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0ee: putfield cn/cool/cherish/module/impl/player/友友友树树友友树树友.何何何树何何友树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0f1: aload 0
      // 0f2: new cn/cool/cherish/value/impl/BooleanValue
      // 0f5: dup
      // 0f6: sipush 6071
      // 0f9: ldc2_w 9003010355205233308
      // 0fc: lload 1
      // 0fd: lxor
      // 0fe: invokedynamic g (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/player/友友友树树友友树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 103: bipush 1
      // 104: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 107: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/Boolean;)V
      // 10a: putfield cn/cool/cherish/module/impl/player/友友友树树友友树树友.何友何友树树友何树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 10d: aload 0
      // 10e: new cn/cool/cherish/utils/树友树友友何何树何何
      // 111: dup
      // 112: lload 3
      // 113: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 116: putfield cn/cool/cherish/module/impl/player/友友友树树友友树树友.友树树友何树友何友友 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 119: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-7976469009604241197L, -5428997318892587614L, MethodHandles.lookup().lookupClass()).a(151557751360917L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 10472623964666L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[13];
      int var7 = 0;
      String var6 = "/\u0098}\u0017v+¹5Í\u00800ô¥\u008eU`\u0010\u001c%\u0013A?\u0081\u0091©îU¸F\u008eË\u001a \u0010SÂz\u0082§\u001cÊóK\u0098í ù(\u0018® 1,¾~\u008d\u0017dO\u0007çëó8ÁÃ\u0010/¤U-LÕfz¸?áS\u000b\n\u0096\u001e\u0010<ä¯KÐV¢¡\u0096pIw\u00adbÊ\u0087 ¸M\u000f\u008bPá²ùkÚÁýn¨ìÌ_\u0085ô\u0085:I\u001cÐB±7M[î¬E\u0018ñ@\u008b,ÛI|F¥%Íø\u0083Þ\u0087¶\u009d%Xjg\u0005\u0088\r\u0010u&\u0006lrø[rø«O.\rÍ\u0098\r\u0010\u009a\u0010ß\u0095¬¤¢\u0099\u001bÃ\u0084\u0082á\u008c\u0002R ù\u0012\u0081\u0005&d\u008a!QÈ\u0016@\u0083Í¬ªrßÁ\u0098\u0089º\u0095Ë%´\u008c\u001fRý{$\u0010&T§\u0001\b\u0096¸À\u0017ù`\u007f:\u000eÔ\\";
      short var8 = 242;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[13];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u0085ñ+ÀÎ´\u000f´ðÂ;\u007fp\u008f=É\u0010¤lgÌT÷Ú¼\u0096j\u0091áô\u0097HJ";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void F(Render2DEvent event) {
      long a = 友友友树树友友树树友.a ^ 129417687181623L;
      long ax = a ^ 116645927249657L;
      c<"I">(2293944686480518428L, a);
      if (!this.w(new Object[]{ax}) && !c<"Á">(this, 2294530488157114689L, a).C(b<"g">(16510, 3152913954851756281L ^ a))) {
         int y = mc.getWindow().getGuiScaledHeight() / 2 + 40;
         if (c<"Á">(this, 2293083803564203763L, a).getValue() && !mc.player.onGround()) {
            HUD.instance
               .D(
                  event.poseStack(),
                  b<"g">(9036, 8895323358055431116L ^ a),
                  c<"Á">(this, 2294405427262778085L, a) / c<"Á">(this, 2293571664963291487L, a).getValue().floatValue(),
                  c<"Á">(this, 2294405427262778085L, a),
                  y
               );
         }
      }
   }

   public void F() {
      long a = 友友友树树友友树树友.a ^ 56971583939348L;
      c<"f">(this, 0, 6193606108150079686L, a);
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 28;
               case 1 -> 31;
               case 2 -> 53;
               case 3 -> 43;
               case 4 -> 48;
               case 5 -> 42;
               case 6 -> 49;
               case 7 -> 6;
               case 8 -> 18;
               case 9 -> 37;
               case 10 -> 23;
               case 11 -> 54;
               case 12 -> 11;
               case 13 -> 59;
               case 14 -> 62;
               case 15 -> 35;
               case 16 -> 21;
               case 17 -> 30;
               case 18 -> 41;
               case 19 -> 51;
               case 20 -> 3;
               case 21 -> 8;
               case 22 -> 47;
               case 23 -> 40;
               case 24 -> 55;
               case 25 -> 9;
               case 26 -> 44;
               case 27 -> 4;
               case 28 -> 39;
               case 29 -> 27;
               case 30 -> 57;
               case 31 -> 1;
               case 32 -> 29;
               case 33 -> 32;
               case 34 -> 58;
               case 35 -> 52;
               case 36 -> 36;
               case 37 -> 26;
               case 38 -> 19;
               case 39 -> 56;
               case 40 -> 15;
               case 41 -> 34;
               case 42 -> 5;
               case 43 -> 14;
               case 44 -> 45;
               case 45 -> 24;
               case 46 -> 13;
               case 47 -> 33;
               case 48 -> 25;
               case 49 -> 12;
               case 50 -> 63;
               case 51 -> 17;
               case 52 -> 7;
               case 53 -> 22;
               case 54 -> 61;
               case 55 -> 50;
               case 56 -> 2;
               case 57 -> 46;
               case 58 -> 16;
               case 59 -> 38;
               case 60 -> 20;
               case 61 -> 60;
               case 62 -> 10;
               default -> 0;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友友友树树友友树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 18258;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友友友树树友友树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 193 && var8 != 'f' && var8 != 'F' && var8 != 'D') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 251) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'I') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 193) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'f') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'F') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友友友树树友友树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @EventTarget
   private void n(WorldEvent event) {
      long a = 友友友树树友友树树友.a ^ 21979384589314L;
      long ax = a ^ 13604864811980L;
      c<"I">(-7286581476634892247L, a);
      if (!this.w(new Object[]{ax})) {
         this.k();
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   @EventTarget
   public void a(LivingUpdateEvent event) {
      long a = 友友友树树友友树树友.a ^ 38114341812251L;
      long ax = a ^ 67108721833941L;
      c<"I">(5690840839448214576L, a);
      if (!this.w(new Object[]{ax})) {
         c<"f">(this, c<"Á">(this, 5691154142575311817L, a) + 1, 5691154142575311817L, a);
      }
   }

   private static void a() {
      j[0] = "/\u001a\u0007j\tp ZJa\u0003m%\u0007A'\u000bp(\u0001ElHv!\u0004E'\u0016s-\rL{H叔厇县核栘厭叔桝桥叢";
      j[1] = "\u001d\u001e\u001dv\u0015j\u0012^P}\u001fw\u0017\u0003[;\fd\u0012\u0005V;\u0013h\u000e\u001c\u001dW\u0015j\u0012\u0015R{,d\u0012\u0005V";
      j[2] = "q\u0000P<\u001c5~@\u001d7\u0016({\u001d\u0016q\u001e5v\u001b\u0012:]3\u007f\u001e\u0012q\u00036s\u0017\u001b-]伏佇厥伫厔桢厑叙伻伫";
      j[3] = "l\nq\u000b\u0017\u0010X)~KZ\u001bR4{\u0016Q]Z)v\u0010U\u0016\u0019\u000b}\u0001L\u001fR}";
      j[4] = ")`1|\u0013|& |w\u0019a#}w1\nr&{z1\u0015~:b1Q\t~(kmI\u001d\u007f?k";
      j[5] = int.class;
      k[5] = "java/lang/Integer";
      j[6] = "V(\u0000\u000bFVYhM\u0000LK\\5FF_XY3KF@TE*\u0000%F]P\u0010O\u0004\\\\";
      j[7] = "$\u0012c8c9/\u001drw\u001f  \u0007|4(\u00106\u0010p)9<!\u001d";
      j[8] = "y;%e\u000f\u001fy;29\u0003\u0010cp2'\u000b\u0013y*\u007f\u0006\u000b\u0018r=#*\u0004\u0002";
      j[9] = "D3X\u0016rYD3OJ~V^xOTvUD\"\u0002woDC9BK";
      j[10] = "\u0010bwpEz\u0010b`,Iu\n)`2Av\u0010s-\u0015Mj3fs.A}\u0019";
      j[11] = "vS$\u0014t1y\u0013i\u001f~,|NbY~(pS~Y~(pS~\u00045\u001bcXd\u0003?\r|Yo";
      j[12] = "eeu\u0012|\u0012j%8\u0019v\u000fox3_f\tog(_栂厶栗叀厐伤但桬体佞";
      j[13] = "Y\u0002\u0016Y\n\u0018VB[R\u0000\u0005S\u001fP\u0014\b\u0018^\u0019T_K伢佯厧佭佯厮伢佯桽栩";
      j[14] = "1o5\u0002u\u0011:`$M\u0014\u001f1k \u0017";
      j[15] = "3DC\u000e4KfE\u0002w桍伩桄佴栣伪桍桭桄佴:N>\u001a,BF\u0007:\u0015c";
      j[16] = "z% cY\u0019td.l?~\u001f\u0011BbFD{:}l\u0007Jt";
      j[17] = "Z\u001a[\u0011UzX\u0004@\r(s0V\u001eN\u0016#0g\u0019\u0010\u0015\u007f\u000e\nIN\u0013q";
      j[18] = "A\n,\r!@\u0014\u000bmt厂桦栶厤伈桭厂伢召厤UD+\u0006W]h\u001exBK";
      j[19] = "i07\u001d\r& p!\u0011m:Pv5\u0014\u00008>rqK\u0011E";
      j[20] = ")r\ntsK|sK\r栊伩会栆厰栔低厷桞栆s7l\u001b~x\u0010`.\u000fw";
      j[21] = "vm{p*J&3}~CI\u001f:|*r\u001e\u001f\u000by{yH9d{w1B";
      j[22] = "\u001ak5G]3\u001bab_ 伊叨又反叢口伊佶栒反!\u00117\u0010msE\u0010=Gu";
      j[23] = "o\u0006@~tx:\u0007\u0001\u0007佉会作桲佤佚受桞作伶9>~)p\u0000Ewz&?";
      j[24] = "l\u000bnWQ49\n/.史佖叁厥栎样栨又栛厥\u0017\u0012\n6p\u0002~P\b63";
      j[25] = "M9\ta\n\u001c\u00188H\u0018伷叠佾厗桩栁厩佾栺桍p!\u0000MR?\fh\u0004B\u001d";
      j[26] = "O!\u0019)\u000ba\u001a XP厨伃佼休桹桉伶桇佼休`l\u0001;G/]*P3\u001c";
      j[27] = "\u001e\u001daG\u0012OK\u001c >\u001bpML#_\u0002M\u000b\u0014z[rMLKyNO\u000b\u0014\u0012}>";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 友友友树树友友树树友.a ^ 129256204542195L;
      long ax = a ^ 97152478078338L;
      c<"Á">(this, -7633106245596568958L, a).U(ax);
      c<"Á">(c<"Á">(mc, -7633280651461901685L, a), -7633598597596994856L, a)
         .setDown(c<"Á">(c<"Á">(mc, -7633280651461901685L, a), -7633598597596994856L, a).isDown());
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void r(MoveInputEvent event) {
      long a = 友友友树树友友树树友.a ^ 49838497600537L;
      if (c<"I">(-6702514656882765774L, a) == null) {
         if (!c<"Á">(this, -6702807579774585180L, a).getValue()) {
            return;
         }

         event.setForwardImpulse(0.0F);
      }

      event.setLeftImpulse(0.0F);
   }

   @EventTarget
   public void P(PacketEvent event) {
      long a = 友友友树树友友树树友.a ^ 88890275685192L;
      long ax = a ^ 87388508728454L;
      c<"I">(-3050449988034549917L, a);
      if (!this.w(new Object[]{ax})) {
         if (event.getSide() == c<"F">(-3050510138193124403L, a)
            && c<"Á">(this, -3051145393331218969L, a).getValue()
            && event.getPacket() instanceof ClientboundPlayerPositionPacket) {
            this.k();
         }
      }
   }

   @EventTarget
   private void T(MoveMathEvent event) {
      long a = 友友友树树友友树树友.a ^ 25526637815676L;
      long ax = a ^ 9439170439346L;
      long axx = a ^ 88445777182454L;
      long axxx = a ^ 109693649264165L;
      c<"I">(5881375704502281047L, a);
      if (!this.w(new Object[]{ax})) {
         String var11 = c<"Á">(this, 5880766328570175242L, a).getValue();
         byte var12 = -1;
         switch (var11.hashCode()) {
            case 2112431799:
               if (!var11.equals(b<"g">(28395, 6205693141658957865L ^ a))) {
                  break;
               }

               var12 = 0;
            case 2011110042:
               if (var11.equals(b<"g">(8156, 3075774122016016664L ^ a))) {
                  var12 = 1;
               }
         }

         switch (var12) {
            case 0:
               if (c<"Á">(this, 5879951871594795192L, a).getValue() && mc.player.onGround()) {
                  return;
               }

               if (!mc.player.isSpectator()) {
                  if (c<"Á">(this, 5880644583264724142L, a) == c<"Á">(this, 5881425977747277588L, a).getValue().intValue()) {
                     RotationUtils.D(new Object[]{axx, new Rotation(axxx, mc.player.getYRot() + (float)(Math.random() - 0.5), mc.player.getXRot())});
                     event.setCancelled(false);
                     c<"f">(this, 0, 5880644583264724142L, a);
                  }

                  KeyMapping.set(c<"Á">(c<"Á">(mc, 5881209670685000964L, a), 5881525451537147223L, a).getKey(), false);
                  event.setCancelled(true);
               }

               if (c<"Á">(this, 5879951871594795192L, a).getValue() && !mc.player.onGround() && !mc.player.isSpectator()) {
                  break;
               }

               c<"f">(this, 0, 5880644583264724142L, a);
            case 1:
               event.setCancelled(true);
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "行走的50万——何炜霖";
   }
}
