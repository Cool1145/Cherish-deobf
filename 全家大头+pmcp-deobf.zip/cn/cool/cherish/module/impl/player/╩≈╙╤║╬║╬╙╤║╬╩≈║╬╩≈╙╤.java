package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.ui.友树何友何友何树树树;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.友何友何树何何友友何;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.树树树友友友树友何树;
import cn.cool.cherish.utils.animations.何何何何何友树树树友;
import cn.cool.cherish.utils.animations.何友友何何友何友友何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.item.SpoofItemUtils;
import cn.cool.cherish.utils.item.友何树树何树何何何友;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.友友何树树友友树树树;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.player.UpdateEvent;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class 树友何何友何树何树友 extends Module implements 何树友 {
   public static 树友何何友何树何树友 树友友树友友友友树何;
   public final ModeValue 树树树树友何树何何友 = new ModeValue("Mode", "模式", new String[]{"Normal", "Telly"}, "Normal");
   public final ModeValue 友何树何何树树树友何 = new ModeValue("Rotation Mode", "转头模式", new String[]{"Normal", "Back", "Heypixel", "GodBridge"}, "Normal");
   private final BooleanValue 树何友何友友何树树友 = new BooleanValue("WaitForNextUpdate", "待下次转头更新", false);
   private final NumberValue 树何友树树何友树树友 = new NumberValue("Place Delay", "放置延迟", 50, 0, 500, 10);
   public final BooleanValue 何友树友友树何树何友 = new BooleanValue("Keep Rotation", "保持转头", true);
   public final BooleanValue 树友何树何树何何友何 = new BooleanValue("Up Telly", "自动上升", true).A(() -> this.树树树树友何树何何友.K("Telly"));
   public final NumberValue 何友何何树何树何树何 = new NumberValue("Telly Tick", "步长", 1, 1, 5, 1).A(() -> {
      E();
      return this.树树树树友何树何何友.K("Telly") && !this.树友何树何树何何友何.getValue();
   });
   public final ModeValue 何树友树何何友树树何 = new ModeValue("Selection Mode", "方块选择模式", new String[]{"Normal", "Max Stack"}, "Normal");
   public final ModeValue 友友何友树树友何何何 = new ModeValue("Sneak Mode", "潜行模式", new String[]{"None", "Legit", "Heypixel"}, "None");
   public final ModeValue 树友友友树树树何友友 = new ModeValue("Swing Mode", "挥手模式", new String[]{"Swing", "Silent"}, "Swing");
   private final BooleanValue 友何何友友友树何何友 = new BooleanValue("Item Spoof", "物品欺骗", true);
   public final BooleanValue 树何友友树何树友树友 = new BooleanValue("Auto Jump", "自动跳跃", true);
   public final BooleanValue 何树树树何树友友何友 = new BooleanValue("Sprint", "疾跑", true);
   public final BooleanValue 友何友树树何友友友何 = new BooleanValue("Move Fix", "移动修复", false);
   private final ModeValue 何树树树树树树何何友 = new ModeValue("Count", "方块数量显示渲染", new String[]{"None", "Modern", "Simple", "OutLine"}, "None");
   private final 何何何何何友树树树友 树树友友何何友何树何 = new 何友友何何友何友友何(250, 16923, 1.0, 47854, '溑');
   private final 何友友何树何树何树友 树友树何友树何友树何 = new 何友友何树何树何树友(51913986529303L);
   public boolean 友友树树友何树树树树;
   public static double 树何友友友何树树何树;
   private float[] 何友树友树友友何何树;
   private 友何友何树何何友友何 友友树树何友友树何何 = null;
   private int 友树友何树何树友何友;
   private int 树树树友友友树何何友 = -1;
   private static Module[] 树树何友树何树树友友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[84];
   private static final String[] k = new String[84];
   private static String LIU_YA_FENG;

   public 树友何何友何树何树友() {
      super("Scaffold", "自动搭路", 树何友友何树友友何何.友树树友何友何树友树);
      树友友树友友友友树何 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3805567448197572001L, 5776151901732042049L, MethodHandles.lookup().lookupClass()).a(36686779326525L);
      // $VF: monitorexit
      a = var10000;
      a();
      O(null);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(37667532953132L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[62];
      int var5 = 0;
      String var4 = "\u0080K;Yê¹¦\u008e¦Uã?D©G\f?i_\u0018/q\u001faë\u008cÁ@Â|½6\u0018õ%xÁ4\u0095«\u0011ÖVvX×$Å\u008d&B§²£ß\u00ad\u008f\u0010\u0000\u0005Ú\u0003%¶é~\u001e\u0083\u0017ò\u0013\r\u0017« 7C\u009ct¼ZÅüÌ\u001bõRP|\u000f\u0006&'\u0019|\f\u008avÇáOS9Ç0x× Òüè\u0015¦[j:\u001c\u0002>\u008fWÿ\u0082\u007fVT\u0003ÖäA?\u008dpXÔ\u0098êu¬\u001e\u0010o¯I6ï²¿\u0094(u-'{ÍRH \u007fÐM\u0080\u0080\u0084È?\u0011*ô%\"OÎ\u008d¦EZFv`4\u0088\u000bË`6o@\u0094Þ(ømè?Ë\\\u00054hþBpòÆü)²\u0014òÁ¢Ás:°¬Ûc¶ªvî\u009c½\u000fn0/F\u0097 Ç9»(|¤äS{\"ø\u0010=ë\u0081\u009ekcÙ¨[=g(ômfE±(\u001c\u001d\u0010Û>Óþ$ÿqxßÙ\u0011õYl_\u0081\u0010Lï|Â¤_]üå\u0015\u001a¤Üûn¼\u0018«\u0011HÐ\u0093\u009c)8\u0093±Ý\u0097yÙ¬Ö\u0004Á²ÿZ\u0016}1\u0010\u0094K\u0091_E1&í\u0092\u0002ïj\u001eq§\u0004(ª{¡fh\u000ef\u0089ðº#\u0094Ë\u009d\u0087¬\u0096Þ#c\u0085\u00adÄ\u001d\r,ð\u0098DÝÏ:tà)¯ï¯\u0084À =&~\u0096Øý¢\u009aÅ3é¹\u0094.\u0084Ë\u0000\u0004'êX\b>Bð;\u008f)Ò\fÌÛ\u0018»\u0005}b\u001d\\¶<}ðN\u007f¡\u0081\u009e\u0011Mg\u0017\u0005µ2?\u009f\u0010\u0091ß\u001d\u008eð\u0012\u0090ÕB\u0097\u0003\u0014hðãi\u0018Z\u000fÆúé&IðØµ®\u0007åöp\u0089Âv¹\nßãP\u008c ÎQ1m×\u0003çq\u0096Å49XÁ\u0096\u0080#Õ@Ûäò\u0098ôçl\u0094ÁzÁD\u0095 öâÍ÷\u009c\u0001e¹?=êhë\r´\u001d\u009f¬\u009d\u0097Í\u001f\u0094\u0005ýØ¤\u0080T ½y(Hé\u0012kPQsóhz!|\u0002Nþ¡\u009b\u0013_4©,\u001dLO\u008fR6\u001bI¶i´Æ\u0016[¾Æ\"+\u0018$Fÿ\u009d#ÍÚ\u0095\rÕíé\u00ad£v\u0006Rõó\u0088Ý\u0014Á)\u0010\u000e4Z´Pè½ÐB6éKã¦ÎD iXRË¨ éè\u0016;ôÿ\u0088±çü:Ý0¥ê¿Aª\u0090\u0090ùñ\u0092ôº¬\u0018·õù®Lì\u0090\u008eììÐ6ÉË¯\u0098>A£¸>KAs\u0010\u0080¡®¿§\u008d\u0087ËSOÒ\u0087·\u009c\u001fD ;\u0088b*Ð9NBd®z\u0084óßÙÇ¶\u00ad4V6ËÅÝ¨\u00865Â\u001bö²l\u0010ù·\b½\u008a` åz,Ë@CLÌø\u0010u¥¨nm¹¿,È+¬víüÜ;\u0018Ç6¬\u0001§´r©Ý\u001eîÀÅ¹ÎµÙ\u0083s\u0084)\u0011HB\u0010\u0015k\u0005\u001ca\u008a<°æ&\u0089\u0011tgÎñ\u0010QÆ%ÃØø\u0082§\u0000aàQß\u0085ný\u0010&\u0011Y¥#hUßg\u001aõ\u00ad\u001dd©S »7\tx2\u008f\u0087\u00ad<\u0004\nrt\t\"{&7ùô)s1\u0087\u001btª{UY={\u0018*èW\u0082\u0005\u008eR4Ë£À\u0082ö¥Ì¦ûhm\u0016T¥&á\u0018wXðÅòø,\u0096óLb\u00910\u0016ø¬tFö\t¸9¿Ú\u0010Ø)\u0097Nné#è°í|w³°5ë\u0018(9ìz¦ÜvÎnÙÏ\u0099\u0017\u0094Ü¶&\u0091ÓÔÛÚö#\u0010ÔûÜ\u009dªZ\u0098¶\u001c~»\u0082\"NK\u008f\u0010Õ\u008cá\u009bG9!®\u0005RfW\n¥v+\u0018[ÔC\u008eÿ\u0083\u0007µÂ'ÿùv*1»G\u0014c'p%È\u0095\u0010å$ÕÕÐÉ4õ³Þ00ft\u0085n\u0010Å\bí\u0090\rÀÑ@S\u0083)'\u0016Ó\u0084]\u0010ì¤\u0019Ï\u0093\u0084øÛ°(I\u0016[ ¼ø %-·Âöâ\u009f¶T8\u0016Y\u000eûÇR5\nÓõbÉÌE\u001f¤Ó;µ×W6\u0010&®ZÛ\u0011¢¼\u0089´\u001a\u0000ýHQ\u008e\u007f Ü¤)ö{\u0085o^ºJó\u0088\u008e\u0095û\u0014§\u001aú\u0006Þ£Å\u0093zm®0©\u0014^§\u0010ÿr;\u0003\u0081Ëx§ú¨\u008b\u009e'_&r\u0010{.ê(ã©\u0019\u008f3x\u00861¼ÜWü \u009dg\u001d\u0094\u0018Çìµ4å%©lÞ\u0096\n¤[lËÁ¼¸ÊõrÔw±\u0088\u0099X\u0018ÏÑËÍx's7dT0Y\u0004\u001cF/ÒsùµéA@ù\u0010\u0095àÈ\u001cL½pÊ\"\u0014\u0002Ò\u0080fó\u00828'-ÉaÿyLC\u000e\u008a7\u0013/!¾«\n¦\u001e\u009e\u0005\u0090h\u009c-\u009b³átÐmí¤¼/tì\u0093G\u0086\u008a\u00909\u001f~y\u0084\u000e\tBy¤ã\u0085»D\u0010\u0085N%$~e1ËBÊ\r¹\u009aÖçW\u0010ÆôÍ\"¡\u0012dt\nò\u008b\r\u0096r\u008cô\u0010ðjÿOy9úæ,¹E\u001ez\u009c\u0093E\u0018Tîq×f\u009c\u009c]ûµ¯\u001dØ)\u0000ÙP\u0003JÃ\u0010Á\u0000#\u0010èO¨\u008c\u0094\u0001õ\u000fÍ\u0090\u00adË«'\u0004# \u001fiesçuÏÌW\u0015\u0013\u008fÃ§\u0083²¶ìÂ\u009cJä¤6X\u0010\n\u0018&rj7\u0018mÍÌ>\u000e¢\u0012\u0080s\u0018Ú\u000f,\u008e¸^õ ªòÍË·²";
      short var6 = 1483;
      char var3 = ' ';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = c(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     c = var7;
                     h = new String[62];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "\u0080\u0098\u0097üÛ¬È\u0019óK¨\u009dä)¤QÛÂV\u008d¢\u009b<¶\u0019\u009bkhee\u0094Ü\u0010q\u0099\u0011°Îý¬&¸zêÃEê³ ";
                  var6 = 49;
                  var3 = ' ';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   @EventTarget(0)
   public void C(MotionEvent event) {
      E();
      if (!this.Q(new Object[]{52406761729175L}) && !event.isPre()) {
         this.l();
         if (mc.player.onGround()) {
            树何友友友何树树何树 = Math.floor(mc.player.getY() - 1.0);
         }

         this.树树树友友友树何何友 = this.s();
         if (this.树树树友友友树何何友 != -1) {
            mc.player.getInventory().selected = this.树树树友友友树何何友;
            if (this.友何何友友友树何何友.getValue() && !SpoofItemUtils.e(96871185550697L)) {
               SpoofItemUtils.m(this.友树友何树何树友何友, 18080999206181L);
            }
         }

         if (this.树树树树友何树何何友.K("Telly")) {
            int requiredTicks = this.树友何树何树何何友何.getValue() ? 1 : this.何友何何树何树何树何.getValue().intValue();
            this.友友树树友何树树树树 = WrapperUtils.T(new Object[0]) >= requiredTicks;
            if (this.友友树树友何树树树树 && !mc.player.onGround() && 友友何树树友友树树树.I(112951582722913L)) {
               mc.player.setSprinting(false);
            }
         }

         this.友友树树友何树树树树 = true;
      }
   }

   private double F(double range) {
      return Math.max(0.08333333333333333, 0.01);
   }

   @EventTarget(4)
   public void Z(UpdateEvent event) {
      c<"Ñ">(103480496721168366L, 59422260527460L);
      if (c<"q">(this, 101439221220771804L, 59422260527460L)) {
         if (c<"q">(this, 102417986599028563L, 59422260527460L) != null && c<"q">(this, 101593565540583657L, 59422260527460L) != -1) {
            String var21 = c<"q">(this, 101332324242713114L, 59422260527460L).getValue();
            byte var22 = -1;
            switch (var21.hashCode()) {
               case -1955878649:
                  if (!var21.equals("")) {
                     break;
                  }

                  var22 = 0;
               case -352307958:
                  if (!var21.equals("Heypixel")) {
                     break;
                  }

                  var22 = 1;
               case 2062599:
                  if (!var21.equals("Back")) {
                     break;
                  }

                  var22 = 2;
               case 1252258565:
                  if (var21.equals("GodBridge")) {
                     var22 = 3;
                  }
            }

            switch (var22) {
               case 0:
               case 1:
                  c<"t">(
                     this,
                     RotationUtils.R(c<"q">(this, 102417986599028563L, 59422260527460L).B(53869721439647L), 4496952532861L),
                     105093914486111806L,
                     59422260527460L
                  );
               case 2:
                  c<"t">(
                     this,
                     RotationUtils.N(
                        RotationUtils.C(
                           c<"q">(this, 102417986599028563L, 59422260527460L).B(53869721439647L),
                           65017800408795L,
                           c<"q">(this, 102417986599028563L, 59422260527460L).E(43823451175524L)
                        ),
                        106334923914300L
                     ),
                     105093914486111806L,
                     59422260527460L
                  );
               case 3:
                  c<"t">(
                     this,
                     RotationUtils.J(c<"q">(this, 102417986599028563L, 59422260527460L).B(53869721439647L), 20422224846832L),
                     105093914486111806L,
                     59422260527460L
                  );
               default:
                  if (c<"q">(this, 105093914486111806L, 59422260527460L) == null) {
                     return;
                  }

                  RotationUtils.i(
                     new Rotation(21273681362686L, c<"q">(this, 105093914486111806L, 59422260527460L)[0], c<"q">(this, 105093914486111806L, 59422260527460L)[1]),
                     21965559892785L,
                     c<"q">(this, 103327130283173007L, 59422260527460L).getValue(),
                     c<"q">(this, 104810831272488736L, 59422260527460L).getValue()
                  );
                  this.P();
            }
         }

         if (!c<"q">(this, 101874174831386098L, 59422260527460L).getValue()) {
            c<"t">(this, null, 102417986599028563L, 59422260527460L);
         }
      }
   }

   private Vec3 Z(BlockPos pos, Direction face) {
      double x = pos.getX() + 0.5;
      double y = pos.getY() + 0.5;
      E();
      double z = pos.getZ() + 0.5;
      double randomOffset = 友友友树何友树友树友.S(35411192288882L, 0.3, -0.3);
      if (face == Direction.UP || face == Direction.DOWN) {
         x += randomOffset;
         z += 友友友树何友树友树友.S(35411192288882L, 0.3, -0.3);
      }

      if (face == Direction.WEST || face == Direction.EAST) {
         y += randomOffset;
         z += 友友友树何友树友树友.S(35411192288882L, 0.3, -0.3);
      }

      y += randomOffset;
      x += 友友友树何友树友树友.S(35411192288882L, 0.3, -0.3);
      return new Vec3(x, y, z);
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   @EventTarget
   public void e(MotionEvent event) {
      c<"Ñ">(3584290194194970428L, 105609192812982L);
      if (!this.Q(new Object[]{52406761729175L})) {
         if (c<"q">(this, 3583379627446646843L, 105609192812982L) >= 0) {
            if (event.isPre()) {
               label31:
               if (c<"q">(this, 3584522511059875645L, 105609192812982L).K("")) {
                  if (友树友友树何树友树友.b(mc.player, 137268177283891L) instanceof AirBlock) {
                     if (!mc.player.onGround()) {
                        break label31;
                     }

                     KeyMapping.set(c<"q">(c<"q">(mc, 3582734629878351899L, 105609192812982L), 3577420671581514913L, 105609192812982L).getKey(), true);
                  }

                  if (mc.player.onGround()) {
                     KeyMapping.set(c<"q">(c<"q">(mc, 3582734629878351899L, 105609192812982L), 3577420671581514913L, 105609192812982L).getKey(), false);
                  }
               }

               if (c<"q">(this, 3584522511059875645L, 105609192812982L).K("Heypixel")) {
                  KeyMapping.set(
                     c<"q">(c<"q">(mc, 3582734629878351899L, 105609192812982L), 3577420671581514913L, 105609192812982L).getKey(),
                     WrapperUtils.T(new Object[0]) == 5
                  );
               }
            }
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 20;
               case 1 -> 17;
               case 2 -> 33;
               case 3 -> 41;
               case 4 -> 1;
               case 5 -> 44;
               case 6 -> 54;
               case 7 -> 46;
               case 8 -> 42;
               case 9 -> 6;
               case 10 -> 53;
               case 11 -> 26;
               case 12 -> 2;
               case 13 -> 50;
               case 14 -> 47;
               case 15 -> 34;
               case 16 -> 27;
               case 17 -> 21;
               case 18 -> 32;
               case 19 -> 28;
               case 20 -> 12;
               case 21 -> 3;
               case 22 -> 13;
               case 23 -> 57;
               case 24 -> 43;
               case 25 -> 55;
               case 26 -> 39;
               case 27 -> 0;
               case 28 -> 49;
               case 29 -> 31;
               case 30 -> 29;
               case 31 -> 30;
               case 32 -> 52;
               case 33 -> 16;
               case 34 -> 7;
               case 35 -> 45;
               case 36 -> 18;
               case 37 -> 40;
               case 38 -> 15;
               case 39 -> 19;
               case 40 -> 38;
               case 41 -> 59;
               case 42 -> 4;
               case 43 -> 24;
               case 44 -> 60;
               case 45 -> 11;
               case 46 -> 56;
               case 47 -> 10;
               case 48 -> 8;
               case 49 -> 51;
               case 50 -> 62;
               case 51 -> 35;
               case 52 -> 23;
               case 53 -> 36;
               case 54 -> 37;
               case 55 -> 25;
               case 56 -> 5;
               case 57 -> 22;
               case 58 -> 63;
               case 59 -> 14;
               case 60 -> 48;
               case 61 -> 9;
               case 62 -> 61;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29464;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/树友何何友何树何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[|\u0098\u0019gÃ\u0017ÍµÛ¡ùÛ|\u0001R_, \u0080oÂ7:|öª\u0093/{«*Y\u0003/, \u0016W\t\u001bm\u008fÐ2, ÷Ø\u0012ø\u0011²\tùÏþÛkôg\u0012(, õ\t\u008dPßÈ?\u0091\u008dú Ã\u0003ð#\u0000, \u0080º¥#\u0007\u0010ñV, ðòpL\u0002$Ããð~ÚQ\u00ad´\u0013o, 5ì\u0006Ê\u0095¨'\u0096®ØF")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友何何友何树何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public int s() {
      E();
      if (this.何树友树何何友树树何.K("Max Stack")) {
         int bestSlot = -1;
         int i = 0;
         ItemStack itemStack = mc.player.getInventory().getItem(0);
         if (!itemStack.isEmpty()
            && itemStack.getItem() instanceof BlockItem blockItem
            && 树何树树何何树友何何.R(36387407288699L, blockItem.getBlock())
            && itemStack.getCount() > 0) {
            itemStack.getCount();
            bestSlot = 0;
         }

         i++;
         return bestSlot;
      } else {
         int i = 0;
         ItemStack itemStack = mc.player.getInventory().getItem(0);
         if (!itemStack.isEmpty() && itemStack.getItem() instanceof BlockItem blockItem && 树何树树何何树友何何.R(36387407288699L, blockItem.getBlock())) {
            return 0;
         } else {
            i++;
            return -1;
         }
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'q' && var8 != 't' && var8 != 202 && var8 != 200) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 225) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 209) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'q') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 't') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/树友何何友何树何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void n(PoseStack poseStack) {
      c<"Ñ">(-8648173038254128774L, 18197378271216L);
      c<"q">(this, -8647177000007821342L, 18197378271216L)
         .n(this.isEnabled() ? c<"Ê">(-8655679584396366348L, 18197378271216L) : c<"Ê">(-8655887507432351497L, 18197378271216L), 59020024422499L);
      if ((this.isEnabled() || !c<"q">(this, -8647177000007821342L, 18197378271216L).U(108461126752643L)) && mc.player != null) {
         int currentBlockSlot = this.s();
         ItemStack heldItem = currentBlockSlot == -1 ? null : mc.player.getInventory().getItem(currentBlockSlot);
         int count = c<"q">(this, -8647816968675750275L, 18197378271216L) == -1 ? 0 : this.u();
         int countNum = this.u();
         String countStr = String.valueOf(countNum);
         float output = (float)c<"q">(this, -8647177000007821342L, 18197378271216L).D(124111691745592L);
         友树何友何友何树树树 font = Cherish.instance.t();
         int color = countNum > 32
            ? new Color(63, 157, 4, 150).getRGB()
            : (countNum < 16 ? new Color(168, 1, 1, 150).getRGB() : new Color(255, 144, 2, 150).getRGB());
         String var27 = c<"q">(this, -8655088409046613061L, 18197378271216L).getValue();
         byte var28 = -1;
         switch (var27.hashCode()) {
            case -1984932033:
               if (!var27.equals("")) {
                  break;
               }

               var28 = 0;
            case 557454402:
               if (!var27.equals("OutLine")) {
                  break;
               }

               var28 = 1;
            case -1818419758:
               if (var27.equals("Simple")) {
                  var28 = 2;
               }
         }

         switch (var28) {
            case 0: {
               String text = "§l" + countStr + "§r Block" + (count != 1 ? "s" : "");
               float textWidth = Cherish.instance.t().H(18).D(text);
               float totalWidth = (textWidth + 15.0F + 3.0F + 6.0F + 2.0F) * output;
               float x = mc.getWindow().getGuiScaledWidth() / 2.0F - totalWidth / 2.0F;
               float y = mc.getWindow().getGuiScaledHeight() - (mc.getWindow().getGuiScaledHeight() / 2.0F + 30.0F);
               poseStack.pushPose();
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               RenderUtils.B((int)(x - 1.5), (int)(y - 1.5), (int)(totalWidth + 3.0F), 23);
               RenderUtils.drawRectangle(poseStack, x, y, totalWidth, 20.0F, new Color(20, 20, 20, 100).getRGB());
               RenderUtils.drawRectangle(poseStack, x, y + 10.0F - 4.0F, 1.0F, 8.0F, color);
               font.H(18).q(poseStack, text, x + 2.0F + 15.0F + 3.0F + 2.0F, y + Cherish.instance.t().H(18).f(20.0F), -1);
               Lighting.setupFor3DItems();
               PoseStack var10000 = new PoseStack();
               int var10002 = (int)x + 3 + 1;
               int a = (int)(y + 10.0F - 7.5F);
               int ax = var10002;
               PoseStack axx = var10000;
               RenderUtils.F(57627225086705L, axx, heldItem, ax, a);
               Lighting.setupForFlatItems();
               RenderUtils.h(new Object[0]);
               poseStack.popPose();
            }
            case 1: {
               float x = mc.getWindow().getGuiScaledWidth() / 2.0F - font.w().Y(countStr) / 2.0F + 6.0F;
               float y = mc.getWindow().getGuiScaledHeight() / 2.0F + 10.0F;
               poseStack.pushPose();
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               poseStack.translate(x + 1.0F, y, 1.0F);
               poseStack.scale(
                  (float)c<"q">(this, -8647177000007821342L, 18197378271216L).D(124111691745592L),
                  (float)c<"q">(this, -8647177000007821342L, 18197378271216L).D(124111691745592L),
                  1.0F
               );
               poseStack.translate(-x - 1.0F, -y, 1.0F);
               Cherish.instance.t().w().f(poseStack, countStr, x, y, 何树友友树树友何树何.O(color, output), false);
               Lighting.setupForEntityInInventory();
               RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
               poseStack.scale(0.7F, 0.7F, 0.7F);
               RenderUtils.F(
                  57627225086705L,
                  poseStack,
                  heldItem,
                  (int)((mc.getWindow().getGuiScaledWidth() / 2.0F - font.w().Y(countStr) / 2.0F - 7.0F) / 0.7),
                  (int)((mc.getWindow().getGuiScaledHeight() / 2.0F + 8.5F) / 0.7)
               );
               poseStack.popPose();
            }
            case 2: {
               String text = "§f" + "No" + "§r Blocks";
               float x = mc.getWindow().getGuiScaledWidth() / 2.0F - Cherish.instance.t().H(18).D(text) / 2.0F;
               float y = mc.getWindow().getGuiScaledHeight() / 2.0F + 10.0F;
               Cherish.instance
                  .t()
                  .H(18)
                  .s(
                     poseStack,
                     text,
                     x,
                     y,
                     何树友友树树友何树何.S(HUD.instance.getColor(1).getRGB(), (float)(c<"q">(this, -8647177000007821342L, 18197378271216L).D(124111691745592L) * 1.0))
                  );
            }
         }
      }
   }

   private boolean n(BlockPos blockPosition) {
      Vec3 eyesPos = mc.player.getEyePosition();
      double xzSSV = this.F(0.5);
      E();
      double ySSV = this.F(0.5);
      Direction[] prioritizedSides = new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP, Direction.DOWN};
      int var32 = prioritizedSides.length;
      int var33 = 0;
      if (0 < var32) {
         Direction side = prioritizedSides[0];
         BlockPos neighbor = blockPosition.relative(side);
         if (友何树树何树何何何友.L(67499386939589L, neighbor)) {
            Vec3 dirVec = new Vec3(side.getNormal().getX(), side.getNormal().getY(), side.getNormal().getZ());
            Vec3 posVec = new Vec3(blockPosition.getX() + 0.25, blockPosition.getY() + 0.25, blockPosition.getZ() + 0.25);
            Vec3 hitVec = posVec.add(dirVec.x * 0.5, dirVec.y * 0.5, dirVec.z * 0.5);
            if (!(eyesPos.distanceToSqr(hitVec) > 25.0) && !(eyesPos.distanceToSqr(posVec) > eyesPos.distanceToSqr(posVec.add(dirVec)))) {
               if (mc.level.clip(new ClipContext(eyesPos, hitVec, Block.COLLIDER, Fluid.NONE, mc.player)).getType() != Type.MISS) {
               }

               double diffX = hitVec.x - eyesPos.x;
               double diffY = hitVec.y - eyesPos.y;
               double diffZ = hitVec.z - eyesPos.z;
               double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
               Rotation rotation = new Rotation(
                  21273681362686L, (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F, (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)))
               );
               Vec3 rotationVector = RotationUtils.e(rotation, 50307048148560L);
               Vec3 vector = eyesPos.add(rotationVector.x * 4.5, rotationVector.y * 4.5, rotationVector.z * 4.5);
               BlockHitResult obj = mc.level.clip(new ClipContext(eyesPos, vector, Block.COLLIDER, Fluid.NONE, mc.player));
               if (obj.getType() == Type.BLOCK && obj.getBlockPos().equals(neighbor)) {
                  new 树树树友友友树友何树(new 友何友何树何何友友何(neighbor, side.getOpposite(), 380961193106L, (byte)-89, hitVec), rotation);
               }
            }

            double var10000 = 0.25 + xzSSV;
            var10000 = 0.25 + ySSV;
            var10000 = 0.25 + xzSSV;
         }

         var33++;
      }

      return false;
   }

   @Override
   public void h() {
      E();
      if (!this.Q(new Object[]{52406761729175L})) {
         mc.player.getInventory().selected = this.友树友何树何树友何友;
         if (this.友何何友友友树何何友.getValue() && SpoofItemUtils.e(96871185550697L)) {
            SpoofItemUtils.z(29996098265021L);
         }

         this.友友树树友何树树树树 = false;
         this.友友树树何友友树何何 = null;
         this.树树树友友友树何何友 = -1;
         mc.options.keySprint.setDown(InputConstants.isKeyDown(mc.getWindow().getWindow(), mc.options.keySprint.getKey().getValue()));
         mc.options.keyShift.setDown(InputConstants.isKeyDown(mc.getWindow().getWindow(), mc.options.keyShift.getKey().getValue()));
         mc.options.keyJump.setDown(InputConstants.isKeyDown(mc.getWindow().getWindow(), mc.options.keyJump.getKey().getValue()));
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private void l() {
      E();
      BlockPos basePos = BlockPos.containing(mc.player.getX(), this.y(), mc.player.getZ());
      if (!友何树树何树何何何友.L(67499386939589L, basePos) && !this.n(basePos)) {
         Iterator var7 = T(basePos).iterator();
         if (var7.hasNext()) {
            BlockPos pos = (BlockPos)var7.next();
            if (this.n(pos)) {
               return;
            }
         }

         if (!友何树树何树何何何友.L(67499386939589L, basePos)) {
            this.友友树树何友友树何何 = null;
         }
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = ">|:P*71<w[ *4a|\u001d(79gxVk10bx\u001d54<kqAk桉厖佇佁司伐桉伈栃叟";
      j[1] = "s/~-P\n|o3&Z\u0017y28`I\u0004|45`V\b`-~\u0003P\u0001u\u00171\"J\u0000";
      j[2] = "+\n#Z\u000e^ \u00052\u0015rG/\u001f<VEw9\b0KT[.\u0005";
      j[3] = "\u000b\u001b[aUC\u0004[\u0016j_^\u0001\u0006\u001d,OX\u0001\u0019\u0006,[B\u0001\u0018\u0014vSC\u0006\u0006[佗佯佹伽传厾栓栫栽厣";
      j[4] = "\rB\u0000<C\u000f9a\u000f|\u000e\u00043|\n!\u0005B;a\u0007'\u0001\txC\f6\u0018\u000035";
      j[5] = int.class;
      k[5] = "java/lang/Integer";
      j[6] = "I\u000b>7nOFKs<dRC\u0016xztTC\tcz`NC\bq hOD\u0016>原佔栱叡桴佅企及栱栻";
      j[7] = "I=vp@;}\u001ey0\r0w\u0003|m\u0006v\u007f\u001eqk\u0002=<<zz\u001b4wJ";
      j[8] = void.class;
      k[8] = "java/lang/Void";
      j[9] = "69/h^A6984RN,r8*ZM6(u6_I!9)h\u007fG;=7\u0016_I!9)";
      j[10] = "\u0015\u0015W\t2G\u0015\u0015@U>H\u000f^@K6K\u0015\u0004\rJ*B\u000f\u0019SK>W\u001e\u0002\rd3G\u001e\u001eWw>M\u0010\u0015Wk6]\u000f\u0015MB-";
      j[11] = "m\u0011\u000bM'pbQFF-mg\fM\u0000>~b\n@\u0000!r~\u0013\u000b`=rl\u001aWx)s{\u001a";
      j[12] = "q+^k0qq+I7<~k`I)4}q:\u0004\b4vz-X$;l";
      j[13] = "3|1z>&3|&&2))7&8:*3mk9&#)p58268kk\u0019&#)p\u00158268k\u00025>*\u0010v!1";
      j[14] = "c5UK4\rc5B\u00178\u0002y~V\n+\bi~h\u000b-\u0001\u007f1B\u00110\u000bc\u0018@\u000b=";
      j[15] = "\u000eV2ibx\u0001\u0016\u007fbhe\u0004Kt$xc\u0004To$叆佂厦佭栍佟佘叜厦佭";
      j[16] = "zmkil/zm|5` `&h(s*p&V)u#fi|3h)zZz4t*`";
      j[17] = "'UEm,f(\u0015\bf&{-H\u0003 6}-W\u0018 伖参厏佮桺佛桒作桕台";
      j[18] = ";%'L\u001b\r;%0\u0010\u0017\u0002!n0\r\u0004\u0001{\u0004:\u0010\u0013\u0007!)<\f";
      j[19] = "\u0002}a\u001d/S\r=,\u0016%N\b`'P6]\rf*P)Q\u0011\u007fa</S\rv.\u0010\u0016]\rf*";
      j[20] = ".R\u001a\u0010\u0015<.R\rL\u001934\u0019\u0019Q\n9$\u0019\u000bP\f<4N@N\u001449R\u001c\u00101;6R\u0000J\u0017'9";
      j[21] = boolean.class;
      k[21] = "java/lang/Boolean";
      j[22] = "\u0018p\b\u0002el\u0018p\u001f^ic\u0002;\u001f@a`\u0018aRcxq\u001fz\u0012_";
      j[23] = "$C~\u00022)$Ci^>&>\bi@6%$R$g:9\u0007Gz\\6.-";
      j[24] = double.class;
      k[24] = "java/lang/Double";
      j[25] = "haj>4}ha}b8rr*i\u007f+xb*nx g(Lwd\u000bquqrd}@\u007ft{";
      j[26] = ".].\u0003#>.]9_/14\u0016-B<;$\u0016*E7$nn?N}";
      j[27] = "v91F*ov9&\u001a&`lr2\u00075j|r)\r1ctr\u0006\u0004.v[3+\u001c\"~lx\u0007\u0004(es";
      j[28] = "m46\"O^m4!~CQw\u007f5cP[g\u007f.iTRo\u007f\u0001`KG@>,xGOwu\u0004`W^g";
      j[29] = ",^";
      j[30] = "B+\u0015\u000f\u001fhMkX\u0004\u0015uH6SB\u001dhE0W\t^栖佴厎台伹桡双只伐佮";
      j[31] = "\n\u0010(\u001a+s\u0001\u001f9UJ}\n\u0014=\u000f";
      j[32] = "\u001cX\r\u00186TL[\nKGy0e15GT\u0010_\u0000\u0004,\u0004\u0013XS";
      j[33] = "_V\u001ewZk\u000fY\u001aL佥桊厦栰伣休叻桊桼佴~u\t(\u0004G\u001e-\t(Y";
      j[34] = "0\u0014\u001frc7`\u001b\u001bI参双佗厨桦桐参佒佗伶\u007fp0tk\u0005\u001f(0t6";
      j[35] = "*;}\u0003cSz8zP\u0012u\b\u0007Any_!1l\u0005)\\&b";
      j[36] = "\b4k\tx:\u001ag?_\u001eN-\u001bD!RH0_b\u000bul\f`pX!:";
      j[37] = "/Tt\\}V\u007f[pg叜桷取佶栍伺栆厭佈叨\u0014\\|\u001cmV.\u0015z\ns";
      j[38] = "'%\u0003<}Bw*\u0007\u0007栆厹佀桃伾栞佂伧叞伇cks\u001fe0\bkg\u0001\u007f";
      j[39] = "e\u0004\tk\u0012@5\u000b\rP桩去厜桢厪厓厳去框伦ij\u000f\u0018d\u0019Q:\u0000\u001c";
      j[40] = "]Z\u000e\u0005\u0001VE\u000e]\u0001:厫栠栭叽伲叹伵栠号栧o^\u0006\t^\u0005QFRZZ";
      j[41] = "\u001d\u0003EoKa\u0017\u0002Z<\"?$T\u0012g\u0012`$eG1R>CXQ.G4";
      j[42] = "\u007fkA~u\\/dEE佊桽桜栍佼桜叔厧优受!){\u0001=~J)o\u001f'";
      j[43] = "&-\u001e7\u0005qv\"\u001a\f\u000eI&hA6\u001c0{nA4gs&mDw\u001e. mF\f";
      j[44] = "6\u0010\u00020Kqf\u001f\u0006\u000b只伔叏桶桻佖只厊叏伲bgE,t\u0005\tgQ2n";
      j[45] = "D\u0016\u0006 xU\u0014\u0019\u0002\u001b栃估厽桰桿但叙桴桧厪f$e\u0006\u0001\u000f^r'\tF";
      j[46] = "E@D[\u000fR\u0015O@` jBT\u0019\u0005\\\r\u0018N\u001d\u0011m";
      j[47] = "1!\u0011A\tzi+\u001cDgNI\u001akl'BF\u0017-\n\u001d7z5\\R\u0017:\u007f";
      j[48] = "\u0007h\u0019\bN|Wg\u001d3可伙栤佊伤株栵桝叾佊y\n\u001d?\\y\u0019R\u001d?\u0001";
      j[49] = ";3!z`\u0005k<%A叁叾栘桕厂伜栛栤栘桕A,}T90x-3Rd";
      j[50] = ")]V5%pyRR\u000e桞桑栊栻叵体桞伕低叡67v3rLVov3/";
      j[51] = "Ak\u001c\b\u0004X\u0011d\u00183桿桹桢受县台桿伽伦受|\b\u0005\u0012\u0003iFA\u0003\u0004\u001d";
      j[52] = "r|\rTh_\"s\to佗厤伕佞桴伲栓伺桑佞mPu\f7eU\u00067\u0003p";
      j[53] = "'v.m\u0001=wu)>p\t\u0001J\u0012\u0000\u001b1,|?kK2+/";
      j[54] = "\u001f+)roQO$-I栔伴另厗桐伔栔厪格厗I%a\f]>\"%u\u0012G";
      j[55] = "n>4K~A>10p佁厺桍厂厗桩佁桠伉厂T\u001cp\u001c,+?\u001cd\u00026";
      j[56] = "#M\u000eqy3y\u0014\u0010/BbD\u001cF&|2D-\u0011x/<z\u001d\u001by0o";
      j[57] = "'\u0001\n\u000boa.[\u0015\u0000\u0004]\u0010*.}_]M\u000b\u0005_?m*\u0002_@4";
      j[58] = "x\u0006W\nJ\u0011(\tS1栱佴厁厺叴佬栱栰伟桠7Q\u0015Ey\u0016GLNC%";
      j[59] = "2\u0011\u0006H45r\tC\u000eU#[VDFkt38|Ik==\u0017\u001aGm6`";
      j[60] = "\u001f\u001b\u0010c\u0018TO\u0014\u0014X档桵另厧伭伅厹伱格伹pb\u0011\u0007K\u001b\u0013e\u001b\u0005\u0014";
      j[61] = ";Nu$\u000fvkAq\u001f桴厍参史栌栆桴伓参史\u0015&\\5`_u~\\5=";
      j[62] = "\u0015pq*\u0001vO)ot:'r!9}\u0005sr\u00101yE7Eug\"\u0001r";
      j[63] = "!XT|'HqWPG历厳栂栾佩厄历桩但佺4. Mj\u0017L\u007f$\u000fa";
      j[64] = "_\u0010|\u001dg7\u0018Pe\r\u001d桏桺厯栂厣佀桏厠伱但`!*\u0004\u0011a\u0001fj\u001d\u0001";
      j[65] = "\u0004MRF_-TBV}栤佈叽佯叱厾你栌栧叱2\u0011QpFXY\u0011En\\";
      j[66] = "0\u000e{d(h`\r|7YO\u001c6]\t2d;\u0004jbbg<W";
      j[67] = "Ou<qd/\b5%a\u001e桗桪佔桂佑标伓伮及厘\f\"2\u0014t!mer\rd";
      j[68] = "%\u00116){\u0007-\u001axt\u000b\u0007\u0013L=$;Q\u0013|g%gR+\fz~a\u000e";
      j[69] = "Q\u0015\u0003_=\u0003\u0001\u001a\u0007d伂司桲厩桺厧厜佦伶桳c\u00074A\u0010RZ\u001efZP";
      j[70] = "0k\u001f\u001f\u0015\n:j\u0000L|T\t<H\u0017M\u0003\t\r\u001dA\fUn0\u000b^\u0019_";
      j[71] = "\u00041\u0002:\u0014\u0001\bb\u000e7l#!\u0015)\u000b\u000e\u0007\u0000b\u001co\u0002T\fo";
      j[72] = "\u0014jH>1=DeL\u0005\u0014\u0005\u0013~\u0015`bbId\u0011tS;\u0016(\u00124)8E~B\u0005";
      j[73] = "'xAw\u0006\u000f>g\u000fs{<\u0003Bx\r{\u0016:w\n3\u0002\u000f%9\u000e";
      j[74] = "I_p\u007fKu\u0019PtD只伐伮口叓厇栰伐伮口\u0010(E(\u000bJ{(Q6\u0011";
      j[75] = "x)\u001e\u0012iv(&\u001a)佖桗桛桏桧栰栒伓伟厕~\u0010:5#8\u001eH:5~";
      j[76] = "B\u000e)<2FJ\u0005gaBFtS\"1}\u0019tcx0.\u0013L\u0013ek(O";
      j[77] = "c.env\u0013b!+4\u0016\u0004Yyd>)UYBbld\u0012sx+jr\f";
      j[78] = "xn\n\u0010!^peDMQ^N3\u0001\u001da\tN\u0003[\u001c=\u000bvsFG;W";
      j[79] = "q\u0015*\u001fM1{\u00145L$oHB}\u0017\u00159Hs(ATn/N>^Ad";
      j[80] = "]:]-&-\r9Z~W\u001bn]V'7+G6\u0006$0x";
      j[81] = "Z@\u001a,\u0011A\nC\u001d\u007f`qvz&\u0001`AVG\u00170\u000b\u0011U@D";
      j[82] = "\u007fRIQI\b/]Mj栲右桜佰只桳佶右桜佰)\u0001@\u000e#II\fR\\{";
      j[83] = "+H\\\u000f562W\u0012\u000bH\n\nnu6(29\fSO1-w\b";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public int u() {
      E();
      int n = 0;
      int i = 0;
      ItemStack stack = mc.player.getInventory().getItem(0);
      if (!stack.isEmpty() && stack.getItem() instanceof BlockItem blockItem && 树何树树何何树友何何.R(36387407288699L, blockItem.getBlock())) {
         n = 0 + stack.getCount();
      }

      i++;
      return n;
   }

   public double y() {
      E();
      if (!this.树树树树友何树何何友.K("Telly") && !this.树何友友树何树友树友.getValue()) {
         return mc.player.getY() - 1.0;
      } else if (this.树友何树何树何何友何.getValue()) {
         return mc.player.getY() - 1.0;
      } else if (mc.options.keyJump.isDown()) {
         return mc.player.getY() - 1.0;
      } else {
         return 友友何树树友友树树树.I(112951582722913L) ? 树何友友友何树树何树 : mc.player.getY() - 1.0;
      }
   }

   public static Module[] E() {
      return 树树何友树何树树友友;
   }

   @Override
   public void M() {
      E();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.友树友何树何树友何友 = mc.player.getInventory().selected;
         mc.options.keySprint.setDown(this.何树树树何树友友何友.getValue() || this.树树树树友何树何何友.K("Telly"));
         this.友友树树友何树树树树 = false;
         this.友友树树何友友树何何 = null;
         this.树树树友友友树何何友 = -1;
      }
   }

   private void P() {
      E();
      if (this.树树树友友友树何何友 >= 0) {
         if (this.树友树何友树何友树何.A(this.树何友树树何友树树友.getValue().longValue(), 118344821288830L)) {
            BlockPos targetPos = BlockPos.containing(mc.player.getX(), this.y(), mc.player.getZ());
            if (树何树树何何树友何何.Y(targetPos, 74305057003608L) instanceof AirBlock) {
               BlockHitResult hitResult = new BlockHitResult(
                  this.Z(this.友友树树何友友树何何.B(53869721439647L), this.友友树树何友友树何何.E(43823451175524L)),
                  this.友友树树何友友树何何.E(43823451175524L),
                  this.友友树树何友友树何何.B(53869721439647L),
                  false
               );
               if (mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, hitResult) == InteractionResult.SUCCESS) {
                  this.树友树何友树何友树何.D(11747522392279L);
                  if (this.树友友友树树树何友友.K("Swing")) {
                     mc.player.swing(InteractionHand.MAIN_HAND);
                  }

                  mc.player.connection.send(new ServerboundSwingPacket(InteractionHand.MAIN_HAND));
               }
            }
         }
      }
   }

   @EventTarget
   public void H(StrafeEvent event) {
      E();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.树何友友树何树友树友.getValue()) {
            mc.options
               .keyJump
               .setDown(
                  mc.player.onGround() && 友友何树树友友树树树.I(112951582722913L)
                     || InputConstants.isKeyDown(mc.getWindow().getWindow(), mc.options.keyJump.getKey().getValue())
               );
         }
      }
   }

   private static List<BlockPos> T(BlockPos basePos) {
      E();
      List<BlockPos> pos = new ArrayList<>();
      int x = -6;
      int z = -6;
      pos.add(basePos.offset(-6, 0, -6));
      z++;
      x++;
      pos.sort((pos1, pos2) -> {
         double dist1 = basePos.distSqr(pos1);
         double dist2 = basePos.distSqr(pos2);
         return Double.compare(dist1, dist2);
      });
      return pos;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖诈骗";
   }

   public static void O(Module[] var0) {
      树树何友树何树树友友 = var0;
   }
}
