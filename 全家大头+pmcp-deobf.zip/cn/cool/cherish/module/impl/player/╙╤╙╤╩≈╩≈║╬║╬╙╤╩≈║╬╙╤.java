package cn.cool.cherish.module.impl.player;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.combat.KillAura;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.item.友何树树何树何何何友;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.AbstractFurnaceMenu;
import net.minecraft.world.inventory.BrewingStandMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.FurnaceMenu;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;

public class 友友树树何何友树何友 extends Module implements 何树友 {
   public static 友友树树何何友树何友 树友树友友何树何树何;
   private static final 何友友何树何树何树友 友何友何树树树何何友;
   private final NumberValue 友友何友树友友何何友 = new NumberValue("Delay", "延迟", 100, 0, 1000, 10);
   private final NumberValue 树树树友树友何何树树 = new NumberValue("Open Delay", "开箱延迟", 1, 0, 10, 1);
   private final BooleanValue 友何友何何树友友友友 = new BooleanValue("Chest", "箱子", true);
   private final BooleanValue 何何友树何友友友何何 = new BooleanValue("Ender Chest", "末影箱", false);
   private final BooleanValue 何何友友友何友树树友 = new BooleanValue("Furnace", "熔炉", true);
   private final BooleanValue 何友何何树友树何友友 = new BooleanValue("BrewingStand", "酿造台", true);
   private final BooleanValue 树何树树树树树何友树 = new BooleanValue("PickTrash", "包括垃圾", false);
   private final BooleanValue 何何友何友何友友友树 = new BooleanValue("Only Best", "仅最佳物品", false);
   private final BooleanValue 何树树友树何何何树树 = new BooleanValue("Random Click", "随机点击", false);
   private final 何友友何树何树何树友 何树树友友树友何树何 = new 何友友何树何树何树友(51913986529303L);
   private final 何友友何树何树何树友 何树友树友友树何树何 = new 何友友何树何树何树友(51913986529303L);
   private final Random 友何树友何友何树树友 = new Random();
   private AbstractContainerMenu 友友树友友树友友友树 = null;
   private boolean 友何友友友友友友树树 = false;
   private int 树树树友树何树友树友 = 0;
   private int 何友树树友树何何友友 = -1;
   private int 何友树友友树树树何树 = 0;
   private long 何树何树树树树树何何;
   private int 何友树友树友何树友何;
   private AbstractContainerMenu 何何友友何树树树何树;
   private int 树何树何何友友树何友 = 0;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[63];
   private static final String[] n = new String[63];
   private static int _何大伟：我要教育何炜霖 _;

   public 友友树树何何友树何友() {
      super("ChestStealer", "箱子小偷", 树何友友何树友友何何.友树树友何友何树友树);
      树友树友友何树何树何 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5765014548435635573L, -1616705048356126927L, MethodHandles.lookup().lookupClass()).a(18362726250717L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var11;
      Cipher var21 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(67065199475045L << var12 * 8 >>> 56);
      }

      var21.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[20];
      int var16 = 0;
      String var15 = "0\u001a?ìå<Ç»µÝ\u009c\u0092ýã%¤®\u0083N4s%tP E:\u008bòK\u0084\r\u0010lIk³'70_\\ ¥\u0019}j¡ñ LÜ©Ñ\rE;g±eTÙ\u001cop|^Y\në¨Þ(â\u0018\rïá´_\u008f\u0004\u0018l&Ç\u0010©\u001705e¹ÏÄp\u0082Ð~'æÍâÃû\u009a4\u0018T\u001dÏ\u0005-¬©ë2e+}®¡\u0007K\u0099_Jãù\u0089G^\u0018ñî¹ß\u0000à´¦ñþú\u0015ÎB±À@º\u0002\u009d]?¢9\u0010Øóþzÿ\u009e'_\u0097Î?mvß:ó ¬\u001dO(Ø¨P\fß¢V\u0085\u0088+ÃKg=Æ\u0016å\u0084±v8\u0017yW\u0000û^5\u0018¦Ä\u0018KiH\u008b!xá@\u0086²¸s(\u0007Æ(ÙÏó\tV ¤g¶C\u0018î·{ºDù÷^Û(Ë¥òHEF6Ø»ÕªÉJV\u00910ã\u0018Í=\u0017Â\u0097/O\u001a`åN\u0080OÕE'ª\u001f!BÊ\u008bïë\u0010!<\u001fG/òr\u001f'G\u0005gáhSú f\u008bJÚ»À¸@\u000fd£¥lá\u0097²¬5ïVF\f1\u0096\u0085)ßÐ\u008b\u00ad\u0004g\u00101Lrqú\u0015K´óL\u00adáé?ï\u008b\u0018Bý\u009c\u0088ç +ôºÀíjïÈ\u001fHDðÊ\u001fê3¡< Hà\u009d\u0080¦,\u0095ñ6ßFó-\u0006T~Ó`Mã\u0092q¦9\\õÞÄ9ÜµÝ\u0010HI\u008f^\u0086ÓÙ\nóÐ»(O7®\u0093 õ\f\u0005c\u008d¼R\u001e\u0001AMZo¼Û\u001fwj´Ó\u0083\u0006\båÔÀï \u001få\u0089Ð";
      short var17 = 465;
      char var14 = ' ';
      int var20 = -1;

      label45:
      while (true) {
         String var22 = var15.substring(++var20, var20 + var14);
         int var10001 = -1;

         while (true) {
            String var31 = c(var11.doFinal(var22.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var31;
                  if ((var20 += var14) >= var17) {
                     c = var18;
                     h = new String[20];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var24 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(67065199475045L << var1 * 8 >>> 56);
                     }

                     var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0092\u0082Êyð\u0081CEyó\u0001\"0p¬v\u0014\u007fhí\u008bØX]".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var36 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 24);

                     j = var6;
                     k = new Long[3];
                     友何友何树树树何何友 = new 何友友何树何树何树友(51913986529303L);
                     return;
                  }

                  var14 = var15.charAt(var20);
                  break;
               default:
                  var18[var16++] = var31;
                  if ((var20 += var14) < var17) {
                     var14 = var15.charAt(var20);
                     continue label45;
                  }

                  var15 = "÷\u001dÛ\u0084\u0091°\u001cG.^é½n¼\u00897 ¼×&\u0016r\u001c54\u008d¸¾\u008a¸µV\u008a;1[ª\u0002*N\u001d\u0002h\u0000\u000bzü\u0087h";
                  var17 = 49;
                  var14 = 16;
                  var20 = -1;
            }

            var22 = var15.substring(++var20, var20 + var14);
            var10001 = 0;
         }
      }
   }

   private boolean B(ItemStack stack) {
      树友何何友何树何树友.E();
      if (stack.getItem() instanceof FishingRodItem) {
         int existingRods = 友何树树何树何何何友.I(126784351559682L, Items.FISHING_ROD);
         if (existingRods > 0) {
            return false;
         }
      }

      if (stack.getItem() instanceof BlockItem) {
         int maxBlockCount = 树友何树友树何友树树.树何友友树树何友友树.友友树友树树何树树何.getValue().intValue();
         if (this.树树树友树何树友树友 + stack.getCount() > maxBlockCount) {
            return false;
         }
      }

      if (this.何何友何友何友友友树.getValue()) {
         Item item = stack.getItem();
         if (item instanceof SwordItem) {
            return this.D(stack);
         }

         if (item instanceof DiggerItem) {
            return this.D(stack);
         }

         if (item instanceof ArmorItem) {
            return this.D(stack);
         }

         if (item instanceof BowItem) {
            return this.D(stack);
         }
      }

      return true;
   }

   private boolean D(ItemStack stack) {
      树友何何友何树何树友.E();
      if (stack.getItem() instanceof SwordItem) {
         return 友何树树何树何何何友.n(stack) >= 友何树树何树何何何友.y(138626317535653L);
      } else {
         if (stack.getItem() instanceof DiggerItem) {
            if (stack.getItem() instanceof PickaxeItem) {
               return 友何树树何树何何何友.y(stack) >= 友何树树何树何何何友.A(110703249513207L);
            }

            if (stack.getItem() instanceof AxeItem) {
               return 友何树树何树何何何友.y(stack) >= 友何树树何树何何何友.u(51835005917766L);
            }

            if (stack.getItem() instanceof ShovelItem) {
               return 友何树树何树何何何友.y(stack) >= 友何树树何树何何何友.S(68871348897904L);
            }
         } else {
            if (stack.getItem() instanceof ArmorItem item) {
               float protection = 友何树树何树何何何友.X(stack);
               float bestArmor = 友何树树何树何何何友.N(item.getEquipmentSlot(), 129159117886604L);
               return protection >= bestArmor;
            }

            if (stack.getItem() instanceof BowItem) {
               if (友何树树何树何何何友.R(stack, 97346254604876L)) {
                  return 友何树树何树何何何友.V(stack) >= 友何树树何树何何何友.d(99887317511718L);
               }

               if (友何树树何树何何何友.p(730843686941L, stack)) {
                  return 友何树树何树何何何友.R(stack) >= 友何树树何树何何何友.B(25262814617821L);
               }
            }
         }

         return true;
      }
   }

   private Container F(AbstractFurnaceMenu container) throws Exception {
      Field[] fields = AbstractFurnaceMenu.class.getDeclaredFields();
      int var7 = fields.length;
      树友何何友何树何树友.E();
      int var8 = 0;
      if (0 < var7) {
         Field field = fields[0];
         if (Container.class.isAssignableFrom(field.getType())) {
            field.setAccessible(true);
            return (Container)field.get(container);
         }

         var8++;
      }

      return null;
   }

   private List<Integer> I(Container container) {
      树友何何友何树何树友.E();
      ArrayList slots = new ArrayList();
      int i = 0;
      if (0 < container.getContainerSize()) {
         ItemStack stack = container.getItem(0);
         if (!stack.isEmpty() && this.B(stack)) {
            slots.add(0);
         }

         i++;
      }

      return slots;
   }

   private void I(AbstractContainerMenu container, int slot) {
      树友何何友何树何树友.E();
      if (!this.友何友友友友友友树树) {
         this.友友树友友树友友友树 = container;
         this.何友树树友树何何友友 = slot;
         this.友何友友友友友友树树 = true;
         this.何友树友友树树树何树 = 0;
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 36;
               case 1 -> 15;
               case 2 -> 50;
               case 3 -> 37;
               case 4 -> 0;
               case 5 -> 9;
               case 6 -> 44;
               case 7 -> 28;
               case 8 -> 18;
               case 9 -> 61;
               case 10 -> 8;
               case 11 -> 39;
               case 12 -> 2;
               case 13 -> 43;
               case 14 -> 23;
               case 15 -> 42;
               case 16 -> 58;
               case 17 -> 10;
               case 18 -> 57;
               case 19 -> 63;
               case 20 -> 40;
               case 21 -> 51;
               case 22 -> 27;
               case 23 -> 38;
               case 24 -> 5;
               case 25 -> 48;
               case 26 -> 14;
               case 27 -> 55;
               case 28 -> 41;
               case 29 -> 12;
               case 30 -> 22;
               case 31 -> 49;
               case 32 -> 33;
               case 33 -> 46;
               case 34 -> 34;
               case 35 -> 7;
               case 36 -> 53;
               case 37 -> 24;
               case 38 -> 17;
               case 39 -> 32;
               case 40 -> 6;
               case 41 -> 30;
               case 42 -> 35;
               case 43 -> 16;
               case 44 -> 1;
               case 45 -> 21;
               case 46 -> 47;
               case 47 -> 26;
               case 48 -> 3;
               case 49 -> 60;
               case 50 -> 19;
               case 51 -> 13;
               case 52 -> 4;
               case 53 -> 56;
               case 54 -> 52;
               case 55 -> 25;
               case 56 -> 20;
               case 57 -> 31;
               case 58 -> 29;
               case 59 -> 54;
               case 60 -> 59;
               case 61 -> 11;
               case 62 -> 45;
               default -> 62;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private void i(BrewingStandMenu container) {
      树友何何友何树何树友.E();
      this.何友树友树友何树友何++;
      WrapperUtils.O(98140427145402L, container);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友友树树何何友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20666;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友友树树何何友树何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[=áPoñ«NLþZ£õ\u0015\u009eï\u009b, \u0003CM\u00adBÅ[a, Yt\u001e,m²y%\u0080Ã¦Ð¡¿¼g, o\u001dV\u0096Ä\u008fN^\u0087÷,\u009ep\u0085S\u001a, Ò\u0007\u009cO|\u0006_]ÄÊ\u00ad\u0004²B2Ô, )ç\u0081TB)ÊáLéÊX\u001cgb\u008e, \u0016=ºÔ'\u0003á\u0093, Ûã\u0083\u009cy\u008f\u00181\u001dÝ\u001cÇnÐÉh, \u0095³çÊ(\u0014\"T0_\u0093f\u009e\tg\u0092, \"\u0011\u0083íä=ó\u0004wÎ5ý4ÿã\u000f, $F®S\u0014\u0002\u001a\u008bÇ¬°\u0088\u001eªC\u0018, 02F°¾W=+, Ûû`0©\u0087\u0013öÛ$ÕXÁ\u0099\u0098ö, `6\u0083ö¦\u0091ôÊ, ÿNß\u000b\u0012É¦\u0017=×\u000e\u0096þSf^, \u0013ëòÁIÒ\u000e,Â/¥²+pß\u00ad,")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private void c() {
      this.友何友友友友友友树树 = false;
      this.何友树树友树何何友友 = -1;
      this.友友树友友树友友友树 = null;
      this.何友树友友树树树何树 = 0;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 21806;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/player/友友树树何何友树何友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友友树树何何友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'K' && var8 != 'F' && var8 != 'f' && var8 != 194) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 't') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 240) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'K') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'F') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'f') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private void n(ChestMenu container) {
      树友何何友何树何树友.E();
      this.何友树友树友何树友何++;
      List availableSlots = this.X(container);
      if (this.何树树友树何何何树树.getValue() && !availableSlots.isEmpty() && this.何友树友树友何树友何 > 1) {
         int randomSlot = (Integer)availableSlots.get(this.友何树友何友何树树友.nextInt(availableSlots.size()));
         this.I(container, randomSlot);
      }

      int i = 0;
      if (0 < container.getRowCount() * 9) {
         ItemStack stack = container.getSlot(0).getItem();
         if (!stack.isEmpty() && this.何友树友树友何树友何 > 1 && this.H(container, 0)) {
            return;
         }

         i++;
      }
   }

   @Override
   public void h() {
      this.w();
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/player/友友树树何何友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "*R;Y!j*R,\u0005-e0\u00198\u0018>o \u0019&\u0003)nj~;\u0012!p";
      m[1] = "]\u0013xHg\u0003]\u0013o\u0014k\fGX{\tx\u0006WXe\u0012o\u0007\u001d?x\u0003g";
      m[2] = "\u0010/80\u0015/\u001fou;\u001f2\u001a2~}\u0017/\u00174z6T)\u001e1z}\n,\u00128s!T压厸桐标伆伯压桢伔叝";
      m[3] = "\u0012K\u001e\u0012\u007f%\u0019D\u000f]\u00141\u001bO\u0018\u00078&\u0016";
      m[4] = "-p\u000b\u0007O\u000e\"0F\fE\u0013'mMJM\u000e*kI\u0001\u000e\b#nIJP\r/g@\u0016\u000e桰厅佋佰厯併桰伛栏叮";
      m[5] = "a~Mb\u0004\u000bU]B\"I\u0000_@G\u007fBFW]JyF\r\u0014\u007fAh_\u0004_\t";
      m[6] = "\f\tg5\u0005p\u0003I*>\u000fm\u0006\u0014!x\u001c~\u0003\u0012,x\u0003r\u001f\u000bg\u0014\u0005p\u0003\u0002(8<~\u0003\u0012,";
      m[7] = ";Y>)`L%Q$f\u001cX?\\'%";
      m[8] = int.class;
      n[8] = "java/lang/Integer";
      m[9] = "$vGS\u0019w+6\nX\u0013j.k\u0001\u001e\u0003l.t\u001a\u001e伣叓厌位桸佥桧位桖叓";
      m[10] = "4\u0014\boKd4\u0014\u001f3Gk._\u000b.Ta>_\u0015/Ph4\u0005\u00133_#\u001b\u0013\u000f5Tl9\u0005?.Hy;\u0018\u0012$T@?\u001f\t";
      m[11] = boolean.class;
      n[11] = "java/lang/Boolean";
      m[12] = "\u007f>$\u001eFyp~i\u0015Ldu#bSDyx%f\u0018\u0007标佉厛叁伨核叝受伅佟";
      m[13] = "]RU+\u00163R\u0012\u0018 \u001c.WO\u0013f\u000f=RI\u001ef\u00101NPU\u0006\f1\\Y\t\u001e\u00180KY";
      m[14] = "^S0\nKOQ\u0013}\u0001ARTNvGIOYHr\f\nIPMrGGOP_\u007f\u001d\nkTQr(QR\\";
      m[15] = long.class;
      n[15] = "java/lang/Long";
      m[16] = "`9\u00126\u0007\u000e`9\u0005j\u000b\u0001zr\u0005t\u0003\u0002`(Hh\u0006\u0006w9\u00146&\bm=\nH\u0006\u0006w9\u0014";
      m[17] = "S\u001d\u000f\u0010j6\\]B\u001b`+Y\u0000I]h6T\u0006M\u0016+0]\u0003M]u5Q\nD\u0001+案叻伦栰厸栔伌叻桢栰";
      m[18] = "\u0002+o_c\u0012\u0002+x\u0003o\u001d\u0018`x\u001dg\u001e\u0002:5<g\u0015\t-i\u0010h\u000f";
      m[19] = "6<w\u007f\r\u00186<`#\u0001\u0017,w`=\t\u00146--<\u0015\u001d,0s=\u0001\b=+-\u001c\u0015\u001d,0S=\u0001\b=+D0\r\u0014\u00156g4";
      m[20] = "\u001bF[A^@\u001bFL\u001dRO\u0001\rX\u0000AE\u0011\rF\u0001EL\u001bW@\u001dJ\u00076OF\fX}\fSJ";
      m[21] = "t\u000f&]\b<\u007f\u00007\u0012i2t\u000b3H";
      m[22] = " 3c\\B\u001d,6reSzph/_\u0006zL+#\u0015RP+,\"\u0006";
      m[23] = "g^g\u001aU9k[v#D^7\u0005+\u0019\u0013^\u000bF'SEtlA&@";
      m[24] = "p,\u0000%@\u0013;zF%9伩厊伜你栅叺桭伔厂叾\u001c\u0005\u000e4:\u0003\u007f\u0007\u0015p(";
      m[25] = "vd\u0017\u0013s\ntr\u000e\u0017B\u0007J3KD}SJ\u0002\u001e\u001ar\u001ba2\tG|\u0017";
      m[26] = "\u0007?\n7U`LiL7,佚佣厑叴体栵栞栧伏栮\u000e\u0013<C-LaMfPl";
      m[27] = "\tk:\u0004|?B=|\u0004\u0005伅栩栟叄栤佘伅佭栟栞=9\"M}9^;9\to";
      m[28] = "2sp\\[\u0002>vaeJeb(=Y\u001be^k0\u0015KO9l1\u0006";
      m[29] = "e\\e/\u001ai.\n#/cg\\\u000bd}[7eI%&\b\u000ef\r3.Z7$Lh}c";
      m[30] = "\u0015!U\u0002OG^w\u0013\u00026口佱厏伵栢栯根佱休厫;\b\u0010M#\tER\u001d\\1";
      m[31] = "f\u001a`e\u001e\u001crG}:f\u001ai[}2\u0000\u0010b ha\u0007EwG|<\u001a\u001a";
      m[32] = "sHsb\u0018V8\u001e5ba佬桓格厍厘桸史众格伓[_\u0001+J/%\u0005\f:X";
      m[33] = "%]7c\u0018\b)X&Z\tou\u0006{`]oIEw*\bE.Bv9";
      m[34] = "S\n%5XeRK ?fXcz\u000f\r1Dye\tN\u000b0_@z*\nqZJ";
      m[35] = "prhNkl|wywz\u000b )%K$\u000b\u001cj(\u0007{!{m)\u0014";
      m[36] = "H|]\u0017j;DyL.{\\\u0018'\u0010\u0017/\\$d\u001d^zvCc\u001cM";
      m[37] = "S\u001d[sWM\u0018K\u001ds.佷厩桩厥厉样栳桳伭桿J\u0013X\u0010\u001f\u00065\u0011R\u0005\u000f";
      m[38] = "\u0013gK\"OeX1\r\"6佟叩栓厵栂叵佟栳叉伫\u001b\u000bpPe\u0016d\tzEu";
      m[39] = "*o#\u0011u\u0019a9e\u0011\f伣叐栛标叫栕伣低叁叝(1\fim~W3\u0006|}";
      m[40] = "{A\b7+F0\u0017N7R佼桛佱栬栗桋核桛佱佨\u000e;C9WLv6\u001b8\u001c";
      m[41] = "\fcPQY0O~\u000eZ%桐叵叝栦叢另厊叵标佢!\u001f4YnCX\\)\u0007e";
      m[42] = "\u001b(@ h\\P~\u0006 \u0011司使历厾叚叒司叡桜桤\u0019!\u000b\u0019t\r}}U[<";
      m[43] = "S\u0006<\u001a\nT\u0002\u001elEa厪桺桢厒伤厢伴桺厸案yQ\u0014\u000e\u0018:D\u0000\f^G";
      m[44] = "B\u0000^z|!\tV\u0018z\u0005桟伦桴桺桚栜桟伦厮桺C9<\u0006\u0016] ;'B\u0004";
      m[45] = "\"vO\u0015\u0018ni \t\u0015a及变栂厱可桸及变变桫,^2fd\tC\u0000hu%";
      m[46] = "\fqf6*\u0019G' 6S桧栬栅厘栖厐伣佨栅桂\u000fb\u0015X{bd3\u0012R}";
      m[47] = "_s9F\u00188Z8g\u0002g栘佨叁叀栧桾作叶叁栚>\rp\u000fz|\u0007\b;Q>";
      m[48] = "&\u0015X\u00112imC\u001e\u0011K体栆去桼叫厈栗佂桡伸(u>~\u0017\u0004V/3o\u0005";
      m[49] = "S\u0005VD\u0017\u0012_\u0000G}\u0006u\u0003^\u001b@Ru?\u001d\u0016\r\u0007_X\u001a\u0017\u001e";
      m[50] = " &(\u0014oFkpn\u0014\u0016核佄桒佈佰叕叢栀伖取-+Sc$uR)Yv4";
      m[51] = "Edw19\u0002\u0006y):E6\u007f% '|\tB#e=9{";
      m[52] = "\u000b0\u0001=p\u001cUj\u0012|\u000b\u001dc0Lr7Kc\u000bA0q\u001cTtC:d\f";
      m[53] = "2Slm\u001cTy\u0005*me株栒栧厒桍伸株又栧厒TXAqQ1+ZKdA";
      m[54] = "p\u0011w]\t';G1]p伝伔县桓伹厳厃厊伡众dL:4\u0007t\u0007N!p\u0015";
      m[55] = "!ub\u0000E\u007fj#$\u0000<叛佅栁厜佤叿佅栁栁厜9\u0000f}d/IW(!\u007f";
      m[56] = "J\u0006l~\u001e\u0012\u0001P*~g伨伮厨伌厄伺厶厰厨案G[\u000f\u000e\u0010o$Y\u0014J\u0002";
      m[57] = "\u0007C70-i\u0002\bitR厓厮栫収桑桋伍桴栫佐Hc;\u0000U4#2<\nS";
      m[58] = "K649U\u0004\u0000`r9,厠伯厘佔佝栵厠厱厘及\u0000\u0010\u0019\u000f 7c\u0012\u0002K2";
      m[59] = "''\u0010\u0018\u0015qlqV\u0018l叕叝众叮核厯叕佃众叮!]}s-\u0014J\fzy+";
      m[60] = "\u001e?d\u0013zSUi\"\u0013\u0003佩佺厑厚叩佞号栾桋厚*?NZ)gI=U\u001e;";
      m[61] = "yZ)TI\b2\foT0桶厃栮受厮佭桶伝栮佉m\t\u0002}\u000em\nBT;\u000e";
      m[62] = "\u0000?C\u0006\u0010\u0003\u0003:\u0001\u0001i\b=aEUXX=ZDV\u0014\u0019\u00115\u001a\f\u0007X";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private void p(FurnaceMenu container) {
      树友何何友何树何树友.E();
      this.何友树友树友何树友何++;

      try {
         this.F(container);
      } catch (Exception var11) {
         var11.printStackTrace();
      }
   }

   @EventTarget
   public void p(LivingUpdateEvent event) {
      树友何何友何树何树友.E();
      if (this.友何友友友友友友树树 && this.友友树友友树友友友树 != null && this.何友树树友树何何友友 >= 0) {
         this.何友树友友树树树何树++;
         if (this.何友树友友树树树何树 >= 1) {
            this.u();
            this.c();
         }
      }
   }

   public boolean p() {
      树友何何友何树何树友.E();
      AbstractContainerMenu container = mc.player.containerMenu;
      if (container instanceof ChestMenu) {
         return this.q((ChestMenu)container);
      } else if (container instanceof FurnaceMenu) {
         return this.w((FurnaceMenu)container);
      } else {
         return container instanceof BrewingStandMenu ? this.u((BrewingStandMenu)container) : true;
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static boolean g() {
      树友何何友何树何树友.E();
      return !友何友何树树树何何友.A(3L, 118344821288830L);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void j(WorldEvent event) {
      this.w();
   }

   private boolean q(ChestMenu c) {
      树友何何友何树何树友.E();
      int i = 0;
      if (0 < c.getRowCount() * 9) {
         ItemStack stack = c.getSlot(0).getItem();
         if (!stack.isEmpty() && (this.E(stack) || this.树何树树树树树何友树.getValue()) && this.B(stack)) {
            return false;
         }

         i++;
      }

      return true;
   }

   private boolean z(ChestMenu menu) {
      树友何何友何树何树友.E();
      if (this.q(menu) && this.何树树友友树友何树何.A(100L, 118344821288830L)) {
         mc.player.closeContainer();
         return false;
      } else {
         return true;
      }
   }

   private boolean w(FurnaceMenu c) {
      树友何何友何树何树友.E();

      try {
         this.F(c);
         return false;
      } catch (Exception var8) {
         var8.printStackTrace();
         return false;
      }
   }

   private void w() {
      this.c();
      this.树何树何何友友树何友 = 0;
   }

   private void u() {
      树友何何友何树何树友.E();
      if (this.友友树友友树友友友树 != null && this.何友树树友树何何友友 >= 0) {
         this.何树何树树树树树何何 = this.友友何友树友友何何友.getValue().longValue();
         mc.gameMode.handleInventoryMouseClick(this.友友树友友树友友友树.containerId, this.何友树树友树何何友友, 0, ClickType.QUICK_MOVE, mc.player);
         this.何树友树友友树何树何.D(11747522392279L);
         this.何树树友友树友何树何.D(11747522392279L);
         友何友何树树树何何友.D(11747522392279L);
      }
   }

   private boolean u(BrewingStandMenu c) {
      树友何何友何树何树友.E();
      WrapperUtils.O(98140427145402L, c);
      return true;
   }

   private boolean E(ItemStack stack) {
      树友何何友何树何树友.E();
      if (stack.isEmpty()) {
         return false;
      } else if (!友何树树何树何何何友.A(90513947799501L, stack) && !友何树树何树何何何友.r(124830374301047L, stack)) {
         if (stack.getItem() instanceof ArmorItem item) {
            float protection = 友何树树何树何何何友.X(stack);
            float bestArmor = 友何树树何树何何何友.N(item.getEquipmentSlot(), 129159117886604L);
            return !(protection <= bestArmor);
         } else if (stack.getItem() instanceof SwordItem) {
            float damage = 友何树树何树何何何友.n(stack);
            float bestDamage = 友何树树何树何何何友.y(138626317535653L);
            return !(damage <= bestDamage);
         } else if (stack.getItem() instanceof PickaxeItem) {
            float score = 友何树树何树何何何友.y(stack);
            float bestScore = 友何树树何树何何何友.A(110703249513207L);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof AxeItem) {
            float score = 友何树树何树何何何友.y(stack);
            float bestScore = 友何树树何树何何何友.u(51835005917766L);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof ShovelItem) {
            float score = 友何树树何树何何何友.y(stack);
            float bestScore = 友何树树何树何何何友.S(68871348897904L);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof CrossbowItem) {
            float score = 友何树树何树何何何友.p(stack);
            float bestScore = 友何树树何树何何何友.q(60615970057744L);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof BowItem && 友何树树何树何何何友.R(stack, 97346254604876L)) {
            float score = 友何树树何树何何何友.V(stack);
            float bestScore = 友何树树何树何何何友.d(99887317511718L);
            return !(score <= bestScore);
         } else if (stack.getItem() instanceof BowItem && 友何树树何树何何何友.p(730843686941L, stack)) {
            float score = 友何树树何树何何何友.R(stack);
            float bestScore = 友何树树何树何何何友.B(25262814617821L);
            return !(score <= bestScore);
         } else if (stack.getItem() == Items.COMPASS) {
            return !友何树树何树何何何友.o(stack.getItem(), 105953152221091L);
         } else if (stack.getItem() == Items.WATER_BUCKET && 友何树树何树何何何友.I(126784351559682L, Items.WATER_BUCKET) >= 树友何树友树何友树树.q()) {
            return false;
         } else if (stack.getItem() == Items.LAVA_BUCKET && 友何树树何树何何何友.I(126784351559682L, Items.LAVA_BUCKET) >= 树友何树友树何友树树.K()) {
            return false;
         } else if (stack.getItem() instanceof BlockItem
            && 树何树树何何树友何何.H(83539975070260L, stack)
            && 友何树树何树何何何友.w(137788481673036L) + stack.getCount() >= 树友何树友树何友树树.y()) {
            return false;
         } else if (stack.getItem() == Items.ARROW && 友何树树何树何何何友.I(126784351559682L, Items.ARROW) + stack.getCount() >= 树友何树友树何友树树.b()) {
            return false;
         } else if (stack.getItem() instanceof FishingRodItem && 友何树树何树何何何友.I(126784351559682L, Items.FISHING_ROD) >= 1) {
            return false;
         } else if ((stack.getItem() == Items.SNOWBALL || stack.getItem() == Items.EGG)
            && 友何树树何树何何何友.I(126784351559682L, Items.SNOWBALL) + 友何树树何树何何何友.I(126784351559682L, Items.EGG) + stack.getCount() >= 树友何树友树何友树树.O()) {
            return false;
         } else {
            return stack.getItem() instanceof ItemNameBlockItem ? false : 友何树树何树何何何友.x(stack, 41856307316715L);
         }
      } else {
         return true;
      }
   }

   private List<Integer> X(ChestMenu container) {
      树友何何友何树何树友.E();
      ArrayList slots = new ArrayList();
      int i = 0;
      if (0 < container.getRowCount() * 9) {
         ItemStack stack = container.getSlot(0).getItem();
         if (!stack.isEmpty() && (this.E(stack) || this.树何树树树树树何友树.getValue()) && this.B(stack)) {
            slots.add(0);
         }

         i++;
      }

      return slots;
   }

   private void N() {
      树友何何友何树何树友.E();
      this.树树树友树何树友树友 = 0;
      int i = 0;
      if (0 < mc.player.getInventory().getContainerSize()) {
         ItemStack stack = mc.player.getInventory().getItem(0);
         if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) {
            this.树树树友树何树友树友 = this.树树树友树何树友树友 + stack.getCount();
         }

         i++;
      }
   }

   @EventTarget
   public void W(MotionEvent event) {
      树友何何友何树何树友.E();
      if (!this.Q(new Object[]{52406761729175L})
         && KillAura.instance.Y() == null
         && !树友何何友何树何树友.树友友树友友友友树何.isEnabled()
         && this.何树友树友友树何树何.A((int)this.何树何树树树树树何何, 118344821288830L)
         && mc.player.isAlive()
         && !mc.player.isDeadOrDying()
         && !mc.player.isSpectator()
         && !event.isPost()) {
         AbstractContainerMenu container = mc.player.containerMenu;
         this.N();
         if (container instanceof ChestMenu && this.友何友何何树友友友友.getValue()) {
            this.n((ChestMenu)container);
         }

         if (container instanceof FurnaceMenu && this.何何友友友何友树树友.getValue()) {
            this.p((FurnaceMenu)container);
         }

         if (container instanceof BrewingStandMenu && this.何友何何树友树何友友.getValue()) {
            this.i((BrewingStandMenu)container);
         }

         if (container != null && (container instanceof ChestMenu || container instanceof FurnaceMenu || container instanceof BrewingStandMenu)) {
            if (container != this.何何友友何树树树何树) {
               友何友何树树树何何友.D(11747522392279L);
               this.树何树何何友友树何友 = 0;
            }

            this.树何树何何友友树何友++;
            if (this.树何树何何友友树何友 < this.树树树友树友何何树树.getValue().intValue()) {
               return;
            }

            if (container instanceof ChestMenu menu && (this.友何友何何树友友友友.getValue() || this.何何友树何友友友何何.getValue()) && this.z(menu)) {
               this.n(menu);
            }
         }

         this.树何树何何友友树何友 = 0;
         this.何何友友何树树树何树 = container;
      }
   }

   private boolean H(ChestMenu container, int slot) {
      树友何何友何树何树友.E();
      ItemStack stack = container.getSlot(0).getItem();
      if ((this.E(stack) || this.树何树树树树树何友树.getValue()) && this.B(stack)) {
         this.I(container, slot);
         return true;
      } else {
         return false;
      }
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖国企变私企";
   }
}
