package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.client.树友何何何树何树友友;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Matrix4f;
import why.tree.friend.antileak.Fucker;

public class 友树友树友树树何友友 extends Module implements 何树友 {
   private final Map<友树友树友树树何友友.树何树友何树友友树树, BlockState> 何树树树友友何友树何 = new ConcurrentHashMap<>();
   private final List<BlockPos> 何树友友树友何友何友 = new CopyOnWriteArrayList<>();
   private final List<BlockPos> 何树何何友友树何友友 = new CopyOnWriteArrayList<>();
   private final Map<Block, Color> 树何友友树树友何何友 = new HashMap<>();
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[49];
   private static final String[] k = new String[49];
   private static String HE_WEI_LIN;

   public 友树友树友树树何友友() {
      super("RareOreXRay", "稀有矿物透视", 树何友友何树友友何何.友友树树何友树树友树);
      this.树何友友树树友何何友.put(Blocks.GOLD_ORE, new Color(255, 215, 0));
      this.树何友友树树友何何友.put(Blocks.DEEPSLATE_GOLD_ORE, new Color(255, 215, 0));
      this.树何友友树树友何何友.put(Blocks.DIAMOND_ORE, new Color(0, 255, 255));
      this.树何友友树树友何何友.put(Blocks.DEEPSLATE_DIAMOND_ORE, new Color(0, 255, 255));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(4180309904318407113L, 3448510027774495527L, MethodHandles.lookup().lookupClass()).a(61956882866361L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(110655972762264L << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 24;
      int var4 = -1;

      while (true) {
         String var13 = c(
               var2.doFinal(
                  "\u0007Tb¼\u007fÌ¶wÝ\u0012#þ·H\n÷\u0016ô[Þ-\u0017ÇG03ã,\u008aUó§ä®uÉ\u001büãÓJÞÚ«\u0004äéTKù\u0007\u0080J\u0096\u0083ë¬òÎf¿7A.\u007fÖxPõÕ-kÿ"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 73) {
            c = var9;
            h = new String[2];
            return;
         }

         var5 = "\u0007Tb¼\u007fÌ¶wÝ\u0012#þ·H\n÷\u0016ô[Þ-\u0017ÇG03ã,\u008aUó§ä®uÉ\u001büãÓJÞÚ«\u0004äéTKù\u0007\u0080J\u0096\u0083ë¬òÎf¿7A.\u007fÖxPõÕ-kÿ"
            .charAt(var4);
      }
   }

   private Color J(BlockState state) {
      Block block = state.getBlock();
      return this.树何友友树树友何何友.getOrDefault(block, Color.WHITE);
   }

   @EventTarget
   public void J(LivingUpdateEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         this.s(5);
      }
   }

   @EventTarget
   public void S(PacketEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundBlockUpdatePacket S23) {
            this.何树何何友友树何友友.add(S23.getPos());
            this.何树树树友友何友树何.put(new 友树友树友树树何友友.树何树友何树友友树树(S23.getPos()), S23.getBlockState());
         }

         if (packet instanceof ClientboundSectionBlocksUpdatePacket S22) {
            S22.runUpdates((pos, state) -> {
               this.何树何何友友树何友友.add(pos);
               this.何树树树友友何友树何.put(new 友树友树友树树何友友.树何树友何树友友树树(pos), state);
            });
         }
      }
   }

   private void Z(PoseStack poseStack, float minX, float maxX, float minY, float maxY, float minZ, float maxZ, int startColor) {
      Matrix4f matrix = poseStack.last().pose();
      float red = (startColor >> 16 & 0xFF) / 255.0F;
      float green = (startColor >> 8 & 0xFF) / 255.0F;
      float blue = (startColor & 0xFF) / 255.0F;
      float alpha = (startColor >> 24 & 0xFF) / 255.0F;
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      bufferBuilder.begin(Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 38;
               case 1 -> 24;
               case 2 -> 2;
               case 3 -> 34;
               case 4 -> 59;
               case 5 -> 47;
               case 6 -> 46;
               case 7 -> 33;
               case 8 -> 52;
               case 9 -> 8;
               case 10 -> 58;
               case 11 -> 32;
               case 12 -> 61;
               case 13 -> 12;
               case 14 -> 40;
               case 15 -> 25;
               case 16 -> 53;
               case 17 -> 55;
               case 18 -> 36;
               case 19 -> 7;
               case 20 -> 27;
               case 21 -> 6;
               case 22 -> 13;
               case 23 -> 44;
               case 24 -> 42;
               case 25 -> 51;
               case 26 -> 45;
               case 27 -> 18;
               case 28 -> 5;
               case 29 -> 57;
               case 30 -> 26;
               case 31 -> 4;
               case 32 -> 41;
               case 33 -> 31;
               case 34 -> 28;
               case 35 -> 3;
               case 36 -> 29;
               case 37 -> 39;
               case 38 -> 62;
               case 39 -> 0;
               case 40 -> 35;
               case 41 -> 20;
               case 42 -> 56;
               case 43 -> 19;
               case 44 -> 54;
               case 45 -> 15;
               case 46 -> 11;
               case 47 -> 23;
               case 48 -> 49;
               case 49 -> 37;
               case 50 -> 14;
               case 51 -> 17;
               case 52 -> 48;
               case 53 -> 43;
               case 54 -> 60;
               case 55 -> 22;
               case 56 -> 1;
               case 57 -> 9;
               case 58 -> 16;
               case 59 -> 10;
               case 60 -> 21;
               case 61 -> 63;
               case 62 -> 30;
               default -> 50;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树友树友树树何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16288;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友树友树友树树何友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public void s(int range) {
      int playerX = (int)mc.player.getX();
      int playerY = (int)mc.player.getY();
      int playerZ = (int)mc.player.getZ();
      树友何何何树何树友友.G(() -> {
         Set<BlockPos> uncheckedSet = new HashSet<>(this.何树友友树友何友何友);
         Set<BlockPos> checkedSet = new HashSet<>(this.何树何何友友树何友友);
         Set<Block> oreBlocks = new HashSet<>();
         oreBlocks.add(Blocks.DIAMOND_ORE);
         oreBlocks.add(Blocks.DEEPSLATE_DIAMOND_ORE);
         oreBlocks.add(Blocks.GOLD_ORE);
         oreBlocks.add(Blocks.DEEPSLATE_GOLD_ORE);
         BetterCamera.e();
         ArrayList newBlocks = new ArrayList();
         int processed = 0;
         int x = -rangex;
         if (x <= rangex) {
            int y = -rangex;
            if (y <= rangex) {
               int z = -rangex;
               if (z <= rangex) {
                  BlockPos blockPos = new BlockPos(playerX + x, playerY + y, playerZ + z);
                  if (!uncheckedSet.contains(blockPos)) {
                     if (checkedSet.contains(blockPos)) {
                     }

                     if (mc.level.isLoaded(blockPos)) {
                        if (oreBlocks.stream().noneMatch(b -> b == Blocks.SPAWNER) && this.k(blockPos)) {
                        }

                        Block block = mc.level.getBlockState(blockPos).getBlock();
                        if (oreBlocks.contains(block)) {
                           newBlocks.add(blockPos);
                           uncheckedSet.add(blockPos);
                        }

                        if (++processed >= 1000) {
                           try {
                              Thread.sleep(1L);
                           } catch (InterruptedException var22) {
                              Thread.currentThread().interrupt();
                              return;
                           }
                        }
                     }
                  }

                  z++;
               }

               y++;
            }

            x++;
         }

         synchronized (this.何树友友树友何友何友) {
            this.何树友友树友何友何友.addAll(newBlocks);
         }
      }, 108624793298909L);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树友树友树树何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'R' && var8 != 245 && var8 != 244 && var8 != 'X') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 253) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'b') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'R') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 245) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @EventTarget
   public void n(Render3DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         this.何树树树友友何友树何.forEach((pos, state) -> {
            BetterCamera.e();
            if (state.getBlock() != Blocks.AIR && this.g(state)) {
               BlockPos blockPos = pos.I();
               if (mc.level.getBlockState(blockPos).getBlock() == Blocks.AIR) {
                  return;
               }

               BlockState actualState = mc.level.getBlockState(blockPos);
               Color color = this.J(state);
               int colorRGB = color.getRGB();
               this.m(event.poseStack(), blockPos, actualState, colorRGB, true, true, 0.3F);
            }
         });
      }
   }

   @Override
   public void h() {
      if (BetterCamera.e() != null) {
         if (this.Q(new Object[]{52406761729175L})) {
            return;
         }

         mc.levelRenderer.allChanged();
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static void a() {
      j[0] = "^r +R\u0016Q2m X\u000bToffP\u0016Yib-\u0013\u0010PlbfO\u001cSxk:\u0013;Xhz-O:\\qk:\\";
      j[1] = "w\u0014jU,%|\u001b{\u001aQ=o\u001crS";
      j[2] = " \u0014\u00120\b]/T_;\u0002@*\tT}\n]'\u000fP6I[.\nP}\u0015W-\u001eY!I叹桒厱栭厘桶栣伖厱号";
      j[3] = "\u0007\u0001[lx.\f\u000eJ#\u0013:\u000e\u0005]y?-\u0003";
      j[4] = "vWBNf>h_X\u0001\u0005*l";
      j[5] = "\r\u0002(\n\u0018\u001f\r\u0002?V\u0014\u0010\u0017I?H\u001c\u0013\r\u0013ri\u001c\u0018\u0006\u0004.E\u0013\u0002";
      j[6] = "zEp\u0006\u0017\u0000zEgZ\u001b\u000f`\u000egD\u0013\fzT*Z\u001f\u0007pEvM\bGXErM\u0016;qN`M\b\ff";
      j[7] = "D*b\\;gZ\"x\u0013Y{]?";
      j[8] = "L&:\u001a2\rL&-F>\u0002Vm9[-\bFm\"Q)\u0001Nm,X0\u0007Im\fX0\u0007I0";
      j[9] = "\u0010=WG\u0003\u000e\u0010=@\u001b\u000f\u0001\nvT\u0006\u001c\u000b\u001avO\f\u0018\u0002\u0012vA\u0005\u0001\u0004\u0015va\u0005\u0001\u0004\u0015";
      j[10] = "\u001a$WB0)\u0015d\u001aI:4\u00109\u0011\u000f2)\u001d?\u0015Dq桗伬厁厲佴桎厍厲伟伬";
      j[11] = "\u0006DL#{H\u000fJOj8E\tJ[h%CK]D\u007fbB\u001d\u0005whdS\u0000SgbdJ\u0004_\u0005@yC\u0000";
      j[12] = "MX%VMDDV&\u001f\u000eIBV2\u001d\u0013O\u0000A-\nTNV\u0019\f\u001dFJ[[<.EYZR0>OYCV<";
      j[13] = "?4+1KO6:(x\bB0:<z\u0015Dr-#mRE$u\u0010zTT9#\u0000pTM=/";
      j[14] = "I\u000e\u0000z\u0006#T\u001bXXG.L\u001d";
      j[15] = "\u0015%\u0004l%N\u0015%\u00130)A\u000fn\u0007-:K\u001fn\u0000*1TU\u00011\u0000\n";
      j[16] = double.class;
      k[16] = "java/lang/Double";
      j[17] = "oE\u0019x:\u0017oE\u000e$6\u0018u\u000e\u001a9%\u0012e\u000e\u001d>.\r/v\b5d";
      j[18] = "N^/PlMN^8\f`BT\u00158\u0012hANOu\fdJD^)\u001bs\ngZ6\u001bSAN_>\fdV";
      j[19] = "IGKu\u0000<BHZ:a2IC^`";
      j[20] = ":/`VNk//kL~|\u0007%a\u000eO(\u0007\u00151V\u001cmo{?J\u0006j";
      j[21] = "cr-\u001apsdlv\u001e\u000e$\t6&B?r\t\n)\u0013|,53u\u0001|-";
      j[22] = "I\u0015\u001fB=\u001b\u0011\u0017CXC\ts\u0017EX2\\BV\u0010Z)`I\u0011\u001dM\u007fQ\bD\u001fVC";
      j[23] = "(?=\u0014\u0011\b/!f\u0010o_B{6L^\fBG9\u001d\u001dW~~e\u000f\u001dV";
      j[24] = "?{=Bk\u00188efF\u0015OU>?\u0013%\u0010U\u00039KgGi:eYgF";
      j[25] = "=\u0019jzk\u0016e\u001b6`\u0015桴佚叢叏栝栌厮佚佼叏\u0004/\u0011u\u001buty\u000e9K";
      j[26] = "\u001aG%hS\u0017BEyr-伱根伢伞叕叮桵佽厼厀\u0016\u0010SF\u0019-u\u0016UF@";
      j[27] = "dxC1nBqxH+^UYrBio\u0000YB\u00121<D1,\u001c-&C";
      j[28] = "\u0004dS\u0012+\b\u0003z\b\u0016U_n!QCe\fn\u001cW\u001b'WR%\u000b\t'V";
      j[29] = " \u000b\u00142V1bA\u00132naK\u0002U`P4K3\u0007(\bhg\u000e\u000bi\u0013l";
      j[30] = "j.#.(\u0016\u007f.(4\u0018\u0001W$\"v(_W\u0014r.z\u0010?z|2`\u0017";
      j[31] = "`R\u0010H@N8PLR>佨桃桳桯叵叽佨厙桳伫6\u0004I(P\u000fFRVd\u0000";
      j[32] = "]\tlV\u001ch\u0010\u00062\u0017y\u0015 *\bi.\u001d,&\u0018}yi\u0004Y%CH$\u000b\u0007d";
      j[33] = "Ut2#zu\u000f342\ne2:d}362\nh+hk\u0001w\"#lf";
      j[34] = "E\u007f(0=}\u0012cy:\r)y!rk=\u007fy\u0011\"5o8\u0011\u007f,)u?";
      j[35] = "lx;aw~lli^&C4,>$.%ca,?K";
      j[36] = ">g$z'_9y\u007f~Y\bT&#)eX<H\u001e-9\u0014et'q+\u0014d";
      j[37] = "i\u0001z\u0000(`$\u000e$AM\b\u0004!\u000f+Ma0Q3\u0015|,?\u000fr";
      j[38] = "v+T6\b\u0018!7\u0005<8LJu\u000em\u0007\u0013JE^3Z]\"+P/@Z";
      j[39] = "u8\u001c\t5C\"$M\u0003\u0005\u0017IfFR5@IV\u0016\fg\u0006!8\u0018\u0010}\u0001";
      j[40] = "v\u0005\u0002y\u001c\u0004q\u001bY}bS\u001c@\u0000([\u0003\u001c}\u0006p\u0010[ DZb\u0010Z";
      j[41] = "OSZL\u0011$ZSQV!3rY[\u0014\u0011lri\u000bLC\"\u001a\u0007\u0005PY%";
      j[42] = ">\u001d\u00192d;|W\u001e2\\kU\u0014X`b=U%] 5<e\u0018[d3{";
      j[43] = "\tN\u0005\u001a%w\u001cN\u000e\u0000\u0015`4D\u0004B$64tT\u001awq\\\u001aZ\u0006mv";
      j[44] = "\u00184qN\u0010\u001e@6-Tn伸栻叏叔栩厭伸叡佑叔0SZDjySU\\D3";
      j[45] = "\bRV\u0010Yo\u000fL\r\u0014'8b\u0013QC\u001bi\t}lGG$SAU\u001bU$R";
      j[46] = "+\r)\u0006n\u001as\u0001cYW&Z0N*WHfJs^4\u0010j\u0000,";
      j[47] = "GP-Q'A\u0007\u0014)VL古去桶桛佨厏栾桡厬桛5s\u0018\u0017\u000b)S3\\\u0013\f";
      j[48] = "C\u001fF=\u0003JV\u001fM'3]~\u0015Ge\u0002\n~%\u0017=QL\u0016K\u0019!KK";
   }

   public void m(PoseStack poseStack, BlockPos pos, BlockState state, int color, boolean fillMode, boolean wireframeMode, float fillAlpha) {
      BetterCamera.e();
      if (!state.isAir()) {
         VoxelShape shape = state.getShape(mc.level, pos);
         if (!shape.isEmpty()) {
            Camera camera = mc.gameRenderer.getMainCamera();
            Vec3 camPos = camera.getPosition();
            double x = pos.getX() - camPos.x;
            double y = pos.getY() - camPos.y;
            double z = pos.getZ() - camPos.z;
            poseStack.pushPose();
            poseStack.translate(x, y, z);
            Iterator var20 = shape.toAabbs().iterator();
            if (var20.hasNext()) {
               AABB aabb = (AABB)var20.next();
               float minX = (float)aabb.minX;
               float maxX = (float)aabb.maxX;
               float minY = (float)aabb.minY;
               float maxY = (float)aabb.maxY;
               float minZ = (float)aabb.minZ;
               float maxZ = (float)aabb.maxZ;
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               RenderSystem.disableDepthTest();
               RenderSystem.setShader(GameRenderer::getPositionColorShader);
               this.E(poseStack, minX, maxX, minY, maxY, minZ, maxZ, color, 0.3F);
               RenderSystem.disableDepthTest();
               RenderSystem.defaultBlendFunc();
               this.Z(poseStack, minX, maxX, minY, maxY, minZ, maxZ, color);
            }

            RenderSystem.enableDepthTest();
            poseStack.popPose();
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private boolean k(BlockPos pos) {
      BetterCamera.e();
      return mc.level.getBlockState(pos.above()).getBlock() == Blocks.AIR
         || mc.level.getBlockState(pos.above()).getBlock() == Blocks.WATER
         || mc.level.getBlockState(pos.below()).getBlock() == Blocks.AIR
         || mc.level.getBlockState(pos.below()).getBlock() == Blocks.WATER
         || mc.level.getBlockState(pos.south()).getBlock() == Blocks.AIR
         || mc.level.getBlockState(pos.south()).getBlock() == Blocks.WATER
         || mc.level.getBlockState(pos.north()).getBlock() == Blocks.AIR
         || mc.level.getBlockState(pos.north()).getBlock() == Blocks.WATER
         || mc.level.getBlockState(pos.east()).getBlock() == Blocks.AIR
         || mc.level.getBlockState(pos.east()).getBlock() == Blocks.WATER
         || mc.level.getBlockState(pos.west()).getBlock() == Blocks.AIR
         || mc.level.getBlockState(pos.west()).getBlock() == Blocks.WATER;
   }

   private boolean g(BlockState state) {
      BetterCamera.e();
      Block block = state.getBlock();
      return block != Blocks.DIAMOND_ORE && block != Blocks.DEEPSLATE_DIAMOND_ORE ? block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE : true;
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void E(PoseStack poseStack, float minX, float maxX, float minY, float maxY, float minZ, float maxZ, int startColor, float alpha) {
      Matrix4f matrix = poseStack.last().pose();
      float red = (startColor >> 16 & 0xFF) / 255.0F;
      float green = (startColor >> 8 & 0xFF) / 255.0F;
      float blue = (startColor & 0xFF) / 255.0F;
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      bufferBuilder.begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, minX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(red, green, blue, alpha).endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
   }

   @Override
   public void M() {
      BetterCamera.e();
      this.何树树树友友何友树何.clear();
      this.何树友友树友何友何友.clear();
      this.何树何何友友树何友友.clear();
      if (!this.Q(new Object[]{52406761729175L})) {
         mc.levelRenderer.allChanged();
      }
   }

   private static String HE_WEI_LIN() {
      return "我是何树友";
   }

   @EventTarget
   public void Q(WorldEvent event) {
      this.n();
   }

   public static class 树何树友何树友友树树 implements 何树友 {
      private final int 何树友树友友何友友何;
      private final int 友友树树何树树树树何;
      private final int 何友友何树友友何友树;
      private static final long a;
      private static final Object[] b = new Object[11];
      private static final String[] c = new String[11];
      private static String HE_JIAN_GUO;

      public 树何树友何树友友树树(BlockPos pos) {
         this.何树友树友友何友友何 = pos.getX();
         this.友友树树何树树树树何 = pos.getY();
         this.何友友何树友友何友树 = pos.getZ();
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(7942805139518793146L, -537458527059419642L, MethodHandles.lookup().lookupClass()).a(61759036452665L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      @Override
      public boolean equals(Object obj) {
         BetterCamera.e();
         if (this == obj) {
            return true;
         } else if (obj != null && this.getClass() == obj.getClass()) {
            友树友树友树树何友友.树何树友何树友友树树 position = (友树友树友树树何友友.树何树友何树友友树树)obj;
            return this.何树友树友友何友友何 == position.何树友树友友何友友何 && this.友友树树何树树树树何 == position.友友树树何树树树树何 && this.何友友何树友友何友树 == position.何友友何树友友何友树;
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         int result = this.何树友树友友何友友何;
         result = 31 * result + this.友友树树何树树树树何;
         return 31 * result + this.何友友何树友友何友树;
      }

      public BlockPos I() {
         return new BlockPos(this.何树友树友友何友友何, this.友友树树何树树树树何, this.何友友何树友友何友树);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友树友树友树树何友友$树何树友何树友友树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 245 && var8 != 204 && var8 != 234 && var8 != 206) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'Y') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 163) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 245) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 204) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 234) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 21;
                  case 1 -> 5;
                  case 2 -> 42;
                  case 3 -> 60;
                  case 4 -> 20;
                  case 5 -> 56;
                  case 6 -> 19;
                  case 7 -> 48;
                  case 8 -> 10;
                  case 9 -> 27;
                  case 10 -> 13;
                  case 11 -> 2;
                  case 12 -> 9;
                  case 13 -> 7;
                  case 14 -> 18;
                  case 15 -> 30;
                  case 16 -> 61;
                  case 17 -> 51;
                  case 18 -> 24;
                  case 19 -> 25;
                  case 20 -> 55;
                  case 21 -> 8;
                  case 22 -> 63;
                  case 23 -> 40;
                  case 24 -> 4;
                  case 25 -> 49;
                  case 26 -> 1;
                  case 27 -> 46;
                  case 28 -> 58;
                  case 29 -> 43;
                  case 30 -> 54;
                  case 31 -> 36;
                  case 32 -> 32;
                  case 33 -> 15;
                  case 34 -> 50;
                  case 35 -> 38;
                  case 36 -> 34;
                  case 37 -> 53;
                  case 38 -> 62;
                  case 39 -> 37;
                  case 40 -> 23;
                  case 41 -> 35;
                  case 42 -> 44;
                  case 43 -> 31;
                  case 44 -> 41;
                  case 45 -> 39;
                  case 46 -> 45;
                  case 47 -> 16;
                  case 48 -> 0;
                  case 49 -> 3;
                  case 50 -> 6;
                  case 51 -> 22;
                  case 52 -> 26;
                  case 53 -> 28;
                  case 54 -> 47;
                  case 55 -> 17;
                  case 56 -> 29;
                  case 57 -> 33;
                  case 58 -> 11;
                  case 59 -> 57;
                  case 60 -> 59;
                  case 61 -> 52;
                  case 62 -> 12;
                  default -> 14;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\u0017#8\u0013J~\u0018cu\u0018@c\u001d>~^H~\u00108z\u0015\u000bx\u0019=z^Wt\u001a)s\u0002\u000bS\u00119b\u0015WR\u0015 s\u0002D";
         b[1] = "\u0016I9\u0016`,\u001dF(Y\u001d4\u000eA!\u0010";
         b[2] = "}.S&cYrn\u001e-iDw3\u0015kaYz5\u0011 \"_s0\u0011k~Sp$\u00187\"叽栏压桬厎栝栧佋压厶a栝佣栏压伨桔叇叽栏桑";
         b[3] = int.class;
         c[3] = "java/lang/Integer";
         b[4] = "p7h,,u{8ycPlt\"w g\\b5{=vpu8";
         b[5] = "Hd\u0007i!zCk\u0016&@tH`\u0012|";
         b[6] = "}DMVV8\"VZn]ZzEJ\u001eN33AIP0";
         b[7] = "Qt\r\u001d6\"\u0014|G\u0019X伅桱叅栬口厛伅厫叅佨 b6\u0001~[Yf'\u0014z";
         b[8] = "\u0012\u001djO\u0018*W\u0015 Kv厓叨桶桋伯桯桉栲桶伏rL>B\u0017<\u000bH/W\u0013";
         b[9] = "W0}B2\u001e\u001287F\\伹厭厁优桦原厧伳厁桜\u007ff\n\u0007:+\u0006b\u001b\u0012>";
         b[10] = "u2$F\r\r0:nBc\u001eL{#\u0006\u0000O)?,K]ww\u007fa\u0018[\u00123p,Ec";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String HE_DA_WEI() {
         return "何大伟230622198107200054";
      }
   }
}
