package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.client.树友何何何树何树友友;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import why.tree.friend.antileak.Fucker;

public class 友何何友树何何友友树 extends Module implements 何树友 {
   private final ModeValue 树何树树树树树何友树;
   private final BooleanValue 何何何树何何树何友树;
   private final NumberValue 树树何树何何何友友树;
   private final NumberValue 树树树友友友树何何友;
   private final NumberValue 何何何树树友树树友树;
   private final NumberValue 树何何树何树树友友友;
   private final NumberValue 友树何友友树何何树何;
   private final BooleanValue 何树友树友树树何何友;
   private final NumberValue 树何友何友树友何友树;
   private final BooleanValue 何友树何树树树何友树;
   private final BooleanValue 何何何友树树树何树何;
   private final BooleanValue 树友友树友树树友树友;
   private final BooleanValue 友树何何友树树树树何;
   private final Color 友何何树友树友树何何;
   private final Color 何友友友何树友树树树;
   private static final int 何友何友友何友何友友;
   private static final double 树何友树树树友树何何 = 0.7;
   private static final double 友友何树树友友何友友 = 0.8;
   private static final double 何何何何树树友友树何 = 3.0;
   private static final int 树树友友树何树何友友;
   private static final double 树何何树树何友友友友 = 3.0;
   private static final int 何树树友树何树树树树;
   private final Set<BlockPos> 友何何树何何何何友树;
   private final Set<BlockPos> 友何树友友树何友友友;
   private AtomicBoolean 树友树友友树树友友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[46];
   private static final String[] n = new String[46];
   private static int _何树友为什么濒天了 _;

   public 友何何友树何何友友树() {
      long a = 88136607349158L;
      super(b<"f">(3365, 1721594994918668118L), b<"f">(27013, 5710732579835073464L), d<"v">(4156002620795226029L, a));
      this.树何树树树树树何友树 = new ModeValue(
         b<"f">(2036, 4449305165857340810L),
         b<"f">(28008, 7693741520655046458L),
         new String[]{b<"f">(15836, 7481219122987894771L), b<"f">(32303, 1789656162767127661L), b<"f">(5427, 3519207018756419406L)},
         b<"f">(6173, 5455265373126402667L)
      );
      this.何何何树何何树何友树 = new BooleanValue(b<"f">(13123, 1690703423342840099L), b<"f">(6413, 1185231587749602159L), true);
      this.树树何树何何何友友树 = new NumberValue(b<"f">(10208, 6250557998560943499L), b<"f">(19711, 3610902225433261696L), 2.0, 1.0, 5.0, 0.5);
      this.树树树友友友树何何友 = new NumberValue(b<"f">(23643, 4990194185881052685L), b<"f">(142, 742905806735391465L), 200, 20, 255, 5);
      this.何何何树树友树树友树 = new NumberValue(b<"f">(26899, 1419257998579061548L), b<"f">(28548, 1433553450356331945L), 64, 32, 128, 8);
      this.树何何树何树树友友友 = new NumberValue(b<"f">(28243, 3716651017417512037L), b<"f">(1792, 6970283390563106124L), 32, 16, 64, 8);
      this.友树何友友树何何树何 = new NumberValue(b<"f">(19213, 7181704183838339367L), b<"f">(10117, 8629330822434430440L), 24, 10, 100, 2);
      this.何树友树友树树何何友 = new BooleanValue(b<"f">(30430, 3589228478620388503L), b<"f">(32083, 4000660853934049087L), false);
      this.树何友何友树友何友树 = new NumberValue(b<"f">(14283, 4726127585359826421L), b<"f">(1465, 3780991718339002253L), 15, 5, 50, 1).A(() -> {
         long ax = 95408821175413L;
         String var3 = d<"Ð">(323443899492253092L, ax);
         boolean var10000 = d<"f">(this, 319902622527758650L, ax).K(b<"f">(32303, 1789656162767127661L));
         if (var3 != null) {
            if (!var10000) {
               var10000 = d<"f">(this, 319902622527758650L, ax).K(b<"f">(5427, 3519207018756419406L));
               if (var3 == null) {
                  return var10000;
               }

               if (!var10000) {
                  return false;
               }
            }

            var10000 = true;
         }

         return var10000;
      });
      this.何友树何树树树何友树 = new BooleanValue(b<"f">(18394, 8159302169551633834L), b<"f">(3959, 7717096351536854312L), true).A(() -> {
         long ax = 57855247643361L;
         String var3 = d<"Ð">(-943089764165334224L, ax);
         boolean var10000 = d<"f">(this, -944375047283976274L, ax).K(b<"f">(32303, 1789656162767127661L));
         if (var3 != null) {
            if (!var10000) {
               var10000 = d<"f">(this, -944375047283976274L, ax).K(b<"f">(5427, 3519207018756419406L));
               if (var3 == null) {
                  return var10000;
               }

               if (!var10000) {
                  return false;
               }
            }

            var10000 = true;
         }

         return var10000;
      });
      this.何何何友树树树何树何 = new BooleanValue(b<"f">(12836, 620703758896695326L), b<"f">(19315, 491856530462961952L), true).A(() -> {
         long ax = 100614757817637L;
         String var3 = d<"Ð">(2102362746195780852L, ax);
         boolean var10000 = d<"f">(this, 2098828032209369194L, ax).K(b<"f">(27264, 4703452665351459066L));
         if (var3 != null) {
            if (!var10000) {
               var10000 = d<"f">(this, 2098828032209369194L, ax).K(b<"f">(8827, 6391207172691073076L));
               if (var3 == null) {
                  return var10000;
               }

               if (!var10000) {
                  return false;
               }
            }

            var10000 = true;
         }

         return var10000;
      });
      this.树友友树友树树友树友 = new BooleanValue(b<"f">(6309, 6133667855862047460L), b<"f">(6880, 6064459805202096331L), true).A(() -> {
         long ax = 115681389729709L;
         String var3 = d<"Ð">(6315495230367985276L, ax);
         boolean var10000 = d<"f">(this, 6316503320328073954L, ax).K(b<"f">(32303, 1789656162767127661L));
         if (var3 != null) {
            if (!var10000) {
               var10000 = d<"f">(this, 6316503320328073954L, ax).K(b<"f">(5427, 3519207018756419406L));
               if (var3 == null) {
                  return var10000;
               }

               if (!var10000) {
                  return false;
               }
            }

            var10000 = true;
         }

         return var10000;
      });
      this.友树何何友树树树树何 = new BooleanValue(b<"f">(2671, 2819551036148232204L), b<"f">(4924, 4047337467597203830L), false);
      this.友何何树友树友树何何 = new Color(31, 1, 221, 216);
      this.何友友友何树友树树树 = new Color(255, 165, 0, 216);
      this.友何何树何何何何友树 = ConcurrentHashMap.newKeySet();
      this.友何树友友树何友友友 = ConcurrentHashMap.newKeySet();
      d<"ï">(this, new AtomicBoolean(false), 4153280245600040810L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8654244591863790813L, -7879091809939337238L, MethodHandles.lookup().lookupClass()).a(138310035294837L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = 109020190366439L;
      Cipher var13;
      Cipher var24 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[93];
      int var18 = 0;
      String var17 = "«¤»\u0083v.Q^\u0005£\u008d\u001eT\u0096¢XSe·ÝF£C¬\u0010í6U#\u0005ù\u009b\u0098éõe\u0012;gË  \u0019\u0089-¨¯nã¥\u0092s¿÷ç\u00adÖ%sTé\u0093d\u0098ïbÇ\u00ad)ú\u0080¦ùp X_]lçU\u0091Øs\u0005ª\u0015\u000f\u0017kú½(ýátà¬K\u0091øº%2¸³[ \u009b_\u000eR\u009aäñ_\u00adÿ\u0018\nó\u008c\u007f^å6\u0013a %\u001a'ä¾\u0095Ý\u0096N\u0011J\u0010\u0018\u0089z¨&\u0001ÙÔ\u0092Ï\u000bE\fi\u001dq\u0010\u009b Îy³\u009d\u0084áï¬Õì\u0097èÏÃ wÖjK©W¥â&\u0000\u0099\u0084 ó×¤ù\u0018p\u0098vehôeõ\u0085ò\u000e¢¬Ñ\u0018\u0001Ý©R\u008e2Ò=¹ÖXS\u0012!\u0082¦:\u008eü÷Ä\u0096x\u0081\u0010¬\u001eòü\u0011«ó!K\u0006¹T\u0007Rå\u0017\u0010[\u009do\u0011å·|:b£-\u0006g+\u009aÒ Q[\u0004G;\u0011ë(\u008d\u0002\u0095\u0091ê\u001a%¢\u001fBÇª\u0090p\t#Íbj¸\t\u0000\u000e*@äe\u0096ÉtÜC×\u0099îAýö\u009fM\u008eØû\u0013\u0097\u0080¦÷ÿD\u0012[Â\u0004\u0094iÈy{ÒÚ]ë\u0019Ú\u0082\u0090aM¾\u0095Ó ²%õ\u001d0\u0085\u009aåÎ51.\u0001@\u0010V\u0010\u0001õõöÂ(\u0012GT\u0089xQQ\u0012Üû\u0010K\u008b\u0084\u001e.7Ó¯ ;\u0019ê³\u0010H:\u0010Ýùª\u0092\n#\u0084-¨Â<\u009aøØeK\u00102\u0084Ñ¬lÛÑY\u0093\u0095Î5\u0005\u001a\u0017ù(\u0004+RÆ('\u0001M~ó\u0017%h\u008fÿòo\u009e\u007f¬\u0018rd\u009a%÷ú0¥«@ØY\u001e¨\u009c\u0091\u0084^Y`\u0086Ù\u0087µ\f\u009f\u0002åÞ\u0015B\tá\u0015\u0094ÎX\u001fì¥\u008dÈ£8¾±W\u0092\u000eH¤¼\u009fóyJ©Ö/zHñîq\u0091\u0012\u0011?/Ô§Qé+\u0081\u0094ö,Cz\u008d\u001f(aÂE\u001c:;\u008b³Ë}S0\u0094á\u000bJ?\u0010(\u008ayðk\u0012\u00034Ur½K\u008a\u0015\u001b 0\u001c\u0088j{ãü\u0094\u0015\rYÆ\u008ct¬Æ\u0003\t|î\u0090Cý´`cl3'Þ<¯ \u0006F@>Á\u0099\u009f\u0015\u0012¥\u0095\u0002ÖMÉG\u0000 +»¿ö\u0014\u0005\u0086É/,ì_D\u00ad(\u0093\u0019\u0004\u000bâ%8\u0095\u0010½ji²\u001dx¾\u008eg©\u0085¦J :TAô©\u0093}eÄ@ú\n?\u001b\u00058\u0015\u00105)¬%\nD¨ðÓZ¹Qÿ\u001a\u0013÷8é¦Ka\u000e\u0098_´Æ'\u008cÇkÔ\u009eº¾[Jê\u0090í\rþ\u001a\u0003ãSêaL\u009f\u001dUv\u0085ñå\u0085Òó\u0005\u00941\t\u0094ñßW\u0004\u0083ê\u0098\u0016\u0006â\u0010åÇ|_64P\u001cá\u001aõ\\\u009ePÈ\u0099\u0010Ýfè\u001aõoþ\u001bÃ\u0098|_\u008f'/Ù\u0010?¡\\%½ùù¿ôö¶\u0096\u009f\u009e©]\u0018/Õ\u0090÷X3í\u00840U\u001c\u000eY¨ï\u0090ß\u000f5Ý\u00162SH\u0010Çë\u0011x²@¨\u0098Bà\u0019\u0002ÈÖ÷¸\u0010i\u0015öa'gâu\u0000\u0094_äÓ¿©\u0093 ª1\u0015uS\u009cý&þ¤ë\u001d-uµQ\u001e\u009f \u000f\u0018QF\u0095\u00170Ê5L\rHÂ NïëÚ)Ý\u0089Ñ\u0081Gç¹Ô4\u0092u7\u000fÿ\u0000\u0019RãÊò\u00ad¢\u0017OV|\u0006 \b§\u009dK\u0080\u001b1Òk½*\u0088\u001dÖÔ¨/ñI\u0090ç*Ãg\u001byL\u0007\u000fèñq\u0010Õ\u008d\u0015\t 8\u00ad\f^\u0014.ØJy0d B'¢/±\u0000.e\u0093\b\u000f%PKé\u0084zúUÙG#ñ\u001eU\u0003À\u0083\u008e(ÿ\u009f\u0018Bê²*¨@[BÜ¥\u0099IêÑ¤\u001a7\u0099\fcJcy\u0083`\u000e\u0091lÎ\u0082\u000fÆÆ\u0002©2\u0012\u0005{\u0089Ø:\u001f`÷IøpOydp#%éº-M\u0081\u009dØ2%Ë/êBSE·Ù§|\u0095C\u009aÿÛ\u0097Á]dQÑ\u009fÉb\u001dn\u00adË\u000f6¡Õ÷\u0015.\u0013\u0097´@Å\u009dK@\u0091û£cT\u0089Ø»\u0095¦çª\u007fä78#è\u008f\r\u009cK½z\u0087\u0083QT\u0088D-\u0000é#\u0004Á¬\u009cÛ¯1\u008eXlV5\u0086tF\u0015]\u0086L\u0003_U\u008fñ§\u009cìôé\u0092;fÕ|ï\nÁ7\u0010>Ëû\u009ce{\u008cª\u0000WÓ\u008c\u009eÎnÃ /\u0016¿\u009f+êdÙFÕ\u0086\u000fÑ\u0086ì\u0081î\u0080Ó\u0097/Uû#\u00ad\u00ad\u009eÆZvÃª\u0010©B¹ª§ã\u0089lÎÏü\u0016Z\u008boÇ\u0010Ð¡ï\u0093\u001bb.ÁódJCS\u009bÑ#\u0010\u0087Ö¥_4-õS¤|Ý\u0098ÖÎ\u0005\u009c\u0018)»\u0088&a8,½?ºpz\u008dýÆà¾)\f,\\\u0018·Ç ý\u0012&¦Â\u0015Õ\u001dþÈ\u0010\u009en\u0005uGý18\\\u0089s|S»ÿS\u0010çï\u0005\t\u0010ÅY½¿tT\u008d[m>[¬X¯?µ IÑ\u0095&\u0097\u0091\u0002H¾\u0088¡\u0016(Òk\u001b$A2\u0095xs©È-¯ÂÚ©\u0082ùvX%Ô?Ü¨\u0016{\u0088Ê\u008a\u00941>¿ëWk¨_£ò¾\u0080\u000bIy¨\bÐu\u000b\u0004ÑíÜP\u009a%\u0007nü\u0006»ÿ7ó\u008bÈÇk¦È,¸\bGr43'\u0096\u0018\u0005.\u001bØCG&e\u008e\u0005öLIÀuP~kÿ(Mõ\u009eZAû\u0010ã\u0010\u0098¬\u009dà\nø@þ,þe\u0088·d(Ü¯\u009c\u0018D±éVë\u007fÆ\fCr\u0095\u008fmþW\tHhg4\u009e\u0088´¦$åbÄ\u0014\u0007Õy\u0001ê\u001b\u0094 W&á\u0098åÝÎ\u0092´Úë\u0083_²õt+Þ7~\u009as\u0001D'\u009aeõ'\u00ad\u0087Ó0\u0096¦Î\u008bûôÇ«0\u001dNmñïíK\u009cM6\u0000ßÂ'pó÷ØFw\u001cXpÖ)\u0093ê?¡N)\u0013Í}ÈÆ\u0099,1\u0018øg\u0095Wç\u009e\u0015\u001c\u0081\u009a\u0094¼\u0097©\u008756Ê¿/KÛóñ\u0010Ö1²/-¡¿D\u001d+_è\u0094ºð|H\u0099\u0082:W:Ñ÷}Ø\u0017\u0017Þ'¾\u0091¨43HW\u001e\u000f\u0098\u009ay\u0098CÏ 6\u0085\u001eoùæÝm´\u0085´xè°\u009f\t/\u0000\u0011\u009c kÚ·,\u0095å\u001a\u0018¹£r_XzG6\u0092<½AÑ\u0014\u0010×$\u009f\u0094Ü\u009abV\u0017w:aïc=ó\u0010P\u008fm!â&\u008d¾8;µ´GÔbÅ \u0019\u0007\u0083ô\u0012Þ~\u009c #Ï\u0092tF&\u001e\u0099\u0085»\u0096D\u001eì\u008e5\u0014\u0099SKÜXo Ð\u001aJ\u0000~\u0003\u0015}d\u001c\u0095T\u008a±ÆËù+¤ÏA¢2\u00ads\u0000\t·A#¶¡\u0018â'ÇMÀ\u008dÎn^Ø#q\u009f\u0098`ð\u001f:NIÈbú· \n\u001b|6N\u009c¢«}uä97w\u0001þk~\u0086O\u0097×Ý>-ã°¼\u008eo\u0086\u0093 ]è\u0093Ç\u0012g\u001bÝ\u001f³auU¹çûÂ\u008b\u00178ì\u0001þ\u0007[\u0016kqÓ2R\u0091\u0010\u009c\u0096CÆw\u00ad\u0097æ\u008d:\u0001çr|\u0002\u0018 \u009e*\u0094Ã×:\u0099\u0003GÎâÐ¶~Ú\u008e¿Ü\u0014í\u001e\u0091C¢îý\u008b¡\u0093ìÙé\u0018Õ¼òé\u0011÷¥Vt¾sa\u0011¨s/d\u0090Çi^@¬Q(¶\u001a\u0091Éwå¡ÄïqÚ\u0016µyeS¸Ú²o 9G;kcE\u001cÊ\u008fg$ª¢±d\u001b2\u0014'(×\u0085¢\"H\u008e.\u0098\u0011Á\u0090\u008cTÑÝÜ$\u0092\u008aÏ\u00051ê°2l\u0007\u0014U\fq\r÷\u009d³a¯X\f\u0090\u00106X²!_\u0094Èpý\u000e\n/Ü\u0083\\ª\u0010g@ÖÕ¸nfX.Mö¯ñÑü\u009f ~O5öåVí\u0007\u0098\u0089-\u001dbÇ\u009e\u0093Ö'(oB\u008d¼6\u000e¦\u008a\u009f=\u0095l\u0019 o{ëzý@líUîãÝ\u001a %÷¯\u008dû¹¯\u0096\t1g\u0094\u000b\u0087%y5f \u001a³>\u0085\u0002¨{8U¡ÈÓöé½X/Ã\u0000ûD\u0015\u001e¸öòü\u0097>êøö\u0010 Sè]~\u001eæ\u0095\u000e\u009b\u0088m?6ó\u008d \u009c3n\u0001\u0096\u0087\u0011\u0096\u000b\tF´'\u008e\u0089º¤\u000fç\u009b\u009d)\u008c\u0005þ·0\u0018ÖÚÙr v~?\u0011»f5\u001aG_î\u0007¹\u009fL(´ã#VZ\u0090;1\u00adê\u0095<×?\u0085eP\u0005\\UX \u0098\u0081àª\u001d\u0088¯ß0ðS\u0019b\u0002\u0018Z\u0098Z\u008f)\u001d8\r\n\")JÕèÄ\u0003Ï¦ônß\u00141\u001e9\"Àù»L\u0082\u008e\u000bô b\u0018õ+¸28+|ãë\u001eþª_±¦ü$¾Á\u0001Ø\u009aK(9«¦æpK\u0002a\u0000Ëè ¨\u009f\u0019\u0013#¿\u008f\u0082r°\u008cr!Üó\bû¶W*ïW\u008c¤è<¥0\u0010\be«\u0016«}@3\u0014Oÿô\u0097.=\u0083 \u00ad\u0015¶\u008fm\u009e¹ý\u0095é\u0005zÞ\u001eZMÈ¬Ò¹Ñ\"ñ\u0015\u007f\u0099Ëßñ\u009b\u0080w\u0018Æ.Ô\u0086\u0004a¯tL\u0090\u0083Ë£nn,²!ÂöÛD\u001eÐP\u007fJ¡\u00adr\u009a\u0094bßØÃ¿éÛôì4Hof\u008aì~\"\u0095¾¤\u0081½×\u009dd/HK û!\u0016\u000b8\u0010\u0096ÒrT<\u0093H;\faå4\u009eu¬-v\u001a#\u0002·y\u0005\u0011Öúåð!\u0011gy©&\u0019´F\r UáüV\u0086 ºm¬Iö\u001bìÛP<{æL×£Ø1@..r\u0012k}\u0088x \u009dKÌ\u0016¬ß\u00854\u008a°\u009b}\u001f\u0091Õø)]3Wk:\u0087¡A:R\u0083b\u009f÷ë Åc\u001fLY\u001a/ÒÚ\u0085)7\u008fþÎ\u0019éCI\u001d+¤\u001fÅh=\u001b\u0082Í\u0089ñ¢\u0010kÚ+\u000f\u0097\u0012º®\u0016\\û^\u0015¨Ì\u0014\u0018§&`U=\u0010ô¶ºA\u0002r0\u0094©Ö0/\u0096ÑN\u0002I\n\u0010¯A\u0003gþ1\u0082\u0001u:ôG\u0086RxQ\u0010÷¶\u009dnå¾\u008b\u0094\u0080\u009d\u0098HX\u001a\u0005B\u0010ß\u0096\u0086\u0095?\\\u0014z~\u0085?\u0083.\u0085\u0087]\u0010!\u0011\u0097ÑÅ$Ò3ñV¼ \u0011QAÜ\u00107ÿ_)¬\u001f%åÍ\u007fÆ\u0000v\u001c\u0080ù";
      short var19 = 2810;
      char var16 = 24;
      int var23 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            String var36 = c(var13.doFinal(var25.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var23 += var16) >= var19) {
                     c = var20;
                     h = new String[93];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var27 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var27.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[7];
                     int var3 = 0;
                     String var4 = "F<Ï\u0091h<n,Ù6\u0016(ÅÉ_\bKÃâ\u0084}i¶Ýù\tøC\u001fbÙ;\rÁ\u0097ÿEd\u0015ë";
                     byte var5 = 40;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var43 = -1;

                        while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    j = var6;
                                    k = new Integer[7];
                                    树树友友树何树何友友 = c<"b">(24825, 7574421479245249045L);
                                    何树树友树何树树树树 = c<"b">(6849, 2667837101242810414L);
                                    何友何友友何友何友友 = c<"b">(21342, 9087796831062706615L);
                                    return;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "Ü]ÖØ\u000fH\u0087\u008cã)I¥!Y\u0093\u009c";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label54;
                  }

                  var17 = "lÆ\u0080ýòä°ÌÔÏÀÞz,¬R\u0010\u008a\u009f¹óÔ\u008d\u0015t16Ë\u008fp¥Ê\u009c";
                  var19 = 33;
                  var16 = 16;
                  var23 = -1;
            }

            var25 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void B(WorldEvent event) {
      this.V();
   }

   private void B() {
      long a = 8748034303016L;
      String var3 = d<"Ð">(2603163810778815993L, a);
      AtomicBoolean var10000 = d<"f">(this, 2606807641073461988L, a);
      if (var3 != null) {
         if (var10000 == null) {
            return;
         }

         var10000 = d<"f">(this, 2606807641073461988L, a);
      }

      var10000.set(false);
      d<"ï">(this, null, 2606807641073461988L, a);
   }

   private boolean C(String blockId) {
      long a = 1795248238093L;
      String var4 = d<"Ð">(3316142345158105052L, a);
      boolean var10000 = blockId.contains(b<"f">(24192, 3439809797487125729L));
      if (var4 != null) {
         if (!var10000) {
            var10000 = blockId.contains(b<"f">(15254, 890232881103012296L));
            if (var4 == null) {
               return var10000;
            }

            if (!var10000) {
               var10000 = blockId.contains(b<"f">(14519, 3308114425277317787L));
               if (var4 == null) {
                  return var10000;
               }

               if (!var10000) {
                  var10000 = blockId.contains(b<"f">(8349, 5862592192755931827L));
                  if (var4 == null) {
                     return var10000;
                  }

                  if (!var10000) {
                     var10000 = blockId.contains(b<"f">(22809, 8656034384385663863L));
                     if (var4 == null) {
                        return var10000;
                     }

                     if (!var10000) {
                        var10000 = blockId.contains(b<"f">(15316, 2125784571013857766L));
                        if (var4 == null) {
                           return var10000;
                        }

                        if (!var10000) {
                           var10000 = blockId.contains(b<"f">(14032, 379449038927137959L));
                           if (var4 == null) {
                              return var10000;
                           }

                           if (!var10000) {
                              var10000 = blockId.contains(b<"f">(8617, 7624239811444153336L));
                              if (var4 == null) {
                                 return var10000;
                              }

                              if (!var10000) {
                                 return false;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         var10000 = true;
      }

      return var10000;
   }

   private boolean I(String blockId) {
      long a = 53562091684889L;
      String var4 = d<"Ð">(-4318533181539648056L, a);
      boolean var10000 = blockId.contains(b<"f">(30590, 8033570580314443102L));
      if (var4 != null) {
         if (!var10000) {
            var10000 = blockId.contains(b<"f">(2043, 4711678286627913119L));
            if (var4 == null) {
               return var10000;
            }

            if (!var10000) {
               return false;
            }
         }

         var10000 = true;
      }

      return var10000;
   }

   private boolean Z(BlockPos pos) {
      long a = 70658576942004L;
      long ax = 85526755286720L;
      long axx = 65332937941542L;
      String axxx = d<"Ð">(269103298408397413L, a);
      if (mc.level == null) {
         return false;
      } else {
         Block block = 友树友友树何树友树友.g(ax, pos);
         Block var10000 = block;
         if (axxx != null) {
            if (block == null) {
               return false;
            }

            var10000 = block;
         }

         boolean var10 = var10000 instanceof AirBlock;
         if (axxx != null) {
            label52:
            if (!var10) {
               boolean var11 = block instanceof LiquidBlock;
               if (axxx != null) {
                  if (var11) {
                     boolean var12 = d<"f">(this, 269267907127863868L, a).getValue();
                     if (axxx == null) {
                        return var12;
                     }

                     if (!var12) {
                        break label52;
                     }
                  }

                  var11 = block instanceof VineBlock;
               }

               if (axxx == null) {
                  return var11;
               }

               if (!var11) {
                  boolean var13 = 树何树树何何树友何何.F(pos, axx);
                  if (axxx == null) {
                     return var13;
                  }

                  if (!var13) {
                     return false;
                  }
               }
            }

            var10 = true;
         }

         return var10;
      }
   }

   private void Z(BlockPos param1, Set<BlockPos> param2, Set<BlockPos> param3, int param4) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:166)
      //
      // Bytecode:
      // 000: ldc2_w 117806629641346
      // 003: lstore 5
      // 005: ldc2_w 125527250587045
      // 008: lstore 7
      // 00a: ldc2_w -2555186538184284845
      // 00d: lload 5
      // 00f: invokedynamic Ð (JJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友树何何友友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 014: new java/util/ArrayDeque
      // 017: dup
      // 018: invokespecial java/util/ArrayDeque.<init> ()V
      // 01b: astore 10
      // 01d: astore 9
      // 01f: aload 10
      // 021: aload 1
      // 022: invokeinterface java/util/Deque.add (Ljava/lang/Object;)Z 2
      // 027: pop
      // 028: aload 10
      // 02a: invokeinterface java/util/Deque.isEmpty ()Z 1
      // 02f: ifne 166
      // 032: aload 2
      // 033: aload 9
      // 035: ifnull 04f
      // 038: goto 03b
      // 03b: invokeinterface java/util/Set.size ()I 1
      // 040: iload 4
      // 042: goto 045
      // 045: if_icmpge 166
      // 048: aload 10
      // 04a: invokeinterface java/util/Deque.poll ()Ljava/lang/Object; 1
      // 04f: checkcast net/minecraft/core/BlockPos
      // 052: astore 11
      // 054: aload 3
      // 055: aload 11
      // 057: invokeinterface java/util/Set.contains (Ljava/lang/Object;)Z 2
      // 05c: aload 9
      // 05e: ifnull 079
      // 061: ifeq 06a
      // 064: goto 067
      // 067: goto 028
      // 06a: aload 3
      // 06b: aload 11
      // 06d: invokeinterface java/util/Set.add (Ljava/lang/Object;)Z 2
      // 072: pop
      // 073: aload 0
      // 074: aload 11
      // 076: invokevirtual cn/cool/cherish/module/impl/render/友何何友树何何友友树.Z (Lnet/minecraft/core/BlockPos;)Z
      // 079: aload 9
      // 07b: ifnull 091
      // 07e: ifne 089
      // 081: goto 084
      // 084: aload 9
      // 086: ifnonnull 028
      // 089: aload 2
      // 08a: aload 11
      // 08c: invokeinterface java/util/Set.add (Ljava/lang/Object;)Z 2
      // 091: pop
      // 092: invokestatic net/minecraft/core/Direction.values ()[Lnet/minecraft/core/Direction;
      // 095: astore 12
      // 097: aload 12
      // 099: arraylength
      // 09a: istore 13
      // 09c: bipush 0
      // 09d: istore 14
      // 09f: iload 14
      // 0a1: iload 13
      // 0a3: if_icmpge 125
      // 0a6: aload 12
      // 0a8: iload 14
      // 0aa: aaload
      // 0ab: astore 15
      // 0ad: aload 11
      // 0af: aload 15
      // 0b1: invokevirtual net/minecraft/core/BlockPos.relative (Lnet/minecraft/core/Direction;)Lnet/minecraft/core/BlockPos;
      // 0b4: astore 16
      // 0b6: aload 9
      // 0b8: ifnull 120
      // 0bb: aload 16
      // 0bd: invokevirtual net/minecraft/core/BlockPos.getX ()I
      // 0c0: aload 1
      // 0c1: invokevirtual net/minecraft/core/BlockPos.getX ()I
      // 0c4: isub
      // 0c5: invokestatic java/lang/Math.abs (I)I
      // 0c8: bipush 50
      // 0ca: aload 9
      // 0cc: ifnull 045
      // 0cf: goto 0d2
      // 0d2: if_icmpgt 11d
      // 0d5: aload 16
      // 0d7: invokevirtual net/minecraft/core/BlockPos.getZ ()I
      // 0da: aload 1
      // 0db: invokevirtual net/minecraft/core/BlockPos.getZ ()I
      // 0de: isub
      // 0df: invokestatic java/lang/Math.abs (I)I
      // 0e2: aload 9
      // 0e4: ifnull 105
      // 0e7: goto 0ea
      // 0ea: bipush 50
      // 0ec: if_icmple 0fa
      // 0ef: goto 0f2
      // 0f2: aload 9
      // 0f4: ifnonnull 11d
      // 0f7: goto 0fa
      // 0fa: aload 3
      // 0fb: aload 16
      // 0fd: invokeinterface java/util/Set.contains (Ljava/lang/Object;)Z 2
      // 102: goto 105
      // 105: aload 9
      // 107: ifnull 11c
      // 10a: ifne 11d
      // 10d: goto 110
      // 110: aload 10
      // 112: aload 16
      // 114: invokeinterface java/util/Deque.add (Ljava/lang/Object;)Z 2
      // 119: goto 11c
      // 11c: pop
      // 11d: iinc 14 1
      // 120: aload 9
      // 122: ifnonnull 09f
      // 125: goto 161
      // 128: astore 12
      // 12a: aload 0
      // 12b: ldc2_w -2555568233376960956
      // 12e: lload 5
      // 130: invokedynamic f (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/render/友何何友树何何友友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 135: invokevirtual cn/cool/cherish/value/impl/BooleanValue.getValue ()Ljava/lang/Object;
      // 138: checkcast java/lang/Boolean
      // 13b: invokevirtual java/lang/Boolean.booleanValue ()Z
      // 13e: ifeq 161
      // 141: aload 12
      // 143: invokevirtual java/lang/Exception.getMessage ()Ljava/lang/String;
      // 146: sipush 19410
      // 149: ldc2_w 7156747244445626757
      // 14c: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友树何何友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 151: swap
      // 152: invokedynamic makeConcatWithConstants (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; bsm=java/lang/invoke/StringConcatFactory.makeConcatWithConstants (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/invoke/CallSite; args=[ "\u0001\u0001" ]
      // 157: lload 7
      // 159: dup2_x1
      // 15a: pop2
      // 15b: invokestatic cn/cool/cherish/utils/client/ClientUtils.P (JLjava/lang/String;)V
      // 15e: goto 161
      // 161: aload 9
      // 163: ifnonnull 028
      // 166: return
   }

   private void V() {
      long a = 11467743605620L;
      d<"f">(this, -5516632224762210178L, a).clear();
      d<"f">(this, -5513244104272574090L, a).clear();
   }

   // $VF: Handled exception range with multiple entry points by splitting it
   // $VF: Duplicated exception handlers to handle obfuscated exceptions
   private void e() {
      long a = 1908198773513L;
      long ax = 125527250587045L;
      long axx = 52406761729175L;
      String axxx = d<"Ð">(-7853910542788384040L, a);
      int var10000 = this.Q(new Object[]{axx});
      if (axxx != null) {
         if (var10000 != 0) {
            return;
         }

         var10000 = d<"f">(this, -7853341859730379352L, a).getValue().intValue();
      }

      int range = var10000;
      int vRange = d<"f">(this, -7853932879585316907L, a).getValue().intValue();
      int playerX = (int)mc.player.getX();
      int playerY = (int)mc.player.getY();
      int playerZ = (int)mc.player.getZ();
      int minY = Math.max(playerY - vRange, mc.level.getMinBuildHeight());
      int maxY = Math.min(playerY + vRange, mc.level.getMaxBuildHeight());
      Set<BlockPos> visitedBlocks = new HashSet<>();
      int rangeSquared = range * range;
      int x = playerX - range;

      label141:
      while (true) {
         var10000 = x;
         int var10001 = playerX + range;

         label138:
         while (var10000 <= var10001) {
            var10000 = playerZ - range;
            if (axxx == null) {
               break label141;
            }

            int z = var10000;

            label135:
            while (true) {
               var10000 = z;

               label133:
               while (true) {
                  if (var10000 > playerZ + range) {
                     break label135;
                  }

                  label148: {
                     int dx = x - playerX;
                     int dz = z - playerZ;
                     var10000 = dx * dx + dz * dz;
                     if (axxx != null) {
                        var10001 = rangeSquared;
                        if (axxx == null) {
                           continue label138;
                        }

                        if (var10000 > rangeSquared) {
                           break label148;
                        }

                        var10000 = minY;
                     }

                     int y = var10000;

                     while (y <= maxY) {
                        label120: {
                           label119: {
                              Exception e;
                              label118: {
                                 label117: {
                                    label116: {
                                       try {
                                          pos = new BlockPos(x, y, z);
                                          var10000 = visitedBlocks.contains(pos);
                                          if (axxx == null) {
                                             continue label133;
                                          }

                                          if (axxx == null) {
                                             break label117;
                                          }

                                          if (var10000 == 0) {
                                             break label116;
                                          }
                                       } catch (Exception var31) {
                                          e = var31;
                                          if (axxx == null) {
                                             break label120;
                                          }
                                          break label118;
                                       }

                                       if (axxx != null) {
                                          break label119;
                                       }
                                    }

                                    try {
                                       var10000 = this.Z(pos);
                                    } catch (Exception var30) {
                                       e = var30;
                                       if (axxx == null) {
                                          break label120;
                                       }
                                       break label118;
                                    }
                                 }

                                 try {
                                    if (var10000 != 0) {
                                       Set<BlockPos> potentialCaveBlocks = new HashSet<>();
                                       this.Z(pos, potentialCaveBlocks, visitedBlocks, 300);
                                       int minSize = d<"f">(this, -7854105201579379861L, a).getValue().intValue();
                                       var10000 = potentialCaveBlocks.size();
                                       if (axxx != null) {
                                          if (var10000 < minSize) {
                                             break label119;
                                          }

                                          var10000 = this.E(potentialCaveBlocks);
                                       }

                                       if (axxx != null && var10000 != 0) {
                                          d<"f">(this, -7850345990810142717L, a).addAll(potentialCaveBlocks);
                                       }
                                    }
                                    break label119;
                                 } catch (Exception var29) {
                                    e = var29;
                                    if (axxx == null) {
                                       break label120;
                                    }
                                 }
                              }

                              if (d<"f">(this, -7853250102343343665L, a).getValue()) {
                                 String axxxx = e.getMessage();
                                 ClientUtils.P(ax, b<"f">(11676, 2336486259864180712L) + x + "," + y + "," + z + b<"f">(25177, 3322451194984749181L) + axxxx);
                              }
                           }

                           y += 3;
                        }

                        if (axxx == null) {
                           break;
                        }
                     }
                  }

                  z += 5;
                  if (axxx == null) {
                     break label135;
                  }
                  break;
               }
            }

            x += 5;
            if (axxx != null) {
               continue label141;
            }
            break;
         }

         var10000 = d<"f">(this, -7853250102343343665L, a).getValue();
         break;
      }

      if (axxx != null) {
         if (var10000 == 0) {
            return;
         }

         var10000 = d<"f">(this, -7850345990810142717L, a).size();
      }

      ClientUtils.P(ax, b<"f">(5151, 1064190271187693140L) + var10000 + b<"f">(13340, 1171396604397194789L));
   }

   private boolean e(Set<BlockPos> cave) {
      long a = 101191362111283L;
      long ax = 125527250587045L;
      long axx = 85526755286720L;
      String axxx = d<"Ð">(7438557133065740002L, a);

      try {
         友何何友树何何友友树 var25;
         Set var10001;
         label164: {
            int var24 = cave.size();
            if (axxx != null) {
               if (var24 < d<"f">(this, 7438470329764398929L, a).getValue().intValue()) {
                  return false;
               }

               var25 = this;
               var10001 = cave;
               if (axxx == null) {
                  break label164;
               }

               var24 = this.c(cave);
            }

            if (var24 == 0) {
               return false;
            }

            var25 = this;
            var10001 = cave;
         }

         Set<BlockPos> borderBlocks = var25.U(var10001);
         int naturalBlockCount = 0;
         int totalBlocks = 0;
         boolean hasCaveFeatures = false;
         Iterator volumeToSurfaceRatio = borderBlocks.iterator();

         label151: {
            while (true) {
               if (volumeToSurfaceRatio.hasNext()) {
                  BlockPos pos = (BlockPos)volumeToSurfaceRatio.next();
                  Block block = 友树友友树何树友树友.g(axx, pos);
                  if (axxx == null) {
                     break;
                  }

                  Block var26 = block;
                  if (axxx != null) {
                     if (block == null) {
                        continue;
                     }

                     var26 = block;
                  }

                  String blockId = var26.getDescriptionId().toLowerCase();
                  totalBlocks++;
                  byte var27 = this.Q(blockId);
                  if (axxx != null) {
                     if (var27 != 0) {
                        naturalBlockCount++;
                     }

                     var27 = this.G(blockId);
                  }

                  label142: {
                     if (axxx != null) {
                        if (var27 == 0) {
                           break label142;
                        }

                        var27 = 1;
                     }

                     hasCaveFeatures = (boolean)var27;
                  }

                  if (axxx != null) {
                     continue;
                  }
               }

               var28 = totalBlocks;
               if (axxx == null) {
                  break label151;
               }

               if (totalBlocks > 0) {
                  double var32;
                  var28 = (var32 = (double)naturalBlockCount / totalBlocks - 0.7) == 0.0 ? 0 : (var32 < 0.0 ? -1 : 1);
                  if (axxx == null) {
                     break label151;
                  }

                  if (var28 < 0) {
                     return false;
                  }
               }
               break;
            }

            var28 = cave.size();
         }

         double volumeToSurfaceRatiox = (double)var28 / borderBlocks.size();
         double var33;
         int var29 = (var33 = volumeToSurfaceRatiox - 3.0) == 0.0 ? 0 : (var33 < 0.0 ? -1 : 1);
         if (axxx != null) {
            if (var29 > 0) {
               return false;
            }

            var29 = c<"b">(5039, 947857570204420418L);
         }

         int var21 = var29;
         int maxY = c<"b">(19431, 4712670932817367305L);
         Iterator heightRange = cave.iterator();

         while (true) {
            if (heightRange.hasNext()) {
               BlockPos posx = (BlockPos)heightRange.next();
               var21 = Math.min(var21, posx.getY());
               var30 = Math.max(maxY, posx.getY());
               if (axxx == null) {
                  break;
               }

               maxY = var30;
               if (axxx != null) {
                  continue;
               }
            }

            var30 = maxY - var21 + 1;
            break;
         }

         int heightRangex = var30;
         int var31 = heightRangex;
         if (axxx != null) {
            if (heightRangex < 4) {
               return false;
            }

            var31 = hasCaveFeatures;
         }

         if (axxx != null) {
            if (var31 != 0) {
               return true;
            }

            double var34;
            var31 = (var34 = naturalBlockCount - totalBlocks * 0.8) == 0.0 ? 0 : (var34 < 0.0 ? -1 : 1);
         }

         if (axxx != null) {
            var31 = var31 > 0 ? 1 : 0;
         }

         return (boolean)var31;
      } catch (Exception var19) {
         boolean var10000 = d<"f">(this, 7438252339526735349L, a).getValue();
         if (axxx != null) {
            if (var10000) {
               ClientUtils.P(ax, b<"f">(29937, 71123757320818331L) + var19.getMessage());
            }

            var10000 = false;
         }

         return var10000;
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 25;
               case 1 -> 28;
               case 2 -> 21;
               case 3 -> 32;
               case 4 -> 23;
               case 5 -> 2;
               case 6 -> 55;
               case 7 -> 22;
               case 8 -> 43;
               case 9 -> 42;
               case 10 -> 62;
               case 11 -> 24;
               case 12 -> 16;
               case 13 -> 57;
               case 14 -> 34;
               case 15 -> 15;
               case 16 -> 20;
               case 17 -> 18;
               case 18 -> 0;
               case 19 -> 27;
               case 20 -> 12;
               case 21 -> 31;
               case 22 -> 38;
               case 23 -> 54;
               case 24 -> 10;
               case 25 -> 19;
               case 26 -> 8;
               case 27 -> 41;
               case 28 -> 35;
               case 29 -> 40;
               case 30 -> 63;
               case 31 -> 5;
               case 32 -> 61;
               case 33 -> 36;
               case 34 -> 59;
               case 35 -> 52;
               case 36 -> 33;
               case 37 -> 7;
               case 38 -> 39;
               case 39 -> 51;
               case 40 -> 30;
               case 41 -> 14;
               case 42 -> 58;
               case 43 -> 9;
               case 44 -> 3;
               case 45 -> 44;
               case 46 -> 53;
               case 47 -> 13;
               case 48 -> 50;
               case 49 -> 47;
               case 50 -> 46;
               case 51 -> 6;
               case 52 -> 1;
               case 53 -> 17;
               case 54 -> 37;
               case 55 -> 11;
               case 56 -> 56;
               case 57 -> 26;
               case 58 -> 45;
               case 59 -> 29;
               case 60 -> 60;
               case 61 -> 4;
               case 62 -> 48;
               default -> 49;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               if (var10 < 0) {
                  var10 += 128;
               }

               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var15 = var7[var13 % var7.length];
               if (var15 == 0) {
                  break;
               }

               var12[var13] = (char)(var12[var13] ^ var15);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 14968;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            var4 = (Object[])i.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               i.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友树何何友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[vÈd¹OK_<\u0095þ\u009d\u0099úF\u0014\u0017, ¯¡xÆ²f\u0015\u0000, ¯pÊÇ({oJÝ>a\u009aà\u0089¬P, y*éF«~®´¶÷\u0095W\u000f¤\u001d\u0014, \u0001]\u008abÍª\u0099Í7Æ\u000epk³ÁÇ, ?Ë±t~\u0000Å\u0099, ±\u009a.BàòïË, \u008cÑ\u001fF\u0010¶\u008a=\u009eáÿ¦Ý>bµ, \u0014ÄDèD¦\u009d\u00985\f\u0092\u0012w#é\u000e, ì)\u0083\u0099XWX~, \u000f¯\u0081´\u009cÅ3ö, ^ðwP\u0090\u001fq\u0098Á]o\u0015ÚÍæ½, Çáº\u009f2¦")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友树何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void b(PoseStack poseStack, BufferBuilder builder, BlockPos pos, float r, float g, float b, float a, Vec3 camPos, Set<BlockPos> blocks) {
      long ax = 63086973887139L;
      float x = (float)(pos.getX() - d<"f">(camPos, 2498231364539219079L, ax));
      String var10000 = d<"Ð">(2498219223341243250L, ax);
      float y = (float)(pos.getY() - d<"f">(camPos, 2496202300335815107L, ax));
      float z = (float)(pos.getZ() - d<"f">(camPos, 2497884647595182858L, ax));
      Matrix4f matrix = poseStack.last().pose();
      boolean[] shouldRenderFace = new boolean[6];
      shouldRenderFace[0] = this.Q(pos.below(), blocks);
      String axx = var10000;
      shouldRenderFace[1] = this.Q(pos.above(), blocks);
      shouldRenderFace[2] = this.Q(pos.north(), blocks);
      shouldRenderFace[3] = this.Q(pos.south(), blocks);
      shouldRenderFace[4] = this.Q(pos.west(), blocks);
      shouldRenderFace[5] = this.Q(pos.east(), blocks);
      boolean var18 = shouldRenderFace[0];
      if (axx != null) {
         if (var18) {
            this.X(builder, matrix, x, y, z, x + 1.0F, y, z, r, g, b, a);
            this.X(builder, matrix, x, y, z, x, y, z + 1.0F, r, g, b, a);
            this.X(builder, matrix, x + 1.0F, y, z, x + 1.0F, y, z + 1.0F, r, g, b, a);
            this.X(builder, matrix, x, y, z + 1.0F, x + 1.0F, y, z + 1.0F, r, g, b, a);
         }

         var18 = shouldRenderFace[1];
      }

      if (axx != null) {
         if (var18) {
            this.X(builder, matrix, x, y + 1.0F, z, x + 1.0F, y + 1.0F, z, r, g, b, a);
            this.X(builder, matrix, x, y + 1.0F, z, x, y + 1.0F, z + 1.0F, r, g, b, a);
            this.X(builder, matrix, x + 1.0F, y + 1.0F, z, x + 1.0F, y + 1.0F, z + 1.0F, r, g, b, a);
            this.X(builder, matrix, x, y + 1.0F, z + 1.0F, x + 1.0F, y + 1.0F, z + 1.0F, r, g, b, a);
         }

         var18 = shouldRenderFace[2];
      }

      label99: {
         label98: {
            label105: {
               if (axx != null) {
                  if (var18) {
                     break label105;
                  }

                  var18 = shouldRenderFace[4];
               }

               if (axx == null) {
                  break label99;
               }

               if (!var18) {
                  break label98;
               }
            }

            this.X(builder, matrix, x, y, z, x, y + 1.0F, z, r, g, b, a);
         }

         var18 = shouldRenderFace[2];
      }

      label86: {
         label85: {
            label106: {
               if (axx != null) {
                  if (var18) {
                     break label106;
                  }

                  var18 = shouldRenderFace[5];
               }

               if (axx == null) {
                  break label86;
               }

               if (!var18) {
                  break label85;
               }
            }

            this.X(builder, matrix, x + 1.0F, y, z, x + 1.0F, y + 1.0F, z, r, g, b, a);
         }

         var18 = shouldRenderFace[3];
      }

      label73: {
         label72: {
            label107: {
               if (axx != null) {
                  if (var18) {
                     break label107;
                  }

                  var18 = shouldRenderFace[4];
               }

               if (axx == null) {
                  break label73;
               }

               if (!var18) {
                  break label72;
               }
            }

            this.X(builder, matrix, x, y, z + 1.0F, x, y + 1.0F, z + 1.0F, r, g, b, a);
         }

         var18 = shouldRenderFace[3];
      }

      label59: {
         if (axx != null) {
            if (var18) {
               break label59;
            }

            var18 = shouldRenderFace[5];
         }

         if (!var18) {
            return;
         }
      }

      this.X(builder, matrix, x + 1.0F, y, z + 1.0F, x + 1.0F, y + 1.0F, z + 1.0F, r, g, b, a);
   }

   private boolean b(Set<BlockPos> potentialShaft) {
      long a = 98393208416223L;
      long ax = 125527250587045L;
      long axx = 85526755286720L;
      String axxx = d<"Ð">(7482472643188874766L, a);

      try {
         Set<BlockPos> borderBlocks = this.U(potentialShaft);
         int mineshaftFeatureScore = 0;
         int artificialBlockScore = 0;
         int totalBlocks = 0;

         for (BlockPos pos : borderBlocks) {
            Block block = 友树友友树何树友树友.g(axx, pos);
            Block var21 = block;
            if (axxx != null) {
               if (block == null) {
                  continue;
               }

               var21 = block;
            }

            String blockId = var21.getDescriptionId().toLowerCase();
            totalBlocks++;
            boolean var22 = this.H(blockId);
            if (axxx != null) {
               if (var22) {
                  mineshaftFeatureScore++;
               }

               var22 = this.C(blockId);
            }

            if (var22) {
               artificialBlockScore++;
            }

            if (axxx == null) {
               break;
            }
         }

         boolean hasLinearStructure = this.Q(potentialShaft);
         int var23 = mineshaftFeatureScore;
         if (axxx != null) {
            var23 = mineshaftFeatureScore > 0 ? 1 : 0;
         }

         boolean hasMineshaftFeatures = (boolean)var23;
         double var26;
         var23 = (var26 = artificialBlockScore - totalBlocks * 0.3) == 0.0 ? 0 : (var26 < 0.0 ? -1 : 1);
         if (axxx != null) {
            var23 = var23 > 0 ? 1 : 0;
         }

         boolean hasArtificialElements = (boolean)var23;
         var23 = hasMineshaftFeatures;
         if (axxx != null) {
            if (hasMineshaftFeatures == 0) {
               return (boolean)0;
            }

            var23 = hasArtificialElements;
         }

         if (axxx != null) {
            if (var23 == 0) {
               return (boolean)0;
            }

            var23 = hasLinearStructure;
         }

         if (axxx == null) {
            return (boolean)var23;
         } else {
            return (boolean)(var23 != 0 ? 1 : 0);
         }
      } catch (Exception var17) {
         boolean var10000 = d<"f">(this, 7482166058581267737L, a).getValue();
         if (axxx != null) {
            if (var10000) {
               ClientUtils.P(ax, b<"f">(2902, 212176380591681893L) + var17.getMessage());
            }

            var10000 = false;
         }

         return var10000;
      }
   }

   private boolean c(Set<BlockPos> cave) {
      long a = 83737734574407L;
      String ax = d<"Ð">(8164745121406503062L, a);
      int var10000 = cave.isEmpty();
      if (ax != null) {
         if (!var10000) {
            Set<BlockPos> visited = new HashSet<>();
            Queue<BlockPos> queue = new LinkedList<>();
            BlockPos start = cave.iterator().next();
            queue.add(start);
            visited.add(start);

            label68:
            while (true) {
               boolean var14 = queue.isEmpty();

               label65:
               while (!var14) {
                  BlockPos current = queue.poll();
                  Direction[] var9 = Direction.values();
                  int var10 = var9.length;
                  var10000 = 0;
                  if (ax == null) {
                     break label68;
                  }

                  int var11 = 0;

                  while (var11 < var10) {
                     Direction dir = var9[var11];
                     BlockPos neighbor = current.relative(dir);
                     if (ax != null) {
                        var14 = cave.contains(neighbor);
                        if (ax == null) {
                           continue label65;
                        }

                        if (var14 && ax != null && !visited.contains(neighbor)) {
                           visited.add(neighbor);
                           queue.add(neighbor);
                        }

                        var11++;
                     }

                     if (ax == null) {
                        break;
                     }
                  }

                  if (ax != null) {
                     continue label68;
                  }
                  break;
               }

               var10000 = visited.size();
               break;
            }

            if (ax != null) {
               var10000 = var10000 == cave.size() ? 1 : 0;
            }

            return (boolean)var10000;
         }

         var10000 = 1;
      }

      return (boolean)var10000;
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         MethodHandle var9;
         if (var8 != 'f' && var8 != 239 && var8 != 'v' && var8 != 198) {
            var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 214) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 208) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'f') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'v') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName())
            .append(" : ")
            .append(var10 != null ? var10.toString() : (var11 != null ? var11.toString() : " null "))
            .append(" : ")
            .append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友树何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 6893;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var9 = (Object[])l.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               l.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友树何何友友树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   @Override
   public void h() {
      this.V();
      this.B();
   }

   @EventTarget
   public void h(TickEvent event) {
      long a = 137211104799916L;
      long ax = 52406761729175L;
      long axx = 108624793298909L;
      String var8 = d<"Ð">(3216749427369481597L, a);
      boolean var10000 = this.Q(new Object[]{ax});
      if (var8 != null) {
         if (var10000) {
            return;
         }

         var10000 = (Boolean)Fucker.isLogin;
      }

      if (var8 != null) {
         if (!var10000) {
            return;
         }

         var10000 = (Boolean)Fucker.isBeta;
      }

      if (var8 != null) {
         if (!var10000) {
            return;
         }

         var10000 = d<"f">(this, 3218180936376394336L, a).get();
      }

      label54: {
         if (var8 != null) {
            if (var10000) {
               return;
            }

            var9 = this;
            if (var8 == null) {
               break label54;
            }

            var10000 = d<"f">(this, 3218180936376394336L, a).compareAndSet(false, true);
         }

         if (!var10000) {
            return;
         }

         var9 = this;
      }

      树友何何何树何树友友.G(() -> {
         long axxx = 108055886690717L;
         long axxxx = 125527250587045L;
         String axxxxx = d<"Ð">(-462412792317067188L, axxx);
         boolean var11 = false /* VF: Semaphore variable */;

         label141: {
            友何何友树何何友友树 var10000x;
            label127: {
               try {
                  var11 = true;
                  String e = d<"f">(this, -461424085681611566L, axxx).getValue();
                  byte var7 = -1;
                  var22 = e.hashCode();
                  label99:
                  if (axxxxx != null) {
                     switch (var22) {
                        case -901402615:
                           var22 = e.equals(b<"f">(6173, 5455265373126402667L));
                           if (axxxxx == null) {
                              break label99;
                           }

                           if (var22 == 0) {
                              break;
                           }

                           var7 = 0;
                           if (axxxxx != null) {
                              break;
                           }
                        case -1581447705:
                           var22 = e.equals(b<"f">(32303, 1789656162767127661L));
                           if (axxxxx == null) {
                              break label99;
                           }

                           if (var22 == 0) {
                              break;
                           }

                           var7 = 1;
                           if (axxxxx != null) {
                              break;
                           }
                        case 2076577:
                           var22 = e.equals(b<"f">(5427, 3519207018756419406L));
                           if (axxxxx == null) {
                              break label99;
                           }

                           if (var22 != 0) {
                              var7 = 2;
                           }
                     }

                     var22 = var7;
                  }

                  switch (var22) {
                     case 0:
                        this.e();
                        if (axxxxx != null) {
                           var11 = false;
                           break label141;
                        }
                     case 1:
                        this.q();
                        if (axxxxx != null) {
                           var11 = false;
                           break label141;
                        }
                     case 2:
                        this.e();
                        this.q();
                        var11 = false;
                        break label141;
                     default:
                        var11 = false;
                        break label141;
                  }
               } catch (Exception var12) {
                  var10000x = this;
                  if (axxxxx == null) {
                     var11 = false;
                     break label127;
                  }

                  if (d<"f">(this, -461683450391753893L, axxx).getValue()) {
                     ClientUtils.P(axxxx, b<"f">(15962, 5106806902976513031L) + var12.getMessage());
                     var11 = false;
                  } else {
                     var11 = false;
                  }
               } finally {
                  if (var11) {
                     d<"f">(this, -461522142434756783L, axxx).set(false);
                  }
               }

               var10000x = this;
            }

            d<"f">(var10000x, -461522142434756783L, axxx).set(false);
            return;
         }

         d<"f">(this, -461522142434756783L, axxx).set(false);
      }, axx);
   }

   private static Field f(Class var0, String var1, Class var2) {
      Field var3 = e(var0, var1, var2);
      if (var3 != null) {
         return var3;
      } else {
         Class[] var4 = var0.getInterfaces();
         if (var4 != null) {
            for (int var5 = 0; var5 < var4.length; var5++) {
               var3 = f(var4[var5], var1, var2);
               if (var3 != null) {
                  return var3;
               }
            }
         }

         return null;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      Method var5 = e(var0, var1, var2, var3, var4);
      if (var5 != null) {
         return var5;
      } else {
         Class[] var6 = var0.getInterfaces();
         if (var6 != null) {
            for (int var7 = 0; var7 < var6.length; var7++) {
               var5 = f(var6[var7], var1, var2, var3, var4);
               if (var5 != null) {
                  return var5;
               }
            }
         }

         return null;
      }
   }

   private boolean f(String blockId) {
      long a = 97167383721666L;
      String var4 = d<"Ð">(-663695889465454829L, a);
      boolean var10000 = blockId.contains(b<"f">(29017, 7717469396314082061L));
      if (var4 != null) {
         if (!var10000) {
            var10000 = blockId.contains(b<"f">(30106, 2634681901295652863L));
            if (var4 == null) {
               return var10000;
            }

            if (!var10000) {
               var10000 = blockId.contains(b<"f">(31368, 6670902700206407884L));
               if (var4 == null) {
                  return var10000;
               }

               if (!var10000) {
                  var10000 = blockId.contains(b<"f">(31384, 1453704031113691364L));
                  if (var4 == null) {
                     return var10000;
                  }

                  if (!var10000) {
                     var10000 = blockId.contains(b<"f">(21497, 4679791349968202144L));
                     if (var4 == null) {
                        return var10000;
                     }

                     if (!var10000) {
                        var10000 = blockId.contains(b<"f">(19855, 5129390559910000578L));
                        if (var4 == null) {
                           return var10000;
                        }

                        if (!var10000) {
                           return false;
                        }
                     }
                  }
               }
            }
         }

         var10000 = true;
      }

      return var10000;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Class var23 = var8;

         while (true) {
            Method var25 = e(var23, var10, var15, var13, var14);
            if (var25 != null) {
               m[var4] = var25;
               return var25;
            }

            if (var23.getName().equals("java.lang.Object")) {
               break;
            }

            if ((var23 = var23.getSuperclass()) == null) {
               j(1282677628261725L, 0L);
               break;
            }
         }

         var23 = var8;

         while (true) {
            Class[] var26;
            if ((var26 = var23.getInterfaces()) != null) {
               for (int var18 = 0; var18 < var26.length; var18++) {
                  Method var19 = f(var26[var18], var10, var15, var13, var14);
                  if (var19 != null) {
                     m[var4] = var19;
                     return var19;
                  }
               }
            }

            if (var23.getName().equals("java.lang.Object")) {
               StringBuffer var27 = new StringBuffer();
               var27.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
               int var28 = 0;

               while (var28 < var13) {
                  var27.append(var14[var28].getName());
                  if (++var28 < var13) {
                     var27.append(", ");
                  }
               }

               var27.append(')');
               throw new RuntimeException(var27.toString());
            }

            if ((var23 = var23.getSuperclass()) == null) {
               var23 = j(1282677628261725L, 0L);
            }
         }
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何友树何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static void a() {
      m[0] = "}6\u007f\u0005Pxrv2\u000eZew+9HRxz-=\u0003\u0011~s(=HMrp<4\u0014\u0011叜佋伍厚桷佪佂叕厓桀";
      m[1] = "\\\u0003W\u000b?kSC\u001a\u00005vV\u001e\u0011F&eS\u0018\u001cF9iO\u0001W&%i]\b\u000b>1hJ\b";
      m[2] = "\u007f)~AV\u0013pi3J\\\u000eu48\fT\u0013x2<G\u0017\u0015q7<\fK\u0019r#5P\u0017>y3$GK?}*5PX";
      m[3] = "}\u0016-^imv\u0019<\u0011\u0014ue\u001e5X";
      m[4] = "y\u001d\r[F\u001bg\u0015\u0017\u0014;\u000bg";
      m[5] = "\r\\~!\u001e'\u0006Sonu3\u0004Xx4Y$\t";
      m[6] = "\u0017ot\u0010vD\u0018/9\u001b|Y\u001dr2]oJ\u0018t?]pF\u0004mt1vD\u0018d;\u001dOJ\u0018t?";
      m[7] = "^V\u0017\u0011`{Q\u0016Z\u001ajfTKQ\\yuQM\\\\fyMT\u0017?`pXnX\u001ezq";
      m[8] = "\". |#M?;x^b@'=";
      m[9] = "h>Tp\u001fkh>C,\u0013druC2\u001bgh/\u000e\u0013\u001blc8R?\u0014v";
      m[10] = "\u0013G~\u001dZ8\u0013GiAV7\t\fi_^4\u0013V$AR?\u0019GxVE\u007f:CgVe4\u0013FoAR#";
      m[11] = "g3%\u001a~#y;?U39c1&\t\"3c&}\u001a$9`;0U\u0011\"b?:\u0018\u00129b>6\u001a>";
      m[12] = "uPR\u0018R\u0001|^QQ\u0011\fz^ES\f\n8IZDK\u000bn\u0011iSM\u001asGyYM\u0003wK\u001b{P\ns";
      m[13] = "p~\u0012^\u0017|yp\u0011\u0017Tq\u007fp\u0005\u0015Iw=g\u001a\u0002\u000evk?;\u0015\u001crf}\u000b&\u001fagt\u00076\u0015a~p\u000b";
      m[14] = "s1\u0014!/\"z?\u0017hl/|?\u0003jq)>(\u001c}6(hp/j09u&?`0 q*";
      m[15] = "2@#TFm=\u0000n_Lp8]e\u0019Dm5[aR\u0007栓伄句叆佢核叉厚佻佘";
      m[16] = "^|csck^|t/odD7`2|nT7g5wq\u001eOr>=";
      m[17] = double.class;
      n[17] = "java/lang/Double";
      m[18] = "tWy>XE\u007fXhq9KtSl+";
      m[19] = "s\u0006g\u001e*b2\thc厙体伓桱佋伾伇体厍桱\u0016Y$b7VoY\"g$";
      m[20] = "\u0012\u0007;o\u0003NS\b4\u0012桪叡栶厪厉栋桪叡召伴J-\u0014E\u0013Tqj\u000e\\\u001e";
      m[21] = "4|\u000bf\u0015Vus\u0004\u001b伸佧佔栋伧但桼佧及栋z'\u0005\u0003xi\u0003+\b]t";
      m[22] = "\u0002jLd>qCeC\u0019桗佀叼余叾栀厍佀叼栝=d6aA\u007f\u0006t5s";
      m[23] = "[^*\f1*\u001aQ%q桘伛桿栩桂桨桘伛厥栩[L/!]K>\u001d.w\u0005";
      m[24] = "Z\u0000b\"|D\u001b\u000fm_叏併伺桷叐框叏栱伺伳\u0013a7T\u001aTk%aJ\u001f";
      m[25] = "\t}j\u0017\u0013QIh1V/\u0000`2nS\u0011U`\u0003h\n\u0010\r\u000el,\u0005K\u0016";
      m[26] = "'*,\u000efAv4w\u0011[aZ\u0004\u0014\"\fiV\b\u00046[\u001ds+*P7Lmp5";
      m[27] = "\n\u0015(op~\u0003Vz,Oul\u001f|dv&l/(=pyW\u0011p-%w";
      m[28] = "z1-Ju\";>\"7栜桗会框企佪佘厍厄框\\J}29$gZ~ ";
      m[29] = "3FNc}\u000ei]J\u007f\u001b[\u000e\u0012H:+\r\u000e\"\u0018{gZ2\u0018\u0002vxL";
      m[30] = "Hce\"B:\tlj_佯厕厶収佉框叱桏桬栔\u0014a\t*\b7l%_4\r";
      m[31] = ";`<wbCzo3\n住召栟体桔栓栋佲叅栗M6r\u0016wu4:\u007fH{";
      m[32] = "UFod/^\u0014I`\u0019框佯伵栱佃栀框叱厫叫\u001ed'N\u0016S%t$\\";
      m[33] = "\\H.\u000b?^\u0007MxMPSe\b%\u001f;T\u0001\br\u001e)>";
      m[34] = "\u0017'tyi\\M<pe\u000f\t*sr 0V*C\"as\b\u0016y8ll\u001e";
      m[35] = "2[d*c4sTkW低桁双栬取桎栊伅佒叶\u0015ksa~Nlg~?r";
      m[36] = "nO)3,\u0006/@&N原伷桊叢厛桗企厩厐叢Xt\"\u0006*\u001f!t$\u00039";
      m[37] = "PD2\n \u0017\n_6\u0016FBm\u00104Sv\u0015m d\u0012:CQ\u001a~\u001f%U";
      m[38] = "B\u001c:buK\u0003\u00135\u001f叆栾伢厱厈栆佘佺桦伯Kb}[\u0001\tpr~I";
      m[39] = "%\rtbQid\u0002{\u001fH\u0005#\u0007krC:}Zxb!>|\rh}\u001e`!\u001ex\u001f";
      m[40] = "uq8\u0000eD4~7}栌栱桑叜厊厾栌併伕叜I\u0000mT6dr\u0010nF";
      m[41] = "sI\u0011I\tq2F\u001e4伤佀伓栾桹号桠栄厍栾`I\u0001a0\\[Y\u0002s";
      m[42] = "`\n+p/\\!\u0005$\r厜栩伀伹厙栔框栩桄伹Z1?\t,\u001f#=2W ";
      m[43] = "\u000e/+laeO $\u0011栈及台桘厙栈栈及株厂Z-q0B:#!|nN";
      m[44] = ">\u0019XN`t\u007f\u0016W3位佅佞厴栰株栉佅栚伪)\u000fp!r\fP\u0003}\u007f~";
      m[45] = "]=6?\u001e@\t}d&b厲号桚框伉厡桨栭厀框T\u000b\u000f](#e_O\u000f1";
   }

   @EventTarget
   public void m(Render3DEvent event) {
      long a = 8053225730971L;
      long ax = 52406761729175L;
      String axx = d<"Ð">(-5506975359883736502L, a);
      if (!this.Q(new Object[]{ax})) {
         Camera camera = d<"f">(mc, -5504166431533207967L, a).getMainCamera();
         Vec3 camPos = camera.getPosition();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableDepthTest();
         RenderSystem.lineWidth(d<"f">(this, -5504524592078755975L, a).getValue().floatValue());
         if (axx != null) {
            label44:
            if (d<"f">(this, -5503882555912260771L, a).getValue()) {
               boolean var10000;
               label67: {
                  label76: {
                     var10000 = d<"f">(this, -5503728423866591532L, a).K(b<"f">(6173, 5455265373126402667L));
                     if (axx != null) {
                        if (!var10000) {
                           var10000 = d<"f">(this, -5503728423866591532L, a).K(b<"f">(5427, 3519207018756419406L));
                           if (axx == null) {
                              break label67;
                           }

                           if (!var10000) {
                              break label76;
                           }
                        }

                        var10000 = d<"f">(this, -5503415214538532719L, a).isEmpty();
                     }

                     if (axx == null) {
                        break label67;
                     }

                     if (!var10000) {
                        this.v(event.poseStack(), camPos, d<"f">(this, -5503415214538532719L, a), d<"f">(this, -5504224625885777735L, a));
                     }
                  }

                  var10000 = d<"f">(this, -5503728423866591532L, a).K(b<"f">(32303, 1789656162767127661L));
               }

               label77: {
                  label53:
                  if (axx != null) {
                     if (!var10000) {
                        var10000 = d<"f">(this, -5503728423866591532L, a).K(b<"f">(5427, 3519207018756419406L));
                        if (axx == null) {
                           break label53;
                        }

                        if (!var10000) {
                           break label44;
                        }
                     }

                     var9 = this;
                     if (axx == null) {
                        break label77;
                     }

                     var10000 = d<"f">(this, -5507329981502387815L, a).isEmpty();
                  }

                  if (var10000) {
                     break label44;
                  }

                  var9 = this;
               }

               var9.v(event.poseStack(), camPos, d<"f">(this, -5507329981502387815L, a), d<"f">(this, -5504323075121992326L, a));
            }

            RenderSystem.disableBlend();
            RenderSystem.enableDepthTest();
         }
      }
   }

   private boolean k(BlockPos pos) {
      long a = 99659576526280L;
      long ax = 85526755286720L;
      String var10000 = d<"Ð">(5026042363849341977L, a);
      int dx = -2;
      String axx = var10000;

      label118:
      while (true) {
         int var13 = dx;

         label114:
         while (true) {
            if (var13 <= 2) {
               var14 = -1;
               if (axx == null) {
                  break;
               }

               int dy = -1;

               while (dy <= 1) {
                  var13 = -2;
                  if (axx == null) {
                     continue label114;
                  }

                  int dz = -2;

                  label106: {
                     while (dz <= 2) {
                        BlockPos checkPos = pos.offset(dx, dy, dz);
                        Block block = 友树友友树何树友树友.g(ax, checkPos);
                        if (axx == null) {
                           break label106;
                        }

                        label129: {
                           Block var15 = block;
                           if (axx != null) {
                              if (block == null) {
                                 break label129;
                              }

                              var15 = block;
                           }

                           String blockId;
                           blockId = var15.getDescriptionId().toLowerCase();
                           var16 = d<"f">(this, 5030423308204810256L, a).getValue();
                           label95:
                           if (axx != null) {
                              if (var16) {
                                 var16 = this.u(blockId);
                                 if (axx == null) {
                                    break label95;
                                 }

                                 if (var16) {
                                    return true;
                                 }
                              }

                              var16 = d<"f">(this, 5026940407152120558L, a).getValue();
                           }

                           label87:
                           if (axx != null) {
                              if (var16) {
                                 var16 = this.f(blockId);
                                 if (axx == null) {
                                    break label87;
                                 }

                                 if (var16) {
                                    return true;
                                 }
                              }

                              var16 = d<"f">(this, 5026740580080264807L, a).getValue();
                           }

                           if (axx != null) {
                              if (!var16) {
                                 break label129;
                              }

                              var16 = this.I(blockId);
                           }

                           if (axx == null) {
                              return var16;
                           }

                           if (var16) {
                              return true;
                           }
                        }

                        dz++;
                        if (axx == null) {
                           break;
                        }
                     }

                     dy++;
                  }

                  if (axx == null) {
                     break;
                  }
               }

               dx++;
               if (axx != null) {
                  continue label118;
               }
            }

            var14 = 0;
            break;
         }

         return (boolean)var14;
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Field)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Class var12 = var8;

         while (true) {
            Field var13 = e(var12, var10, var11);
            if (var13 != null) {
               m[var4] = var13;
               return var13;
            }

            Class[] var14 = var12.getInterfaces();
            if (var14 != null) {
               for (int var15 = 0; var15 < var14.length; var15++) {
                  var13 = f(var14[var15], var10, var11);
                  if (var13 != null) {
                     m[var4] = var13;
                     return var13;
                  }
               }
            }

            if (var12.getName().equals("java.lang.Object")) {
               StringBuffer var19 = new StringBuffer();
               var19.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
               throw new RuntimeException(var19.toString());
            }

            var12 = var12.getSuperclass();
            if (var12 == null) {
               var12 = j(1282677628261725L, 0L);
            }
         }
      }
   }

   private void v(PoseStack poseStack, Vec3 camPos, Set<BlockPos> blocks, Color color) {
      long a = 132715091034554L;
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      String var10000 = d<"Ð">(-9101153685303576469L, a);
      BufferBuilder builder = Tesselator.getInstance().getBuilder();
      builder.begin(d<"v">(-9098148094946001674L, a), d<"v">(-9098215422678636380L, a));
      String ax = var10000;
      float alpha = d<"f">(this, -9101662666778650612L, a).getValue().floatValue() / 255.0F;
      float r = color.getRed() / 255.0F;
      float g = color.getGreen() / 255.0F;
      float b = color.getBlue() / 255.0F;
      Iterator var13 = blocks.iterator();

      while (true) {
         if (var13.hasNext()) {
            BlockPos pos = (BlockPos)var13.next();
            this.b(poseStack, builder, pos, r, g, b, alpha, camPos, blocks);
            if (ax == null) {
               break;
            }

            if (ax != null) {
               continue;
            }
         }

         BufferUploader.drawWithShader(builder.end());
         break;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   // $VF: Handled exception range with multiple entry points by splitting it
   // $VF: Duplicated exception handlers to handle obfuscated exceptions
   private void q() {
      long a = 47930634154121L;
      long ax = 125527250587045L;
      long axx = 52406761729175L;
      String axxx = d<"Ð">(3495188941458999640L, a);
      int var10000 = this.Q(new Object[]{axx});
      if (axxx != null) {
         if (var10000 != 0) {
            return;
         }

         var10000 = d<"f">(this, 3495770793973780008L, a).getValue().intValue();
      }

      int range = var10000;
      int vRange = d<"f">(this, 3495096241851780181L, a).getValue().intValue();
      int playerX = (int)mc.player.getX();
      int playerY = (int)mc.player.getY();
      int playerZ = (int)mc.player.getZ();
      int minY = Math.max(playerY - vRange, mc.level.getMinBuildHeight());
      int maxY = Math.min(playerY + vRange, mc.level.getMaxBuildHeight());
      Set<BlockPos> visitedBlocks = new HashSet<>();
      int rangeSquared = range * range;
      int x = playerX - range;

      label150:
      while (true) {
         var10000 = x;
         int var10001 = playerX + range;

         label147:
         while (var10000 <= var10001) {
            var10000 = playerZ - range;
            if (axxx == null) {
               break label150;
            }

            int z = var10000;

            label144:
            while (true) {
               var10000 = z;

               label142:
               while (true) {
                  if (var10000 > playerZ + range) {
                     break label144;
                  }

                  label157: {
                     int dx = x - playerX;
                     int dz = z - playerZ;
                     var10000 = dx * dx + dz * dz;
                     if (axxx != null) {
                        var10001 = rangeSquared;
                        if (axxx == null) {
                           continue label147;
                        }

                        if (var10000 > rangeSquared) {
                           break label157;
                        }

                        var10000 = minY;
                     }

                     int y = var10000;

                     while (y <= maxY) {
                        label129: {
                           label128: {
                              Exception e;
                              label127: {
                                 label126: {
                                    label125: {
                                       try {
                                          pos = new BlockPos(x, y, z);
                                          var10000 = visitedBlocks.contains(pos);
                                          if (axxx == null) {
                                             continue label142;
                                          }

                                          if (axxx == null) {
                                             break label126;
                                          }

                                          if (var10000 == 0) {
                                             break label125;
                                          }
                                       } catch (Exception var31) {
                                          e = var31;
                                          if (axxx == null) {
                                             break label129;
                                          }
                                          break label127;
                                       }

                                       if (axxx != null) {
                                          break label128;
                                       }
                                    }

                                    try {
                                       var10000 = this.Z(pos);
                                    } catch (Exception var30) {
                                       e = var30;
                                       if (axxx == null) {
                                          break label129;
                                       }
                                       break label127;
                                    }
                                 }

                                 try {
                                    if (axxx != null) {
                                       if (var10000 == 0) {
                                          break label128;
                                       }

                                       var10000 = this.k(pos);
                                    }

                                    if (var10000 != 0) {
                                       Set<BlockPos> potentialShaftBlocks = new HashSet<>();
                                       this.P(pos, potentialShaftBlocks, visitedBlocks, 300);
                                       int minSize = d<"f">(this, 3498335620016347435L, a).getValue().intValue();
                                       var10000 = potentialShaftBlocks.size();
                                       if (axxx != null) {
                                          if (var10000 < minSize) {
                                             break label128;
                                          }

                                          var10000 = this.b(potentialShaftBlocks);
                                       }

                                       if (axxx != null && var10000 != 0) {
                                          d<"f">(this, 3494833216025889419L, a).addAll(potentialShaftBlocks);
                                       }
                                    }
                                    break label128;
                                 } catch (Exception var29) {
                                    e = var29;
                                    if (axxx == null) {
                                       break label129;
                                    }
                                 }
                              }

                              if (d<"f">(this, 3495792251855487567L, a).getValue()) {
                                 String axxxx = e.getMessage();
                                 ClientUtils.P(ax, b<"f">(9062, 955662151072192846L) + x + "," + y + "," + z + b<"f">(8875, 2467322368269687038L) + axxxx);
                              }
                           }

                           y += 2;
                        }

                        if (axxx == null) {
                           break;
                        }
                     }
                  }

                  z += 3;
                  if (axxx == null) {
                     break label144;
                  }
                  break;
               }
            }

            x += 3;
            if (axxx != null) {
               continue label150;
            }
            break;
         }

         var10000 = d<"f">(this, 3495792251855487567L, a).getValue();
         break;
      }

      if (axxx != null) {
         if (var10000 == 0) {
            return;
         }

         var10000 = d<"f">(this, 3494833216025889419L, a).size();
      }

      ClientUtils.P(ax, b<"f">(13034, 6188096078462257285L) + var10000 + b<"f">(27704, 4882409164947052113L));
   }

   private Set<BlockPos> U(Set<BlockPos> caveBlocks) {
      long a = 136013256104037L;
      Set<BlockPos> borderBlocks = new HashSet<>();
      HashSet airBlocksSet = new HashSet<>(caveBlocks);
      String var10000 = d<"Ð">(-7463247497726189132L, a);
      Iterator var7 = caveBlocks.iterator();
      String ax = var10000;

      label38:
      while (true) {
         boolean var14 = var7.hasNext();

         label36:
         while (var14) {
            BlockPos pos = (BlockPos)var7.next();
            Direction[] var9 = Direction.values();
            int var10 = var9.length;
            int var11 = 0;

            while (var11 < var10) {
               Direction dir = var9[var11];
               BlockPos neighbor = pos.relative(dir);
               if (ax != null) {
                  var14 = airBlocksSet.contains(neighbor);
                  if (ax == null) {
                     continue label36;
                  }

                  if (!var14) {
                     borderBlocks.add(neighbor);
                  }

                  var11++;
               }

               if (ax == null) {
                  break;
               }
            }

            if (ax == null) {
               return borderBlocks;
            }
            continue label38;
         }

         return borderBlocks;
      }
   }

   private boolean u(String blockId) {
      long a = 107731089216864L;
      String var4 = d<"Ð">(-3069152850649518927L, a);
      boolean var10000 = blockId.contains(b<"f">(5887, 4372174206025247895L));
      if (var4 != null) {
         if (!var10000) {
            var10000 = blockId.contains(b<"f">(5768, 7893750507837303979L));
            if (var4 == null) {
               return var10000;
            }

            if (!var10000) {
               return false;
            }
         }

         var10000 = true;
      }

      return var10000;
   }

   private boolean E(Set<BlockPos> potentialCave) {
      long a = 108637141435573L;
      long ax = 125527250587045L;
      long axx = 85526755286720L;
      String axxx = d<"Ð">(-8881891714078589596L, a);

      try {
         友何何友树何何友友树 var18 = this;
         Set var10001 = potentialCave;
         if (axxx != null) {
            if (!this.e(potentialCave)) {
               return false;
            }

            var18 = this;
            var10001 = potentialCave;
         }

         Set<BlockPos> borderBlocks = var18.U(var10001);
         int naturalFeatureScore = 0;
         int artificialFeatureScore = 0;

         for (BlockPos borderPos : borderBlocks) {
            Block block = 友树友友树何树友树友.g(axx, borderPos);
            Block var19 = block;
            if (axxx != null) {
               if (block == null) {
                  continue;
               }

               var19 = block;
            }

            String blockId = var19.getDescriptionId().toLowerCase();
            boolean var20 = this.Q(blockId);
            if (axxx != null) {
               if (var20) {
                  naturalFeatureScore++;
               }

               var20 = this.C(blockId);
            }

            if (var20) {
               artificialFeatureScore++;
            }

            if (axxx == null) {
               break;
            }
         }

         boolean hasIrregularShape = this.L(potentialCave);
         int var21 = naturalFeatureScore;
         if (axxx != null) {
            if (naturalFeatureScore <= artificialFeatureScore) {
               return (boolean)0;
            }

            var21 = hasIrregularShape;
         }

         if (axxx == null) {
            return (boolean)var21;
         } else {
            return (boolean)(var21 != 0 ? 1 : 0);
         }
      } catch (Exception var16) {
         boolean var10000 = d<"f">(this, -8881162435990555021L, a).getValue();
         if (axxx != null) {
            if (var10000) {
               ClientUtils.P(ax, b<"f">(18506, 3725731705798652420L) + var16.getMessage());
            }

            var10000 = false;
         }

         return var10000;
      }
   }

   private void X(BufferBuilder builder, Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b, float a) {
      builder.vertex(matrix, x1, y1, z1).color(r, g, b, a).endVertex();
      builder.vertex(matrix, x2, y2, z2).color(r, g, b, a).endVertex();
   }

   private boolean L(Set<BlockPos> cave) {
      long a = 110951863138570L;
      String var10000 = d<"Ð">(-5115481500417654565L, a);
      int minX = c<"b">(26916, 7719993713537414095L);
      int maxX = c<"b">(14887, 4035590566909518031L);
      int minY = c<"b">(5039, 947857570204420418L);
      int maxY = c<"b">(19431, 4712670932817367305L);
      int minZ = c<"b">(5039, 947857570204420418L);
      String ax = var10000;
      int maxZ = c<"b">(19431, 4712670932817367305L);
      Iterator width = cave.iterator();

      while (true) {
         if (width.hasNext()) {
            BlockPos pos = (BlockPos)width.next();
            minX = Math.min(minX, pos.getX());
            maxX = Math.max(maxX, pos.getX());
            minY = Math.min(minY, pos.getY());
            maxY = Math.max(maxY, pos.getY());
            minZ = Math.min(minZ, pos.getZ());
            var20 = Math.max(maxZ, pos.getZ());
            if (ax == null) {
               break;
            }

            maxZ = var20;
            if (ax != null) {
               continue;
            }
         }

         var20 = maxX - minX + 1;
         break;
      }

      label29: {
         int widthx = var20;
         int height = maxY - minY + 1;
         int length = maxZ - minZ + 1;
         int maxDim = Math.max(widthx, Math.max(height, length));
         int minDim = Math.min(widthx, Math.min(height, length));
         int var21 = minDim;
         if (ax != null) {
            if (minDim <= 0) {
               var22 = 0.0;
               break label29;
            }

            var21 = maxDim;
         }

         var22 = (double)var21 / minDim;
      }

      double linearScore = var22;
      double var24;
      int var23 = (var24 = linearScore - 3.0) == 0.0 ? 0 : (var24 < 0.0 ? -1 : 1);
      if (ax != null) {
         var23 = var23 < 0 ? 1 : 0;
      }

      return (boolean)var23;
   }

   @Override
   public void M() {
      long a = 48387658869217L;
      d<"ï">(this, new AtomicBoolean(false), -1593123860600264915L, a);
      this.V();
   }

   private void P(BlockPos param1, Set<BlockPos> param2, Set<BlockPos> param3, int param4) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:166)
      //
      // Bytecode:
      // 000: ldc2_w 78631938984632
      // 003: lstore 5
      // 005: ldc2_w 125527250587045
      // 008: lstore 7
      // 00a: new java/util/ArrayDeque
      // 00d: dup
      // 00e: invokespecial java/util/ArrayDeque.<init> ()V
      // 011: astore 10
      // 013: ldc2_w -8453243552419335319
      // 016: lload 5
      // 018: invokedynamic Ð (JJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友树何何友友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01d: aload 10
      // 01f: aload 1
      // 020: invokeinterface java/util/Deque.add (Ljava/lang/Object;)Z 2
      // 025: pop
      // 026: astore 9
      // 028: aload 10
      // 02a: invokeinterface java/util/Deque.isEmpty ()Z 1
      // 02f: ifne 166
      // 032: aload 2
      // 033: aload 9
      // 035: ifnull 04f
      // 038: goto 03b
      // 03b: invokeinterface java/util/Set.size ()I 1
      // 040: iload 4
      // 042: goto 045
      // 045: if_icmpge 166
      // 048: aload 10
      // 04a: invokeinterface java/util/Deque.poll ()Ljava/lang/Object; 1
      // 04f: checkcast net/minecraft/core/BlockPos
      // 052: astore 11
      // 054: aload 3
      // 055: aload 11
      // 057: invokeinterface java/util/Set.contains (Ljava/lang/Object;)Z 2
      // 05c: aload 9
      // 05e: ifnull 079
      // 061: ifeq 06a
      // 064: goto 067
      // 067: goto 028
      // 06a: aload 3
      // 06b: aload 11
      // 06d: invokeinterface java/util/Set.add (Ljava/lang/Object;)Z 2
      // 072: pop
      // 073: aload 0
      // 074: aload 11
      // 076: invokevirtual cn/cool/cherish/module/impl/render/友何何友树何何友友树.Z (Lnet/minecraft/core/BlockPos;)Z
      // 079: aload 9
      // 07b: ifnull 091
      // 07e: ifne 089
      // 081: goto 084
      // 084: aload 9
      // 086: ifnonnull 028
      // 089: aload 2
      // 08a: aload 11
      // 08c: invokeinterface java/util/Set.add (Ljava/lang/Object;)Z 2
      // 091: pop
      // 092: invokestatic net/minecraft/core/Direction.values ()[Lnet/minecraft/core/Direction;
      // 095: astore 12
      // 097: aload 12
      // 099: arraylength
      // 09a: istore 13
      // 09c: bipush 0
      // 09d: istore 14
      // 09f: iload 14
      // 0a1: iload 13
      // 0a3: if_icmpge 125
      // 0a6: aload 12
      // 0a8: iload 14
      // 0aa: aaload
      // 0ab: astore 15
      // 0ad: aload 11
      // 0af: aload 15
      // 0b1: invokevirtual net/minecraft/core/BlockPos.relative (Lnet/minecraft/core/Direction;)Lnet/minecraft/core/BlockPos;
      // 0b4: astore 16
      // 0b6: aload 9
      // 0b8: ifnull 120
      // 0bb: aload 16
      // 0bd: invokevirtual net/minecraft/core/BlockPos.getX ()I
      // 0c0: aload 1
      // 0c1: invokevirtual net/minecraft/core/BlockPos.getX ()I
      // 0c4: isub
      // 0c5: invokestatic java/lang/Math.abs (I)I
      // 0c8: bipush 50
      // 0ca: aload 9
      // 0cc: ifnull 045
      // 0cf: goto 0d2
      // 0d2: if_icmpgt 11d
      // 0d5: aload 16
      // 0d7: invokevirtual net/minecraft/core/BlockPos.getZ ()I
      // 0da: aload 1
      // 0db: invokevirtual net/minecraft/core/BlockPos.getZ ()I
      // 0de: isub
      // 0df: invokestatic java/lang/Math.abs (I)I
      // 0e2: aload 9
      // 0e4: ifnull 105
      // 0e7: goto 0ea
      // 0ea: bipush 50
      // 0ec: if_icmple 0fa
      // 0ef: goto 0f2
      // 0f2: aload 9
      // 0f4: ifnonnull 11d
      // 0f7: goto 0fa
      // 0fa: aload 3
      // 0fb: aload 16
      // 0fd: invokeinterface java/util/Set.contains (Ljava/lang/Object;)Z 2
      // 102: goto 105
      // 105: aload 9
      // 107: ifnull 11c
      // 10a: ifne 11d
      // 10d: goto 110
      // 110: aload 10
      // 112: aload 16
      // 114: invokeinterface java/util/Deque.add (Ljava/lang/Object;)Z 2
      // 119: goto 11c
      // 11c: pop
      // 11d: iinc 14 1
      // 120: aload 9
      // 122: ifnonnull 09f
      // 125: goto 161
      // 128: astore 12
      // 12a: aload 0
      // 12b: ldc2_w -8452446588914206594
      // 12e: lload 5
      // 130: invokedynamic f (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/render/友何何友树何何友友树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 135: invokevirtual cn/cool/cherish/value/impl/BooleanValue.getValue ()Ljava/lang/Object;
      // 138: checkcast java/lang/Boolean
      // 13b: invokevirtual java/lang/Boolean.booleanValue ()Z
      // 13e: ifeq 161
      // 141: aload 12
      // 143: invokevirtual java/lang/Exception.getMessage ()Ljava/lang/String;
      // 146: sipush 2025
      // 149: ldc2_w 22837153404468661
      // 14c: invokedynamic f (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友何何友树何何友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 151: swap
      // 152: invokedynamic makeConcatWithConstants (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; bsm=java/lang/invoke/StringConcatFactory.makeConcatWithConstants (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/invoke/CallSite; args=[ "\u0001\u0001" ]
      // 157: lload 7
      // 159: dup2_x1
      // 15a: pop2
      // 15b: invokestatic cn/cool/cherish/utils/client/ClientUtils.P (JLjava/lang/String;)V
      // 15e: goto 161
      // 161: aload 9
      // 163: ifnonnull 028
      // 166: return
   }

   private boolean H(String blockId) {
      long a = 33342882126427L;
      String var4 = d<"Ð">(1896950124244935562L, a);
      boolean var10000 = this.f(blockId);
      if (var4 != null) {
         if (!var10000) {
            var10000 = this.u(blockId);
            if (var4 == null) {
               return var10000;
            }

            if (!var10000) {
               var10000 = this.I(blockId);
               if (var4 == null) {
                  return var10000;
               }

               if (!var10000) {
                  var10000 = blockId.contains(b<"f">(7457, 8086762249716999953L));
                  if (var4 == null) {
                     return var10000;
                  }

                  if (!var10000) {
                     var10000 = blockId.contains(b<"f">(23207, 5066110287595495557L));
                     if (var4 == null) {
                        return var10000;
                     }

                     if (!var10000) {
                        var10000 = blockId.contains(b<"f">(1018, 8347784977088461249L));
                        if (var4 == null) {
                           return var10000;
                        }

                        if (!var10000) {
                           var10000 = blockId.contains(b<"f">(24604, 2354446968025897581L));
                           if (var4 == null) {
                              return var10000;
                           }

                           if (!var10000) {
                              return false;
                           }
                        }
                     }
                  }
               }
            }
         }

         var10000 = true;
      }

      return var10000;
   }

   private static String HE_DA_WEI() {
      return "何树友为什么濒天了";
   }

   private boolean Q(BlockPos pos, Set<BlockPos> blocks) {
      long a = 45105425980135L;
      long ax = 85526755286720L;
      String axx = d<"Ð">(-7282490743761853642L, a);
      boolean var10000 = blocks.contains(pos);
      if (axx != null) {
         if (!var10000) {
            Block block = 友树友友树何树友树友.g(ax, pos);
            Block var9 = block;
            if (axx != null) {
               if (block == null) {
                  return false;
               }

               var9 = block;
            }

            var10000 = var9 instanceof AirBlock;
            if (axx == null) {
               return var10000;
            }

            if (!var10000) {
               return true;
            }

            return false;
         }

         var10000 = false;
      }

      return var10000;
   }

   private boolean Q(String blockId) {
      long a = 41587525719097L;
      String var4 = d<"Ð">(-7768311782571561496L, a);
      boolean var10000 = blockId.contains(b<"f">(6409, 6842278136067203880L));
      if (var4 != null) {
         if (!var10000) {
            var10000 = blockId.contains(b<"f">(1479, 6753411847000833949L));
            if (var4 == null) {
               return var10000;
            }

            if (!var10000) {
               var10000 = blockId.contains(b<"f">(27438, 5032746000060010774L));
               if (var4 == null) {
                  return var10000;
               }

               if (!var10000) {
                  var10000 = blockId.contains(b<"f">(14640, 2393666043386364738L));
                  if (var4 == null) {
                     return var10000;
                  }

                  if (!var10000) {
                     var10000 = blockId.contains(b<"f">(2968, 590792216563266014L));
                     if (var4 == null) {
                        return var10000;
                     }

                     if (!var10000) {
                        var10000 = blockId.contains(b<"f">(25211, 4274667954502064206L));
                        if (var4 == null) {
                           return var10000;
                        }

                        if (!var10000) {
                           var10000 = blockId.contains(b<"f">(13062, 9099760002071693626L));
                           if (var4 == null) {
                              return var10000;
                           }

                           if (!var10000) {
                              var10000 = blockId.contains(b<"f">(4584, 4828637830408121256L));
                              if (var4 == null) {
                                 return var10000;
                              }

                              if (!var10000) {
                                 var10000 = blockId.contains(b<"f">(11233, 4724006523552338345L));
                                 if (var4 == null) {
                                    return var10000;
                                 }

                                 if (!var10000) {
                                    var10000 = blockId.contains(b<"f">(9315, 8060592724928011832L));
                                    if (var4 == null) {
                                       return var10000;
                                    }

                                    if (!var10000) {
                                       var10000 = blockId.contains(b<"f">(11297, 6670597586257647194L));
                                       if (var4 == null) {
                                          return var10000;
                                       }

                                       if (!var10000) {
                                          var10000 = blockId.contains(b<"f">(29115, 1935564440525425548L));
                                          if (var4 == null) {
                                             return var10000;
                                          }

                                          if (!var10000) {
                                             var10000 = blockId.contains(b<"f">(23589, 114347993634530912L));
                                             if (var4 == null) {
                                                return var10000;
                                             }

                                             if (!var10000) {
                                                var10000 = blockId.contains(b<"f">(14338, 6334295374864351863L));
                                                if (var4 == null) {
                                                   return var10000;
                                                }

                                                if (!var10000) {
                                                   var10000 = blockId.contains(b<"f">(8343, 2133154260847303406L));
                                                   if (var4 == null) {
                                                      return var10000;
                                                   }

                                                   if (!var10000) {
                                                      var10000 = blockId.contains(b<"f">(21569, 6814015463466626562L));
                                                      if (var4 == null) {
                                                         return var10000;
                                                      }

                                                      if (!var10000) {
                                                         var10000 = blockId.contains(b<"f">(17623, 9205155417412042417L));
                                                         if (var4 == null) {
                                                            return var10000;
                                                         }

                                                         if (!var10000) {
                                                            var10000 = blockId.contains(b<"f">(12097, 8768430571716679024L));
                                                            if (var4 == null) {
                                                               return var10000;
                                                            }

                                                            if (!var10000) {
                                                               var10000 = blockId.contains(b<"f">(1377, 8460560045563658056L));
                                                               if (var4 == null) {
                                                                  return var10000;
                                                               }

                                                               if (!var10000) {
                                                                  return false;
                                                               }
                                                            }
                                                         }
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         var10000 = true;
      }

      return var10000;
   }

   private boolean Q(Set<BlockPos> shaft) {
      long a = 50356292372288L;
      int minX = c<"b">(5039, 947857570204420418L);
      String var10000 = d<"Ð">(5136462616760090257L, a);
      int maxX = c<"b">(19431, 4712670932817367305L);
      int minY = c<"b">(5039, 947857570204420418L);
      int maxY = c<"b">(19431, 4712670932817367305L);
      int minZ = c<"b">(5039, 947857570204420418L);
      String ax = var10000;
      int maxZ = c<"b">(19431, 4712670932817367305L);
      Iterator width = shaft.iterator();

      while (true) {
         if (width.hasNext()) {
            BlockPos pos = (BlockPos)width.next();
            minX = Math.min(minX, pos.getX());
            maxX = Math.max(maxX, pos.getX());
            minY = Math.min(minY, pos.getY());
            maxY = Math.max(maxY, pos.getY());
            minZ = Math.min(minZ, pos.getZ());
            var19 = Math.max(maxZ, pos.getZ());
            if (ax == null) {
               break;
            }

            maxZ = var19;
            if (ax != null) {
               continue;
            }
         }

         var19 = maxX - minX + 1;
         break;
      }

      int widthx = var19;
      int height = maxY - minY + 1;
      int length = maxZ - minZ + 1;
      int[] dimensions = new int[]{widthx, height, length};
      Arrays.sort(dimensions);
      double linearRatio = (double)dimensions[2] / Math.max(dimensions[0], 1);
      double var21;
      int var20 = (var21 = linearRatio - 2.0) == 0.0 ? 0 : (var21 < 0.0 ? -1 : 1);
      if (ax != null) {
         var20 = var20 >= 0 ? 1 : 0;
      }

      return (boolean)var20;
   }

   private boolean G(String blockId) {
      long a = 103765308144325L;
      String var4 = d<"Ð">(-374623287219502316L, a);
      boolean var10000 = blockId.contains(b<"f">(27940, 6052878959839041404L));
      if (var4 != null) {
         if (!var10000) {
            var10000 = blockId.contains(b<"f">(14713, 1609865142697296641L));
            if (var4 == null) {
               return var10000;
            }

            if (!var10000) {
               var10000 = blockId.contains(b<"f">(25108, 1073872048893319236L));
               if (var4 == null) {
                  return var10000;
               }

               if (!var10000) {
                  var10000 = blockId.contains(b<"f">(28158, 4414171416078211001L));
                  if (var4 == null) {
                     return var10000;
                  }

                  if (!var10000) {
                     return false;
                  }
               }
            }
         }

         var10000 = true;
      }

      return var10000;
   }
}
