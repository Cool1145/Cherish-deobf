package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.misc.何树友树何何何树何何;
import cn.cool.cherish.module.impl.misc.树树何树友何何何何树;
import cn.cool.cherish.ui.友树何友何友何树树树;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import cn.lzq.injection.asm.invoked.render.RenderNamePlateEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.scores.Team;
import org.joml.Vector3f;

public class 树何何友何树树友友树 extends Module implements 何树友 {
   private final ModeValue 何树何何友何何友友树 = new ModeValue("Mode", "模式", new String[]{"Modern", "Simple"}, "Modern");
   private final BooleanValue 树友何何友树何友树何 = new BooleanValue("Special Items", "特殊物品检测", true);
   private final BooleanValue 友何树友何友何树树友 = new BooleanValue("Team Color", "队伍颜色", true);
   private final BooleanValue 友何何友树友树何树树 = new BooleanValue("Armor", "装备显示", true);
   private final BooleanValue 何友友友树友树友友树 = new BooleanValue("Show Enchants", "显示附魔", true);
   private final BooleanValue 树友树树树何友友树树 = new BooleanValue("Show Distance", "显示距离", true);
   private final BooleanValue 友友友友树树友何何树 = new BooleanValue("Show Health", "显示血量", true);
   private final BooleanValue 树何何何友友何何树友 = new BooleanValue("Adaptive Scale", "自适应缩放", true);
   private static final DecimalFormat 友树友友树友树何树何;
   private static final Map<String, String> 何友何友树何友何树树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[45];
   private static final String[] k = new String[45];
   private static String LIU_YA_FENG;

   public 树何何友何树树友友树() {
      super("NameTags", "名称标签", 树何友友何树友友何何.友友树树何友树树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-1127850462353198434L, 6190502328680253625L, MethodHandles.lookup().lookupClass()).a(202836760375675L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(14137623025965L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[57];
      int var5 = 0;
      String var4 = "8_oN\u0018Ù\u008dEve%×0¿\u001c\u008ba3×v:Ä\u0015Ø\u0016\u0013¦^À\u009aÅeéT%\u0017çC÷ª Ú\u008ctu\u009fÏs\u0082@ÆEüÕü\t¨g\u009a\u0007\\\u0083Ï\u0086\u0080I$\u0083\u001f*i`³\u0010\u0088[0\u009f$©Ã\u009cR8\u001e#\u000f4É\u0011\u0010é\u0005ð±Â\u000bµ(68\u0002\u009bÊ\u0088ié\u0010qH\u001a~ßÃ\u0090}i&A\u0001qÈuw\u0010\u008a¸É\u0085'¯8WPú\u0086\u008f\u0084D(Ò ¯\u0011ó÷øk³U¶\u009e;Ï\u008c\u0092\u009aô6¹`Z\"×ö)í\u0098ñ\u001eÍ£\u0099C\u0018ó:\u001f\u000eÛ\u0082ë¤:d\u0094+3ü;5¯ÜZ\u0093[\u0098@\u0091\u0010õ\u0084j\u001cÎAÓZì¢i²\u008c j¥\u0010-`g\u0092VoGßñ¦\u001ad\u00904ÊU\u0018¯_Q\b\u0089>\u009eU±OÉ\u0007áÐ¹¡}K|*\u0017Ý\u001b® «¿\u0082A]6À\u008fKt\u009a\u0001ü\u0005«²Ç0ú\u00026¸1\u001e¹\u0098¿;,´\u0099\u0086 ð±¼p\u001cÿ?m\u0087m~b#=rÊBV_ÝË\u0011`ñëÒ\fºV¦¥Ñ\u0010\\\u0001\u00140\tC\u0085Ë2\u009dÃóîû'\u0090 _¹ìT¼\u008dÔ·\u0012pB\u007fÔ\u0004Q\u001dm¯\u001d$\u0098\u009fBý°\u0085Þ9¼ë\u009f<\u00101³íJ£V÷\u0084Ü1¾\u0016©»\u009ce \u0011×Ú6õ¯©µå×P<ZY\u009c;\u008e÷oÖÅÿ&?ÿii\u008fõ\\U% \u009e\u008a`\u0083´^\b\fÅ\u0007\u008búþ\u0083ûü¹àðÜ\u0002#\"Aíüs\u008c8I¸ã(wU\u0097½Nl|Sç\u0012&ÏÝ\u0084$\u0089jpö\u0094\fæä\u008a\u0087ÊÕ\u001f\u000f\u009fJ\u008a»\u0080ë \u0019&\u0088\u0011\u0010úÇ$¤\u009f¦¼\u0080\nÚ\u0097¥~m\u001f\u0087\u0010w\u0005_\u001a[sôæ¦gI\\zþ\f\u0002\u0010))\\\u0083±êqi&dÎXðGÚ¶0\u009cO[\u009dÉ\u0016ì\u008b\u008c0±w\u009a\u009a\u0005gÿl\u009bÖ]b¤\u0084½\u0006<c?4\u0096r«\u0017XÉú\u0013©×¸\"\u0019Mto\u0015a\u0010p\u0089\u009e,¤\u0097V\u0091\u0087\u0087TÎ\u0004\r\u0001ý\u0018I\u0099þ,\u0012\tÇÄ§øEús\u0082Ï\u0089\u009a\u0013h0q¦Lø\u0010è½\u0016Û¦÷}\r\u0010\u0094öÅ\u001cÍ¼a\u0010Jì2Þy£J±è\u0012@\u000fbÜ\u0007M\u00102\u008d\u0010m\u0086\n\u0080Ø\u00122\u0007\u008eâz¡¶ Ì°\u001a\u0019VWy;¨hJm÷0÷Ú\u008f«È%ùkÄcÈ\u0090Ñ:\u0097\u001f\u0010\u0090 Cväû/Þ¸¼¬>B®Û1Í¡&I¼\u008fy\u0092\u0086à\u0086\u0001\fÅæ\u0012m\u0014 O\u0080èkßÅ3\u0013/í\u0091Ògýâh\u0092émï½©ÿ\u0000\u0099:Ø®@¼»Ð\u0010Û|\u0094¸×\u001cü\u0010\u0005*óÍ\u007f\u0083ÛL\u0010\u001c\u001e}pÕè.h\"\u000f\u000bÏ¦\u008d\u00adV\u0010ó4üU2\u0002õs\u0085æ1\u0084¡ZE-\u0010ÛA[P#s×ü¡\t\"we\u0012H \u0010¶Ëþ~{/\u001b{¤õ\u0010ÕöT>\u008f B\u000eþnX_(Ûýø\u001d/¾\u0005Ü\u0099àü?LíwçÛ\u0001¹³£\u0094þ«\u0080\u0018\u0081MKYBánª\u0084°«\u000bMÅ\u0098\u009d\u009e¼`v§²¹\u0082\u0010\u0016)\u0095Í×\u0092dÇæÞ'-ãÆ>Û ¤ì\u0010o½\u001cóÜT\u001d\u009f\u009a÷g\u008eóó\u000bKö\u0094,iÂp\u0017î\u009bZ\u0002Û\u009d\u0010)ü\u0083\u008dãe(±\u001cXieK^^\u008a äsWé\ff\u0089Jr\u009cû,\u0097½ÑïÁù\u00ad÷LNLNZ\u0003©E\u000e©7² \u0099\"zÕ²\u0002çó-d»¬u\u0017Ê8\u0001K}0É\u0011=§\u0089\u0083\u0081ªôÅa} ÓQ\u0085ßiI4¤L6\u000flc\u001bÚå/\u0018jü_HûÎ\u000eGõç\u0094ë\u008cç\u0018\u0001³\u0013%ÎjÊ÷í^Nh\u0019¢ü\u0080,y\u008f\u0002\u0007\rc\n\u0010\u0013é\u0089Ù*Öz\u00adÉw©\u0084\\)\u009ag\u0010\u00996³\u008fålxR_é²ÃvHO\n\u0010ù\u001dOåÌ\u0082ÖË³ÙöÅêYÌ¾ ½\u0082¤\u0091Ù$t\\\u00ad\u0003R\u0082ÊE\u0002Ö\u0097t¸;4\u001dïÎúmi{\u0082\u0006ßå ß\u0087ôÅ\u0090\u00adW\u0099÷F\u0005Qÿ\u009cB¯æV\u0007µ4\u0093ÂÒ)\u009aR\u001a&6Yr $Ob\fq®&C¹ ¬9Èðë\u001b±yý\bû¨a}¤\u008d\u008aCÆø¢\" Ê\u0080ÜBøæ\u009dù¬\u0014\u008b\u0010Üx\u00973f\u001b¦¬ÿWLç>v%qÅ®7S\u0010§\u0099eÕÎ\u009d1\u001bºCå\u0003ø\"à[\u0010wIñ,+\u0019\u007fý%^\u0088¦Q\u008eäþ\u0018°;2ÓQõ\u0013eºØ\u0005|\u0093r¤\u0010ÖÑl\u0018F» \u008c";
      short var6 = 1366;
      char var3 = '(';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = c(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     c = var7;
                     h = new String[57];
                     友树友友树友树何树何 = new DecimalFormat("##0.0", DecimalFormatSymbols.getInstance(Locale.ENGLISH));
                     何友何友树何友何树树 = Map.of(
                        "protection",
                        "Prot",
                        "fire_protection",
                        "FireP",
                        "feather_falling",
                        "FallP",
                        "blast_protection",
                        "BlastP",
                        "sharpness",
                        "Sharp",
                        "unbreaking",
                        "Unb",
                        "efficiency",
                        "Eff",
                        "fortune",
                        "Fort",
                        "looting",
                        "Loot",
                        "mending",
                        "Mend"
                     );
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "!§º\u0094fX©¿àÀ&NñÓ¸\rµ\u009epdÔ\u008dÍ\u001e³Ë§\u009d¹\u0000\u0082l\u0010 \u0010\u009eI: ¤òöJ\u009bï%\u0003y\u001e";
                  var6 = 49;
                  var3 = ' ';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   private Color Z(Entity entity) {
      BetterCamera.e();
      if (entity instanceof LivingEntity) {
         ;
      }

      return Color.WHITE;
   }

   private void e(Render2DEvent event, Player player) {
      c<"ö">(1122827759761073860L, 21487871922077L);
      友树何友何友何树树树 fm = Cherish.instance.t();
      PoseStack poseStack = event.guiGraphics().pose();
      String name = this.p(player);
      String health = c<"E">(this, 1123695916437691870L, 21487871922077L).getValue()
         ? c<"¥">(1123009257367296513L, 21487871922077L).format(player.getHealth()) + ""
         : "";
      String distance = c<"E">(this, 1124466524033723950L, 21487871922077L).getValue()
         ? "[" + c<"¥">(1123009257367296513L, 21487871922077L).format(mc.player.distanceTo(player)) + "m]"
         : "";
      float maxWidth = Math.max(fm.H(24).D(name), Math.max(fm.H(16).D(health), fm.H(16).D(distance)));
      float totalWidth = maxWidth + 10.0F;
      float totalHeight = fm.H(24).x()
         + 10
         + (c<"E">(this, 1123695916437691870L, 21487871922077L).getValue() ? fm.H(16).x() + 2 : 0)
         + (c<"E">(this, 1124466524033723950L, 21487871922077L).getValue() ? fm.H(16).x() + 2 : 0);
      RenderUtils.e(poseStack, 113327438168044L, -totalWidth / 2.0F, -totalHeight - 1.0F, totalWidth / 2.0F, 0.0, 4.0, 100.0, new Color(20, 20, 20, 180));
      if (c<"E">(this, 1123695916437691870L, 21487871922077L).getValue()) {
         float healthPercent = player.getHealth() / player.getMaxHealth();
         RenderUtils.drawRectangle(poseStack, -totalWidth / 2.0F + 3.0F, -2.0F, (totalWidth - 6.0F) * healthPercent, 1.0F, this.G(player.getHealth()).getRGB());
      }

      float y = -totalHeight + 5.0F;
      fm.H(24).q(poseStack, name, -totalWidth / 2.0F + 5.0F, y, this.Z(player).getRGB());
      if (c<"E">(this, 1123695916437691870L, 21487871922077L).getValue()) {
         y += fm.H(24).x() + 2;
         fm.H(16).q(poseStack, health, -totalWidth / 2.0F + 5.0F, y, this.G(player.getHealth()).getRGB());
      }

      if (c<"E">(this, 1124466524033723950L, 21487871922077L).getValue()) {
         y += fm.H(16).x() + 2;
         fm.H(16)
            .B(
               poseStack,
               distance,
               -totalWidth / 2.0F + 5.0F,
               y + (!c<"E">(this, 1123695916437691870L, 21487871922077L).getValue() ? 5.0 : 0.5),
               c<"¥">(1122933621364096949L, 21487871922077L).getRGB()
            );
      }

      if (c<"E">(this, 1123903975175204005L, 21487871922077L).getValue()) {
         this.f(event, player, totalHeight - this.q());
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 39;
               case 1 -> 40;
               case 2 -> 27;
               case 3 -> 61;
               case 4 -> 8;
               case 5 -> 5;
               case 6 -> 48;
               case 7 -> 50;
               case 8 -> 21;
               case 9 -> 7;
               case 10 -> 60;
               case 11 -> 17;
               case 12 -> 32;
               case 13 -> 13;
               case 14 -> 53;
               case 15 -> 24;
               case 16 -> 25;
               case 17 -> 59;
               case 18 -> 30;
               case 19 -> 3;
               case 20 -> 29;
               case 21 -> 55;
               case 22 -> 58;
               case 23 -> 28;
               case 24 -> 23;
               case 25 -> 19;
               case 26 -> 16;
               case 27 -> 57;
               case 28 -> 54;
               case 29 -> 49;
               case 30 -> 35;
               case 31 -> 62;
               case 32 -> 10;
               case 33 -> 12;
               case 34 -> 63;
               case 35 -> 18;
               case 36 -> 2;
               case 37 -> 52;
               case 38 -> 14;
               case 39 -> 51;
               case 40 -> 33;
               case 41 -> 11;
               case 42 -> 41;
               case 43 -> 42;
               case 44 -> 44;
               case 45 -> 56;
               case 46 -> 34;
               case 47 -> 36;
               case 48 -> 31;
               case 49 -> 38;
               case 50 -> 0;
               case 51 -> 9;
               case 52 -> 20;
               case 53 -> 37;
               case 54 -> 15;
               case 55 -> 4;
               case 56 -> 47;
               case 57 -> 1;
               case 58 -> 45;
               case 59 -> 43;
               case 60 -> 46;
               case 61 -> 22;
               case 62 -> 6;
               default -> 26;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树何何友何树树友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29817;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树何何友何树树友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[]Ékñ\u009e\u008dDÌJ¨µ=²!\u0002\u000b(\u0007¢\bs\u0014\u008b¾, F\u009d®<²\bÃÿå\u001d\u008f\u009bì¶1h, \u0087\u0012¦GûÚªë, \u0080}¤$WÓ©\u009f, ù\u0010\u001fq\u0017L\u0090\u0018, 4FBÏ\\@\u008fò, \u0007{w\u0095y\u0094\u009e\u0098%ïË¶<ójV, \u009dPD\u0081ûHhQñØ7\u0019G[1ü, 36\u0011\u009cQåj\u000e, ¹7\u008c×,\u0015,\u0098, Z\u00041\u0090\u001f\u0088wlt\u0081³êX¼\b£, (ÕHKÇJ¤\u0091ö\u0003\u009c\u0006\u0000ý0\b, ¹\u0005Ïí']>®ÿKªÒ\u0086'")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private Vector3f x(Player player, float partialTick) {
      double x = Mth.lerp(partialTick, player.xo, player.getX());
      double y = Mth.lerp(partialTick, player.yo, player.getY()) + player.getBbHeight() + 0.5;
      double z = Mth.lerp(partialTick, player.zo, player.getZ());
      return 友友何何友友树何何友.Q(59240626163826L, (float)x, (float)y, (float)z, (float)mc.getWindow().getGuiScale());
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'E' && var8 != 'n' && var8 != 165 && var8 != 197) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 234) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 246) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'E') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'n') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 165) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树何何友何树树友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private void f(Render2DEvent event, Player player, float yOffset) {
      BetterCamera.e();
      List equipment = this.t(player);
      if (!equipment.isEmpty()) {
         GuiGraphics graphics = event.guiGraphics();
         PoseStack poseStack = graphics.pose();
         float boxWidth = equipment.size() * 16 + 8;
         float boxX = -boxWidth / 2.0F;
         RenderUtils.e(poseStack, 113327438168044L, boxX, yOffset, boxX + boxWidth, yOffset + 24.0F, 4.0, 100.0, new Color(20, 20, 20, 180));
         int i = 0;
         if (0 < equipment.size()) {
            ItemStack stack = (ItemStack)equipment.get(0);
            if (event.side() == Event.Side.POST) {
               graphics.renderItem(stack, (int)(boxX + 4.0F + 0.0F), (int)(yOffset + 4.0F));
               graphics.renderItemDecorations(mc.font, stack, (int)(boxX + 4.0F + 0.0F), (int)(yOffset + 4.0F));
            }

            if (this.何友友友树友树友友树.getValue()) {
               this.P(graphics, stack, boxX + 4.0F + 0.0F, yOffset - 8.0F);
            }

            i++;
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "+j|\u0015\u00107$*1\u001e\u001a*!w:X\u00127,q>\u0013Q1%t>X\r=&`7\u0004Q\u001a-p&\u0013\r\u001b)i7\u0004\u001e";
      j[1] = "0Um8\u001ea;Z|wcy(]u>";
      j[2] = "^*\u0019ZHnQjTQBsT7_\u0017JnY1[\\\thP4[\u0017UdS RK\t栐佨休叼佬栶栐叶厏栦";
      j[3] = "Ye\u001f NuRj\u000eo2l]p\u0000,\u0005\\Kg\f1\u0014p\\j";
      j[4] = "y\u0013\"\u0006\u0010\u0005vSo\r\u001a\u0018s\u000edK\t\u000bv\biK\u0016\u0007j\u0011\"(\u0010\u000e\u007f+m\t\n\u000f";
      j[5] = "\u0016a~[v\u0017\u0019!3P|\n\u001c|8\u0016o\u0019\u0019z5\u0016p\u0015\u0005c~zv\u0017\u0019j1VO\u0019\u0019z5";
      j[6] = "l\"\u007f\u0003\u001a:r*eLy.v";
      j[7] = "VRr=4/Y\u0012?6>2\\O4p6/QI0;u)XL0p)%[X9,u桑你佩厗伋桊桑叾号桍z厐伕你号桍伋桊伕叾号";
      j[8] = "IW";
      j[9] = "\u007f2a1^hpr,:Tuu/'|Dsu0<|Cbr8* \u001f佒栍厗厄桃栠双佉桍会";
      j[10] = "\u001e\u0004.\u000eyZ\u0011\u001d,A\u0013K\u0017\f5\u000e;h\u001b\u00175\u000e#";
      j[11] = "t9k\u0004dY{y&\u000fnD~$-IfYs\")\u0002%栧佂厜厎伲栚叽叜伂伐";
      j[12] = "HA?G\u0007\bUTgeF\u0005MR";
      j[13] = "W]\u0010/ ]W]\u0007s,RM\u0016\u0013n?X]\u0016\u0001o9]MAJq!U@]\u0016/\u001dXXA\u0001s";
      j[14] = double.class;
      k[14] = "java/lang/Double";
      j[15] = "\r-5x/#\u0002mxs%>\u00070s5%:\u000b-o5%:\u000b-ohn\t\u0018&uod\u001f\u0007'~";
      j[16] = "C\u001e0\u0017\"\u0017C\u001e'K.\u0018YU'U&\u001bC\u000fjt&\u0010H\u00186X)\n";
      j[17] = "Bm5k%jBm\"7)eX&\")!fB|o\"=j\u0002N.+<";
      j[18] = "#5*+my,ug gd)(lfoy$.h-,\u007f-+hfo\u007f38*伝栓叝桑伎佑伝栓佃伕";
      j[19] = "/i\u0016qpB$f\u0007>\u0011L/m\u0003d";
      j[20] = "X'\rM\u001b~\bj\b\u0019g叅厢厙厷桥桾叅似伇桭|\\g\u001f3L\u0016Yf\u0019$";
      j[21] = "kgZ\u001b)\u00159wI\u0016\u0019伯桌佚佮桾佄桫桌栞株g%\u0012<<\b\u001b#Cn9";
      j[22] = "Rv\u0003/]z\u0002;\u0006{!叁伶栒厹佃叢佟桲栒厹\u001e\u001ac\u0015bBt\u001fb\u0013u";
      j[23] = "P\u001c3\r4B\u0000Q6YH叹伴似厉栥压栣伴桸桓<s[\u0017\brVvZ\u0011\u001f";
      j[24] = " \\(ST7p\u0011-\u0007(&\u0019\u001b3\u0006E+\u007f\\o\u000eIO#C5\u000fL)d\u001f=\u0003(";
      j[25] = "\u0016\u001f9?56\u0003\u0005~p\\\u00018![A5<A\u0004n. &\u0006K";
      j[26] = ".\u0018\u000e)k\u001de\u0012I&\n\bHMGh7[HtG%`\u001ef\u001f\u0017)h\u0003";
      j[27] = "5:\u0000KQ\u0011~0GD0\u0004SoI\n\rTSVIGZ\u0012}=\u0019KR\u000f";
      j[28] = "\t*I0n+YgLd\u0012伎栩伊佭参住伎右厔栩\u0001((S6Z<p9H+";
      j[29] = "vb\u0010hS>&/\u0015</伛厌佂厪桀佲厅伒栆桰Y\u0013&&$R%\u0015wt!";
      j[30] = "D(W\u000fy:\u0014eR[\u0005桛传伈佳叽叆伟传桌叭>>#\u0003<\u0016T;\"\u0005+";
      j[31] = "EGZCI]\u0015\n_\u00175格县栣栺桫佨另县栣栺r\u000eD\u0002S\u001b\u0018\u000bE\u0004D";
      j[32] = "\u0012\u001fV\bYGIZ\u000f2O9QB\u000f\u000fNCCIQ2";
      j[33] = "\u0019)Um:aN*PxEYh\u001d/\\\u0012Rs\u001b>\u0000uf\u0013?\u0010|\"e\u0016*";
      j[34] = "4\u007f)]v\u0003d2,\t\n厸栔叁厓桵叉桢佐栛伍l5Fuso]r\u001d4o";
      j[35] = "K\u0016\u0017H?v\u001b[\u0012\u001cC体厱厨厭桠厀栗厱厨桷yxo\f\u0002V\u0013}n\n\u0015";
      j[36] = "\u0005\u0014\u0006\u0013b7UY\u0003G\u001e桖叿伴伢叡标伒叿桰伢\"%.B\u0000GH /D\u0017";
      j[37] = "\u001b\u001cGE4HP\u0016\u0000JU]}I\u000e\u0004h\u000f}p\u000eI?KS\u001b^E7V";
      j[38] = "lm\u0012__Q6(\u0007[=栧栞低伿佾你叽叄叐伿#V@wo\u0000L\f\u0005bk";
      j[39] = "\u001c]i-\u0007TNMz 7株叡你佝伌栮佮栻叾參Q\u000bSK\u0006;-\r\u0002\u0019\u0003";
      j[40] = "g6rD\u0019.`!'\u001c}伌桂厅变厺桤伌桂伛变y@)d}%\u0000A7;\u007f";
      j[41] = "JPG{\u001bR\u001dSBndq:j![d\u001e\u0001\u0011\u0010i\u0018I\u0002\u0014\u0005";
      j[42] = "Q\u0011!0\u000e'\u0003\u00012=>厃桶厲伕厏叽厃伲伬压L\u0002 \u0006Js0\u0004qTO";
      j[43] = "\n4\u001f\u001bcv\u0004?\u0018YRc7iB\u001cl77X\u0011T;l\u001ddAE>l";
      j[44] = "_\u001dolgG\u0004X;s\u001b叺厣桾栙作变栠桹厤栙\u0001$C\u000f\n|\u007f\u007f\u0006[\u0015";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private Color m(Component component) {
      BetterCamera.e();
      if (component.getStyle().getColor() != null) {
         return new Color(component.getStyle().getColor().getValue());
      } else {
         String text = component.getString();
         if (text.length() < 2) {
            return null;
         } else {
            int i = 0;
            if (0 < text.length() - 1) {
               if (text.charAt(0) == 167) {
                  String colorCode = String.valueOf(text.charAt(1)).toLowerCase();
                  if (何树友友树树友何树何.友树友何友友友何何友.containsKey(colorCode)) {
                     return 何树友友树树友何树何.友树友何友友友何何友.get(colorCode);
                  }
               }

               i++;
            }

            return null;
         }
      }
   }

   private String p(Player player) {
      BetterCamera.e();
      StringBuilder name = new StringBuilder();
      if (树树何树友何何何何树.m(player)) {
         name.append("§5(杀手)§r ");
      }

      if (树树何树友何何何何树.O(player)) {
         name.append("§9(侦探)§r ");
      }

      if (this.树友何何友树何友树何.getValue()) {
         if (树树何树友何何何何树.Z(player)) {
            name.append("§e(斧)§r ");
         }

         if (树树何树友何何何何树.W(player)) {
            name.append("§6(图腾)§r ");
         }

         if (树树何树友何何何何树.Y(player)) {
            name.append("§a(击退)§r ");
         }

         if (树树何树友何何何何树.P(player)) {
            name.append("§c(火焰弹)§r ");
         }

         if (树树何树友何何何何树.p(player)) {
            name.append("§7(弩)§r ");
         }
      }

      String teamColorCode = 何树友友树树友何树何.何树何何树何树树树树.getOrDefault(this.Z(player), "§f");
      name.append(teamColorCode).append(player.getName().getString()).append("§r");
      return name.toString();
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @EventTarget
   public void k(RenderNamePlateEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (event.getEntity() instanceof Player) {
            event.setCancelled(true);
         }
      }
   }

   private List<ItemStack> t(Player player) {
      BetterCamera.e();
      List<ItemStack> equipment = new ArrayList<>();
      Iterator var6 = player.getArmorSlots().iterator();
      if (var6.hasNext()) {
         ItemStack item = (ItemStack)var6.next();
         equipment.add(0, item);
      }

      equipment.add(player.getMainHandItem());
      equipment.add(player.getOffhandItem());
      equipment.removeIf(ItemStack::isEmpty);
      return equipment;
   }

   private Color g(LivingEntity entity) {
      BetterCamera.e();
      Color componentColor = this.m(entity.getDisplayName());
      if (componentColor != null) {
         return componentColor;
      } else {
         if (entity instanceof Player player) {
            Team team = player.getTeam();
            if (team != null && team.getColor().getColor() != null) {
               return new Color(team.getColor().getColor());
            }

            if (何树友树何何何树何何.树树何何何何友友友何 != null && 何树友树何何何树何何.树树何何何何友友友何.isEnabled()) {
               String teamColorName = 何树友树何何何树何何.树树何何何何友友友何.m(player);
               return 何树友友树树友何树何.树友何何何树何树友友.get(teamColorName != null ? teamColorName.toLowerCase() : null);
            }
         }

         return null;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private int q() {
      BetterCamera.e();
      if (!this.树友树树树何友友树树.getValue() && !this.友友友友树树友何何树.getValue()) {
         return 70;
      } else {
         return this.树友树树树何友友树树.getValue() && this.友友友友树树友何何树.getValue() ? 106 : 88;
      }
   }

   private void w(Render2DEvent event, Player player) {
      友树何友何友何树树树 fm = Cherish.instance.t();
      BetterCamera.e();
      PoseStack poseStack = event.guiGraphics().pose();
      StringBuilder text = new StringBuilder(this.p(player));
      if (this.树友树树树何友友树树.getValue()) {
         text.append("[").append(友树友友树友树何树何.format(mc.player.distanceTo(player))).append("m]");
      }

      if (this.友友友友树树友何何树.getValue()) {
         text.append(" [").append(友树友友树友树何树何.format(player.getHealth())).append("HP]");
      }

      String fullText = text.toString();
      float width = fm.H(20).D(fullText);
      float height = fm.H(20).x();
      RenderUtils.e(
         poseStack,
         113327438168044L,
         -width / 2.0F - 5.0F,
         -height / 2.0F - 8.0F,
         width / 2.0F + 5.0F,
         height / 2.0F - 2.0F,
         4.0,
         100.0,
         new Color(20, 20, 20, 180)
      );
      fm.H(20).q(poseStack, fullText, -width / 2.0F, -height, this.Z(player).getRGB());
      if (this.友何何友树友树何树树.getValue()) {
         this.f(event, player, height / 2.0F - 44.0F);
      }
   }

   @EventTarget
   public void r(Render2DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && mc.level != null) {
         for (Player player : mc.level.players()) {
            if (!this.R(player)) {
               Vector3f pos = this.x(player, event.partialTick());
               this.W(event, player, pos);
               break;
            }
         }
      }
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   @EventTarget
   public void Y(Render3DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         switch (树何何友何树树友友树$友何何友树何树何友友.何树友友友树何树何友[event.side().ordinal()]) {
            case 1:
               友友何何友友树何何友.m(47731723453557L, event.poseStack());
            case 2:
               友友何何友友树何何友.U(116571643732856L);
         }
      }
   }

   private void P(GuiGraphics graphics, ItemStack stack, float x, float y) {
      BetterCamera.e();
      Map enchants = EnchantmentHelper.getEnchantments(stack);
      if (!enchants.isEmpty()) {
         友树何友何友何树树树 fm = Cherish.instance.t();
         PoseStack poseStack = graphics.pose();
         Iterator var12 = enchants.entrySet().iterator();
         if (var12.hasNext()) {
            Entry<Enchantment, Integer> entry = (Entry<Enchantment, Integer>)var12.next();
            String name = entry.getKey().getDescriptionId();
            String shortName = name.substring(name.lastIndexOf(".") + 1);
            String text = 何友何友树何友何树树.getOrDefault(shortName, shortName.substring(0, Math.min(4, shortName.length()))) + " " + entry.getValue();
            poseStack.pushPose();
            poseStack.translate(0.0F, 0.0F, 50.0F);
            fm.H(10).s(poseStack, text, x + 8.0F - fm.H(10).D(text) / 2, y + 0.0F, new Color(118, 4, 239, 181).getRGB());
            poseStack.popPose();
         }
      }
   }

   private void W(Render2DEvent event, Player player, Vector3f screenPos) {
      BetterCamera.e();
      PoseStack poseStack = event.poseStack();
      poseStack.pushPose();
      poseStack.translate(screenPos.x(), screenPos.y(), 0.0F);
      if (this.树何何何友友何何树友.getValue()) {
         float scale = Math.max(0.6F, Math.min(1.0F, 10.0F / mc.player.distanceTo(player)));
         poseStack.scale(scale, scale, 1.0F);
      }

      if ("Modern".equals(this.何树何何友何何友友树.getValue())) {
         this.e(event, player);
      }

      this.w(event, player);
      poseStack.popPose();
   }

   private boolean R(Player player) {
      BetterCamera.e();
      return player == mc.player || !player.isAlive() || player.isSpectator() || player.isInvisibleTo(mc.player) || mc.player.distanceTo(player) > 128.0F;
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖230622200409390090";
   }

   private Color G(float health) {
      float percent = health / 20.0F;

      return switch ((int)(percent * 4.0F)) {
         case 1 -> new Color(255, 165, 0);
         case 2 -> new Color(255, 255, 85);
         case 3, 4 -> new Color(85, 255, 85);
         default -> new Color(255, 85, 85);
      };
   }
}
