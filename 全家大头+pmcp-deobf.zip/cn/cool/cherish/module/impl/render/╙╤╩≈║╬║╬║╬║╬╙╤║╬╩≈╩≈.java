package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.client.树友何何何树何树友友;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import why.tree.friend.antileak.Fucker;

public class 友树何何何何友何树树 extends Module implements 何树友 {
   private final BooleanValue 友树友树何树何何何树 = new BooleanValue("Chest", "箱子", true);
   private final BooleanValue 树树何树树树何树树友 = new BooleanValue("Bed", "床", true);
   private final BooleanValue 友何树友何友友友何何 = new BooleanValue("CryingObsidian", "哭泣黑曜石", true).A(() -> {
      BetterCamera.e();
      return (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta;
   });
   private final NumberValue 树树友树何友何何树友 = new NumberValue("Chunks", "区块数量", 12, 1, 32, 1);
   private final BooleanValue 友树树友友友树树树何 = new BooleanValue("Fill", "填充", true);
   private final BooleanValue 树树何树何何何何树树 = new BooleanValue("Outline", "轮廓", true);
   private final Set<BlockPos> 何何友友友何何友何友 = new HashSet<>();
   private final Map<BlockPos, BlockState> 树友何树树树友友友树 = new ConcurrentHashMap<>();
   private Timer 何何树树树树友树友何;
   private int 友何友友何友友树何友 = Integer.MAX_VALUE;
   private int 何友何友树树树树何友 = Integer.MAX_VALUE;
   private int 友树树何友何树友友何 = 0;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final long m;
   private static final Object[] n = new Object[33];
   private static final String[] o = new String[33];
   private static int _何树友，和树做朋友 _;

   public 友树何何何何友何树树() {
      super("BlockESP", "方块透视", 树何友友何树友友何何.友友树树何友树树友树);
      this.u();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3369778645734257743L, -1052152753176796293L, MethodHandles.lookup().lookupClass()).a(259081811299469L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var18;
      Cipher var28 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(2873886785054L << var19 * 8 >>> 56);
      }

      var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[14];
      int var23 = 0;
      String var22 = "¢²~*tÌ\u008e\u0007À\u009båxü\u0097\u0081\u0000\u0010H\n7!\u0094F\u0094Å\u008e>\u007fwè:+L\u0010ÊÄDÙÌÑª³Ýu£iù\u009f X\u0018g\u0013®]\u009dÏI\u0005ðcXÑ¹ÎÇ\u008c<ÝÈÀ¤VU4\u0018\u0011ë\u009d \u0091\u0092û&y.áY=~á\u009etf¦~\u0017Þ'æ\u0010ì\u0099U\u008a,T>1x<}\u0081\u0014^Ê3\u0010çï\u0082®ÕI-5¤ó«ªZ\u008f\u0083\u0003\u0010\u008bs#\u0087äú/Iàì[\u0084\u0085Õ°\u0002 Ì×O½\u0016ø\u000bþTPXÏ\u009cS\u0002\u0000\u0017X¸\u0010\u0094³3\u0097\u0016êâl@+\u008fç\u0010ÁÊ\u009bwàÔ¤ûe\u00adkÊ\u001b\u0017Oâ (\"$\u001be¯\u00ad\u0099Øâ·OHµµtçJ\u0014óÕöû\u0081÷å~zì.0B\u0010{ª\u008a\u0016\u000b_O\u0016¼ÿÙ³.:Xí";
      short var24 = 251;
      char var21 = 16;
      int var27 = -1;

      label56:
      while (true) {
         String var29 = var22.substring(++var27, var27 + var21);
         int var10001 = -1;

         while (true) {
            String var40 = c(var18.doFinal(var29.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var40;
                  if ((var27 += var21) >= var24) {
                     c = var25;
                     h = new String[14];
                     l = new HashMap(13);
                     Cipher var5;
                     Cipher var31 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(2873886785054L << var6 * 8 >>> 56);
                     }

                     var31.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[2];
                     int var8 = 0;
                     byte var7 = 0;

                     do {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = "N\u000fðýDsÖUû¶C\u008fkS\u0004\u008d".substring(var10001, var7).getBytes("ISO-8859-1");
                        var10001 = var8++;
                        long var13 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        byte[] var15 = var5.doFinal(
                           new byte[]{
                              (byte)(var13 >>> 56),
                              (byte)(var13 >>> 48),
                              (byte)(var13 >>> 40),
                              (byte)(var13 >>> 32),
                              (byte)(var13 >>> 24),
                              (byte)(var13 >>> 16),
                              (byte)(var13 >>> 8),
                              (byte)var13
                           }
                        );
                        long var10004 = (var15[0] & 255L) << 56
                           | (var15[1] & 255L) << 48
                           | (var15[2] & 255L) << 40
                           | (var15[3] & 255L) << 32
                           | (var15[4] & 255L) << 24
                           | (var15[5] & 255L) << 16
                           | (var15[6] & 255L) << 8
                           | var15[7] & 255L;
                        byte var47 = -1;
                        var11[var10001] = var10004;
                     } while (var7 < 16);

                     j = var11;
                     k = new Integer[2];
                     Cipher var0;
                     Cipher var32 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(2873886785054L << var1 * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{16, 84, -59, -80, 44, -74, -95, -42});
                     long var45 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     byte var38 = -1;
                     m = var45;
                     return;
                  }

                  var21 = var22.charAt(var27);
                  break;
               default:
                  var25[var23++] = var40;
                  if ((var27 += var21) < var24) {
                     var21 = var22.charAt(var27);
                     continue label56;
                  }

                  var22 = "4ÆOa\u0080ÿM\u009a¢/\rÛ6\u008a*ñ$¡\u009cÜã\u0015/|Yýäý+7SY\bjM\u001aï²»å\u0018w\u0094¶\u009a' `k<ÖUm*txá¨\u008e]KkÂ.j";
                  var24 = 65;
                  var21 = '(';
                  var27 = -1;
            }

            var29 = var22.substring(++var27, var27 + var21);
            var10001 = 0;
         }
      }
   }

   private boolean C(BlockEntity blockEntity) {
      BetterCamera.e();
      Block block = blockEntity.getBlockState().getBlock();
      return this.友树友树何树何何何树.getValue() && block instanceof ChestBlock || this.树树何树树树何树树友.getValue() && block instanceof BedBlock;
   }

   private void F(int chunkX, int chunkZ, int radius) {
      树友何何何树何树友友.G(() -> {
         ConcurrentHashMap newCryingObsidian = new ConcurrentHashMap();
         BetterCamera.e();
         int x = chunkX - radius;
         if (x <= chunkX + radius) {
            int z = chunkZ - radius;
            if (z <= chunkZ + radius) {
               try {
                  if (this.Q(new Object[]{52406761729175L})) {
                     return;
                  }

                  LevelChunk chunk = mc.level.getChunk(x, z);
                  this.U(chunk, newCryingObsidian);
               } catch (Exception var13) {
               }

               z++;
            }

            x++;
         }

         if (this.友何树友何友友友何何.P().get() && this.友何树友何友友友何何.getValue() && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
            this.树友何树树树友友友树.clear();
            this.树友何树树树友友友树.putAll(newCryingObsidian);
         }
      }, 108624793298909L);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private Color i(BlockEntity blockEntity) {
      BetterCamera.e();
      Block block = blockEntity.getBlockState().getBlock();
      if (block instanceof ChestBlock && blockEntity instanceof ChestBlockEntity chestBlock) {
         BlockPos pos = chestBlock.getBlockPos();
         float openness = chestBlock.getOpenNess(0.0F);
         if (openness > 0.0F) {
            this.何何友友友何何友何友.add(pos);
         }

         return this.何何友友友何何友何友.contains(pos) ? new Color(255, 0, 80) : new Color(80, 255, 0);
      } else {
         return block instanceof BedBlock ? new Color(255, 0, 80) : new Color(255, 255, 255);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 21;
               case 1 -> 30;
               case 2 -> 37;
               case 3 -> 38;
               case 4 -> 54;
               case 5 -> 14;
               case 6 -> 16;
               case 7 -> 20;
               case 8 -> 1;
               case 9 -> 59;
               case 10 -> 8;
               case 11 -> 0;
               case 12 -> 52;
               case 13 -> 58;
               case 14 -> 4;
               case 15 -> 2;
               case 16 -> 3;
               case 17 -> 57;
               case 18 -> 28;
               case 19 -> 24;
               case 20 -> 17;
               case 21 -> 36;
               case 22 -> 15;
               case 23 -> 27;
               case 24 -> 61;
               case 25 -> 53;
               case 26 -> 18;
               case 27 -> 62;
               case 28 -> 49;
               case 29 -> 35;
               case 30 -> 46;
               case 31 -> 5;
               case 32 -> 13;
               case 33 -> 7;
               case 34 -> 10;
               case 35 -> 60;
               case 36 -> 39;
               case 37 -> 29;
               case 38 -> 19;
               case 39 -> 51;
               case 40 -> 40;
               case 41 -> 6;
               case 42 -> 45;
               case 43 -> 23;
               case 44 -> 43;
               case 45 -> 12;
               case 46 -> 50;
               case 47 -> 33;
               case 48 -> 22;
               case 49 -> 47;
               case 50 -> 55;
               case 51 -> 41;
               case 52 -> 48;
               case 53 -> 32;
               case 54 -> 26;
               case 55 -> 11;
               case 56 -> 34;
               case 57 -> 9;
               case 58 -> 42;
               case 59 -> 44;
               case 60 -> 63;
               case 61 -> 25;
               case 62 -> 56;
               default -> 31;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何何何何友何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11568;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何何何何友何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[n\u0092\u001cx¡!\u001dr, ñÔ«ù(%û\u001a, h\u0089æh\u009dÔ$°, \u0014Ìu\u0004§\u000bÇºâC\u001e}«y\u000f\u0080, ^7q\u008eÈE°?6\"")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 229 && var8 != 255 && var8 != 'd' && var8 != 'D') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 221) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 222) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 229) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 255) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'd') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何何何何友何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 8553;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何何何何友何树树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   @Override
   public void h() {
      BetterCamera.e();
      this.何何友友友何何友何友.clear();
      this.树友何树树树友友友树.clear();
      if (this.何何树树树树友树友何 != null) {
         this.何何树树树树友树友何.cancel();
         this.何何树树树树友树友何 = null;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树何何何何友何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   @EventTarget
   public void a(WorldEvent event) {
      this.何何友友友何何友何友.clear();
      this.树友何树树树友友友树.clear();
      this.r();
   }

   private static void a() {
      n[0] = "eLW^_.j\f\u001aUU3oQ\u0011\u0013].bW\u0015X\u001e(kR\u0015\u0013B$hF\u001cO\u001e厊栗佷伬佨佥厊体栳桨";
      n[1] = "8\u0000{Rd\u0004&\ba\u001d\u001e\u0018?\u0004\u007f";
      n[2] = "(W%\u001aI!'\u0017h\u0011C<\"JcWP/'LnWO#;U%;I!'\\j\u0017p/'Ln";
      n[3] = "\u0010%Df\u0012W\u001fe\tm\u0018J\u001a8\u0002+\u0010W\u0017>\u0006`SQ\u001e;\u0006+\u000f]\u001d/\u000fwSz\u0016?\u001e`\u000f{\u0012&\u000fw\u001c";
      n[4] = "\u0006@jF1a\rO{\tLy\u001eHr@";
      n[5] = "Q\u000fCYdoO\u0007Y\u0016\u0007{K";
      n[6] = "Sb\u007f)}.Xmnf\u0016:Zfy<:-W";
      n[7] = "N\u0005Ly}PN\u0005[%q_TNO8bUDNT2f\\LN{?eWK0W$";
      n[8] = int.class;
      o[8] = "java/lang/Integer";
      n[9] = "k\u0005Se;wk\u0005D97xqNP$$raNK. {iNE'9}nNe'9}n\u0013";
      n[10] = "\u0010hIJB\u0011\u0010h^\u0016N\u001e\n#J\u000b]\u0014\u001a#Q\u0001Y\u001d\u0012#_\b@\u001b\u0015#\u007f\b@\u001b\u0015";
      n[11] = ".b+W\u000f~!\"f\\\u0005c$\u007fm\u001a\u0016p!y`\u001a\t|=`+z\u0015|/iwb\u0001}8i";
      n[12] = "1ZI;F >\u001a\u00040L=;G\u000fvD 6A\u000b=\u0007桞伇叿厬伍核厄厙佡伲";
      n[13] = "`}H]=p~uR\u0012@`~";
      n[14] = "2H\u001ce,G9G\r*MI2L\tp";
      n[15] = "\u000e3.\\|7\u0000,?=叐企桹厊伒叾叐原伽伔O\u0004w=\u0019; Wa.\u0018";
      n[16] = "PD\u0017S\u00042^[\u00062厨桀栧叽厵叱桲桀栧佣v\u000b\u000f8GL\u0019X\u0019+F";
      n[17] = "\u0006\u00124&\u001c=\u0004\u0002f%xo<P6o\u0005nZS$a\u0018\u0002";
      n[18] = "2f5?XMmpe,6\u001dX03c\tBX\f39\u000e\bfpm!F\u0016";
      n[19] = "#\nHpYM-\u0015Y\u0011栯栿伐桩佴佌佫佻桔桩)(RG4\u0002F{DT5";
      n[20] = "-\t\u0001K4D#\u0016\u0010*伆佲桚桪桹栳厘栶厀伮`\u0013b\u0010z\u000e\u001aAd\u0010<";
      n[21] = "ill\u0006>\u0010gs}g案桢叄栏佐厤伌伦栞叕\rWj\u00156f`^+\u0006e";
      n[22] = "\u0010*\u0012\tfI\u001e5\u0003h及栻桧伍厰伵栐叡厽伍sUn\u001a\u00059\u000f\u000bvR\u001b";
      n[23] = "v/,(4\u0001x0=I桂桳佅桌桔桐伆桳栁厖Mp?\u000ba'\"#)\u0018`";
      n[24] = "a\u00055\u0002\u001d+o\u001a$c厱桙双桦伉桺伯伝佒桦TZ\u0016!v\r;\t\u00002w";
      n[25] = "\u001cL)2\u0017*CZy!yzv\u001a/nF$v&/4AoHZq,\tq";
      n[26] = "pl`\u0017\u0003k~sqv伱參佃叕栘桯桵栙佃叕\u0001K\u000b8e\u007f}\u0015\u0013p{";
      n[27] = "M:/*p;O%v-J1${'jpd$F 56$Lxul!c";
      n[28] = "(~\nwTg&a\u001b\u0016佦佑厅叇厨佋佦叏伛叇k'\u0003b(d\u001a|\u00036~";
      n[29] = "_'b\u001d:RQ8s|桌叺佬桄栚桥厖叺史桄\u0003G3F\n#b@<BK";
      n[30] = "\u001eCL,q,\u0010\\]MwGLD\u0010|u&\u0016TF/\u001e{\r\u0004\u001c&\u007f!\u001dROM";
      n[31] = "*z=s2\u000f||&#J号叙栄桘休厉栭栃叞桘LzSf\"9w,U}r";
      n[32] = "B=]B:]L\"L#厖佫可厄佡叠厖栯佱厄<\u001e2\u000eW.@@*FI";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void v() {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         树友何何何树何树友友.G(() -> {
            BetterCamera.e();
            if (this.友何树友何友友友何何.P().get() && this.友何树友何友友友何何.getValue() && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
               this.树友何树树树友友友树.entrySet().removeIf(entry -> mc.level.getBlockState(entry.getKey()).getBlock() != Blocks.CRYING_OBSIDIAN);
            }
         }, 108624793298909L);
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void U(LevelChunk chunk, Map<BlockPos, BlockState> cryingObsidianPos) {
      int chunkX = chunk.getPos().x * 16;
      BetterCamera.e();
      int chunkZ = chunk.getPos().z * 16;
      int minY = mc.level.getMinBuildHeight();
      int maxY = mc.level.getMaxBuildHeight();
      if (minY < maxY) {
         int x = 0;
         int z = 0;
         BlockPos pos = new BlockPos(chunkX + 0, minY, chunkZ + 0);
         BlockState state = chunk.getBlockState(pos);
         Block block = state.getBlock();
         if (this.友何树友何友友友何何.P().get() && this.友何树友何友友友何何.getValue() && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta && block == Blocks.CRYING_OBSIDIAN) {
            cryingObsidianPos.put(pos, state);
         }

         z++;
         x++;
         int y = minY + 1;
      }
   }

   private void u() {
      this.何何树树树树友树友何 = new Timer("BlockESP-Cleanup", true);
      this.何何树树树树友树友何.scheduleAtFixedRate(new 友树何何何何友何树树$何友树树何何何何友何(this), 0L, 50L);
   }

   private void r() {
      this.友何友友何友友树何友 = Integer.MAX_VALUE;
      this.何友何友树树树树何友 = Integer.MAX_VALUE;
      this.友树树何友何树友友何 = 0;
   }

   private void y(Render3DEvent event, int chunkX, int chunkZ, int radius) {
      BetterCamera.e();
      if (this.友树友树何树何何何树.getValue() || this.树树何树树树何树树友.getValue()) {
         int x = chunkX - Math.min(radius, 8);
         if (x <= chunkX + Math.min(radius, 8)) {
            int z = chunkZ - Math.min(radius, 8);
            if (z <= chunkZ + Math.min(radius, 8)) {
               try {
                  LevelChunk chunk = mc.level.getChunk(x, z);
                  Iterator var15 = chunk.getBlockEntities().values().iterator();
                  if (var15.hasNext()) {
                     BlockEntity blockEntity = (BlockEntity)var15.next();
                     if (this.C(blockEntity)) {
                        RenderUtils.P(
                           event.poseStack(),
                           blockEntity,
                           67929591207254L,
                           this.i(blockEntity).getRGB(),
                           this.友树树友友友树树树何.getValue(),
                           this.树树何树何何何何树树.getValue(),
                           200.0F
                        );
                     }
                  }
               } catch (Exception var17) {
               }

               z++;
            }

            x++;
         }
      }

      if (this.友何树友何友友友何何.P().get() && this.友何树友何友友友何何.getValue() && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         Iterator var19 = this.树友何树树树友友友树.entrySet().iterator();
         if (var19.hasNext()) {
            Entry<BlockPos, BlockState> entry = (Entry<BlockPos, BlockState>)var19.next();
            RenderUtils.l(
               event.poseStack(),
               entry.getKey(),
               entry.getValue(),
               new Color(152, 0, 241).getRGB(),
               this.友树树友友友树树树何.getValue(),
               this.树树何树何何何何树树.getValue(),
               43890052622549L,
               200.0F
            );
         }
      }
   }

   @Override
   public void M() {
      BetterCamera.e();
      if (this.何何树树树树友树友何 == null) {
         this.u();
      }
   }

   private static String HE_WEI_LIN() {
      return "解放村多种2队1144号";
   }

   @EventTarget
   public void O(Render3DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         int chunkX = mc.player.chunkPosition().x;
         int chunkZ = mc.player.chunkPosition().z;
         int radius = this.树树友树何友何何树友.getValue().intValue();
         if (Math.abs(chunkX - this.友何友友何友友树何友) > 0 || Math.abs(chunkZ - this.何友何友树树树树何友) > 0 || radius != this.友树树何友何树友友何) {
            this.友何友友何友友树何友 = chunkX;
            this.何友何友树树树树何友 = chunkZ;
            this.友树树何友何树友友何 = radius;
            this.F(chunkX, chunkZ, radius);
         }

         this.y(event, chunkX, chunkZ, radius);
      }
   }
}
