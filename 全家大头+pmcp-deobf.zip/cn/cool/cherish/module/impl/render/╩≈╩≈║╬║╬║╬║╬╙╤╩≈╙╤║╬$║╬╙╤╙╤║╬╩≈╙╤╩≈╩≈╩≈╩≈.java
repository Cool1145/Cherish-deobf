package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// $VF: synthetic class
class 树树何何何何友树友何$何友友何树友树树树树 implements 何树友 {
   private static final Object[] a = new Object[10];
   private static final String[] b = new String[10];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(7297883775427057045L, -564977656137540286L, MethodHandles.lookup().lookupClass()).a(105314557386180L);
      // $VF: monitorexit
      long var0 = var10000 ^ 130874360183087L;
      a();

      try {
         a<"Þ">(-2928122061473448411L, var0)[a<"Þ">(-2927752565182913973L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"Þ">(-2928122061473448411L, var0)[a<"Þ">(-2927789327922657765L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"Þ">(-2928122061473448411L, var0)[a<"Þ">(-2927897684699880801L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"Þ">(-2928122061473448411L, var0)[a<"Þ">(-2927685940508367595L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"Þ">(-2928122061473448411L, var0)[a<"Þ">(-2928057261273578864L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 237 && var8 != 219 && var8 != 222 && var8 != 196) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'i') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'K') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 237) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 219) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 222) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树树何何何何友树友何$何友友何树友树树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 1;
               case 1 -> 55;
               case 2 -> 31;
               case 3 -> 18;
               case 4 -> 25;
               case 5 -> 53;
               case 6 -> 15;
               case 7 -> 20;
               case 8 -> 34;
               case 9 -> 22;
               case 10 -> 6;
               case 11 -> 61;
               case 12 -> 47;
               case 13 -> 38;
               case 14 -> 60;
               case 15 -> 37;
               case 16 -> 2;
               case 17 -> 35;
               case 18 -> 52;
               case 19 -> 33;
               case 20 -> 7;
               case 21 -> 4;
               case 22 -> 56;
               case 23 -> 0;
               case 24 -> 14;
               case 25 -> 28;
               case 26 -> 27;
               case 27 -> 51;
               case 28 -> 12;
               case 29 -> 13;
               case 30 -> 16;
               case 31 -> 17;
               case 32 -> 42;
               case 33 -> 11;
               case 34 -> 24;
               case 35 -> 19;
               case 36 -> 5;
               case 37 -> 29;
               case 38 -> 54;
               case 39 -> 30;
               case 40 -> 44;
               case 41 -> 39;
               case 42 -> 57;
               case 43 -> 36;
               case 44 -> 49;
               case 45 -> 46;
               case 46 -> 62;
               case 47 -> 9;
               case 48 -> 41;
               case 49 -> 32;
               case 50 -> 21;
               case 51 -> 8;
               case 52 -> 43;
               case 53 -> 40;
               case 54 -> 26;
               case 55 -> 48;
               case 56 -> 63;
               case 57 -> 45;
               case 58 -> 3;
               case 59 -> 10;
               case 60 -> 58;
               case 61 -> 50;
               case 62 -> 59;
               default -> 23;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "|\\\u0014hk~s\u001cYcacvAR%i~{GVn*xrBV%vtqV_y*栀栎佧佯佞佑叚栎叹佯/叏叚叔叹佯叀栕叚栎栣";
      a[1] = "s\u001a\u0015h 5|ZXc*(y\u0007S%\"5t\u0001Wna3}\u0004W%=?~\u0010^ya桋栁伡佮佞会厑栁县佮/会厑叛伡株叀桞桋栁桥";
      a[2] = "oo";
      a[3] = "v\u0013\b8p\u0006}\u001c\u0019w\u0011\bv\u0017\u001d-";
      a[4] = "zkK<\u001fx9-LX桬佊伜佈株桁桬佊厂佈3c\u000bo%\u007f\\ Mh";
      a[5] = ",Hiv\t'o\u000en\u0012伾桑栎栯佌发厠伕栎栯\u0011)\u001d0s\\~j[7";
      a[6] = "8^AR$K{\u0018F6厍叧栚根佤叵桗栽佞根9\r0\\gJVNv[";
      a[7] = "B94\u001a]\u000e\u0001\u007f3~叴似伤桞桕伣栮厢伤桞LEI\u0019\u001d-#\u0006\u000f\u001e";
      a[8] = "i9kMG.*\u007fl)栴桘厑厄低佴叮厂伏会\u0013\u0012S96-|Q\u0015>";
      a[9] = "\u000ey<\u0012!\u0001\u001f$hv厏伹县桞桋桯休伹伡会RO)\u0003\u00156\"H-\u001b\u0005";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖黑水";
   }
}
