package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;

public class 友树友友友何树树树友 extends Module implements 何树友 {
   private final ModeValue 树树树树友友友树何何;
   private final NumberValue 树树树友树何树何友树;
   private boolean 友友树树何友何友何树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[31];
   private static final String[] k = new String[31];
   private static String LIU_YA_FENG;

   public 友树友友友何树树树友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/render/友树友友友何树树树友.a J
      // 003: ldc2_w 107125086112354
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 17220
      // 00c: ldc2_w 2736837109692150952
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 18331
      // 019: ldc2_w 6673127805649662055
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w -6429572488342326490
      // 026: lload 1
      // 027: invokedynamic Ê (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/ModeValue
      // 033: dup
      // 034: sipush 11557
      // 037: ldc2_w 3239152462062246608
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 9266
      // 044: ldc2_w 8797511577027498954
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 12
      // 050: anewarray 65
      // 053: dup
      // 054: bipush 0
      // 055: sipush 2770
      // 058: ldc2_w 3892955785260727602
      // 05b: lload 1
      // 05c: lxor
      // 05d: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 062: aastore
      // 063: dup
      // 064: bipush 1
      // 065: sipush 26892
      // 068: ldc2_w 952206864346324705
      // 06b: lload 1
      // 06c: lxor
      // 06d: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 072: aastore
      // 073: dup
      // 074: bipush 2
      // 075: sipush 17614
      // 078: ldc2_w 2837391136588739370
      // 07b: lload 1
      // 07c: lxor
      // 07d: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 082: aastore
      // 083: dup
      // 084: bipush 3
      // 085: sipush 6821
      // 088: ldc2_w 8742658650202205534
      // 08b: lload 1
      // 08c: lxor
      // 08d: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 092: aastore
      // 093: dup
      // 094: bipush 4
      // 095: sipush 17399
      // 098: ldc2_w 2148701927688156178
      // 09b: lload 1
      // 09c: lxor
      // 09d: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a2: aastore
      // 0a3: dup
      // 0a4: bipush 5
      // 0a5: sipush 32734
      // 0a8: ldc2_w 5676455347169200174
      // 0ab: lload 1
      // 0ac: lxor
      // 0ad: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b2: aastore
      // 0b3: dup
      // 0b4: bipush 6
      // 0b6: sipush 26414
      // 0b9: ldc2_w 4976912963157364953
      // 0bc: lload 1
      // 0bd: lxor
      // 0be: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c3: aastore
      // 0c4: dup
      // 0c5: bipush 7
      // 0c7: sipush 12174
      // 0ca: ldc2_w 172158645686425724
      // 0cd: lload 1
      // 0ce: lxor
      // 0cf: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d4: aastore
      // 0d5: dup
      // 0d6: bipush 8
      // 0d8: sipush 11900
      // 0db: ldc2_w 6685249737755253128
      // 0de: lload 1
      // 0df: lxor
      // 0e0: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e5: aastore
      // 0e6: dup
      // 0e7: bipush 9
      // 0e9: sipush 19874
      // 0ec: ldc2_w 965465020134308447
      // 0ef: lload 1
      // 0f0: lxor
      // 0f1: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f6: aastore
      // 0f7: dup
      // 0f8: bipush 10
      // 0fa: sipush 27749
      // 0fd: ldc2_w 5035898634408860555
      // 100: lload 1
      // 101: lxor
      // 102: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 107: aastore
      // 108: dup
      // 109: bipush 11
      // 10b: sipush 17463
      // 10e: ldc2_w 26570824397042644
      // 111: lload 1
      // 112: lxor
      // 113: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 118: aastore
      // 119: sipush 26892
      // 11c: ldc2_w 952206864346324705
      // 11f: lload 1
      // 120: lxor
      // 121: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 126: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 129: putfield cn/cool/cherish/module/impl/render/友树友友友何树树树友.树树树树友友友树何何 Lcn/cool/cherish/value/impl/ModeValue;
      // 12c: aload 0
      // 12d: new cn/cool/cherish/value/impl/NumberValue
      // 130: dup
      // 131: sipush 5782
      // 134: ldc2_w 8145461072776454501
      // 137: lload 1
      // 138: lxor
      // 139: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 13e: sipush 21944
      // 141: ldc2_w 8175099925263721050
      // 144: lload 1
      // 145: lxor
      // 146: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14b: bipush 8
      // 14d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 150: bipush 1
      // 151: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 154: bipush 30
      // 156: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 159: bipush 1
      // 15a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 15d: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 160: putfield cn/cool/cherish/module/impl/render/友树友友友何树树树友.树树树友树何树何友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 163: aload 0
      // 164: bipush 0
      // 165: ldc2_w -6430041234574770794
      // 168: lload 1
      // 169: invokedynamic û (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/render/友树友友友何树树树友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16e: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-1025008741206845644L, 422482615894888418L, MethodHandles.lookup().lookupClass()).a(177094675704341L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 78062842779039L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[30];
      int var7 = 0;
      String var6 = "¡?\u0085\u008f1+÷ùÖ\u0090\u0098\u0094\u009c\u0089ýK \r9\u0080çP\u0017Ow¼~ñb°²å{\t\u0086Fw\u0087\t×µV\u00036ú]\t\u007fÅ\u0010qe×-\u0082\u0085f\u0091ÝcRoïì\u0006\f\u0010Í\u0006.õa\u009bjâAÞÞAÿ1\u008a<\u0018->}`î\u0082\u0090Â\u008d\u0092®\u0000¿\u000fÂ;\u0099\u008aó\u0083vÓê\u008e\u0010£¾wG]®Õ\u001cþq\u0013¼LÏ\u0002]\u0010L»ë\u0001²\u001aqÔ-e)x°±íp Cè°n9ê?ëC-F\u008aÄB\u0006Û\u009e¨r\n.¬\u0095hÿ\u00171\t§\u0007X!\u0010\u008aS8\u0007ÉzY\u0011\u0086èÅ&\u000b÷ñ\u0083(w\u008by\u0017©\u008f\u0099¬´¦¥:4\u009aø[\u0004U\u0010ñIn¥Ö Ö§4MêUoÅ¡Ïnº!h\u0096\u0010cüoä8ú;e¬hÔµ\u001aú'\u0002\u0010J2õ\u0095²`ÎX\u0019\u0004¹O\u008b\u008fÙ} 7ßÃ_<ß\u009f¡\u00ad/Ã\u0087=$/\u008cXC\u009e\u0019\u0002¿S¿(PDvX\u0012\u0097T\u0018Uá+\"\u00ad{z°õp2ã\u0098]ÕyÈ»\u0099©ã¹\u008e\u0083 fÙYì×ò/òïbÛw\u0086\u009b²ß±7q©å!\u0019dÞ\n(´\u007f¶øé\u0010\u0007\u0089C\u0089bÍë[(Z00ïYN \u0010ÜÎ¯¿Ç\u0003¯Ðþ\u0088¤B\u0012æ\u001bÿ\u00182\u0087\u0005z\u001a%µ\u0096Ý#u\u0092\u0007P\u0005\u009e\u0088Ö\u0006¡\u0085\u0090q\u0099\u0010Ó\u000b\u0086JZú·øó³\u0011\u0091Çü¶#\u0010»¬ãCyb¬\u0084_½e\u0095rYüã(d|ññ\u0081Ø®\u00ad?V×{7Û-Ûë)\u009c\b\u0016\u001c´x¼\u001f\u009aV¨ÆÑ\u001aºí÷oô\u0096â\u0013 2ú!o\u000eÚöxv\u008eúà/'r\u00adOªÌ\u00180V\u001c\u0098ìTTJm±ûw \u0093Ì\u001a\u0000è÷7íOm\t}ø|?º\u0090ÓJÌmmÉ\u0003\u0090*\u0089Ë\u008fY×'\u0010UÙÎ%a\u00110\u007f\u008d¢T\\Ú\u0014h\t\u0010yd\u001a%O#¾\u0010ïRàÒ\u0094ì\u0003a \u009ec\u008dbOÆÑ\bl\u0090\t\u0015\u0016ëëf¡é\u008få\u00807°\u00068`á\u0014ÔA+\u0003\u0010\bl\u00ad\u001dÀß<\u0005\u007fXÔ\u001fm\u008c\u008cÉ û]\u007fúõ\u0011íÅáÝé¥»Õ\u001a\u0096Ùy¬ç§Ùâ¼TÁÖDÂzµ§";
      short var8 = 675;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[30];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u009bª\u000f¯\u008d\u008b\u0016Åã¦ÿ0\t\u009f½ì\u001fe\u001c,\u001e[\u0007\u0080ój\u000b§c\u0001ß\u009b \u007fù\u001f¼À.RE£<\"\u007fÌK9\u00034Äº9 \u0002\u0098P\u009e2Ä¡\u001d\u0095öÓ";
                  var8 = 65;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 1;
               case 1 -> 17;
               case 2 -> 7;
               case 3 -> 22;
               case 4 -> 39;
               case 5 -> 56;
               case 6 -> 9;
               case 7 -> 46;
               case 8 -> 37;
               case 9 -> 33;
               case 10 -> 57;
               case 11 -> 25;
               case 12 -> 51;
               case 13 -> 50;
               case 14 -> 32;
               case 15 -> 16;
               case 16 -> 59;
               case 17 -> 47;
               case 18 -> 26;
               case 19 -> 55;
               case 20 -> 49;
               case 21 -> 6;
               case 22 -> 8;
               case 23 -> 12;
               case 24 -> 3;
               case 25 -> 40;
               case 26 -> 23;
               case 27 -> 42;
               case 28 -> 29;
               case 29 -> 34;
               case 30 -> 41;
               case 31 -> 53;
               case 32 -> 2;
               case 33 -> 35;
               case 34 -> 61;
               case 35 -> 27;
               case 36 -> 63;
               case 37 -> 13;
               case 38 -> 24;
               case 39 -> 54;
               case 40 -> 60;
               case 41 -> 44;
               case 42 -> 21;
               case 43 -> 28;
               case 44 -> 10;
               case 45 -> 4;
               case 46 -> 14;
               case 47 -> 20;
               case 48 -> 38;
               case 49 -> 58;
               case 50 -> 52;
               case 51 -> 5;
               case 52 -> 0;
               case 53 -> 15;
               case 54 -> 19;
               case 55 -> 36;
               case 56 -> 43;
               case 57 -> 48;
               case 58 -> 45;
               case 59 -> 11;
               case 60 -> 31;
               case 61 -> 62;
               case 62 -> 18;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20774;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友树友友友何树树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树友友友何树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友树友友友何树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'e' && var8 != 251 && var8 != 202 && var8 != 204) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'f') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 186) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'e') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = " V\u0013\u0007Va V\u0004[Zn:\u001d\u0004FIm`C\u0006[Oa-_\u0002Z\u0015X/A\u0013@Xd+g\u001eY^{";
      j[1] = "E\bs\r\u001a\bE\bdQ\u0016\u0007_CdL\u0005\u0004\u0005\u001dfQ\u0003\bH\u0001bPY2B\u0000wO\u00121J\u001fsJ\u0014\rN9~S\u0012";
      j[2] = "\r+W\u000b(>\u0002k\u001a\u0000\"#\u00076\u0011F*>\n0\u0015\ri8\u00035\u0015F54\u0000!\u001c\u001ai厚桿厎厲厣伒桀桿桔厲";
      j[3] = "/sNQeb$|_\u001e\u0019{+fQ].K=q]@?g*|";
      j[4] = "\t\rCP\rP\u0006M\u000e[\u0007M\u0003\u0010\u0005\u001d\u000fP\u000e\u0016\u0001VLV\u0007\u0013\u0001\u001d\u0010Z\u0004\u0007\bAL}\u000f\u0017\u0019V\u0010|\u000b\u000e\bA\u0003";
      j[5] = "f\u0007oA\tUm\b~\u000etM~\u000fwG";
      j[6] = "\u0016:8\\It\u0019zuWCi\u001c'~\u0011Pz\u0019!s\u0011Ov\u000588rI\u007f\u0010\u0002wSS~";
      j[7] = boolean.class;
      k[7] = "java/lang/Boolean";
      j[8] = "0sd6y\u0012?3)=s\u000f:n\"{`\u001c?h/{\u007f\u0010#qd\u001bc\u00101x8\u0003w\u0011&x";
      j[9] = "Go/sXiH/bxRtMri>Zi@tmu\u0019体佱及佔佅叼体佱栐栐";
      j[10] = "\u0012\u001a,1`/\u0019\u0015=~\u0001!\u0012\u001e9$";
      j[11] = "yFq\u001f\u0002\u0015\u007fZi|\u0015},\u00022CE\u0015B8s\u0018\u001dKu\u0000y\u0018\u0010";
      j[12] = "7\u0010}\rRz6M)\f p\r\u0013~\u001a@\"6X)F\u001d\u00197Cr\u001c\u001b\"|\u0014.A ";
      j[13] = "2w!RZ04k91MXg3b\u000e\u0012?\t\t#UEn>1)UH";
      j[14] = "\u001d{\u000f5t.Jf^3\u001e桚栺佘栧桀标伞叠叆叽Y =\u0012iT4w Co";
      j[15] = "\u007fO4\u001b+5yS,x<]*\u000bwGl0D16\u001c4ks\t<\u001c9";
      j[16] = "6,\u000b#gz00\u0013@p\u0012chH\u007f\"x\rR\t$x$:j\u0003$u";
      j[17] = "Zh\u0015ZW][5A[%栧桹案县栲佸栧伽厒桥+\u001b\u0004\u000bl\u001eRDY\u0010:";
      j[18] = "\u0006w7\t\u000bn\u0000k/j\u001c\u0006S3tUOi=\t5\u000e\u00140\n1?\u000e\u0019";
      j[19] = "\u0017!h\u0006U\r\u0011=peBeBe+U\u0014\t,_j\u0001JS\u001bg`\u0001G";
      j[20] = "! <\r\u00015'<$n\u0016]td\u007fQF4\u001a^>\n\u001ek-f4\n\u0013";
      j[21] = "7J\u0017\bTO1V\u000fkC'b\u000eTT\u001cH\f4\u0015\u000fK\u0011;\f\u001f\u000fF";
      j[22] = "k]tOS}mAl,D\u0015>\u00197\u0013\u0015xP#vHL#g\u001b|HA";
      j[23] = "XDkvhGY\u0019?w\u001a叧厡桤栛佚叙佹厡传栛\u0007'FX\u001d{z%\u001eS\u0019";
      j[24] = "B\u007f\u001cD:}Dc\u0004'-\u0015\u0017;_\u0017{ry\u0001\u001eC%#N9\u0014C(";
      j[25] = "d\u0004a\u0014\bx\"]\u007fXj\u0016_VcP\u0014q;\u001d SVH";
      j[26] = "l.a\u0014\u0000$j2yw\u0017L9j\"HH%WPc\u0013\u001fz`hi\u0013\u0012";
      j[27] = "\u0002C_\u001b@g\u0004_GxW\u000fW\u0007\u001cH\u0000`9=]\u001c_9\u000e\u0005W\u001cR";
      j[28] = "Xe'W9\u001bY8sVK桡桻桅桗句厈去桻企伓&w\u0013\u0000b6\u001e-I\u000b-";
      j[29] = "\u0018D\u0015\u0013\u0004}\u001eX\rp\u0013\u0015M\u0000VOA~#:\u0017\u0014\u001b#\u0014\u0002\u001d\u0014\u0016";
      j[30] = "P\u0012;AsfV\u000e#\"d\u000e\u0005Vx\u001d;fkl9Fl8\\T3Fa";
   }

   private ParticleOptions[] p() {
      long a = 友树友友友何树树树友.a ^ 51338033175096L;
      c<"º">(-677224437516520194L, a);
      String var4 = c<"e">(this, -676819910988260195L, a).getValue();
      byte var5 = -1;
      switch (var4.hashCode()) {
         case 67960595:
            if (!var4.equals(b<"e">(30220, 7422886281929216432L ^ a))) {
               break;
            }

            var5 = 0;
         case 1852017554:
            if (!var4.equals(b<"e">(17482, 3956079110138160119L ^ a))) {
               break;
            }

            var5 = 1;
         case -455515669:
            if (!var4.equals(b<"e">(2024, 4981123351106756675L ^ a))) {
               break;
            }

            var5 = 2;
         case -1084044700:
            if (!var4.equals(b<"e">(32660, 6086381306115545135L ^ a))) {
               break;
            }

            var5 = 3;
         case 80009551:
            if (!var4.equals(b<"e">(27231, 7469884468006047231L ^ a))) {
               break;
            }

            var5 = 4;
         case 69599270:
            if (!var4.equals(b<"e">(28685, 7579190585805166524L ^ a))) {
               break;
            }

            var5 = 5;
         case 80997281:
            if (!var4.equals(b<"e">(25044, 8036365407385667174L ^ a))) {
               break;
            }

            var5 = 6;
         case 65203733:
            if (!var4.equals(b<"e">(24151, 87868771735304674L ^ a))) {
               break;
            }

            var5 = 7;
         case 786076318:
            if (!var4.equals(b<"e">(21221, 5606881822567724374L ^ a))) {
               break;
            }

            var5 = 8;
         case 430966332:
            if (!var4.equals(b<"e">(27055, 5404169664081776140L ^ a))) {
               break;
            }

            var5 = 9;
         case -425600778:
            if (!var4.equals(b<"e">(20512, 8432300834119841676L ^ a))) {
               break;
            }

            var5 = 10;
         case 55838914:
            if (var4.equals(b<"e">(26980, 6279293824804867796L ^ a))) {
               var5 = 11;
            }
      }
      return switch (var5) {
         case 0 -> new ParticleOptions[]{c<"Ê">(-676902798290520502L, a)};
         case 1 -> new ParticleOptions[]{c<"Ê">(-676688454759355749L, a)};
         case 2 -> new ParticleOptions[]{c<"Ê">(-677103967016199993L, a)};
         case 3 -> new ParticleOptions[]{
            c<"Ê">(-677513817545364214L, a), c<"Ê">(-677452779428886865L, a), c<"Ê">(-677607423966010202L, a), c<"Ê">(-677252913678296420L, a)
         };
         case 4 -> new ParticleOptions[]{c<"Ê">(-675640112426394722L, a)};
         case 5 -> new ParticleOptions[]{c<"Ê">(-677513817545364214L, a)};
         case 6 -> new ParticleOptions[]{c<"Ê">(-675934129361909327L, a)};
         case 7 -> new ParticleOptions[]{c<"Ê">(-676960051349582071L, a)};
         case 8 -> new ParticleOptions[]{c<"Ê">(-675769953605013741L, a)};
         case 9 -> new ParticleOptions[]{c<"Ê">(-677384338925406705L, a)};
         case 10 -> new ParticleOptions[]{c<"Ê">(-677716878552788452L, a)};
         case 11 -> new ParticleOptions[]{c<"Ê">(-677069878067870180L, a)};
         default -> new ParticleOptions[0];
      };
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void M(AttackEvent event) {
      long a = 友树友友友何树树树友.a ^ 131525547541057L;
      c<"û">(this, true, -5845406915010464331L, a);
   }

   @EventTarget
   public void W(PacketEvent event) {
      long a = 友树友友友何树树树友.a ^ 129987439779249L;
      long ax = a ^ 102749040030610L;
      long axx = a ^ 3217265543229L;
      long axxx = a ^ 38418805577472L;
      long axxxx = a ^ 126278105021423L;
      c<"º">(-5687101306397101193L, (long)a);
      if (!this.w(new Object[]{axx})) {
         if (event.getPacket() instanceof ServerboundInteractPacket wrapper
            && WrapperUtils.Y((long)wrapper, (ServerboundInteractPacket)axxx)
            && c<"e">(this, -5687781588967462331L, (long)a)) {
            c<"û">(this, false, -5687781588967462331L, (long)a);
            if (WrapperUtils.k(new Object[]{ax, wrapper}) != 0 && mc.level.getEntity(WrapperUtils.k(new Object[]{ax, wrapper})) != null) {
               ParticleOptions[] particles = this.p();
               int var16 = particles.length;
               int var17 = 0;
               if (0 < var16) {
                  ParticleOptions particle = particles[0];
                  int i = 0;
                  if (0 < c<"e">(this, -5687633805682119765L, (long)a).getValue().intValue()) {
                     WrapperUtils.Y(new Object[]{mc.level.getEntity(WrapperUtils.k(new Object[]{ax, wrapper})), particle, axxxx});
                     i++;
                  }

                  var17++;
               }
            }
         }
      }
   }

   private static String HE_DA_WEI() {
      return "职业技术教育中心学校";
   }
}
