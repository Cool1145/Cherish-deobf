package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.ChatFormatting;

// $VF: synthetic class
class ESP$树何友友友何友树何树 implements 何树友 {
   private static final Object[] a = new Object[20];
   private static final String[] b = new String[20];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-5913668606583535948L, -7806022737730871810L, MethodHandles.lookup().lookupClass()).a(56490977519366L);
      // $VF: monitorexit
      long var0 = var10000 ^ 16593884191891L;
      a();

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6462761611481229845L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var17) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6463661002577793293L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var16) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6463249655755877131L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var15) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6462808292166967937L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var14) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6464249869821499270L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var13) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6464083604515924193L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var12) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6463561455662443742L, var0).ordinal()] = 7;
      } catch (NoSuchFieldError var11) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6463493627393576765L, var0).ordinal()] = 8;
      } catch (NoSuchFieldError var10) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6463305757333308663L, var0).ordinal()] = 9;
      } catch (NoSuchFieldError var9) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6464175378315277189L, var0).ordinal()] = 10;
      } catch (NoSuchFieldError var8) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6462705051243311607L, var0).ordinal()] = 11;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[ChatFormatting.AQUA.ordinal()] = 12;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6462927205364727081L, var0).ordinal()] = 13;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6463650323811779514L, var0).ordinal()] = 14;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6463722679929507411L, var0).ordinal()] = 15;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"F">(-6464310122435825357L, var0)[a<"F">(-6463383834011544220L, var0).ordinal()] = 16;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 193 && var8 != 254 && var8 != 'F' && var8 != 252) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 163) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'l') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 193) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 254) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'F') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/ESP$树何友友友何友树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 43;
               case 1 -> 6;
               case 2 -> 31;
               case 3 -> 37;
               case 4 -> 51;
               case 5 -> 41;
               case 6 -> 48;
               case 7 -> 32;
               case 8 -> 47;
               case 9 -> 44;
               case 10 -> 56;
               case 11 -> 45;
               case 12 -> 16;
               case 13 -> 24;
               case 14 -> 20;
               case 15 -> 11;
               case 16 -> 35;
               case 17 -> 21;
               case 18 -> 63;
               case 19 -> 10;
               case 20 -> 23;
               case 21 -> 9;
               case 22 -> 17;
               case 23 -> 60;
               case 24 -> 26;
               case 25 -> 50;
               case 26 -> 3;
               case 27 -> 61;
               case 28 -> 49;
               case 29 -> 5;
               case 30 -> 1;
               case 31 -> 2;
               case 32 -> 38;
               case 33 -> 0;
               case 34 -> 52;
               case 35 -> 12;
               case 36 -> 36;
               case 37 -> 53;
               case 38 -> 18;
               case 39 -> 19;
               case 40 -> 42;
               case 41 -> 30;
               case 42 -> 8;
               case 43 -> 4;
               case 44 -> 7;
               case 45 -> 27;
               case 46 -> 14;
               case 47 -> 62;
               case 48 -> 25;
               case 49 -> 59;
               case 50 -> 58;
               case 51 -> 57;
               case 52 -> 33;
               case 53 -> 55;
               case 54 -> 40;
               case 55 -> 29;
               case 56 -> 34;
               case 57 -> 13;
               case 58 -> 28;
               case 59 -> 22;
               case 60 -> 46;
               case 61 -> 39;
               case 62 -> 15;
               default -> 54;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = ":\u001cg0'\u001c:\u001cpl+\u0013 WPv+\u0001\u0012\u0016as+\u0001 \u0010}y";
      a[1] = ":\fFS|\u00035L\u000bXv\u001e0\u0011\u0000\u001e~\u0003=\u0017\u0004U=\u00054\u0012\u0004\u001ea\t7\u0006\rB=)\n2L校但厧厒厩伽叻栂伹案";
      a[2] = "#.";
      a[3] = "h\u0011@R\u001a\rc\u001eQ\u001d{\u0003h\u0015UG";
      a[4] = "\u0001=%\u0019^OM9<g\"`j\u0013\u0017.7tyPq\n\u000bW\u00006=\u000e\u0012";
      a[5] = "@G^\u001053\fCGn_\u0018=*\n\u0003`+ALF\u0007y";
      a[6] = "\u0006(3\u0003#|J,*}\\@z\b\u0010}\"wR;f\u001bnsK";
      a[7] = "4cPXbvxgI&\u0018TLEv&c}`p\u0005@/yy";
      a[8] = "|\u0007p\u0004EG0\u0003iz9h\u0017)B01|\u0000j$\u0017\u0010_}\fh\u0013\t";
      a[9] = "*Zh\u0010F\\f^qn'w_sJ1v\u000bvRs^\u0010GrK";
      a[10] = ",9w.o7`=nP\u0010\u0016Y\u0018\u0012a24cdt-6-";
      a[11] = "s\u0006UcC!?\u0002L\u001d7\u0006\r+lJ+\u001a\u00183tPsv/\u000eN-\u0015:+\u0017";
      a[12] = "mE\u001a6cq!A\u0003H\fW\u001dt2Hbz9VO..~ ";
      a[13] = "\u0016Qf:2\u0004ZU\u007fDM8nm\u0003uo\u0007Y\fe9k\u001e";
      a[14] = "M\u000b0g\u0003\u007f\u0001\u000f)\u0019\u007fP&%\u0002ViT1 U(^|\u0002V3dZe";
      a[15] = ".*(\u0005+Nb.1{WaE\u0004\u001a4AaNG|\u0016~V/!0\u0012g";
      a[16] = "\u0018;(/QoT?1Q-@s\u0015\u001a\u000b,E)g 4\u001f9O+$-";
      a[17] = "j\u0003\u0001{\u0018=c\u0001\u0001=t伞伎叿伦叇伩桚伎栥桢\u0004M,#\u0005Da\u0005$9R";
      a[18] = "\u0006x{al-J|b\u001f\u0010\u0002mVIG\u0001\u0011oQS\u001fm&Rk.y!\"K";
      a[19] = "\u007f|I\u0012\u0006q3xPl|S\u0013\\,][r0!J\u0011_k";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String HE_WEI_LIN() {
      return "何炜霖国企上班";
   }
}
