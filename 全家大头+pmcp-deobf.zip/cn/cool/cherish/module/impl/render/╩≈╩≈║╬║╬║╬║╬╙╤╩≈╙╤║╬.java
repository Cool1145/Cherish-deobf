package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.client.树友何何何树何树友友;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import why.tree.friend.antileak.Fucker;

public class 树树何何何何友树友何 extends Module implements 何树友 {
   private final ModeValue 树友树树何树何树何树 = new ModeValue("Mode", "模式", new String[]{"Standard", "Exposed", "Custom"}, "Exposed");
   private final ModeValue 何友树何树友树树何何 = new ModeValue("Render Mode", "渲染模式", new String[]{"Glow", "Line", "Both"}, "Glow");
   private final ModeValue 何友树树友友友何树友 = new ModeValue("Blocks", "方块", new String[]{"Ores", "Valuables", "All"}, "Ores");
   public final BooleanValue 何何何树树友何何树何 = new BooleanValue("Auto Shutdown", "自动关闭", false);
   private final BooleanValue 何友友树树友何友树友 = new BooleanValue("Exposed Ores", "显示暴露矿物", true);
   private final BooleanValue 何何树树友友何树树友 = new BooleanValue("Spawner Detection", "刷怪笼检测", true);
   private final BooleanValue 友树何友树树何何何何 = new BooleanValue("End Portals", "末地传送门", true);
   private final BooleanValue 树树何友友友何友树树 = new BooleanValue("MineShafts", "废弃矿井", true);
   private final 树友何何树树何友友何 友何树树何友树何树何 = new 树友何何树树何友友何("Diamond Color", "钻石颜色", new Color(0, 255, 255));
   private final BooleanValue 友树树树友何友何树何 = new BooleanValue("Diamond", "钻石", true);
   private final 树友何何树树何友友何 何树何友何树友树何友 = new 树友何何树树何友友何("Emerald Color", "绿宝石颜色", new Color(0, 255, 0));
   private final BooleanValue 友树树友何何友友友何 = new BooleanValue("Emerald", "绿宝石", true);
   private final 树友何何树树何友友何 友树友树何树何何何树;
   private final BooleanValue 何友树树树友树友友何;
   private final 树友何何树树何友友何 友树何友何何何树何树;
   private final BooleanValue 友树树友何树友何友友;
   private final 树友何何树树何友友何 树何友树树树树友友树;
   private final BooleanValue 友树树何友友树何友友;
   private final 树友何何树树何友友何 友树树树友何树友何树;
   private final BooleanValue 树友何友树友何友何友;
   private final 树友何何树树何友友何 友何友友树何友友何何;
   private final BooleanValue 友何何何树何何何树树;
   private final 树友何何树树何友友何 树友友友树树何树何树;
   private final BooleanValue 何友树友友何友树何树;
   private final 树友何何树树何友友何 友友何树树树友何树友;
   private final 树友何何树树何友友何 友友何友友何何友树何;
   private final 树友何何树树何友友何 友树友树何友树友何何;
   private final NumberValue 友树何友树树树何何友;
   private final NumberValue 友何何树何树树树何友;
   private final NumberValue 何何友树友友树友树树;
   private final NumberValue 友何树树何何友树友树;
   private final NumberValue 何友何树友友何何何何;
   private final NumberValue 树树树树友友何树树树;
   private final NumberValue 友何何友友何何何友友;
   private final BooleanValue 何何树何何何树何树树;
   private final BooleanValue 何何何树何树何友树树;
   private final ConcurrentHashMap<BlockPos, 树树何何何何友树友何.树何树何树友何树树树> 树友何何友树何树何树;
   private final Set<BlockPos> 何何友何树何树友树何;
   private final Set<BlockPos> 何友树树友友何友何树;
   private BlockPos 何树树友何何友友友友;
   private static final double 友何友树树何树友友何 = 4.0;
   private Level 何友何树树树友何何何;
   private boolean 树友树友树何友友友树;
   private final 何友友何树何树何树友 何树树树树何树友树友;
   private final CopyOnWriteArraySet<BlockPos> 何树何何友友何何树何;
   private long 友树友何树树何友友何;
   private static final long 何树友树何树树何何树;
   private static final int[][] 何友何何树何何何何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[156];
   private static final String[] n = new String[156];
   private static int _行走的50万——何炜霖 _;

   public 树树何何何何友树友何() {
      super("XRay", "矿物透视", 树何友友何树友友何何.友友树树何友树树友树);
      BetterCamera.e();
      this.友树友树何树何何何树 = new 树友何何树树何友友何("RedStone Color", "红石颜色", new Color(255, 0, 0));
      this.何友树树树友树友友何 = new BooleanValue("RedStone", "红石", true);
      this.友树何友何何何树何树 = new 树友何何树树何友友何("Iron Color", "铁颜色", new Color(210, 210, 210));
      this.友树树友何树友何友友 = new BooleanValue("Iron", "铁", true);
      this.树何友树树树树友友树 = new 树友何何树树何友友何("Gold Color", "金颜色", new Color(255, 215, 0));
      this.友树树何友友树何友友 = new BooleanValue("Gold", "金", true);
      this.友树树树友何树友何树 = new 树友何何树树何友友何("Copper Color", "铜颜色", new Color(205, 127, 50));
      this.树友何友树友何友何友 = new BooleanValue("Copper", "铜", true);
      this.友何友友树何友友何何 = new 树友何何树树何友友何("Lapis Color", "青金石颜色", new Color(0, 0, 255));
      this.友何何何树何何何树树 = new BooleanValue("Lapis", "青金石", true);
      this.树友友友树树何树何树 = new 树友何何树树何友友何("Coal Color", "煤颜色", new Color(50, 50, 50));
      this.何友树友友何友树何树 = new BooleanValue("Coal", "煤", false);
      this.友友何树树树友何树友 = new 树友何何树树何友友何("Spawner Color", "刷怪笼颜色", new Color(255, 100, 255));
      this.友友何友友何何友树何 = new 树友何何树树何友友何("Cobblestone Color", "圆石颜色", new Color(128, 128, 128));
      this.友树友树何友树友何何 = new 树友何何树树何友友何("End Portal Color", "末地传送门颜色", new Color(128, 0, 128));
      this.友树何友树树树何何友 = new NumberValue("Range", "范围", 30, 5, 100, 1);
      this.友何何树何树树树何友 = new NumberValue("Scan Delay", "扫描延迟", 500, 100, 2000, 100);
      this.何何友树友友树友树树 = new NumberValue("Cave Min Size", "洞穴最小大小", 10, 5, 50, 1);
      this.友何树树何何友树友树 = new NumberValue("Min Vein Size", "最小矿脉大小", 2, 1, 10, 1);
      this.何友何树友友何何何何 = new NumberValue("Min Auth Score", "最低真实度分数", 6.0, 1.0, 10.0, 0.5);
      this.树树树树友友何树树树 = new NumberValue("Cobblestone Radius", "圆石检测半径", 10, 3, 20, 1);
      this.友何何友友何何何友友 = new NumberValue("Min Cobblestone Count", "最小圆石数量", 50, 10, 200, 5);
      this.何何树何何何树何树树 = new BooleanValue("Log Coordinates", "记录坐标", true);
      this.何何何树何树何友树树 = new BooleanValue("Show Notifications", "显示通知", true);
      this.树友何何友树何树何树 = new ConcurrentHashMap<>();
      this.何何友何树何树友树何 = ConcurrentHashMap.newKeySet();
      this.何友树树友友何友何树 = ConcurrentHashMap.newKeySet();
      this.何树树友何何友友友友 = null;
      this.树友树友树何友友友树 = false;
      this.何树树树树何树友树友 = new 何友友何树何树何树友(51913986529303L);
      this.何树何何友友何何树何 = new CopyOnWriteArraySet<>();
      this.友树友何树树何友友何 = 0L;
      if (Module.Z() == null) {
         BetterCamera.E("z34cV");
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6868158570732183560L, 2725343723812370539L, MethodHandles.lookup().lookupClass()).a(8001176109825L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(23009813082080L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[99];
      int var18 = 0;
      String var17 = "èHªj\u0089\u0006èàç\u001b\u008fÙèP¢h ,\u0014\u009bfY\u009cûVcM2GæÛ®µKl\u001a0d]u(\u0088*\\÷Mf6ã\u0018}7¹ëïZs©N¿M\u001bTÆ\u0091'\u001c1\u0001Ãv2ýÁ ÂÄ£[\u001d-öW\u0094Ï5\u001f\"Sûp,\u0081¹\u001fwC0û´Ä\u008dÏwÂÂe G©\u001f2\u0081_\u0099w\u001fø.o3Î¼\r/PÛE iÿÐßåQÑöAàE \u0094Ø,Uºï¼,h<Ü\n\u0018]\u009b\u0012Èøu\u008e\u008e:èÂ;\u0090î¬Åd»½ \u008bi¯ý\u008cb\u0001§ÒìZ¯Sf\u007fl5\u0089)(zá¾NBH\u008b©^´±\u0004 qÆ]å]cmz\u009b`\u0004/»¬Tu³©NáÒóª}Jg\u009c\u001c\u0003<\fÖ A\u0015®\u0014\u0000\u0002\u0001@ÞÅ3d\u0088\u0093Ih÷ÏÚ0yð\fu;e 9¸\u0086Ç\u0007 ò£=À\u0095»\u0095\u0086\u0092À1ï]\u009eMKÄEÆ\u001a&'û¿Q\u0015eñ)5ò\u0002 E£\rl÷á\u0002Ö4]*\u0005È\u0080\u0093\u00175\u0012NLä\u009c\u0017\u0091 e\u0093Z\u001b¥\u001b\u0016 \u001c\f\u0091÷5ùY^·uº\u0000Tn\u000e\u00079Èòä+Áâï ÀÛVâ\u001d\u001f@\u0018ñD\u0010Ð\u00152AÙEF;\u0080'\u009e\u008f\"\u0092\u0090(2¤>\u0005S\u0010o×\u0002~©#ÕÅ¶Q\u0084þ`¹\u0010\u009a\u0018\u0082G\u0082é!¥\u0017Â\u00ad2s\u0082íp\u001bÄ+4ÿ\u0000S+_O\u0018äÓ{û¢B\u0013/A>wÃàºb\u009dþ\u001de§+ÿ\u009eç(\u0015\u0083o¿ø÷Ã\u008c\u0010$:[QÛTê¨e)\u008a`A\u009cp:Ã\u0098\u0004\u001ef²\u008fj_{²¥aý\u0013\u0018¼m0¥õÆÅ|\u007f\u009e\u0010ç´Ïæ&ÈÞ±\u0089¿ÊÛÞ\u0010ú=*\u0005\u0019\u001c\u009cYX4WÙ(\u0081\u008d5\u0018`øPµ\u009fÒ©\u001c©\u008eg\u0085UQ»\u001cB\u0083Dù\u001c×R$\u0010ªO7!X\u0092\u009eFxÂ¥j\u008f\u0003\u001d! 9\u0091kÔÇNñBÌ\u0004\u0092\u0016ceBÚýóeÚ \u009a£\u0012ÿùù¼\u008aÈCä\u0018³\u008e\"Q\u00ad.\u0011Yv/\u0095g\u0092Ý+\u008fÓR8\u0084`ôI= ³\u0095ÌT\u001a¯tc\u000bC§\u000e\u0094\u0017\u008e¡¦9\u0013\u001d\u0018ìÂ\u0090\u008e$ð]?hâ© \u0096»Ü\u0089\u0010\u0083xÈUÝ\u0081\u0099LìBH9©UDw\b¦éaûßY#¿T!\u0010A-FÃÀÅè%ö¸eº½\u0080\u0006\u0096\u0010´¿\u0019\u008b\u0096¸¿\u0002Z<HH\u0003êií\u0010r\fG\u008aû+\u000b8cý&EH#\u008fá ì¶\u0014þïæH\u0087Y,\u0005L>x\u009f\u0017Þ\rî:ì\u001e]<°\u0019tËµ\u009d#\u009f Ô\u0019o\u001d¼\u0081=m\u009c\u0004ïX\u0004ïë\u009bÁYµ>\nÿVÇ.\u0006Iì\u008d\u0098øu(×ù(L\tnÓÇ^ó8\u0086¾Å´J4ç| n¬LOÚ$6,Í,h¿JëÂf\u0019D\"Ò\u0010o\u0096m(^\u0096ÎZRà|[\fø\u0092\u0007 <\u009bGl\u008d[|\u0091\u009c \u0017(¬;H\u001c\u001eÂag;!DÒY×q6ª\\íÍ\u0010áÔ\u000f\u0007~Ë¦ºè\u008a\u0087\u0089QÎb%\u0010¬¿\b>M\u001bÈÆ ³gR0|õ((\u00adÆéKfk\u0093Å\u0096Nà÷ZÝ¦-ÿâ©\u0084Í(¤p\u009cÈØ\u009dÌÂ\u0081ò·wòç\u0004\u008a¾û\u0010 \u00adÒÍ\u0094\u008b¯\b[\u009bìEÚ&\u009cÍ\u0010\u0019¿º\u0093$Lk\b\u0092UýI/\u0088¾Ö@\u0096rÖ{k2\u008f\u0089Üî\u008fvdÑOÆm\u001fzÒN7\u0004´\u0089)\nõø\u009b\u001e?\u0099jX`\u0004\u0082\u0084å´\u008a0|¶u\u0015ÙÜ\u0015fúI¾\\§$\u0004>ãÁ\u001a!® \u0005Ì\u0098fi-%1\u008a\rw\u008c\u0019ìlõoë\u008b¦qu\u0084\u00adw32: >]n\u0010\\Ñ>@Hè\u008aÔîf2`æx\u0082I\u0018<í\u0007ã\u007f\u008aÿÞ(\u0006\u0005ö+í\u0004\u0080\u0084%\u0098\u007f\u0094xÛæ\u0010CG>\u0016\u001d\u0098õª>¼£=º\tjD\u0018Á½î\u0015ö+ bÃ«§îÑ\u00adªY[#\b÷ÙìÑñ :ÿ4ë.\u00adwEjÞi\u008d\u001d¯eÁqe\u0000w\u0004\u001bm\u0001®^¥¼\u0001D£ö\u0010³\u0099f\u000bÉ\u0096à\u008e*ò<g,\u0007Q\f(®\u000f\u0091û4\u001fCC:?²3\u0011!-\u001dåYïÏ$[\u000b5FýóªÃ+¶¼AD¬\\\u0005)4ø ÒÁJ)\u0003IéºZjíQ×ú[\u001fD¨#ð\u0094\u0082ÞÖV.\u0084ïó[ùM\u0018Ñ\u009cuöãôK\u009eÖ\n^P\u0099ðï@i2ó\u001d\u0015\u0094½² éÐ\u001e8>Àg·Ïo&ÚÛ·áâüe{\u0013\u0092jG\u001b¬/\u008a\u0090u}Õ.\u0010\u008e<x±wcÏ\u0013ÙìYlà§³\u0086 \"\u0090\u0096ß\u008d0r»ô]\u000fT7ÖY\u0090¸è\u0015\u0087o±ÛT·$\n4ò#Ôá(\u000b\u0005³¿EKù(Gê\u0086zÏa{Úhõû\u0001¦\u009eËêÅðÞã;ºj¿D¡8\u0095\u0013º\u001fê n¬MjKÌSzd \"\u001f\u009f@\u007f!;\u007fyÎº\u0011Û³\u0093bX0±{Ó\u0087\u0010d\u008c\u0006¹Hâ®¤Æ\u0013\u0081[\u0081åC\u0012\u00105Ò\u00031§j\t\u0012Áª\u0081_lpyb(²¦\u0099tÿH\u0017h.á(\u001eüd¶\u0080ÚÀéãw\u00adÍ\u009a¦\u00189°¶µ¬Ñÿ\u0012©Æ¸\u0006\u0092\u000e ÊãnÓìÌ<\u001dñê\t3ç\u0093¹uR\u008e\u0094Ë\u0081þ2\u0007ÊýJ\u009e¹Ä³\u007f ã\u008a<¦ûÒ\u0019üqp0\u0004(RmÞÿÝ\u000e\u000f~*\u0004äüPªà\\1K\u009f\u0010!¢äóöô\u0088H/\u0088ù-\u00ad_ÿ¶(PûQ\u0019ÓûYü½\u0010\u0093 ¤/\u0010ÄGËZS×\u0081^\u0095ì¯xiÈ\u00ad\u0087Ó'x\u008d\u0005Y\u0010Ky(\u0000ÙK·¡\u0012\u0093zí\u0091Xy=Én\u0098Ìs¯Ú8h©\u0085\u0097\u0090v¡Jò\u001cVÝ¯\u0083XÞ\u0010ã\u0006\u0018\u0090ë\u009e3µ¾güyÖÜ\u009f`Ð\u0093³Ø))Å¿þ3ù \n\u000e^\u001f:\u0013\u0017hBí\u001f#{,y%ô\u0012Á\u0015 7Ø7#2ëÔ*,»\u0080\u0018\u0004@ªOK]½Æô\u0096\u009f)P×²\u009dF\n3P\u0002^Þ\u0090\u0010\u0003P\u0098\u0091UO¹zØ\u008cÑ¦Ëï|â\u0010pÔ\u0080AKÖ\t¤ä \u008fõð*YV\u0010uâ$½Mò\u0005\u0005lrJ\u0089ôWÚS\u0018\u0001\u009c$u·\u0004ÈîüâI(`l}_I©Üú!\u0098\u0085O\u0018\u0096î\f AõC¾v\"\u000bÜ\u0019\u009c\u0085f¡à\bT¶Ç\u0091\u008b\u0018a\u001fâ\u000f[¹6ä\u0005Wy\u0006\u0086x\u001e´\b\u0089Ð9¥´\u0002\u0089 \u0087ÿu\u009b2||m?\u007f¡\u0084\u0016\u0095\u0082À|{òØÜ\u007fûð¦\u001eT\u000bßÃG\u0084(®ù\u0097\n*\u0085Mg\u0087=ã\u001aÌ1\u0005K3í\n®;µÁÓÏOMDëüÏÿA\u0092\u0095þ\u009d\t¢\u000b k\u008e\u000e®¿\\w\u009c\u0086¿Ío\u008cúïÃFà_%û\u007f\u008buT\u008d_Zdè\u0007Û\u0010ñ\u0015ÒQA93r\u000b¦\u009e\u0082Oåä\u0094\u0010Í2Õð\u0098>I\u009c'öGÖªà°ò\u0018´l\u001cDMûf\u001c\u0012\u0083í\u0089\u0002´Hn\u0007èº\u009aÒs!t\u0010²x\u0019\u008cýYõ6ËMj\u009a6ª\u001en\u0010n&óIë÷µ¯aÝË\u0088\u0002ã\u0017è\u0010³òê÷\u0091´gD\u0083\n\u008dQ_aWe\u0010è£®:à\u0098ätÍ,tºkpwÇ(×»p]\u0080\u008f´|K\u001a'Ø´/®\u00853\u001b\u0092«\u0016)ð\u000f\u0083\u009cQ5g\u001dÉ\u008fö\u007f\u0017`ó\u0002Wø\u0010ùóL~ÿ\u0099,4X+o\u009b\u001e\u009cÇç(½ç\u0011=c\u0015M\u000fOUaôzd\n«¼©\u0017cbþÐ\n\nw\f¬Tõpå\"v\u0003\u0002\u0089¤.1 \u0005LFQ Ô&X\u001f\u0097öEò]hKm\u0082ÓØýDOÿ×¬åN\u0083(\u000b\u0096\u0010*)Êc\u000b\u009el·GñûÓp=\u0018ë(¾\u0017÷\u001a±ÍÔ\bE¾\u0096\u0089ª¡\u0091\t£æ}\u009e¢Ê\u0080¡$Ñòûg\u009cÑ-X\u0016\u0099' Q\u000fÕ ¾m»Þ×cWÆQà!O>¯µ3Çán\\QÙx*¡eö$ôYð5\u0010 7¶Ùzµe\u000eÈ\u0083ø\u0004q\u0016\u001eÀ\u0010pÍô.M\u001b¿÷J\u0095ãLA#Ö\u008c\u0018\"y·¹É\u0093×\u0096\u0096¶Íg:&\u001a<$4Ó\u0015Ã¸\u0005~(×È\u00061t¾`\u009a áhh\"\u009e@7±.\t\u0002\u001aÙz)ªæ÷¦\t_Ò!®8\u0088G:ç\u0002ª\u0018Á:?wò\u008dy\u0099oc83¢·\u0090óhðÕìÿ#å5\u0010)×\u0080qE\u008eö0Í\u0083«ªTk\u0094R ²Ì\u008cA*`\rz\\ècP\u008d\u0099Gw²\u0007¨W¶}Ñdïfi\u0082[8\u0099ÊH®\u0094O¯¾&nkØQµO\u0096xõ\\FÉ\u009brÉiµØç¦í\u0092\u0014£Ï%²\u009fGN\u0019Ø¡b\u0081E\u009a¼ÌrÅ¹A_J\u000e:\u0094å¯5\u0014\u0091¹¯o>v¡%\u0000Îu¶8§(/\u000bÁòÐ\u0080\u009d¬p\b\u0099ê\u0088Ù£±(\u0018\u0013\u000b+ù1ðYBKà+f«{\u007fÌÔ\u0003P\u008dSó";
      short var19 = 2712;
      char var16 = 16;
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[99];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(23009813082080L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "¬\u0090TÕP\u0004¹\f\u0082A)>Ï'Õ©".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     何树友树何树树何何树 = 1000L;
                     何友何何树何何何何何 = new int[][]{{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "`³\u0013Åøîcõµ\tB¯÷\u001bìhc}\u007f\u0014\u0095|\u0083u\u0011b`\u0081\t\u0012k)\u0010Õ&ð÷»ä\b\nº¡lÉ°þÃ³";
                  var19 = 49;
                  var16 = ' ';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private double B(Set<BlockPos> cave) {
      BetterCamera.e();
      if (cave.size() < 3) {
         return 1.0;
      } else {
         BlockPos[] extremePoints = this.x(cave);
         BlockPos start = extremePoints[0];
         BlockPos end = extremePoints[1];
         double maxDist = start.distManhattan(end);
         double totalDeviation = 0.0;
         Iterator avgDeviation = cave.iterator();
         if (avgDeviation.hasNext()) {
            BlockPos pos = (BlockPos)avgDeviation.next();
            totalDeviation = 0.0 + this.l(pos, start, end);
         }

         double avgDeviationx = totalDeviation / cave.size();
         return Math.max(0.0, Math.min(1.0, 1.0 - avgDeviationx / maxDist));
      }
   }

   private String C(Block block) {
      BetterCamera.e();
      if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) {
         return "钻石";
      } else if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) {
         return "绿宝石";
      } else if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) {
         return "红石";
      } else if (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE) {
         return "铁";
      } else if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.NETHER_GOLD_ORE) {
         return "金";
      } else if (block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE) {
         return "铜";
      } else if (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE) {
         return "青金石";
      } else if (block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE) {
         return "煤";
      } else if (block == Blocks.SPAWNER) {
         return "刷怪笼";
      } else if (block == Blocks.COBBLESTONE) {
         return "圆石";
      } else {
         return block == Blocks.END_PORTAL ? "末地传送门" : "未知";
      }
   }

   private double J(Set<BlockPos> cave) {
      BetterCamera.e();
      if (cave.size() < 10) {
         return 0.0;
      } else {
         int junctions = 0;
         Iterator var6 = cave.iterator();
         if (var6.hasNext()) {
            BlockPos pos = (BlockPos)var6.next();
            int adjacentAir = 0;
            Direction[] var9 = Direction.values();
            int var10 = var9.length;
            int var11 = 0;
            if (0 < var10) {
               Direction dir = var9[0];
               if (cave.contains(pos.relative(dir))) {
                  adjacentAir++;
               }

               var11++;
            }

            if (adjacentAir >= 3) {
               junctions++;
            }
         }

         return (double)junctions / cave.size();
      }
   }

   private 树树何何何何友树友何.友友友友何友树友树树 S(Block block) {
      BetterCamera.e();
      if (block == Blocks.SPAWNER) {
         return 树树何何何何友树友何.友友友友何友树友树树.树何何何树树树何友何;
      } else if (block == Blocks.COBBLESTONE) {
         return 树树何何何何友树友何.友友友友何友树友树树.何树树树何友友何树树;
      } else if (block == Blocks.END_PORTAL) {
         return 树树何何何何友树友何.友友友友何友树友树树.友友树树何友树树何树;
      } else {
         return this.K(block) ? 树树何何何何友树友何.友友友友何友树友树树.树树友友何何友友何何 : 树树何何何何友树友何.友友友友何友树友树树.友何何树树何树友何树;
      }
   }

   private void Z(BlockPos playerPos, int scanRange) {
      BetterCamera.e();
      String var6 = this.树友树树何树何树何树.getValue();
      byte var7 = -1;
      switch (var6.hashCode()) {
         case 1377272541:
            if (!var6.equals("Standard")) {
               break;
            }

            var7 = 0;
         case 355597568:
            if (!var6.equals("Exposed")) {
               break;
            }

            var7 = 1;
         case 2029746065:
            if (var6.equals("Custom")) {
               var7 = 2;
            }
      }

      switch (var7) {
         case 0:
            this.t(playerPos, scanRange);
         case 1:
            if (!(Boolean)Fucker.isLogin || !(Boolean)Fucker.isBeta && !(Boolean)Fucker.友友何友何何树何树树) {
               break;
            }

            this.O(playerPos, scanRange);
         case 2:
            this.l(playerPos, scanRange);
      }
   }

   private boolean V(BlockPos initialOrePos, Block oreType, int minVeinSize) {
      BetterCamera.e();
      if (minVeinSize <= 1) {
         return true;
      } else if (!this.Q(new Object[]{52406761729175L}) && mc.level.isLoaded(initialOrePos)) {
         Set<BlockPos> visited = new HashSet<>();
         Queue<BlockPos> queue = new LinkedList<>();
         queue.add(initialOrePos);
         visited.add(initialOrePos);
         int veinSize = 1;
         int checks = 0;
         if (!queue.isEmpty()) {
            BlockPos pos = queue.poll();
            checks++;
            Direction[] var18 = Direction.values();
            int var19 = var18.length;
            int var20 = 0;
            if (0 < var19) {
               Direction dir = var18[0];
               BlockPos neighbor = pos.relative(dir);
               if (!visited.contains(neighbor) && mc.level.isLoaded(neighbor)) {
                  visited.add(neighbor);
                  Block block = 友树友友树何树友树友.g(85526755286720L, neighbor);
                  if (this.o(block, oreType)) {
                     veinSize++;
                     queue.add(neighbor);
                     if (veinSize >= minVeinSize) {
                        return true;
                     }
                  }
               }

               var20++;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 8;
               case 1 -> 50;
               case 2 -> 25;
               case 3 -> 44;
               case 4 -> 6;
               case 5 -> 45;
               case 6 -> 30;
               case 7 -> 60;
               case 8 -> 21;
               case 9 -> 10;
               case 10 -> 53;
               case 11 -> 17;
               case 12 -> 4;
               case 13 -> 7;
               case 14 -> 14;
               case 15 -> 20;
               case 16 -> 47;
               case 17 -> 63;
               case 18 -> 15;
               case 19 -> 46;
               case 20 -> 49;
               case 21 -> 41;
               case 22 -> 37;
               case 23 -> 52;
               case 24 -> 58;
               case 25 -> 40;
               case 26 -> 28;
               case 27 -> 59;
               case 28 -> 55;
               case 29 -> 5;
               case 30 -> 31;
               case 31 -> 24;
               case 32 -> 35;
               case 33 -> 38;
               case 34 -> 16;
               case 35 -> 1;
               case 36 -> 62;
               case 37 -> 27;
               case 38 -> 3;
               case 39 -> 32;
               case 40 -> 11;
               case 41 -> 54;
               case 42 -> 0;
               case 43 -> 56;
               case 44 -> 29;
               case 45 -> 42;
               case 46 -> 43;
               case 47 -> 2;
               case 48 -> 19;
               case 49 -> 18;
               case 50 -> 26;
               case 51 -> 33;
               case 52 -> 22;
               case 53 -> 51;
               case 54 -> 39;
               case 55 -> 34;
               case 56 -> 9;
               case 57 -> 23;
               case 58 -> 12;
               case 59 -> 61;
               case 60 -> 48;
               case 61 -> 13;
               case 62 -> 57;
               default -> 36;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 14999;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树树何何何何友树友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[)jvU\u009cNV\u001e, »\u008d\u000e\u0092ë¹ù\u0018v >`½\u008d*à, òE¾hp9f8Q¹6%xø\u00155,  \"Ô©\u0082Ï%¼\u0016ëùÁí¯\u0083º, \u00887¯ÅÕÅ¾¶¾\u0007©\u001f\\\u008d\u0013á, LÏ¾º¶\u0088î\u009fX3Iÿ\u000fº't, \u008c©\u009du&\u009e]¨!]\u0005!ÁÃ\u0000?, ¬>Æ\u0097)¬\u001d\u009d\u009c\tr\u0011î\u008b×^, Bõ\u009diªª#\u0019l\u009b÷»í^&y, ½\u008eÊ\u008c\u0011×g\u0000£?\b½aÙ°ð, êRP-\u0083Àôçdæø¬\u0002-¸º, ~]ºÂ\u007fûÍ¹Øáüó\u008d¹wÒ, ¯PVÓ0\u008aS\u001e\u0015P\u0017\u0000 \u0013â\u0005, së\u008fËDk¾\u0019, \u0010$PÄ]\u0000kÊ;gÖ\"\u0086\u0090Wg, Ù[\u0088a\\ü\u0099<Qe\u001cQ;àì\u0019, ãÓ\\ï\u0094W|Ø*Þ½ì\u0015*\u00ad\u0012¾f¥\u008fí6ùê, \u001a\u000e0,;È\u009c\u0013ó\u0080¢\"ë")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private double b(BlockPos orePos) {
      BetterCamera.e();
      int naturalBlocks = 0;
      Direction[] var10 = Direction.values();
      int var11 = var10.length;
      int var12 = 0;
      if (0 < var11) {
         Direction dir = var10[0];
         Block adjacentBlock = 友树友友树何树友树友.g(85526755286720L, orePos.relative(dir));
         if (adjacentBlock == Blocks.STONE
            || adjacentBlock == Blocks.DEEPSLATE
            || adjacentBlock == Blocks.GRANITE
            || adjacentBlock == Blocks.DIORITE
            || adjacentBlock == Blocks.ANDESITE
            || adjacentBlock == Blocks.TUFF) {
            naturalBlocks++;
         }

         var12++;
      }

      return 0.0 + naturalBlocks / 6.0 * 2.0;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树树何何何何友树友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private void x(BlockPos spawnerPos) {
      BetterCamera.e();
      int radius = this.树树树树友友何树树树.getValue().intValue();
      int cobblestoneCount = 0;
      HashSet cobblestonePositions = new HashSet();
      int x = -radius;
      if (x <= radius) {
         int y = -radius;
         if (y <= radius) {
            int z = -radius;
            if (z <= radius) {
               BlockPos checkPos = spawnerPos.offset(x, y, z);
               Block block = 友树友友树何树友树友.g(85526755286720L, checkPos);
               if (block == Blocks.COBBLESTONE) {
                  cobblestoneCount++;
                  cobblestonePositions.add(checkPos);
               }

               z++;
            }

            y++;
         }

         x++;
      }

      if (cobblestoneCount >= this.友何何友友何何何友友.getValue().intValue()) {
         Iterator var16 = cobblestonePositions.iterator();
         if (var16.hasNext()) {
            BlockPos pos = (BlockPos)var16.next();
            this.树友何何友树何树何树.put(pos, new 树树何何何何友树友何.树何树何树友何树树树(Blocks.COBBLESTONE, 树树何何何何友树友何.友友友友何友树友树树.何树树树何友友何树树, 8.0));
         }
      }
   }

   private BlockPos[] x(Set<BlockPos> cave) {
      BetterCamera.e();
      if (cave != null && cave.size() >= 2) {
         List<BlockPos> positions = new ArrayList<>(cave);
         BlockPos p1 = positions.get(0);
         BlockPos p2 = p1;
         Iterator p3 = positions.iterator();
         if (p3.hasNext()) {
            BlockPos currentPos = (BlockPos)p3.next();
            int dist = currentPos.distManhattan(p1);
            if (dist > -1) {
               p2 = currentPos;
            }
         }

         BlockPos p3x = p2;
         Iterator var17 = positions.iterator();
         if (var17.hasNext()) {
            BlockPos currentPos = (BlockPos)var17.next();
            int dist = currentPos.distManhattan(p2);
            if (dist > -1) {
               p3x = currentPos;
            }
         }

         return new BlockPos[]{p2, p3x};
      } else {
         List<BlockPos> tempList = new ArrayList<>(Objects.requireNonNullElseGet(cave, HashSet::new));
         if (tempList.isEmpty()) {
            return new BlockPos[]{BlockPos.ZERO, BlockPos.ZERO};
         } else {
            BlockPos p = tempList.get(0);
            return new BlockPos[]{p, p};
         }
      }
   }

   private boolean s(Block block) {
      BetterCamera.e();
      return block == Blocks.ANCIENT_DEBRIS
         || block == Blocks.NETHER_QUARTZ_ORE
         || block == Blocks.OBSIDIAN
         || block == Blocks.AMETHYST_BLOCK
         || block == Blocks.BUDDING_AMETHYST;
   }

   private void s() {
      d<"Â">(-5765460985308291554L, 94229804724207L);
      long currentTime = System.currentTimeMillis();
      if (currentTime - d<"K">(this, -5768443701709148859L, 94229804724207L) >= 1000L) {
         Iterator var8 = d<"K">(this, -5767091764765811631L, 94229804724207L).entrySet().iterator();
         if (var8.hasNext()) {
            Entry<BlockPos, 树树何何何何友树友何.树何树何树友何树树树> entry = (Entry<BlockPos, 树树何何何何友树友何.树何树何树友何树树树>)var8.next();
            BlockPos pos = entry.getKey();
            树树何何何何友树友何.树何树何树友何树树树 info = entry.getValue();
            if (!d<"K">(this, -5768147165297686870L, 94229804724207L).contains(pos) && d<"K">(this, -5764630435268730867L, 94229804724207L).getValue()) {
               String blockName = this.C(d<"K">(info, -5772486679427844047L, 94229804724207L));
               String message = String.format(b<"i">(29586, 3525966898063493411L), blockName, pos.getX(), pos.getY(), pos.getZ());
               if (d<"K">(info, -5766611459408376519L, 94229804724207L) == d<"ö">(-5779270818298666531L, 94229804724207L)) {
                  message = message + String.format("§7(真实度: %.1f)", d<"K">(info, -5768982569306159157L, 94229804724207L));
               }

               ClientUtils.P(125527250587045L, message);
               d<"K">(this, -5768147165297686870L, 94229804724207L).add(pos);
            }
         }

         d<"Ñ">(this, currentTime, -5768443701709148859L, 94229804724207L);
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'K' && var8 != 209 && var8 != 246 && var8 != 242) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'a') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 194) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'K') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 209) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 246) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 17849;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树树何何何何友树友何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private void c(PoseStack poseStack, AABB box, Color color, Vec3 camPos) {
      float red = color.getRed() / 255.0F;
      float green = color.getGreen() / 255.0F;
      float blue = color.getBlue() / 255.0F;
      double minX = box.minX - camPos.x;
      double minY = box.minY - camPos.y;
      double minZ = box.minZ - camPos.z;
      double maxX = box.maxX - camPos.x;
      double maxY = box.maxY - camPos.y;
      double maxZ = box.maxZ - camPos.z;
      Matrix4f matrix = poseStack.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, 0.7F).endVertex();
      BufferUploader.drawWithShader(buffer.end());
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树树何何何何友树友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private void h(PoseStack poseStack, AABB box, Color color, Vec3 camPos) {
      float red = color.getRed() / 255.0F;
      float green = color.getGreen() / 255.0F;
      float blue = color.getBlue() / 255.0F;
      float alpha = color.getAlpha() / 255.0F;
      double minX = box.minX - camPos.x;
      double minY = box.minY - camPos.y;
      double minZ = box.minZ - camPos.z;
      double maxX = box.maxX - camPos.x;
      double maxY = box.maxY - camPos.y;
      double maxZ = box.maxZ - camPos.z;
      Matrix4f matrix = poseStack.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)minX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)minZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)maxY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      buffer.vertex(matrix, (float)maxX, (float)minY, (float)maxZ).color(red, green, blue, alpha).endVertex();
      BufferUploader.drawWithShader(buffer.end());
   }

   private double h(BlockPos orePos) {
      int naturalFeatures = 0;
      BetterCamera.e();
      int suspiciousFeatures = 0;
      int x = -2;
      int y = -2;
      int z = -2;
      BlockPos checkPos = orePos.offset(-2, -2, -2);
      Block block = 友树友友树何树友树友.g(85526755286720L, checkPos);
      if (block == Blocks.WATER || block == Blocks.LAVA || block == Blocks.GRAVEL || block == Blocks.DIRT) {
         naturalFeatures++;
      }

      if (block == Blocks.BEDROCK || block == Blocks.BARRIER) {
         suspiciousFeatures++;
      }

      z++;
      y++;
      x++;
      double score = 0.0 + Math.min(naturalFeatures * 0.1, 1.0) - suspiciousFeatures * 0.5;
      return Math.max(-1.0, score);
   }

   @Override
   protected void h() {
      this.树友何何友树何树何树.clear();
      this.何何友何树何树友树何.clear();
      this.何友树树友友何友何树.clear();
      this.何树何何友友何何树何.clear();
   }

   private boolean h(BlockPos pos) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && mc.level.isLoaded(pos)) {
         BlockState state = mc.level.getBlockState(pos);
         return state.isAir()
            || !state.canOcclude()
            || state.getBlock() == Blocks.WATER
            || state.getBlock() == Blocks.LAVA
            || state.getBlock() == Blocks.CAVE_AIR;
      } else {
         return false;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private double f(BlockPos orePos, Block oreBlock) {
      BetterCamera.e();
      int sameOreBlocks = 0;
      int x = -2;
      int y = -2;
      int z = -2;
      BlockPos checkPos = orePos.offset(-2, -2, -2);
      Block checkBlock = 友树友友树何树友树友.g(85526755286720L, checkPos);
      if (checkBlock == oreBlock) {
         sameOreBlocks++;
      }

      z++;
      y++;
      x++;
      if (sameOreBlocks >= 2 && sameOreBlocks <= 8) {
         return 2.0;
      } else if (sameOreBlocks == 1) {
         return 1.0;
      } else {
         return sameOreBlocks > 8 ? 0.5 : 0.0;
      }
   }

   private boolean f(Block block) {
      BetterCamera.e();
      return this.友树树树友何友何树何.getValue() && (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE)
         || this.友树树友何何友友友何.getValue() && (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE)
         || this.何友树树树友树友友何.getValue() && (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE)
         || this.友树树友何树友何友友.getValue() && (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE)
         || this.友树树何友友树何友友.getValue() && (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.NETHER_GOLD_ORE)
         || this.树友何友树友何友何友.getValue() && (block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE)
         || this.友何何何树何何何树树.getValue() && (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE)
         || this.何友树友友何友树何树.getValue() && (block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE);
   }

   private double f(Set<BlockPos> cave) {
      BetterCamera.e();
      if (cave.size() < 3) {
         return 0.0;
      } else {
         double avgY = cave.stream().mapToDouble(Vec3i::getY).average().orElse(0.0);
         double variance = cave.stream().mapToDouble(pos -> Math.pow(pos.getY() - avgY, 2.0)).sum() / cave.size();
         return Math.sqrt(variance);
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private void l(BlockPos playerPos, int scanRange) {
      this.t(playerPos, scanRange);
   }

   private double l(BlockPos point, BlockPos lineStart, BlockPos lineEnd) {
      double x0 = point.getX();
      BetterCamera.e();
      double y0 = point.getY();
      double z0 = point.getZ();
      double x1 = lineStart.getX();
      double y1 = lineStart.getY();
      double z1 = lineStart.getZ();
      double x2 = lineEnd.getX();
      double y2 = lineEnd.getY();
      double z2 = lineEnd.getZ();
      double dx = x2 - x1;
      double dy = y2 - y1;
      double dz = z2 - z1;
      double lineLength2 = dx * dx + dy * dy + dz * dz;
      if (lineLength2 == 0.0) {
         return Math.sqrt((x0 - x1) * (x0 - x1) + (y0 - y1) * (y0 - y1) + (z0 - z1) * (z0 - z1));
      } else {
         double t = ((x0 - x1) * dx + (y0 - y1) * dy + (z0 - z1) * dz) / lineLength2;
         t = Math.max(0.0, Math.min(1.0, t));
         double projX = x1 + t * dx;
         double projY = y1 + t * dy;
         double projZ = z1 + t * dz;
         return Math.sqrt((x0 - projX) * (x0 - projX) + (y0 - projY) * (y0 - projY) + (z0 - projZ) * (z0 - projZ));
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树树何何何何友树友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      m[0] = "g\u0010MV\u0005bhP\u0000]\u000f\u007fm\r\u000b\u001b\u0007b`\u000b\u000fPDdi\u000e\u000f\u001b\u0018hj\u001a\u0006GDOa\n\u0017P\u0018Ne\u0013\u0006G\u000b";
      m[1] = "=%^\u00005\r6*OOH\u0015%-F\u0006";
      m[2] = "\u0005\bYI0S\nH\u0014B:N\u000f\u0015\u001f\u00042S\u0002\u0013\u001bOqU\u000b\u0016\u001b\u0004-Y\b\u0002\u0012Xq栭桷伳伢使伊号桷厭伢";
      m[3] = "6<&n<\u0013=37!@\n2)9bw:$>5\u007ff\u001633";
      m[4] = "C\u0018H";
      m[5] = "\u0017+\u001d\u0004Zz\u0018kP\u000fPg\u001d6[ICt\u00180VI\\x\u0004)\u001d)@x\u0016 A1Ty\u0001 ";
      m[6] = "\u0004bgDE\u0011\u0004bp\u0018I\u001e\u001e)d\u0005Z\u0014\u000e)\u007f\u000f^\u001d\u0006)q\u0006G\u001b\u0001)Q\u0006G\u001b\u0001t";
      m[7] = "x\u001bh5\u0002ax\u001b\u007fi\u000enbPkt\u001ddrPp~\u0019mzP~w\u0000k}P^w\u0000k}";
      m[8] = "\f?nZAB\u0003\u007f#QK_\u0006\"(\u0017CB\u000b$,\\\u0000D\u0002!,\u0017\\H\u00015%K\u0000格桾伄伕佬佻另桾厚伕\u001d栿佸桾伄桑史佻格桾桀";
      m[9] = double.class;
      n[9] = "java/lang/Double";
      m[10] = "4z\u007f\u0006~\f*reI\u0003\u001c*";
      m[11] = "m\u0001mu\b\u0007s\tw:E\u001di\u0003nfT\u0017i\u00145WI\u001cd\u0015ifC\u001cs(zgN?f\u0010";
      m[12] = "\u0011zP\u0001\u0016>\u001e:\u001d\n\u001c#\u001bg\u0016L\u000f0\u001ea\u001bL\u0010<\u0002xP \u0016>\u001eq\u001f\f/0\u001ea\u001b";
      m[13] = "\u000bNu\u0005@\u0019\u0004\u000e8\u000eJ\u0004\u0001S3HB\u0019\fU7\u0003\u0001\u001f\u0005P7H]\u0013\u0006D>\u0014\u0001桧桹併伎伳佺厽桹叫伎B古厽厣叫伎厭栾厽桹栱";
      m[14] = long.class;
      n[14] = "java/lang/Long";
      m[15] = "\u0002*<\"1m\u001c\"&m|w\u0006(?1m}\u0006?d\u0000ph\u0011\u0004$\u0014mq\u001c.\u000b1my\u0011\u0018/7";
      m[16] = "?\u001c{5c?0\\6>i\"5\u0001=xy$5\u001e&x余厛厗伧桄伃栝伅桍厹";
      m[17] = boolean.class;
      n[17] = "java/lang/Boolean";
      m[18] = "9i(C[79i?\u001fW8#\"?\u0002D;yN0\u0002U5\u0007c/";
      m[19] = "hNm\u000fDhhNzSHgr\u0005nN[mb\u0005uD_dj\u0005UD_dj";
      m[20] = "}B(k 9r\u0002e`*$w_n&97rYc&&;n@(栙厄伃佋栽栗佝厄厝佋";
      m[21] = "^\u0011bXf=C\u0004:z'0[\u0002";
      m[22] = void.class;
      n[22] = "java/lang/Void";
      m[23] = "P\u000blm;W_K!f1JZ\u0016* 9WW\u0010.kzu\\\u00017b1";
      m[24] = "& *1\u00066\u0012\u0003%qK=\u0018\u001e ,@{\u0010\u0003-*D0S!&;]9\u0018W";
      m[25] = "H\u0013\u001bbm\rGSVig\u0010B\u000e]/o\rO\bYd,桳佾厶叾佔栓厩叠伨你";
      m[26] = "rx\u001b*DQ}8V!NLxe]gFQucY,\u0005W|fYgY[\u007frP;\u0005栯栀佃你伜佾叵栀叝你m佾叵叚佃栤厂栺栯栀标";
      m[27] = "\u007f\u0015";
      m[28] = "]\u0002'\u0010\u0013\b]\u00020L\u001f\u0007GI0R\u0017\u0004]\u0013}s\u0017\u000fV\u0004!_\u0018\u0015";
      m[29] = "`R*nWD`R=2[Kz\u0019=,SH`Cp2_CjR,%H\u0003IV3%hH`S;2__";
      m[30] = "~\fjg\u0017fqL'l\u001d{t\u0011,*\u000ehq\u0017!*\u0011dm\u000ejI\u0017mx4%h\rl";
      m[31] = "@Qa4u^@QvhyQZ\u001abuj[J\u001aeraD\u0000uTXZ";
      m[32] = "=\"Iu:-4,J<y 2,^>d&p;A)#'&cr>%6;5b4%/?9\u0000\u00168&;";
      m[33] = ";G\u0018\"rb;G\u000f~~m!\f\u001bcmg1\f\u001cdfx{t\to,";
      m[34] = "#RYUor*\\Z\u001c,\u007f,\\N\u001e1ynKQ\tvx8\u0013p\u001ed|5Q@-go4XL=mo-\\@";
      m[35] = "\u0001YB&\u0014p\bWAoW}\u000eWUmJ{L@Jz\rz\u001a\u0018ym\u000bk\u0007Nig\u000br\u0003B";
      m[36] = "h_*!T-cP;n5#h[?4";
      m[37] = "t\u00138LUPs\fhC0]GG3H\u0001\tGw7\u000eV\u000fs\u00179\u0015QA";
      m[38] = "\u0003Nr\u000bh\u0015HN6\u0004\u001a厲栣号栒伫叙桨叹佩佖vwMKL{\u0007wA\u0004O";
      m[39] = "V\u0002iv3\b\u0005E\u007f#Y\u0002=\u0000?sfW==:#=\u001d\u0018Th2+\u000b";
      m[40] = "E*?P)\u001e\u000e*{_[厹伡桉桟佰伆厹桥厓桟-g@\u0013*$Ug\u000b\u0018n";
      m[41] = "R\nr\u000fU<\u0001MdZ?69\t-\u0002\u000ee95!Z[)\u001c\\sKM?";
      m[42] = "\u0004VXd6xOV\u001ckD佁叾可核栀厇佁叾栵叢\u0019tl\u0000LXi#uS^";
      m[43] = "\u001e,\u0019QE+P+Z@?伓栶栋桼佧叼厍佲栋桼:\u000epSy\u001f_@w\u0010h";
      m[44] = "q6qLJ\u000bpiwM(\u0015Mi+\u001b\u0018F!\u0007\u0011IN\u001bt2aH\u0011\u001du";
      m[45] = "i[\u0000\u007fjS1\u000f\u0006h\u000e栤伊桼伢佇体叾伊桼伢\u001a3T3\u0014\rsaE%\u0002";
      m[46] = "A_~$\"\u000b\u0012\u0018hqH\u0001*]( v^*`-q,\u001e\u000f\t\u007f`:\b";
      m[47] = "\t@asG\u0016\u001f\u0000n#w.f\u0013y:\bC\u0014\u0004rr\u001b|";
      m[48] = "Y?PeE\u0014\u0012?\u0014j7伭厣优佴栁佪伭伽优佴\u0018\f\u001dZ'P#Y\u0016\u0003|";
      m[49] = "+f\u0000p\u00191`fD\u007fk桌发叟厺栔桲伈栋佁桠\r\u0006icd\t|\u0006e,g";
      m[50] = "\u000fww;23\\0anX9du!?efdH$n<&A!v\u007f*0";
      m[51] = "Z\u000fR\u001d\u001c\u001c\u0011\u000f\u0016\u0012n伥厠伨栲厣厭伥伾伨佶`RB\f\u000fI\u0018R\t\u0007K";
      m[52] = ",I#\u0004C\u000b$D-\f%=\u0014|\u00040%\u00015^'\rJ\t8P/";
      m[53] = "l1z]\fR?vl\bfX\u00073,Z]\n\u0007\u000e)\b\u0002G\"g{\u0019\u0014Q";
      m[54] = "'}0\u0007m2t:&R\u00078L\u007ff\u00076mLBcRc'i+1Cu1";
      m[55] = "SLO\u0003^w\u0018L\u000b\f,低厩佫栯桧栵叐伷佫佫~@x\u000bXI\u0005^p\u0012T";
      m[56] = "\u001ac:\u0007\u001d@I$,RwJqal\u0002J\u001aq\\iR\u0013UT5;C\u0005C";
      m[57] = "Ea<}>\u001d\u0016&*(T\u0017.go{iAD\tR|=\u001d\b,;.,\u000b\u001e";
      m[58] = "J\n!\u0015P\"\u0019M7@:(!\fr\u0013\u0007{NbO\u0014S\"\u0007G&FB4\u0011";
      m[59] = "\u0014H95\\\u0018G\u000f/`6\u0012\u007fJo7\u000bF\u007fwj`R\rZ\u001e8qD\u001b";
      m[60] = "bwZ!\u0002\u0003eh\n.g\u000eQ#Q%VXQ\u0013Uc\u0001\\es[x\u0006\u0012";
      m[61] = ">\u0017Vn9\u0013u\u0017\u0012aK厴佚厮召栊伖厴叄估佲\u0013&Kv\u0015_b&G9\u0016";
      m[62] = " F\u0012\\~Ts\u0001\u0004\t\u0014^KDDZ*\fKyA\tpAn\u0010\u0013\u0018fW";
      m[63] = "cdqm!\u00050#g8K\u000f\bf'hq[\b[\"8/\u0010-2p)9\u0006";
      m[64] = "'g1T\u001e`t '\u0001tjLabRH:*\u000f_U\u001d`j*6\u0007\fv|";
      m[65] = "\u001beVQwHPe\u0012^\u0005佱栻佂召佱栜可栻佂召,h\u0010Sg_]h\u001c\u001cd";
      m[66] = "`X`Ng\f+X$A\u0015伵伄栻佄佮佈桱伄栻栀3%\u0018dB`Cr\u00017P";
      m[67] = "\u0014h&\u0011\u0006jG/0Dl`\u007fjp\u0016S3\u007fWuD\b\u007fZ>'U\u001ei";
      m[68] = "\ti\u007ft\u0015\u0015Gn<eo桩校厔叀佂伲厳叻伊佞\u001f^ND<yz\u0010I\u0007-";
      m[69] = "-3\u001d\u0011Au~t\u000bD+\u007fF1K\u0015\u001b,F\fNDO`ce\u001cUYv";
      m[70] = "L{sr\u001c\t\u0007{7}n厮桬栘叉佒桷厮伨参叉\u000f^\u001dHas\u007f\t\u0004\u001bs";
      m[71] = "d7570\to<%?HWQ``~v\u0002QQ:{6V:=(+7R";
      m[72] = "\u001ck\u000fe8dD0Ql\u0002w,fT:;$,V\u000ehpf\u0019lVhx$";
      m[73] = "\u001fzz@I,L=l\u0015#&ty%M\u0012ttE)\u0015G9Q,{\u0004Q/";
      m[74] = "\u0000\u0000\u0005)v\u0015\u0002RI/\u0013F1\rMt#\u00101=I4u\u0014\u0005]G/rZ";
      m[75] = "fI\u0005\nFr-IA\u00054叕厜佮县厴佩佋厜株伡wY*.K\f\u0006Y&aH";
      m[76] = "m\u0014Ljr\u001fcA_+C厣佑厸栾桋桚伽佑伦佺R!Q3\u0018I=.YqC";
      m[77] = "\u001c\u001ct\u001bN=W\u001c0\u0014<桀格桿栔厥叿伄格桿栔f\u0000cJ\u001co\u001e\u0000(AX";
      m[78] = "$Xb\u0004-\f-Pfh=n9Ma\u0016)\u00001Inh";
      m[79] = "\tD^\u0017\u001fBZ\u0003HBuHbG\u0001\u001aD\u0019b{\rB\u0011WG\u0012_S\u0007A";
      m[80] = "\u001fpJ*D\u001fTp\u000e%6桢句佗台桎叵伦句佗台W\u0006\u000b\u001bjJ'Q\u0012Hx";
      m[81] = "_\u0004\u0011V\u000bG]V]Pn\u0014n\tY\u000b^Cn9]K\bFZYSP\u000f\b";
      m[82] = "H\u001da38\u000b\u0003\u001d%<J厬伬伺叛厍众伲伬厤叛NvU\u001e\u001dz6v\u001e\u0015Y";
      m[83] = "\\gss\u0019A\u0017g7|k另桼佀叉体伶佸桼佀栓\u000e\u0006\u0019\u0014ez\u007f\u0006\u0015[f";
      m[84] = "SnC(JJZfGDz(N{@:NFF\u007fODYL\u00056\u00176R\u0011@g.";
      m[85] = "rad'P|!&rr:v\u0019c2!\u0000(\u0019^7r^i<7ecH\u007f";
      m[86] = "<\u0001V{m2w\u0001\u0012t\u001f厕栜伦召栟栆桏佘伦召\u0006#lj\u0001M~#'aE";
      m[87] = ">u;m\u0004\u0001m2-8n\u000bUshkRT<\u001dUl\u0007\u0001s8<>\u0016\u0017e";
      m[88] = "\u00064\u0004NJRM4@A8叵栦桗桤台佥栯叼伓桤3U\nN6\rBU\u0006\u00015";
      m[89] = "7\t^FWfdNH\u0013=l\\\u000f\r@\u0001=7a0GTfzDY\u0015Epl";
      m[90] = "\u0002\u0000{z|\u001fU\u0019u=D!/9@JD\u0013\u0017\u001fa?%D\u000e\u0011&";
      m[91] = "$0\r^AUww\u001b\u000b+_O6^X\u0017\u000e)Xc_BUi}\n\rSC\u007f";
      m[92] = "K-/\u0011\u0010G\u0000-k\u001eb叠桫桎桏厯伿叠伯桎伋lRSO7/\u001c\u0005J\u001c%";
      m[93] = "9o\b}M\u0010j(\u001e('\u001aRm^~\u001dNRP[(C\u0005w9\t9U\u0013";
      m[94] = "G\u0006\u001f`wJ\u001fR\u0019w\u0013叧伤叻厣佘叐栽伤叻厣\u0005\"\u001a\u0005S\u001a`l\u001dFB";
      m[95] = "\nF\"f8o\u001bI,xZ叓厩栮桑余厙栉桳叴桑\u0004:a\u0000U*{+n\u000eK";
      m[96] = "c\u0017X|3zd\b\bsVwPCSxg PsW>0%d\u0013Y%7k";
      m[97] = "7R\u0010\u00042s|RT\u000b@栎反併伴厺桙佊栗併桰yp*tB\u0019E%tp\u0016";
      m[98] = ")gIT]gbg\r[/佞位佀栩佴栶佞叓栄栩)\u001fs-}IYHj~o";
      m[99] = "\u0003:L/B\u0017P}Zz(\u001dh9\u0013\"\u0019Kh\u0005\u001fzL\u0002MlMkZ\u0014";
      m[100] = "M\u0012${)u\u0006\u0012`t[叒桭桱伀叅厘栈伩厫厞\u0006kaI\b$v<x\u001a\u001a";
      m[101] = "CFI{g}\bF\rt\u0015栀档佡右叅取佄厹栥栩\u0006%iG\\Ivrp\u0014N";
      m[102] = "xA\u0011Pv13AU_\u0004伈厂栢厫叮余厖桘佦桱-4%|[\u0011]c</I";
      m[103] = "\u001bk\u000fmh{H,\u00198\u0002qpiYi2.pT\\8fnU=\u000e)px";
      m[104] = "%x\u0004 /Cnx@/]佺佁栛桤厞厞佺栅栛厾]mW!b\u0004-:Nrp";
      m[105] = ";r\tn'+h5\u001f;M!PtZhq~?\u001ago$+v?\u000e=5=`";
      m[106] = "'\u001a&`-8t]05G2L\u0018pczfL%u5#-iL'$5;";
      m[107] = "<:\u001bW\u0001Lo}\r\u0002kFW8MTS\u0015W\u0005H\u0002\u000fYrl\u001a\u0013\u0019O";
      m[108] = "\\R\u001a\u0017E\u001d[MJ\u0018 \u0010o\u0006\u0011\u0013\u0010No6\u0015UFB[V\u001bNA\f";
      m[109] = "`L&yA<+Lbv3桁厚栯厜栝佮厛厚叵框\u0004X18P>i\r#cV";
      m[110] = "UL\u0002x\u0018O\u001eLFwj佶厯栯桢叆厩佶厯佫桢\u0005UO\u001eO\tn[[\u0002X";
      m[111] = "}G}`\u0001{.\u0000k5kq\u0016D\"mZ&\u0016x.5\u000fn3\u0011|$\u0019x";
      m[112] = "#4U`>[h4\u0011oL佢佇厍佱栄休栦叙桗佱\u001ds[h7^v}Ot ";
      m[113] = "n\u0001?zvs%\u0001{u\u0004~WA'6yz'\n?`a\u0017m\u001awzig&\u0002!b\u0004";
      m[114] = "(}\u0015X\\\u0003c}QW.厤叒佚桵格样厤佌栞厯%C[`\u007f\u001cTCW/|";
      m[115] = "\u0015\u000f\u001e9\u00060FH\bll:~\rH>Wm~0Ml\b%[Y\u001f}\u001e3";
      m[116] = "\f\u0012L\u001f\u0016}G\u0012\b\u0010d叚栬厫佨桻桽佄叶厫佨b\r\"V\u0001Y\u0007\thM\u001a";
      m[117] = "\u0005#\u0003l\u001b\u0003N#Gci厤佡桀档佌厪桾佡桀伧\u0011\u0004[M!\n`\u0004W\u0002\"";
      m[118] = "&s\u007fuD-u4i .'Mu,s\u0013x%\u001b\u0011tG-k>x&V;}";
      m[119] = "7uSs}9d2E&\u00173\\w\u0005v,g\\J\u0000&s,y#R7e:";
      m[120] = "OBY\r13\u0004B\u001d\u0002C伊桯佥佽厳厀伊伫校佽p*+\u000f@\u001a\u0019z;IJ";
      m[121] = " \u0006\u001565|sA\u0003c_vK\u0000F0c'&n{76|mK\u0012e'j{";
      m[122] = "y\u0019\rS852\u0019I\\J伌伝厠桭叭厉案厃桺桭.vk/\u0019\u0016Vv $]";
      m[123] = "\u001bH/BL'H\u000f9\u0017&-pJyF\u0016{pw|\u0017B2U\u001e.\u0006T$";
      m[124] = " @\u0014\u0004Wix\u0014\u0012\u00133叄叝厽伶厢株栞叝伣厨a\r{xB\b\u0001\u0003`\u007f\f";
      m[125] = "$.\rrR\u0006wi\u001b'8\fO,[p\u0002]O\u0011^'\\\u0013jx\f6J\u0005";
      m[126] = "sk\u0011#.K ,\u0007vDA\u0018mB%y\u0017q\u0003\u007f\"-K>&\u0016p<](";
      m[127] = "fd\u0013>mv-dW1\u001f发伂佃伷桚佂住伂标桳C/bb~\u00133x{1l";
      m[128] = "wi|-\u0003K9n?<y样伛伊佝桟桠样伛厔佝FH\u0010:<z#\u0006\u0017y-";
      m[129] = "\u0006Q/z+\u0005U\u00169/A\u000fmW|||Z\u00059A{(\u0005K\u001c()9\u0013]";
      m[130] = "gzH)G\u00134=^|-\u0019\fy\u0017$\u001cI\fE\u001b|I\u0006),Im_\u0010";
      m[131] = "[&\u0017^r\u001c\ba\u0001\u000b\u0018\u00160 DX$FWNy_q\u001c\u0016k\u0010\r`\n\u0000";
      m[132] = "1SW~O%b\u0014A+%/ZQ\u0001z\u0015xZl\u0004+A0\u007f\u0005V:W&";
      m[133] = "woZqX\u0016$(L$2\u001c\u001ci\tw\u000eMp\u00074p[\u0016:\"]\"J\u0000,";
      m[134] = "\u0003\u007f (*nP86}@dhys.|;\u0006\u0017N))nN2'{8xX";
      m[135] = "\u001d:JS\u001d\u0017V:\u000e\\o厰栽伝台样桶伮佹伝佮._\u0003\u0019 J^\b\u001aJ2";
      m[136] = "\u0006Bq\u0002@9\u0001]!\r%45\u0016z\u0006\u0014a5&~@Cf\u0001Fp[D(";
      m[137] = "|X\u0004K\u001dUtU\nC{vTn2k,~Xb\"\u007f{_eO\u0000B\u0014WhA\b";
      m[138] = "R[d_{U\u001c\\'N\u0001右厠桼栁佩参栩桺伸栁40\u000e\u001f\u000ebQ~\t\\\u001f";
      m[139] = "Va\b\u00115\u0016\u001daL\u001eG桫厬栂桨伱桞伯桶但桨l#O\u0006\"I\u0013,\u000b\u000b#";
      m[140] = "y\rj~|\u000f2\r.q\u000e桲伝厴栊栚栗桲厃厴栊\u0003cW1\u000fcrc[~\f";
      m[141] = "XG}-1.\u000b\u0000kx[$3A.+gt[/\u0013,2.\u0015\nz~#8\u0003";
      m[142] = "@f\u00197%ZB4U1@\tqkQj\u007fVq[U*&[E;[1!\u0015";
      m[143] = ".%=4\u0018de%y;j佝栎框桝桐伷栙叔框厇I\u0000gt.!xUdu%";
      m[144] = "y:L9V_2:\b6$司伝伝栬伙栽栢桙伝叶D\u0018\u0001/:W<\u0018J$~";
      m[145] = "aq|,=`*q8#O叇桁又栜伌桖余伅佖栜Q\"8)su \"4fp";
      m[146] = "\u000b\u0012\u0013C\rxE\u0015PRw叞佧佱桶栱伪栄叹佱桶(F#FG\u0015M\b$\u0005V";
      m[147] = "ti\n\u001bfxsvZ\u0014\u0003uG=\u0001\u001f3*G\r\u0005Ye'sm\u000bBbi";
      m[148] = "|[Ltt//\u001cZ!\u001e%\u0017Y\u001ar#t\u0017d\u001f!z:2\rM0l,";
      m[149] = "f\u0012=p;:-\u0012y\u007fI伃厜桱桝収厊厝伂桱厇\r-c6Q|r\"';P";
      m[150] = "'Z9nK\u0003lZ}a9厤标根厃低佤厤叝口伝\u0013\t\u0017#@9c^\u000epR";
      m[151] = "\n5\"j!pYr4?Kza6}gz$a\nq?/eDc#.9s";
      m[152] = "~\u001es[\u0004\u0004-Ye\u000en\u000e\u0015\u0018 ]RQ}v\u001dZ\u0007\u00043St\b\u0016\u0012%";
      m[153] = "\u0012G\\\u0018FWYG\u0018\u00174佮叨栤格桼号株叨叾佸e\u0004C\u0016]\\\u0015SZEO";
      m[154] = "S*JP\\7\u0018*\u000e_.伎厩桉佮栴叭桊桳伍佮-Jn\u0003i\u000bRE*\u000eh";
      m[155] = "(\u000fPac\u001dc\u000f\u0014n\u0011伤栈桬只佁佌厺叒厶只\u001cz\u001fq\u001bKl{@w\u001a";
   }

   @EventTarget
   public void m(WorldEvent event) {
      BetterCamera.e();
      if (this.何友何树树树友何何何 != mc.level) {
         this.何友何树树树友何何何 = mc.level;
         this.树友何何友树何树何树.clear();
         this.何何友何树何树友树何.clear();
         this.何友树树友友何友何树.clear();
         this.何树何何友友何何树何.clear();
         ClientUtils.P(125527250587045L, "§a新世界已检测，矿物数据已重置");
      }
   }

   private boolean o(Block block1, Block block2) {
      BetterCamera.e();
      if (block1 != null && block2 != null) {
         if (block1 != Blocks.DIAMOND_ORE && block1 != Blocks.DEEPSLATE_DIAMOND_ORE || block2 != Blocks.DIAMOND_ORE && block2 != Blocks.DEEPSLATE_DIAMOND_ORE) {
            if (block1 != Blocks.REDSTONE_ORE && block1 != Blocks.DEEPSLATE_REDSTONE_ORE
               || block2 != Blocks.REDSTONE_ORE && block2 != Blocks.DEEPSLATE_REDSTONE_ORE) {
               if (block1 != Blocks.IRON_ORE && block1 != Blocks.DEEPSLATE_IRON_ORE || block2 != Blocks.IRON_ORE && block2 != Blocks.DEEPSLATE_IRON_ORE) {
                  if (block1 != Blocks.COAL_ORE && block1 != Blocks.DEEPSLATE_COAL_ORE || block2 != Blocks.COAL_ORE && block2 != Blocks.DEEPSLATE_COAL_ORE) {
                     if (block1 != Blocks.GOLD_ORE && block1 != Blocks.DEEPSLATE_GOLD_ORE && block1 != Blocks.NETHER_GOLD_ORE
                        || block2 != Blocks.GOLD_ORE && block2 != Blocks.DEEPSLATE_GOLD_ORE && block2 != Blocks.NETHER_GOLD_ORE) {
                        if (block1 != Blocks.EMERALD_ORE && block1 != Blocks.DEEPSLATE_EMERALD_ORE
                           || block2 != Blocks.EMERALD_ORE && block2 != Blocks.DEEPSLATE_EMERALD_ORE) {
                           if (block1 != Blocks.LAPIS_ORE && block1 != Blocks.DEEPSLATE_LAPIS_ORE
                              || block2 != Blocks.LAPIS_ORE && block2 != Blocks.DEEPSLATE_LAPIS_ORE) {
                              return block1 != Blocks.COPPER_ORE && block1 != Blocks.DEEPSLATE_COPPER_ORE
                                    || block2 != Blocks.COPPER_ORE && block2 != Blocks.DEEPSLATE_COPPER_ORE
                                 ? block1 == block2
                                 : true;
                           } else {
                              return true;
                           }
                        } else {
                           return true;
                        }
                     } else {
                        return true;
                     }
                  } else {
                     return true;
                  }
               } else {
                  return true;
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void t(BlockPos playerPos, int scanRange) {
      int px = playerPos.getX();
      BetterCamera.e();
      int py = playerPos.getY();
      int pz = playerPos.getZ();
      int x = px - scanRange;
      if (x <= px + scanRange) {
         int y = Math.max(mc.level.getMinBuildHeight(), py - scanRange);
         if (y <= Math.min(mc.level.getMaxBuildHeight(), py + scanRange)) {
            int z = pz - scanRange;
            if (z <= pz + scanRange) {
               BlockPos pos = new BlockPos(x, y, z);
               Block block = 友树友友树何树友树友.g(85526755286720L, pos);
               if (this.j(block)) {
                  树树何何何何友树友何.友友友友何友树友树树 type = this.S(block);
                  this.树友何何友树何树何树.put(pos, new 树树何何何何友树友何.树何树何树友何树树树(block, type, 10.0));
               }

               z++;
            }

            y++;
         }

         x++;
      }
   }

   @EventTarget
   public void v(TickEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.何何何树何树何友树树.getValue()) {
            this.s();
         }

         if (this.何树树树树何树友树友.A(this.友何何树何树树树何友.getValue().longValue(), 118344821288830L)) {
            BlockPos currentPlayerPos = mc.player.blockPosition();
            boolean hasMovedSignificantly = true;
            if (this.何树树友何何友友友友 != null && currentPlayerPos.distSqr(this.何树树友何何友友友友) < 4.0) {
               hasMovedSignificantly = false;
            }

            if (hasMovedSignificantly || this.何树树友何何友友友友 == null) {
               this.何树树友何何友友友友 = currentPlayerPos;
               if (!this.树友树友树何友友友树) {
                  this.树友树友树何友友友树 = true;
                  树友何何何树何树友友.G(() -> {
                     try {
                        this.Z(currentPlayerPos, this.友树何友树树树何何友.getValue().intValue());
                     } finally {
                        this.树友树友树何友友友树 = false;
                     }
                  }, 108624793298909L);
               }
            }

            this.何树树树树何树友树友.D(11747522392279L);
         }
      }
   }

   private double v(BlockPos orePos, Block oreBlock) {
      BetterCamera.e();
      int y = orePos.getY();
      if (oreBlock == Blocks.DIAMOND_ORE || oreBlock == Blocks.DEEPSLATE_DIAMOND_ORE) {
         if (y >= -64 && y <= 16) {
            return 2.0;
         }

         if (y <= -32) {
            return 1.5;
         }
      }

      if ((oreBlock == Blocks.IRON_ORE || oreBlock == Blocks.DEEPSLATE_IRON_ORE) && y >= -64 && y <= 320) {
         return 2.0;
      } else {
         return (oreBlock == Blocks.COAL_ORE || oreBlock == Blocks.DEEPSLATE_COAL_ORE) && y >= 0 && y <= 320 ? 2.0 : 0.5;
      }
   }

   private boolean j(Block block) {
      d<"Â">(-3551774862399881385L, 50444091313830L);
      String var5 = d<"K">(this, -3565906395599049219L, 50444091313830L).getValue();
      byte var6 = -1;
      switch (var5.hashCode()) {
         case 2466289:
            if (!var5.equals("")) {
               break;
            }

            var6 = 0;
         case 1234985285:
            if (!var5.equals("Valuables")) {
               break;
            }

            var6 = 1;
         case 65921:
            if (var5.equals("All")) {
               var6 = 2;
            }
      }
      return switch (var6) {
         case 0 -> this.f(block);
         case 1 -> this.s(block);
         case 2 -> this.f(block) || this.s(block);
         default -> this.f(block);
      };
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean q(Set<BlockPos> cave) {
      BetterCamera.e();
      if (cave.stream().anyMatch(this::X)) {
         return true;
      } else {
         double linearFactor = this.B(cave);
         if (linearFactor >= 0.7) {
            return false;
         } else {
            double branchFactor = this.J(cave);
            if (branchFactor <= 0.3) {
               return false;
            } else {
               double heightVariance = this.f(cave);
               return heightVariance > 3.0;
            }
         }
      }
   }

   private void U(Set<BlockPos> caveBlocks) {
      BetterCamera.e();
      Iterator var7 = caveBlocks.iterator();
      if (var7.hasNext()) {
         BlockPos caveBlock = (BlockPos)var7.next();
         Direction[] var9 = Direction.values();
         int var10 = var9.length;
         int var11 = 0;
         if (0 < var10) {
            Direction dir = var9[0];
            BlockPos adjacentPos = caveBlock.relative(dir);
            Block block = 友树友友树何树友树友.g(85526755286720L, adjacentPos);
            if (this.j(block)) {
               double authenticity = this.A(adjacentPos, block);
               if (authenticity >= this.何友何树友友何何何何.getValue().doubleValue() && this.V(adjacentPos, block, this.友何树树何何友树友树.getValue().intValue())) {
                  树树何何何何友树友何.友友友友何友树友树树 type = this.S(block);
                  this.树友何何友树何树何树.put(adjacentPos, new 树树何何何何友树友何.树何树何树友何树树树(block, type, authenticity));
               }
            }

            var11++;
         }
      }
   }

   private Set<BlockPos> z(BlockPos startNodePos, Set<BlockPos> visitedGlobal, int maxRangeFromPlayer, BlockPos playerPos) {
      HashSet currentCaveBlocks = new HashSet();
      BetterCamera.e();
      Queue<BlockPos> queue = new LinkedList<>();
      int maxFillSize = this.何何友树友友树友树树.getValue().intValue() * 10;
      queue.add(startNodePos);
      currentCaveBlocks.add(startNodePos);
      if (!queue.isEmpty() && currentCaveBlocks.size() < maxFillSize) {
         BlockPos currentPos = queue.poll();
         int[][] var12 = 何友何何树何何何何何;
         int var13 = var12.length;
         int var14 = 0;
         label24:
         if (0 < var13) {
            int[] dir = var12[0];
            BlockPos nextPos = new BlockPos(currentPos.getX() + dir[0], currentPos.getY() + dir[1], currentPos.getZ() + dir[2]);
            if (nextPos.distManhattan(playerPos) > maxRangeFromPlayer) {
            }

            if (this.h(nextPos) && visitedGlobal.add(nextPos)) {
               if (currentCaveBlocks.size() >= maxFillSize) {
                  break label24;
               }

               currentCaveBlocks.add(nextPos);
               queue.add(nextPos);
            }

            var14++;
         }

         if (currentCaveBlocks.size() >= maxFillSize) {
         }
      }

      return currentCaveBlocks;
   }

   private void w(PoseStack poseStack, BlockPos pos, 树树何何何何友树友何.树何树何树友何树树树 info, Vec3 camPos) {
      AABB box = new AABB(pos);
      Color color = this.Y(info.树何树何何何友何树何);
      String var10 = this.何友树何树友树树何何.getValue();
      BetterCamera.e();
      byte var11 = -1;
      switch (var10.hashCode()) {
         case 2222509:
            if (!var10.equals("Glow")) {
               break;
            }

            var11 = 0;
         case 2368532:
            if (!var10.equals("Line")) {
               break;
            }

            var11 = 1;
         case 2076577:
            if (var10.equals("Both")) {
               var11 = 2;
            }
      }

      switch (var11) {
         case 0: {
            AABB fillBox = new AABB(pos.getX() + 0.1, pos.getY() + 0.1, pos.getZ() + 0.1, pos.getX() + 0.9, pos.getY() + 0.9, pos.getZ() + 0.9);
            Color fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), 100);
            this.h(poseStack, fillBox, fillColor, camPos);
         }
         case 1:
            this.c(poseStack, box, color, camPos);
         case 2: {
            AABB fillBox = new AABB(pos.getX() + 0.1, pos.getY() + 0.1, pos.getZ() + 0.1, pos.getX() + 0.9, pos.getY() + 0.9, pos.getZ() + 0.9);
            Color fillColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), 100);
            this.h(poseStack, fillBox, fillColor, camPos);
            this.c(poseStack, box, color, camPos);
         }
      }
   }

   private double u(BlockPos orePos) {
      double score = 0.0;
      BetterCamera.e();
      int airBlocks = 0;
      int stoneBlocks = 0;
      Direction[] var11 = Direction.values();
      int var12 = var11.length;
      int var13 = 0;
      if (0 < var12) {
         Direction dir = var11[0];
         BlockPos adjacent = orePos.relative(dir);
         Block block = 友树友友树何树友树友.g(85526755286720L, adjacent);
         if (this.h(adjacent)) {
            airBlocks++;
         }

         if (block == Blocks.STONE || block == Blocks.DEEPSLATE) {
            stoneBlocks++;
         }

         var13++;
      }

      if (airBlocks >= 1 && airBlocks <= 3) {
         score = 1.5;
      }

      if (stoneBlocks >= 3) {
         score++;
      }

      return score;
   }

   private double A(BlockPos orePos, Block oreBlock) {
      BetterCamera.e();
      if (this.Q(new Object[]{52406761729175L})) {
         return 0.0;
      } else {
         double score = 0.0 + this.v(orePos, oreBlock) + this.b(orePos) + this.f(orePos, oreBlock) + this.u(orePos) + this.h(orePos);
         int exposedFaces = 0;
         Direction[] var11 = Direction.values();
         int var12 = var11.length;
         int var13 = 0;
         if (0 < var12) {
            Direction dir = var11[0];
            if (this.h(orePos.relative(dir))) {
               exposedFaces++;
            }

            var13++;
         }

         if (exposedFaces > 0 && exposedFaces < 6) {
            score += 2.0;
         }

         if (exposedFaces == 6) {
            score--;
         }

         return Math.max(0.0, Math.min(10.0, score));
      }
   }

   private Color Y(Block block) {
      BetterCamera.e();
      if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) {
         return this.友何树树何友树何树何.getValue();
      } else if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) {
         return this.何树何友何树友树何友.getValue();
      } else if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) {
         return this.友树友树何树何何何树.getValue();
      } else if (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE) {
         return this.友树何友何何何树何树.getValue();
      } else if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.NETHER_GOLD_ORE) {
         return this.树何友树树树树友友树.getValue();
      } else if (block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE) {
         return this.友树树树友何树友何树.getValue();
      } else if (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE) {
         return this.友何友友树何友友何何.getValue();
      } else if (block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE) {
         return this.树友友友树树何树何树.getValue();
      } else if (block == Blocks.SPAWNER) {
         return this.友友何树树树友何树友.getValue();
      } else if (block == Blocks.COBBLESTONE) {
         return this.友友何友友何何友树何.getValue();
      } else {
         return block == Blocks.END_PORTAL ? this.友树友树何友树友何何.getValue() : Color.WHITE;
      }
   }

   private boolean X(BlockPos pos) {
      Direction[] var7 = Direction.values();
      BetterCamera.e();
      int var8 = var7.length;
      int var9 = 0;
      if (0 < var8) {
         Direction dir = var7[0];
         BlockPos adjacent = pos.relative(dir);
         Block block = 友树友友树何树友树友.g(85526755286720L, adjacent);
         if (block == Blocks.DEEPSLATE
            || block == Blocks.CALCITE
            || block == Blocks.DRIPSTONE_BLOCK
            || block == Blocks.AMETHYST_BLOCK
            || block == Blocks.SMOOTH_BASALT
            || block == Blocks.TUFF) {
            return true;
         }

         var9++;
      }

      return false;
   }

   @Override
   protected void M() {
      this.树友何何友树何树何树.clear();
      this.何何友何树何树友树何.clear();
      this.何友树树友友何友何树.clear();
      this.何树何何友友何何树何.clear();
      this.何树树友何何友友友友 = null;
      this.友树友何树树何友友何 = 0L;
      this.何树树树树何树友树友.D(11747522392279L);
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private boolean N(树树何何何何友树友何.树何树何树友何树树树 info) {
      BetterCamera.e();
      switch (树树何何何何友树友何$何友友何树友树树树树.友何友树树树何何何何[info.友何友友何友树何友友.ordinal()]) {
         case 1:
            return this.j(info.树何树何何何友何树何);
         case 2:
         case 3:
            return this.何何树树友友何树树友.getValue();
         case 4:
            return this.友树何友树树何何何何.getValue();
         case 5:
            return this.树树何友友友何友树树.getValue();
         default:
            return false;
      }
   }

   private boolean K(Block block) {
      BetterCamera.e();
      return block == Blocks.OAK_PLANKS || block == Blocks.OAK_FENCE || block == Blocks.RAIL || block == Blocks.TORCH;
   }

   @EventTarget
   public void Q(Render3DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         Vec3 camPos = mc.gameRenderer.getMainCamera().getPosition();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         RenderSystem.setShader(GameRenderer::getPositionColorShader);
         PoseStack poseStack = event.poseStack();
         poseStack.pushPose();

         try {
            this.何树何何友友何何树何.clear();
            Iterator var9 = this.树友何何友树何树何树.entrySet().iterator();
            if (var9.hasNext()) {
               Entry<BlockPos, 树树何何何何友树友何.树何树何树友何树树树> entry = (Entry<BlockPos, 树树何何何何友树友何.树何树何树友何树树树>)var9.next();
               BlockPos pos = entry.getKey();
               树树何何何何友树友何.树何树何树友何树树树 info = entry.getValue();
               if (mc.level.isLoaded(pos)) {
                  Block currentBlock = mc.level.getBlockState(pos).getBlock();
                  if (currentBlock == info.树何树何何何友何树何 && this.N(info)) {
                     this.何树何何友友何何树何.add(pos);
                     this.w(poseStack, pos, info, camPos);
                  }
               }
            }

            this.树友何何友树何树何树.entrySet().removeIf(entryx -> {
               BetterCamera.e();
               return !this.何树何何友友何何树何.contains(entryx.getKey());
            });
         } finally {
            poseStack.popPose();
            RenderSystem.enableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "何建国230622195906030014";
   }

   private void O(BlockPos playerPos, int scanRange) {
      BetterCamera.e();
      if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
         int px = playerPos.getX();
         int py = playerPos.getY();
         int pz = playerPos.getZ();
         Set<BlockPos> visitedInScan = new HashSet<>();
         int x = px - scanRange;
         if (x <= px + scanRange) {
            int y = Math.max(mc.level.getMinBuildHeight(), py - scanRange);
            if (y <= Math.min(mc.level.getMaxBuildHeight(), py + scanRange)) {
               int z = pz - scanRange;
               if (z <= pz + scanRange) {
                  BlockPos pos = new BlockPos(x, y, z);
                  Block block = 友树友友树何树友树友.g(85526755286720L, pos);
                  if (block == Blocks.SPAWNER && this.何何树树友友何树树友.getValue()) {
                     this.树友何何友树何树何树.put(pos, new 树树何何何何友树友何.树何树何树友何树树树(block, 树树何何何何友树友何.友友友友何友树友树树.树何何何树树树何友何, 10.0));
                     this.x(pos);
                  }

                  if (block == Blocks.END_PORTAL && this.友树何友树树何何何何.getValue()) {
                     this.树友何何友树何树何树.put(pos, new 树树何何何何友树友何.树何树何树友何树树树(block, 树树何何何何友树友何.友友友友何友树友树树.友友树树何友树树何树, 10.0));
                  }

                  if (this.何友友树树友何友树友.getValue() && this.h(pos) && !visitedInScan.contains(pos)) {
                     Set<BlockPos> caveBlocks = this.z(pos, visitedInScan, scanRange, playerPos);
                     if (caveBlocks.size() >= this.何何友树友友树友树树.getValue().intValue() && this.q(caveBlocks)) {
                        this.U(caveBlocks);
                     }
                  }

                  z++;
               }

               y++;
            }

            x++;
         }
      }
   }

   private static enum 友友友友何友树友树树 implements  {
      友何何树树何树友何树,
      树何何何树树树何友何,
      何树树树何友友何树树,
      友友树树何友树树何树,
      树树友友何何友友何何;

      private static final long a;
      private static final Object[] b = new Object[9];
      private static final String[] c = new String[9];
      private static String HE_SHU_YOU;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-8367045156734684940L, 7515965917483833064L, MethodHandles.lookup().lookupClass()).a(239208503302316L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(3460330835932L << var2 * 8 >>> 56);
         }

         var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[5];
         int var6 = 0;
         String var5 = "b:ï¸»ÍQ\u000b\u0010 \b\u0080\u0091ç\u001a]¿Ì\u0092pN\u009a\u0088[o\b<Óx¥'«\u008co";
         byte var7 = 34;
         char var4 = '\b';
         int var9 = -1;

         label28:
         while (true) {
            String var11 = var5.substring(++var9, var9 + var4);
            byte var10001 = -1;

            while (true) {
               String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var17;
                     if ((var9 += var4) >= var7) {
                        友何何树树何树友何树 = new 树树何何何何友树友何.友友友友何友树友树树();
                        树何何何树树树何友何 = new 树树何何何何友树友何.友友友友何友树友树树();
                        何树树树何友友何树树 = new 树树何何何何友树友何.友友友友何友树友树树();
                        友友树树何友树树何树 = new 树树何何何何友树友何.友友友友何友树友树树();
                        树树友友何何友友何何 = new 树树何何何何友树友何.友友友友何友树友树树();
                        return;
                     }

                     var4 = var5.charAt(var9);
                     break;
                  default:
                     var0[var6++] = var17;
                     if ((var9 += var4) < var7) {
                        var4 = var5.charAt(var9);
                        continue label28;
                     }

                     var5 = "QÖ¬»3V°îï|\n\u0084¾'\u0014Ü3ý\u0011\u0011\nýAý\u00109®}\u000b95(6VH\u0002O·\t\u0004û";
                     var7 = 41;
                     var4 = 24;
                     var9 = -1;
               }

               var11 = var5.substring(++var9, var9 + var4);
               var10001 = 0;
            }
         }
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 248 && var8 != 'H' && var8 != 'p' && var8 != 251) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'y') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 221) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 248) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'H') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'p') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树树何何何何友树友何$友友友友何友树友树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 4;
                  case 1 -> 8;
                  case 2 -> 27;
                  case 3 -> 33;
                  case 4 -> 1;
                  case 5 -> 22;
                  case 6 -> 44;
                  case 7 -> 14;
                  case 8 -> 54;
                  case 9 -> 5;
                  case 10 -> 38;
                  case 11 -> 45;
                  case 12 -> 25;
                  case 13 -> 58;
                  case 14 -> 20;
                  case 15 -> 49;
                  case 16 -> 62;
                  case 17 -> 29;
                  case 18 -> 40;
                  case 19 -> 35;
                  case 20 -> 36;
                  case 21 -> 21;
                  case 22 -> 16;
                  case 23 -> 39;
                  case 24 -> 52;
                  case 25 -> 15;
                  case 26 -> 56;
                  case 27 -> 24;
                  case 28 -> 43;
                  case 29 -> 11;
                  case 30 -> 47;
                  case 31 -> 42;
                  case 32 -> 18;
                  case 33 -> 55;
                  case 34 -> 57;
                  case 35 -> 7;
                  case 36 -> 46;
                  case 37 -> 6;
                  case 38 -> 53;
                  case 39 -> 28;
                  case 40 -> 59;
                  case 41 -> 13;
                  case 42 -> 2;
                  case 43 -> 12;
                  case 44 -> 10;
                  case 45 -> 30;
                  case 46 -> 37;
                  case 47 -> 31;
                  case 48 -> 17;
                  case 49 -> 23;
                  case 50 -> 61;
                  case 51 -> 3;
                  case 52 -> 34;
                  case 53 -> 32;
                  case 54 -> 9;
                  case 55 -> 51;
                  case 56 -> 26;
                  case 57 -> 19;
                  case 58 -> 48;
                  case 59 -> 41;
                  case 60 -> 0;
                  case 61 -> 60;
                  case 62 -> 50;
                  default -> 63;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "Q|{\u0011{s^<6\u001aqn[a=\\ysVg9\u0017:u_b9\\fy\\v0\u0000:栍栣佇伀伧佁受栣叙伀V叟受叹叙伀厹栅受栣栃";
         b[1] = "\u001e\u001d\u0014Nb/*>\u001b\u000e/$ #\u001eS$b(>\u0013U )k8\u001aP b74\u0019D)>k桀桦併伙伙伐厚桦叫伙h厎厚厼叫伙厇桔厚桦栱w";
         b[2] = "5\u0002\f\u000f_k>\r\u001d@>e5\u0006\u0019\u001a";
         b[3] = "5^oq\u001a`c\u0005&\u001f栿栔厙佤厔佂佻佐伇栠W&\u0019=5^i.Ycj";
         b[4] = "_)iY6L\tr 7栓佼佭伓案栮栓佼右伓QXm\u0019^r<\u000e6P";
         b[5] = "\u0019\u00128X\u001fwOIq6佾栃桯桬佝叵叠佇桯桬\u0000YD\"\u0018Im\u000f\u001fk";
         b[6] = "\u000e\u0000>h\u0005DX[w\u0006叺只桸桾佛叅栠栰似桾\u0006i^\u0011\u000f[k?\u0005X";
         b[7] = "\"EE4\u0012Xt\u001e\fZ叭佨伐栻桤伇样叶伐栻}5I\r#\u001e\u0010c\u0012D";
         b[8] = "{(YC-\u0010-s\u0010-栈桤受厌似佰叒厾佉伒aBvEzs\f\u0014-\f";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      public static 树树何何何何友树友何.友友友友何友树友树树[] X() {
         return (树树何何何何友树友何.友友友友何友树友树树[])树树友何友何何何何树.clone();
      }

      public static 树树何何何何友树友何.友友友友何友树友树树 X(String name) {
         return Enum.valueOf(树树何何何何友树友何.友友友友何友树友树树.class, name);
      }

      private static String HE_DA_WEI() {
         return "何炜霖大狗叫";
      }
   }

   private static class 树何树何树友何树树树 implements 何树友 {
      final Block 树何树何何何友何树何;
      final 树树何何何何友树友何.友友友友何友树友树树 友何友友何友树何友友;
      final double 友友友何友树树友何友;
      final long 树何何树何树友树友友;
      private static int _何炜霖大狗叫 _;

      树何树何树友何树树树(Block block, 树树何何何何友树友何.友友友友何友树友树树 type, double authenticity) {
         this.树何树何何何友何树何 = block;
         this.友何友友何友树何友友 = type;
         this.友友友何友树树友何友 = authenticity;
         this.树何何树何树友树友友 = System.currentTimeMillis();
      }

      private static String LIU_YA_FENG() {
         return "职业技术教育中心学校";
      }
   }
}
