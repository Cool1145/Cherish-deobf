package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.value.impl.ModeValue;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何树何树树树树友树何 extends Module implements 何树友 {
   public ModeValue 树友友友树友友友友何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[15];
   private static final String[] k = new String[15];
   private static int _何炜霖黑水 _;

   public 何树何树树树树友树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;I)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/render/何树何树树树树友树何.a J
      // 03: ldc2_w 63926430096281
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 7058
      // 0c: ldc2_w 296408618921426162
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何树树树树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 26305
      // 19: ldc2_w 190807144820343205
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何树树树树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 8986034133120347011
      // 26: lload 1
      // 27: invokedynamic µ (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/何树何树树树树友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: sipush 344
      // 2f: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;I)V
      // 32: aload 0
      // 33: new cn/cool/cherish/value/impl/ModeValue
      // 36: dup
      // 37: sipush 28276
      // 3a: ldc2_w 3457478452546439443
      // 3d: lload 1
      // 3e: lxor
      // 3f: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何树树树树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 44: sipush 16467
      // 47: ldc2_w 5882586233051096886
      // 4a: lload 1
      // 4b: lxor
      // 4c: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何树树树树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 51: bipush 2
      // 52: anewarray 59
      // 55: dup
      // 56: bipush 0
      // 57: sipush 3893
      // 5a: ldc2_w 5571943295601895511
      // 5d: lload 1
      // 5e: lxor
      // 5f: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何树树树树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 64: aastore
      // 65: dup
      // 66: bipush 1
      // 67: sipush 24812
      // 6a: ldc2_w 4369214722118813578
      // 6d: lload 1
      // 6e: lxor
      // 6f: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何树树树树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 74: aastore
      // 75: sipush 23497
      // 78: ldc2_w 7431817270833724584
      // 7b: lload 1
      // 7c: lxor
      // 7d: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/何树何树树树树友树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 82: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 85: ldc2_w 8985897687910731688
      // 88: lload 1
      // 89: invokedynamic À (Ljava/lang/Object;Lcn/cool/cherish/value/impl/ModeValue;JJ)V bsm=cn/cool/cherish/module/impl/render/何树何树树树树友树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 8e: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-4407697304396494735L, -2114579352444030793L, MethodHandles.lookup().lookupClass()).a(235451292869693L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 75917572185133L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[8];
      int var7 = 0;
      String var6 = ")\u001f\u001bß½¶Ö\u00940\f%G\u0086\u009dlh öþXT\u001f\u0096pg¿Ð=^ñÍ\u0013ÃN0ø\u001c,þrBËd*·\u0092\u0081Y¾\u0010\u0098f<âö\u008aã\f_\u0011ÐâªMã\u0082\u0010\u0096÷t_#ë2\u0019r\u0004L\u009d9á\u00911\u0010\u0099\u00918Õ\u0019`\n\\ô8íâ|Ú©\u0084\u0018u\u0082~3ï±+h ¼5Éº\u0081vÐK4\u0000\u001a\u000e\u0088P\u009e";
      byte var8 = 125;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[8];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "óþHð\u000e\u0096@\u0002h\u001e×Ög \u000f~\u0010ß\u0000v\u008b7\u0011è\u0096ª¡\u0096RC¢Y¼";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 25;
               case 1 -> 57;
               case 2 -> 26;
               case 3 -> 49;
               case 4 -> 17;
               case 5 -> 36;
               case 6 -> 6;
               case 7 -> 33;
               case 8 -> 47;
               case 9 -> 63;
               case 10 -> 62;
               case 11 -> 54;
               case 12 -> 24;
               case 13 -> 35;
               case 14 -> 40;
               case 15 -> 9;
               case 16 -> 1;
               case 17 -> 61;
               case 18 -> 8;
               case 19 -> 0;
               case 20 -> 28;
               case 21 -> 44;
               case 22 -> 58;
               case 23 -> 12;
               case 24 -> 20;
               case 25 -> 46;
               case 26 -> 15;
               case 27 -> 59;
               case 28 -> 53;
               case 29 -> 55;
               case 30 -> 32;
               case 31 -> 21;
               case 32 -> 31;
               case 33 -> 39;
               case 34 -> 43;
               case 35 -> 19;
               case 36 -> 34;
               case 37 -> 48;
               case 38 -> 42;
               case 39 -> 38;
               case 40 -> 27;
               case 41 -> 3;
               case 42 -> 13;
               case 43 -> 56;
               case 44 -> 30;
               case 45 -> 4;
               case 46 -> 5;
               case 47 -> 41;
               case 48 -> 18;
               case 49 -> 23;
               case 50 -> 16;
               case 51 -> 37;
               case 52 -> 52;
               case 53 -> 10;
               case 54 -> 50;
               case 55 -> 29;
               case 56 -> 14;
               case 57 -> 51;
               case 58 -> 60;
               case 59 -> 2;
               case 60 -> 45;
               case 61 -> 11;
               case 62 -> 22;
               default -> 7;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/何树何树树树树友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7127;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/何树何树树树树友树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 206 && var8 != 192 && var8 != 181 && var8 != 'K') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'V') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 245) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 206) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 192) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 181) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/何树何树树树树友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "\u0016;=|\u001d\u0002\u0019{pw\u0017\u001f\u001c&{1\u001f\u0002\u0011 \u007fz\\伸传厞但佊厹伸传桄栂";
      j[1] = "x w8\u001b\u007fw`:3\u0011br=1u\u0019\u007f\u007f;5>Zyv>5u\u0006uu*<)Z佅栊伛案桊桥栁叐桟伌";
      j[2] = "L\u001f\f\u00179XC_A\u001c3EF\u0002JZ VC\u0004GZ?Z_\u001d\f99SJ'C\u0018#R";
      j[3] = "8\u0001)Fq\u00147AdM{\t2\u001co\u000bk\u0012u桾双栴叕伮伎厤双佰佋";
      j[4] = "\u0006L\u0014;$\u0016\t\fY0.\u000b\fQRv>\u0010K栳叱厓厀桨桴栳栫桉伞";
      j[5] = "\u0019]!O[[\u0012R0\u0000'B\u001dH>C\u0010r\u000b_2^\u0001^\u001cR";
      j[6] = "kd(~DMd$euNPayn3FMl\u007fjx\u0005Kezj3YGfnco\u0005`m~rxYaigcoJ";
      j[7] = "\n\u007f\u0005eSa\u0001p\u0014*.y\u0012w\u001dc";
      j[8] = "e\u001e!^WEn\u00110\u00116Ke\u001a4K";
      j[9] = "^\\\u0012+_\u0019^]G\u001a栩去可叴栳叙右去可佪*#JIAEOv_\u0007M";
      j[10] = "\u00191.ih`\u00190{Xn\u0001WcwidxR9(=\u0007=R;';~8\bdsX";
      j[11] = "V\u00132]}}ER(\"栉栎佪桴桉栻位叔叴厮PCnuH\u0000:P/o";
      j[12] = "\u001ee9\u000e4\u0003\u0013>5UH&\"8oGx\u0016\u0019o`_.x";
      j[13] = "P\":s\f\u0005\u0000|\"\u007fk厫桳栄厘佅桲厫厩栄厘\u0018QW\u000bv<u\u0001\t\u0013z";
      j[14] = "fh4\u000f\u001d%$o4\nq厀伀厑桃厫伬伞伀桋厙hJy356\u000e\b~30";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 何树何树树树树友树何.a ^ 81997705097530L;
      long ax = a ^ 116737586720573L;
      c<"õ">(-7631794376773161677L, a);
      if (Cherish.instance != null && Cherish.getConfigManager() != null && !this.w(new Object[]{ax})) {
         Cherish.getConfigManager().m();
         String var6 = c<"Î">(this, -7631592689903753973L, a).getValue();
         byte var7 = -1;
         switch (var6.hashCode()) {
            case 2368702:
               if (!var6.equals(b<"h">(23497, 7431905689243866635L ^ a))) {
                  break;
               }

               var7 = 0;
            case -1679830269:
               if (var6.equals(b<"h">(27501, 1005951263225145005L ^ a))) {
                  var7 = 1;
               }
         }

         switch (var7) {
            case 0:
               mc.setScreen(c<"µ">(-7631657498935600013L, a));
            case 1:
               mc.setScreen(c<"µ">(-7631904348040731532L, a));
            default:
               this.k();
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_WEI_LIN() {
      return "我是何树友";
   }
}
