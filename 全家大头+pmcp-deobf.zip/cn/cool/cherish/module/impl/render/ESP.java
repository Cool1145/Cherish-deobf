package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.scores.Team;
import org.joml.Vector4f;

public final class ESP extends Module implements 何树友 {
   public static ESP instance;
   public final ModeValue mode = new ModeValue("Mode", "模式", new String[]{"3D", "MinecraftGlow", "2D"}, "3D");
   private final BooleanValue 友友树何树树何何友树 = new BooleanValue("Rainbow", "彩虹", true).A(() -> {
      BetterCamera.e();
      return !this.mode.K("");
   });
   private final BooleanValue 友友友树树友友友何何 = new BooleanValue("Team Color", "队伍颜色", false).A(() -> {
      BetterCamera.e();
      return !this.友友树何树树何何友树.getValue();
   });
   public final BooleanValue 友树树友树友友树树树 = new BooleanValue("Players", "玩家", true).A(() -> this.mode.K("MinecraftGlow"));
   public final BooleanValue 友何树何树树树友何何 = new BooleanValue("Mobs", "生物", false).A(() -> this.mode.K(""));
   public final BooleanValue 何树友树何何友何树友 = new BooleanValue("Animals", "动物", false).A(() -> this.mode.K("MinecraftGlow"));
   private final BooleanValue 树何何友友何树何友树 = new BooleanValue("Items", "物品", true).A(() -> this.mode.K("MinecraftGlow"));
   private final BooleanValue 友树何树友树何友何何 = new BooleanValue("Arrows", "箭矢", true).A(() -> this.mode.K("MinecraftGlow"));
   private final BooleanValue 何树何树树友何何友树 = new BooleanValue("Out Line", "外轮廓", true).A(() -> this.mode.K("3D"));
   private final BooleanValue 何何何何何何友何树树 = new BooleanValue("Full Box", "完整方框", true).A(() -> this.mode.K("3D"));
   private final BooleanValue 友友友何友树树树何友 = new BooleanValue("Health Bar", "血条", true).A(() -> this.mode.K("2D"));
   private final BooleanValue 何树友友树何树何何何 = new BooleanValue("Box 2D", "2D方框", true).A(() -> this.mode.K("2D"));
   private final Map<Entity, Vector4f> 树友何何何何树树何何 = new HashMap<>();
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[39];
   private static final String[] k = new String[39];
   private static String HE_WEI_LIN;

   public ESP() {
      super("ESP", "透视方框", 树何友友何树友友何何.友友树树何友树树友树);
      instance = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3137888737988279399L, 7748174520986629697L, MethodHandles.lookup().lookupClass()).a(138592319844844L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(103668459260038L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[32];
      int var7 = 0;
      String var6 = "\u0093pÒ6xào\u0011¤O\"Áì\u0018h+\u0010Ln\u0087^ÿ½\u0084+\u0002«B¬\u0086KßÊ ¬\u0018\u0081Ðwáº%\u009fZÛÈì\u0005¡OQ³¦>¸bí\u0004þ\u0091\u009eª\tê<\" {\u0006ýý\u001dÔJÙç«^ó\u0093\u0081MµÈ\u008bae-u&ì¥³pWô\u0002q \u0010Û¾h\u0084\u009bLJZÄ \u001eßø\u0092I\u0007\u0010Â*¢+À£xÁÁ\u0083ï¯Wm Á\u0010gS\u0003\u00adÀä·ôy7\u0003Í<BÞã\u0010\u001b\u0016\u0012\u009f\u0099wÒû¾Î3&\u0098ãå\u0093\u0010)\u0003¾Ýy¨ÿ«¼<4\u0007^\u009c¶\u0087\u0010\u008dÕÂyYÒ!¿ó\u0090\u0083Î+\u0083°\u0018 Ð¶\u009dI¹Ê~_Ô\u001cYÍ§Ï\u001eg¹5w\u0016 ý $\u0084S\u0082«H³Â\u009c\u0010\u008a~[ùÛD\u0082k\u000eS{Ýó¿ ?\u0010áSëg5.~Ï¸<\u009fÙ\u0013\u0095\u001f\u009e\u0018\u0097~\u0017:\u0018×\\È¸\u0014Ô\u0099\u000bó\u0093ý\u0018\u0006Íß\u0087öÎ'\u0010rs»PO8C\u001c>>¢$®\u001d\u0003Ü ó\u0095óýûova¡À\u0004í²º³åGt?Tçä¡û©M\u0016¥È+¾Ã\u0018E\b\f\u008ec\u001eÎ÷Cö\u0082*\u000e,>D\u0005oÚ\u001a\u00ad\u009bi\u0007\u0010Ó²¯ãY¡\u0082Wïßqq\u0090Ó´Ý\u0010ìº\u009a5\f\u0014ñ\u0012\u0095ÇQB\u0012ÚÌë \u0013/\"~)Å\rÈ\u0093\u0017³0\u0083º\u001b9Á³\r>\u0015\u009bÊËB\u008fGÍNÑ\u009d6\u0010\u009f\u007f\b¯MðL3Ú@Áz©v\fh à}\u008dï\u009dE#¯½U|V\u001d*\u0099þL±øô\u0017ÇÏÍ\u0012nèèñþëÔ »QBËÍ_m°¬à\u001c\u0006Xá\u009dw\u0012w&\u0002\u0084;¦\u0094g@yX\u009b¢´Í\u0010ÎÜ°r\u0000\u0095Æ\u0095½'ñ\u008a\u0018\tY!\u0018I;,ü\u008f\u000bÅiÈ\u0016*\u0001¶÷\u0081\u0082e¢H¬\u008a+ÂÀ\u0010¥Ó¨Ò\u009e\u0085\u0082/v$äMö÷Õ\u0000\u0010hbÀæÂ\u008cí\u0095»\rY8ì\u009atP\u0010\u0088Ä¡\u001bÇ\u0014Ä¹\\\t ª¾\u001d¿®\u0010´!¹±ïÞ6¸fÕ\u008c5ôÑ¶: EÈR\u000fó45<^\u001e\u000bYS°Â·\u0092é¥Åz.\u0087hþ\u000e\u0006hé\u009daf";
      short var8 = 661;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[32];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ö!÷ÅÈzø\u0089TWUüâb\tb\u0010/¨<\u0085\u009ev\u0013½\u0094ò'ö#·1V";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private int F(LivingEntity entity) {
      BetterCamera.e();
      if (entity instanceof Player player) {
         Team team = player.getTeam();
         if (team != null) {
            ChatFormatting teamColor = team.getColor();
            return this.s(teamColor);
         }
      }

      return this.H(entity);
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 5;
               case 1 -> 44;
               case 2 -> 10;
               case 3 -> 56;
               case 4 -> 42;
               case 5 -> 19;
               case 6 -> 35;
               case 7 -> 36;
               case 8 -> 59;
               case 9 -> 57;
               case 10 -> 21;
               case 11 -> 63;
               case 12 -> 58;
               case 13 -> 37;
               case 14 -> 26;
               case 15 -> 60;
               case 16 -> 1;
               case 17 -> 55;
               case 18 -> 43;
               case 19 -> 20;
               case 20 -> 61;
               case 21 -> 51;
               case 22 -> 15;
               case 23 -> 25;
               case 24 -> 39;
               case 25 -> 4;
               case 26 -> 46;
               case 27 -> 62;
               case 28 -> 50;
               case 29 -> 13;
               case 30 -> 6;
               case 31 -> 40;
               case 32 -> 24;
               case 33 -> 28;
               case 34 -> 32;
               case 35 -> 16;
               case 36 -> 48;
               case 37 -> 14;
               case 38 -> 30;
               case 39 -> 23;
               case 40 -> 18;
               case 41 -> 11;
               case 42 -> 49;
               case 43 -> 41;
               case 44 -> 38;
               case 45 -> 12;
               case 46 -> 27;
               case 47 -> 0;
               case 48 -> 7;
               case 49 -> 45;
               case 50 -> 9;
               case 51 -> 3;
               case 52 -> 33;
               case 53 -> 29;
               case 54 -> 34;
               case 55 -> 53;
               case 56 -> 2;
               case 57 -> 52;
               case 58 -> 54;
               case 59 -> 47;
               case 60 -> 8;
               case 61 -> 22;
               case 62 -> 17;
               default -> 31;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20153;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/ESP", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[FR\u0016õÜ÷Î[, ¢Î8\u0018\"\u000b\u008fÈ, \u008eò\u0017,\u0000â½Ò\u009fôìX,\u0004\u0019\u001c, ºû×=ÿ1x\u00169\u000b¬ä.\u009e)\u008b, ¼\u001fU\u009eX ø\u0018, ¦ÙÏ\u0082\u0000\u0090!H, BÏÖ5ü\u009fô\u009d, hè¹\u0011çd^ü, Yi¸àÕ\u0090ît, 8¡é\u0090_ @\u001e, ¿QNíÒ\u0085ã\u0001¨·\u0096@õ\u0085S\u007f, {Ñ\f\t\u0099ò\u0095Q, \u001aHØV¯äõÐ, Ó]\u0099\u0081.\u007f|\u0019b\u000e©zói¼', \u0082\u00adõÂ\u0094\u001c\u009aO, ¡\u0099\u0093Â\u000fAÊ\u001e\u0000ÿ´BÄË-ê, +N\u008bà{\\mäz?¹¬\u0010ü\u0012ü, _\\ºçp¤\"),  ¥\u0014k\tCo|, 6\u0099u\u0093\u008b×Ø|å\u009fðàZ\u008dPu, \u000bPÊ\u009bü°ãd, \u0087³X:Á¬\u00199Áwû?ÝöS\u0088, \u0005\u008cìá¬\u0096â<\u000e\u0019·^9\u0010¥Ü, \u0093.ÆÅa&J\u008c, æY*¤\u008e\u0094\t.ò\u009e\u0004 DTs·, R.·YPö\u008b§, *i\u0018úÍXKU, ©\u001f\u0001\u0016$\u000e\u0080Ú, \u008e[NÇ\"0i0, \u000fú~\u008a¦õ\u009ec")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/ESP" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private int s(ChatFormatting formatting) {
      BetterCamera.e();

      return switch (ESP$何何何友友树友树何何.树何树友友树何树树友[formatting.ordinal()]) {
         case 1 -> Color.BLACK.getRGB();
         case 2 -> new Color(0, 0, 170).getRGB();
         case 3 -> new Color(0, 170, 0).getRGB();
         case 4 -> new Color(0, 170, 170).getRGB();
         case 5 -> new Color(170, 0, 0).getRGB();
         case 6 -> new Color(170, 0, 170).getRGB();
         case 7 -> new Color(255, 170, 0).getRGB();
         case 8 -> new Color(170, 170, 170).getRGB();
         case 9 -> new Color(85, 85, 85).getRGB();
         case 10 -> new Color(85, 85, 255).getRGB();
         case 11 -> new Color(85, 255, 85).getRGB();
         case 12 -> new Color(85, 255, 255).getRGB();
         case 13 -> new Color(255, 85, 85).getRGB();
         case 14 -> new Color(255, 85, 255).getRGB();
         case 15 -> new Color(255, 255, 85).getRGB();
         case 16 -> Color.WHITE.getRGB();
         default -> HUD.instance.getColor(4).getRGB();
      };
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'w' && var8 != 220 && var8 != 234 && var8 != 195) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 229) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'R') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'w') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 220) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 234) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/ESP" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "v:W\u000f-Yyz\u001a\u0004'D|'\u0011B/Yq!\u0015\tl_x$\u0015B0S{0\u001c\u001elsF\u0004";
      j[1] = "\u0018@Spxm\u0017\u0000\u001e{rp\u0012]\u0015=ac\u0017[\u0018=~o\u000bBS^xf\u001ex\u001c\u007fbg";
      j[2] = "Y+5\u007fWzVkxt]gS6s2Uz^0wy\u0016|W5w2JpT!~n\u0016W_1oyJV[(~nY";
      j[3] = "z sxRaq/b7/yb(k~";
      j[4] = "Z*\u0011Q&;Q%\u0000\u001eZ\"^?\u000e]m\u0012H(\u0002@|>_%";
      j[5] = ")PQ\u001ds\"&\u0010\u001c\u0016y?#M\u0017Pj,&K\u001aPu :RQ<s\"&[\u001e\u0010J,&K\u001a";
      j[6] = "\u0016|il[\u001f\u000bi1N\u001a\u0012\u0013o";
      j[7] = "\u0005\u00173\u0006\u0005w\nW~\r\u000fj\u000f\nuK\u0007w\u0002\fq\u0000Dq\u000b\tqK\u0018}\b\u001dx\u0017D]5)9估伿位厭厲栌厮桻位伳";
      j[8] = "<\u0018";
      j[9] = "\u000f\nYt\u0017\u0000\u0000J\u0014\u007f\u001d\u001d\u0005\u0017\u001f9\u001d\u0019\t\n\u00039\u001d\u0019\t\n\u0003dV*\u001a\u0001\u0019c\\<\u0005\u0000\u0012";
      j[10] = "_Op\"rfAGjm\u0011rE";
      j[11] = "8\u0012w\t@'8\u0012`UL(\"Y`KD+8\u0003-jD 3\u0014qFK:";
      j[12] = "}lJ'.s}l]{\"|g']e*\u007f}}\u0010F3nzfPz";
      j[13] = "j92x6\u0000ey\u007fs<\u001d`$t54\u0000m\"p~w桾作厜受低案厤参伂佉";
      j[14] = " RK\u000e\r=+]ZAl3 V^\u001b";
      j[15] = "T[^yI\u0015\u000eI>lU\u0001S#@w^\u0013@\u001f]6\t";
      j[16] = "{t\u007f<i\u001e$-$.\u0016\nB/<tz\u0015\u007fi|tsg";
      j[17] = "7{~\u0001#Vmi\u001e厲厛叭桄栚叝厲厛佳伀\u0003\"L9\u00176r|\u0016aN";
      j[18] = "\u0018.Y{PSB<9又栲佶桫厕栠佖叨佶伯V\u00056J\u0012\u0019'[l\u0012K";
      j[19] = "i4d&= 3&\u0004桏伛伅叀厏余桏伛厛栚L8k'ah=f1\u007f8";
      j[20] = ".^NS16tL.佾桓伓桝栿叭佾众厍桝&\u0012\u001e+w/WLDs.";
      j[21] = "G*3\u0002<\u0004\u001d8S\u001bGFS6.\t*\f\u001d-#r}\u0002I/(\u001f7LR\"S";
      j[22] = "y\u0005|K\u000br#\u0017\u001c佦桩叉栊传佁司伭栓叐} \u0006\u00113x\f~\\Ij";
      j[23] = ">SB\u0007xfdA\"厴叀叝伉叨栻桮栚佃厗+\u001eJb'?Z@\u0010:~";
      j[24] = "a/\u0003h&}n.Go^K\u0018\u0018a\t`\u007fa\"Ego~%%";
      j[25] = "m`\u001bkED7r{变佣栥佚栁桢栂叽佡佚\u0018G&_\u0005li\u0019|\u0007\\";
      j[26] = "\u0018{|\u007fQTBi\u001c栖叩佱伯佞佁栖栳佱伯\u0003#5[N\u0014ys?KV";
      j[27] = "j\r\u0007K\r\u0005*\t\u000e\b4\u007f\u0012%&44\t7\u0006QN\u0004I3\u000f\u0012";
      j[28] = "(X5aRqrJU叒栰栐厁根厖叒栰栐桛 i,H0)Q7v\u0010i";
      j[29] = ">n$')y~j7:DpV!~dz V\u0010w6!.;n8`z!";
      j[30] = "^H~]\u0018\u0013\u001eLw\u001e!|\"hH,!\u001f\u0003C(X\u0011_\u0007Jk";
      j[31] = "\u00010/Q/6[\"O佼伉伓伶伕伒叢伉桗桲Hs\u001c5w\u00009-Fm.";
      j[32] = "\u0000d\u0003\b{\u0005Z;\u0000H\u0015栠你栝厾厲栌佤栤栝厾q(^\u0004z\u0012\u0016wV^f";
      j[33] = "Y\u007f\"y!6\u0003mBh<5On$b7NY\u007f\"y!6\u0003m";
      j[34] = "\"\u0006\u0001R\u001dT-\u0007EUebF'?\r\t\u0004}\u0012Q\u0002\b@z";
      j[35] = "3?>0dkxn8:\u0016厒叁栖桜伎叕案栛双桜S'ayl7il0\u007ff";
      j[36] = "ATZ7&\u000e\u001bF:会桄厵叨栵佧桞伀伫佶,\u0006z<O@]X d\u0016";
      j[37] = "\u001b}.\u001fh\fAoN厬叐桭伬栜桗伲低厷桨\u0005rRrM\u001at,\b*\u0014";
      j[38] = "6{v9&Yv\u007f\u007fz\u001f&PSM\u0005#\b`&%5c\fie";
   }

   @EventTarget
   public void a(Render2DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && this.mode.K("2D")) {
         GuiGraphics guiGraphics = event.guiGraphics();
         PoseStack poseStack = guiGraphics.pose();
         Color firstColor = HUD.instance.getColor(1);
         Color secondColor = HUD.instance.getColor(2);
         Color thirdColor = HUD.instance.getColor(3);
         Color fourthColor = HUD.instance.getColor(4);
         Iterator var13 = this.树友何何何何树树何何.keySet().iterator();
         if (var13.hasNext()) {
            Entity entity = (Entity)var13.next();
            Vector4f pos = this.树友何何何何树树何何.get(entity);
            float x = pos.x();
            float y = pos.y();
            float right = pos.z();
            float bottom = pos.w();
            if ((entity instanceof LivingEntity || entity instanceof ItemEntity) && this.友友友何友树树树何友.getValue()) {
               if (entity instanceof LivingEntity) {
                  float var10000 = ((LivingEntity)entity).getHealth() / ((LivingEntity)entity).getMaxHealth();
               }

               float healthValue = (float)((ItemEntity)entity).getItem().getCount() / ((ItemEntity)entity).getItem().getMaxStackSize();
               Color healthColor = healthValue > 0.75F
                  ? new Color(66, 246, 123)
                  : (healthValue > 0.5F ? new Color(228, 255, 105) : (healthValue > 0.35F ? new Color(236, 100, 64) : new Color(255, 65, 68)));
               float height = bottom - y + 1.0F;
               RenderUtils.drawRectangle(poseStack, x - 3.5F, y - 0.5F, 2.0F, height + 1.0F, new Color(0, 0, 0, 180).getRGB());
               if (this.友友树何树树何何友树.getValue()) {
                  RenderUtils.drawRectangle(poseStack, x - 3.0F, y, 1.0F, height, 何树友友树树友何树何.j(firstColor, 0.3F).getRGB());
                  RenderUtils.drawRectangle(poseStack, x - 3.0F, y + (height - height * healthValue), 1.0F, height * healthValue, firstColor.getRGB());
               }

               RenderUtils.drawRectangle(poseStack, x - 3.0F, y, 1.0F, height, 何树友友树树友何树何.j(healthColor, 0.3F).getRGB());
               RenderUtils.drawRectangle(poseStack, x - 3.0F, y + (height - height * healthValue), 1.0F, height * healthValue, healthColor.getRGB());
            }

            if (this.何树友友树何树何何何.getValue()) {
               RenderUtils.drawRectangle(poseStack, x, y, right - x, 1.0F, firstColor.getRGB());
               RenderUtils.drawRectangle(poseStack, x, y, 1.0F, bottom - y, secondColor.getRGB());
               RenderUtils.drawRectangle(poseStack, x, bottom, right - x, 1.0F, thirdColor.getRGB());
               RenderUtils.drawRectangle(poseStack, right, y, 1.0F, bottom - y + 1.0F, fourthColor.getRGB());
               RenderUtils.drawRectangle(poseStack, x - 0.5F, y - 0.5F, right - x + 2.0F, 0.5F, Color.BLACK.getRGB());
               RenderUtils.drawRectangle(poseStack, x - 0.5F, y, 0.5F, bottom - y + 1.0F, Color.BLACK.getRGB());
               RenderUtils.drawRectangle(poseStack, x - 0.5F, bottom + 1.0F, right - x + 2.0F, 0.5F, Color.BLACK.getRGB());
               RenderUtils.drawRectangle(poseStack, right + 1.0F, y, 0.5F, bottom - y + 1.0F, Color.BLACK.getRGB());
               RenderUtils.drawRectangle(poseStack, x + 1.0F, y + 1.0F, right - x - 1.0F, 0.5F, Color.BLACK.getRGB());
               RenderUtils.drawRectangle(poseStack, x + 1.0F, y + 1.0F, 0.5F, bottom - y - 1.0F, Color.BLACK.getRGB());
               RenderUtils.drawRectangle(poseStack, x + 1.0F, bottom - 0.5F, right - x - 1.0F, 0.5F, Color.BLACK.getRGB());
               RenderUtils.drawRectangle(poseStack, right - 0.5F, y + 1.0F, 0.5F, bottom - y - 1.0F, Color.BLACK.getRGB());
            }
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean A(Entity entity) {
      BetterCamera.e();
      if (entity == mc.player || entity.isRemoved() || !entity.isAlive()) {
         return false;
      } else if (entity instanceof Player) {
         return true;
      } else if (entity instanceof ItemEntity) {
         return true;
      } else {
         return entity instanceof Animal ? true : entity instanceof Mob;
      }
   }

   @EventTarget
   public void L(Render3DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (event.side() == Event.Side.PRE) {
            友友何何友友树何何友.m(47731723453557L, event.poseStack());
            this.树友何何何何树树何何.clear();
            Iterator poseStack = mc.level.entitiesForRendering().iterator();
            if (poseStack.hasNext()) {
               Entity entity = (Entity)poseStack.next();
               if (this.A(entity) && 友友何何友友树何何友.D(45796835247161L, entity)) {
                  this.树友何何何何树树何何.put(entity, 友友何何友友树何何友.V(entity, 87446743937492L));
               }
            }
         }

         if (event.side() == Event.Side.POST) {
            友友何何友友树何何友.U(116571643732856L);
         }

         if (this.mode.K("3D")) {
            PoseStack poseStack = event.poseStack();

            for (LivingEntity entity : Cherish.instance.m().E(126494939063800L)) {
               if ((entity != mc.player || !mc.options.getCameraType().isFirstPerson()) && 友友何何友友树何何友.D(45796835247161L, entity)) {
                  int espColor = this.友友树何树树何何友树.getValue()
                     ? 何树友友树树友何树何.t(94608897312632L, 10, 1).getRGB()
                     : (this.友友友树树友友友何何.getValue() ? this.F(entity) : this.H(entity));
                  友友何何友友树何何友.Z(24488542601285L, poseStack, entity, espColor, true, this.何何何何何何友何树树.getValue(), this.何树何树树友何何友树.getValue(), 200.0F);
                  break;
               }
            }
         }
      }
   }

   private int H(LivingEntity entity) {
      BetterCamera.e();
      if (entity instanceof Player) {
         return HUD.instance.getColor(4).getRGB();
      } else if (entity instanceof Animal) {
         return new Color(85, 255, 85).getRGB();
      } else {
         return entity instanceof Monster ? HUD.instance.getColor(4).getRGB() : Color.GRAY.getRGB();
      }
   }

   public boolean shouldGlow(Entity entity) {
      BetterCamera.e();
      if (instance == null || !instance.isEnabled() || !instance.mode.K("MinecraftGlow") || entity == mc.player) {
         return false;
      } else if (entity instanceof Player) {
         return this.友树树友树友友树树树.getValue();
      } else if (entity instanceof ItemEntity) {
         return this.树何何友友何树何友树.getValue();
      } else if (entity instanceof Animal) {
         return this.何树友树何何友何树友.getValue();
      } else if (entity instanceof Mob) {
         return this.友何树何树树树友何何.getValue();
      } else {
         return entity instanceof Arrow ? this.友树何树友树何友何何.getValue() : false;
      }
   }

   private static String HE_JIAN_GUO() {
      return "何树友被何大伟克制了";
   }
}
