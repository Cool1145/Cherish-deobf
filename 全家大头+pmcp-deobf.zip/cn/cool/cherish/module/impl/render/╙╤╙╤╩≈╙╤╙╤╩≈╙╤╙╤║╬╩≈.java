package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;

public class 友友树友友树友友何树 extends Module implements 何树友 {
   private final ModeValue 何何树树何何树树友树 = new ModeValue("Time Mode", "时间模式", new String[]{"Static", "Cycle"}, "Static");
   private final ModeValue 何友友树树何树何何树 = new ModeValue("Weather Mode", "天气模式", new String[]{"Clear", "Rain"}, "Clear");
   private final NumberValue 树何何树树树树友何友 = new NumberValue("Cycle Speed", "循环速度", 24.0, 1.0, 24.0, 1.0);
   private final BooleanValue 友树何树友何友何友何 = new BooleanValue("Reverse Cycle", "反向循环", false);
   private final NumberValue 树何友树友友友友树友 = new NumberValue("Static Time", "静态时间", 24000.0, 0.0, 24000.0, 100.0);
   private final NumberValue 树何友树何友何树友何 = new NumberValue("Rain Strength", "雨强度", 0.1, 0.1, 0.5, 0.05);
   private long 友树友何树友树树何树 = 0L;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[23];
   private static final String[] n = new String[23];
   private static int _解放村多种2队1144号 _;

   public 友友树友友树友友何树() {
      super("Ambience", "修改时间", 树何友友何树友友何何.友友树树何友树树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-6694862802933959955L, -1139947783320920017L, MethodHandles.lookup().lookupClass()).a(8490160854269L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(128364395136709L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[20];
      int var18 = 0;
      String var17 = "úO\u0090\u0018yA2Ëpçö¸\u000fÉ<]W(\u0088l\u001bwêþP¹Ø\u00ad$éW\u0005 I²Rñ\u0015k½àÁº\b§\u008aÒf)Ó^BõÖ\u000fÕ\u0086ãaf®d\u0017Q} ;µ\b\u00ad\u008fk\u0010Ì¯\u009f\r¿\u0018b[âêYêÀL\u0004Q\u0088}\u0012`g\u008a=d?\u0010â<\bY]\u0096ß4Á\bû F6N\u0002\u0010\u00adNÿpÂæÌ\"Wô\u0090G=»\u001b¶\u0010\u0091²X\u008ez\u0085<Ö6%Eg¶¾4ã 'ÓÇ\u0086ì\u0090G°¼Aa»ò\u000eÁTîy×\u0006w\u000e;±õîìÎ\u0085Oû> \u0004û\u0001P$\u001f]\u007f´Îx¨ïí\u0019}\u0095È¢§H\u001få\u001d\u008eÌý·ëÚa6\u0010\u0091K¥Z;\u008dËîØ¿\u009d=:]À!\u0018\u0097Ìþ(;\u0011úv«g\u0005\u0002lùyoýô#¾\u0010\u0014\u0002Ø \u0016¾ô]\u000e\u0014âP\u009aÍÝtDü´\u00adËßÖ\u0084J\u001c\u00ad¶>\u001e[\u0091oê[t t«æ\u0013Ý\u0099'Êx\u008d\u00155£ÜUÈåÞ4Ö\u000bUxá\u0081í·\u000fËr(A \t~v×m¯þT{ósò\u0015íNgXêûSNv©3\u0099î\n\u001c\u0018\u0095>Ù\u0018/GÇ+Æ\u0015g\u0095\u0012·X:hp\u001d$¬ø®º\bÌ¾\u0082  ÈÁ\u0018\u0010gäv\u0097\u0084Ó¸]¿©âCnªñ?Ú\u0004lðÓ\u0010å@\"Q\u008f 7KùLY^\u008b\u0082T\u009c\u0015e]\u0085\u008fÙ>±\u001cûLý\u0016Ì\fÑì\u0090\u008e\u0085q§\u0010\"»\u0007\u00ad5v÷ \u0085\u009c~1à¿Úd\u0018ª³QÌ\u0003x\u0099bÂk\u0099(mtÄú?ø \u0004\"õ]O";
      short var19 = 489;
      char var16 = ' ';
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[20];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(128364395136709L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "Ú£Y®é^\u0007ó\u0084û\u0086\u008cX\u000bûëøq`³R\f\u008dï".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 24);

                     j = var6;
                     k = new Long[3];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "\u0086Í#&[¿K¼º\u001a=Gæ«`ü\u0018B\u0094\"\u0093¯\u008fÚeª²\u0094\u0002±ÿÎ§J\u0005onÕgc8";
                  var19 = 41;
                  var16 = 16;
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void Z(PacketEvent event) {
      Packet<?> packet = event.getPacket();
      if (packet instanceof ClientboundSetTimePacket) {
         event.setCancelled(true);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 59;
               case 1 -> 21;
               case 2 -> 43;
               case 3 -> 44;
               case 4 -> 10;
               case 5 -> 5;
               case 6 -> 7;
               case 7 -> 9;
               case 8 -> 49;
               case 9 -> 37;
               case 10 -> 36;
               case 11 -> 34;
               case 12 -> 20;
               case 13 -> 12;
               case 14 -> 61;
               case 15 -> 60;
               case 16 -> 45;
               case 17 -> 13;
               case 18 -> 52;
               case 19 -> 15;
               case 20 -> 11;
               case 21 -> 63;
               case 22 -> 24;
               case 23 -> 51;
               case 24 -> 42;
               case 25 -> 3;
               case 26 -> 16;
               case 27 -> 26;
               case 28 -> 18;
               case 29 -> 39;
               case 30 -> 2;
               case 31 -> 30;
               case 32 -> 35;
               case 33 -> 47;
               case 34 -> 32;
               case 35 -> 58;
               case 36 -> 50;
               case 37 -> 38;
               case 38 -> 23;
               case 39 -> 33;
               case 40 -> 57;
               case 41 -> 19;
               case 42 -> 55;
               case 43 -> 46;
               case 44 -> 62;
               case 45 -> 1;
               case 46 -> 25;
               case 47 -> 8;
               case 48 -> 28;
               case 49 -> 40;
               case 50 -> 48;
               case 51 -> 14;
               case 52 -> 53;
               case 53 -> 0;
               case 54 -> 6;
               case 55 -> 54;
               case 56 -> 29;
               case 57 -> 4;
               case 58 -> 22;
               case 59 -> 17;
               case 60 -> 31;
               case 61 -> 41;
               case 62 -> 27;
               default -> 56;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28426;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友友树友友树友友何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u0011#ÐyÒÙùçBÐ\u0097k")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友友树友友树友友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友友树友友树友友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'z' && var8 != 162 && var8 != 'u' && var8 != 197) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'U') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'g') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'z') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 162) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 17191;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友友树友友树友友何树", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友友树友友树友友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      m[0] = "{=:Nuyt}wE\u007fdq |\u0003wy|&xH4\u007fu#x\u0003hsv7q_4叝叓桂叟另栋叝叓伆栅";
      m[1] = long.class;
      n[1] = "java/lang/Long";
      m[2] = "\n\u0016:U~H\u0005Vw^tU\u0000\u000b|\u0018|H\r\rxS?栶似厳叟佣栀召厢伭佁";
      m[3] = "RtJ\u0011Bq]4\u0007\u001aHlXi\f\\@qUo\b\u0017\u0003w\\j\b\\_{_~\u0001\u0000\u0003\\Tn\u0010\u0017_]Pw\u0001\u0000L";
      m[4] = "n-\\q\u0007me\"M>zuv%Dw";
      m[5] = "~\n3SB\u0019qJ~XH\u0004t\u0017u\u001e[\u0017q\u0011x\u001eD\u001bm\b3~X\u001b\u007f\u0001ofL\u001ah\u0001";
      m[6] = "46\u0015JQk46\u0002\u0016]d.}\u0002\bUg4'O\tIn.:\u0011\b]{?!O'Pk?=\u0015(Yt??";
      m[7] = float.class;
      n[7] = "java/lang/Float";
      m[8] = "0CF8g(;LWw\u001b14VY4,\u0001\"AU)=-5L";
      m[9] = "\\\u001dQr`\u0010S]\u001cyj\rV\u0000\u0017?y\u001eS\u0006\u001a?f\u0012O\u001fQS`\u0010S\u0016\u001e\u007fY\u001eS\u0006\u001a";
      m[10] = "\u001aH\u0006Z\\A\u0015\bKQV\\\u0010U@\u0017EO\u0015SM\u0017ZC\tJ\u0006t\\J\u001cpIUFK";
      m[11] = "*\u0019$H~p!\u00165\u0007\u001f~*\u001d1]";
      m[12] = "\u000fLB\u0007fi\\\u0018\u0014M\u0014a5I\u0002\u0011}s\bJ\u0001\u001b.\f";
      m[13] = " x\u0018\u0017\u007fi1o\b*u\u000eq(VS\"ltbVS\u001c0u-\u0010\u0014~5?-\u0010*";
      m[14] = "jw|\u0016'\u0013{`l+厇桭叆佀栔叨桝桭佘栄\r\u0012u\beq7U:Ld";
      m[15] = "2-\u000fosq#:\u001fR栉佋厞桞厽厑叓叕桄厄~ivyl\"\u001f#a'!";
      m[16] = "!5RR\u001d\u00140\"Bo桧伮伓框栺桶桧厰伓厜#T\u0018\u001c\u007f:B\u001e\u000fB2";
      m[17] = ";\u0019UGnT*\u000eEz栔佮厗桪佹厹佐株厗伮$Ak\\e\u0016E\u000b|\u0002(";
      m[18] = "@\n\u001b`j*Q\u001d\u000b]及桔佲桹厩伀及伐召伽jcl}QZ\r9t$_";
      m[19] = "B@2XW\\\u0001P!\u001c2[)\u001d`Z\t\u0005)!b\u0014WVFPd\fLZ";
      m[20] = "$1\u0011\u0016P\u0018w2P\u001a(厺叞桅栱伢叫桠栄原栱\u007f\u0011\u0014$5P\u001eB\u0017e9";
      m[21] = "\u001f#SP\u0012g\u000e4Cm伬佝桩桐使估桨栙厳桐\"RM?\u001b8X\u0011K;\u0013";
      m[22] = "\u007f\u001cFNd%n\u000bVs佚厁叓桯栮伮栞伟位桯7L;}{\u0007M\u000f=ys";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   public void M() {
      this.友树友何树友树树何树 = 0L;
   }

   private static String LIU_YA_FENG() {
      return "刘凤楠230622109211173513";
   }

   @EventTarget
   public void O(TickEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.何何树树何何树树友树.K("Static")) {
            mc.level.setDayTime(this.树何友树友友友友树友.getValue().longValue());
         }

         mc.level.setDayTime(this.友树友何树友树树何树);
         this.友树友何树友树树何树 = this.友树友何树友树树何树
            + (this.友树何树友何友何友何.getValue() ? -this.树何何树树树树友何友.getValue().longValue() : this.树何何树树树树友何友.getValue().longValue()) * 10L;
         if (this.友树友何树友树树何树 > 24000L) {
            this.友树友何树友树树何树 = 0L;
         }

         if (this.友树友何树友树树何树 < 0L) {
            this.友树友何树友树树何树 = 24000L;
         }

         if (this.何友友树树何树何何树.K("Clear")) {
            mc.level.rainLevel = 0.0F;
         }

         mc.level.rainLevel = this.树何友树何友何树友何.getValue().floatValue();
      }
   }
}
