package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何何树友树树何友友树;
import cn.cool.cherish.utils.何树何何树友树何何树;
import cn.cool.cherish.utils.友树友何友何友树何友;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class 友何何何友何友何何何 extends Module implements 何树友 {
   private final 何何树友树树何友友树 何何树树树何何友友何 = new 何何树友树树何友友树(0.0F, 0.0F, 80162555667806L, 0.0F);
   private final 何何树友树树何友友树 友树何友友友何何友何 = new 何何树友树树何友友树(0.0F, 0.0F, 80162555667806L, 0.0F);
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[40];
   private static final String[] l = new String[40];
   private static String HE_JIAN_GUO;

   public 友何何何友何友何何何() {
      super("Projectiles", "抛物线显示", 树何友友何树友友何何.友友树树何友树树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8947643776503979561L, -6062752417835409085L, MethodHandles.lookup().lookupClass()).a(176060606915136L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var7;
      Cipher var16 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(78230282679448L << var8 * 8 >>> 56);
      }

      var16.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[2];
      int var12 = 0;
      char var10 = ' ';
      int var9 = -1;

      while (true) {
         String var20 = c(
               var7.doFinal(
                  ")\u0011r¬ñ¨å³·\u0002\\¡Üö\u009a¡\u0001\u0097¼ô\rÌÆ¶Ç\u0097QRmºv  £h\u0004ÒÔ®\u0086C\u0011B!O\u0005n¤\u0094\t\u0002Ö#\u0004øØK\u000e9Ò\u001fk\u008aÐ\u0099"
                     .substring(++var9, var9 + var10)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var14[var12++] = var20;
         if ((var9 += var10) >= 65) {
            c = var14;
            h = new String[2];
            Cipher var0;
            Cipher var17 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(78230282679448L << var1 * 8 >>> 56);
            }

            var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            byte[] var4 = var0.doFinal(new byte[]{-110, -69, 34, -13, -34, 74, 31, 113});
            long var23 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            j = var23;
            return;
         }

         var10 = ")\u0011r¬ñ¨å³·\u0002\\¡Üö\u009a¡\u0001\u0097¼ô\rÌÆ¶Ç\u0097QRmºv  £h\u0004ÒÔ®\u0086C\u0011B!O\u0005n¤\u0094\t\u0002Ö#\u0004øØK\u000e9Ò\u001fk\u008aÐ\u0099"
            .charAt(var9);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 51;
               case 1 -> 16;
               case 2 -> 53;
               case 3 -> 43;
               case 4 -> 6;
               case 5 -> 57;
               case 6 -> 25;
               case 7 -> 28;
               case 8 -> 22;
               case 9 -> 46;
               case 10 -> 45;
               case 11 -> 8;
               case 12 -> 5;
               case 13 -> 52;
               case 14 -> 33;
               case 15 -> 4;
               case 16 -> 39;
               case 17 -> 17;
               case 18 -> 42;
               case 19 -> 27;
               case 20 -> 3;
               case 21 -> 21;
               case 22 -> 20;
               case 23 -> 40;
               case 24 -> 54;
               case 25 -> 23;
               case 26 -> 55;
               case 27 -> 30;
               case 28 -> 58;
               case 29 -> 47;
               case 30 -> 34;
               case 31 -> 14;
               case 32 -> 63;
               case 33 -> 36;
               case 34 -> 56;
               case 35 -> 7;
               case 36 -> 32;
               case 37 -> 26;
               case 38 -> 10;
               case 39 -> 12;
               case 40 -> 13;
               case 41 -> 49;
               case 42 -> 15;
               case 43 -> 2;
               case 44 -> 62;
               case 45 -> 35;
               case 46 -> 1;
               case 47 -> 11;
               case 48 -> 18;
               case 49 -> 31;
               case 50 -> 48;
               case 51 -> 29;
               case 52 -> 24;
               case 53 -> 44;
               case 54 -> 19;
               case 55 -> 60;
               case 56 -> 59;
               case 57 -> 41;
               case 58 -> 50;
               case 59 -> 9;
               case 60 -> 37;
               case 61 -> 61;
               case 62 -> 38;
               default -> 0;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何何友何友何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11336;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何何友何友何何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u009eÙ")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'd' && var8 != 'g' && var8 != 'h' && var8 != 'E') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'u') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'G') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'd') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'g') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'h') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/友何何何友何友何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "zo[gBPu/\u0016lHMpr\u001d*@P}t\u0019a\u0003栮佌及厾佑格叴叒佔传";
      k[1] = "\u000bLR&4\f\u000bLEz8\u0003\u0011\u0007Qg+\t\u0001\u0007V` \u0016KhgJ\u001b";
      k[2] = double.class;
      l[2] = "java/lang/Double";
      k[3] = "%2\tstp*rDx~m//O>vp\")Ku5v+,K>iz(8Bb5]#(Sui\\'1Bbz";
      k[4] = "$A\u0005k#\u001a/N\u0014$^\u0002<I\u001dm";
      k[5] = "sO>7v\u0007sO)kz\bi\u0004=vi\u0002y\u0004:qb\u001d3|/z(";
      k[6] = ")AOl\bM&\u0001\u0002g\u0002P#\\\t!\u0012V#C\u0012!伲栳伟佺桰叄桶佷伟栾";
      k[7] = "\u0017\u001e2\u0016uh\u0018^\u007f\u001d\u007fu\u001d\u0003t[wh\u0010\u0005p\u00104n\u0019\u0000p[hb\u001a\u0014y\u00074双伡伥佉厾住双伡伥佉";
      k[8] = "s<\u001a4}\"||W?w?y!\\yg9y>Gy佇优栁厙栥框佇历叛桃";
      k[9] = "/C\nT]L/C\u001d\bQC5\b\t\u0015BI%\b\u001b\u0014DL5_P?^Q(R\u0007";
      k[10] = "kHUa;GkHB=7Hq\u0003B#?KkY\u000f\u0002?@`NS.0Z";
      k[11] = "?\u0016\u0005w\u0006f?\u0016\u0012+\ni%]\u00125\u0002j?\u0007_+\u000ea5\u0016\u0003<\u0019!\u0016\u0012\u001c<9j?\u0017\u0014+\u000e}";
      k[12] = "T[l\u0014s\u001b]Uo]0\u0016[U{_-\u0010\u0019BdHj\u0011O\u001aE_x\u0015BXul{\u0006CQy|q\u0006ZUu";
      k[13] = "9\u0000\u001el[k0\u000e\u001d%\u0018f6\u000e\t'\u0005`t\u0019\u00160Ba\"A%'Dp?\u00175-Di;\u001b";
      k[14] = "g4ic;Hl;x,GQc!vopau6zraMb;";
      k[15] = "0\u0005spL\u001a0\u0005d,@\u0015*Np1S\u001f:Nw6X\u0000p\"k1B\u0018\u0016\ts\fD\u0000+\fs";
      k[16] = "D\u0017tcJ}M\u0019w*\tpK\u0019c(\u0014v\t\u000e|?Sw_VO(UfB\u0000_\"U\u007fF\f=\u0000HvB";
      k[17] = "\u0004\u0014\u0004Wg\u001a\u000f\u001b\u0015\u0018\u0006\u0014\u0004\u0010\u0011B";
      k[18] = "/d\u0001\u0017C?a.\u000b,\u0015Vm$I\u001dAV]'\u001dL\u0006d>%\u0015JE";
      k[19] = "\u001bgqI/O_>6\rLN!=s^3MNo#\b|#";
      k[20] = "isP23 /=\u0004}W.\u0005=\u0006|hq\u0005\r\u0005.7=7n\u0007&1~";
      k[21] = "\u000e\u001ejq]\nHP>>9\u0004bP<?\tSb`?mY\u0017P\u0003=e_T";
      k[22] = "\u0006i+\fk\u001bH#!7=rD)c\u0007brt*7W.@\u0017(?Qm";
      k[23] = "N\u001eJ\u001dE-\u0000T@&\u0013D\f^\u0002\u0017ED<]VF\u0000v__^@C";
      k[24] = "\n\"8\u0015m\\V$1\u0015\u0001可叵佂伞併栘佱佫叜伞(8BVb&K:JP!";
      k[25] = "\u000b/?{[W\n$?re厮栯伞厙叒厦估佫厀伇\u0011X\u0016\u0006-8n_\nNy";
      k[26] = "].\u0003o\u00178\u0001(\no{压厢低去伏桢压桸叐去RB&\u0001n\u001d1@.\u0007-";
      k[27] = "\u0013#\\3D O%U3(厓栶标古栗併伍佲标栾\u000e\u0016+W~\u0018iRlQ%";
      k[28] = "vxk\u0005\u0005\t*~b\u0005i桠厉桜叓叻厪桠桓桜位8P\u0017*8u[R\u001f,{";
      k[29] = "L\u000e&#'^\u0002D,\u0018q7\u000eNn)$7>M:xb\u0005]O2~!";
      k[30] = "'j7\u0018Hvqlu\u0016)\"O02\\\u0017wO\u00014\u001fD'#zd\u0004Gt";
      k[31] = "i&$F(4'l.}~]+flM ]\u001be8\u001dmoxg0\u001b.";
      k[32] = "nwGQcG.&\u0013\n\u000fS\t,\u001f\u00016\u0000\t\u001c\u0013X~Y&}FKjR";
      k[33] = ")<X\u001c\u0010\u001e(7X\u0015.佹佉桉栤桯佳佹受厓你v\u0013_$>_\t\u0014Clj";
      k[34] = "\u0017LC\u0019R&Q\u0002\u0017V6({\u0002\u0015W\u0006~{2\u0016\u0005V;IQ\u0014\rPx";
      k[35] = "T+w\u001aCnU w\u0013}=i.)\u0002\u0002-\u0015~k\u000e\u0005T\u0000|`\u000f\u0004(P>l\b}";
      k[36] = "(xl\u0015>\u0018e(9o历古栍桛佔厬桜栾受桛\tS\u007fBn96\u001e/\u0017";
      k[37] = "\u0004\\`A}dJ\u0016jz+\rF\u001c(K|\rv\u001f|\u001a8?\u0015\u001dt\u001c{";
      k[38] = "\u0016+ELb\nJ-LL\u000e伧佷叕叽伬栗档栳叕佣qg\u0003ZrBM?\u001bHg";
      k[39] = "P2g%\u0019!U!?&f\u0007w\u0013\u0000\u00071\u000f{\u001f\u0010\u001f=\u0017`\u0018\u0005H\f \u00004\"\"\t3X7";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void u(Render3DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (!mc.player.getMainHandItem().isEmpty()) {
            何树何何树友树何何树 var4 = 何树何何树友树何何树.w(97050632523607L, mc.player.getMainHandItem().getItem());
            float rotYawRadians = (float)Math.toRadians(mc.player.getYRot() - 25.0F);
            double averageEdgeLengthDiv2 = mc.player.getBoundingBox().getSize() / 2.0;
            double var11 = Math.cos(rotYawRadians) * averageEdgeLengthDiv2;
            double var13 = Math.sin(rotYawRadians) * averageEdgeLengthDiv2;
            PoseStack poseStack = event.poseStack();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.setShader(GameRenderer::getPositionColorShader);
            poseStack.pushPose();
            Camera camera = mc.gameRenderer.getMainCamera();
            Vec3 cameraPos = camera.getPosition();
            RenderSystem.lineWidth(10.0F);
            Tesselator tesselator = Tesselator.getInstance();
            BufferBuilder bufferBuilder = tesselator.getBuilder();
            bufferBuilder.begin(Mode.DEBUG_LINE_STRIP, DefaultVertexFormat.POSITION_COLOR);
            List<友树友何友何友树何友> traceThings = var4.A(69375110554756L);
            int i = 0;
            if (0 < traceThings.size()) {
               友树友何友何友树何友 point = traceThings.get(0);
               double progress = 1.0F / traceThings.size();
               double offsetX = var11 * (1.0 - progress);
               double offsetZ = var13 * (1.0 - progress);
               double offsetY = 0.2F * (1.0 - progress);
               Vec3 pos = point.Q(116800409286248L).subtract(cameraPos).subtract(offsetX, offsetY, offsetZ);
               float alpha = Math.min(1, 0) * 0.05F;
               bufferBuilder.vertex(poseStack.last().pose(), (float)pos.x, (float)pos.y, (float)pos.z).color(0.0F, 0.0F, 0.0F, alpha).endVertex();
               i++;
            }

            tesselator.end();
            RenderSystem.lineWidth(2.0F * (float)mc.getWindow().getGuiScale());
            bufferBuilder.begin(Mode.DEBUG_LINE_STRIP, DefaultVertexFormat.POSITION_COLOR);
            i = 0;
            if (0 < traceThings.size()) {
               友树友何友何友树何友 point = traceThings.get(0);
               double progress = 1.0F / traceThings.size();
               double offsetX = var11 * (1.0 - progress);
               double offsetZ = var13 * (1.0 - progress);
               double offsetY = 0.2F * (1.0 - progress);
               Vec3 pos = point.Q(116800409286248L).subtract(cameraPos).subtract(offsetX, offsetY, offsetZ);
               float alpha = Math.min(1, 0) * 0.75F;
               bufferBuilder.vertex(poseStack.last().pose(), (float)pos.x, (float)pos.y, (float)pos.z).color(1.0F, 1.0F, 1.0F, alpha).endVertex();
               i++;
            }

            label23: {
               tesselator.end();
               if (var4.何何友友何树树树友何 == null) {
                  if (var4.友树树友树何何何树树 == null) {
                     break label23;
                  }

                  友友何何友友树何何友.Z(24488542601285L, poseStack, var4.友树树友树何何何树树, -16723258, false, true, true, 0.3F);
               }

               double var49 = var4.树友树友友友树树树何 - mc.gameRenderer.getMainCamera().getPosition().x;
               double var42 = var4.友友何友何树友树友友 - mc.gameRenderer.getMainCamera().getPosition().y;
               double var45 = var4.友友何何何树何何友何 - mc.gameRenderer.getMainCamera().getPosition().z;
               poseStack.pushPose();
               poseStack.translate(var49, var42, var45);
               BlockPos blockPos = new BlockPos(0, 0, 0).relative(var4.何何友友何树树树友何.getDirection());
               RenderUtils.b(
                  poseStack,
                  45.0,
                  this.何何树树树何何友友何.L(100294337064814L, blockPos.getX()),
                  this.何何树树树何何友友何.G(-blockPos.getY(), 59961070608612L),
                  this.何何树树树何何友友何.C(blockPos.getZ(), 89093007503554L)
               );
               RenderUtils.b(
                  poseStack,
                  90.0,
                  this.友树何友友友何何友何.L(100294337064814L, blockPos.getZ()),
                  this.友树何友友友何何友何.G(blockPos.getY(), 59961070608612L),
                  this.友树何友友友何何友何.C(-blockPos.getX(), 89093007503554L)
               );
               poseStack.translate(-0.5F, 0.0F, -0.5F);
               RenderSystem.setShader(GameRenderer::getPositionColorShader);
               AABB box = new AABB(0.0, 0.0, 0.0, 1.0, 0.0, 1.0);
               Color color = new Color(-21931);
               color = new Color(color.getRed(), color.getGreen(), color.getBlue(), 25);
               RenderUtils.w(
                  poseStack,
                  (float)box.minX,
                  (float)box.maxX,
                  (float)box.minY,
                  (float)box.maxY,
                  (float)box.minZ,
                  (float)box.maxZ,
                  color.getRGB(),
                  color.getRGB(),
                  0.3F,
                  70434559295573L
               );
               RenderUtils.W(
                  poseStack,
                  (float)box.minX,
                  (float)box.maxX,
                  (float)box.minY,
                  83919906043417L,
                  (float)box.maxY,
                  (float)box.minZ,
                  (float)box.maxZ,
                  color.getRGB(),
                  color.getRGB()
               );
               poseStack.popPose();
            }

            poseStack.popPose();
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(true);
            RenderSystem.disableBlend();
         }
      }
   }

   private static String HE_DA_WEI() {
      return "解放村多种2队1144号";
   }
}
