package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.树何树树何树何何树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.树友何友何何友树树友;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import why.tree.friend.antileak.Fucker;

public class 树友友友何何友树树树 extends Module implements 何树友 {
   private final ModeValue 何何友友树何何树友友;
   private final NumberValue 何树树友树树树树树何;
   private final NumberValue 树树何树何何何友友树;
   private final BooleanValue 友树树友树树友树友友;
   private final NumberValue 树友何友树友树树树树;
   private final BooleanValue 友友树树友友树友树何;
   private final NumberValue 友友友何树友何友树树;
   private final BooleanValue 友树何何何何何友何何;
   private final BooleanValue 何友树树树树何树友何;
   private final BooleanValue 友何友树树何树友友友;
   private final NumberValue 树何树树友友何何友何;
   private final NumberValue 何树何树树友何何友树;
   private final NumberValue 树友友友何何友友何树;
   private final BooleanValue 何友何树树何何友何树;
   private final 树友何友何何友树树友 何树树何友树何何何友;
   private final BooleanValue 树何树友树何何树何何;
   private final 树友何友何何友树树友 树树何何何树友树何树;
   private final BooleanValue 何树树何树友何何友友;
   private final 树友何友何何友树树友 友何树树何树友何友树;
   private final BooleanValue 树树树友友树何何友友;
   private final 树友何友何何友树树友 友友树何友何树友友何;
   private final BooleanValue 树友树何何友树树何何;
   private final 树友何友何何友树树友 树友何何树友树何何友;
   private final BooleanValue 树友何何友友友何友友;
   private final 树友何友何何友树树友 树树何树友何何友何友;
   private final BooleanValue 友树树友树何友何友何;
   private final 树友何友何何友树树友 树树友树友树树友何友;
   private final BooleanValue 树何树树树树树树何何;
   private final 树友何友何何友树树友 何何树树树友友何何树;
   private final BooleanValue 何友树树何树何友树友;
   private final BooleanValue 友友何友友何何树树树;
   private final BooleanValue 友何友友何友何树何何;
   private final 树友何友何何友树树友 树友树树树树树何何何;
   private final BooleanValue 何何何树树何何友何何;
   private final 树友何友何何友树树友 友何何何树何何何树树;
   private final BooleanValue 友友友友友友何树何何;
   private final 树友何友何何友树树友 友何友何树树树何何友;
   private final BooleanValue 何树树友友友树友树友;
   private final Map<BlockPos, Block> 树友友树友友友树何树;
   private volatile Map<BlockPos, Block> 何树何何何何何友何友;
   private long 友友何友友树树友友树;
   private boolean 友友何何树何友何友何;
   private final Map<树友友友何何友树树树.友何友树何树何何何何, BlockState> 友何友友何树友树何友;
   private final List<BlockPos> 何树友友友树友友友何;
   private final List<BlockPos> 树树何树友友树何树何;
   private long 友何何友树树何友何何;
   private boolean 何树何树友何树树何树;
   private Level 树树树友友何树友何何;
   private static ThreadPoolExecutor 何何何友何友树友何树;
   private volatile long 友何何何何何友树树何;
   private Matrix4f 树友树树树何何何何何;
   private Matrix4f 何友树何何友友友树树;
   private final Map<String, 树友友友何何友树树树.友树树何树友何何友树> 友何友树树何何友友何;
   private static final Direction[] 树树何何友树何何友树;
   private static final Set<Block> 友何何树友何何树友友;
   private static final Set<Block> 友何树树树树树友树树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final long m;
   private static final Object[] n = new Object[177];
   private static final String[] o = new String[177];
   private static String LIU_YA_FENG;

   public 树友友友何何友树树树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/render/树友友友何何友树树树.a J
      // 003: ldc2_w 30410451190417
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 29387
      // 00c: ldc2_w 4103270071334337423
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 19321
      // 019: ldc2_w 8370893700915511833
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w -8346731805116190235
      // 026: lload 1
      // 027: invokedynamic R (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/ModeValue
      // 033: dup
      // 034: sipush 21545
      // 037: ldc2_w 9036606891427487044
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 28896
      // 044: ldc2_w 1025620569189284248
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 2
      // 04f: anewarray 176
      // 052: dup
      // 053: bipush 0
      // 054: sipush 420
      // 057: ldc2_w 4376427453804611746
      // 05a: lload 1
      // 05b: lxor
      // 05c: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 061: aastore
      // 062: dup
      // 063: bipush 1
      // 064: sipush 25525
      // 067: ldc2_w 7426005460661037757
      // 06a: lload 1
      // 06b: lxor
      // 06c: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 071: aastore
      // 072: sipush 361
      // 075: ldc2_w 5965411115497392180
      // 078: lload 1
      // 079: lxor
      // 07a: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07f: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 082: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何何友友树何何树友友 Lcn/cool/cherish/value/impl/ModeValue;
      // 085: aload 0
      // 086: new cn/cool/cherish/value/impl/NumberValue
      // 089: dup
      // 08a: sipush 12718
      // 08d: ldc2_w 2126338456211568834
      // 090: lload 1
      // 091: lxor
      // 092: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 097: sipush 22952
      // 09a: ldc2_w 6987411570932469935
      // 09d: lload 1
      // 09e: lxor
      // 09f: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a4: bipush 48
      // 0a6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0a9: bipush 16
      // 0ab: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ae: sipush 256
      // 0b1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0b4: bipush 4
      // 0b5: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0b8: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0bb: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何树树友树树树树树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 0be: aload 0
      // 0bf: new cn/cool/cherish/value/impl/NumberValue
      // 0c2: dup
      // 0c3: sipush 3435
      // 0c6: ldc2_w 7836851351937909804
      // 0c9: lload 1
      // 0ca: lxor
      // 0cb: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d0: sipush 1313
      // 0d3: ldc2_w 9004268334823836795
      // 0d6: lload 1
      // 0d7: lxor
      // 0d8: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0dd: sipush 300
      // 0e0: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0e3: bipush 0
      // 0e4: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0e7: sipush 3000
      // 0ea: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ed: bipush 50
      // 0ef: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0f2: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0f5: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树树何树何何何友友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 0f8: ldc2_w -8353306500784055747
      // 0fb: lload 1
      // 0fc: invokedynamic ò (JJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 101: aload 0
      // 102: new cn/cool/cherish/value/impl/BooleanValue
      // 105: dup
      // 106: sipush 19204
      // 109: ldc2_w 8117717960901837437
      // 10c: lload 1
      // 10d: lxor
      // 10e: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 113: sipush 28593
      // 116: ldc2_w 7330805396474685135
      // 119: lload 1
      // 11a: lxor
      // 11b: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 120: bipush 1
      // 121: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 124: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 127: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友树树友树树友树友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 12a: aload 0
      // 12b: new cn/cool/cherish/value/impl/NumberValue
      // 12e: dup
      // 12f: sipush 10079
      // 132: ldc2_w 2290669041141067265
      // 135: lload 1
      // 136: lxor
      // 137: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 13c: sipush 4525
      // 13f: ldc2_w 9222515821970036952
      // 142: lload 1
      // 143: lxor
      // 144: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 149: sipush 23047
      // 14c: ldc2_w 9127057056967504089
      // 14f: lload 1
      // 150: lxor
      // 151: invokedynamic e (IJ)I bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 156: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 159: sipush 10000
      // 15c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 15f: sipush 32462
      // 162: ldc2_w 5797807092182488081
      // 165: lload 1
      // 166: lxor
      // 167: invokedynamic e (IJ)I bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 16f: sipush 10000
      // 172: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 175: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 178: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树友何友树友树树树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 17b: aload 0
      // 17c: new cn/cool/cherish/value/impl/BooleanValue
      // 17f: dup
      // 180: sipush 6191
      // 183: ldc2_w 5339721729297289569
      // 186: lload 1
      // 187: lxor
      // 188: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 18d: sipush 2482
      // 190: ldc2_w 5994123322879246563
      // 193: lload 1
      // 194: lxor
      // 195: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 19a: bipush 1
      // 19b: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 19e: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1a1: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友友树树友友树友树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1a4: pop
      // 1a5: aload 0
      // 1a6: new cn/cool/cherish/value/impl/NumberValue
      // 1a9: dup
      // 1aa: sipush 19694
      // 1ad: ldc2_w 6624603202537964947
      // 1b0: lload 1
      // 1b1: lxor
      // 1b2: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b7: sipush 20021
      // 1ba: ldc2_w 8893895621927290702
      // 1bd: lload 1
      // 1be: lxor
      // 1bf: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c4: dconst_1
      // 1c5: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1c8: dconst_1
      // 1c9: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1cc: ldc2_w 15.0
      // 1cf: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1d2: ldc2_w 0.5
      // 1d5: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1d8: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1db: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友友友何树友何友树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 1de: aload 0
      // 1df: new cn/cool/cherish/value/impl/BooleanValue
      // 1e2: dup
      // 1e3: sipush 7905
      // 1e6: ldc2_w 1049727500561979282
      // 1e9: lload 1
      // 1ea: lxor
      // 1eb: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f0: sipush 784
      // 1f3: ldc2_w 5281943234874051141
      // 1f6: lload 1
      // 1f7: lxor
      // 1f8: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1fd: bipush 0
      // 1fe: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 201: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 204: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友树何何何何何友何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 207: aload 0
      // 208: new cn/cool/cherish/value/impl/BooleanValue
      // 20b: dup
      // 20c: sipush 13849
      // 20f: ldc2_w 7016123936813793039
      // 212: lload 1
      // 213: lxor
      // 214: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 219: sipush 29113
      // 21c: ldc2_w 4321695820791412916
      // 21f: lload 1
      // 220: lxor
      // 221: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 226: bipush 1
      // 227: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 22a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 22d: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何友树树树树何树友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 230: aload 0
      // 231: new cn/cool/cherish/value/impl/BooleanValue
      // 234: dup
      // 235: sipush 14460
      // 238: ldc2_w 3425930668124778815
      // 23b: lload 1
      // 23c: lxor
      // 23d: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 242: sipush 15723
      // 245: ldc2_w 8098988348264002587
      // 248: lload 1
      // 249: lxor
      // 24a: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 24f: bipush 1
      // 250: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 253: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 256: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友何友树树何树友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 259: aload 0
      // 25a: new cn/cool/cherish/value/impl/NumberValue
      // 25d: dup
      // 25e: sipush 28154
      // 261: ldc2_w 4774766796333180051
      // 264: lload 1
      // 265: lxor
      // 266: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 26b: sipush 7043
      // 26e: ldc2_w 729501535642456808
      // 271: lload 1
      // 272: lxor
      // 273: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 278: bipush 32
      // 27a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 27d: bipush 8
      // 27f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 282: sipush 1024
      // 285: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 288: bipush 4
      // 289: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 28c: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 28f: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树何树树友友何何友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 292: aload 0
      // 293: new cn/cool/cherish/value/impl/NumberValue
      // 296: dup
      // 297: sipush 25626
      // 29a: ldc2_w 1781029817044757847
      // 29d: lload 1
      // 29e: lxor
      // 29f: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2a4: sipush 27902
      // 2a7: ldc2_w 8443114747509040619
      // 2aa: lload 1
      // 2ab: lxor
      // 2ac: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2b1: bipush 32
      // 2b3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2b6: bipush 8
      // 2b8: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2bb: sipush 1024
      // 2be: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2c1: bipush 4
      // 2c2: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2c5: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 2c8: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何树何树树友何何友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 2cb: aload 0
      // 2cc: new cn/cool/cherish/value/impl/NumberValue
      // 2cf: dup
      // 2d0: sipush 23621
      // 2d3: ldc2_w 1752454697119274318
      // 2d6: lload 1
      // 2d7: lxor
      // 2d8: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2dd: sipush 5459
      // 2e0: ldc2_w 568148578684509195
      // 2e3: lload 1
      // 2e4: lxor
      // 2e5: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2ea: bipush 1
      // 2eb: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2ee: bipush 1
      // 2ef: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2f2: bipush 10
      // 2f4: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2f7: bipush 1
      // 2f8: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2fb: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 2fe: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树友友友何何友友何树 Lcn/cool/cherish/value/impl/NumberValue;
      // 301: aload 0
      // 302: new cn/cool/cherish/value/impl/BooleanValue
      // 305: dup
      // 306: sipush 19320
      // 309: ldc2_w 6451295066018464302
      // 30c: lload 1
      // 30d: lxor
      // 30e: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 313: sipush 17826
      // 316: ldc2_w 2778438561814432958
      // 319: lload 1
      // 31a: lxor
      // 31b: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 320: bipush 1
      // 321: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 324: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 327: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何友何树树何何友何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 32a: aload 0
      // 32b: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 32e: dup
      // 32f: sipush 12003
      // 332: ldc2_w 6026807935732819898
      // 335: lload 1
      // 336: lxor
      // 337: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 33c: sipush 14009
      // 33f: ldc2_w 5335586029349355513
      // 342: lload 1
      // 343: lxor
      // 344: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 349: new java/awt/Color
      // 34c: dup
      // 34d: bipush 0
      // 34e: sipush 255
      // 351: sipush 255
      // 354: invokespecial java/awt/Color.<init> (III)V
      // 357: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 35a: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何树树何友树何何何友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 35d: aload 0
      // 35e: new cn/cool/cherish/value/impl/BooleanValue
      // 361: dup
      // 362: sipush 12635
      // 365: ldc2_w 7794091270816413791
      // 368: lload 1
      // 369: lxor
      // 36a: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 36f: sipush 11828
      // 372: ldc2_w 3070682817181361972
      // 375: lload 1
      // 376: lxor
      // 377: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 37c: bipush 1
      // 37d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 380: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 383: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树何树友树何何树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 386: aload 0
      // 387: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 38a: dup
      // 38b: sipush 19585
      // 38e: ldc2_w 5369969327659468272
      // 391: lload 1
      // 392: lxor
      // 393: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 398: sipush 29171
      // 39b: ldc2_w 4047622943182026988
      // 39e: lload 1
      // 39f: lxor
      // 3a0: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3a5: new java/awt/Color
      // 3a8: dup
      // 3a9: bipush 0
      // 3aa: sipush 255
      // 3ad: bipush 0
      // 3ae: invokespecial java/awt/Color.<init> (III)V
      // 3b1: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 3b4: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树树何何何树友树何树 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 3b7: aload 0
      // 3b8: new cn/cool/cherish/value/impl/BooleanValue
      // 3bb: dup
      // 3bc: sipush 14709
      // 3bf: ldc2_w 7778430586874900506
      // 3c2: lload 1
      // 3c3: lxor
      // 3c4: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3c9: sipush 29492
      // 3cc: ldc2_w 4026532651108530747
      // 3cf: lload 1
      // 3d0: lxor
      // 3d1: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3d6: bipush 1
      // 3d7: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 3da: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 3dd: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何树树何树友何何友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 3e0: aload 0
      // 3e1: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 3e4: dup
      // 3e5: sipush 14892
      // 3e8: ldc2_w 6763858350567961449
      // 3eb: lload 1
      // 3ec: lxor
      // 3ed: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3f2: sipush 17023
      // 3f5: ldc2_w 1796522187084516157
      // 3f8: lload 1
      // 3f9: lxor
      // 3fa: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3ff: new java/awt/Color
      // 402: dup
      // 403: sipush 255
      // 406: bipush 0
      // 407: bipush 0
      // 408: invokespecial java/awt/Color.<init> (III)V
      // 40b: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 40e: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友何树树何树友何友树 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 411: aload 0
      // 412: new cn/cool/cherish/value/impl/BooleanValue
      // 415: dup
      // 416: sipush 24206
      // 419: ldc2_w 1182096673883903895
      // 41c: lload 1
      // 41d: lxor
      // 41e: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 423: ldc_w "铁"
      // 426: bipush 1
      // 427: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 42a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 42d: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树树树友友树何何友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 430: aload 0
      // 431: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 434: dup
      // 435: sipush 14671
      // 438: ldc2_w 687743700246966337
      // 43b: lload 1
      // 43c: lxor
      // 43d: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 442: sipush 3792
      // 445: ldc2_w 442001393296443279
      // 448: lload 1
      // 449: lxor
      // 44a: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 44f: new java/awt/Color
      // 452: dup
      // 453: sipush 210
      // 456: sipush 210
      // 459: sipush 210
      // 45c: invokespecial java/awt/Color.<init> (III)V
      // 45f: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 462: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友友树何友何树友友何 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 465: aload 0
      // 466: new cn/cool/cherish/value/impl/BooleanValue
      // 469: dup
      // 46a: sipush 15135
      // 46d: ldc2_w 7972928023222661653
      // 470: lload 1
      // 471: lxor
      // 472: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 477: ldc_w "金"
      // 47a: bipush 1
      // 47b: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 47e: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 481: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树友树何何友树树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 484: aload 0
      // 485: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 488: dup
      // 489: sipush 4389
      // 48c: ldc2_w 8815635261996865657
      // 48f: lload 1
      // 490: lxor
      // 491: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 496: sipush 7478
      // 499: ldc2_w 2989883835113608247
      // 49c: lload 1
      // 49d: lxor
      // 49e: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4a3: new java/awt/Color
      // 4a6: dup
      // 4a7: sipush 255
      // 4aa: sipush 215
      // 4ad: bipush 0
      // 4ae: invokespecial java/awt/Color.<init> (III)V
      // 4b1: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 4b4: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树友何何树友树何何友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 4b7: aload 0
      // 4b8: new cn/cool/cherish/value/impl/BooleanValue
      // 4bb: dup
      // 4bc: sipush 18748
      // 4bf: ldc2_w 4268915188695908447
      // 4c2: lload 1
      // 4c3: lxor
      // 4c4: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4c9: ldc_w "铜"
      // 4cc: bipush 1
      // 4cd: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 4d0: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 4d3: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树友何何友友友何友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 4d6: aload 0
      // 4d7: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 4da: dup
      // 4db: sipush 22875
      // 4de: ldc2_w 5710140676304523308
      // 4e1: lload 1
      // 4e2: lxor
      // 4e3: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e8: sipush 23390
      // 4eb: ldc2_w 4234969940242158098
      // 4ee: lload 1
      // 4ef: lxor
      // 4f0: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4f5: new java/awt/Color
      // 4f8: dup
      // 4f9: sipush 205
      // 4fc: bipush 127
      // 4fe: bipush 50
      // 500: invokespecial java/awt/Color.<init> (III)V
      // 503: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 506: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树树何树友何何友何友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 509: aload 0
      // 50a: new cn/cool/cherish/value/impl/BooleanValue
      // 50d: dup
      // 50e: sipush 19773
      // 511: ldc2_w 52090974543987777
      // 514: lload 1
      // 515: lxor
      // 516: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 51b: sipush 28873
      // 51e: ldc2_w 8936038244575541706
      // 521: lload 1
      // 522: lxor
      // 523: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 528: bipush 1
      // 529: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 52c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 52f: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友树树友树何友何友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 532: aload 0
      // 533: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 536: dup
      // 537: sipush 6990
      // 53a: ldc2_w 668176997484433926
      // 53d: lload 1
      // 53e: lxor
      // 53f: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 544: sipush 7886
      // 547: ldc2_w 5632831158017333125
      // 54a: lload 1
      // 54b: lxor
      // 54c: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 551: new java/awt/Color
      // 554: dup
      // 555: bipush 0
      // 556: bipush 0
      // 557: sipush 255
      // 55a: invokespecial java/awt/Color.<init> (III)V
      // 55d: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 560: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树树友树友树树友何友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 563: aload 0
      // 564: new cn/cool/cherish/value/impl/BooleanValue
      // 567: dup
      // 568: sipush 12644
      // 56b: ldc2_w 6506106328485050395
      // 56e: lload 1
      // 56f: lxor
      // 570: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 575: ldc_w "煤"
      // 578: bipush 1
      // 579: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 57c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 57f: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树何树树树树树树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 582: aload 0
      // 583: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 586: dup
      // 587: sipush 5377
      // 58a: ldc2_w 857559275169455129
      // 58d: lload 1
      // 58e: lxor
      // 58f: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 594: sipush 3084
      // 597: ldc2_w 2430796378410583387
      // 59a: lload 1
      // 59b: lxor
      // 59c: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5a1: new java/awt/Color
      // 5a4: dup
      // 5a5: bipush 50
      // 5a7: bipush 50
      // 5a9: bipush 50
      // 5ab: invokespecial java/awt/Color.<init> (III)V
      // 5ae: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 5b1: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何何树树树友友何何树 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 5b4: aload 0
      // 5b5: new cn/cool/cherish/value/impl/BooleanValue
      // 5b8: dup
      // 5b9: sipush 3412
      // 5bc: ldc2_w 8214477433928778790
      // 5bf: lload 1
      // 5c0: lxor
      // 5c1: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5c6: sipush 5220
      // 5c9: ldc2_w 2319134746327752051
      // 5cc: lload 1
      // 5cd: lxor
      // 5ce: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5d3: bipush 1
      // 5d4: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 5d7: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 5da: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何友树树何树何友树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 5dd: aload 0
      // 5de: new cn/cool/cherish/value/impl/BooleanValue
      // 5e1: dup
      // 5e2: sipush 25578
      // 5e5: ldc2_w 1806037432844610219
      // 5e8: lload 1
      // 5e9: lxor
      // 5ea: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5ef: sipush 20598
      // 5f2: ldc2_w 4101317295876954425
      // 5f5: lload 1
      // 5f6: lxor
      // 5f7: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5fc: bipush 1
      // 5fd: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 600: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 603: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友友何友友何何树树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 606: aload 0
      // 607: new cn/cool/cherish/value/impl/BooleanValue
      // 60a: dup
      // 60b: sipush 28918
      // 60e: ldc2_w 5650457555097352674
      // 611: lload 1
      // 612: lxor
      // 613: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 618: sipush 8723
      // 61b: ldc2_w 8212919356387044118
      // 61e: lload 1
      // 61f: lxor
      // 620: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 625: bipush 1
      // 626: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 629: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 62c: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友何友友何友何树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 62f: aload 0
      // 630: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 633: dup
      // 634: sipush 23664
      // 637: ldc2_w 433459036126500118
      // 63a: lload 1
      // 63b: lxor
      // 63c: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 641: sipush 2575
      // 644: ldc2_w 2551140464738763626
      // 647: lload 1
      // 648: lxor
      // 649: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 64e: new java/awt/Color
      // 651: dup
      // 652: bipush 0
      // 653: bipush 85
      // 655: sipush 255
      // 658: invokespecial java/awt/Color.<init> (III)V
      // 65b: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 65e: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树友树树树树树何何何 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 661: aload 0
      // 662: new cn/cool/cherish/value/impl/BooleanValue
      // 665: dup
      // 666: sipush 32142
      // 669: ldc2_w 6526029632739079317
      // 66c: lload 1
      // 66d: lxor
      // 66e: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 673: sipush 6937
      // 676: ldc2_w 7466415319553446410
      // 679: lload 1
      // 67a: lxor
      // 67b: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 680: bipush 1
      // 681: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 684: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 687: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何何何树树何何友何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 68a: aload 0
      // 68b: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 68e: dup
      // 68f: sipush 3300
      // 692: ldc2_w 724776226170340742
      // 695: lload 1
      // 696: lxor
      // 697: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 69c: sipush 17397
      // 69f: ldc2_w 7314569078207793852
      // 6a2: lload 1
      // 6a3: lxor
      // 6a4: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6a9: new java/awt/Color
      // 6ac: dup
      // 6ad: sipush 128
      // 6b0: sipush 128
      // 6b3: sipush 128
      // 6b6: invokespecial java/awt/Color.<init> (III)V
      // 6b9: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 6bc: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友何何何树何何何树树 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 6bf: aload 0
      // 6c0: new cn/cool/cherish/value/impl/BooleanValue
      // 6c3: dup
      // 6c4: sipush 15241
      // 6c7: ldc2_w 5009085318230913684
      // 6ca: lload 1
      // 6cb: lxor
      // 6cc: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6d1: sipush 22758
      // 6d4: ldc2_w 2043542637524832693
      // 6d7: lload 1
      // 6d8: lxor
      // 6d9: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6de: bipush 1
      // 6df: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 6e2: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 6e5: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友友友友友友何树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 6e8: aload 0
      // 6e9: new cn/cool/cherish/value/impl/树友何友何何友树树友
      // 6ec: dup
      // 6ed: sipush 9169
      // 6f0: ldc2_w 2001232646852029113
      // 6f3: lload 1
      // 6f4: lxor
      // 6f5: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6fa: bipush 41
      // 6fc: ldc2_w 3695971284482263373
      // 6ff: lload 1
      // 700: lxor
      // 701: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 706: new java/awt/Color
      // 709: dup
      // 70a: sipush 253
      // 70d: bipush 0
      // 70e: sipush 250
      // 711: invokespecial java/awt/Color.<init> (III)V
      // 714: invokespecial cn/cool/cherish/value/impl/树友何友何何友树树友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/awt/Color;)V
      // 717: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友何友何树树树何何友 Lcn/cool/cherish/value/impl/树友何友何何友树树友;
      // 71a: aload 0
      // 71b: new cn/cool/cherish/value/impl/BooleanValue
      // 71e: dup
      // 71f: sipush 4142
      // 722: ldc2_w 1650232902668786046
      // 725: lload 1
      // 726: lxor
      // 727: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 72c: sipush 27472
      // 72f: ldc2_w 8384625910515196418
      // 732: lload 1
      // 733: lxor
      // 734: invokedynamic c (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 739: bipush 1
      // 73a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 73d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 740: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何树树友友友树友树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 743: aload 0
      // 744: new java/util/concurrent/ConcurrentHashMap
      // 747: dup
      // 748: invokespecial java/util/concurrent/ConcurrentHashMap.<init> ()V
      // 74b: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树友友树友友友树何树 Ljava/util/Map;
      // 74e: aload 0
      // 74f: aconst_null
      // 750: ldc2_w -8352634255649251392
      // 753: lload 1
      // 754: invokedynamic Q (Ljava/lang/Object;Ljava/util/Map;JJ)V bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 759: aload 0
      // 75a: lconst_0
      // 75b: ldc2_w -8348035586712061647
      // 75e: lload 1
      // 75f: invokedynamic Q (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 764: aload 0
      // 765: bipush 0
      // 766: ldc2_w -8354804932951034828
      // 769: lload 1
      // 76a: invokedynamic Q (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 76f: aload 0
      // 770: new java/util/concurrent/ConcurrentHashMap
      // 773: dup
      // 774: invokespecial java/util/concurrent/ConcurrentHashMap.<init> ()V
      // 777: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友何友友何树友树何友 Ljava/util/Map;
      // 77a: aload 0
      // 77b: new java/util/concurrent/CopyOnWriteArrayList
      // 77e: dup
      // 77f: invokespecial java/util/concurrent/CopyOnWriteArrayList.<init> ()V
      // 782: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.何树友友友树友友友何 Ljava/util/List;
      // 785: aload 0
      // 786: new java/util/concurrent/CopyOnWriteArrayList
      // 789: dup
      // 78a: invokespecial java/util/concurrent/CopyOnWriteArrayList.<init> ()V
      // 78d: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.树树何树友友树何树何 Ljava/util/List;
      // 790: aload 0
      // 791: lconst_0
      // 792: ldc2_w -8351150004708902674
      // 795: lload 1
      // 796: invokedynamic Q (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 79b: aload 0
      // 79c: bipush 0
      // 79d: ldc2_w -8351019578603956345
      // 7a0: lload 1
      // 7a1: invokedynamic Q (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 7a6: aload 0
      // 7a7: lconst_0
      // 7a8: ldc2_w -8347909542564092553
      // 7ab: lload 1
      // 7ac: invokedynamic Q (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 7b1: aload 0
      // 7b2: new java/util/concurrent/ConcurrentHashMap
      // 7b5: dup
      // 7b6: invokespecial java/util/concurrent/ConcurrentHashMap.<init> ()V
      // 7b9: putfield cn/cool/cherish/module/impl/render/树友友友何何友树树树.友何友树树何何友友何 Ljava/util/Map;
      // 7bc: ldc2_w -8348950799749041601
      // 7bf: lload 1
      // 7c0: invokedynamic ò (JJ)Z bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 7c5: ifeq 7cc
      // 7c8: bipush 0
      // 7c9: goto 7cd
      // 7cc: bipush 1
      // 7cd: ldc2_w -8346617306515301041
      // 7d0: lload 1
      // 7d1: invokedynamic ò (ZJJ)V bsm=cn/cool/cherish/module/impl/render/树友友友何何友树树树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 7d6: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-4995017686532659355L, -3086756707834198911L, MethodHandles.lookup().lookupClass()).a(160797843100704L);
      // $VF: monitorexit
      a = var10000;
      long var25 = a ^ 117062062765170L;
      a();
      Cipher var16;
      Cipher var29 = var16 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var25 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var17 = 1; var17 < 8; var17++) {
         var10003[var17] = (byte)(var25 << var17 * 8 >>> 56);
      }

      var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var23 = new String[93];
      int var21 = 0;
      String var20 = "s_[4ÏJ\u009e\u0019\u0085©L\u0000_Øæ\u0013N{ú\u0083ðàtÁ£¤\u00ad³Ìñf\u00ad\u0018>f\u0013]Ïr\u0086\u0096¸Ô\u008e.,PE9°s\u008aéo8Ý\b(nò½Î\u0016¾Å\n+\u0088ÚÈ)\u001b\\ÜáO\u00adç\u001eo.¦Ó°bZaD@9¼é¡\u008am2?\u001e\u0018#R{.®9<\u0017×ù£_VCáÀò(&\u0015ñe\nâ \u0005\u0084\u0010ÅÜ\u0000£<õl\u009c\u0010\u0003\u008ab@ÔN9æÈË\u0099NÞk~¾\u0012\u009aØ6\u0010ódñ\rÇïF\u0003uÏo¡¤\u001d·T L´\u001eÝ\u009b\u0016\u0088\u0099\u0093Vw'`cÆô7\u00807Zã]n\tMÀd\u0019¯{z$\u0018s\"~ë\u0088&¦#â×!\u001aÐú\u0089uP\u0096£ä\u008dî:\u0019 »\nq\n\u000f13_h^elFhâ\n\u0096î\u0083\u009býOíFÞA¿÷Ò\u000f\u0094{ ô\u0090:;òl,ï\u008433ò/Ã#Á\u0099öã©øU6W/Ûn½\u0007â!\u001e\u0018\u0093\u009fÉGÈ>¯ö\u001e²´`\u0093ú/YØF\nº°\u001d86\u0010\u008dUß\u0095÷áw\u0007\u0081\u0089\u000bå \u0004\f\u0013\u0018;¾g9¹*I×\u0092kY_æ«cþÙ\u0094\u009b)(\u000eÆR Å¡4(àfç\u0010°\u0014ÿá\u0014Ð@ãD\u001cCÖ0ÉÀ\u0090ôY5û·¥yr phÊÈÒ\u000b·ÿ\u000eé]¸5è\u0012|\u007fÏR'53WÍÂ¾ðÃ)º\u0010/ ü\u008ce\u009aÔ¯\u001b²³\u0080¾µVPæ[3õ4Õ±ÛsDN(ó´\u0080²\u008d´\u0018õz\u0015z¡U\u0019\u0086Àz6¶\u0086\u009c\u001f2¸ö£aC4tõ $\u0080°rÜ©\u0081Æµ\u0004õ+*\u0001Ø\u008eÉ\u0002äCS\u008b\u0097\u008dH\u000e\u000bÜk3úa\u0010\u0017Êã\u009d\u0015ç\u001dk3ãÈ\u0097{®\u000f! ìA\u0007a\u000b¼I\"µ\fn¥<Ó\u0083\u0085}ð/_¤\u008667øÀ\u0096U5Õ¸k\u0010%U\u0011K\u008e]=²±Bæòºds|(W§ÑØ8)Ía^\u0013]Þµ\u0017\u0084ævþRh\"0\r\u008b\nV`$Ï %|qD\u009f¡u[(\u008c \u0019;\u0097&\u008eý\u008b\u000ff\u0088^xÒÖ\u0005\u001e z3\u0090»?¨Ëk÷cR{>\u0000}(ä\\óBÐ\u0016\u008fÕtõc*\u001ba\u001d-#~Ø*Åg&\u0006iú©ÁöI4Þm\u0098k\u0085<É\u0007ã >°}M\u009c\u009eb\u001b \"\u0001ãíøi4?Á_ó¤\u0093\u001c<MÊ\u0016\u0087\u000b\rá\n\u0010m\u0088\u0003\u0084\u009d¾{\u0092\u008d8\u0015B\f&¼\u0017\u0018&ù6Ä.¼W\u0091ý»¡~*^Å\u001d\r®oD\u0090aK-\u0010Û+û¤\u0018º\u0090¤4½\u0093\u0084C~é\u0087(£\u001c5â\u008f\u0006ÚÍë\u008f\u0098\u0097\u001a°E ó^¦°¦\u0083ou>·óTn9?lè\u009e\u0098Æý\u0015o$ r\"\u0084ÇL÷\u0007iV¬\u0090¤M2lYøæ\u008aFTåwQgk\u009a¨+6\u001e3 çw\f\u0091´å2¶¡ÃÈ¹ç»\u0098\u0095\u0094\u0006ø1³\u0013Ïà6\u009d¬\u0087\u0086@\u008dð \u001cSj\u0093È¤$rÏî(pª!\u0006C\u0013\u0010ùÝÍÖ2¼µ-çx<\u0085rÄ ´Áò\u008d\u008eLS\u0018\u008b8\u0097³Þÿv\u008aüp0\u000f/\u008a¿iò->´×©\u0087Ä\u0010!\u0080\u001d\u001b´48j'\u0088f\u0080Î\u0097¼\u0002 \u0080ææ×\u0083ø¿Ä\u0082Ði'A¬©9Dæ\u0019\u0017W3|\u0019Ôü\u0098\u0094 _\u0010y\u0010Æjþ9ê\u0091\u009d\u0006\u0005¶LÕ\u0094\u009f\u0099÷ *\u0017>P-§\u0091Û@Õ\bºwÁ8)¦¤¢)Éüt(\u0087ó.Ûµ.JÍ\u0018 _Ë±\u0000\u0095#ÂL\u0004ûN^\fUõ;¯Í!ï×Ð\u000e Í\u0084\u000e(ù\raÅÿXë,R\bJíÈ\u0010ïÙý5µ\u0012f\u0096\u001e¿÷sØ5(\u008b\u008b#?Ý_í\r\rQ¢\u00831pÌ\u000e|6}9\u0010\u0087¢UxxV¨\"½\u0000\u0006:¶\u0012xóe\u0097È\u0010.áù_¿å#\u008fOï\u0018b\u0084\f\u0001Ä\u0018WC\u0082Cëfkfªj\u0096\u000f\u0000\bg¼\u0012\\ 6ø÷\u00898 j4\u0083\u008ee\u00826\\O¾\u0088\u001c\u0019w\u0019+©Hê\u0097q\u0007\u0099îXDã= @Ü%0ÕRC\u001b\u0090Må÷@5\u00119×\u008b½kHz:\u007fë\u001d\u009b\u009bÒ\róÉö\u0006Û \u001b©0aé±\u0000öa \u0095\u0002-É\u0005\u0000\u0010GA7áKdw7\u0097D×t\u0002h\u0012l(\u0097Õ\u0000ò\u001fÝy'\u0016º ãù¯så6\n4z\u0087&&Äm\u009eÑ\by-ÛS¬\u001b\u0006\u0080üâh>\u0010CIæ´¨Òß\u001aÕ\u0099½ÎÅh\u0005\u0004(\\g¨ý\\\u0016v*\u001b|Áº+°\u009c\u008f':IÊe\u0098\u0091²Ü\u009b5ªaN\u008a²gó36@ÛÑw\u0010\u0081\u001dd\u0088_¨ã¨\u0003Eoú<HS-\u0010(nÑ¥\u0000ä(ÊSÄ\u0090øuá6W \u0015*¾\u0087\u0095ï®ÿ\b¶ÅiËJªO¸îõ¦<´³\u0018µ¼a?*0§Ò\u0010´Øû\u0010áU\rðËi\u008c`øÃ\u000eß( °\u001aûÍ'oÐ\u008e¯'®É\u0097ð-\u0017\u0093\u000f\u001e»õ)?íEÜV¹.\u0000;\t/ûÃ\u000fñ«°\u0010Þ\u008e\u0097ß\u0080\u0094\u008aï'+\u0011\u0001ÌÒm-\u0010y²ÇåP\u009c>6<£\u0004' ì¼È\u00188À'áEî÷½c9C\u0014\"\u008b`à~\u0092\u0080.\u0092ìm= \u008b5Ï©\\\u000b mÔ&E+.\u001a\u0016zØ¬Y\u008d*}p\u001b¶æ\\áó\u0013.P\u0010¡Õ\u0095°²Z\u0003Z\u008bj,£s\u000e\u0086\u001d xX\u0019ÖÚ.0åU\u0003¾ìÇ}/y\u0098´²Å\u0092!DÅ< ¶\u0000ü\u009e÷¬\u0010Ýiõw\u008envi\u009e\u008dtºç?ÞP0<\rC&]%\u0087\u0097&\u008bRA\f_ï\u009by\u00ad\"Ï½z\u001c°>ÙEû=<6\u008c\u0094CõâNìy»|uë Áú\u0098ð\u0010@=mÁæÙ7C/]ÌÿõV¬÷ xè$ûíÎVÕyPøoê/;\u0085S%\u000e\u0002Cx+.5¢\u0094=¼A®ó 6\u00882É#\u0018\u0014>o\u0006\u0011vÌÊ\u007fyÖ\u0095«\u0080`tü/\u0005MúH¡ôØ\u0097\u0010tDòèM÷Båñ/LÐ`Ò,s þØ`S?\\ìÓýf\u0094\"ù\u001cð¦dv\u0080\u00adqÚ\u0088Iíbì\u0016ãs\u0095Ã(\u0089\u0097Cë\u0093Ú\u000fæ±4âF©\u0098½EzL\u001d\u0004 öñ³\u0096\u0091åe\u0089Ô3edEyàìÐñ\u0007\u0010\u0081\u001a\u009aU\u0089W\u0006ÊS'\u0015ä\u009f`ãH(\u0082ÄP\u0082\u001b\u0006OÜ\u00824V\u0000K*\u0005WlÆF\u007fX\u008d$; yJÑ¡Ì¨¢È{\u001d\u0012Gí\u008cJ\u0010\u001b\u00883\u008aTBm÷\u009cð4;¬Y1A KÓI]ê\u0095\u0096\u0000]¾F\u0011\u0099;XúcÏ\n$Q\u0095I\u0014ic\u000e½4ªÏ(\u0018fB\u0000Ç¹\u0012\u000eÂ'2Hwð\u0087\u0094\u0019óÂÄ4·\u0091\u001aú\u0010(°1ü\u0090\u0087\u000fq\fOo?)Ôâ¥\u0010(<õ\u0094ÚE\u0001~yX\bGápÐc / ÛÐ\u007f\u0019\u008a\u0082\u0001yyóá\u008cÞ âìe¢¹¼7\u0002\u0019\b?ÉX8ÒW\u0010-}\u0088p\t\rËÂï\u0097\u009fióUCU á<3\u008a®ªîE\n:öB¿ÐÝçá·\u008bQ\u0098ò\u0006\u001a\tÂÉâùÞÇ\u009f\u0018\u00adñS\r«ðüGÙ¿ÄµÔÎ>\u0000\u009a±¬J\u009e\u001afi \u001ah\u001cJ\u0095\u0085AhÞ[îI\u0003ã\u001cK)\u0099\u001f\u0089ÀW\u0001\b'å\u0006gt¶\u0005\n\u0018\u009f©õBØ%\u0095ÌÍ\u0003fFÕ¥çÌ\u0081ê´\u0006\u0092Ýº® ¬Z÷?°Ä¾¥= û\u0011*XÐ\u009f\\ì¾(\u000fÔâó.Ú\u009f¼µ\u0013\u0014h\u0010çÆgrpG¹@î;é\u001byÑíh u\r\u008f\u0003b\u001d\u0099\u0089Xt®\u0019OíÃDì~¤ßiKö{ùoÁ3Ìã·S\u0010ðô\u001b\u0093\u008e\u0013«5\u0096Z>Ù\u0097ñöy G»\"¹Uu¤\u007fåÚqª\täíó é\u0096Bï\u0082{\u0007ùg;0dJy±\u0010!DKq\u0090\u0083×ËÍ\"\u0010Ã\u0001Þp>\u0010ª\u008eWägaV¯±±ïãâ`ê{\u0018S?®Ç\u0089\u0018¨î^\u009f*\u009c\u0002o\rÓþ5½Þ}\u0010GØ\u0010Ú\u0096\u0082ùø\u000b\"X\u0000¾¬Õ«ð&Ö(Ü\u0080»\u0080\u008e\u009dnµ/×Ã\b¿\u0096Ýn°/vW\u0000_s\u0084é\\\b®\u0014\u000bÃ´ÁÁ¸\u0097Ðð\u0019¦(ìÅN[t\u0080\t\u0088ãù\u0005\n\u0083oïI+\u007fTv=\\G\fuªÃÎ.+\u00ad\u008f×I\u0007\u0095ÙÛ(è";
      short var22 = 2538;
      char var19 = ' ';
      int var28 = -1;

      label56:
      while (true) {
         String var30 = var20.substring(++var28, var28 + var19);
         int var10001 = -1;

         while (true) {
            String var41 = c(var16.doFinal(var30.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var23[var21++] = var41;
                  if ((var28 += var19) >= var22) {
                     c = var23;
                     h = new String[93];
                     l = new HashMap(13);
                     Cipher var5;
                     Cipher var32 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var25 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(var25 << var6 * 8 >>> 56);
                     }

                     var32.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[2];
                     int var8 = 0;
                     byte var7 = 0;

                     do {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = "1)\u0091¸ñÆ°\u001e\u008eß¸Ä¤`jp".substring(var10001, var7).getBytes("ISO-8859-1");
                        var10001 = var8++;
                        long var13 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        byte[] var15 = var5.doFinal(
                           new byte[]{
                              (byte)(var13 >>> 56),
                              (byte)(var13 >>> 48),
                              (byte)(var13 >>> 40),
                              (byte)(var13 >>> 32),
                              (byte)(var13 >>> 24),
                              (byte)(var13 >>> 16),
                              (byte)(var13 >>> 8),
                              (byte)var13
                           }
                        );
                        long var10004 = (var15[0] & 255L) << 56
                           | (var15[1] & 255L) << 48
                           | (var15[2] & 255L) << 40
                           | (var15[3] & 255L) << 32
                           | (var15[4] & 255L) << 24
                           | (var15[5] & 255L) << 16
                           | (var15[6] & 255L) << 8
                           | var15[7] & 255L;
                        byte var48 = -1;
                        var11[var10001] = var10004;
                     } while (var7 < 16);

                     j = var11;
                     k = new Integer[2];
                     Cipher var0;
                     Cipher var33 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var25 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var25 << var1 * 8 >>> 56);
                     }

                     var33.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-125, -52, -80, -85, 31, -128, 46, 66});
                     long var46 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     byte var39 = -1;
                     m = var46;
                     树树何何友树何何友树 = Direction.values();
                     友何何树友何何树友友 = Set.of(
                        d<"R">(8845868699276092242L, var25),
                        d<"R">(8861372987146193658L, var25),
                        d<"R">(8845313128411273067L, var25),
                        d<"R">(8857926466001881972L, var25),
                        d<"R">(8857507843764392976L, var25),
                        d<"R">(8860723908157722078L, var25),
                        d<"R">(8857100024015656643L, var25),
                        d<"R">(8860015382641119325L, var25),
                        d<"R">(8856724193693107377L, var25),
                        d<"R">(8861860677329334114L, var25),
                        d<"R">(8861815299090353054L, var25),
                        d<"R">(8862475981504705695L, var25),
                        d<"R">(8847974912527120882L, var25),
                        d<"R">(8846649220032984205L, var25),
                        d<"R">(8857757680510468991L, var25),
                        d<"R">(8845100652324531155L, var25),
                        d<"R">(8859535110738806825L, var25)
                     );
                     友何树树树树树友树树 = Set.of(
                        d<"R">(8859292818987501143L, var25),
                        d<"R">(8858103162881576578L, var25),
                        d<"R">(8859096130239084364L, var25),
                        d<"R">(8860082710593557731L, var25),
                        d<"R">(8847094722439265873L, var25)
                     );
                     return;
                  }

                  var19 = var20.charAt(var28);
                  break;
               default:
                  var23[var21++] = var41;
                  if ((var28 += var19) < var22) {
                     var19 = var20.charAt(var28);
                     continue label56;
                  }

                  var20 = "¡òXÝñI\u0012\u0092\\;²\u0006²±\u0007î\u0010'_\u0003»+\u0005fÁÉcH½Oµg5";
                  var22 = 33;
                  var19 = 16;
                  var28 = -1;
            }

            var30 = var20.substring(++var28, var28 + var19);
            var10001 = 0;
         }
      }
   }

   private Set<BlockPos> B(BlockPos playerPos) {
      long a = 树友友友何何友树树树.a ^ 25430928960089L;
      Set<BlockPos> reachableAir = new HashSet<>();
      LinkedList queue = new LinkedList();
      d<"ò">(2655746606092432117L, a);
      int maxBlocksToScan = d<"b">(this, 2658063983592090848L, a).getValue().intValue();
      if (this.C(playerPos) && reachableAir.add(playerPos)) {
         queue.add(playerPos);
      }

      BlockPos headPos = playerPos.above();
      if (this.C(headPos) && reachableAir.add(headPos)) {
         queue.add(headPos);
      }

      if (queue.isEmpty()) {
         Direction[] current = d<"R">(2660256050985748389L, a);
         int var11 = current.length;
         int var12 = 0;
         if (0 < var11) {
            Direction dir = current[0];
            BlockPos neighbor = playerPos.relative(dir);
            if (this.C(neighbor) && reachableAir.add(neighbor)) {
               queue.add(neighbor);
            }

            var12++;
         }
      }

      if (!queue.isEmpty() && reachableAir.size() < maxBlocksToScan) {
         BlockPos current = (BlockPos)queue.poll();
         Direction[] var17 = d<"R">(2660256050985748389L, a);
         int var19 = var17.length;
         int var20 = 0;
         if (0 < var19) {
            Direction dir = var17[0];
            BlockPos neighbor = current.relative(dir);
            if (this.C(neighbor) && reachableAir.add(neighbor)) {
               queue.add(neighbor);
            }

            var20++;
         }
      }

      return reachableAir;
   }

   private boolean C(BlockPos pos) {
      long a = 树友友友何何友树树树.a ^ 80037593030086L;
      d<"ò">(-7835062008458836630L, a);
      if (mc.level == null) {
         return false;
      } else {
         Block block = mc.level.getBlockState(pos).getBlock();
         return block.defaultBlockState().isAir()
            || block == d<"R">(-7828549837567369182L, a)
            || block == d<"R">(-7833156200050437996L, a)
            || block == d<"R">(-7828699879949624519L, a)
            || block == d<"R">(-7833728361378341220L, a);
      }
   }

   private double C(int veinSize) {
      long a = 树友友友何何友树树树.a ^ 65445092790873L;
      d<"ò">(-7144055003787293963L, a);
      if (veinSize == 1) {
         return 2.0;
      } else if (veinSize >= 2 && veinSize <= 4) {
         return 2.5;
      } else {
         return veinSize >= 5 && veinSize <= 10 ? 3.5 : 3.0;
      }
   }

   private void D(BlockPos playerPos, Map<BlockPos, Block> foundBlocks) {
      long a = 树友友友何何友树树树.a ^ 89805218085343L;
      d<"ò">(-622237837182017165L, a);
      if (mc.level != null) {
         Set<BlockPos> processedBlocks = new HashSet<>();
         Set<BlockPos> reachableAir = this.B(playerPos);
         Iterator var8 = reachableAir.iterator();
         if (var8.hasNext()) {
            BlockPos airPos = (BlockPos)var8.next();
            Direction[] var10 = d<"R">(-617725128080026589L, a);
            int var11 = var10.length;
            int var12 = 0;
            if (0 < var11) {
               Direction dir = var10[0];
               BlockPos surfacePos = airPos.relative(dir);
               if (!this.C(surfacePos)) {
                  Block block = mc.level.getBlockState(surfacePos).getBlock();
                  if (this.J(block)) {
                     this.H(surfacePos, block, foundBlocks, processedBlocks);
                  }
               }

               var12++;
            }
         }
      }
   }

   public void F() {
      long a = 树友友友何何友树树树.a ^ 127568628800352L;
      long ax = a ^ 48869803994330L;
      d<"ò">(6188641137283548108L, a);
      this.m();
      if (d<"R">(6188235883170814700L, a) != null && !d<"R">(6188235883170814700L, a).isShutdown()) {
         d<"R">(6188235883170814700L, a).shutdownNow();
      }

      if (!this.w(new Object[]{ax})) {
         d<"b">(mc, 6184831827165746747L, a).allChanged();
      }
   }

   private Set<Block> F(Block oreBlock) {
      long a = 树友友友何何友树树树.a ^ 121618645357606L;
      d<"ò">(1919767961842584714L, a);
      String id = oreBlock.builtInRegistryHolder().key().location().getPath();
      if (id.startsWith(b<"c">(30102, 3305844543582562907L ^ a)) || id.equals(b<"c">(11122, 5125664823121261743L ^ a))) {
         return d<"R">(1921613822379808233L, a);
      } else {
         return id.contains(b<"c">(23210, 7834543045547115900L ^ a)) ? d<"R">(1925658334903913895L, a) : Collections.emptySet();
      }
   }

   @EventTarget
   public void I(Render3DEvent event) {
      long a = 树友友友何何友树树树.a ^ 20556968672264L;
      long ax = a ^ 82213380279218L;
      d<"ò">(3641757217549100196L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         if (d<"b">(mc, 3644950616568457947L, a).getMainCamera().isInitialized()) {
            d<"Q">(this, new Matrix4f(event.poseStack().last().pose()), 3639659380415184207L, a);
            d<"Q">(this, new Matrix4f(RenderSystem.getProjectionMatrix()), 3652825721709496382L, a);
         }

         Vec3 camPos = d<"b">(mc, 3644950616568457947L, a).getMainCamera().getPosition();
         PoseStack poseStack = event.poseStack();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         RenderSystem.setShader(GameRenderer::getPositionColorShader);
         if (!d<"b">(this, 3653143853107454827L, a).isEmpty()) {
            double renderRangeSq = Math.pow(d<"b">(this, 3642496734922853180L, a).getValue().doubleValue(), 2.0);

            for (Entry<BlockPos, Block> entry : d<"b">(this, 3653143853107454827L, a).entrySet()) {
               if (!(entry.getKey().distSqr(mc.player.blockPosition()) > renderRangeSq)) {
                  this.Q(poseStack, entry.getKey(), entry.getValue().defaultBlockState(), camPos);
                  break;
               }
            }
         }

         if (d<"b">(this, 3655472217312950368L, a).getValue() && !d<"b">(this, 3652511271762398575L, a).isEmpty()) {
            double packetRangeSq = Math.pow(d<"b">(this, 3652967066446079575L, a).getValue().doubleValue(), 2.0);
            d<"b">(this, 3652511271762398575L, a).forEach((pos, state) -> {
               long var10000 = 树友友友何何友树树树.a ^ 57812913896234L;
               if (this.q(state)) {
                  BlockPos blockPos = pos.P();
                  if (blockPos.distSqr(mc.player.blockPosition()) <= packetRangeSq) {
                     this.Q(poseStack, blockPos, state, camPos);
                  }
               }
            });
         }

         RenderSystem.enableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.disableBlend();
      }
   }

   private boolean J(Block block) {
      long a = 树友友友何何友树树树.a ^ 14224781462711L;
      d<"ò">(4770720175976731675L, a);
      if (block == null) {
         return false;
      } else {
         String currentBlockType = d<"b">(this, 4769667837575235764L, a).getValue();
         if (currentBlockType.equalsIgnoreCase(b<"c">(361, 5965425119085741586L ^ a))) {
            return d<"b">(this, 4768780643817738826L, a).getValue() && (block == d<"R">(4759482070520021661L, a) || block == d<"R">(4769838018228200930L, a))
               || d<"b">(this, 4759193941595881148L, a).getValue() && (block == d<"R">(4771832827853048862L, a) || block == d<"R">(4772452926331223525L, a))
               || d<"b">(this, 4755808522913329113L, a).getValue() && (block == d<"R">(4759386207395467915L, a) || block == d<"R">(4767975636212452983L, a))
               || d<"b">(this, 4773344302083768678L, a).getValue() && (block == d<"R">(4769061224980283949L, a) || block == d<"R">(4768354866827302407L, a))
               || d<"b">(this, 4757736282046035606L, a).getValue()
                  && (block == d<"R">(4773416909735481398L, a) || block == d<"R">(4767802689654369798L, a) || block == d<"R">(4769189947254291073L, a))
               || d<"b">(this, 4768982782367281160L, a).getValue() && (block == d<"R">(4770015457289307995L, a) || block == d<"R">(4773080332817547959L, a))
               || d<"b">(this, 4756658138239261893L, a).getValue() && (block == d<"R">(4772132358762032579L, a) || block == d<"R">(4756181608058891157L, a))
               || d<"b">(this, 4768280185309385051L, a).getValue() && (block == d<"R">(4773785647645425762L, a) || block == d<"R">(4756317052338402852L, a))
               || d<"b">(this, 4758470189114379822L, a).getValue() && block == d<"R">(4770677725425859026L, a)
               || d<"b">(this, 4770871855640392226L, a).getValue() && block == d<"R">(4772747721949070546L, a)
               || d<"b">(this, 4768834598643364112L, a).getValue() && block == d<"R">(4759942928067839684L, a)
               || d<"b">(this, 4760173083589103437L, a).getValue() && block == d<"R">(4759795504903803754L, a)
               || d<"b">(this, 4757674224887936880L, a).getValue()
                  && (block == d<"R">(4770567412304780156L, a) || block == d<"R">(4756374215382563645L, a) || block == d<"R">(4772282780029822033L, a));
         } else {
            return !currentBlockType.equalsIgnoreCase(b<"c">(13519, 3226502960413602795L ^ a))
               ? false
               : block == d<"R">(4759795504903803754L, a)
                  || block == d<"R">(4769189947254291073L, a)
                  || block == d<"R">(4759942928067839684L, a)
                  || block == d<"R">(4767351051431196303L, a)
                  || block == d<"R">(4769659628850015984L, a)
                  || block == d<"R">(4767892359003662658L, a);
         }
      }
   }

   private Set<Block> S() {
      long a = 树友友友何何友树树树.a ^ 114364467888965L;
      d<"ò">(5604558578486729705L, a);
      HashSet targets = new HashSet();
      if (d<"b">(this, 5610976597895437993L, a).getValue()) {
         targets.add(d<"R">(5606278043983384464L, a));
         targets.add(d<"R">(5617028619083938262L, a));
      }

      if (d<"b">(this, 5610553293970653178L, a).getValue()) {
         targets.add(d<"R">(5602507783563511977L, a));
         targets.add(d<"R">(5606708489495661893L, a));
      }

      if (d<"b">(this, 5605916892169932436L, a).getValue()) {
         targets.add(d<"R">(5610780378168692191L, a));
         targets.add(d<"R">(5611200983524645365L, a));
      }

      if (d<"b">(this, 5617320366724053348L, a).getValue()) {
         targets.add(d<"R">(5606121236943888324L, a));
         targets.add(d<"R">(5609452849360544244L, a));
         targets.add(d<"R">(5610909066135385459L, a));
      }

      if (d<"b">(this, 5616393027276297015L, a).getValue()) {
         targets.add(d<"R">(5604837440274063921L, a));
         targets.add(d<"R">(5616900322173166695L, a));
      }

      if (d<"b">(this, 5610491549863632312L, a).getValue()) {
         targets.add(d<"R">(5620342069259128175L, a));
         targets.add(d<"R">(5603527470005692944L, a));
      }

      if (d<"b">(this, 5616659759654903851L, a).getValue()) {
         targets.add(d<"R">(5620167319394409849L, a));
         targets.add(d<"R">(5609554909559587205L, a));
      }

      if (d<"b">(this, 5620045111966789966L, a).getValue()) {
         targets.add(d<"R">(5605451294220911596L, a));
         targets.add(d<"R">(5605095095697076759L, a));
      }

      if (d<"b">(this, 5610404459366252258L, a).getValue()) {
         targets.add(d<"R">(5619597554907728182L, a));
      }

      if (d<"b">(this, 5619908350650368191L, a).getValue()) {
         targets.add(d<"R">(5619458963331013784L, a));
      }

      if (d<"b">(this, 5619119597006537180L, a).getValue()) {
         targets.add(d<"R">(5604376728665355808L, a));
      }

      if (d<"b">(this, 5604710222249246160L, a).getValue()) {
         targets.add(d<"R">(5606506720515083040L, a));
      }

      if (d<"b">(this, 5617329505624012930L, a).getValue()) {
         targets.add(d<"R">(5604185638146086030L, a));
         targets.add(d<"R">(5616109451775079631L, a));
         targets.add(d<"R">(5604985970338573219L, a));
      }

      return targets;
   }

   private void Z(
      BlockPos pos,
      BlockState state,
      Vec3 playerEyePos,
      double rangeSq,
      Vec3 camPos,
      BufferBuilder buffer,
      PoseStack guiPoseStack,
      float cX,
      float cY,
      float sW,
      float sH
   ) {
      long a = 树友友友何何友树树树.a ^ 84889617482085L;
      d<"ò">(5757642539181332937L, a);
      Vec3 worldPos = Vec3.atCenterOf(pos);
      if (!(worldPos.subtract(playerEyePos).lengthSqr() > rangeSq)) {
         Vector3f screenPos = this.K(worldPos, camPos);
         if (screenPos != null) {
            float tX = d<"b">(screenPos, 5754962262709832212L, a);
            float tY = d<"b">(screenPos, 5759328430706330633L, a);
            if (d<"b">(screenPos, 5763706111910317881L, a) > 0.0F) {
            }

            Color color = this.l(state.getBlock());
            if (color == null) {
               color = this.f(state.getBlock());
            }

            if (color != null) {
               float r = color.getRed() / 255.0F;
               float g = color.getGreen() / 255.0F;
               float b = color.getBlue() / 255.0F;
               Vector3f clipped = this.l(cX, cY, tX, tY, sW, sH);
               tX = d<"b">(clipped, 5754962262709832212L, a);
               tY = d<"b">(clipped, 5759328430706330633L, a);
               buffer.vertex(guiPoseStack.last().pose(), cX, cY, 0.0F).color(r, g, b, 0.8F).endVertex();
               buffer.vertex(guiPoseStack.last().pose(), tX, tY, 0.0F).color(r, g, b, 0.8F).endVertex();
            }
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 30;
               case 1 -> 40;
               case 2 -> 19;
               case 3 -> 44;
               case 4 -> 34;
               case 5 -> 23;
               case 6 -> 12;
               case 7 -> 24;
               case 8 -> 25;
               case 9 -> 60;
               case 10 -> 62;
               case 11 -> 47;
               case 12 -> 10;
               case 13 -> 5;
               case 14 -> 35;
               case 15 -> 48;
               case 16 -> 36;
               case 17 -> 1;
               case 18 -> 8;
               case 19 -> 51;
               case 20 -> 59;
               case 21 -> 49;
               case 22 -> 0;
               case 23 -> 3;
               case 24 -> 29;
               case 25 -> 63;
               case 26 -> 57;
               case 27 -> 33;
               case 28 -> 38;
               case 29 -> 41;
               case 30 -> 54;
               case 31 -> 15;
               case 32 -> 26;
               case 33 -> 52;
               case 34 -> 56;
               case 35 -> 6;
               case 36 -> 9;
               case 37 -> 28;
               case 38 -> 53;
               case 39 -> 16;
               case 40 -> 31;
               case 41 -> 39;
               case 42 -> 58;
               case 43 -> 4;
               case 44 -> 27;
               case 45 -> 20;
               case 46 -> 11;
               case 47 -> 2;
               case 48 -> 45;
               case 49 -> 18;
               case 50 -> 14;
               case 51 -> 17;
               case 52 -> 61;
               case 53 -> 46;
               case 54 -> 50;
               case 55 -> 7;
               case 56 -> 43;
               case 57 -> 21;
               case 58 -> 32;
               case 59 -> 37;
               case 60 -> 22;
               case 61 -> 42;
               case 62 -> 13;
               default -> 55;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 1356;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友友友何何友树树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树友友友何何友树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private boolean x(Block b1, Block b2) {
      long a = 树友友友何何友树树树.a ^ 127207280853689L;
      d<"ò">(5493124802571131413L, a);
      if (b1 == b2) {
         return true;
      } else if (b1 != null && b2 != null) {
         Set<Block> g1 = this.a(b1);
         Set<Block> g2 = this.a(b2);
         return !g1.isEmpty() && g1.equals(g2);
      } else {
         return false;
      }
   }

   private List<BlockPos> x(BlockPos startPos, Block oreType, Set<BlockPos> processedBlocks) {
      long a = 树友友友何何友树树树.a ^ 100384449047975L;
      d<"ò">(-6690845901545065205L, a);
      ArrayList vein = new ArrayList();
      Queue<BlockPos> queue = new LinkedList<>();
      Set<BlockPos> veinVisited = new HashSet<>();
      if (processedBlocks.contains(startPos)) {
         return vein;
      } else {
         queue.add(startPos);
         veinVisited.add(startPos);
         if (!queue.isEmpty() && vein.size() < 64) {
            BlockPos currentPos = queue.poll();
            vein.add(currentPos);
            Direction[] var12 = d<"R">(-6695325814411018149L, a);
            int var13 = var12.length;
            int var14 = 0;
            if (0 < var13) {
               Direction dir = var12[0];
               BlockPos neighbor = currentPos.relative(dir);
               if (!processedBlocks.contains(neighbor)
                  && !veinVisited.contains(neighbor)
                  && mc.level.isLoaded(neighbor)
                  && this.x(mc.level.getBlockState(neighbor).getBlock(), oreType)) {
                  veinVisited.add(neighbor);
                  queue.add(neighbor);
               }

               var14++;
            }
         }

         return vein;
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 26333;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友友友何何友树树树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树友友友何何友树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'b' && var8 != 'Q' && var8 != 'R' && var8 != 'S') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 244) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 242) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'b') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Q') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'R') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @EventTarget
   public void n(PacketEvent event) {
      long a = 树友友友何何友树树树.a ^ 108358441141265L;
      long ax = a ^ 64848300340139L;
      d<"ò">(762074651492785341L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundBlockUpdatePacket S23) {
            d<"b">(this, 768957500579584882L, a).remove(S23.getPos());
            if (d<"b">(this, 766641776790028409L, a).getValue()) {
               d<"b">(this, 759195929944652591L, a).add(S23.getPos());
               d<"b">(this, 768184352473757046L, a).put(new 树友友友何何友树树树.友何友树何树何何何何(S23.getPos()), S23.getBlockState());
            }
         }

         if (packet instanceof ClientboundSectionBlocksUpdatePacket S22) {
            S22.runUpdates((pos, state) -> {
               long axx = 树友友友何何友树树树.a ^ 84849163762644L;
               d<"ò">(8455017358927979384L, axx);
               d<"b">(this, 8461926577566672055L, axx).remove(pos);
               if (d<"b">(this, 8459597401339740092L, axx).getValue()) {
                  d<"b">(this, 8452160336091579626L, axx).add(pos);
                  d<"b">(this, 8461151266474642099L, axx).put(new 树友友友何何友树树树.友何友树何树何何何何(pos), state);
               }
            });
         }
      }
   }

   private boolean h(BlockPos pos) {
      long a = 树友友友何何友树树树.a ^ 73220658231981L;
      d<"ò">(8371996882057617921L, a);
      return mc.level.getBlockState(pos.above()).is(d<"R">(8367294232926821136L, a))
         || mc.level.getBlockState(pos.above()).is(d<"R">(8372311782861375305L, a))
         || mc.level.getBlockState(pos.below()).is(d<"R">(8367294232926821136L, a))
         || mc.level.getBlockState(pos.below()).is(d<"R">(8372311782861375305L, a))
         || mc.level.getBlockState(pos.south()).is(d<"R">(8367294232926821136L, a))
         || mc.level.getBlockState(pos.south()).is(d<"R">(8372311782861375305L, a))
         || mc.level.getBlockState(pos.north()).is(d<"R">(8367294232926821136L, a))
         || mc.level.getBlockState(pos.north()).is(d<"R">(8372311782861375305L, a))
         || mc.level.getBlockState(pos.east()).is(d<"R">(8367294232926821136L, a))
         || mc.level.getBlockState(pos.east()).is(d<"R">(8372311782861375305L, a))
         || mc.level.getBlockState(pos.west()).is(d<"R">(8367294232926821136L, a))
         || mc.level.getBlockState(pos.west()).is(d<"R">(8372311782861375305L, a));
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private Color f(Block block) {
      long a = 树友友友何何友树树树.a ^ 119976361651084L;
      d<"ò">(7281864611928797984L, a);
      return null;
   }

   private void f(PoseStack poseStack, AABB box, Color color) {
      long a = 树友友友何何友树树树.a ^ 1086489017903L;
      float r = color.getRed() / 255.0F;
      float g = color.getGreen() / 255.0F;
      float b = color.getBlue() / 255.0F;
      float minX = (float)d<"b">(box, 3507673675118483597L, a);
      float minY = (float)d<"b">(box, 3503523111019899224L, a);
      float minZ = (float)d<"b">(box, 3503855771011386035L, a);
      float maxX = (float)d<"b">(box, 3502511859901301097L, a);
      float maxY = (float)d<"b">(box, 3503322752117022462L, a);
      float maxZ = (float)d<"b">(box, 3504096512428547323L, a);
      Matrix4f matrix = poseStack.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(d<"R">(3504213992896604345L, a), d<"R">(3504336099863226264L, a));
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      BufferUploader.drawWithShader(buffer.end());
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private Vector3f l(float cX, float cY, float tX, float tY, float sW, float sH) {
      long a = 树友友友何何友树树树.a ^ 44483806139666L;
      float dX = tX - cX;
      d<"ò">(1986127170654473662L, a);
      float dY = tY - cY;
      if (Math.abs(dX) < 1.0E-6 && Math.abs(dY) < 1.0E-6) {
         return new Vector3f(cX, cY, 0.0F);
      } else {
         float scale = Float.MAX_VALUE;
         if (dX > 0.0F) {
            scale = Math.min(Float.MAX_VALUE, (sW - cX) / dX);
         }

         if (dX < 0.0F) {
            scale = Math.min(scale, -cX / dX);
         }

         if (dY > 0.0F) {
            scale = Math.min(scale, (sH - cY) / dY);
         }

         if (dY < 0.0F) {
            scale = Math.min(scale, -cY / dY);
         }

         return new Vector3f(cX + scale * dX, cY + scale * dY, 0.0F);
      }
   }

   private double l(BlockPos pos, Block oreType) {
      long a = 树友友友何何友树树树.a ^ 12400666523218L;
      long ax = a ^ 91468858507752L;
      d<"ò">(4093779834998140670L, a);
      if (this.w(new Object[]{ax})) {
         return 0.0;
      } else {
         int chunkX = pos.getX() >> 4;
         int chunkZ = pos.getZ() >> 4;
         Set<Block> oreGroup = this.a(oreType);
         if (oreGroup.isEmpty()) {
            return 0.0;
         } else {
            Block representative = oreGroup.stream().min(Comparator.comparing(b -> b.builtInRegistryHolder().key().location().toString())).orElse(oreType);
            String cacheKey = chunkX + ":" + chunkZ + ":" + representative.builtInRegistryHolder().key().location();
            树友友友何何友树树树.友树树何树友何何友树 cachedLevel = (树友友友何何友树树树.友树树何树友何何友树)d<"b">(this, 4094403183392029734L, a).get(cacheKey);
            if (cachedLevel == d<"R">(4096440603125007185L, a)) {
               return -5.0;
            } else if (cachedLevel == d<"R">(4098944695306041639L, a)) {
               return 1.0;
            } else {
               BlockPos playerPos = mc.player.blockPosition();
               int playerChunkX = playerPos.getX() >> 4;
               int playerChunkZ = playerPos.getZ() >> 4;
               int distManhattan = Math.abs(playerChunkX - chunkX) + Math.abs(playerChunkZ - chunkZ);
               if (distManhattan <= 3) {
                  d<"b">(this, 4094403183392029734L, a).put(cacheKey, d<"R">(4098944695306041639L, a));
                  return 1.0;
               } else {
                  d<"b">(this, 4094403183392029734L, a).put(cacheKey, d<"R">(4094793692554725787L, a));
                  if (!oreGroup.contains(d<"R">(4100549525150021752L, a)) && oreGroup.contains(d<"R">(4097698434514155259L, a))) {
                  }

                  if (!oreGroup.contains(d<"R">(4097029687471581907L, a)) && oreGroup.contains(d<"R">(4097997140992792358L, a))) {
                  }

                  int totalOreCount = 0;
                  int startX = chunkX << 4;
                  int startZ = chunkZ << 4;
                  int x = 0;
                  int z = 0;
                  int y = mc.level.getMinBuildHeight();
                  if (y < mc.level.getMaxBuildHeight()) {
                     if (this.x(mc.level.getBlockState(new BlockPos(startX + 0, y, startZ + 0)).getBlock(), oreType)) {
                        totalOreCount++;
                     }

                     y++;
                  }

                  z++;
                  x++;
                  if (totalOreCount > 200) {
                     d<"b">(this, 4094403183392029734L, a).put(cacheKey, d<"R">(4096440603125007185L, a));
                     return -5.0;
                  } else {
                     d<"b">(this, 4094403183392029734L, a).put(cacheKey, d<"R">(4098944695306041639L, a));
                     return 0.0;
                  }
               }
            }
         }
      }
   }

   private Color l(Block block) {
      long a = 树友友友何何友树树树.a ^ 131045160283399L;
      d<"ò">(-2052098291804375637L, a);
      return null;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树友友友何何友树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static void a() {
      n[0] = ",Qd\u0016z\u001f.O-nu\u00137Lq\u000bv";
      n[1] = float.class;
      o[1] = "java/lang/Float";
      n[2] = "+\u00012QB5$A\u007fZH(!\u001ct\u001c@5,\u001apW\u00033%\u001fp\u001c_?&\u000by@\u0003\u0018-\u001bhW_\u0019)\u0002y@L";
      n[3] = "\u00100O[,\u0007\u001b?^\u0014Q\u001f\b8W]";
      n[4] = "@hh\u0018\\IO(%\u0013VTJu.U^IGs*\u001e\u001dONv*UACMb#\t\u001d样叨反厍伮佦叭栲栗桗";
      n[5] = ".8\u000fmwE%7\u001e\"\u001cQ'<\tx0F*";
      n[6] = "\u0013YI:4]\u0013Y^f8R\t\u0012J{+X\u0019\u0012Qq/Q\u0011\u0012_x6W\u0016\u0012\u007fx6W\u0016O";
      n[7] = "\u00175I\u0000Ih\u00175^\\Eg\r~JAVm\u001d~QKRd\u0015~_BKb\u0012~\u007fBKb\u0012";
      n[8] = "[#\u0016\u007fklTc[taqQ>P2rbT8]2mnH!\u0016^klT(YrRbT8]";
      n[9] = long.class;
      o[9] = "java/lang/Long";
      n[10] = boolean.class;
      o[10] = "java/lang/Boolean";
      n[11] = "Z!<YgFD)&\u0016\u0004R@";
      n[12] = "\u0003z<Tz,\f:q_p1\tgz\u0019c\"\faw\u0019|.\u0010x<y`.\u0002q`at/\u0015q";
      n[13] = "\b3\u0000#_h\b3\u0017\u007fSg\u0012x\u0003b@m\u0002x\u0018hDd\nx8hDd\n";
      n[14] = "$HoIF\u0001&V&*M\u001a9SpSJ";
      n[15] = "'[/\u00074\u0003'[8[8\f=\u0010,F+\u0006-\u0010+A \u0019gh>Jj";
      n[16] = double.class;
      o[16] = "java/lang/Double";
      n[17] = "\u001a=\u000e,/G\u0015}C'%Z\u0010 Ha-G\u001d&L*nA\u0014#La2M\u00177E=n根厲厘叫会伕口桨桂栱k桑根厲厘叫厄桑口伬伆";
      n[18] = "f_S\u001d\u000e^PzS\u001d\u0019\u0002\\uIV\u0019\u001fOv\u0013<\u0013\u0002XpI\u0011\u0015\u001e\u0006";
      n[19] = "@\u00014|$uOAyw.hJ\u001cr1&uG\u001avzeWL\u000bos.";
      n[20] = "e\u000b=l~>jKpgt#o\u0016{!|>b\u0010\u007fj?伄体厮但佚叚伄体桴栂";
      n[21] = void.class;
      o[21] = "java/lang/Void";
      n[22] = "F\u0019N('(X\u0011Tgj2B\u001bM;{8B\f\u0016\u001da/I\u0019\\\u0019f2@=@,j(X\u0017J";
      n[23] = "\r\u0011\"\u001b'\u001c\r\u00115G+\u0013\u0017Z5Y#\u0010\r\u0000xx#\u001b\u0006\u0017$T,\u0001";
      n[24] = "!\u001d<J\u0007+!\u001d+\u0016\u000b$;V+\b\u0003'!\ff\u0016\u000f,+\u001d:\u0001\u0018l\u0003\u001d>\u0001\u0006\u0010*\u0016,\u0001\u0018'=";
      n[25] = "[g\b\u000f;cEo\u0012@Y\u007fBr";
      n[26] = "\bc&\u0011\u007f\u0007\u0007#k\u001au\u001a\u0002~`\\f\t\u0007xm\\y\u0005\u001ba&档叛伽厠佘佝厹栁桹厠";
      n[27] = "HMX@*sG\r\u0015K nBP\u001e\r3}GV\u0013\r,q[OXn*xNu\u0017O0y";
      n[28] = "^`D?YV^`ScUYD+S}]Z^q\u001ecQQT`BtF\u0011wd]tfZ^aUcQM";
      n[29] = "N@O\u0000RsGNLI\u0011~ANXK\fx\u0003YG\\KyU\u0001tKMhHWdAMqL[\u0006cPxH";
      n[30] = "FGK~RFOIH7\u0011KII\\5\fM\u000b^C\"KL]\u0006b5YHPDR\u0006Z[QM^\u0016P[HIR";
      n[31] = "\u00149>\b\u0014\u000e\u001d7=AW\u0003\u001b7)CJ\u0005Y 6T\r\u0004\u000fx\u0005C\u000b\u0015\u0012.\u0015I\u000b\f\u0016\"";
      n[32] = ";\u000e\u0012\be\u00174N_\u0003o\n1\u0013TEg\u0017<\u0015P\u000e$\u00115\u0010PEx\u001d6\u0004Y\u0019$桩厓厫号伾佟厳桉桱栭O叁桩桉伵栭厠佟伭厓桱";
      n[33] = "FP9\u0014jYFP.HfV\\\u001b:Uu\\L\u001b=R~C\u0006t\fxE";
      n[34] = "7\r\u0000T\u001c3)\u0005\u001a\u001ba#)";
      n[35] = "tPnK<K\u007f_\u007f\u0004]EtT{^";
      n[36] = "\b#jq\u000e}Xs|d\u007f桞佮栁栞栐桦桞株佅佚\tB7\u000b}mtN:Mg";
      n[37] = "rQ\u0002j!j5\u0007\b(N}\u0019QKir+\u0019lN;$.>\u0013\u001a')i";
      n[38] = "<c\b@aTl3\u001eU\u0010厭佚伅伸校位伳佚桁桼8q^ib\u0006Hq\u0001\u007f`";
      n[39] = "xxD\u001d\u001a\u0006?.N_u\u0011\u0013|\b\u0018IAt\u00125\u001f\u001b\u0015y5JK\u0007\u0018>";
      n[40] = "[\u001cz\u001a3!\u000bLl\u000fB栂桹佺栎厡厁栂伽栾佊b\"cXDhY=\u007f\u001aA";
      n[41] = "<7-S\u0004\u001a{a'\u0011k\rW6m]Z]W\na\u0002\u0001^pu5\u001e\f\u0019";
      n[42] = "/]`O^uh\u000bj\r1bDY,J\r=,7\u0011M_f.\u0010n\u0019Cki";
      n[43] = "\u0013r3l6uT$9.Ybxssbh<xO\u007f=31_0+!>v";
      n[44] = "ol\"M\u0018\u0002?<4Xi佥厗桎桖佨桰佥厗桎厌5THl2%HXE*(";
      n[45] = "#l;\u0017\u0018\u0002s<-\u0002i佥叛伊桏桶伴佥叛伊桏oTH 2<\u0012XEf(";
      n[46] = "u&_\u0007\u0019\u001b%vI\u0012h核厍佀佯厼厫叢伓叞叱\u007fUQvxX\u0002Y\\0b";
      n[47] = "ZbA\u00049\u0017Ta\b9-,\rlI\u0006n\u0011]8\b\b";
      n[48] = "brz\tI0%$pK&'\tv6\f\u001btf\u0018\u000b\u000bH#c?t_T.$";
      n[49] = "\u0016w[$$uQ!QfKb}w\u0012#{4}J\u0017u!1Z5Ci,v";
      n[50] = "x\\'\u0010B.(\f1\u00053受厀桾桓厫台栍厀桾众h\u000ed{\u0002 \u0015\u0002i=\u0018";
      n[51] = "s\u0014\u0012L\u0018-#D\u0004Yi栎桑佲桦号伴佊压佲厼4\b'&\u0015\u001cD\bx0\u0017";
      n[52] = "f\u0010;t \u0002!F16O\u0015\r\u0010rsqA\r-w%%F*R#9(\u0001";
      n[53] = "<`xO_9l0nZ.叀佚伆栌叴佳佞栞厘取7I?6gmK\u0015o67";
      n[54] = "&(<|/\ba~6>@\u001fM(uzzKM\u0015p-*Ljj$1'\u000b";
      n[55] = "\u000f/K=h8_\u007f](\u0019佟栭栍佻历栀佟佩佉句Ex2Z.E5xmL,";
      n[56] = "\u0013{\f]\u0012^T-\u0006\u001f}Ix\u007f@XA\u0018\u0014\u0011}_\u0013M\u00126\u0002\u000b\u000f@U";
      n[57] = "Hq:\u001dJV\u000f'0_%A#qs\u001b\u001e\u0010#LvLO\u0012\u00043\"PBU";
      n[58] = "heQ6OO85G#>厶厐伃佡桗佣厶伎厝佡N\u0001E2n\u0007q\u0002H:,";
      n[59] = "bn\f\u000e\u00023%8\u0006Lm$\tnE\u000fWu\tS@_\u0007w.,\u0014C\n0";
      n[60] = ">\u000e5\u00046m>\tsN\u0006y\u0006S3\u00078,\u0006bh@\u007f{2]wQaj";
      n[61] = "\u0004+\u0000n\u0001\u0007C}\n,n\u0010o*@`_Fo\u0016L?\u0004CHi\u0018#\t\u0004";
      n[62] = "\bg']7\u0010O1-\u001fX\u0007cckXdX\r\rV_6\u0003\t*)\u000b*\u000eN";
      n[63] = "KF.@A\u0000\f\u0010$\u0002.\u0017 BbE\u0012GH,_B@\u0013J\u000b \u0016\\\u001e\r";
      n[64] = "\rqTAIH]!BT8伯栯桓叺叺叻桫叵桓叺9\u0005\u0002\u000e/SD\t\u000fH5";
      n[65] = "+Yv\u0015\u0011`/[y\u0017~^\u0011YvI\f{t\b%LO\u0000";
      n[66] = "\u001bY(k\rtD\u001a&34z*Qb6\u0004$*a20\u000fxB\u0010!4K(";
      n[67] = "DW0]3C\u0014\u0007&HB伤伢伱桄格伟伤厼伱伀%\u007f\tG\t7Xs\u0004\u0001\u0013";
      n[68] = "\u0001O?.a\\F\u00195l\u000eKjOv+3\u0015jrs\u007fd\u0018M\r'ci_";
      n[69] = "y$b\u0003R~)tt\u0016#桝厁佂佒桢叠桝伟佂双{Bt,%l\u000bB+:'";
      n[70] = "Hv~>?)\u000f t|P>#v79`m#K2o:m\u00044fs7*";
      n[71] = "2pDhjou&N*\u0005xYp\rh>.YM\b9o+~2\\%bl";
      n[72] = "#9T[\u001f*siBNn栉栁栛叺叠伳栉叛佟佤#_r$yRQ\u0010svh";
      n[73] = "z H=\u001cp*p^(m厉伜变格桜估众厂变佸E]u; T(\u00148x*";
      n[74] = "vE\u0017|#s1\u0013\u001d>Ld\u001dE^zw6\u001dx[-&7:\u0007\u000f1+p";
      n[75] = "f\u0019|BbN6IjW\u0013厷厞叡佌栣叐伩厞栻栈:#\f%Hx\u0006x\f:L";
      n[76] = "9sOZ\u000fDi#YO~伣佟伕叡使厽桧叁伕栻\"\u0010\u0018y9SCBFp/";
      n[77] = "b+\u0002\u0000Hb%}\bB'u\t+K\u0004\u0016'\t\u0016NQM&.i\u001aM@a";
      n[78] = "s,\r\u000etD#|\u001b\u001b\u0005桧压栎桹桯栜桧伕佊伽vdN&-\u0003\u0006d\u00110/";
      n[79] = "lyxC(.2y\u007f\\S企佔佝桚栤厐桅及參伞=6%2~8Oh%5a";
      n[80] = ":/5b\u000b\\j\u007f#wz伻作受厛栃伧伻栘受厛\u001a\u0018\u000fz\u007f>zC\u001aj*";
      n[81] = "h\u0017F\u0010?%/ALRP2\u0003\u0013\n\u0015lml}7\u0012>6iZHF\";.";
      n[82] = "Y\u0011|!OQ\u001eGvc F2\u00150$\u001c\u0017Y{\r#NBX\\rwRO\u001f";
      n[83] = "\u001aA<n26\u0010T,qV収桩右伞低厕収桩佭伞\u0013<1K\\|b/5\u000f\f";
      n[84] = "6xS\nJdq.YH%s]x\u001a\t\u0014&]E\u001f[O z:KGBg";
      n[85] = "\u000e\u0018\u0019+3\nIN\u0013i\\\u001de\u0018P-gNe%Uz6NBZ\u0001f;\t";
      n[86] = "{]\u0010\u007f[fqH\u0000`?厞栈栵厬栛叼厞栈佱伲\u0002Ua*@PsFen\u0010";
      n[87] = "*I.?[Lz\u00198**桯佌桫桚厄叩伫佌厱伞G\u001a\u000ei\u0018*{A\u000ev\u001c";
      n[88] = "v%&\u0000i\u001e&u0\u0015\u0018佹桔佃伖伥佅佹厎佃厈x(\u001b7%:\u0015aVt/";
      n[89] = "|\u0019@+c}.GU\"_(BG\u001epo\u007fBwNpd**\u0006]t z";
      n[90] = "\n\u0007\u000eC' \u0000\u0012\u001e\\C但桹厵伬叽厀变桹桯桨>)'[\u001aNO:#\u001fJ";
      n[91] = "y\u001bT\u00058F)KB\u0010I伡桛根叺桤桐桥桛根佤}y\u0004:JPA\"\u0004%N";
      n[92] = "MJ~.\u0005'\n\u001ctlj0&N2+WfL \u000f,\u00044L\u0007px\u00189\u000b";
      n[93] = "GT?*u)MA/5\u0011发佰佸伝伊佌发佰佸桙W{.\u0016I\u007f&h*R\u0019";
      n[94] = "?7/I3Uxa%\u000b\\BT3cL`\u001d=]^K2F>z!\u001f.Ky";
      n[95] = "\u001c\u000f8JVSL_._'桰栾佩伈佯栾厪栾佩桌2FYI\u000e6BF\u0006_\f";
      n[96] = "\u0010}cs\u0012wW+i1}`{y/v@6\u0012\u0017\u0012q\u0013d\u00110m%\u000fiV";
      n[97] = "}{\u0012\fN6-+\u0004\u0019?佑桟伝桦厷佢栕桟伝桦t\u0000<'pDK\u00031/2";
      n[98] = "O\nk@\u0018#\u001fZ}Ui叚桭佬佛佥伴佄厷佬佛8TiLTlEXd\nN";
      n[99] = "\u000e/[\u0005wv^\u007fM\u0010\u0006桕叶栍栯桤佛休佨佉佫}7=VlOE77Tn";
      n[100] = "HB\u0006Q<\u0013\u0016B\u0001NG厢栴佦叾召桞似佰栢栤/\"\u0018\u0016EF]|\u0018\u0011Z";
      n[101] = "9t\tr=5~\"\u00030R\"Rt@sovRIE#8qu6\u0011?56";
      n[102] = "%hc)\u001c[u8u<m厢佃伎反案桴似叝伎体QS\nu\"s!\u0015^&c";
      n[103] = "|?[qQ\u0001;iQ3>\u0016\u0017?\u0012u\u0005D\u0017\u0002\u0017 TE0}C<Y\u0002";
      n[104] = "k\u0019J,1ee\u001a\u0003\u0011&^<\u0017B.fclC\u0003 ";
      n[105] = "]jR\u000e\u0012\u0013\r:D\u001bc佴桿厒叼厵桺只厥厒佢v\u0003Q^2@M\u001cM\u001c7";
      n[106] = "\u0004 . \u0013FCv$b|Qo!n.M\u0000o\u001dbq\u0016\u0002Hb6m\u001bE";
      n[107] = "\u0010cdZm\u0016B=qSQC.=:\u0001a\u0015.\rj\u0001jAF|y\u0005.\u0011";
      n[108] = "Fk(E17\u0016;>P@栔桤桉历叾桙佐传厓历=}}E5/@qp\u0003/";
      n[109] = "\u0018&\u001b#\"\u0010_p\u0011aM\u0007s&R%|Ts\u001bWr'TTd\u0003n*\u0013";
      n[110] = "bi{_G\u0006%?q\u001d(\u0011\ti2]\u0019N\tT7\u000eBB.+c\u0012O\u0005";
      n[111] = "{]f4\u0018\u001f<\u000blvw\b\u0010\\&:F[\u0010`*e\u001d[7\u001f~y\u0010\u001c";
      n[112] = "D*@\u0012h)\u001d7AY\f\u001cj\u0004r/[\u0014f\bb;\f3C!]\u0004uj^ \u0016";
      n[113] = "(\u001d\u0012M\u0013xw^\u001c\u0015*v\u0019\u0015X\u0010\u001b#\u0019%\b\u0016\u0011tqT\u001b\u0012U$";
      n[114] = "[-^\u007f@uA4Gt-zom\u0002.\u0014)o][~Jk\u0007&Z%Bi";
      n[115] = "Kk/w3\u0016\u001b;9bB可桩桉厁栖桛可桩厓厁\u000f\u007f\\H5(rsQ\u000e/";
      n[116] = "\tjsE\fiN<y\u0007c~bj:DY.bW?\u0014\t-E(k\b\u0004j";
      n[117] = "\u007f\u0012l\u001cBe QbD{kN\u001a&AJ=N*vG@i&[eC\u00049";
      n[118] = "sM7\nqD4\u001b=H\u001eS\u0018M~\u000f \u0001\u0018p{[t\u0000?\u000f/GyG";
      n[119] = "sA/\u0007i\u00004\u0017%E\u0006\u0017\u0018@o\t7E\u0018|cVlD?\u00037Ja\u0003";
      n[120] = "C ZNFx\u0013pL[7伟伥栂栮栯叴厁伥但栮6Vr\u0016!TFV-\u0000#";
      n[121] = "%\u0011| #tbGvbLcN\u00150%p2({\r\"\"g$\\rv>jc";
      n[122] = "2Psf>F8EcyZ传桁佼叏但伇厾厛叢佑\u001b0AcM3j#E'\u001d";
      n[123] = "7`F\u007f\u0007\u000fg0Pjv叶佑桂栲栞桯栬叏桂栲\u0007\u0011\t=gS{MY=7";
      n[124] = "iFAyeJ.\u0010K;\n]\u0002G\u0001w;\n\u0002{\r(`\u000e%\u0004Y4mI";
      n[125] = "X\u001a(N7&\u001fL\"\fX13\u001aaIen3'd\u001f2b\u0014X0\u0003?%";
      n[126] = "{\u007f=\u0017F\b+/+\u00027[@\u007f+\u000e\n@'? \u0013\u00072{?1REU;4,_7";
      n[127] = "\u000e#\u00118E;Iu\u001bz*,e#X;\u0016|e\u001e]i@\u007fBa\tuM8";
      n[128] = "D\u0006P<cd\u0003PZ~\fs/\u0007\u00102=&/;\u001cmf \bDHqkg";
      n[129] = "'\u001e\u000f{[xwN\u0019n*桛栅佸伿叀栳伟佁另桻\u0003A#%^Y;I \"\u001f";
      n[130] = "M\bYGjJ\u001dXOR\u001b厳伫台栭栦但桩厵台号?&\u0000NV^B*\r\bL";
      n[131] = "M\u0006^YI/\nPT\u001b&8&\u0006\u0017\\\u001cf&;\u0012\bLk\u0001DF\u0014A,";
      n[132] = "\u0006Q\u001bq\fzV\u0001\rd}桙叾厩厵佔传厃叾伷桯\tM8E\u0000\u001f5\u00168Z\u0004";
      n[133] = "\rXX+\u00110]\bN>`佗叵桺栬桊桹佗栯厠佨S]z\u000e\u0006_.QwH\u001c";
      n[134] = "\u001e%\u0010z=ZYs\u001a8RMu%Y}k\u001du\u0018\\+8\u001eRg\b75Y";
      n[135] = "\f!^X$a\u0011s\u001e\u0002MN`t^\\}6_wST?\r";
      n[136] = "g\u001cm\u0002\u001859\u001cj\u001dc桞佟伸厕桥桺会佟桼桏|\u0006>9\u001b-\u000eX>>\u0004";
      n[137] = "m\u0011\t#;T2R\u0007{\u0002Z\\\u0019C~2\u0005\\)\u0013x9X4X\u0000|}\b";
      n[138] = "18\u0006.\r\th%\u0007ei)\u000f\u0015%\u0007i\u001363\u001b8\u0010J+2P";
      n[139] = "{e_\fBU<3UN-B\u0010e\u0016\u000b\u0013\u001d\u0010X\u0013]G\u00117'GAJV";
      n[140] = "<>\u0019L\bHc}\u0017\u00141F\r6S\u0011\u0000\u0012\r\u0006\u0003\u0017\nDew\u0010\u0013N\u0014";
      n[141] = "Su\n\u001a`@\u0003%\u001c\u000f\u0011厹厫桗伺厡佌档厫厍伺bpJ\u0006t\u0004\u0012p\u0015\u0010v";
      n[142] = "L'1=;>\u001cw'(J栝厴栅企优厉栝桮佁企EwtOy68{y\tc";
      n[143] = "\u0012\u001e\u000eJ\u001a|BN\u0018_k厅只另厠叱厨伛栰佸伾2V6\u0011@\tOZ;WZ";
      n[144] = "z;%\u0005]f=m/G2q\u0011?i\u0000\u000e |QT\u0007\\u{v+S@x<";
      n[145] = "d\"-WF\u00104r;B7叩伂叚伝栶栮栳伂佄厃/V\u001a1##_VE'!";
      n[146] = "M\u000f*\u0017\u0003\f\nY Ul\u001b&\u000bf\u0012PK@e[\u0015\u0002\u001fLB$A\u001e\u0012\u000b";
      n[147] = "Kr3\u0010)\tAg#\u000fM栫佼栚厏桴伐叱核佞休m'\u000e\u001aos\u001c4\n^?";
      n[148] = "Q<AZm\u0004\u0001lWO\u001c叽伷佚佱使佁叽桳栞佱\"\"U\u0001vQRd\u0001R7";
      n[149] = "N\u0000\u001fR5_\u001eP\tGD伸桬栢伯栳厇伸伨司厱*y\u0015M^\u0018Wu\u0018\u000bD";
      n[150] = "J\"?Ie\"\rt5\u000b\n5!#\u007fG;a!\u001fs\u0018`f\u0006`'\u0004m!";
      n[151] = "ct\u000bc\u007f\u00123$\u001dv\u000e栱桁厌桿变栗栱厛伒厥\u001bo\u00186u\u0005koG w";
      n[152] = "c&\u0007azT<e\t9CZR.M<r\rR\u001e\u001d:xX:o\u000e><\b";
      n[153] = ">\u0017KTn\bnG]A\u001f叱栜栵句栵佂叱佘可佻,\"B=ILQ.O{S";
      n[154] = ":)\u001e0\u0011\u0002jy\b%`叻参住厰压桹校参发桪H^Sjc\u000e8\u0018\u00079\"";
      n[155] = "\u007f&r\u0015ZV\u007f!4_jBG{t\u0016T\u0014GJ\"H\u0018\u0012!q(\u0015\u001aG";
      n[156] = "0\u0019g+=swOmiRd[\u0019.-i4[$+z87|[\u007ff5p";
      n[157] = "b\u001aOe+\u0003%LE'D\u0014\t\u001a\u0006`yE\t'\u00034.G.XW(#\u0000";
      n[158] = "W\u001a75\u0010u\u0007J! a厌伱核桃伐桸厌伱叢桃M\u0000\u007f\u0002\u001b9=\u0000 \u0014\u0019";
      n[159] = "J\u0010*JOY\u0018N?Cs\ftNt\u0011LSt~$\u0011H\u000e\u001c\u000f7\u0015\f^";
      n[160] = "\u000e'\u0016/r\u0014^w\u0000:\u0003样叶佁厸桎叀样栬栅桢W3VMv\u0012khVRr";
      n[161] = "BDVj/\u000e\u0005\u0012\\(@\u0019)D\u001fmpF)y\u001a;*J\u000e\u0006N''\r";
      n[162] = "\u0013\u0003'*TQCS1?%桲栱佥桓伏佸伶叫叻桓R\u0015\u0013PR#nN\u0013OV";
      n[163] = "\u0011)Z~\u0000uAyLkq桖叩发栮叅厲厌栳住栮\u0006ApP)Fk\b=\u0013#";
      n[164] = "I5i(W;\u0014rekk桟栽佖桍桏桲伛叧又厗V\u0006x\u0019uh+[?\u00156";
      n[165] = "wf5\u000b)B'6#\u001eX桡休桄厛桪伅伥桕伀伅se\bt82\u000ei\u00052\"";
      n[166] = "QX\u001c\u001bo\\L\n\\A\u0006y=\r\u001c\u001f6\u000b\u0002\u000e\u0011\u0017t0PTI\u001dxV\u0001[\\\u0017\u0006";
      n[167] = "\u00037#ehmDa)'\u0007zh7jc8/h\no4m)Ou;(`n";
      n[168] = "Q537\u0003B\u0001e%\"r去伷反厝伒桫去桳体厝OBG\u00105/\"\u000b\nS?";
      n[169] = ";\u000e')4.|X-k[9P\nk,fl8dV+5=:C)\u007f)0}";
      n[170] = "\u001a2\u0004J\u001fz\u00141Mw\tAM<\fHH|\u001dhMF";
      n[171] = "{7S\u0012}`+gE\u0007\f厙厃佑叽厩佑伇桙栕栧j1*xiT\u0017='>s";
      n[172] = "#\t\f3'?sY\u001a&V佘叛栫似伖厕叆叛栫桸Kgt{J\u0018sg~yH";
      n[173] = "\rI\"M}6J\u001f(\u000f\u0012!fIkM(uftn\u001cxrA\u000b:\u0000u5";
      n[174] = "\nl\u001bxt\u0003Z<\rm\u0005佤栨伊桯栙叆佤佬厔桯\u00005AI=\u001f<nAV9";
      n[175] = "F\b\u0015z\u001f!\u0001^\u001f8p6-\b\\~Ka-5Y+\u001ae\nJ\r7\u0017\"";
      n[176] = "$o)4\u0003_t??!r厦佂厗厇休厱伸栆伉伙LO\u0015'1.1C\u0018a+";
   }

   private Set<Block> a(Block block) {
      long a = 树友友友何何友树树树.a ^ 30530359790935L;
      d<"ò">(-8947219165317818885L, a);
      if (block == null) {
         return Collections.emptySet();
      } else if (Set.of(d<"R">(-8940484658531662979L, a), d<"R">(-8948149654324845566L, a)).contains(block)) {
         return Set.of(d<"R">(-8940484658531662979L, a), d<"R">(-8948149654324845566L, a));
      } else if (Set.of(d<"R">(-8948919910633716787L, a), d<"R">(-8949621854097319961L, a)).contains(block)) {
         return Set.of(d<"R">(-8948919910633716787L, a), d<"R">(-8949621854097319961L, a));
      } else if (Set.of(d<"R">(-8944568563794210346L, a), d<"R">(-8950142973823422490L, a), d<"R">(-8948784578412184735L, a)).contains(block)) {
         return Set.of(d<"R">(-8944568563794210346L, a), d<"R">(-8950142973823422490L, a), d<"R">(-8948784578412184735L, a));
      } else if (Set.of(d<"R">(-8946150490141274626L, a), d<"R">(-8945486359121544187L, a)).contains(block)) {
         return Set.of(d<"R">(-8946150490141274626L, a), d<"R">(-8945486359121544187L, a));
      } else if (Set.of(d<"R">(-8940582450095418517L, a), d<"R">(-8949963352887341161L, a)).contains(block)) {
         return Set.of(d<"R">(-8940582450095418517L, a), d<"R">(-8949963352887341161L, a));
      } else if (Set.of(d<"R">(-8945817699005256669L, a), d<"R">(-8943780718114018699L, a)).contains(block)) {
         return Set.of(d<"R">(-8945817699005256669L, a), d<"R">(-8943780718114018699L, a));
      } else if (Set.of(d<"R">(-8944162146144992894L, a), d<"R">(-8943654066177132604L, a)).contains(block)) {
         return Set.of(d<"R">(-8944162146144992894L, a), d<"R">(-8943654066177132604L, a));
      } else if (Set.of(d<"R">(-8947974186663295301L, a), d<"R">(-8944865271077305513L, a)).contains(block)) {
         return Set.of(d<"R">(-8947974186663295301L, a), d<"R">(-8944865271077305513L, a));
      } else if (block == d<"R">(-8940164365093367158L, a)) {
         return Set.of(d<"R">(-8940164365093367158L, a));
      } else {
         return block == d<"R">(-8940030140355311836L, a) ? Set.of(d<"R">(-8940030140355311836L, a)) : Collections.emptySet();
      }
   }

   private void m() {
      long a = 树友友友何何友树树树.a ^ 59608615756222L;
      d<"b">(this, -5835338563518873891L, a).clear();
      d<"Q">(this, null, -5820243941928305425L, a);
      d<"Q">(this, false, -5826839112069441765L, a);
      d<"b">(this, -5834845276496686887L, a).clear();
      d<"b">(this, -5821457326223107826L, a).clear();
      d<"b">(this, -5825863417742795136L, a).clear();
      d<"Q">(this, false, -5821999356076575576L, a);
      d<"Q">(this, null, -5821871837639991047L, a);
      d<"Q">(this, null, -5834601166034889336L, a);
      d<"b">(this, -5819209882934187062L, a).clear();
      d<"Q">(this, d<"b">(this, -5834016261488146856L, a) + 1L, -5834016261488146856L, a);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @EventTarget
   public void k(Render2DEvent event) {
      long a = 树友友友何何友树树树.a ^ 76381655873934L;
      long ax = a ^ 31887933591092L;
      d<"ò">(-5256746257730428638L, a);
      if (!this.w(new Object[]{ax})
         && (Boolean)Fucker.isLogin
         && (Boolean)Fucker.isBeta
         && (!d<"b">(this, -5245350791162059027L, a).isEmpty() || !d<"b">(this, -5244999888816207639L, a).isEmpty())
         && d<"b">(this, -5259973177786102317L, a).getValue()
         && d<"b">(this, -5258800109932037943L, a) != null
         && d<"b">(this, -5244681020325753416L, a) != null) {
         this.W(event.poseStack());
      }
   }

   public void t() {
      long a = 树友友友何何友树树树.a ^ 55368971458695L;
      long ax = a ^ 116737586720573L;
      d<"ò">(-7636629366993453013L, a);
      if ((Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         this.m();
         d<"Q">(this, null, -7636036558663882459L, a);
         if (d<"R">(-7636343680456648437L, a) == null || d<"R">(-7636343680456648437L, a).isShutdown()) {
            d<"S">((ThreadPoolExecutor)Executors.newFixedThreadPool(2), -7636343680456648437L, a);
         }

         if (!this.w(new Object[]{ax})) {
            d<"b">(mc, -7623563268529629732L, a).allChanged();
         }
      }
   }

   private boolean t(List<BlockPos> positions) {
      long a = 树友友友何何友树树树.a ^ 121258919922620L;
      d<"ò">(-8845524735003258096L, a);
      if (positions.size() <= 1) {
         return true;
      } else {
         Set<BlockPos> allPositions = new HashSet<>(positions);
         Set<BlockPos> visited = new HashSet<>();
         Queue<BlockPos> queue = new LinkedList<>();
         BlockPos startNode = positions.get(0);
         queue.add(startNode);
         visited.add(startNode);
         if (!queue.isEmpty()) {
            BlockPos current = queue.poll();
            Direction[] var10 = Direction.values();
            int var11 = var10.length;
            int var12 = 0;
            if (0 < var11) {
               Direction dir = var10[0];
               BlockPos neighbor = current.relative(dir);
               if (allPositions.contains(neighbor) && !visited.contains(neighbor)) {
                  visited.add(neighbor);
                  queue.add(neighbor);
               }

               var12++;
            }
         }

         return visited.size() == positions.size();
      }
   }

   private double v(BlockPos centerPos, int radius) {
      long a = 树友友友何何友树树树.a ^ 53993050155732L;
      HashMap oreDistribution = new HashMap();
      d<"ò">(-6605024400280833416L, a);
      int x = -8;
      if (-8 <= radius) {
         int y = -radius;
         if (y <= radius) {
            int z = -radius;
            if (z <= radius) {
               BlockPos pos = centerPos.offset(-8, y, z);
               if (mc.level.isLoaded(pos)) {
                  Block block = mc.level.getBlockState(pos).getBlock();
                  if (this.E(block)) {
                     this.a(block)
                        .stream()
                        .findFirst()
                        .ifPresent(representative -> oreDistribution.computeIfAbsent(representative, k -> new ArrayList()).add(pos));
                  }
               }

               z++;
            }

            y++;
         }

         x++;
      }

      for (List<BlockPos> positions : oreDistribution.values()) {
         if (positions.size() >= 2) {
            if (this.t(positions)) {
            }

            if (this.N(positions)) {
               return -10.0;
            }
            break;
         }
      }

      return 0.0;
   }

   private void v() {
      long a = 树友友友何何友树树树.a ^ 34010241110471L;
      long ax = a ^ 77623511508605L;
      long var10001 = a ^ 45066068034116L;
      int axx = (int)((a ^ 45066068034116L) >>> 48);
      int axxx = (int)((a ^ 45066068034116L) << 16 >>> 48);
      int axxxx = (int)(var10001 << 32 >>> 32);
      d<"ò">(-6970144266454759061L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         int playerX = (int)mc.player.getX();
         int playerY = (int)mc.player.getY();
         int playerZ = (int)mc.player.getZ();
         int range = d<"b">(this, -6971390173700520230L, a).getValue().intValue();
         树何树树何树何何树何.N((char)axx, () -> {
            long axxxxx = 树友友友何何友树树树.a ^ 1890773159120L;
            d<"ò">(4778897472832853116L, axxxxx);

            try {
               ;
            } finally {
               d<"Q">(this, false, 4781184395006597574L, axxxxx);
               d<"Q">(this, System.currentTimeMillis(), 4781656503241815727L, axxxxx);
            }
         }, (char)axxx, axxxx);
      } else {
         d<"Q">(this, false, -6967857288983247663L, a);
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean q(BlockState state) {
      long a = 树友友友何何友树树树.a ^ 137794833873611L;
      d<"ò">(8379352845454271079L, a);
      Block block = state.getBlock();
      if ((block == d<"R">(8377704092366517790L, a) || block == d<"R">(8394046242976907352L, a)) && d<"b">(this, 8381238684408768295L, a).getValue()) {
         return true;
      } else if ((block == d<"R">(8380651848025911591L, a) || block == d<"R">(8376997651986150603L, a)) && d<"b">(this, 8381943481561548404L, a).getValue()) {
         return true;
      } else if ((block == d<"R">(8382160255645004881L, a) || block == d<"R">(8381454826376732795L, a)) && d<"b">(this, 8377296632785581850L, a).getValue()) {
         return true;
      } else if ((block == d<"R">(8377509901927474762L, a) || block == d<"R">(8383119702466238586L, a) || block == d<"R">(8382290996651658493L, a))
         && d<"b">(this, 8393212504670683370L, a).getValue()) {
         return true;
      } else if ((block == d<"R">(8378512411375459263L, a) || block == d<"R">(8393909553154792937L, a)) && d<"b">(this, 8394563345225411257L, a).getValue()) {
         return true;
      } else if ((block == d<"R">(8390595353765475553L, a) || block == d<"R">(8380547835727254430L, a)) && d<"b">(this, 8381881735831872566L, a).getValue()) {
         return true;
      } else if ((block == d<"R">(8390431742898955511L, a) || block == d<"R">(8383223285235398667L, a)) && d<"b">(this, 8393714760525420965L, a).getValue()) {
         return true;
      } else if ((block == d<"R">(8377967517505600098L, a) || block == d<"R">(8378763606630255513L, a)) && d<"b">(this, 8390342520815962304L, a).getValue()) {
         return true;
      } else if (block == d<"R">(8390988282041331896L, a) && d<"b">(this, 8381828309292337004L, a).getValue()) {
         return true;
      } else if (block == d<"R">(8390841031785899286L, a) && d<"b">(this, 8391324927048841521L, a).getValue()) {
         return true;
      } else if (block == d<"R">(8379135811797667758L, a) && d<"b">(this, 8391625377120188498L, a).getValue()) {
         return true;
      } else {
         return block == d<"R">(8376771693745566382L, a) && d<"b">(this, 8379504635811890270L, a).getValue()
            ? true
            : (block == d<"R">(8378952003395464448L, a) || block == d<"R">(8394279363345927489L, a) || block == d<"R">(8378661622200144429L, a))
               && d<"b">(this, 8393256413986423052L, a).getValue();
      }
   }

   private double w(BlockPos orePos, Block oreBlock) {
      long a = 树友友友何何友树树树.a ^ 126509230775497L;
      d<"ò">(5929973356960466021L, a);
      Set validHostRocks = this.F(oreBlock);
      if (validHostRocks.isEmpty()) {
         return 1.0;
      } else {
         int stoneNeighbors = 0;
         int invalidNeighbors = 0;
         int airNeighbors = 0;
         Direction[] score = d<"R">(5943419890062373173L, a);
         int var11 = score.length;
         int var12 = 0;
         if (0 < var11) {
            Direction dir = score[0];
            BlockPos neighborPos = orePos.relative(dir);
            Block neighborBlock = mc.level.getBlockState(neighborPos).getBlock();
            if (validHostRocks.contains(neighborBlock)) {
               stoneNeighbors++;
            }

            if (this.C(neighborPos)) {
               airNeighbors++;
            }

            if (!this.x(neighborBlock, oreBlock) && !this.E(neighborBlock) && !this.r(neighborBlock)) {
               invalidNeighbors++;
            }

            var12++;
         }

         if (stoneNeighbors == 0 && invalidNeighbors >= 4 && airNeighbors <= 1) {
            return -5.0;
         } else if (airNeighbors >= 2) {
            if (stoneNeighbors >= 1) {
               return 2.0;
            } else {
               return invalidNeighbors <= 2 ? 0.5 : -1.0;
            }
         } else {
            double scorex = 0.0;
            if (stoneNeighbors >= 4) {
               scorex = 3.0;
            }

            if (stoneNeighbors >= 2) {
               scorex++;
            }

            if (stoneNeighbors == 1) {
               scorex += 0.5;
            }

            return scorex;
         }
      }
   }

   @EventTarget
   public void r(LivingUpdateEvent event) {
      long a = 树友友友何何友树树树.a ^ 56230343279981L;
      long ax = a ^ 118006980047575L;
      long var10001 = a ^ 5730678478574L;
      int axx = (int)((a ^ 5730678478574L) >>> 48);
      int axxx = (int)((a ^ 5730678478574L) << 16 >>> 48);
      int axxxx = (int)(var10001 << 32 >>> 32);
      d<"ò">(-8363396221707412031L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         if (mc.level != d<"b">(this, -8363931855309605681L, a)) {
            this.Q();
         }

         if (d<"b">(this, -8365062566954444740L, a) != null) {
            d<"b">(this, -8370024102740846066L, a).clear();
            d<"b">(this, -8370024102740846066L, a).putAll(d<"b">(this, -8365062566954444740L, a));
            d<"Q">(this, null, -8365062566954444740L, a);
         }

         if (System.currentTimeMillis() - d<"b">(this, -8369384305126654259L, a) > d<"b">(this, -8369966107719298280L, a).getValue().longValue()
            && !d<"b">(this, -8362641755119373368L, a)) {
            d<"Q">(this, true, -8362641755119373368L, a);
            long scanId = d<"b">(this, -8369258157312531829L, a);
            树何树树何树何何树何.N((char)axx, () -> {
               long axxxxx = 树友友友何何友树树树.a ^ 55789445442107L;
               d<"ò">(7257901456927879831L, axxxxx);

               try {
                  Map<BlockPos, Block> foundBlocks = new ConcurrentHashMap<>();
                  this.D(mc.player.blockPosition(), foundBlocks);
                  if (scanId == d<"b">(this, 7245286387390893533L, axxxxx)) {
                     d<"Q">(this, foundBlocks, 7259611778478487402L, axxxxx);
                  }
               } finally {
                  d<"Q">(this, false, 7253025453822336158L, axxxxx);
                  d<"Q">(this, System.currentTimeMillis(), 7246283863801123227L, axxxxx);
               }
            }, (char)axxx, axxxx);
         }

         if (d<"b">(this, -8367695755509710587L, a).getValue()
            && System.currentTimeMillis() - d<"b">(this, -8365742120269119726L, a) > m
            && !d<"b">(this, -8365683165355995013L, a)) {
            d<"Q">(this, true, -8365683165355995013L, a);
            this.v();
         }
      }
   }

   private boolean r(Block block) {
      long a = 树友友友何何友树树树.a ^ 118687142285344L;
      d<"ò">(2207440724459161740L, a);
      if (block == null) {
         return false;
      } else {
         String id = block.builtInRegistryHolder().key().location().getPath();
         return id.contains(b<"c">(4845, 3827464304862726450L ^ a))
            || id.contains(b<"c">(17473, 795603329973247982L ^ a))
            || id.contains(b<"c">(257, 8946024960637344454L ^ a))
            || id.contains(b<"c">(24455, 3877151500129944700L ^ a))
            || id.contains(b<"c">(31504, 7286599196213928181L ^ a))
            || id.equals(b<"c">(1351, 3669950784816717562L ^ a))
            || id.equals(b<"c">(27868, 559509335456216875L ^ a))
            || id.equals(b<"c">(22095, 7734597075768102372L ^ a))
            || id.equals(b<"c">(18827, 6297181286658757217L ^ a))
            || id.equals(b<"c">(1373, 8617538205775961752L ^ a))
            || id.equals(b<"c">(31645, 6156370403834224677L ^ a));
      }
   }

   private boolean E(Block block) {
      long a = 树友友友何何友树树树.a ^ 131160380857182L;
      d<"ò">(6186955350755951602L, a);
      if (block == null) {
         return false;
      } else {
         String blockId = block.builtInRegistryHolder().key().location().getPath();
         return blockId.contains(b<"c">(9200, 8289027972433015640L ^ a));
      }
   }

   private boolean N(List<BlockPos> positions) {
      long a = 树友友友何何友树树树.a ^ 113049586658453L;
      d<"ò">(-2155136764918991815L, a);
      if (positions.size() < 4) {
         return false;
      } else {
         Map<Integer, Integer> xSpacing = new HashMap<>();
         Map<Integer, Integer> ySpacing = new HashMap<>();
         Map<Integer, Integer> zSpacing = new HashMap<>();
         int i = 0;
         if (0 < positions.size()) {
            int j = 1;
            if (1 < positions.size()) {
               BlockPos p1 = positions.get(0);
               BlockPos p2 = positions.get(1);
               int dx = Math.abs(p1.getX() - p2.getX());
               int dy = Math.abs(p1.getY() - p2.getY());
               int dz = Math.abs(p1.getZ() - p2.getZ());
               if (dx > 1) {
                  xSpacing.put(dx, xSpacing.getOrDefault(dx, 0) + 1);
               }

               if (dy > 1) {
                  ySpacing.put(dy, ySpacing.getOrDefault(dy, 0) + 1);
               }

               if (dz > 1) {
                  zSpacing.put(dz, zSpacing.getOrDefault(dz, 0) + 1);
               }

               j++;
            }

            i++;
         }

         i = positions.size() > 5 ? 3 : 2;
         return xSpacing.values().stream().anyMatch(c -> {
            long ax = 树友友友何何友树树树.a ^ 71528133025463L;
            d<"ò">(5779610751180195355L, ax);
            return c > i;
         }) || ySpacing.values().stream().anyMatch(c -> {
            long ax = 树友友友何何友树树树.a ^ 31171999630490L;
            d<"ò">(-8496023038291272650L, ax);
            return c > i;
         }) || zSpacing.values().stream().anyMatch(c -> {
            long ax = 树友友友何何友树树树.a ^ 73322274781002L;
            d<"ò">(-448021331153358874L, ax);
            return c > i;
         });
      }
   }

   private double P(BlockPos orePos, Block oreBlock) {
      long a = 树友友友何何友树树树.a ^ 86716064135311L;
      d<"ò">(8506528425687179299L, a);
      int y = orePos.getY();
      Set oreGroup = this.a(oreBlock);
      if (oreGroup.contains(d<"R">(8517803915588597413L, a))) {
         if (y >= -64 && y <= 16) {
            return 2.0;
         } else {
            return y > 16 && y <= 32 ? 0.5 : -10.0;
         }
      } else if (oreGroup.contains(d<"R">(8502996883655079974L, a))) {
         return y >= -16 && y <= 320 ? 2.0 : -10.0;
      } else if (oreGroup.contains(d<"R">(8504721695043052558L, a))) {
         if (y >= -64 && y <= 32) {
            return 2.0;
         } else {
            return y > 32 && y < 80 ? -1.5 : -5.0;
         }
      } else if (!oreGroup.contains(d<"R">(8509368820156282389L, a))) {
         if (oreGroup.contains(d<"R">(8504949974775805018L, a))) {
            return y >= 0 && y <= 256 ? 1.0 : 0.0;
         } else if (oreGroup.contains(d<"R">(8505678985762648931L, a))) {
            return y >= -16 && y <= 112 ? 1.5 : 0.5;
         } else if (oreGroup.contains(d<"R">(8503437289694779899L, a))) {
            return y >= -64 && y <= 64 ? 1.5 : 0.0;
         } else if (oreGroup.contains(d<"R">(8517712877858743987L, a))) {
            return y >= -64 && y <= 16 ? 1.5 : 0.0;
         } else if (oreGroup.contains(d<"R">(8518122166748964690L, a))) {
            if (y >= 8 && y <= 22) {
               return 2.0;
            } else {
               return y < 120 ? 1.0 : -15.0;
            }
         } else {
            return 0.5;
         }
      } else {
         return (y < -24 || y > 72) && (y <= 80 || y > 320) ? 1.0 : 1.5;
      }
   }

   private void W(PoseStack guiPoseStack) {
      long a = 树友友友何何友树树树.a ^ 81930583628921L;
      float sW = mc.getWindow().getGuiScaledWidth();
      float sH = mc.getWindow().getGuiScaledHeight();
      float cX = sW / 2.0F;
      float cY = sH / 2.0F;
      Vec3 camPos = d<"b">(mc, -3250420840258172246L, a).getMainCamera().getPosition();
      Tesselator tesselator = Tesselator.getInstance();
      d<"ò">(-3243921224744614699L, a);
      BufferBuilder buffer = tesselator.getBuilder();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableDepthTest();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      buffer.begin(d<"R">(-3245069547948881169L, a), d<"R">(-3244934367101647410L, a));
      double renderRangeSq = Math.pow(d<"b">(this, -3243181847510963379L, a).getValue().doubleValue(), 2.0);
      Vec3 playerEyePos = mc.player.getEyePosition(1.0F);
      Iterator packetRangeSq = d<"b">(this, -3259538731717442790L, a).entrySet().iterator();
      if (packetRangeSq.hasNext()) {
         Entry<BlockPos, Block> entry = (Entry<BlockPos, Block>)packetRangeSq.next();
         this.Z(entry.getKey(), entry.getValue().defaultBlockState(), playerEyePos, renderRangeSq, camPos, buffer, guiPoseStack, cX, cY, sW, sH);
      }

      if (d<"b">(this, -3257368426855098351L, a).getValue()) {
         double packetRangeSqx = Math.pow(d<"b">(this, -3260419209309600218L, a).getValue().doubleValue(), 2.0);
         Iterator var17 = d<"b">(this, -3260311908279390946L, a).entrySet().iterator();
         if (var17.hasNext()) {
            Entry<树友友友何何友树树树.友何友树何树何何何何, BlockState> entry = (Entry<树友友友何何友树树树.友何友树何树何何何何, BlockState>)var17.next();
            if (this.q(entry.getValue())) {
               this.Z(entry.getKey().P(), entry.getValue(), playerEyePos, packetRangeSqx, camPos, buffer, guiPoseStack, cX, cY, sW, sH);
            }
         }
      }

      tesselator.end();
      RenderSystem.enableDepthTest();
      RenderSystem.disableBlend();
   }

   private 树友友友何何友树树树.树树友友友友树友何何 W(List<BlockPos> vein, Block oreBlock) {
      long a = 树友友友何何友树树树.a ^ 54066632214272L;
      long ax = a ^ 115843319673018L;
      d<"ò">(-3926508326983934036L, a);
      if (!this.w(new Object[]{ax}) && !vein.isEmpty()) {
         树友友友何何友树树树.树树友友友友树友何何 report = new 树友友友何何友树树树.树树友友友友树友何何();
         BlockPos representativePos = vein.get(0);
         int veinSize = vein.size();
         d<"Q">(report, this.C(veinSize), -3925729085917903735L, a);
         if (veinSize < d<"b">(this, -3912711185215813790L, a).getValue().intValue()) {
            d<"Q">(report, -20.0, -3925729085917903735L, a);
            return report;
         } else {
            d<"Q">(report, this.l(representativePos, oreBlock), -3923498019418632259L, a);
            d<"Q">(report, this.P(representativePos, oreBlock), -3925260990100682696L, a);
            if (d<"b">(report, -3925260990100682696L, a) <= -10.0) {
               return report;
            } else {
               if (d<"b">(this, -3912730626787589831L, a).getValue()) {
                  double totalHostRockScore = 0.0;
                  int exposedFaces = 0;
                  Iterator avgExposedFaces = vein.iterator();
                  if (avgExposedFaces.hasNext()) {
                     BlockPos pos = (BlockPos)avgExposedFaces.next();
                     totalHostRockScore = 0.0 + this.w(pos, oreBlock);
                     Direction[] var16 = d<"R">(-3913057679202702596L, a);
                     int var17 = var16.length;
                     int var18 = 0;
                     if (0 < var17) {
                        Direction dir = var16[0];
                        if (this.C(pos.relative(dir))) {
                           exposedFaces++;
                        }

                        var18++;
                     }
                  }

                  d<"Q">(report, totalHostRockScore / veinSize, -3924928531440637321L, a);
                  double avgExposedFacesx = (double)exposedFaces / veinSize;
                  if (avgExposedFacesx >= 3.0) {
                     d<"Q">(report, 3.0, -3925735243703016820L, a);
                  }

                  if (avgExposedFacesx >= 1.0) {
                     d<"Q">(report, 1.5, -3925735243703016820L, a);
                  }

                  if (avgExposedFacesx > 0.0) {
                     d<"Q">(report, 0.5, -3925735243703016820L, a);
                  }

                  d<"Q">(report, 0.0, -3925735243703016820L, a);
               }

               if (d<"b">(this, -3924065726544676089L, a).getValue()) {
                  d<"Q">(report, this.v(representativePos, 8), -3911748691764397240L, a);
               }

               return report;
            }
         }
      } else {
         return new 树友友友何何友树树树.树树友友友友树友何何();
      }
   }

   private void H(BlockPos startPos, Block oreType, Map<BlockPos, Block> foundBlocks, Set<BlockPos> processedBlocks) {
      long a = 树友友友何何友树树树.a ^ 34135284202334L;
      d<"ò">(-5342373767654464526L, a);
      if (!processedBlocks.contains(startPos)) {
         List<BlockPos> potentialVein = this.x(startPos, oreType, processedBlocks);
         if (!potentialVein.isEmpty()) {
            processedBlocks.addAll(potentialVein);
            if (d<"b">(this, -5350053740648638217L, a).getValue()) {
               树友友友何何友树树树.树树友友友友树友何何 report = this.W(potentialVein, oreType);
               if (report.v(d<"b">(this, -5341671354308271675L, a).getValue().doubleValue())) {
                  Iterator pos = potentialVein.iterator();
                  if (pos.hasNext()) {
                     BlockPos posx = (BlockPos)pos.next();
                     foundBlocks.put(posx, oreType);
                  }
               }
            }

            Iterator var12 = potentialVein.iterator();
            if (var12.hasNext()) {
               BlockPos pos = (BlockPos)var12.next();
               foundBlocks.put(pos, oreType);
            }
         }
      }
   }

   private void T(PoseStack poseStack, AABB box, Color color) {
      long a = 树友友友何何友树树树.a ^ 81806961756760L;
      float r = color.getRed() / 255.0F;
      float g = color.getGreen() / 255.0F;
      float b = color.getBlue() / 255.0F;
      float minX = (float)d<"b">(box, -4261944545043616518L, a);
      float minY = (float)d<"b">(box, -4258072980869243601L, a);
      float minZ = (float)d<"b">(box, -4262805645885309244L, a);
      float maxX = (float)d<"b">(box, -4256990845629270754L, a);
      float maxY = (float)d<"b">(box, -4257863311626507639L, a);
      float maxZ = (float)d<"b">(box, -4263141185870960500L, a);
      Matrix4f matrix = poseStack.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(d<"R">(-4257986029017235243L, a), d<"R">(-4263029204464757777L, a));
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      BufferUploader.drawWithShader(buffer.end());
      buffer.begin(d<"R">(-4263164383160312626L, a), d<"R">(-4263029204464757777L, a));
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      BufferUploader.drawWithShader(buffer.end());
   }

   private void Q() {
      long a = 树友友友何何友树树树.a ^ 60945679304134L;
      long ax = a ^ 122155380748924L;
      this.m();
      String var10000 = d<"ò">(5423524965942746474L, a);
      d<"Q">(this, mc.level, 5424123958540743780L, a);
      if (var10000 == null) {
         if (this.w(new Object[]{ax})) {
            return;
         }

         d<"b">(mc, 5436597558462089373L, a).allChanged();
      }
   }

   private void Q(PoseStack poseStack, BlockPos pos, BlockState state, Vec3 camPos) {
      long a = 树友友友何何友树树树.a ^ 75991568146545L;
      d<"ò">(7994814352643782877L, a);
      if (state != null && !state.isAir()) {
         Block block = state.getBlock();
         Color color = this.l(block);
         if (color == null) {
            color = this.f(block);
         }

         if (color != null) {
            poseStack.pushPose();
            poseStack.translate(
               pos.getX() - d<"b">(camPos, 7981738847029683868L, a),
               pos.getY() - d<"b">(camPos, 7996690630723366321L, a),
               pos.getZ() - d<"b">(camPos, 7995421214809477905L, a)
            );
            if (d<"b">(this, 7994764956188098890L, a).getValue()) {
               this.T(poseStack, new AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0), color);
            }

            this.f(poseStack, new AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0), color);
            poseStack.popPose();
         }
      }
   }

   private Vector3f K(Vec3 worldPos, Vec3 camPos) {
      long a = 树友友友何何友树树树.a ^ 37286565452006L;
      d<"ò">(-7609907168756170678L, a);
      if (d<"b">(this, -7607536659147712095L, a) != null && d<"b">(this, -7611291208852558640L, a) != null) {
         Vector4f pos = new Vector4f(
            (float)(d<"b">(worldPos, -7614547083588919797L, a) - d<"b">(camPos, -7614547083588919797L, a)),
            (float)(d<"b">(worldPos, -7606976458222463706L, a) - d<"b">(camPos, -7606976458222463706L, a)),
            (float)(d<"b">(worldPos, -7610496437670466682L, a) - d<"b">(camPos, -7610496437670466682L, a)),
            1.0F
         );
         pos.mul(d<"b">(this, -7607536659147712095L, a));
         pos.mul(d<"b">(this, -7611291208852558640L, a));
         if (pos.w() <= 0.0F) {
            return null;
         } else {
            pos.mul(1.0F / pos.w());
            float sW = mc.getWindow().getGuiScaledWidth();
            float sH = mc.getWindow().getGuiScaledHeight();
            float sX = (pos.x() * 0.5F + 0.5F) * sW;
            float sY = (-pos.y() * 0.5F + 0.5F) * sH;
            if (sX >= 0.0F && sX <= sW && sY >= 0.0F && sY <= sH) {
            }

            return new Vector3f(sX, sY, 1.0F);
         }
      } else {
         return null;
      }
   }

   private static String LIU_YA_FENG() {
      return "何炜霖230622200409390090";
   }

   public static class 友何友树何树何何何何 implements 何树友 {
      private final int 友何友友树何树树友友;
      private final int 何树友树友友何何何何;
      private final int 何友友何树友友友何树;
      private static final long a;
      private static final Object[] b = new Object[11];
      private static final String[] c = new String[11];
      private static String HE_WEI_LIN;

      public 友何友树何树何何何何(BlockPos pos) {
         this.友何友友树何树树友友 = pos.getX();
         this.何树友树友友何何何何 = pos.getY();
         this.何友友何树友友友何树 = pos.getZ();
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-818364272836182662L, 8089185439384969286L, MethodHandles.lookup().lookupClass()).a(115380772469716L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      @Override
      public boolean equals(Object obj) {
         long a = 树友友友何何友树树树.友何友树何树何何何何.a ^ 47552744244266L;
         a<"P">(-567248653896910435L, a);
         if (this == obj) {
            return true;
         } else if (obj != null && this.getClass() == obj.getClass()) {
            树友友友何何友树树树.友何友树何树何何何何 position = (树友友友何何友树树树.友何友树何树何何何何)obj;
            return a<"È">(this, -566503242519712836L, a) == a<"È">(position, -566503242519712836L, a)
               && a<"È">(this, -567205151200457954L, a) == a<"È">(position, -567205151200457954L, a)
               && a<"È">(this, -566464743397135598L, a) == a<"È">(position, -566464743397135598L, a);
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         long a = 树友友友何何友树树树.友何友树何树何何何何.a ^ 54361984530138L;
         int result = a<"È">(this, -3831584700511921844L, a);
         result = 31 * result + a<"È">(this, -3832286596514186770L, a);
         return 31 * result + a<"È">(this, -3831550496608560670L, a);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 200 && var8 != 'J' && var8 != 238 && var8 != 'i') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 203) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'P') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 200) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'J') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 238) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友友友何何友树树树$友何友树何树何何何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 24;
                  case 1 -> 25;
                  case 2 -> 2;
                  case 3 -> 52;
                  case 4 -> 20;
                  case 5 -> 3;
                  case 6 -> 13;
                  case 7 -> 56;
                  case 8 -> 31;
                  case 9 -> 4;
                  case 10 -> 50;
                  case 11 -> 16;
                  case 12 -> 6;
                  case 13 -> 9;
                  case 14 -> 15;
                  case 15 -> 40;
                  case 16 -> 63;
                  case 17 -> 62;
                  case 18 -> 23;
                  case 19 -> 58;
                  case 20 -> 54;
                  case 21 -> 55;
                  case 22 -> 43;
                  case 23 -> 11;
                  case 24 -> 36;
                  case 25 -> 30;
                  case 26 -> 7;
                  case 27 -> 48;
                  case 28 -> 28;
                  case 29 -> 14;
                  case 30 -> 19;
                  case 31 -> 35;
                  case 32 -> 46;
                  case 33 -> 34;
                  case 34 -> 1;
                  case 35 -> 22;
                  case 36 -> 8;
                  case 37 -> 10;
                  case 38 -> 53;
                  case 39 -> 32;
                  case 40 -> 18;
                  case 41 -> 26;
                  case 42 -> 57;
                  case 43 -> 49;
                  case 44 -> 44;
                  case 45 -> 45;
                  case 46 -> 39;
                  case 47 -> 12;
                  case 48 -> 60;
                  case 49 -> 5;
                  case 50 -> 33;
                  case 51 -> 42;
                  case 52 -> 0;
                  case 53 -> 21;
                  case 54 -> 38;
                  case 55 -> 51;
                  case 56 -> 61;
                  case 57 -> 17;
                  case 58 -> 37;
                  case 59 -> 27;
                  case 60 -> 41;
                  case 61 -> 29;
                  case 62 -> 47;
                  default -> 59;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "6-DD-\u00159m\tO'\b<0\u0002\t/\u001516\u0006Bl\u001383\u0006\t0\u001f;'\u000fUl807\u001eB094.\u000fU#";
         b[1] = "W#*/1H\\,;`LPO+2)";
         b[2] = "]7[T%2Rw\u0016_//W*\u001d\u0019'2Z,\u0019Rd4S)\u0019\u001988P=\u0010Ed桌叵厒厾佢伟厖栯案桤\u0013厁伈叵案传栦伟伈佫伌";
         b[3] = int.class;
         c[3] = "java/lang/Integer";
         b[4] = "2e3WBx9j\"\u0018>a6p,[\tQ g F\u0018}7j";
         b[5] = "'K\u0016h|3,D\u0007'\u001d='O\u0003}";
         b[6] = "O\u00074I$7M\u00170s\u0018\u000fJL4\b>i\u0010\u00034\u0014F";
         b[7] = ";jJ\u0007Dnm`\u0005\b\"佖栛及校厫叡佖佟佔佥h\u0018ggg\u0006\tXayk";
         b[8] = "<l\u001e\"ifjfQ-\u000fj\u00054V&~~bh\n#k\u0003>5\u0007<rdbi\u0002)\u000f";
         b[9] = "\u0002\u007fZ\f\u00063Tu\u0015\u0003`厕佦叟叫桺伽桏栢叟叫cZ:^r\u0016\u0002\u001a<@~";
         b[10] = "No{yzL\u0018e4v\u001c佴厴叏佔栏叟只厴佑栐\u0016&E\u0012b7wfC\fn";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public BlockPos P() {
         long a = 树友友友何何友树树树.友何友树何树何何何何.a ^ 111950833022928L;
         return new BlockPos(a<"È">(this, 5465450901484263494L, a), a<"È">(this, 5465873536564558052L, a), a<"È">(this, 5465625843445815528L, a));
      }

      private static String HE_SHU_YOU() {
         return "行走的50万——何炜霖";
      }
   }

   private static enum 友树树何树友何何友树 implements  {
      树何何友树树何何树树,
      友树何友友树何何树树,
      何何何树树友树友友何;

      private static final long a;
      private static final Object[] b = new Object[7];
      private static final String[] c = new String[7];
      private static String HE_SHU_YOU;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-7339082121381244402L, 4151368307315735372L, MethodHandles.lookup().lookupClass()).a(226038934559902L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 7890420724294L;
         a();
         Cipher var1;
         Cipher var12 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[3];
         int var6 = 0;
         char var4 = '\b';
         int var3 = -1;

         while (true) {
            String var14 = a(
                  var1.doFinal(
                     "òV\u0016hÈ§\u008e!\u0010D4\\l\u0012l\u0004\u0083¶U\u00917ÅØ¥·\b§tøÿe\u009d\u0016\u0086"
                        .substring(++var3, var3 + var4)
                        .getBytes("ISO-8859-1")
                  )
               )
               .intern();
            byte var10001 = -1;
            var0[var6++] = var14;
            if ((var3 += var4) >= 34) {
               树何何友树树何何树树 = new 树友友友何何友树树树.友树树何树友何何友树();
               友树何友友树何何树树 = new 树友友友何何友树树树.友树树何树友何何友树();
               何何何树树友树友友何 = new 树友友友何何友树树树.友树树何树友何何友树();
               return;
            }

            var4 = "òV\u0016hÈ§\u008e!\u0010D4\\l\u0012l\u0004\u0083¶U\u00917ÅØ¥·\b§tøÿe\u009d\u0016\u0086".charAt(var3);
         }
      }

      public static 树友友友何何友树树树.友树树何树友何何友树 e(String name) {
         return Enum.valueOf(树友友友何何友树树树.友树树何树友何何友树.class, name);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'D' && var8 != 242 && var8 != 186 && var8 != 210) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'c') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 223) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'D') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 242) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 186) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 7;
                  case 1 -> 58;
                  case 2 -> 43;
                  case 3 -> 50;
                  case 4 -> 23;
                  case 5 -> 24;
                  case 6 -> 13;
                  case 7 -> 54;
                  case 8 -> 34;
                  case 9 -> 61;
                  case 10 -> 39;
                  case 11 -> 25;
                  case 12 -> 2;
                  case 13 -> 56;
                  case 14 -> 59;
                  case 15 -> 4;
                  case 16 -> 62;
                  case 17 -> 44;
                  case 18 -> 60;
                  case 19 -> 0;
                  case 20 -> 32;
                  case 21 -> 9;
                  case 22 -> 26;
                  case 23 -> 63;
                  case 24 -> 22;
                  case 25 -> 41;
                  case 26 -> 21;
                  case 27 -> 46;
                  case 28 -> 12;
                  case 29 -> 16;
                  case 30 -> 53;
                  case 31 -> 37;
                  case 32 -> 28;
                  case 33 -> 31;
                  case 34 -> 49;
                  case 35 -> 42;
                  case 36 -> 11;
                  case 37 -> 20;
                  case 38 -> 40;
                  case 39 -> 55;
                  case 40 -> 27;
                  case 41 -> 8;
                  case 42 -> 18;
                  case 43 -> 29;
                  case 44 -> 14;
                  case 45 -> 35;
                  case 46 -> 1;
                  case 47 -> 45;
                  case 48 -> 10;
                  case 49 -> 51;
                  case 50 -> 57;
                  case 51 -> 6;
                  case 52 -> 36;
                  case 53 -> 47;
                  case 54 -> 30;
                  case 55 -> 52;
                  case 56 -> 5;
                  case 57 -> 17;
                  case 58 -> 15;
                  case 59 -> 48;
                  case 60 -> 33;
                  case 61 -> 19;
                  case 62 -> 38;
                  default -> 3;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\\f'?}AS&j4w\\V{ar\u007fA[}e9<GRxer`KQll.<栿叴參参伉佇句栮栙栘x叙栿栮佝栘厗佇佻叴栙";
         b[1] = "^\u0000E\u0004\u0016\\j#JD[W`>O\u0019P\u0011h#B\u001fTZ+%K\u001aT\u0011w)H\u000e]M+桝叭厡右佪佐厇样桻栩\u001b収桝样伿栩叴佐伙叭桻\u0003";
         b[2] = "l((\u0018Qng'9W0`l,=\r";
         b[3] = "D_Y/Q*_\u0012\u001e_叶桕佸厬厣框佨休格桶`>\u0005uU\u000b\u0006%H2";
         b[4] = "\u000f~\u0004 Fs\u00143CP使佈伳桗栤厓栻取厭伓=1\u0012,\u001e*[*_k";
         b[5] = "I_TX/\u0018R\u0012\u0013(厈厽叫伲厮叫桒伣併伲mY,\u0018I\u001e\u001dGs\u0006";
         b[6] = "H\u00116\u0000\u0001qS\\qp桼佊佴叢栖桩伸佊栰核\u000f\u0011U.YEi\n\u0018i";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友友友何何友树树树$友树树何树友何何友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      public static 树友友友何何友树树树.友树树何树友何何友树[] R() {
         long var0 = a ^ 33944085770106L;
         return (树友友友何何友树树树.友树树何树友何何友树[])a<"º">(-5593705849954593880L, var0).clone();
      }

      private static String HE_WEI_LIN() {
         return "何建国230622195906030014";
      }
   }

   private static class 树树友友友友树友何何 implements 何树友 {
      double 友树树友树友友树何何;
      double 友树友何何友友树何何;
      double 友何何何何何友何何树;
      double 树何树友树何友树何何;
      double 何树友何友友友树树树;
      double 何树何友何何友友友何;
      double 何何何树树友友友友何;
      private static final long a;
      private static final Object[] b = new Object[15];
      private static final String[] c = new String[15];
      private static String HE_SHU_YOU;

      private 树树友友友友树友何何() {
         long a = 树友友友何何友树树树.树树友友友友树友何何.a ^ 121740458181744L;
         super();
         a<"j">(this, 0.0, 4955681344992533528L, a);
         a<"j">(this, 0.0, 4955636181928510273L, a);
         a<"j">(this, 0.0, 4955983038961598500L, a);
         a<"j">(this, 0.0, 4955561327837439512L, a);
         a<"j">(this, 0.0, 4955893720379793355L, a);
         a<"j">(this, 0.0, 4955852059844620240L, a);
         a<"j">(this, 0.0, 4956007956958750441L, a);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(5379769631392937020L, 5494734502363574668L, MethodHandles.lookup().lookupClass()).a(26382818222130L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友友友何何友树树树$树树友友友友树友何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'I' && var8 != 'j' && var8 != 204 && var8 != 245) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'm') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'v') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'I') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'j') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 204) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static void a() {
         b[0] = "\u0007!4T5(\bay_?5\r<r\u00197(\u0000:vRt.\t?v\u0019(\"\n+\u007fEt\u0005\u0001;nR(\u0004\u0005\"\u007fE;";
         b[1] = "\u001bb\u0011fMb\u0010m\u0000)0z\u0003j\t`";
         b[2] = "W:_>2HXz\u001258U]'\u0019s0HP!\u001d8sNY$\u001ds/BZ0\u0014/s栶叿原厺伈伈召栥桅桠y桌栶叿原厺厖桌召佡企";
         b[3] = "\u001b\u0014L>-\\\u0010\u001b]qQE\u001f\u0001S2fu\t\u0016_/wY\u001e\u001b";
         b[4] = double.class;
         c[4] = "java/lang/Double";
         b[5] = "J(^\u0001X\u0003A'ON9\rJ,K\u0014";
         b[6] = "?\u00196h0Uz\u001f2i\u0001栱佛桤厘桋作叫栟传伆R:\u0013z\u00116;?RmL";
         b[7] = "((\u0006cf m.\u0002bW厞栈厏伶伄厔厞栈休伶Ylfm \u00060i'z}";
         b[8] = "\u0003nT}MjFhP||叔栣栓叺桞县叔栣佗佤GG,FfT.BmQ;";
         b[9] = "B'\u000137\u001eC2_^\t%\n3UcmBIr^^";
         b[10] = "\u000fB\f}\u0019+JD\b|(伋栯佻厢会併厕叵句似G\u0013mJJ\f.\u0016,]\u0017";
         b[11] = "L\u0018z~:)\t\u001e~\u007f\u000b伉桬县佊厇又厗桬桥栎D0o\t\u0010z-5.\u001eM";
         b[12] = "+K\u001anrWnM\u001eoC叩住佲伪伉伞叩住佲桮Tx\u0011nC\u001a=}Py\u001e";
         b[13] = "ck8h0\u0007&m<i\u0001伧伇佒桌桋参厹厙双伈R:A&c8;?\u00001>";
         b[14] = "\u0006\u000e|xJyC\bxy{m?Pu%\u0003fA\t-&\u001d\u0004\u0005\u000ev:\u0019z\\Vu${";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 55;
                  case 1 -> 40;
                  case 2 -> 62;
                  case 3 -> 2;
                  case 4 -> 45;
                  case 5 -> 22;
                  case 6 -> 43;
                  case 7 -> 10;
                  case 8 -> 41;
                  case 9 -> 61;
                  case 10 -> 44;
                  case 11 -> 20;
                  case 12 -> 35;
                  case 13 -> 49;
                  case 14 -> 4;
                  case 15 -> 32;
                  case 16 -> 11;
                  case 17 -> 42;
                  case 18 -> 3;
                  case 19 -> 34;
                  case 20 -> 47;
                  case 21 -> 39;
                  case 22 -> 25;
                  case 23 -> 7;
                  case 24 -> 8;
                  case 25 -> 29;
                  case 26 -> 15;
                  case 27 -> 13;
                  case 28 -> 63;
                  case 29 -> 37;
                  case 30 -> 1;
                  case 31 -> 59;
                  case 32 -> 54;
                  case 33 -> 58;
                  case 34 -> 60;
                  case 35 -> 57;
                  case 36 -> 52;
                  case 37 -> 46;
                  case 38 -> 17;
                  case 39 -> 14;
                  case 40 -> 28;
                  case 41 -> 53;
                  case 42 -> 0;
                  case 43 -> 6;
                  case 44 -> 19;
                  case 45 -> 12;
                  case 46 -> 21;
                  case 47 -> 50;
                  case 48 -> 9;
                  case 49 -> 24;
                  case 50 -> 36;
                  case 51 -> 48;
                  case 52 -> 38;
                  case 53 -> 16;
                  case 54 -> 23;
                  case 55 -> 5;
                  case 56 -> 31;
                  case 57 -> 51;
                  case 58 -> 18;
                  case 59 -> 56;
                  case 60 -> 27;
                  case 61 -> 33;
                  case 62 -> 30;
                  default -> 26;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      boolean v(double threshold) {
         long a = 树友友友何何友树树树.树树友友友友树友何何.a ^ 15523243799433L;
         a<"v">(3692722131149255023L, a);
         return this.E() >= threshold;
      }

      double E() {
         long a = 树友友友何何友树树树.树树友友友友树友何何.a ^ 131744245826520L;
         return a<"I">(this, -4364546007846495312L, a)
            + a<"I">(this, -4364571110732823319L, a)
            + a<"I">(this, -4364224184443713652L, a)
            + a<"I">(this, -4364645893420129872L, a)
            + a<"I">(this, -4364332743402121117L, a)
            + a<"I">(this, -4364374680428631944L, a)
            + a<"I">(this, -4364164440162852543L, a);
      }

      private static String HE_WEI_LIN() {
         return "何树友，和树做朋友";
      }
   }
}
