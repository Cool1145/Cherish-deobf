package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;

public class 何树树何何树树友树何 extends Module implements 何树友 {
   private final ModeValue 友友树树友何树友何树 = new ModeValue(
      "Particle",
      "粒子",
      new String[]{
         "Flame",
         "Critical Hit",
         "Enchanted Hit",
         "Make Love",
         "Smoke",
         "Heart",
         "Totem",
         "Cloud",
         "Damage Indicator",
         "Sweep Attack",
         "Soul Fire Flame",
         "End Rod"
      },
      "Critical Hit"
   );
   private final NumberValue 友树何友树友树友友树 = new NumberValue("Count", "数量", 8, 1, 30, 1);
   private boolean 何树友友何友何树树何 = false;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[31];
   private static final String[] k = new String[31];
   private static String LIU_YA_FENG;

   public 何树树何何树树友树何() {
      super("Particles", "粒子效果", 树何友友何树友友何何.友友树树何友树树友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(4475481302682161972L, 7082915704563343864L, MethodHandles.lookup().lookupClass()).a(125032515948107L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(71162737672853L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[30];
      int var7 = 0;
      String var6 = ",\u000e\nÖ÷rî\rE0\u0091'ëw¨o§ñ\tm.HýMÃT#\u0093eGð\u0093\u0010Ô%Î\u008d75±M\u0010±@8´¤åu\u0010ÊDè\u0012/`Ê\u000b\u0012\\\u0015sf\u0090DJ\u00108#ø£]\b#9H\u0018±Ù\u0004\u008f-\u0096\u0010ª\u0083\u0094ö]9N<\u0006¯\u0010z[] ! \u009cZ{Rbx\u0014G,\u0011Ø}Sí\bZ¢FKæ\u0092°F\t\u009f4m<ÿ\u001a:î\u0010ª\u0006/ÒQ+Énz\u001e'ì.\u008a\u0093Ü\u0010Õ\u0099ÅÑ\u0010\u0084\u0082Pb Wè\u0002øv~\u0010þ|rq¥¬öâ&\u000eû`Ý¢Ã®\u0018¬Ør\u0098jDN¤ù\u0090Ì\"Ò+&³%\u0084\u009fÑñ\r\u008b\u008b \u0004\u0010³m}\u0083pÎ¼Nã³\u0093(X\u0014\u0092ÇÚ\u0094x\u0002äÝÞ±\u0097\u0019½aûº\u0010ÑY9\u008eÌ\u0018ðåK(ý\u0014ò¹¿\u0089 ÛL\u0011ýø)Ñ@&¤\u0094\u0095ðayñÌOK¿\u00883;-\u0083ôVQ\u0097\u0000ö½\u0010ë\"ð§\u00adøÆ?¥JÜ¤\u0085%\u009d\\ \u0090CV3M\u009cwLÅ 'æÖ\u008d\u009evÊÜr\u008di¼jq<\u009eo\u0004Pµ¤\u0006\u0010\u0092X\u0003LÿâóR\u0003Í\u0016X×b\u0096å\u0010j4ð\u0011¬ÖñT\u000bÅ\u0085\u008eÆ¯\u0088ð \u008bY\rNIØ\u000byIQt¥ÂÇ¬\u00ad{2ß\u0093\u001bê,;øå¢Í£íj2(ôÒó'rÚ\u0098\n±¾@%\u009c\u0005vè\u0005\u0015\u0086\u008cÓ'wWò¿\u001d\u0092S¬?\u008c\u0091]Z\u009büññÎ\u0010\u0082¤\u001f\u001a\\¤¡¿«pÌÒ²m'\u0017\u0010Ðöõã\u000be%/iGÝ\u0016Jèí^\u0010\t7öcóù]ý¦ç\u0097@/]op\u0018«ôÊk\u0089ÍÅÃü°r\rjÁ¡íÔ\u0089\\[Úúhx \u0084\u009d\ba`TÄ\u008fh\u0013\u001a\u00065ÃË¿\u0087¸¿\u0014uL\u00ad\u0099(îo\u0013\u009aä\u0083¸ P\u009aë\u001cõ\u000eÕì( \u0087QéßéàÜ\u000e\u0001j\u0089\u008d}j\u008e \u0002ëÚ'©\u0096 \u0080\u009e\tSì+Ä³\u0083\u008bý\u0002F¥\u0017ã:È\u001d3\u001aþõ\u008fæ\u0084øZM\u0082\u0096q(óbËyYi¹f\u001d,ê#±8\u0004´\u0095K\u000f\u000b:\u0080x'÷S[üèÓYÓ!\u001cL;\u0093sßõ\u0018f$\u0092©*§¶î\u009eC>hu\u001bÅ¥[\u00932úá+þ¸";
      short var8 = 691;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[30];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u0007À×\u0000\u0087\\z¹ö\u0018\u001e\u0087×÷ \u0093\u0019® ÚÒÇq®\u0010\u0086¤¦¹Ò\u008eÝÙ\u001cÛ_Þ){u°";
                  var8 = 41;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void C(PacketEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (event.getPacket() instanceof ServerboundInteractPacket wrapper && WrapperUtils.Y(114813987783679L, wrapper) && this.何树友友何友何树树何) {
            this.何树友友何友何树树何 = false;
            if (WrapperUtils.w(72331927741833L, wrapper) != 0 && mc.level.getEntity(WrapperUtils.w(72331927741833L, wrapper)) != null) {
               ParticleOptions[] particles = this.W();
               int var16 = particles.length;
               int var17 = 0;
               if (0 < var16) {
                  ParticleOptions particle = particles[0];
                  int i = 0;
                  if (0 < this.友树何友树友树友友树.getValue().intValue()) {
                     WrapperUtils.S(mc.level.getEntity(WrapperUtils.w(72331927741833L, wrapper)), 80197125588742L, particle);
                     i++;
                  }

                  var17++;
               }
            }
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 46;
               case 1 -> 5;
               case 2 -> 16;
               case 3 -> 30;
               case 4 -> 27;
               case 5 -> 47;
               case 6 -> 3;
               case 7 -> 45;
               case 8 -> 29;
               case 9 -> 36;
               case 10 -> 12;
               case 11 -> 34;
               case 12 -> 7;
               case 13 -> 22;
               case 14 -> 2;
               case 15 -> 24;
               case 16 -> 41;
               case 17 -> 21;
               case 18 -> 60;
               case 19 -> 10;
               case 20 -> 0;
               case 21 -> 55;
               case 22 -> 39;
               case 23 -> 13;
               case 24 -> 53;
               case 25 -> 48;
               case 26 -> 37;
               case 27 -> 18;
               case 28 -> 8;
               case 29 -> 61;
               case 30 -> 11;
               case 31 -> 35;
               case 32 -> 50;
               case 33 -> 49;
               case 34 -> 42;
               case 35 -> 15;
               case 36 -> 56;
               case 37 -> 44;
               case 38 -> 4;
               case 39 -> 59;
               case 40 -> 31;
               case 41 -> 23;
               case 42 -> 25;
               case 43 -> 38;
               case 44 -> 19;
               case 45 -> 32;
               case 46 -> 1;
               case 47 -> 33;
               case 48 -> 58;
               case 49 -> 40;
               case 50 -> 20;
               case 51 -> 6;
               case 52 -> 17;
               case 53 -> 51;
               case 54 -> 57;
               case 55 -> 63;
               case 56 -> 9;
               case 57 -> 14;
               case 58 -> 54;
               case 59 -> 28;
               case 60 -> 62;
               case 61 -> 52;
               case 62 -> 26;
               default -> 43;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/何树树何何树树友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 17249;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/何树树何何树树友树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/何树树何何树树友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'D' && var8 != 254 && var8 != 210 && var8 != 'Y') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 212) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 235) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'D') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 254) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 210) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "B,f\u001d/lMl+\u0016%qH1 P-lE7$\u001bnjL2$P2fO&-\fnAD6<\u001b2@@/-\f!";
      j[1] = "B\u0015|ZY/I\u001am\u0015$7Z\u001dd\\";
      j[2] = "tG\u0011\u001e7R{\u0007\\\u0015=O~ZWS5Rs\\S\u0018vTzYSS*XyMZ\u000fv佨栆核佪伨桉栬叜核佪";
      j[3] = "\u0007\\&)\fh\b\u001ck\"\u0006u\rA`d\u0015f\bGmd\nj\u0014^&\u0004\u0016j\u0006Wz\u001c\u0002k\u0011W";
      j[4] = boolean.class;
      k[4] = "java/lang/Boolean";
      j[5] = "`\u0011r@|*k\u001ec\u000f\u00003d\u0004mL7\u0003r\u0013aQ&/e\u001e";
      j[6] = "\u0016 r'z7\u0019`?,p*\u001c=4jx7\u0011;0!;桉传厅厗休栄厓厾伛伉";
      j[7] = "\u0018\u0015C\"D\u000f\u0018\u0015T~H\u0000\u0002^Tc[\u0003X\u0000V~]\u000f\u0015\u001cR\u007f\u00076\u0017\u0002CeJ\n\u0013$N|L\u0015";
      j[8] = "i\u0010\u00105g]i\u0010\u0007ikRs[\u0007txQ)\u0005\u0005i~]d\u0019\u0001h$gn\u0018\u0014wodf\u0007\u0010riXb!\u001dko";
      j[9] = "ZF9O%QU\u0006tD/LP[\u007f\u0002<_U]r\u0002#SID9a%Z\\~v@?[";
      j[10] = "\u000ep>$%U\u0005\u007f/kD[\u000et+1";
      j[11] = "G\bZP\u0012U\u0019OMZ)E-\t\u0010\u0007\u0019\u0013Ag*\u0002\u0015\u0015FQL[N@\u0003";
      j[12] = "l{\t<Alh-GWW\u0011:v\t'\u0007,c!]1:";
      j[13] = "\u001e\r\u000eqM%F\u000e\u0018~1叛古桥桫反佬栁古伡桫\u000e\u000ftU\u001a\u0014|LyW@";
      j[14] = "A\\\r\u0011m9\u001f\u001b\u001a\u001bV)+]GFivB3}Cjy@\u0005\u001b\u001a1,\u0005";
      j[15] = "#\u001eduRG{\u001drz.厹栃伲叛栓叭档叙厬栁\n\u0014\u001ek\b}{\u0011\u0007\u007f\u0003";
      j[16] = "N\u0007YJ\u00013\u0010@N@:#$\u0006\u0013\u001d\u0005|Ch)\u0018\u0006sO^OA]&\n";
      j[17] = "[PD\u0015K\u001f\u0005\u0017S\u001fp\u000f1Q\u000eB@X^?4GL_Z\tR\u001e\u0017\n\u001f";
      j[18] = "S'u7>\u0018\r`b=\u0005\b9&?`:XQH\u0005e9XR~c<b\r\u0017";
      j[19] = "\u0001\r\u000b^93Y\u000e\u001dQE体校县厴佼历体校桥伪!\u007f\u007fQL\u0018M94\u0003\u0003";
      j[20] = "24\u001d}\u0019Lls\nw\"\\X5W*\u001d\f5[m/\u001e\f3m\u000bvEYv";
      j[21] = "o\u0012SOB?7\u0011E@>kVXVW\u0003z6\u0002L^^\u0002m\u001aH\rFb7\u0000AP>";
      j[22] = "R%ID&7\fb^N\u001d'8$\u0003\u0013\"xWJ9\u0016!wS|_Oz\"\u0016";
      j[23] = "%MI]FI{\n^W}YOL\u0003\nM\u000f(\"9\u000fA\t$\u0014_V\u001a\\a";
      j[24] = "&?:a*-xx-k\u0011=L>p6.n#PJ3-m'f,jv8b";
      j[25] = "`6Y\u001c_ >qN\u0016d0\n7\u0013K[obY)NX`aoO\u0017\u00035$";
      j[26] = "<\u0012\u0019k&\rbU\u000ea\u001d\u001dV\u0013S<\"M?}i9!M=K\u000f`z\u0018x";
      j[27] = "*\u0007?1JRt@(;qB@\u0006ufN\u0010*hOcM\u0012+^):\u0016Gn";
      j[28] = "\u0000yeCJL^>rIq\\jx/\u0014N\r\u0007\u0016\u0015\u0011M\f\u0001 sH\u0016YD";
      j[29] = "VA\u0002\u001d\ttWGO\u001a1压厩栾栦伮史桑桳古栦s\r.WI\u0007O\f(\u001aN";
      j[30] = ".5\u000e\u0003u6pr\u0019\tN&D4DTqt/Z~Qrv/l\u0018\b)#j";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private ParticleOptions[] W() {
      BetterCamera.e();
      String var4 = this.友友树树友何树友何树.getValue();
      byte var5 = -1;
      switch (var4.hashCode()) {
         case 67960595:
            if (!var4.equals("Flame")) {
               break;
            }

            var5 = 0;
         case 1852017554:
            if (!var4.equals("Critical Hit")) {
               break;
            }

            var5 = 1;
         case -455515669:
            if (!var4.equals("Enchanted Hit")) {
               break;
            }

            var5 = 2;
         case -1084044700:
            if (!var4.equals("Make Love")) {
               break;
            }

            var5 = 3;
         case 80009551:
            if (!var4.equals("Smoke")) {
               break;
            }

            var5 = 4;
         case 69599270:
            if (!var4.equals("Heart")) {
               break;
            }

            var5 = 5;
         case 80997281:
            if (!var4.equals("Totem")) {
               break;
            }

            var5 = 6;
         case 65203733:
            if (!var4.equals("Cloud")) {
               break;
            }

            var5 = 7;
         case 786076318:
            if (!var4.equals("Damage Indicator")) {
               break;
            }

            var5 = 8;
         case 430966332:
            if (!var4.equals("Sweep Attack")) {
               break;
            }

            var5 = 9;
         case -425600778:
            if (!var4.equals("Soul Fire Flame")) {
               break;
            }

            var5 = 10;
         case 55838914:
            if (var4.equals("End Rod")) {
               var5 = 11;
            }
      }
      return switch (var5) {
         case 0 -> new ParticleOptions[]{ParticleTypes.FLAME};
         case 1 -> new ParticleOptions[]{ParticleTypes.CRIT};
         case 2 -> new ParticleOptions[]{ParticleTypes.ENCHANTED_HIT};
         case 3 -> new ParticleOptions[]{ParticleTypes.HEART, ParticleTypes.WHITE_ASH, ParticleTypes.DRIPPING_WATER, ParticleTypes.BUBBLE_POP};
         case 4 -> new ParticleOptions[]{ParticleTypes.SMOKE};
         case 5 -> new ParticleOptions[]{ParticleTypes.HEART};
         case 6 -> new ParticleOptions[]{ParticleTypes.TOTEM_OF_UNDYING};
         case 7 -> new ParticleOptions[]{ParticleTypes.CLOUD};
         case 8 -> new ParticleOptions[]{ParticleTypes.DAMAGE_INDICATOR};
         case 9 -> new ParticleOptions[]{ParticleTypes.SWEEP_ATTACK};
         case 10 -> new ParticleOptions[]{ParticleTypes.SOUL_FIRE_FLAME};
         case 11 -> new ParticleOptions[]{ParticleTypes.END_ROD};
         default -> new ParticleOptions[0];
      };
   }

   @EventTarget
   public void T(AttackEvent event) {
      this.何树友友何友何树树何 = true;
   }

   private static String LIU_YA_FENG() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
