package cn.cool.cherish.module.impl.render;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.client.树友何何何树何树友友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import why.tree.friend.antileak.Fucker;

public class 树友树友何友何何友何 extends Module implements 何树友 {
   private final ModeValue 树何友友何何友何友树 = new ModeValue("Block Type", "方块类型", new String[]{"Ores", "Valuables"}, "Ores");
   private final NumberValue 何友何何树友树友何何 = new NumberValue("Range", "范围", 48, 16, 256, 4);
   private final NumberValue 何友友树何何树树树友 = new NumberValue("Scan Delay (ms)", "扫描延迟(毫秒)", 300, 0, 3000, 50);
   private final BooleanValue 何友友何树何何树树友 = new BooleanValue("Tracers", "连线", true);
   private final NumberValue 树何友友树何树友何树 = new NumberValue("MaxBlocks", "最大方块数", 80000, 10000, 500000, 10000);
   private final BooleanValue 树友何友树树友友友树 = new BooleanValue("Anti-Fake Ore", "防假矿物", true);
   private final NumberValue 友何树何何何何友树友 = new NumberValue("Min Auth Score", "最低验证分数", 1.0, 1.0, 15.0, 0.5);
   private final BooleanValue 友友何友何友何树何树 = new BooleanValue("Pattern Analysis", "模式分析", false);
   private final BooleanValue 友何友何友友何友友友 = new BooleanValue("Strict Host Rock Check", "严格主岩检查", true);
   private final BooleanValue 友树树树何树树树树友 = new BooleanValue("Blind Scan", "盲扫描", true);
   private final NumberValue 何树友友何何友友树何 = new NumberValue("Blind Scan Range", "盲扫描范围", 32, 8, 1024, 4);
   private final NumberValue 友友何树友友友友何树 = new NumberValue("Blind Render Range", "盲扫描渲染范围", 32, 8, 1024, 4);
   private final NumberValue 树友友何何友友何友树 = new NumberValue("Minimum Vein Size", "最小矿脉大小", 1, 1, 10, 1);
   private final BooleanValue 树树树何何友何何友友 = new BooleanValue("Diamond", "钻石", true);
   private final 树友何何树树何友友何 何何树树何何树树树何 = new 树友何何树树何友友何("Diamond Color", "钻石颜色", new Color(0, 255, 255));
   private final BooleanValue 树何树树何树友友友友 = new BooleanValue("Emerald", "绿宝石", true);
   private final 树友何何树树何友友何 何树友何何何何何树何 = new 树友何何树树何友友何("Emerald Color", "绿宝石颜色", new Color(0, 255, 0));
   private final BooleanValue 树何友友何树树树树友 = new BooleanValue("RedStone", "红石", true);
   private final 树友何何树树何友友何 树树何友友树树友何何 = new 树友何何树树何友友何("RedStone Color", "红石颜色", new Color(255, 0, 0));
   private final BooleanValue 友树友友树友友树何树 = new BooleanValue("Iron", "铁", true);
   private final 树友何何树树何友友何 树树友友树何何何树何 = new 树友何何树树何友友何("Iron Color", "铁颜色", new Color(210, 210, 210));
   private final BooleanValue 树友何树何树何友何树 = new BooleanValue("Gold", "金", true);
   private final 树友何何树树何友友何 树树树何树何友何友树 = new 树友何何树树何友友何("Gold Color", "金颜色", new Color(255, 215, 0));
   private final BooleanValue 树何友何友树友何友树 = new BooleanValue("Copper", "铜", true);
   private final 树友何何树树何友友何 友友树树何树树何友友 = new 树友何何树树何友友何("Copper Color", "铜颜色", new Color(205, 127, 50));
   private final BooleanValue 友友友何树何何友何树;
   private final 树友何何树树何友友何 友何何树友友何友树何;
   private final BooleanValue 何树友树友树树何何树;
   private final 树友何何树树何友友何 何树树何树树树树何友;
   private final BooleanValue 树友树何何树树何树友;
   private final BooleanValue 树树何树何何树何友友;
   private final BooleanValue 友何何树何何何何何树;
   private final 树友何何树树何友友何 树友友何友友友何树树;
   private final BooleanValue 树树友友树友友友树树;
   private final 树友何何树树何友友何 何何树友树何何友友友;
   private final BooleanValue 何友何树树友树树何友;
   private final 树友何何树树何友友何 树何何友何树友友友何;
   private final BooleanValue 树何友友树何何树何友;
   private final Map<BlockPos, Block> 树友何何何友何树何友;
   private volatile Map<BlockPos, Block> 树友何何何树树友树何;
   private long 树树树友何友何何树友;
   private boolean 树何友树何友何何树树;
   private final Map<树友树友何友何何友何.何树友何树何友友何树, BlockState> 友树友何何何树树何何;
   private final List<BlockPos> 友何树友友何树友树友;
   private final List<BlockPos> 友何何友友树何友树友;
   private long 友友树何友树友友树友;
   private boolean 友树树友树友友树树树;
   private Level 友树友树何树何友何何;
   private static ThreadPoolExecutor 何树友友何何友何友何;
   private volatile long 友友友友友友友友友树;
   private Matrix4f 树何何树何友树何何树;
   private Matrix4f 何树友友友何树何何何;
   private final Map<String, 树友树友何友何何友何.何何何树友何树何何何> 何树友树树何树树友树;
   private static final Direction[] 树友友友树友友何树何;
   private static final Set<Block> 何何树友何何树何树何;
   private static final Set<Block> 何树树友友树友友友友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final long m;
   private static final Object[] n = new Object[179];
   private static final String[] o = new String[179];
   private static String HE_DA_WEI;

   public 树友树友何友何何友何() {
      super("XRayPro", "矿物透视加强版", 树何友友何树友友何何.友友树树何友树树友树);
      BetterCamera.e();
      this.友友友何树何何友何树 = new BooleanValue("Lapis", "青金石", true);
      this.友何何树友友何友树何 = new 树友何何树树何友友何("Lapis Color", "青金石颜色", new Color(0, 0, 255));
      this.何树友树友树树何何树 = new BooleanValue("Coal", "煤", true);
      this.何树树何树树树树何友 = new 树友何何树树何友友何("Coal Color", "煤颜色", new Color(50, 50, 50));
      this.树友树何何树树何树友 = new BooleanValue("Quartz", "石英", true);
      this.树树何树何何树何友友 = new BooleanValue("Ancient Debris", "远古残骸", true);
      this.友何何树何何何何何树 = new BooleanValue("Spawner", "刷怪笼", true);
      this.树友友何友友友何树树 = new 树友何何树树何友友何("Spawner Color", "刷怪笼颜色", new Color(0, 85, 255));
      this.树树友友树友友友树树 = new BooleanValue("Cobblestone", "圆石", true);
      this.何何树友树何何友友友 = new 树友何何树树何友友何("Cobblestone Color", "圆石颜色", new Color(128, 128, 128));
      this.何友何树树友树树何友 = new BooleanValue("EndPortalFrame", "末地传送门框架", true);
      this.树何何友何树友友友何 = new 树友何何树树何友友何("EndPortalFrame Color", "末地传送门框架颜色", new Color(253, 0, 250));
      this.树何友友树何何树何友 = new BooleanValue("Full Box", "完整方框", true);
      this.树友何何何友何树何友 = new ConcurrentHashMap<>();
      this.树友何何何树树友树何 = null;
      this.树树树友何友何何树友 = 0L;
      this.树何友树何友何何树树 = false;
      this.友树友何何何树树何何 = new ConcurrentHashMap<>();
      this.友何树友友何树友树友 = new CopyOnWriteArrayList<>();
      this.友何何友友树何友树友 = new CopyOnWriteArrayList<>();
      this.友友树何友树友友树友 = 0L;
      this.友树树友树友友树树树 = false;
      this.友友友友友友友友友树 = 0L;
      this.何树友树树何树树友树 = new ConcurrentHashMap<>();
      Module.V(new Module[3]);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3964456452236333592L, 669941427351820554L, MethodHandles.lookup().lookupClass()).a(33563155301553L);
      // $VF: monitorexit
      a = var10000;
      c();
      Cipher var16;
      Cipher var26 = var16 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var17 = 1; var17 < 8; var17++) {
         var10003[var17] = (byte)(9541630840232L << var17 * 8 >>> 56);
      }

      var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var23 = new String[93];
      int var21 = 0;
      String var20 = "\u0089Ò\u0017Î{\u008aZÁ´é\u0092\u00800Ø\u008b%\u0010K4zN½Øp\u0090n_áÙD^DA\u0010£ï:ë:mºô[7Z(\\\u0087\u0015\u008a\u0010ó\u0013j\u0019í\u008a\u000bè\u0001,ÚñXÔ¹ø\u0010æ=¨\u0006[\u0013\u0013Í\u0086\t\u0006D\u008d\u000fzb0\u0093E7yÒó×.\fÉÔGÌÂ\b\u0018Òª:û\u0096©\u008d´\u0084\u0088kÐ\u0013\u0013{\u00999÷,{«9\tå}Ã=M5J\u0018h \u0083¨®\u0080¨\u0094s|± Z\u008cÉ^(\b\u0007\u0001\u0089 ¿\u00adÝ.\u0089ä\u0097\u0010é<\u00adæ \u0094Ú\u0082²k·ÌFH\u0019\u0094°ñ\u0087\tw(\u008f;Ýù6\u0015ÒWjH¬Ô]\u0001ö\u0018î¤\u0091Êf\u001fç\u0001\u0002ù'+´\u000bæ7\u0098RÙeC2\u0006B\u0010äW8´Í®ä©-i\u009fPWHgä\u0018z¢\u0015\u0004\u0011]º®èA\u0012\u0005n\u009fØ\u0096Ã}\nÂí\u0083\u0094\u0096\u0010ý£Ú\u0017ÿ\u009añÉn½D\u0002êt\u0002æ\u0018Phc\u0093Ø¸Ðþ°L¡b\u0013»}ø\u00adõ%¥ÔE\u001br($$\u0004Ô86z \u0018 +\u0085[U\u0093L¾ \u001bUH6Tehàv7H\u0087PÊþ©\u0012ÃÓÌâg\u0018çå@ÌÎ\u001b¡os\u0094©Ø\u0005ûh×\u0080R\u009d½¶ªû\\\u0010ãày{näëà%M\u0091\u0012\u000eD%p\u0010\u000bjkF\u001f÷ÏãÞ ¶V\u001bå§\u008f \u001bôì:L1b±ËÁëä\u0011=\u009d\f\u0080uQå\u0098Ï«\u0081í\u0015#\u0088úmO\u0082\u0010\u0086D¨»\u001e,L,¦çLhN-\u0005µ\u0010\u009eÇå\u008f\u001d\u0093#û¬|t\u008c\rDýI\u0018/\u0019³+P$nõ¡\u0018Ïî\u001a/s\u008a\u008d?4ÙP¢Y½ ðN^hÙ\u0001¤ÖàB<\u008då\u00160_Éõ_\u001eHÌ\rCm¦Sv\u0087cÍ\u001f oÄÊ\u0005\u0011\u0017ßÙH\u009fÌÿG\u0005\u001d¡´\u0081j^;s\u0010Ö;^\u0087\u0015}Ýw°0\u0010¶\u009f³6â¹îú¬£G\u0099Øð\u009e»\u009b7\u009c¥Ò;\u008ck\"+6\u0095\u0093ts@ë\u008cØ\u0006\u0017Rþza,\nüv\u0011Y Ò]û`ù;\u0095Õ\u0092\u001fTÌ.\u009d\u0007 k®Æï Õý°\u001cè\u0015m\u001f/\t- \u0083¯\u001fÉ6øKºÓ¶\r\u008c\u0092Õ6Õ\"\u0093+#7Q¬\u000b&yþ#v?æ~ \u0086\u001b\"Ó@\u0086|d\b$\u0014h¼~\tU\u0019~·\u0019Åm§Ñ2\u008d\u000bËÕG\u0085L\u0010\u0086»ó\u001aqý\nÔÓ\u0001ûê·\u001cÎ{(Å×2A×\u008fÛ¿fb¥t\u0007ª=Ëb\t_\t®\u0091Ë=]\r\u0005/*|Ò²Õ\u0014\u0004ô\u001b\u0015ù´(%nÛ4òñ\u0099Ó¯5ÈR\u0019\u0011®iÛâtÏÁg\u0003E7º{:êk\u00adÅð\u000eD\u009dj@ú\u00190\u0088¡óÃè«\u009b\u008d\u001fuèeÍ78hmanr-\u009evùëá\u0002áp\u0010è\u0012lÒÃ\u0090^Ö¼Ôu\u001eAÙÙþsÎ 4\u009bÿºº\u0089ÓYß'FõöI¡½\u0096I¼òR¿¸\u0006ð\u008a#å:a¤\" Ø\u001c°\bz7@ì\u0085?\u00ad\u0099»éOqæwo)éÈ)uýì9¦±ßÔx0Ú%\\0\u0000\u0094s\u008d/\u000b\u0096áä¬äÎç\u000eÖ¶ \u009f\u0019pt\u001bAStöóL°i¹ôR®aLoA\u0099Mé\u009a«\u00850än\u0014R÷\u0005àÕ3gIR¿ý\u001c\u0086¹ý\u0001\u0089\u001cxÓIÎÈ¶VB\u0080BI»#ûN\u0098\u0007Û\u001e\u0093?ÛG\u0089þ\u0082¡\u0010å}ä\\æ\u009c\u0018á¯Ùó½ [.ì\u0010êóÄ:\u0085Ù¯f\u0090`¾Î\u007f$qÇ(ÉX=õ9,Õôº\u008b¥8\u0019\fTë\u00859Ä\u008d;-\u0086\u008a6TÏ\u0015x\u0085ÇT¼\u0094Öí?²Ã\u001e XEµ·Ò\u008aSrqÄTV\u009b\u0012_\u0017ÅÓûlc\u007f\u0080ï\u007fv\u0018U±\u0005oU\u0010¹\"¦C#\u0097\u0083¨\tÒ\u008bÿÿ+óÚ(\u0093\u0080!Ú\u001b\u0086}\u0017\u008bÞlÓ;ºû\u0087¸e\u0081\t9Å3ª\t6|\u009a\u0013\u0097§\u0086×\u0087\u00195º\u008c!\u0085\u0018\u0081\t¸Öîò%âÚÐg\u0098ÛèS¯ê[_\u009bh\u0093\u0091ç ùÿ \u0004Ü\u0092ÚëMyù¸\u008cÃ|@\u0094Ã\u0081$¡\u0086\u0005ô?7\u0096\u0093\u008aNaú 8\u0095b;>\u0081vë¸÷I\u008cmQ\u000fÊâxLÔJsÑ¯\u008c!kÏ<ÏÍù ó>\u000b$\u0081¸âsá¥ù³Qu>tGÉÍ\f ð\u0016\u008eÌ ¹WmßÀ\u0086\u0018ë\u0015À\u0088\u001cQ\u0081Ë\u000bÉù¯È>\u009d\u0016;â\n\u0089\u0085N\u0087ë \u0084´t`}\u0093\u000fUY\u001e:qÖ\u0010ð~ã\u0004\u0083Õ O¦\u0089IM\u009eL¢{ÅÊ §3\u0086A\u0002\u0093>\u0094ådÍB\fS¯CÂ®*´+¤¯\u0089d\u0088¾Ã\u0097\u009bÖU\u0018Ïì\u0011=Hé¨zÇ\u0094ñE[\u0004\u00ad(äÍE\u0089=\u008fà¬\u00182\u0080åÆÓGÝÂ[=\u0004\u0000\u0093\u0093ü]¬\u0018ÔzÛ0\u001cÎ\u0010³ñ\u009bRËÉ\u0018 \u0090\u008d\u0091!Sâ\t\u0013\u0018\u001aÙ«jF¦õI\u0085õÛ\u0084Ã\u009f¿QRD\u001etºÚË\u0002 \u008f¢ÿÕÇ2\u00ad}\u001f8¶ÓM\u009d\u0093ù¾gíP\u0003ëZ÷\u0002m`²¢\u001b6\u008d\u0018ï\u0083z\u0004Ãkíy\u0089\u0007±EÖØÓø]af\u0007{¥Z¹\u0018êò\u0080óÕª\u008bÀ\u0080ÞÙ\\èle\u0017\u001dj»Ù\u0085k?  Þ\u0013³\u000e«V´\u0000~\u008c\u0093£\u0010i\u001aÁÀÖ´Æ¬l¼Ñíq\u008cj¸^íÏ âhq\u0019Q)?á\u0096×ô&O\u0082\u000eµy¯ÆþM\u000b`1\u009aDÌnL\u0010\u008e\u0007\u0010u\u0010\u00158·\u0001\u008c%UNö\n\u000fÙµ\u0086\u0010\u000f\u0005·Ò\u0093\u009a2ªÊê\nV»\u0090\u0092\u0090\u0018\u0091à\u008dó\u0001LËÄ\u0081ã\u009fOô;µ?¶W\u009d½ßÖõ\u009d\u0010\\6ìÿß\u0003ÒS\u0012åAà\u0000±;æ \u009d.±Z %\u0019\u0099\u0093\u0094\u0088MI0ý¡\u00871Y3zñ6êVX;91ä\u00197\u0010ÅÉß\u008c¦ºñú$K®Q°°vÅ ar¼.\u0087ùà:/O¯9\n\u0098Y\u0006Ás\u0007ñh~å¨E\r½s/C\u0016õ\u0018\u00819\u0011q\u0094O\u0013Hb<AÍûÅjóÈ\"\u0088¨yâ\u009f\u0081(0`X%d5±\u0091\u0090CÜqAà¥û\u0082àzvÌ\u0093\fBf°ff=UO°«Ts\u0090\u00140\u0088Ø \u0090Õ¤T\u0085Qß¶X0À\u0001Æâ\u000e\u0000êé\u0096\u009ftÖ\u0086Züq0»F\u00167¸(²ì×\u000e6³\u0090C\u009c °\u007fÛ\u0010Ì\u0098®Ð\u0086½@;¾5dôj\u0003f«F¬Õ6\u0098ýÝ\"z\f(ävqµ,¶\u009f\u0003\u008f>H\u0015h\u0010\u008c§¿IíÖ\u008e¶óÔX»¼±âIh7\u008bgå\u0094Sd¤ò\u0010õ\\ºË¼\u008f©aÁ\u001bEç»\u0017ªè Ò&\u001eq\u0001Sñ=\u000f\u0085h\u0084Î\u0090ã~2£@*Kßa·Ëroó\u001b×\u0092\u0013 ûh\u0098\bÆ£`sÂçÛæJJë\u0012÷=7\u0095qlÉ,Éó¸þ\u0010×OC\u0018Ó4\u0096\u0010B«|y¥Õu·\u0000²Æ¤XÊíC«Ú\u0000ª\u00108\u0098ø×CÍva\nðºû\u0011}ä\u0084 ÊÊ\u0097ï°ò\u0084áw\u0090p\u0006\u0097*½ÐÏ\u0007¸\nXvYq°û¼ldö\u0011*\u0010\u008c\u0013\u0096Ú4²ó\u0096¥êoÎÕÐ\"ç\u0010\u0019µH$Ã5ýcêmÜ|[x°\u008f\u0010ª¬|éW¯[\u001fr®ü'd¹T+\u0010D4\u0097\u0082Îõ\u0096+©¨tæu}$Ö(k\u0099¯\f7ÍØ|ÿ@rõË¨@@Ê\u0093c\u0095\u001fÝÒä:ÀãÐÎ\u000f\u009d+Ë4\u0092nÑ\u0097½m\u0010m¨A\u008eÕh³ûx\u008f=R\u0012à\u001eµ V¡Ô\u009c\u0096\u001a{\u008d\u0080\u0016\u00114ì\u0004â\u009cz\u008aþ§Óª¥}&6\u00adL\u0097sZm\u0010à\u0082\u0019Êé\u0013Ì%h\u009fÊÅ¶0b?\u0010îå×\u000eè\u0000}\u0087Ç\u0004õlÆ«\t\u009b m&\u0080/\u000eûv\u009c\u0013;_fÆ\u0097É&'\u001al_Ð!\u007f è\u0087\u0086ä\u0003äyä\u0010,Ê¿\u0005\u009d½Åß4\u001e\u0083\"Rõu« ¿ÆuY\u0091\"v\u0010\u0003xYo (Âüc\u0080uBÌÍ\u000e3\t\u008a\u0091Ó\u0090u\u0084m\u0010f¦ôÑ¤ì\u0084IàÉ\u0089\fàñQq0¨y\u008e\u008d1x\u0003õÛx\u0097E«#æ&\u000f)×\u009eh#}>LªT=4J`(\u0089äeÎ\u0012×Ý~\u0002°ê\u008d\u000bÜÓµ\u0018\u000bÕÓ\u0082¾m¡AÊ@Ð=~\u009a\u0094ö\u0017[ÄíDÀIá\u0010d½ã¹Ö\u0018£\u0006Y²òÈpÔ-\u001e";
      short var22 = 2530;
      char var19 = 16;
      int var25 = -1;

      label56:
      while (true) {
         String var27 = var20.substring(++var25, var25 + var19);
         int var10001 = -1;

         while (true) {
            String var38 = c(var16.doFinal(var27.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var23[var21++] = var38;
                  if ((var25 += var19) >= var22) {
                     c = var23;
                     h = new String[93];
                     l = new HashMap(13);
                     Cipher var5;
                     Cipher var29 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(9541630840232L << var6 * 8 >>> 56);
                     }

                     var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[2];
                     int var8 = 0;
                     byte var7 = 0;

                     do {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = "æ,5÷\u001dÚ¡\u0001Ã9ø±C©Ñ\u001b".substring(var10001, var7).getBytes("ISO-8859-1");
                        var10001 = var8++;
                        long var13 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        byte[] var15 = var5.doFinal(
                           new byte[]{
                              (byte)(var13 >>> 56),
                              (byte)(var13 >>> 48),
                              (byte)(var13 >>> 40),
                              (byte)(var13 >>> 32),
                              (byte)(var13 >>> 24),
                              (byte)(var13 >>> 16),
                              (byte)(var13 >>> 8),
                              (byte)var13
                           }
                        );
                        long var10004 = (var15[0] & 255L) << 56
                           | (var15[1] & 255L) << 48
                           | (var15[2] & 255L) << 40
                           | (var15[3] & 255L) << 32
                           | (var15[4] & 255L) << 24
                           | (var15[5] & 255L) << 16
                           | (var15[6] & 255L) << 8
                           | var15[7] & 255L;
                        byte var45 = -1;
                        var11[var10001] = var10004;
                     } while (var7 < 16);

                     j = var11;
                     k = new Integer[2];
                     Cipher var0;
                     Cipher var30 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(9541630840232L << var1 * 8 >>> 56);
                     }

                     var30.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-63, -9, -97, -73, -46, 124, -115, 97});
                     long var43 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     byte var36 = -1;
                     m = var43;
                     树友友友树友友何树何 = Direction.values();
                     何何树友何何树何树何 = Set.of(
                        Blocks.STONE,
                        Blocks.ANDESITE,
                        Blocks.DIORITE,
                        Blocks.GRANITE,
                        Blocks.DEEPSLATE,
                        Blocks.TUFF,
                        Blocks.CALCITE,
                        Blocks.DIRT,
                        Blocks.GRASS_BLOCK,
                        Blocks.PODZOL,
                        Blocks.MYCELIUM,
                        Blocks.GRAVEL,
                        Blocks.DRIPSTONE_BLOCK,
                        Blocks.SAND,
                        Blocks.SANDSTONE,
                        Blocks.RED_SAND,
                        Blocks.RED_SANDSTONE
                     );
                     何树树友友树友友友友 = Set.of(Blocks.NETHERRACK, Blocks.BASALT, Blocks.BLACKSTONE, Blocks.SOUL_SAND, Blocks.SOUL_SOIL);
                     return;
                  }

                  var19 = var20.charAt(var25);
                  break;
               default:
                  var23[var21++] = var38;
                  if ((var25 += var19) < var22) {
                     var19 = var20.charAt(var25);
                     continue label56;
                  }

                  var20 = "rô§xö/9\u0011 ¦º°\u000b\u0016²¼Iÿ=ßt\u008dóUÄCiP\u009deà\u0002\u0018ì¥|9°\u0005òí °n\u0087Zø\u0012¨\u008ca\u0084Â\u009e¨¾\b";
                  var22 = 57;
                  var19 = ' ';
                  var25 = -1;
            }

            var27 = var20.substring(++var25, var25 + var19);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void B(Render2DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L})
         && (Boolean)Fucker.isLogin
         && (Boolean)Fucker.isBeta
         && (!this.树友何何何友何树何友.isEmpty() || !this.友树友何何何树树何何.isEmpty())
         && this.何友友何树何何树树友.getValue()
         && this.树何何树何友树何何树 != null
         && this.何树友友友何树何何何 != null) {
         this.N(event.poseStack());
      }
   }

   private Set<BlockPos> B(BlockPos playerPos) {
      BetterCamera.e();
      HashSet reachableAir = new HashSet();
      Queue<BlockPos> queue = new LinkedList<>();
      int maxBlocksToScan = this.树何友友树何树友何树.getValue().intValue();
      if (this.c(playerPos) && reachableAir.add(playerPos)) {
         queue.add(playerPos);
      }

      BlockPos headPos = playerPos.above();
      if (this.c(headPos) && reachableAir.add(headPos)) {
         queue.add(headPos);
      }

      if (queue.isEmpty()) {
         Direction[] current = 树友友友树友友何树何;
         int var11 = current.length;
         int var12 = 0;
         if (0 < var11) {
            Direction dir = current[0];
            BlockPos neighbor = playerPos.relative(dir);
            if (this.c(neighbor) && reachableAir.add(neighbor)) {
               queue.add(neighbor);
            }

            var12++;
         }
      }

      if (!queue.isEmpty() && reachableAir.size() < maxBlocksToScan) {
         BlockPos current = queue.poll();
         Direction[] var17 = 树友友友树友友何树何;
         int var19 = var17.length;
         int var20 = 0;
         if (0 < var19) {
            Direction dir = var17[0];
            BlockPos neighbor = current.relative(dir);
            if (this.c(neighbor) && reachableAir.add(neighbor)) {
               queue.add(neighbor);
            }

            var20++;
         }
      }

      return reachableAir;
   }

   private boolean C(List<BlockPos> positions) {
      BetterCamera.e();
      if (positions.size() <= 1) {
         return true;
      } else {
         Set<BlockPos> allPositions = new HashSet<>(positions);
         Set<BlockPos> visited = new HashSet<>();
         Queue<BlockPos> queue = new LinkedList<>();
         BlockPos startNode = positions.get(0);
         queue.add(startNode);
         visited.add(startNode);
         if (!queue.isEmpty()) {
            BlockPos current = queue.poll();
            Direction[] var10 = Direction.values();
            int var11 = var10.length;
            int var12 = 0;
            if (0 < var11) {
               Direction dir = var10[0];
               BlockPos neighbor = current.relative(dir);
               if (allPositions.contains(neighbor) && !visited.contains(neighbor)) {
                  visited.add(neighbor);
                  queue.add(neighbor);
               }

               var12++;
            }
         }

         return visited.size() == positions.size();
      }
   }

   private Set<Block> D(Block block) {
      BetterCamera.e();
      if (block == null) {
         return Collections.emptySet();
      } else if (Set.of(Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE).contains(block)) {
         return Set.of(Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE);
      } else if (Set.of(Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE).contains(block)) {
         return Set.of(Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE);
      } else if (Set.of(Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE).contains(block)) {
         return Set.of(Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE);
      } else if (Set.of(Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE).contains(block)) {
         return Set.of(Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE);
      } else if (Set.of(Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE).contains(block)) {
         return Set.of(Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE);
      } else if (Set.of(Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE).contains(block)) {
         return Set.of(Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE);
      } else if (Set.of(Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE).contains(block)) {
         return Set.of(Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE);
      } else if (Set.of(Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE).contains(block)) {
         return Set.of(Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE);
      } else if (block == Blocks.ANCIENT_DEBRIS) {
         return Set.of(Blocks.ANCIENT_DEBRIS);
      } else {
         return block == Blocks.NETHER_QUARTZ_ORE ? Set.of(Blocks.NETHER_QUARTZ_ORE) : Collections.emptySet();
      }
   }

   private Set<Block> J() {
      BetterCamera.e();
      HashSet targets = new HashSet();
      if (this.何树友树友树树何何树.getValue()) {
         targets.add(Blocks.COAL_ORE);
         targets.add(Blocks.DEEPSLATE_COAL_ORE);
      }

      if (this.树何友何友树友何友树.getValue()) {
         targets.add(Blocks.COPPER_ORE);
         targets.add(Blocks.DEEPSLATE_COPPER_ORE);
      }

      if (this.友树友友树友友树何树.getValue()) {
         targets.add(Blocks.IRON_ORE);
         targets.add(Blocks.DEEPSLATE_IRON_ORE);
      }

      if (this.树友何树何树何友何树.getValue()) {
         targets.add(Blocks.GOLD_ORE);
         targets.add(Blocks.DEEPSLATE_GOLD_ORE);
         targets.add(Blocks.NETHER_GOLD_ORE);
      }

      if (this.友友友何树何何友何树.getValue()) {
         targets.add(Blocks.LAPIS_ORE);
         targets.add(Blocks.DEEPSLATE_LAPIS_ORE);
      }

      if (this.树树树何何友何何友友.getValue()) {
         targets.add(Blocks.DIAMOND_ORE);
         targets.add(Blocks.DEEPSLATE_DIAMOND_ORE);
      }

      if (this.树何友友何树树树树友.getValue()) {
         targets.add(Blocks.REDSTONE_ORE);
         targets.add(Blocks.DEEPSLATE_REDSTONE_ORE);
      }

      if (this.树何树树何树友友友友.getValue()) {
         targets.add(Blocks.EMERALD_ORE);
         targets.add(Blocks.DEEPSLATE_EMERALD_ORE);
      }

      if (this.树友树何何树树何树友.getValue()) {
         targets.add(Blocks.NETHER_QUARTZ_ORE);
      }

      if (this.树树何树何何树何友友.getValue()) {
         targets.add(Blocks.ANCIENT_DEBRIS);
      }

      if (this.友何何树何何何何何树.getValue()) {
         targets.add(Blocks.SPAWNER);
      }

      if (this.树树友友树友友友树树.getValue()) {
         targets.add(Blocks.COBBLESTONE);
      }

      if (this.何友何树树友树树何友.getValue()) {
         targets.add(Blocks.END_PORTAL_FRAME);
         targets.add(Blocks.END_PORTAL);
         targets.add(Blocks.END_GATEWAY);
      }

      return targets;
   }

   private List<BlockPos> J(BlockPos startPos, Block oreType, Set<BlockPos> processedBlocks) {
      BetterCamera.e();
      List<BlockPos> vein = new ArrayList<>();
      LinkedList queue = new LinkedList();
      Set<BlockPos> veinVisited = new HashSet<>();
      if (processedBlocks.contains(startPos)) {
         return vein;
      } else {
         queue.add(startPos);
         veinVisited.add(startPos);
         if (!queue.isEmpty() && vein.size() < 64) {
            BlockPos currentPos = (BlockPos)queue.poll();
            vein.add(currentPos);
            Direction[] var12 = 树友友友树友友何树何;
            int var13 = var12.length;
            int var14 = 0;
            if (0 < var13) {
               Direction dir = var12[0];
               BlockPos neighbor = currentPos.relative(dir);
               if (!processedBlocks.contains(neighbor)
                  && !veinVisited.contains(neighbor)
                  && mc.level.isLoaded(neighbor)
                  && this.Y(mc.level.getBlockState(neighbor).getBlock(), oreType)) {
                  veinVisited.add(neighbor);
                  queue.add(neighbor);
               }

               var14++;
            }
         }

         return vein;
      }
   }

   private void V(PoseStack poseStack, AABB box, Color color) {
      float r = color.getRed() / 255.0F;
      float g = color.getGreen() / 255.0F;
      float b = color.getBlue() / 255.0F;
      float minX = (float)box.minX;
      float minY = (float)box.minY;
      float minZ = (float)box.minZ;
      float maxX = (float)box.maxX;
      float maxY = (float)box.maxY;
      float maxZ = (float)box.maxZ;
      Matrix4f matrix = poseStack.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      BufferUploader.drawWithShader(buffer.end());
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (o[var4] != null) {
         return var4;
      } else {
         Object var5 = n[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 13;
               case 1 -> 24;
               case 2 -> 27;
               case 3 -> 7;
               case 4 -> 30;
               case 5 -> 33;
               case 6 -> 17;
               case 7 -> 53;
               case 8 -> 16;
               case 9 -> 39;
               case 10 -> 44;
               case 11 -> 35;
               case 12 -> 9;
               case 13 -> 62;
               case 14 -> 46;
               case 15 -> 1;
               case 16 -> 57;
               case 17 -> 12;
               case 18 -> 31;
               case 19 -> 58;
               case 20 -> 2;
               case 21 -> 50;
               case 22 -> 29;
               case 23 -> 41;
               case 24 -> 36;
               case 25 -> 8;
               case 26 -> 4;
               case 27 -> 3;
               case 28 -> 15;
               case 29 -> 6;
               case 30 -> 49;
               case 31 -> 60;
               case 32 -> 18;
               case 33 -> 28;
               case 34 -> 14;
               case 35 -> 45;
               case 36 -> 10;
               case 37 -> 22;
               case 38 -> 59;
               case 39 -> 55;
               case 40 -> 11;
               case 41 -> 26;
               case 42 -> 34;
               case 43 -> 38;
               case 44 -> 54;
               case 45 -> 52;
               case 46 -> 23;
               case 47 -> 32;
               case 48 -> 42;
               case 49 -> 61;
               case 50 -> 48;
               case 51 -> 51;
               case 52 -> 20;
               case 53 -> 25;
               case 54 -> 21;
               case 55 -> 19;
               case 56 -> 0;
               case 57 -> 56;
               case 58 -> 40;
               case 59 -> 63;
               case 60 -> 5;
               case 61 -> 43;
               case 62 -> 37;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            o[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树友树友何友何何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24427;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友树友何友何何友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u0083Ïy\b\u009f¹]), |\u008eå`cÎM\u0094, \u0087Øç\u0098¦\t\u0092\u001f, Njb\u0094Ú´¸å, V\u0086;µ\u0086#.[, êiß²å¢9ç¿«\\£¼}\u009fD\u008eCÐv$\u0090Ññ, \u0090|´?ë¡\u007f¿t\u009aaõD\u007fÌ¿, h§¿ü¦\u0085Ù\u001c\u0013\u0000×[\u0010\u0002e4, w.Ufj\u00966n¬\u001aZ\u001atE)¿, \u0007ëB3\u0090)X\u0083, 3¼\u0011qh\u0019Í\u0092®k´\u00948Tâ>, c±^\u001e\u0085ùO\u0018, =å\u0086)ÙL\u0018\b34½\u000f®=º\u001c, :")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private Vector3f x(float cX, float cY, float tX, float tY, float sW, float sH) {
      BetterCamera.e();
      float dX = tX - cX;
      float dY = tY - cY;
      if (Math.abs(dX) < 1.0E-6 && Math.abs(dY) < 1.0E-6) {
         return new Vector3f(cX, cY, 0.0F);
      } else {
         float scale = Float.MAX_VALUE;
         if (dX > 0.0F) {
            scale = Math.min(Float.MAX_VALUE, (sW - cX) / dX);
         }

         if (dX < 0.0F) {
            scale = Math.min(scale, -cX / dX);
         }

         if (dY > 0.0F) {
            scale = Math.min(scale, (sH - cY) / dY);
         }

         if (dY < 0.0F) {
            scale = Math.min(scale, -cY / dY);
         }

         return new Vector3f(cX + scale * dX, cY + scale * dY, 0.0F);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 216 && var8 != 252 && var8 != 224 && var8 != 'D') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 193) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 202) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 216) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 252) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 224) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private boolean c(BlockPos pos) {
      BetterCamera.e();
      if (mc.level == null) {
         return false;
      } else {
         Block block = mc.level.getBlockState(pos).getBlock();
         return block.defaultBlockState().isAir() || block == Blocks.WATER || block == Blocks.LAVA || block == Blocks.CAVE_AIR || block == Blocks.VOID_AIR;
      }
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树友树友何友何何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void c() {
      n[0] = "\"<3\u0016xf-|~\u001dr{(!u[zf%'q\u00109`,\"q[el/6x\u00079K$&i\u0010eJ ?x\u0007v";
      n[1] = "w\u0012\fwvR|\u001d\u001d8\u000bJo\u001a\u0014q";
      n[2] = "\u001d\u0017\\48\\\u0012W\u0011?2A\u0017\n\u001ay:\\\u001a\f\u001e2yZ\u0013\t\u001ey%V\u0010\u001d\u0017%y栢厵桨厹伂厜佦伫厲伧";
      n[3] = "f\u0000V`\b\u0014m\u000fG/c\u0000o\u0004PuO\u0017b";
      n[4] = "yi6Djkv){O`vstp\tsevr}\tlijk6栶収佑住栖栉佲収叏住";
      n[5] = "\u0011}!(!r\u0011}6t-}\u000b6\"i>w\u001b69c:~\u001367j#x\u00146\u0017j#x\u0014k";
      n[6] = "M~6\u001aE-M~!FI\"W55[Z(G5.Q^!O5 XG'H5\u0000XG'H";
      n[7] = "AHQ\u0016RQ_@KY/A_";
      n[8] = "QUEn5UgpEn\"\tk\u007f_%\"\u0014x|\u0005O(\toz_b.\u00151";
      n[9] = "\u0012vpPZ\u0013\f~j\u001f9\u0007\b";
      n[10] = "\u0002\u0011V|v\u0006\u001c\u0019L3\u0014\u001a\u001b\u0004";
      n[11] = "\u0001\t1+\\J\u000eI| VW\u000b\u0014wfED\u000e\u0012zfZH\u0012\u000b1\n\\J\u000e\u0002~&eD\u000e\u0012z";
      n[12] = "\u00132To~=\u001cr\u0019dt \u0019/\u0012\"g3\u001c)\u001f\"x?\u00000TBd?\u00129\bZp>\u00059";
      n[13] = "\u0019+W\u0007n8\u0019+@[b7\u0003`@Ej4\u0019:\rdj?\u0012-QHe%";
      n[14] = "\u0014P3:\bn\u0014P$f\u0004a\u000e\u001b$x\fb\u0014Aif\u0000i\u001eP5q\u0017)=T*q7b\u0014Q\"f\u0000u";
      n[15] = "CSxu<VJ]{<\u007f[L]o>b]\u000eJp)%\\X\u0012C>#MEDS4#TAH1\u0016>]E";
      n[16] = "Rt\u0019>[}[z\u001aw\u0018p]z\u000eu\u0005v\u001fm\u0011bBwI50uPsDw\u0000FS`E~\fVY`\\z\u0000";
      n[17] = "\u0016>ajA<\u001f0b#\u00021\u00190v!\u001f7['i6X6\r\u007fZ!^'\u0010)J+^>\u0014%";
      n[18] = "mn@E`\u0006mnW\u0019l\tw%W\u0007d\nm\u007f\u001a\u0019h\u0001gnF\u000e\u007fAOnB\u000ea=feP\u000e\u007f\nq";
      n[19] = "_2~\u001abDA:dU/^[0}\t>T['&/$CP2l+#^Y\u0016p\u001e/DA<z";
      n[20] = "b~xp\u0002]``1\b\rQycmm\u000e";
      n[21] = float.class;
      o[21] = "java/lang/Float";
      n[22] = "P\u0019dp\b__Y){\u0002BZ\u0004\"=\u0011Q_\u0002/=\u000e]C\u001bd^\bTV!+\u007f\u0012U";
      n[23] = "Xr\u0018o\b\u0004Xr\u000f3\u0004\u000bB9\u001b.\u0017\u0001R9\u001c)\u001c\u001e\u0018A\t\"V";
      n[24] = double.class;
      o[24] = "java/lang/Double";
      n[25] = "&Io\u0013${$W&p/`;Rp\t(";
      n[26] = long.class;
      o[26] = "java/lang/Long";
      n[27] = "\u000e.UT3D\u0001n\u0018_9Y\u00043\u0013\u00191D\t5\u0017Rrf\u0002$\u000e[9";
      n[28] = "bl3Ov$VO<\u000f;/\\R9R0iTO4T4\"\u0017m?E-+\\\u001b";
      n[29] = ";a!2\u000f\"\u000fB.rB)\u0005_+/Io\rB&)M$N`-8T-\u0005\u0016";
      n[30] = void.class;
      o[30] = "java/lang/Void";
      n[31] = boolean.class;
      o[31] = "java/lang/Boolean";
      n[32] = "w6mrJDxv y@Y}++?HDp-/t\u000b栺佁厓厈佄栴叠叟伍伖";
      n[33] = "t^*!r_{\u001eg*xB~Cllp_sEh'3Yz@hloUyTa03校叜校叏众取佥佂叻佑f佈佥佂校叏众栌佥佂佥";
      n[34] = "{C.0D\n{C9lH\u0005a\b-q[\u000fq\b6{_\u0006y\b\u0016{_\u0006y";
      n[35] = "yh\u0001(!ryh\u0016t-}c#\u0002i>ws#\u0005n5h9L4D\u000e";
      n[36] = "t\fao5b{L,d?\u007f~\u0011'\"7bs\u0017#itdz\u0012#\"(hy\u0006*~t栜叜桳厄余厑佘佂厩会(桋栜栆厩会叇伏佘栆厩";
      n[37] = "P,l4eu[#}{\u0004{P(y!";
      n[38] = "g'Ri[N~wM*!\u001bWv\u0018o\u0010OWFB<[\u0018f=]'_M";
      n[39] = "vRWR\u001c\u0012?J[Ss桧厌佽句栻桪厽厌口栿\"CE?EWI\u0016\u001frO";
      n[40] = "cn\u0014D;%*v\u0018ET桐伇叟厦栭伉桐厙佁桼4d3k\"\u001eMi6#y";
      n[41] = "]1\u0005s\u007ff\u0014)\tr\u0010cdy\u0014d`c\u0018#\ng{\n^#\u0013syv\u0004=\u0010h\u0010";
      n[42] = "d#E<\u0011 -;I=~休厞伌佩桕厽桕厞伌佩LN6loO5C3$4";
      n[43] = "a\u001a+u\u0017]!\b7tiK\rUw(V\u001e\rhstRD'R5*\u000e@";
      n[44] = "Z\u0007k|\bF\u001a\u0015w}vP6I>)G\u00046u3}M_\u001cOu#\u0011[";
      n[45] = "a,av\u000fh!>}wq~\rb4#@-\r^9wJq'd\u007f)\u0016u";
      n[46] = "#5Cr=(j-OsR伙栃桞佯栛桋桝栃会叱\u0002h8k~Y~j+&,";
      n[47] = "d.\u0007 O(-6\u000b! 厇伀桅伫伍佽伙厞桅厵P\u0010>lb\r)\u001d;$9";
      n[48] = "\u0011Ig\u001e;%XQk\u001fT伔栱栢叕厭桍厊叫司叕nir\u0018T{\u0011m#Y\u0006";
      n[49] = "_-\u000e\u0015\u000fL\u001f?\u0012\u0014qZ3bRIO\u00053_V\u0014JU\u0019e\u0010J\u0016Q";
      n[50] = "}~C\u00186|sl]_YB\u001cl^\u001a4u$5\f\u0019`\u0010";
      n[51] = ".\u001d1X\u0013\u007fg\u0005=Y|叐栎桶桙併桥栊栎桶厃(L(g\n1C\u0019r*\u0000";
      n[52] = "2r:n\u007f?4aj3\u0012厕伈栚伉桋住桏厖佞桍Rr?/n2)m$+;";
      n[53] = "6J3\rV<vX/\f(*Z\u0005oQ\u0015uZ8k\f\u0013%p\u0002-RO!";
      n[54] = "pS-\u0019~:9K!\u0018\u0011伋伔核原伴佌桏伔核企i,myN1\u0016(<8\u001c";
      n[55] = "?8#)W\\4b /.z\u000b\u0014\t\u001d.J3;*?QAi8,";
      n[56] = "u(\t|\u001c>5:\u0015}b(\u0019gU#Yz\u0019ZQ}Y'3`\u0017#\u0005#";
      n[57] = "Q\u0010*m\u0014\u0002\u0011\u00026lj\u0014=_v5[A=brlQ\u001b\u0017X42\r\u001f";
      n[58] = "\\ZR\u001d\u0003b\u0015B^\u001cl体厦叫栺估伱栗桼栱叠m\\tT\u0016X\u0014Qq\u001cM";
      n[59] = "\u0002;\f\u0011S_B)\u0010\u0010-IntPM\u0014\u0019nIT\u0010\u0016FDs\u0012NJB";
      n[60] = "I<\u0001]Z+\t.\u001d\\$=%wX\u0003\u0019kO\u0019e\u0005Ah\u00133_C\u001f4\u0017";
      n[61] = "<,3\u0019$Du4?\u0018K叫佘桇厁厪伖栱叆桇厁itI<&%\u0015:Wd ";
      n[62] = "Z\u0002_\u001b#&\u0013\u001aS\u001aL桓厠伭佳伶桕桓厠桩佳kr5\u0002\u0017\u0011\u0012r \u0011N";
      n[63] = "\u001eUAp\u0011E^G]qoSr\u001e\u0018.R\u0000\u001dp%(\n\u0006DZ\u001fnTZ@";
      n[64] = "`\u000eX @\u000b \u001cD!>\u001d\fA\u0004z\u0003I\f|\u0000!\u0005\u0012&FF\u007fY\u0016";
      n[65] = "w{\u000fu1Un+\u00106K\u0000G*EszVG\u001a\u001f 1\u0003va\u0000;5V";
      n[66] = "G\u0006b_Z^M\fm\u0001;核栻伪栋厬佦佼使厴栋o^PRGs\u0010TZ]\u0019";
      n[67] = "l$q!^.f.~\u007f?伌栐厖参佌叼伌栐桌作\u0011Z ye`nP*v;";
      n[68] = "\u0010\u000bg{7?P\u0019{zI)|D;%tw|y?zr&VCy$.\"";
      n[69] = "l/\u001e?2\u0004,=\u0002>L\u0012\u0000`Bar@\u0000]F>w\u001d*g\u0000`+\u0019";
      n[70] = "n6^{\u0007-.$Bzy;\u0002y\u0002&Co\u0002D\u0006zB4(~@$\u001e0";
      n[71] = "K:\n\u000fm=\u000b(\u0016\u000e\u0013+'qSQ/{A\u001fnWv~\u00115T\u0011(\"\u0015";
      n[72] = "\u0001s6.O\u0006Hk:/ 桳佥参厄伃佽厩佥参桞^N\bW`|1I\n\u0006:";
      n[73] = "L\u0000o\u0017y}\u0005\u0018c\u0016\u0016叒厶桫佃厤栏叒厶桫叝gwvIL~Wv/DJ";
      n[74] = "\u0017;)\u001eqL^#%\u001f\u001e根佳伔厛伳标口叭厊伅n$\\_p3\u0012&O\u0012\"";
      n[75] = "\"}_r\u0001jkeSsn佛栂双样叁桷栟但佒样\u0002^=kj_i\u000bg&`";
      n[76] = "\u0000&g\b'-@4{\tY;li;UbjlT?\tb4FnyW>0";
      n[77] = "Ly\u001b\u000bus\fk\u0007\n\u000be 6GW;6 \u000bC\n0j\n1\u0005Tln";
      n[78] = "BqV0c\u0017\u0019i\u00172\u0012C$!\u0010q,\u0016$\u0010@rrT\u000f+\u0016-s\u001c";
      n[79] = ",\u0018D*M/\"\nZm\"\u001dM\nY(O&uS\u000b+\u001bC.\u0017WgE12W\u0005.\"";
      n[80] = "Jq~e8<\u0003irdW伍厰佞栖栌厔桉桪佞双\u0015gk\u0003f~~21Nl";
      n[81] = "\u0005\\v_&O\u000fU}\u0000\u001c\u00108\u0003'Q%C83q\r`\u0015R\nf_!C";
      n[82] = "\u0012W3j6$RE/kH2~\u0018o7ya~%kks=T\u001f-5/9";
      n[83] = "j\u0007\u0012\u0017V\u001f*\u0015\u000e\u0016(\t\u0006IGB\u0019[\u0006uJ\u0016\u0013\u0006,O\fHO\u0002";
      n[84] = "*\u000eO$fh']\u0016 \u0002?\u0012\u000f\u0014s2i\u0012?N&x<#DQ=|i";
      n[85] = "*X\u0019\r\u0007\u0010c@\u0015\fh伡叐叩伵桤伵伡栊栳厫}XGcO\u0019\u0016\r\u001d.E";
      n[86] = "+Sn\u0016P@tDqo]>s\u000f4\u0016A\u000e&S7^0";
      n[87] = "OT\u000bcM*\u0006L\u0007b\"桟伫句厹栊使伛桯佻厹\u0013\u0012}\u0006C\u000bxG'KI";
      n[88] = "/=bb[uo/~c%cCs77\u00142CO:c\u001eliu|=Bh";
      n[89] = "pkWr:Fvx\u0007/W栶栎佇叺桗厔佲栎叙叺N7Fmw_5(]i\"";
      n[90] = "bJF\u0000vx+RJ\u0001\u0019栍伆佥栮伭叚栍伆佥栮pyz)VWA$pcJ";
      n[91] = "\u001e\u0000\u0017lp!\u0013SNh\u0014v&\u0001L;$!&1\u0016nnu\u0017J\tuj ";
      n[92] = "\u0010$/v@FP63w>P|jz#\u000f\u0005|Vww\u0005_Vl1)Y[";
      n[93] = "&^x\t\f.fLd\br8J\u0011$QNnJ, \bI7`\u0016fV\u00153";
      n[94] = ")xTXUwijHY+aE7\b\u0006\u0011?E\n\fY\u0010no0J\u0007Lj";
      n[95] = "\rYW\"|$DA[#\u0013伕栭叨句厑低桑佩佶佻Rs&FEFc.,\fY";
      n[96] = "^:M\u0000cm\u0017\"A\u0001\f栘厤压叿桩叏参伺桑佡p1{\u0019&F\u0002ix\u0015'";
      n[97] = "V\"vo\"\u0004\u001f:znM桱厬厓佚佂厎厫伲厓栞\u001f}\u0012^n|fp\u0017\u00165";
      n[98] = "u{\u001ew\f\f5i\u0002vr\u001a\u00190G)NEp^z/\u0017O/t@iI\u0013+";
      n[99] = "WK()xH\u001eS$(\u0017栽厭栠伄伄栎栽伳栠厚Y'\u001f\u001e\\(2rESV";
      n[100] = "l\u000e#\u0010]vf\u0004,N<及及伢伎根栥佔栐伢桊 YxyO2_Srv\u0011";
      n[101] = "\u000e$}\u000e-bG<q\u000fB反叴桏栕伣桛栗佪厕叏~xrFog\u0002za\u000b=";
      n[102] = "\u0003\u0010o]\u0011\u001fC\u0002s\\o\to[6\u0003SX\u00045\u000b\u0005\n\\Y\u001f1CT\u0000]";
      n[103] = "\u001e\u0005\u0017<\u0019hW\u001d\u001b=v栝栾桮伻休厵余佺厴厥LF?W\u0012\u0017'\u0013e\u001a\u0018";
      n[104] = "`\r\u00067\u0007\u0018 \u001f\u001a6y\u000e\fF_iE_j(bo\u001c[:\u0002X)B\u0007>";
      n[105] = "UCDh\nN\u0015QXitX9\f\u00183N\f91\u001ciOW\u0013\u000bZ7\u0013S";
      n[106] = "\u001cA\u0001Y\u001a{UY\rXu栎格佮厳只桬栎另佮伭)OkT\n\u001bUMx\u0019X";
      n[107] = "pM?'\u001349U3&|桁桐叼厍桎县厛厊栦桗WLc9Z?<\u00199tP";
      n[108] = "\"q\u000f\n\u00010bc\u0013\u000b\u007f&N>SRCvN\u0003W\u000bD)d9\u0011U\u0018-";
      n[109] = "v\t-h;2?\u0011!iT桇桖桢原佅厗伃伒桢原\u001859sE<(4`~C";
      n[110] = "NM\u0015@2C\u0013\u001c\u0014A@厱叨桪桨佣厃桫栲厰桨>%LO\r\u0003\u000fx\u001dN\f";
      n[111] = "6dKas)/4T\"\t|\u00065\u0001g8+\u0006\u0005[4s\u007f7~D/w*";
      n[112] = "nOJ\u0016K]h\\\u001aK&佩栐佣叧叩佻栭及佣栽*F]sSBQYFw\u0006";
      n[113] = "\u001cf\n\u0002IGU~\u0006\u0003&叨佸受伦厱句佶另受厸r\u0016\u0010Uq\n\u0019CJ\u0018{";
      n[114] = "yEg!\u0011\f9W{ o\u001a\u0015\u000b2t^L\u00157? T\u0015?\ry~\b\u0011";
      n[115] = "\bS(j`jHA4k\u001e|d\u001ct6.#d!pk%sN\u001b65yw";
      n[116] = "AI]7\u0019y\bQQ6v佈伥栢可桞伫佈去司可GLi\t\u0002G;NzDP";
      n[117] = "\u0007IK\u00124xG[W\u0013Jnk\u0002\u0012Lv1\u0004l/J/;]F\u0015\fqgY";
      n[118] = "[>4F\u0003V\u0012&8Gl栣桻休桜佫伱栣伿厏历6\\\u0001\u0012)4]\t[_#";
      n[119] = "\u0016\u0004\bD\u0017BV\u0016\u0014EiTzKT\u0019R\u0006zvPER[PL\u0016\u001b\u000e_";
      n[120] = "yn.#y.0v\"\"\u0016厁厃叟厜厐叕厁厃叟框Sw%|\"?cv|q$";
      n[121] = "L$(\u000bj;Ut7H\u0010n|ub\r 0|E8^jmM>'En8";
      n[122] = "A\u0018<o$g\b\u00000nK佖伥桳桔佂伖栒桡桳伐\u001fqw\tS&csdD\u0001";
      n[123] = "Gski!@\u0007awh_V+=><n\u0001+\u00013hdY\u0001;u68]";
      n[124] = "e%8U8:,=4TW伋桅厔桐格伊桏桅厔桐%i)=0v\\i<.i";
      n[125] = "\u0002\u0015\"vo\u001cK\r.w\u0000厳栢厤伎佛佝桩栢伺伎\u0006>\u000fZ\u0000l\u007f>\u001aIY";
      n[126] = "\u0019A\f\u0016)KPY\u0000\u0017F古根台桤伻桟佺口佮传f ZN\u000e\u0001\u001e8\u001fFB";
      n[127] = "we_'`\\7wC&\u001eJ\u001b*\u0003x%\u001d\u001b\u0017\u0007&%E1-AxyA";
      n[128] = "?O\u0013t\u0019+dWRvh\u007fY\u001fU5V)Y.\u00006Ti~TRsT/";
      n[129] = "7\"Y\u0019\u0002?w0E\u0018|)[m\u0005CFy[P\u0001\u0018G&qjGF\u001b\"";
      n[130] = "~gn':\u0005>ur&D\u0013\u0012(2xuA\u0012\u00156&\u007f\u001c8/px#\u0018";
      n[131] = " i`j'FiqlkH佷栀变叒佇伕叩佄变佌\u001a$W{&\u007fp4R}`";
      n[132] = "\u001e*\bpfEW2\u0004q\t栰古伅伤佝及佴栾伅厺\u00007VF?Fy7CUf";
      n[133] = "z*{J[|32wK4叓伞伅叉叹栭位厀桁叉:\u000bqz mFEo\"&";
      n[134] = "|B\u0002*py<P\u001e+\u000eo\u0010\t[t2>}gfrk:&M\\45f\"";
      n[135] = "vKI3Wh6YU2)~\u001a\u0004\u0015o\u0019(\u001a9\u00112\u0012q0\u0003WlNu";
      n[136] = "$\u0016\u001e\u0015%7\"\u0005NHH伃桚桾桩佴伕厝桚桾桩)(79\n\u0016R7,=_";
      n[137] = "?\u001f?\u001d:*\u007f\r#\u001cD<SPcG~mSmg\u001c\u007f3yW!B#7";
      n[138] = "\u001auBw_RSmNv0栧栺叄台栞佭佣佾栞佮\u0007\nBR>X{\bQ\u001fl";
      n[139] = "q8y[^|1*eZ j\u001ds \u0005\u001d<t\u001d\u001d\u0003E?+7'E\u001bc/";
      n[140] = "\u0001^jpQ\u0005ALvq/\u0013m\u00116+\u0014Em,2q\u0014\u001cG\u0016t/H\u0018";
      n[141] = "|Y\u0016OJW5A\u001aN%佦桜叨厤佢佸司历栲伺?\u0015At\u0015\u001cF\u0018D<N";
      n[142] = "\u0015J\u000f\u000e\u0015~UX\u0013\u000fkhy\u0001VPV=\u0011okV\u000e=OEQ\u0010PaK";
      n[143] = "GM\u0017\nzj\u0007_\u000b\u000b\u0004|+\u0003B_5,+?O\u000b?s\u0001\u0005\tUcw";
      n[144] = "\u0010jLBP\u0004PxPC.\u0012|!\u0015\u001c\u0012B\u001bO(\u001aKGJe\u0012\\\u0015\u001bN";
      n[145] = "\u0003\u001d#)/6J\u0005/(@厙佧伲桋伄伝伇佧伲桋YpaJ\n#2%;\u0007\u0000";
      n[146] = "xi\u0007+.\u001b8{\u001b*P\r\u0014\"^ul\\xLcs5X\"fY5k\u0004&";
      n[147] = "jZ{U\u0014\u007f*HgTji\u0006\u0011\"\u000bV6h\u007f\u001f\r\u000f<0U%KQ`4";
      n[148] = ".F \u0019u<g^,\u0018\u001a伍栎号伌伴佇伍佊栭伌i ,f\r:\u0015\"?+_";
      n[149] = "\u00118%U\u000ei\bh:\u0016t<!ioSEi!Y5\u0000\u000e?\u0010\"*\u001b\nj";
      n[150] = "r(\\a`Nt;\f<\r古取桀叱厞栔古取厚栫]mNo4T&rUka";
      n[151] = "2$d\n\u0016\"r6x\u000bh4^k8SYk^V<\u000bS;tlzU\u000f?";
      n[152] = "\n\u0014u`w\u000e\u0001Nvf\u000e=.;N@Y5\"7^T\u000e\u0018\u0006\u0017|vq\u0013\\\u0014z";
      n[153] = "P\f\u0000yy ]\u0001\r`D =P\u001bu??X\r\t~&";
      n[154] = "3%-\u0002pez=!\u0003\u001f栐佗厔桅伯叜佔佗桎桅r{ql68\u001cfww(";
      n[155] = "\u0011]^^ymXER_\u0016栘併召佲叭栏参併召栶.&:XJ^Es`\u0015@";
      n[156] = "\u0012t_\r4r[lS\f[标叨佛样传桂佃叨佛样}k%[c_\u0016>\u007f\u0016i";
      n[157] = "\u0018\n lKT\u0015\u0007-uvVuV;`\rK\u0010\u000b)k\u0014";
      n[158] = "\"p*na*kh&o\u000e桟变叁伆叝反厅但栛桂\u001e4:j;0b6)'i";
      n[159] = "\u0002O\u0016R;8B]\nSE.n\u0004O\fy~\u0006jr\n {X@HL~'\\";
      n[160] = "g0f$tm.(j%\u001b参厝伟栎厗变参厝伟栎T+{o|l-&~''";
      n[161] = "I\u0002u{+^DQ,\u007fO\tq\u0003.,pVq3ty5\n@Hkb1_";
      n[162] = "\u0019O7 ?<Y]+!A*u\u0000k|\u007f~u=o!z%_\u0007)\u007f&!";
      n[163] = "\bO\u000eW5&AW\u0002VZ厉史你厼佺厙众栨你桦'jqAX\u000eL?+\fR";
      n[164] = "\u0014c\r\bT8]{\u0001\t;厗栴叒县桡司厗栴佌桥x\u000bo]t\r\u0013^5\u0010~";
      n[165] = "@\u0002E6\u000b1YRZuqdpS\u000f0A;pcUc\u000bgA\u0018Jx\u000f2";
      n[166] = "u\u001b0\f|=s\b`Q\u0011伉发桳伃佭栈厗栋桳厝0q=h\u00078Kn&lR";
      n[167] = "M\nWppu\u0004\u0012[q\u001f叚伩伥栿參叜佄厷桡佻\u0000%e\u0005AM|'vH\u0013";
      n[168] = "\u00066\u0017\u0018@LF$\u000b\u0019>ZjyKF\u0003\u000bjDO\u0019\u0005U@~\tGYQ";
      n[169] = "dH\u0003A5T-P\u000f@Z校伀叹厱佬桃校桄栣厱1j\u0003-_\u0003Z?Y`U";
      n[170] = "\u0005i\tz(\u0015Lq\u0005{G桠栥栂伥栓会厺佡变桡\n}\u0005M\"\u0013v\u007f\u0016\u0000p";
      n[171] = "9'\u0004'\u0001jy5\u0018&\u007f|UiQrN\"UU\\&Ds\u007fo\u001ax\u0018w";
      n[172] = "\f:1,1^L(--OH`qhrs\u0017\b\u001fUt*\u001dV5o2tAR";
      n[173] = "I$f\u0017?-\u0000<j\u0016P厂桩桏叔桾厓厂桩桏栎g49\u00167s\t)?\r)";
      n[174] = "`\u0017Dn':)\u000fHoH厕厚厦佨标伕伋厚伸栬\u001exm)\u0000Du-7d\n";
      n[175] = "swWf0]3eKgNK\u001f8\u000b;u\u0018\u001f\u0005\u000fguD5?I9)@";
      n[176] = "}U%\u007f(?=G9~V)\u0011\u001ay\"my\u0011'}~m&;\u001d; 1\"";
      n[177] = "eq2\u0007\u0018\u0019,i>\u0006w桬企栚桚伪桮厶原叀厀wGN,f2\u001c\u0012\u0014al";
      n[178] = "s\u0010_\u0002`<~\u001dR\u001b]?\u001eLD\u000e&#{\u0011V\u0005?";
   }

   @EventTarget
   public void c(PacketEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundBlockUpdatePacket S23) {
            this.树友何何何友何树何友.remove(S23.getPos());
            if (this.友树树树何树树树树友.getValue()) {
               this.友何何友友树何友树友.add(S23.getPos());
               this.友树友何何何树树何何.put(new 树友树友何友何何友何.何树友何树何友友何树(S23.getPos()), S23.getBlockState());
            }
         }

         if (packet instanceof ClientboundSectionBlocksUpdatePacket S22) {
            S22.runUpdates((pos, state) -> {
               BetterCamera.e();
               this.树友何何何友何树何友.remove(pos);
               if (this.友树树树何树树树树友.getValue()) {
                  this.友何何友友树何友树友.add(pos);
                  this.友树友何何何树树何何.put(new 树友树友何友何何友何.何树友何树何友友何树(pos), state);
               }
            });
         }
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 22782;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友树友何友何何友何", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   @Override
   public void h() {
      BetterCamera.e();
      this.v();
      if (何树友友何何友何友何 != null && !何树友友何何友何友何.isShutdown()) {
         何树友友何何友何友何.shutdownNow();
      }

      if (!this.Q(new Object[]{52406761729175L})) {
         mc.levelRenderer.allChanged();
      }
   }

   private double h(BlockPos pos, Block oreType) {
      BetterCamera.e();
      if (this.Q(new Object[]{52406761729175L})) {
         return 0.0;
      } else {
         int chunkX = pos.getX() >> 4;
         int chunkZ = pos.getZ() >> 4;
         Set<Block> oreGroup = this.D(oreType);
         if (oreGroup.isEmpty()) {
            return 0.0;
         } else {
            Block representative = oreGroup.stream().min(Comparator.comparing(b -> b.builtInRegistryHolder().key().location().toString())).orElse(oreType);
            String cacheKey = chunkX + ":" + chunkZ + ":" + representative.builtInRegistryHolder().key().location();
            树友树友何友何何友何.何何何树友何树何何何 cachedLevel = this.何树友树树何树树友树.get(cacheKey);
            if (cachedLevel == 树友树友何友何何友何.何何何树友何树何何何.何树友友何友何树树何) {
               return -5.0;
            } else if (cachedLevel == 树友树友何友何何友何.何何何树友何树何何何.友友何何树树何树何树) {
               return 1.0;
            } else {
               BlockPos playerPos = mc.player.blockPosition();
               int playerChunkX = playerPos.getX() >> 4;
               int playerChunkZ = playerPos.getZ() >> 4;
               int distManhattan = Math.abs(playerChunkX - chunkX) + Math.abs(playerChunkZ - chunkZ);
               if (distManhattan <= 3) {
                  this.何树友树树何树树友树.put(cacheKey, 树友树友何友何何友何.何何何树友何树何何何.友友何何树树何树何树);
                  return 1.0;
               } else {
                  this.何树友树树何树树友树.put(cacheKey, 树友树友何友何何友何.何何何树友何树何何何.树树何树友何何何友树);
                  if (!oreGroup.contains(Blocks.DIAMOND_ORE) && oreGroup.contains(Blocks.EMERALD_ORE)) {
                  }

                  if (!oreGroup.contains(Blocks.GOLD_ORE) && oreGroup.contains(Blocks.LAPIS_ORE)) {
                  }

                  int totalOreCount = 0;
                  int startX = chunkX << 4;
                  int startZ = chunkZ << 4;
                  int x = 0;
                  int z = 0;
                  int y = mc.level.getMinBuildHeight();
                  if (y < mc.level.getMaxBuildHeight()) {
                     if (this.Y(mc.level.getBlockState(new BlockPos(startX + 0, y, startZ + 0)).getBlock(), oreType)) {
                        totalOreCount++;
                     }

                     y++;
                  }

                  z++;
                  x++;
                  if (totalOreCount > 200) {
                     this.何树友树树何树树友树.put(cacheKey, 树友树友何友何何友何.何何何树友何树何何何.何树友友何友何树树何);
                     return -5.0;
                  } else {
                     this.何树友树树何树树友树.put(cacheKey, 树友树友何友何何友何.何何何树友何树何何何.友友何何树树何树何树);
                     return 0.0;
                  }
               }
            }
         }
      }
   }

   private double f(BlockPos centerPos, int radius) {
      BetterCamera.e();
      HashMap oreDistribution = new HashMap();
      int x = -8;
      if (-8 <= radius) {
         int y = -radius;
         if (y <= radius) {
            int z = -radius;
            if (z <= radius) {
               BlockPos pos = centerPos.offset(-8, y, z);
               if (mc.level.isLoaded(pos)) {
                  Block block = mc.level.getBlockState(pos).getBlock();
                  if (this.Q(block)) {
                     this.D(block)
                        .stream()
                        .findFirst()
                        .ifPresent(representative -> oreDistribution.computeIfAbsent(representative, k -> new ArrayList()).add(pos));
                  }
               }

               z++;
            }

            y++;
         }

         x++;
      }

      for (List<BlockPos> positions : oreDistribution.values()) {
         if (positions.size() >= 2) {
            if (this.C(positions)) {
            }

            if (this.G(positions)) {
               return -10.0;
            }
            break;
         }
      }

      return 0.0;
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         n[var4] = var21;
         return var21;
      }
   }

   private boolean d(BlockPos pos) {
      BetterCamera.e();
      return mc.level.getBlockState(pos.above()).is(Blocks.AIR)
         || mc.level.getBlockState(pos.above()).is(Blocks.WATER)
         || mc.level.getBlockState(pos.below()).is(Blocks.AIR)
         || mc.level.getBlockState(pos.below()).is(Blocks.WATER)
         || mc.level.getBlockState(pos.south()).is(Blocks.AIR)
         || mc.level.getBlockState(pos.south()).is(Blocks.WATER)
         || mc.level.getBlockState(pos.north()).is(Blocks.AIR)
         || mc.level.getBlockState(pos.north()).is(Blocks.WATER)
         || mc.level.getBlockState(pos.east()).is(Blocks.AIR)
         || mc.level.getBlockState(pos.east()).is(Blocks.WATER)
         || mc.level.getBlockState(pos.west()).is(Blocks.AIR)
         || mc.level.getBlockState(pos.west()).is(Blocks.WATER);
   }

   private void d(PoseStack poseStack, AABB box, Color color) {
      float r = color.getRed() / 255.0F;
      float g = color.getGreen() / 255.0F;
      float b = color.getBlue() / 255.0F;
      float minX = (float)box.minX;
      float minY = (float)box.minY;
      float minZ = (float)box.minZ;
      float maxX = (float)box.maxX;
      float maxY = (float)box.maxY;
      float maxZ = (float)box.maxZ;
      Matrix4f matrix = poseStack.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.3F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.3F).endVertex();
      BufferUploader.drawWithShader(buffer.end());
      buffer.begin(Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, 0.8F).endVertex();
      buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, 0.8F).endVertex();
      BufferUploader.drawWithShader(buffer.end());
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/render/树友树友何友何何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private void a() {
      this.v();
      String var10000 = BetterCamera.e();
      this.友树友树何树何友何何 = mc.level;
      if (var10000 != null) {
         if (this.Q(new Object[]{52406761729175L})) {
            return;
         }

         mc.levelRenderer.allChanged();
      }
   }

   private void p() {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         int playerX = (int)mc.player.getX();
         int playerY = (int)mc.player.getY();
         int playerZ = (int)mc.player.getZ();
         int range = this.何树友友何何友友树何.getValue().intValue();
         树友何何何树何树友友.G(() -> {
            BetterCamera.e();

            try {
               ;
            } finally {
               this.友树树友树友友树树树 = false;
               this.友友树何友树友友树友 = System.currentTimeMillis();
            }
         }, 108624793298909L);
      } else {
         this.友树树友树友友树树树 = false;
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = n[var4];
      if (var5 instanceof String) {
         String var6 = o[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         n[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private Vector3f k(Vec3 worldPos, Vec3 camPos) {
      BetterCamera.e();
      if (this.树何何树何友树何何树 != null && this.何树友友友何树何何何 != null) {
         Vector4f pos = new Vector4f((float)(worldPos.x - camPos.x), (float)(worldPos.y - camPos.y), (float)(worldPos.z - camPos.z), 1.0F);
         pos.mul(this.树何何树何友树何何树);
         pos.mul(this.何树友友友何树何何何);
         if (pos.w() <= 0.0F) {
            return null;
         } else {
            pos.mul(1.0F / pos.w());
            float sW = mc.getWindow().getGuiScaledWidth();
            float sH = mc.getWindow().getGuiScaledHeight();
            float sX = (pos.x() * 0.5F + 0.5F) * sW;
            float sY = (-pos.y() * 0.5F + 0.5F) * sH;
            if (sX >= 0.0F && sX <= sW && sY >= 0.0F && sY <= sH) {
            }

            return new Vector3f(sX, sY, 1.0F);
         }
      } else {
         return null;
      }
   }

   private void v() {
      this.树友何何何友何树何友.clear();
      this.树友何何何树树友树何 = null;
      this.树何友树何友何何树树 = false;
      this.友树友何何何树树何何.clear();
      this.友何树友友何树友树友.clear();
      this.友何何友友树何友树友.clear();
      this.友树树友树友友树树树 = false;
      this.树何何树何友树何何树 = null;
      this.何树友友友何树何何何 = null;
      this.何树友树树何树树友树.clear();
      this.友友友友友友友友友树++;
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = n[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void q(BlockPos playerPos, Map<BlockPos, Block> foundBlocks) {
      BetterCamera.e();
      if (mc.level != null) {
         Set<BlockPos> processedBlocks = new HashSet<>();
         Set<BlockPos> reachableAir = this.B(playerPos);
         Iterator var8 = reachableAir.iterator();
         if (var8.hasNext()) {
            BlockPos airPos = (BlockPos)var8.next();
            Direction[] var10 = 树友友友树友友何树何;
            int var11 = var10.length;
            int var12 = 0;
            if (0 < var11) {
               Direction dir = var10[0];
               BlockPos surfacePos = airPos.relative(dir);
               if (!this.c(surfacePos)) {
                  Block block = mc.level.getBlockState(surfacePos).getBlock();
                  if (this.N(block)) {
                     this.H(surfacePos, block, foundBlocks, processedBlocks);
                  }
               }

               var12++;
            }
         }
      }
   }

   private Color z(Block block) {
      BetterCamera.e();
      return null;
   }

   @EventTarget
   public void w(Render3DEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         if (mc.gameRenderer.getMainCamera().isInitialized()) {
            this.树何何树何友树何何树 = new Matrix4f(event.poseStack().last().pose());
            this.何树友友友何树何何何 = new Matrix4f(RenderSystem.getProjectionMatrix());
         }

         Vec3 camPos = mc.gameRenderer.getMainCamera().getPosition();
         PoseStack poseStack = event.poseStack();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         RenderSystem.setShader(GameRenderer::getPositionColorShader);
         if (!this.树友何何何友何树何友.isEmpty()) {
            double renderRangeSq = Math.pow(this.何友何何树友树友何何.getValue().doubleValue(), 2.0);

            for (Entry<BlockPos, Block> entry : this.树友何何何友何树何友.entrySet()) {
               if (!(entry.getKey().distSqr(mc.player.blockPosition()) > renderRangeSq)) {
                  this.R(poseStack, entry.getKey(), entry.getValue().defaultBlockState(), camPos);
                  break;
               }
            }
         }

         if (this.友树树树何树树树树友.getValue() && !this.友树友何何何树树何何.isEmpty()) {
            double packetRangeSq = Math.pow(this.友友何树友友友友何树.getValue().doubleValue(), 2.0);
            this.友树友何何何树树何何.forEach((pos, state) -> {
               if (this.T(state)) {
                  BlockPos blockPos = pos.N();
                  if (blockPos.distSqr(mc.player.blockPosition()) <= packetRangeSq) {
                     this.R(poseStack, blockPos, state, camPos);
                  }
               }
            });
         }

         RenderSystem.enableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.disableBlend();
      }
   }

   private boolean y(Block block) {
      BetterCamera.e();
      if (block == null) {
         return false;
      } else {
         String id = block.builtInRegistryHolder().key().location().getPath();
         return id.contains("_planks")
            || id.contains("_log")
            || id.contains("_fence")
            || id.contains("_stairs")
            || id.contains("rail")
            || id.equals("torch")
            || id.equals("wall_torch")
            || id.equals("cobweb")
            || id.equals("ladder")
            || id.equals("chest")
            || id.equals("trapped_chest");
      }
   }

   private Set<Block> A(Block oreBlock) {
      d<"Ê">(-6111518805885204354L, 13756428626746L);
      String id = oreBlock.builtInRegistryHolder().key().location().getPath();
      if (id.startsWith("") || id.equals("ancient_debris")) {
         return d<"à">(-6109693949063865614L, 13756428626746L);
      } else {
         return id.contains("_ore") ? d<"à">(-6109247910884572893L, 13756428626746L) : Collections.emptySet();
      }
   }

   private Color Y(Block block) {
      BetterCamera.e();
      return null;
   }

   private boolean Y(Block b1, Block b2) {
      BetterCamera.e();
      if (b1 == b2) {
         return true;
      } else if (b1 != null && b2 != null) {
         Set<Block> g1 = this.D(b1);
         Set<Block> g2 = this.D(b2);
         return !g1.isEmpty() && g1.equals(g2);
      } else {
         return false;
      }
   }

   @EventTarget
   public void X(LivingUpdateEvent event) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && (Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         if (mc.level != this.友树友树何树何友何何) {
            this.a();
         }

         if (this.树友何何何树树友树何 != null) {
            this.树友何何何友何树何友.clear();
            this.树友何何何友何树何友.putAll(this.树友何何何树树友树何);
            this.树友何何何树树友树何 = null;
         }

         if (System.currentTimeMillis() - this.树树树友何友何何树友 > this.何友友树何何树树树友.getValue().longValue() && !this.树何友树何友何何树树) {
            this.树何友树何友何何树树 = true;
            long scanId = this.友友友友友友友友友树;
            树友何何何树何树友友.G(() -> {
               BetterCamera.e();

               try {
                  Map<BlockPos, Block> foundBlocks = new ConcurrentHashMap<>();
                  this.q(mc.player.blockPosition(), foundBlocks);
                  if (scanId == this.友友友友友友友友友树) {
                     this.树友何何何树树友树何 = foundBlocks;
                  }
               } finally {
                  this.树何友树何友何何树树 = false;
                  this.树树树友何友何何树友 = System.currentTimeMillis();
               }
            }, 108624793298909L);
         }

         if (this.友树树树何树树树树友.getValue() && System.currentTimeMillis() - this.友友树何友树友友树友 > 1000L && !this.友树树友树友友树树树) {
            this.友树树友树友友树树树 = true;
            this.p();
         }
      }
   }

   private 树友树友何友何何友何.树树树友何友何何树友 L(List<BlockPos> vein, Block oreBlock) {
      BetterCamera.e();
      if (!this.Q(new Object[]{52406761729175L}) && !vein.isEmpty()) {
         树友树友何友何何友何.树树树友何友何何树友 report = new 树友树友何友何何友何.树树树友何友何何树友();
         BlockPos representativePos = vein.get(0);
         int veinSize = vein.size();
         report.友何树何树何树友何树 = this.W(veinSize);
         if (veinSize < this.树友友何何友友何友树.getValue().intValue()) {
            report.友何树何树何树友何树 = -20.0;
            return report;
         } else {
            report.何树何友友何树友何树 = this.h(representativePos, oreBlock);
            report.树树何友树友何树友友 = this.N(representativePos, oreBlock);
            if (report.树树何友树友何树友友 <= -10.0) {
               return report;
            } else {
               if (this.友何友何友友何友友友.getValue()) {
                  double totalHostRockScore = 0.0;
                  int exposedFaces = 0;
                  Iterator avgExposedFaces = vein.iterator();
                  if (avgExposedFaces.hasNext()) {
                     BlockPos pos = (BlockPos)avgExposedFaces.next();
                     totalHostRockScore = 0.0 + this.K(pos, oreBlock);
                     Direction[] var16 = 树友友友树友友何树何;
                     int var17 = var16.length;
                     int var18 = 0;
                     if (0 < var17) {
                        Direction dir = var16[0];
                        if (this.c(pos.relative(dir))) {
                           exposedFaces++;
                        }

                        var18++;
                     }
                  }

                  report.友友树友友树友友友树 = totalHostRockScore / veinSize;
                  double avgExposedFacesx = (double)exposedFaces / veinSize;
                  if (avgExposedFacesx >= 3.0) {
                     report.何树树树何何友树树树 = 3.0;
                  }

                  if (avgExposedFacesx >= 1.0) {
                     report.何树树树何何友树树树 = 1.5;
                  }

                  if (avgExposedFacesx > 0.0) {
                     report.何树树树何何友树树树 = 0.5;
                  }

                  report.何树树树何何友树树树 = 0.0;
               }

               if (this.友友何友何友何树何树.getValue()) {
                  report.何友树何何树友树树友 = this.f(representativePos, 8);
               }

               return report;
            }
         }
      } else {
         return new 树友树友何友何何友何.树树树友何友何何树友();
      }
   }

   @Override
   public void M() {
      BetterCamera.e();
      if ((Boolean)Fucker.isLogin && (Boolean)Fucker.isBeta) {
         this.v();
         this.友树友树何树何友何何 = null;
         if (何树友友何何友何友何 == null || 何树友友何何友何友何.isShutdown()) {
            何树友友何何友何友何 = (ThreadPoolExecutor)Executors.newFixedThreadPool(2);
         }

         if (!this.Q(new Object[]{52406761729175L})) {
            mc.levelRenderer.allChanged();
         }
      }
   }

   private boolean N(Block block) {
      d<"Ê">(-6810970795747655125L, 27083627274607L);
      if (block == null) {
         return false;
      } else {
         String currentBlockType = d<"Ø">(this, -6810249323342034305L, 27083627274607L).getValue();
         if (currentBlockType.equalsIgnoreCase("")) {
            return d<"Ø">(this, -6811976347026146773L, 27083627274607L).getValue()
                  && (block == d<"à">(-6812856175562110792L, 27083627274607L) || block == d<"à">(-6812053432510932971L, 27083627274607L))
               || d<"Ø">(this, -6826482760212078481L, 27083627274607L).getValue()
                  && (block == d<"à">(-6809922381823426023L, 27083627274607L) || block == d<"à">(-6812473192978751081L, 27083627274607L))
               || d<"Ø">(this, -6825910802748552105L, 27083627274607L).getValue()
                  && (block == d<"à">(-6816827374388110803L, 27083627274607L) || block == d<"à">(-6824150205734856598L, 27083627274607L))
               || d<"Ø">(this, -6825707840286537200L, 27083627274607L).getValue()
                  && (block == d<"à">(-6823826724711629658L, 27083627274607L) || block == d<"à">(-6824349080757959811L, 27083627274607L))
               || d<"Ø">(this, -6825193504960980517L, 27083627274607L).getValue()
                  && (
                     block == d<"à">(-6817239817352858459L, 27083627274607L)
                        || block == d<"à">(-6824968258844106476L, 27083627274607L)
                        || block == d<"à">(-6825775932399592715L, 27083627274607L)
                  )
               || d<"Ø">(this, -6824688205796881965L, 27083627274607L).getValue()
                  && (block == d<"à">(-6818432175119498599L, 27083627274607L) || block == d<"à">(-6823528849424903516L, 27083627274607L))
               || d<"Ø">(this, -6826164764114462748L, 27083627274607L).getValue()
                  && (block == d<"à">(-6817767062585052611L, 27083627274607L) || block == d<"à">(-6823326448516514734L, 27083627274607L))
               || d<"Ø">(this, -6810039245448649508L, 27083627274607L).getValue()
                  && (block == d<"à">(-6811398326855907767L, 27083627274607L) || block == d<"à">(-6809770296034326929L, 27083627274607L))
               || d<"Ø">(this, -6824280513815034821L, 27083627274607L).getValue() && block == d<"à">(-6810440230607183255L, 27083627274607L)
               || d<"Ø">(this, -6812306659906915473L, 27083627274607L).getValue() && block == d<"à">(-6809699414113812499L, 27083627274607L)
               || d<"Ø">(this, -6811760967435535570L, 27083627274607L).getValue() && block == d<"à">(-6813695626230383426L, 27083627274607L)
               || d<"Ø">(this, -6813220425483327056L, 27083627274607L).getValue() && block == d<"à">(-6812415982041489365L, 27083627274607L)
               || d<"Ø">(this, -6810787372203977081L, 27083627274607L).getValue()
                  && (
                     block == d<"à">(-6809993865289347454L, 27083627274607L)
                        || block == d<"à">(-6826008887105750318L, 27083627274607L)
                        || block == d<"à">(-6812793602617941214L, 27083627274607L)
                  );
         } else {
            return !currentBlockType.equalsIgnoreCase("Valuables")
               ? false
               : block == d<"à">(-6812415982041489365L, 27083627274607L)
                  || block == d<"à">(-6825775932399592715L, 27083627274607L)
                  || block == d<"à">(-6813695626230383426L, 27083627274607L)
                  || block == d<"à">(-6823247525139705544L, 27083627274607L)
                  || block == d<"à">(-6813305993222269730L, 27083627274607L)
                  || block == d<"à">(-6824132994749489977L, 27083627274607L);
         }
      }
   }

   private double N(BlockPos orePos, Block oreBlock) {
      BetterCamera.e();
      int y = orePos.getY();
      Set<Block> oreGroup = this.D(oreBlock);
      if (oreGroup.contains(Blocks.DIAMOND_ORE)) {
         if (y >= -64 && y <= 16) {
            return 2.0;
         } else {
            return y > 16 && y <= 32 ? 0.5 : -10.0;
         }
      } else if (oreGroup.contains(Blocks.EMERALD_ORE)) {
         return y >= -16 && y <= 320 ? 2.0 : -10.0;
      } else if (oreGroup.contains(Blocks.GOLD_ORE)) {
         if (y >= -64 && y <= 32) {
            return 2.0;
         } else {
            return y > 32 && y < 80 ? -1.5 : -5.0;
         }
      } else if (!oreGroup.contains(Blocks.IRON_ORE)) {
         if (oreGroup.contains(Blocks.COAL_ORE)) {
            return y >= 0 && y <= 256 ? 1.0 : 0.0;
         } else if (oreGroup.contains(Blocks.COPPER_ORE)) {
            return y >= -16 && y <= 112 ? 1.5 : 0.5;
         } else if (oreGroup.contains(Blocks.LAPIS_ORE)) {
            return y >= -64 && y <= 64 ? 1.5 : 0.0;
         } else if (oreGroup.contains(Blocks.REDSTONE_ORE)) {
            return y >= -64 && y <= 16 ? 1.5 : 0.0;
         } else if (oreGroup.contains(Blocks.ANCIENT_DEBRIS)) {
            if (y >= 8 && y <= 22) {
               return 2.0;
            } else {
               return y < 120 ? 1.0 : -15.0;
            }
         } else {
            return 0.5;
         }
      } else {
         return (y < -24 || y > 72) && (y <= 80 || y > 320) ? 1.0 : 1.5;
      }
   }

   private void N(PoseStack guiPoseStack) {
      float sW = mc.getWindow().getGuiScaledWidth();
      float sH = mc.getWindow().getGuiScaledHeight();
      BetterCamera.e();
      float cX = sW / 2.0F;
      float cY = sH / 2.0F;
      Vec3 camPos = mc.gameRenderer.getMainCamera().getPosition();
      Tesselator tesselator = Tesselator.getInstance();
      BufferBuilder buffer = tesselator.getBuilder();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableDepthTest();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      buffer.begin(Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
      double renderRangeSq = Math.pow(this.何友何何树友树友何何.getValue().doubleValue(), 2.0);
      Vec3 playerEyePos = mc.player.getEyePosition(1.0F);
      Iterator packetRangeSq = this.树友何何何友何树何友.entrySet().iterator();
      if (packetRangeSq.hasNext()) {
         Entry<BlockPos, Block> entry = (Entry<BlockPos, Block>)packetRangeSq.next();
         this.Q(entry.getKey(), entry.getValue().defaultBlockState(), playerEyePos, renderRangeSq, camPos, buffer, guiPoseStack, cX, cY, sW, sH);
      }

      if (this.友树树树何树树树树友.getValue()) {
         double packetRangeSqx = Math.pow(this.友友何树友友友友何树.getValue().doubleValue(), 2.0);
         Iterator var17 = this.友树友何何何树树何何.entrySet().iterator();
         if (var17.hasNext()) {
            Entry<树友树友何友何何友何.何树友何树何友友何树, BlockState> entry = (Entry<树友树友何友何何友何.何树友何树何友友何树, BlockState>)var17.next();
            if (this.T(entry.getValue())) {
               this.Q(entry.getKey().N(), entry.getValue(), playerEyePos, packetRangeSqx, camPos, buffer, guiPoseStack, cX, cY, sW, sH);
            }
         }
      }

      tesselator.end();
      RenderSystem.enableDepthTest();
      RenderSystem.disableBlend();
   }

   private double W(int veinSize) {
      BetterCamera.e();
      if (veinSize == 1) {
         return 2.0;
      } else if (veinSize >= 2 && veinSize <= 4) {
         return 2.5;
      } else {
         return veinSize >= 5 && veinSize <= 10 ? 3.5 : 3.0;
      }
   }

   private void H(BlockPos startPos, Block oreType, Map<BlockPos, Block> foundBlocks, Set<BlockPos> processedBlocks) {
      BetterCamera.e();
      if (!processedBlocks.contains(startPos)) {
         List<BlockPos> potentialVein = this.J(startPos, oreType, processedBlocks);
         if (!potentialVein.isEmpty()) {
            processedBlocks.addAll(potentialVein);
            if (this.树友何友树树友友友树.getValue()) {
               树友树友何友何何友何.树树树友何友何何树友 report = this.L(potentialVein, oreType);
               if (report.E(this.友何树何何何何友树友.getValue().doubleValue())) {
                  Iterator pos = potentialVein.iterator();
                  if (pos.hasNext()) {
                     BlockPos posx = (BlockPos)pos.next();
                     foundBlocks.put(posx, oreType);
                  }
               }
            }

            Iterator var12 = potentialVein.iterator();
            if (var12.hasNext()) {
               BlockPos pos = (BlockPos)var12.next();
               foundBlocks.put(pos, oreType);
            }
         }
      }
   }

   private boolean T(BlockState state) {
      BetterCamera.e();
      Block block = state.getBlock();
      if ((block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE) && this.何树友树友树树何何树.getValue()) {
         return true;
      } else if ((block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE) && this.树何友何友树友何友树.getValue()) {
         return true;
      } else if ((block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE) && this.友树友友树友友树何树.getValue()) {
         return true;
      } else if ((block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.NETHER_GOLD_ORE) && this.树友何树何树何友何树.getValue()) {
         return true;
      } else if ((block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE) && this.友友友何树何何友何树.getValue()) {
         return true;
      } else if ((block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) && this.树树树何何友何何友友.getValue()) {
         return true;
      } else if ((block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) && this.树何友友何树树树树友.getValue()) {
         return true;
      } else if ((block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) && this.树何树树何树友友友友.getValue()) {
         return true;
      } else if (block == Blocks.NETHER_QUARTZ_ORE && this.树友树何何树树何树友.getValue()) {
         return true;
      } else if (block == Blocks.ANCIENT_DEBRIS && this.树树何树何何树何友友.getValue()) {
         return true;
      } else if (block == Blocks.SPAWNER && this.友何何树何何何何何树.getValue()) {
         return true;
      } else {
         return block == Blocks.COBBLESTONE && this.树树友友树友友友树树.getValue()
            ? true
            : (block == Blocks.END_PORTAL_FRAME || block == Blocks.END_PORTAL || block == Blocks.END_GATEWAY) && this.何友何树树友树树何友.getValue();
      }
   }

   private void R(PoseStack poseStack, BlockPos pos, BlockState state, Vec3 camPos) {
      BetterCamera.e();
      if (state != null && !state.isAir()) {
         Block block = state.getBlock();
         Color color = this.z(block);
         if (color == null) {
            color = this.Y(block);
         }

         if (color != null) {
            poseStack.pushPose();
            poseStack.translate(pos.getX() - camPos.x, pos.getY() - camPos.y, pos.getZ() - camPos.z);
            if (this.树何友友树何何树何友.getValue()) {
               this.d(poseStack, new AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0), color);
            }

            this.V(poseStack, new AABB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0), color);
            poseStack.popPose();
         }
      }
   }

   private double K(BlockPos orePos, Block oreBlock) {
      BetterCamera.e();
      Set validHostRocks = this.A(oreBlock);
      if (validHostRocks.isEmpty()) {
         return 1.0;
      } else {
         int stoneNeighbors = 0;
         int invalidNeighbors = 0;
         int airNeighbors = 0;
         Direction[] score = 树友友友树友友何树何;
         int var11 = score.length;
         int var12 = 0;
         if (0 < var11) {
            Direction dir = score[0];
            BlockPos neighborPos = orePos.relative(dir);
            Block neighborBlock = mc.level.getBlockState(neighborPos).getBlock();
            if (validHostRocks.contains(neighborBlock)) {
               stoneNeighbors++;
            }

            if (this.c(neighborPos)) {
               airNeighbors++;
            }

            if (!this.Y(neighborBlock, oreBlock) && !this.Q(neighborBlock) && !this.y(neighborBlock)) {
               invalidNeighbors++;
            }

            var12++;
         }

         if (stoneNeighbors == 0 && invalidNeighbors >= 4 && airNeighbors <= 1) {
            return -5.0;
         } else if (airNeighbors >= 2) {
            if (stoneNeighbors >= 1) {
               return 2.0;
            } else {
               return invalidNeighbors <= 2 ? 0.5 : -1.0;
            }
         } else {
            double scorex = 0.0;
            if (stoneNeighbors >= 4) {
               scorex = 3.0;
            }

            if (stoneNeighbors >= 2) {
               scorex++;
            }

            if (stoneNeighbors == 1) {
               scorex += 0.5;
            }

            return scorex;
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "何大伟230622198107200054";
   }

   private void Q(
      BlockPos pos,
      BlockState state,
      Vec3 playerEyePos,
      double rangeSq,
      Vec3 camPos,
      BufferBuilder buffer,
      PoseStack guiPoseStack,
      float cX,
      float cY,
      float sW,
      float sH
   ) {
      BetterCamera.e();
      Vec3 worldPos = Vec3.atCenterOf(pos);
      if (!(worldPos.subtract(playerEyePos).lengthSqr() > rangeSq)) {
         Vector3f screenPos = this.k(worldPos, camPos);
         if (screenPos != null) {
            float tX = screenPos.x;
            float tY = screenPos.y;
            if (screenPos.z > 0.0F) {
            }

            Color color = this.z(state.getBlock());
            if (color == null) {
               color = this.Y(state.getBlock());
            }

            if (color != null) {
               float r = color.getRed() / 255.0F;
               float g = color.getGreen() / 255.0F;
               float b = color.getBlue() / 255.0F;
               Vector3f clipped = this.x(cX, cY, tX, tY, sW, sH);
               tX = clipped.x;
               tY = clipped.y;
               buffer.vertex(guiPoseStack.last().pose(), cX, cY, 0.0F).color(r, g, b, 0.8F).endVertex();
               buffer.vertex(guiPoseStack.last().pose(), tX, tY, 0.0F).color(r, g, b, 0.8F).endVertex();
            }
         }
      }
   }

   private boolean Q(Block block) {
      BetterCamera.e();
      if (block == null) {
         return false;
      } else {
         String blockId = block.builtInRegistryHolder().key().location().getPath();
         return blockId.contains("_ore");
      }
   }

   private boolean G(List<BlockPos> positions) {
      BetterCamera.e();
      if (positions.size() < 4) {
         return false;
      } else {
         Map<Integer, Integer> xSpacing = new HashMap<>();
         Map<Integer, Integer> ySpacing = new HashMap<>();
         Map<Integer, Integer> zSpacing = new HashMap<>();
         int i = 0;
         if (0 < positions.size()) {
            int j = 1;
            if (1 < positions.size()) {
               BlockPos p1 = positions.get(0);
               BlockPos p2 = positions.get(1);
               int dx = Math.abs(p1.getX() - p2.getX());
               int dy = Math.abs(p1.getY() - p2.getY());
               int dz = Math.abs(p1.getZ() - p2.getZ());
               if (dx > 1) {
                  xSpacing.put(dx, xSpacing.getOrDefault(dx, 0) + 1);
               }

               if (dy > 1) {
                  ySpacing.put(dy, ySpacing.getOrDefault(dy, 0) + 1);
               }

               if (dz > 1) {
                  zSpacing.put(dz, zSpacing.getOrDefault(dz, 0) + 1);
               }

               j++;
            }

            i++;
         }

         i = positions.size() > 5 ? 3 : 2;
         return xSpacing.values().stream().anyMatch(c -> {
            BetterCamera.e();
            return c > i;
         }) || ySpacing.values().stream().anyMatch(c -> {
            BetterCamera.e();
            return c > i;
         }) || zSpacing.values().stream().anyMatch(c -> {
            BetterCamera.e();
            return c > i;
         });
      }
   }

   private static enum 何何何树友何树何何何 implements  {
      友友何何树树何树何树,
      何树友友何友何树树何,
      树树何树友何何何友树;

      private static final long a;
      private static final Object[] b = new Object[7];
      private static final String[] c = new String[7];
      private static String LIU_YA_FENG;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-3914886123678737L, 3431397251262807414L, MethodHandles.lookup().lookupClass()).a(94221388387708L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var8 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(135114442123109L << var2 * 8 >>> 56);
         }

         var8.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[3];
         int var6 = 0;
         char var4 = '\b';
         int var3 = -1;

         while (true) {
            String var10 = a(
                  var1.doFinal("5~-]ÌK\u009d\u0091\u0010äµÙ¬ä\u0010Ð\r\u0000 /ÄX\u0016MT\b÷\u0017\tê`pK¾".substring(++var3, var3 + var4).getBytes("ISO-8859-1"))
               )
               .intern();
            byte var10001 = -1;
            var0[var6++] = var10;
            if ((var3 += var4) >= 34) {
               友友何何树树何树何树 = new 树友树友何友何何友何.何何何树友何树何何何();
               何树友友何友何树树何 = new 树友树友何友何何友何.何何何树友何树何何何();
               树树何树友何何何友树 = new 树友树友何友何何友何.何何何树友何树何何何();
               return;
            }

            var4 = "5~-]ÌK\u009d\u0091\u0010äµÙ¬ä\u0010Ð\r\u0000 /ÄX\u0016MT\b÷\u0017\tê`pK¾".charAt(var3);
         }
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 162 && var8 != 239 && var8 != 204 && var8 != 'E') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'h') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'K') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 162) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 239) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 204) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友树友何友何何友何$何何何树友何树何何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 49;
                  case 1 -> 57;
                  case 2 -> 40;
                  case 3 -> 5;
                  case 4 -> 4;
                  case 5 -> 21;
                  case 6 -> 39;
                  case 7 -> 44;
                  case 8 -> 20;
                  case 9 -> 6;
                  case 10 -> 8;
                  case 11 -> 63;
                  case 12 -> 58;
                  case 13 -> 33;
                  case 14 -> 53;
                  case 15 -> 25;
                  case 16 -> 18;
                  case 17 -> 60;
                  case 18 -> 32;
                  case 19 -> 43;
                  case 20 -> 59;
                  case 21 -> 51;
                  case 22 -> 30;
                  case 23 -> 41;
                  case 24 -> 34;
                  case 25 -> 62;
                  case 26 -> 3;
                  case 27 -> 38;
                  case 28 -> 1;
                  case 29 -> 42;
                  case 30 -> 47;
                  case 31 -> 55;
                  case 32 -> 28;
                  case 33 -> 9;
                  case 34 -> 48;
                  case 35 -> 29;
                  case 36 -> 15;
                  case 37 -> 14;
                  case 38 -> 12;
                  case 39 -> 24;
                  case 40 -> 54;
                  case 41 -> 27;
                  case 42 -> 11;
                  case 43 -> 16;
                  case 44 -> 23;
                  case 45 -> 37;
                  case 46 -> 2;
                  case 47 -> 56;
                  case 48 -> 52;
                  case 49 -> 36;
                  case 50 -> 13;
                  case 51 -> 22;
                  case 52 -> 31;
                  case 53 -> 17;
                  case 54 -> 61;
                  case 55 -> 46;
                  case 56 -> 26;
                  case 57 -> 35;
                  case 58 -> 19;
                  case 59 -> 50;
                  case 60 -> 7;
                  case 61 -> 10;
                  case 62 -> 45;
                  default -> 0;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\u000f '\tI(\u0000`j\u0002C5\u0005=aDK(\b;e\u000f\b.\u0001>eDT\"\u0002*l\u0018\b桖厧桟参伿叭伒伹厅作N佳伒伹桟参伿样伒伹伛";
         b[1] = "0gumph\u0004Dz-=c\u000eY\u007fp6%\u0006Drv2nEB{s2%\u0019Nxg;yE栺叝栒厕佞厠佾佃又伋/伾佾佃栒厕佞桺佾佃佖e";
         b[2] = "Q1[\bs*Z>JG\u0012$Q5N\u001d";
         b[3] = "c\u00152\u0000\u0013=uDgy桪桊佐桢厝伤伮伎収桢^\u0017\u001d?t\u001b0\u0001Lj";
         b[4] = "]\u001cT\"'{KM\u0001[厄取佮伯校桂会栌佮桫85)yJ\u0012V#x,";
         b[5] = "\u0013R \r/e\u0005\u0003ut伒栒厾叿休厷伒栒桤佡L\u001a!g\u0004\\\"\fp2";
         b[6] = "\u001f9\u0004]d\u000e\thQ$余桹伬厔桱佹栝厣厲桎hX{\tO+\u0003Hg\u0005";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      public static 树友树友何友何何友何.何何何树友何树何何何[] z() {
         return (树友树友何友何何友何.何何何树友何树何何何[])何树何友树何树友友树.clone();
      }

      public static 树友树友何友何何友何.何何何树友何树何何何 P(String name) {
         return Enum.valueOf(树友树友何友何何友何.何何何树友何树何何何.class, name);
      }

      private static String HE_WEI_LIN() {
         return "何炜霖大狗叫";
      }
   }

   public static class 何树友何树何友友何树 implements 何树友 {
      private final int 何友树树何树树何友何;
      private final int 树树友何何友友何友树;
      private final int 树何树树树何何树何友;
      private static final long a;
      private static final Object[] b = new Object[11];
      private static final String[] c = new String[11];
      private static int _何炜霖黑水 _;

      public 何树友何树何友友何树(BlockPos pos) {
         this.何友树树何树树何友何 = pos.getX();
         this.树树友何何友友何友树 = pos.getY();
         this.树何树树树何何树何友 = pos.getZ();
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-5891038359246413296L, 3695997886942611649L, MethodHandles.lookup().lookupClass()).a(9716311828034L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      @Override
      public boolean equals(Object obj) {
         BetterCamera.e();
         if (this == obj) {
            return true;
         } else if (obj != null && this.getClass() == obj.getClass()) {
            树友树友何友何何友何.何树友何树何友友何树 position = (树友树友何友何何友何.何树友何树何友友何树)obj;
            return this.何友树树何树树何友何 == position.何友树树何树树何友何 && this.树树友何何友友何友树 == position.树树友何何友友何友树 && this.树何树树树何何树何友 == position.树何树树树何何树何友;
         } else {
            return false;
         }
      }

      @Override
      public int hashCode() {
         int result = this.何友树树何树树何友何;
         result = 31 * result + this.树树友何何友友何友树;
         return 31 * result + this.树何树树树何何树何友;
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 195 && var8 != 'n' && var8 != 246 && var8 != 'k') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 163) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'v') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 195) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'n') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 246) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友树友何友何何友何$何树友何树何友友何树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 62;
                  case 1 -> 36;
                  case 2 -> 17;
                  case 3 -> 54;
                  case 4 -> 5;
                  case 5 -> 58;
                  case 6 -> 12;
                  case 7 -> 30;
                  case 8 -> 40;
                  case 9 -> 20;
                  case 10 -> 25;
                  case 11 -> 28;
                  case 12 -> 33;
                  case 13 -> 48;
                  case 14 -> 49;
                  case 15 -> 15;
                  case 16 -> 35;
                  case 17 -> 43;
                  case 18 -> 22;
                  case 19 -> 2;
                  case 20 -> 53;
                  case 21 -> 31;
                  case 22 -> 52;
                  case 23 -> 29;
                  case 24 -> 44;
                  case 25 -> 38;
                  case 26 -> 10;
                  case 27 -> 41;
                  case 28 -> 45;
                  case 29 -> 56;
                  case 30 -> 57;
                  case 31 -> 8;
                  case 32 -> 63;
                  case 33 -> 47;
                  case 34 -> 60;
                  case 35 -> 34;
                  case 36 -> 26;
                  case 37 -> 61;
                  case 38 -> 21;
                  case 39 -> 55;
                  case 40 -> 1;
                  case 41 -> 14;
                  case 42 -> 19;
                  case 43 -> 6;
                  case 44 -> 37;
                  case 45 -> 51;
                  case 46 -> 4;
                  case 47 -> 9;
                  case 48 -> 24;
                  case 49 -> 3;
                  case 50 -> 42;
                  case 51 -> 18;
                  case 52 -> 59;
                  case 53 -> 13;
                  case 54 -> 50;
                  case 55 -> 16;
                  case 56 -> 46;
                  case 57 -> 32;
                  case 58 -> 27;
                  case 59 -> 7;
                  case 60 -> 11;
                  case 61 -> 39;
                  case 62 -> 23;
                  default -> 0;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\u0014\bW;C\u0003\u001bH\u001a0I\u001e\u001e\u0015\u0011vA\u0003\u0013\u0013\u0015=\u0002\u0005\u001a\u0016\u0015v^\t\u0019\u0002\u001c*\u0002.\u0012\u0012\r=^/\u0016\u000b\u001c*M";
         b[1] = "oY`U\u001e#dVq\u001ac;wQxS";
         b[2] = "\u0012\rmB4Q\u001dM I>L\u0018\u0010+\u000f6Q\u0015\u0016/DuW\u001c\u0013/\u000f)[\u001f\u0007&Su栯厺桲厈佴厐佫伤厨伖\u0005伎栯厺伶桒佴厐叵伤桲";
         b[3] = int.class;
         c[3] = "java/lang/Integer";
         b[4] = "\u0002s Pph\t|1\u001f\fq\u0006f?\\;A\u0010q3A*m\u0007|";
         b[5] = "_\u0016>I}CT\u0019/\u0006\u001cM_\u0012+\\";
         b[6] = "/t79=\u0013ff=q\u0004栵栏受伉佝叇可佋受桍\u0000>\u0010xh>izSwq";
         b[7] = "\b7|UX+\u000f(hm\bVRr~UU1\u001a?w\te";
         b[8] = "\u0006<W~`gO.]6Y桁佢桅栭桞伄伅栦企号GcdQ ^.''^9";
         b[9] = "Y9x9I\u0007\u0010+rqpQ`brd\u0010YZadx\u00008[0\u007f`\u0011\u0002X&cpp";
         b[10] = " #\u001apI\u0001i1\u00108p佣叚桚桠伔桩栧佄厀伤IJ\u0002w?\u0013 \u000eAx&";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public BlockPos N() {
         return new BlockPos(this.何友树树何树树何友何, this.树树友何何友友何友树, this.树何树树树何何树何友);
      }

      private static String HE_WEI_LIN() {
         return "解放村多种2队1144号";
      }
   }

   private static class 树树树友何友何何树友 implements 何树友 {
      double 友友树友友树友友友树 = 0.0;
      double 树树何友树友何树友友 = 0.0;
      double 友何树何树何树友何树 = 0.0;
      double 何友树何何树友树树友 = 0.0;
      double 何树树树何何友树树树 = 0.0;
      double 何树何友友何树友何树 = 0.0;
      double 何友友树树树树何何何 = 0.0;
      private static final long a;
      private static final Object[] b = new Object[15];
      private static final String[] c = new String[15];
      private static String LIU_YA_FENG;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-772412456681524793L, 4306723308615473491L, MethodHandles.lookup().lookupClass()).a(242420901550247L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      double Z() {
         return this.友友树友友树友友友树 + this.树树何友树友何树友友 + this.友何树何树何树友何树 + this.何友树何何树友树树友 + this.何树树树何何友树树树 + this.何树何友友何树友何树 + this.何友友树树树树何何何;
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/render/树友树友何友何何友何$树树树友何友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 227 && var8 != 'b' && var8 != 181 && var8 != 213) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 216) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 220) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 227) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'b') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 181) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static void a() {
         b[0] = "3,\u0007oOq<lJdEl91A\"Mq47Ei\u000ew=2E\"R{>&L~\u000e\\56]iR]1/L~A";
         b[1] = "\u0016\u000145%}\u001d\u000e%zXe\u000e\t,3";
         b[2] = "\t{PAU!\u0006;\u001dJ_<\u0003f\u0016\fW!\u000e`\u0012G\u0014'\u0007e\u0012\fH+\u0004q\u001bP\u0014桟厡栄厵佷叱伛伿叞伫\u0006栫桟桻叞伫叩佯伛桻叞";
         b[3] = "U\u0015m5gX^\u001a|z\u001bAQ\u0000r9,qG\u0017~$=]P\u001a";
         b[4] = double.class;
         c[4] = "java/lang/Double";
         b[5] = "y\u001a\u0015\u001c|Dr\u0015\u0004S\u001dJy\u001e\u0000\t";
         b[6] = "\u0007|I!1\u001cOcM\"\nM>'B lD\u000f-Z)n$\u0004}R6j\u0015\u000ee[4\n";
         b[7] = "]R\rC0c\u0015M\t@\u000b伆厧台桿栫栒桂伹佮伻20e\u0016Z\nQbd\u001b\u0003";
         b[8] = "\u0017\u007fyjby_`}iY伜样佃发变伄桘叭佃栋\u001bb\u007f\\w~x0~Q.";
         b[9] = "#K%'\u001c\\kT!$'伹栃栳桗伋佺厧栃栳桗V\u001cZhC\"5N[e\u001a";
         b[10] = "OTms9g\u0007Kip\u0002伂厵栬佛佟栛厜桯栬叅\u00029a\u0004\\jak`\t\u0005";
         b[11] = "my\u0012AgR8\"\u0015};2'&J@-T<=\u000f}";
         b[12] = "J0L\u0014m,\u0002/H\u0017V栍桪伌古桼厕佉桪厒古em*\u00018K\u0006?+\fa";
         b[13] = "RS>\fA\u0002\u001aL:\u000fz叹伶栫伈桤伧栣厨佯桌}A\u0004\u0019[9\u001e\u0013\u0005\u0014\u0002";
         b[14] = "Z\\\u0018bM(\u0012C\u001cav叓厠栤厰叐桯叓厠叾桪\u0013M.\u0011T\u001fp\u001f/\u001c\r";
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 46;
                  case 1 -> 34;
                  case 2 -> 50;
                  case 3 -> 24;
                  case 4 -> 27;
                  case 5 -> 33;
                  case 6 -> 48;
                  case 7 -> 3;
                  case 8 -> 32;
                  case 9 -> 37;
                  case 10 -> 62;
                  case 11 -> 7;
                  case 12 -> 1;
                  case 13 -> 9;
                  case 14 -> 52;
                  case 15 -> 31;
                  case 16 -> 23;
                  case 17 -> 30;
                  case 18 -> 40;
                  case 19 -> 55;
                  case 20 -> 53;
                  case 21 -> 49;
                  case 22 -> 22;
                  case 23 -> 57;
                  case 24 -> 59;
                  case 25 -> 4;
                  case 26 -> 11;
                  case 27 -> 18;
                  case 28 -> 20;
                  case 29 -> 56;
                  case 30 -> 8;
                  case 31 -> 15;
                  case 32 -> 12;
                  case 33 -> 39;
                  case 34 -> 5;
                  case 35 -> 14;
                  case 36 -> 60;
                  case 37 -> 54;
                  case 38 -> 45;
                  case 39 -> 63;
                  case 40 -> 0;
                  case 41 -> 36;
                  case 42 -> 58;
                  case 43 -> 43;
                  case 44 -> 21;
                  case 45 -> 47;
                  case 46 -> 35;
                  case 47 -> 2;
                  case 48 -> 17;
                  case 49 -> 16;
                  case 50 -> 61;
                  case 51 -> 26;
                  case 52 -> 13;
                  case 53 -> 42;
                  case 54 -> 51;
                  case 55 -> 28;
                  case 56 -> 44;
                  case 57 -> 25;
                  case 58 -> 41;
                  case 59 -> 29;
                  case 60 -> 38;
                  case 61 -> 10;
                  case 62 -> 6;
                  default -> 19;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      boolean E(double threshold) {
         BetterCamera.e();
         return this.Z() >= threshold;
      }

      private static String HE_JIAN_GUO() {
         return "何炜霖大狗叫";
      }
   }
}
