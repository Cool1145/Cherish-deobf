package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import it.unimi.dsi.fastutil.ints.IntListIterator;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundAddPlayerPacket;
import net.minecraft.network.protocol.game.ClientboundMoveEntityPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Action;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;

public class 树何树何何友友友友何 extends Module implements 何树友 {
   public static 树何树何何友友友友何 何树何友何树何树树何;
   private final BooleanValue 树树树何何何何树何友 = new BooleanValue("EntityID", "实体ID", false);
   private final BooleanValue 何何树何何何何树何树 = new BooleanValue("Sleep", "睡眠", false);
   private final BooleanValue 友树友友树何树何树树 = new BooleanValue("NoArmor", "无盔甲", false);
   private final BooleanValue 友树友树友树树何友何 = new BooleanValue("Height", "高度", false);
   private final BooleanValue 何友树友树树树何友友 = new BooleanValue("Ground", "地面", false);
   private final BooleanValue 友友何友友树友友友树 = new BooleanValue("Dead", "死亡", false);
   private final BooleanValue 何树友树友友何何何何 = new BooleanValue("Health", "生命值", false);
   private final BooleanValue 树何树友友何树树何友 = new BooleanValue("Hypixel", "嗨皮咳嗽", false);
   private final BooleanValue 树树何友树友何友树树 = new BooleanValue("Matrix", "矩阵", true);
   private final BooleanValue 友何树友何友友树树何 = new BooleanValue("Matrix Bot Check Debug", "矩阵机器人检查调试输出", false).A(this.树树何友树友何友树树::getValue);
   private final List<Integer> 树友树何何树何友友友 = new ArrayList<>();
   private final Map<UUID, String> 友何何树友友友何树友 = new ConcurrentHashMap<>();
   private final Map<Integer, String> 树友树友何友树友树友 = new ConcurrentHashMap<>();
   private final Map<UUID, Long> 何何树树树何树何何友 = new ConcurrentHashMap<>();
   private final Set<Integer> 树树友何何何友何树友 = new HashSet<>();
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final long k;
   private static final Object[] l = new Object[36];
   private static final String[] m = new String[36];
   private static String HE_WEI_LIN;

   public 树何树何何友友友友何() {
      super("AntiBot", "防假人", 树何友友何树友友何何.友树何友何树树树树何);
      何树何友何树何树树何 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8764244679447377108L, -4186422424007582168L, MethodHandles.lookup().lookupClass()).a(27486244404453L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var12;
      Cipher var22 = var12 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var13 = 1; var13 < 8; var13++) {
         var10003[var13] = (byte)(65124141317266L << var13 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var19 = new String[25];
      int var17 = 0;
      String var16 = "wur´Ffò©´þ#\\\u0085g&\u0005\u009b>|åùÔÕ%\u0018¨Xó\fí\r\u0014«âË·V\u0015Ó\u007f_ä?\u0001\u0093·ßü\u000e(=à\u0005>\u0015\u008c\u001a\r?©\u009b>^hfnN»'bPªKÐ~ñq{?h\u009c\u0080õ¹¼yÚ?k}\u0010\u000eÔÑÌ¡ö\u008eåu¤`\u008a\u0012\u0093#s\u00100ºÂP\b\u0084ÐG\r$g\u008b'çê\u0011 á\u0013¥´\u0006zO¢3Iú\u00877Ì9\u00ad/wºª´ú\u00adÖ\u0084\u001c.}\u0087³\u009a\u008d \u0019î@ãµÛ1_7ïBº³¶1ßUÈ¶u=wt)È6Ú]W\u0012Ò\u001d\u0010ó\u0002%_\u001c\u0091\u0092 O7KµÊd/s\u0010\u0080\u001bñ\u0089Û(IÁ}\u0094aú°«\u009a\u0085 }\u008b?6¦²Y¼«ËPs\u0080»-!³ôi`~=Swi\u0003e\u0010m\u0011\u008aÿ\u0010ä\u0080á4ü¾ør»A\u009dÏ¶1V;\u0010\u0017\u0083\u001cø\u000e§ûB\u0088(ø-¢\u009a¸i\u0010wÝ -(\u0011cS\u0000¿\u0018áu èÒ@\fIv³TÒ>O\u009d¢Ê\u0000\u00151×4\u008e\u008cvm®2Y<ÔW\u0087I-\u0099h\u0082÷0=r½°E¨T\u0011¢JY-éM°¨?JÀ÷\u0099Þ4üz\u001b\u009cÂCú\u0010¬\u0012\u008a³\u0000¤\u0005çR;áó³¼\u0003²\u0018//Ó\u0010i3ö¾\u009f¥ÜQ«\u0012\n\u008e\u001c\u009d£ÞNï²ð\u0018¤\"±Mç\u0005\u0018\u0097\u0003ã\u001bÑ¿]4óÒP\r×\u001b\u0093Ø|\u0018ÇíößGÔ#õ\u0004\u008fdZ½ßâ§`R5\u008e©r(\\\u0010\u00148+\u001b\u008b\u001b§Þ6á\u0001á\u0003\f¿L\u0010\u0098«ÙW\u0087» ¸ëÅë£hj\u0012\u0015\u0010Z¬\u008cH×\u0089Ð<è¯\u0001Õ\u000bzCâ\u0010K½(è\u0086\u0004\u0012\u0096ÖÓ¡È»\u0015Øí(¯\u007f+CVØëÔÇÏÊ\u001a\u0098\nkù(8®\u00adõ\u0085\n×g\u0086·\u0000\u001bfÀ\u0013\u0010ãßk\u0086*\n\u009d";
      short var18 = 574;
      char var15 = 24;
      int var21 = -1;

      label49:
      while (true) {
         String var23 = var16.substring(++var21, var21 + var15);
         byte var10001 = -1;

         while (true) {
            String var33 = c(var12.doFinal(var23.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var19[var17++] = var33;
                  if ((var21 += var15) >= var18) {
                     c = var19;
                     h = new String[25];
                     Cipher var5;
                     Cipher var25 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(65124141317266L << var6 * 8 >>> 56);
                     }

                     var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var9 = var5.doFinal(new byte[]{10, -56, 121, -77, -30, -101, -72, 14});
                     long var37 = (var9[0] & 255L) << 56
                        | (var9[1] & 255L) << 48
                        | (var9[2] & 255L) << 40
                        | (var9[3] & 255L) << 32
                        | (var9[4] & 255L) << 24
                        | (var9[5] & 255L) << 16
                        | (var9[6] & 255L) << 8
                        | var9[7] & 255L;
                     var10001 = -1;
                     j = var37;
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(65124141317266L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-75, -82, -88, 114, 51, -11, 56, -14});
                     long var39 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     k = var39;
                     return;
                  }

                  var15 = var16.charAt(var21);
                  break;
               default:
                  var19[var17++] = var33;
                  if ((var21 += var15) < var18) {
                     var15 = var16.charAt(var21);
                     continue label49;
                  }

                  var16 = "?´¾Å<\u008a\n\u00adð\u000e¤\u009a\u001d¡Úò\u0010àöO¡Ö.a¯þ\u0015|uÛÕ\u009fb";
                  var18 = 33;
                  var15 = 16;
                  var21 = -1;
            }

            var23 = var16.substring(++var21, var21 + var15);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void B(PacketEvent event) {
      何树友树何何何树何何.a();
      if (!this.Q(new Object[]{52406761729175L})) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundMoveEntityPacket wrapper && this.何友树友树树树何友友.getValue()) {
            Entity entity = wrapper.getEntity(mc.level);
            if (entity instanceof Player && wrapper.isOnGround() && !this.树友树何何树何友友友.contains(entity.getId())) {
               this.树友树何何树何友友友.add(entity.getId());
            }
         }

         if (this.树树何友树友何友树树.getValue()) {
            if (packet instanceof ClientboundPlayerInfoUpdatePacket wrapperx) {
               if (!wrapperx.actions().contains(Action.ADD_PLAYER)) {
                  return;
               }

               Iterator displayName = wrapperx.entries().iterator();
               if (displayName.hasNext()) {
                  net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Entry entry = (net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket.Entry)displayName.next();
                  if (entry.displayName() != null && entry.displayName().getSiblings().isEmpty() && entry.gameMode() == GameType.SURVIVAL) {
                     UUID uuid = entry.profile().getId();
                     this.何何树树树何树何何友.put(uuid, System.currentTimeMillis());
                     this.友何何树友友友何树友.put(uuid, entry.displayName().getString());
                  }
               }
            }

            if (packet instanceof ClientboundAddPlayerPacket wrapperx) {
               if (!this.何何树树树何树何何友.containsKey(wrapperx.getPlayerId())) {
                  return;
               }

               String displayName = this.友何何树友友友何树友.get(wrapperx.getPlayerId());
               if (this.友何树友何友友树树何.getValue()) {
                  ClientUtils.P(125527250587045L, "Bot Detected! (" + displayName + ")");
               }

               this.树友树友何友树友树友.put(wrapperx.getEntityId(), displayName);
               this.何何树树树何树何何友.remove(wrapperx.getPlayerId());
               this.树树友何何何友何树友.add(wrapperx.getEntityId());
            }

            if (packet instanceof ClientboundRemoveEntitiesPacket wrapperx) {
               IntListIterator var19 = wrapperx.getEntityIds().iterator();
               if (var19.hasNext()) {
                  Integer entityId = (Integer)var19.next();
                  if (this.树树友何何何友何树友.contains(entityId)) {
                     String displayName = this.树友树友何友树友树友.get(entityId);
                     if (this.友何树友何友友树树何.getValue()) {
                        ClientUtils.P(125527250587045L, "Bot Removed! (" + displayName + ")");
                     }

                     this.树树友何何何友何树友.remove(entityId);
                  }
               }
            }
         }
      }
   }

   @EventTarget
   public void F(MotionEvent e) {
      何树友树何何何树何何.a();
      if (e.isPre()) {
         Iterator var7 = this.何何树树树何树何何友.entrySet().iterator();
         if (var7.hasNext()) {
            Entry<UUID, Long> entry = (Entry<UUID, Long>)var7.next();
            if (System.currentTimeMillis() - entry.getValue() > 500L) {
               if (this.友何树友何友友树树何.getValue()) {
                  ClientUtils.P(125527250587045L, "Fake Staff Detected! (" + this.友何何树友友友何树友.get(entry.getKey()) + ")");
               }

               this.何何树树树何树何何友.remove(entry.getKey());
            }
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (m[var4] != null) {
         return var4;
      } else {
         Object var5 = l[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 24;
               case 1 -> 13;
               case 2 -> 44;
               case 3 -> 59;
               case 4 -> 46;
               case 5 -> 23;
               case 6 -> 11;
               case 7 -> 31;
               case 8 -> 37;
               case 9 -> 40;
               case 10 -> 61;
               case 11 -> 53;
               case 12 -> 27;
               case 13 -> 38;
               case 14 -> 60;
               case 15 -> 52;
               case 16 -> 58;
               case 17 -> 36;
               case 18 -> 55;
               case 19 -> 4;
               case 20 -> 22;
               case 21 -> 29;
               case 22 -> 62;
               case 23 -> 8;
               case 24 -> 1;
               case 25 -> 7;
               case 26 -> 48;
               case 27 -> 5;
               case 28 -> 54;
               case 29 -> 10;
               case 30 -> 34;
               case 31 -> 30;
               case 32 -> 3;
               case 33 -> 56;
               case 34 -> 49;
               case 35 -> 28;
               case 36 -> 32;
               case 37 -> 26;
               case 38 -> 9;
               case 39 -> 18;
               case 40 -> 47;
               case 41 -> 42;
               case 42 -> 15;
               case 43 -> 19;
               case 44 -> 63;
               case 45 -> 16;
               case 46 -> 45;
               case 47 -> 14;
               case 48 -> 57;
               case 49 -> 21;
               case 50 -> 33;
               case 51 -> 12;
               case 52 -> 41;
               case 53 -> 51;
               case 54 -> 0;
               case 55 -> 17;
               case 56 -> 20;
               case 57 -> 2;
               case 58 -> 43;
               case 59 -> 50;
               case 60 -> 25;
               case 61 -> 35;
               case 62 -> 39;
               default -> 6;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            m[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20166;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树何何友友友友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u0094\u001bÍEÉ]\u0086\u000bñÚ3\u0090ak\b;, g¿È\u0090ôfaÙ\u0084\u001f\u009foq\u001f\tM, *\u008a\u00826¼>í\u0082òþ\u0083X\u001eÖÜªºàN\u001c\u0004\u0003A1, \u0083\u0084\u001aoÅg\u0002õ, \u009d`&\u00004\u0086²\u0016, ªMFÍ")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树何何友友友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @EventTarget
   public void c(WorldEvent event) {
      this.p();
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 241 && var8 != 198 && var8 != 'h' && var8 != 'H') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 194) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'P') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 241) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 198) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'h') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树何何友友友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   public void h() {
      this.p();
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = l[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = m[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         l[var4] = var21;
         return var21;
      }
   }

   public boolean a(Entity entity) {
      何树友树何何何树何何.a();
      if (this.isEnabled() && entity instanceof Player) {
         if (!this.友树友树友树树何友何.getValue() || !(entity.getBbHeight() <= 0.5) && !((Player)entity).isSleeping() && entity.tickCount >= 80) {
            if (this.友友何友友树友友友树.getValue() && ((Player)entity).isDeadOrDying()) {
               return true;
            } else if (this.何树友树友友何何何何.getValue() && ((Player)entity).getHealth() == 0.0F) {
               return true;
            } else if (this.何何树何何何何树何树.getValue() && ((Player)entity).isSleeping()) {
               return true;
            } else if (!this.树树树何何何何树何友.getValue() || entity.getId() < 1000000000 && entity.getId() > -1) {
               if (this.树何树友友何树树何友.getValue() && mc.getConnection().getPlayerInfo(entity.getUUID()) == null) {
                  return true;
               } else if (this.何友树友树树树何友友.getValue() && !this.树友树何何树何友友友.contains(entity.getId())) {
                  return true;
               } else {
                  return this.树树何友树友何友树树.getValue()
                     ? this.树树友何何何友何树友.contains(entity.getId())
                     : this.友树友友树何树何树树.getValue()
                        && ((Player)entity).getInventory().getArmor(0).isEmpty()
                        && ((Player)entity).getInventory().getArmor(1).isEmpty()
                        && ((Player)entity).getInventory().getArmor(2).isEmpty()
                        && ((Player)entity).getInventory().getArmor(3).isEmpty();
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private static void a() {
      l[0] = "!\u0000E\u000f2j.@\b\u00048w+\u001d\u0003B0j&\u001b\u0007\tsl/\u001e\u0007B0l1\rE桽伈栔众伻厠厧厖収众";
      l[1] = "T\u0002\u0002:T\u0015[BO1^\b^\u001fDwM\u001b[\u0019IwR\u0017G\u0000\u0002\u001bT\u0015[\tM7m\u001b[\u0019I";
      l[2] = "54l\u0014\u001fe:t!\u001f\u0015x?)*Y\u001de2/.\u0012^栛伃厑厉伢桡叁厝伏众";
      l[3] = "Q\u001e\u001eb\u0001(O\u0016\u0004-|8O";
      l[4] = "?\u0016@\u0012\u0010\u0012!\u001eZ]s\u0006%";
      l[5] = "2n@\r\u0015{2nWQ\u0019t(%ZF\fe3y_\r\b`3\u007f[@\u0017~rlUN\u001d<\u001fg]F\u0016f>dAM\u001cB0jMF\n[2m[v\bv=\u007fQs\u0019q7n@\u00079q(b[M";
      l[6] = "G2\u0011_\u0007aHr\\T\r|M/W\u0012\u0005a@)SYFgI,S\u0012\u0005gW?\u0011佩桹叅栵伉佪佩桹佛佱";
      l[7] = "2ABTA\u00039NS\u001b<\u001b*IZR";
      l[8] = "\fs^N9k\fsI\u00125d\u00168]\u000f&n\u00068F\u0005\"g\u000e8m\u00019g6oZ\u0005";
      l[9] = "eF\u0007\u000bW\u001f{N\u001dD5\u0003|S";
      l[10] = "\u0006pzF3d\r\u007fk\tO}\u0002eeJxM\u0014riWia\u0003\u007f";
      l[11] = "M\u001fNm`AM\u001fY1lNWTM,\u007fDGT_-yAW\u0003\u0014\u0006c\\J\u000eC";
      l[12] = int.class;
      m[12] = "java/lang/Integer";
      l[13] = "w{cPsG|tr\u001f\u0012Iw\u007fvE";
      l[14] = "U6*8R\u0002PipU栲校伴厚桐厖佶叻桰桀IlAE\u0013>\";\u0014QU";
      l[15] = "7il}\"~266\u0010桂桝又佛佒位厘伙栒叅\u000f*2-f>j-8-v";
      l[16] = "LRl\u0014M\u0005I\r6y号佢伭栤双厺号佢桩叾\u000fB\tF\u001f^eE\tBL";
      l[17] = ";\u0000\u000bNGM>_Q#佣桮叄桶厫叠佣伪佚伲h\u001aT\n}\b\u0003M\u0001\u001e;";
      l[18] = "n\u0018]QP8`PIPmg\u0006X\u0006\u0013\\6\u0006a\u0007A\f4/_LBWc";
      l[19] = "\u000f}g\r\b\u0016\n\"=`伬可株发栝桹桨佱台发\u0004Y\u001bQIuo\u000eNE\u000f";
      l[20] = "Y5oD\fQ\\j5)桬厨桼厙佑只桬厨桼厙\f\u0012H\u0012\n9f\u0015H\u0016Y";
      l[21] = "S6U!v\u0019Vi\u000fL双栺厬厚栯休栖佾桶桀6ue^\u0015>]\"0JS";
      l[22] = "\u0018\u001e\u0007^JEB\u0015\u0003\u000eq<o39;5<r24cJ\u0014JBUS\u0010\u001fN\u0012";
      l[23] = "e\u0002-)\n\u0005`]wD桪佢桀厮厍伙桪栦伄厮N}\u0019B#\n%*LVe";
      l[24] = "SsU{\u0007\r\u001b`B=m厮桳作召伞桴桴桳栘佲CT\u001f\u00109E#\u001c\f\u0007\u007f";
      l[25] = "o(a{y\u0013?:9i\u001c\u001eSin:x\u000eol|law";
      l[26] = "D$B<=\u0002A{\u0018Q伙佥桡桒核伌桝佥伥厈!jyA\u0017(KmyED";
      l[27] = "^38\u001a@\u0014[lbw佤佳桻企伆伪佤样伿桅[NSS\u0018;0\u0019\u0006G^";
      l[28] = "\u000fjG*;d\n5\u001dG桛桇株佘佹会伟桇佮叆$~(#IbO)}7\u000f";
      l[29] = "\u0012\u000bNf/i\u0017T\u0014\u000b伋桊佳厧佰栒伋桊样伹-790C\u001d\u00172fj";
      l[30] = "\u001dy\u0005k4']jImY\u0013}[)K\u0007\u0001d\u0001Jr+)Mn\nag/";
      l[31] = ";4|3\u001fx>k&^桿厁栞伆佂桇伻厁叄厘\u001f`\u001b28fv4\\~|";
      l[32] = "f}\u000e\u0019\bNc\"Tt\u0018tdc\u0016\u001bM\u0014\"j\u0010OqJ+i\u0002H\u0011\f\"oVt";
      l[33] = "\u001djF1s3\u00185\u001c\\叉及佼叆另桅叉及叢栜%e`t[bN25`\u001d";
      l[34] = "G\t$7\n\u0019BV~Z厰栺厸桿厄桃桪佾厸伻Gc\u0019^\u0001\u0001,4LJG";
      l[35] = "5E@?)K0\u001a\u001aR厓伬栐叩佾厑厓桨栐佷#k:\fsMH<o\u00185";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private void p() {
      this.友何何树友友友何树友.clear();
      this.树友树友何友树友树友.clear();
      this.树树友何何何友何树友.clear();
      this.何何树树树何树何何友.clear();
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = l[var4];
      if (var5 instanceof String) {
         String var6 = m[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         l[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = l[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   public void M() {
      this.p();
   }

   private static String HE_DA_WEI() {
      return "何树友，和树做朋友";
   }
}
