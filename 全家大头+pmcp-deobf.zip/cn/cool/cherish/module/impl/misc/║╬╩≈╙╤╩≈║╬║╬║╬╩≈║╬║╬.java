package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.value.impl.BooleanValue;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeableLeatherItem;
import net.minecraft.world.item.ItemStack;

public class 何树友树何何何树何何 extends Module implements 何树友 {
   public static 何树友树何何何树何何 树树何何何何友友友何;
   private final BooleanValue 树树友何友树何树友何 = new BooleanValue("Armor Color", "按盔甲颜色", true);
   private final BooleanValue 树友何友何何树友树友 = new BooleanValue("Color", "按颜色", true);
   private final BooleanValue 树友树树友树何友友何 = new BooleanValue("Scoreboard Team", "按计分板", false);
   private static final int 树树树何何何树何友树;
   private static final int 友何树友何何何友友何;
   private static final int 树何何何何树树何友友;
   private static final int 何树树何树何友何树友;
   private static final int 何友何树树何友何友何;
   private static final int 树友何友树树树树友友;
   private static final int 树何树何友何何友树何;
   private static final int 树何友树树何树何友树;
   private static String 何何树何友何何树树树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[18];
   private static final String[] n = new String[18];
   private static String HE_JIAN_GUO;

   public 何树友树何何何树何何() {
      super("Teams", "队伍", 树何友友何树友友何何.友树何友何树树树树何);
      树树何何何何友友友何 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2591582745858929364L, 4903101438142985776L, MethodHandles.lookup().lookupClass()).a(8928228368459L);
      // $VF: monitorexit
      a = var10000;
      c();
      z("a3aRxc");
      Cipher var11;
      Cipher var22 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(136433886460194L << var12 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[11];
      int var16 = 0;
      String var15 = "(\u0006 \u009e\tH¹à\u0089£)k[ä\u0019\u0091\u0011%\u0090ë\u0007`>ùQ\u00034Z\u0011\u0003Bx\u0010\u00844«\fQ\u001eäµíÝ\u0013Ó$Nú\u0016 ú\u0081W¸¦-Ø\u0003\u001a }F½Àñø.>©\u0001KóùÁmÚ§}TÊ¡\u0092\u0010\u0088îü´ùutù\u0080\u0088ë\u0014ßïVP\u0018«>\u009d\u0093¾ìÎ1\u0003\u009e)6aÓ\u0097IM6ªB\u001bO\u001bW\u0018\u0017;\u0095®ñõ\u0080ìSÒ=§\u0089\u009d\u009a¾.CìHé\u00934Z\u0018\u000f\nx¥] \u009bÞ\u009c\u0097\u008a\u009fïí\"\u0018©\nU´ÐÃW^\u0010\u008an\u0014mSOVl\u00adf¦\u0092X\b8¾\u0010¶4åøÏ\u0098õ\u001aê\r\u0080´\u0089Óøï";
      short var17 = 208;
      char var14 = ' ';
      int var21 = -1;

      label54:
      while (true) {
         String var23 = var15.substring(++var21, var21 + var14);
         int var10001 = -1;

         while (true) {
            String var34 = c(var11.doFinal(var23.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var34;
                  if ((var21 += var14) >= var17) {
                     c = var18;
                     h = new String[11];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var25 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(136433886460194L << var1 * 8 >>> 56);
                     }

                     var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[22];
                     int var3 = 0;
                     String var4 = "\u0001R[s\u007feL\u008fgÓ/ðn÷)¸ÒwðÑÍØáPìÙ\u000eÛ\u001e~øTã\u0098õÔ<\u0080ëY\u007f\u0097Y;ãÄÞ\u001a\u0090\u0090\u0011qÅP\u000bn´b xÑ5ñ\u0088OmýÉ\nçÁ\\\u000eK\u000b¥ò^³¸\u0093.ÝÚ@%ÁÝa\u0090\u0087e\u0007Ï%s\u0016:G¥H\u0089_c«÷^£ø¿\u0094)\u0085x2¥VIÃÌ\u0000\u0093/\u0087³\u009a\u0000¨Ö\b©\u008aõ¶LÏ\u0083H!\u008d\u0088EuäcYÝòýdÌ9ï\u0093ð\u009fl1ö\u0016";
                     short var5 = 160;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var26 = var6;
                        var10001 = var3++;
                        long var38 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var41 = -1;

                        while (true) {
                           long var8 = var38;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var43 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var41) {
                              case 0:
                                 var26[var10001] = var43;
                                 if (var2 >= var5) {
                                    j = var6;
                                    k = new Integer[22];
                                    何树树何树何友何树友 = 170;
                                    树友何友树树树树友友 = 16733695;
                                    树何何何何树树何友友 = 5635925;
                                    何友何树树何友何友何 = 5636095;
                                    友何树友何何何友友何 = 16777045;
                                    树树树何何何树何友树 = 16733525;
                                    树何友树树何树何友树 = 11184810;
                                    树何树何友何何友树何 = 16777215;
                                    return;
                                 }
                                 break;
                              default:
                                 var26[var10001] = var43;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "-â^\b2uDmd¦ù\u0015 §×L";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var32 = var2;
                           var2 += 8;
                           var7 = var4.substring(var32, var2).getBytes("ISO-8859-1");
                           var26 = var6;
                           var10001 = var3++;
                           var38 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var41 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var21);
                  break;
               default:
                  var18[var16++] = var34;
                  if ((var21 += var14) < var17) {
                     var14 = var15.charAt(var21);
                     continue label54;
                  }

                  var15 = "âÁ\u0005.Ô\u0016\b³0)\u0097-Â\rhy\u0010\u000e|&\u0018\u009f§ÏS¾\u0001 \u0002\u008c\u0001kx";
                  var17 = 33;
                  var14 = 16;
                  var21 = -1;
            }

            var23 = var15.substring(++var21, var21 + var14);
            var10001 = 0;
         }
      }
   }

   public boolean B(LivingEntity entity) {
      a();
      if (this.Q(new Object[]{52406761729175L})) {
         return false;
      } else if (this.树友树树友树何友友何.getValue() && mc.player.getTeam() != null && entity.getTeam() != null && mc.player.getTeam().isAlliedTo(entity.getTeam())) {
         return true;
      } else {
         Component displayName = mc.player.getDisplayName();
         if (this.树树友何友树何树友何.getValue() && entity instanceof Player entityPlayer) {
            ItemStack myHead = (ItemStack)mc.player.getInventory().armor.get(3);
            ItemStack entityHead = (ItemStack)entityPlayer.getInventory().armor.get(3);
            if (!myHead.isEmpty() && !entityHead.isEmpty()) {
               int myTeamColor = this.l(myHead);
               int entityTeamColor = this.l(entityHead);
               if (myTeamColor != -1 && entityTeamColor != -1) {
                  return myTeamColor == entityTeamColor;
               }
            }
         }

         if (this.树友何友何何树友树友.getValue() && !displayName.getString().isEmpty() && !entity.getDisplayName().getString().isEmpty()) {
            String targetName = entity.getDisplayName().getString().replace("§r", "");
            String clientName = displayName.getString().replace("§r", "");
            return targetName.startsWith("§" + clientName.charAt(1));
         } else {
            return false;
         }
      }
   }

   public String I(int color) {
      a();
      if (color == -1) {
         return "无";
      } else if (color == 16733525) {
         return "红";
      } else if (color == 16777045) {
         return "黄";
      } else if (color == 5635925) {
         return "绿";
      } else if (color == 170) {
         return "蓝";
      } else if (color == 5636095) {
         return "青";
      } else if (color == 16733695) {
         return "紫";
      } else if (color == 16777215) {
         return "白";
      } else {
         return color == 11184810 ? "灰" : "未知";
      }
   }

   private boolean Z(int color) {
      a();
      return color == -1
         ? false
         : color == 16733525
            || color == 16777045
            || color == 5635925
            || color == 170
            || color == 5636095
            || color == 16733695
            || color == 16777215
            || color == 11184810;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 40;
               case 1 -> 48;
               case 2 -> 37;
               case 3 -> 14;
               case 4 -> 6;
               case 5 -> 53;
               case 6 -> 49;
               case 7 -> 60;
               case 8 -> 15;
               case 9 -> 24;
               case 10 -> 29;
               case 11 -> 42;
               case 12 -> 38;
               case 13 -> 33;
               case 14 -> 5;
               case 15 -> 26;
               case 16 -> 51;
               case 17 -> 0;
               case 18 -> 61;
               case 19 -> 28;
               case 20 -> 7;
               case 21 -> 46;
               case 22 -> 20;
               case 23 -> 27;
               case 24 -> 43;
               case 25 -> 9;
               case 26 -> 57;
               case 27 -> 1;
               case 28 -> 30;
               case 29 -> 10;
               case 30 -> 17;
               case 31 -> 32;
               case 32 -> 22;
               case 33 -> 41;
               case 34 -> 56;
               case 35 -> 2;
               case 36 -> 45;
               case 37 -> 18;
               case 38 -> 39;
               case 39 -> 52;
               case 40 -> 59;
               case 41 -> 4;
               case 42 -> 34;
               case 43 -> 36;
               case 44 -> 47;
               case 45 -> 23;
               case 46 -> 50;
               case 47 -> 58;
               case 48 -> 21;
               case 49 -> 62;
               case 50 -> 25;
               case 51 -> 55;
               case 52 -> 54;
               case 53 -> 44;
               case 54 -> 31;
               case 55 -> 19;
               case 56 -> 16;
               case 57 -> 13;
               case 58 -> 3;
               case 59 -> 63;
               case 60 -> 8;
               case 61 -> 12;
               case 62 -> 11;
               default -> 35;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   public int i(Player player) {
      a();
      if (player == null) {
         return -1;
      } else {
         ItemStack helmet = (ItemStack)player.getInventory().armor.get(3);
         return helmet.isEmpty() ? -1 : this.l(helmet);
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/何树友树何何何树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28196;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/何树友树何何何树何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[ü\u008a\u008e\u0097\u000b\u0002¡\u009eO*\u0089\u008cD\u0016g\u0093, Ý1\u0098\u009b\u0087\u001d\u000bp, 93¬*\u008a+iàà\u009d:âïÊ_', !ª±ÚÅ{ûÈ, ²ö8")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void c() {
      m[0] = "2Db\\kk=\u0004/Wav8Y$\u0011ik5_ Z*m<Z \u0011im\"Ib佪栕叏桀使伙佪栕佑伄";
      m[1] = "ov,A\n,dy=\u000ew4w~4G";
      m[2] = void.class;
      n[2] = "java/lang/Void";
      m[3] = "g?pxb,l0a7\u001e5c*ot)\u0005u=ci8)b0";
      m[4] = "\"Pf`\u0019;-\u0010+k\u0013&(M -\u001b;%K$fX桅伔叵厃佖桧原厊佫伝";
      m[5] = "Hwh\u0001WXG7%\n]EBj.LNVGl#LQZ[uh WXG|'\fnVGl#";
      m[6] = "7+,D\u007f\u00057+;\u0018s\n-`/\u0005`\u0000=`=\u0004f\u0005-7v\u001a~\r +*D[\u0002/+6\u001e}\u001e ";
      m[7] = "%.W</$%.@`#+?e@}0(e\u0005L|\f8''o{19";
      m[8] = "\u0005\\A|,E\u000eSP3MK\u0005XTi";
      m[9] = "\u001d`gEEtG?1X\"双栿佒厕佨栻栖栿栖伋5\u0019`\u0017\u007f1NC?Ab";
      m[10] = "/v\u0000|B:*/L\u0013G_6(\u000fq\\!:w\u0006\u0013";
      m[11] = "\u0004\u007f\u000b\r\u0011k\u0001&Gb\u000f\u000e\u001d!\u0004\u0000\u000fp\u0011~\rbDh\u0007\"F\bCb\u0002`v";
      m[12] = "OGL'k(J\u001e\u0000HnM\u0011XJ48)\u0015D\\\"\u0007wRZMwcsNL[H";
      m[13] = "\u0013T\u0014\u0013e!\u0016\rX|栐厇桮栫厪桥佔厇厴佯iGx)\u0013Y\u0012\u0010qz\u0018";
      m[14] = "Si\u000eeD4V0B\n栱案叴佒厰栓併案叴佒s1Y<Sd\bfPoX";
      m[15] = "\u0010<z%Oe\u00116021z{i\u007fe\u000e){R\u007flLmA >3^/";
      m[16] = "uO\u0011O|\u0000p\u0016] 栉厦佌只伱佽栉厦栈只l\u001ba\buB\u0017Lh[~";
      m[17] = "\u001b%\u0011R!$\u001e|]=桔桘伢伞伱你厎厂厼伞lY+<\u0010/\t\\rp";
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 30937;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/何树友树何何何树何何", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/何树友树何何何树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 220 && var8 != 'K' && var8 != 'r' && var8 != 'h') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'C') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Y') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 220) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'K') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'r') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private int l(ItemStack helmet) {
      a();
      int helmetColor = j(helmet);
      return this.Z(helmetColor) ? this.j(helmetColor) : -1;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/何树友树何何何树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public static String a() {
      return 何何树何友何何树树树;
   }

   public String m(Player player) {
      int color = this.i(player);
      return this.I(color);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static int j(ItemStack stack) {
      a();
      return stack.getItem() instanceof DyeableLeatherItem ? ((DyeableLeatherItem)stack.getItem()).getColor(stack) : -1;
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private int j(int color) {
      a();
      if (color == 16733525) {
         return 16733525;
      } else if (color == 16777045) {
         return 16777045;
      } else if (color == 5635925) {
         return 5635925;
      } else if (color == 170) {
         return 170;
      } else if (color == 5636095) {
         return 5636095;
      } else if (color == 16733695) {
         return 16733695;
      } else if (color == 16777215) {
         return 16777215;
      } else {
         return color == 11184810 ? 11184810 : -1;
      }
   }

   public static void z(String var0) {
      何何树何友何何树树树 = var0;
   }

   private static String HE_SHU_YOU() {
      return "职业技术教育中心学校";
   }
}
