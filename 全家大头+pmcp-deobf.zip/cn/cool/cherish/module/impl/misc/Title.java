package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.client.树友何何何树何树友友;
import cn.cool.cherish.utils.misc.WebUtils;
import cn.cool.cherish.utils.misc.何友何树树友树何树友;
import cn.cool.cherish.utils.player.何树何树友树树友友何;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.SharedConstants;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.glfw.GLFWImage.Buffer;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import why.tree.friend.antileak.utils.CryptUtil;

public class Title extends Module implements 何树友 {
   private String 何何何树树友何何树何 = null;
   private boolean 友友何友树树何何何何 = false;
   private int 何何树树友何友树树树 = 0;
   private int 树树友树友何友树树何 = 0;
   private int 何何树何何树树树树树 = 0;
   private int 何何树友树树友何友树 = 0;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[23];
   private static final String[] k = new String[23];
   private static int _刘凤楠230622109211173513 _;

   public Title() {
      super("Title", "标题", 树何友友何树友友何何.友树何友何树树树树何);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(396443918023103936L, 1544050878987200559L, MethodHandles.lookup().lookupClass()).a(258949756474815L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(6239540858542L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[20];
      int var7 = 0;
      String var6 = "\u0085rº{Å& [\u0086W\u0098.\u008fº\u009b\u001f\u0010þLw.ü\u0004¨ä÷ø\u00ad\u009e\u0089î\t\u0093\u0018\u008dxLòêI\u001eÿ§|Ïà\u008e£¬§Y\u008a×¼\u0091\u001bÝ·\u0010û¤§ÙÄëÝaÈ^4¶ÐÇ!\u000b Ò^\u00194ö\nzw\u0092©æ\u009f³=¶\u009b:l\u001eUFìã¸-ÈÐÚÊ\u0082Ï\u0083(\u00adèÉõ\u0095/úÇó¬*Ï\u000b§CÃ÷¶\u0086Ù\u009a\u001d©?<\u0091sÓêytÅn_\"0oÇ\u0094\u0003(Ï/0ê8K\u0015j\u009cü¨ÏPÔ\"J\u0099Üêþ\u0006#VKÄ-~è3;õkÎ¹c\u008aº eU(©5\u0018¯uRâ¥\u009e\u000f¾\u0083\u008bXYÌD·\"å©ú$¼<Ðl@~íìÐÆP©(à\u009b\u0000Ò\u00104}\u0004³D£}Aôs=KkÅ§°\u0010\f·94:Òæñ,X~âò³ª\u001d8\u0019³¢=Àr\u0090\u009e}SÓÓx\u008a¨LLã£<§\u008eü\u008e¯iÀÉöÐß\u0006\u00adÏ5\u0000fn?ÇõFsñX@âW£\u0093$\u009dáO\u008d\u008f\u0010\u008eh&7\u0019\u0082ò\u008d\u0084îO)\u0090\u001fZê(Üý¤î\u009eÔ\u0086\u008aà\u000e·\u009c:ÞÛIJUÃ%\u0011\u001fBó\u000fÊ;T\u0092Ã¡p?½,\u0084?\u0087{W\u0010-TÝ\u0090¨\u0091rÀ³\b\u009c&újB½0\u000bä72vs+E/FÎ{s\fó\u0099\u0081p~ªR\u0089KÀ¤Êä\u0086¶jDqKU\u0094ðá\u0090WñÕdLôÙöú/\u0010U\u0014vT²×ÍÐ\bß0H(º`E(Ã¿Ó\u008eÍd\u008a£³6Â\u0004E$÷\u001f×m<U\u001b\u0000\u0010î\u0086ëý\u000fÐy\u0086(ÚdûnGH°á0\\«®ÍID7xB*þ q©&nu2þø\u0001¥»\u000f($\u0085@|áçø\u0000Û¿ÿ¡\"\u0005÷^P\u0084¬ÕÌ×\u0012";
      short var8 = 553;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[20];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "äÏleFªPQ'A\u0011=¥\n¯°\u0010X\u0097Ä\u0016oï\u0081X4Û\t\u00805çí±";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void F(LivingUpdateEvent event) {
      何树友树何何何树何何.a();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.树树友树友何友树树何++;
         if (this.树树友树友何友树树何 == 20) {
            this.何何树树友何友树树树++;
            this.树树友树友何友树树何 = 0;
         }

         if (this.何何树树友何友树树树 == 60) {
            this.何何树何何树树树树树++;
            this.何何树树友何友树树树 = 0;
         }

         if (this.何何树何何树树树树树 == 60) {
            this.何何树友树树友何友树++;
            this.何何树何何树树树树树 = 0;
         }

         int a = this.何何树树友何友树树树;
         int ax = this.何何树何何树树树树树;
         int var12 = this.何何树友树树友何友树;
         String playTime = "已游玩时间: " + var12 + " 时 " + ax + " 分 " + a + " 秒";
         mc.getWindow()
            .setTitle(
               this.何何何树树友何何树何 != null && !this.何何何树树友何何树何.isEmpty()
                  ? this.何何何树树友何何树何 + " | 现在时间: " + 何友何树树友树何树友.B(104697671685106L) + " | " + playTime + " | Cherish B3.7"
                  : "Waiting... | 现在时间: " + 何友何树树友树何树友.B(104697671685106L) + " | " + playTime + " | Cherish B3.7"
            );
      }
   }

   private void Z() {
      何树友树何何何树何何.a();

      try {
         long window = mc.getWindow().getWindow();
         String iconPath = Cherish.getResourcesManager().resources.getPath() + "\\icon\\";
         String icon16Path = iconPath + "cherish_icon_16x16.png";
         String icon32Path = iconPath + "cherish_icon_32x32.png";
         File icon16File = new File(icon16Path);
         File icon32File = new File(icon32Path);
         if (!icon16File.exists() || !icon32File.exists()) {
            return;
         }

         ByteBuffer icon16Buffer = Cherish.getResourcesManager().o(icon16File);
         ByteBuffer icon32Buffer = Cherish.getResourcesManager().o(icon32File);
         if (icon16Buffer != null && icon32Buffer != null) {
            MemoryStack stack = MemoryStack.stackPush();

            try {
               Buffer iconBuffer = GLFWImage.malloc(2, stack);
               IntBuffer width = stack.mallocInt(1);
               IntBuffer height = stack.mallocInt(1);
               IntBuffer channels = stack.mallocInt(1);
               ByteBuffer icon16Data = STBImage.stbi_load_from_memory(icon16Buffer, width, height, channels, 4);
               if (icon16Data != null) {
                  ((GLFWImage)iconBuffer.get(0)).set(width.get(0), height.get(0), icon16Data);
               }

               width.rewind();
               height.rewind();
               channels.rewind();
               ByteBuffer icon32Data = STBImage.stbi_load_from_memory(icon32Buffer, width, height, channels, 4);
               if (icon32Data != null) {
                  ((GLFWImage)iconBuffer.get(1)).set(width.get(0), height.get(0), icon32Data);
               }

               GLFW.glfwSetWindowIcon(window, iconBuffer);
               this.友友何友树树何何何何 = true;
               if (icon16Data != null) {
                  STBImage.stbi_image_free(icon16Data);
               }

               if (icon32Data != null) {
                  STBImage.stbi_image_free(icon32Data);
               }
            } catch (Throwable var21) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var20) {
                     var21.addSuppressed(var20);
                  }
               }

               throw var21;
            }

            if (stack != null) {
               stack.close();
            }
         }

         if (icon16Buffer != null) {
            MemoryUtil.memFree(icon16Buffer);
         }

         if (icon32Buffer != null) {
            MemoryUtil.memFree(icon32Buffer);
         }
      } catch (Exception var22) {
         var22.printStackTrace();
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private void e() {
      c<"Ý">(2125211234483160308L, 78089549979005L);

      try {
         if (何树何树友树树友友何.f(38856877526439L).contains(CryptUtil.Base64Crypt.decrypt(""))) {
            long window = mc.getWindow().getWindow();
            String iconPath = c<"l">(Cherish.getResourcesManager(), 2123917496637367334L, 78089549979005L).getPath() + "\\icon\\";
            String icon64Path = iconPath + "heypixel_icon.png";
            File icon64File = new File(icon64Path);
            if (!icon64File.exists()) {
               return;
            }

            ByteBuffer icon64Buffer = Cherish.getResourcesManager().o(icon64File);
            MemoryStack stack = MemoryStack.stackPush();

            try {
               Buffer iconBuffer = GLFWImage.malloc(1, stack);
               IntBuffer width = stack.mallocInt(1);
               IntBuffer height = stack.mallocInt(1);
               IntBuffer channels = stack.mallocInt(1);
               ByteBuffer icon64Data = STBImage.stbi_load_from_memory(icon64Buffer, width, height, channels, 4);
               if (icon64Data != null) {
                  ((GLFWImage)iconBuffer.get(0)).set(width.get(0), height.get(0), icon64Data);
                  GLFW.glfwSetWindowIcon(window, iconBuffer);
                  c<"Ë">(this, false, 2125372085247366471L, 78089549979005L);
                  STBImage.stbi_image_free(icon64Data);
               }
            } catch (Throwable var19) {
               if (stack != null) {
                  try {
                     stack.close();
                  } catch (Throwable var18) {
                     var19.addSuppressed(var18);
                  }
               }

               throw var19;
            }

            if (stack != null) {
               stack.close();
            }

            MemoryUtil.memFree(icon64Buffer);
         }

         mc.getWindow()
            .setIcon(
               mc.getVanillaPackResources(),
               SharedConstants.getCurrentVersion().isStable() ? c<"ë">(2124005871581572936L, 78089549979005L) : c<"ë">(2123717241549694321L, 78089549979005L)
            );
      } catch (Exception var20) {
         var20.printStackTrace();
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 58;
               case 1 -> 27;
               case 2 -> 39;
               case 3 -> 17;
               case 4 -> 36;
               case 5 -> 32;
               case 6 -> 8;
               case 7 -> 56;
               case 8 -> 23;
               case 9 -> 28;
               case 10 -> 63;
               case 11 -> 42;
               case 12 -> 35;
               case 13 -> 0;
               case 14 -> 61;
               case 15 -> 11;
               case 16 -> 2;
               case 17 -> 1;
               case 18 -> 5;
               case 19 -> 53;
               case 20 -> 26;
               case 21 -> 4;
               case 22 -> 21;
               case 23 -> 50;
               case 24 -> 9;
               case 25 -> 18;
               case 26 -> 57;
               case 27 -> 40;
               case 28 -> 38;
               case 29 -> 31;
               case 30 -> 6;
               case 31 -> 30;
               case 32 -> 43;
               case 33 -> 13;
               case 34 -> 51;
               case 35 -> 47;
               case 36 -> 29;
               case 37 -> 7;
               case 38 -> 45;
               case 39 -> 52;
               case 40 -> 19;
               case 41 -> 54;
               case 42 -> 60;
               case 43 -> 3;
               case 44 -> 48;
               case 45 -> 14;
               case 46 -> 59;
               case 47 -> 62;
               case 48 -> 33;
               case 49 -> 49;
               case 50 -> 24;
               case 51 -> 55;
               case 52 -> 41;
               case 53 -> 12;
               case 54 -> 10;
               case 55 -> 16;
               case 56 -> 44;
               case 57 -> 20;
               case 58 -> 37;
               case 59 -> 34;
               case 60 -> 46;
               case 61 -> 15;
               case 62 -> 22;
               default -> 25;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/Title" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 1954;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/Title", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[Ó\u0095|ç¥ªºÃ, ªÂÛAís\u0091§, ]3Y\u0019Ê\u0086h\u001f\u009fjò\u0011zúÄý, -©")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Throwable b(Throwable var0) {
      return var0;
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'l' && var8 != 203 && var8 != 235 && var8 != 'z') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'a') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 221) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'l') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 203) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 235) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/Title" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   public void h() {
      何树友树何何何树何何.a();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.何何何树树友何何树何 = null;
         this.何何树树友何友树树树 = 0;
         this.树树友树友何友树树何 = 0;
         this.何何树何何树树树树树 = 0;
         this.何何树友树树友何友树 = 0;
         mc.updateTitle();
         if (this.友友何友树树何何何何) {
            this.e();
            this.友友何友树树何何何何 = false;
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "?2c3G\u00050r.8M\u00185/%~E\u00058)!5\u0006\u00031,!~E\u0003/?c\u0004A\u001e09";
      j[1] = "wCP\u0007\u000bt|LAHqpoMQ\u0007Gtx";
      j[2] = "\u000bH/mn9\u0002F,$-4\u0004F8&02FW.\"w0\u0007U/mJ5\u0007I\u0011&w";
      j[3] = "6\t?q\u001a\u00139Irz\u0010\u000e<\u0014y<\u0000\b<\u000bb<\u0007\u0019&\bd`\u0016\u0019&ICw\u0006\u0013 \u0015rw\u000614\tpu\u0010\u000e";
      j[4] = "c\u001e7v%XfQ\u0007~gT";
      j[5] = "$^%\u00035Q+\u001eh\b?L.CcN7Q#Eg\u0005tW*@gN7W4S%伵桋叵桖佥佞伵桋佫伒";
      j[6] = "g\u001f:\u000bLCl\u0010+D1[\u007f\u0017\"\r";
      j[7] = boolean.class;
      k[7] = "java/lang/Boolean";
      j[8] = int.class;
      k[8] = "java/lang/Integer";
      j[9] = ")7-\"3\u0002&w`)9\u001f#*ko1\u0002.,o$r桼伟厒又伔桍厦厁伌佖";
      j[10] = "/g=*)Q$h,eH_/c(?";
      j[11] = "D\u0002L)Yn@\nQ}+厜档伶叽位栲框档桲佣\u0010\u00156\bRL!\u0011>\u0015\u0006";
      j[12] = "\u0002LP\u0001\u000b.T\u0015R\u001bq.9\u0012\u0015EN#\\G\u001c\t\u000bG";
      j[13] = ".\u0018w\u001cmT)\u0000* en7\u0003`J2\u0000q@b q\u00132\u0014&N7P0~";
      j[14] = "xx9\u0010\u0019/\u007f`d,厸取佂叝桌栵伦佈佂佃U\u0010\u000bhs\":R\u001ezs";
      j[15] = "d\u007f}~*zcg B伕伝栚叚栈桛压伝叀栀\u0011|s}a v-9yh";
      j[16] = "j\u0015[Z\u0014\u0019m\r\u0006f伫佾栔桪叴伻厵栺栔桪7XM\u001eoJP\t\u0007\u001af";
      j[17] = "\t\u001b\u000777p\u000e\u0003Z\u000b桌桓厭桤厨佖厖桓桷传k5nw\fD\fd$s\u0005";
      j[18] = "\u0015OphYB_\nq+!(b2DZz?/L0jZ\n\u001f\u0006uk\u0019";
      j[19] = "F\u000e4{7A\u0010VvpXK\u0011\u0017,a\"Z\u0011\u0017K'cQ\u0012\u0016+~i\rM";
      j[20] = "*\u0019Oy>x-\u0001\u0012E企伟伐桦栺历企伟桔伢#y$~r\u001bF,-27";
      j[21] = ")A/Chs.Yr\u007f佗伔桗佺伞桦栓桐桗栾CA1t,\u001e$\u0010{p%";
      j[22] = "\u0010_Qk0dZ\u001aP(H\u000fl/pK\b\u0013vf\u0012)1/RVXl0l";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   public void M() {
      树友何何何树何树友友.G(() -> {
         何树友树何何何树何何.a();

         try {
            String response = WebUtils.get(Cherish.何何何树何树友何何树);
            if (response != null && !response.isEmpty()) {
               this.何何何树树友何何树何 = 何友何树树友树何树友.H(response, 友友友树何友树友树友.x(1391347873739L, 1, 100) + ".", "。", 18555188824097L);
            }

            this.何何何树树友何何树何 = "无法获取标题";
            this.Z();
         } catch (Exception var9) {
            var9.printStackTrace();
            this.何何何树树友何何树何 = "获取标题失败";
         }
      }, 108624793298909L);
   }

   private static String HE_DA_WEI() {
      return "刘凤楠230622109211173513";
   }
}
