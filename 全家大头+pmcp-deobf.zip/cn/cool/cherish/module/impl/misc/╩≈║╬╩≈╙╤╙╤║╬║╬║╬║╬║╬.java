package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.world.entity.player.Player;

public class 树何树友友何何何何何 extends Module implements 何树友 {
   private final BooleanValue 何树树何何友友树树友 = new BooleanValue("Auto GG", "自动GG", true);
   private final 何何何友友何树何何何 友友友友树友友友何友 = new 何何何友友何树何何何("GG Keywords", "GG关键词", "胜利,赢,Win,Victory,获胜").A(this.何树树何何友友树树友::getValue);
   private final 何何何友友何树何何何 树树友何何友何树何何 = new 何何何友友何树何何何("GG Message", "GG消息", "GG").A(this.何树树何何友友树树友::getValue);
   private final BooleanValue 何友何树树何友树何树 = new BooleanValue("Kill Taunt", "击杀嘲讽", true);
   private final 何何何友友何树何何何 树树友友树树树友友友 = new 何何何友友何树何何何("Kill Message", "击杀消息", "L").A(this.何友何树树何友树何树::getValue);
   private Player 友友树树何树友何树何 = null;
   private final 何友友何树何树何树友 何何友友树友树树树友 = new 何友友何树何树何树友(51913986529303L);
   private final 何友友何树何树何树友 树树何何何何树何何友 = new 何友友何树何树何树友(51913986529303L);
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[24];
   private static final String[] n = new String[24];
   private static int _何炜霖国企变私企 _;

   public 树何树友友何何何何何() {
      super("AutoGG", "自动GG", 树何友友何树友友何何.友树何友何树树树树何);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-738811331123901619L, 5877490733443400702L, MethodHandles.lookup().lookupClass()).a(66615650048193L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(140143398972988L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[15];
      int var18 = 0;
      String var17 = "¶\u000eÀI\u0099ÙìÄ/sý\u0090 ï<SñEÐ\u001aêõªå\u0010\u0004\u0012\u0087\"Â¹Lº\u009aÅ;S.\b\u009b± T_îBÜûÑcøKzv÷>\u0096\fþp2\u00197!;VB\u0010q\u008cMï\\æ *è Í\u0089\u0010\u001d\u0013\u008eà\u0088´\u0002\u00172àvgO{b\ri¤þ\u0001u#¬\u008a¥Ù ü\u00ad_\ri\u0003g\fÉ\u0096\u0088\u0098BûMË\\9µ\u00871Q\u008b×±FEá±/\u0006é >z,\\àæÿ\u0097±\u008d³#\u008b\u007fGIïaÝ\u0004k¨yÔ\u0010\u0082 Ó(îs\u000e\u0010f\u0002á:\bd\u0016·Õ\u0011[~!Gµ\u0004\u0018\u00ad\u000fàµ<\u008bE0÷Åò1'´g¨\u0003³-\u0087\u000e\u0089\u0004Ê x\u007fAÞ¦Iø\u0085KÙw\u0090¢¬\u000e\u0007$\u001by\u0007ü\u0017ï\u0084nÑ\u001aQ£\u0084\u001bç\u0010\b¥gýæWoÔ\u0084IYóïw/U8¡EÔ¾ÓñX3\\G\u008aÛgeðH\u008bø6´©òÄì®u\u009a{&y\u008fî\u008c34\u0004©=ø\u009d+òRT\u0014a\b\u0019!å§u\u0017\u0083&ç\u0018Öÿ#lm\u0010TÒ\u001c~ï\u0015r\u0090\u001fé¥*\u0095\u0088\u001bÄïO\u00104Ævî\u0096\u009dØ\u0084\"1ãÙvsà¶";
      short var19 = 364;
      char var16 = 24;
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[15];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(140143398972988L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "Qä«ê½.Eå\u008bB)åZÿ¾\f".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "\"µ\u008fô\u009d¾ö¶\u0013Ñ\u00997Cx¥®I³:s\u0013ñÓ\u0082(Ë$É\u0014\u0014<\u0081 ·#¨{r\u000e\u0081áÀmâÑÃåÎU\u0002iµ¦¨XaÜyt«MèNN\u001b";
                  var19 = 65;
                  var16 = ' ';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 18;
               case 1 -> 62;
               case 2 -> 20;
               case 3 -> 56;
               case 4 -> 53;
               case 5 -> 34;
               case 6 -> 50;
               case 7 -> 9;
               case 8 -> 32;
               case 9 -> 43;
               case 10 -> 44;
               case 11 -> 13;
               case 12 -> 6;
               case 13 -> 38;
               case 14 -> 54;
               case 15 -> 55;
               case 16 -> 0;
               case 17 -> 29;
               case 18 -> 27;
               case 19 -> 14;
               case 20 -> 30;
               case 21 -> 15;
               case 22 -> 8;
               case 23 -> 2;
               case 24 -> 23;
               case 25 -> 41;
               case 26 -> 25;
               case 27 -> 60;
               case 28 -> 16;
               case 29 -> 59;
               case 30 -> 17;
               case 31 -> 35;
               case 32 -> 19;
               case 33 -> 40;
               case 34 -> 10;
               case 35 -> 3;
               case 36 -> 52;
               case 37 -> 47;
               case 38 -> 26;
               case 39 -> 36;
               case 40 -> 7;
               case 41 -> 46;
               case 42 -> 51;
               case 43 -> 22;
               case 44 -> 42;
               case 45 -> 24;
               case 46 -> 12;
               case 47 -> 63;
               case 48 -> 37;
               case 49 -> 4;
               case 50 -> 28;
               case 51 -> 48;
               case 52 -> 49;
               case 53 -> 1;
               case 54 -> 57;
               case 55 -> 33;
               case 56 -> 39;
               case 57 -> 5;
               case 58 -> 61;
               case 59 -> 21;
               case 60 -> 31;
               case 61 -> 58;
               case 62 -> 45;
               default -> 11;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树友友何何何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13628;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树友友何何何何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u000771\u0003\u0087y\u0095¦\u0015\u0099ò\u0090v$OE, ×sÙ\u001a\u00987èö, W×Ü\u00957ÙàB>\u009e\u0095õ+\u0094Ô», é\u0000\u009bðqèDªfãts\\\u009fO·, ¢L\t,\u0011\u009dÉY\u001bý$Â½\u0094\u009d\u009d, z\u000e\u000bì©\u0087.\u00ad]Ç\u009b\u0082$æÑã, ÖÌTÎ\u009c¤\u0083\u0015, UýðÇ\u00078U:Ù\u009ct5\"ðçq, ®óµÔ)\u0004 \u0094¥\u001cæÊ\t«\"\u0087, :éOíî\u0017êÎ, MMÎÏ\f\u0080\u008fé3ð/\u009e´\u007f¶S\u009aisá\u008e8ÇÎ>\u0004\u001báÈ\u0093Yý, cd3z dÂ$÷-")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 4480;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树友友何何何何何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 252 && var8 != 233 && var8 != 211 && var8 != 'x') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 223) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'S') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 252) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 233) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 211) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树友友何何何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树何树友友何何何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      m[0] = "\u000e\u0013(U\u0012\f\u0001Se^\u0018\u0011\u0004\u000en\u0018\u0010\f\t\bjSS\n\u0000\rj\u0018\u0010\n\u001e\u001e(栧伨桲厦厶体佣伨伶伸";
      m[1] = "\u00150=++\u000b\u001app !\u0016\u001f-{f2\u0005\u001a+vf-\t\u00062=\n+\u000b\u001a;r&\u0012\u0005\u001a+v";
      m[2] = "SQ \u000f3~\\\u0011m\u00049cYLfB1~TJb\trx]ObB1xC\\ 伹桍叚校佪佛伹桍佄佥";
      m[3] = "\u0007xq\u0004%0\fw`KX(\u001fpi\u0002";
      m[4] = "7\fmU|\u0017<\u0003|\u001a\u0000\u000e3\u0019rY7>%\u000e~D&\u00122\u0003";
      m[5] = "\u0016SIr\b<\u0016S^.\u00043\f\u0018J3\u00179\u001c\u0018X2\u0011<\fO\u0013,\t4\u0001SOr59\u0019OX.";
      m[6] = "\u0005^U\u00040\u0006\u0005^BX<\t\u001f\u0015BF4\n\u0005O\u000fZ1\u000e\u0012^S\u0004\u0011\u0000\bZMz1\u000e\u0012^S";
      m[7] = "*\u0002\u0012\fId*\u0002\u0005PEk0I\u0005NMh*\u0013HOQa0\u000e\u0016NEt!\u0015HaHd!\t\u0012rEn/\u0002\u0012nM~0\u0002\bGV";
      m[8] = "ww@dc#x7\roi>}j\u0006)y8}u\u001d)余厇叟佌桿佒栝伙栅叒";
      m[9] = "\u00168\u0015EYA\u0019xXNS\\\u001c%S\b@O\u0019#^\b_C\u0005:\u0015佳佣佻厾厝佮样佣佻传";
      m[10] = "BGhP)>M\u0007%[##HZ.\u001d+>E\\*Vh桀佴叢厍佦桗厚只佼伓";
      m[11] = "'\u0012\u0000:~n,\u001d\u0011u\u001f`'\u0016\u0015/";
      m[12] = "&3qv1\u0001h#~p\\厡栀伇叟但桅桻栀桃佁\u001bc\u000bt7qx-\u001b{1";
      m[13] = "\u001cWh\u0001\r3\\\u000eo\u0015g0%\rw\r\u000e`\u001bH)\r\u000bY";
      m[14] = "\u000eDx\u0014Q*O\u0011\u007f\u000fi:e\u0017'BWm\ry\u001fOQ,\tP#\u0011\u0017n\u000f";
      m[15] = "`\u0018v$I.jNtH佪伂又厰栊压栮框栒厰\u0013uK%d\u001c\"&\u000e&5";
      m[16] = "6%).J\\<s+B佩栴桄伓休厁号栴桄厍L{\u0005Q`q(<E\u00107";
      m[17] = "d^9ie2n\b;\u0005rC5Dlij*7W5b\u001by~\u00050tr{m\\;\u0005";
      m[18] = "\fD\u001cU\u001d&\u0006\u0012\u001e9桺桎厤佲伤叺伾桎伺佲y\u0007\u0007k\u000b\u0017HZ\u0012'^";
      m[19] = "\u007f\u001c#~*duJ!\u0012厗取栍桮伛栋厗佈栍伪F)0u/G=bo.+";
      m[20] = "r\u001cuU\b6xJw9厵厄叚厴栉叺厵厄佄厴\u0010\u0007\u0012{uO!Z\u00077 ";
      m[21] = "\u0007}\u0017\r` \r+\u0015a标案厯叕桫桸标厒厯叕r_zm\u0000.C\u0002o!U";
      m[22] = "aZ\u001aRK.k\f\u0018>栬框佗佬伢佣栬伂佗史\u007f\u0003I%e^NP\f&4";
      m[23] = "f\u00163\u0015\u0000!l@1y伣厓佐桤桏伤厽桉佐桤V@O,0B2\u0007\u000fmg";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @EventTarget
   public void j(PacketEvent event) {
      d<"S">(4511543420958916990L, 80515168222879L);
      if (!this.Q(new Object[]{52406761729175L})) {
         if (event.getPacket() instanceof ClientboundSetTitleTextPacket wrapper && d<"ü">(this, 4511295996695993393L, 80515168222879L).getValue()) {
            Component titleComponent = wrapper.getText();
            String titleText = Component.literal(titleComponent.getString()).getString();
            String[] keywords = d<"ü">(this, 4511019820930887406L, 80515168222879L).getValue().split(",");
            boolean containsGGKeyword = false;
            int var18 = keywords.length;
            int var19 = 0;
            if (0 < var18) {
               String keyword = keywords[0];
               if (titleText.contains(keyword.trim())) {
                  containsGGKeyword = true;
               }

               var19++;
            }

            if (containsGGKeyword && d<"ü">(this, 4511680256197975037L, 80515168222879L).c(c<"o">(19609, 8874364856839527705L), 41972279541307L)) {
               this.A(d<"ü">(this, 4511420633003917805L, 80515168222879L).getValue());
               d<"ü">(this, 4511680256197975037L, 80515168222879L).D(11747522392279L);
            }
         }
      }
   }

   @EventTarget
   public void j(LivingUpdateEvent event) {
      d<"S">(4917661889464679389L, 134698932454460L);
      if (!this.Q(new Object[]{52406761729175L})) {
         if (d<"ü">(this, 4916104573722219961L, 134698932454460L).getValue()) {
            if (d<"ü">(this, 4915845067956993166L, 134698932454460L) != null && !d<"ü">(this, 4915845067956993166L, 134698932454460L).isAlive()) {
               if (d<"ü">(this, 4916174831587025119L, 134698932454460L).c(c<"o">(1549, 4815413318809950092L), 41972279541307L)) {
                  String message = ""
                     + d<"ü">(this, 4915845067956993166L, 134698932454460L).getName().getString()
                     + " "
                     + d<"ü">(this, 4915986339738692905L, 134698932454460L).getValue();
                  this.A(message);
                  d<"ü">(this, 4916174831587025119L, 134698932454460L).D(11747522392279L);
               }

               d<"é">(this, null, 4915845067956993166L, 134698932454460L);
            }
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void A(String message) {
      何树友树何何何树何何.a();
      if (mc.player != null) {
         mc.player.connection.sendChat(message);
      }
   }

   @EventTarget
   public void A(AttackEvent event) {
      何树友树何何何树何何.a();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.何友何树树何友树何树.getValue()) {
            if (event.getTarget() instanceof Player player && player != mc.player) {
               this.友友树树何树友何树何 = player;
            }
         }
      }
   }

   @EventTarget
   public void W(WorldEvent event) {
      this.友友树树何树友何树何 = null;
   }

   private static String HE_DA_WEI() {
      return "何炜霖230622200409390090";
   }
}
