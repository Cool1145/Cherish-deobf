package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.友树树何何树树何何树;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.client.树何树树何树何何树何;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.other.BlinkEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPongPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;
import why.tree.friend.antileak.Fucker;

public class 树友何友何友友何友何 extends Module implements 何树友 {
   public static 树友何友何友友何友何 友何树何友友友树何友;
   private static final boolean 何友友何何友何友树友 = false;
   public final BooleanValue 树友树树友何友友友友;
   private final BooleanValue 友何何友何何何友友树;
   private final BooleanValue 树友何何何树何友树树;
   private final BooleanValue 何友树何何何何树何树;
   public final BooleanValue 何树友友何树何树何树;
   private final BooleanValue 树友友树树何树友何友;
   private final BooleanValue 何何何何何友何友友何;
   private final BooleanValue 何何树何何何树何树树;
   private final BooleanValue 友友何何树何何树何友;
   private final BooleanValue 树树友何友树树友何树;
   private final BooleanValue 友何树树何树何何友树;
   private final BooleanValue 何友友树树树友树何何;
   private final BooleanValue 友友树树友友树何树树;
   private final BooleanValue 友何树友树友何友何何;
   private final BooleanValue 友树树树何树何何树树;
   private ServerboundContainerClosePacket 树树树何友友友树树友;
   private final 树友树友友何何树何何 树何树树树何树何友友;
   private long 树友何何树友友何友友;
   private boolean 树友何树何树友友树何;
   private long 树树树友友树何何友友;
   private long 何树友何树树树树何树;
   private int 何树友树何树树树友树;
   private int 友友友何树何友树树何;
   private static final double[] 友何友友友何何何何友;
   private static final double 友树何树友何何友友何 = 1.0E-10;
   private final Random 友何何树何何友树友友;
   private float 友何友友何友树友何何;
   private float 友树友树何树何何何何;
   private float 友友友何友何友树友友;
   private float 树何友友友友何何何何;
   private float 何树友友何友友友何树;
   private float 友友友树树何树何何何;
   private float 树何树何树树友树树树;
   private float 树友树何友友树友友树;
   private float 何何树树何友友友何树;
   private float 友树友树友树树何友何;
   private boolean 友友树树友友树友友友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[58];
   private static final String[] n = new String[58];
   private static int _何大伟为什么要诈骗何炜霖 _;

   public 树友何友何友友何友何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/misc/树友何友何友友何友何.a J
      // 003: ldc2_w 137962929073621
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 76763107217978
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 2820
      // 014: ldc2_w 2422898639648042898
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 19451
      // 021: ldc2_w 5867006194032176986
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w 4159865487275577567
      // 02e: lload 1
      // 02f: invokedynamic Ø (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/BooleanValue
      // 03b: dup
      // 03c: sipush 32125
      // 03f: ldc2_w 2755184492176169441
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 29353
      // 04c: ldc2_w 4733787910217520641
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 0
      // 057: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 05a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 05d: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.树友树树友何友友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 060: aload 0
      // 061: new cn/cool/cherish/value/impl/BooleanValue
      // 064: dup
      // 065: sipush 28939
      // 068: ldc2_w 5340115956304696734
      // 06b: lload 1
      // 06c: lxor
      // 06d: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 072: sipush 22722
      // 075: ldc2_w 3506960450296216689
      // 078: lload 1
      // 079: lxor
      // 07a: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07f: bipush 0
      // 080: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 083: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 086: aload 0
      // 087: invokedynamic get (Lcn/cool/cherish/module/impl/misc/树友何友何友友何友何;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/misc/树友何友何友友何友何.U ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 08c: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 08f: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 092: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.友何何友何何何友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 095: aload 0
      // 096: new cn/cool/cherish/value/impl/BooleanValue
      // 099: dup
      // 09a: sipush 31522
      // 09d: ldc2_w 7213032761776136064
      // 0a0: lload 1
      // 0a1: lxor
      // 0a2: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0a7: sipush 31979
      // 0aa: ldc2_w 269048194806667379
      // 0ad: lload 1
      // 0ae: lxor
      // 0af: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b4: bipush 0
      // 0b5: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0b8: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0bb: aload 0
      // 0bc: ldc2_w 4160142947367355591
      // 0bf: lload 1
      // 0c0: invokedynamic Ì (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c5: dup
      // 0c6: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 0c9: pop
      // 0ca: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 0cf: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0d2: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 0d5: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.树友何何何树何友树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0d8: aload 0
      // 0d9: new cn/cool/cherish/value/impl/BooleanValue
      // 0dc: dup
      // 0dd: sipush 11046
      // 0e0: ldc2_w 4738282274086850469
      // 0e3: lload 1
      // 0e4: lxor
      // 0e5: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ea: sipush 23256
      // 0ed: ldc2_w 2139838054396427847
      // 0f0: lload 1
      // 0f1: lxor
      // 0f2: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f7: bipush 0
      // 0f8: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0fb: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0fe: aload 0
      // 0ff: ldc2_w 4160142947367355591
      // 102: lload 1
      // 103: invokedynamic Ì (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 108: dup
      // 109: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 10c: pop
      // 10d: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 112: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 115: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 118: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.何友树何何何何树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 11b: aload 0
      // 11c: new cn/cool/cherish/value/impl/BooleanValue
      // 11f: dup
      // 120: sipush 26418
      // 123: ldc2_w 8197981586788074411
      // 126: lload 1
      // 127: lxor
      // 128: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 12d: sipush 19298
      // 130: ldc2_w 8919695380601106393
      // 133: lload 1
      // 134: lxor
      // 135: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 13a: bipush 0
      // 13b: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 13e: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 141: aload 0
      // 142: ldc2_w 4160142947367355591
      // 145: lload 1
      // 146: invokedynamic Ì (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14b: dup
      // 14c: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 14f: pop
      // 150: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 155: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 158: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 15b: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.何树友友何树何树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 15e: aload 0
      // 15f: new cn/cool/cherish/value/impl/BooleanValue
      // 162: dup
      // 163: sipush 2338
      // 166: ldc2_w 8967464878140796297
      // 169: lload 1
      // 16a: lxor
      // 16b: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 170: sipush 23561
      // 173: ldc2_w 4779861563850160259
      // 176: lload 1
      // 177: lxor
      // 178: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 17d: bipush 0
      // 17e: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 181: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 184: aload 0
      // 185: ldc2_w 4160142947367355591
      // 188: lload 1
      // 189: invokedynamic Ì (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 18e: dup
      // 18f: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 192: pop
      // 193: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 198: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 19b: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 19e: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.树友友树树何树友何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1a1: aload 0
      // 1a2: new cn/cool/cherish/value/impl/BooleanValue
      // 1a5: dup
      // 1a6: sipush 24716
      // 1a9: ldc2_w 6107877810887509000
      // 1ac: lload 1
      // 1ad: lxor
      // 1ae: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b3: sipush 12100
      // 1b6: ldc2_w 6235689998750256096
      // 1b9: lload 1
      // 1ba: lxor
      // 1bb: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c0: bipush 0
      // 1c1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1c4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1c7: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.何何何何何友何友友何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1ca: aload 0
      // 1cb: new cn/cool/cherish/value/impl/BooleanValue
      // 1ce: dup
      // 1cf: sipush 9726
      // 1d2: ldc2_w 1684769314111783257
      // 1d5: lload 1
      // 1d6: lxor
      // 1d7: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1dc: sipush 29770
      // 1df: ldc2_w 1264470326861320445
      // 1e2: lload 1
      // 1e3: lxor
      // 1e4: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e9: bipush 0
      // 1ea: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1ed: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1f0: aload 0
      // 1f1: invokedynamic get (Lcn/cool/cherish/module/impl/misc/树友何友何友友何友何;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/misc/树友何友何友友何友何.j ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 1f6: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 1f9: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 1fc: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.何何树何何何树何树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1ff: aload 0
      // 200: new cn/cool/cherish/value/impl/BooleanValue
      // 203: dup
      // 204: sipush 24565
      // 207: ldc2_w 7660501836029787002
      // 20a: lload 1
      // 20b: lxor
      // 20c: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 211: sipush 15510
      // 214: ldc2_w 4227008031195961371
      // 217: lload 1
      // 218: lxor
      // 219: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 21e: bipush 0
      // 21f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 222: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 225: aload 0
      // 226: ldc2_w 4159710013663179230
      // 229: lload 1
      // 22a: invokedynamic Ì (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 22f: dup
      // 230: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 233: pop
      // 234: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 239: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 23c: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 23f: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.友友何何树何何树何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 242: aload 0
      // 243: new cn/cool/cherish/value/impl/BooleanValue
      // 246: dup
      // 247: sipush 31736
      // 24a: ldc2_w 1461452038315564894
      // 24d: lload 1
      // 24e: lxor
      // 24f: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 254: sipush 9430
      // 257: ldc2_w 4917371237752275039
      // 25a: lload 1
      // 25b: lxor
      // 25c: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 261: bipush 0
      // 262: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 265: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 268: aload 0
      // 269: ldc2_w 4159710013663179230
      // 26c: lload 1
      // 26d: invokedynamic Ì (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 272: dup
      // 273: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 276: pop
      // 277: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 27c: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 27f: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 282: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.树树友何友树树友何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 285: aload 0
      // 286: new cn/cool/cherish/value/impl/BooleanValue
      // 289: dup
      // 28a: sipush 15311
      // 28d: ldc2_w 8756997371189534531
      // 290: lload 1
      // 291: lxor
      // 292: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 297: sipush 5453
      // 29a: ldc2_w 836057769827086787
      // 29d: lload 1
      // 29e: lxor
      // 29f: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2a4: bipush 0
      // 2a5: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2a8: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2ab: aload 0
      // 2ac: ldc2_w 4159710013663179230
      // 2af: lload 1
      // 2b0: invokedynamic Ì (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2b5: dup
      // 2b6: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 2b9: pop
      // 2ba: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 2bf: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 2c2: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 2c5: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.友何树树何树何何友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2c8: aload 0
      // 2c9: new cn/cool/cherish/value/impl/BooleanValue
      // 2cc: dup
      // 2cd: sipush 29227
      // 2d0: ldc2_w 7758134809019995832
      // 2d3: lload 1
      // 2d4: lxor
      // 2d5: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2da: sipush 17919
      // 2dd: ldc2_w 6833038277856911720
      // 2e0: lload 1
      // 2e1: lxor
      // 2e2: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2e7: bipush 0
      // 2e8: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2eb: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2ee: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.何友友树树树友树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2f1: aload 0
      // 2f2: new cn/cool/cherish/value/impl/BooleanValue
      // 2f5: dup
      // 2f6: sipush 31009
      // 2f9: ldc2_w 2950888668352339367
      // 2fc: lload 1
      // 2fd: lxor
      // 2fe: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 303: sipush 24039
      // 306: ldc2_w 601419493181290876
      // 309: lload 1
      // 30a: lxor
      // 30b: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 310: bipush 0
      // 311: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 314: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 317: aload 0
      // 318: ldc2_w 4158632000561903464
      // 31b: lload 1
      // 31c: invokedynamic Ì (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 321: dup
      // 322: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 325: pop
      // 326: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 32b: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 32e: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 331: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.友友树树友友树何树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 334: aload 0
      // 335: new cn/cool/cherish/value/impl/BooleanValue
      // 338: dup
      // 339: sipush 10467
      // 33c: ldc2_w 6770572651517250664
      // 33f: lload 1
      // 340: lxor
      // 341: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 346: sipush 28222
      // 349: ldc2_w 2807807255210019502
      // 34c: lload 1
      // 34d: lxor
      // 34e: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 353: bipush 0
      // 354: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 357: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 35a: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.友何树友树友何友何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 35d: aload 0
      // 35e: new cn/cool/cherish/value/impl/BooleanValue
      // 361: dup
      // 362: sipush 2790
      // 365: ldc2_w 5083428838338145871
      // 368: lload 1
      // 369: lxor
      // 36a: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 36f: sipush 12302
      // 372: ldc2_w 699920019579376788
      // 375: lload 1
      // 376: lxor
      // 377: invokedynamic x (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 37c: bipush 0
      // 37d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 380: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 383: invokedynamic get ()Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/misc/树友何友何友友何友何.z ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 388: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 38b: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 38e: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.友树树树何树何何树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 391: aload 0
      // 392: aconst_null
      // 393: ldc2_w 4157735693957396349
      // 396: lload 1
      // 397: invokedynamic N (Ljava/lang/Object;Lnet/minecraft/network/protocol/game/ServerboundContainerClosePacket;JJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 39c: aload 0
      // 39d: new cn/cool/cherish/utils/树友树友友何何树何何
      // 3a0: dup
      // 3a1: lload 3
      // 3a2: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 3a5: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.树何树树树何树何友友 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 3a8: aload 0
      // 3a9: invokestatic java/lang/System.currentTimeMillis ()J
      // 3ac: ldc2_w 4159453931694555490
      // 3af: lload 1
      // 3b0: invokedynamic N (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3b5: aload 0
      // 3b6: bipush 0
      // 3b7: ldc2_w 4158153620995501241
      // 3ba: lload 1
      // 3bb: invokedynamic N (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3c0: aload 0
      // 3c1: lconst_0
      // 3c2: ldc2_w 4160034936386089851
      // 3c5: lload 1
      // 3c6: invokedynamic N (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3cb: aload 0
      // 3cc: lconst_0
      // 3cd: ldc2_w 4158031002701152942
      // 3d0: lload 1
      // 3d1: invokedynamic N (Ljava/lang/Object;JJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3d6: ldc2_w 4159271986889723518
      // 3d9: lload 1
      // 3da: invokedynamic O (JJ)I bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3df: aload 0
      // 3e0: bipush -1
      // 3e1: ldc2_w 4157779414527873700
      // 3e4: lload 1
      // 3e5: invokedynamic N (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3ea: pop
      // 3eb: aload 0
      // 3ec: bipush 0
      // 3ed: ldc2_w 4158539780414565600
      // 3f0: lload 1
      // 3f1: invokedynamic N (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3f6: aload 0
      // 3f7: new java/util/Random
      // 3fa: dup
      // 3fb: invokespecial java/util/Random.<init> ()V
      // 3fe: putfield cn/cool/cherish/module/impl/misc/树友何友何友友何友何.友何何树何何友树友友 Ljava/util/Random;
      // 401: aload 0
      // 402: fconst_0
      // 403: ldc2_w 4159076536088145405
      // 406: lload 1
      // 407: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 40c: aload 0
      // 40d: fconst_0
      // 40e: ldc2_w 4159960169054849171
      // 411: lload 1
      // 412: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 417: aload 0
      // 418: fconst_0
      // 419: ldc2_w 4160090066535528928
      // 41c: lload 1
      // 41d: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 422: aload 0
      // 423: fconst_0
      // 424: ldc2_w 4158991772162998626
      // 427: lload 1
      // 428: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 42d: aload 0
      // 42e: fconst_0
      // 42f: ldc2_w 4156879295433137375
      // 432: lload 1
      // 433: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 438: aload 0
      // 439: fconst_0
      // 43a: ldc2_w 4159638206812264314
      // 43d: lload 1
      // 43e: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 443: aload 0
      // 444: fconst_0
      // 445: ldc2_w 4157305617406895362
      // 448: lload 1
      // 449: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 44e: aload 0
      // 44f: fconst_0
      // 450: ldc2_w 4158824679990694355
      // 453: lload 1
      // 454: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 459: aload 0
      // 45a: fconst_0
      // 45b: ldc2_w 4157372327479604221
      // 45e: lload 1
      // 45f: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 464: aload 0
      // 465: fconst_0
      // 466: ldc2_w 4158445848293039983
      // 469: lload 1
      // 46a: invokedynamic N (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 46f: aload 0
      // 470: bipush 0
      // 471: ldc2_w 4158253882136233961
      // 474: lload 1
      // 475: invokedynamic N (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 47a: aload 0
      // 47b: ldc2_w 4159349362346267800
      // 47e: lload 1
      // 47f: invokedynamic ¢ (Lcn/cool/cherish/module/impl/misc/树友何友何友友何友何;JJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 484: ldc2_w 4157143067781295001
      // 487: lload 1
      // 488: invokedynamic O (JJ)Z bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 48d: ifeq 494
      // 490: bipush 0
      // 491: goto 495
      // 494: bipush 1
      // 495: ldc2_w 4159059978311101236
      // 498: lload 1
      // 499: invokedynamic O (ZJJ)V bsm=cn/cool/cherish/module/impl/misc/树友何友何友友何友何.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 49e: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-3824942942267636671L, 6211399529615400018L, MethodHandles.lookup().lookupClass()).a(181143071897575L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 101396721879295L;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[63];
      int var18 = 0;
      String var17 = "\u0001\u008c>\u0097ªXC\f©Y[@\u0006ÇL\u0004Ål|\u009b[VÃKÄ·\u0011_ýA¯\u008bU\u001dÞ\u009d5¾:¹ \\=rÞ\u000b\u0014Ü7oÝ\u00064\u0003\u0096\\»üd¸6H,ÍÆ\u001d?µ[[æêð@¹\u0094Ü|]`iá\u008ae*Ú\u0012Eww\"\u009fjxdÐ\u001f\u0002o\u0097Î\u0000ÿº*·Â1V\u008b\u0094Mßvª%©°K;ÉOÄ-\u000e,\u0018¶ÂÛÅÃ\u001a¶Ó¬Ê\u009f(\u0003y'ü\u0095\u009a\u001c\r\u0094\u0001éz\u0099m«È~ã¬\ri×\rfÎ \u0013§6\u009b\n\u0006DT\rf¼ïT¹0ÚL\b\u0013?\u0006½t\u0096\u001ag¼Ñm3¶éÊ¿\u0081î¢1»±L~7î¨%\u0097x\u0081\u0080\u0081û\u00ad¹}\u0011h\u000f\u009aRÊðº\u0010Ì\bY9ÉÍªÝ\u0018<\u0095%\u0012¹lÐ >\"Gn;\u001fÏ\u0014½+\u0099¬\u008cÜÛ\u007foÛ}\u0095½ãº\u0005?\u0096¢\u0084ý~\u0097& Ý¯çU\tº4\u0081!j,(\u0015[\u0092YM\u0017,f\n\u009cnùÍ\fò×ãVWî\u0010³¸ã\u009a;ÄH=Áü6AO\u001bÂ\u0096\u0010L\u0085\u0085ú\u0093çbxÉÃè\u0013(¿¹Ó\u0010^@\u0013\u0014\u001a\u00018R-h\\Òñ²\rã8\u0098´×=RTùK+Ü2\u0080ÍêI\u008bØ·\u0099\u0096\u0003\u0012Â7\u0003èy\u0096¹ÂÅìNã¹ö´9\tÌO\\\u008b\u009dã\u0096Àä\u0080-¬7\u009f2@§PÑ\u009e\u009a\u008a@)!'¾Õ\u000f\u0014*\bÉ(äzê(\u001d*k|Ö\u0007CÏúubúÝ6B+º³ò×Ú3\u0006 \u0091®\na^5oÔ\u0011\u007fü\u0013s\u0088\u00134\u0092\u0014·[0\"\u0083øÏ^Á.sb.ÿë>¨RPÌ\u0088\u0001Záï#iÉB\"#¬U\u007f\u0015à\u0089\u0096(\u0080\tÚ\u008b)-w\u007fÈ\u0010ª«n\u0092\u0098\u0003!\u0013tf\u001dÔ\u008a!On?W\u0016V\u000b»\u008b5µ¶\u001dâß\u0003\u00888ú,ò¶Ø<Z\u0004\u0092õ\u008e1u.)b\u000e\u00960{\u0013\u00adòV\u009fÕl}e×Çc·\u000eèÀÌÉpÏûSÅÔÓ\u0083àILc3¥2\t\u007f¤Å\u0094\u0088\u0093`dÐ¬Jzr`,\\z{Û\nÎ©\u0017\u0018«7v\u0014\u008c\u0007\u00ad³xÛ@Ù\u001a*\u0010\u008dE\u0017IEÅêò¶^\u0014GÁ(5\u0000>EHÚÿÙ^\u0019¿µ>PI!æüß\u0010Ôw[åwl$yÂÒÊî¥^³\u009f°áF¬âÜMþ\u0092òi\u001d¯ª\u0006\u0087ªÍhÛ¹\u0010\u0005¸0ïkS\u007f]\u009a\u0098v\u0088½¼ú¤(\u00009¹\u0088ñ|\u009fÃ\u008eéFå\u001c?Ë\u009b\u001eê\u0012£y\u0000ì\u008b\"\t\u008aSLS«¾\u0011B\u0017:\u0098t£5 j÷R{j \u0007\tWßÑ`Bý®[\u0097Ù\u008fØ®\u008a3ÿ Ù(å_ßp¿P\u000eP×â\u0010\rçëÁÂ\u008b_\u0097¾ÂòÕÇi=\u007f\u0012®\u0093WÁmñív\u0018vK¢$\u001b\u0092h ¥~<\"ë;\u009cÌÅ=o·\u001a\u0080A\u0086\u008a£Ö9b¯p\u0099\u008ey\u0088\u0082ã,LI£Å\u0092\u0007ÙÍª\u0001M 48¼Qt\u0006÷ª¡\u009dÞúl\rÐtÞØâÅ\u0088ÓEtøâTg\u001b\u00827\u001e\u0010Jr?4¬2£~\\¿\u001d'\u009dJ1H ®D§5º\u0098ÒhÈû\u0094\u000e'Ç{¹E«ï%\u0000\u009b\u0095Í\t\u0014EX\u0084õÑ\u00ad\u0010\u0083ÖFKhµ/®Yª\u001f¹Jõ\u0007\u0011 uA\u000e¢¸\u0016\u009e\u0095Ö\u000eÆ\u008c&Z Á\u000f\u001b\u0080ÈÃ;=\u009a%\u0089µ\t°\u0091^µ8\u0088þÿq,+÷jÎ29\u009d\u0017Ä\u001bö\u0015IÓ~\u001cQB>i\u009f\u0002üä\u0005w>©I\r0\u008bÉ\u0089h/gF\u0099]\býz\u0096q\u0000\u001dUÜñ\u00ad ß¨ÍJ@°\u00adÞô¼X\u008ft\u000bs\u0082\u0094\u001cSÆ\u0099Æ¦Gv¤:âw\u0080ÖûP¦Ôß\u007f TÇ\u0002\u00123û3åæJæx\u0019{\r\u009b\u0014Õ2mJ\u009b\u0098·\u0011±\u0096ðÿ·_ÑÏ:@¡VzÀWsÐ¦\u0084`ù,\u0087¦|ØÞD\u0007}©t\u0082gÀ`\u009d\u0090ö|\u0015\u0019ÛS\u0012¹\u0082\u0086{jH\u0084e \nò@\u001f_\u008a\u0015\u0086\u0012\u0092fsúü\u00adhtö\u0012&NSµ\u0082\u0019<umB\\m5ÆR\u00adfoBU\u0015§´S\u0084\u0002åfkvê±\u0090éhXãh\u0017%\"\u0097\u0003Óm\u0006Ì^Ú[\u0010,\u0006nªR\u001eL÷æUêü\fÁ[7\u0010ãW£Æ\u0003Ôü]ù®Ç§ÎØ\u0001\u009c \u0015K<£8Sü\u0014P\u0001\\\u0089n'!³/ºË\u008dTMê¿f?m m\u0095Èd >\u0088iòÌÚ/â\u0081Ê\u0010Õ×#z\u0012\u0010Çc¹ª\u008d;÷\u0089!æ/\u001dÐ\u008a/ \u009aÜÃ\u0081áÊ\u001aN\u0090¥ø4§¶2\u0013ýå\u008f\u0012³i±L=káNõ@Â<(¡³JºtW¶)ÃÏ\u009bDK¦x¢E~ªRgþ)§\u009cõÈ\u009b\u0017\u0011ùc¹\u0096{aw\u0095\u009e³\u0010ê\u0016\u000f\u009e\u0099Â&fù½á\t\f¯\u0011\u0095(\u0080©®T\u009c#ýù\u0092ÖÃ\u0014ÏöV+o%\u009bm¼#ò\u001fÚ\u0005\u008fM\u0083ÕxØXV\u001fV\u000b¡Fz\u0010\u0081e¥\u0081\u001d\u0084³0\u008f\u009f\u008a\u001c\fU\u007f\u008b@ñem¨]ÖtQ o(7\u0085·K/É4¬Ð]Ü&F|tù\u0088äç÷Èô®n\u009c^Ü\u0090\u0015Ú\u000eÄ¡Iç\u0093{\\¨¡\u0087 |¼2\u0090üÖGê\u0004jm\u0010À\u00021D~è·²@æß\u009d!Æ\t- î|ëñ\u007f#¿HÑ\u009dîgC\u0092².Ì\u0019?\u0085¼Â'»\u0011fDÃW??¢h2Æ\u000f\u0012KX\u0016öb`Ý\u0004¿¶\u000et\u0003x\nâ\u0006Hb\u0093\u001c\u001cð×·©\u0012F£±¿\u0084aïìÜF\u007f(b\u009d7¾A\u0015®;y{¬\u0003-\u008e&\u009e\u0083R\u0083\u000f'nXófò¨5\nD\ro¸\"E`ÿ_$y¢Tí\u009c\u001d\u000f®\u0080Á[6¯\u00ad8¯.¾¡Ä0\u0016\u0018\r°µ}W¿èýê\u001dÑ¦^k;¦(÷\u0010þ\u009a~o¤\u00100\u0094j_\u0016|bÈâ\u0081YN£Ð\u0090È \u0018(W|©\u0089-ò\u0094e\u0017±ý\u0095éIéq\u0015í5Þ\u009càd`È÷¨.¶\u009a(!mÙé\u008a6\u001aè²\u0005GñM\u009aKãÒæ¨IÒCål\u001c,\u00891â$\u009a¶.\u0003¾\u001bÉ\u0014\u00125(íxBù\u0081i°H·vJ\u009f\tUAGô¡°x\u009eBÏ\u000býOô\u0081Ó;¾ÁJiâÍl6\u0017= \u00906§|mîÑ/\u001fñ0cç\n\u000fnñ§W\u009e%Â8(¤Õ1t\u0081@©±@H$\u001e\u0013QFD!3fÏè\u00adÖóª¼¿ózÚ<xq§L\u008e(«\u0092\u0013ÙX\u0016êÀt\u0012H\u0005\u009am *\u008a>½èq÷\\¢Ì÷)t\u009b×è\"Y~nW(\u000bÞV\u0005sÌØµêN(]¦87\u008a÷ê\u009aêò\u0002´®ð\u0016£yrÏ\u000b\u001aFé²:i\u00ad\u00931\u0010Ç\u008b¡ë!ú#öø=\u0086\u0014\u0010\u0014Â\u0002\u0010TÙy\u0086iEk\u0093\u001b®\u009c\u0084H\u008fÃl\u0018v\u0098\u0086h2©ó\u008bñ\u0083Û¢[h\u009c\u0016\u00955\u0094cKë×\u008d\u0010\u0091\u0087l\u008fùjìÈs\u008dfªÔÃ\u0090¡\u0010\\F)&æ·L¥{3Ê\ng\u0095\u0013b\u0018Æÿ4¹\u0013Yy\u008fì\u0081\u0085ôvoÝ¯Ê\u0018ª\u0015\u008d Û_\u0010N¼ÝÖË$\u00ad{ºv+(Bp\u007fL(\u0012\u001fÂvxLèåGå\u0013*ç9+ÈÃ¥§¬¾£Îé!íÜê\u0094Î®«\u0095!µ¸ç)ëj\u0010\u0002ñÓ\u0014\u0096Ë{\u008b\u0000\u0086«l\u0083ôñë\u0018EN\u0084ûÛY\u0096Ø)\b\\ó\u0006¾\u0097,(ý©Ü±\u007f¾^\u0010õó!Ý¯\u0000®$áò\u0005-ê\u0018\u0082w";
      short var19 = 2276;
      char var16 = '(';
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[63];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "EÌ»¡¦ö\u0004\u0098\u00028\u0017Kîví\u0087\u008fª¤«fâ\u008fR".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 24);

                     j = var6;
                     k = new Long[3];
                     友何友友友何何何何友 = new double[]{0.1, 0.25};
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "\u0093¸Õ(3cöFñ\u001dèÁ>u\u00819\u0018Ï>¹$I\u0005½\u0006ùê\u000fæ+\u007f\u0099°\u008aFû\u00adúr\"Ù";
                  var19 = 41;
                  var16 = 16;
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   public void F() {
      this.L();
   }

   private boolean S(int from, int to) {
      long a = 树友何友何友友何友何.a ^ 27694032852386L;
      d<"O">(-9092812056862181879L, a);
      return from == 0 && to == 8 || from == 8 && to == 0;
   }

   private boolean V(float currentYaw, float currentPitch) {
      long a = 树友何友何友友何友何.a ^ 19282078350611L;
      long var10001 = a ^ 4029616609621L;
      int ax = (int)((a ^ 4029616609621L) >>> 48);
      int axx = (int)((a ^ 4029616609621L) << 16 >>> 32);
      int axxx = (int)(var10001 << 48 >>> 48);
      d<"O">(2986186236398037894L, a);
      if (d<"Ì">(this, 2986405573060415908L, a) == 0.0F && d<"Ì">(this, 2989817510279522598L, a) == 0.0F) {
         return false;
      } else {
         double yawDelta = Math.abs(友树树何何树树何何树.g(currentYaw - d<"Ì">(this, 2986405573060415908L, a), (char)ax, axx, (char)axxx));
         double pitchDelta = Math.abs(currentPitch - d<"Ì">(this, 2989817510279522598L, a));
         boolean isStepYaw = yawDelta < 1.0E-5 && pitchDelta > 1.0;
         boolean isStepPitch = pitchDelta < 1.0E-5 && yawDelta > 1.0;
         return isStepYaw || isStepPitch;
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 53;
               case 1 -> 44;
               case 2 -> 29;
               case 3 -> 19;
               case 4 -> 46;
               case 5 -> 63;
               case 6 -> 57;
               case 7 -> 39;
               case 8 -> 15;
               case 9 -> 48;
               case 10 -> 58;
               case 11 -> 13;
               case 12 -> 24;
               case 13 -> 40;
               case 14 -> 17;
               case 15 -> 37;
               case 16 -> 35;
               case 17 -> 42;
               case 18 -> 26;
               case 19 -> 2;
               case 20 -> 43;
               case 21 -> 16;
               case 22 -> 14;
               case 23 -> 10;
               case 24 -> 33;
               case 25 -> 32;
               case 26 -> 55;
               case 27 -> 9;
               case 28 -> 60;
               case 29 -> 23;
               case 30 -> 59;
               case 31 -> 49;
               case 32 -> 5;
               case 33 -> 6;
               case 34 -> 50;
               case 35 -> 25;
               case 36 -> 51;
               case 37 -> 8;
               case 38 -> 38;
               case 39 -> 54;
               case 40 -> 7;
               case 41 -> 4;
               case 42 -> 36;
               case 43 -> 56;
               case 44 -> 61;
               case 45 -> 62;
               case 46 -> 45;
               case 47 -> 12;
               case 48 -> 20;
               case 49 -> 21;
               case 50 -> 18;
               case 51 -> 52;
               case 52 -> 47;
               case 53 -> 34;
               case 54 -> 1;
               case 55 -> 0;
               case 56 -> 22;
               case 57 -> 31;
               case 58 -> 41;
               case 59 -> 3;
               case 60 -> 28;
               case 61 -> 11;
               case 62 -> 27;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7452;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/树友何友何友友何友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树友何友何友友何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树友何友何友友何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15051;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/树友何友何友友何友何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private float[] c(float yaw, float pitch) {
      long a = 树友何友何友友何友何.a ^ 131231959495047L;
      long var10001 = a ^ 111572796560833L;
      int ax = (int)((a ^ 111572796560833L) >>> 48);
      int axx = (int)((a ^ 111572796560833L) << 16 >>> 32);
      int axxx = (int)(var10001 << 48 >>> 48);
      d<"O">(2732200594394485292L, a);
      if (d<"Ì">(this, 2730798585849929008L, a) == 0.0F && d<"Ì">(this, 2731875164593464754L, a) == 0.0F) {
         return new float[]{yaw, pitch};
      } else {
         double yawDelta = Math.abs(友树树何何树树何何树.g(yaw - d<"Ì">(this, 2730798585849929008L, a), (char)ax, axx, (char)axxx));
         double pitchDelta = Math.abs(pitch - d<"Ì">(this, 2731875164593464754L, a));
         float newYaw = yaw;
         float newPitch = pitch;
         if (!this.T(yawDelta) && this.t(yawDelta)) {
            double jitter = d<"Ì">(this, 2731249437751587998L, a).nextGaussian() * 0.005;
            newYaw = yaw + (float)jitter;
         }

         if (!this.T(pitchDelta) && this.t(pitchDelta)) {
            double jitter = d<"Ì">(this, 2731249437751587998L, a).nextGaussian() * 0.005;
            newPitch = pitch + (float)jitter;
         }

         return new float[]{newYaw, newPitch};
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 204 && var8 != 'N' && var8 != 216 && var8 != 162) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 211) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'O') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 204) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'N') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 216) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   public boolean d(Packet<?> packet) {
      return packet instanceof ServerboundMovePlayerPacket;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/树友何友何友友何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "~Lq(&\u0011q\f<#,\ftQ7e$\u0011yW3.g\u0017pR3e$\u0017nAq桚厂伫取佷厔厀伜厵佈";
      m[1] = boolean.class;
      n[1] = "java/lang/Boolean";
      m[2] = float.class;
      n[2] = "java/lang/Float";
      m[3] = long.class;
      n[3] = "java/lang/Long";
      m[4] = int.class;
      n[4] = "java/lang/Integer";
      m[5] = "6\u0004~TG\u007f6\u0004i\bKp,Od\u001f^a7\u0013aTZd7\u0015e\u0019Ezv\u0006k\u0017O8\u000b\u0004x\fOd:\u000e\u007f\u0014NU7\u000f~\u001bCx=\u0013I\u0016Ee=1k\u0019As,";
      m[6] = "y/\u001eq(\u0004voSz\"\u0019s2X<*\u0004~4\\wi\u0002w1\\<*\u0002i\"\u001e叙厌厠住伔校栃桖伾栋";
      m[7] = "\u0017;KA\u00101\u001c4Z\u000el(\u0013.TM[\u0018\u00059XPJ4\u00124";
      m[8] = "L*\rJ\u0010QCj@A\u001aLF7K\u0007\t_C1F\u0007\u0016S_(\rk\u0010QC!BG)_C1F";
      m[9] = "x\u001f\u001aOxfw_WDr{r\u0002\\\u0002zf\u007f\u0004XI9作低厺佡佹叜作低桠栥";
      m[10] = "W%+-C7Xef&I*]8m`A7P>i+\u0002\u0015[/p\"I";
      m[11] = void.class;
      n[11] = "java/lang/Void";
      m[12] = "S_\u0004\bH5MW\u001eG4!WZ\u001d\u0004";
      m[13] = "B(vu\\/Mh;~V2H508F4H*+8栢压栰厍厓佃佦桑佴伓";
      m[14] = "\u0017w";
      m[15] = "_MT\t\u0000\u0004TBEFa\n_IA\u001c";
      m[16] = "u9|t @oj2N桘叼佊伏栕厍厂佢叔厑\ftzD&6b~ \u0002j";
      m[17] = "JU \u0011K&P\u0006n+佷伄栱佣伍佶栳伄栱栧P\u0016WgJU)@JhZ";
      m[18] = "rGhE\u0007fh\u0014&\u007f伻叚栉佱佅伢伻栀位栵\u0018B\u001b'rGa\u0014\u0006(b";
      m[19] = "Zn+imk@=eS叏受校栜厘厐栕佉校栜[nq*Zn\"8l%J";
      m[20] = " \u007fO/st:,\u0001\u0015发佖桛受栦取住又伟佉?(o5 \u007fF~r:0";
      m[21] = "LFF%v@V\u0015\b\u001f叔佢叭叮佫叜栎叼佳佰6&f\\\u001eNHgh_\u0015";
      m[22] = "I(ED;jS{\u000b~厙佈栲伞叶厽厙栌佶厀5\u001c1e\u0011\"J\u0006b+";
      m[23] = "#6z$\u001e...,4g\r\u001fo?+\u0004,r.9+\u0003K";
      m[24] = "Dr\u0016q\u0000m^!XK桸栋栿叚厥桒似住句叚fqZi\u0017}\b{\u0000/[";
      m[25] = "*Bz\u0007!c0\u00114=厃栅压栰佗栤伝佁伕佴\n\u00041\u007fxJtE?|s";
      m[26] = "d\u001d\u000fh\u001f\u0001~NAR桧厽栟桯厼伏厽厽叅厵\u007fo\u0003@d\u001d\u00069\u001eOt";
      m[27] = "a\u0011RK\u001c%{B\u001cq厾厙叀伧叡伬厾桃叀厹\"H\f93\u0019\\\t\u0002:8";
      m[28] = "t\u00121Zj!nA\u007f`佖伃佋伤伜厣佖厝叕伤A]v`t\u00128\u000bkod";
      m[29] = "\rd\u0006-=I\u00177H\u0017原叵厬栖桯佊桅佫伲佒v.-U_l\bo#VT";
      m[30] = "!\rP\b<b _H^C厐佂伲佳佥厀桊叜桶样8}1a_Q\t|cy\t";
      m[31] = "L4pOW:Vg>u栯历佳伂佝桬佫历样框\u0000HK{L4y\u001eVt\\";
      m[32] = "z5\u0019Y\u0014;`fWc厶伙佅桇伴伾厶桝叛厝iS\u0010~cn\u0002\n\f(%";
      m[33] = "q!\u0017e(nkrY_厊叒栊桓厤厜桐叒叐厉g.5kq5\u0002!+-";
      m[34] = "U0K'@YOc\u0005\u001d叢栿叴桂司栄核佻叴伆;$PE\u00078Ee^F\f";
      m[35] = "0?/8\u0019\u0016*la\u0002桡厪厑桍框佟桡厪伏厗_?\u0005W0?&i\u0018X ";
      m[36] = "2\u0018>K/\u0014(Kpq伓桲厓伮桗桨桗桲伍桪NKu\u0010a\u0017 A/V-";
      m[37] = "$On\f&8>\u001c 6桞会桟栽标佫桞会厅叧\u001e\u0007-?#\u0019}L 8/";
      m[38] = "J#0d&TPp~^厄佶叫压厃伃会佶併压@7yE\u0012*y4yOR";
      m[39] = "|>\u000f;a\u0015fmA\u0001栙厩佃桌伢栘參厩标伈\u007fp|\u0010|*\u001a\u007fbV";
      m[40] = "\u0000:'-&\"\r\"q=_\u000e<cb\"< Q\"d\";G";
      m[41] = "{\u0016mb}EaE#X栅叹栀传叞厛栅叹叚桤\u001damY)\u001ec cZ\"";
      m[42] = "a\u007f\"W\u0007#'f<Dg\u0012_|&O\u0005$:s8\tgknn?\b\u0000* c55";
      m[43] = "\u001bP\u0019j\u0019)\u0001\u0003WP桡伋厺司厪厓伥伋伤佦ii\t5IX\u0017(\u00076B";
      m[44] = "JByF\u0001WP\u00117|伽叫叫栰栐桥厣栱併佴\tA\u001d\u0016JBp\u0017\u0000\u0019Z";
      m[45] = "P'r&z1Jt<\u001c变厍叱休栛佁变桗栫休\u0002&d+Q+ogb+V";
      m[46] = "OB1U@dU\u0011\u007fo叢但佰只伜伲佼变叮栰AR\\%OB8\u0004A*_";
      m[47] = "\u00051\u0016\u001cT\u0005\u001fbX&叶档桾桃伻栿佨伧桾桃f\u001bHD\u00051\u001fMUK\u0015";
      m[48] = "\u0002a\u0016\u0015$@\u00182X/,?]0\u001dA&U\u000ej\f]E\u0002Zq\bL/Q\u0000`\u0014/";
      m[49] = "*{PSJRlbN@*G\u0014xTKHUqwJ\r*";
      m[50] = "\"k\u007f+\u0007m881\u0011伻住桙栙佒叒厥发伝栙\u000f(\u0017qpcqi\u0019r{";
      m[51] = "\u0015\b#]QI\u000f[mg栩佫桮伾桊桾右栯桮桺S^AUG\u0000-\u001fOVL";
      m[52] = "\u001f\u0012\u0017D?S\u0005AY~厝可传伤桾伣伃栵传厺gC#\u0012\u001f\u0012\u001e\u0015>\u001d\u000f";
      m[53] = "{v\u001b\u001f)/a%U%伕桉叚叞伶另压厓佄栄k\u001c93)~\u0015]70\"";
      m[54] = "o\u0019fGk$uJ(}栓桂収伯叕桤栓厘佐桫\u0016@weo\u0019o\u0016jj\u007f";
      m[55] = "\tk{96\u0003\u001385\u0003厔伡桲栙佖栚伊伡厨栙\u000b>*B\tkrh7M\u0019";
      m[56] = "c\u0014/3P\u000byGa\t佬桭参桦伂栐栨桭参桦_3N\u0011b\u00182rH\u0011e";
      m[57] = "~RI*\u001bbd\u0001\u0007\u0010档栄栅佤叺叓厹栄栅叺9+\bz#SCnJpe";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      this.L();
   }

   private boolean t(double rotation) {
      long a = 树友何友何友友何友何.a ^ 87529026189281L;
      d<"O">(7173250381213455434L, a);
      if (!Double.isInfinite(rotation) && !Double.isNaN(rotation)) {
         double[] var6 = d<"Ø">(7170004036365503022L, a);
         int var7 = var6.length;
         int var8 = 0;
         if (0 < var7) {
            double pattern = var6[0];
            if (this.w(pattern, rotation)) {
               return true;
            }

            var8++;
         }

         return false;
      } else {
         return false;
      }
   }

   public void g(String message) {
      long a = 树友何友何友友何友何.a ^ 113333708730357L;
      d<"O">(4294368885300890718L, a);
      if ((Boolean)d<"Ì">(this, 4293763157373378528L, a).v().get() && d<"Ì">(this, 4293763157373378528L, a).getValue()) {
      }
   }

   @EventTarget(0)
   public void v(BlinkEvent event) {
      long a = 树友何友何友友何友何.a ^ 27100618602295L;
      long ax = a ^ 40608943528567L;
      d<"O">(-6675788159402109796L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (!mc.isSingleplayer() || !d<"Ì">(this, -6675989440330821731L, a).getValue())) {
         Packet<?> packet = event.getPacket();
         if (d<"Ì">(this, -6676113502866629083L, a).getValue()
            && d<"Ì">(this, -6676646082536922838L, a).getValue()
            && this.d(packet)
            && event.getBlinkTicks() % 9 == 0) {
            event.setCancelled(false);
            this.g(
               b<"x">(29860, 7076849315777497835L ^ a)
                  + event.getBlinkTicks()
                  + b<"x">(25202, 4887559478824524846L ^ a)
                  + packet.getClass().getSimpleName()
                  + b<"x">(10858, 8493955625677132813L ^ a)
            );
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean z() {
      long a = 树友何友何友友何友何.a ^ 104776241334376L;
      d<"O">(6630866448620186563L, a);
      return mc.player != null && mc.player.getDeltaMovement().lengthSqr() > 0.001;
   }

   private boolean w(double reference, double value) {
      long a = 树友何友何友友何友何.a ^ 72398872943790L;
      d<"O">(-8589419064292619717L, a);
      double multiple = value / reference;
      return Math.abs(multiple - Math.round(multiple)) <= 1.0E-10;
   }

   private void r(int from, int to) {
      long a = 树友何友何友友何友何.a ^ 102022703625176L;
      long ax = a ^ 98126231992157L;
      d<"O">(2862703644099634509L, a);
      int diff = Math.abs(from - to);
      if (diff > 1 && !this.S(from, to)) {
         int direction = from > to ? -1 : 1;
         int middle = from + direction;
         if (middle != to) {
            if (middle >= 0 && middle <= 8) {
               PacketUtils.e(new Object[]{ax, new ServerboundSetCarriedItemPacket(middle)});
               this.g(b<"x">(2737, 5988231051633340435L ^ a) + middle);
            }

            int var10000 = middle + direction;
         }
      }
   }

   public void L() {
      long a = 树友何友何友友何友何.a ^ 24594643430466L;
      d<"N">(this, -1, 4045373203806196531L, a);
      d<"N">(this, 0L, 4047613035229803244L, a);
      d<"N">(this, false, 4045307273989188910L, a);
      d<"N">(this, null, 4045452589785413354L, a);
      d<"N">(this, 0L, 4045112131262956345L, a);
      d<"N">(this, 0.0F, 4044478605090177269L, a);
      d<"N">(this, 0.0F, 4047875114197727351L, a);
      d<"N">(this, 0.0F, 4047696597588691204L, a);
      d<"N">(this, 0.0F, 4048570268441848938L, a);
      d<"N">(this, 0.0F, 4044362364657864772L, a);
      d<"N">(this, 0.0F, 4046163522837226645L, a);
      d<"N">(this, 0.0F, 4044988177367785208L, a);
      d<"N">(this, 0.0F, 4046096401592545898L, a);
      d<"N">(this, 0.0F, 4048010175044196077L, a);
      d<"N">(this, 0.0F, 4046300193361681736L, a);
      d<"N">(this, false, 4044935020140529278L, a);
   }

   @EventTarget
   public void L(WorldEvent event) {
      this.L();
   }

   @EventTarget(0)
   public void P(PacketEvent event) {
      long a = 树友何友何友友何友何.a ^ 5116690337732L;
      long ax = a ^ 62592867066500L;
      long axx = a ^ 58556040512952L;
      long axxx = a ^ 6575166783041L;
      long axxxx = a ^ 115821437560348L;
      long axxxxx = a ^ 71707473749318L;
      long axxxxxx = a ^ 64333599442777L;
      long axxxxxxx = a ^ 7549415571872L;
      long axxxxxxxx = a ^ 112338573670051L;
      long axxxxxxxxx = a ^ 11671792379963L;
      long axxxxxxxxxx = a ^ 1458589387585L;
      long var10001 = a ^ 95143905789629L;
      int axxxxxxxxxxx = (int)((a ^ 95143905789629L) >>> 48);
      int axxxxxxxxxxxx = (int)((a ^ 95143905789629L) << 16 >>> 48);
      int axxxxxxxxxxxxx = (int)(var10001 << 32 >>> 32);
      d<"O">(-7231085961134286511L, a);
      树何树树何树何何树何.N(
         (char)axxxxxxxxxxx,
         () -> {
            long axxxxxxxxxxxxxx = 树友何友何友友何友何.a ^ 116330766699164L;
            long axxxxxxxxxxxxxxx = axxxxxxxxxxxxxx ^ 29631223655187L;
            long axxxxxxxxxxxxxxxx = axxxxxxxxxxxxxx ^ 49032911181595L;
            long axxxxxxxxxxxxxxxxx = axxxxxxxxxxxxxx ^ 118994589175321L;
            Properties prop = System.getProperties();
            d<"O">(-6990034349089170423L, axxxxxxxxxxxxxx);
            String hostname = prop.getProperty(b<"x">(23121, 4104922540817504696L ^ axxxxxxxxxxxxxx));
            if (Cherish.BLOCKED_COMPUTER.stream().anyMatch(computer -> hostname.contains(computer.toString()))
               || Cherish.BLOCKED_COMPUTER.stream().anyMatch(computer -> {
                  long axxxxxxxxxxxxxxxxxx = 树友何友何友友何友何.a ^ 526317187708L;
                  return System.getProperty(b<"x">(15541, 4107250026329196444L ^ axxxxxxxxxxxxxxxxxx)).contains(computer.toString());
               })
               || Cherish.BLOCKED_COMPUTER.stream().anyMatch(computer -> {
                  long axxxxxxxxxxxxxxxxxx = 树友何友何友友何友何.a ^ 6975970888323L;
                  return System.getProperty(b<"x">(20975, 2390222184435356219L ^ axxxxxxxxxxxxxxxxxx)).contains(computer.toString());
               })) {
               int i = 0;
               PacketUtils.e(
                  new Object[]{
                     axxxxxxxxxxxxxxxxx, new Rot(WrapperUtils.R(new Object[]{axxxxxxxxxxxxxxxx}), WrapperUtils.I(new Object[]{axxxxxxxxxxxxxxx}), true)
                  }
               );
               i++;
            }
         },
         (char)axxxxxxxxxxxx,
         axxxxxxxxxxxxx
      );
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && (!mc.isSingleplayer() || !d<"Ì">(this, -7230244449221167250L, a).getValue())) {
         Packet<?> packet = event.getPacket();
         if (d<"Ì">(this, -7232139662382770836L, a) != null && d<"Ì">(this, -7231293956000336011L, a).Y(d<"Ì">(this, -7231317602634309441L, a), axxxxxx)) {
            PacketUtils.e(new Object[]{axxxxxxxxxx, d<"Ì">(this, -7232139662382770836L, a)});
            this.g(b<"x">(1551, 1925331544694718640L ^ a));
            d<"N">(this, null, -7232139662382770836L, a);
         }

         if (packet instanceof ClientboundOpenScreenPacket) {
            d<"N">(this, System.currentTimeMillis(), -7229948223909899926L, a);
            d<"N">(this, true, -7231158735214522712L, a);
            this.g(b<"x">(970, 945625743980758379L ^ a) + d<"Ì">(this, -7229948223909899926L, a));
         }

         if (packet instanceof ServerboundSetCarriedItemPacket wrapper
            && (Boolean)Fucker.isLogin
            && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)
            && !this.w(new Object[]{ax})) {
            int targetSlot = wrapper.getSlot();
            if (d<"Ì">(this, -7229770373140699434L, a).getValue()
               && (Boolean)d<"Ì">(this, -7230665694864325833L, a).v().get()
               && d<"Ì">(this, -7230665694864325833L, a).getValue()
               && targetSlot == d<"Ì">(this, -7232183382950661963L, a)
               && targetSlot != -1) {
               event.setCancelled(true);
               this.g(b<"x">(4097, 490207139374307004L ^ a) + targetSlot);
               return;
            }

            if (d<"Ì">(this, -7229618903676824625L, a).getValue()
               && (Boolean)d<"Ì">(this, -7230418900529285983L, a).v().get()
               && d<"Ì">(this, -7230418900529285983L, a).getValue()
               && d<"Ì">(this, -7232183382950661963L, a) != -1
               && targetSlot != d<"Ì">(this, -7232183382950661963L, a)) {
               this.r(d<"Ì">(this, -7232183382950661963L, a), targetSlot);
            }

            d<"N">(this, targetSlot, -7232183382950661963L, a);
            this.g(b<"x">(13231, 7031396180535162139L ^ a) + d<"Ì">(this, -7232183382950661963L, a) + b<"x">(15030, 5128318678969924635L ^ a) + targetSlot);
         }

         if (d<"Ì">(this, -7229618903676824625L, a).getValue()
            && d<"Ì">(this, -7232496135033269937L, a).getValue()
            && packet instanceof ServerboundContainerClosePacket closePacket
            && d<"Ì">(this, -7231158735214522712L, a)) {
            long currentTime = System.currentTimeMillis();
            long timeSinceOpen = currentTime - d<"Ì">(this, -7229948223909899926L, a);
            if (timeSinceOpen <= c<"r">(19086, 1679831172989807593L ^ a)) {
               event.setCancelled(true);
               d<"N">(this, closePacket, -7232139662382770836L, a);
               d<"N">(this, c<"r">(28464, 7086111640229760597L ^ a) - timeSinceOpen, -7231317602634309441L, a);
               d<"Ì">(this, -7231293956000336011L, a).U(axxxxxxxxx);
               this.g(b<"x">(14786, 4797655857865080667L ^ a) + d<"Ì">(this, -7231317602634309441L, a) + b<"x">(21297, 3683044324049606047L ^ a));
               d<"N">(this, false, -7231158735214522712L, a);
               return;
            }

            d<"N">(this, false, -7231158735214522712L, a);
            this.g(b<"x">(2500, 3283269628339687272L ^ a) + timeSinceOpen + b<"x">(12718, 7590248477409785645L ^ a));
         }

         if (d<"Ì">(this, -7230788567219055239L, a).getValue() && d<"Ì">(this, -7230268702583417829L, a).getValue()) {
            if (System.currentTimeMillis() - d<"Ì">(this, -7230493405210336397L, a) > c<"r">(7399, 5596205145900400001L ^ a)) {
               if (d<"Ì">(this, -7230704869830340879L, a) == 0) {
                  PacketUtils.e(new Object[]{axxxxxxxxxx, new ServerboundPongPacket(0)});
                  this.g(b<"x">(3659, 5899041915933722848L ^ a));
               }

               d<"N">(this, System.currentTimeMillis(), -7230493405210336397L, a);
               d<"N">(this, 0, -7230704869830340879L, a);
            }

            if (packet instanceof StatusOnly || packet instanceof ServerboundPongPacket) {
               d<"N">(this, d<"Ì">(this, -7230704869830340879L, a) + 1, -7230704869830340879L, a);
            }
         }

         if (d<"Ì">(this, -7229770373140699434L, a).getValue()
            && d<"Ì">(this, -7230356699575235601L, a).getValue()
            && packet instanceof ServerboundMovePlayerPacket movePacket
            && movePacket.hasRotation()) {
            float yaw = WrapperUtils.F(movePacket, axxxxxxxx);
            float pitch = WrapperUtils.U(new Object[]{movePacket, axx});
            if (yaw == d<"Ì">(this, -7229864662632076670L, a) && pitch == d<"Ì">(this, -7230111609407827988L, a)) {
               float baseRange = this.z() ? 3.0E-4F : 1.5E-4F;
               float yawRange = baseRange * (0.8F + d<"Ì">(this, -7231607714957391139L, a).nextFloat() * 0.4F);
               float pitchRange = baseRange * (0.8F + d<"Ì">(this, -7231607714957391139L, a).nextFloat() * 0.4F);
               float yawOffset = (float)(d<"Ì">(this, -7231607714957391139L, a).nextGaussian() * yawRange * 0.3F);
               float pitchOffset = (float)(d<"Ì">(this, -7231607714957391139L, a).nextGaussian() * pitchRange * 0.3F);
               yawOffset = 友树树何何树树何何树.w(yawOffset, axxxxx, -5.0E-4F, 5.0E-4F);
               pitchOffset = 友树树何何树树何何树.w(pitchOffset, axxxxx, -3.0E-4F, 3.0E-4F);
               float newYaw = yaw + yawOffset;
               float newPitch = 友树树何何树树何何树.t(pitch + pitchOffset, axxxx);
               Object[] var10004 = new Object[]{null, null, newYaw};
               var10004[1] = axxxxxxx;
               var10004[0] = movePacket;
               WrapperUtils.Q(var10004);
               var10004 = new Object[]{null, movePacket, newPitch};
               var10004[0] = axxx;
               WrapperUtils.c(var10004);
               this.g(
                  b<"x">(27010, 5215284827782246187L ^ a)
                     + yaw
                     + b<"x">(2813, 7558938352150940760L ^ a)
                     + newYaw
                     + b<"x">(3971, 1762078959003109667L ^ a)
                     + pitch
                     + b<"x">(3433, 7231109349683465189L ^ a)
                     + newPitch
               );
            }

            d<"N">(this, WrapperUtils.F(movePacket, axxxxxxxx), -7229864662632076670L, a);
            d<"N">(this, WrapperUtils.U(new Object[]{movePacket, axx}), -7230111609407827988L, a);
         }

         label152:
         if (d<"Ì">(this, -7229770373140699434L, a).getValue() && d<"Ì">(this, -7229420233556052672L, a).getValue()) {
            if (packet instanceof ServerboundMovePlayerPacket movePacket) {
               if (!movePacket.hasRotation()) {
                  break label152;
               }

               float lastPlayerYaw = d<"Ì">(this, -7230981248257444926L, a);
               float lastPlayerPitch = d<"Ì">(this, -7232553744474994925L, a);
               d<"N">(this, WrapperUtils.F(movePacket, axxxxxxxx), -7230981248257444926L, a);
               d<"N">(this, WrapperUtils.U(new Object[]{movePacket, axx}), -7232553744474994925L, a);
               d<"N">(this, Math.abs(d<"Ì">(this, -7230981248257444926L, a) - lastPlayerYaw), -7231446564465017474L, a);
               d<"N">(this, Math.abs(d<"Ì">(this, -7232553744474994925L, a) - lastPlayerPitch), -7232625127402876436L, a);
               d<"N">(this, true, -7231536348094716424L, a);
               if (d<"Ì">(this, -7231446564465017474L, a) > 2.0F) {
                  float yawDiff = Math.abs(d<"Ì">(this, -7231446564465017474L, a) - d<"Ì">(this, -7229551496951253653L, a));
                  if (yawDiff < 1.0E-4) {
                     float randomOffset = (float)(0.001 + Math.random() * 0.009);
                     float newYaw = d<"Ì">(this, -7230981248257444926L, a) - randomOffset;
                     Object[] var72 = new Object[]{null, null, newYaw};
                     var72[1] = axxxxxxx;
                     var72[0] = movePacket;
                     WrapperUtils.Q(var72);
                     float axxxxxxxxxxxxxx = d<"Ì">(this, -7230981248257444926L, a);
                     this.g(
                        b<"x">(2670, 1852638416864513244L ^ a)
                           + axxxxxxxxxxxxxx
                           + b<"x">(25458, 939160057064973815L ^ a)
                           + newYaw
                           + b<"x">(13818, 2121548364110771050L ^ a)
                           + yawDiff
                           + ")"
                     );
                  }
               }

               if (d<"Ì">(this, -7232625127402876436L, a) > 2.0F) {
                  float pitchDiff = Math.abs(d<"Ì">(this, -7232625127402876436L, a) - d<"Ì">(this, -7232417684374913330L, a));
                  if (pitchDiff < 1.0E-4) {
                     float randomOffset = (float)(0.001 + Math.random() * 0.009);
                     float newPitch = 友树树何何树树何何树.t(d<"Ì">(this, -7232553744474994925L, a) - randomOffset, axxxx);
                     Object[] var73 = new Object[]{null, movePacket, newPitch};
                     var73[0] = axxx;
                     WrapperUtils.c(var73);
                     float var48 = d<"Ì">(this, -7232553744474994925L, a);
                     this.g(
                        b<"x">(30872, 6256840750134918680L ^ a)
                           + var48
                           + b<"x">(24651, 5097805707196196588L ^ a)
                           + newPitch
                           + b<"x">(17210, 4181747043442345362L ^ a)
                           + pitchDiff
                           + ")"
                     );
                  }
               }
            }

            if (packet instanceof ServerboundUseItemOnPacket && d<"Ì">(this, -7231536348094716424L, a)) {
               d<"N">(this, d<"Ì">(this, -7231446564465017474L, a), -7229551496951253653L, a);
               d<"N">(this, d<"Ì">(this, -7232625127402876436L, a), -7232417684374913330L, a);
               d<"N">(this, false, -7231536348094716424L, a);
               this.g(
                  b<"x">(29504, 2844599350376756707L ^ a)
                     + d<"Ì">(this, -7229551496951253653L, a)
                     + b<"x">(16563, 3823077169388144151L ^ a)
                     + d<"Ì">(this, -7232417684374913330L, a)
               );
            }
         }

         if (d<"Ì">(this, -7229618903676824625L, a).getValue()
            && (d<"Ì">(this, -7232306953747100628L, a).getValue() || d<"Ì">(this, -7232265264553893340L, a).getValue())
            && packet instanceof ServerboundMovePlayerPacket movePacket) {
            float currentYaw = WrapperUtils.F(movePacket, axxxxxxxx);
            float currentPitch = WrapperUtils.U(new Object[]{movePacket, axx});
            boolean modified = false;
            if (d<"Ì">(this, -7232306953747100628L, a).getValue() && this.V(currentYaw, currentPitch)) {
               float[] modifiedRotation = this.O(currentYaw, currentPitch);
               currentYaw = modifiedRotation[0];
               currentPitch = modifiedRotation[1];
               modified = true;
               this.g(b<"x">(26081, 8492244319722038106L ^ a));
            }

            if (d<"Ì">(this, -7232265264553893340L, a).getValue()) {
               float[] antiPerfectRotation = this.c(currentYaw, currentPitch);
               if (antiPerfectRotation[0] != currentYaw || antiPerfectRotation[1] != currentPitch) {
                  currentYaw = antiPerfectRotation[0];
                  currentPitch = antiPerfectRotation[1];
                  modified = true;
                  this.g(b<"x">(30597, 1405126133545201939L ^ a));
               }
            }

            if (modified) {
               Object[] var74 = new Object[]{null, null, currentYaw};
               var74[1] = axxxxxxx;
               var74[0] = movePacket;
               WrapperUtils.Q(var74);
               var74 = new Object[]{null, movePacket, 友树树何何树树何何树.t(currentPitch, axxxx)};
               var74[0] = axxx;
               WrapperUtils.c(var74);
            }

            d<"N">(this, WrapperUtils.F(movePacket, axxxxxxxx), -7230866588898958477L, a);
            d<"N">(this, WrapperUtils.U(new Object[]{movePacket, axx}), -7229717755910906895L, a);
         }
      }
   }

   private boolean T(double rotation) {
      long a = 树友何友何友友何友何.a ^ 101717727223647L;
      d<"O">(-8413465702908048950L, a);
      return Math.abs(rotation) <= 1.0E-10 || this.w(360.0, rotation);
   }

   private float[] O(float yaw, float pitch) {
      long a = 树友何友何友友何友何.a ^ 95347181590634L;
      long var10001 = a ^ 75406678981676L;
      int ax = (int)((a ^ 75406678981676L) >>> 48);
      int axx = (int)((a ^ 75406678981676L) << 16 >>> 32);
      int axxx = (int)(var10001 << 48 >>> 48);
      d<"O">(-8356332687809065217L, a);
      double yawDelta = Math.abs(友树树何何树树何何树.g(yaw - d<"Ì">(this, -8356254058569337635L, a), (char)ax, axx, (char)axxx));
      double pitchDelta = Math.abs(pitch - d<"Ì">(this, -8357361418865374113L, a));
      float newYaw = yaw;
      float newPitch = pitch;
      if (yawDelta < 1.0E-5 && pitchDelta > 1.0) {
         newYaw = d<"Ì">(this, -8356254058569337635L, a) + (float)(d<"Ì">(this, -8355733074799190669L, a).nextGaussian() * 0.001);
      }

      if (pitchDelta < 1.0E-5 && yawDelta > 1.0) {
         newPitch = d<"Ì">(this, -8357361418865374113L, a) + (float)(d<"Ì">(this, -8355733074799190669L, a).nextGaussian() * 0.001);
      }

      return new float[]{newYaw, newPitch};
   }

   private static String HE_WEI_LIN() {
      return "解放村多种2队1144号";
   }
}
