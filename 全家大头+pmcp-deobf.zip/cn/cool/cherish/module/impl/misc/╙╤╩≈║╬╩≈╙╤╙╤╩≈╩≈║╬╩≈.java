package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.world.entity.player.Player;

public class 友树何树友友树树何树 extends Module implements 何树友 {
   private final BooleanValue 友树树树友树何友友友;
   private final 友树何树友友何树友友 何树树友何何树何友友;
   private final 友树何树友友何树友友 友树树何何树友友何何;
   private final BooleanValue 树何树何树何树何友树;
   private final 友树何树友友何树友友 友友何友友何何树何何;
   private Player 何何何何树友树友树友;
   private final 树友树友友何何树何何 何友何树何何友友何友;
   private final 树友树友友何何树何何 树友树何树何树树树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[25];
   private static final String[] n = new String[25];
   private static int _何树友为什么濒天了 _;

   public 友树何树友友树树何树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/misc/友树何树友友树树何树.a J
      // 003: ldc2_w 98767118344151
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 137754045495661
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 20661
      // 014: ldc2_w 5566015882418118874
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 30721
      // 021: ldc2_w 5584611605515094116
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w 5975961399911976808
      // 02e: lload 1
      // 02f: invokedynamic Z (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/BooleanValue
      // 03b: dup
      // 03c: sipush 25552
      // 03f: ldc2_w 2491722299351389110
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 26401
      // 04c: ldc2_w 6401539103056123723
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 1
      // 057: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 05a: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 05d: putfield cn/cool/cherish/module/impl/misc/友树何树友友树树何树.友树树树友树何友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 060: aload 0
      // 061: new cn/cool/cherish/value/impl/友树何树友友何树友友
      // 064: dup
      // 065: sipush 14317
      // 068: ldc2_w 8801490984027981702
      // 06b: lload 1
      // 06c: lxor
      // 06d: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 072: sipush 2396
      // 075: ldc2_w 7300270181559679293
      // 078: lload 1
      // 079: lxor
      // 07a: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07f: sipush 18821
      // 082: ldc2_w 7761795029994535401
      // 085: lload 1
      // 086: lxor
      // 087: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 08c: invokespecial cn/cool/cherish/value/impl/友树何树友友何树友友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
      // 08f: aload 0
      // 090: ldc2_w 5974544646819813153
      // 093: lload 1
      // 094: invokedynamic J (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 099: dup
      // 09a: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 09d: pop
      // 09e: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 0a3: invokevirtual cn/cool/cherish/value/impl/友树何树友友何树友友.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0a6: checkcast cn/cool/cherish/value/impl/友树何树友友何树友友
      // 0a9: putfield cn/cool/cherish/module/impl/misc/友树何树友友树树何树.何树树友何何树何友友 Lcn/cool/cherish/value/impl/友树何树友友何树友友;
      // 0ac: aload 0
      // 0ad: new cn/cool/cherish/value/impl/友树何树友友何树友友
      // 0b0: dup
      // 0b1: sipush 10053
      // 0b4: ldc2_w 723289074676340517
      // 0b7: lload 1
      // 0b8: lxor
      // 0b9: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0be: sipush 27130
      // 0c1: ldc2_w 3491892594857728414
      // 0c4: lload 1
      // 0c5: lxor
      // 0c6: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0cb: sipush 21054
      // 0ce: ldc2_w 4602999667116597843
      // 0d1: lload 1
      // 0d2: lxor
      // 0d3: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d8: invokespecial cn/cool/cherish/value/impl/友树何树友友何树友友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
      // 0db: aload 0
      // 0dc: ldc2_w 5974544646819813153
      // 0df: lload 1
      // 0e0: invokedynamic J (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e5: dup
      // 0e6: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 0e9: pop
      // 0ea: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 0ef: invokevirtual cn/cool/cherish/value/impl/友树何树友友何树友友.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0f2: checkcast cn/cool/cherish/value/impl/友树何树友友何树友友
      // 0f5: putfield cn/cool/cherish/module/impl/misc/友树何树友友树树何树.友树树何何树友友何何 Lcn/cool/cherish/value/impl/友树何树友友何树友友;
      // 0f8: aload 0
      // 0f9: new cn/cool/cherish/value/impl/BooleanValue
      // 0fc: dup
      // 0fd: sipush 16376
      // 100: ldc2_w 4858466439715655578
      // 103: lload 1
      // 104: lxor
      // 105: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 10a: sipush 6110
      // 10d: ldc2_w 8860276738866161591
      // 110: lload 1
      // 111: lxor
      // 112: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 117: bipush 1
      // 118: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 11b: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 11e: putfield cn/cool/cherish/module/impl/misc/友树何树友友树树何树.树何树何树何树何友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 121: aload 0
      // 122: new cn/cool/cherish/value/impl/友树何树友友何树友友
      // 125: dup
      // 126: sipush 11272
      // 129: ldc2_w 2965315637670747238
      // 12c: lload 1
      // 12d: lxor
      // 12e: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 133: sipush 3329
      // 136: ldc2_w 8137694451422248294
      // 139: lload 1
      // 13a: lxor
      // 13b: invokedynamic e (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 140: ldc "L"
      // 142: invokespecial cn/cool/cherish/value/impl/友树何树友友何树友友.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
      // 145: aload 0
      // 146: ldc2_w 5976018615540790740
      // 149: lload 1
      // 14a: invokedynamic J (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14f: dup
      // 150: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 153: pop
      // 154: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 159: invokevirtual cn/cool/cherish/value/impl/友树何树友友何树友友.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 15c: checkcast cn/cool/cherish/value/impl/友树何树友友何树友友
      // 15f: putfield cn/cool/cherish/module/impl/misc/友树何树友友树树何树.友友何友友何何树何何 Lcn/cool/cherish/value/impl/友树何树友友何树友友;
      // 162: aload 0
      // 163: aconst_null
      // 164: ldc2_w 5974489786529088377
      // 167: lload 1
      // 168: invokedynamic W (Ljava/lang/Object;Lnet/minecraft/world/entity/player/Player;JJ)V bsm=cn/cool/cherish/module/impl/misc/友树何树友友树树何树.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16d: aload 0
      // 16e: new cn/cool/cherish/utils/树友树友友何何树何何
      // 171: dup
      // 172: lload 3
      // 173: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 176: putfield cn/cool/cherish/module/impl/misc/友树何树友友树树何树.何友何树何何友友何友 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 179: aload 0
      // 17a: new cn/cool/cherish/utils/树友树友友何何树何何
      // 17d: dup
      // 17e: lload 3
      // 17f: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 182: putfield cn/cool/cherish/module/impl/misc/友树何树友友树树何树.树友树何树何树树树何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 185: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2239564690766617332L, -2250150309050547138L, MethodHandles.lookup().lookupClass()).a(277305290981819L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 95033052907620L;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[15];
      int var18 = 0;
      String var17 = "¨ðñ¹õÄ\u001dK²þÓ\bxH»'HÑ<ì,GPs\u0010'£ÐBQ¾ÐT\u00174û§\u0007Me\u0089 VR%¹»6\u0081£\u0096\u008eÿ\u000e®ãmX½I~j\u008dª\u00adË\f^\u001f)M\u0093ï¸\u0018ñ\u0012\u0017\u0098áß\u0080Ï\u0082\u0095/5C\u008e\u009bÒ,YÚ\u001b\u0015\u0087¥(\u0010\u008e\u009bbäoX\u008b\u0091Û\u008f#A\u0095´\u0005\u001b Óy\u0099ç¯Øoa\u009b`\tõ<\u001dh \u0002c\u009e¦Ð[ÌhùöP\u008bv-¤O\u0018lÚÉa½\u0019Vÿú\u009f·8\u008d\u0081Àn>\u0088´ýxpkþ ÐÎ\u0019pdòE\né¾\u0004Ø¢C3ñ\u009f8$æ÷Ðm!~8\u0081\u008e\f9üæ\u0010³\u008e©Cáíý\u009a\u000b^\u0088G¥TEö\u0018\u0082ö\u0097\u009al).EÔ\u0006¬£ÿ-\u008e~-ÛS=\u009a+ö£\u0010\"\u00ad+¡\u0002½\u0089\u0014\u007f\u0010Y°<¿\u0096c0ã^\u009c\u001aàL9õw¯\npgJ9»~ÒÍ\u0083\u0090áÕ\u0006ìo\u001clv¢\u0012Få\fC£\u0004\u0085kH\u0099a½3x<\u001c\u0096\u0018\u0083Óªæ2\u0012ÓÁxí\u0086?\u0088ÊS\u0012¹¶'»po\t,";
      short var19 = 340;
      char var16 = 24;
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[15];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u000fZq\u0081sW$\u001aíß>»Ú\u009e³¥".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "Ï:¸|}üî«O\u0082_sw\rLÀ;óÔê¡\u0011\u0012²\u009f\u0098@æ§\u0098Ùµ ]gï\u000b'þÌÈs3}\u0083\u000eµà\u009c²Ý\u0006¢\u00970_bm£àÍ!\u009b\u001d\u0019";
                  var19 = 65;
                  var16 = ' ';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   private void V(String message) {
      long a = 友树何树友友树树何树.a ^ 104872236772916L;
      d<"C">(2524867978826267014L, a);
      if (mc.player != null) {
         d<"J">(mc.player, 2525880412356491978L, a).sendChat(message);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 36;
               case 1 -> 61;
               case 2 -> 37;
               case 3 -> 14;
               case 4 -> 35;
               case 5 -> 38;
               case 6 -> 13;
               case 7 -> 18;
               case 8 -> 26;
               case 9 -> 51;
               case 10 -> 10;
               case 11 -> 12;
               case 12 -> 28;
               case 13 -> 60;
               case 14 -> 63;
               case 15 -> 15;
               case 16 -> 0;
               case 17 -> 5;
               case 18 -> 21;
               case 19 -> 47;
               case 20 -> 1;
               case 21 -> 49;
               case 22 -> 32;
               case 23 -> 62;
               case 24 -> 30;
               case 25 -> 41;
               case 26 -> 34;
               case 27 -> 16;
               case 28 -> 57;
               case 29 -> 56;
               case 30 -> 50;
               case 31 -> 40;
               case 32 -> 54;
               case 33 -> 42;
               case 34 -> 3;
               case 35 -> 25;
               case 36 -> 46;
               case 37 -> 2;
               case 38 -> 55;
               case 39 -> 48;
               case 40 -> 20;
               case 41 -> 9;
               case 42 -> 17;
               case 43 -> 44;
               case 44 -> 43;
               case 45 -> 11;
               case 46 -> 4;
               case 47 -> 7;
               case 48 -> 22;
               case 49 -> 33;
               case 50 -> 58;
               case 51 -> 8;
               case 52 -> 24;
               case 53 -> 29;
               case 54 -> 45;
               case 55 -> 59;
               case 56 -> 6;
               case 57 -> 39;
               case 58 -> 23;
               case 59 -> 31;
               case 60 -> 53;
               case 61 -> 52;
               case 62 -> 19;
               default -> 27;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25229;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树何树友友树树何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树何树友友树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树何树友友树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'J' && var8 != 'W' && var8 != 'Z' && var8 != 228) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 198) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'C') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'J') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'W') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'Z') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 31445;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树何树友友树树何树", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树何树友友树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "\u001f\u001cd1af\u0010\\):k{\u0015\u0001\"|cf\u0018\u0007&7 `\u0011\u0002&|c`\u000f\u0011d厙栟作桭厹厁桃栟作桭";
      m[1] = "qb\u0012{/\u0003~\"_p%\u001e{\u007fT66\r~yY6)\u0001b`\u0012Z/\u0003~i]v\u0016\r~yY";
      m[2] = "\u0007o\u001bSy1\u0007o\f\u000fu>\u001d$\u0018\u0012f4\r$\n\u0013`1\u001dsA\rx9\u0010o\u001dSD4\bs\n\u000f";
      m[3] = "K\u0001l)M\\DA!\"GAA\u001c*dO\\L\u001a./\f佦佽厤众伟叩佦佽桾桓";
      m[4] = "Sa\u0012<2j\\!_78wY|Tq+d\\zYq4h@c\u0012厔桌佐校叄号伊桌収叻";
      m[5] = "\b\u0010RjT9\u0007P\u001fa^$\u0002\r\u0014'V9\u000f\u000b\u0010l\u0015?\u0006\u000e\u0010'V?\u0018\u001dR参台厝伾伫桭栘株伃桺";
      m[6] = int.class;
      n[6] = "java/lang/Integer";
      m[7] = "F@g\u0006t\nI\u0000*\r~\u0017L]!Kn\u0011LB:K栊厮栴句厂估低桴佰佻";
      m[8] = "u\f%E)a~\u00034\nUxq\u0019:IbHg\u000e6Tsdp\u0003";
      m[9] = "h\u000e[\u0010vsh\u000eLLz|rELRr\u007fh\u001f\u0001Nw{\u007f\u000e]\u0010Wue\nCnw{\u007f\u000e]";
      m[10] = "t\u000eiz(}t\u000e~&$rnE~8,qt\u001f390xn\u0002m8$m\u007f\u00193\u0017)}\u007f\u0005i\u0004$wq\u000ei\u0018,gn\u000es17";
      m[11] = ">\u0013\u0011qm{5\u001c\u0000>\fu>\u0017\u0004d";
      m[12] = "\u000f%D\u001d}1\u0015%Es栅厝桳会栧伮栅桇桳会>N#:\u0016*\u0007\u0014'<\u0004";
      m[13] = "\u0003\"PN\u0018,_(\u0015Kt\u00178\u007f\u0007\rHg\u0006&UL\u0005^";
      m[14] = "\"`l>\u001bU8`mP厹栣桞栛叕桉伧叹厄叁\u0016)\u0001\n#lk/\u001aV";
      m[15] = "\u001fV3j\u00079\u0005V2\u0004伻伋伧佩桐叇桿厕档号I=\u0005;\u0002Q/j\u001a?\u0017";
      m[16] = "\u001e\u0000_\u001aVb\u0004\u0000^t叴栔桢伿佸桭叴収伦伿%NLv\u0004^\u001dMP3\u001b";
      m[17] = "\u0013?R\u0001\u001e$O5\u0017\u0004r\u0010(b\u0005BNo\u0016;W\u0003\u0003V";
      m[18] = "|(G+C\u000e>|\u001dv8厼伛佊伧佇叻桦厅栎档\u001a\u0002@{&\u0001k@\u0014!{";
      m[19] = "j4c\u0015l\\;.+\u0017\u0014J\u0003g+Y*\u001dk\t\u0013V~[7oqW$Jm";
      m[20] = "{+\u000e\u001e\u0018\u000ba+\u000fp伤厧佃桐伩伭厺厧佃厊tMF\u0000b$M\u0017B\u0006p";
      m[21] = ";8u\u000f'Y!8ta桟佫桇伇栖似桟佫厝桃\u000f\u0018=\u0006:4r\u001e&Z";
      m[22] = "\u001akw(3\u0019\u0000kvF伏桯桦及佐伛桋伫厼及\r|)\r\u000055\u007f5H\u001f";
      m[23] = "\u007fwXg0\bewY\t厒厤佇取叡佔伌桾佇佈\"3*\u001ce)\u001a06Yz";
      m[24] = "Cfo@LWYfn.D8\u0018;t\u0011HJMmuI-\u0006\u0019e*K_SOdr.";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   @EventTarget
   public void o(AttackEvent event) {
      long a = 友树何树友友树树何树.a ^ 7157180423703L;
      long ax = a ^ 42867515320834L;
      d<"C">(1380771030278834597L, a);
      if (!this.w(new Object[]{ax})) {
         if (d<"J">(this, 1382405055358792724L, a).getValue()) {
            if (event.getTarget() instanceof Player player && player != mc.player) {
               d<"W">(this, player, 1380909195929797305L, a);
            }
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void u(WorldEvent event) {
      long a = 友树何树友友树树何树.a ^ 62525631225935L;
      d<"W">(this, null, -5948753973634859807L, a);
   }

   @EventTarget
   public void N(LivingUpdateEvent event) {
      long a = 友树何树友友树树何树.a ^ 83146923700125L;
      long ax = a ^ 118616543353736L;
      long axx = a ^ 113781209855886L;
      long axxx = a ^ 98481796337975L;
      d<"C">(-6727212406954822873L, a);
      if (!this.w(new Object[]{ax})) {
         if (d<"J">(this, -6726962704789617250L, a).getValue()) {
            if (d<"J">(this, -6727334932259212493L, a) != null && !d<"J">(this, -6727334932259212493L, a).isAlive()) {
               if (d<"J">(this, -6727439317499954855L, a).c(c<"z">(28674, 3615720220669257846L ^ a), axx)) {
                  String message = b<"e">(16157, 7013326146509504308L ^ a)
                     + d<"J">(this, -6727334932259212493L, a).getName().getString()
                     + " "
                     + d<"J">(this, -6726806736150537689L, a).getValue();
                  this.V(message);
                  d<"J">(this, -6727439317499954855L, a).U(axxx);
               }

               d<"W">(this, null, -6727334932259212493L, a);
            }
         }
      }
   }

   @EventTarget
   public void Q(PacketEvent event) {
      long a = 友树何树友友树树何树.a ^ 115631686472849L;
      long ax = a ^ 80625926103172L;
      long axx = a ^ 76753210526850L;
      long axxx = a ^ 135395274517051L;
      d<"C">(-7374643011309123541L, a);
      if (!this.w(new Object[]{ax})) {
         if (event.getPacket() instanceof ClientboundSetTitleTextPacket wrapper && d<"J">(this, -7372418646717375385L, a).getValue()) {
            Component titleComponent = wrapper.getText();
            String titleText = Component.literal(titleComponent.getString()).getString();
            String[] keywords = d<"J">(this, -7374098176464537684L, a).getValue().split(",");
            boolean containsGGKeyword = false;
            int var18 = keywords.length;
            int var19 = 0;
            if (0 < var18) {
               String keyword = keywords[0];
               if (titleText.contains(keyword.trim())) {
                  containsGGKeyword = true;
               }

               var19++;
            }

            if (containsGGKeyword && d<"J">(this, -7374241069301837123L, a).c(c<"z">(22159, 9162153250309780982L ^ a), axx)) {
               this.V(d<"J">(this, -7374553725590592403L, a).getValue());
               d<"J">(this, -7374241069301837123L, a).U(axxx);
            }
         }
      }
   }

   private static String HE_SHU_YOU() {
      return "何树友被何大伟克制了";
   }
}
