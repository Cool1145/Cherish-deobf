package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.HitResult.Type;
import org.lwjgl.glfw.GLFW;

public class 何树友树何何友何树友 extends Module implements 何树友 {
   private boolean 树友何何何友友树何何 = false;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[18];
   private static final String[] k = new String[18];
   private static int _何炜霖230622200409390090 _;

   public 何树友树何何友何树友() {
      super("MidAddFriend", "中键添加好友", 树何友友何树友友何何.友树何友何树树树树何);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3501892674193836565L, -1891358838552321262L, MethodHandles.lookup().lookupClass()).a(175493876812705L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(22365995791224L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "Ã\u0012\u0088\u0091ÁT¸}[ÃV\u0017m×\u009d¹\u0086\u0011õ\u0085\u0000¥R$Ë\u0080\u000fa¥\nUåäKÌ³¹Ñ6Ó ¨\u000b\r)\u000bT\u0087L\"\u001e¾á$\u001aÆ¨\u0016Ñ»á\u0090Ðìr¸x\u0080\u0098\u0018\u0089\u009dÊ";
      byte var8 = 73;
      char var5 = '(';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[4];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "_d«[2Ëa%«¼D\u001aN0\u0018\u00928\u0007ü\u0013Î\u0086\u008d7ôÐød¾\u0082\u00ad¶ÊùÒeqÙÈ~÷Ìá\u009fA\u0019¿\u0015ý¨\u0082\u0013Ã\u0099Í\u00990'ËÌQFÈ ÆLÄsG\u000e\u000fÆ\u001b\u001bÎgÊ\u0006\u0092^>\u008cQ\f\u009eäg)Ð\u001dòw9Ñ\u0011ç*Ø\u0019qÁ\u009a+\u0004ê";
                  var8 = 105;
                  var5 = '8';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 15;
               case 1 -> 10;
               case 2 -> 31;
               case 3 -> 62;
               case 4 -> 2;
               case 5 -> 32;
               case 6 -> 50;
               case 7 -> 5;
               case 8 -> 63;
               case 9 -> 40;
               case 10 -> 49;
               case 11 -> 21;
               case 12 -> 24;
               case 13 -> 55;
               case 14 -> 37;
               case 15 -> 59;
               case 16 -> 36;
               case 17 -> 58;
               case 18 -> 38;
               case 19 -> 6;
               case 20 -> 51;
               case 21 -> 19;
               case 22 -> 61;
               case 23 -> 25;
               case 24 -> 60;
               case 25 -> 41;
               case 26 -> 13;
               case 27 -> 18;
               case 28 -> 33;
               case 29 -> 29;
               case 30 -> 45;
               case 31 -> 43;
               case 32 -> 39;
               case 33 -> 35;
               case 34 -> 3;
               case 35 -> 12;
               case 36 -> 42;
               case 37 -> 53;
               case 38 -> 47;
               case 39 -> 23;
               case 40 -> 44;
               case 41 -> 8;
               case 42 -> 27;
               case 43 -> 34;
               case 44 -> 54;
               case 45 -> 17;
               case 46 -> 52;
               case 47 -> 56;
               case 48 -> 20;
               case 49 -> 26;
               case 50 -> 9;
               case 51 -> 30;
               case 52 -> 14;
               case 53 -> 1;
               case 54 -> 28;
               case 55 -> 46;
               case 56 -> 11;
               case 57 -> 48;
               case 58 -> 57;
               case 59 -> 7;
               case 60 -> 22;
               case 61 -> 4;
               case 62 -> 0;
               default -> 16;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/何树友树何何友何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28975;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/何树友树何何友何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[?\u001e\u008e\u009cé\u0094N\u0094[õ9a%\u007f")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'p' && var8 != 'P' && var8 != 'D' && var8 != 232) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 201) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'u') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'p') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'P') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'D') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/何树友树何何友何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "k\u000e\u0003nf\u000bdNNel\u0016a\u0013E#d\u000bl\u0015Ah'\re\u0010A#d\r{\u0003\u0003佘栘厯栙伵佸叆作桵參";
      j[1] = boolean.class;
      k[1] = "java/lang/Boolean";
      j[2] = "3\u0006h\u007f\u001c\u0001<F%t\u0016\u001c9\u001b.2\u001e\u00014\u001d*y]桿伅厣厍佉桢厥厛伽伓";
      j[3] = "k.o!K\u000ek.x}G\u0001qel`T\u000baekg_\u0014+\u0003r{t\u0002v>w{\u00023|;~";
      j[4] = "!qM</R*~\\sSK%dR0d{3s^-uW$~";
      j[5] = "~z|E9d~zk\u00195kd1k\u0007=h~k&&=cu|z\n2y";
      j[6] = "F\u0013p{34F\u0013g'?;\\Xs:,1LXt='.\u0006>m!\f8[\u0003h!";
      j[7] = "]\u000fR4M^RO\u001f?GCW\u0012\u0014yO^Z\u0014\u00102\fXS\u0011\u0010yOXM\u0002R伂栳叺栯伴伩伂栳佤佫";
      j[8] = "0_A\u0018Np;PPW3h(WY\u001e";
      j[9] = "z\u0007jh=Kz\u0007}41D`L}*9Gz\u00160!%K:\u0011}45Gz\u00110\u00153Pq\u0007p";
      j[10] = "mTtn\u001fDf[e!~JmPa{";
      j[11] = "E\".V-\u0010\u00029+\rJ厸桥伍历佫桓桢桥桉优6s\t\u00170\"]4\u0012\u0012k";
      j[12] = "+jjF8|nb>[Vp\u0016<kV$y&s?\u0001'\u0019";
      j[13] = "yX\u0019\u0000c)+\u0018Pn栕厃位伿佴厭叏桙位伿)\u001f<*o\u000bK\bb+";
      j[14] = "9q(\u0004_.rl.\u0002!'U zB\u0011qU\u0011}\u0006Mxoj{\u0001S+";
      j[15] = "}o\u0005hpY(-L#\u0015i\u0001\f4FD$}o\u0005hpY(-L#";
      j[16] = "\u001c.D\u000bm\"Nn\rekKNzD\u0000o1Km\u001b\u001d\u0002p\u001b$\u0011\bxu\f{\fe";
      j[17] = "'\u001bL\u0000\u0016il\u0006J\u0006h`KJ\u001eFW1K{\u001b\u0005\r7,\u0014D\u0010P~";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void E(Render2DEvent event) {
      何树友树何何何树何何.a();
      if (!this.Q(new Object[]{52406761729175L}) && mc.screen == null) {
         boolean isMiddleMouseDown = GLFW.glfwGetMouseButton(mc.getWindow().getWindow(), 2) == 1;
         if (!this.树友何何何友友树何何) {
            HitResult hitResult = mc.hitResult;
            if (hitResult == null || hitResult.getType() != Type.ENTITY) {
               return;
            }

            EntityHitResult entityHit = (EntityHitResult)hitResult;
            Entity entity = entityHit.getEntity();
            if (entity instanceof Player) {
               String playerName = 何树友友树树友何树何.N(entity.getName().getString(), 45819100191072L);
               if (!Cherish.instance.P().M(playerName)) {
                  Cherish.instance.P().j(playerName);
                  ClientUtils.P(125527250587045L, playerName + "was added to your friends.");
               }

               Cherish.instance.P().l(playerName);
               ClientUtils.P(125527250587045L, playerName + " was removed from your friends.");
            }
         }

         this.树友何何何友友树何何 = isMiddleMouseDown;
      }
   }

   private static String HE_WEI_LIN() {
      return "何树友为什么濒天了";
   }
}
