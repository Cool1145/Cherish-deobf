package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.protocol.game.ClientboundSetScorePacket;

public class 友树友树何树何何何树 extends Module implements 何树友 {
   public static final Map<String, AtomicInteger> 何树何何何何友何树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[12];
   private static final String[] k = new String[12];
   private static String HE_SHU_YOU;

   public 友树友树何树何何何树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/misc/友树友树何树何何何树.a J
      // 03: ldc2_w 52992612786403
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 29099
      // 0c: ldc2_w 2499016386342030642
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树友树何树何何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 12501
      // 19: ldc2_w 8417875217916316750
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/misc/友树友树何树何何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w -820717135234244063
      // 26: lload 1
      // 27: invokedynamic î (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/misc/友树友树何树何何何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-9152027047267749753L, -7854753558145454315L, MethodHandles.lookup().lookupClass()).a(117166950764994L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 76858007588383L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "â\u0015½eù§\u008eöÑ°.ÿ\u0092\u0096ïÓ\u009aÒ&\u009fáÃ¨õ\u0018Ék\u0010:vio\u0004Çì.\u0001\u0086Ü8QÐ5\u0015\u009do\u0018c\r";
      byte var8 = 49;
      char var5 = 24;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[4];
                     何树何何何何友何树何 = new HashMap<>();
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "f!¥\u0091\u0007»5¾}de:¶\u0094ñ\u0097\u0085\u008c\u009d2< «\u009cÙ>\u0089ã\u0080Ýc\u000f\u0010CøÏrÏMUì\u007f\u001e-V·<\u008c\u008b";
                  var8 = 49;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 57;
               case 1 -> 33;
               case 2 -> 23;
               case 3 -> 58;
               case 4 -> 40;
               case 5 -> 52;
               case 6 -> 4;
               case 7 -> 49;
               case 8 -> 3;
               case 9 -> 26;
               case 10 -> 14;
               case 11 -> 46;
               case 12 -> 15;
               case 13 -> 42;
               case 14 -> 38;
               case 15 -> 19;
               case 16 -> 27;
               case 17 -> 45;
               case 18 -> 21;
               case 19 -> 13;
               case 20 -> 6;
               case 21 -> 63;
               case 22 -> 32;
               case 23 -> 37;
               case 24 -> 8;
               case 25 -> 54;
               case 26 -> 39;
               case 27 -> 36;
               case 28 -> 61;
               case 29 -> 43;
               case 30 -> 53;
               case 31 -> 60;
               case 32 -> 31;
               case 33 -> 2;
               case 34 -> 28;
               case 35 -> 35;
               case 36 -> 30;
               case 37 -> 41;
               case 38 -> 25;
               case 39 -> 44;
               case 40 -> 34;
               case 41 -> 20;
               case 42 -> 50;
               case 43 -> 0;
               case 44 -> 55;
               case 45 -> 5;
               case 46 -> 11;
               case 47 -> 51;
               case 48 -> 47;
               case 49 -> 56;
               case 50 -> 10;
               case 51 -> 22;
               case 52 -> 48;
               case 53 -> 17;
               case 54 -> 24;
               case 55 -> 12;
               case 56 -> 18;
               case 57 -> 29;
               case 58 -> 62;
               case 59 -> 59;
               case 60 -> 16;
               case 61 -> 1;
               case 62 -> 7;
               default -> 9;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树友树何树何何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2053;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树友树何树何何何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   @EventTarget
   public void b(LivingUpdateEvent event) {
      long a = 友树友树何树何何何树.a ^ 28483538176879L;
      long ax = a ^ 98165334648378L;
      c<"f">(6850138308912950095L, a);
      if (!this.w(new Object[]{ax})) {
         Iterator var7 = mc.level.players().iterator();
         if (var7.hasNext()) {
            AbstractClientPlayer player = (AbstractClientPlayer)var7.next();
            if (player != mc.player && c<"î">(6850985657093420931L, a).containsKey(player.getName().getString())) {
               player.setHealth(Math.max(1, ((AtomicInteger)c<"î">(6850985657093420931L, a).get(player.getName().getString())).get()));
            }
         }
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树友树何树何何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'G' && var8 != 201 && var8 != 238 && var8 != 'c') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 214) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'f') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'G') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 201) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 238) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "pl\u0013\u0007!\u0019\u007f,^\f+\u0004zqUJ#\u0019wwQ\u0001`\u001f~rQJ#\u001f`a\u0013厯桟厽栂佗栬伱伛伣栂";
      j[1] = "a2pI\u001a\u001c\u007f:j\u0006y\b{";
      j[2] = "P\u001erO=#_^?D7>Z\u00034\u0002?#W\u00050I|%^\u00000\u0002?%@\u0013r叧厙厇佦伥桍栽桃伙栢";
      j[3] = int.class;
      k[3] = "java/lang/Integer";
      j[4] = "MJL\u000f\u001c\nFE]@`\u0013I_S\u0003W#_H_\u001eF\u000fHE";
      j[5] = ".\u0012AoH0!R\fdB-$\u000f\u0007\"J0)\t\u0003i\t伊优厷伺余召伊优桭桾";
      j[6] = "fb\u0002?\u0016$mm\u0013pw*ff\u0017*";
      j[7] = "BDW\u0000\nIC\u0005[j佪桮伡佨佫伷叴伪桥佨6\u001aQL\u001c\u0005N\u0005\r\b";
      j[8] = "\u0017E\\:0M\u001fH@>\r}.\u001dVk\u007fL\u001eE\u0006\u007fh4";
      j[9] = "P#2-\u001e1\u0000ri+\u007f参伱佄伌伕厼栘厯栀案HC;\u000f|0x\u0013jTz";
      j[10] = "sg{\\mmr&w69Sv&\"T-5(k\"UPh}.xK660.y6";
      j[11] = "kI% c:cD9$^\u0005R\u0011/q,;bI\u007fe;C";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   @EventTarget
   public void p(PacketEvent event) {
      long a = 友树友树何树何何何树.a ^ 114085229926829L;
      long ax = a ^ 43305002923256L;
      c<"f">(995884338819929789L, a);
      if (!this.w(new Object[]{ax})) {
         if (event.getPacket() instanceof ClientboundSetScorePacket packet
            && mc.level != null
            && (
               b<"w">(16064, 4812572920439618324L ^ a).equals(packet.getObjectiveName())
                  || b<"w">(20253, 5400656709350968011L ^ a).equals(packet.getObjectiveName())
            )
            && !packet.getOwner().equals(mc.player.getGameProfile().getName())) {
            if (!c<"î">(995833236463494465L, a).containsKey(packet.getOwner())) {
               AtomicInteger atomic = new AtomicInteger();
               c<"î">(995833236463494465L, a).put(packet.getOwner(), atomic);
            }

            ((AtomicInteger)c<"î">(995833236463494465L, a).get(packet.getOwner())).set(packet.getScore());
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_WEI_LIN() {
      return "何建国230622195906030014";
   }
}
