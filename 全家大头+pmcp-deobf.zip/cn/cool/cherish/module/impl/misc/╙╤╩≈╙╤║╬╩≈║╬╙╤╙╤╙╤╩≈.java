package cn.cool.cherish.module.impl.misc;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.combat.KillAura;
import cn.cool.cherish.module.impl.player.友友树树何何友树何友;
import cn.cool.cherish.module.impl.player.树友何何友何树何树友;
import cn.cool.cherish.module.impl.player.树友何树友树何友树树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundLoginPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;

public class 友树友何树何友友友树 extends Module implements 何树友 {
   private final BooleanValue 友友何友树何树友友友 = new BooleanValue("LagBack Check", "回弹检测", false);
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[14];
   private static final String[] k = new String[14];
   private static String HE_DA_WEI;

   public 友树友何树何友友友树() {
      super("ModuleHelper", "模块助手", 树何友友何树友友何何.友树何友何树树树树何);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(5989676385733706487L, 7984677092405964311L, MethodHandles.lookup().lookupClass()).a(163238033530212L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(39291961575854L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "/\u0081å\u0088|\u009e\u009dw\\\u0013\u0010d\u001aÄÉxµßT\u00adÔøz¦AS2°\u0096Õ\u0094c +¼\u000bz(È^\u00168Z\u0016fjºÇïd\u0099Ó§ß\u008b\u0080°\u009cÅK\ríÚoá";
      byte var8 = 65;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[4];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ó¨VXnèÉ\u0086I\u009f\u000fW\u0010\u0092¥³\u007f\b¹Þ[\u0093×C\u0018\u008cÜ³9úeù\u000etÄ\t°U\u001fªì\u009e\u007f\u0097\u001b/\u0016~(";
                  var8 = 49;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void F(WorldEvent event) {
      this.d();
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 34;
               case 1 -> 62;
               case 2 -> 45;
               case 3 -> 44;
               case 4 -> 38;
               case 5 -> 56;
               case 6 -> 8;
               case 7 -> 23;
               case 8 -> 13;
               case 9 -> 1;
               case 10 -> 12;
               case 11 -> 15;
               case 12 -> 2;
               case 13 -> 58;
               case 14 -> 47;
               case 15 -> 57;
               case 16 -> 9;
               case 17 -> 37;
               case 18 -> 41;
               case 19 -> 10;
               case 20 -> 33;
               case 21 -> 21;
               case 22 -> 19;
               case 23 -> 54;
               case 24 -> 43;
               case 25 -> 32;
               case 26 -> 48;
               case 27 -> 36;
               case 28 -> 11;
               case 29 -> 55;
               case 30 -> 49;
               case 31 -> 18;
               case 32 -> 25;
               case 33 -> 4;
               case 34 -> 16;
               case 35 -> 51;
               case 36 -> 63;
               case 37 -> 50;
               case 38 -> 46;
               case 39 -> 20;
               case 40 -> 61;
               case 41 -> 29;
               case 42 -> 17;
               case 43 -> 27;
               case 44 -> 59;
               case 45 -> 28;
               case 46 -> 42;
               case 47 -> 7;
               case 48 -> 3;
               case 49 -> 60;
               case 50 -> 5;
               case 51 -> 40;
               case 52 -> 14;
               case 53 -> 6;
               case 54 -> 22;
               case 55 -> 53;
               case 56 -> 0;
               case 57 -> 35;
               case 58 -> 52;
               case 59 -> 31;
               case 60 -> 39;
               case 61 -> 26;
               case 62 -> 24;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树友何树何友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27159;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树友何树何友友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/misc/友树友何树何友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'x' && var8 != 240 && var8 != 'g' && var8 != 234) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 214) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'P') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'x') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 240) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'g') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   public void d() {
      何树友树何何何树何何.a();
      if (Cherish.instance.getModuleManager().getModule(KillAura.class).isEnabled()) {
         Cherish.instance.getModuleManager().getModule(KillAura.class).J(false);
      }

      if (Cherish.instance.getModuleManager().getModule(树友何树友树何友树树.class).isEnabled()) {
         Cherish.instance.getModuleManager().getModule(树友何树友树何友树树.class).J(false);
      }

      if (Cherish.instance.getModuleManager().getModule(友友树树何何友树何友.class).isEnabled()) {
         Cherish.instance.getModuleManager().getModule(友友树树何何友树何友.class).J(false);
      }

      if (Cherish.instance.getModuleManager().getModule(树友何何友何树何树友.class).isEnabled()) {
         Cherish.instance.getModuleManager().getModule(树友何何友何树何树友.class).J(false);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "&5\\\u0001\"d)u\u0011\n(y,(\u001aL d!.\u001e\u0007cb(+\u001eL b68\\厩桜叀伐桊伧厩历叀桔";
      j[1] = "6M]\u001d\u001bp=BLRgi2XB\u0011PY$ON\fAu3B";
      j[2] = "/V\u000fy0` \u0016Br:}%KI42`(MM\u007fqf!HM42f?[\u000f住桎叄桝佭佴住桎佚伙";
      j[3] = "\u001dH@G\u00100\u0016GQ\bm(\u0005@XA";
      j[4] = "!S9;bm.\u0013t0hp+N\u007fv`m&H{=#栓众叶叜伍栜叉厉佨佂";
      j[5] = "xyn5pLw9#>zQrd(xiBwb%xvNk{n\u0014pLwr!8IBwb%";
      j[6] = "\u000eN\u007fA\t9\u000eNh\u001d\u00056\u0014\u0005h\u0003\r5\u000e_%\u001f\b1\u0019NyA(?\u0003Jg?\b1\u0019Ny";
      j[7] = int.class;
      k[7] = "java/lang/Integer";
      j[8] = "oh\u0011\u0003(.dg\u0000LI ol\u0004\u0016";
      j[9] = "\u0001\u0005#:\u000bdH_2J[\u001eJ\u0007&*PxFZ J@x\\\u0001 ,L%Za";
      j[10] = "{\u0019Z.\u0005v9O[ ;叓桙伮右伞栢栉桙桪佭C\u0000z*\u001e\u000e%B,+\u0010";
      j[11] = "\u001cL[R.sYC\f\u0011Ue%\tUV;p\u001bIBA2\f";
      j[12] = "P\u000bM\u000f*s\u0019Q\\\u007f叐及伴厬栵伢栊及厪厬,Dun\u0014\u000bE\u0018#p\u0012";
      j[13] = "r\u000eg:vZ$\bs{HF\u0019M35y\u0017\u0019t?0-V1\u0012:a6X";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @EventTarget
   public void t(PacketEvent event) {
      何树友树何何何树何何.a();
      if (mc.player != null) {
         Packet<?> packet = event.getPacket();
         if (packet instanceof ClientboundLoginPacket
            || packet instanceof ClientboundPlayerPositionPacket && mc.player.tickCount > 200 && this.友友何友树何树友友友.getValue()) {
            this.d();
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void M(LivingUpdateEvent event) {
      何树友树何何何树何何.a();
      if (mc.player != null) {
         if (mc.player.isSpectator() || !mc.player.isAlive() || mc.player.isDeadOrDying()) {
            if (Cherish.instance.getModuleManager().getModule(树友何树友树何友树树.class).isEnabled()) {
               Cherish.instance.getModuleManager().getModule(树友何树友树何友树树.class).J(false);
            }

            if (Cherish.instance.getModuleManager().getModule(友友树树何何友树何友.class).isEnabled()) {
               Cherish.instance.getModuleManager().getModule(友友树树何何友树何友.class).J(false);
            }
         }
      }
   }

   private static String HE_DA_WEI() {
      return "我是何树友";
   }
}
