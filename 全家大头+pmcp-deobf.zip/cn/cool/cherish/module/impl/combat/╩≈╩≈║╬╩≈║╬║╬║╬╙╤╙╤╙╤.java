package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.树树何树何何树何何树;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.packet.BlinkUtils;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public class 树树何树何何何友友友 extends Module implements 何树友 {
   private final ModeValue 何何何友何何树何友友 = new ModeValue("Mode", "模式", new String[]{"Range", "Simple", "KillAura"}, "Range");
   private final NumberValue 树友何何友友树何何树 = new NumberValue("Range", "范围", 6.0, 1.0, 12.0, 0.1).A(() -> this.何何何友何何树何友友.K("Range"));
   private final NumberValue 何何友树树何友何友何 = new NumberValue("Delay", "间隔", 500.0, 10.0, 1000.0, 10.0);
   private final BooleanValue 友何何友树何树友友友 = new BooleanValue("Forward Check", "真实位置检测", true);
   private final BooleanValue 树树何友树友友何何何 = new BooleanValue("Hurt Check", "受伤检测", true);
   private final BooleanValue 树树树何何何树何树何 = new BooleanValue("Render Real Position", "显示真实位置", true);
   private final BooleanValue 树友何友友何何树友树 = new BooleanValue("Rainbow", "彩虹", true).A(this.树树树何何何树何树何::getValue);
   private final BooleanValue 何友树何树何友友友友 = new BooleanValue("Fill Mode", "填充模式", true).A(this.树树树何何何树何树何::getValue);
   private final BooleanValue 友友树何何友树树何友 = new BooleanValue("Wireframe Mode", "线框模式", true).A(this.树树树何何何树何树何::getValue);
   private final NumberValue 树友友友友何树何友何 = new NumberValue("Fill Alpha", "填充透明度", 0.3, 0.0, 1.0, 0.05).A(() -> {
      KillAura.x();
      return this.树树树何何何树何树何.getValue() && this.何友树何树何友友友友.getValue();
   });
   private final BooleanValue 友何友何何何友树友何 = new BooleanValue("Damage Effect", "伤害效果", true).A(this.树树树何何何树何树何::getValue);
   private final 何友友何树何树何树友 何树树友友何树友何树 = new 何友友何树何树何树友(51913986529303L);
   private final 何友友何树何树何树友 何树友树树树何何何树 = new 何友友何树何树何树友(51913986529303L);
   private boolean 何何何何树树友友树树 = false;
   private boolean 树友树友树友树何何何 = false;
   private boolean 树何何何何何友树树树 = false;
   private RemotePlayer 树友何树何友何友友树;
   private Vec3 友树树树何何树何何树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[53];
   private static final String[] l = new String[53];
   private static String HE_DA_WEI;

   public 树树何树何何何友友友() {
      super("FakeLag", "虚假延迟", 树何友友何树友友何何.何何何何何树何何友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5677114387515288910L, -25885405704587525L, MethodHandles.lookup().lookupClass()).a(258648789995544L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(57345825498979L << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[30];
      int var12 = 0;
      String var11 = "3Be\u0004\u0092©Å@âö\u008b\u0092¡0V\u0012\u007f\u0012\u008d*;óHN Ç\u0099Ø´Ü1yCY¯H<\u0000\u001dÕ\u000f \u0090W0Ãù\u0091j\b\tÃ\u0001î¬ZA kõùgO\u008d\u0007\fV\u0083äCe¢\u0098\u00adòþ&[\u008e\u008d¾NL\u001b[/ûL\f+\u0010\f5{/X5Ö×Ä7Ä(:í9+\u0010)kx©$âíIüV»îP\u0018òË @\u0095\u001d·\nÐ¹ö+\u0015Ë]Ï\u0014²²\u0013ù°1»r¦\u0012WðSKgZ<]\u0010G\u008alí¦:nºD..ÐAJc\r Ê}4µ@×\u0096!ÁH\u0019µ^\u0017\u0084ûº\u007f@,\fù\u008a\b\u001cN³ÌðÛÿT\u0010-Øê^\u001fýÿê@ñì²°Öê[(\tµ\u008b\u0089B$Ú\u0082Q\u0012uG#òÕ\u0099\u009b\u0011Âcè\u008cã§L\u0004ËÇµ17á\u0092V·\u0088\u0083¸ø°\u0018\u008c\u000ezâWÞ¼\u0088¿a\u0001ÁÑþ\u008a\u009e\f\u0081ØÓÏ\u009a_¦\u0010\u0014çU\u001d<f g4\u0086In\u0098Õ¢Ñ Àí?KiÜæ\u001d¹\u0002Ô)r¸E\r\u0004%«gQ'Çu&\u0080g\u000b\u007f2sC \u0089°\u001c\u008a\u0096õ\u008a]T\u001a®8\u001a\u00adz»\bºØ\u0010Æ\u0096ú±µ\u001f\u001e\u0098\u0005\u0013t0\u0018eõ(\u008cÓ\u0080mJ%À©Ò\u0014¡±\u0081Þ\b@D\u009c>î\u0012\u0010X&Þõw¸Ó\u009c8ñ²6\u009c\u008fÂÏ\u0010\u0013¦ö\n\u001aÂ®%\u0002º@Lúy`6\u0018L ò\f¨$ÊX§\u009eÚXjuþu0+=Sf\u0002{÷(\u008ao5óÙ^á·ä\u009f\u0093\u00055aÄ&\\£\"\u0090JoÓ[isü\u001a(ISè¯Ï§â\u0005\u007f~H\u0018µ\u001d6´\u0082äP·6d\u009eO¸\u0094q\u0001ñ\u008aLÌV±\u001eD\u0010UIaÆ5Ìå\u0080\u000bläZÎÅ\u0080ì \u0090ÉV\u0094@\na\u0081ê%\u0081 \u0093¡W\u0007/\u0089q\u001eE¯\u000e\u0002\u0011\f3²J\u0097¯\u0092\u0010\u008f\u001b\u0081e}a\u0093é\u0019©ER\u009aîPp á\u008dÖ¥\fµ4ô\u0017?\"¸w6\u009f}l$\u001e\u001aoþÿÝé\u001aÔ\u0011Û$^=\u0010Be\u0080éND´6ªL+»Ë=Ô_\u0018è\u0018Êän\u0089\u000fÔ)¿×\tô\u000bwð\u0016 Pð&8\fÇ\u0010\u0017»\u008cW\t\u0003É¸,¨ÏÖbÒ\u0094Í\u00105¤²ñ6-\tó¥$yÉÉ\u0095{\u0002";
      short var13 = 699;
      char var10 = 24;
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[30];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(57345825498979L << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{20, -74, -68, 122, -100, 53, 125, -119});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "ÔÍ\u0088ZÙSµ\u001be\u0002)\u008c30\u009aeC\u0099\u00ad÷\u009f\u0092\u001c\u009c(¥å\u0098\u0006_Ý\u001dàÖ\u0017Ö·-\u001d\u0018g£Î\u0005Ú@\u0015Í\u0019\u0080ÛD»Sd¯T\u001aÝ¸±,\bzF";
                  var13 = 65;
                  var10 = 24;
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   private void F() {
      KillAura.x();
      if (!this.何何何何树树友友树树) {
         this.友树树树何何树何何树 = mc.player.position();
         this.o();
         BlinkUtils.W(138430676960977L);
         this.何何何何树树友友树树 = true;
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private void i() {
      KillAura.x();
      if (this.树友何树何友何友友树 != null) {
         this.树友何树何友何友友树.setPos(this.友树树树何何树何何树);
         this.树友何树何友何友友树.setYRot(mc.player.getYRot());
         this.树友何树何友何友友树.setXRot(mc.player.getXRot());
         this.树友何树何友何友友树.xo = this.友树树树何何树何何树.x;
         this.树友何树何友何友友树.yo = this.友树树树何何树何何树.y;
         this.树友何树何友何友友树.zo = this.友树树树何何树何何树.z;
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 23;
               case 2 -> 14;
               case 3 -> 0;
               case 4 -> 51;
               case 5 -> 54;
               case 6 -> 36;
               case 7 -> 58;
               case 8 -> 35;
               case 9 -> 16;
               case 10 -> 10;
               case 11 -> 39;
               case 12 -> 20;
               case 13 -> 49;
               case 14 -> 21;
               case 15 -> 9;
               case 16 -> 4;
               case 17 -> 6;
               case 18 -> 18;
               case 19 -> 57;
               case 20 -> 44;
               case 21 -> 48;
               case 22 -> 17;
               case 23 -> 13;
               case 24 -> 41;
               case 25 -> 46;
               case 26 -> 8;
               case 27 -> 45;
               case 28 -> 24;
               case 29 -> 34;
               case 30 -> 19;
               case 31 -> 32;
               case 32 -> 56;
               case 33 -> 62;
               case 34 -> 33;
               case 35 -> 42;
               case 36 -> 11;
               case 37 -> 7;
               case 38 -> 52;
               case 39 -> 63;
               case 40 -> 50;
               case 41 -> 61;
               case 42 -> 30;
               case 43 -> 40;
               case 44 -> 38;
               case 45 -> 15;
               case 46 -> 26;
               case 47 -> 55;
               case 48 -> 12;
               case 49 -> 22;
               case 50 -> 60;
               case 51 -> 53;
               case 52 -> 31;
               case 53 -> 25;
               case 54 -> 59;
               case 55 -> 47;
               case 56 -> 43;
               case 57 -> 28;
               case 58 -> 29;
               case 59 -> 5;
               case 60 -> 3;
               case 61 -> 27;
               case 62 -> 1;
               default -> 2;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/树树何树何何何友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7217;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/树树何树何何何友友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[ù\u009aüºú8e\u0085VEãHzd\u0017o, Ø>ãóÞ¡ }igÌj¿Uþ\u008b, \u001c\u009e§Tñ\u0000\u00984\u009eÏ\u001f74ñ¡ã, \u009f\u0093Ñ\u001d¬®ð§, \u0000¾äÒ}èP\u001f, AL?}®jÀ&õ\u0098¤oó\u0012âá, g¨\u008f®Jò\u0010\u008d, x\u0080^¿æb#ùuSpïqú\u0087ÿ, \u0003¬ºRÇ\ta], \u0007\u009e\u0090^zÚ\u0011¨-wú'\u0092´wÅ÷¸;\tÙ¿\u0091\u0094, ®]\u0005\u0015~7u¦Ê\u000e,mÏ³\u008b|, £×\u0087\u009fÅÒX), ûñ£ÅwÃ!ù*æÃ¨Ï\u00adÚ\u00ad, í\u0015={Ëµ¨4¸Z\u0001¥êBÉÛ, \u001d°ÀüwZBl$í\u00151'Ô^Í, ×`\u009bd")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private void s() {
      KillAura.x();
      if (this.何何何何树树友友树树) {
         this.m();
      }

      this.树友树友树友树何何何 = false;
      this.树何何何何何友树树树 = false;
      this.友树树树何何树何何树 = null;
      this.树友何树何友何友友树 = null;
      this.何树友树树树何何何树.D(11747522392279L);
      this.何树树友友何树友何树.D(11747522392279L);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/树树何树何何何友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'S' && var8 != 'K' && var8 != 'a' && var8 != 207) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 186) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'n') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'S') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'K') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'a') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @Override
   public void h() {
      this.s();
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "V<;VHuV<,\nDzLw,\u0014LyV-a\bI}A<=VwyU6;\u001dupY *\n";
      k[1] = float.class;
      l[1] = "java/lang/Float";
      k[2] = "\u001cx \u0000\u001bX\u001cx7\\\u0017W\u000637B\u001fT\u001ciz^\u001aP\u000bx&\u0000:^\u0011|8~\u001aP\u000bx&";
      k[3] = "J{+3 \u0019E;f8*\u0004@fm~\"\u0019M`i5a\u001fDei~,\u0019Dwd$a桧核佀栔伅会伣叢叞収";
      k[4] = "a\u0005E_;\bnE\bT1\u0015k\u0018\u0003\u00129\bf\u001e\u0007Yz\u000eo\u001b\u0007\u00120\u000eq\u001b\u0007]-I栓桺伾栭企伲栓伾伾栭";
      k[5] = "S\u0003aR\u0019$\\C,Y\u00139Y\u001e'\u001f\u0000*\\\u0018*\u001f\u001f&@\u0001a栠厽伞佥桼桞佤厽厀佥";
      k[6] = "\u0013\u0019\u00048.\u0011\u001cYI3$\f\u0019\u0004Bu7\u001f\u001c\u0002Ou(\u0013\u0000\u001b\u0004\u0019.\u0011\u001c\u0012K5\u0017\u001f\u001c\u0002O";
      k[7] = "\u0019M>Dqr\u0016\rsO{o\u0013Px\tsr\u001eV|B0t\u0017S|\t}r\u0017AqS0V\u0013O|fko\u001b";
      k[8] = ">@\u001f\f|v\nc\u0010L1}\u0000~\u0015\u0011:;\bc\u0018\u0017>pKA\u0013\u0006'y\u00007";
      k[9] = "\u0002\u000fZ\u0015!P\rO\u0017\u001e+M\b\u0012\u001cX8^\r\u0014\u0011X'R\u0011\rZ8;R\u0003\u0004\u0006 /S\u0014\u0004";
      k[10] = "_\u0019\u0005\u001am\rT\u0016\u0014U\u0011\u0014[\f\u001a\u0016&$M\u001b\u0016\u000b7\bZ\u0016";
      k[11] = boolean.class;
      l[11] = "java/lang/Boolean";
      k[12] = "T\u00057X]K[EzSWV^\u0018q\u0015_KS\u001eu^\u001c栵佢厠叒佮栣可叼伾佌";
      k[13] = "v+Ah\f@yk\fc\u0006]|6\u0007%\u0015Ny0\n%\nBe)AF\fKp\u0013\u000eg\u0016J";
      k[14] = "\u0007?5\u0012\bz\b\u007fx\u0019\u0002g\r\"s_\u0012a\r=h_伲叞厯伄栊伤桶佀桵厚";
      k[15] = ";\u00114\u0011F\u0013;\u0011#MJ\u001c!Z7PY\u00161Z0WR\t{\"%\\\u0018";
      k[16] = int.class;
      l[16] = "java/lang/Integer";
      k[17] = double.class;
      l[17] = "java/lang/Double";
      k[18] = ".\u0014tW_\\%\u001be\u0018>R.\u0010aB";
      k[19] = "Sx/#\u0004\u0000\r+n+=佭伴会叒伇你栩伴厄叒Z\f^U&*!@\\\u0011v";
      k[20] = "\u0018mC,Y-CuGH\f\u0011\u001a.\u001au_\u0011#uWq^)@'\u0016(\u0012";
      k[21] = "\u0001S<i_\u000fZK8\r\n3\u0003\u0010e0Z3:K(4X\u000bY\u0019im\u0014";
      k[22] = "<q8l\rQb\"yd4似叅桗佛栌佩厢叅厍叅\u0015\b\u001dg>c+L\u0019as";
      k[23] = "\nvFIrVQnB-'j\u000b<\u001f\u001dtj1=\u0011P1\u0001[|\u001f\u001d4";
      k[24] = "W;\\Gt3\th\u001dOM叀估叇伿佣伐叀桴叇伿>q\u007f\ft\u0007\u00005{\n9";
      k[25] = "\f\\\u0007_\u0017)R\u000fFW.栀叵厠叺句佳栀佫厠佤&\u0010bQ\u0004^@\u0012aF\u0011";
      k[26] = "\u001a-GMm\u001eD~\u0006ETG -\u001c\tnHI*\u0019\u000b?.\u001fwD\u000e2G\u0018rF_T";
      k[27] = "e?6\n9q(72Q\u0003n>&+^ed5]jUb2b#']fi";
      k[28] = "lCxx\b\u00142\u00109p1栽厕伡伛参史栽伋伡桟\u0001\u000f_1\u001b!g\r\\&\u000e";
      k[29] = "Tq$g\nW\\d4ovU:0|&F\u0006:\n}(\u000bCQ`<&FF";
      k[30] = "9\n\r6@\u00071\u001f\u001d><\u0005WKUv\u0005UWq\u0007#G\u0016j\u0003\u001c R\u0019";
      k[31] = "\u001b\u0014M[*sEG\fS\u0013桚叢栲厰栻叐桚佼佶伮\"#\u007f\u001eH\u0001\u001e*-\u001bY";
      k[32] = "+qO\t\u001e@u\"\u000e\u0001'厳佌伓厲桩佺桩叒厍厲p\u001b\fp>\u0014N_\bvs";
      k[33] = "_(y0.j\u0001{88\u0017桃桼栎会伔佊桃伸栎会I+&\u0004g\"wo\"\u0002*";
      k[34] = "`$5|i3qy#a\t ^rf/9v^B6n0rf!d/i>";
      k[35] = "O@9Kd@\u0015SaPX栰桬佡企叺桁佴伨叿桅9d\u0012\u001eM=IgW\u0010Y";
      k[36] = ":dbf4:d7#n\r栓栙伆原栆収叉佝伆企\u001f1va+9!urgf";
      k[37] = "~8-9\u0013\u001coe;$s\u000f@n~jLP@^.+J]x=|j\u0013\u0011";
      k[38] = "c\u001fB\bZT.\u0017FS`Z^@\\\t\u000e\u0015 \u001f\u001aO\u001b*";
      k[39] = "\u001c\u0019\u001b}\u0004MF\nCf8栽栿厦厽双叻栽句伸伣\u000f\u0002XC\u0017BfXK\u001b\f";
      k[40] = "{qgQ`N%\"&YY伣桘桗厚叫伄桧厂伓桀(h\u000f<09Z=F9s";
      k[41] = "p!\u0014yq\u007fa|\u0002d\u0011lNwG*!;NG\u0017k(>v$E*qr";
      k[42] = "\u000bsL1\u0014\u001eU \r9-佳佬厏桫桑佰叭佬厏伯H\u0013UV+\u0015.\u0011VA>";
      k[43] = "\u0015H{m!?BVg:\u0011作佸佨佗佟栈作佸叶栓\u0002!|TZ:<vbH\r";
      k[44] = "\fW.\u0002.=R\u0004o\n\u0017収栯桱栉伦佊栔佫伵栉{~k_\u0007p\u0006o6I\u001a";
      k[45] = "\u0001Q#/f^_\u0002b'_伳佦伳佀桏框厭司桷栄VoR\u0004\rojf\u0000\u0001\u001c";
      k[46] = "\u0000;\u000b;qkM3\u000f`K取栤伄伷佛伖栌你厚伷\u0006unZ>\r`wmM+";
      k[47] = "O#J\u0013fT\u0011p\u000b\u001b_厧厶栅伩伷厜桽桬佁厷jc\u0018\u0014l\u0011T'\u001c\u0012!";
      k[48] = "\u0011A\u0005\u00041\tJY\u0001`d5\u0013\u0002\\]65*Y\u0011Y6\rI\u000bP\u0000z";
      k[49] = "=5;\u0004Lwcfz\fu桞叄佗叆厾伨会栞叉栜}I;fz`C\r?`7";
      k[50] = "l-\u0018\u000fsg2~Y\u0007J桎伋住佻伫众厔桏栋栿vzkiqTJs9l`";
      k[51] = "6\u0010WKU\u0018hC\u0016Cl栱叏佲桰佯厯併叏召桰2WZeKRY\fBa";
      k[52] = "\u0019Gf;\u001a\u0003G\u0014'3#佮栺去桁桛栺佮佾伥桁B\u0012B^\u000680G\u000b[E";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private void m() {
      BlinkUtils.l(102729178478887L);
      this.何何何何树树友友树树 = false;
      this.友树树树何何树何何树 = null;
      this.树友何树何友何友友树 = null;
   }

   private void o() {
      this.树友何树何友何友友树 = new RemotePlayer(mc.level, mc.player.getGameProfile());
      this.树友何树何友何友友树.yHeadRot = mc.player.yHeadRot;
      this.树友何树何友何友友树.copyPosition(mc.player);
      this.树友何树何友何友友树.setUUID(mc.player.getUUID());
      this.树友何树何友何友友树.setId(mc.player.getId());
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void j(AttackEvent event) {
      KillAura.x();
      if (event.isPost() && !event.isCancelled()) {
         this.树友树友树友树何何何 = true;
         this.何树树友友何树友何树.D(11747522392279L);
         if (this.何何何何树树友友树树) {
            this.m();
            this.树何何何何何友树树树 = true;
            this.何树友树树树何何何树.D(11747522392279L);
         }
      }
   }

   private boolean u() {
      KillAura.x();
      if (this.友树树树何何树何何树 == null) {
         return false;
      } else {
         double yaw = Math.toRadians(mc.player.getYRot());
         Vec3 lookDirection = new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
         Vec3 real = this.友树树树何何树何何树.subtract(mc.player.position());
         real = new Vec3(real.x, 0.0, real.z);
         if (real.length() < 0.1) {
            return false;
         } else {
            real = real.normalize();
            double smooth = lookDirection.dot(real);
            return smooth > 0.3;
         }
      }
   }

   @EventTarget
   public void Y(Render3DEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L}) && this.树树树何何何树何树何.getValue() && this.何何何何树树友友树树 && this.树友何树何友何友友树 != null) {
         PoseStack var10000 = event.poseStack();
         RemotePlayer var10001 = this.树友何树何友何友友树;
         int var10002 = this.树友何友友何何树友树.getValue() ? 何树友友树树友何树何.t(94608897312632L, 10, 1).getRGB() : 树树何树何何树何何树.树树友友友友树友何何.树树何何友树何何友树.O();
         boolean var10003 = this.友何友何何何友树友何.getValue();
         boolean var10004 = this.何友树何树何友友友友.getValue();
         boolean var10005 = this.友友树何何友树树何友.getValue();
         float a = this.树友友友友何树何友何.getValue().floatValue();
         int ax = var10005;
         int axx = var10004;
         int axxx = var10003;
         int axxxx = var10002;
         RemotePlayer axxxxx = var10001;
         PoseStack axxxxxx = var10000;
         友友何何友友树何何友.Z(24488542601285L, axxxxxx, axxxxx, axxxx, axxx, axx, ax, a);
      }
   }

   @Override
   public void M() {
      this.s();
   }

   private void T() {
      KillAura.x();
      if (this.何何何何树树友友树树) {
         this.m();
      }

      this.树友树友树友树何何何 = false;
      this.树何何何何何友树树树 = false;
   }

   private static String HE_WEI_LIN() {
      return "何炜霖黑水";
   }

   @EventTarget
   public void Q(LivingUpdateEvent event) {
      c<"n">(6204799140573778266L, 118816490411538L);
      if (!this.Q(new Object[]{52406761729175L})) {
         this.X(c<"S">(this, 6203322147271975807L, 118816490411538L).getValue());
         if (c<"S">(this, 6204059133043726208L, 118816490411538L) && c<"S">(this, 6204063871243842878L, 118816490411538L) == null) {
            c<"K">(this, mc.player.position(), 6204063871243842878L, 118816490411538L);
            this.o();
         }

         if (c<"S">(this, 6204059133043726208L, 118816490411538L) && c<"S">(this, 6204063871243842878L, 118816490411538L) != null) {
            this.i();
            if (c<"S">(this, 6204365331880162335L, 118816490411538L).getValue() && this.u()
               || c<"S">(this, 6204632996167654528L, 118816490411538L).getValue() && c<"S">(mc.player, 6203094869510316936L, 118816490411538L) > 0) {
               this.m();
               return;
            }
         }

         if (c<"S">(this, 6203322147271975807L, 118816490411538L).K("KillAura")) {
            if (c<"S">(this, 6205666188412382465L, 118816490411538L) && !c<"S">(this, 6203043168764804626L, 118816490411538L)) {
               this.F();
               c<"K">(this, false, 6205666188412382465L, 118816490411538L);
               c<"S">(this, 6205768660200492118L, 118816490411538L).D(11747522392279L);
            }

            if (!c<"S">(this, 6204059133043726208L, 118816490411538L) && !c<"S">(this, 6203043168764804626L, 118816490411538L)) {
               this.F();
               c<"S">(this, 6205768660200492118L, 118816490411538L).D(11747522392279L);
            }

            if (c<"S">(this, 6204059133043726208L, 118816490411538L)
               && !c<"S">(this, 6203043168764804626L, 118816490411538L)
               && c<"S">(this, 6205768660200492118L, 118816490411538L)
                  .a(60984292003631L, c<"S">(this, 6203936426978508234L, 118816490411538L).getValue().floatValue())) {
               this.m();
               this.F();
               c<"S">(this, 6205768660200492118L, 118816490411538L).D(11747522392279L);
            }
         } else {
            LivingEntity target = this.Q();
            if (target != null) {
               double distance = RotationUtils.i(target, 55874601829708L);
               if (distance
                  <= (
                     c<"S">(this, 6203322147271975807L, 118816490411538L).K("Range")
                        ? c<"S">(c<"a">(6202780397410962212L, 118816490411538L), 6204229887420743486L, 118816490411538L).getValue().floatValue()
                        : c<"S">(this, 6202996770863817200L, 118816490411538L).getValue().floatValue()
                  )) {
                  if (c<"S">(this, 6205666188412382465L, 118816490411538L) && !c<"S">(this, 6203043168764804626L, 118816490411538L)) {
                     ClientUtils.P(125527250587045L, "FakeLag:" + c<"S">(this, 6205666188412382465L, 118816490411538L));
                     this.F();
                     c<"K">(this, false, 6205666188412382465L, 118816490411538L);
                     c<"S">(this, 6205768660200492118L, 118816490411538L).D(11747522392279L);
                  }

                  if (!c<"S">(this, 6204059133043726208L, 118816490411538L) && !c<"S">(this, 6203043168764804626L, 118816490411538L)) {
                     this.F();
                     c<"S">(this, 6205768660200492118L, 118816490411538L).D(11747522392279L);
                  }

                  if (c<"S">(this, 6204059133043726208L, 118816490411538L)
                     && !c<"S">(this, 6203043168764804626L, 118816490411538L)
                     && c<"S">(this, 6205768660200492118L, 118816490411538L)
                        .a(60984292003631L, c<"S">(this, 6203936426978508234L, 118816490411538L).getValue().floatValue())) {
                     this.m();
                     this.F();
                     c<"S">(this, 6205768660200492118L, 118816490411538L).D(11747522392279L);
                  }
               }
            }

            this.T();
            if (c<"S">(this, 6203043168764804626L, 118816490411538L) && c<"S">(this, 6203826227925066271L, 118816490411538L).A(50L, 118344821288830L)) {
               c<"K">(this, false, 6203043168764804626L, 118816490411538L);
            }
         }
      }
   }

   private LivingEntity Q() {
      KillAura.x();
      LivingEntity target = null;
      if (this.何何何友何何树何友友.K("KillAura") && KillAura.instance.isEnabled()) {
         target = KillAura.instance.Y();
      }

      if (target == null && this.何何何友何何树何友友.K("Range")) {
         Iterator var9 = Cherish.instance.m().V(this.树友何何友友树何何树.getValue().floatValue(), 16843851536371L).iterator();
         if (var9.hasNext()) {
            LivingEntity entity = (LivingEntity)var9.next();
            if (entity != null && !entity.isDeadOrDying() && entity.isAlive() && entity.getHealth() > 0.0F) {
               double distance = RotationUtils.i(entity, 55874601829708L);
               if (distance <= this.树友何何友友树何何树.getValue().floatValue()) {
                  target = entity;
               }
            }
         }
      }

      return target;
   }
}
