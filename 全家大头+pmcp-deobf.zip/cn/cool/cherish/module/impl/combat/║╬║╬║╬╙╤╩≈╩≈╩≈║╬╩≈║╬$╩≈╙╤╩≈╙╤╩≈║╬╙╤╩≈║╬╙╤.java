package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// $VF: synthetic class
class 何何何友树树树何树何$树友树友树何友树何友 implements 何树友 {
   private static final Object[] a = new Object[11];
   private static final String[] b = new String[11];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-7737189772940350210L, -990207771326283811L, MethodHandles.lookup().lookupClass()).a(182146932803903L);
      // $VF: monitorexit
      long var0 = var10000 ^ 80842901770782L;
      a();

      try {
         a<"û">(-4128234145688969399L, var0)[a<"û">(-4127966154800303478L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"û">(-4128234145688969399L, var0)[a<"û">(-4128091040937647138L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"û">(-4128234145688969399L, var0)[a<"û">(-4128254956125649354L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"û">(-4128234145688969399L, var0)[a<"û">(-4128124529859606310L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"û">(-4128234145688969399L, var0)[a<"û">(-4128023438247310275L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"û">(-4128234145688969399L, var0)[a<"û">(-4128344415771650419L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 246 && var8 != 206 && var8 != 251 && var8 != 'u') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 232) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'J') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 246) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 206) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/何何何友树树树何树何$树友树友树何友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 42;
               case 2 -> 26;
               case 3 -> 12;
               case 4 -> 31;
               case 5 -> 33;
               case 6 -> 46;
               case 7 -> 21;
               case 8 -> 7;
               case 9 -> 18;
               case 10 -> 27;
               case 11 -> 25;
               case 12 -> 34;
               case 13 -> 58;
               case 14 -> 35;
               case 15 -> 10;
               case 16 -> 0;
               case 17 -> 32;
               case 18 -> 9;
               case 19 -> 59;
               case 20 -> 1;
               case 21 -> 14;
               case 22 -> 62;
               case 23 -> 2;
               case 24 -> 41;
               case 25 -> 5;
               case 26 -> 47;
               case 27 -> 20;
               case 28 -> 13;
               case 29 -> 48;
               case 30 -> 16;
               case 31 -> 63;
               case 32 -> 53;
               case 33 -> 19;
               case 34 -> 44;
               case 35 -> 49;
               case 36 -> 60;
               case 37 -> 56;
               case 38 -> 50;
               case 39 -> 40;
               case 40 -> 15;
               case 41 -> 57;
               case 42 -> 55;
               case 43 -> 3;
               case 44 -> 28;
               case 45 -> 54;
               case 46 -> 39;
               case 47 -> 24;
               case 48 -> 45;
               case 49 -> 8;
               case 50 -> 4;
               case 51 -> 30;
               case 52 -> 51;
               case 53 -> 29;
               case 54 -> 43;
               case 55 -> 36;
               case 56 -> 6;
               case 57 -> 22;
               case 58 -> 38;
               case 59 -> 23;
               case 60 -> 17;
               case 61 -> 11;
               case 62 -> 61;
               default -> 52;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "\u0010c,Lf:\u001f#aGl'\u001a~j\u0001d:\u0017xnJ'<\u001e}n\u0001j:\u001eoc['伀伦佘叉栾栘桄伦栜佗\u000b栘桄桢栜叉栾作伀伦佘";
      a[1] = "\u0004}N`c}\u000b=\u0003ki`\u000e`\b-a}\u0003f\ff\"{\nc\f-o}\nq\u0001w\"佇伲但厫栒栝栃伲栂伵'栝叙桶变桱佖叇栃伲变";
      a[2] = "1r";
      a[3] = "F-6\u000etgM\"'A\u0015iF)#\u001b";
      a[4] = "9ud\u0010aGzc?(叀栵栙佘伀栱栚佱佝栜]\u0011s\u00158g6ReN";
      a[5] = "J@\u0012\u001a,$\tVI\"伓伒伮右栲使桗桖桪佭+\u001b>vKR@X(-";
      a[6] = "r\u0018rmQ^|\t(\u0010可厥収厴伓位栵伻栔桮N*\u0015\u000f|F~u]\u0000}";
      a[7] = "#\u001fAF~\u0005`\t\u001a~叟厭栃桶伥伣栅桷佇厬xGlW\"\r\u0013\u0004z\f";
      a[8] = "ULZ\u0017)\u0000\u0016Z\u0001/伖桲厯佡桺栶伖桲桵叿c\u0016;RT^\bU-\t";
      a[9] = "^7O\u0015\u0006\u0003\u001d!\u0014-伹桱桾厄桯叮厧桱桾厄v\u0014\u0014Q_%\u001dW\u0002\n";
      a[10] = "VX\u001c>Xk\u0015NG\u0006佧佝桶栱格佛栣栙厬叫%?J9WJN|\\b";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String HE_JIAN_GUO() {
      return "何大伟：我要教育何炜霖";
   }
}
