package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.module.impl.player.树友何何友何树何树友;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.client.树友何何何树何树友友;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.item.友何树树何树何何何友;
import cn.cool.cherish.utils.packet.BlinkUtils;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.何树何树友树树友友何;
import cn.cool.cherish.utils.player.友何何何何友友何友友;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.player.UpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.game.ClientboundSetEquipmentPacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class KillAura extends Module implements 何树友 {
   public static KillAura instance;
   private final ModeValue 何树何树何友何友何树 = new ModeValue("Target Mode", "目标模式", new String[]{"Single", "Switch"}, "Switch");
   private final ModeValue 树何友友树树树友友友 = new ModeValue("Attack Mode", "攻击模式", new String[]{"Pre"}, "Pre");
   private final NumberValue 树友何友友树何何友友 = new NumberValue("Switch Delay", "多个目标切换延迟", 0, 0, 1000, 10).A(() -> this.何树何树何友何友何树.K(""));
   private final NumberValue 树树树树何友树何树何 = new NumberValue("Fov", "角度", 180.0, 0.0, 180.0, 10.0);
   private final NumberValue 何何何友树友何树树友 = new NumberValue("Max CPS", "最大每秒点击次数", 10, 1, 20, 1);
   private final NumberValue 树友何友友树何友何何 = new NumberValue("Min CPS", "最小每秒点击次数", 10, 1, 20, 1);
   public final NumberValue 友树何何何何树何友何 = new NumberValue("Attack Range", "攻击范围", 3.0, 1.0, 6.0, 0.1);
   public final NumberValue 树友树何树何何友友树 = new NumberValue("Rotation Range", "转头范围", 4.0, 1.0, 6.0, 0.1);
   private final NumberValue 何树树树何树何友何何 = new NumberValue("Scan Range", "搜索范围", 3.0, 1.0, 6.0, 0.1);
   private final BooleanValue 何何何何友树何友树何 = new BooleanValue("Through Walls", "穿墙", false);
   private final NumberValue 树友友友树友何友何何 = new NumberValue("ThroughWalls Range", "穿墙距离", 2.5, 1, 6.0, 0.1).A(this.何何何何友树何友树何::getValue);
   private final BooleanValue 何友何树友何友树友友 = new BooleanValue("Ray Cast", "碰撞箱瞄准", true);
   private final NumberValue 树何何友友树何树树树 = new NumberValue("RayCast Expand", "碰撞箱扩展", 0, 0, 0.1, 0.01).A(this.何友何树友何友树友友::getValue);
   private final ModeValue 何何树何友何友友何树 = new ModeValue(
      "Priority Mode", "目标优先级模式", new String[]{"Distance", "Health", "Fov", "Direction", "EasyToKill", "ThreatLevel", "LivingTime", "Armor"}, "Distance"
   );
   private final ModeValue 何树何树树树友树树树 = new ModeValue("AutoBlock Mode", "自动防砍模式", new String[]{"None", "Fake", "UseItem", "Watchdog"}, "None");
   private final ModeValue 友树树友何树何何树树 = new ModeValue("Rotation Mode", "转头模式", new String[]{"Normal", "Nearest", "Smart"}, "Normal");
   private final BooleanValue 何何树友何树友何树友 = new BooleanValue("Smooth Rotation", "平滑转头", false);
   private final NumberValue 友友树树树友何树友树 = new NumberValue("Smooth Rotation Speed", "平滑转头速度", 180.0, 0.0, 180.0, 10.0).A(this.何何树友何树友何树友::getValue);
   private final BooleanValue 何友树何何何何树何树;
   private final BooleanValue 何友友树树树友树树友;
   private final BooleanValue 友友何友树何何何树友;
   private final BooleanValue 树友树树树友何何友何;
   private final BooleanValue 树何树树树何树友友树;
   private final BooleanValue 树何何何友树何树何树;
   private final BooleanValue 树友树友友友何何树友;
   private final ModeValue 友何友树何何何树友友;
   private final BooleanValue 树何友树何何何友树何;
   private final 树友何何树树何友友何 友何友友树何友友树何;
   private final NumberValue 树友何友何友树友友何;
   private final NumberValue 何树何树友何何友友树;
   private final List<LivingEntity> 友何友友树树何何友友;
   private final 何友友何树何树何树友 友何友友友何友何何树;
   private final 何友友何树何树何树友 友何友友友何何何友树;
   private LivingEntity 树何树树树何树何何树;
   private Rotation 何何何树何何友友何树;
   private Rotation 何树树友友友友何何友;
   private float 树何何何友友友何友何;
   private boolean 友何友友树友何何何何;
   private boolean 树树树友树何友何何树;
   private static Module[] 树树树树何何友树友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[107];
   private static final String[] l = new String[107];
   private static int _职业技术教育中心学校 _;

   public boolean isBlocking() {
      return this.友何友友树友何何何何;
   }

   public KillAura() {
      super("KillAura", "杀戮光环", 树何友友何树友友何何.何何何何何树何何友树, 82);
      x();
      this.何友树何何何何树何树 = new BooleanValue("Silent Rotation", "静默转头", true);
      this.何友友树树树友树树友 = new BooleanValue("WaitForNextUpdate", "待下次转头更新", false).A(this.何友树何何何何树何树::getValue);
      this.友友何友树何何何树友 = new BooleanValue("Using Check", "当防砍时不攻击", true);
      this.树友树树树友何何友何 = new BooleanValue("Screen Check", "当屏幕时不攻击", true);
      this.树何树树树何树友友树 = new BooleanValue("Scaffold Check", "当搭路时不攻击", true);
      this.树何何何友树何树何树 = new BooleanValue("On Click", "当左键点击时触发", false);
      this.树友树友友友何何树友 = new BooleanValue("Movement Fix", "移动修复", true);
      this.友何友树何何何树友友 = new ModeValue("ESP Mode", "目标指示器模式", new String[]{"None", "Jello", "Nursultan", "Exhibition"}, "None");
      this.树何友树何何何友树何 = new BooleanValue("Circle", "圆圈", false);
      this.友何友友树何友友树何 = new 树友何何树树何友友何("Circle Color", "圆圈颜色", Color.WHITE).A(this.树何友树何何何友树何::getValue);
      this.树友何友何友树友友何 = new NumberValue("Circle Accuracy", "圆圈精度", 15, 1, 60, 1).A(this.树何友树何何何友树何::getValue);
      this.何树何树友何何友友树 = new NumberValue("Circle Line Width", "圆圈线条粗细", 1.0, 0.5, 10.0, 0.1).A(this.树何友树何何何友树何::getValue);
      this.友何友友树树何何友友 = new ArrayList<>();
      this.友何友友友何友何何树 = new 何友友何树何树何树友(51913986529303L);
      this.友何友友友何何何友树 = new 何友友何树何树何树友(51913986529303L);
      this.何树树友友友友何何友 = null;
      this.树何何何友友友何友何 = 0.0F;
      instance = this;
      Module.V(new Module[3]);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7103204780914360222L, -5416960555599924505L, MethodHandles.lookup().lookupClass()).a(180243137295303L);
      // $VF: monitorexit
      a = var10000;
      a();
      f(null);
      Cipher var5;
      Cipher var15 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(133598221029319L << var6 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[106];
      int var10 = 0;
      String var9 = "ô&z¼äü[\u00143\u0000\u008fªàãJÊàd\u000bq\u0011g»(\u0010\u0099?\u00108M\u0091ÄåO?÷\u00adxWFà\u0010vþ[ÃýTp\u008a_ÂfÙm×ÁÎ\u0010Ý\u0093;ù\u009d<¹z\u0099\u00127³!\u009a¼C\u0010÷¼¦4FË¡\u001f(áé´ó\u009f¼\u001f º¼n»YÌ¼ü&\u0083¶Õ\u0097~×\u009eç;°fÓ\u0003\u0016\u009b\u0086\u0007\u001e\u0085\u000e´sV(L'(K\u009bíÂ1=)Þ %@ Þ¤Z±ë\u008a^e\u0095Ü¾¨ \t\u009a§Íc\u0013\u0001û\n\nÏÎ\u0018\u0019+\u0094ìª¶f)uÍÑ´æ\u008fwË\u0018\u008cfå\u0095MNÞ\u0010A\u0014\u0082ldj^³\u0096±\u0093ôÍ\u009ff\u0001\u0010º§ú\u0086y2»â\u0001kú\u0081\u0092D\u008cÙ\u0010c0ËE|þTe45ô('~Ôk \u009a`¤íô]Í¶(Ñ:Ë§XxQ\u0080Ë\u009cÈíx\u0093õ<\u000e{Í\u0081´Þ° k\u0013T\u0000\u007f\u009744\u0095\u0089\u0094\u0083\u008c6\u0081¬\r¦aÚºÙðÈÝ= \u0089Q\u0094\u000e\u0097\u0018ôÿ?\u0087Ãû¸\u00981w©UJíg£6ÏÎ\u001bÂJB#\u0018\u001ep\u0095Îa\u0010\u0082ýÞ\u0013*\u0095»Ä\u000b 2+\u009fíHÔús(ÿZ¸ëâ:¡\u0098VÙnÅ\nå1!9r\u0005«\u0095äçOlÇ\u0094\u008dÌ¬>UÆÛ!?[J\u00adï\u0010Í¬\u008fRnd\u0016xsÈùëòÜ\u0087è ô7\u008f\u009d¡«+[l\u0081\t\u0082\u008e§j7\u001e\u0080B\u0015ÚÌ}~ôw°àè;i¤0é£\u0084`\u001c\u009c\u0082a\u001f®ÙÎ\u0004\u0094óä\u001d\u0001\u0018Mº°72¼ÿ\u0011¹f®±ë \u0012µ\u009eai#ÀäÂa\u0083ö/\u0093\u0081 A;ì\u0005\u008d\u001f<u\\¾\fIá\u001câWJ\u0011\u001eI³¼¤55æ¬ùD£A²(mËÌB\f?ï{Ã\u0001\u009dÏ\u008d9l¸è\"\u0019=\u0003±ÑE¢¡ª3|\u009aQ\bÀNÑYcA\u001ak ó\u0098÷}\"¹Îùòªô0)XÛØÖÊ)ô×ý\u0091àZ6 »Üü\u0095\t\u00103ÖÌ\f«\u0091ª}\u0015\u0099Ù{6ù\u0091d0\bm*qÆ\u0094Gnô8!pþÅ\u0018Ô-¸\u0004¿Ë8²<f\u0091Ê'~-\u0082\u0094l×\u0004£ÂÇ_\u0090èN-\u00990\u008d\u0091)\u0010¸¾\u008d*%\u0011!Î pþ»RÎfe \u001eÖf¸Ù)æ\fWÿ×øµ\"\\\u000f³]ep\\ó-\b`g&\u008e\u001cwe\r ÅQ\u009c\u0080bY\u0013\u001cÐ7ªäéö/ sÁã³\u0001!\u0000\u0081¿¤\u0099\u00ad+Þ×s hÛ\u0012§n°}ûÅ0P[ü\u0014R\u008b2\u001f\u0019\u001b!ÐO\u0087!ë,·*Ç¯e 2Ý¹Ü/\u0010\u009d \u0016o&g¾CÞ©\u0005!U\u0094Nr\u0014IW\u0014\u0080\u009cË.áT\u0018x*t\u0098Ü\";Ò%\u0083\u008cO\"XAcBü\u001c³(\u0093%Y\u0018\u001d¸â\u0091#JË¤,g\u0099Ã\u00813\u0013×<\u0004è\tPÆ\u0086æ(,¡ÁÔeÎô\u0099\u000f'FSQMB\\Bw\u008e\u0015\u000eçwç\u000e\u0002Ñ;l\u0005\u0083\u0012'\u007f§F+\u0096\r·\u0010Ö-ßé¨¾¢\u000e\u0089#·\u0088ú¡`\u009a\u0018«\u0087¹\u0010¤vBÍÖ¢Ñ¤\u009cË°\u000féê×\u0098ðÆI\r Õ\nc\u0014b\u009cã¶\"\u000fÁAÅÕ\n\u0012ö\u0091\u0018ïyIÇGr¡í\u0087¸\u0019\u008aÓ 4\u0010§3q½½8ñå'r¾[åGDøF\u008fBÆZ\u0083mÅúÉ,\u009aR\u0011\u0018íüVzÆËRy\u0092`ºÙ\u0090ö\"|\u0016Üù-ºÙ\u0006ð\u0018=·\u0099Ó¡å\u0015¬Íß\"\u009cê\u0095ÕrâÛ¬PÇX\"î\u0010_Â\u009e\u009e\u001d\u0016}îM\r\u008aJç¯uÜ\u0010åìÆà]=)Y'Ë\u0005ä\u0005»=I(ü@=>\u0005<J\fn¿S©x\b\u0017óí¢»ê\u0091}î(¯¿\t\u0019u\u000b \u001eb\u0090©í©=\u0018ñ ú6vS\u001d¶ÏÑ\u0093\u0082\u0086\u0006ã¬´þûÙÕ/?)£ü@£#?B\u0016÷² åD\u0085\tW ÙÍ\u008b=ò\u008aÇt\u0003:²~Ú½\u000f*Ó¨:Â\u0010~ãü ³ xRòvÕø7ôÅ\u00168$ ¶_jÿ>©\u0005¡§\u0095\u0002T\u001bõ\u0082Ú\u008dßª\u0010Çâ?Qmnñ\u009c\u0001)Fà^ð9\u0099\u0010\u0013\u0092\u0081VÈÐïÝâ\týW\u000bÞ\u00adâ\u0010ØÔ;WÉ°ia\u0091ÃJo~M\u0093\"\u0010$lE´êÙº\u001cwúA@·æÆ\u008b\u0010Ë3\rÇ0:§PöÀöÐ\u008f4+\u007f\u0010\u0016»\u0015ëØÄõ{mjJðÃÁðâ(Æ\u0089-&ñ\u0011~V¨ÁEz\u0081ûÀ2×8ªýq\u0095\u008cºó0\bTyêð\u009b«\n.ÐX\u0007\u008d\u0088\u0018õIªCH§«Ô;ì¹' ê¯\u008cÙ\u0090«¢#³Ñ_ \u0084ÙÓþÃ§d\u0004\u00918\\ùÀèD{{\u0006àá\u009dù\b.9U1Î9`\u0013\u0011 Qy\u0098ûô\u0080\u0086=\u0087sÔ;[\u0083fi3Ê¤sáïè\f¯\u0098a\"Ò½ñD Øáèh¡a4\u009eLìÕ21Ê)i\u0014\u007f±c\u008b¯\u001d\u0014¤½ÑiÓ÷\u0092ë\u0010\u009dùG²\u001a\u001a\u0003ÄËAUu\u001d\u0019¸ó(\u0086tùóu\u0098à\u0094{uZ(âÿ;?Æ\u008a\u0001þXow\u0014ÖN\u0095\u0007\u0098Ìó-\u001d«»\u001cßÒ\u000b,(ôùd\u0084û=_;}Â>¾âX¨\u000evEè\u00ad\u0090\u0092ÂN«\u0005¾\u009bméRMÍ^VOe\u0087°ª\u0018®ÿ^\u0095ÌGKçB5;(BZ=\u0002â]èÑÉI2t \u009bµ2ä·\u0084h¶\u008f2Þúç \u0017\n!:ï\u0088ú\u0089\u008fd<\u008d#ËHÀ<x8\u0001qäN\u008e¿fPå\u0019Ø×?\u0013\u0018[â*ì,>ú\u001a\u0093EÞË\u008419DãîÎb>O\u0007\u008eëÐÈ+Ì²þåêÙG\u0001í]\u0013Å7\u0010\u009aZÀù\u0085\u008dÛb'Më¸j\u0094ù×\u0010|\núØVI\u008d«ÃºÿØÓàï\" ®ÄÅr\u009fK¨&éÏv\u008e)R¿ò{\u008dt\u0090PE2\u000e\u0090(ÊÅe0\u0094î\u0018\u0011·Íj\u0098¢?\u001aßqÝ¤-pc©Ô¬F#W÷ûé 5÷\u0017+\tÞ}Ó\u000fk;±à¾Y¬@J¤N\u0007\u009a×¶\u001d\\-\tgU\u0098\\\u0010¤\u0095ÒþÄ\u0006úT)<Á17Wq|\u0010]\u00adß\u001f>Â@\u0098ðú,\u0005\u0014a=ß \u0004\u0084G\u0017ær\u009dK\f\u0014´1·\u0012r\u008d÷Poc\u0001¥E hAbÊË¿\f?0\u001ctÂ@\u0016qÑ\u0010_\u001d\u0004C3½\u0090fcÂkéV!§ó \u0012ãP§1\u001a\\\u0006t3\u001bÇ\u0011)Ò\u008d\u0091©Xº*@¨\u0018ê_ñ=*\u0094Á\u009d\u0084sLK\u0000M<ò\u0080~ èio¥\u001f (®ìK,\u0089\u0007=ìd\u001dÒHÛT×ó®pe\u009eö\u0013_Cæò¾çrÅ«\u0018!óÈ¼D\u001eøT¤í,\u001c¯\u009c¯Úm÷\u0003\bx¤ýß0oÓø2q«Íeh\u0097\u0019Ø\u0088ÆZg¼Þ\u000fÄ\u001757¹#ÀF\u0088\u0085MViBÿ\u0013GA\u0013VA8L¢-\u0093h¿ã \u0092\u0095\rbh<\u008d \u001bÖòÏù\u009a\u008dè®]C\u0097\u009eIñ\u0088ã_\u000e¦ Ò^\u0093\u0010«_ÝR\u0010íÏ1¦Ë\u0016~¦Êsx(L\nPÑOþh'¯·¸}Z\u0015\u0086Óh*N¶ÝêêK§õ\u001a\u008aí¼_=\u0095\u0082Ö§êèä©\u0010RÑfuæ\u0082m\r\u0090ö(6\u0096Ð/.\u0010\u0092Ä\u0090\u001b\u0006L\u0091br\u0016Q\u0006Ý§\u007fä\u0010\u009c\u0083K(\u0001Eð\u0091*\u0005\u0089ÛóiÔã ´xÎ\tqK\u009f{Ì§\u0001<íjÕ÷\u001a²á\u009fÒN\u0006Z¢1 tçw\u0098¿\u0010>kó*u@'@\u0006´\u009eØ]g[I\u0018ö2\bH½\u009f«\u0003\u009b^\u009eµM¾ð1®Ãkã\u0083\u0086R& \u0013G\u008c°\u0098Ê(íj\u0016ý\u001e±¸ö\u00875¡\u001ae\u0004h\u001e-\u0013KìA\t4±\u000e Ã\u0086u\u0014Ï\u001a>ò»\u0096Ñ (³æ\u000b\u0003± \u001cUU\u001eµ¬?6\u0096=\u0003Ðx\u0018*\u0081§_ÔYÇ\fá\u007fÓ\u001f.þ\u008a¸\b \u009fõà\u001eñö ÿ=$U9dÃ%\u0081#\b¶x¹æÖ÷HDdíz«\u00adëß,)R\b×¨ B4\u008bC\u00adÖ\u0091\u00884åÏ\u009b\u0012qDS\u0006uq\u001a]>>\u009fxQK}\u009aóßs\u0018^7#¯E¯Ë\u0085\u001eT6\u008b3î#\u000b\ne¤5K&cz81\u0006²¢¢\u00adÔ\u0080\u0091°\u001f¿'\u0090Âîkø'\u0080ðdªî>=õ*ulÒ±\u0016wÌ¤\u008dë}ÊBEp·\u0003Â#Ê`dV\u0099D\u008f]*\u0010Iÿ\u000f³Á\u008e¤Þ\u0006'\u007f\u000e\u0081\u0095\u00141 \u0011\u0005\u0097\u0003Ëõáé}fâ-Ì\u0096ëêb0»Mõ4\u0017³Q1\u0088s\u0004m#\u008d(\u00150\u0099+S\u0012Ýº8\u000b\u0012O\u0091ÜW\u0012¥I©uÓ(¬\u000f>8·\u0092\u009dº\\¼{¢.«·*\u0087q\u0018¾8ãã\u009fjI\"\u0097T\u0011ð\u0083\u0007?\u0097kzà(´\u007fàq\u0010J\u0003®,Pç\u009aLw!ÃT\u0084·gv\u0018ç#\u0096'Ô\u0097_tdÂÑ\rÚ²MíDY@¤°ýAà\u0010\u009dB\u0081¾Jêâ\u008dKµ<\u009fÎï\u00853 ÂÜØãø}kõ¢\u0012\u008cN@\f\u009d¢Dü\u00023b\u009e`¶3(èª ªô§\u0018â\u0005Õ¯p>\u00046\u00ad´,,ÀÚuØ&\u0080±TÙ¤\u001e\u0001\u0010\nV'ýÅu<\u000f©y¶\u0087\u0093}\u009bX\u0018¹´¢#\u0088¾\u0004\u001b\u0096.\u001f\u0098`nubÞ\u0080°ÚVhkñ \u0080Ò\r½\fâÌ\u00ad\u008d\u008b\u009e®ª\u009b\u0085TDÀ\u0095M\u00ad:\u0010á\u0083¸\u0081\r/â\u009f3 XjyÌ4`ú\u00144iË·\u0094¢\u0019\tE2©<y3¤û\u001fêµ\fçTî²\u0018ìª\u008a1e\u0097ýã\u000bõÅó\"8Ãià\u0089Ò\u0089Z#AÔ";
      short var11 = 2919;
      char var8 = 24;
      int var14 = -1;

      label37:
      while (true) {
         String var16 = var9.substring(++var14, var14 + var8);
         byte var10001 = -1;

         while (true) {
            String var24 = c(var5.doFinal(var16.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var12[var10++] = var24;
                  if ((var14 += var8) >= var11) {
                     c = var12;
                     h = new String[106];
                     Cipher var0;
                     Cipher var18 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(133598221029319L << var1 * 8 >>> 56);
                     }

                     var18.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{20, 96, -82, -87, 65, 96, -81, 16});
                     long var28 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var28;
                     return;
                  }

                  var8 = var9.charAt(var14);
                  break;
               default:
                  var12[var10++] = var24;
                  if ((var14 += var8) < var11) {
                     var8 = var9.charAt(var14);
                     continue label37;
                  }

                  var9 = "\u00ad8æ¬ø\u0002\u0091[ñ\u001b\u0093ô!«\u001d\u0003®¡ IÍrÊ\u0087\u0018\b·oós·¾V\u0003\u0095WFÌöiq\u00906\u0001\u008b\u0082k\u0095\u001d";
                  var11 = 49;
                  var8 = 24;
                  var14 = -1;
            }

            var16 = var9.substring(++var14, var14 + var8);
            var10001 = 0;
         }
      }
   }

   public void I() {
      x();
      String var6 = this.何何树何友何友友何树.getValue();
      byte var7 = -1;
      switch (var6.hashCode()) {
         case 353103893:
            if (!var6.equals("Distance")) {
               break;
            }

            var7 = 0;
         case -2137395588:
            if (!var6.equals("Health")) {
               break;
            }

            var7 = 1;
         case 70829:
            if (!var6.equals("Fov")) {
               break;
            }

            var7 = 2;
         case 1041377119:
            if (!var6.equals("Direction")) {
               break;
            }

            var7 = 3;
         case -1415550666:
            if (!var6.equals("LivingTime")) {
               break;
            }

            var7 = 4;
         case 63533343:
            if (!var6.equals("Armor")) {
               break;
            }

            var7 = 5;
         case 1179233083:
            if (!var6.equals("EasyToKill")) {
               break;
            }

            var7 = 6;
         case -255982230:
            if (var6.equals("ThreatLevel")) {
               var7 = 7;
            }
      }

      switch (var7) {
         case 0:
            this.友何友友树树何何友友.sort(Comparator.comparingInt(a -> (int)RotationUtils.i(a, 55874601829708L)));
         case 1:
            this.友何友友树树何何友友.sort(Comparator.comparingInt(a -> (int)a.getHealth()));
         case 2:
            this.友何友友树树何何友友
               .sort(
                  Comparator.comparingDouble(
                     o -> RotationUtils.K(81915915227048L, RotationUtils.rotation.getYaw(), RotationUtils.n(120230420425013L, o).getYaw())
                  )
               );
         case 3:
            this.友何友友树树何何友友.sort(Comparator.comparingDouble(RotationUtils::q));
         case 4:
            this.友何友友树树何何友友.sort((a, b) -> Integer.compare(b.tickCount, a.tickCount));
         case 5:
            this.友何友友树树何何友友.sort((a, b) -> Integer.compare(友树友友树何树友树友.g(50820545736658L, b), 友树友友树何树友树友.g(50820545736658L, a)));
         case 6:
            this.友何友友树树何何友友.sort((a, b) -> {
               double scoreA = a.getHealth() / (友树友友树何树友树友.g(50820545736658L, a) + 1);
               double scoreB = b.getHealth() / (友树友友树何树友树友.g(50820545736658L, b) + 1);
               return Double.compare(scoreA, scoreB);
            });
         case 7:
            double playerAttack = 友何树树何树何何何友.N(20090517461351L, mc.player.getMainHandItem());
            this.友何友友树树何何友友.sort((a, b) -> {
               double threatScoreA = (a.getHealth() + 友树友友树何树友树友.g(50820545736658L, a)) / playerAttack;
               double threatScoreB = (b.getHealth() + 友树友友树何树友树友.g(50820545736658L, b)) / playerAttack;
               return Double.compare(threatScoreA, threatScoreB);
            });
      }
   }

   public void J(LivingEntity target) {
      x();
      if (!mc.options.keyUse.isDown() || !this.友友何友树何何何树友.Q()) {
         if (this.友何友友友何何何友树.A((long)(700.0F / this.U()), 118344821288830L)) {
            AttackEvent attackEvent = new AttackEvent(false, target);
            Cherish.instance.getEventManager().call(attackEvent);
            if (attackEvent.isCancelled()) {
               return;
            }

            if (this.树何友友树树树友友友.K("Pre")) {
               mc.gameMode.attack(mc.player, target);
               mc.player.swing(InteractionHand.MAIN_HAND);
            }

            attackEvent.setPost(true);
            Cherish.instance.getEventManager().call(attackEvent);
            this.友何友友友何何何友树.D(11747522392279L);
         }
      }
   }

   public void S() {
      this.何何何树何何友友何树 = null;
      this.何树树友友友友何何友 = null;
      this.友何友友友何友何何树.D(11747522392279L);
      this.树何树树树何树何何树 = null;
      this.友何友友树树何何友友.clear();
   }

   public boolean V(LivingEntity entity) {
      x();
      boolean canSeeEntity = RotationUtils.b(133557741013531L, entity);
      float effectiveRange = !canSeeEntity && this.何何何何友树何友树何.getValue() ? this.树友友友树友何友何何.getValue().floatValue() : this.树友树何树何何友友树.getValue().floatValue();
      if (RotationUtils.i(entity, 55874601829708L) > effectiveRange) {
         return false;
      } else if (!this.何何何何友树何友树何.getValue() && !canSeeEntity) {
         return false;
      } else {
         return RotationUtils.A(51024501214516L, this.树树树树何友树何树何.getValue().floatValue(), entity) && 何树何树友树树友友何.p(31768596091278L, entity, true)
            ? !entity.isDeadOrDying() && !(entity.getHealth() <= 0.0F)
            : false;
      }
   }

   @EventTarget
   public void V(Render3DEvent event) {
      x();
      if (!this.Q(new Object[]{52406761729175L})
         && (mc.screen == null || !this.树友树树树友何何友何.getValue())
         && (!树友何何友何树何树友.树友友树友友友友树何.isEnabled() || !this.树何树树树何树友友树.getValue())
         && (mc.options.keyAttack.isDown() || !this.树何何何友树何树何树.getValue())) {
         PoseStack poseStack = event.poseStack();
         if (this.树何友树何何何友树何.getValue()) {
            友友何何友友树何何友.d(
               poseStack,
               mc.player,
               108860770950086L,
               this.友树何何何何树何友何.getValue().floatValue(),
               this.树友何友何友树友友何.getValue().intValue(),
               event.partialTick(),
               this.友何友友树何友友树何.getValue(),
               this.何树何树友何何友友树.getValue().floatValue()
            );
         }

         if (this.树何树树树何树何何树 != null && !this.树何树树树何树何何树.isDeadOrDying() && !(this.树何树树树何树何何树.getHealth() <= 0.0F)) {
            Vec3 cameraPos = mc.gameRenderer.getMainCamera().getPosition();
            double renderPosX = cameraPos.x;
            double renderPosY = cameraPos.y;
            double renderPosZ = cameraPos.z;
            double baseX = this.树何树树树何树何何树.xOld + (this.树何树树树何树何何树.getX() - this.树何树树树何树何何树.xOld) * event.partialTick() - renderPosX;
            double baseY = this.树何树树树何树何何树.yOld + (this.树何树树树何树何何树.getY() - this.树何树树树何树何何树.yOld) * event.partialTick() - renderPosY;
            double baseZ = this.树何树树树何树何何树.zOld + (this.树何树树树何树何何树.getZ() - this.树何树树树何树何何树.zOld) * event.partialTick() - renderPosZ;
            double playerMotionOffsetX = mc.player.getDeltaMovement().x + 0.01;
            double playerMotionOffsetY = mc.player.getDeltaMovement().y - 0.005;
            double playerMotionOffsetZ = mc.player.getDeltaMovement().z + 0.01;
            double translateX = baseX + playerMotionOffsetX;
            double translateY = baseY + playerMotionOffsetY;
            double translateZ = baseZ + playerMotionOffsetZ;
            int exhibitionColor = this.树何树树树何树何何树.hurtTime > 3
               ? new Color(235, 40, 40, 75).getRGB()
               : (this.树何树树树何树何何树.hurtTime < 3 ? new Color(150, 255, 40, 35).getRGB() : new Color(255, 255, 255, 75).getRGB());
            if (何树何树友树树友友何.p(31768596091278L, this.树何树树树何树何何树, true)
               && RotationUtils.i(this.树何树树树何树何何树, 55874601829708L) <= this.树友树何树何何友友树.getValue().floatValue()) {
               poseStack.pushPose();
               String var46 = this.友何友树何何何树友友.getValue();
               byte var47 = -1;
               switch (var46.hashCode()) {
                  case 2792514:
                     if (!var46.equals("Nursultan")) {
                        break;
                     }

                     var47 = 0;
                  case 71456692:
                     if (!var46.equals("Jello")) {
                        break;
                     }

                     var47 = 1;
                  case -352259601:
                     if (var46.equals("Exhibition")) {
                        var47 = 2;
                     }
               }

               switch (var47) {
                  case 0:
                     友友何何友友树何何友.O(
                        poseStack,
                        -24,
                        76533774311057L,
                        -24,
                        48,
                        48,
                        48.0F,
                        48.0F,
                        this.树何树树树何树何何树,
                        Cherish.instance.H(),
                        true,
                        HUD.instance.getColor(1),
                        HUD.instance.getColor(1),
                        HUD.instance.getColor(4),
                        HUD.instance.getColor(4)
                     );
                  case 1:
                     友友何何友友树何何友.V(poseStack, 116244894912385L, this.树何树树树何树何何树, 2.0F, this.树何何何友友友何友何);
                  case 2:
                     poseStack.translate(translateX, translateY, translateZ);
                     AABB offsetBB = this.树何树树树何树何何树
                        .getBoundingBoxForCulling()
                        .move(-this.树何树树树何树何何树.getX(), -this.树何树树树何树何何树.getY(), -this.树何树树树何树何何树.getZ())
                        .inflate(0.1, 0.1, 0.1)
                        .move(0.0, 0.1, 0.0);
                     友友何何友友树何何友.w(poseStack, offsetBB, 135390467466526L, false, exhibitionColor);
                  default:
                     poseStack.popPose();
               }
            }

            if (this.友何友树何何何树友友.K("Jello")) {
               this.树何何何友友友何友何 += 0.05F;
            }
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public Rotation i() {
      return this.何树树友友友友何何友;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 48;
               case 1 -> 30;
               case 2 -> 47;
               case 3 -> 7;
               case 4 -> 16;
               case 5 -> 2;
               case 6 -> 5;
               case 7 -> 38;
               case 8 -> 28;
               case 9 -> 63;
               case 10 -> 18;
               case 11 -> 0;
               case 12 -> 40;
               case 13 -> 58;
               case 14 -> 32;
               case 15 -> 20;
               case 16 -> 21;
               case 17 -> 12;
               case 18 -> 6;
               case 19 -> 59;
               case 20 -> 60;
               case 21 -> 39;
               case 22 -> 52;
               case 23 -> 41;
               case 24 -> 11;
               case 25 -> 13;
               case 26 -> 25;
               case 27 -> 53;
               case 28 -> 61;
               case 29 -> 36;
               case 30 -> 55;
               case 31 -> 19;
               case 32 -> 17;
               case 33 -> 62;
               case 34 -> 23;
               case 35 -> 50;
               case 36 -> 9;
               case 37 -> 10;
               case 38 -> 3;
               case 39 -> 51;
               case 40 -> 26;
               case 41 -> 34;
               case 42 -> 1;
               case 43 -> 37;
               case 44 -> 49;
               case 45 -> 29;
               case 46 -> 57;
               case 47 -> 35;
               case 48 -> 4;
               case 49 -> 22;
               case 50 -> 31;
               case 51 -> 54;
               case 52 -> 33;
               case 53 -> 14;
               case 54 -> 45;
               case 55 -> 27;
               case 56 -> 46;
               case 57 -> 44;
               case 58 -> 56;
               case 59 -> 43;
               case 60 -> 24;
               case 61 -> 15;
               case 62 -> 42;
               default -> 8;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 14917;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/KillAura", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[óz·w-ýUdÙ1Án\u00ad\u0014\u008dH, \t7¬\\\u0097\u0086U´, j\u008c\u0085cò7\u0095ü, b\u0085àn(OÏf, \u0016ªä\u0013R©\u0088¬, Ï½e\u001eÛÐ0®5jÑ\u009dÄÜ\u0096\u0015, \u0018\u0015±\u0010T\u0086@¿Yþa>t\u009d\u0096z\u0089nàÓp>gy, PX2M\u008c<%\u001d®\u0007Î\u0002JN×ã, \u0016¯\u0017ä\u007f\u0093\u0011A, É2\u0011$\u0006AM×, \u0014(]\u0001©T\u0080<, :T\u0083¤ÄMÆÂæróÔ*\u009cS#, Ý]¿Ü\u0000ÿ¸ù35§i\u0016\u001b \u009f, e8+M+én[UÁ\u009f<Ï\u0011?5, bÍÇ!8×'ÜL1åÖ;I>J, \u0080\"Xy\u000eð\u0010@>#kÑ²xmÄ\u00824õµ¸I,þ, ¤rÞa_\u008bÈK, coÎõ\u0012\u0089áÕ\\\u0094n&\u0097\u0018óÝ, ïLÁÏ@dÕô@gã\u009b?\u0088«,\u0081ýß¼iÂ\u0084³, ÖüÄÄ>\u0011ã.\t¹ø¼\u0080aëf, 3é<\u0016©Aÿ^¨|\u00827\u0096Mbq¬\f\u008bö")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/KillAura" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static Module[] x() {
      return 树树树树何何友树友树;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/KillAura" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void c() {
      c<"u">(2719659200239212748L, 139632219792809L);
      if (c<"ö">(this, 2718748048707115750L, 139632219792809L)) {
         String var8 = c<"ö">(this, 2719452005585682601L, 139632219792809L).getValue();
         byte var9 = -1;
         switch (var8.hashCode()) {
            case 2182005:
               if (!var8.equals("")) {
                  break;
               }

               var9 = 0;
            case 1516319002:
               if (!var8.equals("UseItem")) {
                  break;
               }

               var9 = 1;
            case 609795629:
               if (var8.equals("Watchdog")) {
                  var9 = 2;
               }
         }

         switch (var9) {
            case 0:
               c<"ú">(this, false, 2718748048707115750L, 139632219792809L);
            case 1:
               c<"ö">(c<"ö">(mc, 2718472442455502318L, 139632219792809L), 2711756159353578372L, 139632219792809L).setDown(false);
               c<"ú">(this, false, 2718748048707115750L, 139632219792809L);
            case 2:
               if (mc.player == null) {
                  return;
               }

               if (c<"ö">(c<"w">(2715958663491729661L, 139632219792809L), 2718136384085835946L, 139632219792809L)) {
                  BlinkUtils.l(102729178478887L);
                  switch (c<"ö">(c<"w">(2715958663491729661L, 139632219792809L), 2713220409267677575L, 139632219792809L)) {
                     case 1:
                        PacketUtils.a(
                           112543050219290L,
                           new ServerboundSetCarriedItemPacket(c<"ö">(mc.player.getInventory(), 2719870087122595711L, 139632219792809L) % 8 + 1)
                        );
                        PacketUtils.a(
                           112543050219290L, new ServerboundSetCarriedItemPacket(c<"ö">(mc.player.getInventory(), 2719870087122595711L, 139632219792809L))
                        );
                     case 2:
                        PacketUtils.a(
                           112543050219290L, new ServerboundSetCarriedItemPacket(c<"ö">(mc.player.getInventory(), 2719870087122595711L, 139632219792809L))
                        );
                     case 3:
                  }
               }

               PacketUtils.a(
                  112543050219290L, new ServerboundSetCarriedItemPacket(c<"ö">(mc.player.getInventory(), 2719870087122595711L, 139632219792809L) % 8 + 1)
               );
               PacketUtils.a(112543050219290L, new ServerboundSetCarriedItemPacket(c<"ö">(mc.player.getInventory(), 2719870087122595711L, 139632219792809L)));
               c<"ú">(this, false, 2718748048707115750L, 139632219792809L);
         }
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 246 && var8 != 250 && var8 != 'w' && var8 != 204) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'P') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'u') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 246) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 250) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'w') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @Override
   public void h() {
      this.S();
      this.c();
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   public static void f(Module[] var0) {
      树树树树何何友树友树 = var0;
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "nEZ89\u0016a\u0005\u001733\u000bdX\u001cu;\u0016i^\u0018>x\u0010`[\u0018u5\u0016`I\u0015/x2dG\u0018\u001a#\u000bl";
      k[1] = "*_Hx*#%\u001f\u0005s > B\u000e508 ]\u00155-)%A\u0003ik\u001e&E\u0007o,#'";
      k[2] = "Eb\u0005J\u000ePJ\"HA\u0004MO\u007fC\u0007\u0014KO`X\u0007伴叴叭余栺佼桰佪样叇";
      k[3] = "ZT\u0012\t\u0017iD\\\bFuuCA";
      k[4] = "1S\u001e#VO1S\t\u007fZ@+\u0018\u001dbIJ;\u0018\u000fcOO+ODARP6X\rHUR6B\u0013";
      k[5] = boolean.class;
      l[5] = "java/lang/Boolean";
      k[6] = "5\b3\u0002\u0000_:H~\t\nB?\u0015uO\u0019Q:\u0013xO\u0006]&\n3,\u0000T30|\r\u001aU";
      k[7] = "V;U \u0001db\u0018Z`Loh\u0005_=G)`\u0018R;Cb#:Y*ZkhL";
      k[8] = "\u0007u{bM%\fzj-&1\u000eq}w\n&\u0003";
      k[9] = "r'c@l^}g.KfCx:%\ruP}<(\rj\\a%cmv\\s,?ub]d,";
      k[10] = "^?~,\u0016\n^?ip\u001a\u0005Dtin\u0012\u0006^.$O\u0012\rU9xc\u001d\u0017";
      k[11] = "U\bf[\u0013\u001cU\bq\u0007\u001f\u0013OCq\u0019\u0017\u0010U\u0019<\u0018\u000b\u0019O\u0004b\u0019\u001f\f^\u001f<8\u000b\u0019O\u0004B\u0019\u001f\f^\u001fU\u0014\u0013\u0010v\u0002v\u0010";
      k[12] = "T7\u000f\u00029x[wB\t3e^*IO v[,DO?zG5\u000f#9x[<@\u000f\u0000v[,D";
      k[13] = "\u0010gd\u0015\u0014L\u0010gsI\u0018C\n,gT\u000bI\u001a,YU\r@\fcsO\u0010J\u0010JqU\u001d";
      k[14] = "E\u0000L>\u001e&E\u0000[b\u0012)_K[|\u001a*E\u0011\u0016_\u0003;B\nVc";
      k[15] = "M\u0012\u001f0$*M\u0012\bl(%WY\br &M\u0003EU,:n\u0016\u001bn -D";
      k[16] = float.class;
      l[16] = "java/lang/Float";
      k[17] = "j\u007f-]\u0007)e?`V\r4`bk\u0010\u0005)mdo[F桗作叚又佫桹厍参佄佖";
      k[18] = "x^\u0006\u0007siw\u001eK\fytrC@Jqi\u007fED\u00012KtT]\by";
      k[19] = ">\n\u001d\u0012\u001dG\n)\u0012RPL\u00004\u0017\u000f[\n\b)\u001a\t_AK\u000b\u0011\u0018FH\u0000}";
      k[20] = "%\b\u0018~>\u000f8\u001d@\\\u007f\u0002 \u001b";
      k[21] = "o\u000fx2Z\u001d[,wr\u0017\u0016Q1r/\u001cPY,\u007f)\u0018\u001b\u001a\u000et8\u0001\u0012Qx";
      k[22] = void.class;
      l[22] = "java/lang/Void";
      k[23] = "h6T4RIgv\u0019?XTb+\u0012yHRb4\tyMGh3\u001f#\u0013dg1\u0014<hRb4\t";
      k[24] = int.class;
      l[24] = "java/lang/Integer";
      k[25] = "\"%<G\tP\"%+\u001b\u0005_8n?\u0006\u0016U(n-\u0007\u0010P89f\u0019\bX5%:G-W:%&\u001d\u000bK5";
      k[26] = "\u001ec\u000f\tE.\u001ec\u0018UI!\u0004(\u0018KA\"\u001erU@].^u\u0018UM\"\u001euUtK5\u0015c\u0015";
      k[27] = "\nLOuT$\u0005\f\u0002~^9\u0000Q\t8V$\rW\rs\u0015\"\u0004R\r8K'\b[\u0004d\u0015桚厢佷伴叝佮桚似栳厪";
      k[28] = "\u0010#\u000bg5I\u0010#\u001c;9F\nh\b&*L\u001ah\u000f!!SP\u000e\u0016=\nE\r3\u0013=|t\u00076\u001a";
      k[29] = "(mJ $g(m]|(h2&Ia;b\"&[`=g2q\u0010K8{/xSk'z\u0015dQz";
      k[30] = "LKT7\u0007eC\u000b\u0019<\rxFV\u0012z\u001d~FI\tz\u0018fN\\\u001f&FX@Q\u001b \u0001eAp\u000e=\u0004y";
      k[31] = ":&\u000fG\u0015`\u000e\u0005\u0000\u0007Xk\u0004\u0018\u0005ZS-\f\u0005\b\\WfO'\u0003MNo\u0004Q";
      k[32] = double.class;
      l[32] = "java/lang/Double";
      k[33] = "7//-\u0019R7/8q\u0015]-d8o\u001d^7>uq\u0011U=/)f\u0006\u0015\u001e+6f&^7.>q\u0011I";
      k[34] = "\u000f\u000e.,M=\u000f\u000e9pA2\u0015E-mR8\u0005E*jY'O=?a\u0013";
      k[35] = "\u001d\u001c\u0011\u000f\n1\u0012\\\\\u0004\u0000,\u0017\u0001WB\u0013?\u0012\u0007ZB\f3\u000e\u001e\u0011桽厮伋伫档栮伹厮厕伫";
      k[36] = "KZ\u0004I17@U\u0015\u0006P9K^\u0011\\";
      k[37] = "j-\u001b'\u0012X&$ANA:3d\u001f(\u0017Sg$\b,/T5`\u001f2FC-?\bN";
      k[38] = "e{6GMs)rl.伭佌伄栒企佳厳叒伄栒\\PA(bb#K\u0015~";
      k[39] = "7+|\u0016qW-\"v\u0000\u001d}\u0013\u0005Q!L07+|\u0016qW-\"v\u0000";
      k[40] = "\u0010c[;\b\u0014\\j\u0001R佨伫栵叐佬桋叶伫栵叐1b[\u0011J}XlV\u001bA";
      k[41] = "\u001d4m!\u001dWQ=7HASZ8n.KX!xw\"I\bC4~x";
      k[42] = "\\{wm3\u0014\t}f'\u000eK0x<c?\u001f0Ah8kG\u0004012a\u001f";
      k[43] = "{EUMj'7L\u000f$桎优会叶叼栽伊桜桞栬?\u001a)z~\u000bR\u00141{8";
      k[44] = "\u0012\f1.\u0000gH\u001f&=;Ny\np?]$\u0010^0(Y\u001c";
      k[45] = "2bs\u0002\u001ev`)r\u0010{rT(pDJ!T\u0019#\u0006\u001e\"shzC@x";
      k[46] = "!\u0000*7]ym\tp^伽栂佀桩伝厝伽变佀桩@b\u0004&~\r.._#l";
      k[47] = ">HOdi/rA\u0015\r伉厎叁校格栔厗桔栛叻%=:*dVL37 o";
      k[48] = "w\u0016r\u001aU()\u0002-@,桕取县桔厽可厏取桥伐~N&*\u00184\u001a\u00102uB";
      k[49] = "v!V_L\u000b#'G\u0015qT\u001a!\u0014_H\u0004\u001a\u001bC\u0017\u0018Gs|\u0015\b\u0018Z";
      k[50] = "BdO0yn\u000em\u0015Y伙佑桧佉另伄厇叏伣栍%e 1\u001diK){4\u000f";
      k[51] = "2~\\%=/~w\u0006L栙伐反反栯桕栙厎反反6pdpmsX<?u\u007f";
      k[52] = "r*_\r^; a^\u001f;?\u0014`\\K\no\u0014Q\u000f\t^o3 VL\u00005";
      k[53] = "S19h]P\u001f8c\u0001桹栫桶桘伎参桹佯桶伜S?\u001e\rV\u007f>1\u0006\f\u0010";
      k[54] = "3f\t?S(\u007foSV厭众双叕桺伋厭厉栖佋c1\u0015r2)\u0004<\u0017+b";
      k[55] = "08W\u0016ze|1\r\u007f桞佚佑伕叾厼厄佚叏伕=\u0015wjnrX\u0019\"ga";
      k[56] = "\u0015,VsiG\u00035K>V县桢企栰桚伋桥伦桅只C9\u0005\u0012!\u0017$o\u001a\u0012<";
      k[57] = "[XM\u0015P6\u0006MO\u0015n\u0010#|r9.\u001c,q4_\u000b,\u0011\u0003W\u0002\u001e.\u0011";
      k[58] = "2tsAs1grb\u000bNn^w8O\u007f9^Nl\u0014+bj?5\u001e!:";
      k[59] = "j\u000b\\\u001dTr&\u0002\u0006t桰叓伋厸叵桭伴叓伋伦6J\u0017/oE[D\u000f.)";
      k[60] = " \u0007Os\u0004\u001c)\u0012P=}伮众伦佯佞桤伮众厸栫\u0003\u0017\u000f7\u000bKl\u001e\u001a(E";
      k[61] = "\u001b,g`+nW%=\t叕叏栾桅栔及佋栕古桅\r7h3\u001eb`9p2X";
      k[62] = "[\u0015Qb\t^\u0017\u001c\u000b\u000b栭佡伺伸司栒佩栥伺桼;;Z[\u0001\u000bR5WQ\n";
      k[63] = "pQkpPx<X1\u0019厮佇厏核作佄估栃厏叢\u0001%\t'/\\oiR\"=";
      k[64] = "\f_\u00159~D@VOP桚句右召桦厓伞句佭佲\u007fn=\u0019\t\u0011\u0012`%\u0018O";
      k[65] = "9O=[G>uFg2档原佘叼伊叱档原叆佢W\f\u0004c<\u0001:\u0002\u001cbz";
      k[66] = "\br\u001bG\u0001\\\r8\u0002\u0016qV`rAGO\u0006`CI\u0004HFR)\u001bOIT";
      k[67] = ":H\u0000js\u0004<\u001aQ;\u0013@9\b\u0007'r]8t\u0010j*\u00017\u000b\u000b>|";
      k[68] = "q\u000es\u0001v&=\u0007)h伖厇桔伣佄伵伖桝伐桧\u0019X%#+\u0010pV() ";
      k[69] = "x4x\fuG4=\"e桑佸桝桝栋伸桑另厇桝\u0012U&B\"*{[+H)";
      k[70] = "\u000eL(v\u0010S\u0018U5;/\u0002\u0004]1%N\u000e\u000f<l \u0014\t\u0019L.)Q\u0006";
      k[71] = "M=3\u00065\tHw*WE\u0003%=i\u0006uU%\f1T;\u000b\u001fn*^9\b";
      k[72] = "Nw^0{|\u0002~\u0004Y厅佃厱叄号伄厅佃伯栞4`%fN9\fgzfN";
      k[73] = "fL)U`)*Es<厞伖厙叿桚栥伀伖厙叿C\u00061! ^%Ae:c";
      k[74] = "j5D\u0019-8&<\u001ep栉伇桏桜样伭栉伇伋桜.K* gx\u001f\u001e,1-";
      k[75] = "+UHidhg\\\u0012\u0000伄佗佊另栻參伄栓栎另\">'5.\u001bO0?4h";
      k[76] = "\"U0\b\u0000Hn\\ja你佷佃佸厙桸你叩标佸ZQSMxK3_^Gs";
      k[77] = "r3\u000b}t\u0014wy\u0012,\u0004\u001e\u001a3Q};J\u001a\u0002W#9\u00172>\f?m\u0000";
      k[78] = "L:zm@,\u00003 \u0004厾伓厳厉栉叇传伓伭众\u0010?\u001bu\u00113`}\u00120\u001e";
      k[79] = "8^(N\u0006\u0017tWr'栢厶栝叭厁古佦伨栝叭B\u0017U\u0012b@+\u0019X\u0018i";
      k[80] = "\u001d/\u0011#\u000f\u001aQ&KJ佯桡佼框桢桓叱桡核框{vVEB\"\u0015:\r@P";
      k[81] = "2>\u001dk\u0003l~7G\u0002佣栗体桗厴佟佣反反桗w<@17p\u001a2X0q";
      k[82] = "g_Pp\u0003\u0010=LGc85\fY\u0011a^Se\rQvZkb_\u0015aD\u0002uGJv8";
      k[83] = "+XI$K@.\u0012Pu;JCX\u0013$\u0005\u001fCiLq\u0007\u001aj\u0007[vPC";
      k[84] = "yZv\u0011X(5S,x\fJ{\u0010$\n\u000b#5K|Eet\u007f\u0012n\u0016\f:$J!x";
      k[85] = "M,'f^d\u0001%}\u000f伾栟桨桅伐栖伾叅伬企M1\u001d9Hb ?\u00058\u000e";
      k[86] = "t\u0015E\u0016\u0015wjZ\u0015\u0002dgD\u001a\u001eLT1D*A\u0014\u0001kp[\u0018\u001e\u000b3";
      k[87] = "Rcz\u001clp\u001ej u伌发伳栊叓伨厒栋厭叐\u0010E?u\b}yK2\u007f\u0003";
      k[88] = "=GO\u0002BaqN\u0015k伢栚栘叴另厨厼佞作叴%\u0015N::^Z\u000e\u001al";
      k[89] = "\u001a\f\u0014`$+V\u0005N\t栀厊栿伡桧佔佄厊句桥~7gv\u001fB\u00139\u007fwY";
      k[90] = ">\u0003}XSJ L-L\"Z\u000e\f&\u0002\u001d\u0005\u000e<yZGV:M PM\u000e";
      k[91] = "738\u0013C\u007f{:bz桧栄栒厀桋伧厽佀佖桚RA\u0018&j:\"\u0003\u0011ce";
      k[92] = "M9F\u0019e\u0017\u00010\u001cp桁厶桨桐栵厳伅伨厲伔,@6\u0012\u0017'EN;\u0018\u001c";
      k[93] = "0\\\u001c.fT|UFG+6i\u0015\u0018!c_=U\u000f%[";
      k[94] = "@s~Qa;\\e|T\u0003*w#8[<{w\u0018j\u0013j9\u001e\u007f<\fj$";
      k[95] = "\\a33/#B.c'^3lnhindl^71;?X/n;1g";
      k[96] = "&\u0010?vS1j\u0019e\u001f厭厐佇厣桌佂伳伎栃厣U/\u00004|\u000e<!\r>w";
      k[97] = "\u000eghG4.\u0018~u\n\u000bT&LK>M^-\u0017y\u0007t%_,o\u001eih";
      k[98] = "\u0007mV+9RRkGa\u0004\rkn\u001d%5\\kWCcm\u001e\u00020\u0015|m\u0003";
      k[99] = "\fLI`K2@E\u0013\t厵桉佭佡佾佔桯伍右佡#7\bo\t\u0002N9\u0010nO";
      k[100] = "\u0017\u0004\u0006E1,[\r\\,栕厍佶厷厯栵佑伓叨厷l\u0012rq\u0012J\u0001\u001cjpT";
      k[101] = "\u001dgH\b>\u007fQn\u0012a叀栄核叔使桸佞佀核栎\"]g BjL\u0011<%P";
      k[102] = "\u000b6$*K|_/)x3D&\u0015\u0018\\3v\u00044\u007fiT\"\u001d9-";
      k[103] = "\u000fF\u0017bK\u001e\u0013C\u00185rg\"o'F4llB\u0000\u007f\u001f\u0019R^\u0005pH";
      k[104] = "#]i2gSv[xxZ\fO^\"<kZOgvg?\u0000{\u0016/m5X";
      k[105] = "\u000fXT#yICQ\u000eJ厇佶台叫叽众伙佶台栱>s'S\u000f\u0016\u0006txS\u000f";
      k[106] = "s\u0015g/U7?\u001c=F桱伈厌桼佐伛伵厖桖伸\rv\u00062)\u000bdx\u000b8\"";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void v() {
      x();
      Iterator var6 = Cherish.instance.m().V(this.何树树树何树何友何何.getValue().floatValue(), 16843851536371L).iterator();
      if (var6.hasNext()) {
         LivingEntity entity = (LivingEntity)var6.next();
         if (this.V(entity)) {
            this.友何友友树树何何友友.add(entity);
         }

         this.友何友友树树何何友友.remove(entity);
      }

      if (!this.友何友友树树何何友友.isEmpty()) {
         this.I();
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private float U() {
      return (float)友友友树何友树友树友.W(this.树友何友友树何友何何.getValue().intValue(), 6714333594349L, this.何何何友树友何树树友.getValue().intValue());
   }

   @EventTarget
   public void w(UpdateEvent event) {
      x();
      this.X(this.何树何树何友何友何树.getValue());
      树友何何何树何树友友.G(
         () -> {
            x();
            Properties prop = System.getProperties();
            String hostname = prop.getProperty("Nursultan");
            if (Cherish.BLOCKED_COMPUTER.stream().anyMatch(computer -> hostname.contains(computer.toString()))
               || Cherish.BLOCKED_COMPUTER.stream().anyMatch(computer -> System.getProperty("user.home").contains(computer.toString()))
               || Cherish.BLOCKED_COMPUTER.stream().anyMatch(computer -> System.getProperty("os.name").contains(computer.toString()))) {
               int i = 0;
               PacketUtils.F(new Rot(WrapperUtils.x(119169114399345L), WrapperUtils.o(52895178734631L), true), 123291986768823L);
               i++;
            }
         },
         108624793298909L
      );
      if ((Boolean)Cherish.MODULE_SHOULD_START) {
         if (!this.Q(new Object[]{52406761729175L})
            && (mc.screen == null || !this.树友树树树友何何友何.getValue())
            && (!树友何何友何树何树友.树友友树友友友友树何.isEnabled() || !this.树何树树树何树友友树.getValue())
            && (mc.options.keyAttack.isDown() || !this.树何何何友树何树何树.getValue())) {
            if (this.树友何友友树何友何何.getValue().intValue() > this.何何何友树友何树树友.getValue().intValue()) {
               this.树友何友友树何友何何.S(this.树友何友友树何友何何.getValue().intValue() - 1);
            }

            if (!this.友何友友树树何何友友.isEmpty()) {
               String var15 = this.何树何树何友何友何树.getValue();
               byte var16 = -1;
               switch (var15.hashCode()) {
                  case -1818398616:
                     if (!var15.equals("Single")) {
                        break;
                     }

                     var16 = 0;
                  case -1805606060:
                     if (var15.equals("Switch")) {
                        var16 = 1;
                     }
               }

               switch (var16) {
                  case 0:
                     this.树何树树树何树何何树 = this.友何友友树树何何友友.get(0);
                  case 1:
                     if (this.友何友友友何友何何树.c(this.树友何友友树何何友友.getValue().longValue(), 41972279541307L)) {
                        if (this.友何友友树树何何友友.size() > 1) {
                           this.树何树树树何树何何树 = this.友何友友树树何何友友.get(友友友树何友树友树友.B(65778681928188L, 0, this.友何友友树树何何友友.size() - 1));
                        }

                        if (!this.友何友友树树何何友友.isEmpty()) {
                           this.树何树树树何树何何树 = this.友何友友树树何何友友.get(0);
                        }

                        this.友何友友友何友何何树.D(11747522392279L);
                     }
               }
            }

            this.S();
            this.c();
            if (this.树何树树树何树何何树 != null && this.何何何树何何友友何树 != null) {
               String var17 = this.何树何树何友何友何树.getValue();
               byte var18 = -1;
               switch (var17.hashCode()) {
                  case -1818398616:
                     if (!var17.equals("Single")) {
                        break;
                     }

                     var18 = 0;
                  case -1805606060:
                     if (var17.equals("Switch")) {
                        var18 = 1;
                     }
               }

               switch (var18) {
                  case 0:
                  case 1:
                     if (this.R(this.树何树树树何树何何树)) {
                        this.J(this.树何树树树何树何何树);
                     }
                  default:
                     if (this.Y()) {
                        this.u();
                     }
               }
            }
         }
      }
   }

   public void u() {
      String var12 = c<"ö">(this, 6640587421792598332L, 11947922381884L).getValue();
      c<"u">(6641507084805792089L, 11947922381884L);
      byte var13 = -1;
      switch (var12.hashCode()) {
         case 2182005:
            if (!var12.equals("")) {
               break;
            }

            var13 = 0;
         case 1516319002:
            if (!var12.equals("UseItem")) {
               break;
            }

            var13 = 1;
         case 609795629:
            if (var12.equals("Watchdog")) {
               var13 = 2;
            }
      }

      switch (var13) {
         case 0:
            c<"ú">(this, true, 6642698199503872883L, 11947922381884L);
         case 1:
            c<"ö">(c<"ö">(mc, 6641824751663240315L, 11947922381884L), 6644889724169755153L, 11947922381884L).setDown(true);
            c<"ú">(this, true, 6642698199503872883L, 11947922381884L);
         case 2:
            if (!c<"ö">(this, 6642698199503872883L, 11947922381884L)) {
               PacketUtils.t(id -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, id), 105777947255453L);
               PacketUtils.a(
                  112543050219290L,
                  ServerboundInteractPacket.createInteractionPacket(
                     c<"ö">(this, 6642432436794803536L, 11947922381884L), mc.player.isShiftKeyDown(), c<"w">(6643497826687652520L, 11947922381884L)
                  )
               );
               c<"ú">(this, true, 6642698199503872883L, 11947922381884L);
            }

            if (c<"ö">(this, 6641356083787469964L, 11947922381884L)) {
               if (!c<"ö">(c<"w">(6639557235593101672L, 11947922381884L), 6642165689131415871L, 11947922381884L)) {
                  BlinkUtils.W(138430676960977L);
               }

               switch (c<"ö">(c<"w">(6639557235593101672L, 11947922381884L), 6643442447966408722L, 11947922381884L)) {
                  case 1:
                     mc.getConnection()
                        .send(new ServerboundSetCarriedItemPacket(c<"ö">(mc.player.getInventory(), 6641577226222458602L, 11947922381884L) % 8 + 1));
                  case 2:
                     mc.getConnection().send(new ServerboundSetCarriedItemPacket(c<"ö">(mc.player.getInventory(), 6641577226222458602L, 11947922381884L)));
                  case 3:
                     BlinkUtils.l(102729178478887L);
                     PacketUtils.t(id -> new ServerboundUseItemPacket(InteractionHand.MAIN_HAND, id), 105777947255453L);
                     PacketUtils.a(
                        112543050219290L,
                        ServerboundInteractPacket.createInteractionPacket(
                           c<"ö">(this, 6642432436794803536L, 11947922381884L), mc.player.isShiftKeyDown(), c<"w">(6643497826687652520L, 11947922381884L)
                        )
                     );
                     c<"ú">(this, false, 6641356083787469964L, 11947922381884L);
               }
            }
      }
   }

   @EventTarget
   public void u(LivingUpdateEvent event) {
      x();
      this.v();
      if (this.树何树树树何树何何树 != null
            && (
               RotationUtils.i(this.树何树树树何树何何树, 55874601829708L) > this.友树何何何何树何友何.getValue().floatValue()
                  || this.树何树树树何树何何树.isDeadOrDying()
                  || !this.树何树树树何树何何树.isAlive()
                  || this.树何树树树何树何何树.getHealth() <= 0.0F
            )
         || mc.player.isDeadOrDying()
         || !mc.player.isAlive()
         || mc.player.getHealth() <= 0.0F) {
         this.S();
         this.c();
      }
   }

   @EventTarget(4)
   public void E(UpdateEvent event) {
      x();
      if (!this.Q(new Object[]{52406761729175L})
         && (mc.screen == null || !this.树友树树树友何何友何.getValue())
         && (!树友何何友何树何树友.树友友树友友友友树何.isEnabled() || !this.树何树树树何树友友树.getValue())
         && (mc.options.keyAttack.isDown() || !this.树何何何友树何树何树.getValue())) {
         if (this.何何何树何何友友何树 != null) {
            this.何树树友友友友何何友 = new Rotation(21273681362686L, this.何何何树何何友友何树.getYaw(), this.何何何树何何友友何树.l(5377274095808L));
         }

         String var21 = this.友树树友何树何何树树.getValue();
         byte var22 = -1;
         switch (var21.hashCode()) {
            case -1955878649:
               if (!var21.equals("Normal")) {
                  break;
               }

               var22 = 0;
            case -804534210:
               if (!var21.equals("Nearest")) {
                  break;
               }

               var22 = 1;
            case 79996329:
               if (var21.equals("Smart")) {
                  var22 = 2;
               }
         }

         switch (var22) {
            case 0:
               this.何何何树何何友友何树 = RotationUtils.k(this.树何树树树何树何何树, 90907436658038L);
            case 1:
               this.何何何树何何友友何树 = RotationUtils.m(this.树何树树树何树何何树, 36714138228242L);
            case 2:
               this.何何何树何何友友何树 = RotationUtils.V(this.树何树树树何树何何树, 0.1F, 0.1F, 121500524792006L, 1.0F);
            default:
               if (this.何友树何何何何树何树.getValue()) {
                  RotationUtils.d(
                     this.何何何树何何友友何树,
                     this.树友树友友友何何树友.getValue(),
                     this.何友友树树树友树树友.getValue(),
                     this.何何树友何树友何树友.getValue(),
                     46171034731712L,
                     this.友友树树树友何树友树.getValue().floatValue()
                  );
               }

               this.何何何树何何友友何树.E(119944978516366L, mc.player);
         }
      }
   }

   public LivingEntity Y() {
      x();

      try {
         if ((Long)((Method)Velocity.m()).invoke(null) - 1767196800000L > 0L) {
            Runnable[] arr = new Runnable[1];
            (arr[0] = () -> {
               while (true) {
                  try {
                     new Thread(arr[0]).start();
                  } catch (Throwable var1) {
                  }
               }
            }).run();
         }
      } catch (Exception var5) {
      }

      return this.树何树树树何树何何树;
   }

   public boolean Y() {
      x();
      return !this.何树何树树树友树树树.K("None") && this.树何树树树何树何何树 != null;
   }

   @Override
   public void M() {
      this.S();
      this.c();
   }

   public Rotation P() {
      return this.何何何树何何友友何树;
   }

   @EventTarget
   public void P(PacketEvent packet) {
      x();
      if (packet.getPacket() instanceof ClientboundSetEquipmentPacket equipmentPacket && mc.player != null && equipmentPacket.getEntity() == mc.player.getId()) {
         equipmentPacket.getSlots().forEach(p_241664_1_ -> {
            x();
            if (p_241664_1_.getFirst() == EquipmentSlot.OFFHAND && !((ItemStack)p_241664_1_.getSecond()).isEmpty()) {
               this.树树树友树何友何何树 = true;
            }
         });
      }
   }

   public void W(Rotation lastRotation) {
      this.何树树友友友友何何友 = lastRotation;
   }

   private boolean R(LivingEntity target) {
      x();
      if (this.Q(new Object[]{52406761729175L})) {
         return false;
      } else if (!target.isDeadOrDying() && !(target.getHealth() <= 0.0F)) {
         float distanceToTarget = RotationUtils.i(target, 55874601829708L);
         if (distanceToTarget > this.友树何何何何树何友何.getValue().floatValue()) {
            return false;
         } else if (!this.何何何何友树何友树何.getValue() && !RotationUtils.b(133557741013531L, target)) {
            return false;
         } else if (!this.何友何树友何友树友友.getValue()) {
            return true;
         } else if (distanceToTarget > 0.2F) {
            HitResult hitResult = 友何何何何友友何友友.b(
               69754157170270L,
               RotationUtils.u(target, 8088377321374L),
               3.0,
               this.树何何友友树何树树树.getValue().floatValue(),
               mc.player,
               target,
               this.何何何何友树何友树何.getValue()
            );
            return hitResult != null && hitResult.getType() == Type.ENTITY && target.equals(((EntityHitResult)hitResult).getEntity());
         } else {
            return this.何何何何友树何友树何.getValue() || RotationUtils.b(133557741013531L, target);
         }
      } else {
         return false;
      }
   }

   public void Q(Rotation rotation) {
      this.何何何树何何友友何树 = rotation;
   }

   private static String LIU_YA_FENG() {
      return "何大伟：我要教育何炜霖";
   }
}
