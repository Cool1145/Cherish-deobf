package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.ui.何树树友树树友树友树;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.player.树友友何树友树树树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class 友友树友友友友何友友 extends Module implements 何树友 {
   public static 友友树友友友友何友友 友友何友何友树树树何;
   private final ModeValue 树树何树树树何友友友;
   private final BooleanValue 何何友何友树友友何何;
   private final BooleanValue 何树树树何树友何何树;
   private final NumberValue 树树树何何树何何何何;
   private final NumberValue 何树友何树树何树树友;
   private final NumberValue 友友友友树友树何树树;
   private final NumberValue 何友树友友友何何树友;
   private final NumberValue 树树何何树何友友友友;
   private final ModeValue 何树树友何树何友友友;
   private final 树友树友友何何树何何 友友友何树树树树树友;
   private final 树友树友友何何树何何 友友友何友何树何树何;
   private boolean 何友树树友友树何何友;
   private boolean 何树树树树何何树何树;
   private boolean 友树友树友何树友树何;
   private boolean 树树何树何树树何树何;
   private LivingEntity 何友何何何友友何何友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[44];
   private static final String[] n = new String[44];
   private static int _何炜霖国企变私企 _;

   public 友友树友友友友何友友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/combat/友友树友友友友何友友.a J
      // 003: ldc2_w 93262763876045
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 90481426720706
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 5517
      // 014: ldc2_w 1101023659863045026
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 11940
      // 021: ldc2_w 8968536939086170242
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -8339609842879096412
      // 02e: lload 1
      // 02f: invokedynamic À (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/ModeValue
      // 03b: dup
      // 03c: sipush 24574
      // 03f: ldc2_w 6619624037390957019
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 16866
      // 04c: ldc2_w 6441903962695346134
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 2
      // 057: anewarray 99
      // 05a: dup
      // 05b: bipush 0
      // 05c: sipush 25556
      // 05f: ldc2_w 8257046561815463400
      // 062: lload 1
      // 063: lxor
      // 064: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 069: aastore
      // 06a: dup
      // 06b: bipush 1
      // 06c: sipush 17803
      // 06f: ldc2_w 5011148326762816418
      // 072: lload 1
      // 073: lxor
      // 074: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 079: aastore
      // 07a: sipush 25556
      // 07d: ldc2_w 8257046561815463400
      // 080: lload 1
      // 081: lxor
      // 082: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 087: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 08a: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.树树何树树树何友友友 Lcn/cool/cherish/value/impl/ModeValue;
      // 08d: aload 0
      // 08e: new cn/cool/cherish/value/impl/BooleanValue
      // 091: dup
      // 092: sipush 14072
      // 095: ldc2_w 5510960425764081872
      // 098: lload 1
      // 099: lxor
      // 09a: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09f: sipush 20668
      // 0a2: ldc2_w 4933378213157779089
      // 0a5: lload 1
      // 0a6: lxor
      // 0a7: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ac: bipush 0
      // 0ad: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0b0: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0b3: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.何何友何友树友友何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0b6: aload 0
      // 0b7: new cn/cool/cherish/value/impl/BooleanValue
      // 0ba: dup
      // 0bb: sipush 13395
      // 0be: ldc2_w 2027322160654013047
      // 0c1: lload 1
      // 0c2: lxor
      // 0c3: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c8: sipush 30511
      // 0cb: ldc2_w 6705300640125358366
      // 0ce: lload 1
      // 0cf: lxor
      // 0d0: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d5: bipush 1
      // 0d6: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0d9: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0dc: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.何树树树何树友何何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0df: aload 0
      // 0e0: new cn/cool/cherish/value/impl/NumberValue
      // 0e3: dup
      // 0e4: sipush 27166
      // 0e7: ldc2_w 2241333693468707876
      // 0ea: lload 1
      // 0eb: lxor
      // 0ec: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f1: sipush 18015
      // 0f4: ldc2_w 7097901888156868717
      // 0f7: lload 1
      // 0f8: lxor
      // 0f9: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0fe: bipush 100
      // 100: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 103: bipush 0
      // 104: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 107: bipush 100
      // 109: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 10c: bipush 1
      // 10d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 110: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 113: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.树树树何何树何何何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 116: aload 0
      // 117: new cn/cool/cherish/value/impl/NumberValue
      // 11a: dup
      // 11b: sipush 2124
      // 11e: ldc2_w 2017667879728279161
      // 121: lload 1
      // 122: lxor
      // 123: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 128: sipush 842
      // 12b: ldc2_w 1596247290387621239
      // 12e: lload 1
      // 12f: lxor
      // 130: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 135: bipush 120
      // 137: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 13a: bipush 50
      // 13c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 13f: sipush 1000
      // 142: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 145: bipush 10
      // 147: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 14a: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 14d: aload 0
      // 14e: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友友树友友友友何友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友友树友友友友何友友.J ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 153: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 156: checkcast cn/cool/cherish/value/impl/NumberValue
      // 159: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.何树友何树树何树树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 15c: aload 0
      // 15d: new cn/cool/cherish/value/impl/NumberValue
      // 160: dup
      // 161: sipush 13396
      // 164: ldc2_w 428857231729775202
      // 167: lload 1
      // 168: lxor
      // 169: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16e: sipush 20969
      // 171: ldc2_w 7464468530797656014
      // 174: lload 1
      // 175: lxor
      // 176: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 17b: ldc2_w 3.0
      // 17e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 181: ldc2_w 0.5
      // 184: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 187: ldc2_w 7.0
      // 18a: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 18d: ldc2_w 0.1
      // 190: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 193: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 196: aload 0
      // 197: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友友树友友友友何友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友友树友友友友何友友.k ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 19c: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 19f: checkcast cn/cool/cherish/value/impl/NumberValue
      // 1a2: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.友友友友树友树何树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 1a5: aload 0
      // 1a6: new cn/cool/cherish/value/impl/NumberValue
      // 1a9: dup
      // 1aa: sipush 23784
      // 1ad: ldc2_w 3861896734852463312
      // 1b0: lload 1
      // 1b1: lxor
      // 1b2: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b7: sipush 30659
      // 1ba: ldc2_w 7250260350222766576
      // 1bd: lload 1
      // 1be: lxor
      // 1bf: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c4: ldc2_w 6.0
      // 1c7: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1ca: dconst_1
      // 1cb: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1ce: ldc2_w 15.0
      // 1d1: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1d4: ldc2_w 0.5
      // 1d7: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 1da: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1dd: aload 0
      // 1de: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友友树友友友友何友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友友树友友友友何友友.Z ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 1e3: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 1e6: checkcast cn/cool/cherish/value/impl/NumberValue
      // 1e9: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.何友树友友友何何树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 1ec: aload 0
      // 1ed: new cn/cool/cherish/value/impl/NumberValue
      // 1f0: dup
      // 1f1: sipush 16557
      // 1f4: ldc2_w 5218913282155619983
      // 1f7: lload 1
      // 1f8: lxor
      // 1f9: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1fe: sipush 19555
      // 201: ldc2_w 5921968044889156180
      // 204: lload 1
      // 205: lxor
      // 206: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 20b: ldc2_w 15.0
      // 20e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 211: dconst_0
      // 212: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 215: ldc2_w 20.0
      // 218: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 21b: dconst_1
      // 21c: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 21f: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 222: aload 0
      // 223: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友友树友友友友何友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友友树友友友友何友友.a ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 228: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 22b: checkcast cn/cool/cherish/value/impl/NumberValue
      // 22e: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.树树何何树何友友友友 Lcn/cool/cherish/value/impl/NumberValue;
      // 231: aload 0
      // 232: new cn/cool/cherish/value/impl/ModeValue
      // 235: dup
      // 236: sipush 16801
      // 239: ldc2_w 4266216703250147217
      // 23c: lload 1
      // 23d: lxor
      // 23e: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 243: sipush 29740
      // 246: ldc2_w 3122889639018566163
      // 249: lload 1
      // 24a: lxor
      // 24b: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 250: bipush 2
      // 251: anewarray 99
      // 254: dup
      // 255: bipush 0
      // 256: sipush 19267
      // 259: ldc2_w 8209690167467289967
      // 25c: lload 1
      // 25d: lxor
      // 25e: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 263: aastore
      // 264: dup
      // 265: bipush 1
      // 266: sipush 24526
      // 269: ldc2_w 6324350078263376375
      // 26c: lload 1
      // 26d: lxor
      // 26e: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 273: aastore
      // 274: sipush 11665
      // 277: ldc2_w 3253566093262277563
      // 27a: lload 1
      // 27b: lxor
      // 27c: invokedynamic m (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 281: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 284: aload 0
      // 285: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友友树友友友友何友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友友树友友友友何友友.H ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 28a: invokevirtual cn/cool/cherish/value/impl/ModeValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 28d: checkcast cn/cool/cherish/value/impl/ModeValue
      // 290: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.何树树友何树何友友友 Lcn/cool/cherish/value/impl/ModeValue;
      // 293: aload 0
      // 294: new cn/cool/cherish/utils/树友树友友何何树何何
      // 297: dup
      // 298: lload 3
      // 299: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 29c: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.友友友何树树树树树友 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 29f: aload 0
      // 2a0: new cn/cool/cherish/utils/树友树友友何何树何何
      // 2a3: dup
      // 2a4: lload 3
      // 2a5: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 2a8: putfield cn/cool/cherish/module/impl/combat/友友树友友友友何友友.友友友何友何树何树何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 2ab: aload 0
      // 2ac: bipush 0
      // 2ad: ldc2_w -8336235339155076487
      // 2b0: lload 1
      // 2b1: invokedynamic Õ (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2b6: aload 0
      // 2b7: bipush 0
      // 2b8: ldc2_w -8339810118228021918
      // 2bb: lload 1
      // 2bc: invokedynamic Õ (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c1: aload 0
      // 2c2: bipush 0
      // 2c3: ldc2_w -8339868295086269988
      // 2c6: lload 1
      // 2c7: invokedynamic Õ (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2cc: aload 0
      // 2cd: aconst_null
      // 2ce: ldc2_w -8336838050673796982
      // 2d1: lload 1
      // 2d2: invokedynamic Õ (Ljava/lang/Object;Lnet/minecraft/world/entity/LivingEntity;JJ)V bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2d7: aload 0
      // 2d8: ldc2_w -8340195776317917202
      // 2db: lload 1
      // 2dc: invokedynamic Ð (Lcn/cool/cherish/module/impl/combat/友友树友友友友何友友;JJ)V bsm=cn/cool/cherish/module/impl/combat/友友树友友友友何友友.d (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2e1: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7965526825655946581L, -8261503841820008518L, MethodHandles.lookup().lookupClass()).a(3224036798511L);
      // $VF: monitorexit
      a = var10000;
      b();
      long var11 = a ^ 101086619497422L;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[30];
      int var18 = 0;
      String var17 = "¦\n\u0015^û£º.¤&$§\u001e$2¸k\u0000[\u009fÒf\"æZK©\u0089\u0002Y]í %d§:@V^Û«UvdFzô¢\u001b÷Õ5\u0092;&\u001d§s½Ïðà\u0083¾(oh?¶´\u0001\u0092õl\u009b½ È 3Ô²]b±O\u0011\u0015ÉH²×\u001dì\\wg\u0004þÑ\u0092j\u008f§K\u0010È c÷ÓP-Ö\u0090²Ñú+ª\u00ad\u001f\u0010ëèË\\â[\u0017ÌÃ²køòb4¼\u0010h\u0011@\bÚ\rúYl\tá\u008e\u0013\n34\u0010?Ê\u0003\u0089\r³[|\u00973\u0017Ö\u0010ö[Þ \u0011óGü\u0093Ì\u0092¬\u0017a\\N£eÈ\u0015\"mÎ\b¦»ÑæE\u0093Ç3H)dd\u00104\u0098\fÌßJ%¶ò)\u009aJPòp¸\u0010]FÛ\r\u0011\u0092´c\u0094u¸ºÝf0?0\u0092Sf\u009axWÄæÁüÄc8büHª#Æý\f\u007f\u009a\u0088è?Ô,=\u008e±_¶AE¤ü\u008dj\u0097ÿ\u0095\u0019\u0005 ^Ú\u0015\u0010¹ü\u007f\u0085\u00827¬o\u0001\\\u0097Ô\u001cDd¹ Â\u0094\u001e\u008c}\u001d~ù\u009fØäÑ±DÕ\u0087Þ©¢\u00adL\u0093\t-Ð¤j6TÖ´C\u0018\u0088Ì`®\u0088d¤°,ñN\"l\\Ý¿\u008aâ\t4åv\u0089¾(¯$\u001c*ò\u00923øJóqt\u001cäÜ\u0080c»\u0094§\u001bÀøNcöq\u009dø\u0096ªg|D'½\u0019\u0017>¦ *\u001dwÅ=Ëýi \u0018\u00ad\u0083\u0090FåÊ0ÃTUUÈQ<ÛzÃ%\u0084\u0017{é \fK\u008b\u0091«\u0087ñ7·\u008b\u009b\u0011çqÏÇúÌ¶/^?ÍÄ^ã\u009emB§ë\u0096\u0010\u001cÂ\u008edUU¨(xÌ\\@¨\u009e\u0088`0\u0006\u0085\u008e\u0083Aø\u0018¦\u008a\u001cà\u001e^\u0089Ð\"í \"\u008e4\n°·Úÿ\u0016Ø´%ÆîoSd¶³;5iSÌOS\u0099yÛ\u001b ´ä\u009bì³´Ð«\u0083\u00178\u008e}({]Ô\u0085k©\u009fWçmQu¯3rÃjé\u0010Ý\u0097þ\u009dBëfó¿2!\u009aD²g\u0082 £\u0080§mïÓÿ1¼¢?äa3þÍjJ¶Èº\u000f\u0090\u0018¬\u00ad\u000ba\u0007c\b]\u0010àþíÝï\u0097TÂ\u001eX\u0013\u0005%m-\u0084 Çö<Åg\u0002D\u001b;vÜbÍè\u0000c\u001c\u0091É\u0013VRàyU\u0012Û\u0089÷;+\u0098\u0010C/~È\u0093\u0096QÓ¸<ßÀ\u001d\u0099´§ âl\u009cøoÝ÷xÂ\u0099¨\u0098\u001d\u00ad\u0092\u0092ãk«{\u0005úúÐº\u009e\nA\u009b\u0004þ)\u0010OÜÇÜ\u0093Ô)!¸¸¢WøAºW »Þg¨\u001cj´cÙg<z*\u0091\u0004ð¨¨\u0005ºº)\u0088ÛÐJsá[Ûg5";
      short var19 = 771;
      char var16 = ' ';
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[30];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "OúF³}·Ûà(\u0019Å±\u0090.;\u008e".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "òøì\u0015ü\u0017\u0085ª3\u000bOy¨pã\u0007èÄ;\u0091©ÿ÷Tß¬ÎÁ\u0007-è±\u001d\u0004Ï\u0010ÙÂ¢T.\u0010\u001a®\u0090¾è<Y\u009d°h¬\u007f#Ø\u0010>\u009cÄâ²/4\u0083\u0013O0òÞß*ê";
                  var19 = 73;
                  var16 = '8';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void B(MotionEvent event) {
      long a = 友友树友友友友何友友.a ^ 30795728359655L;
      long ax = a ^ 33506869787463L;
      long axx = a ^ 20767196845889L;
      long axxx = a ^ 48418936369656L;
      d<"R">(-4438449005554083132L, a);
      if (d<"Å">(this, -4438434187350273934L, a).C(b<"m">(25556, 8256968154174278594L ^ a))) {
         if (!this.w(new Object[]{ax})) {
            if (d<"Å">(this, -4438870346916903853L, a)
               && d<"Å">(this, -4438608596705968012L, a).c(d<"Å">(this, -4437462149780823512L, a).getValue().longValue(), axx)) {
               d<"Å">(d<"Å">(mc, -4437538999872930602L, a), -4438545675808613831L, a).setDown(d<"Å">(this, -4437943173581036728L, a));
               d<"Õ">(this, false, -4438870346916903853L, a);
            }

            if (d<"Å">(this, -4438870346916903853L, a)
               && d<"Å">(this, -4438608596705968012L, a)
                  .c(d<"Å">(this, -4437462149780823512L, a).getValue().longValue() + c<"f">(17851, 2938693910122960412L ^ a), axx)) {
               d<"Å">(d<"Å">(mc, -4437538999872930602L, a), -4438545675808613831L, a).setDown(d<"Å">(this, -4437943173581036728L, a));
               d<"Õ">(this, false, -4438870346916903853L, a);
            }

            if (d<"Å">(this, -4437248889885166459L, a).c(c<"f">(23836, 3275484813876891322L ^ a), axx)) {
               d<"Å">(this, -4437248889885166459L, a).U(axxx);
               if (!d<"Å">(this, -4438870346916903853L, a)
                  && d<"Å">(mc.player, -4438772129243043090L, a) > 0.0F
                  && !d<"Å">(d<"Å">(mc, -4437538999872930602L, a), -4438545675808613831L, a).isDown()) {
                  d<"Å">(d<"Å">(mc, -4437538999872930602L, a), -4438545675808613831L, a).setDown(true);
               }
            }
         }
      }
   }

   public void F() {
      long a = 友友树友友友友何友友.a ^ 50617232885626L;
      long ax = a ^ 48869803994330L;
      d<"R">(6195339202702331225L, a);
      d<"Õ">(this, false, 6193945245463041256L, a);
      d<"Õ">(this, null, 6195514023243809085L, a);
      if (!this.w(new Object[]{ax})) {
         if (d<"Å">(this, 6194917869870666702L, a)) {
            d<"Å">(d<"Å">(mc, 6194564679134423883L, a), 6195312832343985572L, a).setDown(d<"Å">(this, 6193698779452519637L, a));
            d<"Õ">(this, false, 6194917869870666702L, a);
         }

         if (d<"Å">(this, 6194049429760229483L, a)) {
            KeyMapping.set(d<"Å">(d<"Å">(mc, 6194564679134423883L, a), 6194910243504766756L, a).getKey(), false);
            d<"Õ">(this, false, 6194049429760229483L, a);
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 4;
               case 1 -> 0;
               case 2 -> 28;
               case 3 -> 61;
               case 4 -> 42;
               case 5 -> 43;
               case 6 -> 50;
               case 7 -> 51;
               case 8 -> 19;
               case 9 -> 52;
               case 10 -> 6;
               case 11 -> 18;
               case 12 -> 29;
               case 13 -> 13;
               case 14 -> 38;
               case 15 -> 16;
               case 16 -> 47;
               case 17 -> 24;
               case 18 -> 53;
               case 19 -> 34;
               case 20 -> 60;
               case 21 -> 15;
               case 22 -> 12;
               case 23 -> 41;
               case 24 -> 48;
               case 25 -> 9;
               case 26 -> 22;
               case 27 -> 14;
               case 28 -> 17;
               case 29 -> 55;
               case 30 -> 25;
               case 31 -> 46;
               case 32 -> 45;
               case 33 -> 57;
               case 34 -> 21;
               case 35 -> 56;
               case 36 -> 36;
               case 37 -> 49;
               case 38 -> 11;
               case 39 -> 39;
               case 40 -> 3;
               case 41 -> 35;
               case 42 -> 37;
               case 43 -> 10;
               case 44 -> 63;
               case 45 -> 58;
               case 46 -> 27;
               case 47 -> 31;
               case 48 -> 40;
               case 49 -> 7;
               case 50 -> 2;
               case 51 -> 8;
               case 52 -> 59;
               case 53 -> 32;
               case 54 -> 5;
               case 55 -> 30;
               case 56 -> 20;
               case 57 -> 54;
               case 58 -> 62;
               case 59 -> 33;
               case 60 -> 44;
               case 61 -> 23;
               case 62 -> 26;
               default -> 1;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private void i() {
      long a = 友友树友友友友何友友.a ^ 86569107579541L;
      d<"R">(3464715744906291382L, a);
      if (d<"Å">(this, 3466311085980231044L, a)) {
         KeyMapping.set(d<"Å">(d<"Å">(mc, 3465769999194738340L, a), 3465483326873131723L, a).getKey(), false);
      }

      d<"Õ">(this, false, 3466311085980231044L, a);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友树友友友友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27258;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友树友友友友何友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void b() {
      m[0] = "zK9\u001fz+u\u000bt\u0014p6pV\u007fRx+}P{\u0019;-tU{Rv+tGv\b;厏叒栴叜厷叞厏佌叮叜";
      m[1] = "&Z?lBe)\u001argHx,Gy!X~,Xb!格叁桔叿叚佚佸栛伐佡";
      m[2] = "l+\r\u0019s\u0002l+\u001aE\u007f\rv`\u000eXl\u0007f`\u001cYj\u0002v7W{w\u001dk \u001erp\u001fk:\u0000";
      m[3] = boolean.class;
      n[3] = "java/lang/Boolean";
      m[4] = "Z`]\u001b\u000fSU \u0010\u0010\u0005NP}\u001bV\u0016]U{\u0016V\tQIb]5\u000fX\\X\u0012\u0014\u0015Y";
      m[5] = "f5y3U\tiu48_\u0014l(?~W\ta.;5\u0014\u000fh+;~Y\th96$\u0014-l7;\u0011O\u0014d";
      m[6] = "h\u0000U\u0004mv\\#ZD }V>_\u0019+;^#R\u001f/p\u001d\u0001Y\u000e6yVw";
      m[7] = "\u0012\\\u0013tMa\u0012\\\u0004(An\b\u0017\u00046Im\u0012MI\u0017If\u0019Z\u0015;F|";
      m[8] = "Y\t\tu\u001f8Y\t\u001e)\u00137CB\u001e7\u001b4Y\u0018S\u0014\u0002%^\u0003\u0013(";
      m[9] = "5\u0002\u0001ihi>\r\u0010&\u0014p1\u0017\u001ee#@'\u0000\u0012x2l0\r";
      m[10] = "\u0001kU4\u0003g\u0001kBh\u000fh\u001b Bv\u0007k\u0001z\u000fQ\u000bw\"oQj\u0007`\b";
      m[11] = "R2#\\e\b]rnWo\u0015X/e\u0011g\bU)aZ$伲佤厗佘佪叁伲佤桍栜";
      m[12] = "Nm\u001bNmEA-VEgXDp]\u0003tKAvP\u0003kG]o\u001bcwGOfG{cFXf";
      m[13] = "\u001czaUGu\u001czv\tKz\u00061v\u0017Cy\u001ck;\u000bF}\u000bzgUfs\u0011~y+F}\u000bzg";
      m[14] = float.class;
      n[14] = "java/lang/Float";
      m[15] = "DAC3+YK\u0001\u000e8!DN\\\u0005~1_\t栾桼厛休佣佲古厦桁休";
      m[16] = "KK37n0D\u000b~<d-AVuzw>DPxzh2XI3\u0016n0D@|:W>DPx";
      m[17] = ":S8v^\\1\\)9?R:W-c";
      m[18] = "*#fR a#d&7厓厞叐伀厚佪桉伀栊伀Y\u000eofbde\u000f?\"t";
      m[19] = "Kd\u0014J/?B#T/厜叀伯叙佶召框栚桫佇+\u0016!<\u0017j\u0017\u001ff|";
      m[20] = "\t\u001d\u000b|\u0011]\u0000ZK\u0019桸桸佭伾栭佄厢厢右厠4)\u0007\fK\u0007\u000fiXZ@";
      m[21] = "|n\fS~\u0012u)L6体样桜叓佮栯体叭历叓3\r4@?z\u0002\b0\u00154";
      m[22] = "$/\u0002p#bx6WuXjOl\n(f:O]\u000et#h\u007fdKqf|";
      m[23] = "[:ioAtR})\n佬桑厡伙桏栓佬桑桻厇V:W%\u0019 mz\bs\u0012";
      m[24] = "Q}(>H#\u0004f!7s-\f{$8\u0015'\u0007\u0000c,\u0003#Qo67\n*";
      m[25] = "\u0000\u00079kI\"\t@y\u000e佤标栠桠栟体佤标佤桠\u00064A!B\u00059eAsU";
      m[26] = "\u001c:3ky(^e8+\u0018厍栵叀厗伎佅厍佱栚厗S(wK;55j(@{";
      m[27] = "\u000bxL\t\u0017r\u0002?\fl伺伓叱佛厰桵厤厍佯佛s\u0006ZsXa\b\u0001Z5L";
      m[28] = "G'M(J\u001fN`\rM佧栺桧桀伯桔叹佾伣桀r'\u0007\u001e\u0014>\t \u0007X\u0000";
      m[29] = "<\u0002,\r>j5Elh桗桏佘桥低桱桗伋栜伡\u0013R6i~\u0000,\u00036;i";
      m[30] = "&T\u001a\u0001Y;/\u0013Zd只栞叜栳另伹栰叄栆佷%^Q8dV\u001a\u000fQjs";
      m[31] = "G3\u000f\u0000\u0004!\u0015>\u001a\u0018{桃佳伞桨桠桢桃叭伞厲y\u0012*P:\u000e\u0002@'E\"";
      m[32] = "\u0004L \u001aquAIe\u000e\u0016\"n\u0019aN&qn(dKs/^F5\n/&";
      m[33] = "\u001b*\u0017Q*tN1\u001eX\u0011J k\tE(aRo^Zj\u001b";
      m[34] = "\td\u0001K\u001dj\u0000#A.桴桏佭栃栧样估厕右叙>\u0015W8Jp\u000f\u0010SmA";
      m[35] = "=B'xm\u000f4\u0005g\u001d佀台余佡佅叞叞佮余叿\u0018'$TaGtf,Ai";
      m[36] = "\u0017b\rP\u000bE\u001e%M5\u0012y\u0010p\fV\u0011\u001cC!\u0003W{GB\"Q_\u001e\u0014\u0013-P5";
      m[37] = "e\r\u001b'\u0013\".\u0003H()7\u0003\u0007\u0019k\u0011c\u0003=H`\u00165)FXbJb";
      m[38] = "\u001c\ru;75\u0015J5^会及格厰厉厝会佔格厰Jn!d^\u0017q.~2U";
      m[39] = "JJ l\u001cOC\r`\t厯厰厰佩栆栐桵桪桪号\u001f0SH\u0002\r#1\u0003\f\u0014";
      m[40] = "0W'\u0013l39\u0010gv栅栖栐佴佅桯佁佒佔佴\u0018FzbrM#\u0006%4y";
      m[41] = "ud\u0003\u0018\u001cm|#C}厯厒厏叙栥厾桵伌桕栃<M\n<7~\u0007\rUj<";
      m[42] = "PnotY\u0006\u0015k*`>Q:;. \u000e\u0000:\n+%[\\\ndzd\u0007U";
      m[43] = "bkYT}\u0001k,\u00191佐叾桂栌厥史栔你伆取f\u000bu\u0002 iYZuP7";
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 197 && var8 != 213 && var8 != 192 && var8 != 208) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'r') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'R') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 197) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 192) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 4553;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友树友友友友何友友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友树友友友友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void c() {
      long a = 友友树友友友友何友友.a ^ 129596534784463L;
      long ax = a ^ 131551996848751L;
      long axx = a ^ 76782516052176L;
      d<"R">(6003051982839598060L, a);
      if (!this.w(new Object[]{ax}) && d<"Å">(d<"Å">(mc, 5999595243966115326L, a), 6003148655099136785L, a).isDown()) {
         d<"Õ">(this, true, 5999124481418572384L, a);
         d<"Õ">(this, true, 6002628890539349371L, a);
         d<"Å">(d<"Å">(mc, 5999595243966115326L, a), 6003148655099136785L, a).setDown(false);
         d<"Å">(this, 6002890537936359772L, a).U(axx);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友树友友友友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 友友树友友友友何友友.a ^ 114724129883293L;
      long ax = a ^ 97152478078338L;
      d<"Õ">(this, false, -7633013970560444657L, a);
      d<"Õ">(this, null, -7629760277247180070L, a);
      d<"Õ">(this, false, -7629235596624293847L, a);
      d<"Õ">(this, false, -7632781691144371316L, a);
      d<"Å">(this, -7633093456011419393L, a).U(ax);
   }

   @EventTarget
   public void j(AttackEvent event) {
      long a = 友友树友友友友何友友.a ^ 68299558047750L;
      long ax = a ^ 66406226099110L;
      d<"R">(-9041446597089224155L, a);
      if (d<"Å">(this, -9041361616500698989L, a).C(b<"m">(25556, 8256935220475005731L ^ a))) {
         if (!this.w(new Object[]{ax})) {
            Entity var8 = event.getTarget();
            if (var8 instanceof LivingEntity) {
               ;
            }
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void L() {
      long a = 友友树友友友友何友友.a ^ 120052139563708L;
      long ax = a ^ 122408921149724L;
      long axx = a ^ 58358671391994L;
      d<"R">(-4018329032971890529L, a);
      if (this.w(new Object[]{ax})) {
         d<"Õ">(this, null, -4018160797821985541L, a);
      } else {
         List<LivingEntity> getTargets = Cherish.instance.S().W(d<"Å">(this, -4017795017552042817L, a).getValue().floatValue(), axx);
         List<LivingEntity> validTargets = getTargets.stream().filter(entity -> {
            long axxx = 友友树友友友友何友友.a ^ 47967150817362L;
            d<"R">(-7867153549932885391L, axxx);
            return entity != null && entity.isAlive() && !entity.isDeadOrDying() && mc.player.hasLineOfSight(entity);
         }).sorted(Comparator.comparingDouble(e -> mc.player.distanceToSqr(e))).toList();
         if (!validTargets.isEmpty()) {
            d<"Õ">(this, validTargets.get(0), -4018160797821985541L, a);
         }

         d<"Õ">(this, null, -4018160797821985541L, a);
         if (d<"Å">(this, -4018160797821985541L, a) != null
            && (
               d<"Å">(this, -4018160797821985541L, a).isDeadOrDying()
                  || !d<"Å">(this, -4018160797821985541L, a).isAlive()
                  || mc.player.distanceTo(d<"Å">(this, -4018160797821985541L, a)) > d<"Å">(this, -4017795017552042817L, a).getValue().floatValue() + 1.0F
                  || !mc.player.hasLineOfSight(d<"Å">(this, -4018160797821985541L, a))
            )) {
            d<"Õ">(this, null, -4018160797821985541L, a);
         }
      }
   }

   @EventTarget
   public void T(LivingUpdateEvent event) {
      long a = 友友树友友友友何友友.a ^ 109117649961918L;
      long ax = a ^ 106956289402910L;
      long axx = a ^ 41529053446951L;
      d<"R">(1242440558382909853L, a);
      if (d<"Å">(this, 1242708313586090795L, a).C(b<"m">(17803, 5011128928557285073L ^ a))) {
         if (this.w(new Object[]{ax})) {
            if (d<"Å">(this, 1239019962509395119L, a)) {
               this.i();
            }

            d<"Õ">(this, null, 1242621970077074937L, a);
         } else {
            LivingEntity oldTarget = d<"Å">(this, 1242621970077074937L, a);
            String distance = d<"Å">(this, 1239343352935456264L, a).getValue();
            byte var11 = -1;
            switch (distance.hashCode()) {
               case -1955878649:
                  if (!distance.equals(b<"m">(9138, 733445756817037546L ^ a))) {
                     break;
                  }

                  var11 = 0;
               case -540863999:
                  if (distance.equals(b<"m">(11665, 3253510913651496648L ^ a))) {
                     var11 = 1;
                  }
            }

            switch (var11) {
               case 0:
                  this.L();
               case 1:
                  if (d<"À">(1238590462699307609L, a).isEnabled()) {
                     d<"Õ">(this, d<"À">(1238590462699307609L, a).B(), 1242621970077074937L, a);
                  }

                  d<"Õ">(this, null, 1242621970077074937L, a);
               default:
                  if (oldTarget != d<"Å">(this, 1242621970077074937L, a) && d<"Å">(this, 1239019962509395119L, a)) {
                     this.i();
                  }

                  if (d<"Å">(this, 1242621970077074937L, a) != null
                     && d<"Å">(this, 1242621970077074937L, a).isAlive()
                     && !d<"Å">(this, 1242621970077074937L, a).isDeadOrDying()) {
                     double distance = mc.player.distanceTo(d<"Å">(this, 1242621970077074937L, a));
                     double range = d<"Å">(this, 1241885696837785524L, a).getValue().doubleValue();
                     double buffer = d<"Å">(this, 1239472539121193520L, a).getValue().doubleValue() / 100.0;
                     if (distance < range - buffer) {
                        if (树友友何树友树树树何.o(axx)) {
                           if (!d<"Å">(this, 1239019962509395119L, a)) {
                              KeyMapping.set(d<"Å">(d<"Å">(mc, 1239561877157146511L, a), 1242135051562122208L, a).getKey(), true);
                              d<"Õ">(this, true, 1239019962509395119L, a);
                           }

                           d<"Õ">(this, false, 1238803630172606508L, a);
                        }

                        if (d<"Å">(this, 1239019962509395119L, a)) {
                           KeyMapping.set(d<"Å">(d<"Å">(mc, 1239561877157146511L, a), 1242135051562122208L, a).getKey(), false);
                           d<"Õ">(this, false, 1239019962509395119L, a);
                        }

                        if (d<"Å">(this, 1238803630172606508L, a)) {
                           return;
                        }

                        何树树友树树友树友树.p(d<"À">(1238976928464114783L, a), b<"m">(14697, 7024081830344344100L ^ a), b<"m">(27323, 7084086436454568427L ^ a));
                        d<"Õ">(this, true, 1238803630172606508L, a);
                     }

                     if (d<"Å">(this, 1239019962509395119L, a)) {
                        KeyMapping.set(d<"Å">(d<"Å">(mc, 1239561877157146511L, a), 1242135051562122208L, a).getKey(), false);
                        d<"Õ">(this, false, 1239019962509395119L, a);
                     }

                     if (d<"Å">(this, 1238803630172606508L, a)) {
                        d<"Õ">(this, false, 1238803630172606508L, a);
                     }
                  } else {
                     if (d<"Å">(this, 1239019962509395119L, a)) {
                        this.i();
                     }

                     if (d<"Å">(this, 1238803630172606508L, a)) {
                        d<"Õ">(this, false, 1238803630172606508L, a);
                     }
                  }
            }
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "职业技术教育中心学校";
   }
}
