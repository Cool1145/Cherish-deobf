package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.友树友友何友树友树友;
import cn.cool.cherish.utils.友树树何何树树何何树;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.item.友何树何友树友树何何;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.树友友何树友树树树何;
import cn.cool.cherish.utils.player.树树树何友友树友友友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;

public class 友何何友树何树友友友 extends Module implements 何树友 {
   private final ModeValue 友树何友树何树友友何;
   private final NumberValue 何何友树树友何友友友;
   private final NumberValue 何友树树树树何树友树;
   private final ModeValue 何友何友树何树友友树;
   private final BooleanValue 树友树树树友树树何树;
   private final NumberValue 何树树何何友友树树友;
   private final BooleanValue 友友树树何友树树友树;
   private final NumberValue 树何友友何友树树友何;
   private final BooleanValue 友何友树何何友树何树;
   private final NumberValue 何树树友友友友何何友;
   private final NumberValue 树何树何树何友何何何;
   private final BooleanValue 友树友树何树何树何友;
   private final NumberValue 友树何何树树友树友何;
   private final BooleanValue 何友树树友何何友树树;
   private final NumberValue 树树友友何树树友树何;
   private final BooleanValue 何树树何树友何树何何;
   private final NumberValue 树何友友树友友何何友;
   private final BooleanValue 友树何树树友树树友树;
   private final NumberValue 何友友友友友何何树友;
   private final NumberValue 何友树树树树树友树树;
   private final BooleanValue 树树树何树树友树何树;
   private final NumberValue 友友树树何友树树何树;
   private final BooleanValue 树树何树友树友树树树;
   private final NumberValue 友何树友友友何树友友;
   private Rotation 友树何何友树友树树友;
   private Rotation 何树树友树树友树友树;
   private boolean 友何树友何友友友何友;
   private final 树友树友友何何树何何 树何友友树树何友友树;
   private final List<LivingEntity> 友友树友友何树友何友;
   private double 友树何何树友树友何树;
   private double 友树何树何友树树树树;
   private float 何友树何友何何树友树;
   private float 树何何友何友友树树友;
   private float 友树树友树树友友友何;
   private float 友树友何何何友树何树;
   private float 何友树树何树友何友树;
   private float 何何何友树何树树树何;
   private BlockPos 友何树友友树何友友友;
   private int 树树树友树何树何何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[86];
   private static final String[] k = new String[86];
   private static String HE_JIAN_GUO;

   public 友何何友树何树友友友() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:200)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/combat/友何何友树何树友友友.a J
      // 003: ldc2_w 138177422772625
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 31869615271311
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 22103
      // 014: ldc2_w 2622957872511069065
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 5346
      // 021: ldc2_w 5638134737945061649
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w 432877566937642049
      // 02e: lload 1
      // 02f: invokedynamic B (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/ModeValue
      // 03b: dup
      // 03c: sipush 2196
      // 03f: ldc2_w 654890804745991551
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 18202
      // 04c: ldc2_w 2287149571603118784
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 3
      // 057: anewarray 122
      // 05a: dup
      // 05b: bipush 0
      // 05c: sipush 23555
      // 05f: ldc2_w 1732053919522726383
      // 062: lload 1
      // 063: lxor
      // 064: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 069: aastore
      // 06a: dup
      // 06b: bipush 1
      // 06c: sipush 13961
      // 06f: ldc2_w 7983452662045887309
      // 072: lload 1
      // 073: lxor
      // 074: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 079: aastore
      // 07a: dup
      // 07b: bipush 2
      // 07c: sipush 7590
      // 07f: ldc2_w 2385597362164162676
      // 082: lload 1
      // 083: lxor
      // 084: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 089: aastore
      // 08a: sipush 14310
      // 08d: ldc2_w 8950850054005606971
      // 090: lload 1
      // 091: lxor
      // 092: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 097: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 09a: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.友树何友树何树友友何 Lcn/cool/cherish/value/impl/ModeValue;
      // 09d: aload 0
      // 09e: new cn/cool/cherish/value/impl/NumberValue
      // 0a1: dup
      // 0a2: sipush 10952
      // 0a5: ldc2_w 2528318851632879385
      // 0a8: lload 1
      // 0a9: lxor
      // 0aa: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0af: sipush 12294
      // 0b2: ldc2_w 4398896676179561927
      // 0b5: lload 1
      // 0b6: lxor
      // 0b7: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bc: bipush 5
      // 0bd: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0c0: bipush 3
      // 0c1: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0c4: bipush 100
      // 0c6: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0c9: ldc2_w 0.1
      // 0cc: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0cf: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0d2: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.何何友树树友何友友友 Lcn/cool/cherish/value/impl/NumberValue;
      // 0d5: aload 0
      // 0d6: new cn/cool/cherish/value/impl/NumberValue
      // 0d9: dup
      // 0da: sipush 5684
      // 0dd: ldc2_w 3905798299982556126
      // 0e0: lload 1
      // 0e1: lxor
      // 0e2: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e7: sipush 1560
      // 0ea: ldc2_w 8358042405175131103
      // 0ed: lload 1
      // 0ee: lxor
      // 0ef: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f4: sipush 180
      // 0f7: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0fa: bipush 0
      // 0fb: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0fe: sipush 360
      // 101: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 104: bipush 1
      // 105: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 108: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 10b: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.何友树树树树何树友树 Lcn/cool/cherish/value/impl/NumberValue;
      // 10e: aload 0
      // 10f: new cn/cool/cherish/value/impl/ModeValue
      // 112: dup
      // 113: sipush 18451
      // 116: ldc2_w 2234684997457393150
      // 119: lload 1
      // 11a: lxor
      // 11b: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 120: sipush 19196
      // 123: ldc2_w 7391947611715745563
      // 126: lload 1
      // 127: lxor
      // 128: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 12d: bipush 8
      // 12f: anewarray 122
      // 132: dup
      // 133: bipush 0
      // 134: sipush 4229
      // 137: ldc2_w 5613638153364532588
      // 13a: lload 1
      // 13b: lxor
      // 13c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 141: aastore
      // 142: dup
      // 143: bipush 1
      // 144: sipush 13571
      // 147: ldc2_w 7602467184094464206
      // 14a: lload 1
      // 14b: lxor
      // 14c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 151: aastore
      // 152: dup
      // 153: bipush 2
      // 154: sipush 5684
      // 157: ldc2_w 3905798299982556126
      // 15a: lload 1
      // 15b: lxor
      // 15c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 161: aastore
      // 162: dup
      // 163: bipush 3
      // 164: sipush 22297
      // 167: ldc2_w 4304003997478595298
      // 16a: lload 1
      // 16b: lxor
      // 16c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 171: aastore
      // 172: dup
      // 173: bipush 4
      // 174: sipush 31198
      // 177: ldc2_w 351340474663207977
      // 17a: lload 1
      // 17b: lxor
      // 17c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 181: aastore
      // 182: dup
      // 183: bipush 5
      // 184: sipush 810
      // 187: ldc2_w 1755804833535033075
      // 18a: lload 1
      // 18b: lxor
      // 18c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 191: aastore
      // 192: dup
      // 193: bipush 6
      // 195: sipush 1629
      // 198: ldc2_w 2519086679949179811
      // 19b: lload 1
      // 19c: lxor
      // 19d: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1a2: aastore
      // 1a3: dup
      // 1a4: bipush 7
      // 1a6: sipush 15118
      // 1a9: ldc2_w 8371355176869676737
      // 1ac: lload 1
      // 1ad: lxor
      // 1ae: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b3: aastore
      // 1b4: sipush 4229
      // 1b7: ldc2_w 5613638153364532588
      // 1ba: lload 1
      // 1bb: lxor
      // 1bc: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c1: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 1c4: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.何友何友树何树友友树 Lcn/cool/cherish/value/impl/ModeValue;
      // 1c7: aload 0
      // 1c8: new cn/cool/cherish/value/impl/BooleanValue
      // 1cb: dup
      // 1cc: sipush 26402
      // 1cf: ldc2_w 1620083473586330331
      // 1d2: lload 1
      // 1d3: lxor
      // 1d4: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1d9: sipush 16190
      // 1dc: ldc2_w 3497115217081713381
      // 1df: lload 1
      // 1e0: lxor
      // 1e1: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1e6: bipush 1
      // 1e7: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1ea: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1ed: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.树友树树树友树树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1f0: aload 0
      // 1f1: new cn/cool/cherish/value/impl/NumberValue
      // 1f4: dup
      // 1f5: sipush 22336
      // 1f8: ldc2_w 8154625570511432373
      // 1fb: lload 1
      // 1fc: lxor
      // 1fd: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 202: sipush 258
      // 205: ldc2_w 4569629950275747066
      // 208: lload 1
      // 209: lxor
      // 20a: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 20f: ldc2_w 500.0
      // 212: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 215: dconst_0
      // 216: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 219: ldc2_w 1000.0
      // 21c: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 21f: dconst_1
      // 220: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 223: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 226: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.何树树何何友友树树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 229: aload 0
      // 22a: new cn/cool/cherish/value/impl/BooleanValue
      // 22d: dup
      // 22e: sipush 10489
      // 231: ldc2_w 9127764260690777389
      // 234: lload 1
      // 235: lxor
      // 236: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23b: sipush 5772
      // 23e: ldc2_w 4376882299508583290
      // 241: lload 1
      // 242: lxor
      // 243: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 248: bipush 0
      // 249: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 24c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 24f: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.友友树树何友树树友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 252: aload 0
      // 253: new cn/cool/cherish/value/impl/NumberValue
      // 256: dup
      // 257: sipush 19443
      // 25a: ldc2_w 7731610985404052999
      // 25d: lload 1
      // 25e: lxor
      // 25f: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 264: sipush 21675
      // 267: ldc2_w 6691255168426256747
      // 26a: lload 1
      // 26b: lxor
      // 26c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 271: ldc2_w 2.5
      // 274: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 277: bipush 1
      // 278: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 27b: ldc2_w 6.0
      // 27e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 281: ldc2_w 0.1
      // 284: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 287: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 28a: aload 0
      // 28b: ldc2_w 433593556363932902
      // 28e: lload 1
      // 28f: invokedynamic k (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 294: dup
      // 295: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 298: pop
      // 299: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 29e: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 2a1: checkcast cn/cool/cherish/value/impl/NumberValue
      // 2a4: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.树何友友何友树树友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 2a7: aload 0
      // 2a8: new cn/cool/cherish/value/impl/BooleanValue
      // 2ab: dup
      // 2ac: sipush 30357
      // 2af: ldc2_w 6812778873824906057
      // 2b2: lload 1
      // 2b3: lxor
      // 2b4: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2b9: sipush 13927
      // 2bc: ldc2_w 6028327771332266925
      // 2bf: lload 1
      // 2c0: lxor
      // 2c1: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c6: bipush 1
      // 2c7: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 2ca: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 2cd: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.友何友树何何友树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2d0: aload 0
      // 2d1: new cn/cool/cherish/value/impl/NumberValue
      // 2d4: dup
      // 2d5: sipush 27454
      // 2d8: ldc2_w 5386017068074669806
      // 2db: lload 1
      // 2dc: lxor
      // 2dd: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2e2: sipush 20862
      // 2e5: ldc2_w 2228543872820980879
      // 2e8: lload 1
      // 2e9: lxor
      // 2ea: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2ef: bipush 5
      // 2f0: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2f3: bipush 1
      // 2f4: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2f7: bipush 10
      // 2f9: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 2fc: bipush 1
      // 2fd: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 300: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 303: aload 0
      // 304: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.k ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 309: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 30c: checkcast cn/cool/cherish/value/impl/NumberValue
      // 30f: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.何树树友友友友何何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 312: aload 0
      // 313: new cn/cool/cherish/value/impl/NumberValue
      // 316: dup
      // 317: sipush 4671
      // 31a: ldc2_w 2875713205323788255
      // 31d: lload 1
      // 31e: lxor
      // 31f: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 324: sipush 21070
      // 327: ldc2_w 2605581517672492940
      // 32a: lload 1
      // 32b: lxor
      // 32c: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 331: bipush 5
      // 332: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 335: bipush 1
      // 336: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 339: bipush 10
      // 33b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 33e: bipush 1
      // 33f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 342: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 345: aload 0
      // 346: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.d ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 34b: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 34e: checkcast cn/cool/cherish/value/impl/NumberValue
      // 351: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.树何树何树何友何何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 354: ldc2_w 439714383975513381
      // 357: lload 1
      // 358: invokedynamic R (JJ)[Lcn/cool/cherish/module/Module; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 35d: aload 0
      // 35e: new cn/cool/cherish/value/impl/BooleanValue
      // 361: dup
      // 362: sipush 29211
      // 365: ldc2_w 4186449338505793410
      // 368: lload 1
      // 369: lxor
      // 36a: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 36f: sipush 293
      // 372: ldc2_w 4544618077386767576
      // 375: lload 1
      // 376: lxor
      // 377: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 37c: bipush 0
      // 37d: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 380: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 383: aload 0
      // 384: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.x ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 389: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 38c: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 38f: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.友树友树何树何树何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 392: aload 0
      // 393: new cn/cool/cherish/value/impl/NumberValue
      // 396: dup
      // 397: sipush 31268
      // 39a: ldc2_w 1272575692639733741
      // 39d: lload 1
      // 39e: lxor
      // 39f: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3a4: sipush 31591
      // 3a7: ldc2_w 3744337655596189437
      // 3aa: lload 1
      // 3ab: lxor
      // 3ac: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3b1: ldc2_w 15.0
      // 3b4: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 3b7: dconst_1
      // 3b8: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 3bb: ldc2_w 90.0
      // 3be: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 3c1: dconst_1
      // 3c2: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 3c5: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 3c8: aload 0
      // 3c9: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 3ce: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 3d1: checkcast cn/cool/cherish/value/impl/NumberValue
      // 3d4: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.友树何何树树友树友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 3d7: aload 0
      // 3d8: new cn/cool/cherish/value/impl/BooleanValue
      // 3db: dup
      // 3dc: sipush 4181
      // 3df: ldc2_w 1560838935860735421
      // 3e2: lload 1
      // 3e3: lxor
      // 3e4: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3e9: sipush 3678
      // 3ec: ldc2_w 3522045079062705048
      // 3ef: lload 1
      // 3f0: lxor
      // 3f1: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 3f6: bipush 1
      // 3f7: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 3fa: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 3fd: aload 0
      // 3fe: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.J ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 403: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 406: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 409: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.何友树树友何何友树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 40c: aload 0
      // 40d: new cn/cool/cherish/value/impl/NumberValue
      // 410: dup
      // 411: sipush 23964
      // 414: ldc2_w 559599785637453903
      // 417: lload 1
      // 418: lxor
      // 419: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41e: sipush 27543
      // 421: ldc2_w 47733725820425743
      // 424: lload 1
      // 425: lxor
      // 426: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 42b: ldc2_w 0.85
      // 42e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 431: dconst_0
      // 432: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 435: dconst_1
      // 436: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 439: ldc2_w 0.01
      // 43c: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 43f: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 442: aload 0
      // 443: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.D ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 448: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 44b: checkcast cn/cool/cherish/value/impl/NumberValue
      // 44e: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.树树友友何树树友树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 451: aload 0
      // 452: new cn/cool/cherish/value/impl/BooleanValue
      // 455: dup
      // 456: sipush 14536
      // 459: ldc2_w 3269346832309601542
      // 45c: lload 1
      // 45d: lxor
      // 45e: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 463: sipush 30665
      // 466: ldc2_w 4802332027213253179
      // 469: lload 1
      // 46a: lxor
      // 46b: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 470: bipush 1
      // 471: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 474: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 477: aload 0
      // 478: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.Q ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 47d: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 480: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 483: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.何树树何树友何树何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 486: aload 0
      // 487: new cn/cool/cherish/value/impl/NumberValue
      // 48a: dup
      // 48b: sipush 32715
      // 48e: ldc2_w 2983153371153203757
      // 491: lload 1
      // 492: lxor
      // 493: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 498: sipush 20324
      // 49b: ldc2_w 5110129640648848044
      // 49e: lload 1
      // 49f: lxor
      // 4a0: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4a5: ldc2_w 0.5
      // 4a8: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 4ab: dconst_0
      // 4ac: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 4af: dconst_1
      // 4b0: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 4b3: ldc2_w 0.01
      // 4b6: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 4b9: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 4bc: aload 0
      // 4bd: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.Z ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 4c2: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 4c5: checkcast cn/cool/cherish/value/impl/NumberValue
      // 4c8: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.树何友友树友友何何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 4cb: aload 0
      // 4cc: new cn/cool/cherish/value/impl/BooleanValue
      // 4cf: dup
      // 4d0: sipush 11172
      // 4d3: ldc2_w 4318787896375432792
      // 4d6: lload 1
      // 4d7: lxor
      // 4d8: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4dd: sipush 8190
      // 4e0: ldc2_w 7353159620419609138
      // 4e3: lload 1
      // 4e4: lxor
      // 4e5: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4ea: bipush 0
      // 4eb: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 4ee: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 4f1: aload 0
      // 4f2: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.V ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 4f7: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 4fa: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 4fd: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.友树何树树友树树友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 500: aload 0
      // 501: new cn/cool/cherish/value/impl/NumberValue
      // 504: dup
      // 505: sipush 24696
      // 508: ldc2_w 5073623819689500060
      // 50b: lload 1
      // 50c: lxor
      // 50d: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 512: sipush 9001
      // 515: ldc2_w 2467011189571706614
      // 518: lload 1
      // 519: lxor
      // 51a: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 51f: ldc2_w 0.1
      // 522: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 525: dconst_0
      // 526: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 529: dconst_1
      // 52a: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 52d: ldc2_w 0.01
      // 530: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 533: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 536: aload 0
      // 537: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.f ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 53c: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 53f: checkcast cn/cool/cherish/value/impl/NumberValue
      // 542: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.何友友友友友何何树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 545: aload 0
      // 546: new cn/cool/cherish/value/impl/NumberValue
      // 549: dup
      // 54a: sipush 21149
      // 54d: ldc2_w 7831187360560557912
      // 550: lload 1
      // 551: lxor
      // 552: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 557: sipush 29391
      // 55a: ldc2_w 6544356223812767500
      // 55d: lload 1
      // 55e: lxor
      // 55f: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 564: ldc2_w 5.0
      // 567: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 56a: dconst_1
      // 56b: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 56e: ldc2_w 45.0
      // 571: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 574: dconst_1
      // 575: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 578: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 57b: aload 0
      // 57c: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.N ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 581: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 584: checkcast cn/cool/cherish/value/impl/NumberValue
      // 587: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.何友树树树树树友树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 58a: aload 0
      // 58b: new cn/cool/cherish/value/impl/BooleanValue
      // 58e: dup
      // 58f: sipush 27159
      // 592: ldc2_w 473204547579877312
      // 595: lload 1
      // 596: lxor
      // 597: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 59c: sipush 21949
      // 59f: ldc2_w 394584765604997153
      // 5a2: lload 1
      // 5a3: lxor
      // 5a4: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5a9: bipush 1
      // 5aa: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 5ad: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 5b0: aload 0
      // 5b1: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.H ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 5b6: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 5b9: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 5bc: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.树树树何树树友树何树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 5bf: aload 0
      // 5c0: new cn/cool/cherish/value/impl/NumberValue
      // 5c3: dup
      // 5c4: sipush 14610
      // 5c7: ldc2_w 3864601704301544589
      // 5ca: lload 1
      // 5cb: lxor
      // 5cc: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5d1: sipush 27897
      // 5d4: ldc2_w 8071329130738651419
      // 5d7: lload 1
      // 5d8: lxor
      // 5d9: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 5de: dconst_1
      // 5df: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 5e2: ldc2_w 0.1
      // 5e5: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 5e8: ldc2_w 2.0
      // 5eb: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 5ee: ldc2_w 0.1
      // 5f1: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 5f4: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 5f7: aload 0
      // 5f8: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.G ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 5fd: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 600: checkcast cn/cool/cherish/value/impl/NumberValue
      // 603: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.友友树树何友树树何树 Lcn/cool/cherish/value/impl/NumberValue;
      // 606: aload 0
      // 607: new cn/cool/cherish/value/impl/BooleanValue
      // 60a: dup
      // 60b: sipush 24043
      // 60e: ldc2_w 953681885328056371
      // 611: lload 1
      // 612: lxor
      // 613: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 618: sipush 5432
      // 61b: ldc2_w 3708886908662147315
      // 61e: lload 1
      // 61f: lxor
      // 620: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 625: bipush 1
      // 626: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 629: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 62c: aload 0
      // 62d: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.R ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 632: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 635: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 638: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.树树何树友树友树树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 63b: pop
      // 63c: aload 0
      // 63d: new cn/cool/cherish/value/impl/NumberValue
      // 640: dup
      // 641: sipush 31954
      // 644: ldc2_w 3619202135327539460
      // 647: lload 1
      // 648: lxor
      // 649: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 64e: sipush 29950
      // 651: ldc2_w 1309406823792544001
      // 654: lload 1
      // 655: lxor
      // 656: invokedynamic v (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 65b: dconst_1
      // 65c: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 65f: ldc2_w 0.1
      // 662: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 665: ldc2_w 2.0
      // 668: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 66b: ldc2_w 0.1
      // 66e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 671: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 674: aload 0
      // 675: invokedynamic get (Lcn/cool/cherish/module/impl/combat/友何何友树何树友友友;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/友何何友树何树友友友.U ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 67a: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 67d: checkcast cn/cool/cherish/value/impl/NumberValue
      // 680: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.友何树友友友何树友友 Lcn/cool/cherish/value/impl/NumberValue;
      // 683: aload 0
      // 684: bipush 0
      // 685: ldc2_w 439476322712575938
      // 688: lload 1
      // 689: invokedynamic Ý (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 68e: aload 0
      // 68f: new cn/cool/cherish/utils/树友树友友何何树何何
      // 692: dup
      // 693: lload 3
      // 694: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 697: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.树何友友树树何友友树 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 69a: aload 0
      // 69b: new java/util/ArrayList
      // 69e: dup
      // 69f: invokespecial java/util/ArrayList.<init> ()V
      // 6a2: putfield cn/cool/cherish/module/impl/combat/友何何友树何树友友友.友友树友友何树友何友 Ljava/util/List;
      // 6a5: aload 0
      // 6a6: dconst_0
      // 6a7: ldc2_w 434526957219979866
      // 6aa: lload 1
      // 6ab: invokedynamic Ý (Ljava/lang/Object;DJJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6b0: aload 0
      // 6b1: dconst_0
      // 6b2: ldc2_w 432533908015773463
      // 6b5: lload 1
      // 6b6: invokedynamic Ý (Ljava/lang/Object;DJJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6bb: aload 0
      // 6bc: ldc_w 0.15
      // 6bf: ldc2_w 440311594284890705
      // 6c2: lload 1
      // 6c3: invokedynamic Ý (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6c8: aload 0
      // 6c9: ldc_w 0.15
      // 6cc: ldc2_w 432367937544177304
      // 6cf: lload 1
      // 6d0: invokedynamic Ý (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6d5: aload 0
      // 6d6: fconst_0
      // 6d7: ldc2_w 433637080120295087
      // 6da: lload 1
      // 6db: invokedynamic Ý (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6e0: aload 0
      // 6e1: fconst_0
      // 6e2: ldc2_w 433521815031403188
      // 6e5: lload 1
      // 6e6: invokedynamic Ý (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6eb: aload 0
      // 6ec: fconst_0
      // 6ed: ldc2_w 434262704555293546
      // 6f0: lload 1
      // 6f1: invokedynamic Ý (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 6f6: aload 0
      // 6f7: fconst_0
      // 6f8: ldc2_w 440287592840624279
      // 6fb: lload 1
      // 6fc: invokedynamic Ý (Ljava/lang/Object;FJJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 701: ldc2_w 440139542111840649
      // 704: lload 1
      // 705: invokedynamic R (JJ)Z bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 70a: ifne 71a
      // 70d: bipush 2
      // 70e: anewarray 4
      // 711: ldc2_w 432738766384234464
      // 714: lload 1
      // 715: invokedynamic R (Ljava/lang/Object;JJ)V bsm=cn/cool/cherish/module/impl/combat/友何何友树何树友友友.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 71a: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8390173475481352020L, -6068374408987135846L, MethodHandles.lookup().lookupClass()).a(107952966581450L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 11455557065899L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[71];
      int var7 = 0;
      String var6 = "\u0085®³oz\u008d\u009d-\u009fâ=ÓÉ\u0007\u0015á\u00ad\u0094ç\u009a¸\u0087L\u009còæëëOÀn³ îU\u009aþ\u0080\u008e\u0089Ïß(é\u007fô\\NG½ú\u0099ÅÏ\u001bÜÜÄ4%i¨\u001c§i qlÒ,¾NÆ\nq28T\u000eIÿç\u008cÝ¡éï%»\u0014\nþ.¶\u000f²\u0005%\u0010#à\u0019èOá\u008f!\u0091Sç·\u00959ÇI\u0010\u0085Í/Ïö`\u000f÷\u00ad\u000fî\u0090A¹í6(8²ÑQ\u0003\u0003\u007fm\u001as¥\u000bÈ\u008fÓ9\u0007\u00adìrÀÑ\u0001>É\r\u0094íZ6\u0000i·\u0088\u008d-\n\u0086Ð1 x\u0015ú`8¢TªøáÓA~GP£ø\u009e°7ÎSé\u0095¤/\rÙ-:ï¸\u0018Õº\u0006ÿ\u0083\fIO\u0001R_ÄÎëPÒ¡Ñ¸ýç\u009dÜT\u0010]Ûý\"\u001d\t(Dê\u0093\u0001\u0090%\u000f'û(Ýlx\u0001\u00adìy·÷å \u0002\u009a\nÇ1\u001d=XöT\u0096ø\u009dü\u0013ü|D#\u001e\u009e\u008b\u0091|¿]BÍ» \u0004\u0092¢\u00978\u001d.ó`8YÉá:Û&\u0089\u0087Ý\u0082.h\u0098x\u0092ë\u0098²\"ÄX\u009f\u0010\u0084\u008b8/\u0085K©\u0017÷/ÊÓ]$]M\u0010\u0081íJÁëÒ¸e\u008fOIj@Éû\u008a ×fÂ\u0011\u0006\u0083Ê\u0086hùÏ\u0099\u0015<üá\u001a§²ÿ\u0096Ñ«\u0017%èwP\u0084Û4v\u0018ô¶<ð\u009a\u0085³·¨×ã\u000b\u0091.\u0012¢\u001f?·\u000eÛ\u009eZQ QäÒâøXýÜO$^\r_\u0003]UWiÇ\u00104¨%ãOE2\u0018äï\u0014`\u0010Z\u000b@¯ïþ\u0006\u0011\u0085Ï\u0011m\u0015\u0018â\u0005 é\u0016\u0086u\u0083h\u0088l\u0006ï2À¾µs<%\u0091íëB>àgË+\u0002\u008d¼,äÒ\u0018àd\u0092Ø\u009a=A\u0015@\u001còh×5\\ü^´ìãd\u0002ÝÞ\u0018îô$?â\u0084\u009a\u0098çaT´}\u0081HÍñ\u000fêÆ\u009eáE\u0084\u0010\u009eùñ%ª\u0080\u0017\u001bo\"ÅCÈ\u0007\u0007\u000e\u0018\u00adå\u0010b7UCçmfx¶\bÙÀ\u001e\u0083\u001e¹\u0012\u0080\u000e\u0084Q\u0010Ó\u0006\u0083Öcy´ý'\u0080´\\\u0003 \u0092È\u0018õ¨ø\u001d*\f\u008eîÁ¨¦\u0086hÜ³\u0080\\p_À7QÎ\u001a\u0010w¢%ÈC\u0018]L\u0090×\u009c\u0006` \u008c± j\u0086Ø\u007fp\u009a\u0016 ©ð\u0015\u001e®\"\"\u007f¬×uý¶p«\u0085ë\u0096\u0017f\u0088\u009d=» \u009eü}¬/\u0098\u0004\u008ec\u0001\u0098¬p7\u00847èg3Þï0Ê\u009e\u009ay¥tt×Üp(Î*Ã\u0006\u0080\u0012ÀNOH3>Ôæ\u001coa\u0086?\u0001¼²e7Ûá#\u0004cQ÷~¯\u0003°©5È\u000f¤ !\u0004ÚÙ1\u008c\u009cÿ5Y\u0015<¬\u0003»\u0088º$\u0006\bN¸\\¾.aVAV$r\u0096\u0010ÑÏYÀE¥qiÏ±±\u0091\u0014Xo\u0015 ÉD¨#°Æ\u001f\u009bt×çy´\u0086\u0010»Ú\u009c`CDÚê\u00adö/\u0087\u0000ë^\u0088l\u0018©j\u0086lö\u0017\u0004êÃ jÈ\u001b\u0011ó¯ÿµP\u0084\u0014\u001aTÍ \u0015&Âÿìþï\u0089Ñ lîUHO\u00139äN\u0019Î¬üªys$PPÔÐ\u0084 \u009d\u001e\u0085âwò¼=\u000fõk\u0004¨\u008bË¾üQI\u008b\u0089\u009eä\u0001c1\u0096\u0019\u0013¢\u0080Ú \u009a\u0011,Ôþe\u0018\u001ec¡SË\u0002\u008b\u0087kËh\u0013\u0007\u0095)Ð\u0086¼W\u0087¬ñ¡ó8\u0010U¤\u000bÂ\u008cå÷p\u0019²:\u0002Éi»\u0098 V~\u0080\u000fÉ\u000fÊ\u001eÕL\u001c\u001c\u0096£\u0001 Úþ7Ú\u0096\nõ¢G(\u009d\tÙÏ\u0094  Vç:\u0015E\u008ac\u001fÌj\u0006eA\u000eù\u0019Hô½\u009c¤-ý¶\u001a Ó\\!Uª2 ØL\u0014®µ\u0084võí\u0085]NU\u009fW\u001f\u008b³;tÕ\u0014ò%9K\n¶x\u0092´\u0017 .\u0011Þ\u008cÕ¨\u0010¿\u0096\u008b\u0012ÊZ+ \u008b{\u0083.¼Æ\u0094bJF#\u009a\u0090Z\u000b2\u000e(\u000b\u008aÉºoTØÅ?!àç\u0004éJ/¯%ó\b=£\u0018½û\u0006xÿ/'épeæÕ\"Dz©D\u0018\u0087d\u0002\u009dÙÝö\u000b\u009dð\u0003º\u0016¨GPc4Ý\u0091hü¯\u0093\u0018^iÐ\u0012t\u000es_Ç]\u0095\u009aòøÐÏË\u0019!\u0006|zt\u0018 ©yú\u0018U>©QÙ³A´ë\u0093©·\u0093ß´ZM\u0093èðºÇSµõ*:Â õn\u0099o\u0099¤G5á\u001c\n2/¡\u0092s\u0080Xÿº\u0015\u0003\u001b\u0007òãò]û¨±(0|\u008eT\u0098\u0087\u0001O¬¬\u0096r\u008e+p¼\f\u0014\u0082\u008f8\u0019`ìßý\u000fÎ\u0098å·È\u008e?\u008d\u0086÷\u008d\u0093\u0000$ç¦ '\u0006?M  Ö\u008d\u001býE0jL\u0004+Õ\u0017ùÛá\u0002¦\u000eáx\u0000Òq\u000f\u0013\u0017\u0095\u0096=)\u0015Ï\u0010B8îÖb\u001dÈmÖó×^,<±M ÅmC\u0005<N\u009fÝÿ¨`£KÇ\u000b\u0097\u0097H< \u0098\n\u001aî\u0013\"bB\tªHí\u0018£QÓÝ\u007f¢c\u009b]ï'<NÀÉp>\u0006}\u009a\u0010>z\u00ad\u0010\n0\u0088ú\u0094Ð3YS\u0098UÏÕµ÷2\u0010\u008am\u0007í±Eþ\u0087\u008dÉõ\u0018Ä!¶\u0085 Oyù\u009eªÂ\u001dù8Èâ]øª°©Z0Bâl\u0098\u0018\u0084.æþëcàHá\u00107â5\u0083wkËï:F\u0018UU<\tD\u0018¨ÕÊ\u0018 \u0083\u0083Á\u0094xà\u0093Ç\u0084\"\u0097\u001dm¨p\u0094ñ\u0088\u001d\u0010\u0002òÃn\u009brê`X,×ù\u001cß?U\u0018\u0005ØM\u008eÎØ\u0019¡)%ÖÞ²DÌ\u0084ëlx¨ÐÕ-S(ß°äy´\u008cî±O¡\u0085t¤c:\u001c×W\u00936À]\u000b\t \u009e\u0080^<¦`\u0004¿Í-\u0017>\u0092¿c\u0010\u0097l}J\u0092ÕÁ\u0090KÞKz§ÁÃä\u0018µ\u008dX\u0081'£±\u0002\u0096b\u0003ìíÒ\u0010Ü\\$Ú@ÞùxÝ JÈ¹[-opªÙÔ0cUGo\u0085\u0094\u008bî-I\u0099=®³ÞQ\u0018ÍÝ\u008dÆ\u0018p\u009f\u009d\t\u0014\u0015õ[\u009c¾¡¯W0\u009b\u0001\u009b\u00adµ/¬\u0012ãÑ(éS\u0085\"\u0083\u00ad\u0013E_Rö+^\u0016\u00176\u009ca\u0003~Â_\u0017z(jìNò\u0010\u001bn\u0097Ð\u008fälOVì ûo°~&\u0012ö\u0018ÜÈ5x\u0099²WøaA´\u0088¶úEÌöÕÜ{Ð¬û\u0095\u0018Åö\u001dÛ\u009d¦±øä\u0083>:MÙ+º\u0085r¸»ÀÚ!\u0086 Ômp\u0083Åç\u0012W D\u0013\u0088a\u00ad][9Ñ©m!ØmÑ^o(lo×óÑ\u0010K]XÖ~W\u001f0\u009eÑ÷ÝiÞgß v®ÂÄ\u009d\u008b¨%kUý$¨¾\u001c>ðqc|§\u0097\u0002¸âÚ©`\u0095Â\u0098É\u0018rWÜ~6¶\u0085©\u008c°\u008c6$7!\u0083V¯õ3æ\u001b\u009có";
      short var8 = 1924;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[71];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u0000>à\u0015$\u000fë\u0099\u007f\t\f\u001duOÛä§Js\u0091M\u0085í\"¼\u001f\u0090v\u0098Î¶\u0091(«å\u0013w\u009eÊM\u00ad¥ò\u0018T\u0015³2³ç\u0017\u009d\u000e\u0017ðþ©[9¨¸¶\u009b-q.\u0004Q**\u0010\u0004\u0093";
                  var8 = 73;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private void D() {
      long a = 友何何友树何树友友友.a ^ 8976259116844L;
      long ax = a ^ 61413501457531L;
      c<"R">(2352946521306192792L, a);
      c<"k">(this, 2359183648281859934L, a).clear();
      Iterator var6 = Cherish.instance.S().W(c<"k">(this, 2352595816604159527L, a).getValue().floatValue() + 1.0F, ax).iterator();
      if (var6.hasNext()) {
         LivingEntity entity = (LivingEntity)var6.next();
         if (this.k(entity)) {
            c<"k">(this, 2359183648281859934L, a).add(entity);
         }
      }

      c<"k">(this, 2359183648281859934L, a).sort(this.q());
   }

   private Vec2 D(Vec2 vec) {
      long a = 友何何友树何树友友友.a ^ 17527389533458L;
      return new Vec2(Mth.wrapDegrees(c<"k">(vec, -394560120157638673L, a)), Mth.wrapDegrees(c<"k">(vec, -388890069693261422L, a)));
   }

   private Rotation Z(LivingEntity entity, double heightOffset) {
      long a = 友何何友树何树友友友.a ^ 94543859397518L;
      long ax = a ^ 53088308692287L;
      long axx = a ^ 100163558388648L;
      c<"R">(-286816746480236742L, a);
      if (this.w(new Object[]{ax})) {
         return null;
      } else {
         float currentYaw = mc.player.getYRot();
         float currentPitch = mc.player.getXRot();
         double entityX = entity.getX();
         double entityY = entity.getY();
         double entityZ = entity.getZ();
         double posX = entityX - mc.player.getX();
         double posY = entityY + entity.getBbHeight() * heightOffset - (mc.player.getY() + mc.player.getEyeHeight());
         double posZ = entityZ - mc.player.getZ();
         double dX = entityX - c<"k">(entity, -279382509215450614L, a);
         double dZ = entityZ - c<"k">(entity, -281424147177442128L, a);
         double dX2 = dX - c<"k">(this, -281308261524088763L, a);
         double dZ2 = dZ - c<"k">(this, -279360497981879032L, a);
         c<"Ý">(this, dX, -281308261524088763L, a);
         c<"Ý">(this, dZ, -279360497981879032L, a);
         double targetYawCalc = Math.toDegrees(Math.atan2(posZ, posX)) - 90.0;
         double yawDiffToTarget = Math.abs(Mth.wrapDegrees((float)(currentYaw - targetYawCalc)));
         double aimStrength = Math.max(0.1, Math.min(0.8, yawDiffToTarget / 45.0));
         if (yawDiffToTarget > c<"k">(this, -287528322840972232L, a).getValue().doubleValue() && yawDiffToTarget < 120.0) {
            double dist = Math.sqrt(posX * posX + posZ * posZ);
            double predictionTime = Math.min(dist / 25.0, 0.3);
            posX += dX * aimStrength * predictionTime * 3.0;
            posZ += dZ * aimStrength * predictionTime * 3.0;
            posX += dX2 * aimStrength * predictionTime * predictionTime * 1.5;
            posZ += dZ2 * aimStrength * predictionTime * predictionTime * 1.5;
         }

         double horizontalDistance = Math.sqrt(posX * posX + posZ * posZ);
         float yaw = (float)(Math.toDegrees(Math.atan2(posZ, posX)) - 90.0);
         float pitch = (float)(-Math.toDegrees(Math.atan2(posY, horizontalDistance)));
         yaw = Mth.wrapDegrees(yaw);
         pitch = Mth.clamp(pitch, -90.0F, 90.0F);
         float yawDiffSmooth = Mth.wrapDegrees(yaw - currentYaw);
         float pitchDiffSmooth = pitch - currentPitch;
         float smoothF = (float)(0.3F + aimStrength * 0.2F);
         yaw = currentYaw + yawDiffSmooth * smoothF;
         pitch = currentPitch + pitchDiffSmooth * smoothF;
         return new Rotation(axx, yaw, pitch);
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 44;
               case 2 -> 6;
               case 3 -> 5;
               case 4 -> 63;
               case 5 -> 28;
               case 6 -> 3;
               case 7 -> 40;
               case 8 -> 0;
               case 9 -> 57;
               case 10 -> 13;
               case 11 -> 48;
               case 12 -> 55;
               case 13 -> 29;
               case 14 -> 8;
               case 15 -> 10;
               case 16 -> 37;
               case 17 -> 60;
               case 18 -> 26;
               case 19 -> 22;
               case 20 -> 39;
               case 21 -> 30;
               case 22 -> 54;
               case 23 -> 23;
               case 24 -> 36;
               case 25 -> 52;
               case 26 -> 14;
               case 27 -> 33;
               case 28 -> 15;
               case 29 -> 32;
               case 30 -> 53;
               case 31 -> 27;
               case 32 -> 42;
               case 33 -> 16;
               case 34 -> 17;
               case 35 -> 24;
               case 36 -> 19;
               case 37 -> 9;
               case 38 -> 49;
               case 39 -> 20;
               case 40 -> 31;
               case 41 -> 47;
               case 42 -> 45;
               case 43 -> 51;
               case 44 -> 46;
               case 45 -> 1;
               case 46 -> 34;
               case 47 -> 12;
               case 48 -> 38;
               case 49 -> 35;
               case 50 -> 58;
               case 51 -> 2;
               case 52 -> 56;
               case 53 -> 18;
               case 54 -> 59;
               case 55 -> 11;
               case 56 -> 21;
               case 57 -> 25;
               case 58 -> 61;
               case 59 -> 62;
               case 60 -> 43;
               case 61 -> 41;
               case 62 -> 4;
               default -> 7;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友何何友树何树友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   @EventTarget
   public void b(Render2DEvent event) {
      long a = 友何何友树何树友友友.a ^ 13645977049252L;
      c<"R">(1670655304130587664L, a);
      if (c<"k">(this, 1672067803204741123L, a).C(b<"v">(23555, 1731928855483494618L ^ a))) {
         this.x();
      }

      if (c<"k">(this, 1672067803204741123L, a).C(b<"v">(14310, 8950833278913633038L ^ a))) {
         this.j();
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 31697;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友何何友树何树友友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   @EventTarget
   public void x(LivingUpdateEvent event) {
      long a = 友何何友树何树友友友.a ^ 97765270306066L;
      long ax = a ^ 112073148427627L;
      c<"R">(8257640901816027558L, a);
      this.T(c<"k">(this, 8258062676963467306L, a).getValue());
      if (!c<"k">(this, 8252486035380430121L, a).getValue() || !this.y()) {
         if (c<"k">(this, 8251214973314436533L, a).C(b<"v">(23555, 1732012966741529964L ^ a))) {
            this.D();
            LivingEntity target = null;
            if (!c<"k">(this, 8251669583648867680L, a).isEmpty()) {
               target = (LivingEntity)c<"k">(this, 8251669583648867680L, a).get(0);
            }

            c<"Ý">(this, null, 8252309241822432541L, a);
            c<"Ý">(this, null, 8250988856075368109L, a);
            c<"Ý">(this, c<"k">(this, 8252309241822432541L, a), 8250988856075368109L, a);
            c<"Ý">(this, RotationUtils.z(new Object[]{target, ax}), 8252309241822432541L, a);
         }
      }
   }

   private void x() {
      long a = 友何何友树何树友友友.a ^ 118983669275463L;
      long ax = a ^ 10458978905590L;
      long axx = a ^ 13764802572181L;
      long axxx = a ^ 86080921151765L;
      long axxxx = a ^ 108656685341537L;
      c<"R">(1498639279014375411L, a);
      if (!c<"k">(this, 1500697644905431932L, a).getValue() || !this.y()) {
         boolean isLeftClicking = c<"k">(mc, 1498648204122865042L, a).isLeftPressed();
         if (c<"k">(this, 1498875574772139283L, a).getValue() && c<"k">(this, 1499493066923199764L, a) && !isLeftClicking) {
            c<"Ý">(this, null, 1500581951711325000L, a);
            c<"Ý">(this, null, 1500915268073181432L, a);
         }

         c<"Ý">(this, isLeftClicking, 1499493066923199764L, a);
         boolean shouldAim = !c<"k">(this, 1498875574772139283L, a).getValue() || isLeftClicking;
         if (shouldAim && !this.w(new Object[]{ax}) && c<"k">(this, 1500581951711325000L, a) != null && c<"k">(this, 1500915268073181432L, a) != null) {
            float partialTicks = mc.getFrameTime();
            Rotation rotations = new Rotation(
               axxxx,
               c<"k">(this, 1500915268073181432L, a).getYaw()
                  + (c<"k">(this, 1500581951711325000L, a).getYaw() - c<"k">(this, 1500915268073181432L, a).getYaw()) * partialTicks,
               c<"k">(this, 1500915268073181432L, a).J(new Object[]{axx})
                  + (c<"k">(this, 1500581951711325000L, a).J(new Object[]{axx}) - c<"k">(this, 1500915268073181432L, a).J(new Object[]{axx})) * partialTicks
            );
            float strength = 友树树何何树树何何树.k(
               axxx, c<"k">(this, 1499216896636476919L, a).getValue().intValue() * 30, c<"k">(this, 1500197293717702562L, a).getValue().intValue() * 30
            );
            double sensitivity = (Double)c<"k">(mc, 1499729491085989094L, a).sensitivity().get() * 0.6F + 0.2F;
            double gcd = sensitivity * sensitivity * sensitivity * 8.0;
            float deltaYaw = (float)((rotations.getYaw() - mc.player.getYRot()) * (strength / 100.0F) * gcd);
            float deltaPitch = (float)((rotations.J(new Object[]{axx}) - mc.player.getXRot()) * (strength / 100.0F) * gcd);
            mc.player.turn(deltaYaw, deltaPitch);
         }
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友何何友树何树友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'k' && var8 != 221 && var8 != 'B' && var8 != 198) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 237) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'R') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'k') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 221) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'B') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private Vec2 h(Vec3 position) {
      long a = 友何何友树何树友友友.a ^ 136549393544306L;
      Vec3 playerPos = new Vec3(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ());
      Vec3 diff = position.subtract(playerPos);
      double horizontalDistance = Math.sqrt(
         c<"k">(diff, -289441248616228842L, a) * c<"k">(diff, -289441248616228842L, a)
            + c<"k">(diff, -289571056036320819L, a) * c<"k">(diff, -289571056036320819L, a)
      );
      float yaw = (float)Math.toDegrees(Math.atan2(c<"k">(diff, -289571056036320819L, a), c<"k">(diff, -289441248616228842L, a))) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(c<"k">(diff, -288354995143625790L, a), horizontalDistance)));
      return new Vec2(Mth.wrapDegrees(yaw), Mth.clamp(pitch, -90.0F, 90.0F));
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   @EventTarget
   public void l(Render3DEvent event) {
      long a = 友何何友树何树友友友.a ^ 10627983340652L;
      long ax = a ^ 118878885921501L;
      long axx = a ^ 115557442928830L;
      long axxx = a ^ 121435788453632L;
      long axxxx = a ^ 103829246232674L;
      long axxxxx = a ^ 102277494990602L;
      c<"R">(-4906854422498918184L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"k">(this, -4900931186151111477L, a).C(b<"v">(7590, 2385548978503540105L ^ a))) {
            if (!c<"k">(this, -4901911926148813737L, a).getValue() || !this.y()) {
               if (c<"k">(c<"k">(mc, -4901190061876888627L, a), -4907075632618466314L, a).isDown()) {
                  c<"k">(this, -4908476909377461737L, a).U(axxxx);
               }

               if (!c<"k">(this, -4907103930633082312L, a).getValue()
                  || !c<"k">(this, -4908476909377461737L, a).Y(c<"k">(this, -4903639421675104688L, a).getValue().longValue(), axxx)) {
                  this.D();
                  if (!c<"k">(this, -4900619514475475938L, a).isEmpty()) {
                     LivingEntity target = (LivingEntity)c<"k">(this, -4900619514475475938L, a).get(0);
                     Rotation headRotation = c<"k">(this, -4907345473301456958L, a).getValue()
                        ? this.Z(target, c<"k">(this, -4908791207299885835L, a).getValue().doubleValue())
                        : null;
                     Rotation bodyRotation = c<"k">(this, -4901579822545391262L, a).getValue()
                        ? this.Z(target, c<"k">(this, -4900241423045374034L, a).getValue().doubleValue())
                        : null;
                     Rotation feetRotation = c<"k">(this, -4901049342518787912L, a).getValue()
                        ? this.Z(target, c<"k">(this, -4901703068716989721L, a).getValue().doubleValue())
                        : null;
                     double distHead = Math.abs(mc.player.getXRot() - headRotation.J(new Object[]{axx}));
                     double distBody = Math.abs(mc.player.getXRot() - bodyRotation.J(new Object[]{axx}));
                     double distFeet = Math.abs(mc.player.getXRot() - feetRotation.J(new Object[]{axx}));
                     if (c<"k">(this, -4907345473301456958L, a).getValue() && headRotation != null && distHead <= distBody && distHead <= distFeet) {
                     }

                     if (c<"k">(this, -4901579822545391262L, a).getValue() && bodyRotation != null && distBody <= distFeet) {
                     }

                     if (c<"k">(this, -4901049342518787912L, a).getValue() && feetRotation != null) {
                     }

                     if (headRotation != null) {
                     }

                     if (bodyRotation != null) {
                     }

                     if (feetRotation != null) {
                     }

                     Rotation finalRotation = RotationUtils.F(new Object[]{axxxxx, target});
                     if (finalRotation != null) {
                        float yaw = finalRotation.getYaw();
                        float pitch = finalRotation.J(new Object[]{axx});
                        if (c<"k">(this, -4900365657960437779L, a).getValue()) {
                           mc.player.setYRot(this.N(mc.player.getYRot(), yaw, c<"k">(this, -4900089971395054941L, a).getValue().floatValue(), true));
                        }

                        if (c<"k">(this, -4903704989850781128L, a).getValue()) {
                           mc.player.setXRot(this.N(mc.player.getXRot(), pitch, c<"k">(this, -4901984387166296797L, a).getValue().floatValue(), false));
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "zjSP\fAu*\u001e[\u0006\\pw\u0015\u001d\u000eA}q\u0011VMGtt\u0011\u001d\u0000Atf\u001cGM句佌佑厶栢伶栿叒叏厶";
      j[1] = "`\u0006\u0005l~RoFHgtOj\u001bC!g\\o\u001dN!xPs\u0004\u0005B~Yf>JcdX";
      j[2] = " &_5\u0011\u0006/f\u0012>\u001b\u001b*;\u0019x\u0013\u0006'=\u001d3P\u0000.8\u001dx\u001d\u0006.*\u0010\"P\"*$\u001d\u0017\u000b\u001b\"";
      j[3] = "mySgLuYZ\\'\u0001~SGYz\n8[ZT|\u000es\u0018x_m\u0017zS\u000e";
      j[4] = "\u000f\fW\u0017o6\u0004\u0003FX\u0013/\u000b\u0019H\u001b$\u001f\u001d\u000eD\u000653\n\u0003";
      j[5] = float.class;
      k[5] = "java/lang/Float";
      j[6] = double.class;
      k[6] = "java/lang/Double";
      j[7] = "p Gb>q\u007f`\ni4lz=\u0001/'\u007f\u007f;\f/8sc\"GC>q\u007f+\bo\u0007\u007f\u007f;\f";
      j[8] = "w\u0014@tZmxT\r\u007fPp}\t\u00069Xmp\u000f\u0002r\u001bO{\u001e\u001b{P";
      j[9] = boolean.class;
      k[9] = "java/lang/Boolean";
      j[10] = "L 9<eRx\u00036|(Yr\u001e3!#\u001fz\u0003>''T9!56>]rW";
      j[11] = void.class;
      k[11] = "java/lang/Void";
      j[12] = "{!$3\u001bVtai8\u0011Kq<b~\u0019V|:f5Z佬位厄佟伅县佬位桞栛";
      j[13] = "\u0005m\u0002;Z:\n-O0P'\u000fpDvC4\nvIv\\8\u0016o\u0002\u0016@8\u0004f^\u000eT9\u0013f";
      j[14] = ")'\u001e?P\u0014)'\tc\\\u001b3l\t}T\u0018)6D\\T\u0013\"!\u0018p[\t";
      j[15] = "|\u0005wO\u0015P|\u0005`\u0013\u0019_fN`\r\u0011\\|\u0014-.\bM{\u000fm\u0012";
      j[16] = "c*9\u00166x}\"#YTdz?";
      j[17] = "8L\u0001l1c8L\u00160=l\"\u0007\u0016.5o8][\t9s\u001bH\u000525d1";
      j[18] = "\u001f'T\u007fn\n\u0010g\u0019td\u0017\u0015:\u00122t\u0011\u0015%\t2栐厮桭厂厱佉佔桴伩伜";
      j[19] = "f$q\n&'id<\u0001,:l97G<<l&,G!-i::\u001bg\u001aj>>\u001d 'k";
      j[20] = "pl\u0018I5Ppl\u000f\u00159_j'\u001b\b*Uz'\u001c\u000f!J0A\u0005\u0013\n\\m|\u0000\u0013";
      j[21] = ")4\u0014-bR)4\u0003qn]3\u007f\u0003l}^i\u0013\fllP\u0017>\u0013";
      j[22] = "7=;{+\u001b7=,''\u0014-v8:4\u001e=v?=?\u0001w\u0010&!\u0014\u0017*-#!b& (*";
      j[23] = int.class;
      k[23] = "java/lang/Integer";
      j[24] = "=(A\u001f|#=(VCp,'cB^c&7cP_e#'4\u001b}x<:#Rt\u007f>:9L";
      j[25] = "V|J8V\u0015V|]dZ\u001aL7IyI\u0010\\7N~B\u000f\u0016O[u\t";
      j[26] = "\u0007\\`Y\u00077\u0007\\w\u0005\u000b8\u001d\u0017c\u0018\u00182\r\u0017d\u001f\u0013-Goq\u0014Y";
      j[27] = "b7=\tx\bb7*Ut\u0007x|*K|\u0004b&gjz\u0014\u007f7\u0001F{\u0005`7;";
      j[28] = "\u000b\b\u0002D)f\u0000\u0007\u0013\u000bHh\u000b\f\u0017Q";
      j[29] = "\u001bCsh\u0019 @\u0000)>hv,K&hY',rx=PyK\tzo\u0016{";
      j[30] = "V\u00136\\#!SI#2伞栄桴伮伕叱厀栄桴厰H\u0003#|SLx\u0003=rS";
      j[31] = "tT*>!'q\u000e?P桘栂伒栭厗桉厂栂桖栭Tm{f>I;=z\u007f$";
      j[32] = "p4!Ei$un4+栐佅伖厗伂叨及栁桒厗_\u00173e5;0Bp`2";
      j[33] = "y}b(\u0004>\">8~uhNu7(D>NL:k\u0019ig19'\u0010t";
      j[34] = ">\u0010\u001dw&?;J\b\u0019厅栚佘桩伾叚桟栚栜桩c%:oj\u000e\u001e&vfw";
      j[35] = "\u0001\u001c]x!q\u0004FH\u0016厂厎栣县叠佋桘厎佧县#|/*CA\u0018o:<\u0007";
      j[36] = "\u0003=*t-1\u0006g?\u001a厎栔佥厞桍佇桔収叻伀T#u3_a; 4qG";
      j[37] = "e\u0019\u0017<#q:DU?D\u0012\\GL'$v0\u0000\u001f-&Ic\u001d\\?&&dDRkD";
      j[38] = "\u0006fR\u000f\u001bA\u0003<Ga厸传栤叅可桸伦厾叾叅,\u000fAMDfP^\u001aFR";
      j[39] = "\u00190y_6\u0003\u0017#gFZ叼栰厞叆佩伇叼佴桄叆4jRU6i\bdAK/";
      j[40] = "?/yPzb:ul>叙厝栝桖佚叽栃桇余桖\u0007\u000fz?:p7\u000fd1:";
      j[41] = "'v-w\u00002\",8\u0019伽栗栅叕桊栀厣栗叟栏Su\u0003e%i!k\t1!";
      j[42] = "c{'Og6rq0\u0019\u001c\u001aI[\u0002<\u001c>jry\u0004z/`e/";
      j[43] = ".}Dx/j+'Q\u0016伒厕栌栄栣栏伒桏取栄:'/7+\"\n'19+";
      j[44] = "X\"cA\u0017k]xv/桮桎桺伟栄栶厴桎伾桛\u001d\u0012M*\u0012?rBL3\b";
      j[45] = "\u0004%;E!>\u0001\u007f.+(\u0002\u0005>\u007f\u0011;eC>$\u0017A8D\u007f\u007fQ&~D$y+";
      j[46] = " U{*_\u001e%\u000fnD栦使变叶栜厇叼使但叶\u0005u_C%\n5uAM%";
      j[47] = "\u00028\r7:]\u00104^8DW<`_}{\u0006<Q\u000b,6]S>\u001e)4X";
      j[48] = "]\u0011\b@N\rXK\u001d.叭栨厥伬伫佳叭栨伻桨v\u0012\u0014L\u0018\u001e\u0019GWI\u001f";
      j[49] = "@E\u0018\u0005G\fE\u001f\rk古右桢格伻厨栾栩厸格fV\u001dM\nX\t\u0006\u001cT\u0010";
      j[50] = "NA\u001a\u0006:<K\u001b\u000fh厙栙桬叢桽桱厙參厶佼dT`}\u000bN\u000b\u0001#x\f";
      j[51] = "<o;a1M95.\u000f伌厲叄双历双伌伬栞双E>1\u001090u>/\u001e9";
      j[52] = "VFB\u0014;^S\u001cWz厘桻估佻叿档厘桻桴句<\u00168\tTYN\b2]P";
      j[53] = "iD#_AAyOb\u0018}I^\rh[B\u001f^=n]\u0000YfR;\u001e\u0005^";
      j[54] = "\u000eTg3jA\u000b\u000er]叉传叶栭佄伀叉桤佨栭\u0019`0\u0000DIv01\u0019^";
      j[55] = "'&A#L\t\"|TM可佨栅厅叼厎佱栬叟厅?|LT\"y\u000f|RZ\"";
      j[56] = "\u0012\u0002Q\u0004\u000e\\\u0000\u000e\u0002\u000bpV,Z\u0003NN\u0006,kS\u0017O\b@[\u0007J\u001cF";
      j[57] = "\u0003\u001cQ&/\\\u0006FDH桖伽叻县佲压桖桹叻伡/y/\u0001\u0006C\u001fy1\u000f\u0006";
      j[58] = "kn#\u001c<\u001fn46r原栺伍栗桄厱桅栺厓栗]Of^!s2\u001fgG;";
      j[59] = "\u000b3\u0000E\u001ej\u000ei\u0015+伣厕栩桊伣栲厽伋右桊~\u0017D+N<\u0011B\u0007.I";
      j[60] = "&c60#@} lfR\u0016\u0011kc0cB\u0011Rns>\u00178/m?7\n";
      j[61] = ">q\u0010H\u001fM;+\u0005&伢桨栜佌桷句伢桨佘佌n\u001bE\ftl\u0001KD\u0015n";
      j[62] = "\u0016DA[_u\u0013\u001eT5叼桐佰佹栦叶栦厊佰栽?\tC%BZB\n\u000f,_";
      j[63] = "\f+\u0005TyS\tq\u0010:佄桶栮厈厸叹叚伲佪厈{\u000by\u000e\ttK\u000bg\u0000\t";
      j[64] = "\u0001\u000ffAgZ\u0018Z4^\u0016F7Vc\u0004&\u00117feDzG\u001e\u001bf\bsZ";
      j[65] = "\u0013g\u007f0\u0019<\u0016=j^桠佝栱佚栘伃厺佝併佚\u0001o\u0019a\u001681o\u0007o\u0016";
      j[66] = "t\u0013J?N\u0017mF\u0018 ?\u000bBJOz\u0000TBzI:S\nk\u0007JvZ\u0017";
      j[67] = "UR5@uHP\b .佈厷桷栫厈佳佈厷桷栫K\u0013/\t\u001fO$C.\u0010\u0005";
      j[68] = "qh,t9\u000eacm3\u0005\u0006F!gp:QF\u0011avx\u0016~~45}\u0011";
      j[69] = "s22\u000bg\u0012vh'e叄佳桑厑休厦叄叭伕厑L[dE\"41\u0019{G+";
      j[70] = "\u0004A\u0016\u0010\u001cD\u0001\u001b\u0003~伡去佢叢桱伣桥去叼核hGDFX\u001d\u0007D\u0005\u0004@";
      j[71] = "!\u0018\u001c\u000bTU$B\te栭桰栃去桻伸栭伴佇伥b\n^Q{H\u0019\b\f\u0017y";
      j[72] = "@ULh\u001c\u001a\u001f\b\u000ek{sy\u000b\u0017s\u001b\u001d\u0015LDy\u0019\"";
      j[73] = "%\u001aO\"XD7\u0016\u001c-&N\u001bB\u001dh\u0018\u001f\u001bsE/DCw\u0003\u0014)]\u0011";
      j[74] = "fJ$]\u0018\u0016c\u001013去栳伀佷桃株去栳厞佷Z\u0002\u0018Kc\u0015j\u0002\u0006Ec";
      j[75] = "\u0003>aA6\u0006\u0006dt/厕栣叻桇佂栶伋栣佥厝\u001f\u0012lGI#pBm^S";
      j[76] = "IX\u007f'n\u0004L\u0002jI栗叻桫校栘厊栗校伯校\u0001t4E\u0003En$5\\\u0019";
      j[77] = ",>\u0005\u007fOh)d\u0010\u0011佲伉叔桇桢叒佲厗叔厝{ O5)aK Q;)";
      j[78] = "\u007f\u0003JVxE+\u001aKRG\u0014BGY\\-\u001f?\u0005F^$y";
      j[79] = "G&bN+s\u0013{1\u0000\u0010-yvgF!}yG6G!s\u0011z`\u0010.<";
      j[80] = "N+aW#YKqt9伞伸伨厈栆佤桚桼桬伖\u001f\u0005y\u0018\u000b$pP:\u001d\f";
      j[81] = "\u0007\u0014F\r+\u0010\u0002NSc伖可栥伩叻伾伖栵叿桭8_qQB\u001bW\n2TE";
      j[82] = "e/)@\u0017}|z{_faSv,\u0005V7SF*E\n`z;)\t\u0003}";
      j[83] = "][I\u000bIdX\u0001\\e栰伅厥司栮桼佴厛厥栢7\t\u0012f\u001f\u0002\b\u0004U=\u0018";
      j[84] = "\u000fr?%>L\n(*K桇桩号发伜桒桇厳栭住Az>\u0011\n-qz \u001f\n";
      j[85] = "]7h%\u0004?Xm}K伹叀桿桎栏桒桽叀桿桎\u0016z\u0004bXh&z\u001alX";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private boolean k(LivingEntity entity) {
      long a = 友何何友树何树友友友.a ^ 90676668276837L;
      long ax = a ^ 61351166056148L;
      long axx = a ^ 76919326036481L;
      long axxx = a ^ 9444538978388L;
      c<"R">(8065386408079267025L, a);
      if (!this.w(new Object[]{ax})
         && 树树树何友友树友友友.P(entity, axx, true)
         && !entity.isDeadOrDying()
         && !(entity.getHealth() <= 0.0F)
         && RotationUtils.r(axxx, c<"k">(this, 8067887255013689497L, a).getValue().floatValue(), entity)) {
         boolean hasLineOfSight = mc.player.hasLineOfSight(entity);
         if (hasLineOfSight) {
            c<"k">(this, 8065739397668307310L, a).getValue().floatValue();
         }

         if (c<"k">(this, 8066018235273780498L, a).getValue()) {
            c<"k">(this, 8066614285874785880L, a).getValue().floatValue();
         }

         return false;
      } else {
         return false;
      }
   }

   protected void t() {
      long a = 友何何友树何树友友友.a ^ 17146424646028L;
      long ax = a ^ 116737586720573L;
      c<"R">(-7636029275593577160L, a);
      if (!this.w(new Object[]{ax})) {
         c<"Ý">(this, mc.player.getYRot(), -7630816770424672590L, a);
         c<"Ý">(this, mc.player.getXRot(), -7630962570585980247L, a);
         c<"Ý">(this, 0.0, -7630560373089619385L, a);
         c<"Ý">(this, 0.0, -7629703050148911350L, a);
         c<"Ý">(this, 0.0F, -7630296705622578313L, a);
         c<"Ý">(this, 0.0F, -7637747590687528822L, a);
         c<"Ý">(this, 0.15F, -7637753965552489908L, a);
         c<"Ý">(this, 0.15F, -7629829584096504187L, a);
         this.L();
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void j() {
      long a = 友何何友树何树友友友.a ^ 132566449266944L;
      c<"R">(7965505297522365876L, a);
      if (!c<"k">(this, 7968160938636605755L, a).getValue() || !this.y()) {
         if (!c<"k">(this, 7965187422231527252L, a).getValue() || c<"k">(c<"k">(mc, 7968847549816827553L, a), 7965426895036139162L, a).isDown()) {
            this.D();
            if (c<"k">(this, 7967415019130476914L, a).isEmpty()) {
               return;
            }

            Player target = null;

            for (LivingEntity entity : c<"k">(this, 7967415019130476914L, a)) {
               if (entity instanceof Player player) {
                  target = player;
                  break;
               }
            }

            Vec2 currentLookAngles = new Vec2(mc.player.getYRot(), mc.player.getXRot());
            Vec3 ePos = target.position();
            Vec3 eHeadPos = ePos.add(new Vec3(0.0, target.getEyeHeight(), 0.0));
            Vec2 anglesFoot = this.h(ePos);
            Vec2 anglesHead = this.h(eHeadPos);
            Vec2 difference = this.D(currentLookAngles.negated().add(anglesHead));
            Vec2 differenceFoot = this.D(currentLookAngles.negated().add(anglesFoot));
            float targetYaw = (float)(
               c<"k">(currentLookAngles, 7968075864161811453L, a)
                  + c<"k">(difference, 7968075864161811453L, a) / c<"k">(this, 7965663009993420330L, a).getValue().doubleValue()
            );
            if (c<"k">(currentLookAngles, 7964640042793307520L, a) > c<"k">(anglesFoot, 7964640042793307520L, a)
               || c<"k">(currentLookAngles, 7964640042793307520L, a) < c<"k">(anglesHead, 7964640042793307520L, a)) {
               float targetPitchFoot = (float)(
                  c<"k">(currentLookAngles, 7964640042793307520L, a)
                     + c<"k">(differenceFoot, 7964640042793307520L, a) / c<"k">(this, 7965663009993420330L, a).getValue().doubleValue()
               );
               float targetPitchHead = (float)(
                  c<"k">(currentLookAngles, 7964640042793307520L, a)
                     + c<"k">(difference, 7964640042793307520L, a) / c<"k">(this, 7965663009993420330L, a).getValue().doubleValue()
               );
               float diffFoot = Math.abs(c<"k">(currentLookAngles, 7964640042793307520L, a) - targetPitchFoot);
               float diffHead = Math.abs(c<"k">(currentLookAngles, 7964640042793307520L, a) - targetPitchHead);
               float targetPitch = diffFoot > diffHead ? targetPitchHead : targetPitchFoot;
               if (!c<"k">(this, 7965694770037347666L, a).getValue()) {
                  mc.player.setXRot(targetPitch);
               }

               mc.player.setYRot(targetYaw);
            }

            if (!c<"k">(this, 7965694770037347666L, a).getValue()) {
               mc.player.setXRot(c<"k">(currentLookAngles, 7964640042793307520L, a));
            }

            mc.player.setYRot(targetYaw);
         }
      }
   }

   private Comparator<LivingEntity> q() {
      long a = 友何何友树何树友友友.a ^ 88464011973675L;
      long ax = a ^ 110710456107555L;
      String var6 = c<"k">(this, 1991577157832722707L, a).getValue();
      c<"R">(1990591283756556447L, a);
      byte var7 = -1;
      switch (var6.hashCode()) {
         case 353103893:
            if (!var6.equals(b<"v">(21976, 3065033713020286339L ^ a))) {
               break;
            }

            var7 = 0;
         case -2137395588:
            if (!var6.equals(b<"v">(22846, 117501662902565201L ^ a))) {
               break;
            }

            var7 = 1;
         case 70829:
            if (!var6.equals(b<"v">(10129, 4352106456392452037L ^ a))) {
               break;
            }

            var7 = 2;
         case 1041377119:
            if (!var6.equals(b<"v">(2983, 5002236815808195570L ^ a))) {
               break;
            }

            var7 = 3;
         case -1415550666:
            if (!var6.equals(b<"v">(13333, 7059585365695747167L ^ a))) {
               break;
            }

            var7 = 4;
         case 63533343:
            if (!var6.equals(b<"v">(24594, 9219246409655418955L ^ a))) {
               break;
            }

            var7 = 5;
         case 1179233083:
            if (!var6.equals(b<"v">(28502, 8447339640138272521L ^ a))) {
               break;
            }

            var7 = 6;
         case -255982230:
            if (var6.equals(b<"v">(11967, 4072071810540555928L ^ a))) {
               var7 = 7;
            }
      }
      return switch (var7) {
         case 0 -> Comparator.comparingDouble(e -> RotationUtils.O(e));
         case 1 -> Comparator.comparingDouble(LivingEntity::getHealth);
         case 2 -> Comparator.comparingDouble(this::R);
         case 3 -> Comparator.comparingDouble(RotationUtils::R);
         case 4 -> (ax, b) -> {
            long ax = 友何何友树何树友友友.a ^ 29031561409038L;
            return Integer.compare(c<"k">(b, -175607669055846735L, ax), c<"k">(ax, -175607669055846735L, ax));
         };
         case 5 -> (ax, b) -> {
            long ax = 友何何友树何树友友友.a ^ 132107891224332L ^ 14764905836053L;
            return Integer.compare(树友友何树友树树树何.M(b, ax), 树友友何树友树树树何.M(ax, ax));
         };
         case 6 -> (ax, b) -> {
            long ax = 友何何友树何树友友友.a ^ 12599259749822L ^ 138804845141159L;
            double scoreA = ax.getHealth() / (树友友何树友树树树何.M(ax, ax) + 1);
            double scoreB = b.getHealth() / (树友友何树友树树树何.M(b, ax) + 1);
            return Double.compare(scoreA, scoreB);
         };
         case 7 -> {
            double playerAttack = 友何树何友树友树何何.p(mc.player.getMainHandItem(), ax);
            yield (axx, b) -> {
               long ax = 友何何友树何树友友友.a ^ 21788504949092L ^ 112813540573309L;
               double threatScoreA = (axx.getHealth() + 树友友何树友树树树何.M(axx, ax)) / playerAttack;
               double threatScoreB = (b.getHealth() + 树友友何树友树树树何.M(b, ax)) / playerAttack;
               return Double.compare(threatScoreA, threatScoreB);
            };
         }
         default -> Comparator.comparingDouble(e -> RotationUtils.O(e));
      };
   }

   private boolean y() {
      long a = 友何何友树何树友友友.a ^ 84732310483885L;
      long ax = a ^ 133055204036688L;
      c<"R">(4334183975519667993L, a);
      if (!c<"k">(c<"k">(mc, 4339848407083957260L, a), 4334666328291054647L, a).isDown()) {
         this.L();
         return false;
      } else if (c<"k">(mc, 4341402732443536352L, a) != null && c<"k">(mc, 4341402732443536352L, a).getType() == c<"B">(4341063552569388765L, a)) {
         BlockHitResult blockHit = (BlockHitResult)c<"k">(mc, 4341402732443536352L, a);
         BlockPos currentBlockPos = blockHit.getBlockPos();
         if (友树友友何友树友树友.M(currentBlockPos, ax)) {
            this.L();
            return false;
         } else {
            if (c<"k">(this, 4340793520808165309L, a) == null || !c<"k">(this, 4340793520808165309L, a).equals(currentBlockPos)) {
               c<"Ý">(this, currentBlockPos, 4340793520808165309L, a);
               c<"Ý">(this, 0, 4334112753093642152L, a);
            }

            c<"Ý">(this, c<"k">(this, 4334112753093642152L, a) + 1, 4334112753093642152L, a);
            return c<"k">(this, 4334112753093642152L, a) >= 1;
         }
      } else {
         this.L();
         return false;
      }
   }

   private void L() {
      long a = 友何何友树何树友友友.a ^ 104151879859226L;
      c<"Ý">(this, null, 8325619815999811594L, a);
      c<"Ý">(this, 0, 8327946517569226783L, a);
   }

   private float N(float current, float target, float speed, boolean isYaw) {
      long a = 友何何友树何树友友友.a ^ 74646622255678L;
      long ax = a ^ 42125668945039L;
      c<"R">(8481707089761734282L, a);
      if (this.w(new Object[]{ax})) {
         return 0.0F;
      } else {
         float diff = Mth.wrapDegrees(target - current);
         float absDiff = Math.abs(diff);
         if (absDiff > 90.0F) {
            diff = diff > 0.0F ? 5.0F : -5.0F;
            return current + diff;
         } else {
            float targetVelocity = isYaw ? target - c<"k">(this, 8479056470310489344L, a) : target - c<"k">(this, 8478892184567816475L, a);
            c<"Ý">(this, c<"k">(this, 8478573782056011973L, a) * 0.9F + targetVelocity * 0.1F, 8478573782056011973L, a);
            c<"Ý">(this, c<"k">(this, 8481132918550465336L, a) * 0.9F + targetVelocity * 0.1F, 8481132918550465336L, a);
            float baseSmoothFactor = speed / 20.0F;
            if (absDiff > 15.0F) {
               baseSmoothFactor = Math.min(baseSmoothFactor * 1.2F, 0.9F);
            }

            if (absDiff > 5.0F) {
               baseSmoothFactor = Math.min(baseSmoothFactor, 0.6F);
            }

            baseSmoothFactor = Math.min(baseSmoothFactor * 0.95F, 0.4F);
            float velocityFactor = Math.abs(c<"k">(this, 8478573782056011973L, a)) * 0.2F;
            float targetSmoothFactor = baseSmoothFactor * (1.0F + Math.min(velocityFactor, 0.5F));
            c<"Ý">(this, c<"k">(this, 8481249242294405630L, a) + (targetSmoothFactor - c<"k">(this, 8481249242294405630L, a)) * 0.3F, 8481249242294405630L, a);
            c<"Ý">(this, target, 8479056470310489344L, a);
            c<"Ý">(this, c<"k">(this, 8480042900640675127L, a) + (targetSmoothFactor - c<"k">(this, 8480042900640675127L, a)) * 0.3F, 8480042900640675127L, a);
            c<"Ý">(this, target, 8478892184567816475L, a);
            float rotationAmount = diff * c<"k">(this, 8481249242294405630L, a);
            rotationAmount = Mth.clamp(rotationAmount, -20.0F, 20.0F);
            return current + rotationAmount;
         }
      }
   }

   private double R(Entity entity) {
      long var10000 = 友何何友树何树友友友.a ^ 77144974313828L;
      long a = 友何何友树何树友友友.a ^ 77144974313828L ^ 39159735910357L;
      long ax = 友何何友树何树友友友.a ^ 77144974313828L ^ 135434928396573L;
      long axx = var10000 ^ 42444539821494L;
      long var10001 = var10000 ^ 15341884274387L;
      int axxx = (int)((var10000 ^ 15341884274387L) >>> 48);
      int axxxx = (int)((var10000 ^ 15341884274387L) << 16 >>> 32);
      int axxxxx = (int)(var10001 << 48 >>> 48);
      if (this.w(new Object[]{a})) {
         return 0.0;
      } else {
         Rotation targetRot = RotationUtils.z(new Object[]{entity, ax});
         float entityYaw = targetRot.getYaw();
         float entityPitch = targetRot.J(new Object[]{axx});
         float playerYaw = mc.player.getYRot();
         float playerPitch = mc.player.getXRot();
         float deltaYaw = 友树树何何树树何何树.g(entityYaw - playerYaw, (char)axxx, axxxx, (char)axxxxx);
         float deltaPitch = 友树树何何树树何何树.g(entityPitch - playerPitch, (char)axxx, axxxx, (char)axxxxx);
         return Math.abs(deltaYaw) + Math.abs(deltaPitch);
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖诈骗";
   }
}
