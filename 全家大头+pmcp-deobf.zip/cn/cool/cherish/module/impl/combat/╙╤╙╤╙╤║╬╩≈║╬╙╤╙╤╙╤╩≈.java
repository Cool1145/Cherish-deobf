package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.GameLoopEvent;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.packet.HandleReceivePacketEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundMoveEntityPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ClientboundSetHealthPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ClientboundTeleportEntityPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import why.tree.friend.antileak.Fucker;

public class 友友友何树何友友友树 extends Module implements 何树友 {
   private final NumberValue 友友何友何友树树树何;
   private final NumberValue 树何何何友何友树树何;
   private final BooleanValue 何树树友树友何树树友;
   private final NumberValue 友何友树友树树何树何;
   private final NumberValue 树树友何何友何树何何;
   private final BooleanValue 何树树友树友何何何何;
   private final NumberValue 友何友友友何树树树友;
   private final NumberValue 树友友树何树友友树友;
   private final 树友树友友何何树何何 何何友何树树树友友树;
   private final 树友树友友何何树何何 何树友何友友友树何何;
   private final 树友树友友何何树何何 树树树友树树树友何何;
   private final 树友树友友何何树何何 树树何友树友友何树友;
   private Entity 友树树何树何树何友树;
   private 友友友何树何友友友树.树何树何树何何友树友 友树友友树何树友友友;
   private final LinkedHashSet<友友友何树何友友友树.树友树何何友树树何何> 友何树何树何何树友何;
   private boolean 树树树何何何何何树何;
   private volatile boolean 友何友何何何友何友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[59];
   private static final String[] k = new String[59];
   private static int _何炜霖黑水 _;

   public 友友友何树何友友友树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/combat/友友友何树何友友友树.a J
      // 003: ldc2_w 5073539985199
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 73337993632914
      // 00d: lxor
      // 00e: lstore 3
      // 00f: dup2
      // 010: ldc2_w 127683880649858
      // 013: lxor
      // 014: lstore 5
      // 016: pop2
      // 017: aload 0
      // 018: sipush 6639
      // 01b: ldc2_w 7382173529462851745
      // 01e: lload 1
      // 01f: lxor
      // 020: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 025: sipush 4873
      // 028: ldc2_w 2342626310928974405
      // 02b: lload 1
      // 02c: lxor
      // 02d: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 032: ldc2_w -640579928712751024
      // 035: lload 1
      // 036: invokedynamic Í (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 03b: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 03e: aload 0
      // 03f: new cn/cool/cherish/value/impl/NumberValue
      // 042: dup
      // 043: sipush 11680
      // 046: ldc2_w 3379842930256215291
      // 049: lload 1
      // 04a: lxor
      // 04b: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 050: sipush 19047
      // 053: ldc2_w 6441688413626964798
      // 056: lload 1
      // 057: lxor
      // 058: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 05d: dconst_1
      // 05e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 061: dconst_0
      // 062: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 065: ldc2_w 10.0
      // 068: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 06b: ldc2_w 0.1
      // 06e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 071: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 074: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.友友何友何友树树树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 077: aload 0
      // 078: new cn/cool/cherish/value/impl/NumberValue
      // 07b: dup
      // 07c: sipush 17369
      // 07f: ldc2_w 257796297435910812
      // 082: lload 1
      // 083: lxor
      // 084: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 089: sipush 9006
      // 08c: ldc2_w 6518502050123936374
      // 08f: lload 1
      // 090: lxor
      // 091: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 096: sipush 150
      // 099: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09c: bipush 0
      // 09d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0a0: sipush 1000
      // 0a3: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0a6: bipush 10
      // 0a8: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ab: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0ae: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.树何何何友何友树树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 0b1: aload 0
      // 0b2: new cn/cool/cherish/value/impl/BooleanValue
      // 0b5: dup
      // 0b6: sipush 20278
      // 0b9: ldc2_w 2703928508227001975
      // 0bc: lload 1
      // 0bd: lxor
      // 0be: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c3: sipush 30645
      // 0c6: ldc2_w 8960012442169517807
      // 0c9: lload 1
      // 0ca: lxor
      // 0cb: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d0: bipush 0
      // 0d1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0d4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0d7: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.何树树友树友何树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0da: aload 0
      // 0db: new cn/cool/cherish/value/impl/NumberValue
      // 0de: dup
      // 0df: sipush 7510
      // 0e2: ldc2_w 1250241333882866717
      // 0e5: lload 1
      // 0e6: lxor
      // 0e7: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ec: sipush 250
      // 0ef: ldc2_w 804789388788355506
      // 0f2: lload 1
      // 0f3: lxor
      // 0f4: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f9: bipush 0
      // 0fa: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0fd: bipush 0
      // 0fe: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 101: sipush 1000
      // 104: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 107: bipush 10
      // 109: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 10c: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 10f: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.友何友树友树树何树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 112: aload 0
      // 113: new cn/cool/cherish/value/impl/NumberValue
      // 116: dup
      // 117: sipush 927
      // 11a: ldc2_w 5534955375093895901
      // 11d: lload 1
      // 11e: lxor
      // 11f: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 124: sipush 21152
      // 127: ldc2_w 5083037452618367983
      // 12a: lload 1
      // 12b: lxor
      // 12c: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 131: bipush 100
      // 133: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 136: bipush 0
      // 137: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 13a: bipush 100
      // 13c: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 13f: bipush 1
      // 140: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 143: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 146: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.树树友何何友何树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 149: aload 0
      // 14a: new cn/cool/cherish/value/impl/BooleanValue
      // 14d: dup
      // 14e: sipush 14703
      // 151: ldc2_w 7475970707889154095
      // 154: lload 1
      // 155: lxor
      // 156: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 15b: sipush 24363
      // 15e: ldc2_w 4572333336405904994
      // 161: lload 1
      // 162: lxor
      // 163: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 168: bipush 0
      // 169: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 16c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 16f: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.何树树友树友何何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 172: aload 0
      // 173: new cn/cool/cherish/value/impl/NumberValue
      // 176: dup
      // 177: sipush 11628
      // 17a: ldc2_w 8799503392839564321
      // 17d: lload 1
      // 17e: lxor
      // 17f: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 184: sipush 4609
      // 187: ldc2_w 6339957144706564933
      // 18a: lload 1
      // 18b: lxor
      // 18c: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 191: bipush 5
      // 192: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 195: bipush 0
      // 196: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 199: bipush 10
      // 19b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 19e: bipush 1
      // 19f: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1a2: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1a5: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.友何友友友何树树树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 1a8: aload 0
      // 1a9: new cn/cool/cherish/value/impl/NumberValue
      // 1ac: dup
      // 1ad: sipush 2740
      // 1b0: ldc2_w 7329643418624351223
      // 1b3: lload 1
      // 1b4: lxor
      // 1b5: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1ba: sipush 27893
      // 1bd: ldc2_w 342553143566450098
      // 1c0: lload 1
      // 1c1: lxor
      // 1c2: invokedynamic i (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c7: sipush 800
      // 1ca: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1cd: bipush 0
      // 1ce: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1d1: sipush 5000
      // 1d4: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1d7: bipush 50
      // 1d9: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 1dc: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 1df: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.树友友树何树友友树友 Lcn/cool/cherish/value/impl/NumberValue;
      // 1e2: aload 0
      // 1e3: new cn/cool/cherish/utils/树友树友友何何树何何
      // 1e6: dup
      // 1e7: lload 3
      // 1e8: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 1eb: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.何何友何树树树友友树 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 1ee: aload 0
      // 1ef: new cn/cool/cherish/utils/树友树友友何何树何何
      // 1f2: dup
      // 1f3: lload 3
      // 1f4: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 1f7: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.何树友何友友友树何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 1fa: aload 0
      // 1fb: new cn/cool/cherish/utils/树友树友友何何树何何
      // 1fe: dup
      // 1ff: lload 3
      // 200: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 203: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.树树树友树树树友何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 206: aload 0
      // 207: new cn/cool/cherish/utils/树友树友友何何树何何
      // 20a: dup
      // 20b: lload 3
      // 20c: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 20f: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.树树何友树友友何树友 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 212: aload 0
      // 213: new java/util/LinkedHashSet
      // 216: dup
      // 217: invokespecial java/util/LinkedHashSet.<init> ()V
      // 21a: putfield cn/cool/cherish/module/impl/combat/友友友何树何友友友树.友何树何树何何树友何 Ljava/util/LinkedHashSet;
      // 21d: aload 0
      // 21e: bipush 0
      // 21f: ldc2_w -643174256469309252
      // 222: lload 1
      // 223: invokedynamic á (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 228: aload 0
      // 229: bipush 0
      // 22a: ldc2_w -640779701441303378
      // 22d: lload 1
      // 22e: invokedynamic á (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 233: aload 0
      // 234: ldc2_w -640036769696975037
      // 237: lload 1
      // 238: invokedynamic Á (Ljava/lang/Object;JJ)Lcn/cool/cherish/utils/树友树友友何何树何何; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23d: lload 5
      // 23f: invokevirtual cn/cool/cherish/utils/树友树友友何何树何何.U (J)V
      // 242: aload 0
      // 243: ldc2_w -640438663702894966
      // 246: lload 1
      // 247: invokedynamic Á (Ljava/lang/Object;JJ)Lcn/cool/cherish/utils/树友树友友何何树何何; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 24c: lload 5
      // 24e: invokevirtual cn/cool/cherish/utils/树友树友友何何树何何.U (J)V
      // 251: aload 0
      // 252: ldc2_w -642961800733577684
      // 255: lload 1
      // 256: invokedynamic Á (Ljava/lang/Object;JJ)Lcn/cool/cherish/utils/树友树友友何何树何何; bsm=cn/cool/cherish/module/impl/combat/友友友何树何友友友树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 25b: lload 5
      // 25d: invokevirtual cn/cool/cherish/utils/树友树友友何何树何何.U (J)V
      // 260: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1348347686823797365L, -6727786709760186168L, MethodHandles.lookup().lookupClass()).a(47335365158193L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 62276792333583L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[20];
      int var7 = 0;
      String var6 = "J`¨-H\u0018\u0003B½d·ß4\u0006\u001eH`·Ë\u0099¶å2mÒ\u0091\u0081¶ÁK6\u0013£þ\u009eÝd»\u001bð\u0018Hë\\o\u0006Ï\u001açüèWiðÌ`Ä[\u0011Jëîiis M\u0007\u0013r\u0091Þ\u001dÕo/ï*¢³ôí{5\u0085\u0093K¨Q»?j|Ó>¡\u001f\u009b(;]\u0086ëÎ%Cy9¡\u007fÊ\u0005´{Â\u0092ÌO\u008c_\u0086nä_\u000e×òÜ&Ò[/\u00180ßX\u009f`\u00ad\u0018Þ\u0019\u0019î'÷\u0093#Â\u009e\u0010 ç\ts\u0002\u001eÍ6t²\u0015¦n \u001d-Ô ¢ÿëÀQ\u0010xaãHPå<tº%ÝÏÑ®#¯\u0099£ÊµÝ{ ÷Bv_\u009fù^\u0011\u0090\u008d·\u0092\u001d\u0095<Ih\u0017*o8\u009e\u0011WLo\u0006#\t&4\b\u0010\u0094{ü\u000b<,'_¹\u0081Þ\u0014Æ\u0096×Ð(r#À'¨û\u008eï\u0085HªÔT\u009fJb\u0012Áìýý@ó\u008b\u0089øÓHpð\u0097\u000e\u000e#wõÂÛ\u0012Â\u0010ái¼¶\u008dì&\u007f\u0016ô»O\b³\u0095<\u0018gM\u0016:ÖWð#Ê\n§tàQÙ¡\u0005l¤à\u0080b±ê\u0018\u0097\u0098âü\u0005\u0002\u0004\nÉe\u0011RUL\u0085±Ð\u0015\u0084:§%i\u000e(cÑ\u0091-Wlù\u0012y\u001eçQû«'à'WÚt\u007ft\u0002È\u0002\u0003Ü\u00100V\u008c=5>¸\u000f\u0088\u0084\u001f\u0088\u0010\u009fÌ\u0093¹W\u009a¨´4\u0090\u0082\u0080ö²Y+\u0010í·W¸unºô]E¡\b6w\u009eÆ('g\u00903/\u0017\u0098\u0016öá÷\b\\ÎË\u0089v4]¥·EÚµ#\u0086d\u0001¬<\u0098À[ÄüC)þh*\u0010Sµ\u0007øïb&\u0080a$\r³³ßì¡ iîJêÞ¤Br4\u009cÉÒTþ#¡\u0098á4OuïI1-\u009b½Ûg\u0096Æ°";
      short var8 = 521;
      char var5 = '(';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[20];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ã~|Æ!æ{3\u001f4!?ËÖ¶\u007f\u0010Ì\\ã \u0011í\u0084\u0085#\u0016\u001a\u000fd·Å\b";
                  var8 = 33;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private void C(boolean handlePackets) {
      this.K(handlePackets, false);
   }

   @EventTarget
   public void D(TickEvent event) {
      long a = 友友友何树何友友友树.a ^ 13754083714244L;
      long ax = a ^ 86103977706966L;
      c<"ý">(-4830675350190371963L, a);
      if (!this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
         if (c<"Á">(this, -4830844583383699003L, a) != null && c<"Á">(this, -4831360250479984058L, a) != null) {
            c<"Á">(this, -4831360250479984058L, a).U(false);
            c<"Á">(this, -4831360250479984058L, a).H(c<"Á">(this, -4830844583383699003L, a).position());
         }
      }
   }

   public void F() {
      this.C(true);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private void Z(boolean clear) {
      long a = 友友友何树何友友友树.a ^ 44339488341612L;
      c<"ý">(2764606046048571693L, a);
      LinkedHashSet var5;
      synchronized (var5 = c<"Á">(this, 2763742400626152774L, a)){} // $VF: monitorenter 

      try {
         long currentTime = System.currentTimeMillis();
         if (c<"Á">(this, 2763742400626152774L, a).stream().anyMatch(packet -> {
            long ax = 友友友何树何友友友树.a ^ 95934730648611L;
            c<"ý">(2599322033949397858L, ax);
            return currentTime - c<"Á">(packet, 2598987846231875765L, ax) >= c<"Á">(this, 2600055293753213623L, ax).getValue().longValue();
         })) {
            c<"Á">(this, 2763742400626152774L, a).forEach(packet -> {
               long ax = 友友友何树何友友友树.a ^ 52361928716331L;
               c<"ý">(-6333506651348934806L, ax);
               if (mc.getConnection() != null) {
                  try {
                     Packet<ClientGamePacketListener> clientPacket = c<"Á">(packet, -6333589661540568743L, ax);
                     if (this.U()) {
                        if (clientPacket instanceof ClientboundSetEntityMotionPacket || clientPacket instanceof ClientboundExplodePacket) {
                           return;
                        }

                        clientPacket.handle(mc.getConnection());
                     }

                     clientPacket.handle(mc.getConnection());
                  } catch (Exception var6x) {
                  }
               }
            });
            c<"Á">(this, 2763742400626152774L, a).clear();
            c<"á">(this, null, 2764436817422773101L, a);
            c<"á">(this, null, 2763991512353560814L, a);
         }

         // $VF: monitorexit
      } finally {
         // $VF: monitorexit
      }
   }

   private boolean V(Entity entity) {
      long a = 友友友何树何友友友树.a ^ 38793618839398L;
      c<"ý">(5717268698007484455L, a);
      if (c<"Á">(this, 5715526119087288804L, a) != null && c<"Á">(this, 5715526119087288804L, a).v() != null) {
         double distance = entity.position().distanceTo(c<"Á">(this, 5715526119087288804L, a).v());
         return distance > 3.0;
      } else {
         return true;
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private boolean i(Entity target) {
      long a = 友友友何树何友友友树.a ^ 57283824639946L;
      long ax = a ^ 128349872544517L;
      long axx = a ^ 75473594954855L;
      c<"ý">(5186957957604585611L, a);
      if (target != null && target.isAlive() && !target.isRemoved()) {
         if (target instanceof LivingEntity living && living.getHealth() < 3.0F) {
            return false;
         } else {
            Vec3 backtrackPos = c<"Á">(this, 5187504553287760200L, a) != null ? c<"Á">(this, 5187504553287760200L, a).v() : target.position();
            if (backtrackPos == null) {
               return false;
            } else {
               double backtrackDistance = backtrackPos.distanceTo(mc.player.position());
               if (!(backtrackDistance > 6.0) && !(backtrackDistance < c<"Á">(this, 5186465603858340633L, a).getValue().doubleValue())) {
                  boolean outOfRange = backtrackDistance > c<"Á">(this, 5186465603858340633L, a).getValue().floatValue();
                  if (!outOfRange) {
                     return false;
                  } else {
                     if (outOfRange) {
                        c<"Á">(this, 5186322584791717487L, a).U(axx);
                     }

                     return target instanceof LivingEntity
                        && c<"Í">(5185806457603887937L, a).w((LivingEntity)target)
                        && c<"Á">(mc.player, 5187154189345863185L, a) > 10
                        && Math.random() * 100.0 < c<"Á">(this, 5186666956760564950L, a).getValue().doubleValue()
                        && !this.f()
                        && !c<"Á">(this, 5185487199200190153L, a).Y(c<"Á">(this, 5187615875386145822L, a).getValue().longValue(), ax);
                  }
               } else {
                  return false;
               }
            }
         }
      } else {
         return false;
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 12;
               case 1 -> 8;
               case 2 -> 49;
               case 3 -> 6;
               case 4 -> 39;
               case 5 -> 45;
               case 6 -> 33;
               case 7 -> 17;
               case 8 -> 31;
               case 9 -> 52;
               case 10 -> 34;
               case 11 -> 23;
               case 12 -> 11;
               case 13 -> 10;
               case 14 -> 13;
               case 15 -> 5;
               case 16 -> 58;
               case 17 -> 28;
               case 18 -> 44;
               case 19 -> 24;
               case 20 -> 42;
               case 21 -> 15;
               case 22 -> 35;
               case 23 -> 14;
               case 24 -> 59;
               case 25 -> 32;
               case 26 -> 4;
               case 27 -> 55;
               case 28 -> 30;
               case 29 -> 48;
               case 30 -> 40;
               case 31 -> 38;
               case 32 -> 47;
               case 33 -> 20;
               case 34 -> 0;
               case 35 -> 19;
               case 36 -> 18;
               case 37 -> 26;
               case 38 -> 2;
               case 39 -> 61;
               case 40 -> 3;
               case 41 -> 27;
               case 42 -> 60;
               case 43 -> 29;
               case 44 -> 56;
               case 45 -> 36;
               case 46 -> 25;
               case 47 -> 43;
               case 48 -> 21;
               case 49 -> 63;
               case 50 -> 62;
               case 51 -> 54;
               case 52 -> 41;
               case 53 -> 46;
               case 54 -> 22;
               case 55 -> 7;
               case 56 -> 53;
               case 57 -> 16;
               case 58 -> 51;
               case 59 -> 1;
               case 60 -> 9;
               case 61 -> 50;
               case 62 -> 37;
               default -> 57;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友何树何友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9822;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友何树何友友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   @EventTarget
   public void s(Render3DEvent event) {
      long a = 友友友何树何友友友树.a ^ 108910385789155L;
      c<"ý">(-2246572928190146654L, a);
      if (c<"Á">(this, -2246720079866221086L, a) != null && c<"Á">(this, -2245922937528934815L, a) != null) {
         AABB backtrackBox = new AABB(
            c<"Á">(c<"Á">(this, -2245922937528934815L, a).v(), -2246414731063801666L, a) - 0.4,
            c<"Á">(c<"Á">(this, -2245922937528934815L, a).v(), -2246093271669300161L, a),
            c<"Á">(c<"Á">(this, -2245922937528934815L, a).v(), -2247235937314577454L, a) - 0.4,
            c<"Á">(c<"Á">(this, -2245922937528934815L, a).v(), -2246414731063801666L, a) + 0.4,
            c<"Á">(c<"Á">(this, -2245922937528934815L, a).v(), -2246093271669300161L, a) + c<"Á">(this, -2246720079866221086L, a).getBbHeight(),
            c<"Á">(c<"Á">(this, -2245922937528934815L, a).v(), -2247235937314577454L, a) + 0.4
         );
         c<"Í">(-2243296694331955715L, a).put(backtrackBox, new Color(255, 0, 0, 100));
         if (c<"Á">(this, -2245922937528934815L, a).p() != null) {
            AABB actualBox = new AABB(
               c<"Á">(c<"Á">(this, -2245922937528934815L, a).p(), -2246414731063801666L, a) - 0.4,
               c<"Á">(c<"Á">(this, -2245922937528934815L, a).p(), -2246093271669300161L, a),
               c<"Á">(c<"Á">(this, -2245922937528934815L, a).p(), -2247235937314577454L, a) - 0.4,
               c<"Á">(c<"Á">(this, -2245922937528934815L, a).p(), -2246414731063801666L, a) + 0.4,
               c<"Á">(c<"Á">(this, -2245922937528934815L, a).p(), -2246093271669300161L, a) + c<"Á">(this, -2246720079866221086L, a).getBbHeight(),
               c<"Á">(c<"Á">(this, -2245922937528934815L, a).p(), -2247235937314577454L, a) + 0.4
            );
            c<"Í">(-2243296694331955715L, a).put(actualBox, new Color(0, 255, 0, 100));
         }
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友何树何友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 193 && var8 != 225 && var8 != 205 && var8 != 't') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'k') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 253) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 193) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 225) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 205) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private boolean c() {
      long a = 友友友何树何友友友树.a ^ 87908761812529L;
      c<"ý">(-6484975460640239248L, a);
      return c<"Á">(this, -6485140566227522768L, a) != null
         && c<"Á">(this, -6485140566227522768L, a).isAlive()
         && this.i(c<"Á">(this, -6485140566227522768L, a));
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   @EventTarget
   public void f(GameLoopEvent event) {
      long a = 友友友何树何友友友树.a ^ 51244384808735L;
      c<"ý">(-635328304429760418L, a);
      if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
         if (this.c()) {
            this.Z(false);
         }

         if (!c<"Á">(this, -636322255577977698L, a)) {
            this.p();
         }
      }
   }

   private boolean f() {
      long a = 友友友何树何友友友树.a ^ 5874648875017L;
      c<"ý">(-7477955011357380792L, a);
      return c<"Á">(this, -7477248275711546369L, a).getValue() && c<"Á">(this, -7479074211468089446L, a);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private void d(Entity entity) {
      long a = 友友友何树何友友友树.a ^ 128304507525750L;
      c<"ý">(-9059124311826827977L, a);
      if (c<"Á">(this, -9060689119701828364L, a) != null) {
         double distance = entity.distanceTo(mc.player);
         if (distance > 6.0) {
            this.p();
            return;
         }

         c<"Á">(this, -9060689119701828364L, a).Y(entity.position());
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static void a() {
      j[0] = "nt+==6a4f67+dimp?6ioi;|0`jip16`xd*|厒叆发佐桏伇厒叆发栔";
      j[1] = "\u001bNd\r$I\u001bNsQ(F\u0001\u0005gL;L\u0011\u0005uM=I\u0001R>f'T\u001c_i";
      j[2] = " 04C%'/pyH/:*-r\u000e?<*2i\u000e桛厃桒厕发併伟桙伖伋";
      j[3] = "=sxPwc235[}~7n>\u001duc:h:V6e3m:\u001d{c3\u007f7G6G7q:rm~?";
      j[4] = "\u001e\u0007\r\u00067X*$\u0002FzS 9\u0007\u001bq\u0015($\n\u001du^k\u0006\u0001\flW p";
      j[5] = "z_np\u0014iu\u001f#{\u001etpB(=\rguD%=\u0012ki]n]\u000ek{T2E\u001ajlT";
      j[6] = "Ty\u0018;soJq\u0002t\u0011sPs\u000b>\u0015{Mp=?)";
      j[7] = "\u0006T\u001e#M{\u0006T\t\u007fAt\u001c\u001f\u0019bU|\fBD^Og\u0006U/{E|\u001cB";
      j[8] = "UU\u000517mUU\u0012m;bO\u001e\u0002p/j_C_L5qUT4i?jO";
      j[9] = "\u0010\u0017Y\u001ajX\u0010\u0017NFfW\n\\Z[u]\u001a\\]\\~BP$HW4";
      j[10] = double.class;
      k[10] = "java/lang/Double";
      j[11] = "a\t\u0013\u0019SAj\u0006\u0002V8Uh\r\u0015\f\u0014Be";
      j[12] = "pzGD\u0017!\u007f:\nO\u001d<zg\u0001\t\u0015!wa\u0005BV'~d\u0005\t\u001b!~v\bSV厅变叟似栶伭厅变叟桸\u0003桩伛栂佁桸佲伭厅栂叟";
      j[13] = "\u0007t0\u0003:n\b4}\b0s\rivN8n\u0000or\u0005{h\tjrN6n\tx\u007f\u0014{及厯发佋桱伀及厯发栏D桄及桵住佋厫桄栐伱住";
      j[14] = long.class;
      k[14] = "java/lang/Long";
      j[15] = "\u0002|3S;1\u0002|$\u000f7>\u00187)\u0018\"/\u0003k,S&*\u0003m(\u001e94BI&\u001e==\u0018";
      j[16] = boolean.class;
      k[16] = "java/lang/Boolean";
      j[17] = "(W(kqQ(W?7}^2\u001c+*nT\"\u001c9+hQ2Kr\tuN/\\;\u0000rL/F%";
      j[18] = int.class;
      k[18] = "java/lang/Integer";
      j[19] = "Bc+ _7M#f+U*H~mmE,HavmB=Oi`1\u001e\nDca&B\rUdi0";
      j[20] = "r\u00052\u0005l\nl\r(J\u000f\u001eh";
      j[21] = "\u00168^&IB\u0019x\u0013-C_\u001c%\u0018kPL\u0019#\u0015kO@\u0005:^\u0007IB\u00193\u0011+pL\u0019#\u0015";
      j[22] = "`4H.\u007f\u001fot\u0005%u\u0002j)\u000ec}\u001fg/\n(>伥佖厑伳优叛伥佖桋桷";
      j[23] = "\"\u0007v\u0003F\u0006\"\u0007a_J\t8LaAB\n\"\u0016,]G\u000e5\u0007p\u0003g\u0000/\u0003n}G\u000e5\u0007p";
      j[24] = "zzIkK\u000eu:\u0004`A\u0013pg\u000f&I\u000e}a\u000bm\n\btd\u000b&G\u000etv\u0006|\n7|x\bkM\u0015`";
      j[25] = "zV(\u00023Fu\u0016e\t9[pKnO*HuMcO5DiT(,3M|ng\r)L";
      j[26] = "{+9w|mp$(8\u001dc{/,b";
      j[27] = "m\u001a`\u0018o;w_'}栕栚栖叡桅桤栕叀佒使\\Ds<s\u00128A~so";
      j[28] = "Qd\u00076\u001c|F`\rgu栆叾叅伵伇桬叜叾栟桱Z\u0018!T`\u0014;\u000e`\\6";
      j[29] = "\u0006k'\u0019\b+\u001c.`|厨低厧桊变桥桲低桽伎\u001bG\u0016#]7x\u0016\u001a|\u0014";
      j[30] = "\u0018]:F\u000e?\u0002\u0018}#桴栞档伸佛佾估佚档伸\u0006I\t\u007f\u001fT\u007fA\u0014=\u0013";
      j[31] = "~4BE\u001cG{#@\u001f\u007f\u0016\"(F\u0012\u0019\u001c)S\u0000\u001c\u0007I'c\u0005\u000b\u0005\u0013";
      j[32] = " \u000b\u0010\\+\u0015:NW9伕栴桛台栵叺伕佰伟佮,Wv\u0015s\\EF1F\u007f";
      j[33] = "\u000et~:Br].~=y栅栦栍桛桀桠叟佢受伟Y\u0010q\u0006{+0\u0016vP(";
      j[34] = "r\u0019\u0013~iEh\\T\u001b栓桤位叢栶变叉传栉叢/\"uBl\u0011K'x\rp";
      j[35] = "g'@\"Dwd#\u0015qy栒栞厍佰桖厺栒栞伓佰O\u0019rm)@\u007f\u0014gu\"";
      j[36] = "*a]KL\u001dvlO\u0016q\u0018C>\bMAOC\u000e\r\u0012\u001a\u0014q4C\u000e\u001b\u0015";
      j[37] = ":\u0007<#IK2\u0015{&3叩桍县叁伄佮叩伉桥叁Y]Qj\u0006x8UC-\u0003";
      j[38] = "O/I2dIL+\u001caYTI=X6?^BFD64X\u0012:G2a\u000b";
      j[39] = "ok$\rw(u.ch佉栉収伎叛厫受栉佐伎\u0018Qk/qc|Tf`m";
      j[40] = "\u0018;2C\f3D6 \u001e16qdgE\u000eiqTb\u001aZ:Cn,\u0006[;";
      j[41] = "*\u0018w\u0012@k0]0w叠厐伕口伖厴栺桊桑佽KL^cqD(\u001dR<8";
      j[42] = "\r\u0011b2N\u000f\u0017T%W佰栮桶只桇厔佰栮桶只^9\u0013\u000f^F7(T\\R";
      j[43] = "($t9\u001d&2a3\\桧标厉佁伕原伣标众佁Hg\u0003.sx+6\u000fq:";
      j[44] = "nTkvy\u0003t\u0011,\u0013叙栢栕伱桎低栃佦叏桵WhuImQ+uf\u000b";
      j[45] = "yZCi?\u001ac\u001f\u0004\f企使变伿桦栕桅叡变桻\u007f5#\u001dgR\u001b0.R{";
      j[46] = ">&3^Z\u0006;11\u00049g\u0004{9\u000b\u0005Za}5[\u00076";
      j[47] = "\t|k\u0000:yZ&k\u0007\u0001叔佥栅伊桺作叔叻栅伊chqZw;\u001e~p[a";
      j[48] = "}3q\u0019psuc3\\L$Ec~[}uEZ$\u00151u-4 _s$";
      j[49] = "(\u0004{\u001aN62A<\u007f栴体众佡厄伢叮栗桓佡GDP>sX$\u0015\\a:";
      j[50] = "MQU!8MW\u0014\u0012D厘伨栶伴桰伙伆桬召伴ix=\u0005\u001e\u0006\n'f\u0016I";
      j[51] = "7\b\u00106!\u0005y\u001fFa\u0010\u0000\\CLj*U\\zHnh\u00103\nI=.\u001e";
      j[52] = "i_>\r\u0016Os\u001ayh\u001cw;]{V\b\u0012`\u0006\u007fXuG1\u001e<\u0015\u0010\u001cj\u001a2h";
      j[53] = "3\u0019\u001cchYo\u0014\u000e>U\\ZFIee\nZvL:>PhL\u0002&?Q";
      j[54] = "64{3t?6; 0K8\u000b|%lrh\u000bFv,6ic(rft8";
      j[55] = "\u0001I\u0007)\u0017\u0007\u001b\f@L厷栦厠厲栢休桭叼厠厲;|\u000e\\\tK\u00051\u001d\u000e\b";
      j[56] = "vF\u0018\u0000a>l\u0003_e叁佛受伣佹伸叁佛受桧$\u000ff~qO]\u0007{<}";
      j[57] = "sC3I0bi\u0006t,桊厙叒桢佒栵厐厙栈厸\u000f\u0017.j(\u001flF\"5a";
      j[58] = "z\fb[8v`I%>厘伓叛号厝佣桂桗栁号^\u0005&~!P=T*!h";
   }

   @EventTarget
   public void m(AttackEvent event) {
      long a = 友友友何树何友友友树.a ^ 17139430643352L;
      long ax = a ^ 85055115081610L;
      long axx = a ^ 139824463428917L;
      c<"ý">(5668340092310141401L, a);
      if (this.isEnabled() && !this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
         c<"Á">(this, 5666855088572962715L, a).U(axx);
         if (c<"Á">(this, 5669904833698082842L, a) != null) {
            c<"Á">(this, 5669904833698082842L, a).U(true);
         }

         Entity entity = event.getTarget();
         this.Y(entity);
      }
   }

   @EventTarget
   public void p(HandleReceivePacketEvent event) {
      long a = 友友友何树何友友友树.a ^ 2384285751120L;
      long ax = a ^ 71360223524418L;
      long axx = a ^ 63335983155341L;
      c<"ý">(-3503254097586440175L, a);
      if (this.isEnabled() && !this.w(new Object[]{ax}) && (Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
         if (!c<"Á">(this, -3501861612641108870L, a).isEmpty()) {
            c<"Á">(this, -3503475859572338884L, a).A((long)(Math.random() * c<"Á">(this, -3500117018298561879L, a).getValue().longValue()), axx);
         }

         synchronized (c<"Á">(this, -3501861612641108870L, a)) {
            if (!event.isCancelled() && event.getPacket() != null) {
               if (!c<"Á">(this, -3501861612641108870L, a).isEmpty() || this.c()) {
                  Packet<?> packet = event.getPacket();
                  if (!(packet instanceof ServerboundChatPacket)
                     && !(packet instanceof ClientboundSystemChatPacket)
                     && !(packet instanceof ServerboundCommandSuggestionPacket)) {
                     if (!(packet instanceof ClientboundPlayerPositionPacket) && !(packet instanceof ClientboundDisconnectPacket)) {
                        if (!(packet instanceof ClientboundSoundPacket soundPacket && soundPacket.getSound().get() == c<"Í">(-3501914940466478969L, a))) {
                           if (packet instanceof ClientboundSetHealthPacket healthPacket && healthPacket.getHealth() <= 0.0F) {
                              this.C(true);
                           } else if (c<"Á">(this, -3503401545221012911L, a) != null && mc.level != null) {
                              boolean isEntityPacket = packet instanceof ClientboundMoveEntityPacket
                                 && ((ClientboundMoveEntityPacket)packet).getEntity(mc.level) == c<"Á">(this, -3503401545221012911L, a);
                              boolean isPositionPacket = packet instanceof ClientboundTeleportEntityPacket
                                 && ((ClientboundTeleportEntityPacket)packet).getId() == c<"Á">(this, -3503401545221012911L, a).getId();
                              if ((isEntityPacket || isPositionPacket) && c<"Á">(this, -3501687410512252462L, a) != null) {
                                 if (packet instanceof ClientboundMoveEntityPacket c03) {
                                    double dx = c03.getXa() / 4096.0;
                                    double dy = c03.getYa() / 4096.0;
                                    double dz = c03.getZa() / 4096.0;
                                    if (c<"Á">(this, -3501687410512252462L, a).v() != null) {
                                       new Vec3(
                                          c<"Á">(c<"Á">(this, -3501687410512252462L, a).v(), -3503729510813604083L, a) + dx,
                                          c<"Á">(c<"Á">(this, -3501687410512252462L, a).v(), -3501787066610775156L, a) + dy,
                                          c<"Á">(c<"Á">(this, -3501687410512252462L, a).v(), -3502859376265966495L, a) + dz
                                       );
                                    } else {
                                       Object var10000 = null;
                                    }

                                    if (Math.abs(dx) > 5.0 || Math.abs(dy) > 5.0 || Math.abs(dz) > 5.0) {
                                       return;
                                    }
                                 }

                                 ClientboundTeleportEntityPacket p = (ClientboundTeleportEntityPacket)packet;
                                 Vec3 pos = new Vec3(p.getX(), p.getY(), p.getZ());
                                 if (c<"Á">(this, -3501687410512252462L, a) != null && pos != null) {
                                    double moveDistance = c<"Á">(this, -3501687410512252462L, a).v().distanceTo(pos);
                                    if (moveDistance > 5.0) {
                                       return;
                                    }

                                    c<"Á">(this, -3501687410512252462L, a).Y(pos);
                                 }
                              }

                              event.setCancelled(true);
                              c<"Á">(this, -3501861612641108870L, a).add(new 友友友何树何友友友树.树友树何何友树树何何(packet));
                           }
                        }
                     } else {
                        this.C(true);
                     }
                  }
               }
            }
         }
      }
   }

   private void p() {
      this.K(true, false);
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 友友友何树何友友友树.a ^ 44950794538543L;
      long ax = a ^ 97152478078338L;
      c<"Á">(this, -7629645813677975997L, a).U(ax);
      c<"Á">(this, -7629662938851533925L, a).U(ax);
      this.C(false);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private boolean U() {
      long a = 友友友何树何友友友树.a ^ 8682078968526L;
      c<"ý">(216160944208180623L, a);
      return c<"Í">(215607071251527459L, a) != null
         && c<"Í">(215607071251527459L, a).isEnabled()
         && !c<"Á">(c<"Í">(215607071251527459L, a), 215208326211111388L, a).C(b<"i">(5863, 1728772742561444428L ^ a))
         && !c<"Á">(c<"Í">(215607071251527459L, a), 215208326211111388L, a).C(b<"i">(32639, 2278059214145379288L ^ a))
         && c<"Á">(this, 215870042628349479L, a).getValue();
   }

   public void Y(Entity entity) {
      long a = 友友友何树何友友友树.a ^ 47139608911928L;
      c<"ý">(8649682059126116217L, a);
      if (entity != null && entity.isAlive() && !entity.isRemoved() && (!(entity instanceof LivingEntity) || !(((LivingEntity)entity).getHealth() <= 0.0F))) {
         double actualDistance = entity.position().distanceTo(mc.player.position());
         if (actualDistance > 5.5) {
            if (c<"Á">(this, 8649517331500348729L, a) != null) {
               this.p();
            }
         } else {
            boolean isSameTarget = c<"Á">(this, 8649517331500348729L, a) != null && entity.getId() == c<"Á">(this, 8649517331500348729L, a).getId();
            if (isSameTarget) {
               c<"á">(
                  this,
                  entity instanceof LivingEntity
                     && c<"Á">((LivingEntity)entity, 8651411753946240629L, a) >= c<"Á">(this, 8650526645351723009L, a).getValue().intValue(),
                  8648549733764171691L,
                  a
               );
               if (c<"Á">(this, 8651319428477093562L, a) != null) {
                  c<"Á">(this, 8651319428477093562L, a).H(entity.position());
                  if (c<"Á">(this, 8651319428477093562L, a).p().distanceTo(mc.player.position()) > 5.5) {
                     this.p();
                     return;
                  }
               }

               if (!this.i(entity)) {
                  this.p();
               } else {
                  if (c<"Á">(this, 8651319428477093562L, a) == null || this.V(entity)) {
                     if (c<"Á">(this, 8651319428477093562L, a) == null) {
                        c<"á">(this, new 友友友何树何友友友树.树何树何树何何友树友(), 8651319428477093562L, a);
                     }

                     this.d(entity);
                  }
               }
            } else if (this.i(entity)) {
               this.p();
               c<"á">(this, new 友友友何树何友友友树.树何树何树何何友树友(), 8651319428477093562L, a);
               this.d(entity);
               c<"Á">(this, 8651319428477093562L, a).H(entity.position());
               c<"á">(this, entity, 8649517331500348729L, a);
            }
         }
      } else {
         if (c<"Á">(this, 8649517331500348729L, a) != null && c<"Á">(this, 8649517331500348729L, a).getId() == entity.getId()) {
            this.p();
         }
      }
   }

   public void K(boolean handlePackets, boolean clearOnly) {
      long a = 友友友何树何友友友树.a ^ 67494728021570L;
      c<"ý">(3347247356149324035L, a);
      if (!c<"Á">(this, 3347942255398401475L, a)) {
         c<"á">(this, true, 3347942255398401475L, a);

         try {
            synchronized (c<"Á">(this, 3347542467136970088L, a)) {
               if (mc.getConnection() != null) {
                  c<"Á">(this, 3347542467136970088L, a).forEach(packet -> {
                     long ax = 友友友何树何友友友树.a ^ 68454487715032L;

                     try {
                        Packet<ClientGamePacketListener> clientPacket = c<"Á">(packet, -798966586948129366L, ax);
                        mc.tell(() -> {
                           long axx = 友友友何树何友友友树.a ^ 119031115641164L;
                           c<"ý">(-1621965895134765555L, axx);

                           try {
                              if (this.U()) {
                                 if (clientPacket instanceof ClientboundSetEntityMotionPacket || clientPacket instanceof ClientboundExplodePacket) {
                                    return;
                                 }

                                 clientPacket.handle(mc.getConnection());
                              }

                              clientPacket.handle(mc.getConnection());
                           } catch (Exception var5x) {
                           }
                        });
                     } catch (Exception var5) {
                     }
                  });
               }

               c<"Á">(this, 3347542467136970088L, a).clear();
            }
         } finally {
            c<"á">(this, null, 3347113037013508931L, a);
            c<"á">(this, null, 3347791439277674688L, a);
            c<"á">(this, false, 3347942255398401475L, a);
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "何大伟为什么要诈骗何炜霖";
   }

   private static class 树何树何树何何友树友 implements 何树友 {
      private Vec3 树树何何何树友树何树;
      private Vec3 何友树友何何何树树树;
      private long 何何友何树树树何何何;
      private boolean 树树何友何何友何友树;
      private Vec3 何何友树友何何友树树;
      private static final long a;
      private static final long b;
      private static final Object[] c = new Object[15];
      private static final String[] d = new String[15];
      private static String HE_JIAN_GUO;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(8113811856506963318L, 3535290231284250022L, MethodHandles.lookup().lookupClass()).a(120895121917950L);
         // $VF: monitorexit
         a = var10000;
         a();
         long var0 = a ^ 85060710622006L;
         Cipher var2;
         Cipher var7 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var3 = 1; var3 < 8; var3++) {
            var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
         }

         var7.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         byte[] var6 = var2.doFinal(new byte[]{-23, 39, 26, -8, 109, -42, -97, -49});
         long var8 = (var6[0] & 255L) << 56
            | (var6[1] & 255L) << 48
            | (var6[2] & 255L) << 40
            | (var6[3] & 255L) << 32
            | (var6[4] & 255L) << 24
            | (var6[5] & 255L) << 16
            | (var6[6] & 255L) << 8
            | var6[7] & 255L;
         byte var10001 = -1;
         b = var8;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = c[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(d[var4]);
               c[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = c[var4];
         if (var5 instanceof String) {
            String var6 = d[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            c[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = d[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            c[var4] = var21;
            return var21;
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 255 && var8 != 204 && var8 != 208 && var8 != 236) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 195) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'l') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 255) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 204) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 208) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/友友友何树何友友友树$树何树何树何何友树友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (d[var4] != null) {
            return var4;
         } else {
            Object var5 = c[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 14;
                  case 1 -> 6;
                  case 2 -> 56;
                  case 3 -> 30;
                  case 4 -> 10;
                  case 5 -> 4;
                  case 6 -> 13;
                  case 7 -> 22;
                  case 8 -> 42;
                  case 9 -> 27;
                  case 10 -> 60;
                  case 11 -> 45;
                  case 12 -> 55;
                  case 13 -> 37;
                  case 14 -> 35;
                  case 15 -> 23;
                  case 16 -> 16;
                  case 17 -> 33;
                  case 18 -> 18;
                  case 19 -> 51;
                  case 20 -> 0;
                  case 21 -> 59;
                  case 22 -> 5;
                  case 23 -> 7;
                  case 24 -> 58;
                  case 25 -> 19;
                  case 26 -> 62;
                  case 27 -> 3;
                  case 28 -> 49;
                  case 29 -> 8;
                  case 30 -> 32;
                  case 31 -> 34;
                  case 32 -> 25;
                  case 33 -> 31;
                  case 34 -> 21;
                  case 35 -> 11;
                  case 36 -> 1;
                  case 37 -> 53;
                  case 38 -> 39;
                  case 39 -> 40;
                  case 40 -> 41;
                  case 41 -> 44;
                  case 42 -> 26;
                  case 43 -> 43;
                  case 44 -> 17;
                  case 45 -> 20;
                  case 46 -> 2;
                  case 47 -> 24;
                  case 48 -> 28;
                  case 49 -> 54;
                  case 50 -> 57;
                  case 51 -> 61;
                  case 52 -> 48;
                  case 53 -> 38;
                  case 54 -> 50;
                  case 55 -> 46;
                  case 56 -> 47;
                  case 57 -> 29;
                  case 58 -> 12;
                  case 59 -> 9;
                  case 60 -> 15;
                  case 61 -> 36;
                  case 62 -> 52;
                  default -> 63;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               d[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         c[0] = "5-X\u00054p:m\u0015\u000e>m?0\u001eH6p26\u001a\u0003uv;3\u001aH8p;!\u0017\u0012u叔厝厈伣桷伎叔厝厈桧B桊佊桇伖桧伳伎叔桇厈";
         c[1] = boolean.class;
         d[1] = "java/lang/Boolean";
         c[2] = "\u0015\u0016(6\u0019>\u0015\u0016?j\u00151\u000f]+w\u0006;\u001f],p\r$U%9{G";
         c[3] = "w\u001fj`:.x_'k03}\u0002,-8.p\u0004(f{(y\u0001(-6.y\u0013%w{\n}\u001d(B 3u";
         c[4] = "+J\u000f@V\u000e\u001fi\u0000\u0000\u001b\u0005\u0015t\u0005]\u0010C\u001di\b[\u0014\b^K\u0003J\r\u0001\u0015=";
         c[5] = "f;K^UIm4Z\u0011)Pb.TR\u001e`t9XO\u000fLc4";
         c[6] = long.class;
         d[6] = "java/lang/Long";
         c[7] = "qD\u0002\u0017)_zK\u0013XHQq@\u0017\u0002";
         c[8] = "EL]\u0005\rzT\u001eD\u007f桯栟佳县佡伢厵佛叭桥<\u0006\u001c7\u0010EL\rO?";
         c[9] = "\u001fi^=,\u0005\u000e;GG伊伤厷桀叼会伊厺桭桀?}nI\n=R>n\u0012\f";
         c[10] = "a\u000bp\u001a\u0005z8Jh\t9E[H(\u000bY,$\u0011i\u0011G\u0014";
         c[11] = "\u0013\u0005G\u001aHG\u0002W^`佮司桡叶佻伽佮栢桡栬&Z\n\u000b\u0006QK\u0019\nP\u0000";
         c[12] = "1G\u001bY_\u000b \u0015\u0002#栽桮伇伪伧栺叧桮伇桮z\u0019\u001dG$\u0013\u0017Z\u001d\u001c\"";
         c[13] = "lf;K\\E}4\"1佺佤叄伋桃栨栾佤佚伋Z\r\u0016\be<c\f\u0017Ty";
         c[14] = "vtKa\u00120g&R\u001b\u0000L&$\u0010{\u0016v&*Xciw}~JdSws6R\u001b";
      }

      public Vec3 p() {
         long a = 友友友何树何友友友树.树何树何树何何友树友.a ^ 125544931966317L;
         return a<"ÿ">(this, -9037077835662692665L, a);
      }

      public Vec3 v() {
         long a = 友友友何树何友友友树.树何树何树何何友树友.a ^ 26488144887766L;
         return a<"ÿ">(this, 4625021414522775688L, a);
      }

      public void U(boolean attacking) {
         long a = 友友友何树何友友友树.树何树何树何何友树友.a ^ 133454240776527L;
         a<"Ì">(this, attacking, -4704278790157028336L, a);
      }

      public void Y(Vec3 pos) {
         long a = 友友友何树何友友友树.树何树何树何何友树友.a ^ 119062820785773L;
         a<"l">(-5650407510025396780L, a);
         if (a<"ÿ">(this, -5650869475203835597L, a) != null) {
            double distance = a<"ÿ">(this, -5650869475203835597L, a).distanceTo(pos);
            if (distance > 5.0) {
               return;
            }
         }

         a<"Ì">(this, pos, -5650869475203835597L, a);
         if (!a<"ÿ">(this, -5650576673465746638L, a)) {
            a<"Ì">(this, pos, -5650500228979931626L, a);
         }
      }

      public void H(Vec3 pos) {
         long a = 友友友何树何友友友树.树何树何树何何友树友.a ^ 9395692366573L;
         a<"l">(-3092323073463355052L, a);
         if (pos != null) {
            if (a<"ÿ">(this, -3092386125752190649L, a) != null) {
               long currentTime = System.currentTimeMillis();
               if (!a<"ÿ">(this, -3092430642819670094L, a) && currentTime - a<"ÿ">(this, -3092821602168044890L, a) < b) {
                  return;
               }

               double distance = a<"ÿ">(this, -3092386125752190649L, a).distanceTo(pos);
               double maxDistance = a<"ÿ">(this, -3092430642819670094L, a) ? 20.0 : 10.0;
               if (distance > maxDistance) {
                  if (a<"ÿ">(this, -3092557630482734442L, a) != null) {
                     a<"Ì">(this, a<"ÿ">(this, -3092557630482734442L, a), -3092386125752190649L, a);
                  }

                  return;
               }
            }

            a<"Ì">(this, pos, -3092386125752190649L, a);
            if (!a<"ÿ">(this, -3092430642819670094L, a)) {
               a<"Ì">(this, pos, -3092557630482734442L, a);
            }

            a<"Ì">(this, System.currentTimeMillis(), -3092821602168044890L, a);
         }
      }

      private static String HE_JIAN_GUO() {
         return "何树友为什么濒天了";
      }
   }

   private static class 树友树何何友树树何何 implements 何树友 {
      final Packet<?> 友何树何树何友友树何;
      final long 树树树树树树友何友何;
      private static String HE_WEI_LIN;

      树友树何何友树树何何(Packet<?> packet) {
         this.友何树何树何友友树何 = packet;
         this.树树树树树树友何友何 = System.currentTimeMillis();
      }

      private static String HE_JIAN_GUO() {
         return "何炜霖国企上班";
      }
   }
}
