package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.ui.何树友友何友友何树树;
import cn.cool.cherish.ui.树友何何何树友树何友;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class 树树树树树树友何友何 extends Module implements 何树友 {
   public static 树树树树树树友何友何 何树友树友树树何何树;
   private final ModeValue 树树树何树树友何何友 = new ModeValue("Mode", "模式", new String[]{"WTap", "STap"}, "WTap");
   private final BooleanValue 何友友友树友何何何树 = new BooleanValue("Only Ground", "仅在地板生效", false);
   private final BooleanValue 何何树友树树友友友树 = new BooleanValue("Only Players", "仅对玩家生效", true);
   private final NumberValue 何树友树友友树何友树 = new NumberValue("Chance", "触发概率", 100, 0, 100, 1);
   private final NumberValue 树树何友何树友树树何 = new NumberValue("Release Duration", "释放持续时间", 120, 50, 1000, 10).A(() -> this.树树树何树树友何何友.K(""));
   private final NumberValue 树树树友树何树何友树 = new NumberValue("Range", "距离", 3.0, 0.5, 7.0, 0.1).A(() -> this.树树树何树树友何何友.K("STap"));
   private final NumberValue 何何何友何何何树何何 = new NumberValue("Scan Radius", "扫描半径", 6.0, 1.0, 15.0, 0.5).A(() -> this.树树树何树树友何何友.K("STap"));
   private final NumberValue 何何何何何何友树友友 = new NumberValue("Buffer", "缓冲", 15.0, 0.0, 20.0, 1.0).A(() -> this.树树树何树树友何何友.K("STap"));
   private final ModeValue 树树友何树树树友友树 = new ModeValue("STap Mode", "STap模式", new String[]{"KillAura", "Normal"}, "KillAura").A(() -> this.树树树何树树友何何友.K("STap"));
   private final 何友友何树何树何树友 友何何树树友友何友友 = new 何友友何树何树何树友(51913986529303L);
   private final 何友友何树何树何树友 树何何树树树友友友友 = new 何友友何树何树何树友(51913986529303L);
   private boolean 树树何何树何友友友友 = false;
   private boolean 树树友友友树何何何友 = false;
   private boolean 友何何友何友树友何何 = false;
   private boolean 树树何何何何树友树友;
   private LivingEntity 何友友友友何何何友树 = null;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[44];
   private static final String[] n = new String[44];
   private static String HE_WEI_LIN;

   public 树树树树树树友何友何() {
      super("Sprint Reset", "疾跑重置", 树何友友何树友友何何.何何何何何树何何友树);
      何树友树友树树何何树 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6836122167900898706L, -6904790141985310563L, MethodHandles.lookup().lookupClass()).a(183827901363365L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(42280836292380L << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[30];
      int var18 = 0;
      String var17 = "©´\u0018\u009a¥J·d\u0091Â\u009aÉ´Ô\u0000¤\u0010më\u001f\u0088V¾z,Ñ>£[\u000f1Za(^°\u008c\u0005²øÈ)\u0085rù\u00065u×·q÷ðvB\u0091\u0007 6ÀÁßÿTTy§{\u0096yÒHdî 'û;HÉ%*X\u0016cë¬\u000eU¼õ\u009a±\u008f\u0014_8ÎÛ\u0003£½Có\u0004Ø\u0006\u0010\u0099:d|(sZý\u001bÉ\u009f7Ôä=L\u0010È\u000b\u0089NÙ?cmY\u0017ä«æs\u0011Ó(¶ç Æ\u0013i5Ï\u0080ä>-\u0086ÚOà7ç[-R\u0089X/GØÚ$\u008dH¥\f\u0004D|9v\u001a\u0015Ï þù\u008e.ð3æÞõ¾\u001d\u0007âzV7ß\u0089#VsÿÛõYñ\u0017\u0095Å7R\u0016\u0018Jú\u009c\u0089\fPäEr°\u0099ûò8ýìÕN\u0088Óâs,Ú\u0018\u0088^\u001d\u0085¤h¶!4ë'Ö#\u008fSê7Íæbô\u001e\u009d»\u0010øê×=BwÌ$aó)£ä\\Ì4 \u008e£Y}\u0010x¹Ö¸Ö\u009f\u001cçë\u0083\u0094\u009eõ[Ù\u0081\u007fPÆc\u0019vºú´\u0080B \u0013\u0097ô¾\u0007¼lSc*®Òñ©\u008a\u0082×\t¡UH\u0090äÌ Ä\u0010\u0094OZ³È(Å3m\u0080s\u0083\u0016@Z\u0098x\u0018E~#j9¹\u0080û~\u0019;\t7c~+q\r\u0087è¦m`g\u008a«¹\u008a \u0002I\u008d\u0006\u0094õ\u001cÓ_º5:p\u008d«xVÅ§ÊRû\u008a\n\u0098÷§Ñ\u0085\u0014qÕ\u0010\u008a[\u0082I«\u0094qC+{(³\u0084!r\u0099 ëÿ×©#ßÝ\u001bï\u0080ñ\u0015\u000fð¶§\u0096<®\u0086\u001f¸\n\u0005\u0011±Ðl=ck\u0013 \u000f}\u0099\u0098Dÿ\u0087\u0000K\\\\\u009c(.º\u0089\u0088\u0014ä\u001e¼Çx\u000e`\u0083Ï\u0082¹I°D\u0010T(\u0003)xÆ\u009eÅ\u0005\u000b5\u008c×fcØ\u0010\u009açî0H¤\u009a¸¦^y@QJ]¾\u0010O\u0097\u001f$Ì\n2\u0010\u0013-Òzø\u008f\u0094L 2/\u0094|\u0090lÙ@å¦\u0013¸·Êªp\u0010÷A\u0007´\u0015¾Ø\\\u001aâ\u0096é2¸_0RoÇ2<s\u000e»ð\u001b;\u0096\u0086Ûn·u|<ÈÚre\f\u0083ó(öä\u007f\u008c«³f>÷á\u009c{1[\u00823È\u007fñ|£\u0010]»\u009cOª©{\u0088_s ûHùí\u009b\u0010Èî\u0006ç7åL\u0086Ïi©\u0013¹ÿòê zÏ\u0082\u0003\u0015*öÉ£oµxTÇd\u0013\u0081ÅC¿\u007fõ2áÊ ãþò\u0096<j0q Yî\u0082Dì\u0011P²ùß\ró\u0002½xH\u009eÒ\u0095Þ\u0084\u0003($â\u008aµ±\u0082¥-\u0096\u0012ÌÂ?ÔÉ\u0089¨ä\u0086\fâiC\u0010\u0085[Ç\u00887Uøö¼\u0007T\u0006à\u008d\u0095ý";
      short var19 = 771;
      char var16 = 16;
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = c(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     c = var20;
                     h = new String[30];
                     l = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(42280836292380L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0001ÛEtPÓùIá\u0083\rã\u0017µ\u001ed".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     j = var6;
                     k = new Long[2];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "yP\u0006Î\u009dû\u0002$_à9 \u008fÏ\u0000³\u008a\u0014¦\u0081[íÂ³\u0088\u0088z\u00068Za»\u00101MQPÑuºØ(´\u0080\u0098(~W×";
                  var19 = 49;
                  var16 = ' ';
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void I(MotionEvent event) {
      d<"ø">(2512886917450129443L, 71432131322583L);
      if (d<"ª">(this, 2508811079253207922L, 71432131322583L).K("STap")) {
         if (!this.Q(new Object[]{52406761729175L})) {
            if (d<"ª">(this, 2512813588149677646L, 71432131322583L)
               && d<"ª">(this, 2512336379795242971L, 71432131322583L)
                  .c(d<"ª">(this, 2509522321283094496L, 71432131322583L).getValue().longValue(), 41972279541307L)) {
               d<"ª">(d<"ª">(mc, 2512285310440107696L, 71432131322583L), 2512568091549833748L, 71432131322583L)
                  .setDown(d<"ª">(this, 2509293193689545214L, 71432131322583L));
               d<"O">(this, false, 2512813588149677646L, 71432131322583L);
            }

            if (d<"ª">(this, 2512813588149677646L, 71432131322583L)
               && d<"ª">(this, 2512336379795242971L, 71432131322583L)
                  .c(d<"ª">(this, 2509522321283094496L, 71432131322583L).getValue().longValue() + c<"l">(23059, 4130275072454735088L), 41972279541307L)) {
               d<"ª">(d<"ª">(mc, 2512285310440107696L, 71432131322583L), 2512568091549833748L, 71432131322583L)
                  .setDown(d<"ª">(this, 2509293193689545214L, 71432131322583L));
               d<"O">(this, false, 2512813588149677646L, 71432131322583L);
            }

            if (d<"ª">(this, 2512207978926062591L, 71432131322583L).c(c<"l">(25561, 8166040451820752187L), 41972279541307L)) {
               d<"ª">(this, 2512207978926062591L, 71432131322583L).D(11747522392279L);
               if (!d<"ª">(this, 2512813588149677646L, 71432131322583L)
                  && d<"ª">(mc.player, 2512602813792349379L, 71432131322583L) > 0.0F
                  && !d<"ª">(d<"ª">(mc, 2512285310440107696L, 71432131322583L), 2512568091549833748L, 71432131322583L).isDown()) {
                  d<"ª">(d<"ª">(mc, 2512285310440107696L, 71432131322583L), 2512568091549833748L, 71432131322583L).setDown(true);
               }
            }
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (n[var4] != null) {
         return var4;
      } else {
         Object var5 = m[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 63;
               case 1 -> 11;
               case 2 -> 59;
               case 3 -> 47;
               case 4 -> 0;
               case 5 -> 58;
               case 6 -> 53;
               case 7 -> 12;
               case 8 -> 30;
               case 9 -> 35;
               case 10 -> 56;
               case 11 -> 10;
               case 12 -> 15;
               case 13 -> 23;
               case 14 -> 17;
               case 15 -> 48;
               case 16 -> 52;
               case 17 -> 32;
               case 18 -> 7;
               case 19 -> 21;
               case 20 -> 22;
               case 21 -> 5;
               case 22 -> 60;
               case 23 -> 38;
               case 24 -> 42;
               case 25 -> 6;
               case 26 -> 28;
               case 27 -> 19;
               case 28 -> 44;
               case 29 -> 25;
               case 30 -> 13;
               case 31 -> 34;
               case 32 -> 62;
               case 33 -> 54;
               case 34 -> 46;
               case 35 -> 50;
               case 36 -> 33;
               case 37 -> 36;
               case 38 -> 43;
               case 39 -> 49;
               case 40 -> 16;
               case 41 -> 39;
               case 42 -> 27;
               case 43 -> 18;
               case 44 -> 20;
               case 45 -> 45;
               case 46 -> 31;
               case 47 -> 3;
               case 48 -> 51;
               case 49 -> 24;
               case 50 -> 61;
               case 51 -> 29;
               case 52 -> 57;
               case 53 -> 2;
               case 54 -> 8;
               case 55 -> 14;
               case 56 -> 41;
               case 57 -> 26;
               case 58 -> 9;
               case 59 -> 4;
               case 60 -> 1;
               case 61 -> 40;
               case 62 -> 37;
               default -> 55;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            n[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/树树树树树树友何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29918;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/树树树树树树友何友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\t2\u009fD¹dX9, \u0001\u0093\bc÷±{n, Æ×9¾D`Ã¹«^\u0019Ié\u008eäõ'O´°«nYB, W¢~>\u0091k\u0007íï\u0083)6Õ\u0017¸\u0096, \u0011²\u0098øIëòz, \u009c\u009e@uÈü.ð, z¡\u0007Õ!ÄÃÕ\tðáU\u0085\u0019DÊT\u009f\u0019Üs 7\u0083, \u0006\u0093%ÝÉÅ\u001a»ù×OÂÞç\u009a\u0006, LßEj@á^\u0094¤\u009fvü'W¥d, \u001b|\u0007\u0019\u0014\u000f4h¾ºg\u0000\u008d\u0097{£, 5\\y\u0015}2RÀ, Ë$\u0011w\u0091Ñ\u009b.÷öâbÔdÇ], óç7òØf@f!\f\u0097\u0097ª)É7, ¬\u001a\u009b)\u0016ÁWU»ù\u0083zÛDl \u0096±U}\u001efÈb, iÓ\u008a6Ë\u001d®|Ð-*Û\u008f\u0012¯Ô, aÑ\u0010QóP\u0019q, §\u0002E\u0093\u0099¯\u0013É\u009f¡=\u009bâ²ÿÐ, *=\u0091Ì \u0088\u009d\u0018ùó\u0006&[ á6, u+®#\u009a·3u, Ô#\u0002Jõvú!, |´Ü¨\u0016\u001a\u0001S,")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/树树树树树树友何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 28387;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])l.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            l.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/树树树树树树友何友何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 170 && var8 != 'O' && var8 != 217 && var8 != 'I') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 238) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 248) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 170) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'O') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 217) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @Override
   public void h() {
      KillAura.x();
      this.树树何何何何树友树友 = false;
      this.何友友友友何何何友树 = null;
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.树树何何树何友友友友) {
            mc.options.keyUp.setDown(this.树树友友友树何何何友);
            this.树树何何树何友友友友 = false;
         }

         if (this.友何何友何友树友何何) {
            KeyMapping.set(mc.options.keyDown.getKey(), false);
            this.友何何友何友树友何何 = false;
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         m[var4] = var21;
         return var21;
      }
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/树树树树树树友何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      m[0] = "|\u0014\u0017p*9sTZ{ $v\tQ=(9{\u000fUvk?r\nU=&9r\u0018Xgk桇栎桫栨栂桔厝佊厱佬";
      m[1] = boolean.class;
      n[1] = "java/lang/Boolean";
      m[2] = "\u0002w<\t>\u0002\tx-FB\u001b\u0006b#\u0005u+\u0010u/\u0018d\u0007\u0007x";
      m[3] = "{9{+y\u0005ty6 s\u0018q$=f`\u000bt\"0f\u007f\u0007h;{\u0005y\u000e}\u00014$c\u000f";
      m[4] = "2\u0005mPY\t2\u0005z\fU\u0006(Nn\u0011F\f8N|\u0010@\t(\u001972]\u00165\u000e~;Z\u00145\u0014`";
      m[5] = "\\\bi\u0015\n\u0003SH$\u001e\u0000\u001eV\u0015/X\u0013\rS\u0013\"X\f\u0001O\ni8\u0010\u0001]\u00035 \u0004\u0000J\u0003";
      m[6] = "\\t\\\u0014\"P\\tKH._F?KV&\\\\e\u0006u?M[~FI";
      m[7] = "W,N?y_W,YcuPMgY}}SW=\u0014ZqOt(Ja}X^";
      m[8] = "T\u001ck-\u000f\u0015[\\&&\u0005\b^\u0001-`\r\u0015S\u0007)+N\u0013Z\u0002)`\u0003\u0015Z\u0010$:N1^\u001e)\u000f\u0015\bV";
      m[9] = "ZU\u001e\u0013A4nv\u0011S\f?dk\u0014\u000e\u0007ylv\u0019\b\u00032/T\u0012\u0019\u001a;d\"";
      m[10] = "eH-)\u0007LeH:u\u000bC\u007f\u0003:k\u0003@eYwJ\u0003KnN+f\fQ";
      m[11] = "bhS\u001dsMm(\u001e\u0016yPhu\u0015PiK/体桬厵受佷及反伨桯栍";
      m[12] = "\"v>D\u007f\u001f\"v)\u0018s\u00108=)\u0006{\u0013\"gd\u001a~\u00175v8D^\u0019/r&:~\u00175v8";
      m[13] = float.class;
      n[13] = "java/lang/Float";
      m[14] = "\tc\u0012\u001fm\u0002\u0006#_\u0014g\u001f\u0003~TRw\u0019\u0003aOR佗厦厡佘栭伩栓伸桻叆";
      m[15] = "\u001dYu{\u0018y\u0012\u00198p\u0012d\u0017D36\u0001w\u0012B>6\u001e{\u000e[uZ\u0018y\u0012R:v!w\u0012B>";
      m[16] = "Aa-#\u0005sN!`(\u000fnK|kn\u0007sFzo%D栍佷叄又伕桻受叩佚佖";
      m[17] = "~nfvX\u0004uaw99\n~jsc";
      m[18] = "mg(XV\u00066f >栱桲伍佟伍佣栱厨桉叁PDJ\u00112n/AR\u000f";
      m[19] = "\u001d3kD*LF2c\"桍核佽厕低栻厗核根伋\u0013\u0019)NP.bRo]A";
      m[20] = "ZYv`C$\u0001X~\u0006TI^]pwXs\u000b\u0003nm=p\u0006B\u007fc\u0007%X\\e\u0006";
      m[21] = "7|\"?O\u007fl}*Y佬发叉叚厙伄佬住叉栀ZcLvhp$;Ijl";
      m[22] = "f\u0010-Rr\u0012=\u0011%4栕桦厘厶厖栭佑伢伆厶UNn\u00059\u0019*Kv\u001b";
      m[23] = "Q\u000e\"+z\\\n\u000f*M余佬伱伶伇伐叇栨厯厨Zvy^\u001c\u0013+=?M\r";
      m[24] = "}@dDm\u0015*\u0016tE\u0001\f%\u0003xQg\u0006.x:\u0000a\u0011/\u0000mVq\u0010";
      m[25] = "x7XgxE#6P\u0001栟栱桜伏根栘叅併优厑 ;bU#7Z8}Y7";
      m[26] = "\u0007BGZ\u0005]\\CO<伦栩叹栾叼叿桢佭叹栾?\u0007\u0006_J_NL@L[";
      m[27] = "F\u0013Y\u00008q\u001d\u0012Qf伛叟厸厵核厥伛佁伦桯!\u000f$\"A\u001fH\u001d\u007f`\u0015";
      m[28] = "\"x5Ssxyy=5栔栌栆叞桔佨栔佈叜栄M\u000epzoe<E6i~";
      m[29] = "\u0019Lg5.\u0015IT96\u001f桱句叨伊桒叜桱佻佶厔K \u000f\u0016Uf6p\u0017HV";
      m[30] = "J\t\u0018\u0018o\u0005\u0011\b\u0010~佌桱厴桵厣桧栈伵伪桵`Ct\u0010\u0011\u0012\r\u0018u\u0018";
      m[31] = "\u001e1&\\@QE0.:栧栥叠伉桇栣栧叿叠桍^\u0000ZAE1$\u0003EMQ";
      m[32] = ".\u0014V!\u001c\u000fu\u0015^G桻桻低伬样会厡厡叐厲.=\u0000\u0018q\u001dQ8\u0018\u0006";
      m[33] = "U\u007f9\u0000Q \u000e~1f佲伐伵叙伜伻佲桔伵佇A]R\"\u0018b0\u0016\u00141\t";
      m[34] = "t/\nq*,\">\u0010!M.\u001f~K#}\u007f\u001fOL*+&p\"Ogr|";
      m[35] = "MV[\u0010(K\u001a\u0000K\u0011DCsPUT$\r\u0002_\u0000\u0005 3";
      m[36] = "_t%\u0010\b]\te?@o_4%dB_\f4\u0014cK\tW[y`\u0006P\r";
      m[37] = "_ac\u000e_|P,w^e佃佨伀佗伸桼佃佨厞栓e\u000f\"\\60\u0007\u0000oHf";
      m[38] = "M:T~8x\u0016;\\\u0018厅佈伭厜佱叛桟取伭伂,b$o\u00123Sg<q";
      m[39] = "\u001b6wl\u001b\u001dY0n{w\u0011|p.!OE|J'p\u0010@[+f N\u0015";
      m[40] = "fp6%</i|7)\u0006;\u000e#t!8k\u000e\u0012qy}?>~'hgo";
      m[41] = "j\u0001\u0002\fZG1\u0000\nj栽佷伊桽档桳叧叩厔厧z\u0003\u001f\u0014i[\u000bZY@7";
      m[42] = "R\"\u007fVgz\t#w0佄佊桶厄栞栩叚叔厬桞\u0007Y{)U.nK k\u0001";
      m[43] = "I\u001c[MZ\u001b\u0012\u001dS+叧伫伩桠栺叨叧伫厷厺#B\u001fHJFR\u001bY\u001c\u0014";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private void m() {
      KillAura.x();
      if (this.Q(new Object[]{52406761729175L})) {
         this.何友友友友何何何友树 = null;
      } else {
         List<LivingEntity> getTargets = Cherish.instance.m().V(this.何何何友何何何树何何.getValue().floatValue(), 16843851536371L);
         List<LivingEntity> validTargets = getTargets.stream().filter(entity -> {
            KillAura.x();
            return entity != null && entity.isAlive() && !entity.isDeadOrDying() && mc.player.hasLineOfSight(entity);
         }).sorted(Comparator.comparingDouble(e -> mc.player.distanceToSqr(e))).toList();
         if (!validTargets.isEmpty()) {
            this.何友友友友何何何友树 = validTargets.get(0);
         }

         this.何友友友友何何何友树 = null;
         if (this.何友友友友何何何友树 != null
            && (
               this.何友友友友何何何友树.isDeadOrDying()
                  || !this.何友友友友何何何友树.isAlive()
                  || mc.player.distanceTo(this.何友友友友何何何友树) > this.何何何友何何何树何何.getValue().floatValue() + 1.0F
                  || !mc.player.hasLineOfSight(this.何友友友友何何何友树)
            )) {
            this.何友友友友何何何友树 = null;
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = m[var4];
      if (var5 instanceof String) {
         String var6 = n[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         m[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = m[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void y() {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L}) && mc.options.keyUp.isDown()) {
         this.树树友友友树何何何友 = true;
         this.树树何何树何友友友友 = true;
         mc.options.keyUp.setDown(false);
         this.友何何树树友友何友友.D(11747522392279L);
      }
   }

   @EventTarget
   public void Y(AttackEvent event) {
      KillAura.x();
      if (this.树树树何树树友何何友.K("WTap")) {
         if (!this.Q(new Object[]{52406761729175L})) {
            Entity var8 = event.getTarget();
            if (var8 instanceof LivingEntity) {
               ;
            }
         }
      }
   }

   @Override
   public void M() {
      this.树树何何何何树友树友 = false;
      this.何友友友友何何何友树 = null;
      this.树树何何树何友友友友 = false;
      this.友何何友何友树友何何 = false;
      this.树何何树树树友友友友.D(11747522392279L);
   }

   @EventTarget
   public void P(LivingUpdateEvent event) {
      KillAura.x();
      if (this.树树树何树树友何何友.K("STap")) {
         if (this.Q(new Object[]{52406761729175L})) {
            if (this.友何何友何友树友何何) {
               this.G();
            }

            this.何友友友友何何何友树 = null;
         } else {
            LivingEntity oldTarget = this.何友友友友何何何友树;
            String distance = this.树树友何树树树友友树.getValue();
            byte var11 = -1;
            switch (distance.hashCode()) {
               case -1955878649:
                  if (!distance.equals("Normal")) {
                     break;
                  }

                  var11 = 0;
               case -540863999:
                  if (distance.equals("KillAura")) {
                     var11 = 1;
                  }
            }

            switch (var11) {
               case 0:
                  this.m();
               case 1:
                  if (KillAura.instance.isEnabled()) {
                     this.何友友友友何何何友树 = KillAura.instance.Y();
                  }

                  this.何友友友友何何何友树 = null;
               default:
                  if (oldTarget != this.何友友友友何何何友树 && this.友何何友何友树友何何) {
                     this.G();
                  }

                  if (this.何友友友友何何何友树 != null && this.何友友友友何何何友树.isAlive() && !this.何友友友友何何何友树.isDeadOrDying()) {
                     double distance = mc.player.distanceTo(this.何友友友友何何何友树);
                     double range = this.树树树友树何树何友树.getValue().doubleValue();
                     double buffer = this.何何何何何何友树友友.getValue().doubleValue() / 100.0;
                     if (distance < range - buffer) {
                        if (友树友友树何树友树友.c(138749102283572L)) {
                           if (!this.友何何友何友树友何何) {
                              KeyMapping.set(mc.options.keyDown.getKey(), true);
                              this.友何何友何友树友何何 = true;
                           }

                           this.树树何何何何树友树友 = false;
                        }

                        if (this.友何何友何友树友何何) {
                           KeyMapping.set(mc.options.keyDown.getKey(), false);
                           this.友何何友何友树友何何 = false;
                        }

                        if (this.树树何何何何树友树友) {
                           return;
                        }

                        树友何何何树友树何友.z(何树友友何友友何树树.树友友何树友树何何友, "Sprint Reset", "You can't keep distance.");
                        this.树树何何何何树友树友 = true;
                     }

                     if (this.友何何友何友树友何何) {
                        KeyMapping.set(mc.options.keyDown.getKey(), false);
                        this.友何何友何友树友何何 = false;
                     }

                     if (this.树树何何何何树友树友) {
                        this.树树何何何何树友树友 = false;
                     }
                  } else {
                     if (this.友何何友何友树友何何) {
                        this.G();
                     }

                     if (this.树树何何何何树友树友) {
                        this.树树何何何何树友树友 = false;
                     }
                  }
            }
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "何树友，和树做朋友";
   }

   private void G() {
      KillAura.x();
      if (this.友何何友何友树友何何) {
         KeyMapping.set(mc.options.keyDown.getKey(), false);
      }

      this.友何何友何友树友何何 = false;
   }
}
