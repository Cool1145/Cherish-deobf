package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.movement.树树何友树友友何何何;
import cn.cool.cherish.module.impl.player.何友树树树树树何友树;
import cn.cool.cherish.module.impl.player.树友何何友何树何树友;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.友友何树树友友树树树;
import cn.cool.cherish.utils.player.友树友友树何树友树友;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MoveMathEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.packet.SyncHandleReceivePacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import com.mojang.blaze3d.platform.InputConstants;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingDeque;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundLoginPacket;
import net.minecraft.network.protocol.game.ClientboundMoveEntityPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundRotateHeadPacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ClientboundSetHealthPacket;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ClientboundTeleportEntityPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.WebBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import why.tree.friend.antileak.Fucker;

public class Velocity extends Module implements 何树友 {
   public static Velocity instance;
   public final ModeValue 树何树友树何友何友友 = new ModeValue("Mode", "模式", new String[]{"Vanilla", "GrimFull", "Watchdog", "JumpReset", "Tick"}, "Vanilla");
   public final BooleanValue 树何树何友何树友树树 = new BooleanValue("Jump Reset Rotate", "跳跃重置旋转", false).A(() -> this.树何树友树何友何友友.K("JumpReset"));
   public final BooleanValue 何友何友树友友何友何 = new BooleanValue("Silent Rotate", "静默旋转", false).A(() -> {
      KillAura.x();
      return this.树何树友树何友何友友.K("JumpReset") && this.树何树何友何树友树树.getValue();
   });
   private final NumberValue 友树何何何何何何友友 = new NumberValue("Ticks", "延迟时刻", 10, 1, 15, 1).A(() -> this.树何树友树何友何友友.K("Tick"));
   private final BooleanValue 树友何何友何树何树友 = new BooleanValue("Grim Full Auto Jump", "GrimFull自动跳跃", false).A(() -> this.树何树友树何友何友友.K("GrimFull"));
   private final NumberValue 何树何何树何何树树树 = new NumberValue("Grim Full Skip Ticks", "GrimFull跳过值", 3, 1, 6, 1).A(() -> this.树何树友树何友何友友.K("GrimFull"));
   private final BooleanValue 友友树友何何树树何树 = new BooleanValue("Grim Full Focus Ground", "GrimFull强制地面处理", false).A(() -> this.树何树友树何友何友友.K("GrimFull"));
   private final BooleanValue 何树何树何友友树何友 = new BooleanValue("Only Move", "仅在移动生效", false);
   private final BooleanValue 树何树何友何何树友何 = new BooleanValue("Only Ground", "仅在地板生效", false);
   private final BooleanValue 何树友何友友友树树何 = new BooleanValue("Flag Check", "回弹检测", false);
   private final BooleanValue 何何何友树友何树树友 = new BooleanValue("Flag Disable", "回弹关闭", false);
   public final NumberValue 何树何何何何友何树何 = new NumberValue("Flag Ticks", "回弹阈值", 6, 0, 30, 1);
   public final BooleanValue 何友何树何何树何友友 = new BooleanValue("Flag Debug", "回弹调试信息", false);
   public final BooleanValue 友何树何友树树何友何 = new BooleanValue("Debug", "反击退调试信息", false);
   private final LinkedBlockingDeque<Packet<ClientGamePacketListener>> 友何树友树友友友树树 = new LinkedBlockingDeque<>();
   private ClientboundSetEntityMotionPacket 树何树友树树树何友何;
   BlockHitResult 树友何友何树友何友友;
   private Level 友树友友何树树友树何;
   public int inGameTick;
   private static final String[] 何友友友友何树友树友;
   private boolean 友友友何何树树何友树 = false;
   private boolean 树树何友友友何友树树 = false;
   private boolean 友友树友何何树友树何 = false;
   private int 何何友何何友何友友树;
   private int 友友何何友友树友何何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[73];
   private static final String[] k = new String[73];
   private static int _何炜霖国企变私企 _;

   public Velocity() {
      super("Velocity", "反击退", 树何友友何树友友何何.何何何何何树何何友树);
      instance = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-566223532595024795L, 6810167407582970813L, MethodHandles.lookup().lookupClass()).a(79819198601400L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher a;
      Cipher var21 = a = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int ax = 1; ax < 8; ax++) {
         var10003[ax] = (byte)(38607390027451L << ax * 8 >>> 56);
      }

      var21.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] ax = new String[49];
      int axx = 0;
      String axxx = "Dp\u0013×ø\u009cG¿â±\u001b\u0012Lp\u0019\u008eª\u0007Ì1rs\u00826\u008fDï\u0003\u0019\f³\u001cØ4§8\u0019\u0000\u0007\u0095 \u008fCË^\u0006ð¨é\u0096d¯!4ä\\úàÊ/Ö\f\u008cRG»´\u007f¬\u008c#Ó6 <h\u0093\u0098][ü\u0015\u0089î\u0014EÍ\u0012O*#\u001bn\u0088%(\u009b=\b¿\u0006\u001d\u000f\u0085\u001aÕ(¬\u0019Øð\u0002¤ý7PI¾ékÞÅ\u000f÷\u0005Ãôìúÿ9äÚ¡\u0087Â%w+\u0013yÆ\u0004\u0096Üåñ(ÉÖ´KÞk\\bãaª\u0091ÚÈNb\u0087\\*úÕTnÂz¢·Ú\u0019¾f\u0094R\u0089\u007fÔ±\\\\È\u0018Ìøy¼/i«·¼\u0090¼\u00adðñ{ÞU\u0010\u000f©\u008f\f\u0087\u008d V\u0083Øø\u001ad 9\rÒåH\u0016\u0080ìT\u0088»\u0087\u0004ÐÉ\u0001#¢\u0013\u008aþjúÐ¬ în\u0097s\u009bfÖ\u0096Ê'\u0019g\u0084ù\u0002F°@ ´\u0004L\u0018\tÚ\u008dä\u001c\u000f¦ÔD\u0010Ä\u0088ÔwÃhs\u0098\u009f\u008e\u001c`\u008aw§~ '?ÂYÛFrþ¿]\u0011Ì\\\u008e¸V\u0080³\u0016Q»_}\u0083×i9X¯|}ã ~~\u001e²þ!\u0094peþÆõp\u0094ï.9\f\u008cíZ\u0006Q\u0099\u007fý\u0015ãÒ¯ö\u0013(v!Ð¬H'\u0086\u00149ò4ÌÞ\u0006P\u0098b:\\rç®\u0083\nd/ÛK\u009dð\u0000¸«á\\hÚÎ¯\u007f(ªZVÅÎ\u001aÞ¯5\u0083\u0010\u001b¼\u0094Ì\u009cæ{\u000fÀws¥¯i[NLåÑ\u000f:þ[jÓE\u0012\u0089\\0#\\\f¬Vn\u0095ø\u009cç0Ä¯K\u0095ýM`ÀtVß\r\u0011¹®!Qme2/Á\u0089w:÷>v¤è\u0005¨&R4èx0jÇ[\u0092\u008dsz?Þ\u000bGh\u001e9\u009d´ñ!\u0010J\u0018~\u0011Þ¤7áìkP¶\u0017·\u001b¾){\u0005IF\u0087\u000e)q\u009aØÂx8öN&!\u007f^Ïøp\u001c\u000e\u0003¸96\u0086\u0011\fsb#ÅÇÔ\u0006(á-(øRæÿÚ>\u0018p]Q\u0081\u0002Uú\u0005\u0082z?ÒôÛØã#ì\t\u009b\u0018É@n>ee¬º\u0089¾¸Ý\u0093þ\u0088hJÎ\u00ad!\u008b¤\u001a\u0082\u0010²º\r\u0096\tn\u0015ÕÇ\u001c\u008e\u009ep[·y ¥{ÿØ\u0011n\u009dDöí\u00ad§L$7cx\u001aà\u0015a\u0007\u0010íV{\u001d'V\u009bS\u001c\u0010¯`ù\u0091¶W%ªcZIª\u0089ñë¦\u0010\u0098\u009dø8\u008a\u008f\u008a&yb¼Ü\u001a}\u009eÂ(p\u009a:jO©Gt\u009a\u001b-8\u0088ÙJ\u001d^ÏÌ\u0099\u001d³¨®\u0018f \u0004mR?kà2ìaÎ ÕJ\u0010{\u0016,Ä(¢®¤nä\u0080\u001aÄá\u008a\u0019\u0010£-û\b\\5¹Ý\u009c\u0003q\u009d÷@òßH\rÐ3\u0014¸F¦cQ\u0080rÝ\u0001 e\u009c«\u0005àl\u001chæ\u0081fi\u000f]¢w3\u0095\u0098\u009aCSaª¾÷qlD\u009fÕæ6 ,1|I@\u0093ÃDÙã]ÏÖ\u008eE@Ì^:È¡C\u000f~\u0010¿R¡\u0019\u0086I*&ëH\u0098f\u008b0(\u0006(Ó\u000fÐÑM&÷l=ceUèM\u0099\u0005\u0083=n\u0096\b7Â÷¹¡\u0082\u0098Á\u001e}\u0093?ü}ûÏ¢¿\u008c(\u0082t>xRGï<\u0082\u0098nzJø\f\u0097C\u0085\u0015\u009bzm\\\u0007\u000bW^\u0019\u0019½C\u0087°\u0082\u0084ôîÊ\u0017\u0004 \u0084 Í½QÀ.ûPQpqÜñÕò¡\u008d¨»¼©i¯ûØ°X¼\u009aB2\u0010\u001e\u0016ÊÕ\u0088\u0088\u009eÇbèuL\u0095¼7»(\u0003Å¸\u008a\u0005AG\u000eÎXFUgîGÈ\u0085°Õ¯\u0011\u0015x¸ä\u0097\u009eá\u0014RTÕêÙ³«dàra\u0018'S\u009fÓ'\u0093éZ^ï£§8lú\u008a\u0082\u000e\u0082·?¨×\u0098 êf³Hv½§ª\u001b=B\u0093°\u008a¿ðB§WÉõ%\u001e\u0086vº\u0095tÂ¶\t_0\u00044\u0091*\u007f\u001aiòÆK\rþÃù1\u0015®\u0003\u009cÎ\u0010\rcëMÓ\t·WyJÐ\fc\u00942\u0089SÅ\na\rw[!B3\u0014 \u0007\u000bØþQvõË-Iøh\u0081/\u008fW\u000f¦U\t÷\u001fÈÒ¼\b}\u0083¿\u0014¢A(\u009c¶Ö9_\u0097d\u00ad\u001c\u0083\bÝê\u008añ?«\u001cèk×\u009c\u0084Âö}\u0094)8¸lçx¢ë\u0001H\u008b0¤\u0010Úæa*dë2\u0092é)¶}«\u008dZ\u007f\u00187\u0088p®+\u0093ó¨åÒ%*SFR¾¢Ûdß\u007f[$K ®\u000boç¡\u0002\u0017¤\u0088@A©\u001bb<flU5ì\b\u0097ã@´%Û\u0098 ¸\u001fê æø^¦T?¶ë3qS(âo¿ÑæP{ÓàÃÀ\u0091e¸\b\u0004`9\u000eO(\u0019Eê\fíÚw\u009f'·\u0096ùÆsÏì¨\n{ÈEêúÐ¼üú%\u0014§fzEäÚ÷\u009f\u001d%T\u0010q&:^ßÝB6¿K\u008e¯\u0018ÀX7\u0018\u0013\u00ad\\j\r\u0017á\u0099O\u000b\f \u0096:) õk÷¡¶Ù)\u0001 sZøË\u008eû³~\u009b1\u0015\u009f\u009a¨L¶ÈÏß(Õ»Ëp\u0013;\u00888xæý9\u0018¥}èÀ\u0081G\u0090F\n\u0006\u0014ä\u007f5áÓ)xiÅ^\u0091ú¦(Û¾{Cáý\u0082¬;T\u0088_rå»ÔSÔ\u0005*\u0082a\u001f0\u008f)ðg2´\u0081;ÌÿRpÔÎûÈ(-¯r\u0003@\u001b/àu\u0087lëø\u0014¥à\u00928\u000e¡¹ì»g\u00028!\u008e*&/4*\u0015ëã\u0004N¬\u000b";
      int axxxx = 1558;
      int axxxxx = '(';
      int var16 = -1;

      label46:
      while (true) {
         String var22 = axxx.substring(++var16, var16 + axxxxx);
         byte var10001 = -1;

         while (true) {
            String var28 = c(a.doFinal(var22.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  ax[axx++] = var28;
                  if ((var16 += axxxxx) >= axxxx) {
                     c = ax;
                     h = new String[49];
                     何友友友友何树友树友 = new String[]{"", ""};

                     for (char c : "lgpg(jgha(U\u007furck".toCharArray()) {
                        何友友友友何树友树友[0] = 何友友友友何树友树友[0] + (char)(c ^ 6);
                     }

                     for (char c : "k}zzmf|\\aemEadda{".toCharArray()) {
                        何友友友友何树友树友[1] = 何友友友友何树友树友[1] + (char)(c ^ '\b');
                     }

                     return;
                  }

                  axxxxx = axxx.charAt(var16);
                  break;
               default:
                  ax[axx++] = var28;
                  if ((var16 += axxxxx) < axxxx) {
                     axxxxx = axxx.charAt(var16);
                     continue label46;
                  }

                  axxx = "\u0088\u001a4× \u0094£c¯t>\u00959µoôç\u0010\u0010\u0003X=\\DF%\u008a\u008f\u008f6\u008fÊ\u00189Ë5Ij6zñ\u001c¦5\u008eW\u001aÇ'®e=\u0092'Êê»";
                  axxxx = 57;
                  axxxxx = ' ';
                  var16 = -1;
            }

            var22 = axxx.substring(++var16, var16 + axxxxx);
            var10001 = 0;
         }
      }
   }

   private boolean D() {
      KillAura.x();
      return 树树何友树友友何何何.何树友树何树友友何何 != null && 树树何友树友友何何何.何树友树何树友友何何.isEnabled() || this.A();
   }

   private void I() {
      this.e();
      this.inGameTick = 0;
      this.T();
      this.友树友友何树树友树何 = mc.level;
   }

   private boolean S() {
      KillAura.x();
      return mc.level.getBlockState(mc.player.blockPosition()).getBlock() instanceof WebBlock && mc.player.onGround()
         || mc.player.isInLava()
         || mc.player.isOnFire()
         || mc.player.isInWater();
   }

   @EventTarget
   public void V(LivingUpdateEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.X(this.树何树友树何友何友友.getValue());
         if (!this.D()) {
            if (this.何树友何友友友树树何.getValue() && this.何何友何何友何友友树 > 0) {
               this.何何友何何友何友友树--;
               this.e();
               this.T();
            }

            if (mc.player.isDeadOrDying()
               || !mc.player.isAlive()
               || mc.player.getHealth() <= 0.0F
               || mc.screen instanceof ProgressScreen
               || mc.screen instanceof DeathScreen) {
               this.e();
               this.T();
            }
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public void e() {
      KillAura.x();
      ClientPacketListener connection = mc.getConnection();
      if (connection == null) {
         this.友何树友树友友友树树.clear();
      } else {
         Packet<ClientGamePacketListener> packet;
         while ((packet = this.友何树友树友友友树树.poll()) != null) {
            try {
               packet.handle(connection);
            } catch (Exception var7) {
               var7.printStackTrace();
               this.友何树友树友友友树树.clear();
               break;
            }
         }
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 46;
               case 1 -> 39;
               case 2 -> 44;
               case 3 -> 33;
               case 4 -> 59;
               case 5 -> 13;
               case 6 -> 28;
               case 7 -> 25;
               case 8 -> 16;
               case 9 -> 3;
               case 10 -> 56;
               case 11 -> 23;
               case 12 -> 20;
               case 13 -> 1;
               case 14 -> 27;
               case 15 -> 57;
               case 16 -> 53;
               case 17 -> 22;
               case 18 -> 15;
               case 19 -> 43;
               case 20 -> 38;
               case 21 -> 18;
               case 22 -> 0;
               case 23 -> 8;
               case 24 -> 51;
               case 25 -> 62;
               case 26 -> 10;
               case 27 -> 48;
               case 28 -> 2;
               case 29 -> 36;
               case 30 -> 61;
               case 31 -> 41;
               case 32 -> 17;
               case 33 -> 19;
               case 34 -> 60;
               case 35 -> 52;
               case 36 -> 54;
               case 37 -> 4;
               case 38 -> 6;
               case 39 -> 12;
               case 40 -> 32;
               case 41 -> 5;
               case 42 -> 40;
               case 43 -> 24;
               case 44 -> 50;
               case 45 -> 11;
               case 46 -> 34;
               case 47 -> 37;
               case 48 -> 21;
               case 49 -> 35;
               case 50 -> 9;
               case 51 -> 49;
               case 52 -> 14;
               case 53 -> 58;
               case 54 -> 26;
               case 55 -> 45;
               case 56 -> 7;
               case 57 -> 30;
               case 58 -> 31;
               case 59 -> 55;
               case 60 -> 47;
               case 61 -> 42;
               case 62 -> 29;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6098;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/Velocity", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[È\bLÿEG;\f§\u00997¹\u0099Üß»Îá70²\u0089Ñ^, &êmýì¹»ÈoìØò?gy4, Ú\u0097N\u0099¼Lä\u0082'\u000bïï\u008eKd?, b[9k9Ï±U6«î\u0003ãw\u0092òFùÞ\u008f\u0089\u0001\u009f1, v.Û\u0015F/ÔÕ{k\u001a\u008e\u008e|HîÌ\u008b£Ùéº)p, l")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/Velocity" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/Velocity" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 170 && var8 != 212 && var8 != 'd' && var8 != 235) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 216) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 231) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 170) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'd') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   @Override
   public void h() {
      this.e();
      this.inGameTick = 0;
      this.友树友友何树树友树何 = null;
      this.T();
   }

   @EventTarget
   public void f(TickEvent event) {
      KillAura.x();
      if (this.树树何友友友何友树树) {
         BlockHitResult blockRayTraceResult = (BlockHitResult)友树友友树何树友树友.T(4.5, mc.player.getYRot(), 90.0F, 31236139168509L);
         if (this.友友树友何何树树何树.Q() && !mc.player.onGround()) {
            return;
         }

         if (树何树树何何树友何何.F(blockRayTraceResult.getBlockPos(), 65332937941542L)) {
            return;
         }

         AABB aabb = new AABB(blockRayTraceResult.getBlockPos().above());
         if (!mc.player.getBoundingBox().intersects(aabb)) {
            return;
         }

         this.e();
         this.树友何友何树友何友友 = new BlockHitResult(blockRayTraceResult.getLocation(), blockRayTraceResult.getDirection(), blockRayTraceResult.getBlockPos(), false);
         float yaw = WrapperUtils.x(119169114399345L) - (float)友友友树何友树友树友.S(35411192288882L, 0.002F, 0.004F);
         WrapperUtils.a(59016142181061L, yaw);
         WrapperUtils.W(90.0F, 51500432313623L);
         WrapperUtils.G(20, 106768409975143L);
         mc.hitResult = this.树友何友何树友何友友;
         PacketUtils.a(112543050219290L, new Rot(yaw, 90.0F, mc.player.onGround()));
         RotationUtils.F(new Rotation(21273681362686L, yaw, 90.0F), 3052380832273L);
         mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, this.树友何友何树友何友友);
         WrapperUtils.s(this.何树何何树何何树树树.getValue().intValue());
         this.友友树友何何树友树何 = true;
         this.树友何友何树友何友友 = null;
         this.树树何友友友何友树树 = false;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "`\u0012\u0004u4moRI~>pj\u000fB86mg\tFsukn\fF88mn\u001eKbuTf\u0010Eu2vz";
      j[1] = "W\u001d:+\u0014\u001d\"=1$\u0005R_%\"#\f\u001b7";
      j[2] = "5[\u0019\u0005nt:\u001bT\u000edi?F_Hlt2@[\u0003/r;E[Hqw7LR\u0014/低厝栤栦桷栐栊伃叾栦";
      j[3] = boolean.class;
      k[3] = "java/lang/Boolean";
      j[4] = "?wI sy4xXo\u0018m6sO54z;";
      j[5] = ";\u0018\u0000\u0013zT4XM\u0018pI1\u0005F^cZ4\u0003K^|V(\u001a\u0000=z_= O\u001c`^";
      j[6] = "\u001cK\u000e6#c\u0013\u000bC=)~\u0016VH{!c\u001bPL0be\u0012UL{/c\u0012GA!bG\u0016IL\u00149~\u001e";
      j[7] = "-B$y'J\u0019a+9jA\u0013|.da\u0007\u001ba#beLXC(s|E\u00135";
      j[8] = int.class;
      k[8] = "java/lang/Integer";
      j[9] = "\u00041sn\u0001\u0018\u00041d2\r\u0017\u001ezp/\u001e\u001d\u000ezk%\u001a\u0014\u0006zK%\u001a\u0014\u0006";
      j[10] = "cj0G\u001e`}b*\bSzgh3TBpg\u007fhjY{bn\"d\\zj`/HWQlz3C";
      j[11] = "`PYo\u0004\u0005o\u0010\u0014d\u000e\u0018jM\u001f\"\u001d\u000boK\u0012\"\u0002\u0007sRYN\u0004\u0005o[\u0016b=\u000boK\u0012";
      j[12] = "\u000e5:}]M\u000e5-!QB\u0014~9<BH\u0004~>;IWN\u0006+0\u0003";
      j[13] = double.class;
      k[13] = "java/lang/Double";
      j[14] = "=RB\u0010O+=RULC$'\u0019X[V5<E]\u0010R0<CY]M.}PWSGl\u0010[_[L61XCPF\u00116CsPV+'N{QV+<Yf_A)6C";
      j[15] = "\u000bvBJ_1\u00046\u000fAU,\u0001k\u0004\u0007F?\u0004m\t\u0007Y3\u0018tBgE3\n}\u001e\u007fQ2\u001d}";
      j[16] = "!@k/Y+!@|sU$;\u000b|m]'!Q1qX#6@m/x-,DsQX#6@m";
      j[17] = "}3'\u000b\u0000V}30W\fYgx0I\u0004Z}\"}h\u0004Qv5!D\u000bK";
      j[18] = "h}aLh<h}v\u0010d3r6v\u000el0hl;-u!ow{\u0011";
      j[19] = "5|\r^[\b:<@UQ\u0015?aK\u0013Y\b2gOX\u001a\u000e;bO\u0013D\u000b7kFO\u001a桶厝佇佶叶佡桶伃栃叨";
      j[20] = "eaw\u00044\u001bea`X8\u0014\u007f*`F0\u0017ep-a<\u000bFesZ0\u001cl";
      j[21] = "TD\u001a],\bTD\r\u0001 \u0007N\u000f\r\u001f(\u0004TU@\u001e4\rNH\u001e\u001f \u0018_S@>4\rNH>\u001f \u0018_S)\u0012,\u0004wN\n\u0016";
      j[22] = "\u0016\u0006\f{ge\u0016\u0006\u001b'kj\fM\u000f:x`\u001cM1;~i\n\u0002\u001b!cc\u0016+\u0019;n";
      j[23] = "*=Mr\u0017\u000e*=Z.\u001b\u00010vN3\b\u000b vI4\u0003\u0014j\u0010P((\u00027-U(";
      j[24] = "Um]\tq0UmJU}?O&^Hn5_&YOe*\u0015JEH\u007f2sa]uy*Nd]";
      j[25] = "l\u0015\u0014#?1cUY(5,f\bRn=1k\u000eV%~7b\u000bVn=1y\u001eW%>*!桪栫伕厛桏叄厰佯伕伅";
      j[26] = "*\u001e\r%t\u001f%^@.~\u0002 \u0003Khv\u001f-\u0005O#5桡伜去叨伓栊去厂伥佶";
      j[27] = "~\u0011ml\u001b}~\u0011z0\u0017rdZz.\u001fq~\u00007%\u0003}>\u0007z0\u0013q~\u00077\u0011\u0015fu\u0011w";
      j[28] = "?0d\u007f\u0019&4?u0x(?4qj";
      j[29] = "\r):T#\u0012\u0005$hQR佲佩伔栓佦伏召号伔栓;hIH$wG1DLr";
      j[30] = "\u0002\u0005\tx*-C\u0004FG|@\u0005CD)s0\u000eHFx\u0015zEEV!eqNG\u0007G";
      j[31] = "-B)X\u001dTlCfg叡叺栉厽佅伺栻栠位桧\u0018W\u001e\tnO|\u0005@\tp";
      j[32] = "~\"QBv\u0019v/\u0003G\u0007佹厄厁似栴栞栽桞厁桸-<T6?\u0005]z\u00156 ";
      j[33] = "6V/x[\u000e9U }!X\nZz\u007f\u001e\f\nk-z\u0011X/\u0004x%YV";
      j[34] = "u_ON114^\u0000q反桅压厠伣桨栗原桑伾~On r\u0005\u000f\nacw";
      j[35] = "91z\u0004a\u0013x05;桇厽余佐厈佦桇伣栝収K\u000bbNz</Y<Nd";
      j[36] = ".5-@Vzo4b\u007f\bqhuu\u0019\u0002z\u00134 NV(~u!\u0001";
      j[37] = "\u001e%[PJN\u0016(\tU;厰佺优桲叼司桪古历伶?\u0001\u0015[(\u0016CX\u0018_~";
      j[38] = "$\u0006 \"\\C,\u000br'-厽叞桿栉伐栴伣栄厥叓M\u0014\u001e-\tap\u001c\u0013\u007f\f";
      j[39] = "eG[\u001cJ\r5\u000eZP*\u000eX\u0004\\\\\u0013^X>ZPX\u000e7\u0001U\u000bU\\";
      j[40] = "\u001dL\u007f#w#\\M0\u001c压厍佽伭厍叟桑厍佽伭N\"u<NHq-.1\u001c";
      j[41] = "\u00023\u001d*Q>C2R\u0015伳伎叼佒佱取伳厐叼栖,+S!Q7\u0013$\b,\u0003";
      j[42] = ">i&%\\2\u007fhi\u001a厠伂栚厖栎叙厠厜栚桌\u0017%\u000e-e0ps\\1s";
      j[43] = "jp|\u0002)\u0005+q3=栏桱伊厏厎叾佋厫桎桕M\u0007p\u0014:11^}\u0010l";
      j[44] = "2hujk\u001e?dhi\u0000根厝叇栀取參口厝栝佄\u0015lL2{r+a@/x";
      j[45] = "\b\u0016<\u0019=V\u0001U.\u000bSA4[vKc\u001e4j!L4ES\u0011u\b,\u0015";
      j[46] = "\u0017/zk\u001c\u000fV.5T佾厡叩叐厈伉栺厡栳叐Km\u001c\u001eT|:dR\rW";
      j[47] = "`[\u0019OLo!ZVp厰栛伀伺併伭伮佟厞厤(\u0019\b3=\u0002\u0010L\f|\"";
      j[48] = "R^m\\}\u0011S\u0002iS\u0002伱栫叺栊佪栛厯叱佤低7b\u000bLRlJcWH]";
      j[49] = "hLm35q)M\"\f佗栅伈伭桅佑佗栅桌桩\\eq-5\u0015d0ub*";
      j[50] = "PC\u0007}C\b\u0011BHB伡厦估桦佫伟桥伸厮厼6r@U\u0013NR \u001eU\r";
      j[51] = "\u0017_:ri\u001eV^uM厕厰栳厠佖伐桏厰栳伾\u000bw0\u000fG\u001ew.=\u000b\u0011";
      j[52] = "(E,,8WiDc\u0013栞佧栌厺栄低叄佧取厺\u001d(wKh\u001dmn6Kw";
      j[53] = "h&Uo0ob>H%I~\u000fv\u0010kv!\u000fF\u001b:ur4?X/&)";
      j[54] = "-112n\u007fl0~\r案住栉佐參佐伌栋叓佐\u0000=m\"n<do3\"p";
      j[55] = "\b\u000b\\\u0004P\u001dI\n\u0013;\u000e\u0016z^\bV3\u0011^Tm\u0005R\u0002[\u000fR\n\t\u000f\t";
      j[56] = "M\u0019Yf\u0016\u0003\u000f\u0006\u0007+(\nq\\\u001ft\u0011\u0004\u0017\u001d\u001cfGz";
      j[57] = "j\u0011kk+ `\tv!R1\rA.obf\rq%>n=6\bf+=f";
      j[58] = "H/5\u001f\u0007B\t.z 叻佲桬低叇根校佲厶低\u0004\u0010\u0004\u001f\u000b\"`BZ\u001f\u0015";
      j[59] = ")\u007f\u001ci\u001f\u0002?,\u0011=g!\u000eR(\u0005'-\u0001_n<\u000b\u0016|k\b*X\u001b(";
      j[60] = "\u001biQJ\u0004\u0017\u0014j^O~A'e\u0004MA\u0010'TRD\fU\u001c/WKE\u001f";
      j[61] = "\\rd\u0013\u0015HZzv\u0010-佸你但佇佷栴佸你变栃*LLC\"\"GJDQ!";
      j[62] = "D\u007f-d} \u0005~b[桛伐桠伞叟伆桛厎桠桚\u001ck~}\u0007rx9 }\u0019";
      j[63] = "\u0012R\u0017IbdSSXv伀栐佲桷佻厵厞栐佲厭&Fa9Q_B\u0014?9O";
      j[64] = "-vauvqlw.J伔栅叓众厓厉厊栅栉众Pzu,n{4(+,p";
      j[65] = "b\u00198w]h#\u0018wH桻叆伂另佔桑厡佘厜另\t'\u0018= \u001ekq\ffb";
      j[66] = "x=y'%\u001cw>v\"_JD1, a\u001aD\u0000~d/N}yw'=\\";
      j[67] = ":\"\u007f\u0006& {#09叚厎叄佃伓栠栀伐叄标N\u0003\u007f1jc2Zr5<";
      j[68] = "4'*\u0003&:u&e<栀伊栐变栂栥栀伊及但\u001bU\"l`d!Fu&`";
      j[69] = "iQ\u0013Z[\u0014fR\u001c_!BU]F]\u0011\u0014Ul\u001e\u001fGW>\u000e\u0016UCF";
      j[70] = "/\u000e\u000e\n])n\u000fA5伿桝住佯佢佨厡伙栋佯?\\\u0019urW\u0007\t\u001d:m";
      j[71] = "|A>V\u0010P=@qi佲你伜厾栖厪佲栤桘厾\u000fY\u0013\r?Lk\u000bM\r!";
      j[72] = "\u0000\u000eo0NHA\u000f \u000f伬另你叱桇双厲佸叾佯^?M\u0015C\u0003:m\u0013\u0015]";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   public static Object m() {
      try {
         return Class.forName(何友友友友何树友树友[0]).getMethod(何友友友友何树友树友[1]);
      } catch (Exception var0) {
         return null;
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void j(StrafeEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (!this.D()) {
            if (this.何何友何何友何友友树 == 0) {
               if (this.树何树友树何友何友友.K("GrimFull")
                  && this.树友何何友何树何树友.getValue()
                  && this.友友树友何何树友树何
                  && mc.player.hurtTime > 0
                  && mc.player.onGround()
                  && !mc.options.keyJump.isDown()) {
                  mc.player.jumpFromGround();
                  this.友友树友何何树友树何 = false;
               }
            }
         }
      }
   }

   private boolean A() {
      KillAura.x();
      return 何友树树树树树何友树.友友树树何树何树友友 != null
         && 何友树树树树树何友树.友友树树何树何树友友.isEnabled()
         && 何友树树树树树何友树.友友树树何树何树友友.何友友何树树树树友树.K("Grim 1.17+")
         && 何友树树树树树何友树.友友树树何树何树友友.友何何树友友树友友何
         && 何友树树树树树何友树.友友树树何树何树友友.何何何树何何友友何树;
   }

   @EventTarget
   public void X(WorldEvent event) {
      KillAura.x();
      if (!this.D()) {
         this.e();
         this.inGameTick = 0;
         this.T();
      }
   }

   @Override
   public void M() {
      this.e();
      this.inGameTick = 0;
      this.T();
   }

   @EventTarget(0)
   public void M(SyncHandleReceivePacketEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (!this.D()) {
            Packet<?> packet = event.getPacket();
            if (packet instanceof ClientboundLoginPacket) {
               this.e();
               this.T();
            }

            if (packet instanceof ClientboundPlayerPositionPacket wrapper) {
               if (wrapper.getId() != mc.player.getId()) {
                  return;
               }

               if (this.何树友何友友友树树何.getValue()) {
                  this.何何友何何友何友友树 = this.何树何何何何友何树何.getValue().intValue();
                  if (this.何友何树何何树何友友.getValue()) {
                     ClientUtils.P(125527250587045L, "[Velocity]Debug Flags.");
                  }
               }

               if (this.何何何友树友何树树友.getValue()) {
                  this.n();
                  if (this.何友何树何何树何友友.getValue()) {
                     ClientUtils.P(125527250587045L, "[Velocity]Auto Disabled.");
                  }
               }
            }

            if (this.何何友何何友何友友树 == 0) {
               if ((!this.树何树何友何何树友何.getValue() || mc.player.onGround()) && (!this.何树何树何友友树何友.getValue() || 友友何树树友友树树树.I(112951582722913L))) {
                  if (packet instanceof ClientboundSetEntityMotionPacket wrapper) {
                     if (wrapper.getId() != mc.player.getId()) {
                        return;
                     }

                     this.友友友何何树树何友树 = true;
                     if (this.友何树何友树树何友何.getValue()) {
                        ClientUtils.P(125527250587045L, "[Debug]Entity Velocity >> " + 友友友树何友树友树友.x(1391347873739L, 1000, 10000) + " <<");
                     }

                     String var15 = this.树何树友树何友何友友.getValue();
                     byte var16 = -1;
                     switch (var15.hashCode()) {
                        case 1897755483:
                           if (!var15.equals("Vanilla")) {
                              break;
                           }

                           var16 = 0;
                        case -1618295391:
                           if (!var15.equals("JumpReset")) {
                              break;
                           }

                           var16 = 1;
                        case 390612638:
                           if (!var15.equals("GrimFull")) {
                              break;
                           }

                           var16 = 2;
                        case 609795629:
                           if (var15.equals("Watchdog")) {
                              var16 = 3;
                           }
                     }

                     switch (var16) {
                        case 0:
                           event.setCancelled(true);
                        case 1:
                           if (!this.树何树何友何树友树树.getValue()) {
                              break;
                           }

                           if (wrapper.getYa() < 0) {
                              this.树何树友树树树何友何 = null;
                           }

                           this.树何树友树树树何友何 = wrapper;
                        case 2:
                           if (!(Boolean)Fucker.isLogin || !(Boolean)Fucker.isBeta && !(Boolean)Fucker.友友何友何何树何树树 || !(Boolean)Cherish.MODULE_SHOULD_START) {
                              break;
                           }

                           if (this.inGameTick < 65) {
                              this.树树何友友友何友树树 = false;
                              event.setCancelled(false);
                              this.e();
                              this.T();
                              return;
                           }

                           if (wrapper.getYa() < 0) {
                              this.树树何友友友何友树树 = false;
                              event.setCancelled(false);
                              this.e();
                              this.T();
                              return;
                           }

                           if (mc.level.getBlockState(mc.player.blockPosition()).getBlock() instanceof WebBlock && mc.player.onGround()) {
                              this.树树何友友友何友树树 = false;
                              event.setCancelled(false);
                              this.e();
                              this.T();
                              return;
                           }

                           if (mc.player.onClimbable()) {
                              this.树树何友友友何友树树 = false;
                              event.setCancelled(false);
                              this.e();
                              this.T();
                              return;
                           }

                           this.树树何友友友何友树树 = true;
                           event.setCancelled(true);
                        case 3:
                           event.setCancelled(true);
                           mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, wrapper.getYa() / 8000.0, mc.player.getDeltaMovement().z);
                     }
                  }

                  if (packet instanceof ClientboundExplodePacket wrapper) {
                     if (wrapper.getKnockbackX() == 0.0F || wrapper.getKnockbackY() == 0.0F || wrapper.getKnockbackZ() == 0.0F) {
                        return;
                     }

                     if (this.友何树何友树树何友何.getValue()) {
                        ClientUtils.P(125527250587045L, "[Debug]Explode Entity Velocity >> " + 友友友树何友树友树友.x(1391347873739L, 1000, 10000) + " <<");
                     }

                     String var19 = this.树何树友树何友何友友.getValue();
                     byte var20 = -1;
                     switch (var19.hashCode()) {
                        case 1897755483:
                           if (!var19.equals("Vanilla")) {
                              break;
                           }

                           var20 = 0;
                        case 390612638:
                           if (var19.equals("GrimFull")) {
                              var20 = 1;
                           }
                     }

                     switch (var20) {
                        case 0:
                           event.setCancelled(true);
                        case 1:
                           if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树) && (Boolean)Cherish.MODULE_SHOULD_START) {
                              if (this.inGameTick < 65) {
                                 this.树树何友友友何友树树 = false;
                                 event.setCancelled(false);
                                 this.e();
                                 this.T();
                                 return;
                              }

                              if (mc.level.getBlockState(mc.player.blockPosition()).getBlock() instanceof WebBlock && mc.player.onGround()) {
                                 this.树树何友友友何友树树 = false;
                                 event.setCancelled(false);
                                 this.e();
                                 this.T();
                                 return;
                              }

                              if (mc.player.onClimbable()) {
                                 this.树树何友友友何友树树 = false;
                                 event.setCancelled(false);
                                 this.e();
                                 this.T();
                                 return;
                              }

                              this.树树何友友友何友树树 = true;
                              event.setCancelled(true);
                           }
                     }
                  }

                  if (this.树树何友友友何友树树
                     && (Boolean)Fucker.isLogin
                     && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)
                     && (Boolean)Cherish.MODULE_SHOULD_START) {
                     if (this.inGameTick < 65) {
                        this.树树何友友友何友树树 = false;
                        event.setCancelled(false);
                        this.e();
                        this.T();
                        return;
                     }

                     if (mc.level.getBlockState(mc.player.blockPosition()).getBlock() instanceof WebBlock && mc.player.onGround()) {
                        this.树树何友友友何友树树 = false;
                        event.setCancelled(false);
                        this.e();
                        this.T();
                        return;
                     }

                     if (mc.player.onClimbable()) {
                        this.树树何友友友何友树树 = false;
                        event.setCancelled(false);
                        this.e();
                        this.T();
                        return;
                     }

                     if (!(packet instanceof ClientboundSystemChatPacket)
                        && !(packet instanceof ClientboundSetEntityMotionPacket)
                        && !(packet instanceof ClientboundExplodePacket)
                        && !(packet instanceof ClientboundSetTimePacket)
                        && !(packet instanceof ClientboundMoveEntityPacket)
                        && !(packet instanceof ClientboundTeleportEntityPacket)
                        && !(packet instanceof ClientboundSoundPacket)
                        && !(packet instanceof ClientboundSetHealthPacket)
                        && !(packet instanceof ClientboundPlayerPositionPacket)
                        && !(packet instanceof ClientboundPlayerAbilitiesPacket)
                        && !(packet instanceof ClientboundRotateHeadPacket)
                        && !(packet instanceof ClientboundSectionBlocksUpdatePacket)
                        && !(packet instanceof ClientboundBlockUpdatePacket)) {
                        event.setCancelled(true);
                        this.友何树友树友友友树树.add((Packet<ClientGamePacketListener>)packet);
                     }
                  }
               }
            }
         }
      }
   }

   @EventTarget
   public void H(LivingUpdateEvent event) {
      KillAura.x();
      if (!this.D()) {
         if (mc.level != this.友树友友何树树友树何) {
            this.I();
         }

         if (this.树何树友树何友何友友.K("JumpReset") && mc.player.onGround() && mc.player.isSprinting() && !this.S()) {
            if (this.树何树何友何树友树树.getValue() && mc.player.hurtTime > 0) {
               if (this.树何树友树树树何友何 == null) {
                  return;
               }

               float motionX = (float)(this.树何树友树树树何友何.getXa() / 8000.0);
               float motionZ = (float)(this.树何树友树树树何友何.getZa() / 8000.0);
               float fixedYaw = (float)Math.toDegrees(Math.atan2(motionX, -motionZ));
               if (!this.何友何友树友友何友何.getValue()) {
                  mc.player.setYRot(fixedYaw);
               }

               RotationUtils.F(new Rotation(21273681362686L, fixedYaw, mc.player.getXRot()), 3052380832273L);
            }

            if (mc.player.hurtTime > 6 && !mc.options.keyJump.isDown()) {
               mc.options.keyJump.setDown(true);
            }

            if (!cn.cool.cherish.module.impl.player.树友何何友何树何树友.树友友树友友友友树何.isEnabled()) {
               boolean isHoldingJump = InputConstants.isKeyDown(mc.getWindow().getWindow(), mc.options.keyJump.getKey().getValue());
               mc.options.keyJump.setDown(isHoldingJump);
            }
         }
      }
   }

   public void T() {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.友何树友树友友友树树.clear();
         this.友友树友何何树友树何 = false;
         this.友友何何友友树友何何 = 0;
         this.树树何友友友何友树树 = false;
         this.树何树友树树树何友何 = null;
      }
   }

   private static String LIU_YA_FENG() {
      return "何树友被何大伟克制了";
   }

   @EventTarget
   private void G(MoveMathEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (!this.D()) {
            if (this.何何友何何友何友友树 == 0) {
               if ((!this.树何树何友何何树友何.getValue() || mc.player.onGround()) && (!this.何树何树何友友树何友.getValue() || 友友何树树友友树树树.I(112951582722913L))) {
                  if (this.树何树友树何友何友友.K("Tick")) {
                     if (this.友友友何何树树何友树) {
                        event.setCancelled(true);
                        this.友友何何友友树友何何++;
                     }

                     event.setCancelled(false);
                  }

                  if (this.友友何何友友树友何何 > this.友树何何何何何何友友.getValue().intValue() || !this.友友友何何树树何友树) {
                     this.友友友何何树树何友树 = false;
                     this.友友何何友友树友何何 = 0;
                  }
               }
            }
         }
      }
   }
}
