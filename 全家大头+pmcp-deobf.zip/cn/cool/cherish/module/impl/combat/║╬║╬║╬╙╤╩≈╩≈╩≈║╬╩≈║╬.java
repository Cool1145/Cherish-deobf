package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.树树树何友友树友友友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.phys.Vec3;

public class 何何何友树树树何树何 extends Module implements 何树友 {
   private final NumberValue 何友友友树树树友树树;
   private final NumberValue 友树友树友树树友何友;
   private final BooleanValue 友树何友树何树友友友;
   private final BooleanValue 友何友何树树何何何友;
   private final NumberValue 友树友树树何树何友何;
   private final NumberValue 友何树何友树友树何何;
   private final List<LivingEntity> 何何树友何何树友友树;
   private final Map<Integer, List<Vec3>> 树树友树友何友树树何;
   private final Map<Integer, List<Vec3>> 何友树何何何树何树何;
   private final Map<Integer, Boolean> 树树树友树友何何树树;
   private final Map<Integer, List<Double>> 友友树友树友树何树友;
   private final int 友友何友友何树树何友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[50];
   private static final String[] l = new String[50];
   private static String HE_JIAN_GUO;

   public 何何何友树树树何树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/combat/何何何友树树树何树何.a J
      // 003: ldc2_w 66808420730063
      // 006: lxor
      // 007: lstore 1
      // 008: aload 0
      // 009: sipush 9782
      // 00c: ldc2_w 3387792314621014607
      // 00f: lload 1
      // 010: lxor
      // 011: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 016: sipush 27041
      // 019: ldc2_w 9201233488122183122
      // 01c: lload 1
      // 01d: lxor
      // 01e: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 023: ldc2_w 8130941667985951047
      // 026: lload 1
      // 027: invokedynamic v (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 02f: aload 0
      // 030: new cn/cool/cherish/value/impl/NumberValue
      // 033: dup
      // 034: sipush 23499
      // 037: ldc2_w 5181710319227097023
      // 03a: lload 1
      // 03b: lxor
      // 03c: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 041: sipush 32599
      // 044: ldc2_w 5059021135745870634
      // 047: lload 1
      // 048: lxor
      // 049: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04e: bipush 50
      // 050: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 053: bipush 15
      // 055: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 058: bipush 100
      // 05a: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 05d: bipush 5
      // 05e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 061: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 064: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.何友友友树树树友树树 Lcn/cool/cherish/value/impl/NumberValue;
      // 067: aload 0
      // 068: new cn/cool/cherish/value/impl/NumberValue
      // 06b: dup
      // 06c: sipush 16268
      // 06f: ldc2_w 7908241709258779645
      // 072: lload 1
      // 073: lxor
      // 074: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 079: sipush 26081
      // 07c: ldc2_w 1234594392184779165
      // 07f: lload 1
      // 080: lxor
      // 081: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 086: bipush 90
      // 088: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 08b: bipush 45
      // 08d: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 090: sipush 180
      // 093: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 096: bipush 15
      // 098: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 09b: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 09e: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.友树友树友树树友何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 0a1: aload 0
      // 0a2: new cn/cool/cherish/value/impl/BooleanValue
      // 0a5: dup
      // 0a6: sipush 18590
      // 0a9: ldc2_w 5223212299312749804
      // 0ac: lload 1
      // 0ad: lxor
      // 0ae: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0b3: sipush 19596
      // 0b6: ldc2_w 2964059866149902585
      // 0b9: lload 1
      // 0ba: lxor
      // 0bb: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c0: bipush 1
      // 0c1: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0c4: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0c7: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.友树何友树何树友友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0ca: aload 0
      // 0cb: new cn/cool/cherish/value/impl/BooleanValue
      // 0ce: dup
      // 0cf: sipush 24373
      // 0d2: ldc2_w 8006755804794309443
      // 0d5: lload 1
      // 0d6: lxor
      // 0d7: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0dc: sipush 15181
      // 0df: ldc2_w 5080805923144249141
      // 0e2: lload 1
      // 0e3: lxor
      // 0e4: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e9: bipush 1
      // 0ea: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0ed: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0f0: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.友何友何树树何何何友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0f3: aload 0
      // 0f4: new cn/cool/cherish/value/impl/NumberValue
      // 0f7: dup
      // 0f8: sipush 26377
      // 0fb: ldc2_w 2697719060945466230
      // 0fe: lload 1
      // 0ff: lxor
      // 100: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 105: sipush 13665
      // 108: ldc2_w 1623181445899428127
      // 10b: lload 1
      // 10c: lxor
      // 10d: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 112: ldc2_w 8.0
      // 115: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 118: dconst_1
      // 119: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 11c: ldc2_w 20.0
      // 11f: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 122: ldc2_w 0.5
      // 125: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 128: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 12b: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.友树友树树何树何友何 Lcn/cool/cherish/value/impl/NumberValue;
      // 12e: aload 0
      // 12f: new cn/cool/cherish/value/impl/NumberValue
      // 132: dup
      // 133: sipush 13215
      // 136: ldc2_w 3677537495592904680
      // 139: lload 1
      // 13a: lxor
      // 13b: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 140: sipush 2624
      // 143: ldc2_w 8171466771160014384
      // 146: lload 1
      // 147: lxor
      // 148: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何何友树树树何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14d: bipush 0
      // 14e: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 151: bipush 0
      // 152: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 155: bipush 3
      // 156: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 159: ldc2_w 0.01
      // 15c: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 15f: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 162: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.友何树何友树友树何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 165: aload 0
      // 166: new java/util/ArrayList
      // 169: dup
      // 16a: invokespecial java/util/ArrayList.<init> ()V
      // 16d: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.何何树友何何树友友树 Ljava/util/List;
      // 170: aload 0
      // 171: new java/util/HashMap
      // 174: dup
      // 175: invokespecial java/util/HashMap.<init> ()V
      // 178: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.树树友树友何友树树何 Ljava/util/Map;
      // 17b: aload 0
      // 17c: new java/util/HashMap
      // 17f: dup
      // 180: invokespecial java/util/HashMap.<init> ()V
      // 183: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.何友树何何何树何树何 Ljava/util/Map;
      // 186: aload 0
      // 187: new java/util/HashMap
      // 18a: dup
      // 18b: invokespecial java/util/HashMap.<init> ()V
      // 18e: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.树树树友树友何何树树 Ljava/util/Map;
      // 191: aload 0
      // 192: new java/util/HashMap
      // 195: dup
      // 196: invokespecial java/util/HashMap.<init> ()V
      // 199: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.友友树友树友树何树友 Ljava/util/Map;
      // 19c: aload 0
      // 19d: getstatic cn/cool/cherish/module/impl/combat/何何何友树树树何树何.j J
      // 1a0: l2i
      // 1a1: putfield cn/cool/cherish/module/impl/combat/何何何友树树树何树何.友友何友友何树树何友 I
      // 1a4: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-535619064511669946L, -6651550005496352199L, MethodHandles.lookup().lookupClass()).a(258935778494607L);
      // $VF: monitorexit
      a = var10000;
      b();
      long var5 = a ^ 80938309743338L;
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(var5 << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[14];
      int var12 = 0;
      String var11 = "\u0086Ë\u00ad;#\u001a\u0097@G\u0003\u0098Oæ%±\u0096\u0010\u0010ý'U3Ýqç\u0007\u009a\u0016\u0013\u0012\u0089³¤\u0010\u009fi²\u007f\u009dúd´ï¿=:M:\u009b.(µðã\u0014h«\u001c\u0080\u000eZPíGÃÃ\u0095\u0010ÇË¦°àøÅ\r\u0006Ú«\u0097¯.\u009a#ù\u0003À~£ù¢ üUR³û\u0094\u007f*faË³¢9ùõ\u0091à'\u0093i´$¿'¶\u0097°\u0095|[\u0007\u0010¤³;~«ó¡øºfA\n=±®©\u0010\u0080íFÄ\u0090U1ùÔ\u001b»Zj]\u009d\u008f ú®$l\u008a[pÕ\nÉ\u0006Å²\u0006á\u0011eI\b{i¯Ë ~\bg\u0096\u000fùýÛ\u0010\u0006Ê\u001fí\u0084în\u009bïIú,(Ö\u0098»\u0010\u000b\u0014áÕÛNú2\u0087\u0086»ð¡b6\u007f\u0010¦\u0083;õ¼èmÄà\\LðÛß»·\u0010Â\u0007¶¼\u0083\u001bëQpºÂ¬óZ\u001f\u0015";
      short var13 = 259;
      char var10 = 16;
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[14];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var5 << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-60, -19, 1, 76, 105, -20, 118, -98});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "\u009bj=\u0004º\u0014`©\u009en\u0006å\u0090\u008d\u0006F\u008dù\u0093å\u0085ÇZq*ÞË*¥<7d\u0010XX]X.Ç\nñ\"Ý\u007fð²\u0083ìN";
                  var13 = 49;
                  var10 = ' ';
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   private double J(LivingEntity target) {
      long a = 何何何友树树树何树何.a ^ 10274362805152L;
      long ax = a ^ 5704740554393L;
      c<"ù">(4591608925032349375L, a);
      if (this.w(new Object[]{ax})) {
         return 1.0;
      } else {
         何何何友树树树何树何.何何友何树何友树树树 pattern = this.d(target.getId());
         double offsetX = target.getX() - mc.player.getX();
         double offsetZ = target.getZ() - mc.player.getZ();
         double horizontalDist = Math.sqrt(offsetX * offsetX + offsetZ * offsetZ);
         double baseFlightTime = horizontalDist / 1.5;
         double targetMotionX = target.getX() - c<"n">(target, 4591326022555227261L, a);
         double targetMotionZ = target.getZ() - c<"n">(target, 4591054542926338073L, a);
         double targetSpeed = Math.sqrt(targetMotionX * targetMotionX + targetMotionZ * targetMotionZ);
         double targetAngle = Math.atan2(targetMotionZ, targetMotionX);
         double throwAngle = Math.atan2(offsetZ, offsetX);
         double angleDiff = Math.abs(targetAngle - throwAngle);
         if (angleDiff > Math.PI) {
            angleDiff = (Math.PI * 2) - angleDiff;
         }

         double relativeSpeedFactor = Math.abs(angleDiff) < Math.PI / 2
            ? 0.85
            : (Math.abs(angleDiff) > Math.PI * 3.0 / 4.0 ? 1.4 + Math.min(targetSpeed * 2.0, 0.8) : 1.15);
         double adjustedTime = baseFlightTime * relativeSpeedFactor * Math.min(1.0 + horizontalDist / 20.0 * 0.5, 1.8);
         return Math.max(this.R(adjustedTime, pattern, targetSpeed, horizontalDist) * 1.05, 1.0);
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 22;
               case 1 -> 17;
               case 2 -> 37;
               case 3 -> 41;
               case 4 -> 7;
               case 5 -> 44;
               case 6 -> 4;
               case 7 -> 6;
               case 8 -> 57;
               case 9 -> 48;
               case 10 -> 26;
               case 11 -> 8;
               case 12 -> 21;
               case 13 -> 36;
               case 14 -> 0;
               case 15 -> 16;
               case 16 -> 61;
               case 17 -> 43;
               case 18 -> 35;
               case 19 -> 33;
               case 20 -> 29;
               case 21 -> 10;
               case 22 -> 50;
               case 23 -> 62;
               case 24 -> 14;
               case 25 -> 28;
               case 26 -> 12;
               case 27 -> 32;
               case 28 -> 15;
               case 29 -> 18;
               case 30 -> 11;
               case 31 -> 27;
               case 32 -> 38;
               case 33 -> 42;
               case 34 -> 54;
               case 35 -> 51;
               case 36 -> 13;
               case 37 -> 49;
               case 38 -> 2;
               case 39 -> 58;
               case 40 -> 25;
               case 41 -> 23;
               case 42 -> 34;
               case 43 -> 19;
               case 44 -> 47;
               case 45 -> 30;
               case 46 -> 9;
               case 47 -> 20;
               case 48 -> 52;
               case 49 -> 46;
               case 50 -> 55;
               case 51 -> 31;
               case 52 -> 45;
               case 53 -> 59;
               case 54 -> 56;
               case 55 -> 63;
               case 56 -> 3;
               case 57 -> 39;
               case 58 -> 5;
               case 59 -> 53;
               case 60 -> 1;
               case 61 -> 40;
               case 62 -> 24;
               default -> 60;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void b() {
      k[0] = "C/X\\= Lo\u0015W7=I2\u001e\u0011? D4\u001aZ|&M1\u001a\u00111 M#\u0017K|\u0004I-\u001a~'=A";
      k[1] = "l+~3-*X\bqs`!R\u0015t.kgZ\by(o,\u0019*r9v%R\\";
      k[2] = "8\u0018\u0016\u0015\u001a\u00187X[\u001e\u0010\u00052\u0005PX\u0018\u0018?\u0003T\u0013[\u001e6\u0006TX\u0016\u00186\u0014Y\u0002[伢伎伣右桧桤桦伎桧佭";
      k[3] = "\u0015RUCGI\u001a\u0012\u0018HMT\u001fO\u0013\u000e^G\u001aI\u001e\u000eAK\u0006PUn]K\u0014Y\tvIJ\u0003Y";
      k[4] = "g\u007f\u00071h\u001clp\u0016~\u0014\u0005cj\u0018=#5u}\u0014 2\u0019bp";
      k[5] = "y\u001a\u0003\u001baBg\u0012\u0019T\u0003^`\u000f";
      k[6] = "x4JDHYf<P\u000b+Mb";
      k[7] = "]<!Zfz]<6\u0006juGw\"\u001by\u007fWw0\u001a\u007fzG {8beZ721egZ-,";
      k[8] = double.class;
      l[8] = "java/lang/Double";
      k[9] = "/o_;fR/oHgj]5$\\zyW%$[}rHo\\Nv8";
      k[10] = "k)AQ\u0005adi\fZ\u000f|a4\u0007\u001c\u0007al2\u0003WDge7\u0003\u001c\tae%\u000eFD佛佝伒厤栣桻栟佝桖伺\u0016桻叅栙厌桾佧厡栟佝厌";
      k[11] = "\u0015\u001b";
      k[12] = "@mE[ncO-\bPd~Jp\u0003\u0016lcGv\u0007]/eNs\u0007\u0016bcNa\nL/余佶佖厠栩栐栝佶栒伾\u001c佔余叨佖桺佭及栝栲栒";
      k[13] = "X\u0003\u0007l\u007ftWCJguiR\u001eA!}t_\u0018Ej>rV\u001dE!stV\u000fH{>低佮伸叢栞栁栊佮桼佼+栁栊株桼叢栞佅低佮伸";
      k[14] = "Pb|\"5&_\"1)?;Z\u007f:o7&Wy>$t伜佦叇伇伔厑伜佦栝桃";
      k[15] = "V1e4iwYq(?cj\\,#ypyY*.youE3e\u0015iwY:*9PyY*.";
      k[16] = "s\n\\\u001d\u001a4s\nKA\u0016;iAK_\u001e8s\u001b\u0006~\u001e3x\fZR\u0011)";
      k[17] = "KYUt0yKYB(<vQ\u0012B64uKH\u000f\u0015-dLSO)";
      k[18] = "MY|\u0011P\rMYkM\\\u0002W\u0012kST\u0001MH&tX\u001dn]xOT\nD";
      k[19] = "\u001a_k<sF\u0011Pzs\u0012H\u001a[~)";
      k[20] = ";}\u0001^!\u000efg\u000e\u0011J桺栛叙桴口众厠栛栃估 v\u0003c \u0001\u00115\u0007=c";
      k[21] = "eh`\rBY.1{\u001bs佾伉佐叒桻伮栺桍栔佌bBF%b \u0018\t\u001f>t";
      k[22] = "B\u001d'`A|\u001d\u0018i p叟厾厺叚伀伭栅传桠栀]@'\u001e\u0015z;\u0001nF\u000b";
      k[23] = "{sF~\u000b\b~uU-:XF/\u0010{\u0004\bF\u001eB(HVipQ|H\b";
      k[24] = "\u0014!|\u001di1I;sR\u0002企叮厅叓桺栛桅叮桟栉c87Wy`^ilW'";
      k[25] = "o\u0010l\u000bYF|DlU!FSJ$S\u0010\u0015S{u\u0017\u0018Ix\u0016o\u0012HM";
      k[26] = " \u001aV\u0010_Cv\u0016Q\u00009@JJ\u0019P\b\u0016Js\u0015\t@TsBL\u001eG\u0015";
      k[27] = "U{`H7S\bao\u0007\\叽厯栅叏栯原栧伱栅叏6`^\r&`\u0007#ZSe";
      k[28] = "{\u001f\u0001\u007fe\u0010&\u0005\u000e0\u000e传厁桡估作体桤伟桡估\u00012\u001d#B\u00010q\u0019}\u0001";
      k[29] = "xwbrB&3.yds桅厊发低栄桪原厊发低\u001dB98}\"g\t`#k";
      k[30] = "'Rq\u001c#Cq^v\fE@M\u0002>\\t\u0014M;2\u0005<Tt\nk\u0012;\u0015";
      k[31] = ".$'Ez7s>(\n\u0011厙栎厀桒栢佌桃佊厀伖;+1m|;\u0006zjm\"";
      k[32] = "\u0004M_lP~O\u0014Dza余佨栱样栚似栝栬叫叭\u0003PaDG\u001fy\u001b8_Q";
      k[33] = "\u0006\f%lzu[\u0016*#\u0011佅佢桲厊住佌栁叼厨桐\u0012*aOSrcxwXZ";
      k[34] = "i\u0007UKE,8\u001dC_< \u0000N\u0013\r\fw\u0000~\u0014WE49OM@Bu";
      k[35] = "\u0014H\u000b\f!\t\u001e[L\tC厺格叱厷伶伞厺佸栫厷kr\u0003ZU\u0016\u001bx\u0010\u001dP";
      k[36] = "aYL2\u0001\u000f0CZ&x\u0003\b\u0010\ntG\\\b \r.\u0001\u00171\u0011T9\u0006V";
      k[37] = "}v'up\u00116/<cA伶桕栊厕栃厂厨桕栊厕\u001ap\u000e=|g`;W&j";
      k[38] = "_8Z(i]_r@M\u0005`]%M6hPXw\u001fqT";
      k[39] = "E|BbO\u001f\u0013pEr)\u001c/,\r\"\u0018K/\u0015\u0001{P\b\u0016$XlWI";
      k[40] = "\u00137[c)DN-T,B只栳厓栮叞桛栰叩伍叴\u001dxBPoG )\u0019P1";
      k[41] = "S{H\u0013\u0016S\u0002a^\u0007o_:2\u000eUP\u0001:\u0002\n\u0010\u0013K\u0014`[\n\u0005_";
      k[42] = " JW\u000b\u001c\u0013}PXDw厽栀佰司桬伪桧叚叮司u\u001e\u0007y@\u0000\u001e\u0019\u001fu_";
      k[43] = "\n6nVtfW,a\u0019\u001f又佮厒佟栱栆佖佮伌叁(vrS<9Cqj_#";
      k[44] = "5\u0012*9jJh\b%v\u0001N\fN~vxY`\u000e$yb'7Mw>\u007fKw\u0017x$\u0001";
      k[45] = "]\\Q{h\u0002\u0016\u0005JmY去桵栠佽佉桀桡伱佤根\u0014h\u001d\u001dV\u0011n#D\u0006@";
      k[46] = "\u0015~\u0016s_DHd\u0019<4栰栵栀厹栔号佴佱栀档\r\bIM#\u0016<KM\u0013`";
      k[47] = "\u0016(fmg\u0019Z0d+\u0004口句桖叕厐叇口栿伒叕S5EW ')~\u001cL6";
      k[48] = "v\nf>lp'\u0010p*\u0015|\u001fC x%*\u001fs'\"lh&B~5k)";
      k[49] = "%#;d\u001a\fx94+q厢佁桝伊叙桨厢栅伙伊\u001aK\nf{''\u001aQf%";
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25770;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/何何何友树树树何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/何何何友树树树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void x() {
      long a = 何何何友树树树何树何.a ^ 66898651419005L;
      long ax = a ^ 73157780428945L;
      long axx = a ^ 17499995052740L;
      long axxx = a ^ 117610151612834L;
      c<"ù">(7306420231494476898L, a);
      c<"n">(this, 7306084188141400435L, a).clear();
      Iterator var10 = Cherish.instance.S().W(c<"n">(this, 7307670449611271607L, a).getValue().floatValue() + 10.0F, axxx).iterator();
      if (var10.hasNext()) {
         LivingEntity entity = (LivingEntity)var10.next();
         if (树树树何友友树友友友.P(entity, ax, true)
            && !entity.isDeadOrDying()
            && entity.getHealth() > 0.0F
            && RotationUtils.r(axx, c<"n">(this, 7306572375026307625L, a).getValue().floatValue(), entity)
            && RotationUtils.O(entity) <= c<"n">(this, 7307670449611271607L, a).getValue().doubleValue()) {
            c<"n">(this, 7306084188141400435L, a).add(entity);
         }
      }

      c<"n">(this, 7306084188141400435L, a).sort(Comparator.comparingDouble(RotationUtils::O));
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/何何何友树树树何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'n' && var8 != 226 && var8 != 'v' && var8 != 'd') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'f') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 249) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'n') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 226) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'v') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private Vec3 h(LivingEntity target, double ticks) {
      long a = 何何何友树树树何树何.a ^ 100446339283181L;
      if (mc.level == null) {
         return null;
      } else {
         this.Y(target);
         this.d(target.getId());
         double motionX = target.getX() - c<"n">(target, -3676352694395033808L, a);
         double motionZ = target.getZ() - c<"n">(target, -3676096410627822764L, a);
         double predictedX = target.getX() + motionX * ticks;
         double predictedZ = target.getZ() + motionZ * ticks;
         return new Vec3(predictedX, target.getY() + target.getEyeHeight(), predictedZ);
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private 何何何友树树树何树何.何何友何树何友树树树 d(int entityId) {
      long a = 何何何友树树树何树何.a ^ 44294582935044L;
      c<"ù">(7646139015217785627L, a);
      List motionHistory = c<"n">(this, 7643172631251713935L, a).getOrDefault(entityId, new ArrayList());
      List<Double> speedHistory = c<"n">(this, 7643680515210242929L, a).getOrDefault(entityId, new ArrayList<>());
      List<Vec3> positionHistory = c<"n">(this, 7642628408095951226L, a).getOrDefault(entityId, new ArrayList<>());
      if (motionHistory.size() >= 3 && speedHistory.size() >= 3 && !positionHistory.isEmpty()) {
         Vec3 currentMotion = (Vec3)motionHistory.get(motionHistory.size() - 1);
         Vec3 prevMotion = (Vec3)motionHistory.get(motionHistory.size() - 2);
         double currentSpeed = speedHistory.get(speedHistory.size() - 1);
         double prevSpeed = speedHistory.get(speedHistory.size() - 2);
         double acceleration = currentSpeed - prevSpeed;
         double currentAngle = Math.atan2(c<"n">(currentMotion, 7646462621899945178L, a), c<"n">(currentMotion, 7646037152377698816L, a));
         double prevAngle = Math.atan2(c<"n">(prevMotion, 7646462621899945178L, a), c<"n">(prevMotion, 7646037152377698816L, a));
         double angleDiff = Math.abs(currentAngle - prevAngle);
         if (angleDiff > Math.PI) {
            angleDiff = (Math.PI * 2) - angleDiff;
         }

         何何何友树树树何树何.树树树树友树何何何何 type = angleDiff > 0.3
            ? c<"v">(7646092887359406330L, a)
            : (
               acceleration > 0.01
                  ? c<"v">(7646290147015728519L, a)
                  : (acceleration < -0.01 ? c<"v">(7642724201841520300L, a) : c<"v">(7646622091417653254L, a))
            );
         return new 何何何友树树树何树何.何何友何树何友树树树(
            type, currentAngle, 0.0, !c<"n">(this, 7646756376110008106L, a).getOrDefault(entityId, true), positionHistory.get(positionHistory.size() - 1)
         );
      } else {
         return new 何何何友树树树何树何.何何友何树何友树树树(
            c<"v">(7643304526543089526L, a),
            0.0,
            0.0,
            false,
            positionHistory.isEmpty() ? c<"v">(7646952121508178880L, a) : positionHistory.get(positionHistory.size() - 1)
         );
      }
   }

   private void a() {
      long a = 何何何友树树树何树何.a ^ 12453545093977L;
      if (c<"ù">(6863954184649023046L, a) == null) {
         if (mc.level == null) {
            return;
         }

         c<"n">(this, 6863586263518088023L, a).stream().filter(entity -> {
            long ax = 何何何友树树树何树何.a ^ 126230711854473L;
            c<"ù">(-7957349908018409322L, ax);
            return entity instanceof Player && entity != mc.player;
         }).forEach(this::Y);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   protected void t() {
      long a = 何何何友树树树何树何.a ^ 112442324902404L;
      long ax = a ^ 116737586720573L;
      c<"ù">(-7630007196826511589L, a);
      if (!this.w(new Object[]{ax})) {
         c<"n">(this, -7633500186195872390L, a).clear();
         c<"n">(this, -7632951495070448753L, a).clear();
         c<"n">(this, -7629394199627334870L, a).clear();
         c<"n">(this, -7632615230553811087L, a).clear();
      }
   }

   private Rotation v(LivingEntity target) {
      long a = 何何何友树树树何树何.a ^ 31135652129777L;
      c<"ù">(-2312106978113872146L, a);
      Vec3 targetPos = target.position().add(0.0, target.getBbHeight() * 0.7, 0.0);
      if (c<"n">(this, -2311860423652191249L, a).getValue()) {
         double tick = this.J(target);
         PlayerInfo playerInfo = mc.getConnection().getPlayerInfo(mc.player.getUUID());
         if (playerInfo != null) {
            int ping = Math.max(playerInfo.getLatency(), 0);
            tick += ping / 50.0 + c<"n">(this, -2311380404725853335L, a).getValue().doubleValue();
         }

         Vec3 predictedPos = this.h(target, tick);
         if (predictedPos != null) {
            targetPos = predictedPos;
         }
      }

      return c<"n">(this, -2311789616153226522L, a).getValue() ? this.r(targetPos) : this.W(targetPos);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private Rotation r(Vec3 targetPos) {
      long a = 何何何友树树树何树何.a ^ 71015755402895L;
      long ax = a ^ 43632689214753L;
      Vec3 playerPos = new Vec3(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ());
      Vec3 diff = targetPos.subtract(playerPos);
      double horizontalDist = Math.sqrt(
         c<"n">(diff, 4221920794614639243L, a) * c<"n">(diff, 4221920794614639243L, a)
            + c<"n">(diff, 4221801267147285585L, a) * c<"n">(diff, 4221801267147285585L, a)
      );
      double heightDiff = c<"n">(diff, 4220511835236080724L, a);
      double flightTime = horizontalDist / 3.0;
      c<"ù">(4222091888237345680L, a);
      double gravityDrop = 0.025 * flightTime * flightTime;
      double compensatedHeight = heightDiff + gravityDrop;
      double distanceScale = Math.min(horizontalDist / 20.0, 1.5);
      compensatedHeight *= 0.7 + 0.3 * distanceScale;
      if (horizontalDist > 40.0) {
         compensatedHeight *= 1.2;
      }

      if (horizontalDist < 15.0) {
         compensatedHeight *= 0.8;
      }

      double compensatedAngle = Math.atan2(compensatedHeight, horizontalDist);
      float yaw = (float)Math.toDegrees(Math.atan2(c<"n">(diff, 4221801267147285585L, a), c<"n">(diff, 4221920794614639243L, a))) - 90.0F;
      float pitch = Mth.clamp((float)Math.toDegrees(compensatedAngle), -45.0F, 45.0F);
      return new Rotation(ax, Mth.wrapDegrees(yaw), -pitch);
   }

   private boolean E() {
      long a = 何何何友树树树何树何.a ^ 31902776557793L;
      c<"ù">(-794393136582085122L, a);
      return mc.player.getMainHandItem().getItem() instanceof BowItem || mc.player.getMainHandItem().getItem() instanceof CrossbowItem;
   }

   private void A(Rotation target) {
      long a = 何何何友树树树何树何.a ^ 119808764764505L;
      long ax = a ^ 111706763783683L;
      float yawDiff = Mth.wrapDegrees(target.getYaw() - mc.player.getYRot());
      float pitchDiff = target.J(new Object[]{ax}) - mc.player.getXRot();
      float speedFactor = c<"n">(this, -7687741453706487265L, a).getValue().floatValue();
      mc.player.setYRot(mc.player.getYRot() + yawDiff * speedFactor);
      mc.player.setXRot(mc.player.getXRot() + pitchDiff * speedFactor);
   }

   private void Y(LivingEntity entity) {
      long a = 何何何友树树树何树何.a ^ 16438324114358L;
      c<"ù">(-4058116728380062039L, a);
      if (entity != null) {
         int entityId = entity.getId();
         Vec3 currentPosition = new Vec3(entity.getX(), entity.getY(), entity.getZ());
         Vec3 currentMotion = new Vec3(
            entity.getX() - c<"n">(entity, -4061775059689165717L, a),
            entity.getY() - c<"n">(entity, -4058028944860094336L, a),
            entity.getZ() - c<"n">(entity, -4062048525782376433L, a)
         );
         this.O(c<"n">(this, -4061625978914872120L, a), entityId, currentPosition);
         this.O(c<"n">(this, -4062203187557871043L, a), entityId, currentMotion);
         this.O(
            c<"n">(this, -4061709940241742141L, a),
            entityId,
            Math.sqrt(
               c<"n">(currentMotion, -4058296327527671886L, a) * c<"n">(currentMotion, -4058296327527671886L, a)
                  + c<"n">(currentMotion, -4057858130674165400L, a) * c<"n">(currentMotion, -4057858130674165400L, a)
            )
         );
         c<"n">(this, -4058698934961034600L, a).put(entityId, entity.onGround());
      }
   }

   private boolean M() {
      long a = 何何何友树树树何树何.a ^ 16261812215588L;
      c<"ù">(-6107817399797126597L, a);
      return c<"n">(c<"n">(mc, -6111143957404432813L, a), -6110447605984710370L, a).isDown()
         && mc.player.isUsingItem()
         && (mc.player.getUseItem().getItem() instanceof BowItem || mc.player.getUseItem().getItem() instanceof CrossbowItem);
   }

   private Rotation W(Vec3 pos) {
      long a = 何何何友树树树何树何.a ^ 81089348623651L;
      long ax = a ^ 51650068670093L;
      Vec3 playerPos = new Vec3(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ());
      Vec3 diff = pos.subtract(playerPos);
      double dist = Math.sqrt(
         c<"n">(diff, 2971056128078199079L, a) * c<"n">(diff, 2971056128078199079L, a)
            + c<"n">(diff, 2970916379367421949L, a) * c<"n">(diff, 2970916379367421949L, a)
      );
      float yaw = (float)Math.toDegrees(Math.atan2(c<"n">(diff, 2970916379367421949L, a), c<"n">(diff, 2971056128078199079L, a))) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(c<"n">(diff, 2971896854819246072L, a), dist)));
      return new Rotation(ax, Mth.wrapDegrees(yaw), Mth.clamp(pitch, -90.0F, 90.0F));
   }

   private double R(double time, 何何何友树树树何树何.何何友何树何友树树树 pattern, double targetSpeed, double distance) {
      long a = 何何何友树树树何树何.a ^ 104601692344715L;
      c<"ù">(-1903899460227226476L, a);
      return time;
   }

   @EventTarget
   public void Q(Render3DEvent event) {
      long a = 何何何友树树树何树何.a ^ 31438071618107L;
      long ax = a ^ 18690315736834L;
      c<"ù">(-5898661960727564508L, a);
      if (!this.w(new Object[]{ax}) && this.E() && this.M()) {
         this.a();
         this.x();
         if (!c<"n">(this, -5899068364771689931L, a).isEmpty()) {
            LivingEntity target = (LivingEntity)c<"n">(this, -5899068364771689931L, a).get(0);
            Rotation rotation = this.v(target);
            this.A(rotation);
         }
      }
   }

   private <T> void O(Map<Integer, List<T>> historyMap, int entityId, T value) {
      long a = 何何何友树树树何树何.a ^ 132639848957484L;
      c<"ù">(8229442146415588147L, a);
      List<T> history = historyMap.computeIfAbsent(entityId, k -> new ArrayList<>());
      history.add(value);
      if (history.size() > 8) {
         history.remove(0);
      }
   }

   private static String LIU_YA_FENG() {
      return "行走的50万——何炜霖";
   }

   private record 何何友何树何友树树树(何何何友树树树何树何.树树树树友树何何何何 友友树友友友友树何友, double 友友何何友何何友友友, double 何何友何何何树何何树, boolean 友何树何友树友友何何, Vec3 友何友树树友树树友何) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[11];
      private static final String[] c = new String[11];
      private static String HE_JIAN_GUO;

      private 何何友何树何友树树树(何何何友树树树何树何.树树树树友树何何何何 友友树友友友友树何友, double 友友何何友何何友友友, double 何何友何何何树何何树, boolean 友何树何友树友友何何, Vec3 友何友树树友树树友何) {
         this.友友树友友友友树何友 = 友友树友友友友树何友;
         this.友友何何友何何友友友 = 0.0;
         this.何何友何何何树何何树 = 0.0;
         this.友何树何友树友友何何 = false;
         this.友何友树树友树树友何 = 友何友树树友树树友何;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-3816352710779038449L, -5963825059308496314L, MethodHandles.lookup().lookupClass()).a(264784079328249L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 208 && var8 != 204 && var8 != 'o' && var8 != 245) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'b') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 165) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 208) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 204) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'o') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/何何何友树树树何树何$何何友何树何友树树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 13;
                  case 1 -> 19;
                  case 2 -> 38;
                  case 3 -> 57;
                  case 4 -> 43;
                  case 5 -> 24;
                  case 6 -> 50;
                  case 7 -> 52;
                  case 8 -> 0;
                  case 9 -> 45;
                  case 10 -> 12;
                  case 11 -> 10;
                  case 12 -> 25;
                  case 13 -> 9;
                  case 14 -> 8;
                  case 15 -> 48;
                  case 16 -> 17;
                  case 17 -> 7;
                  case 18 -> 2;
                  case 19 -> 21;
                  case 20 -> 31;
                  case 21 -> 18;
                  case 22 -> 63;
                  case 23 -> 6;
                  case 24 -> 20;
                  case 25 -> 41;
                  case 26 -> 1;
                  case 27 -> 14;
                  case 28 -> 58;
                  case 29 -> 3;
                  case 30 -> 44;
                  case 31 -> 53;
                  case 32 -> 15;
                  case 33 -> 55;
                  case 34 -> 35;
                  case 35 -> 47;
                  case 36 -> 54;
                  case 37 -> 37;
                  case 38 -> 34;
                  case 39 -> 42;
                  case 40 -> 46;
                  case 41 -> 16;
                  case 42 -> 62;
                  case 43 -> 56;
                  case 44 -> 59;
                  case 45 -> 49;
                  case 46 -> 27;
                  case 47 -> 39;
                  case 48 -> 30;
                  case 49 -> 23;
                  case 50 -> 36;
                  case 51 -> 40;
                  case 52 -> 61;
                  case 53 -> 32;
                  case 54 -> 60;
                  case 55 -> 11;
                  case 56 -> 5;
                  case 57 -> 4;
                  case 58 -> 51;
                  case 59 -> 33;
                  case 60 -> 26;
                  case 61 -> 29;
                  case 62 -> 28;
                  default -> 22;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\u000b-Eq+C\u0004m\bz!^\u00010\u0003<)C\f6\u0007wjE\u00053\u0007<'C\u0005!\nfj佹伽伖厠栃桕栽伽桒伾6休佹厣伖桺佇厏栽桹桒";
         b[1] = double.class;
         c[1] = "java/lang/Double";
         b[2] = "\u0006>8=Ws\u0006>/a[|\u001cu;|Hv\fu<{CiF\r)p\t";
         b[3] = boolean.class;
         c[3] = "java/lang/Boolean";
         b[4] = "IF\u000bf\u001a.F\u0006Fm\u00103C[M+\u0018.N]I`[(GXI+\u0016.GJDq[伔使佽叮栔桤桐使根佰!桤桐栻根叮栔传伔使佽";
         b[5] = "\bJ894U\u0003E)vU[\bN-,";
         b[6] = "Qh;\u0005~}F4i}叀叟栢厚厚厾叀栅佦厚YGxs\u0005:eLam^";
         b[7] = "\f\u001b\u0011\f\u000b3\u001bGCt伫伏厥佷伮伩桯伏伻栳sMJn\bE\u0013\n\b.\u0018";
         b[8] = "z@\\\u0003T,m\u001c\u000e{只伐叓桨栧厸栰桔叓伬>BU=`LLKE$o";
         b[9] = "#7\u000e\u001eoG4k\\f发佻桐佛厯桿发句伔佛l\\rE-h\r\u001a+\u0018t";
         b[10] = "T\\$o2;C\u0000v\u0017厌厙佣估厅佊伒厙叽厮F.sfP\u0002&i1&@";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public 何何何友树树树何树何.树树树树友树何何何何 v() {
         long a = 何何何友树树树何树何.何何友何树何友树树树.a ^ 68401741604882L;
         return a<"Ð">(this, 7897778134694474073L, a);
      }

      public Vec3 U() {
         long a = 何何何友树树树何树何.何何友何树何友树树树.a ^ 131916353210867L;
         return a<"Ð">(this, 5510226002357689535L, a);
      }

      public double Y() {
         long a = 何何何友树树树何树何.何何友何树何友树树树.a ^ 99708741977557L;
         return a<"Ð">(this, 4638036457826426315L, a);
      }

      public double T() {
         long a = 何何何友树树树何树何.何何友何树何友树树树.a ^ 5456680487429L;
         return a<"Ð">(this, 5732723005343272220L, a);
      }

      public boolean Q() {
         long a = 何何何友树树树何树何.何何友何树何友树树树.a ^ 41245235924914L;
         return a<"Ð">(this, 736744764232753028L, a);
      }

      private static String LIU_YA_FENG() {
         return "何炜霖国企变私企";
      }
   }

   private static enum 树树树树友树何何何何 implements  {
      何何树树树何树树友友,
      何何何友树何树树树何,
      友树树何何树树何何树,
      何树树友树友友树树友,
      何树友何树树何树树友,
      友友树树何何树树何友,
      树何树友友何友何树友,
      树友友何树树友友友何;

      private static final long a;
      private static final Object[] b = new Object[12];
      private static final String[] c = new String[12];
      private static String HE_DA_WEI;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(2701516327471314821L, 4483255956971214911L, MethodHandles.lookup().lookupClass()).a(233446409049580L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 100242052796665L;
         a();
         Cipher var1;
         Cipher var13 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[8];
         int var6 = 0;
         String var5 = "·@\u009cQ`\u001dDÊ\u00194:\bÍ\u001a¬ò\u001eä\u0098\u00931\u0098ú_\u00101£\u0011È¹\u0080\u00ad)ý\u008eX¶\u0014\u0083z§\u0010\u0010I)â*\u0000µ3\u0088\u009d\u0097\u0084¼¸\u0095F\b¤2\u0006]\u009c\u0087g\u001d\bQí¼Â\"ûCµ\u0018lÀ9ªJ6<\u001eK»ÌtµsRá\u0094»n\u0099ÿáxZ";
         byte var7 = 101;
         char var4 = 24;
         int var12 = -1;

         label28:
         while (true) {
            String var14 = var5.substring(++var12, var12 + var4);
            byte var10001 = -1;

            while (true) {
               String var20 = a(var1.doFinal(var14.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var20;
                     if ((var12 += var4) >= var7) {
                        何何树树树何树树友友 = new 何何何友树树树何树何.树树树树友树何何何何();
                        何何何友树何树树树何 = new 何何何友树树树何树何.树树树树友树何何何何();
                        友树树何何树树何何树 = new 何何何友树树树何树何.树树树树友树何何何何();
                        何树树友树友友树树友 = new 何何何友树树树何树何.树树树树友树何何何何();
                        何树友何树树何树树友 = new 何何何友树树树何树何.树树树树友树何何何何();
                        友友树树何何树树何友 = new 何何何友树树树何树何.树树树树友树何何何何();
                        树何树友友何友何树友 = new 何何何友树树树何树何.树树树树友树何何何何();
                        树友友何树树友友友何 = new 何何何友树树树何树何.树树树树友树何何何何();
                        return;
                     }

                     var4 = var5.charAt(var12);
                     break;
                  default:
                     var0[var6++] = var20;
                     if ((var12 += var4) < var7) {
                        var4 = var5.charAt(var12);
                        continue label28;
                     }

                     var5 = "\u009a±Ìîy2\u0006§,\u009dÉ¥\u008bêûq\u0010üjA7-à\u007fgÅ\u009búÞ\u0084ió¼";
                     var7 = 33;
                     var4 = 16;
                     var12 = -1;
               }

               var14 = var5.substring(++var12, var12 + var4);
               var10001 = 0;
            }
         }
      }

      public static 何何何友树树树何树何.树树树树友树何何何何[] J() {
         long var0 = a ^ 29704052682609L;
         return (何何何友树树树何树何.树树树树友树何何何何[])a<"Þ">(918838129971491660L, var0).clone();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public static 何何何友树树树何树何.树树树树友树何何何何 h(String name) {
         return Enum.valueOf(何何何友树树树何树何.树树树树友树何何何何.class, name);
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 240 && var8 != 163 && var8 != 222 && var8 != 208) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 226) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'g') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 240) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 163) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 222) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/何何何友树树树何树何$树树树树友树何何何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 24;
                  case 1 -> 14;
                  case 2 -> 54;
                  case 3 -> 50;
                  case 4 -> 25;
                  case 5 -> 33;
                  case 6 -> 41;
                  case 7 -> 26;
                  case 8 -> 3;
                  case 9 -> 56;
                  case 10 -> 16;
                  case 11 -> 39;
                  case 12 -> 46;
                  case 13 -> 47;
                  case 14 -> 27;
                  case 15 -> 20;
                  case 16 -> 40;
                  case 17 -> 11;
                  case 18 -> 8;
                  case 19 -> 53;
                  case 20 -> 43;
                  case 21 -> 28;
                  case 22 -> 2;
                  case 23 -> 32;
                  case 24 -> 23;
                  case 25 -> 57;
                  case 26 -> 44;
                  case 27 -> 19;
                  case 28 -> 52;
                  case 29 -> 0;
                  case 30 -> 7;
                  case 31 -> 51;
                  case 32 -> 30;
                  case 33 -> 55;
                  case 34 -> 17;
                  case 35 -> 45;
                  case 36 -> 9;
                  case 37 -> 35;
                  case 38 -> 21;
                  case 39 -> 58;
                  case 40 -> 62;
                  case 41 -> 60;
                  case 42 -> 4;
                  case 43 -> 59;
                  case 44 -> 36;
                  case 45 -> 38;
                  case 46 -> 42;
                  case 47 -> 1;
                  case 48 -> 12;
                  case 49 -> 18;
                  case 50 -> 63;
                  case 51 -> 34;
                  case 52 -> 29;
                  case 53 -> 6;
                  case 54 -> 37;
                  case 55 -> 31;
                  case 56 -> 13;
                  case 57 -> 5;
                  case 58 -> 61;
                  case 59 -> 10;
                  case 60 -> 22;
                  case 61 -> 49;
                  case 62 -> 48;
                  default -> 15;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "D`\u001dD#AK PO)\\N}[\t!AC{_BbGJ~_\t/AJlRSb佻佲佛司栶桝栿佲栟佦\u0003桝栿栶栟司栶伙佻佲佛";
         b[1] = "9\bm,gI\r+bl*B\u00076g1!\u0004\u000f+j7%OL-c2%\u0004\u0001+c (^L休佛众厂栻桳桕佛桓伜\u000e桳桕栟桓厂栻伷休佛众r";
         b[2] = "\u0018'Qo\u0002@\u0013(@ cN\u0018#Dz";
         b[3] = ",y\u0001T\u0012~\u007f(\b)栴佂栊厂厥佴叮佂栊厂f\u0016\u0015xn~\u0007EDq";
         b[4] = "B]+\u0011-r\u0011\f\"l发栊桤伸休桵栋低传桼LS*t\u0000Z-\u0000{}";
         b[5] = "I.A\u0013Y5\u001a\u007fHn伻伉伫叕栿伳桿桍桯佋&Q^3\u000b)G\u0002\u000f:";
         b[6] = "l\u0004,'\r&?U%Z叱厄桊栥伖伇栫桞伎叿Ke\n .\u0003*6[)";
         b[7] = "%}Ks9Av,B\u000e佛根叙优栵栗佛根栃历,1>GgzMboN";
         b[8] = "Dx$\u0012\\\u0013\u0017)-o厠厱厸厃伞伲桺伯桢桙CV\\\u0002\u001a)%P\u001aI\u001a";
         b[9] = "5Oz2wRf\u001esO伕株栓厴栄厌压株栓厴\u001dppTwH|#!]";
         b[10] = "g\u000b[I2:4ZR4栔厘厛佮栥栭収厘厛佮<\u000b5<%\f]Xd5";
         b[11] = "~\u001d\u0010&\u0004Y-L\u0019[佦佥桘格桮伆栢校厂另wd\u0003_<\u001a\u00167RV";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String HE_SHU_YOU() {
         return "何炜霖诈骗";
      }
   }
}
