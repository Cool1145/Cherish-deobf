package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.packet.BlinkUtils;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.render.友友树何树树友树友何;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import why.tree.friend.antileak.Fucker;

public class 何何树树何友树树何树 extends Module implements 何树友 {
   private final NumberValue 树树何友何友友友树何;
   private final NumberValue 树友树树友友何友树何;
   private final BooleanValue 友树友何友树树树友树;
   private final BooleanValue 何友何树何何友树树何;
   private final BooleanValue 何何友何何友何树树友;
   private final BooleanValue 何何树友何友友何何何;
   private final BooleanValue 树友树树树树友何友友;
   private final BooleanValue 友何何何何何友何树树;
   private final BooleanValue 树友友树树何树友友树;
   private final NumberValue 友友何友友何树友何何;
   private final BooleanValue 何树树何何树何何友树;
   private final 树友树友友何何树何何 友友何何友树何何何何;
   private final 树友树友友何何树何何 树友何何树树友友何何;
   private boolean 友友友友树树何何何何;
   private boolean 友树树友树树友友友何;
   private RemotePlayer 何树树树友友友何树何;
   private Vec3 树树树友树友何树友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[50];
   private static final String[] l = new String[50];
   private static int _刘凤楠230622109211173513 _;

   public 何何树树何友树树何树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/combat/何何树树何友树树何树.a J
      // 003: ldc2_w 27989921124418
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 140476090369889
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 22699
      // 014: ldc2_w 1821690691118571126
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 31290
      // 021: ldc2_w 6349306978811460834
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -5989499944018886696
      // 02e: lload 1
      // 02f: invokedynamic L (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/NumberValue
      // 03b: dup
      // 03c: sipush 3006
      // 03f: ldc2_w 5740281011940052322
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 971
      // 04c: ldc2_w 3304292982685648134
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: ldc2_w 6.0
      // 059: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 05c: dconst_1
      // 05d: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 060: ldc2_w 12.0
      // 063: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 066: ldc2_w 0.1
      // 069: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 06c: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 06f: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.树树何友何友友友树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 072: aload 0
      // 073: new cn/cool/cherish/value/impl/NumberValue
      // 076: dup
      // 077: sipush 18237
      // 07a: ldc2_w 576085976505811442
      // 07d: lload 1
      // 07e: lxor
      // 07f: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 084: sipush 28735
      // 087: ldc2_w 2791694908970448634
      // 08a: lload 1
      // 08b: lxor
      // 08c: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 091: ldc2_w 500.0
      // 094: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 097: ldc2_w 10.0
      // 09a: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 09d: ldc2_w 1000.0
      // 0a0: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0a3: ldc2_w 10.0
      // 0a6: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0a9: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0ac: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.树友树树友友何友树何 Lcn/cool/cherish/value/impl/NumberValue;
      // 0af: aload 0
      // 0b0: new cn/cool/cherish/value/impl/BooleanValue
      // 0b3: dup
      // 0b4: sipush 10482
      // 0b7: ldc2_w 4828961169761201720
      // 0ba: lload 1
      // 0bb: lxor
      // 0bc: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c1: sipush 18369
      // 0c4: ldc2_w 3701025779950387471
      // 0c7: lload 1
      // 0c8: lxor
      // 0c9: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ce: bipush 1
      // 0cf: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0d2: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0d5: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.友树友何友树树树友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0d8: aload 0
      // 0d9: new cn/cool/cherish/value/impl/BooleanValue
      // 0dc: dup
      // 0dd: sipush 15899
      // 0e0: ldc2_w 1685069591561468114
      // 0e3: lload 1
      // 0e4: lxor
      // 0e5: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ea: sipush 4102
      // 0ed: ldc2_w 196952390988814041
      // 0f0: lload 1
      // 0f1: lxor
      // 0f2: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f7: bipush 1
      // 0f8: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0fb: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0fe: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.何友何树何何友树树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 101: aload 0
      // 102: new cn/cool/cherish/value/impl/BooleanValue
      // 105: dup
      // 106: sipush 1852
      // 109: ldc2_w 6468147596777669112
      // 10c: lload 1
      // 10d: lxor
      // 10e: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 113: sipush 31699
      // 116: ldc2_w 266756055257562376
      // 119: lload 1
      // 11a: lxor
      // 11b: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 120: bipush 1
      // 121: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 124: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 127: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.何何友何何友何树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 12a: aload 0
      // 12b: new cn/cool/cherish/value/impl/BooleanValue
      // 12e: dup
      // 12f: sipush 24025
      // 132: ldc2_w 4731028834281659161
      // 135: lload 1
      // 136: lxor
      // 137: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 13c: sipush 17502
      // 13f: ldc2_w 5250724156501426837
      // 142: lload 1
      // 143: lxor
      // 144: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 149: bipush 1
      // 14a: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 14d: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 150: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.何何树友何友友何何何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 153: aload 0
      // 154: new cn/cool/cherish/value/impl/BooleanValue
      // 157: dup
      // 158: sipush 17568
      // 15b: ldc2_w 8873778338973450849
      // 15e: lload 1
      // 15f: lxor
      // 160: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 165: sipush 8081
      // 168: ldc2_w 9043689510466083144
      // 16b: lload 1
      // 16c: lxor
      // 16d: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 172: bipush 1
      // 173: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 176: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 179: aload 0
      // 17a: ldc2_w -5985682237247330901
      // 17d: lload 1
      // 17e: invokedynamic â (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 183: dup
      // 184: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 187: pop
      // 188: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 18d: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 190: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 193: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.树友树树树树友何友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // 196: aload 0
      // 197: new cn/cool/cherish/value/impl/BooleanValue
      // 19a: dup
      // 19b: sipush 17648
      // 19e: ldc2_w 8264657810243420726
      // 1a1: lload 1
      // 1a2: lxor
      // 1a3: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1a8: sipush 2428
      // 1ab: ldc2_w 5303516492742774708
      // 1ae: lload 1
      // 1af: lxor
      // 1b0: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1b5: bipush 1
      // 1b6: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1b9: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1bc: aload 0
      // 1bd: ldc2_w -5985682237247330901
      // 1c0: lload 1
      // 1c1: invokedynamic â (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1c6: dup
      // 1c7: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 1ca: pop
      // 1cb: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 1d0: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 1d3: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 1d6: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.友何何何何何友何树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 1d9: aload 0
      // 1da: new cn/cool/cherish/value/impl/BooleanValue
      // 1dd: dup
      // 1de: sipush 16572
      // 1e1: ldc2_w 8337815683724019298
      // 1e4: lload 1
      // 1e5: lxor
      // 1e6: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1eb: sipush 1427
      // 1ee: ldc2_w 7390752587418747721
      // 1f1: lload 1
      // 1f2: lxor
      // 1f3: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f8: bipush 1
      // 1f9: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 1fc: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 1ff: aload 0
      // 200: ldc2_w -5985682237247330901
      // 203: lload 1
      // 204: invokedynamic â (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 209: dup
      // 20a: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 20d: pop
      // 20e: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 213: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 216: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 219: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.树友友树树何树友友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 21c: aload 0
      // 21d: new cn/cool/cherish/value/impl/NumberValue
      // 220: dup
      // 221: sipush 17935
      // 224: ldc2_w 384434526351261900
      // 227: lload 1
      // 228: lxor
      // 229: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 22e: sipush 9350
      // 231: ldc2_w 1826909841216299588
      // 234: lload 1
      // 235: lxor
      // 236: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23b: ldc2_w 0.3
      // 23e: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 241: dconst_0
      // 242: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 245: dconst_1
      // 246: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 249: ldc2_w 0.05
      // 24c: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 24f: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 252: aload 0
      // 253: invokedynamic get (Lcn/cool/cherish/module/impl/combat/何何树树何友树树何树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/combat/何何树树何友树树何树.k ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 258: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 25b: checkcast cn/cool/cherish/value/impl/NumberValue
      // 25e: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.友友何友友何树友何何 Lcn/cool/cherish/value/impl/NumberValue;
      // 261: aload 0
      // 262: new cn/cool/cherish/value/impl/BooleanValue
      // 265: dup
      // 266: sipush 22315
      // 269: ldc2_w 7808158239928586732
      // 26c: lload 1
      // 26d: lxor
      // 26e: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 273: sipush 8164
      // 276: ldc2_w 4963499850799077672
      // 279: lload 1
      // 27a: lxor
      // 27b: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 280: bipush 1
      // 281: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 284: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 287: aload 0
      // 288: ldc2_w -5985682237247330901
      // 28b: lload 1
      // 28c: invokedynamic â (Ljava/lang/Object;JJ)Lcn/cool/cherish/value/impl/BooleanValue; bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 291: dup
      // 292: invokestatic java/util/Objects.requireNonNull (Ljava/lang/Object;)Ljava/lang/Object;
      // 295: pop
      // 296: invokedynamic get (Lcn/cool/cherish/value/impl/BooleanValue;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/value/树何何何友树树何友何.getValue ()Ljava/lang/Object;, ()Ljava/lang/Boolean; ]
      // 29b: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 29e: checkcast cn/cool/cherish/value/impl/BooleanValue
      // 2a1: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.何树树何何树何何友树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 2a4: aload 0
      // 2a5: new cn/cool/cherish/utils/树友树友友何何树何何
      // 2a8: dup
      // 2a9: lload 3
      // 2aa: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 2ad: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.友友何何友树何何何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 2b0: aload 0
      // 2b1: new cn/cool/cherish/utils/树友树友友何何树何何
      // 2b4: dup
      // 2b5: lload 3
      // 2b6: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 2b9: putfield cn/cool/cherish/module/impl/combat/何何树树何友树树何树.树友何何树树友友何何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 2bc: aload 0
      // 2bd: bipush 0
      // 2be: ldc2_w -5989342748833368500
      // 2c1: lload 1
      // 2c2: invokedynamic ì (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c7: aload 0
      // 2c8: bipush 0
      // 2c9: ldc2_w -5989656315750458103
      // 2cc: lload 1
      // 2cd: invokedynamic ì (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/combat/何何树树何友树树何树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2d2: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2913172789582040672L, -4292155428687959305L, MethodHandles.lookup().lookupClass()).a(7350452877221L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var5 = a ^ 122225186427386L;
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(var5 << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[24];
      int var12 = 0;
      String var11 = "\u0014yÞj¯\u007f+\u0086Vc±%Ìè\u009cRà¾+¥~éN¢\u0010ÆþÚW\n²%ÿS»\u009f\u0000\u0001îâU \u0082ï8}6ø\u0017L_³Î(b\u001foÃ\u0012ÜÌi+¨Æ\u0095wO\"ïÄ*\u0006Ì\u0010²\u0005\u0017\u009c\u0005\u0003öåp\u0090º=]\\\u009aa\u0010FÅ\u000fcHM1q\u0002=º\u0089ï\u0019\b\r(\u0006å_0ÅPÁ9or\u0092Ò'\u0082öH×¸ù÷5\u0087ÜT\u0001A#G\u0098\u001dËë;O\fwµB\u0004p %<`°\u008a\u007f\u0002hà\u001fo\u009f²eI¦¤¨èJêaDÍ-a\u00ad\u0091yê\u0086S Ä£Ð\u0017\u0091\u0000L\u009f>\u008f.äÑ\u0097ÿEÅ]Y\u0084\u0006MfÄ\u0085¿5~P>¸« I\u0013âC!gÀ\u0087\u001b'\u009bd9$5ì+Ë@,%¿qÉ\u0081å\u0094)\u008f±yç n \u00adà7óEy±\u000e\u009e\u00801õ®9»M2µA\u001d=µ4Iã6¨?+7\u0018itÑµ\u0011/Fµ²Æ\u001bnÂÃ¿auþ$\u0097Ë\u0096\u0083¸\u0010\u0099\f$\u0093±¿½\u0011\\ê\u00ad\u0000¦+\u00041 \u009bHª´ªí)ÏÈ² S\u000f\u008a\u0083Ý\u000e¤\u009dÆÌ¤\u0096\u0017VSõTJ;¹Í Ë\u008f[Á¸\u008cÁH·T¦«\u007fÆ\u007f}Êß{Cý\u0086P¥}\u0091\u000e\u009a\u0090ÁËi(¸\u0093L©a\u0018X\u0017³è)P\u00129ûzTV£B\u009c}Z\u0017=\u0003!9¤ZdXhXH^\t\u0096äõ\u0010ÕÁ_(®\u000bì\u0011üíÓ¾Q5«\u0004\u0018Þ°xÜ¿\u007fXÆñD²bÖª\"4ÛÖEàëÒ(¦(Oc\u001bÄoÂ\u0087\u000eìó¿<ØØ4Ï\u009f@\u008b\u008a_¼©\u0092!h\u008ees¸É\u0092ÇøÒØÃe\bï\u0010\u0085ìû\u0010[Ôs{ýC¤öÃÉqÒ\u0018ÝmÙç\u0004ù>ª$\u0096%¥0©6P\u0004/uÂPs\u0006ë © ¸\u0080\u009f\u0005÷\u0087÷Ð9;DS·\u0011JÏ\u0094.(5\u008b\u009f\u0098\f;ÿ\u008cÉnF õv¬®»\u0005ë\u0011A0\u001eÃí\u008b¿FÅæ\u009a|±\u008cï\u000e£\u008e\u0086¤:6N\u0084";
      short var13 = 621;
      char var10 = 24;
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[24];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var5 << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-108, -22, -2, 34, 39, 124, -121, 55});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "¬Ñ\u000f\u008bô\u00ad\"±hÓÂ\u000erÂ\u0019UX\u0091\n±\u001a\u0002\u0003\u0014\u0007ít\u000fgæw\u0011\u0010¤É\u009eö@\u0099\u009f¬Ñr©ü\u0007Ûü\u000b";
                  var13 = 49;
                  var10 = ' ';
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   public void F() {
      this.c();
   }

   private boolean Z() {
      long a = 何何树树何友树树何树.a ^ 19942973447020L;
      c<"p">(-1746979606217275001L, a);
      if (c<"â">(this, -1743796953379659301L, a) == null) {
         return false;
      } else {
         double yaw = Math.toRadians(mc.player.getYRot());
         Vec3 lookDirection = new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
         Vec3 real = c<"â">(this, -1743796953379659301L, a).subtract(mc.player.position());
         real = new Vec3(c<"â">(real, -1747388979196948603L, a), 0.0, c<"â">(real, -1742938414535263108L, a));
         if (real.length() < 0.1) {
            return false;
         } else {
            real = real.normalize();
            double smooth = lookDirection.dot(real);
            return smooth > 0.3;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 56;
               case 1 -> 41;
               case 2 -> 22;
               case 3 -> 17;
               case 4 -> 36;
               case 5 -> 59;
               case 6 -> 26;
               case 7 -> 28;
               case 8 -> 60;
               case 9 -> 2;
               case 10 -> 40;
               case 11 -> 29;
               case 12 -> 10;
               case 13 -> 54;
               case 14 -> 18;
               case 15 -> 42;
               case 16 -> 24;
               case 17 -> 50;
               case 18 -> 46;
               case 19 -> 35;
               case 20 -> 27;
               case 21 -> 12;
               case 22 -> 39;
               case 23 -> 53;
               case 24 -> 63;
               case 25 -> 37;
               case 26 -> 19;
               case 27 -> 49;
               case 28 -> 15;
               case 29 -> 47;
               case 30 -> 6;
               case 31 -> 11;
               case 32 -> 31;
               case 33 -> 61;
               case 34 -> 25;
               case 35 -> 13;
               case 36 -> 14;
               case 37 -> 44;
               case 38 -> 30;
               case 39 -> 34;
               case 40 -> 52;
               case 41 -> 1;
               case 42 -> 51;
               case 43 -> 58;
               case 44 -> 9;
               case 45 -> 4;
               case 46 -> 57;
               case 47 -> 33;
               case 48 -> 38;
               case 49 -> 43;
               case 50 -> 0;
               case 51 -> 16;
               case 52 -> 23;
               case 53 -> 21;
               case 54 -> 8;
               case 55 -> 7;
               case 56 -> 55;
               case 57 -> 20;
               case 58 -> 32;
               case 59 -> 48;
               case 60 -> 62;
               case 61 -> 3;
               case 62 -> 5;
               default -> 45;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/何何树树何友树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27176;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/何何树树何友树树何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private void x() {
      long a = 何何树树何友树树何树.a ^ 77933370595434L;
      long ax = a ^ 90859619538299L;
      c<"p">(2650139200289409665L, a);
      if (c<"â">(this, 2650413207592916257L, a)) {
         try {
            BlinkUtils.M(new Object[]{ax});
            c<"ì">(this, false, 2650413207592916257L, a);
            c<"ì">(this, null, 2651104138173244125L, a);
            c<"ì">(this, null, 2649440794429983008L, a);
         } catch (Exception var7) {
            var7.printStackTrace();
         }
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 226 && var8 != 236 && var8 != 'L' && var8 != 223) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 213) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'p') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 226) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'L') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/何何树树何友树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private void c() {
      long a = 何何树树何友树树何树.a ^ 106536472007363L;
      long ax = a ^ 53604748516848L;
      c<"p">(3345622063453405224L, a);
      if (c<"â">(this, 3341968618980859784L, a)) {
         this.x();
      }

      c<"ì">(this, false, 3341931579242329293L, a);
      c<"ì">(this, null, 3342721160322050164L, a);
      c<"ì">(this, null, 3345491008336069513L, a);
      c<"â">(this, 3345706309351077921L, a).U(ax);
      c<"â">(this, 3342473764281389751L, a).U(ax);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   @EventTarget
   public void f(AttackEvent event) {
      long a = 何何树树何友树树何树.a ^ 54310291909269L;
      long ax = a ^ 106932854039974L;
      c<"p">(-3010559544047667074L, a);
      if (event.isPost() && !event.isCancelled() && (Boolean)Fucker.isLogin) {
         c<"ì">(this, true, -3011011968663303013L, a);
         c<"â">(this, -3011628679916164383L, a).U(ax);
         if (c<"â">(this, -3010833091789674530L, a)) {
            this.x();
         }
      }
   }

   private void l() {
      long a = 何何树树何友树树何树.a ^ 124068946205795L;
      c<"ì">(this, new RemotePlayer(mc.level, mc.player.getGameProfile()), -6859683260423467735L, a);
      c<"ì">(c<"â">(this, -6859683260423467735L, a), c<"â">(mc.player, -6859195928228852704L, a), -6859352043993626610L, a);
      c<"â">(this, -6859683260423467735L, a).copyPosition(mc.player);
      c<"â">(this, -6859683260423467735L, a).setUUID(mc.player.getUUID());
      c<"â">(this, -6859683260423467735L, a).setId(mc.player.getId());
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static void a() {
      k[0] = "Ei|#JyJ)1(@dOt:nHyBr>%\u000b\u007fKw>nFyKe34\u000b]Ok>\u0001PdG";
      k[1] = "!\u0003\u007f\\T\u0012\u0015 p\u001c\u0019\u0019\u001f=uA\u0012_\u0017 xG\u0016\u0014T\u0002sV\u000f\u001d\u001ft";
      k[2] = "\u00182\u0015+c&\u0017rX i;\u0012/Sfa&\u001f)W-\" \u0016,Wfo&\u0016>Z<\"伜伮桍株伝叇桘桪伉株";
      k[3] = "&\u007f\u001c\n\f\u000f)?Q\u0001\u0006\u0012,bZG\u0015\u0001)dWG\n\r5}\u001c+\f\u000f)tS\u00075\u0001)dW";
      k[4] = "!\u001b\njw=.[Ga} +\u0006L'u=&\u0000Hl6;/\u0005H'|;1\u0005Hha|厉桤栵栘栉伇桓桤可参";
      k[5] = "s\u0014\u0001nL0|TLeF-y\tG#U>|\u000fJ#J2`\u0016\u0001栜叨伊叛伯佺叆栲桎叛";
      k[6] = boolean.class;
      l[6] = "java/lang/Boolean";
      k[7] = "\u0019T\u0012\t\u001ew\u0019T\u0005U\u0012x\u0003\u001f\u0005K\u001a{\u0019EHW\u001f\u007f\u000eT\u0014\t!{\u001a^\u0012B#r\u0016H\u0003U";
      k[8] = "\u0005Qr\u000e;e\n\u0011?\u00051x\u000fL4C\"k\nJ9C=g\u0016Sr#!g\u0004Z.;5f\u0013Z";
      k[9] = "T\u0011b\u0007\u0012F_\u001esHyR]\u0015d\u0012UEP";
      k[10] = "FjO0(2FjXl$=\\!Lq77L!Kv<(\u0006Y^}v";
      k[11] = ">\u0001*>5\u001e1Ag5?\u00034\u001cls/\u00054\u0003ws桋厺桌厤叏伈伏桠伈伺";
      k[12] = "h'DVL&h'S\n@)rlS\u0014H*h6\u001e\bM.\u007f'BVm e#\\(M.\u007f'B";
      k[13] = int.class;
      l[13] = "java/lang/Integer";
      k[14] = "?lV'e\u00140,\u001b,o\t5q\u0010jg\u00148w\u0014!$伮伉叉伭休叁伮伉栓桩";
      k[15] = float.class;
      l[15] = "java/lang/Float";
      k[16] = double.class;
      l[16] = "java/lang/Double";
      k[17] = "[)$_\u0019cP&5\u0010xm[-1J";
      k[18] = "}k\n\u0004\u0002V%z\u000f\u0012h桶桝栏台桰厫伲桝叕株iWS.dZ\u0018\t\u0011$r";
      k[19] = "\u0001vlQW9YgiG=參佥佖伈佡你參佥栒桌<\u0007l\u0004jl\u0006Z`B`";
      k[20] = "q5b\u0017\u0013\u0004}l?Hw\u0012\u001b3i\u001cJB\u001b\n2G\u0006Mq59S\u0016\u0012";
      k[21] = "$\u0011\u0019z\u0016~b\u0000\u001fg/位佃似厵佀佲位标似厵\u001d\u0014k~]\u000byIqb\u001e";
      k[22] = "\u001e\u0011\u0015s|z\u0001\u0001K\u001ftr\u0001\u0000Ay~yz\u0018E\"y}\u0014\u0007U|";
      k[23] = "d+*\u0018\u0014|<:/\u000e~历厞伋低厶桧优伀伋低uN~:+x\u000b\u001ex<g";
      k[24] = "8\f\u0015|E\u0002`\u001d\u0010j/司栘桨可栈栶司参厲佱\u0011\u0013]1\u001fAc\u001e\nj\f";
      k[25] = "Usr5C\u001b\rbw#)使厯体桒伅佴叡桵栗伖X\u0013NPorbNB\u0016e";
      k[26] = "@r_J}e\fe\u000b[Dv'$\b\u0001}&'\u001e\u0001_<vK%MW8d";
      k[27] = ",\u001b\u0005ZT7t\n\u0000L>反取伻叿叴佣栗取伻佡7\u0003le\fBZ\u0001\u007fkX";
      k[28] = "'\f![4Z\u007f\u001d$M^桺叝桨栁叵厝伾叝桨佅6c\u0001n\u001bf[a\u0012`O";
      k[29] = "b!T.=Vt`\u0017$\u0003叨栒叓厪伞佞叨佖栉厪Cj\u001a6}W>|[uw";
      k[30] = "N/v0\u007fb\u0010m|&\u0016}&#&~&*&\u0013v)g\"L,}=w}";
      k[31] = "(z.\u001fm5pk+\t\u0007叏叒叄叔桫栞佑佌佚佊r;j!iz\u00006=zz";
      k[32] = "O}.l\u0010Z\u0003jz})I(+y&\u0019\u001a(\u0011(o\u0014\u001bC}~z\u0017A";
      k[33] = "D~3hH_\u001a<9~!@,rc&\u001e\u001f,B3qP\u001fF}8e@@";
      k[34] = "tWj\u000fIHx\u000e7P-^\u001eQa\u0004\u0010\r\u001eh:_\\\u0001tW1KL^";
      k[35] = "Bng~\u000e\u0016\u001a\u007fbhd佲伦栊厝低厧召伦低伃\u0013^CGrg)\u0003O\u0001x";
      k[36] = "Fs\u000b8;+YcUT\u0003E^lYh)%Ow]T";
      k[37] = "cW\u0004zDq;F\u0001l.桑厙佷你栎样压厙佷你\u0017\u001es=WViNu;\u001b";
      k[38] = "UM\u000eK/KY\u0014S\u0014K]?H\f@{\u000e?r]\tv\u000fT\u001e\u000b\u001cuU";
      k[39] = "U>\u000fN\u00196\r/\nXs佒桵桚佫佾桪佒伱厀栯#IcP\"\u000f\u0019\u0014o\u0016(";
      k[40] = "i\u0001}H \u000b/\u0010{U\u0019桼厐厲栋召叚厦伎桨发/#\u0015<\u0016+Ae\u0004:\u000b";
      k[41] = "R~|=BE^'!b&S8xw6\u001b\u00018A,mW\fR~'yGS";
      k[42] = "\u0004gOtX|\\vJb2优栤栃桯叚叱历你栃伫\u0019\u000fz\u0007!\u0012a\u0003#Z~";
      k[43] = "_M+J]G\u0007\\.\\7桧桿佭发佺叴厽厥栩住'\n\u001c\u0016ZlJ\b\u000f\u0018\u000e";
      k[44] = "n\u0006\u0018\bLq6\u0017\u001d\u001e&!WEK\u000b\u001dvm\u001a@\u000eMHi\u0011O^\u0018r6\u001aJ\u000e&";
      k[45] = "-D<\u0010lAs\u00066\u0006\u0005^EHl^5\bEx<\tt\u0001/G7\u001dd^";
      k[46] = "e5T}0U=$QkZ桵原桑桴栉桃厯企压厮\u0010`\u0000`)T*=\f&#";
      k[47] = "_w\u001c\u0001\t0\u0007f\u0019\u0017c佔伻叉佸伱厠佔桿栓另lYeZk\u001cV\u0004i\u001ca";
      k[48] = "\u001b\u0003GV9mC\u0012B@S桍叡厽桧栢伎桍叡厽桧;i8\u001e\u001fG\u000144X\u0015";
      k[49] = "*U\u0000$g'rD\u00052\r叝栊叫佤厊栔标栊叫栠I7r/I\u0000sj~iC";
   }

   @EventTarget
   public void p(Render3DEvent event) {
      long a = 何何树树何友树树何树.a ^ 81394810986920L;
      long ax = a ^ 44337336853540L;
      long axx = a ^ 93040309848405L;
      long axxx = a ^ 64676971731460L;
      c<"p">(6702802557317935939L, a);
      if (!this.w(new Object[]{ax})
         && c<"â">(this, 6702700691137500225L, a).getValue()
         && c<"â">(this, 6704210729655938275L, a)
         && c<"â">(this, 6703248208945541346L, a) != null) {
         友友树何树树友树友何.N(
            event.poseStack(),
            c<"â">(this, 6703248208945541346L, a),
            c<"â">(this, 6703487163463721500L, a).getValue()
               ? 树树何友友友友何树友.w(axx, 10, 1).getRGB()
               : c<"â">(c<"L">(6703073345170344837L, a), 6703985729727921215L, a).a(),
            c<"â">(this, 6703007080704941187L, a).getValue(),
            c<"â">(this, 6703820057233042751L, a).getValue(),
            c<"â">(this, 6701375088264992283L, a).getValue(),
            c<"â">(this, 6704434744236684842L, a).getValue().floatValue(),
            axxx
         );
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      this.c();
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void y(LivingUpdateEvent event) {
      long a = 何何树树何友树树何树.a ^ 110636907483530L;
      long ax = a ^ 7471270515718L;
      long axx = a ^ 53416442662231L;
      long axxx = a ^ 5106021970395L;
      long axxxx = a ^ 57980162563769L;
      c<"p">(3253584585238872929L, a);
      if (!this.w(new Object[]{ax})
         && (!c<"â">(this, 3252256035563185423L, a).getValue() || c<"L">(3254886383662858359L, a).isEnabled())
         && (Boolean)Fucker.isLogin) {
         if (c<"â">(this, 3253862533309357249L, a) && c<"â">(this, 3254624048447843133L, a) == null) {
            c<"ì">(this, mc.player.position(), 3254624048447843133L, a);
            this.l();
         }

         if (c<"â">(this, 3253862533309357249L, a) && c<"â">(this, 3254624048447843133L, a) != null) {
            this.P();
            if (c<"â">(this, 3253961413107044195L, a).getValue() && this.Z()
               || c<"â">(this, 3253238340775073064L, a).getValue() && c<"â">(mc.player, 3254013853011827615L, a) > 0) {
               this.x();
               return;
            }
         }

         LivingEntity target = this.O();
         if (target != null) {
            double distance = RotationUtils.O(target);
            if (distance <= c<"â">(this, 3252956876981342037L, a).getValue().floatValue()) {
               if (!c<"â">(this, 3253862533309357249L, a) && !c<"â">(this, 3254388855706892164L, a)) {
                  this.T();
                  c<"â">(this, 3253659768587778920L, a).U(axxxx);
               }

               if (c<"â">(this, 3253862533309357249L, a)
                  && !c<"â">(this, 3254388855706892164L, a)
                  && c<"â">(this, 3253659768587778920L, a).C(axx, c<"â">(this, 3254200495340807560L, a).getValue().floatValue())) {
                  this.x();
                  this.T();
                  c<"â">(this, 3253659768587778920L, a).U(axxxx);
               }
            }
         }

         if (c<"â">(this, 3253862533309357249L, a)) {
            this.x();
         }

         c<"ì">(this, false, 3254388855706892164L, a);
         if (c<"â">(this, 3254388855706892164L, a) && c<"â">(this, 3254939619641135614L, a).Y(j, axxx)) {
            c<"ì">(this, false, 3254388855706892164L, a);
         }
      }
   }

   private void P() {
      long a = 何何树树何友树树何树.a ^ 120764812395623L;
      c<"p">(8703774432125441676L, a);
      if (c<"â">(this, 8703663030406075693L, a) != null) {
         c<"â">(this, 8703663030406075693L, a).setPos(c<"â">(this, 8703125045335178960L, a));
         c<"â">(this, 8703663030406075693L, a).setYRot(mc.player.getYRot());
         c<"â">(this, 8703663030406075693L, a).setXRot(mc.player.getXRot());
         c<"ì">(c<"â">(this, 8703663030406075693L, a), c<"â">(c<"â">(this, 8703125045335178960L, a), 8704183804399390862L, a), 8703608204976525339L, a);
         c<"ì">(c<"â">(this, 8703663030406075693L, a), c<"â">(c<"â">(this, 8703125045335178960L, a), 8703303989786931581L, a), 8704238777848309650L, a);
         c<"ì">(c<"â">(this, 8703663030406075693L, a), c<"â">(c<"â">(this, 8703125045335178960L, a), 8702266515050308471L, a), 8702680958533788527L, a);
      }
   }

   private void T() {
      long a = 何何树树何友树树何树.a ^ 46867795995837L;
      long ax = a ^ 47531941958388L;
      c<"p">(1157499659533205078L, a);
      if (!c<"â">(this, 1161722562982339062L, a)) {
         try {
            c<"ì">(this, mc.player.position(), 1161349724669236746L, a);
            this.l();
            BlinkUtils.g(new Object[]{ax});
            c<"ì">(this, true, 1161722562982339062L, a);
         } catch (Exception var7) {
            var7.printStackTrace();
         }
      }
   }

   private LivingEntity O() {
      long a = 何何树树何友树树何树.a ^ 51696131645479L;
      long ax = a ^ 25389461055565L;
      c<"p">(-2555152413441363252L, a);
      LivingEntity currentTarget = null;
      if (c<"L">(-2556102368123227686L, a) != null && c<"L">(-2556102368123227686L, a).isEnabled()) {
         currentTarget = c<"L">(-2556102368123227686L, a).B();
      }

      if (currentTarget == null) {
         Iterator var7 = Cherish.instance.S().W(c<"â">(this, -2555343566458913032L, a).getValue().floatValue(), ax).iterator();
         if (var7.hasNext()) {
            LivingEntity entity = (LivingEntity)var7.next();
            if (entity != null && !entity.isDeadOrDying() && entity.isAlive() && entity.getHealth() > 0.0F) {
               double distance = RotationUtils.O(entity);
               if (distance <= c<"â">(this, -2555343566458913032L, a).getValue().floatValue()) {
                  currentTarget = entity;
               }
            }
         }
      }

      return currentTarget;
   }

   private static String HE_WEI_LIN() {
      return "解放村多种2队1144号";
   }
}
