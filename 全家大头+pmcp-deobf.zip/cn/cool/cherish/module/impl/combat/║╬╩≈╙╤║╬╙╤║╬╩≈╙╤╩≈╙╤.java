package cn.cool.cherish.module.impl.combat;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.树树何树何何树何何树;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.packet.BlinkUtils;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.AttackEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import why.tree.friend.antileak.Fucker;

public class 何树友何友何树友树友 extends Module implements 何树友 {
   private final NumberValue 友树树友友友树树树何 = new NumberValue("Range", "范围", 6.0, 1.0, 12.0, 0.1);
   private final NumberValue 树何树何何何何何何树 = new NumberValue("Delay", "间隔", 500.0, 10.0, 1000.0, 10.0);
   private final BooleanValue 友树何友何树何何何友 = new BooleanValue("On Aura", "在杀戮生效", true);
   private final BooleanValue 友友何友友树树友友树 = new BooleanValue("Forward Check", "真实位置检测", true);
   private final BooleanValue 友友树何何何树树友树 = new BooleanValue("Hurt Check", "受伤检测", true);
   private final BooleanValue 友树何树何树何树友何 = new BooleanValue("Render Real Position", "显示真实位置", true);
   private final BooleanValue 树树友何何友何树何何 = new BooleanValue("Rainbow", "彩虹", true).A(this.友树何树何树何树友何::getValue);
   private final BooleanValue 何友何何树友友何友树 = new BooleanValue("Fill Mode", "填充模式", true).A(this.友树何树何树何树友何::getValue);
   private final BooleanValue 何树友友树何树何何何 = new BooleanValue("Wireframe Mode", "线框模式", true).A(this.友树何树何树何树友何::getValue);
   private final NumberValue 树友何树树友树树树树 = new NumberValue("Fill Alpha", "填充透明度", 0.3, 0.0, 1.0, 0.05).A(() -> {
      KillAura.x();
      return this.友树何树何树何树友何.getValue() && this.何友何何树友友何友树.getValue();
   });
   private final BooleanValue 何友何友友树树友树友 = new BooleanValue("Damage Effect", "伤害效果", true).A(this.友树何树何树何树友何::getValue);
   private final 何友友何树何树何树友 树友树树树友友何树树 = new 何友友何树何树何树友(51913986529303L);
   private final 何友友何树何树何树友 树何何友树树友友何树 = new 何友友何树何树何树友(51913986529303L);
   private boolean 树树友何树何树树友友 = false;
   private boolean 友树友何友树树友友树 = false;
   private RemotePlayer 树树友何树树树树友树;
   private Vec3 树树友友何树何友何友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[50];
   private static final String[] l = new String[50];
   private static String LIU_YA_FENG;

   public 何树友何友何树友树友() {
      super("TickBase", "先人一步", 树何友友何树友友何何.何何何何何树何何友树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(1831024372497954967L, 5500458742480063697L, MethodHandles.lookup().lookupClass()).a(153474367442536L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var7;
      Cipher var17 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(53805645766292L << var8 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[24];
      int var12 = 0;
      String var11 = "È\u0087\u0097*I6u'óbsÎÈFÃ¼\u0005ìç\u000bÔÚ}h\u008d\n\"\u001d<\u000f¬W\u0018)øL\u000f:Bõë áÿ;Ï\u0085x\u008e\u0018\bÁYv,\u0094(\u0010\u0091\u0088G¼ãù ðå(\u0006n)_R\u0098 ¢%\u0093DmK\u008d§_a7Ñ\u0085\u001fj\u0014ÌV¤¡\u0016i2ðNw¿O÷\u0083¨S\u0010\u0013d\u00822gËgî Õ&w\b\b\u009dÈ pc\ntb:\u001e®\u0088qcözï¸«ÝªA\u000f7èýéûÚó¸È³th(ùyÃe<À*\u009b\u000fÙµDbl\u0090ï=\bslþÇ\u0010o[$°\u009f·\u0096\u008eoÇ6½äÝ>\u0010[ 2¿\u008b\u00ad \"ÎÉ+¤¯ìâ'øò\u0004#òqJx÷\u0004\u009b\u0013¯)9à\u00ad!\u0010ì\u008e\u0091ÿ\u008e/úSd\u000e\u0019\u0086ü[\u0090T ±ÙûÞ\u00127\u0010\u0096é¾\u009cO¯\u0018\u0091AöUÚÀ7w*%Ñ\u001fZö½\u001fþò\u0010-Nj´Ó\u009aeÙ5ï÷o\u00adªxå\u0018«·\u001f[ÑB±\u00adÂ\u000e¥|CÃÕ\u000fævÅèÓU0^ »ø8v\u0012\u0085¡0ÓôlISÖ\u009c²ÕTiÈC2¤]\u0094o¡\u008eÒÖ¿\u0002\u0018ý\u0083´\u009cûÅ\u0011Sú\u0091ì¹¾ç®\u0093Eæµ\u009da`y\u009b\u0010Fê-\u001d*w='\u008c¥¬à\u001f\u00917ë V]²\u008d\u009a\u001dñëÀ|ì»ùèªj\u0081Õþ¶Q!\u0005tÑ\u009d\u0003\u00ad_¤\u0084ó\u0010èÌZ¤õX n\u0083¡¨ë\u0096÷d'(ïQiWü\u0002ëbÆ¿ö\u0002·ýé\u0087·k,ÉÈ\u0003\u009b²I\u0087i\u001aBJ¤!>Øéà\réÖÓ\u0018\u000b\u0003cTn\fZ\u0016\u0007Ò\u0013\u000e\u0087<\u0083[ZÇ\u0083&¹1zO \u009d½\\éð\"þ®¥À´\u0007H\u0097AF\u001c\u0080¶É\u0013a\u008bø+\u0010V\fÎû\u0082((#u\u0005Tv×³pGÁøÊGÕ\u001e=s4\u0015tw\u000fù\u008cû\u001cìºÒozi¦9Ø\u0093\u0085è¥¾ »¯-\u0088;TìÝU\u0014\u0010ß¤\u0083\u0012¶Ç¾àØ\u0088ãòÏJÂ\u0082\u0088î\t\u008f\u0090";
      short var13 = 621;
      char var10 = ' ';
      int var16 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var16, var16 + var10);
         byte var10001 = -1;

         while (true) {
            String var26 = c(var7.doFinal(var18.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var26;
                  if ((var16 += var10) >= var13) {
                     c = var14;
                     h = new String[24];
                     Cipher var0;
                     Cipher var20 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(53805645766292L << var1 * 8 >>> 56);
                     }

                     var20.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{0, 93, -4, 16, -82, 71, -24, -4});
                     long var30 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var30;
                     return;
                  }

                  var10 = var11.charAt(var16);
                  break;
               default:
                  var14[var12++] = var26;
                  if ((var16 += var10) < var13) {
                     var10 = var11.charAt(var16);
                     continue label37;
                  }

                  var11 = "\u0097\"1Tµ<ö\u001a¾¹C.Õô»¾\u0018Ü[\u0089Y¸Åßó\\y\u0080Ç¢µ\u007fÈw\f\u00043\u0087/\u009dÍ";
                  var13 = 41;
                  var10 = 16;
                  var16 = -1;
            }

            var18 = var11.substring(++var16, var16 + var10);
            var10001 = 0;
         }
      }
   }

   private void Z() {
      KillAura.x();
      if (!this.友树友何友树树友友树) {
         try {
            this.树树友友何树何友何友 = mc.player.position();
            this.H();
            BlinkUtils.W(138430676960977L);
            this.友树友何友树树友友树 = true;
         } catch (Exception var7) {
            var7.printStackTrace();
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 34;
               case 1 -> 26;
               case 2 -> 53;
               case 3 -> 14;
               case 4 -> 2;
               case 5 -> 37;
               case 6 -> 36;
               case 7 -> 1;
               case 8 -> 27;
               case 9 -> 5;
               case 10 -> 23;
               case 11 -> 18;
               case 12 -> 11;
               case 13 -> 20;
               case 14 -> 17;
               case 15 -> 52;
               case 16 -> 7;
               case 17 -> 21;
               case 18 -> 30;
               case 19 -> 57;
               case 20 -> 3;
               case 21 -> 42;
               case 22 -> 39;
               case 23 -> 6;
               case 24 -> 50;
               case 25 -> 12;
               case 26 -> 40;
               case 27 -> 61;
               case 28 -> 54;
               case 29 -> 59;
               case 30 -> 58;
               case 31 -> 28;
               case 32 -> 10;
               case 33 -> 35;
               case 34 -> 16;
               case 35 -> 41;
               case 36 -> 13;
               case 37 -> 32;
               case 38 -> 31;
               case 39 -> 62;
               case 40 -> 55;
               case 41 -> 22;
               case 42 -> 47;
               case 43 -> 49;
               case 44 -> 29;
               case 45 -> 33;
               case 46 -> 0;
               case 47 -> 19;
               case 48 -> 56;
               case 49 -> 45;
               case 50 -> 44;
               case 51 -> 48;
               case 52 -> 43;
               case 53 -> 9;
               case 54 -> 25;
               case 55 -> 60;
               case 56 -> 4;
               case 57 -> 15;
               case 58 -> 24;
               case 59 -> 46;
               case 60 -> 8;
               case 61 -> 38;
               case 62 -> 51;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2632;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/combat/何树友何友何树友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[µrb\u0082IÆA\u0004\u0083TÔ\u0087cÓù\u001c, \u0012\u0004Í(\u000b\u0012\u001c\u0091u\u00adZYºö\u0099%, ¼\u0002F\u0088r÷ìI, å¥ß\u0094]ï\u008bA\u0011Õ¡O<r=\u001a, \u0089³ª\u000b\u0087Ø\u000fë, \u0015Ù\f\u008ep¬Ïy\u009a½éP\u0006\u0000\b\u0097, ô«*²\u0098Xó\u00ad\u001dB\u0080\u0096'¸!HyáÒ\u008d3\u001a[\t, \u008b>CíÆÙ9òõÍ×\u001c½9ÕF, ù¨7Ì§ãdÿ, \b¸÷áâ\u0091K\u0012\u0004)ÙwÛ\"Z±, µwtÏðô7ø, °S{\u0006´)Bl[\u0081i\u008b½P¾\u007f, l1§\u009có\u009eB¦\u000f=\u009f\u0089õ\u008d9õ, \u008e\u0084'ó*`ÊÚÓ.9%g\u009f'V,")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private boolean b() {
      KillAura.x();
      if (this.树树友友何树何友何友 == null) {
         return false;
      } else {
         double yaw = Math.toRadians(mc.player.getYRot());
         Vec3 lookDirection = new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
         Vec3 real = this.树树友友何树何友何友.subtract(mc.player.position());
         real = new Vec3(real.x, 0.0, real.z);
         if (real.length() < 0.1) {
            return false;
         } else {
            real = real.normalize();
            double smooth = lookDirection.dot(real);
            return smooth > 0.3;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/何树友何友何树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 227 && var8 != 186 && var8 != 234 && var8 != 't') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 193) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'R') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 227) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 186) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 234) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/combat/何树友何友何树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @Override
   public void h() {
      this.P();
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "D+\"&6vKko-<kN6dk4vC0` wpJ5`k:vJ'm1wRN)`\u0004,kF";
      k[1] = "gBE%XSSaJe\u0015XY|O8\u001e\u001eQaB>\u001aU\u0012CI/\u0003\\Y5";
      k[2] = "O\u0004\"\b <@Do\u0003*!E\u0019dE\"<H\u001f`\u000ea:A\u001a`E,<A\bm\u001fa伆栽厡余厠会桂叧桻叇";
      k[3] = "&\u000ej;r2)N'0x/,\u0013,vk<)\u0015!vt05\fj\u0016h0'\u00056\u000e|10\u0005";
      k[4] = "q>|;\u0004Vz1mtoBx:z.CUu";
      k[5] = "otPXs|`4\u001dSyaei\u0016\u0015q|ho\u0012^2zaj\u0012\u0015xz\u007fj\u0012Ze=栝栋伫株佉但栝住伫株";
      k[6] = "IG\u001eV/\u0002F\u0007S]%\u001fCZX\u001b6\fF\\U\u001b)\u0000ZE\u001e栤压伸使核校你压厦使";
      k[7] = "\u00171:\tI2\u0018qw\u0002C/\u001d,|DP<\u0018*qDO0\u00043:(I2\u0018:u\u0004p<\u0018*q";
      k[8] = boolean.class;
      l[8] = "java/lang/Boolean";
      k[9] = "\u000f_\u0013e}\u0007\u000f_\u00049q\b\u0015\u0014\u0004'y\u000b\u000fNI;|\u000f\u0018_\u0015eB\u000b\fU\u0013.@\u0002\u0000C\u00029";
      k[10] = "Y\u001b\nbD\u0004V[GiN\u0019S\u0006L/F\u0004^\u0000Hd\u0005桺佯厾可佔栺厠叱传佱";
      k[11] = "AX7\u001e_VAX BSY[\u00134_@SK\u00133XKL\u0001k&S\u0001";
      k[12] = double.class;
      l[12] = "java/lang/Double";
      k[13] = "O`%\u0013VY@ h\u0018\\DE}c^LBEbx^佬叽叧佛栚伥栨佣栽叅";
      k[14] = "$5\u0015\u001b1\u001b$5\u0002G=\u0014>~\u0002Y5\u0017$$OE0\u001335\u0013\u001b\u0010\u001d)1\re0\u001335\u0013";
      k[15] = int.class;
      l[15] = "java/lang/Integer";
      k[16] = float.class;
      l[16] = "java/lang/Float";
      k[17] = "\u0000\u0014\u000eC\u000f)\u000b\u001b\u001f\fn'\u0000\u0010\u001bV";
      k[18] = "~+d\u0015\u001b77jkT\"众桞厗厙栲使桓会伉伇+\u001fv{21\u0013\u0012p==";
      k[19] = "o5u7\u0018\u000f/ek$r\u000e\u0006=>dO]\u0006\u0004?9\u0019\ra>2m\nP";
      k[20] = "2\u001fT\u0010\u0019,rOJ\u0003s-[\u0017\u001fCN}[.\u001e\u001e\u0018.<\u0014\u0013J\u000bs";
      k[21] = "d^q7A\u0011-\u001f~vx桵厞核桖栐去厯伀核桖\tI\u0006&Aq4\u001c\u0012<\u001d";
      k[22] = "Q\u0016OTb<\u0018W@\u0015[桘桱厪伬桳伆桘桱厪厲jez\b\u001b\u001a\u000e0|\f\u0019";
      k[23] = "\u007ft\u001b\u001b\u0006\u001665\u0014Z?厨桟又佸另栦桲厅又格%\u0001P&yNATV\"{";
      k[24] = "\u0004|{tfeD,eg\fdmw9'<7mMk}gx\n|;rq4";
      k[25] = "b0)\u00076\u0019+q&F\u000f厧桂桖叔叺双桽桂桖佊95\u0004$\u007fxTk\u000b'(";
      k[26] = "Y%4}v2\u0000l>\f&?A+'j,4:4<v6hQmu|";
      k[27] = "DkxG\u00032\r*w\u0006:桖厾佉桟桠叹桖桤栍桟y\u0000/\u0002$)\u0014^ \u0001s";
      k[28] = "RL\u000f&\t-\u001b\r\u0000g0伍厨佮佬栁右厓伶台栨\u0018\rlWUZ \u0000j\u0011Z";
      k[29] = "\u0000-\u000b\u001e\u0000\r\u00050B@>\u0003>{JL\u0007S>A\u0018G\u0007\f\u0007zI\u0005[\r";
      k[30] = "M8\u001d+}{H%TuCusn\\xs&sT\u000e\"(i\u0014e^->%";
      k[31] = "Je\u000e\u0013KI\u0003$\u0001Rr栭桪叙佭栴桫栭桪叙栩-L\u0005\tyZB\fU\u0017j";
      k[32] = "~N~4Oz:F!13k\u0016\u0007!6\u0003=\u00167+gXhq\r&3K5";
      k[33] = "\u00108uI\u000b\rYyz\b2桩栰厄厈伪栫伭只会厈w\r\tLy7\bI\u0001\u0013|";
      k[34] = "\u0006,S$LF\u0005s\u000e&+栮栣佉伾厅栲佪佧受桺F\u0017QJyX:\u0010Y\u0004q";
      k[35] = "\u000bp|\u007fbiB1s>[佉叱佒厁厂桂栍叱栖厁Af(\u000ei)yk.Hf";
      k[36] = "\b<\u0018\\\u0015,A}\u0017\u001d,案栨厀佻伿可伌栨伞佻b\u0011m\r%MZ\u001ckK*";
      k[37] = "&XW\u0011<6o\u0019XP\u0005桒佂佺厪栶栜厈叜佺桰/4!dGW\u0012a5~\u001b";
      k[38] = "\\MObq,\u0015\f@#H厒厦佯厲原桑案厦叱桨\\umYT\u001adxk\u001f[";
      k[39] = "\\$XS\u0011\u001b\u0018,\u0007Vm\n4m\u0007QRU4]\r\u0000\u0006\tSg\u0000T\u0015T";
      k[40] = "\u0010``w\f*Y!o65厔栰佂桇伔栬伊栰叜伃I\bk\u0015y5q\u0005mSv";
      k[41] = "@u\b>A\u0018\u0019<\u0002O\u0000sSu\u0013r@\u0003Qv\u0003O";
      k[42] = "Rg\n>/\nQ8W<H桢桷厜叹原压桢厭伂佧\\tC^=]-w\u001c\u0003?";
      k[43] = "oN^/T\u001d+F\u0001*(\f\u0007\u0007\u0001-\u0018[\u00077\u000b|C\u000f`\r\u0006(PR";
      k[44] = "Ju\u0013V19\u0005r\u0001Z\u000e伏伨佂伧佦栗伏伨叜档;18\u001crEP~?\u000e~";
      k[45] = "\u001aor\u001fexS.}^\\叆叠栉休佼企栜栺叓桕!a9\u001fv'\u0019l?Yy";
      k[46] = "fnfqhZ//i0QN_*`$2^-!54?'d)3,(Uo|#!Q";
      k[47] = "+mLs0Uk=R`ZTBe\u0007 g\u0006B\\\u0006}1W%f\u000b)\"\n";
      k[48] = "|pTC\u0016k51[\u0002/栏优栖伷传佲佋优佒桳}\u0015v:?\u0005\u0010Ky9h";
      k[49] = "'?vl\"\nn~y-\u001b厴标伝压伏栂伪佃伝压R&K\"&#j+Md)";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private LivingEntity m() {
      KillAura.x();
      LivingEntity currentTarget = null;
      if (KillAura.instance != null && KillAura.instance.isEnabled()) {
         currentTarget = KillAura.instance.Y();
      }

      if (currentTarget == null) {
         Iterator var9 = Cherish.instance.m().V(this.友树树友友友树树树何.getValue().floatValue(), 16843851536371L).iterator();
         if (var9.hasNext()) {
            LivingEntity entity = (LivingEntity)var9.next();
            if (entity != null && !entity.isDeadOrDying() && entity.isAlive() && entity.getHealth() > 0.0F) {
               double distance = RotationUtils.i(entity, 55874601829708L);
               if (distance <= this.友树树友友友树树树何.getValue().floatValue()) {
                  currentTarget = entity;
               }
            }
         }
      }

      return currentTarget;
   }

   @EventTarget
   public void k(Render3DEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L}) && this.友树何树何树何树友何.getValue() && this.友树友何友树树友友树 && this.树树友何树树树树友树 != null) {
         PoseStack var10000 = event.poseStack();
         RemotePlayer var10001 = this.树树友何树树树树友树;
         int var10002 = this.树树友何何友何树何何.getValue() ? 何树友友树树友何树何.t(94608897312632L, 10, 1).getRGB() : 树树何树何何树何何树.树树友友友友树友何何.树树何何友树何何友树.O();
         boolean var10003 = this.何友何友友树树友树友.getValue();
         boolean var10004 = this.何友何何树友友何友树.getValue();
         boolean var10005 = this.何树友友树何树何何何.getValue();
         float a = this.树友何树树友树树树树.getValue().floatValue();
         int ax = var10005;
         int axx = var10004;
         int axxx = var10003;
         int axxxx = var10002;
         RemotePlayer axxxxx = var10001;
         PoseStack axxxxxx = var10000;
         友友何何友友树何何友.Z(24488542601285L, axxxxxx, axxxxx, axxxx, axxx, axx, ax, a);
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @EventTarget
   public void g(LivingUpdateEvent event) {
      KillAura.x();
      if (!this.Q(new Object[]{52406761729175L}) && (!this.友树何友何树何何何友.getValue() || KillAura.instance.isEnabled()) && (Boolean)Fucker.isLogin) {
         if (this.友树友何友树树友友树 && this.树树友友何树何友何友 == null) {
            this.树树友友何树何友何友 = mc.player.position();
            this.H();
         }

         if (this.友树友何友树树友友树 && this.树树友友何树何友何友 != null) {
            this.u();
            if (this.友友何友友树树友友树.getValue() && this.b() || this.友友树何何何树树友树.getValue() && mc.player.hurtTime > 0) {
               this.j();
               return;
            }
         }

         LivingEntity target = this.m();
         if (target != null) {
            double distance = RotationUtils.i(target, 55874601829708L);
            if (distance <= this.友树树友友友树树树何.getValue().floatValue()) {
               if (!this.友树友何友树树友友树 && !this.树树友何树何树树友友) {
                  this.Z();
                  this.树何何友树树友友何树.D(11747522392279L);
               }

               if (this.友树友何友树树友友树 && !this.树树友何树何树树友友 && this.树何何友树树友友何树.a(60984292003631L, this.树何树何何何何何何树.getValue().floatValue())) {
                  this.j();
                  this.Z();
                  this.树何何友树树友友何树.D(11747522392279L);
               }
            }
         }

         if (this.友树友何友树树友友树) {
            this.j();
         }

         this.树树友何树何树树友友 = false;
         if (this.树树友何树何树树友友 && this.树友树树树友友何树树.A(50L, 118344821288830L)) {
            this.树树友何树何树树友友 = false;
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void j() {
      KillAura.x();
      if (this.友树友何友树树友友树) {
         try {
            BlinkUtils.l(102729178478887L);
            this.友树友何友树树友友树 = false;
            this.树树友友何树何友何友 = null;
            this.树树友何树树树树友树 = null;
         } catch (Exception var7) {
            var7.printStackTrace();
         }
      }
   }

   private void u() {
      KillAura.x();
      if (this.树树友何树树树树友树 != null) {
         this.树树友何树树树树友树.setPos(this.树树友友何树何友何友);
         this.树树友何树树树树友树.setYRot(mc.player.getYRot());
         this.树树友何树树树树友树.setXRot(mc.player.getXRot());
         this.树树友何树树树树友树.xo = this.树树友友何树何友何友.x;
         this.树树友何树树树树友树.yo = this.树树友友何树何友何友.y;
         this.树树友何树树树树友树.zo = this.树树友友何树何友何友.z;
      }
   }

   @EventTarget
   public void u(AttackEvent event) {
      KillAura.x();
      if (event.isPost() && !event.isCancelled() && (Boolean)Fucker.isLogin) {
         this.树树友何树何树树友友 = true;
         this.树友树树树友友何树树.D(11747522392279L);
         if (this.友树友何友树树友友树) {
            this.j();
         }
      }
   }

   @Override
   public void M() {
      this.P();
   }

   private void P() {
      KillAura.x();
      if (this.友树友何友树树友友树) {
         this.j();
      }

      this.树树友何树何树树友友 = false;
      this.树树友友何树何友何友 = null;
      this.树树友何树树树树友树 = null;
      this.树何何友树树友友何树.D(11747522392279L);
      this.树友树树树友友何树树.D(11747522392279L);
   }

   private void H() {
      this.树树友何树树树树友树 = new RemotePlayer(mc.level, mc.player.getGameProfile());
      this.树树友何树树树树友树.yHeadRot = mc.player.yHeadRot;
      this.树树友何树树树树友树.copyPosition(mc.player);
      this.树树友何树树树树友树.setUUID(mc.player.getUUID());
      this.树树友何树树树树友树.setId(mc.player.getId());
   }

   private static String HE_WEI_LIN() {
      return "行走的50万——何炜霖";
   }
}
