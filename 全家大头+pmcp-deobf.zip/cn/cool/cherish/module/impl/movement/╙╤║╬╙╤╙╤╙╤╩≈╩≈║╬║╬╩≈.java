package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.player.友友何树树友友树树树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友何友友友树树何何树 extends Module implements 何树友 {
   private final NumberValue 树树友友树何友树友树 = new NumberValue("Horizontal Speed", 1.0, 0.1, 5.0, 0.1);
   private final NumberValue 友友友何何何友何树树 = new NumberValue("Vertical Speed", 1.0, 0.1, 5.0, 0.1);
   private final BooleanValue 友何树友友友友何友何 = new BooleanValue("Fake Damage", true);
   private final BooleanValue 何友树何何树树树树树 = new BooleanValue("Disable Stop Move", false);
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[34];
   private static final String[] k = new String[34];
   private static String HE_WEI_LIN;

   public 友何友友友树树何何树() {
      super("Flight", "飞行", 树何友友何树友友何何.何友树何树友友友何树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-128678446786959079L, -6231836830013954563L, MethodHandles.lookup().lookupClass()).a(227887229183513L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(52370702862143L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[6];
      int var7 = 0;
      String var6 = "iÔ\u0003k$GÕi\u0090lí|Õð\u0098BÏ`V\u007fþù\u008c<l:cÓ|ô\u0007V\u0010y\b\u0017\u008a?P\u0015ê\u0014l¸ æ\u008c\u001bÚ öó&\u0015x\u0088nî \u0002wÍ×þ\\í\u009b¯uÙ5¸áP\u0001\u0092Kê²÷Éy(\u0083\u009d5ö\u0080¬\u001b×.\u001a®Ð|Ñi'LüÇ§ªÅ\u0013\u0087È\u0087.\u009fïXÇBe\u0019}\u009a\u008f8æy";
      byte var8 = 123;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[6];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "bMêâ\u0019²}ØvÛ\füåg\u0012L(qy\u009b7A\u0093«KÓ],e1\u0001\u0015É\u00adRL\u008e[Õ\u008aÃY= m#\u001eÁÝu¦q¡\u008b²\u0093\t";
                  var8 = 57;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 39;
               case 1 -> 23;
               case 2 -> 36;
               case 3 -> 10;
               case 4 -> 4;
               case 5 -> 22;
               case 6 -> 9;
               case 7 -> 35;
               case 8 -> 8;
               case 9 -> 62;
               case 10 -> 41;
               case 11 -> 18;
               case 12 -> 50;
               case 13 -> 27;
               case 14 -> 52;
               case 15 -> 24;
               case 16 -> 0;
               case 17 -> 17;
               case 18 -> 49;
               case 19 -> 63;
               case 20 -> 14;
               case 21 -> 13;
               case 22 -> 53;
               case 23 -> 38;
               case 24 -> 12;
               case 25 -> 16;
               case 26 -> 51;
               case 27 -> 37;
               case 28 -> 20;
               case 29 -> 3;
               case 30 -> 40;
               case 31 -> 2;
               case 32 -> 6;
               case 33 -> 1;
               case 34 -> 30;
               case 35 -> 11;
               case 36 -> 43;
               case 37 -> 56;
               case 38 -> 48;
               case 39 -> 54;
               case 40 -> 60;
               case 41 -> 57;
               case 42 -> 32;
               case 43 -> 58;
               case 44 -> 59;
               case 45 -> 31;
               case 46 -> 55;
               case 47 -> 45;
               case 48 -> 33;
               case 49 -> 46;
               case 50 -> 19;
               case 51 -> 21;
               case 52 -> 47;
               case 53 -> 7;
               case 54 -> 26;
               case 55 -> 28;
               case 56 -> 34;
               case 57 -> 29;
               case 58 -> 25;
               case 59 -> 44;
               case 60 -> 5;
               case 61 -> 61;
               case 62 -> 15;
               default -> 42;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 10544;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何友友友树树何何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何友友友树树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何友友友树树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 203 && var8 != 236 && var8 != 207 && var8 != 205) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'w') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 222) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 203) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 207) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @Override
   protected void h() {
      树树何友树友友何何何.M();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.何友树何何树树树树树.getValue()) {
            友友何树树友友树树树.a(115959497860849L);
         }
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "\u001cl#=\u001b.\u0013,n6\u00113\u0016qep\u0019.\u001bwa;Z桐伪叉叆伋桥厊厴佗佘";
      j[1] = "\u000fQf\u001a\"0\u000fQqF.?\u0015\u001aqX&<\u000f@<D#8\u0018Q`\u001a\u00036\u0002U~d#8\u0018Q`";
      j[2] = float.class;
      k[2] = "java/lang/Float";
      j[3] = "\u001eo>2eS\u001eo)ni\\\u0004$=szV\u0014$:tqI^\\/\u007f;";
      j[4] = double.class;
      k[4] = "java/lang/Double";
      j[5] = "Bc\u00154.\u001bM#X?$\u0006H~Sy,\u001bExW2o\u001dL}Wy,\u001bWhV2/\u0000\u000f叆佮厜厊县栰栜佮伂桐";
      j[6] = "u|zt\u007f/z<7\u007fu2\u007fa<9f!zg19y-f~zYe-tw&Aq,cw";
      j[7] = "Pbi@)JPb~\u001c%EJ)~\u0002-FPs3!4WWhs\u001d";
      j[8] = "96V&N\u001396AzB\u001c#}AdJ\u001f9'\fCF\u0003\u001a2RxJ\u00140";
      j[9] = "w\u0018\u0001\u001a\u000bZxXL\u0011\u0001G}\u0005GW\tZp\u0003C\u001cJ\\y\u0006CW\tZb\u0013B\u001c\nA:桧栾伬厯栤叟厽佺伬伱";
      j[10] = boolean.class;
      k[10] = "java/lang/Boolean";
      j[11] = "\u0003_SR\u0004#\u0003_D\u000e\b,\u0019\u0014D\u0010\u0000/\u0003N\t1\u0000$\bYU\u001d\u000f>";
      j[12] = "OK=eh\u0016DD,*\u0014\u000fK^\"i#?]I.t2\u0013JD";
      j[13] = "O\u0018\u0002mzM@XOfpPE\u0005D cC@\u0003I |O\\\u001a\u0002LzM@\u0013M`CC@\u0003I";
      j[14] = int.class;
      k[14] = "java/lang/Integer";
      j[15] = "IFn\"NEBI\u007fm/KIB{7";
      j[16] = "+\u0000=lg,}D)o\u001f厂佊栠厐叆叜厂佊叺伎\u0005. z]nba0p\u0006";
      j[17] = "Je5\u0011\u0003'W .}\u0017\u001d\n\"nEA\u001d0#=\u001e\u00021^pa@G";
      j[18] = "\u0012LH8X\u0004\u0010IJ7<\u001b\u007fGKe\u0003D\u007fwJ0\u0003\u0018B\f\u0012b[\u0011";
      j[19] = ":%\u001a5O\u000364]\u0005伨厮案伛核叆厶厮伌桟!n\u0016Va|Ob\u0007\u0011";
      j[20] = "N%upLU\u0018aas4校桫叟变栀佩叻桫叟栂\u0019\bX\u0013-rzPZ\ty";
      j[21] = "qN\u0011\u0002Gy'\n\u0005\u0001?受厎厴伢伶佢受伐桮桦k\u0003t,F\u0016\b[v6\u0012";
      j[22] = "1\u001a-_4Z3\u001f/PPE\\\u0011.\u0002`\u0012\\!/WoFaZw\u00057O";
      j[23] = "3\u0014Ukp~t\u0017\u001bg\u0002~YHS43(YyW6n/kEP|3w";
      j[24] = "TNLxv\f\u0002\nX{\u000e似厫桮使佌栗桸桱桮栻\u0011?\u0000\u0005\u0013\u001fvp\u0010\u000fH";
      j[25] = "\u0007\u0015$`\u001b2\\G1# J9E'$\u001b?C\u0018!dN\u000f";
      j[26] = "LS\u0004PN!Q\u0016\u001f<Z\u001b\f\u0014_\u0005\n\u001b6\u001d\u0014@_&[\u0014\u0014]\b";
      j[27] = "\u0015jB\u001aC)\b/YvW\u0013U-\u0019N\u0003\u0013o,J\u0015B?\u0001\u007f\u0016K\u0007";
      j[28] = "r\u0004T]\u0000\r)VA\u001e;ILTW\u0019\u0000\u00006\tQYU0";
      j[29] = "`l92&\u0002=|%\"\\R\b#dfb\u0002\b\u0012`3`[-|'0.W";
      j[30] = "\u0001KHwE\u0005W\u000f\\t=\u0001=BZ#W\u0016F\tIeFh\r\u000e\u001btC\u0013F\u001d]e=";
      j[31] = "\tp5+[t\u00145.GONJ>`w\u0010Ns6=$Zb\u001deaz\u001f";
      j[32] = "\u0017,Z\u001ac]\u0015)X\u0015\u0007Bz'YG7\u0014z\u0017X\u00128AGl\u0000@`H";
      j[33] = "\u0014m]t4RSn\u0013xFR~1[+v\r~\u0000_)*\u0003L<Xcw[";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void q(MotionEvent event) {
      树树何友树友友何何何.q();
      if (!this.Q(new Object[]{52406761729175L})) {
         mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, 0.0, mc.player.getDeltaMovement().z);
         int hSpeed = this.树树友友树何友树友树.getValue().intValue();
         int vSpeed = this.友友友何何何友何树树.getValue().intValue();
         if (mc.options.keyJump.isDown()) {
            mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, vSpeed, mc.player.getDeltaMovement().z);
         }

         if (mc.options.keyShift.isDown()) {
            mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, -vSpeed, mc.player.getDeltaMovement().z);
         }

         if (mc.player.zza != 0.0F || mc.player.xxa != 0.0F) {
            float forward = mc.player.zza;
            float strafe = mc.player.xxa;
            float yaw = mc.player.getYRot();
            double sin = Math.sin(Math.toRadians(yaw));
            double cos = Math.cos(Math.toRadians(yaw));
            double motionX = (strafe * cos - forward * sin) * hSpeed;
            double motionZ = (forward * cos + strafe * sin) * hSpeed;
            mc.player.setDeltaMovement(motionX, mc.player.getDeltaMovement().y, motionZ);
         }

         mc.player.fallDistance = 0.0F;
      }
   }

   @Override
   protected void M() {
      树树何友树友友何何何.M();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.友何树友友友友何友何.getValue()) {
            mc.player.handleEntityEvent((byte)2);
            mc.player.hurtTime = 10;
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "何树友为什么濒天了";
   }
}
