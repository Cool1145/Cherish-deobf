package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.packet.SyncHandleReceivePacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetHealthPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;
import why.tree.friend.antileak.Fucker;

public class 何友何友友树友友何何 extends Module implements 何树友 {
   public static 何友何友友树友友何何 友何树友何友友友何何;
   private static final boolean 树友何树何树友友树何 = false;
   private final NumberValue 树友何何树树何树何友;
   private final BooleanValue 树友友何友友树何树何;
   private final BooleanValue 友树何树何友何何树友;
   private final Queue<何友何友友树友友何何.友何树何友树树友何何> 树树何何友友树友何树;
   private boolean 友友树何友友友友何友;
   private boolean 树何何友何友何何何友;
   private double 友何何树何树树友树友;
   private static String 树树何友何友友友树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[26];
   private static final String[] l = new String[26];
   private static int _何建国230622195906030014 _;

   public 何友何友友树友友何何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/movement/何友何友友树友友何何.a J
      // 03: ldc2_w 27379717726846
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 15021
      // 0c: ldc2_w 6061391791102360325
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic o (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 3131
      // 19: ldc2_w 1021569905045556639
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic o (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 7997466390072162447
      // 26: lload 1
      // 27: invokedynamic Â (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/NumberValue
      // 33: dup
      // 34: sipush 31617
      // 37: ldc2_w 4638851050683742763
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic o (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 1133
      // 44: ldc2_w 3353707249607591362
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic o (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: bipush 50
      // 50: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 53: bipush 10
      // 55: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 58: sipush 200
      // 5b: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 5e: bipush 10
      // 60: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 63: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 66: putfield cn/cool/cherish/module/impl/movement/何友何友友树友友何何.树友何何树树何树何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 69: aload 0
      // 6a: new cn/cool/cherish/value/impl/BooleanValue
      // 6d: dup
      // 6e: sipush 28400
      // 71: ldc2_w 2665685933330607952
      // 74: lload 1
      // 75: lxor
      // 76: invokedynamic o (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 7b: sipush 19099
      // 7e: ldc2_w 1900919343227800364
      // 81: lload 1
      // 82: lxor
      // 83: invokedynamic o (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 88: bipush 1
      // 89: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 8c: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 8f: putfield cn/cool/cherish/module/impl/movement/何友何友友树友友何何.树友友何友友树何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 92: aload 0
      // 93: new cn/cool/cherish/value/impl/BooleanValue
      // 96: dup
      // 97: sipush 283
      // 9a: ldc2_w 8018028640533692600
      // 9d: lload 1
      // 9e: lxor
      // 9f: invokedynamic o (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // a4: sipush 10002
      // a7: ldc2_w 1282389799164765881
      // aa: lload 1
      // ab: lxor
      // ac: invokedynamic o (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // b1: bipush 0
      // b2: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // b5: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // b8: invokedynamic get ()Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/movement/何友何友友树友友何何.T ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // bd: invokevirtual cn/cool/cherish/value/impl/BooleanValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // c0: checkcast cn/cool/cherish/value/impl/BooleanValue
      // c3: putfield cn/cool/cherish/module/impl/movement/何友何友友树友友何何.友树何树何友何何树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // c6: aload 0
      // c7: new java/util/concurrent/ConcurrentLinkedQueue
      // ca: dup
      // cb: invokespecial java/util/concurrent/ConcurrentLinkedQueue.<init> ()V
      // ce: putfield cn/cool/cherish/module/impl/movement/何友何友友树友友何何.树树何何友友树友何树 Ljava/util/Queue;
      // d1: aload 0
      // d2: bipush 0
      // d3: ldc2_w 7996787609352877054
      // d6: lload 1
      // d7: invokedynamic Ó (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // dc: aload 0
      // dd: bipush 0
      // de: ldc2_w 7997279457673146466
      // e1: lload 1
      // e2: invokedynamic Ó (Ljava/lang/Object;ZJJ)V bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // e7: aload 0
      // e8: dconst_0
      // e9: ldc2_w 7997803436137231412
      // ec: lload 1
      // ed: invokedynamic Ó (Ljava/lang/Object;DJJ)V bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // f2: aload 0
      // f3: ldc2_w 7997575413171179274
      // f6: lload 1
      // f7: invokedynamic ä (Lcn/cool/cherish/module/impl/movement/何友何友友树友友何何;JJ)V bsm=cn/cool/cherish/module/impl/movement/何友何友友树友友何何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // fc: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2905424341888146790L, -6245494086390323675L, MethodHandles.lookup().lookupClass()).a(19611345956474L);
      // $VF: monitorexit
      a = var10000;
      long var14 = a ^ 4152579221700L;
      a();
      c<"ù">("TRfem", 7225680090393351650L, var14);
      Cipher var5;
      Cipher var18 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(var14 << var6 * 8 >>> 56);
      }

      var18.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[19];
      int var10 = 0;
      String var9 = "w\u009dt\u0016Þ·Âpü\u0092r´#ÓÆ*\u0086\u0016\u0086<-U\u0003¡Õ#\u0013B|SB-\\\u001c^Nì6+\u0013 W\u008dñÖág\u008f{â\u0018:Ý\u009a~Â±]@ ¼j].¨ø¹ég·2\u009e*\u0018?\u0091\u008d\u0011Øðà\u0087k\u0019|Bç1ÁÐ\u009fÑÉ z·\u0096¾\u0018\u0088W\f3è·\u001aÐ\u0094wYÈ\u0089i¤>\u007fMG*;\u0018Ð\u001c\u0010\u0003¯3\u001c8ÄBËÀñsãd¸Á\u001d(=\u0083±Ü>!Ê\n\u001fèáÎ¼\u0090Re¹ÁA\f7\"(Æ\u000e- ûXÍ\u0002\u0099U¡ý©æA-©(+Ù\u0011y\u009acû$g°\rÙYºsïo\u0088Z\u0001°Ñ6\u0007\u001c\u008fîå\u008b\u0019Î\u0016\u009cY\u009b«f»áØ ZêçøÛÅS»\u0096|á\u0090C±lÕ\\TÙô,%þ\u0004<0\fV¹;\u0001N \u0017ô*aj?y5<ÛscQçF¯/\u0086M³À\u009e>ò,\u0018,¼Î\u009bß\t\u0018`ï\u0015ï%Â\u009aæÕ¡JTÕ\u0015\ng\u0087\u0097\u0090û\u001b\u009bd5\u0010®e'|}\u0094\u0095f¯7×=µÉG\u009f0\têòZ9\u0012&\u009efG§öt\u0016$Ìz\u001a\u0080¶DüÙ¦pS\u0084\u0013®\u008e\u0097\u009c)V\u0091½¹UÇ\u0013~ö\u0007sà\u0015zÙ\u0018{)Ö`Þ1\u0007\u008c(kaü\u0089ª0\\\u0016MÒÿ!´6´\u0018ý\u0080S3'ÁºÍÔõ\u009dù$îY¦\u0096õ¶Î\"9©\u0099 e\u0089öü\u007fk\u0002\u000b×\u0082±¨:¿©¦>\"ÍÐ\u0096¦\u001c+qa\u007f\u009e=)Ì\u0087 ^¦\u0092\u009cPô\b\u0017»:p\u008e1k_\u00ad\u009e\u0098\u0015Ü1\u009dÊ4\u009b1\u0011.¸67¨ f¢Ñ(Ü\u0089M \u0081_@Þ\u009dÿÏj\u001fûHMUIàüzL¨\u008f\u0098\u0007'~";
      short var11 = 528;
      char var8 = '(';
      int var17 = -1;

      label37:
      while (true) {
         String var19 = var9.substring(++var17, var17 + var8);
         byte var10001 = -1;

         while (true) {
            String var27 = c(var5.doFinal(var19.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var12[var10++] = var27;
                  if ((var17 += var8) >= var11) {
                     c = var12;
                     h = new String[19];
                     Cipher var0;
                     Cipher var21 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var14 << var1 * 8 >>> 56);
                     }

                     var21.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{-9, -18, -101, 99, -59, 49, 35, 124});
                     long var31 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var31;
                     return;
                  }

                  var8 = var9.charAt(var17);
                  break;
               default:
                  var12[var10++] = var27;
                  if ((var17 += var8) < var11) {
                     var8 = var9.charAt(var17);
                     continue label37;
                  }

                  var9 = "g\u00adçÅ%2wO\u000emçxÃ_¬%\tâ4\u0090\u0018äiùM½i}¢&Ð\u0016MÃ\u0019\u0083\u0007Ú1¯\u0084èø±Ô\u008eÀÝ\t3VøTîeL(\u009fbîEtÄ0#'\u0018=$¤\f:iópíÑ\u001c\u008déu{\fy\u0007g(\u0003¬\f\u0086]ö\u0086\u0018\u008eî";
                  var11 = 97;
                  var8 = '8';
                  var17 = -1;
            }

            var19 = var9.substring(++var17, var17 + var8);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 何友何友友树友友何何.a ^ 20091291982197L;
      long ax = a ^ 48869803994330L;
      c<"ù">(6193588768400076147L, a);
      if (!this.w(new Object[]{ax})) {
         if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
            this.L();
            c<"Ó">(this, false, 6192802796873582837L, a);
            c<"Ó">(this, false, 6194421910901214057L, a);
            c<"Ó">(this, 0.0, 6194399449264983871L, a);
         }
      }
   }

   public boolean I() {
      long a = 何友何友友树友友何何.a ^ 112104487744544L;
      return c<"A">(this, 8693133540957300128L, a);
   }

   @EventTarget
   public void S(WorldEvent event) {
      long a = 何友何友友树友友何何.a ^ 135292494216709L;
      c<"ù">(-971540145439684093L, a);
      if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
         this.L();
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 30;
               case 1 -> 24;
               case 2 -> 39;
               case 3 -> 14;
               case 4 -> 10;
               case 5 -> 3;
               case 6 -> 29;
               case 7 -> 2;
               case 8 -> 52;
               case 9 -> 22;
               case 10 -> 51;
               case 11 -> 37;
               case 12 -> 28;
               case 13 -> 1;
               case 14 -> 38;
               case 15 -> 42;
               case 16 -> 0;
               case 17 -> 18;
               case 18 -> 32;
               case 19 -> 9;
               case 20 -> 7;
               case 21 -> 62;
               case 22 -> 11;
               case 23 -> 40;
               case 24 -> 17;
               case 25 -> 34;
               case 26 -> 33;
               case 27 -> 31;
               case 28 -> 54;
               case 29 -> 59;
               case 30 -> 55;
               case 31 -> 61;
               case 32 -> 41;
               case 33 -> 44;
               case 34 -> 13;
               case 35 -> 48;
               case 36 -> 23;
               case 37 -> 12;
               case 38 -> 49;
               case 39 -> 26;
               case 40 -> 4;
               case 41 -> 5;
               case 42 -> 36;
               case 43 -> 15;
               case 44 -> 8;
               case 45 -> 57;
               case 46 -> 45;
               case 47 -> 19;
               case 48 -> 43;
               case 49 -> 16;
               case 50 -> 46;
               case 51 -> 63;
               case 52 -> 35;
               case 53 -> 50;
               case 54 -> 20;
               case 55 -> 25;
               case 56 -> 6;
               case 57 -> 47;
               case 58 -> 58;
               case 59 -> 21;
               case 60 -> 60;
               case 61 -> 27;
               case 62 -> 56;
               default -> 53;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12126;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/何友何友友树友友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何友何友友树友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'A' && var8 != 211 && var8 != 194 && var8 != 228) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 248) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 249) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'A') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 211) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何友何友友树友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static String n() {
      return 树树何友何友友友树何;
   }

   @EventTarget
   public void h(SyncHandleReceivePacketEvent event) {
      long a = 何友何友友树友友何何.a ^ 131686687067990L;
      c<"ù">(4888492099755047760L, a);
      if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
         if (!event.isCancelled()) {
            Packet<?> packet = event.getPacket();
            if (!(packet instanceof ServerboundChatPacket)
               && !(packet instanceof ClientboundSystemChatPacket)
               && !(packet instanceof ServerboundCommandSuggestionPacket)) {
               if (!(packet instanceof ClientboundPlayerPositionPacket) && !(packet instanceof ClientboundDisconnectPacket)) {
                  if (packet instanceof ClientboundSoundPacket soundPacket && soundPacket.getSound().get() == c<"Â">(4887840776529112060L, a)) {
                     this.L();
                  } else if (packet instanceof ClientboundSetHealthPacket healthPacket && healthPacket.getHealth() <= 0.0F) {
                     this.L();
                     this.y(false);
                  } else {
                     event.setCancelled(true);
                     c<"A">(this, 4887245900707864505L, a).offer(new 何友何友友树友友何何.友何树何友树树友何何(packet, System.currentTimeMillis()));
                  }
               } else {
                  this.L();
                  this.y(false);
               }
            }
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static void a() {
      k[0] = "6\u0004t\u0005J\u000f9D9\u000e@\u0012<\u00192HH\u000f1\u001f6\u0003\u000b\t8\u001a6HH\u000f#\u000f7\u0003K\u0014{伿厑伳叮厫桄厡厑伳佰";
      k[1] = "\u001cM/g\u0005t\u0013\rbl\u000fi\u0016Pi*\u001cz\u0013Vd*\u0003v\u000fO/F\u0005t\u0013F`j<z\u0013Vd";
      k[2] = boolean.class;
      l[2] = "java/lang/Boolean";
      k[3] = "2`\u0017]b^9o\u0006\u0012\tJ;d\u0011H%]6";
      k[4] = "\u0017\b%^%(\u001c\u00074\u0011X0\u000f\u0000=X";
      k[5] = "I3\u001ak\u0003EW;\u0000$|EF'\t";
      k[6] = "X\b\u000204RX\b\u0015l8]BC\u0005q,UR\u001eXM6NX\t3h<UB\u001e";
      k[7] = "G\u000b\u0018\u0019xgG\u000b\u000fEth]@\u001fX``M\u001dBdz{G\n)Ap`]";
      k[8] = double.class;
      l[8] = "java/lang/Double";
      k[9] = "2B[u\u0014x=\u0002\u0016~\u001ee8_\u001d8\u0016x5Y\u0019sU佂伄叧传佃厰佂伄栽桤";
      k[10] = void.class;
      l[10] = "java/lang/Void";
      k[11] = "l\nK\"BbcJ\u0006)H\u007ff\u0017\ro[lc\u0011\u0000oD`\u007f\bK\u000fX`m\u0001\u0017\u0017Laz\u0001";
      k[12] = "\u0013.RW\u0013k\u0018!C\u0018re\u0013*GB";
      k[13] = "[*\u0015@]v\\u\u001cq叱双桾伒厱厲叱双伺厌rHQ1W!\u001d\u001dV3[";
      k[14] = "x0\u0017U`F\u007fo\u001ed栖栦伙伈厳厧栖叼伙桌p_wG~o\u0014\n\u007fC-";
      k[15] = "%wy\u001e3;\"(p/原桛佄栋佃召企伟栀发\u001e\u0016d)'lo\u00178|c";
      k[16] = "!&\u0005\u000f^\u0018&y\f>史似栄厀伿叽史厢佀伞b\u0002T\u0006,,\u001b\u0005\u000b\u000f";
      k[17] = "+\u000b\u001f2g\u0014.W\u0015n\u001b\u0016@WNj!C@nI`c\u001c'\u0011\r?aA";
      k[18] = "\r-:P}\u0012\nr3a栋厨史伕厞厢栋伶栨伕]X*\u0000\u000f6,YvUK";
      k[19] = "aI/gGIf\u0016&V叫佭伀栵伕桏栱右桄可HkLI?J%:DQm";
      k[20] = "n\u0012'Ax\fiM.p栎伨伏厴伝厳佊伨伏厴@ItKb\u0019/\u001csIn";
      k[21] = ";GK_\u00130<\u0018Bn\u0015I=FFR\u000e;lDC\b|scH\u0010\u001c\u000e\"aMJn";
      k[22] = "\u00136hd\u007f\u0005Sqca\u0011厨叮桕栘作叒厨佰桕参\u0001/\u0011D)oooVO,";
      k[23] = "/#h~V\u001e(|aOfg(z?4B\nc+w>9X|$61\u0007\nc!3O";
      k[24] = "\u0006x\u0010a\u0004\u0002\u0001'\u0019P\r{\u0001!G+\u0010\u0016Jp\u000f!k";
      k[25] = "A6A+5^FiH\u001a桃古传伎栿栃伇栾传厐&%'V\u0003>Yb'_\u0007";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 何友何友友树友友何何.a ^ 92477818116754L;
      long ax = a ^ 116737586720573L;
      c<"ù">(-7632675076882026860L, a);
      if (!this.w(new Object[]{ax})) {
         if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
            c<"Ó">(this, false, -7631904773588923630L, a);
            c<"Ó">(this, false, -7633522517608232818L, a);
            c<"Ó">(this, mc.player.getY(), -7633131719499100968L, a);
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void r(MotionEvent event) {
      long a = 何友何友友树友友何何.a ^ 56303825132001L;
      long ax = a ^ 14306475502670L;
      c<"ù">(1540280945292652007L, a);
      if (!this.w(new Object[]{ax})) {
         if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.树何何友何树树友友树)) {
            if (!event.isPre()) {
               if (!mc.player.isDeadOrDying() && !(mc.player.getHealth() <= 0.0F)) {
                  if (!c<"A">(this, 1541744162303330401L, a) && mc.player.getY() > c<"A">(this, 1541018367135961003L, a) + 3.0) {
                     c<"Ó">(this, true, 1541744162303330401L, a);
                     this.N(b<"o">(5233, 6733631486243253827L ^ a));
                  }

                  if (c<"A">(this, 1541841518646937870L, a).isEmpty()) {
                     this.N(b<"o">(26346, 6787080940986719442L ^ a));
                  }

                  this.y();
               } else {
                  this.L();
                  this.y(false);
               }
            }
         }
      }
   }

   @EventTarget
   public void y(StrafeEvent event) {
      long a = 何友何友友树友友何何.a ^ 32691957574868L;
      c<"ù">(-6893599440863291182L, a);
      if (c<"A">(this, -6892856839648968876L, a).getValue() && mc.player.onGround() && !c<"A">(this, -6893306687780864312L, a)) {
         mc.player.jumpFromGround();
         c<"Ó">(this, true, -6893306687780864312L, a);
      }
   }

   private void y() {
      long a = 何友何友友树友友何何.a ^ 6301724712307L;
      long currentTime = System.currentTimeMillis();
      long delay = c<"A">(this, 1293215574198605074L, a).getValue().longValue() * j;
      c<"A">(this, 1294659820460789148L, a).removeIf(snapshot -> {
         long axx = 何友何友友树友友何何.a ^ 63695707458790L;
         long ax = axx ^ 98242239692807L;
         c<"ù">(4640721375882115296L, axx);
         if (currentTime - snapshot.u() >= delay) {
            try {
               PacketUtils.U(new Object[]{ax, snapshot.o()});
               this.N(b<"o">(4843, 5353083048968420817L ^ axx) + snapshot.o().getClass().getSimpleName());
               return true;
            } catch (Exception var12) {
               this.N(b<"o">(9715, 9219492056561470173L ^ axx) + var12.getMessage());
               return true;
            }
         } else {
            return false;
         }
      });
   }

   private void L() {
      long a = 何友何友友树友友何何.a ^ 83459810148787L;
      long ax = a ^ 47689666301266L;
      c<"ù">(5562602526577128885L, a);
      this.N(b<"o">(7676, 6075184899783786372L ^ a) + c<"A">(this, 5564127436671488348L, a).size() + b<"o">(18535, 2299822942164036108L ^ a));
      int count = 0;
      if (!c<"A">(this, 5564127436671488348L, a).isEmpty()) {
         何友何友友树友友何何.友何树何友树树友何何 snapshot = (何友何友友树友友何何.友何树何友树树友何何)c<"A">(this, 5564127436671488348L, a).poll();
         if (snapshot != null) {
            try {
               PacketUtils.U(new Object[]{ax, snapshot.o()});
               if (++count % 10 == 0) {
                  this.N(b<"o">(31891, 899881789149683447L ^ a) + count + b<"o">(14361, 822003238552689274L ^ a));
               }
            } catch (Exception var9) {
               this.N(b<"o">(608, 847165919782789132L ^ a) + var9.getMessage());
            }
         }
      }

      this.N(b<"o">(4618, 3070190673254740075L ^ a) + count + b<"o">(21543, 8445981512180512335L ^ a));
   }

   public void N(String message) {
      long a = 何友何友友树友友何何.a ^ 93385524672641L;
      c<"ù">(8358762829062458503L, a);
      if ((Boolean)c<"A">(this, 8360240041909419407L, a).v().get() && c<"A">(this, 8360240041909419407L, a).getValue()) {
      }
   }

   public static void W(String var0) {
      树树何友何友友友树何 = var0;
   }

   private static String HE_WEI_LIN() {
      return "何炜霖黑水";
   }

   private record 友何树何友树树友何何(Packet<?> 树树友友何何友树何友, long 树树何友树何何树友树) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[6];
      private static final String[] c = new String[6];
      private static String HE_WEI_LIN;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(373020860864128817L, -8349107414748755905L, MethodHandles.lookup().lookupClass()).a(140624334828411L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 228 && var8 != '$' && var8 != 217 && var8 != 245) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 252) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'R') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 228) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == '$') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 217) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/何友何友友树友友何何$友何树何友树树友何何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 41;
                  case 1 -> 33;
                  case 2 -> 0;
                  case 3 -> 44;
                  case 4 -> 43;
                  case 5 -> 28;
                  case 6 -> 34;
                  case 7 -> 6;
                  case 8 -> 36;
                  case 9 -> 55;
                  case 10 -> 39;
                  case 11 -> 4;
                  case 12 -> 13;
                  case 13 -> 16;
                  case 14 -> 52;
                  case 15 -> 54;
                  case 16 -> 12;
                  case 17 -> 49;
                  case 18 -> 18;
                  case 19 -> 62;
                  case 20 -> 37;
                  case 21 -> 50;
                  case 22 -> 26;
                  case 23 -> 46;
                  case 24 -> 10;
                  case 25 -> 58;
                  case 26 -> 1;
                  case 27 -> 29;
                  case 28 -> 21;
                  case 29 -> 25;
                  case 30 -> 3;
                  case 31 -> 20;
                  case 32 -> 31;
                  case 33 -> 2;
                  case 34 -> 30;
                  case 35 -> 38;
                  case 36 -> 61;
                  case 37 -> 19;
                  case 38 -> 23;
                  case 39 -> 11;
                  case 40 -> 47;
                  case 41 -> 53;
                  case 42 -> 22;
                  case 43 -> 27;
                  case 44 -> 51;
                  case 45 -> 17;
                  case 46 -> 14;
                  case 47 -> 56;
                  case 48 -> 35;
                  case 49 -> 5;
                  case 50 -> 42;
                  case 51 -> 57;
                  case 52 -> 40;
                  case 53 -> 7;
                  case 54 -> 45;
                  case 55 -> 9;
                  case 56 -> 59;
                  case 57 -> 8;
                  case 58 -> 24;
                  case 59 -> 32;
                  case 60 -> 60;
                  case 61 -> 63;
                  case 62 -> 48;
                  default -> 15;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "BJ\u0016D`nM\n[OjsHWP\tbnEQTB!hLTT\tbnWAUBau\u000f佱右佲叄及栰可右佲佚%只佱栩佲叄栐栰可佭佲";
         b[1] = "i^~38\u001di^io4\u0012s\u0015dx!\u0003hIa3%\u0006hOe~:\u0018)kk~>\u0011s";
         b[2] = long.class;
         c[2] = "java/lang/Long";
         b[3] = "W#jS;\u001c\\,{\u001cZ\u0012W'\u007fF";
         b[4] = "\u0018)Z4\u001eHY&RH桪桯叡历佮伕厰桯使历3qH\fP)\t/C\u0013G";
         b[5] = "~XY_-<?WQ#桙栛伙号栩佾伝栛厇栭0\u001a>z-\u0005\nE\u007fy.";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public Packet<?> o() {
         long a = 何友何友友树友友何何.友何树何友树树友何何.a ^ 112584828623096L;
         return a<"ä">(this, -1885742684355368329L, a);
      }

      public long u() {
         long a = 何友何友友树友友何何.友何树何友树树友何何.a ^ 60962800351434L;
         return a<"ä">(this, 5036827935935038627L, a);
      }

      private static String HE_SHU_YOU() {
         return "何树友，和树做朋友";
      }
   }
}
