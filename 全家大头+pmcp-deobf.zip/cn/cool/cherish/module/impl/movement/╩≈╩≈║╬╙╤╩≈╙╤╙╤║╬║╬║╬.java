package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.packet.SyncHandleReceivePacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetHealthPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;
import net.minecraft.sounds.SoundEvents;
import why.tree.friend.antileak.Fucker;

public class 树树何友树友友何何何 extends Module implements 何树友 {
   public static 树树何友树友友何何何 何树友树何树友友何何;
   private static final boolean 何友何树友友何树何友 = false;
   private final NumberValue 何树树何何友树何树友 = new NumberValue("Packet Delay", "发包延迟", 50, 10, 200, 10);
   private final BooleanValue 树树何何友友树树友树 = new BooleanValue("Auto Jump", "自动跳跃", true);
   private final BooleanValue 树树何何友树何友树树 = new BooleanValue("Debug", "调试信息", false).A(() -> false);
   private final Queue<树树何友树友友何何何.友友何何树树何友树树> 何树树树树友何何友何 = new ConcurrentLinkedQueue<>();
   private boolean 何树友友友友友友何何 = false;
   private boolean 何友何友树何树何树何 = false;
   private double 树何树友树何友友友何 = 0.0;
   private static boolean 友树友友树树何树树友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long j;
   private static final Object[] k = new Object[26];
   private static final String[] l = new String[26];
   private static int _何树友为什么濒天了 _;

   public 树树何友树友友何何何() {
      super("LongJump", "跳远冠军", 树何友友何树友友何何.何友树何树友友友何树);
      何树友树何树友友何何 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5112506802119903759L, -3384424051091764166L, MethodHandles.lookup().lookupClass()).a(91471788372896L);
      // $VF: monitorexit
      a = var10000;
      a();
      M(true);
      Cipher var5;
      Cipher var15 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(62170858356323L << var6 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[19];
      int var10 = 0;
      String var9 = "\u000fJ\u0080ç\u0016Ã&èÇä·Ê\u0082\u0007_c\u0099\u00adAQÌÉ!9Yùµ$\u000b\u001eÛZ(f£ó.~\"hb¥Eì«Ñ\u0093\u0093EÒ\nX*\u0086â8x5\u009fÜv§1È¸PÚE\u0093\u009eL8\u009f(é3Lb;5|7jùD\u0013J¼À ½,H>ø\tðE\u000fnZ»¥÷<\u0087ê1\u0096A8Ûç{8å\u0083bªÑ.\u0017ÕÐyî®\u009e=K«\u0001Uã%\u0002BVCSò5]\u0011\u00019\u009f©,YìwF\t¾ójá\u007f\u0017Læî\u0090ÞFEÜ\u0091üò 9¥\u0091óõh¯³5\u0090)\u0097ÊV'E\u001d\u0080âÆPðÆ$\u0095íÖ\u0084>òT\r\u0018Ì$ {Ë\u0095f0¯Ì\u009c\u008c§R\r_ùuaÞQ£®b )\u000e\u0016´\u008e(í\u0085'Á\u0097iu$*\u0007\u008baûÓÝá\u0082UÄ\u001e\u00801üÉ\u009f\u0081\u0010â\u0084 ÐG\u0081/ÂøåØu\u000ej'Ã\u00186Ã{LÙÛÿ÷\u0016Ñ\u0019õó£\u009cTÛ×`ÍO¯Í% ½A!h°È5×à\u0003¦\u0018?x\u0016\u0018.wlUÖý\u0012A\u008b\u00adiðÚ÷\u0085y(\u009dótvÈ\u00ad©\u008cÈBNr¥Ô'`B;_\u0019A\u0099*ðsÄ\u0098æH~¹&«Ü\u0082\u007fðb\u0019\u0082\u0018·I·\f\u008bqÄ%Lù\u0098\u0010>µÇ\u001bÜóÐåþÈ\u001f\u000b(æe,\u0004xxiNboñ$ª\u0007M¡\u0017±ß\u0011\u008c8\u0005,?Kè±\u0092óFÏ\u009b¼&d]`ýx\u0018\u008f÷ó\u0018(\u001e\u000e'Ø`L\u0018q¾\u008e\u0082»Y\u009e8$Mbñ\u0018`cà¶6ÇÖé´ãR´íZü\u00008\u0094Mÿ&«¤l û\u00179\u001aE\u0086Ò\u0017¡U®~È¯¿²]G\u000e\u0001´G»Ü¢q©\u009azÉu\u008c(¾:4l9\u0089Åë\u0097ªè¤¯õÔoaÏÉ³ ¡]['R¼É^\u0014\u0015\u0010N/áÚ´â(ó";
      short var11 = 568;
      char var8 = ' ';
      int var14 = -1;

      label37:
      while (true) {
         String var16 = var9.substring(++var14, var14 + var8);
         byte var10001 = -1;

         while (true) {
            String var24 = c(var5.doFinal(var16.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var12[var10++] = var24;
                  if ((var14 += var8) >= var11) {
                     c = var12;
                     h = new String[19];
                     Cipher var0;
                     Cipher var18 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(62170858356323L << var1 * 8 >>> 56);
                     }

                     var18.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{30, -105, -6, 127, 68, 15, -115, -110});
                     long var28 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     j = var28;
                     return;
                  }

                  var8 = var9.charAt(var14);
                  break;
               default:
                  var12[var10++] = var24;
                  if ((var14 += var8) < var11) {
                     var8 = var9.charAt(var14);
                     continue label37;
                  }

                  var9 = "e\u0017ªQ\u0002¢ÿ#è³2ó¹ýò\u0002 ÉE*Ìð\u009c\u0007\u0085ô\bhëë\u0001Zì,¯àuÖ\u0010ÒyÆ\u0085,e\u0097\u009e6\u0007";
                  var11 = 49;
                  var8 = 16;
                  var14 = -1;
            }

            var16 = var9.substring(++var14, var14 + var8);
            var10001 = 0;
         }
      }
   }

   private void I() {
      M();
      this.p("Starting to release " + this.何树树树树友何何友何.size() + " packets");
      int count = 0;
      if (!this.何树树树树友何何友何.isEmpty()) {
         树树何友树友友何何何.友友何何树树何友树树 snapshot = this.何树树树树友何何友何.poll();
         if (snapshot != null) {
            try {
               PacketUtils.V(103559961885797L, snapshot.c());
               if (++count % 10 == 0) {
                  this.p("Released " + count + " packets so far");
               }
            } catch (Exception var9) {
               this.p("Error handling packet: " + var9.getMessage());
            }
         }
      }

      this.p("Released a total of " + count + " packets");
   }

   @EventTarget
   public void J(StrafeEvent event) {
      q();
      if (this.树树何何友友树树友树.getValue() && mc.player.onGround() && !this.何友何友树何树何树何) {
         mc.player.jumpFromGround();
         this.何友何友树何树何树何 = true;
      }
   }

   @EventTarget
   public void V(SyncHandleReceivePacketEvent event) {
      M();
      if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
         if (!event.isCancelled()) {
            Packet<?> packet = event.getPacket();
            if (!(packet instanceof ServerboundChatPacket)
               && !(packet instanceof ClientboundSystemChatPacket)
               && !(packet instanceof ServerboundCommandSuggestionPacket)) {
               if (!(packet instanceof ClientboundPlayerPositionPacket) && !(packet instanceof ClientboundDisconnectPacket)) {
                  if (packet instanceof ClientboundSoundPacket soundPacket && soundPacket.getSound().get() == SoundEvents.PLAYER_HURT) {
                     this.I();
                  } else if (packet instanceof ClientboundSetHealthPacket healthPacket && healthPacket.getHealth() <= 0.0F) {
                     this.I();
                     this.J(false);
                  } else {
                     event.setCancelled(true);
                     this.何树树树树友何何友何.offer(new 树树何友树友友何何何.友友何何树树何友树树(packet, System.currentTimeMillis()));
                  }
               } else {
                  this.I();
                  this.J(false);
               }
            }
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (l[var4] != null) {
         return var4;
      } else {
         Object var5 = k[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 0;
               case 1 -> 29;
               case 2 -> 2;
               case 3 -> 55;
               case 4 -> 50;
               case 5 -> 10;
               case 6 -> 19;
               case 7 -> 23;
               case 8 -> 34;
               case 9 -> 3;
               case 10 -> 5;
               case 11 -> 58;
               case 12 -> 11;
               case 13 -> 57;
               case 14 -> 48;
               case 15 -> 51;
               case 16 -> 26;
               case 17 -> 31;
               case 18 -> 43;
               case 19 -> 42;
               case 20 -> 30;
               case 21 -> 35;
               case 22 -> 45;
               case 23 -> 53;
               case 24 -> 7;
               case 25 -> 22;
               case 26 -> 8;
               case 27 -> 4;
               case 28 -> 32;
               case 29 -> 59;
               case 30 -> 61;
               case 31 -> 41;
               case 32 -> 62;
               case 33 -> 6;
               case 34 -> 21;
               case 35 -> 60;
               case 36 -> 13;
               case 37 -> 54;
               case 38 -> 16;
               case 39 -> 36;
               case 40 -> 63;
               case 41 -> 40;
               case 42 -> 37;
               case 43 -> 9;
               case 44 -> 38;
               case 45 -> 12;
               case 46 -> 17;
               case 47 -> 18;
               case 48 -> 49;
               case 49 -> 25;
               case 50 -> 24;
               case 51 -> 52;
               case 52 -> 1;
               case 53 -> 27;
               case 54 -> 47;
               case 55 -> 46;
               case 56 -> 28;
               case 57 -> 44;
               case 58 -> 20;
               case 59 -> 56;
               case 60 -> 14;
               case 61 -> 15;
               case 62 -> 33;
               default -> 39;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            l[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 18491;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树何友树友友何何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[o¤F+è\u0017]\u0012\b¿\u0093\u0012¢ê¶\u008c, ëGBÕå«Ö\"æê4Õ\u008eÈ |")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树何友树友友何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public boolean x() {
      return this.何树友友友友友友何何;
   }

   private void s() {
      long currentTime = System.currentTimeMillis();
      long delay = this.何树树何何友树何树友.getValue().longValue() * 50L;
      this.何树树树树友何何友何.removeIf(snapshot -> {
         M();
         if (currentTime - snapshot.b() >= delay) {
            try {
               PacketUtils.V(103559961885797L, snapshot.c());
               this.p("Processed packet: " + snapshot.c().getClass().getSimpleName());
               return true;
            } catch (Exception var12) {
               this.p("Failed to handle packet:" + var12.getMessage());
               return true;
            }
         } else {
            return false;
         }
      });
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树何友树友友何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'z' && var8 != 236 && var8 != 243 && var8 != '$') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 200) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 195) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'z') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 243) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @Override
   public void h() {
      q();
      if (!this.Q(new Object[]{52406761729175L})) {
         if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
            this.I();
            this.何树友友友友友友何何 = false;
            this.何友何友树何树何树何 = false;
            this.树何树友树何友友友何 = 0.0;
         }
      }
   }

   @EventTarget
   public void h(MotionEvent event) {
      q();
      if (!this.Q(new Object[]{52406761729175L})) {
         if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
            if (!event.isPre()) {
               if (!mc.player.isDeadOrDying() && !(mc.player.getHealth() <= 0.0F)) {
                  if (!this.何树友友友友友友何何 && mc.player.getY() > this.树何树友树何友友友何 + 3.0) {
                     this.何树友友友友友友何何 = true;
                     this.p("Flying!");
                  }

                  if (this.何树树树树友何何友何.isEmpty()) {
                     this.p("All packets released!");
                  }

                  this.s();
               } else {
                  this.I();
                  this.J(false);
               }
            }
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         k[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      k[0] = "jWe(w\u0005e\u0017(#}\u0018`J#eu\u0005mL'.6\u0003dI'eu\u0005\u007f\\&.v\u001e'栨桚伞叓桻参史伞伞位";
      k[1] = double.class;
      l[1] = "java/lang/Double";
      k[2] = boolean.class;
      l[2] = "java/lang/Boolean";
      k[3] = "M\u0005)\n'jF\n8EL~D\u0001/\u001f`iI";
      k[4] = "9t!\u0006\fJ'|;IsJ6`2";
      k[5] = "K\u0002aMR\u0013DB,FX\u000eA\u001f'\u0000K\u001dD\u0019*\u0000T\u0011X\u0000a`H\u0011J\t=x\\\u0010]\t";
      k[6] = "Pl\r<.*_,@7$7ZqKq7$_wFq((Cn\r\u001d.*_gB1\u0017$_wF";
      k[7] = "\u0002CEkQ\u0005\r\u0003\b`[\u0018\b^\u0003&S\u0005\u0005X\u0007m\u0010桻伴另厠佝栯厡厪佸伾";
      k[8] = void.class;
      l[8] = "java/lang/Void";
      k[9] = "m[/l^\u000fm[80R\u0000w\u0010(-F\bgMu\u0011\\\u0013mZ\u001e4V\bwM";
      k[10] = "\u000bz+~n/\u000bz<\"b \u00111,?v(\u0001lq\u0003l3\u000b{\u001a&f(\u0011";
      k[11] = "\u00144E$|.\u001f;Tk\u001d \u00140P1";
      k[12] = "P}6O8!\b87>伊案厩桝佑栧厔厒伷伙\f\u0004nk\u001b+|\\+j";
      k[13] = ")P\u0007/uwq\u0015\u0006^栃佚栊厪栤伃叙叄叐伴=gse}\u000bO/bk#";
      k[14] = "\u0007@\u0001\u001eW#_\u0005\u0000o佥厐你厺栢伲校伎栤伤;V@6\u0006\u001b\u0000\u0002E7\u0001";
      k[15] = "vi\u0013gf\u000f9uPc\u001c\u001c\u001f3\u0012>&I\u001f\n\u0017`-\r,aOlr\t";
      k[16] = "\u0005\u0005eC9pB\u0012:_H体叻桳佗格压反叻伷栓%uaW\f{[2v\b\u0010";
      k[17] = "\u0015)rcd\u0015Mls\u0012栒桼佲位压栋佖厦栶栉H.m\u0007Nb,#a\u001b\u0015";
      k[18] = "\u000bV\u0007\nxPS\u0013\u0006{佊根史厬叾厸叔口佬伲=BoE\n\r\u0006\u0016jD\r";
      k[19] = "SOz<|\b\u000b\n{MVxP\u000e%vqC\u0004\u000b$q\u0013";
      k[20] = "N\\\u0012~L\u001c\u0016\u0019\u0013\u000f栺桵伩伸叫双栺桵厷桼(3E\u000e\u0015\u0017L>I\u0012N";
      k[21] = "\nc8A-]R&90+-\n7y\u000b?\u0014^%f\bB\u0017]!9M{CO>:0";
      k[22] = "L*0>B8\u0014o1OhHOkotOs\u001bnns-u\u000fm:#G7\u0014z3O";
      k[23] = "i59J'f1p8;伕栏桊佑佞司桑佋桊叏\u0003\u00006wnkmV4/.";
      k[24] = "/tqE\u0014qw1p4\u0002\u0001,5.\u000f\u0019:x0/\b{";
      k[25] = "\"O[0P z\nZA佢桉栁桯桸厂佢伍叛伫azQ`|\u0006\u0006>_nq";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   public void p(String message) {
      q();
      if (this.树树何何友树何友树树.P().get() && this.树树何何友树何友树树.getValue()) {
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = k[var4];
      if (var5 instanceof String) {
         String var6 = l[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         k[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = k[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static boolean q() {
      M();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   @Override
   public void M() {
      M();
      if (!this.Q(new Object[]{52406761729175L})) {
         if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
            this.何树友友友友友友何何 = false;
            this.何友何友树何树何树何 = false;
            this.树何树友树何友友友何 = mc.player.getY();
         }
      }
   }

   @EventTarget
   public void M(WorldEvent event) {
      M();
      if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
         this.I();
      }
   }

   public static void M(boolean var0) {
      友树友友树树何树树友 = var0;
   }

   public static boolean M() {
      return 友树友友树树何树树友;
   }

   private static String HE_WEI_LIN() {
      return "何建国230622195906030014";
   }

   private record 友友何何树树何友树树(Packet<?> 何树何友友友友何树何, long 何树树何友友树友树树) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[6];
      private static final String[] c = new String[6];
      private static String HE_DA_WEI;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-6010052437022492740L, -3592932942463728554L, MethodHandles.lookup().lookupClass()).a(110077567407170L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      public long b() {
         return this.何树树何友友树友树树;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public Packet<?> c() {
         return this.何树何友友友友何树何;
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树何友树友友何何何$友友何何树树何友树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 162 && var8 != 196 && var8 != 234 && var8 != 222) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'P') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 226) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 162) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 196) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 234) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 61;
                  case 1 -> 36;
                  case 2 -> 17;
                  case 3 -> 55;
                  case 4 -> 54;
                  case 5 -> 33;
                  case 6 -> 30;
                  case 7 -> 58;
                  case 8 -> 41;
                  case 9 -> 39;
                  case 10 -> 43;
                  case 11 -> 20;
                  case 12 -> 53;
                  case 13 -> 26;
                  case 14 -> 45;
                  case 15 -> 60;
                  case 16 -> 50;
                  case 17 -> 57;
                  case 18 -> 42;
                  case 19 -> 5;
                  case 20 -> 59;
                  case 21 -> 6;
                  case 22 -> 56;
                  case 23 -> 31;
                  case 24 -> 22;
                  case 25 -> 8;
                  case 26 -> 4;
                  case 27 -> 46;
                  case 28 -> 14;
                  case 29 -> 48;
                  case 30 -> 52;
                  case 31 -> 16;
                  case 32 -> 12;
                  case 33 -> 2;
                  case 34 -> 62;
                  case 35 -> 32;
                  case 36 -> 19;
                  case 37 -> 0;
                  case 38 -> 24;
                  case 39 -> 18;
                  case 40 -> 38;
                  case 41 -> 15;
                  case 42 -> 40;
                  case 43 -> 9;
                  case 44 -> 28;
                  case 45 -> 37;
                  case 46 -> 11;
                  case 47 -> 63;
                  case 48 -> 25;
                  case 49 -> 27;
                  case 50 -> 44;
                  case 51 -> 23;
                  case 52 -> 1;
                  case 53 -> 35;
                  case 54 -> 7;
                  case 55 -> 47;
                  case 56 -> 51;
                  case 57 -> 34;
                  case 58 -> 49;
                  case 59 -> 10;
                  case 60 -> 29;
                  case 61 -> 3;
                  case 62 -> 13;
                  default -> 21;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\u0017P#\u0013Gl\u0018\u0010n\u0018Mq\u001dMe^El\u0010Ka\u0015\u0006j\u0019Na^El\u0002[`\u0015FwZ栯栜伥口栒县叵佘伥佽'县叵佘伥根栒伡叵栜桡";
         b[1] = long.class;
         c[1] = "java/lang/Long";
         b[2] = "i;R\u0011P:i;EM\\5spHZI$h,M\u0011M!h*I\\R?)\u000eG\\V6s";
         b[3] = "'\u0002w{tA,\rf4\u0015O'\u0006bn";
         b[4] = ":0,\u007f\u0001 a5.\u001a伦栀伅双厒叙厸佄桁佒Q#\u001d|?`;`\u0002ag";
         b[5] = "5\u0012-S\u000bUn\u0017/6伬桵桎佰厓叵桨厯桎栴P\u000fO\u00111I5F\u0014\u001e<";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String HE_WEI_LIN() {
         return "何炜霖国企上班";
      }
   }
}
