package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.player.友友何树树友友树树树;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.UpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;

public class 友树树树何何友树树树 extends Module implements 何树友 {
   public ModeValue 友树何何树友树友何树 = new ModeValue("Mode", new String[]{"Normal", "Grim"}, "Normal");
   public NumberValue 何友树树友友何友何树;
   public NumberValue 树何友树树何树树树何;
   public NumberValue 何友何树树树友友树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[33];
   private static final String[] k = new String[33];
   private static int _何炜霖国企变私企 _;

   public 友树树树何何友树树树() {
      super("NoWeb", "没有蜘蛛网减速", 树何友友何树友友何何.何友树何树友友友何树);
      树树何友树友友何何何.q();
      this.何友树树友友何友何树 = new NumberValue("Move Speed", 0.5, 0.1, 1, 0.1).A(() -> this.友树何何树友树友何树.K("Normal"));
      this.树何友树树何树树树何 = new NumberValue("Up Speed", 0.5, 0.1, 1, 0.1).A(() -> this.友树何何树友树友何树.K("Normal"));
      this.何友何树树树友友树何 = new NumberValue("Down Speed", 0.5, 0.1, 0.5, 0.1).A(() -> this.友树何何树友树友何树.K("Normal"));
      if (Module.Z() == null) {
         树树何友树友友何何何.M(false);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8891283778396047314L, -3317521724783974582L, MethodHandles.lookup().lookupClass()).a(56067205558096L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(86072751170102L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[10];
      int var7 = 0;
      String var6 = "é/\u008c\u0087\u001f¨DÓç\u0014ùq;^¶ÿ\u0010*&\u009c{¯#D´\u008br¹T·Í%Î\u0010î\u008b\u0007NGj\u0097\n5[¢\u0019«\u0085\u0010Ã æé}\u009b\u000b\u0005\u0087;@[\u009a\u0001\t\u0099\u0006Q¬HëY\u007fOK£*óøÆb\u001d\u0087(\u0018ËywÝ)2)\u001c{Çð\u0013\u009c0\u0003¤\bVê}ó³f%\u0010¬Íé\u0013µ8g\u0083ªi¢¤SýÚ \u0010öWJÑFÈ0·\u0080Âá\u0080\u0003eê@\u0010Í¡q*ºiÿåC²\u0014¨jOè/";
      short var8 = 159;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[10];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u009cx\\´½é\u0087ù >ÔÒ§-\tz,\u0002\u009cÏ\u008aiª5(5®#Ì¨Ù\u0011\u0080;\u0093@\u009a\fþÚ\u008a/\u00188ø\u0019\u000e[6ÎñSýÛ'Èà\u0087\u000b()uÛ´\u0010";
                  var8 = 65;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 21;
               case 1 -> 3;
               case 2 -> 12;
               case 3 -> 23;
               case 4 -> 61;
               case 5 -> 10;
               case 6 -> 11;
               case 7 -> 20;
               case 8 -> 57;
               case 9 -> 1;
               case 10 -> 9;
               case 11 -> 36;
               case 12 -> 39;
               case 13 -> 53;
               case 14 -> 49;
               case 15 -> 8;
               case 16 -> 32;
               case 17 -> 44;
               case 18 -> 35;
               case 19 -> 18;
               case 20 -> 17;
               case 21 -> 54;
               case 22 -> 58;
               case 23 -> 27;
               case 24 -> 47;
               case 25 -> 48;
               case 26 -> 40;
               case 27 -> 2;
               case 28 -> 52;
               case 29 -> 55;
               case 30 -> 13;
               case 31 -> 33;
               case 32 -> 30;
               case 33 -> 62;
               case 34 -> 5;
               case 35 -> 14;
               case 36 -> 38;
               case 37 -> 31;
               case 38 -> 6;
               case 39 -> 29;
               case 40 -> 46;
               case 41 -> 25;
               case 42 -> 41;
               case 43 -> 28;
               case 44 -> 43;
               case 45 -> 24;
               case 46 -> 60;
               case 47 -> 63;
               case 48 -> 37;
               case 49 -> 50;
               case 50 -> 45;
               case 51 -> 34;
               case 52 -> 42;
               case 53 -> 56;
               case 54 -> 22;
               case 55 -> 51;
               case 56 -> 19;
               case 57 -> 15;
               case 58 -> 0;
               case 59 -> 16;
               case 60 -> 59;
               case 61 -> 7;
               case 62 -> 4;
               default -> 26;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友树树树何何友树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5708;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/友树树树何何友树树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'u' && var8 != 194 && var8 != 164 && var8 != 'd') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'k') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 198) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'u') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 164) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友树树树何何友树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      j[0] = "\u000eX\u000b}TQ\u000eX\u001c!X^\u0014\u0013\b<KT\u0004\u0013\u00136O]\f\u0013\u001d?V[\u000b\u0013=?V[\u000bN";
      j[1] = "D\u0005U?0\u001cD\u0005Bc<\u0013^NV~/\u0019NNMt+\u0010FNC}2\u0016ANc}2\u0016A";
      j[2] = "gM\u0015\u001cu5h\rX\u0017\u007f(mPSQw5`VW\u001a43iSWQw5rFV\u001at.*叨株桮栋伏佑叨株桮栋";
      j[3] = "\f\u0014PCA\u001e\u0003T\u001dHK\u0003\u0006\t\u0016\u000eX\u0010\u0003\u000f\u001b\u000eG\u001c\u001f\u0016Pn[\u001c\r\u001f\fvO\u001d\u001a\u001f";
      j[4] = "_K\u0018\u001a[d_K\u000fFWkE\u0000\u001b[DaU\u0000\u001c\\O~\u001fx\tW\u0005";
      j[5] = double.class;
      k[5] = "java/lang/Double";
      j[6] = "v\u000b\u000eNauv\u000b\u0019\u0012mzl@\u0019\feyv\u001aT/|hq\u0001\u0014\u0013";
      j[7] = "\u0007-\u0018U\u00184\u0007-\u000f\t\u0014;\u001df\u000f\u0017\u001c8\u0007<B0\u0010$$)\u001c\u000b\u001c3\u000e";
      j[8] = "3C(V8\u000b<\u0003e]2\u00169^n\u001b:\u000b4XjPy\r=]j\u001b:\u000b&HkP9\u0010~格栗你厜桵厛另体你伂";
      j[9] = boolean.class;
      k[9] = "java/lang/Boolean";
      j[10] = "wTn\u0006E%x\u0014#\rO8}I(K\\+xO%KC'dVn(E.ql!\t_/";
      j[11] = "\t\"\u001b;9F\t\"\fg5I\u0013i\fy=J\t3AX=A\u0002$\u001dt2[";
      j[12] = "\u0011'K\u0006&D\u001a(ZIZ]\u00152T\nmm\u0003%X\u0017|A\u0014(";
      j[13] = "1\u001a\u000eK\nB>ZC@\u0000_;\u0007H\u0006\bB6\u0001LMK格伇县叫佽桴另厙伡併";
      j[14] = void.class;
      k[14] = "java/lang/Void";
      j[15] = "8E\\S\u000387\u0005\u0011X\t%2X\u001a\u001e\u00018?^\u001eUB\u001a4O\u0007\\\t";
      j[16] = "9o\u001cS#\r\rL\u0013\u0013n\u0006\u0007Q\u0016Ne@\u000fL\u001bHa\u000bLn\u0010Yx\u0002\u0007\u0018";
      j[17] = "N71(\u001a\u0018E8 g{\u0016N3$=";
      j[18] = "V\u0004C@oWP\u001a\u0006xjkQF\u0001C?kl\u0006D\u0016>L\u0015\u0006FE";
      j[19] = "\rf\\J\u0000~V\u007f[L|但号标桺叩县但号佃桺*F|V/SA\u0012*M&";
      j[20] = "\u0006m Q!'^1:X\u001e&j`x\u0015!yjPyI.&L`zPcp";
      j[21] = "\u001b\rUu!\u0005\u0015M\u0006>]伹叩桬伱栝厞厧叩伨桵\u0004l\u001c\u0013\u0004\u0010eb\\@O";
      j[22] = "\u00024`=\u0019\u0007Zhz4&\u0006n98y\u0016Qn\t9%\u0016\u0006H9:<[P";
      j[23] = "a8sQ[\u0004c}bZ?\u0013\n7#\u000b\u000eE\n\u0006$\tD\u0003&7bRX\u0019";
      j[24] = "HuK|\"Q\u0013lLz^栭伬収桭栅伃栭桨栔伩\u001cdS\u0013<Dw0\u0005\b5";
      j[25] = "\u001e\u001c\u001fA\u0017GX\u0003L\u0015'=#Y@\u0019JIM\u001e\u0011\u0014Zx\u0012\u001a\u0011\u0014M\u0012\u0019\u000e\u001c\u001b'";
      j[26] = "\n\u00194\u0003j\u0002\u0005\u0010j\u0004\f1c\u00166\u001cs\u0000\u001b\u001f0@fc";
      j[27] = "\"k]\u0001I\u0007yrZ\u00075伿变低桻桸栬厡变栊伿a\u000f\u0005y\"R\n[Sb+";
      j[28] = "/6{\u001f0Yi)(K\u0000\u001f\u0012s$GmW|4uJ}f";
      j[29] = "H9\u001f=B!\u0013 \u0018;>厇桨伜佽桄叽桝厲伜根]\u00005H1YeG'\u0001}";
      j[30] = "C\u0010w%.xO\u0015j W\u007f$\u00183ai/$)6g=s\u0017P4\",x";
      j[31] = "@y\u001b\u0013d\b\u001b`\u001c\u0015\u0018\u0004y1Y\u001cu\u0012@9X\bvmI|K\u001egTA}_\u001d\u0018";
      j[32] = "t\u0014|V&\u0016vQm]B\u0001\u001f\u001b,\fr^\u001f*+\u000e9\u00113\u001bmU%\u000b";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @EventTarget
   public void t(UpdateEvent event) {
      树何树树何何树友何何.h(95256570475762L, 2)
         .forEach(
            (key, value) -> {
               树树何友树友友何何何.q();
               if (value == Blocks.COBWEB
                  && new AABB(key.getX(), key.getY(), key.getZ(), key.getX() + 1, key.getY() + 1, key.getZ() + 1).intersects(mc.player.getBoundingBox())) {
                  mc.player.setDeltaMovement(0.0, 0.0, 0.0);
                  String var10 = this.友树何何树友树友何树.getValue();
                  byte var11 = -1;
                  switch (var10.hashCode()) {
                     case -1955878649:
                        if (!var10.equals("Normal")) {
                           break;
                        }

                        var11 = 0;
                     case 2228079:
                        if (var10.equals("Grim")) {
                           var11 = 1;
                        }
                  }

                  switch (var11) {
                     case 0:
                        if (友友何树树友友树树树.I(112951582722913L)) {
                           友友何树树友友树树树.W(10156851673231L, this.何友树树友友何友何树.getValue().doubleValue());
                        }

                        if (mc.options.keyJump.isDown()) {
                           mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, this.树何友树树何树树树何.getValue().doubleValue(), mc.player.getDeltaMovement().z);
                           return;
                        }

                        if (!mc.options.keyShift.isDown()) {
                           break;
                        }

                        mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, this.何友何树树树友友树何.getValue().doubleValue(), mc.player.getDeltaMovement().z);
                     case 1:
                        if (友友何树树友友树树树.I(112951582722913L)) {
                           友友何树树友友树树树.W(10156851673231L, 0.6);
                        }

                        if (mc.options.keyJump.isDown()) {
                           mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, 0.6, mc.player.getDeltaMovement().z);
                           return;
                        }

                        if (mc.options.keyShift.isDown()) {
                           mc.player.setDeltaMovement(mc.player.getDeltaMovement().x, -0.6, mc.player.getDeltaMovement().z);
                        }
                  }
               }
            }
         );
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String HE_JIAN_GUO() {
      return "何大伟230622198107200054";
   }
}
