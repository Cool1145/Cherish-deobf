package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.combat.KillAura;
import cn.cool.cherish.module.impl.player.树友何何友何树何树友;
import cn.cool.cherish.utils.render.友友何何友友树何何友;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.move.JumpEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class 何树友树友友树何友树 extends Module implements 何树友 {
   public static 何树友树友友树何友树 树何何何何友何友何友;
   public final ModeValue 友何何何树树友何何何 = new ModeValue("Mode", "模式", new String[]{"Legit", "Watchdog"}, "Legit");
   private final NumberValue 友树友何树树友友何何;
   private final BooleanValue 树树树友友树何树友树;
   private final BooleanValue 树何何何何友何友友树;
   private final BooleanValue 树树树树树树友何友何;
   private final BooleanValue 友树友树树何何友树友;
   private boolean 友友友何何友友友何何;
   public boolean 友树树友树树何友何何;
   private int 树友友何友友树树何友;
   private boolean 友何何何友友何友友树;
   private boolean 树友何友何树树树何树;
   public static boolean 何树树友树何何友何树;
   public static boolean 树树树友友友友何何何;
   public float 树树友树树树树何树树;
   private int 树友友何友何何何友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[62];
   private static final String[] k = new String[62];
   private static String HE_SHU_YOU;

   public 何树友树友友树何友树() {
      super("TargetStrafe", "目标空中灵活", 树何友友何树友友何何.何友树何树友友友何树);
      树树何友树友友何何何.M();
      this.友树友何树树友友何何 = new NumberValue("Range", "距离", 2.0, 0.5, 6.0, 0.1);
      this.树树树友友树何树友树 = new BooleanValue("Circle", "圆圈", false).A(() -> this.友何何何树树友何何何.K(""));
      this.树何何何何友何友友树 = new BooleanValue("Auto Jump", "自动跳跃", false).A(() -> this.友何何何树树友何何何.K(""));
      this.树树树树树树友何友何 = new BooleanValue("Behind", "后退", false).A(() -> this.友何何何树树友何何何.K("Watchdog"));
      this.友树友树树何何友树友 = new BooleanValue("Hold Jump", "按住跳跃", false).A(() -> this.友何何何树树友何何何.K("Watchdog"));
      this.友友友何何友友友何何 = false;
      this.友树树友树树何友何何 = false;
      this.树友友何友友树树何友 = -1;
      this.友何何何友友何友友树 = false;
      this.树友何友何树树树何树 = false;
      this.树友友何友何何何友树 = 0;
      树何何何何友何友何友 = this;
      Module.V(new Module[2]);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5384191498570540026L, -6356658227168958089L, MethodHandles.lookup().lookupClass()).a(193219720939637L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(100201658190497L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[18];
      int var5 = 0;
      String var4 = "Oõyí.Sµ¯v\u0080\u0083[\u009bo\u000f\u001f#â0\u008cK9ùRp\fâþ\u0096 iÁ\u0010\u0085óA?î¼\u0091VU@x0z·ã\u0010\u0010M\u0006\u00ad\u0088Rj'Ùfv0ù¯\u001aÉ\u0092\u0010äÙt±ÂYU¤\u0089Jñ\u008d\u0093\u0088=s\u0010\u0001\u000b\u0089«\u001dC»\u0007æq[\u008bÍùv¹\u0010ª\u0006\u008eÝÂYÿ`Xù\u0088\u008e¡\u0096Ìó(!\u0097Tm\u0017|XÆ\u0006ïß\u0084½Ä/äf\u0006\u001eæ\u009f»\u0004£\u0091k7¦8Õ¾É\u0081\u008dG\u0094h\u0092°O\u0010ÕÞ@Ø{/\u0004÷\u009b0Zôÿ®ý\u0012 ¸µ½/{p¨#\töJWÈæf<¼\u001dº\u0017µ\u001ec¾\u0012/ü.¤Ã\u009bÄ \u0080¤Õ±\u0007¦a2,à\u008e\u0097¡i2¨!=AT\u0089\u001c\u0007eóÁ3¿\u0014a\rã\u0010¹w¿Ta\u0088¥N¸àCóY\u0083\u0099\u00ad\u0010Äo½b`Sô\u008c2\u0005fM5¢\u00036\u0010\u001cµ\u0005²{nSÖÞ\u0017'\u001fÏó²\u0014 dÇ3§ÛA\u0017\u0013á\u0010\u0088;\"ñî®\u0087â¯\u0007\u008d²Ò^ÝQ+\u0093¿x5[ Ò\u000e\u000b_pÜ\u001aÍ%\u0081\u008dx'8¡\u0007æô´ê|ãíÒ\u001at\u001f\u0087\u009bñ\u0089Ä\u0010Å®®\u0096ß¤ÍçâYÐñ\u0094\u0012,\u001a";
      short var6 = 375;
      char var3 = ' ';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = c(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     c = var7;
                     h = new String[18];
                     何树树友树何何友何树 = false;
                     树树树友友友友何何何 = false;
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "ZÌa\u0002q\u0080jv\u0001s-Ò\u009cÕ4\u0099Ñ\u0083Xv\u0015I\u007f/ ? ¬Ó\u009aAÚ\\åLN¢5\u0015;RÉì½k\u001cx'dn\u000eú\\ò¢(`";
                  var6 = 57;
                  var3 = 24;
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void C(LivingUpdateEvent event) {
      树树何友树友友何何何.M();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.X(this.友何何何树树友何何何.getValue());
         LivingEntity target = KillAura.instance.Y();
         if (this.友何何何树树友何何何.K("Legit")) {
            this.z(target);
         }

         if (this.友何何何树树友何何何.K("Watchdog")) {
            this.G(target);
         }
      }
   }

   private void I() {
      this.d();
      KeyMapping.set(mc.options.keyDown.getKey(), false);
      KeyMapping.set(mc.options.keyJump.getKey(), false);
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 11;
               case 1 -> 10;
               case 2 -> 53;
               case 3 -> 47;
               case 4 -> 37;
               case 5 -> 63;
               case 6 -> 61;
               case 7 -> 0;
               case 8 -> 16;
               case 9 -> 44;
               case 10 -> 12;
               case 11 -> 31;
               case 12 -> 48;
               case 13 -> 42;
               case 14 -> 18;
               case 15 -> 43;
               case 16 -> 46;
               case 17 -> 7;
               case 18 -> 57;
               case 19 -> 13;
               case 20 -> 60;
               case 21 -> 34;
               case 22 -> 35;
               case 23 -> 54;
               case 24 -> 51;
               case 25 -> 15;
               case 26 -> 28;
               case 27 -> 62;
               case 28 -> 41;
               case 29 -> 26;
               case 30 -> 27;
               case 31 -> 9;
               case 32 -> 49;
               case 33 -> 38;
               case 34 -> 50;
               case 35 -> 8;
               case 36 -> 30;
               case 37 -> 20;
               case 38 -> 5;
               case 39 -> 14;
               case 40 -> 36;
               case 41 -> 25;
               case 42 -> 32;
               case 43 -> 58;
               case 44 -> 22;
               case 45 -> 59;
               case 46 -> 4;
               case 47 -> 56;
               case 48 -> 33;
               case 49 -> 23;
               case 50 -> 39;
               case 51 -> 55;
               case 52 -> 29;
               case 53 -> 21;
               case 54 -> 2;
               case 55 -> 17;
               case 56 -> 3;
               case 57 -> 52;
               case 58 -> 45;
               case 59 -> 19;
               case 60 -> 6;
               case 61 -> 1;
               case 62 -> 24;
               default -> 40;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何树友树友友树何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 22184;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/何树友树友友树何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[)\u0004/Íß\u009c\u0080á\u0017Çc{\u008aýÅ©, ^î]Îù1ô\u001d, Å7¿\u0086K'\u00935, \u0082FÌÝ¿Ket, 7Úí@íLr¹, ÄÉöÿú5\u0089Å, Éë\u0002+ù¥_sL{T§\u0004Íb|ù4°È¨\u0091MH, ¡\u0088ex¾\u0084")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何树友树友友树何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 194 && var8 != 'e' && var8 != 'n' && var8 != 229) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 239) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 249) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 194) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'e') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'n') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   @Override
   public void h() {
      this.友树树友树树何友何何 = false;
      树树何友树友友何何何.q();
      何树树友树何何友何树 = false;
      this.I();
      if (树树树友友友友何何何) {
         mc.options.setCameraType(mc.options.getCameraType());
         树树树友友友友何何何 = false;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   @EventTarget
   public void l(JumpEvent event) {
      树树何友树友友何何何.M();
      if (this.友何何何树树友何何何.K("Watchdog") && 何树树友树何何友何树) {
         event.setRotationYaw(this.树树友树树树树何树树);
      }
   }

   private void d() {
      KeyMapping.set(mc.options.keyLeft.getKey(), false);
      KeyMapping.set(mc.options.keyRight.getKey(), false);
   }

   private static void a() {
      j[0] = "\u0002SXp\u001b-\r\u0013\u0015{\u00110\bN\u001e=\u0019-\u0005H\u001avZ+\fM\u001a=\u0019-\u0017X\u001bv\u001a6O佨桧变桥厉厪栬伣变桥";
      j[1] = "DlG\f\u0000\u000fK,\n\u0007\n\u0012Nq\u0001A\u0019\u0001Kw\fA\u0006\rWnG!\u001a\rEg\u001b9\u000e\fRg";
      j[2] = "\u0007Pablm\b\u0010,ifp\rM'/uc\bK*/jo\u0014RaClm\b[.oUc\bK*";
      j[3] = "$P'1b'+\u0010j:h:.Ma|`'#Ke7#!*Ne|n'*\\h&#\u0003.Re\u0013x:&";
      j[4] = "LY\u001cx\"sGV\r7^jHL\u0003tiZ^[\u000fixvIV";
      j[5] = "bI3QgE\u007f\\ks&HgZ";
      j[6] = int.class;
      k[6] = "java/lang/Integer";
      j[7] = boolean.class;
      k[7] = "java/lang/Boolean";
      j[8] = "3\u00001Q\u0010B<@|Z\u001a_9\u001dw\u001c\tL<\u001bz\u001c\u0016@ \u00021\u007f\u0010I58~^\nH";
      j[9] = "<`H\u001a?73 \u0005\u00115*6}\u000eW=7;{\n\u001c~12~\nW=7)k\u000b\u001c>,q栟桷伬厛桉厔叅伳伬伅";
      j[10] = float.class;
      k[10] = "java/lang/Float";
      j[11] = "Q\u0012\u00196L7^RT=F*[\u000f_{N7V\t[0\r桉佧厷叼伀栲厓叹伩佢";
      j[12] = "\u0011oyN\"U\u001e/4E(H\u001br?\u0003 U\u0016t;Hcw\u001de\"A(";
      j[13] = "mj\u0012a\u0006\u001cYI\u001d!K\u0017ST\u0018|@Q[I\u0015zD\u001a\u0018k\u001ek]\u0013S\u001d";
      j[14] = "g\u0017?G&^S40\u0007kUY)5Z`\u0013Q48\\dX\u0012\u00163M}QY`";
      j[15] = void.class;
      k[15] = "java/lang/Void";
      j[16] = "Aw\n\u0013\u001d\tAw\u001dO\u0011\u0006[<\u001dQ\u0019\u0005AfPr\u0000\u0014F}\u0010N";
      j[17] = "+cJ\u0006Y'+c]ZU(1(]D]++r\u0010cQ7\bgNX] \"";
      j[18] = "Pk\fHY\u0010Pk\u001b\u0014U\u001fJ \u001b\n]\u001cPzV+]\u0017[m\n\u0007R\r";
      j[19] = "w4y,=rw4np1}m\u007fnn9~w%#r<z`4\u007f,\u001ctz0aR<z`4\u007f";
      j[20] = "\n\u001ad\u0016\u00044\n\u001asJ\b;\u0010QsT\u00008\n\u000b>U\u001c1\u0010\u0016`T\b$\u0001\r>{\u00054\u0001\u0011dt\f+\u0001\u0013";
      j[21] = "}C\u0010vd\f}C\u0007*h\u0003g\b\u0011,`\t=t\u00056m\n~u\u000b-{\u0006v";
      j[22] = "\u001f \u0015]}4\u0010`XVw)\u0015=S\u0010\u007f4\u0018;W[<2\u0011>W\u0010b7\u001d7^L<桊厷伛佮叵佇桊伩桟台";
      j[23] = "x+jF?\u0007x+}\u001a3\bb`i\u0007 \u0002r`n\u0000+\u001d8\u0018{\u000ba";
      j[24] = double.class;
      k[24] = "java/lang/Double";
      j[25] = "C 0L>oH/!\u0003_aC$%Y";
      j[26] = ")T9m{\u001d&\u000f0\u0016取桭厁桶桄佋佈厷桛厬]/sI-\u0000aq$\u000f'";
      j[27] = "s$\\[9\u001a|\u007fU 厔桪栁叜校根伊厰佅佂8\u001do\u001ch @\u0010n\u000e}";
      j[28] = "BEUFI\u007fM\u001e\\=佺栏栰厽栨你佺叕佴桧1\u0000\u001fyYAI\r\u001ekL";
      j[29] = "cz\u0012[\r[\"$\u001f\f`Y?`\u0002Y\u0006S4\u001bDQ\fS4x\u0005\u000f\u0001\u0004";
      j[30] = "x\u0003%wv=wX,\f栁厗叐佥厂佑佅伉叐校A0{6q\u00031ru)n";
      j[31] = "[xsI%\u000b\u000b{qWF&k&cVz\u001e\u001as!W&t";
      j[32] = "\u0011P!\u0005z{\u001e\u000b(~}\u0012AS9@e|\u000bVz\u001f\u0014)B\u0017{\u000fzcGT$~";
      j[33] = "\u0001RR'DV[\bR8tA?\u000bT5\u0004\u0007G\u0006U'\u00118";
      j[34] = "[\\w\u001eu;T\u0007~e栂厑佭厤低桼栂桋佭桾\u0013X#=@XkU\"/U";
      j[35] = "]-\u0011r@sRv\u0018\t叭叙叵佋伨及叭叙佫佋u4\u0016uF)\r9\u0017gS";
      j[36] = "\u001d1\u0012\u0016\u001aSM2\u0010\byr-o\u0002\tEF\\:@\b\u0019,D/OL\u0012PI0\u001f\u0002y";
      j[37] = "\u0018!)U;\u0010\u0011+iBC栰厵厃栌只厀只厵桙佈)-HJ<m\u0010$B\n+";
      j[38] = "U\u0011Hz^\\YGV!>\u000bo\u001d\f,\u0002\\o!_s[[VOUm\\Z";
      j[39] = "D;\u0003};\"\u00112\u0003nG-yrA;wryC\u0010l+'P.\u00058=9";
      j[40] = "(_e1Vn.\u0014ew0x\u0013\u001d86\u0001)\u0013$5jRt\u007fTwdMk";
      j[41] = "t\rL`# {VE\u001b桔厊叜佫叫变桔桐佂叵('.+}\rXe 4b";
      j[42] = "0\u0013BEbW-\u0004\u001bK^\b\bND\u0015aW\b~\u0011Y8V-EBR.\u001b";
      j[43] = "p0v\b%8\u007fk\u007fs厈伌但佖发厰伖厒变栒\u0012Ns>k4jCr,~";
      j[44] = "@*Z]s;OqS&叞桋叨佌栧栿叞厑佶佌>\u001fw1R|XF|mU";
      j[45] = "\u00155M0\u0005'\u001anDK桲桗桧反只桒伶桗厽栗)r\rs\u0011a\u0015,Z5\u001b";
      j[46] = "20t\u0014:\bg9t\u0007F\u0007\u000fy6RvY\u000fHg\u0005*\r&%rQ<\u0013";
      j[47] = "\u0003JS9A\u001d\f\u0011ZB栶桭桱厲叴厁召伩伵伬7\u007f\u0017\u001b\u0018NOr\u0016\t\r";
      j[48] = "\u0015c\u001c49\u0015\u001b9K1R伨另框伭框厑厶另伂桩_bII4\u001b?l\u0013\u001e1";
      j[49] = "\u000bP\u001e\u001f|V\u0004\u000b\u0017d发佢伽伶档桽发佢伽伶zZ(\u000e\u000b\u000e\u0002\u0007h\u000f\f";
      j[50] = "4K}&Z\u0003aB}5&\f\t\u0002?`\u0016]\t3n7J\u0006 ^{c\\\u0018";
      j[51] = "\"\u001a,\"\u001cD?\ru, \u001b\u001aG*r\u0010L\u001aw\u007f>FE?L,5P\b";
      j[52] = "]{}\u001d\tj\u0007!}\u00029Ac\"{\u000fI;\u001b/z\u001d\\\u0004";
      j[53] = "Qcv:}\u001c\u0004jv)\u0001\u0013l*4|1@l\u001be+m\u0019Evp\u007f{\u0007";
      j[54] = "\u0011e\u00064Xk\u001e>\u000fO栯栛厹桇桻桖栯佟档桇bp\u0007;\u0015?\u0005$V|K";
      j[55] = "$EvPQ1+\u0000-W-!\u0018\u000er\u000e\u0013q\u0018?!NU13^tGU\"";
      j[56] = "Q%D\"u\u0004T{Kk\fj*\u0007}\u001f\f\u000e\t#Q+=\u000bW,\u0018";
      j[57] = "\u0007(<\u001awm\bs5a栀余伱低伅厢佄叇厯栊XX\u007f9\u0003|d\u0006(\u007f\t";
      j[58] = "\u0019B#|\u000b.\u0016\u0019*\u0007桼会伯伤会叄伸厄伯厺Gl^#\t\u0017.c\u0005*";
      j[59] = "_8ha)\u0014\n1hrU\u001bbq*'eKb@{p9\u0011K-n$/\u000f";
      j[60] = "\u001bqCLU;\u001d:C\n3- 3\u001eD\ry \n\u0012L\\3Hr\u001fMN&";
      j[61] = "\u0006\u0005\u0014\roo\t^\u001dv栘栟桴栧桩桯参佛厮佣pOg;\u0002QL\u00110}\b";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   @EventTarget
   public void m(Render3DEvent event) {
      if (!this.Q(new Object[]{52406761729175L})) {
         PoseStack poseStack = event.poseStack();
         LivingEntity target = KillAura.instance.Y();
         if (this.树树树友友树何树友树.getValue()) {
            友友何何友友树何何友.d(poseStack, target, 108860770950086L, this.友树友何树树友友何何.getValue().doubleValue(), 1, event.partialTick(), Color.WHITE, 2.0F);
         }
      }
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @EventTarget
   public void t(StrafeEvent event) {
      树树何友树友友何何何.q();
      if (this.友何何何树树友何何何.K("Watchdog") && 何树树友树何何友何树) {
         event.setRotationYaw(this.树树友树树树树何树树);
      }
   }

   public static float v(Player from, Vec3 pos) {
      return from.getYRot() + Mth.wrapDegrees((float)Math.toDegrees(Math.atan2(pos.z - from.getZ(), pos.x - from.getX())) - 90.0F - from.getYRot());
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void z(LivingEntity target) {
      树树何友树友友何何何.M();
      boolean canStrafe = !树友何何友何树何树友.树友友树友友友友树何.isEnabled() && KillAura.instance.isEnabled() && mc.options.keyUp.isDown();
      if (canStrafe) {
         if (this.树何何何何友何友友树.getValue()) {
            KeyMapping.set(mc.options.keyJump.getKey(), mc.player.onGround());
         }

         if (!this.友树树友树树何友何何) {
            this.树友友何友友树树何友 = -1;
            this.友树树友树树何友何何 = true;
         }

         if (mc.options.keyLeft.isDown()) {
            this.树友友何友友树树何友 = -1;
         }

         if (mc.options.keyRight.isDown()) {
            this.树友友何友友树树何友 = 1;
         }

         label44: {
            if (mc.player.distanceTo(target) < this.友树友何树树友友何何.getValue().doubleValue()) {
               if (this.友友友何何友友友何何) {
                  break label44;
               }

               KeyMapping.set(mc.options.keyDown.getKey(), true);
               this.友友友何何友友友何何 = true;
            }

            if (this.友友友何何友友友何何) {
               KeyMapping.set(mc.options.keyDown.getKey(), false);
               this.友友友何何友友友何何 = false;
            }
         }

         if (mc.player.horizontalCollision) {
            this.树友友何友友树树何友 *= -1;
            this.d();
         }

         if (this.树友友何友友树树何友 == -1) {
            KeyMapping.set(mc.options.keyLeft.getKey(), true);
            KeyMapping.set(mc.options.keyRight.getKey(), false);
         }

         KeyMapping.set(mc.options.keyRight.getKey(), true);
         KeyMapping.set(mc.options.keyLeft.getKey(), false);
      }

      if (this.友树树友树树何友何何) {
         this.友树树友树树何友何何 = false;
         this.友友友何何友友友何何 = false;
         this.I();
      }
   }

   @Override
   public void M() {
      this.树友友何友友树树何友 = -1;
      this.友树树友树树何友何何 = false;
      this.友友友何何友友友何何 = false;
      何树树友树何何友何树 = false;
      树树树友友友友何何何 = false;
      this.I();
   }

   private static String HE_DA_WEI() {
      return "何炜霖230622200409390090";
   }

   private void G(LivingEntity target) {
      树树何友树友友何何何.q();
      KillAura ka = (KillAura)Cherish.instance.getModuleManager().getModule(KillAura.class);
      树友何何友何树何树友 sca = (树友何何友何树何树友)Cherish.instance.getModuleManager().getModule(树友何何友何树何树友.class);
      if ((!this.友树友树树何何友树友.getValue() || mc.options.keyJump.isDown()) && !sca.isEnabled() && ka.isEnabled()) {
         何树树友树何何友何树 = false;
      } else {
         何树树友树何何友何树 = false;
      }
   }
}
