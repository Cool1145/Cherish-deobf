package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.树何何何树何友何树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;

public class 何树友何何何何何树何 extends Module implements 何树友 {
   public final BooleanValue 何友树何何何树何树何;
   private float 树友树友何何何何何何;
   private float 树树友友树友何友树树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[22];
   private static final String[] k = new String[22];
   private static int _刘凤楠230622109211173513 _;

   public 何树友何何何何何树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/movement/何树友何何何何何树何.a J
      // 03: ldc2_w 133750588051405
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 30952
      // 0c: ldc2_w 920897455345914170
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何树友何何何何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 22376
      // 19: ldc2_w 366089583919857337
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何树友何何何何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 7858347844396371455
      // 26: lload 1
      // 27: invokedynamic W (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/movement/何树友何何何何何树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/BooleanValue
      // 33: dup
      // 34: sipush 5205
      // 37: ldc2_w 4262172727350246789
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何树友何何何何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 2131
      // 44: ldc2_w 5393268574780563840
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic w (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何树友何何何何何树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: bipush 0
      // 4f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 52: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 55: putfield cn/cool/cherish/module/impl/movement/何树友何何何何何树何.何友树何何何树何树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 58: aload 0
      // 59: bipush 1
      // 5a: invokevirtual cn/cool/cherish/module/impl/movement/何树友何何何何何树何.y (Z)V
      // 5d: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-5198975818910715886L, -5505390085618244782L, MethodHandles.lookup().lookupClass()).a(85407328584456L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 80930179616168L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "JÍÄ[\u0095\u0081*\u0001\u0084!\u0081G\rÕ¶Ê\u0010Ö¶\u0083dÑxaùá%ªÇÐx\u008dÚ";
      byte var8 = 33;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[4];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "¾é\u0081òÞ\u008f Vn-Ãn¼~ç\u0099á@Ò\u0082ö\\Û\u0004\u0010Â\u008a\u0084\u0093|=(\u0002`=¥\u0094qTÔç";
                  var8 = 41;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 何树友何何何何何树何.a ^ 32872886581045L;
      c<"G">(c<"G">(mc, 6192976671901889272L, a), 6192929736143443752L, a)
         .setDown(c<"G">(c<"G">(mc, 6192976671901889272L, a), 6192929736143443752L, a).isDown());
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 9;
               case 1 -> 1;
               case 2 -> 31;
               case 3 -> 23;
               case 4 -> 25;
               case 5 -> 61;
               case 6 -> 41;
               case 7 -> 52;
               case 8 -> 21;
               case 9 -> 59;
               case 10 -> 20;
               case 11 -> 53;
               case 12 -> 62;
               case 13 -> 4;
               case 14 -> 46;
               case 15 -> 36;
               case 16 -> 38;
               case 17 -> 48;
               case 18 -> 58;
               case 19 -> 11;
               case 20 -> 6;
               case 21 -> 45;
               case 22 -> 63;
               case 23 -> 29;
               case 24 -> 37;
               case 25 -> 55;
               case 26 -> 5;
               case 27 -> 44;
               case 28 -> 8;
               case 29 -> 17;
               case 30 -> 10;
               case 31 -> 28;
               case 32 -> 27;
               case 33 -> 2;
               case 34 -> 43;
               case 35 -> 39;
               case 36 -> 34;
               case 37 -> 22;
               case 38 -> 32;
               case 39 -> 47;
               case 40 -> 60;
               case 41 -> 26;
               case 42 -> 24;
               case 43 -> 3;
               case 44 -> 51;
               case 45 -> 7;
               case 46 -> 16;
               case 47 -> 35;
               case 48 -> 42;
               case 49 -> 49;
               case 50 -> 50;
               case 51 -> 54;
               case 52 -> 0;
               case 53 -> 15;
               case 54 -> 19;
               case 55 -> 56;
               case 56 -> 13;
               case 57 -> 30;
               case 58 -> 18;
               case 59 -> 57;
               case 60 -> 14;
               case 61 -> 12;
               case 62 -> 40;
               default -> 33;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 17627;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/何树友何何何何何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何树友何何何何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   @EventTarget
   public void x(LivingUpdateEvent event) {
      long a = 何树友何何何何何树何.a ^ 65861948957084L;
      long ax = a ^ 90796760050743L;
      long axx = (a ^ 99825966687448L) >>> 32;
      int axxx = (int)((a ^ 99825966687448L) << 32 >>> 32);
      long axxxx = a ^ 106792977681636L;
      if (c<"G">(this, 240954153268134650L, a).getValue()) {
         RotationUtils.D(
            new Object[]{
               ax,
               new Rotation(
                  axxxx,
                  (float)Math.toDegrees(树何何何树何友何树何.J(c<"G">(this, 241048176502022388L, a), axx, axxx, c<"G">(this, 243145444563619271L, a))),
                  mc.player.getXRot()
               )
            }
         );
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何树友何何何何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'G' && var8 != 220 && var8 != 'W' && var8 != 219) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 241) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'O') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'G') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 220) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'W') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   @EventTarget
   public void l(StrafeEvent event) {
      long a = 何树友何何何何何树何.a ^ 23228270126105L;
      c<"O">(5105729704667580710L, a);
      if (c<"W">(5105596002665671928L, a) != null
         && c<"W">(5105596002665671928L, a).isEnabled()
         && !c<"G">(c<"W">(5105596002665671928L, a), 5105529539933877827L, a).getValue()) {
         KeyMapping.set(c<"G">(c<"G">(mc, 5106474760172085716L, a), 5106444316557476868L, a).getKey(), false);
      } else {
         KeyMapping.set(c<"G">(c<"G">(mc, 5106474760172085716L, a), 5106444316557476868L, a).getKey(), true);
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "tyvINE{9;BDX~d0\u0004LEsb4O\u000fCzg4\u0004LEar5OO^9佂桉叡佴使佂佂伍栻佴";
      j[1] = "9 1aP\u000f6`|jZ\u00123=w,I\u00016;z,V\r*\"1@P\u000f6+~li\u00016;z";
      j[2] = float.class;
      k[2] = "java/lang/Float";
      j[3] = "=t#)\u0011\u001a6{2fm\u00039a<%Z3/v08K\u001f8{";
      j[4] = "}A{l^7}Al0R8g\nl.Z;}P!\u000fZ0vG}#U*";
      j[5] = "4nlJTz4n{\u0016Xu.%{\bPv4\u007f6+Ig3dv\u0017";
      j[6] = "eVQ\u0019k,eVFEg#\u007f\u001dF[o eG\u000b|c<FRUGo+l";
      j[7] = "\u0011z7A\u0004\u0018\u001e:zJ\u000e\u0005\u001bgq\f\u0006\u0018\u0016auGE伢伧叟佌佷厠伢伧栅栈";
      j[8] = "9;m}\rX6{ v\u0007E3&+0\u000fX> /{L^7%/0\u000fX,0.{\fCt伀厈佋厩叼桋厞厈佋伷";
      j[9] = "\u0006i&H-.\rf7\u0007P6\u001ea>N";
      j[10] = "|\u0016-b+@sV`i!]v\u000bk/)@{\rodjFr\bo/4C~\u0001fsj佺佊厳佖及桕古叔伭佖";
      j[11] = "\u000ebT\u001e3f\u0005mEQRh\u000efA\u000b";
      j[12] = "Mzu[!\u0018Gw!\"伛厧栱佀众使桟伹栱佀J\u001b}ZJb.^#\rF";
      j[13] = "9=dsx\u000b300\n栆厴桅厙伆佗佂伪企伇[3~\u001df+ wgFd";
      j[14] = "a&/hG7d.t?v5\n/p<Gb\n\u001ev;\u001a'-dzf\u0012)";
      j[15] = "@\u0011AgsaEP\nu\u001e4-_\t! d-n\f!{6K\u0002\t) a";
      j[16] = "T%dFLm\u0019g(O 厗厪栆桍佰口厗伴栆厗-\u001dnYt8\u0014P,\u0015}";
      j[17] = "y\u0004u;b?$\u0004e&X叇厅叺佖伃伅叇伛叺栒^a?x[t:$a/W";
      j[18] = "-w#E\u0013@pw3X)桢发厉厞根栰伦栋厉伀 \u0016Fl/g\u001bKF|2";
      j[19] = "3UV\u0015~d9X\u0002l栀栁厕叱桰厯佄叛桏栫iUxrlC\u0012\u0011a)n";
      j[20] = "F\\T3\u0013?@\u000fK=y$xZ[kH&\u0011XJiAB";
      j[21] = "9)~bM\t3$*\u001bCufr!`\u0015\f!\"0u*O`.:$S\b0?/\u001b";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void r(MoveInputEvent event) {
      long a = 何树友何何何何何树何.a ^ 29476608109860L;
      c<"O">(1145671265807515675L, a);
      if (c<"G">(this, 1143962336917245506L, a).getValue()) {
         c<"Ü">(this, event.getForwardImpulse(), 1143985927001713740L, a);
         c<"Ü">(this, event.getLeftImpulse(), 1146151089879056767L, a);
      }
   }

   private static String HE_SHU_YOU() {
      return "刘凤楠230622109211173513";
   }
}
