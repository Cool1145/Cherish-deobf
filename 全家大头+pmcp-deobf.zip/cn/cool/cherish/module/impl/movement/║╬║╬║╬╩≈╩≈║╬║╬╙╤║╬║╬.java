package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.ui.何树树友何友友友何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.packet.BlinkUtils;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.player.树何何何树何友何树何;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import cn.lzq.injection.asm.invoked.player.UpdateEvent;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.PacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBlockEventPacket;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ServerboundAcceptTeleportationPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

public class 何何何树树何何友何何 extends Module implements 何树友 {
   private final ModeValue 友何友友何友何树何何;
   private final NumberValue 何友何树友友何树何友;
   public final BooleanValue 友树友何何何友友树树;
   public final BooleanValue 树树树何树树树友树何;
   private final LinkedList<Packet<PacketListener>> 友何何友友树友树树友;
   private final 树友树友友何何树何何 树友何树友友树何友何;
   private boolean 树树友友树树友何友何;
   private int 友友何友友树何友友树;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[33];
   private static final String[] k = new String[33];
   private static String HE_SHU_YOU;

   public 何何何树树何何友何何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/movement/何何何树树何何友何何.a J
      // 003: ldc2_w 112375286883975
      // 006: lxor
      // 007: lstore 1
      // 008: lload 1
      // 009: dup2
      // 00a: ldc2_w 128711005374150
      // 00d: lxor
      // 00e: lstore 3
      // 00f: pop2
      // 010: aload 0
      // 011: sipush 26581
      // 014: ldc2_w 7718408998190256411
      // 017: lload 1
      // 018: lxor
      // 019: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01e: sipush 23330
      // 021: ldc2_w 8815846154445467109
      // 024: lload 1
      // 025: lxor
      // 026: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02b: ldc2_w -1349325812853407285
      // 02e: lload 1
      // 02f: invokedynamic x (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 034: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 037: aload 0
      // 038: new cn/cool/cherish/value/impl/ModeValue
      // 03b: dup
      // 03c: sipush 2796
      // 03f: ldc2_w 9135828522045307944
      // 042: lload 1
      // 043: lxor
      // 044: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 049: sipush 4439
      // 04c: ldc2_w 3710108018561279898
      // 04f: lload 1
      // 050: lxor
      // 051: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 056: bipush 2
      // 057: anewarray 87
      // 05a: dup
      // 05b: bipush 0
      // 05c: sipush 4358
      // 05f: ldc2_w 5561965142988744650
      // 062: lload 1
      // 063: lxor
      // 064: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 069: aastore
      // 06a: dup
      // 06b: bipush 1
      // 06c: sipush 24949
      // 06f: ldc2_w 2105039895809726397
      // 072: lload 1
      // 073: lxor
      // 074: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 079: aastore
      // 07a: sipush 29282
      // 07d: ldc2_w 484238641953473705
      // 080: lload 1
      // 081: lxor
      // 082: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 087: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 08a: putfield cn/cool/cherish/module/impl/movement/何何何树树何何友何何.友何友友何友何树何何 Lcn/cool/cherish/value/impl/ModeValue;
      // 08d: aload 0
      // 08e: new cn/cool/cherish/value/impl/NumberValue
      // 091: dup
      // 092: sipush 1590
      // 095: ldc2_w 8678603228049731839
      // 098: lload 1
      // 099: lxor
      // 09a: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09f: sipush 8125
      // 0a2: ldc2_w 5662948488553523576
      // 0a5: lload 1
      // 0a6: lxor
      // 0a7: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ac: dconst_1
      // 0ad: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0b0: dconst_1
      // 0b1: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0b4: ldc2_w 5.0
      // 0b7: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0ba: ldc2_w 0.1
      // 0bd: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0c0: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0c3: putfield cn/cool/cherish/module/impl/movement/何何何树树何何友何何.何友何树友友何树何友 Lcn/cool/cherish/value/impl/NumberValue;
      // 0c6: aload 0
      // 0c7: new cn/cool/cherish/value/impl/BooleanValue
      // 0ca: dup
      // 0cb: sipush 17708
      // 0ce: ldc2_w 2900038806148133869
      // 0d1: lload 1
      // 0d2: lxor
      // 0d3: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0d8: sipush 31765
      // 0db: ldc2_w 8660996013636160218
      // 0de: lload 1
      // 0df: lxor
      // 0e0: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0e5: bipush 0
      // 0e6: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 0e9: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 0ec: putfield cn/cool/cherish/module/impl/movement/何何何树树何何友何何.友树友何何何友友树树 Lcn/cool/cherish/value/impl/BooleanValue;
      // 0ef: aload 0
      // 0f0: new cn/cool/cherish/value/impl/BooleanValue
      // 0f3: dup
      // 0f4: sipush 15249
      // 0f7: ldc2_w 1604761314069597531
      // 0fa: lload 1
      // 0fb: lxor
      // 0fc: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 101: sipush 29969
      // 104: ldc2_w 8627916419370255298
      // 107: lload 1
      // 108: lxor
      // 109: invokedynamic p (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 10e: bipush 0
      // 10f: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // 112: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // 115: putfield cn/cool/cherish/module/impl/movement/何何何树树何何友何何.树树树何树树树友树何 Lcn/cool/cherish/value/impl/BooleanValue;
      // 118: aload 0
      // 119: new java/util/LinkedList
      // 11c: dup
      // 11d: invokespecial java/util/LinkedList.<init> ()V
      // 120: putfield cn/cool/cherish/module/impl/movement/何何何树树何何友何何.友何何友友树友树树友 Ljava/util/LinkedList;
      // 123: aload 0
      // 124: new cn/cool/cherish/utils/树友树友友何何树何何
      // 127: dup
      // 128: lload 3
      // 129: invokespecial cn/cool/cherish/utils/树友树友友何何树何何.<init> (J)V
      // 12c: putfield cn/cool/cherish/module/impl/movement/何何何树树何何友何何.树友何树友友树何友何 Lcn/cool/cherish/utils/树友树友友何何树何何;
      // 12f: aload 0
      // 130: bipush 0
      // 131: ldc2_w -1349747516931116604
      // 134: lload 1
      // 135: invokedynamic w (Ljava/lang/Object;IJJ)V bsm=cn/cool/cherish/module/impl/movement/何何何树树何何友何何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 13a: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8807484206331450826L, 6482111118317866746L, MethodHandles.lookup().lookupClass()).a(233490037064093L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 110222039522096L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[18];
      int var7 = 0;
      String var6 = "{Kì\u0099®\u0092(-5Î\u009eHQÿã\u009d×ÙpZÄ\u000fÖá½+<KÁòÐý\u0010Ox8×#Ò\u001c\u0098\n¡pY'Énâ\u0018L+Y[æ1å\u0097<ß¸mXÅÎ\u0016W)WT\nYÑ\u0004\u0010·Ú¨s\u008fÐ©½;(\u008f´¦æ|E\u0010|¼Xïë¬&æ\u008d0jTÍ²Ët\u0010ÊÂ\u0081P\u008d×ÕxAZ\u0091ØG½Yl\u0010´cY\u008aÓ¼7H\u00843\u00ad\u0089gwþ=\u0010p\u008f\u0010¶¹Î\u0016ÜAFÒ¬÷ô\u0014\u0012\u0010í\u0011}å\u009fâ¤ßQ\u0099\u0015ò¾¿øó\u0010Îÿ+/\u0088ÄµF\u0014µ\u0002\u0082)\u0097]\u0085\u0010à>Lk>¾U[#ÃÑ4Ì¿[.\u0010\u0010flJ9\b~\u0000[9\u0015n\u0013¾yç\u0018òAI¡\u0085O\u0085U;Y²<ä0óþ!\u0004î¯¥½w§\u0010[sÐ»ôÍ'ÔÎáë\u009aP=T4\u0010\u008e\u0081E\u001dO×%\u001c L´-øãî<\u0010\rF\f(9~ûHZ¦³bµã\u0084Ø";
      short var8 = 303;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[18];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "Ý©\u0087Æå>J<\"ê¼-P¸¼¡ÝÏä8ã\u0096^\u008a\u0018¾r-\b\u001bô\"vÚü\u009dzRfLº§LßÊatS\r";
                  var8 = 49;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   public void F() {
      long a = 何何何树树何何友何何.a ^ 65602375245364L;
      long ax = a ^ 48869803994330L;
      long axx = a ^ 32995681248869L;
      c<"B">(6194116797625225301L, a);
      if (!this.w(new Object[]{ax})) {
         c<"w">(this, 0, 6194673071854537079L, a);
         c<"í">(this, 6193864805340682077L, a).U(axx);
         WrapperUtils.D(new Object[]{1.0F});
         if (c<"í">(this, 6194469253333329819L, a).C(b<"p">(21244, 2326315696045628559L ^ a))) {
            c<"í">(this, 6193835489474648843L, a).forEach(packet -> {
               try {
                  packet.handle(mc.getConnection().getConnection().getPacketListener());
               } catch (Exception var1x) {
               }
            });
            c<"í">(this, 6193835489474648843L, a).clear();
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 28;
               case 1 -> 35;
               case 2 -> 23;
               case 3 -> 24;
               case 4 -> 63;
               case 5 -> 53;
               case 6 -> 7;
               case 7 -> 2;
               case 8 -> 21;
               case 9 -> 6;
               case 10 -> 22;
               case 11 -> 59;
               case 12 -> 9;
               case 13 -> 42;
               case 14 -> 8;
               case 15 -> 60;
               case 16 -> 48;
               case 17 -> 12;
               case 18 -> 11;
               case 19 -> 14;
               case 20 -> 50;
               case 21 -> 46;
               case 22 -> 43;
               case 23 -> 37;
               case 24 -> 54;
               case 25 -> 32;
               case 26 -> 17;
               case 27 -> 0;
               case 28 -> 33;
               case 29 -> 56;
               case 30 -> 34;
               case 31 -> 39;
               case 32 -> 40;
               case 33 -> 4;
               case 34 -> 55;
               case 35 -> 31;
               case 36 -> 26;
               case 37 -> 51;
               case 38 -> 19;
               case 39 -> 18;
               case 40 -> 57;
               case 41 -> 15;
               case 42 -> 58;
               case 43 -> 5;
               case 44 -> 16;
               case 45 -> 30;
               case 46 -> 36;
               case 47 -> 61;
               case 48 -> 49;
               case 49 -> 1;
               case 50 -> 38;
               case 51 -> 27;
               case 52 -> 62;
               case 53 -> 41;
               case 54 -> 10;
               case 55 -> 20;
               case 56 -> 3;
               case 57 -> 45;
               case 58 -> 52;
               case 59 -> 13;
               case 60 -> 29;
               case 61 -> 44;
               case 62 -> 25;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7042;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/何何何树树何何友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何何何树树何何友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 237 && var8 != 'w' && var8 != 'x' && var8 != 241) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 200) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'B') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 237) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'w') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'x') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何何何树树何何友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @EventTarget
   public void f(MotionEvent event) {
      long a = 何何何树树何何友何何.a ^ 136316382482089L;
      long ax = a ^ 118897521294407L;
      long axx = a ^ 108681909808295L;
      c<"B">(-8833621311420858168L, a);
      if (!this.w(new Object[]{ax})) {
         if (event.isPost()
            && c<"í">(this, -8833128251283409146L, a).C(b<"p">(21244, 2326385856144526354L ^ a))
            && c<"í">(this, -8832690094548755296L, a).getValue()
            && c<"í">(mc.player, -8832784882955344495L, a) % 20 == 0
            && c<"í">(this, -8833128251283409146L, a).C(b<"p">(21244, 2326385856144526354L ^ a))) {
            ClientUtils.e(new Object[]{b<"p">(16417, 686509222307126988L ^ a) + c<"í">(this, -8833065174092310038L, a), axx});
         }
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   @EventTarget
   public void a(Render2DEvent event) {
      long a = 何何何树树何何友何何.a ^ 67182405563094L;
      long ax = a ^ 47013825626168L;
      c<"B">(-5109357034590585673L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"í">(this, -5110131715734647943L, a).C(b<"p">(21244, 2326317552023236717L ^ a))) {
            int y = mc.getWindow().getGuiScaledHeight() / 2 + 10;
            event.poseStack().pushPose();
            String var8 = c<"í">(HUD.instance, -5109991317278717088L, a).getValue();
            byte var9 = -1;
            switch (var8.hashCode()) {
               case -1818419758:
                  if (!var8.equals(b<"p">(14620, 57522550300351375L ^ a))) {
                     break;
                  }

                  var9 = 0;
               case -1984932033:
                  if (var8.equals(b<"p">(13, 2619475687755129498L ^ a))) {
                     var9 = 1;
                  }
            }

            switch (var9) {
               case 0:
                  何树树友何友友友何何.P(
                     event.poseStack(),
                     b<"p">(28906, 68482390234780265L ^ a),
                     c<"í">(this, -5109930920870173291L, a) / 5000.0F,
                     c<"í">(this, -5109930920870173291L, a),
                     y
                  );
               case 1:
                  何树树友何友友友何何.F(event.poseStack(), c<"í">(this, -5109930920870173291L, a) / 5000.0F, y);
               default:
                  event.poseStack().popPose();
            }
         }
      }
   }

   private static void a() {
      j[0] = "p\u0007?\u0014\u001d3\u007fGr\u001f\u0017.z\u001ayY\u001f3w\u001c}\u0012\\5~\u0019}Y\u001f3e\f|\u0012\u001c(=似佄伢档桍但似叚伢伧";
      j[1] = "0R(:tQ?\u0012e1~L:Onwm_?IcwrS#P(\u0014tZ6jg5n[";
      j[2] = "b[*y9)iT;6R=k_,l~*f";
      j[3] = "r\u0018\u001c\u0012^Z}XQ\u0019TGx\u0005Z_\\Zu\u0003^\u0014\u001f\\|\u0006^_U\\b\u0006^\u0010H\u001bY#v";
      j[4] = int.class;
      k[4] = "java/lang/Integer";
      j[5] = "?\n\u001c\u001c V0JQ\u0017*K5\u0017ZQ\"V8\u0011^\u001aaP1\u0014^Q\"V*\u0001_\u001a!Mr伱叹伪厄史桍厯叹伪会";
      j[6] = "14\u000eh3::;\u001f'N\")<\u0016n";
      j[7] = "YX\btO\u0019V\u0018E\u007fE\u0004SEN9V\u0017VCC9I\u001bJZ\bUO\u0019VSGyv\u0017VCC";
      j[8] = "%J<E\u001b\u0004%J+\u0019\u0017\u000b?\u0001+\u0007\u001f\b%[f\u001b\u001a\f2J:E:\u0002(N$;\u001a\f2J:";
      j[9] = boolean.class;
      k[9] = "java/lang/Boolean";
      j[10] = "2{wP\u0018M=;:[\u0012P8f1\u001d\u0002V8y*\u001d桦叩桀叞厒佦伢栳伄佀";
      j[11] = "-\u0000\u001f\u001a`\u0015\"@R\u0011j\b'\u001dYWy\u001b\"\u001bTWf\u0017>\u0002\u001f7z\u0017,\u000bC/n\u0016;\u000b";
      j[12] = "0fi\u0013CI?&$\u0018IT:{/^YR:d4^\\G0c\"\u0004\u0002d?a)\u001byR:d4";
      j[13] = "#D\u000f!2(=L\u0015nP4'N\u001c$P4:Q";
      j[14] = "@|\u007f\u0019n\u0003O<2\u0012d\u001eJa9Td\u001aF|%Td\u001aF|%\t/)Uw?\u000e%?Jv4";
      j[15] = "%z,\"K2*:a)A//gjoI2\"an$\n伈伓叟佗伔可伈伓栅栓";
      j[16] = "\u007f)z\u0014n.t&k[\u000f \u007f-o\u0001";
      j[17] = "ls\u001fy`L7v\u000f!\u001a=\u001aH)\t\\7\u0011\u0013E pE&#\u001e%`\u001d";
      j[18] = "?\u00176\njLgI)w栞栺栗伭桎桮栞叠栗伭WJ?Iv\t9\u0015vZ?";
      j[19] = "\u0011y\u000b\u0005v?\u001dg\f[\u001c7{<E\\-f{\u0005O\tq2\u0011\u007f\b\u0006x5";
      j[20] = "\u0019I=wLIA\u0017\"\n叢佻叫叭企叉佼栿併佳\\w]\u001aIL3l\u0010A";
      j[21] = "$Q\u001e91o|\u000f\u0001D5\u0000,M@(.:xHA/\\9n\t\u00136fmk\b\u0014D";
      j[22] = "\u0015qju+\u0012U\u007f\u007frW桺召叒栖栆厔伾佲佌佒\u001f*\u001f\u0013pmp1RH";
      j[23] = "[ \u00072i?\u0003~\u0018O叇厓伷厄厥桖余厓厩桞ftn=\u0001z\u001c3a4\u0006";
      j[24] = "ju\u001c0?!2+\u0003M桋桗厘发桤桔厑伓厘住}s=/%c\u001f|27`";
      j[25] = "7\u0001B?\u001fa<XJ %Y\u0019gnAL<.B\b!Ge&]";
      j[26] = "\\\"V\"\u0000\u0005\u0004|I_估厩估桜叴厜估桳估历7oT\u0018\u0012=Ua\u000f\u0018\f";
      j[27] = "~\r91u\u000b&S&L叛伹伒厩厛桕叛桽桖厩X}w\u0015.S?\"vT2";
      j[28] = "F1\"{\u0007k\u001eo=\u0006桳叇伪桏厀叅桳余厴伋C9\b>J.~|Vt\f";
      j[29] = "\u001dB\u00053SX\u0005\u0002\n 1厡厷栧桸伄史厡伩栧厢YX\u001e\u0010T\u0003c@^\u001fG";
      j[30] = "49p\u000e{4lgos叕桂叆伃佌伮叕厘栜桇\u0011N.1}'\u007f\u0011g\"4";
      j[31] = "\b}8?\nx\u0002=: vt38c5\u0012+A|?<\u001c\u0012";
      j[32] = "RC\u0011\u0004\u0006a\tF\u0001\\|;\u0006B\u001d^\u001d7\r#ER\u001d/\u0013AJ]\u0005j";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void t() {
      long a = 何何何树树何何友何何.a ^ 138488190606803L;
      long ax = a ^ 116737586720573L;
      long axx = a ^ 97152478078338L;
      c<"B">(-7632851266605509710L, a);
      if (!this.w(new Object[]{ax})) {
         c<"w">(this, 0, -7633425407899039088L, a);
         c<"í">(this, -7632966507264355142L, a).U(axx);
         WrapperUtils.D(new Object[]{1.0F});
         if (c<"í">(this, -7632782358696851507L, a).Z()) {
            c<"w">(this, false, -7632624957576323817L, a);
         }
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void z(PacketEvent event) {
      long a = 何何何树树何何友何何.a ^ 131708397417291L;
      long ax = a ^ 105628768305573L;
      long axx = a ^ 2738911711013L;
      long axxx = a ^ 5788958714929L;
      long axxxx = a ^ 90579142970138L;
      long axxxxx = a ^ 24215550789944L;
      c<"B">(8685930801076075818L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"í">(this, 8685298072965286628L, a).C(b<"p">(21244, 2326381539137368560L ^ a))) {
            if (event.getPacket() instanceof ServerboundMovePlayerPacket movePacket) {
               try {
                  boolean hasRotation = movePacket.hasRotation();
                  if (!hasRotation && !树何何何树何友何树何.x(axx)) {
                     event.setCancelled(true);
                  }

                  if (!event.isCancelled() || c<"í">(c<"x">(8685474834498578575L, a), 8684474436145389720L, a)) {
                     BlinkUtils.M(new Object[]{axxxxx});
                     c<"w">(this, c<"í">(this, 8685379027972219912L, a) - 50, 8685379027972219912L, a);
                  }

                  c<"w">(this, c<"í">(this, 8685379027972219912L, a) + (int)c<"í">(this, 8685837684131248674L, a).p(axxx), 8685379027972219912L, a);
                  c<"í">(this, 8685837684131248674L, a).U(axxxx);
               } catch (Exception var18) {
               }
            }
         }
      }
   }

   @EventTarget
   public void r(LivingUpdateEvent event) {
      long a = 何何何树树何何友何何.a ^ 90132029708170L;
      long ax = a ^ 77108128146788L;
      c<"B">(-7184501189988083221L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"í">(this, -7185134059887268315L, a).C(b<"p">(21244, 2326339690983052593L ^ a))) {
            label25: {
               if (c<"í">(this, -7185057773996375863L, a) < 200) {
                  WrapperUtils.D(new Object[]{1.0F});
                  if (!c<"í">(this, -7184432246626677356L, a).Z() || !c<"í">(this, -7184837864611063986L, a)) {
                     break label25;
                  }

                  this.k();
               }

               WrapperUtils.D(new Object[]{c<"í">(this, -7184688535548631362L, a).getValue().floatValue()});
               if (c<"í">(this, -7184432246626677356L, a).getValue()) {
                  c<"w">(this, true, -7184837864611063986L, a);
               }
            }

            if (c<"í">(this, -7185057773996375863L, a) >= 5000.0F) {
               this.k();
            }
         }
      }
   }

   @EventTarget
   public void y(UpdateEvent event) {
      long a = 何何何树树何何友何何.a ^ 19218783420621L;
      long ax = a ^ 7296709636643L;
      c<"B">(-3815456289149104468L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"í">(this, -3815105066012722846L, a).C(b<"p">(29282, 484184463923454691L ^ a))) {
            WrapperUtils.D(new Object[]{c<"í">(this, -3815222523837926919L, a).getValue().floatValue()});
         }
      }
   }

   @EventTarget
   public void Q(WorldEvent event) {
      long a = 何何何树树何何友何何.a ^ 14073978345468L;
      long ax = a ^ 29774985667858L;
      long axx = a ^ 45511686172589L;
      c<"B">(6646709479310383517L, a);
      if (!this.w(new Object[]{ax})) {
         this.k();
         c<"í">(this, 6646521812620353173L, a).U(axx);
      }
   }

   @EventTarget
   public void K(PacketEvent event) {
      long a = 何何何树树何何友何何.a ^ 41518968450093L;
      long ax = a ^ 55090443902659L;
      long axx = a ^ 12801913288454L;
      c<"B">(2876940343908180556L, a);
      if (!this.w(new Object[]{ax})) {
         if (event.getSide() == c<"x">(2877057406765517138L, a) && c<"í">(this, 2877292872633898370L, a).C(b<"p">(21244, 2326291331450629782L ^ a))) {
            Packet<?> packet = event.getPacket();
            if (packet instanceof ClientboundBlockEventPacket) {
               event.setCancelled(true);
               PacketUtils.e(new Object[]{axx, new ServerboundAcceptTeleportationPacket(0)});
            }

            if (packet instanceof ClientboundSetEntityMotionPacket) {
               c<"í">(this, 2877222812760697106L, a).add(packet);
               event.setCancelled(true);
            }

            if (packet instanceof ClientboundExplodePacket) {
               c<"í">(this, 2877222812760697106L, a).add(packet);
               event.setCancelled(true);
            }

            if (packet instanceof ClientboundBlockUpdatePacket) {
               c<"í">(this, 2877222812760697106L, a).add(packet);
               event.setCancelled(true);
            }
         }

         this.T(c<"í">(this, 2877292872633898370L, a).getValue());
      }
   }

   private static String HE_DA_WEI() {
      return "刘凤楠230622109211173513";
   }
}
