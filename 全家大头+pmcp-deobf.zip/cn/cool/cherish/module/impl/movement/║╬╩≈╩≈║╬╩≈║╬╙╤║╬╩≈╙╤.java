package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.player.友友何树树友友树树树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.protocol.game.ClientboundContainerClosePacket;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import org.lwjgl.glfw.GLFW;

public class 何树树何树何友何树友 extends Module implements 何树友 {
   public static 何树树何树何友何树友 何何友树友树何友友友;
   final ModeValue 树何树友何何何友树树 = new ModeValue("Mode", "模式", new String[]{"Vanilla", "Grim", "Spoof"}, "Vanilla");
   private final BooleanValue 友何何树何树树树树友 = new BooleanValue("No Jump", "取消跳跃", false);
   private final BooleanValue 树树何友友树何友何友 = new BooleanValue("Can Sneak", "允许潜行", false);
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[29];
   private static final String[] k = new String[29];
   private static String HE_JIAN_GUO;

   public 何树树何树何友何树友() {
      super("InventoryMove", "背包移动", 树何友友何树友友何何.何友树何树友友友何树);
      何何友树友树何友友友 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3986715477557899799L, 1959445432895213944L, MethodHandles.lookup().lookupClass()).a(140901709497599L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(89858116626587L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[14];
      int var7 = 0;
      String var6 = "®üúÐ\u0086\u009b©Úx5Ñ=¾\u008a÷\u001c\u007f-Û-Ë\u000bó@¾i\u0004W\u001bè\u0019Ì\u0010Ã\u001fêyR\u0012\u0013_méÞÐq{¨ \u0018¤Mmûèö\u008c·.àW\u009e/x\u0016\"\u0007f´\u001cò¶<°\u0010\u008f\u001b®µxÍ´\u0091\u0013UÅ\u009d\u0088\u0004M:\u0010Õù.\u008b\u0095S²æx8\u0097Ñ·ö\u0007Á vJ\u0018\u0006m\u0000îÿ\u001b\u009c\u0015xÅ£¦þê?P\u0011O\réÀs\u0016\u0093\u0082ÜÙV:\u0010Z\u0084´\u0015Ø7Y\u0089Á\u0083!\u001c\u000381Ð\u0018²«\u000f¡zsíw¯\u00902ñt°2;³èþLZYâ\u008a\u0010ÞÊÍ§Ç\u0097\u0083\u009ay\u001bM±;Ý\u009ej\u0010\u0080\bö\b\u0012ã0\u001agÚ¦g\u000eúÜ\u00ad ú¯R\u001a~Íñ¡\u0089\u0007_\u001eyÔmR\u00915ZËH\u0094¤,\u008f·Q±´+ÏÔ\u0010(Å(w£\u0093xó\u0097ñ»®ø\u0004xZ";
      short var8 = 267;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[14];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u009b¶øÖì\u0086P·1j\u009fôñõgµ\u0088\u0015è\u009dÂ§Çxk\u0082d,\"uÎT\u0010\u0095ñ\u0012W~\u0095\b;¡y°\u0097\u008fïÎ\u000f";
                  var8 = 49;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void S(MoveInputEvent event) {
      树树何友树友友何何何.q();
      if (!this.Q(new Object[]{52406761729175L}) && mc.screen != null) {
         if (this.A(mc.options.keyUp)) {
            event.setForwardImpulse(1.0F);
         }

         if (this.A(mc.options.keyDown)) {
            event.setForwardImpulse(-1.0F);
         }

         if (this.A(mc.options.keyLeft)) {
            event.setLeftImpulse(1.0F);
         }

         if (this.A(mc.options.keyRight)) {
            event.setLeftImpulse(-1.0F);
         }

         if (!this.友何何树何树树树树友.getValue() && this.A(mc.options.keyJump)) {
            event.setKeyJump(true);
         }

         if (this.树树何友友树何友何友.getValue() && this.A(mc.options.keyShift)) {
            event.setKeyShift(true);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 2;
               case 1 -> 11;
               case 2 -> 40;
               case 3 -> 16;
               case 4 -> 62;
               case 5 -> 60;
               case 6 -> 1;
               case 7 -> 32;
               case 8 -> 14;
               case 9 -> 12;
               case 10 -> 48;
               case 11 -> 30;
               case 12 -> 24;
               case 13 -> 59;
               case 14 -> 45;
               case 15 -> 55;
               case 16 -> 21;
               case 17 -> 8;
               case 18 -> 50;
               case 19 -> 43;
               case 20 -> 51;
               case 21 -> 34;
               case 22 -> 63;
               case 23 -> 36;
               case 24 -> 26;
               case 25 -> 9;
               case 26 -> 20;
               case 27 -> 39;
               case 28 -> 5;
               case 29 -> 38;
               case 30 -> 37;
               case 31 -> 33;
               case 32 -> 6;
               case 33 -> 10;
               case 34 -> 31;
               case 35 -> 22;
               case 36 -> 56;
               case 37 -> 17;
               case 38 -> 53;
               case 39 -> 23;
               case 40 -> 42;
               case 41 -> 13;
               case 42 -> 54;
               case 43 -> 18;
               case 44 -> 41;
               case 45 -> 19;
               case 46 -> 4;
               case 47 -> 7;
               case 48 -> 46;
               case 49 -> 47;
               case 50 -> 29;
               case 51 -> 61;
               case 52 -> 58;
               case 53 -> 57;
               case 54 -> 35;
               case 55 -> 52;
               case 56 -> 15;
               case 57 -> 49;
               case 58 -> 0;
               case 59 -> 3;
               case 60 -> 25;
               case 61 -> 44;
               case 62 -> 27;
               default -> 28;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 1346;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/何树树何树何友何树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[«#n®9ÎfÖ\u0010î¥Í\u009dz#ð, Òs\týa°Þ\u0016, å\u0090Ê\u0083¨¹Âá, ZC¥0Ê¤\u0095¿, ù¤t\u00038Ùh\u00ad, ïP\u0081Q~ß6ÕCs·\u0090aâSì, >É")[var5]
            .getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何树树何树何友何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/何树树何树何友何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'n' && var8 != 's' && var8 != 239 && var8 != 'J') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'j') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'A') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'n') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 's') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "\u0010q\u001e\u0003r\n\u001f1S\bx\u0017\u001alXNp\n\u0017j\\\u00053\f\u001eo\\Np\n\u0005z]\u0005s\u0011]佊校桱佈桴伦叔佥桱取";
      j[1] = ".\u001d`<(9%\u0012qsT *\b\u007f0c\u0010<\u001fs-r<+\u0012";
      j[2] = "HC\u0010I\\8G\u0003]BV%B^V\u0004^8OXRO\u001d>F]R\u0004^8]HSO]#\u0005格栯使司框叠另佫使佦";
      j[3] = boolean.class;
      k[3] = "java/lang/Boolean";
      j[4] = "v\"\u0000XJ9ybMS@$|?F\u0015S7y9K\u0015L;e \u0000vJ2p\u001aOWP3";
      j[5] = "VE)YjzVE>\u0005fuL\u000e>\u001bnvVTs:n}]C/\u0016ag";
      j[6] = "d*R/\u0007ud*Es\u000bz~aEm\u0003yd;\bf\u001fu$<Es\u000fyd<\bR\tno*H";
      j[7] = "\n?Q\u00072r\u0005\u007f\u001c\f8o\u0000\"\u0017J8k\f?\u000bJ8k\f?\u000b\u0017sX\u001f4\u0011\u0010yN\u00005\u001a";
      j[8] = "\u0011\u007f\u0007= \r\u001e?J6*\u0010\u001bbAp\"\r\u0016dE;a桳伧叚叢伋桞厩厹佄佼";
      j[9] = "x}/\u0001\b\u0007x}8]\u0004\bb68C\f\u000bxlu`\u0015\u001a\u007fw5\\";
      j[10] = "|\u0014b8K\u000e|\u0014udG\u0001f_uzO\u0002|\u00058]C\u001e_\u0010ffO\tu";
      j[11] = "1\u001fQwzN>_\u001c|pS;\u0002\u0017:c@>\u0004\u001a:|L\"\u001dQVzN>\u0014\u001ezC@>\u0004\u001a";
      j[12] = "\"_37S;)P\"x25\"[&\"";
      j[13] = "\u0018hK\u007fv\u0012\f$\u000e\u0019z)D4\u0010&xSC1Nh\u0013\u0010\u0011;Lri\u0017\u0014e\u0002\u0019";
      j[14] = "nP(\u0002\u001cV.\u0011 \u0019n^\u0007P*C^\u0000\u0007a/D\bH5\u0001hB\b_";
      j[15] = "tQ|H\u0013p7\u0014\u007fJn伒厉桰佞核厭厌厉伴栚!Pw5\u0000~\u001e\u001326\u0002";
      j[16] = "Gk\u0004\u0003\u0017kS'Ae桫伍栻厘佡伸伯厓栻桂<^C2S!S\u0017\u0018(\u001a";
      j[17] = "nds=!\b.%{&S\u0000\u0007dq|cQ\u0007Ut{5\u0016553}5\u0001";
      j[18] = "Wx\u0016~R(\u00179\u001ee  >x\u0014?\u0011v>I\u00118F6\f)V>F!";
      j[19] = "\u000e\r\u0000_iVNL\bD\u001b^g\r\u0002\u001e+\rg<\u0007\u0019}HU\\@\u001f}_";
      j[20] = "\b\u0011N/Z%\u001c]\u000bI佢佃厮核厵桐佢叝厮叢v,\u000f&\u000bDM8Cc";
      j[21] = "\u0019\u0000qe\u0015`\rL4\u0003桩桂伡右厊栚伭厘伡右I3A9LU#j\u00164\u0017";
      j[22] = "zV9bw9.G|f\f~C\u000338=|9\u0005o\u007fc\u0007";
      j[23] = "\u001c\f\u0016X;q\\M\u0019\u001dGepEJ]y5ptMT\u007frU\u0012\r\u0015wi";
      j[24] = "/c`lgko\"o)\u001b\u007fC*<i+)C\u001b9?`.\u007f~|m\u007fm";
      j[25] = "Q\u000fb\u0018o\f\u0011Nj\u0003\u001d\u00048\u000f`Y-T8>e^{\u0012\n^\"X{\u0005";
      j[26] = "Y\u0018\u0001t\u0019l\u0005\u0006R1(R>;<pF7]GZ,Xd\u0018";
      j[27] = "\u00040qK&;DqyPT3m0s\ndlm\u0001v\r2%_a1\u000b22";
      j[28] = "\\fgN\u001bLH*\"(厽伪佤桏伂栱桧桮栠厕_\u0018O\u0015\t35A\u0018\u0018R";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void j(LivingUpdateEvent event) {
      树树何友树友友何何何.q();
      if (!this.Q(new Object[]{52406761729175L})) {
         if (this.树何树友何何何友树树.K("Grim") && mc.screen != null) {
            友友何树树友友树树树.L(49817048057184L);
         }

         this.X(this.树何树友何何何友树树.getValue());
      }
   }

   @EventTarget
   public void U(PacketEvent e) {
      树树何友树友友何何何.q();
      if (e.getSide() == Event.Side.PRE
         && this.树何树友何何何友树树.K("Spoof")
         && (e.getPacket() instanceof ClientboundOpenScreenPacket || e.getPacket() instanceof ClientboundContainerClosePacket)) {
         e.setCancelled(true);
      }
   }

   private boolean A(KeyMapping keyMapping) {
      树树何友树友友何何何.q();
      return GLFW.glfwGetKey(mc.getWindow().getWindow(), keyMapping.getKey().getValue()) == 1;
   }

   private static String HE_WEI_LIN() {
      return "我是何树友";
   }
}
