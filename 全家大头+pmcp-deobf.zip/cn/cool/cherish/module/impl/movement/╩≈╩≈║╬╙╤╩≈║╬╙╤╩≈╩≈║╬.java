package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.player.树何何何树何友何树何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.protocol.game.ClientboundContainerClosePacket;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import org.lwjgl.glfw.GLFW;

public class 树树何友树何友树树何 extends Module implements 何树友 {
   public static 树树何友树何友树树何 树友友何树友何友树树;
   final ModeValue 何树友树友友何何何何;
   private final BooleanValue 树何何树何树友树友友;
   private final BooleanValue 树友友友何树树树树友;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[29];
   private static final String[] k = new String[29];
   private static int _何炜霖国企上班 _;

   public 树树何友树何友树树何() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/module/impl/movement/树树何友树何友树树何.a J
      // 03: ldc2_w 45648844529225
      // 06: lxor
      // 07: lstore 1
      // 08: aload 0
      // 09: sipush 26410
      // 0c: ldc2_w 4397418256057938309
      // 0f: lload 1
      // 10: lxor
      // 11: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 16: sipush 7041
      // 19: ldc2_w 2892270207567875366
      // 1c: lload 1
      // 1d: lxor
      // 1e: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 23: ldc2_w 1970750463500444788
      // 26: lload 1
      // 27: invokedynamic K (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2c: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 2f: aload 0
      // 30: new cn/cool/cherish/value/impl/ModeValue
      // 33: dup
      // 34: sipush 8371
      // 37: ldc2_w 160722883437950489
      // 3a: lload 1
      // 3b: lxor
      // 3c: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 41: sipush 29388
      // 44: ldc2_w 1163399076904608873
      // 47: lload 1
      // 48: lxor
      // 49: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 4e: bipush 3
      // 4f: anewarray 75
      // 52: dup
      // 53: bipush 0
      // 54: sipush 30879
      // 57: ldc2_w 8095242139791797817
      // 5a: lload 1
      // 5b: lxor
      // 5c: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 61: aastore
      // 62: dup
      // 63: bipush 1
      // 64: sipush 3131
      // 67: ldc2_w 5917879743820159638
      // 6a: lload 1
      // 6b: lxor
      // 6c: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 71: aastore
      // 72: dup
      // 73: bipush 2
      // 74: sipush 26377
      // 77: ldc2_w 7157115207701737901
      // 7a: lload 1
      // 7b: lxor
      // 7c: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 81: aastore
      // 82: sipush 16240
      // 85: ldc2_w 8999089949835160018
      // 88: lload 1
      // 89: lxor
      // 8a: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 8f: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 92: putfield cn/cool/cherish/module/impl/movement/树树何友树何友树树何.何树友树友友何何何何 Lcn/cool/cherish/value/impl/ModeValue;
      // 95: aload 0
      // 96: new cn/cool/cherish/value/impl/BooleanValue
      // 99: dup
      // 9a: sipush 30780
      // 9d: ldc2_w 4965955017848663703
      // a0: lload 1
      // a1: lxor
      // a2: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // a7: sipush 5384
      // aa: ldc2_w 924674005652947883
      // ad: lload 1
      // ae: lxor
      // af: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // b4: bipush 0
      // b5: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // b8: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // bb: putfield cn/cool/cherish/module/impl/movement/树树何友树何友树树何.树何何树何树友树友友 Lcn/cool/cherish/value/impl/BooleanValue;
      // be: aload 0
      // bf: new cn/cool/cherish/value/impl/BooleanValue
      // c2: dup
      // c3: sipush 5324
      // c6: ldc2_w 7710031549123969634
      // c9: lload 1
      // ca: lxor
      // cb: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // d0: sipush 8873
      // d3: ldc2_w 456932707134731265
      // d6: lload 1
      // d7: lxor
      // d8: invokedynamic s (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // dd: bipush 0
      // de: invokestatic java/lang/Boolean.valueOf (Z)Ljava/lang/Boolean;
      // e1: invokespecial cn/cool/cherish/value/impl/BooleanValue.<init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V
      // e4: putfield cn/cool/cherish/module/impl/movement/树树何友树何友树树何.树友友友何树树树树友 Lcn/cool/cherish/value/impl/BooleanValue;
      // e7: aload 0
      // e8: ldc2_w 1971351954216838337
      // eb: lload 1
      // ec: invokedynamic Ê (Lcn/cool/cherish/module/impl/movement/树树何友树何友树树何;JJ)V bsm=cn/cool/cherish/module/impl/movement/树树何友树何友树树何.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // f1: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(4420083670119292521L, -3299112943713015276L, MethodHandles.lookup().lookupClass()).a(29060081481499L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 58862257074945L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[14];
      int var7 = 0;
      String var6 = "8zNï¬ÛNfCã%\u0017Ýµx§y\t~$\u001eÁJ\b íÇ\u0089Æ>Ô:;À\u0092\u0004L©vÝ\u001b:\u0089Sðkï\u008788~`\u0014v\u0018ê\u001d\u0010å_\u000e¼f¼~¬½¿¢\"Î\u0084¹×\u0010\u0010\u0016/\u0092Vð?\u0089i\u0082ÖÞv\u0013Mú\u0010ò\u0082í\u001cÓ¸FF\u0011T\u0013®XW>¡\u0010*îAêºßiV/\u009c.\u000fY&qº\u0018N!\u0093b¡`1)Ë«EÀI^7\u008b<P©áö \u0097\u0015\u0010«\u001díJMß©Á\u0012\u001bö±\u0099ÿ\u0019ð\u0010<ï~3\u007f\u0000à\u0000Í\u0082¤t\u0014Ff¤\u0018²\u0005\u000e\u0003hçWg¡. b\u009cýÖ\u0082Þpà©m\u0094\u0017\u0098\u0010JS÷Ä°´é²í\u008ct¹K\u0013Ft\u0010½8m§ê\t*ã\fífK¥Ñ\u0092\u008d";
      short var8 = 243;
      char var5 = 24;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[14];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "@Ðj\u0084Ó0\u0097K2KÀ²<·\u0018i \u0094]\u001d\u00936j4dyÖlNà\u0018Zù ²¸¨\u0088Õú(PB\u007f\u0092CÒw\u0012";
                  var8 = 49;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void B(LivingUpdateEvent event) {
      long a = 树树何友树何友树树何.a ^ 39742568737395L;
      long ax = a ^ 47223176910413L;
      long axx = a ^ 84429498198878L;
      c<"Ø">(-5808520511950935154L, a);
      if (!this.w(new Object[]{ax})) {
         if (c<"R">(this, -5809467305400534885L, a).C(b<"s">(27137, 8924960224714918039L ^ a)) && c<"R">(mc, -5809599965287134009L, a) != null) {
            树何何何树何友何树何.G(axx);
         }

         this.T(c<"R">(this, -5809467305400534885L, a).getValue());
      }
   }

   @EventTarget
   public void J(PacketEvent e) {
      long a = 树树何友树何友树树何.a ^ 25132720472797L;
      c<"Ø">(-4049352202126802144L, a);
      if (e.getSide() == c<"K">(-4050884930734524779L, a)
         && c<"R">(this, -4049137674042503115L, a).C(b<"s">(9273, 6785694351392517636L ^ a))
         && (e.getPacket() instanceof ClientboundOpenScreenPacket || e.getPacket() instanceof ClientboundContainerClosePacket)) {
         e.setCancelled(true);
      }
   }

   private boolean S(KeyMapping keyMapping) {
      long a = 树树何友树何友树树何.a ^ 64265755841371L;
      c<"Ø">(-3005058699507707226L, a);
      return GLFW.glfwGetKey(mc.getWindow().getWindow(), keyMapping.getKey().getValue()) == 1;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 49;
               case 1 -> 14;
               case 2 -> 53;
               case 3 -> 3;
               case 4 -> 25;
               case 5 -> 7;
               case 6 -> 17;
               case 7 -> 62;
               case 8 -> 61;
               case 9 -> 24;
               case 10 -> 40;
               case 11 -> 54;
               case 12 -> 43;
               case 13 -> 2;
               case 14 -> 32;
               case 15 -> 51;
               case 16 -> 23;
               case 17 -> 50;
               case 18 -> 26;
               case 19 -> 38;
               case 20 -> 15;
               case 21 -> 34;
               case 22 -> 58;
               case 23 -> 11;
               case 24 -> 52;
               case 25 -> 37;
               case 26 -> 13;
               case 27 -> 1;
               case 28 -> 30;
               case 29 -> 36;
               case 30 -> 41;
               case 31 -> 10;
               case 32 -> 5;
               case 33 -> 4;
               case 34 -> 47;
               case 35 -> 16;
               case 36 -> 55;
               case 37 -> 35;
               case 38 -> 59;
               case 39 -> 0;
               case 40 -> 57;
               case 41 -> 6;
               case 42 -> 31;
               case 43 -> 29;
               case 44 -> 33;
               case 45 -> 19;
               case 46 -> 39;
               case 47 -> 48;
               case 48 -> 21;
               case 49 -> 27;
               case 50 -> 45;
               case 51 -> 12;
               case 52 -> 18;
               case 53 -> 46;
               case 54 -> 22;
               case 55 -> 8;
               case 56 -> 28;
               case 57 -> 42;
               case 58 -> 56;
               case 59 -> 9;
               case 60 -> 44;
               case 61 -> 63;
               case 62 -> 60;
               default -> 20;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树何友树何友树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 19953;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树何友树何友树树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/树树何友树何友树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'R' && var8 != 'M' && var8 != 'K' && var8 != 202) {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'x') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 216) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'R') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'M') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'K') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "4rc\u0005iT;2.\u000ecI>o%HcM2r9HcM2r9\u0015(~!y#\u0012\"h>x(";
      j[1] = "-0]\u0010\u001e\u0013\"p\u0010\u001b\u0014\u000e'-\u001b]\u001c\u0013*+\u001f\u0016_\u0015#.\u001f]\u001c\u00138;\u001e\u0016\u001f\b`桏桢伦厺桭伛厕桢桢伤";
      j[2] = ">$Mm\u0004 5+\\\"x9:1RaO\t,&^|^%;+";
      j[3] = "7\u0014\"(qm8To#{p=\tdehc8\u000fiewo$\u0016\"\u0006qf1,m'kg";
      j[4] = " T\u0014N\u0006Y/\u0014YE\fD*IR\u0003\u0004Y'OVHG_.JV\u0003\u0004Y5_WH\u0007Bm佯叱佸厢叽桒叱叱佸似";
      j[5] = "\ts3;\u0011i\u0002|\"tlq\u0011{+=";
      j[6] = "Nb\u0003~6sNb\u0014\":|T)\u0014<2\u007fNsY\u001d2tEd\u00051=n";
      j[7] = "\u0018Ye(\u0012\u0018\u0018Yrt\u001e\u0017\u0002\u0012rj\u0016\u0014\u0018H?a\n\u0018XOrt\u001a\u0014\u0018O?U\u001c\u0003\u0013Y\u007f";
      j[8] = "')2& \f(i\u007f-*\u0011-4tk9\u0002(2yk&\u000e4+2\u0007 \f(\"}+\u0019\u0002(2y";
      j[9] = "\fMrP0j\fMe\f<e\u0016\u0006e\u00124f\f\\(1-w\u000bGh\r";
      j[10] = "01U7?\u001601Bk3\u0019*zBu;\u001a0 \u000fR7\u0006\u00135Qi;\u00119";
      j[11] = "\u00136iD!R\u001cv$O+O\u0019+/\t#R\u0014-+B`佨伥厓伒佲厅佨伥桉桖";
      j[12] = "l3\u0014Om1g<\u0005\u0000\f?l7\u0001Z";
      j[13] = "\u0000a\u0010.1$Xm\u0015\u001f\u0005\u0003)\n\rt$h\bwUx!";
      j[14] = "MH0x\" \n\fv\u0003桞伅佮桨佒栚厄桁台厲\u000f>$*S\u001bdny6T";
      j[15] = "S\u0018\u0002jA\u0017S\tG&x\u0013:Y\u0007nHC:h\u0002n\u0000\u001aW\u0003Y0\n\u001c";
      j[16] = "h-U\u0010j1/i\u0013kfI/f\u0004Seqh,U\u0019\u000fpdzR\u000177.+\u0018k";
      j[17] = "m_Z?Yc2NPw>c\u0006\u0003Rv\u00003\u00062U>\u00011hXU/D}";
      j[18] = "1FVu\u000fqv\u0002\u0010\u000e桳及厌伢桰反伷及桖桦ipS64\u001a\u00117\u0017p";
      j[19] = "2\u0018P\u0005\u0017qu\\\u0016~桫及厏叢伲桧桫栐桕叢oC\u0011{,K\u0004\u0013Lg+";
      j[20] = "\u001di\u0003Ce\u0003Bx\t\u000b\u0002\u0003v5\u000b\n2Uv\u0004\u000eC?\u0017\u0019z\t^cS";
      j[21] = "\u00102\u001fCaM\u0010#Z\u000fXIys\u001aGh\u0017yB\u001fG @\u0014)D\u0019*F";
      j[22] = "a\u0006+$D\b&Bm_佼桩叜栦受厜佼伭佂佢\u0014eM\u0010!Y{5\u001cH/";
      j[23] = "$C8]mU$R}\u0011TQM\u0002=Yd\u0000M38Y,X Xc\u0007&^";
      j[24] = "P%af\u0015RP4$*,V9ddb\u001d\u00009UabT_T>:<^Y";
      j[25] = "O\u001e\u0000l\u000b!O\u000fE 2%&_\u0005h\u0002z&n\u0000hJ,K\u0005[6@*";
      j[26] = "$c\u001fP&\u0016u$F\u0013G厷变栁桥佷厄厷但栁县*x\u000fxb\u001dH)H!!";
      j[27] = "0[Rh?MjL[.EA\n\u001dC`|\\7\u0019A.:'";
      j[28] = "2Y\u001f0\u001cE2HZ|%A[\u0018\u001a4\u0015\u0012[)\u001f4]H6BDjWN";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void u(MoveInputEvent event) {
      long a = 树树何友树何友树树何.a ^ 42394519010550L;
      long ax = a ^ 44362568335560L;
      c<"Ø">(8783989552862199051L, a);
      if (!this.w(new Object[]{ax}) && c<"R">(mc, 8783467567525108290L, a) != null) {
         if (this.S(c<"R">(c<"R">(mc, 8783238937831742324L, a), 8784000840720687562L, a))) {
            event.setForwardImpulse(1.0F);
         }

         if (this.S(c<"R">(c<"R">(mc, 8783238937831742324L, a), 8783641528586420786L, a))) {
            event.setForwardImpulse(-1.0F);
         }

         if (this.S(c<"R">(c<"R">(mc, 8783238937831742324L, a), 8783131026227801684L, a))) {
            event.setLeftImpulse(1.0F);
         }

         if (this.S(c<"R">(c<"R">(mc, 8783238937831742324L, a), 8783532601427444532L, a))) {
            event.setLeftImpulse(-1.0F);
         }

         if (!c<"R">(this, 8783039672460120886L, a).getValue() && this.S(c<"R">(c<"R">(mc, 8783238937831742324L, a), 8783838671284458881L, a))) {
            event.setKeyJump(true);
         }

         if (c<"R">(this, 8783365627556592365L, a).getValue() && this.S(c<"R">(c<"R">(mc, 8783238937831742324L, a), 8783740821632099105L, a))) {
            event.setKeyShift(true);
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
