package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.友树友友何友树友树友;
import cn.cool.cherish.utils.player.树何何何树何友何树何;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.lzq.injection.asm.invoked.player.UpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.phys.AABB;

public class 友何友友友友友友树树 extends Module implements 何树友 {
   public ModeValue 何友友树树树树树友树;
   public NumberValue 友友树树何何友树何友;
   public NumberValue 何友树树何何树树何树;
   public NumberValue 友树友树友树何友树何;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[33];
   private static final String[] k = new String[33];
   private static int _我是何树友 _;

   public 友何友友友友友友树树() {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: Constructor cn/cool/cherish/module/Module.<init>(Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V not found
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExprUtil.getSyntheticParametersMask(ExprUtil.java:49)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.appendParamList(InvocationExprent.java:959)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.InvocationExprent.toJava(InvocationExprent.java:904)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:200)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/module/impl/movement/友何友友友友友友树树.a J
      // 003: ldc2_w 127634543267178
      // 006: lxor
      // 007: lstore 1
      // 008: ldc2_w 9542488340079974
      // 00b: lload 1
      // 00c: invokedynamic Z (JJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 011: aload 0
      // 012: sipush 27284
      // 015: ldc2_w 1551078073277987277
      // 018: lload 1
      // 019: lxor
      // 01a: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01f: sipush 16711
      // 022: ldc2_w 7533787827866636824
      // 025: lload 1
      // 026: lxor
      // 027: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 02c: ldc2_w 9392718125014562
      // 02f: lload 1
      // 030: invokedynamic Ç (JJ)Lcn/cool/cherish/module/何何友何何友何何树树; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 035: invokespecial cn/cool/cherish/module/Module.<init> (Ljava/lang/String;Ljava/lang/String;Lcn/cool/cherish/module/何何友何何友何何树树;)V
      // 038: pop
      // 039: aload 0
      // 03a: new cn/cool/cherish/value/impl/ModeValue
      // 03d: dup
      // 03e: sipush 30642
      // 041: ldc2_w 3480195119597528302
      // 044: lload 1
      // 045: lxor
      // 046: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 04b: bipush 2
      // 04c: anewarray 72
      // 04f: dup
      // 050: bipush 0
      // 051: sipush 481
      // 054: ldc2_w 3609178728029016762
      // 057: lload 1
      // 058: lxor
      // 059: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 05e: aastore
      // 05f: dup
      // 060: bipush 1
      // 061: sipush 17821
      // 064: ldc2_w 8785003174286890695
      // 067: lload 1
      // 068: lxor
      // 069: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 06e: aastore
      // 06f: sipush 481
      // 072: ldc2_w 3609178728029016762
      // 075: lload 1
      // 076: lxor
      // 077: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 07c: invokespecial cn/cool/cherish/value/impl/ModeValue.<init> (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
      // 07f: ldc2_w 9889547046362757
      // 082: lload 1
      // 083: invokedynamic s (Ljava/lang/Object;Lcn/cool/cherish/value/impl/ModeValue;JJ)V bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 088: aload 0
      // 089: new cn/cool/cherish/value/impl/NumberValue
      // 08c: dup
      // 08d: sipush 9577
      // 090: ldc2_w 8258861586745947704
      // 093: lload 1
      // 094: lxor
      // 095: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 09a: ldc2_w 0.5
      // 09d: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0a0: ldc2_w 0.1
      // 0a3: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0a6: bipush 1
      // 0a7: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0aa: ldc2_w 0.1
      // 0ad: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0b0: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0b3: aload 0
      // 0b4: invokedynamic get (Lcn/cool/cherish/module/impl/movement/友何友友友友友友树树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/movement/友何友友友友友友树树.g ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 0b9: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0bc: checkcast cn/cool/cherish/value/impl/NumberValue
      // 0bf: ldc2_w 13087998671448167
      // 0c2: lload 1
      // 0c3: invokedynamic s (Ljava/lang/Object;Lcn/cool/cherish/value/impl/NumberValue;JJ)V bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0c8: aload 0
      // 0c9: new cn/cool/cherish/value/impl/NumberValue
      // 0cc: dup
      // 0cd: sipush 20164
      // 0d0: ldc2_w 8206524428585672090
      // 0d3: lload 1
      // 0d4: lxor
      // 0d5: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0da: ldc2_w 0.5
      // 0dd: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0e0: ldc2_w 0.1
      // 0e3: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0e6: bipush 1
      // 0e7: invokestatic java/lang/Integer.valueOf (I)Ljava/lang/Integer;
      // 0ea: ldc2_w 0.1
      // 0ed: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 0f0: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 0f3: aload 0
      // 0f4: invokedynamic get (Lcn/cool/cherish/module/impl/movement/友何友友友友友友树树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 0f9: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 0fc: checkcast cn/cool/cherish/value/impl/NumberValue
      // 0ff: ldc2_w 9436643015080672
      // 102: lload 1
      // 103: invokedynamic s (Ljava/lang/Object;Lcn/cool/cherish/value/impl/NumberValue;JJ)V bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 108: aload 0
      // 109: new cn/cool/cherish/value/impl/NumberValue
      // 10c: dup
      // 10d: sipush 24510
      // 110: ldc2_w 1128305284353297646
      // 113: lload 1
      // 114: lxor
      // 115: invokedynamic h (IJ)Ljava/lang/String; bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 11a: ldc2_w 0.5
      // 11d: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 120: ldc2_w 0.1
      // 123: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 126: ldc2_w 0.5
      // 129: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 12c: ldc2_w 0.1
      // 12f: invokestatic java/lang/Double.valueOf (D)Ljava/lang/Double;
      // 132: invokespecial cn/cool/cherish/value/impl/NumberValue.<init> (Ljava/lang/String;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V
      // 135: aload 0
      // 136: invokedynamic get (Lcn/cool/cherish/module/impl/movement/友何友友友友友友树树;)Ljava/util/function/Supplier; bsm=java/lang/invoke/LambdaMetafactory.metafactory (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[ ()Ljava/lang/Object;, cn/cool/cherish/module/impl/movement/友何友友友友友友树树.j ()Ljava/lang/Boolean;, ()Ljava/lang/Boolean; ]
      // 13b: invokevirtual cn/cool/cherish/value/impl/NumberValue.i (Ljava/util/function/Supplier;)Lcn/cool/cherish/value/树何何何友树树何友何;
      // 13e: checkcast cn/cool/cherish/value/impl/NumberValue
      // 141: ldc2_w 9962251371864642
      // 144: lload 1
      // 145: invokedynamic s (Ljava/lang/Object;Lcn/cool/cherish/value/impl/NumberValue;JJ)V bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 14a: ldc2_w 9851392276786068
      // 14d: lload 1
      // 14e: invokedynamic Z (JJ)Z bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 153: ifeq 161
      // 156: ldc "YBN9Zb"
      // 158: ldc2_w 9342878390689982
      // 15b: lload 1
      // 15c: invokedynamic Z (Ljava/lang/Object;JJ)V bsm=cn/cool/cherish/module/impl/movement/友何友友友友友友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 161: return
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-3236717027835407861L, 4597217623869414000L, MethodHandles.lookup().lookupClass()).a(200556480672557L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 126340343311540L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[10];
      int var7 = 0;
      String var6 = "Õ÷\u0018ÊT¥\u0002³&q8)q»\u0081ñ\u0010]\u0085Õá{ºûÁfî¹!sv\u0007\u000f\u0010pguÈå¡Fá#´nÓYàB÷\u0010\u001aÆ6Jôc\u0094\u0005Ê Pù\u0011\u009d\u0094,\u0010\u0019§¯Ñ[Eú¤qrOX ä\u0098¤\u0010ø½@ëÁ\f(\u0082\u0091wó\u0090`\t\u0018ÿ(y\u0099c[®cïg¾s\u008fú\u0091\u0096®¸Ü¦uÀþ\u0017x\r\u009aè\fk£\t\u008e¦ÃêN²¼ùR\u0006\u0018\u0005H\u0081îïP\u000fË\u0004Æ\u008bUT:;¢#0Þ¶\u0094\u0011}a";
      short var8 = 167;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[10];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "I5z\u008fcÛîê¶m\u008f4\u009cúuðíÕfÇ\u0085\u0005\u0019\u009a\u0018u¬\u009bÿ\u0080\u0004G¥®\u0006ÏÅ_\u0085\u0007\u0018ë·gã\u0093Â\u001d«";
                  var8 = 49;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 15;
               case 1 -> 7;
               case 2 -> 14;
               case 3 -> 57;
               case 4 -> 13;
               case 5 -> 26;
               case 6 -> 61;
               case 7 -> 37;
               case 8 -> 55;
               case 9 -> 16;
               case 10 -> 10;
               case 11 -> 29;
               case 12 -> 25;
               case 13 -> 50;
               case 14 -> 5;
               case 15 -> 17;
               case 16 -> 62;
               case 17 -> 44;
               case 18 -> 27;
               case 19 -> 18;
               case 20 -> 9;
               case 21 -> 45;
               case 22 -> 34;
               case 23 -> 40;
               case 24 -> 56;
               case 25 -> 3;
               case 26 -> 0;
               case 27 -> 8;
               case 28 -> 54;
               case 29 -> 11;
               case 30 -> 43;
               case 31 -> 46;
               case 32 -> 2;
               case 33 -> 1;
               case 34 -> 42;
               case 35 -> 4;
               case 36 -> 20;
               case 37 -> 48;
               case 38 -> 52;
               case 39 -> 60;
               case 40 -> 51;
               case 41 -> 24;
               case 42 -> 35;
               case 43 -> 36;
               case 44 -> 49;
               case 45 -> 39;
               case 46 -> 38;
               case 47 -> 63;
               case 48 -> 58;
               case 49 -> 53;
               case 50 -> 28;
               case 51 -> 30;
               case 52 -> 12;
               case 53 -> 22;
               case 54 -> 19;
               case 55 -> 6;
               case 56 -> 41;
               case 57 -> 33;
               case 58 -> 31;
               case 59 -> 47;
               case 60 -> 59;
               case 61 -> 21;
               case 62 -> 23;
               default -> 32;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21375;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何友友友友友友树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何友友友友友友树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何友友友友友友树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 206 && var8 != 's' && var8 != 199 && var8 != 'Y') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 213) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 206) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 's') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 199) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "dg\"E\\+k'oNV6nzd\b^+c|`C\u001d-jy`\b^+qlaC]0)参余叭司厏双参叇样栢";
      j[1] = "\u0000l\u001dW\u0000%\u000f,P\\\n8\nq[\u001a\u0019+\u000fwV\u001a\u0006'\u0013n\u001dy\u0000.\u0006TRX\u001a/";
      j[2] = ")9+8@T&yf3JI#$muBT.\"i>\u0001v%3p7J";
      j[3] = boolean.class;
      k[3] = "java/lang/Boolean";
      j[4] = "$r\u001e\r5r+2S\u0006?o.oX@,|+iU@3p7p\u001e /p%yB8;q2y";
      j[5] = "iz\u0004Bmxbu\u0015\r\u0011amo\u001bN&Q{x\u0017S7}lu";
      j[6] = "_\u00130#\u001fXPS}(\u0015EU\u000evn\u001dXX\br%^佢佩厶佋伕去佢佩桬栏";
      j[7] = "\u0007m\u000bQa\\\b-FZkA\rpM\u001cc\\\u0000vIW Z\tsI\u001cc\\\u0012fHW`GJ佖叮佧叅司桵又叮佧佛";
      j[8] = "n\u0019\twW\u0013e\u0016\u00188*\u000bv\u0011\u0011q";
      j[9] = void.class;
      k[9] = "java/lang/Void";
      j[10] = "w[`Ygsw[w\u0005k|m\u0010w\u001bc\u007fwJ::ct|]f\u0016ln";
      j[11] = "\u0019\u0011z\u0010[\t\u0019\u0011mLW\u0006\u0003ZmR_\u0005\u0019\u0000 qF\u0014\u001e\u001b`M";
      j[12] = "Fp\u0007(J\u001bFp\u0010tF\u0014\\;\u0004iU\u001eL;\u0003n^\u0001\u0006C\u0016e\u0014";
      j[13] = double.class;
      k[13] = "java/lang/Double";
      j[14] = "`uC\by\u001c`uTTu\u0013z>@If\u0019j>[Cb\u0010b>UJ{\u0016e>uJ{\u0016ec";
      j[15] = "VCe_\u000b(VCr\u0003\u0007'L\bf\u001e\u0014-\\\b}\u0014\u0010$T\bs\u001d\t\"S\bS\u001d\t\"S";
      j[16] = "y-@~i)y-W\"e&cfW<m%y<\u001a\u001ba9Z)D m.p";
      j[17] = "p*JEe9{%[\n\u00047p._P";
      j[18] = "kF]+\u0007`-K\r$8@R\u0003S(A;j[V7\u0003\u0003";
      j[19] = "$\u0011}\u0006g4&Hd\t\u0002cLD;]<3Lu2[ync\u0012e\u0000}i";
      j[20] = " ~\\\u001e\u00145)s\u0002z召桖厅栀台档佲厌桟佄3A\u00111/y]\u0010\u001f=\u007f";
      j[21] = "YN[\u0018\u000eQPC\u0005|佨叨叼栰栭桥栬栲叼栰4E\nZ[RQEYU\\";
      j[22] = "Xp\u0011UDW\n>S\u0004z\b?0SVJ_?\u0000XP\u0015\b\u0013r\u0012\u0012\u0018\u0005";
      j[23] = "\"`}\u000fHjc 0\u00010vD$4\\\u000b#D\u0019e\u001cLb||b\b\r#";
      j[24] = ">p.!m^7}pE?$d.|<i_\"q-?V\u0018a*8z-^>{;E";
      j[25] = "&`\u0004.[^q;\u0000)#WAoEu\u0012\u0001A^\u0015\"A\u0004n/\u0012(\u001cC";
      j[26] = "1`\b\tZ<c.JXdcV J\n[<V\u0010A\f\u000bczb\u000bN\u0006n";
      j[27] = "FVc!\u0010Y\u0011\rg&hP!Y\"zX\u000f!hr-\n\u0003\u000e\u0019u'WD";
      j[28] = "&5-oG\u0004&=|<*厡叙框栈伃叩厡佇框叒^\u0016\b&n|8\u0016\u0000w=";
      j[29] = "\u0013!~\u000e!Z\u001fc&\u000f\u001e:.%{\u0004&\u001c\u001ee8\u0018qe\u0010r\u007f\\|\n\u001e|9Z\u001e";
      j[30] = "Kmd\u0015\u0011+G/<\u0014.rvia\u001f\u0016mF)\"\u0003A\u0014";
      j[31] = "bKF\u001edZkF\u0018z伂口栝栵佴伧框根余栵)Aa^mLG\u0010oR=";
      j[32] = "\n7Em-}\u0003:\u001b\t叕叄桵桉佷佔叕栞伱厓*2(y\u00050Dc&uU";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @EventTarget
   public void L(UpdateEvent event) {
      long a = 友何友友友友友友树树.a ^ 15329948797782L ^ 100303555705372L;
      友树友友何友树友树友.F(2, a)
         .forEach(
            (key, value) -> {
               long axxxx = 友何友友友友友友树树.a ^ 80928808124304L;
               long ax = axxxx ^ 64317255157108L;
               int axx = (int)((axxxx ^ 74933876166245L) >>> 32);
               int axxx = (int)((axxxx ^ 74933876166245L) << 32 >>> 32);
               c<"Z">(-946922124612184164L, axxxx);
               if (value == c<"Ç">(-947550758414378637L, axxxx)
                  && new AABB(key.getX(), key.getY(), key.getZ(), key.getX() + 1, key.getY() + 1, key.getZ() + 1).intersects(mc.player.getBoundingBox())) {
                  mc.player.setDeltaMovement(0.0, 0.0, 0.0);
                  String var10 = c<"Î">(this, -947691121974121345L, axxxx).getValue();
                  byte var11 = -1;
                  switch (var10.hashCode()) {
                     case -1955878649:
                        if (!var10.equals(b<"h">(481, 3609174825803718720L ^ axxxx))) {
                           break;
                        }

                        var11 = 0;
                     case 2228079:
                        if (var10.equals(b<"h">(20552, 2057855903833321967L ^ axxxx))) {
                           var11 = 1;
                        }
                  }

                  switch (var11) {
                     case 0:
                        if (树何何何树何友何树何.x(ax)) {
                           树何何何树何友何树何.c(c<"Î">(this, -949059985715684707L, axxxx).getValue().doubleValue(), axx, axxx);
                        }

                        if (c<"Î">(c<"Î">(mc, -947824444289336883L, axxxx), -947257380562157088L, axxxx).isDown()) {
                           mc.player
                              .setDeltaMovement(
                                 c<"Î">(mc.player.getDeltaMovement(), -947224811492169960L, axxxx),
                                 c<"Î">(this, -946957567068092390L, axxxx).getValue().doubleValue(),
                                 c<"Î">(mc.player.getDeltaMovement(), -947456485358253908L, axxxx)
                              );
                           return;
                        }

                        if (!c<"Î">(c<"Î">(mc, -947824444289336883L, axxxx), -947410972688210067L, axxxx).isDown()) {
                           break;
                        }

                        mc.player
                           .setDeltaMovement(
                              c<"Î">(mc.player.getDeltaMovement(), -947224811492169960L, axxxx),
                              c<"Î">(this, -947628308824190792L, axxxx).getValue().doubleValue(),
                              c<"Î">(mc.player.getDeltaMovement(), -947456485358253908L, axxxx)
                           );
                     case 1:
                        if (树何何何树何友何树何.x(ax)) {
                           树何何何树何友何树何.c(0.6, axx, axxx);
                        }

                        if (c<"Î">(c<"Î">(mc, -947824444289336883L, axxxx), -947257380562157088L, axxxx).isDown()) {
                           mc.player
                              .setDeltaMovement(
                                 c<"Î">(mc.player.getDeltaMovement(), -947224811492169960L, axxxx),
                                 0.6,
                                 c<"Î">(mc.player.getDeltaMovement(), -947456485358253908L, axxxx)
                              );
                           return;
                        }

                        if (c<"Î">(c<"Î">(mc, -947824444289336883L, axxxx), -947410972688210067L, axxxx).isDown()) {
                           mc.player
                              .setDeltaMovement(
                                 c<"Î">(mc.player.getDeltaMovement(), -947224811492169960L, axxxx),
                                 -0.6,
                                 c<"Î">(mc.player.getDeltaMovement(), -947456485358253908L, axxxx)
                              );
                        }
                  }
               }
            }
         );
   }

   private static String LIU_YA_FENG() {
      return "何炜霖230622200409390090";
   }
}
