package cn.cool.cherish.module.impl.movement;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.packet.PacketUtils;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.cool.cherish.value.impl.ModeValue;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action;
import why.tree.friend.antileak.Fucker;

public class 友何树树友何友友树友 extends Module implements 何树友 {
   private final ModeValue 友友何树何树树友友树 = new ModeValue("Mode", new String[]{"Grim"}, "Grim");
   private boolean 友友友何何友友何何友 = false;
   private static final long a;
   private static final String[] c;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[18];
   private static final String[] k = new String[18];
   private static int _解放村多种2队1144号 _;

   public 友何树树友何友友树友() {
      super("KeepSneak", "保持下蹲", 树何友友何树友友何何.何友树何树友友友何树);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(2709212955116619313L, 5195260538840585125L, MethodHandles.lookup().lookupClass()).a(11647225280231L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(70577957787306L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[5];
      int var7 = 0;
      String var6 = "=`\u0013á[\u0099\u0086;`v\u008c\u008a]TþÜ\u0010¢Ù\u0019ZÅ\ff8³J§;`\nÌß\u0010\u0099OiaÑ\u0091\u0090\u0000÷\u001fÒ\u0019k¥[@";
      byte var8 = 50;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = c(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     h = new String[5];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ÔÞõ{\u001bÊ\u008bGj\u0082Ib=å¼\r¡\u00adwc\u0097\u009e\u0017ðAg7\u0094Ä\u00840\t\u0018é\u0080¾d3ÉùÀ«\u0004LÜ\u0000qeûXj\u0080(Kþg%";
                  var8 = 57;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 34;
               case 2 -> 12;
               case 3 -> 47;
               case 4 -> 49;
               case 5 -> 52;
               case 6 -> 21;
               case 7 -> 58;
               case 8 -> 9;
               case 9 -> 22;
               case 10 -> 1;
               case 11 -> 45;
               case 12 -> 60;
               case 13 -> 0;
               case 14 -> 23;
               case 15 -> 44;
               case 16 -> 50;
               case 17 -> 56;
               case 18 -> 51;
               case 19 -> 19;
               case 20 -> 36;
               case 21 -> 29;
               case 22 -> 62;
               case 23 -> 18;
               case 24 -> 2;
               case 25 -> 27;
               case 26 -> 40;
               case 27 -> 41;
               case 28 -> 4;
               case 29 -> 8;
               case 30 -> 10;
               case 31 -> 30;
               case 32 -> 33;
               case 33 -> 59;
               case 34 -> 55;
               case 35 -> 31;
               case 36 -> 24;
               case 37 -> 37;
               case 38 -> 35;
               case 39 -> 28;
               case 40 -> 20;
               case 41 -> 43;
               case 42 -> 13;
               case 43 -> 11;
               case 44 -> 16;
               case 45 -> 48;
               case 46 -> 15;
               case 47 -> 25;
               case 48 -> 5;
               case 49 -> 53;
               case 50 -> 26;
               case 51 -> 63;
               case 52 -> 46;
               case 53 -> 32;
               case 54 -> 39;
               case 55 -> 54;
               case 56 -> 14;
               case 57 -> 38;
               case 58 -> 6;
               case 59 -> 57;
               case 60 -> 7;
               case 61 -> 17;
               case 62 -> 61;
               default -> 3;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5633;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])i.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            i.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何树树友何友友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[E¦:\u0088\u0002ÊÈ@, è-1\u009dXA\u0092Á, åé¥z,Î5n, À³\u001f6\u0090ßHYb)®é\u0090û")[var5].getBytes("ISO-8859-1");
         h[var5] = c(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何树树友何友友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/impl/movement/友何树树友何友友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'x' && var8 != 'X' && var8 != 'f' && var8 != 'P') {
            Method var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 163) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 238) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'x') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'X') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'f') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String c(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @Override
   public void h() {
      树树何友树友友何何何.q();
      if (this.友友友何何友友何何友) {
         PacketUtils.F(new ServerboundPlayerCommandPacket(mc.player, Action.RELEASE_SHIFT_KEY), 123291986768823L);
      }

      this.友友友何何友友何何友 = false;
   }

   private static Field f(Class var0, String var1, Class var2) {
      return e(var0, var1, var2);
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return e(var0, var1, var2, var3, var4);
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = e(var8, var10, var15, var13, var14);
         j[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      j[0] = "\fW@\u007fN|\u0003\u0017\rtDa\u0006J\u00062L|\u000bL\u0002y\u000f栂伺史厥佉栰变厤佬伻";
      j[1] = "(9T4 G'y\u0019?*Z\"$\u0012y\"G/\"\u00162aA&'\u0016y\"G=2\u00172!\\e厜伯框桞口伞厜厱框厄";
      j[2] = boolean.class;
      k[2] = "java/lang/Boolean";
      j[3] = "S\bO$8LS\bXx4CICUo!RR\u001fP$%WR\u0019Ti:I\u0013\nZg0\u000bn\bI|0W_\u0002Nd1uQ\fBo'fR\u0000Vk;Am\fXa0Q\u0019,X~<JS";
      j[4] = "\u0010\f1\u0014>\r\u001fL|\u001f4\u0010\u001a\u0011wY<\r\u0017\u0017s\u0012\u007f\u000b\u001e\u0012sY<\r\u0005\u0007r\u0012?\u0016]桳栎伢厚桳厸厩佊伢伄";
      j[5] = "\u0015q$6R\u001e\u001e~5y.\u0007\u0011d;:\u00197\u0007s7'\b\u001b\u0010~";
      j[6] = "vaw!}5y!:*w(||1lw,pa-lw,pa-1<\u001fcj766\t|k<";
      j[7] = "upJ\u0004\u0006\u0001z0\u0007\u000f\f\u001c\u007fm\fI\u001f\u000fzk\u0001I\u0000\u0003frJ*\u0006\nsH\u0005\u000b\u001c\u000b";
      j[8] = "zlW v\u001fqcFo\u0017\u0011zhB5";
      j[9] = "kFj<\u001b\u000e?Tp7cd\u001ch]\u001e8s\u0006wP\u0016-b\u0006o]\u0006c\u0004;V{/SP)Lp";
      j[10] = "o2C,h\ni4[x\u0011HTgX$wT39\u0005y/1";
      j[11] = "Y8\b\u001bFh\r*\u0012\u0010>\u00009\u001f)+i\u0003#\u0013<,i\u001b.\u0003rJT\"\b*B\u001eF8\u0003";
      j[12] = "IA.\u0013B\tKL>u厺厠佭栺伜桬桠厠右栺AHE\u001bQD(\u001f\t\f\r";
      j[13] = "\u001cm55\u0016kB=\u007f^伷叚桥佐桞厝厩叚伡栔G>\nk\u0017q5`Z!";
      j[14] = "\u0014m1aIg\u0016`!\u0007\u001b\rVk;7\u00173P2`{r6\tjnbL0P1\"\u0007";
      j[15] = "A8eCq]C5u%厉叴叻伇佗另厉佪佥厙\n\u001c(R^?mBu\u000f\u0006";
      j[16] = "8$\u0010\t\u0007\u0003`/KUn)C\u001b+3R\u0015cz\u001eA\n\u001e8&";
      j[17] = "Q,NWpDW*V\u0003\t:jyU_o\u001a\r'\b\u00027\u007f";
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (var5 instanceof String) {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = e(var8, var10, var11);
         j[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, 0L);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   @Override
   protected void M() {
      this.友友友何何友友何何友 = WrapperUtils.G(30063522265202L);
   }

   @EventTarget
   public void T(PacketEvent event) {
      树树何友树友友何何何.M();
      if ((Boolean)Fucker.isLogin && ((Boolean)Fucker.isBeta || (Boolean)Fucker.友友何友何何树何树树)) {
         if (event.getSide() == Event.Side.POST) {
            Packet<?> packet = event.getPacket();
            if (packet instanceof ServerboundPlayerCommandPacket wrapper
               && (wrapper.getAction() == Action.PRESS_SHIFT_KEY || wrapper.getAction() == Action.RELEASE_SHIFT_KEY)) {
               event.setCancelled(true);
            }

            if (this.友友何树何树树友友树.K("Grim") && packet instanceof ServerboundInteractPacket wrapper && !wrapper.isUsingSecondaryAction()) {
               WrapperUtils.K(77671152457130L, wrapper, true);
            }
         }
      }
   }

   private static String HE_SHU_YOU() {
      return "何树友为什么濒天了";
   }
}
