package cn.cool.cherish.module;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.impl.combat.KillAura;
import cn.cool.cherish.module.impl.combat.Velocity;
import cn.cool.cherish.module.impl.combat.何树友何友何树友树友;
import cn.cool.cherish.module.impl.combat.友何何友树友树树树友;
import cn.cool.cherish.module.impl.combat.友友友何树何何友何树;
import cn.cool.cherish.module.impl.combat.友树树树何友树树友何;
import cn.cool.cherish.module.impl.combat.树树何树何何何友友友;
import cn.cool.cherish.module.impl.combat.树树树树树树友何友何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.module.impl.display.RotationRender;
import cn.cool.cherish.module.impl.display.ScoreboardHUD;
import cn.cool.cherish.module.impl.display.何何何何何树友树树何;
import cn.cool.cherish.module.impl.display.何何何友树树何何树何;
import cn.cool.cherish.module.impl.display.何友何友树何树友友树;
import cn.cool.cherish.module.impl.display.何树树何友友何何树友;
import cn.cool.cherish.module.impl.display.友何何何何友何友友树;
import cn.cool.cherish.module.impl.display.友何树树友何树树树友;
import cn.cool.cherish.module.impl.display.友友何何友何友树何树;
import cn.cool.cherish.module.impl.display.友友何树树何树树何何;
import cn.cool.cherish.module.impl.display.友树何友友何树何友何;
import cn.cool.cherish.module.impl.display.友树友树友树何友树何;
import cn.cool.cherish.module.impl.display.树友何友友何何树友树;
import cn.cool.cherish.module.impl.display.树友友何树树树何树何;
import cn.cool.cherish.module.impl.display.树友树树何何友何何友;
import cn.cool.cherish.module.impl.display.树树何树何何树何何树;
import cn.cool.cherish.module.impl.display.树树树何树树何何树友;
import cn.cool.cherish.module.impl.misc.Title;
import cn.cool.cherish.module.impl.misc.何何友何树友树树友友;
import cn.cool.cherish.module.impl.misc.何树何树何何友友友何;
import cn.cool.cherish.module.impl.misc.何树何树树友何何友树;
import cn.cool.cherish.module.impl.misc.何树友树何何何树何何;
import cn.cool.cherish.module.impl.misc.何树友树何何友何树友;
import cn.cool.cherish.module.impl.misc.友何树友何友何树树友;
import cn.cool.cherish.module.impl.misc.友树友何树何友友友树;
import cn.cool.cherish.module.impl.misc.树何树何何友友友友何;
import cn.cool.cherish.module.impl.misc.树何树友友何何何何何;
import cn.cool.cherish.module.impl.misc.树树何树友何何何何树;
import cn.cool.cherish.module.impl.misc.树树树树友何树何树何;
import cn.cool.cherish.module.impl.movement.KeepSprint;
import cn.cool.cherish.module.impl.movement.NoJumpDelay;
import cn.cool.cherish.module.impl.movement.何树友友何何树何友友;
import cn.cool.cherish.module.impl.movement.何树友树友友树何友树;
import cn.cool.cherish.module.impl.movement.何树树何树何友何树友;
import cn.cool.cherish.module.impl.movement.友何友友友树树何何树;
import cn.cool.cherish.module.impl.movement.友何树树友何友友树友;
import cn.cool.cherish.module.impl.movement.友树何树何树何树友树;
import cn.cool.cherish.module.impl.movement.友树树树何何友树树树;
import cn.cool.cherish.module.impl.movement.树友树友友何友友友友;
import cn.cool.cherish.module.impl.movement.树树何友树友友何何何;
import cn.cool.cherish.module.impl.movement.树树树树树友何友何树;
import cn.cool.cherish.module.impl.player.NoSlowBreak;
import cn.cool.cherish.module.impl.player.Reach;
import cn.cool.cherish.module.impl.player.何何友何友树友友何何;
import cn.cool.cherish.module.impl.player.何友何友何树何树友树;
import cn.cool.cherish.module.impl.player.何友友树友树何友何何;
import cn.cool.cherish.module.impl.player.何友树何何何何树何树;
import cn.cool.cherish.module.impl.player.何友树树树树何何树树;
import cn.cool.cherish.module.impl.player.何友树树树树树何友树;
import cn.cool.cherish.module.impl.player.何树树何何树何何友树;
import cn.cool.cherish.module.impl.player.友何友何树何树何树何;
import cn.cool.cherish.module.impl.player.友何友友何何树何友何;
import cn.cool.cherish.module.impl.player.友友树树何何友树何友;
import cn.cool.cherish.module.impl.player.树何何友友何树何友树;
import cn.cool.cherish.module.impl.player.树何友友树友何树友友;
import cn.cool.cherish.module.impl.player.树何友树友友友友友友;
import cn.cool.cherish.module.impl.player.树何树树树树友树何何;
import cn.cool.cherish.module.impl.player.树友何何友何树何树友;
import cn.cool.cherish.module.impl.player.树友何何树友友何友友;
import cn.cool.cherish.module.impl.player.树友何树友树何友树树;
import cn.cool.cherish.module.impl.player.树树何树树友何友友何;
import cn.cool.cherish.module.impl.player.树树树何何何树何友树;
import cn.cool.cherish.module.impl.player.树树树友树树树友何何;
import cn.cool.cherish.module.impl.player.树树树树何友树何树友;
import cn.cool.cherish.module.impl.player.树树树树友树友何友友;
import cn.cool.cherish.module.impl.render.Animations;
import cn.cool.cherish.module.impl.render.BetterCamera;
import cn.cool.cherish.module.impl.render.ESP;
import cn.cool.cherish.module.impl.render.ItemPhysic;
import cn.cool.cherish.module.impl.render.WallHack;
import cn.cool.cherish.module.impl.render.何何树树何何树树树何;
import cn.cool.cherish.module.impl.render.何树树何何树树友树何;
import cn.cool.cherish.module.impl.render.友何何何友何友何何何;
import cn.cool.cherish.module.impl.render.友何何友树何何友友树;
import cn.cool.cherish.module.impl.render.友何树何何友友树友友;
import cn.cool.cherish.module.impl.render.友友何友何树树树友何;
import cn.cool.cherish.module.impl.render.友友树友友树友友何树;
import cn.cool.cherish.module.impl.render.友树何何何何友何树树;
import cn.cool.cherish.module.impl.render.友树何树树何树何树友;
import cn.cool.cherish.module.impl.render.树何何友何树树友友树;
import cn.cool.cherish.module.impl.render.树友树友何友何何友何;
import cn.cool.cherish.module.impl.render.树树何何何何友树友何;
import cn.cool.cherish.module.impl.render.树树树何友友友友何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.lzq.injection.asm.invoked.input.KeyEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class ModuleManager implements IWrapper, 何树友 {
   private final List<Module> 何树何何树何友友树何 = new ArrayList<>();
   public final Map<Class<? extends Module>, Module> 何友友友何何何何何树 = new HashMap<>();
   private static String 树何友友树树友何何友;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[24];
   private static final String[] e = new String[24];
   private static String LIU_YA_FENG;

   public ModuleManager() {
      Cherish.instance.getEventManager().register(this);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2656405476067839852L, -6331493582520796090L, MethodHandles.lookup().lookupClass()).a(241861347726340L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (h() == null) {
         T("LfMTn");
      }

      Cipher var0;
      Cipher var2 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(26575874093224L << var1 * 8 >>> 56);
      }

      var2.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var3 = b(var0.doFinal("ê&!N±Î\u0091\u001b&\u0000¦f\u0001\tI#´¼x\u0010\u001f:õV¤²¦Iª³ô¹".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      b = var3;
   }

   public Module getModule(Class<? extends Module> moduleClazz) {
      return this.何友友友何何何何何树.get(moduleClazz);
   }

   private void I(Module... modules) {
      Arrays.asList(modules).forEach(this::k);
   }

   public List<Module> Z(树何友友何树友友何何 category) {
      return this.何树何何树何友友树何.stream().filter(module -> module.Z().equals(category)).collect(Collectors.toList());
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 49;
               case 1 -> 36;
               case 2 -> 34;
               case 3 -> 38;
               case 4 -> 56;
               case 5 -> 55;
               case 6 -> 33;
               case 7 -> 52;
               case 8 -> 62;
               case 9 -> 3;
               case 10 -> 26;
               case 11 -> 16;
               case 12 -> 17;
               case 13 -> 22;
               case 14 -> 61;
               case 15 -> 46;
               case 16 -> 51;
               case 17 -> 28;
               case 18 -> 20;
               case 19 -> 24;
               case 20 -> 5;
               case 21 -> 59;
               case 22 -> 0;
               case 23 -> 60;
               case 24 -> 18;
               case 25 -> 12;
               case 26 -> 44;
               case 27 -> 15;
               case 28 -> 43;
               case 29 -> 58;
               case 30 -> 37;
               case 31 -> 19;
               case 32 -> 11;
               case 33 -> 10;
               case 34 -> 2;
               case 35 -> 13;
               case 36 -> 45;
               case 37 -> 41;
               case 38 -> 8;
               case 39 -> 29;
               case 40 -> 23;
               case 41 -> 31;
               case 42 -> 53;
               case 43 -> 39;
               case 44 -> 32;
               case 45 -> 6;
               case 46 -> 1;
               case 47 -> 21;
               case 48 -> 63;
               case 49 -> 48;
               case 50 -> 40;
               case 51 -> 30;
               case 52 -> 9;
               case 53 -> 42;
               case 54 -> 4;
               case 55 -> 57;
               case 56 -> 50;
               case 57 -> 7;
               case 58 -> 25;
               case 59 -> 35;
               case 60 -> 14;
               case 61 -> 27;
               case 62 -> 54;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 213 && var8 != 'P' && var8 != 244 && var8 != 250) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'm') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 229) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 213) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'P') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public List<Module> x(树何友友何树友友何何 category) {
      树何友友何树友友何何.r();
      return category == null
         ? Collections.emptyList()
         : this.何友友友何何何何何树.values().stream().filter(module -> category.equals(module.Z())).collect(Collectors.toList());
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public static String h() {
      return 树何友友树树友何何友;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/module/ModuleManager" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      c[0] = "mBi5\u0000jb\u0002$>\nwg_/x\u0002jjY+3AHaH2:\nHoB&1\nw";
      c[1] = "\\\u000euYQ5B\u0006o\u00163)E\u001b";
      c[2] = ",J\u0019>F<'E\bq;$4B\u00018";
      c[3] = void.class;
      e[3] = "java/lang/Void";
      c[4] = "3(\"lV\n8'3#=\u001e:,$y\u0011\t7";
      c[5] = "\u0007\u0018j+\u0015]\bX' \u001f@\r\u0005,f\u0017]\u0000\u0003(-T栣伱厽厏伝桫叹厯伣休";
      c[6] = int.class;
      e[6] = "java/lang/Integer";
      c[7] = "YJ\\\u0001bhYJK]ngC\u0001KCfdY[\u0006bfoRLZNiu";
      c[8] = "<10/'{<1's+t&z'm#w< jf?{|''s/w<'jR)`71*";
      c[9] = "UW\n\u0010z]Z\u0017G\u001bp@_JL]x]RLH\u0016;\u007fY]Q\u001fp";
      c[10] = "q\u0003!\u0001\u00129E .A_2O=+\u001cTtG &\u001aP?\u0004\u0002-\u000bI6Ot";
      c[11] = "\u0010QD\u001e%\u0001$rK^h\n.oN\u0003cL&rC\u0005g\u0007ePH\u0014~\u000e.&";
      c[12] = "OGx`a\u001c@\u00075kk\u0001EZ>-{\u0007EE%-y\u0001MY&f|]e~$b~\u0003I[";
      c[13] = "!`\u001f?Ad/q\u0010t\u000ex!u\u001fxNs`~\u0017v\u0014~`^\u0017vGq<";
      c[14] = "DbWy\u001cYOmF6}WDfBl";
      c[15] = "pU~`Lox_x\\佸桋佀伸栞企另厑栄伸\u0007%\u0015ny[kaT(";
      c[16] = "VNk\u000b\u0012!^Dm7\u001b\u001c\u0001FqFKyVAhS{";
      c[17] = "\u000b\u0013RBH\u0011\u0003\u0019T~H,]M\u001aA@F\u0000MUN!\u0017\b\u0012\u0014\u001fKJ\b]\u001b~";
      c[18] = "b\u0018`\u0007\u000f\u001b2\u000bw\u000fey\\Fe\\\f\u00140\u00153\u000e\\+";
      c[19] = "GX,RFT\u0012PfN<[\u0010O3^F?FL#OZO\u0006@6Z";
      c[20] = "Lx\tM\b\u0001\u001ck\u001eEbor&\f\u0016\u000b\u000e\u001euZD[1H(\u001fK\u000bV\u001cm]@b";
      c[21] = "#\u0002\u001aK|\u0015/\u001e\u001dI\u0003\u0015HB]\u00013CHsYDi\u0010'C\u000eY`\u0019";
      c[22] = "&$W\u007f0W..QC\u0005jq,M2i\u000f&+T'YPumB*>\u00040/IC";
      c[23] = "~%4sX\u007f?.40e=E~x2\u000f?/r8q_G";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   public Module o(String name) {
      return this.何树何何树何友友树何.stream().filter(module -> module.A().replace(" ", "").equalsIgnoreCase(name)).findFirst().orElse(null);
   }

   public Collection<Module> p() {
      return this.何树何何树何友友树何;
   }

   private void k(Module module) {
      树何友友何树友友何何.r();
      this.何树何何树何友友树何.add(module);
      this.何友友友何何何何何树.put((Class<? extends Module>)module.getClass(), module);
      Class<?> currentClass = module.getClass();
      if (currentClass != Object.class) {
         Field[] var6 = currentClass.getDeclaredFields();
         int var7 = var6.length;
         int var8 = 0;
         if (0 < var7) {
            Field field = var6[0];

            try {
               field.setAccessible(true);
               Object obj = field.get(module);
               if (obj instanceof 树何何树何友树何何树) {
                  module.P().add((树何何树何友树何何树<?>)obj);
               }
            } catch (IllegalAccessException var11) {
               IWrapper.logger.error("{} register value error : {}", module.A(), var11.getMessage());
            }

            var8++;
         }

         currentClass.getSuperclass();
      }
   }

   @EventTarget
   public void g(KeyEvent event) {
      树何友友何树友友何何.r();
      if (mc != null && mc.player != null && mc.level != null && mc.screen == null) {
         Iterator var5 = this.p().iterator();
         if (var5.hasNext()) {
            Module module = (Module)var5.next();
            if (module.r() != -1 && module.r() == event.getKeyCode() && mc.screen == null || module.r() == 344 && event.getKeyCode() == -1 && mc.screen == null
               )
             {
               module.n();
            }
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void T(String var0) {
      树何友友树树友何何友 = var0;
   }

   private static String HE_WEI_LIN() {
      return "何树友被何大伟克制了";
   }

   public void O() {
      int var10000 = 树何友友何树友友何何.r();
      this.I(
         new 友树树树何友树树友何(),
         new 友何何友树友树树树友(),
         new 何友友树友树何友何何(),
         new 友友友何树何何友何树(),
         new 树树何树何何何友友友(),
         new KillAura(),
         new 树树树树树树友何友何(),
         new 何树友何友何树友树友(),
         new Velocity(),
         new 何何何友树树何何树何(),
         new 友何树树友何树树树友(),
         new 友友何树树何树树何何(),
         new 树友树树何何友何何友(),
         new 友何何何何友何友友树(),
         new 何树树何友友何何树友(),
         new HUD(),
         new 何友何友树何树友友树(),
         new 友友何何友何友树何树(),
         new 树友友何树树树何树何(),
         new 友树何友友何树何友何(),
         new RotationRender(),
         new ScoreboardHUD(),
         new 何何何何何树友树树何(),
         new 树友何友友何何树友树(),
         new 友树友树友树何友树何(),
         new 树树何树何何树何何树(),
         new 树树树何树树何何树友(),
         new 树何树何何友友友友何(),
         new 树何树友友何何何何何(),
         new 何树何树何何友友友何(),
         new 友何树友何友何树树友(),
         new 何何友何树友树树友友(),
         new 何树友树何何友何树友(),
         new 何树何树树友何何友树(),
         new 友树友何树何友友友树(),
         new 树树树树友何树何树何(),
         new 何树友树何何何树何何(),
         new Title(),
         new 树树何树友何何何何树(),
         new 友何友友友树树何何树(),
         new 树树何友树友友何何何(),
         new 何树树何树何友何树友(),
         new 友何树树友何友友树友(),
         new KeepSprint(),
         new NoJumpDelay(),
         new 友树何树何树何树友树(),
         new 友树树树何何友树树树(),
         new 树树树树树友何友何树(),
         new 何树友友何何树何友友(),
         new 何树友树友友树何友树(),
         new 树友树友友何友友友友(),
         new 树树树树何友树何树友(),
         new 友何友何树何树何树何(),
         new 友何友友何何树何友何(),
         new 树树树树友树友何友友(),
         new 何友树树树树何何树树(),
         new 树树树友树树树友何何(),
         new 树树何树树友何友友何(),
         new 树树树何何何树何友树(),
         new 何何友何友树友友何何(),
         new 友友树树何何友树何友(),
         new 树何友树友友友友友友(),
         new 树何何友友何树何友树(),
         new 何友树何何何何树何树(),
         new 树何友友树友何树友友(),
         new 树友何树友树何友树树(),
         new 树何树树树树友树何何(),
         new 树友何何树友友何友友(),
         new 何友树树树树树何友树(),
         new NoSlowBreak(),
         new 何树树何何树何何友树(),
         new Reach(),
         new 树友何何友何树何树友(),
         new 何友何友何树何树友树(),
         new 友友树友友树友友何树(),
         new 友友何友何树树树友何(),
         new 树树树何友友友友何何(),
         new Animations(),
         new BetterCamera(),
         new 友树何何何何友何树树(),
         new 友何何友树何何友友树(),
         new 友何树何何友友树友友(),
         new ESP(),
         new 何何树树何何树树树何(),
         new 友树何树树何树何树友(),
         new ItemPhysic(),
         new 树何何友何树树友友树(),
         new 何树树何何树树友树何(),
         new 友何何何友何友何何何(),
         new WallHack(),
         new cn.cool.cherish.module.impl.render.树友树树何何友何何友(),
         new 树树何何何何友树友何(),
         new 树友树友何友何何友何()
      );
      this.何树何何树何友友树何.sort(Comparator.comparing(Module::A));
      if (var10000 == 0) {
         Module.V(new Module[5]);
      }
   }
}
