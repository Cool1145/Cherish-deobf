package cn.cool.cherish.module;

public interface 树何何树友何何友何友 {
   void b(long var1);

   int[] b();

   boolean b(树何何树友何何友何友 var1);

   void a(树何何树友何何友何友 var1);

   long a(long var1);
}
