package cn.cool.cherish;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.render.何树何树树树树友树何;
import cn.cool.cherish.ui.何树树友树树友树友树;
import cn.cool.cherish.utils.client.ClientUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.glfw.GLFW;

public class 友何树树树树何树何友 extends 友树树友树树友友何何 implements 何树友 {
   private final Map<Integer, String> 树树何何何树友友树何;
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[17];
   private static final String[] i = new String[17];
   private static int _何炜霖230622200409390090 _;

   public 友何树树树树何树何友() {
      long a = b ^ 110769496405627L;
      c<"Ó">(5508437808879089552L, a);
      super(a<"d">(28561, 3668493455042004113L ^ a), a<"d">(30375, 3319926802570567077L ^ a));
      this.树树何何何树友友树何 = new HashMap<>();
      Field[] var4 = GLFW.class.getFields();
      int var5 = var4.length;
      int var6 = 0;
      if (0 < var5) {
         Field field = var4[0];
         if (Modifier.isStatic(field.getModifiers()) && field.getName().startsWith(a<"d">(30168, 2316308393950076635L ^ a))) {
            field.setAccessible(true);

            try {
               int keyCode = (Integer)field.get(null);
               String keyName = field.getName().substring(9).toLowerCase();
               c<"é">(this, 5508362599992228705L, a).put(keyCode, keyName);
            } catch (IllegalAccessException var10) {
               var10.printStackTrace();
            }
         }

         var6++;
      }

      if (!c<"Ó">(5509715559915806185L, a)) {
         c<"Ó">(new Module[4], 5508079362156484248L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7516376604009836431L, -5664599748086643368L, MethodHandles.lookup().lookupClass()).a(279151933072015L);
      // $VF: monitorexit
      b = var10000;
      b();
      long var0 = b ^ 108608312080872L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[11];
      int var7 = 0;
      String var6 = "\u0094Í¸\u0005m\u001e--\u008f\u001d\fðèÆfÜ(|O%\u001eíçó\u008aáX®\u0098¢G}ÕN\u0013/\u0082Ô(=§Ëó3=úì%H\u0003\u0090ì¶\u0006§d<\u0010Ï\\C\u0001\r\rúE_q×óÀR\u0082\u0095 \u008ctmb\u0098ÑÆ\u000f*i\u0002Z\u009c\u00872s\u000b\u0087\u009dÄÊ3\u009b\u001a£\u0004\u0082å0wz!\u0018h\u0089[¿£íKa®e\u0083\u0097ñ:!ÀyÄ\u008f\u0092\u0083\u0095ËQ\u0010\u001cmÿª]\u0002+¼6\u0018O\u009d\bc´\u001b\u0010mOòÕ÷ÈH\u0094.\u0006?\"À,¼?\u0010\u008f¬{m,\u000b\u0007øw)ÈÉ\u009c÷,\u0085\u0010dï½\u0096\u009cWP\u000emÆÓ\u001fj¹ñ\u008e";
      short var8 = 200;
      char var5 = 16;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     d = new String[11];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "c\u0014J \u0019\u000b\u001eÖ_\u0090Å\u0086øæ\u00853\u008dA£ \u0085%\u0086x+z\u0018F·\u001a¿}\u0010·\u0013ò\u0012\u001dR:0·«ÓO\u0083ÂM¼";
                  var8 = 49;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 9;
               case 1 -> 37;
               case 2 -> 15;
               case 3 -> 31;
               case 4 -> 32;
               case 5 -> 58;
               case 6 -> 45;
               case 7 -> 0;
               case 8 -> 61;
               case 9 -> 54;
               case 10 -> 35;
               case 11 -> 50;
               case 12 -> 22;
               case 13 -> 38;
               case 14 -> 62;
               case 15 -> 33;
               case 16 -> 23;
               case 17 -> 44;
               case 18 -> 46;
               case 19 -> 49;
               case 20 -> 18;
               case 21 -> 10;
               case 22 -> 43;
               case 23 -> 20;
               case 24 -> 41;
               case 25 -> 51;
               case 26 -> 36;
               case 27 -> 57;
               case 28 -> 3;
               case 29 -> 7;
               case 30 -> 53;
               case 31 -> 16;
               case 32 -> 6;
               case 33 -> 13;
               case 34 -> 12;
               case 35 -> 40;
               case 36 -> 52;
               case 37 -> 5;
               case 38 -> 28;
               case 39 -> 17;
               case 40 -> 30;
               case 41 -> 14;
               case 42 -> 2;
               case 43 -> 8;
               case 44 -> 47;
               case 45 -> 21;
               case 46 -> 11;
               case 47 -> 1;
               case 48 -> 56;
               case 49 -> 27;
               case 50 -> 63;
               case 51 -> 26;
               case 52 -> 39;
               case 53 -> 55;
               case 54 -> 19;
               case 55 -> 42;
               case 56 -> 48;
               case 57 -> 59;
               case 58 -> 60;
               case 59 -> 34;
               case 60 -> 24;
               case 61 -> 29;
               case 62 -> 25;
               default -> 4;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 233 && var8 != 253 && var8 != 236 && var8 != 'C') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 197) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 211) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 233) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 253) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void b() {
      h[0] = "qc\u0000\bhl~#M\u0003bq{~FE双佖栃栜栿桺佒栒佇叆";
      h[1] = "\u0010L\u0010\r'~\u001bC\u0001BLj\u0019H\u0016\u0018`}\u0014";
      h[2] = "\u001bC$I<o\u0005K>\u0006_{\u0001";
      h[3] = "\u001f.\"kp\u0005\u0010no`z\u0018\u00153d&j\u0003R桑栝參佊伿伩压叇栙佊";
      h[4] = ";\u0001t\u000f7]4A9\u0004=@1\u001c2B桉佧桉厤桋伹伍叹厓桾";
      h[5] = "5z/\u001cO\u001a\u0001Y \\\u0002\u0011\u000bD%\u0001\tW\u0003Y(\u0007\r\u001c@{#\u0016\u0014\u0015\u000b\r";
      h[6] = "'\u0003<l\u0003\u001b(Cqg\t\u0006-\u001ez!\u0001\u001b \u0018~jB9+\tgc\t";
      h[7] = boolean.class;
      i[7] = "java/lang/Boolean";
      h[8] = "7sZ<`&\u0003PU|--\tMP!&k\u0001P]'\" BrV6;)\t\u0004";
      h[9] = void.class;
      i[9] = "java/lang/Void";
      h[10] = " &aX4$+)p\u0017U* \"tM";
      h[11] = "z\u000b\u0017\nxg#\u0007\u001a\u000e\u0013=@F\f\u0000t%z\u001bW\u0004nX~\u001e\u0005S)$:@\n\u001b\u0013";
      h[12] = "y_2Y,d}\u0007#LF双桚叿厚栺厅佒厀栥厚#|l(F3Hx49S";
      h[13] = "K\u0000A\u001e&$\u0006\u0004\u0000/uKOW\u0000\u0016ps\f\u0005\u001bA\u001crH\u0010@C$1\u001a\u000b\u0017/";
      h[14] = "#\u0012\nS\baz\u001e\u0007Wc#\u0019_\u0011Y\u0004##\u0002J]\u001e^";
      h[15] = "!*G\u0003f\u001el.\u00062桅桨佁伞伢栫原厲栅伞\u007f\bf\u0017cr\u000fY;If";
      h[16] = "j\u0004&\u000fAqkQ;\u0003+~V\bdUR-&\u00049U\u0015\u0013";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友何树树树树何树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26485;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/友何树树树树何树何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友何树树树树何树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   public void W(String[] params) {
      long a = b ^ 37575772281420L;
      long ax = a ^ 10841031461261L;
      c<"Ó">(6937409927994579879L, a);
      if (params.length >= 1 && params[0].equalsIgnoreCase(a<"d">(30611, 4678748531365408937L ^ a))) {
         Iterator var13 = Cherish.instance.getModuleManager().k().iterator();
         if (var13.hasNext()) {
            Module module = (Module)var13.next();
            if (!(module instanceof 何树何树树树树友树何)) {
               module.E(-1);
            }
         }

         何树树友树树友树友树.S(c<"ì">(6937274231604500195L, a), a<"d">(28825, 8379363087348365227L ^ a), a<"d">(26711, 7971016334137749350L ^ a), 5.0F);
      } else {
         ClientUtils.e(new Object[]{a<"d">(19086, 655855244842814903L ^ a), ax});
         Collection<Module> modules = Cherish.instance.getModuleManager().k();
         boolean foundBinds = false;
         Iterator var9 = modules.iterator();
         if (var9.hasNext()) {
            Module module = (Module)var9.next();
            int key = module.W();
            if (key != -1 && key != 0) {
               String keyName = c<"é">(this, 6937483015671404374L, a).getOrDefault(key, a<"d">(27257, 8133018519897828681L ^ a) + key);
               ClientUtils.e(new Object[]{a<"d">(322, 4379897326067517044L ^ a) + module.i() + a<"d">(30777, 2347561785564102401L ^ a) + keyName, ax});
               foundBinds = true;
            }
         }

         if (!foundBinds) {
            ClientUtils.e(new Object[]{a<"d">(15873, 4938490802394282290L ^ a), ax});
         }
      }
   }

   private static String HE_DA_WEI() {
      return "何树友为什么濒天了";
   }
}
