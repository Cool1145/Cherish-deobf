package cn.cool.cherish;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何何何何何何友树友树 implements 何树友 {
   private final Set<String> 树何友树树何树何何树;
   private final File 树友友何何友友何树何;
   private static boolean 友何友树友何何何友树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[18];
   private static final String[] f = new String[18];
   private static int _何炜霖230622200409390090 _;

   public 何何何何何何友树友树() {
      T();
      this.树何友树树何树何何树 = new HashSet<>();
      this.树友友何何友友何树何 = new File(Cherish.getConfigManager().getMainFile().getAbsolutePath() + File.separator + "friends.txt");
      File parentDir = this.树友友何何友友何树何.getParentFile();
      if (!parentDir.exists()) {
         if (!parentDir.mkdirs()) {
            null.println("Failed to create parent directory: " + parentDir.getAbsolutePath());
            Module.V(new Module[2]);
         }

         null.println("Parent directory created: " + parentDir.getAbsolutePath());
      }

      if (!this.树友友何何友友何树何.exists()) {
         try {
            if (this.树友友何何友友何树何.createNewFile()) {
               null.println("Friends file created: " + this.树友友何何友友何树何.getAbsolutePath());
            }

            null.println("Failed to create friends file: " + this.树友友何何友友何树何.getAbsolutePath());
         } catch (IOException var6) {
            null.println("Error creating friends file:" + var6.getMessage());
            var6.printStackTrace();
         }
      }

      this.R();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6737961565784678766L, 7007479315704344243L, MethodHandles.lookup().lookupClass()).a(28028749887099L);
      // $VF: monitorexit
      a = var10000;
      a();
      H(true);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(140404564275110L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[6];
      int var5 = 0;
      String var4 = "aÂ\u0089.³½Ó_«Â\u001býññ¼\u009b\u008cpf×*«\"\u000ez>\\¼ð<#ºý\\a\u000e!Ç~£ ·rÞ¤°©QB<Â\u0094\u009c\u00817¼ôê\rüý_\u0001\u009d\u009a\r¡Bk»W\u008bW0Ü\u008dC\u001aÉKXû¢3i©È|ñØAÍ,\u009fDÊ«÷\u0010Ýò\u0082\t\u00ad\u0004.éZL\u009d½\u0005-î´\u007fÏ\\¶Û\u0097×8¾2Ð_ò\u0094o·\f\u009e'\u0019Ñ\u0095Ò«ØÜ[,i ß\u0007âS6êa\tV°ýDÝ-(¹y¸\b¦¸!=:_\u00971ð\u00103\u0019\u0001\u0010Ã";
      short var6 = 179;
      char var3 = '(';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = a(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[6];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "Lä9È\u0007\u0013 \b×'3*®1ç¹ÿù Õ/\u0086c\u0003\u008f\u0087}VVL\u0097/§\ts\u0081²kä%sa\u000f,¼\u008b\u009eä mY\r/<í\u0085)7/{Saê\u000f8Ú\u0080\u009cy\u0019\u0086\f¹©|»-³\u0093p\u0096¬Ò\u008dê\u0085P\u0098Õ\u008fw¶Ò\u0002\rª\u009fV3ñ©ç \u0002Èu7\u0098M4¾è\u000eØ!gô:\u0017ú!";
                  var6 = 121;
                  var3 = '@';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public void B() {
      this.树何友树树何树何何树.clear();
      this.m();
   }

   public static boolean D() {
      T();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/何何何何何何友树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void l(String name) {
      this.树何友树树何树何何树.remove(name.toLowerCase());
      T();
      this.m();
      if (Module.Z() == null) {
         H(false);
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 49;
               case 1 -> 7;
               case 2 -> 1;
               case 3 -> 3;
               case 4 -> 5;
               case 5 -> 61;
               case 6 -> 13;
               case 7 -> 35;
               case 8 -> 18;
               case 9 -> 29;
               case 10 -> 62;
               case 11 -> 51;
               case 12 -> 2;
               case 13 -> 44;
               case 14 -> 32;
               case 15 -> 22;
               case 16 -> 8;
               case 17 -> 25;
               case 18 -> 54;
               case 19 -> 30;
               case 20 -> 46;
               case 21 -> 40;
               case 22 -> 36;
               case 23 -> 21;
               case 24 -> 59;
               case 25 -> 43;
               case 26 -> 28;
               case 27 -> 11;
               case 28 -> 23;
               case 29 -> 17;
               case 30 -> 45;
               case 31 -> 42;
               case 32 -> 20;
               case 33 -> 53;
               case 34 -> 39;
               case 35 -> 48;
               case 36 -> 60;
               case 37 -> 37;
               case 38 -> 56;
               case 39 -> 55;
               case 40 -> 19;
               case 41 -> 4;
               case 42 -> 24;
               case 43 -> 9;
               case 44 -> 15;
               case 45 -> 47;
               case 46 -> 58;
               case 47 -> 0;
               case 48 -> 31;
               case 49 -> 6;
               case 50 -> 33;
               case 51 -> 27;
               case 52 -> 34;
               case 53 -> 26;
               case 54 -> 52;
               case 55 -> 16;
               case 56 -> 57;
               case 57 -> 41;
               case 58 -> 10;
               case 59 -> 38;
               case 60 -> 63;
               case 61 -> 50;
               case 62 -> 12;
               default -> 14;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      e[0] = "n\u001a\u001a\u0005BZaZW\u000eHGd\u0007\\H佸你佘伡佡伳另栤叆桥";
      e[1] = "28t\t0:,0nFM*,";
      e[2] = "!\"(l=e*-9#Ga9,)lqe.";
      e[3] = boolean.class;
      f[3] = "java/lang/Boolean";
      e[4] = void.class;
      f[4] = "java/lang/Void";
      e[5] = "i_\u001bi\\Sf\u001fVbVNcB]$^SnDYo\u001dqeU@fV";
      e[6] = "\u0010?'pd+$\u001c(0) .\u0001-m\"f&\u001c k&-e>+z?$.H";
      e[7] = " PZ3 c%\u001fj;bo";
      e[8] = "\u0011u[kOj%VT+\u0002a/KQv\t''V\\p\rldtWa\u0014e/\u0002";
      e[9] = "r\u0004\u0014hley\u000b\u0005'\rkr\u0000\u0001}";
      e[10] = "/\r\u0007v-h:\n\t\u0012\u0010T~L[,;;}\u001c\rx\\";
      e[11] = "p\u0003++\u00179 \u0013\" e\u000bKQ?a_3.\n+a\u0014Y";
      e[12] = "\u0015@]6\u001f@\u0000GSR桷县厽你佤厑厭伡桧你9oS\u001dBEUl\nGD";
      e[13] = "oAHWEX?QA\\7fT\u0013\\\u001d\rR1HH\u001dF8oCSWO[nT@I7";
      e[14] = ")>TCw\u0007<9Z'栟佦厁桚栩佺栟佦伟桚0\u001e;J-9B_~C$";
      e[15] = ";Y(c#\u001c.^&\u0007; iC1<6\u001c.@|hR\u00197Ywcn^4\u0014#\u0007";
      e[16] = "\u000e8vBl\u0003\u001b?x&]?_y*\u0018zP\\)|L\u001d\u0004\b.b^~\u0005\u001f=|&";
      e[17] = "l\u0016\u001d0\u0011!y\u0011\u0013T<\u001d=WAj\u0007r>\u0007\u0017>`";
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 236 && var8 != 201 && var8 != 227 && var8 != 'm') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 231) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 165) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 236) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 201) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 227) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24936;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/何何何何何何友树友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[G\u0096\u0098¢.\u0083Í\u0003\u0094\u0002¢,}´±m\u001aÿß\u0084\u0007zÄj, ÌëQ\u0006ûò\"\u0011¸4¥ëe !Õ, xEç]1\b¬5§\\7Ú3X)A'\u001b\u0003\u0007&\u009f\u0089ÃM.\u0098C\u0018ë¼Ô, Æy\u0002Rõl\u0092©øÇ®faØ\u0002S\u008dÃ\u008eõÖõÙÛûÂQÎ\u0018è\u0085\u0087, \u0017\u001cøA$`Î \u009aÇ\u00adT±ïSR û¼ÇJD%\u0010\u009d\u00adúÊÞ³ÜÛ´½\u009a\t\u001cH0ª,  Õà¦vî\u0005ãã9ÏW\u0004$Ùñ\u009dÌ\u0011\u0015¼")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/何何何何何何友树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void m() {
      D();

      try {
         File parentDir = this.树友友何何友友何树何.getParentFile();
         if (!parentDir.exists()) {
            parentDir.mkdirs();
         }

         try (PrintWriter writer = new PrintWriter(new FileWriter(this.树友友何何友友何树何))) {
            this.树何友树树何树何何树.forEach(writer::println);
         }
      } catch (IOException var10) {
         var10.printStackTrace();
      }
   }

   public Set<String> v() {
      return new HashSet<>(this.树何友树树何树何何树);
   }

   public void j(String name) {
      this.树何友树树何树何何树.add(name.toLowerCase());
      this.m();
   }

   public boolean M(String name) {
      return this.树何友树树何树何何树.contains(name.toLowerCase());
   }

   public static void H(boolean var0) {
      友何友树友何何何友树 = var0;
   }

   public static boolean T() {
      return 友何友树友何何何友树;
   }

   private void R() {
      T();
      if (this.树友友何何友友何树何.exists()) {
         try {
            Files.readAllLines(this.树友友何何友友何树何.toPath()).forEach(line -> {
               D();
               if (!line.trim().isEmpty()) {
                  this.树何友树树何树何何树.add(line.trim().toLowerCase());
               }
            });
         } catch (IOException var5) {
            var5.printStackTrace();
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
