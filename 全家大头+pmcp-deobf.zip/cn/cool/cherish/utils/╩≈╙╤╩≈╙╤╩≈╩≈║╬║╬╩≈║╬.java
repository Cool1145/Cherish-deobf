package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.树何树树何树何何树何;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

public final class 树友树友树树何何树何 implements 何树友 {
   private static final Map<String, Clip> 树何友何友树何树树友;
   private static String 何树何友何何何友友何;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[19];
   private static final String[] d = new String[19];
   private static String HE_SHU_YOU;

   private 树友树友树树何何树何(long a) {
      long var10000 = 树友树友树树何何树何.a ^ a;
      super();
      throw new UnsupportedOperationException(b);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8575163859309347019L, 6603311791492360001L, MethodHandles.lookup().lookupClass()).a(249750964959838L);
      // $VF: monitorexit
      a = var10000;
      long var3 = a ^ 113934261227383L;
      a();
      if (a<"Ò">(1632574599053634052L, var3) != null) {
         a<"Ò">("dDBQGb", 1634630031671355743L, var3);
      }

      Cipher var0;
      Cipher var5 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var3 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var3 << var1 * 8 >>> 56);
      }

      var5.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var6 = a(
            var0.doFinal(
               "¥*\u0002l~\u007fÐÓÑâDç\u0013ùû´uÙr\u0085×)Á÷P÷¶\u008e?¿'\u0014i×=ï\\\u0010«\u008c·R\u0010?Hþþà\u008eB\u0000\u001b¯ù\u0013\u0003"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      byte var10001 = -1;
      b = var6;
      树何友何友树何树树友 = new ConcurrentHashMap<>();
   }

   public static void C(String var0) {
      何树何友何何何友友何 = var0;
   }

   public static String I(String a, long a, float filePath) {
      a = 树友树友树树何何树何.a ^ a;
      long var10001 = a ^ 84935102584687L;
      int ax = (int)((a ^ 84935102584687L) >>> 48);
      int axx = (int)((a ^ 84935102584687L) << 16 >>> 48);
      int axxx = (int)(var10001 << 32 >>> 32);
      a<"Ò">(-3856766681217485098L, a);
      树何树树何树何何树何.N((char)ax, () -> {
         long axxxx = 树友树友树树何何树何.a ^ 138974597319306L;
         a<"Ò">(-7830343545096474631L, axxxx);

         try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(new File(a))) {
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);
            FloatControl gainControl = (FloatControl)clip.getControl(a<"x">(-7830760265623895140L, axxxx));
            float dB = (float)(Math.log10(Math.max(1.0E-4F, (float)filePath)) * 20.0);
            gainControl.setValue(Math.max(gainControl.getMinimum(), Math.min(gainControl.getMaximum(), dB)));
            a<"x">(-7830204005641743460L, axxxx).put(a, clip);
            clip.addLineListener(event -> {
               long axxxxx = 树友树友树树何何树何.a ^ 83300796251063L;
               a<"Ò">(-6744072619410104636L, axxxxx);
               if (event.getType() == a<"x">(-6741932182991329044L, axxxxx)) {
                  clip.close();
                  a<"x">(-6743943259548212575L, axxxxx).remove(a);
               }
            });
            clip.start();
         } catch (Exception var12) {
            var12.printStackTrace();
            a<"x">(-7830204005641743460L, axxxx).remove(a);
         }
      }, (char)axx, axxx);
      a<"Ò">(!a<"Ò">(-3856689643229898111L, a), -3855751328301070224L, a);
      return a;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void l(String a, long a) {
      boolean var10000;
      label25: {
         a = 树友树友树树何何树何.a ^ a;
         a<"Ò">(-3657116596624346733L, a);
         Clip clip = (Clip)a<"x">(-3656991969799352842L, a).get(a);
         if (clip != null) {
            var10000 = clip.isRunning();
            if (a < 0L) {
               break label25;
            }

            if (var10000) {
               clip.stop();
               clip.close();
               a<"x">(-3656991969799352842L, a).remove(a);
            }
         }

         if (a <= 0L) {
            return;
         }

         var10000 = a<"Ò">(-3658736531184934905L, a);
      }

      if (var10000) {
         a<"Ò">("CUU7E", -3659173064192871736L, a);
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/树友树友树树何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 244 && var8 != 228 && var8 != 'x' && var8 != 'L') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 226) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 210) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 244) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 228) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'x') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (d[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 21;
               case 1 -> 34;
               case 2 -> 7;
               case 3 -> 14;
               case 4 -> 13;
               case 5 -> 2;
               case 6 -> 9;
               case 7 -> 41;
               case 8 -> 62;
               case 9 -> 51;
               case 10 -> 16;
               case 11 -> 55;
               case 12 -> 10;
               case 13 -> 32;
               case 14 -> 25;
               case 15 -> 49;
               case 16 -> 58;
               case 17 -> 18;
               case 18 -> 43;
               case 19 -> 31;
               case 20 -> 61;
               case 21 -> 46;
               case 22 -> 23;
               case 23 -> 8;
               case 24 -> 24;
               case 25 -> 39;
               case 26 -> 59;
               case 27 -> 45;
               case 28 -> 6;
               case 29 -> 5;
               case 30 -> 12;
               case 31 -> 53;
               case 32 -> 57;
               case 33 -> 52;
               case 34 -> 48;
               case 35 -> 56;
               case 36 -> 36;
               case 37 -> 15;
               case 38 -> 47;
               case 39 -> 28;
               case 40 -> 63;
               case 41 -> 50;
               case 42 -> 40;
               case 43 -> 17;
               case 44 -> 1;
               case 45 -> 54;
               case 46 -> 44;
               case 47 -> 33;
               case 48 -> 27;
               case 49 -> 11;
               case 50 -> 0;
               case 51 -> 29;
               case 52 -> 42;
               case 53 -> 37;
               case 54 -> 35;
               case 55 -> 19;
               case 56 -> 30;
               case 57 -> 22;
               case 58 -> 38;
               case 59 -> 4;
               case 60 -> 20;
               case 61 -> 3;
               case 62 -> 60;
               default -> 26;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            d[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      c[0] = "A\u001b\u0007\u000eG\u0004N[J\u0005M\u0019K\u0006ACE\u0004F\u0000E\b\u0006&M\u0011\\\u0001M";
      c[1] = boolean.class;
      d[1] = "java/lang/Boolean";
      c[2] = "dgN\bdkk'\u0003\u0003nvnz\bE~pne\u0013E栚叏栖参桱桺佞佑栖作";
      c[3] = "Pef1<A[jw~FEHkg1pA_";
      c[4] = "7\b[\u001c A<\u0007JS]Y/\u0000C\u001a";
      c[5] = void.class;
      d[5] = "java/lang/Void";
      c[6] = "wf*!+1in0nH%m";
      c[7] = "\u0018@P'b7\u0001NS(~7\u0001@K6v|\u0016\u000f`*ux\u0006bI(nk\u001dM\u0002\u0012ci\u0017";
      c[8] = "\u0011\u0013\u001dj\u0012/\b\u001d\u001ee\u000e/\b\u0013\u0006{\u0006d\u001f\\'b\u0004d>\u0004\u000ee\u001e%/\u000b\u001bn";
      c[9] = "\t|lCA\u001f\u0002s}\f \u0011\txyV";
      c[10] = "\u0000I\u001d\u0013F*\u0001\u0015\u0012\u0011yPt~,e#Brl1ny(QHK\u0017F)\rGI";
      c[11] = "hS\u001fBSr6KD2v\u0017`\u0010COS*:IUI5";
      c[12] = "S1pp+M\u00016+-V\u0014jpy*5\u0014\u001a7uy-}P&\u007f#?\r\u0017*,;V";
      c[13] = "f\u0018L!0\u00014\u001f\u0017|Mz_X\u0011h,K \u0000Q-#1d\u0019HrrO:\u0012B,M";
      c[14] = "v\u000fnh\u000e\u0007(\u00175\u0018!b~L2e\u000e_$\u0015$chY=\u00115'\u0016\u00076\u001bk\u0018";
      c[15] = "btiF\\-?n+\u0014g\t\u0003VI,Z7'{*S\u0007-e)";
      c[16] = "\u0007iH%\u001e\"Un\u0013xcU>)\u0015l\u0002hAqU)\r\u0012";
      c[17] = "Me\u0000wa\u0000\u0013}[\u0007jeE&\\zaX\u001f\u007fJ|\u0007";
      c[18] = "SqhQ=,\u0001v3\f@栅伷叉佐厢桙佁桳栓収a|e\u001b34\u0007*!\u001b{";
   }

   public static void Y(long var0) {
      var0 = a ^ var0;
      a<"x">(5982426661684630476L, var0).forEach((id, clip) -> {
         long a = 树友树友树树何何树何.a ^ 56846368435540L;
         a<"Ò">(-825489285743835097L, a);
         if (clip != null && clip.isRunning()) {
            clip.stop();
            clip.close();
         }
      });
      a<"x">(5982426661684630476L, var0).clear();
   }

   public static void T(long a, String a) {
      a = 树友树友树树何何树何.a ^ a;
      a<"x">(7337667356078171421L, (long)a).entrySet().removeIf(entry -> {
         long ax = 树友树友树树何何树何.a ^ 5350640131733L;
         String id = (String)entry.getKey();
         a<"Ò">(525358407281081318L, ax);
         Clip clip = (Clip)entry.getValue();
         if (id.contains(a) && clip != null && clip.isRunning()) {
            clip.stop();
            clip.close();
            return true;
         } else {
            return false;
         }
      });
   }

   public static String O() {
      return 何树何友何何何友友何;
   }

   private static String LIU_YA_FENG() {
      return "行走的50万——何炜霖";
   }
}
