package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.树友友友树友友何树何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class 友树树何何树树何何树 implements 何树友 {
   public static final Random 树树树何何何树何树何;
   private static int 树树树友友树何友友何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[38];
   private static final String[] f = new String[38];
   private static String HE_SHU_YOU;

   private 友树树何何树树何何树(int a, char a, int a) {
      long ax = ((long)a << 32 | (long)a << 48 >>> 32 | (long)a << 48 >>> 48) ^ 友树树何何树树何何树.a;
      super();
      throw new UnsupportedOperationException(a<"s">(8657, 1019287431319995297L ^ ax));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8890194198145569453L, -6789087613879275180L, MethodHandles.lookup().lookupClass()).a(127437776687208L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 55806247022048L;
      a();
      b<"ª">(0, 556943360467582590L, var9);
      Cipher var0;
      Cipher var12 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[2];
      int var5 = 0;
      char var3 = ' ';
      int var2 = -1;

      while (true) {
         String var14 = a(
               var0.doFinal(
                  "v\u001a\u001dõÉp+£&\u0012Ò`Ý\u0096\u0012é]Éögè1°Ñ\u0005ã*\u0095LÑÒôP\u001eyõ*wûu©C«NT\u0005£¤pñ¿ëA\n\u0012Ý\u001dùécr`ýxaÄ5¾¸\u0004p3ÒãÜ[ZdÌJ\u0082ñöd\u008eMa¥)»äi\u0016:1¼\u000f©Ëzgãm\u0004S\u001aÉºâùLò³"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var14;
         if ((var2 += var3) >= 113) {
            b = var7;
            c = new String[2];
            树树树何何何树何树何 = new Random();
            return;
         }

         var3 = "v\u001a\u001dõÉp+£&\u0012Ò`Ý\u0096\u0012é]Éögè1°Ñ\u0005ã*\u0095LÑÒôP\u001eyõ*wûu©C«NT\u0005£¤pñ¿ëA\n\u0012Ý\u001dùécr`ýxaÄ5¾¸\u0004p3ÒãÜ[ZdÌJ\u0082ñöd\u008eMa¥)»äi\u0016:1¼\u000f©Ëzgãm\u0004S\u001aÉºâùLò³"
            .charAt(var2);
      }
   }

   public static int C() {
      return 树树树友友树何友友何;
   }

   public static int C(long a, int a, int var3, int num) {
      a = 友树树何何树树何何树.a ^ a;
      b<"ª">(-1599143711786538559L, (long)a);
      return a < 0 ? var3 : Math.min((int)a, 255);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友树树何何树树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static int x() {
      C();

      try {
         return 44;
      } catch (IllegalArgumentException var0) {
         throw a(var0);
      }
   }

   public static Vec3 x(AABB a, long a, Direction vec, Vec3 face) {
      a = 友树树何何树树何何树.a ^ a;
      long ax = a ^ 98016789122533L;
      return X(a, vec, b<"a">(face, 365389421696938833L, a), b<"a">(face, 368529713426197872L, a), ax, b<"a">(face, 368387207123953075L, a));
   }

   public static float s(float a, float min, float delta) {
      return -40.0F + (-40.0F - a) * delta;
   }

   public static double c(double a, long var2, double var4) {
      var2 = 友树树何何树树何何树.a ^ var2;
      return a + (var4 - a) * b<"m">(8528637765005670096L, var2).nextDouble();
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友树树何何树树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static double a(double a, double var2, long var4) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/utils/友树树何何树树何何树.a J
      // 03: lload 4
      // 05: lxor
      // 06: lstore 4
      // 08: ldc2_w -8884606749826317124
      // 0b: lload 4
      // 0d: invokedynamic ª (JJ)I bsm=cn/cool/cherish/utils/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 12: pop
      // 13: dload 0
      // 14: dload 2
      // 15: dcmpl
      // 16: iflt 1d
      // 19: dload 0
      // 1a: goto 30
      // 1d: ldc2_w -8881970718796479433
      // 20: lload 4
      // 22: invokedynamic m (JJ)Ljava/util/Random; bsm=cn/cool/cherish/utils/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 27: invokevirtual java/util/Random.nextDouble ()D
      // 2a: dload 2
      // 2b: dload 0
      // 2c: dsub
      // 2d: dmul
      // 2e: dload 0
      // 2f: dadd
      // 30: dreturn
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 14057;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/友树树何何树树何何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static IllegalArgumentException a(IllegalArgumentException var0) {
      return var0;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      e[0] = "z`f~$Au +u.\\p} 3&A}{$xecvj=q.";
      e[1] = boolean.class;
      f[1] = "java/lang/Boolean";
      e[2] = "{\u0010\u000eh\b\u0015tPCc\u0002\bq\rH%\u0012\u000eq\u0012S%厬桫栉伫併栚桶伯位桯";
      e[3] = int.class;
      f[3] = "java/lang/Integer";
      e[4] = void.class;
      f[4] = "java/lang/Void";
      e[5] = "\u0017?\u0017dzy\u001c0\u0006+\u001dy\u0011;\u0006d8T\u000f9\u0014h1{\t\u001b\u0019f1e\t7\u000ek";
      e[6] = "ia<[8\nf!qP2\u0017c|z\u0016\"\u0011cca\u0016?\u0000f\u007fwJy桴叁叄叙栩厜厮佟栞佇";
      e[7] = double.class;
      f[7] = "java/lang/Double";
      e[8] = "M-=t<'M-*(0(Wf>5#\"Gf92(=\r\t\b\u0018\u0013";
      e[9] = "q g6XOq pjT@kkpwGC1\u0001zjPEk,|v";
      e[10] = "Z\u000e\u001fUmWUNR^gJP\u0013Y\u0018wLP\fB\u0018叉栩栨伵佤栧栓佭佬桱\u0015叽栓佭佬厫叺栧佗佭史";
      e[11] = "\u0013*";
      e[12] = "`e\b\u0018\u007fZ~m\u0012W\u0003Nd`\u0011\u0014";
      e[13] = "\u0010\u0011dgwx\u0010\u0011s;{w\nZg&h}\u001aZ`!cbP\"u*)";
      e[14] = "ah|Ll\u001bjgm\u0003\r\u0015aliY";
      e[15] = "E-\be}(\u001f4\u0013<\u0016>/zI;'k/JN8+2\b8I1'j";
      e[16] = "x7J$l\"(a\u0000\u001cA\u0018(f\u001c!gh,<O,\u0002";
      e[17] = "\u0016\u0001\"ET\u0005FWh}s?FPt@_OB\n'M:\u0004BZ(APC\u0016\u0001d}";
      e[18] = "u\u00102F\u0007;u\u0011nIz\u001f\f)Vjzg(KfW\u0018g)\u0017i";
      e[19] = "z9m3y\u001b  vj\u0012\r\u0010n,m#Z\u0010^+n/\u00017,,g#Y";
      e[20] = "\u000bI,\u0006\u0001,QP7_j:a\u001emX[la.j[W6F\\mR[n";
      e[21] = "|\u001dk*-\u001f&\u0004psF\t\u0016J*tvV\u0016z-w{\u00051\b*~w]";
      e[22] = "7?l1!U~+zcPh\u000e`\u007f7\"\u001eck=:,.5g7klDr3l'P";
      e[23] = "\u0000X1\u001f\u0017p\u0000Ym\u0010j^ydOsTq\u0006Wt\u0011TpZX";
      e[24] = "!7\u00117\b*#}\u000ba4伉佃叅厨栕栭伉标叅伶\f\u000b2fv\u0019w\berf";
      e[25] = "\u0013bK\u0006yhI{P_\u0012~y5\nX\" y\u0005\r[/r^w\nR#*";
      e[26] = "|E&3\u00035&\\=jh#\u0016\u0012gmYw\u0016\"`nU/1PggYw";
      e[27] = "\u0007l\u000e\br\u0011]x\u0018\u000e\u0018\u001ea:SN(Ia\nTK%\u0012FxSB)J";
      e[28] = "h!iI5B!5\u007f\u001bDPQ\u007fr\u001b K55`F-9j4:G6] &gJD";
      e[29] = "\u001c!?g@UF5)a*Zzwb!\u001a\fzGe$\u0017V]5b-\u001b\u000e";
      e[30] = "2\u0007\r\tA'{\u0013\u001b[0\u0017\u000bX\u001e\u000fBlfS\\\u0002L\\";
      e[31] = "&[Wi\u000e\foOA;\u007f\u0007\u001f\u0004Do\rGr\u000f\u0006b\u0003w";
      e[32] = "jCd@\u0003)0WrFi&\f\u00159\u0006Vy\f%>\u0003T*+W9\nXr";
      e[33] = "y,#z*ay-\u007fuW\\\n\u0014G\u0016i`\u007f#ftia#,";
      e[34] = "\u0006\u0003i\u0012\u001e\u001aO\u0017\u007f@o桸栦桿佟伥伲桸佢桿佟x_\u001aAZa\u001d\u001d\u0003\\[";
      e[35] = "\u0018to>W\u0004V-i:h桷佹佉叁桝厫伳栽受栛DUW\u0019vr6R^\u0015.";
      e[36] = ".\u0012M@z6`KKDE桅住桫口叹桜桅住伯口:xe/\u0010PH\u007fl#H";
      e[37] = "!c\r_\"\u000fo:\u000b[\u001d厦叞佞厣佸叞厦叞佞桹% \\ a\u0010W'U,9";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 16;
               case 2 -> 21;
               case 3 -> 11;
               case 4 -> 47;
               case 5 -> 13;
               case 6 -> 55;
               case 7 -> 42;
               case 8 -> 51;
               case 9 -> 43;
               case 10 -> 63;
               case 11 -> 22;
               case 12 -> 25;
               case 13 -> 1;
               case 14 -> 50;
               case 15 -> 31;
               case 16 -> 52;
               case 17 -> 59;
               case 18 -> 36;
               case 19 -> 41;
               case 20 -> 3;
               case 21 -> 46;
               case 22 -> 40;
               case 23 -> 18;
               case 24 -> 17;
               case 25 -> 0;
               case 26 -> 61;
               case 27 -> 53;
               case 28 -> 39;
               case 29 -> 7;
               case 30 -> 24;
               case 31 -> 4;
               case 32 -> 44;
               case 33 -> 48;
               case 34 -> 35;
               case 35 -> 57;
               case 36 -> 19;
               case 37 -> 30;
               case 38 -> 5;
               case 39 -> 58;
               case 40 -> 2;
               case 41 -> 14;
               case 42 -> 29;
               case 43 -> 33;
               case 44 -> 26;
               case 45 -> 8;
               case 46 -> 27;
               case 47 -> 28;
               case 48 -> 38;
               case 49 -> 54;
               case 50 -> 34;
               case 51 -> 10;
               case 52 -> 56;
               case 53 -> 49;
               case 54 -> 20;
               case 55 -> 9;
               case 56 -> 62;
               case 57 -> 6;
               case 58 -> 45;
               case 59 -> 23;
               case 60 -> 32;
               case 61 -> 15;
               case 62 -> 12;
               default -> 60;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'a' && var8 != 212 && var8 != 'm' && var8 != 214) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 239) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 170) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'a') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'm') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public static int k(long a, int var2, int n2) {
      a = 友树树何何树树何何树.a ^ a;
      long ax = a ^ 17709188302135L;
      b<"ª">(-7524505251538823268L, (long)a);
      int max = Math.max(var2, n2);
      int min = Math.min(var2, n2);
      return M(min, ax, max);
   }

   public static float k(long a, float endInclusive, float a) {
      a = 友树树何何树树何何树.a ^ a;
      b<"ª">(6362741015342700611L, (long)a);
      if (endInclusive != a) {
         float var10000 = a - endInclusive;
         if (a > 0L) {
            if (var10000 <= 0.0F) {
               return endInclusive;
            }

            var10000 = endInclusive;
         }

         return (float)(var10000 + (a - endInclusive) * Math.random());
      } else {
         return endInclusive;
      }
   }

   public static float t(float a, long a) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:258)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/utils/友树树何何树树何何树.a J
      // 03: lload 1
      // 04: lxor
      // 05: lstore 1
      // 06: ldc2_w -7500604282039003161
      // 09: lload 1
      // 0a: invokedynamic ª (JJ)I bsm=cn/cool/cherish/utils/友树树何何树树何何树.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: pop
      // 10: fload 0
      // 11: ldc_w 90.0
      // 14: fcmpl
      // 15: ifle 1c
      // 18: ldc_w 90.0
      // 1b: freturn
      // 1c: fload 0
      // 1d: ldc_w -90.0
      // 20: fcmpg
      // 21: ifge 28
      // 24: ldc_w -90.0
      // 27: freturn
      // 28: fload 0
      // 29: freturn
   }

   public static float g(float a, int angle, int a, int a) {
      long ax = ((long)angle << 48 | (long)a << 32 >>> 16 | (long)a << 48 >>> 48) ^ 友树树何何树树何何树.a;
      int var10000 = b<"ª">(6518541387076536103L, ax);
      a %= 360.0F;
      int var7 = var10000;
      if (a >= 180.0F) {
         a -= 360.0F;
      }

      float var10 = (float)a;
      if (var7 == 0) {
         if (a < -180.0F) {
            a += 360.0F;
         }

         var10 = (float)a;
      }

      if (b<"ª">(6518133124183935575L, ax)) {
         b<"ª">(++var7, 6518006062197629872L, ax);
      }

      return var10;
   }

   public static float w(float a, long a, float num, float max) {
      a = 友树树何何树树何何树.a ^ a;
      b<"ª">(1491489075521145315L, a);
      return a < num ? num : Math.min((float)a, max);
   }

   public static Vec3 X(AABB a, Direction x, double var2, double var4, long var6, double var8) {
      var6 = 友树树何何树树何何树.a ^ var6;
      double maxA = Math.max(b<"a">(a, 7108395447113084348L, var6), Math.min(var2, b<"a">(a, 7107958699472260745L, var6)));
      Math.max(b<"a">(a, 7108150022960843346L, var6), Math.min(var4, b<"a">(a, 7108599452581551936L, var6)));
      int var10000 = b<"ª">(7108873190443401206L, var6);
      double maxC = Math.max(b<"a">(a, 7108217240571569318L, var6), Math.min(var8, b<"a">(a, 7107717712303458478L, var6)));
      int ax = var10000;
      switch (b<"m">(7108470028549294165L, var6)[x.ordinal()]) {
         case 1:
         case 2:
            double closestY = x == b<"m">(7108230181373633895L, var6) ? b<"a">(a, 7108150022960843346L, var6) : b<"a">(a, 7108599452581551936L, var6);
            var10000 = ax;
            if (var6 >= 0L) {
               if (ax == 0) {
                  return new Vec3(maxA, closestY, maxC);
               }

               var10000 = b<"ª">(7107885074778747526L, var6);
            }

            b<"ª">(var10000 == 0, 7107820476309388183L, var6);
         case 3:
         case 4:
            if (x == b<"m">(7108035219279127628L, var6)) {
               b<"a">(a, 7108217240571569318L, var6);
            } else {
               b<"a">(a, 7107717712303458478L, var6);
            }

            if (var6 > 0L) {
            }
         case 5:
         case 6:
            if (x == b<"m">(7108962912902779314L, var6)) {
               b<"a">(a, 7108395447113084348L, var6);
            } else {
               b<"a">(a, 7107958699472260745L, var6);
            }
         default:
            throw new IllegalArgumentException(a<"s">(13378, 8600649549565386763L ^ var6) + x);
      }
   }

   public static float X(float a, float b) {
      return ((a - b) % 360.0F + 540.0F) % 360.0F - 180.0F;
   }

   public static int M(int a, long min, int a) {
      min = (int)(友树树何何树树何何树.a ^ min);
      return b<"m">(-507557648539682689L, (long)min).nextInt((int)(a - a)) + a;
   }

   public static void N(int var0) {
      树树树友友树何友友何 = var0;
   }

   public static Vec3 P(long a, 树友友友树友友何树何 var2) {
      a = 友树树何何树树何何树.a ^ a;
      return new Vec3(b<"a">(var2, -6829239937488740041L, (long)a), b<"a">(var2, -6829699117138727615L, (long)a), b<"a">(var2, -6829574158990384842L, (long)a));
   }

   public static boolean G(float a, float b, long a) {
      a = 友树树何何树树何何树.a ^ a;
      b<"ª">(521835834690132588L, (long)a);
      return Math.abs(b - a) < 1.0E-5F;
   }

   public static double Q(long a, double var2, double var4) {
      a = 友树树何何树树何何树.a ^ a;
      b<"ª">(-2061348764837036491L, (long)a);
      SecureRandom random = new SecureRandom();
      return random.nextDouble() * (var4 - var2) + var2;
   }

   public static boolean O(float a, float b, long a) {
      a = 友树树何何树树何何树.a ^ a;
      b<"ª">(-5773742829990989872L, a);
      return Math.abs(a - b) < 1.0E-4;
   }

   private static String LIU_YA_FENG() {
      return "解放村多种2队1144号";
   }
}
