package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友树树树树何何友何友 implements 何树友 {
   public static final float 树友何何何友树友何友 = (float) Math.PI;
   public static final float 树友何何树树何何树何 = (float) (Math.PI / 2);
   public static final float 何友何树树何树树树友 = (float) (Math.PI / 4);
   public static final float 树友树何友友友何友友 = (float) (Math.PI * 2);
   private static final float 树友何树友何友何友何 = -0.5F;
   private static final float 树友友树友何树树友何 = 1.5F;
   private static final float 何友何何树何树友树何 = -1.5F;
   private static final float 树何友树何何树何友树 = 0.5F;
   private static final float 树何友何何友何树树友 = 1.0F;
   private static final float 何树友何何友友树树友 = -2.5F;
   private static final float 何友友何何树何友树何 = 2.0F;
   private static final float 友何友树友何何何友树 = -0.5F;
   private static final float 树树何树树何何友何树 = -0.5F;
   private static final float 友友树树友友何树树何 = 0.0F;
   private static final float 何树友友何何友何树何 = 0.5F;
   private static final float 何树友树友何友友树树 = 0.0F;
   private static final float 友何树树友友何友何树 = 0.0F;
   private static final float 何树何何何友树友何友 = 1.0F;
   private static final float 何树树友友友友何何友 = 0.0F;
   private static final float 友何何友何友友何友友 = 0.0F;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[14];
   private static final String[] f = new String[14];
   private static int _解放村多种2队1144号 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8142891433877626291L, 6467631794755150447L, MethodHandles.lookup().lookupClass()).a(55034361381037L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 102570449890837L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = '(';
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "\"9!.lQµ7;þÔ¨N\u000f°ÁÏCÛ4ð\u00101$Hª¶\u000bi%\u0099?á¬Ô¹|\u00ad¿\u0096(\u0082\u0082ìÊïÚ\u0010÷¨\u009e ±\u0082êi\u008ez\u0085h5Ë\u008fcQßRÊ ¸\u001f\u001fÒÌ\u0097O\u0091é&ÏÂ"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 81) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "\"9!.lQµ7;þÔ¨N\u000f°ÁÏCÛ4ð\u00101$Hª¶\u000bi%\u0099?á¬Ô¹|\u00ad¿\u0096(\u0082\u0082ìÊïÚ\u0010÷¨\u009e ±\u0082êi\u008ez\u0085h5Ë\u008fcQßRÊ ¸\u001f\u001fÒÌ\u0097O\u0091é&ÏÂ"
            .charAt(var4);
      }
   }

   public static float B(float a, float a, long var2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/utils/render/友树树树树何何友何友.a J
      // 03: lload 2
      // 04: lxor
      // 05: lstore 2
      // 06: fload 0
      // 07: fconst_1
      // 08: fdiv
      // 09: f2i
      // 0a: istore 6
      // 0c: ldc2_w -5300054196454041851
      // 0f: lload 2
      // 10: invokedynamic Û (JJ)Z bsm=cn/cool/cherish/utils/render/友树树树树何何友何友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 15: fload 0
      // 16: iload 6
      // 18: i2f
      // 19: fload 1
      // 1a: fmul
      // 1b: fsub
      // 1c: fstore 0
      // 1d: pop
      // 1e: fload 0
      // 1f: fconst_0
      // 20: fcmpg
      // 21: ifge 28
      // 24: fload 0
      // 25: fload 1
      // 26: fadd
      // 27: freturn
      // 28: fload 0
      // 29: freturn
   }

   public static float F(long a, float var2, float a, float b) {
      a = 友树树树树何何友何友.a ^ a;
      b<"Û">(3321054097602521249L, (long)a);
      return var2 < 0.0F ? a : (var2 > 1.0F ? b : var2);
   }

   public static int J(int a, long a, int a, int var4) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.AssignmentExprent.toJava(AssignmentExprent.java:154)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:258)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/utils/render/友树树树树何何友何友.a J
      // 03: lload 1
      // 04: lxor
      // 05: lstore 1
      // 06: ldc2_w 5359106053454048040
      // 09: lload 1
      // 0a: invokedynamic Û (JJ)Z bsm=cn/cool/cherish/utils/render/友树树树树何何友何友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: istore 6
      // 11: iload 0
      // 12: iload 3
      // 13: if_icmpge 1a
      // 16: iload 3
      // 17: goto 31
      // 1a: iload 0
      // 1b: iload 6
      // 1d: lload 1
      // 1e: lconst_0
      // 1f: lcmp
      // 20: ifle 28
      // 23: ifeq 2d
      // 26: iload 4
      // 28: if_icmple 30
      // 2b: iload 4
      // 2d: goto 31
      // 30: iload 0
      // 31: ireturn
   }

   public static float e(float a) {
      a = 1.0F - a;
      return (float)Math.sqrt(1.0F - a * a);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/友树树树树何何友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static float n(float a, float t, float a) {
      return t + a * (a - t);
   }

   public static int n(int a) {
      int r = a >> 16 & 0xFF;
      int g = a >> 8 & 0xFF;
      int b = a & 255;
      return (int)(r * 0.299F + g * 0.587F + b * 0.114F);
   }

   public static double h(double a, long var2, double var4) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/utils/render/友树树树树何何友何友.a J
      // 03: lload 2
      // 04: lxor
      // 05: lstore 2
      // 06: ldc2_w 6738872982495313138
      // 09: lload 2
      // 0a: invokedynamic Û (JJ)Z bsm=cn/cool/cherish/utils/render/友树树树树何何友何友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: dload 0
      // 10: dload 4
      // 12: ddiv
      // 13: d2i
      // 14: istore 8
      // 16: pop
      // 17: dload 0
      // 18: iload 8
      // 1a: i2d
      // 1b: dload 4
      // 1d: dmul
      // 1e: dsub
      // 1f: dstore 0
      // 20: dload 0
      // 21: dconst_0
      // 22: dcmpg
      // 23: ifge 2b
      // 26: dload 0
      // 27: dload 4
      // 29: dadd
      // 2a: dreturn
      // 2b: dload 0
      // 2c: dreturn
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/友树树树树何何友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6528;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/render/友树树树树何何友何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static IllegalArgumentException a(IllegalArgumentException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 195 && var8 != 181 && var8 != 224 && var8 != 204) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 217) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 219) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 195) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 181) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 224) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      e[0] = "dyJ;6uk9\u00070<hnd\fv,nn{\u0017v+\u007fis\u0001*w住双佂厯桉厒住佒佂伱";
      e[1] = boolean.class;
      f[1] = "java/lang/Boolean";
      e[2] = "_a $\rzP!m/\u0007gU|fi\u0017aUc}i\u0010pRkk5L叞栭栞栟桖伷佀号佚叅";
      e[3] = "a/PLM\u0000j A\u0003*\u0000g+AL\u000f-y)S@\u0006\u0002\u007f\u000b^N\u0006\u001c\u007f'IC";
      e[4] = "p\b\u000b\u0010<\"\u007fHF\u001b6?z\u0015M]>\"w\u0013I\u0016}\u0000|\u0002P\u001f6";
      e[5] = void.class;
      f[5] = "java/lang/Void";
      e[6] = "Lj\u0003)RBGe\u0012f3LLn\u0016<";
      e[7] = "\u0014$BI5\bCiX\u0011\f-.a\u0005\u0012f\nR9A\r<n";
      e[8] = " N`}j&v\u0019kFOF)\u001ar,w:q^mv\u0013";
      e[9] = "5l\u001eO@\u0000b!\u0004\u0017y/\u000f)Y\u0014\u0013\u0002sq\u001d\u000bIf3(\u0002\u0017\u0010\u0007>m\u001aOy";
      e[10] = "bk\u0000Z\u0003r4<\u000ba4\u0012k?\u0012\u000b\u001en3{\rQz";
      e[11] = "y=\f\u0005\u0011n/j\u0007>\u0003\u000epi\u001eT\fr(-\u0001\u000eh2q2\u001dW\t?4*E>";
      e[12] = "\u0005K\u0013~CDU[\u0011~~C<\u0001Qq\u0015WPJ\u0013qO*\u0006\u000b\bs\u0003FMI\b)~";
      e[13] = "f,|&7\u00041af~\u000e\u000f\\i;}d\u0006 1\u007fb>b";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 56;
               case 1 -> 19;
               case 2 -> 15;
               case 3 -> 43;
               case 4 -> 33;
               case 5 -> 48;
               case 6 -> 38;
               case 7 -> 17;
               case 8 -> 39;
               case 9 -> 61;
               case 10 -> 49;
               case 11 -> 1;
               case 12 -> 47;
               case 13 -> 59;
               case 14 -> 7;
               case 15 -> 4;
               case 16 -> 10;
               case 17 -> 0;
               case 18 -> 21;
               case 19 -> 45;
               case 20 -> 35;
               case 21 -> 60;
               case 22 -> 9;
               case 23 -> 24;
               case 24 -> 40;
               case 25 -> 3;
               case 26 -> 18;
               case 27 -> 50;
               case 28 -> 6;
               case 29 -> 63;
               case 30 -> 57;
               case 31 -> 25;
               case 32 -> 16;
               case 33 -> 30;
               case 34 -> 29;
               case 35 -> 27;
               case 36 -> 13;
               case 37 -> 55;
               case 38 -> 42;
               case 39 -> 51;
               case 40 -> 26;
               case 41 -> 2;
               case 42 -> 22;
               case 43 -> 62;
               case 44 -> 54;
               case 45 -> 8;
               case 46 -> 14;
               case 47 -> 28;
               case 48 -> 44;
               case 49 -> 41;
               case 50 -> 11;
               case 51 -> 53;
               case 52 -> 36;
               case 53 -> 52;
               case 54 -> 31;
               case 55 -> 20;
               case 56 -> 34;
               case 57 -> 46;
               case 58 -> 5;
               case 59 -> 58;
               case 60 -> 23;
               case 61 -> 37;
               case 62 -> 12;
               default -> 32;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static int p(int a, int numKnots, int[] yknots, int[] x, long xknots) {
      xknots = (int[])(友树树树树何何友何友.a ^ xknots);
      int var10000 = b<"Û">(2741270111779233981L, (long)xknots);
      int numSpans = numKnots - 3;
      int ax = (byte)var10000;
      if (numSpans < 1) {
         throw new IllegalArgumentException(a<"h">(9369, 7532340735526902545L ^ xknots));
      } else {
         int span;
         int var10001;
         byte var10002;
         label97: {
            label96: {
               label105: {
                  span = 0;
                  if (0 < numSpans) {
                     do {
                        var10000 = yknots[span + 1];
                        var10001 = (int)a;
                        var10002 = ax;
                        if (xknots < 0L) {
                           break label97;
                        }

                        if (ax != 0) {
                           break label96;
                        }

                        if (var10000 > a) {
                           var10000 = ax;
                           if (xknots < 0L) {
                              break label105;
                           }

                           if (ax == 0) {
                              break;
                           }
                        }

                        span++;
                     } while (xknots < 0L);
                  }

                  var10000 = span;
               }

               var10001 = numKnots - 3;
            }

            var10002 = ax;
         }

         if (var10002 == 0) {
            if (var10000 > var10001) {
               span = numKnots - 3;
            }

            var10000 = (int)a;
            var10001 = yknots[span];
         }

         float t = (float)(var10000 - var10001) / (yknots[span + 1] - yknots[span]);
         if (--span < 0) {
            span = 0;
            t = 0.0F;
         }

         int v = 0;
         int i = 0;

         while (true) {
            if (i < 4) {
               int shift = i * 8;
               float k0 = ((Object[])x)[span] >> shift & 0xFF;
               float k1 = ((Object[])x)[span + 1] >> shift & 0xFF;
               float k2 = ((Object[])x)[span + 2] >> shift & 0xFF;
               float k3 = ((Object[])x)[span + 3] >> shift & 0xFF;
               float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
               float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
               float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
               float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
               int n = (int)(((c3 * t + c2) * t + c1) * t + c0);
               var10000 = n;
               short var28 = ax;
               if (xknots >= 0L) {
                  if (ax != 0) {
                     break;
                  }

                  var28 = ax;
               }

               label70: {
                  label69: {
                     label68: {
                        if (xknots > 0L) {
                           if (var28 == 0) {
                              if (n < 0) {
                                 n = 0;
                                 var10000 = ax;
                                 if (xknots < 0L) {
                                    break label69;
                                 }

                                 if (ax == 0) {
                                    break label68;
                                 }
                              }

                              var10000 = n;
                           }

                           if (xknots < 0L) {
                              break label70;
                           }

                           var28 = 255;
                        }

                        if (var10000 > var28) {
                           n = 255;
                        }
                     }

                     var10000 = v;
                  }

                  v = var10000 | n << shift;
                  i++;
                  var10000 = ax;
               }

               if (var10000 == 0) {
                  continue;
               }
            }

            var10000 = v;
            break;
         }

         return var10000;
      }
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static void t(int[] a, int[] a, int var2, int source, int offset, long stride, float[] length) {
      stride = (int)(友树树树树何何友何友.a ^ stride);
      int destIndex = (int)source;
      int var10000 = b<"Û">(-193242077040501722L, (long)stride);
      int lastIndex = a.length;
      int ax = (byte)var10000;
      float[] in = new float[var2 + 2];
      int i = 0;
      int j = 0;

      while (true) {
         label92:
         if (j < var2) {
            label97: {
               float var47;
               var10000 = (var47 = ((Object[])length)[i + 1] - j) == 0.0F ? 0 : (var47 < 0.0F ? -1 : 1);
               if (stride > 0L) {
                  if (var10000 >= 0) {
                     break label97;
                  }

                  i++;
                  var10000 = ax;
               }

               if (stride <= 0L) {
                  if (var10000 != 0) {
                     continue;
                  }
                  break label92;
               }

               if (var10000 == 0) {
                  if (ax != 0) {
                     continue;
                  }
                  break label92;
               }

               if (stride < 0L) {
                  j++;
                  if (ax != 0) {
                     continue;
                  }
                  break label92;
               }
            }

            in[j] = i + (j - ((Object[])length)[i]) / (((Object[])length)[i + 1] - ((Object[])length)[i]);
            j++;
            if (ax != 0) {
               continue;
            }
         }

         do {
            in[var2] = var2;
            in[var2 + 1] = var2;
            if (stride >= 0L) {
               float inSegment = 1.0F;
               float outSegment = in[1];
               float sizfac = outSegment;
               float bSum = 0.0F;
               float gSum = 0.0F;
               float rSum = 0.0F;
               float aSum = 0.0F;
               int rgb = (int)a[source];
               int axx = rgb >> 24 & 0xFF;
               int r = rgb >> 16 & 0xFF;
               int g = rgb >> 8 & 0xFF;
               int b = rgb & 0xFF;
               int srcIndex = source + offset;
               rgb = (int)a[srcIndex];
               int nextA = rgb >> 24 & 0xFF;
               int nextR = rgb >> 16 & 0xFF;
               int nextG = rgb >> 8 & 0xFF;
               int nextB = rgb & 0xFF;
               srcIndex += offset;
               i = 1;

               while (i <= var2) {
                  label48: {
                     label47: {
                        float aIntensity = inSegment * axx + (1.0F - inSegment) * nextA;
                        float rIntensity = inSegment * r + (1.0F - inSegment) * nextR;
                        float gIntensity = inSegment * g + (1.0F - inSegment) * nextG;
                        float bIntensity = inSegment * b + (1.0F - inSegment) * nextB;
                        float var45 = inSegment;
                        float var10001 = outSegment;
                        if (stride > 0L) {
                           if (inSegment < outSegment) {
                              aSum += aIntensity * inSegment;
                              rSum += rIntensity * inSegment;
                              gSum += gIntensity * inSegment;
                              bSum += bIntensity * inSegment;
                              outSegment -= inSegment;
                              inSegment = 1.0F;
                              axx = nextA;
                              r = nextR;
                              g = nextG;
                              b = nextB;
                              var10000 = srcIndex;
                              if (stride >= 0L) {
                                 if (srcIndex < lastIndex) {
                                    rgb = (int)a[srcIndex];
                                 }

                                 nextA = rgb >> 24 & 0xFF;
                                 nextR = rgb >> 16 & 0xFF;
                                 nextG = rgb >> 8 & 0xFF;
                                 nextB = rgb & 0xFF;
                                 srcIndex += offset;
                                 var10000 = ax;
                              }

                              if (stride <= 0L) {
                                 break label48;
                              }

                              if (var10000 != 0) {
                                 break label47;
                              }
                           }

                           aSum += aIntensity * outSegment;
                           rSum += rIntensity * outSegment;
                           gSum += gIntensity * outSegment;
                           bSum += bIntensity * outSegment;
                           ((Object[])a)[destIndex] = (long)((int)Math.min(aSum / sizfac, 255.0F) << 24
                              | (int)Math.min(rSum / sizfac, 255.0F) << 16
                              | (int)Math.min(gSum / sizfac, 255.0F) << 8
                              | (int)Math.min(bSum / sizfac, 255.0F));
                           destIndex += offset;
                           bSum = 0.0F;
                           gSum = 0.0F;
                           rSum = 0.0F;
                           aSum = 0.0F;
                           inSegment -= outSegment;
                           var45 = in[i + 1];
                           var10001 = in[i];
                        }

                        outSegment = var45 - var10001;
                        sizfac = outSegment;
                        i++;
                     }

                     var10000 = ax;
                  }

                  if (var10000 == 0) {
                     break;
                  }
               }

               return;
            }

            j++;
         } while (ax != 0);
      }
   }

   public static float g(float a, float b1, long a, float b2, float a1, float a2) {
      a = 友树树树树何何友何友.a ^ a;
      b<"Û">(5151438390898541002L, a);
      if (!(a2 < a)) {
         float var12;
         int var10000 = (var12 = a2 - a1) == 0.0F ? 0 : (var12 < 0.0F ? -1 : 1);
         if (a > 0L) {
            if (var10000 >= 0) {
               return 0.0F;
            }

            if (a <= 0L) {
               return a2;
            }

            float var13;
            var10000 = (var13 = a2 - b1) == 0.0F ? 0 : (var13 < 0.0F ? -1 : 1);
         }

         if (var10000 >= 0) {
            float var11 = a2;
            if (a >= 0L) {
               float var10001 = b2;
               if (a >= 0L) {
                  if (a2 < b2) {
                     return 1.0F;
                  }

                  a2 = (a2 - b2) / (a1 - b2);
                  var11 = 1.0F;
                  var10001 = a2 * a2;
               }

               var11 -= var10001 * (3.0F - 2.0F * a2);
            }

            return var11;
         } else {
            a2 = (a2 - a) / (b1 - a);
            return a2 * a2 * (3.0F - 2.0F * a2);
         }
      } else {
         return 0.0F;
      }
   }

   public static float v(float a, float a) {
      return a / ((1.0F / a - 2.0F) * (1.0F - a) + 1.0F);
   }

   public static int v(int a, long a, int var3) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/utils/render/友树树树树何何友何友.a J
      // 03: lload 1
      // 04: lxor
      // 05: lstore 1
      // 06: ldc2_w 4566904634745305559
      // 09: lload 1
      // 0a: invokedynamic Û (JJ)Z bsm=cn/cool/cherish/utils/render/友树树树树何何友何友.b (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: iload 0
      // 10: iload 3
      // 11: idiv
      // 12: istore 6
      // 14: pop
      // 15: iload 0
      // 16: iload 6
      // 18: iload 3
      // 19: imul
      // 1a: isub
      // 1b: istore 0
      // 1c: iload 0
      // 1d: ifge 24
      // 20: iload 0
      // 21: iload 3
      // 22: iadd
      // 23: ireturn
      // 24: iload 0
      // 25: ireturn
   }

   public static int j(float a, int x, long knots, int[] var4) {
      knots = (int[])(友树树树树何何友何友.a ^ knots);
      long ax = knots ^ 16847806825170L;
      int var10000 = b<"Û">(5673224390106361804L, (long)knots);
      int numSpans = (int)(x - 3);
      int axx = (byte)var10000;
      if (numSpans < 1) {
         throw new IllegalArgumentException(a<"h">(9369, 7532328135706375072L ^ knots));
      } else {
         int span;
         label72: {
            a = F(ax, (float)a, 0.0F, 1.0F) * numSpans;
            span = (int)a;
            var10000 = span;
            int var10001 = axx;
            if (knots >= 0L) {
               if (axx == 0) {
                  break label72;
               }

               var10001 = (int)(x - 4);
            }

            if (span > var10001) {
               span = (int)(x - 4);
            }

            a -= span;
            var10000 = 0;
         }

         int v = var10000;
         int i = 0;

         while (true) {
            if (i < 4) {
               int shift = i * 8;
               float k0 = var4[span] >> shift & 0xFF;
               float k1 = var4[span + 1] >> shift & 0xFF;
               float k2 = var4[span + 2] >> shift & 0xFF;
               float k3 = var4[span + 3] >> shift & 0xFF;
               float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
               float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
               float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
               float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
               int n = (int)(((c3 * a + c2) * a + c1) * a + c0);
               var10000 = n;
               short var28 = axx;
               if (knots >= 0L) {
                  if (axx == 0) {
                     break;
                  }

                  var28 = axx;
               }

               label56: {
                  label55: {
                     label54: {
                        if (knots > 0L) {
                           if (var28 != 0) {
                              if (n < 0) {
                                 n = 0;
                                 var10000 = axx;
                                 if (knots < 0L) {
                                    break label55;
                                 }

                                 if (axx != 0) {
                                    break label54;
                                 }
                              }

                              var10000 = n;
                           }

                           if (knots <= 0L) {
                              break label56;
                           }

                           var28 = 255;
                        }

                        if (var10000 > var28) {
                           n = 255;
                        }
                     }

                     var10000 = v;
                  }

                  v = var10000 | n << shift;
                  i++;
                  var10000 = axx;
               }

               if (var10000 != 0) {
                  continue;
               }
            }

            var10000 = v;
            break;
         }

         return var10000;
      }
   }

   public static int q(float a, int t, int rgb2) {
      int a1 = (int)(t >> 24 & 255);
      int r1 = (int)(t >> 16 & 255);
      int g1 = (int)(t >> 8 & 255);
      int b1 = (int)(t & 255);
      int a2 = rgb2 >> 24 & 0xFF;
      int r2 = rgb2 >> 16 & 0xFF;
      int g2 = rgb2 >> 8 & 0xFF;
      int b2 = rgb2 & 0xFF;
      a1 = y((float)a, a1, a2);
      r1 = y((float)a, r1, r2);
      g1 = y((float)a, g1, g2);
      b1 = y((float)a, b1, b2);
      return a1 << 24 | r1 << 16 | g1 << 8 | b1;
   }

   public static float U(float a, long a, float b) {
      a = 友树树树树何何友何友.a ^ a;
      b<"Û">(-292807516353200808L, a);
      float c = (1.0F / b - 2.0F) * (1.0F - 2.0F * a);
      return a < 0.5 ? a / (c + 1.0F) : (c - a) / (c - 1.0F);
   }

   public static int y(float a, int a, int b) {
      return (int)(a + a * (b - a));
   }

   public static void E(int[] a, int p, int offset, long a) {
      a = 友树树树树何何友何友.a ^ a;
      int var10000 = b<"Û">(-758255550332300275L, a);
      offset += 0;
      int i = (int)p;
      int ax = (byte)var10000;

      while (i < offset) {
         int rgb = (int)a[i];
         int axx = rgb >> 24 & 0xFF;
         int r = rgb >> 16 & 0xFF;
         int g = rgb >> 8 & 0xFF;
         int b = rgb & 0xFF;
         var10000 = ax;
         if (a > 0L) {
            if (ax != 0) {
               if (axx != 255) {
                  float f = 255.0F / axx;
                  r = (int)(r * f);
                  g = (int)(g * f);
                  b = (int)(b * f);
                  var10000 = r;
                  short var10001 = 255;
                  byte var10002 = ax;
                  if (a > 0L) {
                     if (ax != 0) {
                        if (r > 255) {
                           r = 255;
                        }

                        var10000 = g;
                        var10001 = 255;
                     }

                     var10002 = ax;
                  }

                  label50: {
                     label67: {
                        if (var10002 != 0) {
                           if (var10000 > var10001) {
                              g = 255;
                           }

                           var10000 = b;
                           var10001 = ax;
                           if (a > 0L) {
                              if (ax == 0) {
                                 break label67;
                              }

                              var10001 = 255;
                           }
                        }

                        if (var10000 <= var10001) {
                           break label50;
                        }

                        var10000 = 255;
                     }

                     b = var10000;
                  }

                  a[i] = axx << 24 | r << 16 | g << 8 | b;
               }

               i++;
            }

            var10000 = ax;
         }

         if (var10000 == 0) {
            break;
         }
      }
   }

   public static float A(float a, float b, float a, long var3) {
      var3 = 友树树树树何何友何友.a ^ var3;
      b<"Û">(9025221461352520759L, var3);
      return !(a < a) && !(a >= b) ? 1.0F : 0.0F;
   }

   public static int X(long a, float y, float nw, int a, int var5, int se, int x) {
      a = 友树树树树何何友何友.a ^ a;
      int a0 = (int)(a >> 24 & 255);
      int r0 = (int)(a >> 16 & 255);
      int g0 = (int)(a >> 8 & 255);
      int b0 = (int)(a & 255);
      int a1 = var5 >> 24 & 0xFF;
      int r1 = var5 >> 16 & 0xFF;
      int g1 = var5 >> 8 & 0xFF;
      int b1 = var5 & 0xFF;
      int a2 = se >> 24 & 0xFF;
      int r2 = se >> 16 & 0xFF;
      int g2 = se >> 8 & 0xFF;
      int b2 = se & 0xFF;
      int a3 = (int)(x >> 24 & 255);
      int r3 = (int)(x >> 16 & 255);
      int g3 = (int)(x >> 8 & 255);
      int b3 = (int)(x & 255);
      float cx = 1.0F - y;
      float cy = 1.0F - nw;
      float m0 = cx * a0 + y * a1;
      float m1 = cx * a2 + y * a3;
      int ax = (int)(cy * m0 + nw * m1);
      m0 = cx * r0 + y * r1;
      m1 = cx * r2 + y * r3;
      b<"Û">(832121977990769403L, (long)a);
      int r = (int)(cy * m0 + nw * m1);
      m0 = cx * g0 + y * g1;
      m1 = cx * g2 + y * g3;
      int g = (int)(cy * m0 + nw * m1);
      m0 = cx * b0 + y * b1;
      m1 = cx * b2 + y * b3;
      int b = (int)(cy * m0 + nw * m1);
      int var10000 = ax << 24 | r << 16 | g << 8 | b;
      b<"Û">(!b<"Û">(833035353736943750L, (long)a), 832047410184821294L, (long)a);
      return var10000;
   }

   public static float X(float a, long yknots, int x, int[] a, int[] var5) {
      yknots = (int[])(友树树树树何何友何友.a ^ yknots);
      int var10000 = b<"Û">(-742521159452814139L, (long)yknots);
      int numSpans = (int)(x - 3);
      int ax = (byte)var10000;
      if (numSpans < 1) {
         throw new IllegalArgumentException(a<"h">(9369, 7532389119195924649L ^ yknots));
      } else {
         int span;
         label59: {
            label63: {
               int var10001;
               label64: {
                  label56: {
                     span = 0;
                     if (0 < numSpans) {
                        do {
                           float var24;
                           var10000 = (var24 = ((Object[])a)[span + 1] - a) == 0.0F ? 0 : (var24 < 0.0F ? -1 : 1);
                           var10001 = ax;
                           if (yknots < 0L) {
                              break label64;
                           }

                           if (ax == 0) {
                              break label56;
                           }

                           if (var10000 > 0) {
                           }

                           span++;
                        } while (yknots < 0L);
                     }

                     var10000 = span;
                  }

                  if (yknots <= 0L) {
                     break label63;
                  }

                  var10001 = (int)(x - 3);
               }

               if (var10000 <= var10001) {
                  break label59;
               }

               var10000 = (int)(x - 3);
            }

            span = var10000;
         }

         float t = (a - ((Object[])a)[span]) / (((Object[])a)[span + 1] - ((Object[])a)[span]);
         if (--span < 0) {
            span = 0;
            t = 0.0F;
         }

         float k0 = var5[span];
         float k1 = var5[span + 1];
         float k2 = var5[span + 2];
         float k3 = var5[span + 3];
         float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
         float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
         float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
         float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
         float var22 = ((c3 * t + c2) * t + c1) * t + c0;
         byte var23 = b<"Û">(-742176691611354676L, (long)yknots);
         if (yknots >= 0L) {
            if (var23 != 0) {
               return var22;
            }

            var23 = ax;
         }

         b<"Û">(var23 == 0, -742251002161430646L, (long)yknots);
         return var22;
      }
   }

   public static float L(float a) {
      return 1.0F - (float)Math.sqrt(1.0F - a * a);
   }

   public static float P(long a, float x, float a) {
      a = 友树树树树何何友何友.a ^ a;
      b<"Û">(2190116952591505619L, (long)a);
      return a < x ? 0.0F : 1.0F;
   }

   public static void W(int[] a, long p, int length, int a) {
      p = (int[])(友树树树树何何友何友.a ^ p);
      b<"Û">(-4782841571249046744L, (long)p);
      a += 0;
      if (length < a) {
         int rgb = (int)a[length];
         int ax = rgb >> 24 & 0xFF;
         int r = rgb >> 16 & 0xFF;
         int g = rgb >> 8 & 0xFF;
         int b = rgb & 0xFF;
         float f = ax * 0.003921569F;
         r = (int)(r * f);
         g = (int)(g * f);
         b = (int)(b * f);
         a[length] = ax << 24 | r << 16 | g << 8 | b;
         int i = length + 1;
      }
   }

   public static float W(long a, float x, float a, float var4) {
      a = 友树树树树何何友何友.a ^ a;
      b<"Û">(4055548360858491199L, (long)a);
      if (var4 < x) {
         return 0.0F;
      } else {
         float var10000 = var4;
         if (a >= 0L) {
            if (var4 >= a) {
               return 1.0F;
            }

            var4 = (var4 - x) / (a - x);
            var10000 = var4 * var4 * (3.0F - 2.0F * var4);
         }

         return var10000;
      }
   }

   public static float Q(long a, float var2) {
      a = 友树树树树何何友何友.a ^ a;
      long ax = a ^ 19784206090642L;
      b<"Û">(-3053639915684776728L, (long)a);
      float r = B(var2, 1.0F, ax);
      return 2.0F * (r < 0.5 ? r : 1.0F - r);
   }

   public static float O(float a, long knots, int numKnots, float[] a) {
      knots = (float[])(友树树树树何何友何友.a ^ knots);
      long ax = (long)(knots ^ 131679176880280L);
      int var10000 = b<"Û">(4391433229727840838L, (long)knots);
      int numSpans = numKnots - 3;
      int axx = (byte)var10000;
      if (numSpans < 1) {
         throw new IllegalArgumentException(a<"h">(16287, (long)(3612512205863852781L ^ knots)));
      } else {
         int span;
         label24: {
            a = F(ax, (float)a, 0.0F, 1.0F) * numSpans;
            span = (int)a;
            var10000 = axx;
            if (knots >= 0L) {
               if (axx != 0) {
                  break label24;
               }

               var10000 = span;
            }

            if (var10000 > numKnots - 4) {
               span = numKnots - 4;
            }

            a -= span;
         }

         float k0 = (float)((Object[])a)[span];
         float k1 = (float)((Object[])a)[span + 1];
         float k2 = (float)((Object[])a)[span + 2];
         float k3 = (float)((Object[])a)[span + 3];
         float c3 = -0.5F * k0 + 1.5F * k1 + -1.5F * k2 + 0.5F * k3;
         float c2 = 1.0F * k0 + -2.5F * k1 + 2.0F * k2 + -0.5F * k3;
         float c1 = -0.5F * k0 + 0.0F * k1 + 0.5F * k2 + 0.0F * k3;
         float c0 = 0.0F * k0 + 1.0F * k1 + 0.0F * k2 + 0.0F * k3;
         return ((c3 * a + c2) * a + c1) * a + c0;
      }
   }

   private static String HE_SHU_YOU() {
      return "何大伟：我要教育何炜霖";
   }
}
