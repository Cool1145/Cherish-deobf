package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Point2D.Double;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.Kernel;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树树何树何友友友友友 extends 何何树友友何友何友树 implements 何树友 {
   public static int 树树友树友何树树何树;
   public static int 何友友树何树友树何友;
   public static int 何何友友何友何树何树;
   protected Kernel 树何友树何友友友友何;
   protected boolean 树何何友友树友树何何;
   protected boolean 树树树友友何树何友何;
   private int 友友友何树友何友树树;
   private static final long b;
   private static final String d;
   private static final Object[] h = new Object[17];
   private static final String[] i = new String[17];
   private static String HE_JIAN_GUO;

   public 树树何树何友友友友友(long a, Kernel kernel) {
      a = 38376574155497L ^ a;
      super();
      b<"J">(this, null, -5146749747311216342L, a);
      b<"J">(this, true, -5146452993558884435L, a);
      b<"J">(this, true, -5146021674363355086L, a);
      b<"J">(this, b<"W">(-5146170416267908583L, a), -5146130080839649146L, a);
      b<"J">(this, kernel, -5146749747311216342L, a);
   }

   public 树树何树何友友友友友(int rows, int cols, float[] matrix, long a) {
      long ax = 38376574155497L ^ a ^ 17638043405951L;
      this(ax, new Kernel(cols, rows, matrix));
   }

   public 树树何树何友友友友友(float[] matrix, long a) {
      long ax = 38376574155497L ^ a ^ 52093511073729L;
      this(ax, new Kernel(3, 3, matrix));
   }

   public 树树何树何友友友友友(char a, long a) {
      long ax = ((long)a << 48 | a << 16 >>> 16) ^ 38376574155497L ^ 64506255240438L;
      this(new float[9], ax);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8740277672484569017L, -2346500781969769869L, MethodHandles.lookup().lookupClass()).a(55104096939401L);
      // $VF: monitorexit
      b = var10000;
      b();
      Cipher var7;
      Cipher var9 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(37451392894907L << var8 * 8 >>> 56);
      }

      var9.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var12 = a(var7.doFinal("\u0089å°\u000fÔh 7\u0018\u0015ít\u001a?ô\u0015¬f¡Üÿ k\"".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      d = var12;
      Cipher var2;
      Cipher var10 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(37451392894907L << var3 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var6 = var2.doFinal(new byte[]{-58, -85, 56, 0, -1, -128, 42, -36});
      long var14 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      var10001 = -1;
      long var0 = var14;
      树树友树友何树树何树 = 0;
      何友友树何树友树何友 = 1;
      何何友友何友何树何树 = (int)var0;
   }

   @Override
   public String toString() {
      return "Blur/Convolve...";
   }

   public boolean B(long a) {
      a = 38376574155497L ^ a;
      return b<"G">(this, -6877405924417497047L, (long)a);
   }

   public void F(long a, int kernel, Kernel a) {
      long ax = (a << 16 | (long)kernel << 48 >>> 48) ^ 38376574155497L;
      b<"J">(this, a, -5641026284933812210L, ax);
   }

   public static void V(Kernel a, int[] height, int[] kernel, int a, int var4, boolean inPixels, long edgeAction, int width) {
      何何友何友何树树树友.q();
      if (a.getHeight() == 1) {
         c(a, (int[])height, (int[])kernel, (int)a, var4, true, width, 13891677507025L);
      }

      if (a.getWidth() == 1) {
         k(a, (int[])height, (int[])kernel, (int)a, var4, (boolean)inPixels, width, 107822655912838L);
      }

      z(a, (int[])height, (int[])kernel, 3244092800711L, (int)a, var4, (boolean)inPixels, width);
   }

   public void e(long a, boolean a) {
      a = 38376574155497L ^ a;
      b<"J">(this, (boolean)a, -1786687969251487731L, (long)a);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 13;
               case 1 -> 63;
               case 2 -> 48;
               case 3 -> 55;
               case 4 -> 51;
               case 5 -> 49;
               case 6 -> 23;
               case 7 -> 50;
               case 8 -> 40;
               case 9 -> 52;
               case 10 -> 41;
               case 11 -> 53;
               case 12 -> 27;
               case 13 -> 6;
               case 14 -> 8;
               case 15 -> 24;
               case 16 -> 31;
               case 17 -> 33;
               case 18 -> 26;
               case 19 -> 16;
               case 20 -> 15;
               case 21 -> 7;
               case 22 -> 18;
               case 23 -> 37;
               case 24 -> 1;
               case 25 -> 10;
               case 26 -> 60;
               case 27 -> 5;
               case 28 -> 4;
               case 29 -> 35;
               case 30 -> 47;
               case 31 -> 17;
               case 32 -> 38;
               case 33 -> 58;
               case 34 -> 11;
               case 35 -> 56;
               case 36 -> 21;
               case 37 -> 43;
               case 38 -> 62;
               case 39 -> 12;
               case 40 -> 54;
               case 41 -> 14;
               case 42 -> 3;
               case 43 -> 25;
               case 44 -> 30;
               case 45 -> 39;
               case 46 -> 28;
               case 47 -> 22;
               case 48 -> 36;
               case 49 -> 61;
               case 50 -> 59;
               case 51 -> 19;
               case 52 -> 20;
               case 53 -> 32;
               case 54 -> 29;
               case 55 -> 0;
               case 56 -> 34;
               case 57 -> 9;
               case 58 -> 42;
               case 59 -> 45;
               case 60 -> 44;
               case 61 -> 46;
               case 62 -> 57;
               default -> 2;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'G' && var8 != 'J' && var8 != 'W' && var8 != 'C') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 216) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'g') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'G') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'J') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'W') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void b() {
      h[0] = "uHL<\u0004<z\b\u00017\u000e!\u007fU\nq\u001e'\u007fJ\u0011q\u00196xB\u0007-E桂标佳桳伊厠厘叝叭厩";
      h[1] = int.class;
      i[1] = "java/lang/Integer";
      h[2] = boolean.class;
      i[2] = "java/lang/Boolean";
      h[3] = "N2MF\b\u001eS'\u0015NK\u001eC6\u0015lC\rJ6W";
      h[4] = "2\t~\ne\\9\u0006oE\u0019E6\u001ca\u0006.u \u000bm\u001b?Y7\u0006";
      h[5] = "}\u001dk\u000e.\u0012r]&\u0005$\u000fw\u0000-C4\tw\u001f6C3\u0018p\u0017 \u001fo伨佋厸伐厦伔桬栏桢厎";
      h[6] = "{\t\u0005\u0013!\u001ep\u0006\u0014\\@\u0010{\r\u0010\u0006";
      h[7] = "#s\u0007krXsv\u0007\u000e伐伺叚叔伣反伐桾佄栎~v2\u001d(lC3q^";
      h[8] = "1\u000b\u000fG*1a\u000e\u000f\"佈反又桶伫栻取栗佖厬vZjt:\u0014K\u001f)7";
      h[9] = "J9\u000bzl[\u001a<\u000b\u001f厐厧厳伀桫叜伎厧桩桄rg,\u001eA&O\"o]";
      h[10] = "&/<gd0v*<\u0002桂栖栅厈历佟桂佒叟伖E8aw\"-~rdqu";
      h[11] = "+F\"&d'{P5;\u0001%\u0010Z,10<-\u001for\u0001";
      h[12] = "\u0011\u001e7\nQ\u0005A\u001b7o桷佧佶厹厍桶厭栣佶伧NUTB\u0015\u001cu\u001fQDB";
      h[13] = "\t2\\\"\u0004RY7\\GRm\biI\"\u0000\u0000\u00020\\~;V\f:@|V\\U/\u001cG";
      h[14] = "J\n\u0019('\u0006\u001a\u001c\u000e5B\u001fq\u0016\u0017?s\u001dLST|B";
      h[15] = "&\u000bP\u001dO\u0014v\u000ePx桩栲叟桶只伥桩栲佁桶)\u0000\u000fQ-\u0014\u0014EL\u0012";
      h[16] = "\np_\\d:Zu_9桂佘右栍佻叺厘叆右佉&\u0003d>N(\u0018P!}\u000e";
   }

   public int b(long a) {
      a = 38376574155497L ^ a;
      return b<"G">(this, -1494321083877954736L, (long)a);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/树树何树何友友友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   // $VF: Irreducible bytecode has more than 5 nodes in sequence and was not entirely decomposed
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public static void c(Kernel a, int[] edgeAction, int[] a, int var3, int width, boolean kernel, int outPixels, long inPixels) {
      inPixels = (int[])(38376574155497L ^ inPixels);
      long ax = inPixels ^ 133928488473861L;
      int var10000 = b<"g">(3979966825005698860L, (long)inPixels);
      int index = 0;
      float[] matrix = a.getKernelData(null);
      int cols = a.getWidth();
      int axx = var10000;
      int cols2 = cols / 2;
      int y = 0;

      while (true) {
         while (y < width || inPixels <= 0L) {
            do {
               int ioffset = y * var3;
               int x = 0;
               if (0 < var3) {
                  float r = 0.0F;
                  float g = 0.0F;
                  float b = 0.0F;
                  float axxx = 0.0F;
                  int moffset = cols2;
                  int col = -cols2;

                  label151: {
                     int var10001;
                     while (true) {
                        if (col <= cols2) {
                           float f = matrix[moffset + col];
                           var10000 = axx;
                           if (inPixels >= 0L) {
                              if (axx == 0) {
                                 float var42;
                                 var10000 = (var42 = f - 0.0F) == 0.0F ? 0 : (var42 < 0.0F ? -1 : 1);
                                 var10001 = axx;
                                 if (inPixels <= 0L) {
                                    break;
                                 }

                                 if (axx != 0) {
                                    var10001 = axx;
                                    break;
                                 }

                                 if (var10000 == 0) {
                                    col++;
                                    var10000 = axx;
                                 } else {
                                    label129: {
                                       int ix;
                                       label155: {
                                          ix = 0 + col;
                                          var10000 = ix;
                                          var10001 = axx;
                                          if (inPixels >= 0L) {
                                             if (axx == 0) {
                                                if (ix < 0) {
                                                   if (outPixels == b<"W">(3979517528746337718L, (long)inPixels)) {
                                                      ix = 0;
                                                      var10000 = axx;
                                                      if (inPixels > 0L) {
                                                         if (axx == 0) {
                                                            break label155;
                                                         }

                                                         var10000 = (int)outPixels;
                                                      }
                                                   } else {
                                                      var10000 = (int)outPixels;
                                                   }

                                                   if (var10000 != b<"W">(3979444914491410448L, (long)inPixels)) {
                                                      break label155;
                                                   }

                                                   ix = (0 + var3) % var3;
                                                   var10000 = axx;
                                                   if (inPixels > 0L) {
                                                      if (axx == 0) {
                                                         break label155;
                                                      }

                                                      var10000 = ix;
                                                      var10001 = axx;
                                                   } else {
                                                      var10001 = axx;
                                                   }
                                                } else {
                                                   var10000 = ix;
                                                   var10001 = axx;
                                                }
                                             } else {
                                                var10001 = axx;
                                             }
                                          }

                                          if (inPixels > 0L) {
                                             if (var10001 != 0) {
                                                break label129;
                                             }

                                             var10001 = var3;
                                          }

                                          label112:
                                          if (var10000 >= var10001) {
                                             if (outPixels == b<"W">(3979517528746337718L, (long)inPixels)) {
                                                ix = var3 - 1;
                                                var10000 = axx;
                                                if (inPixels > 0L) {
                                                   if (axx == 0) {
                                                      break label112;
                                                   }

                                                   var10000 = (int)outPixels;
                                                }
                                             } else {
                                                var10000 = (int)outPixels;
                                             }

                                             if (var10000 == b<"W">(3979444914491410448L, (long)inPixels)) {
                                                ix = (0 + var3) % var3;
                                             }
                                          }
                                       }

                                       var10000 = ((Object[])edgeAction)[ioffset + ix];
                                    }

                                    int rgb = var10000;
                                    axxx += f * (rgb >> 24 & 0xFF);
                                    r += f * (rgb >> 16 & 0xFF);
                                    g += f * (rgb >> 8 & 0xFF);
                                    b += f * (rgb & 0xFF);
                                    col++;
                                    var10000 = axx;
                                 }
                              } else {
                                 var10000 = axx;
                              }
                           }

                           if (var10000 == 0) {
                              continue;
                           }
                        }

                        if (inPixels < 0L) {
                           break label151;
                        }

                        var10000 = (int)kernel;
                        var10001 = axx;
                        break;
                     }

                     if (var10001 == 0) {
                        var10000 = var10000 != 0 ? 何何友何友何树树树友.q(ax, (int)(axxx + 0.5)) : 255;
                     }

                     col = var10000;
                  }

                  int ir = 何何友何友何树树树友.q(ax, (int)(r + 0.5));
                  int ig = 何何友何友何树树树友.q(ax, (int)(g + 0.5));
                  int ib = 何何友何友何树树树友.q(ax, (int)(b + 0.5));
                  ((Object[])a)[index++] = (long)(col << 24 | ir << 16 | ig << 8 | ib);
                  x++;
               }

               y++;
            } while (inPixels < 0L || axx == 0 || inPixels <= 0L);

            return;
         }

         return;
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public Kernel h(long a) {
      a = 38376574155497L ^ a;
      return b<"G">(this, -2724004144758875253L, (long)a);
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   public boolean a(long a) {
      a = 38376574155497L ^ a;
      return b<"G">(this, 1345539096112260501L, (long)a);
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   @Override
   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
      int width = src.getWidth();
      何何友何友何树树树友.q();
      int height = src.getHeight();
      if (dst == null) {
         dst = this.createCompatibleDestImage(src, null);
      }

      int[] inPixels = new int[width * height];
      int[] outPixels = new int[width * height];
      Object[] var10009 = new Object[]{null, null, null, null, null, height, inPixels};
      var10009[4] = width;
      var10009[3] = 0;
      var10009[2] = 0;
      var10009[1] = src;
      var10009[0] = 55271767695490L;
      this.D(var10009);
      if (this.树树树友友何树何友何) {
         何树何树何何友友树友.l(inPixels, 0, inPixels.length, 67654678660012L);
      }

      V(this.树何友树何友友友友何, inPixels, outPixels, width, height, this.树何何友友树友树何何, 44085112321504L, this.友友友何树友何友树树);
      if (this.树树树友友何树何友何) {
         何树何树何何友友树友.e(2703856022367L, outPixels, 0, outPixels.length);
      }

      var10009 = new Object[]{null, null, null, null, null, height, outPixels};
      var10009[4] = width;
      var10009[3] = 0;
      var10009[2] = 0;
      var10009[1] = dst;
      var10009[0] = 46216504335066L;
      this.X(var10009);
      return dst;
   }

   public void p(long a, boolean var3) {
      a = 38376574155497L ^ a;
      b<"J">(this, var3, 1079117346451568222L, (long)a);
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   // $VF: Irreducible bytecode has more than 5 nodes in sequence and was not entirely decomposed
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public static void k(Kernel a, int[] a, int[] var2, int edgeAction, int alpha, boolean inPixels, int outPixels, long width) {
      width = (int)(38376574155497L ^ width);
      long ax = width ^ 25824101229394L;
      int index = 0;
      float[] matrix = a.getKernelData(null);
      int rows = a.getHeight();
      int var10000 = b<"g">(4714354083121052027L, (long)width);
      int rows2 = rows / 2;
      int y = 0;
      int axx = var10000;

      while (true) {
         while (y < alpha || width < 0L) {
            do {
               int x = 0;
               if (0 < edgeAction) {
                  float r = 0.0F;
                  float g = 0.0F;
                  float b = 0.0F;
                  float axxx = 0.0F;
                  int row = -rows2;

                  label191: {
                     int var10001;
                     while (true) {
                        if (row <= rows2) {
                           int iy = y + row;
                           var10000 = iy;
                           var10001 = axx;
                           if (width < 0L) {
                              break;
                           }

                           if (axx != 0) {
                              var10001 = axx;
                              break;
                           }

                           int ioffset;
                           label194: {
                              var10001 = axx;
                              if (width > 0L) {
                                 if (axx == 0 && width > 0L) {
                                    if (iy < 0) {
                                       var10000 = (int)outPixels;
                                       var10001 = b<"W">(4714557054952920033L, (long)width);
                                       int var10002 = axx;
                                       if (width >= 0L) {
                                          if (axx == 0) {
                                             if (outPixels == var10001) {
                                                ioffset = 0;
                                                var10000 = axx;
                                                if (width >= 0L) {
                                                   if (axx == 0) {
                                                      break label194;
                                                   }

                                                   var10000 = (int)outPixels;
                                                }
                                             } else {
                                                var10000 = (int)outPixels;
                                             }

                                             var10001 = b<"W">(4714911068355608135L, (long)width);
                                             var10002 = axx;
                                          } else {
                                             var10002 = axx;
                                          }
                                       }

                                       if (var10002 == 0) {
                                          if (var10000 == var10001) {
                                             ioffset = (y + alpha) % alpha * edgeAction;
                                             var10000 = axx;
                                             if (width >= 0L) {
                                                if (axx == 0) {
                                                   break label194;
                                                }

                                                var10000 = iy;
                                                var10001 = edgeAction;
                                             } else {
                                                var10001 = edgeAction;
                                             }
                                          } else {
                                             var10000 = iy;
                                             var10001 = edgeAction;
                                          }
                                       }

                                       ioffset = var10000 * var10001;
                                       var10000 = axx;
                                       if (width >= 0L) {
                                          if (axx == 0) {
                                             break label194;
                                          }

                                          var10000 = iy;
                                       }
                                    } else {
                                       var10000 = iy;
                                    }
                                 }

                                 if (width < 0L) {
                                    ioffset = var10000;
                                    break label194;
                                 }

                                 var10001 = alpha;
                              }

                              if (var10000 >= var10001) {
                                 var10000 = (int)outPixels;
                                 var10001 = b<"W">(4714557054952920033L, (long)width);
                                 int var43 = axx;
                                 if (width >= 0L) {
                                    if (axx == 0) {
                                       if (outPixels == var10001) {
                                          ioffset = (alpha - 1) * edgeAction;
                                          var10000 = axx;
                                          if (width >= 0L) {
                                             if (axx == 0) {
                                                break label194;
                                             }

                                             var10000 = (int)outPixels;
                                          }
                                       } else {
                                          var10000 = (int)outPixels;
                                       }

                                       var10001 = b<"W">(4714911068355608135L, (long)width);
                                       var43 = axx;
                                    } else {
                                       var43 = axx;
                                    }
                                 }

                                 if (var43 == 0) {
                                    if (var10000 == var10001) {
                                       ioffset = (y + alpha) % alpha * edgeAction;
                                       var10000 = axx;
                                       if (width > 0L) {
                                          if (axx == 0) {
                                             break label194;
                                          }

                                          var10000 = iy;
                                          var10001 = edgeAction;
                                       } else {
                                          var10001 = edgeAction;
                                       }
                                    } else {
                                       var10000 = iy;
                                       var10001 = edgeAction;
                                    }
                                 }

                                 ioffset = var10000 * var10001;
                                 var10000 = axx;
                                 if (width >= 0L) {
                                    if (axx == 0) {
                                       break label194;
                                    }

                                    var10000 = iy;
                                 }
                              } else {
                                 var10000 = iy;
                              }

                              ioffset = var10000 * edgeAction;
                           }

                           float f = matrix[row + rows2];
                           var10000 = axx;
                           if (width >= 0L) {
                              if (axx == 0) {
                                 if (f != 0.0F) {
                                    int rgb = (int)((Object[])a)[ioffset + 0];
                                    axxx += f * (rgb >> 24 & 0xFF);
                                    r += f * (rgb >> 16 & 0xFF);
                                    g += f * (rgb >> 8 & 0xFF);
                                    b += f * (rgb & 0xFF);
                                 }

                                 row++;
                              }

                              var10000 = axx;
                           }

                           if (var10000 == 0) {
                              continue;
                           }
                        }

                        if (width < 0L) {
                           break label191;
                        }

                        var10000 = (int)inPixels;
                        var10001 = axx;
                        break;
                     }

                     if (var10001 == 0) {
                        var10000 = var10000 != 0 ? 何何友何友何树树树友.q(ax, (int)(axxx + 0.5)) : 255;
                     }

                     row = var10000;
                  }

                  int ir = 何何友何友何树树树友.q(ax, (int)(r + 0.5));
                  int ig = 何何友何友何树树树友.q(ax, (int)(g + 0.5));
                  int ib = 何何友何友何树树树友.q(ax, (int)(b + 0.5));
                  var2[index++] = row << 24 | ir << 16 | ig << 8 | ib;
                  x++;
               }

               y++;
            } while (width <= 0L || axx == 0 || width < 0L);

            return;
         }

         return;
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static void z(Kernel a, int[] inPixels, int[] height, long alpha, int outPixels, int a, boolean var7, int kernel) {
      alpha = (boolean)(38376574155497L ^ alpha);
      long ax = alpha ^ 131527426205203L;
      int index = 0;
      int var10000 = b<"g">(4912759706892811322L, (long)alpha);
      float[] matrix = a.getKernelData(null);
      int axx = var10000;
      int rows = a.getHeight();
      int cols = a.getWidth();
      int rows2 = rows / 2;
      int cols2 = cols / 2;
      int y = 0;

      label245:
      while (true) {
         var10000 = y;

         label243:
         while (true) {
            int x;
            int var10001;
            if (var10000 < a) {
               x = 0;
               var10000 = 0;
               var10001 = (int)outPixels;
            } else {
               if (alpha >= 0L) {
                  return;
               }

               x = 0;
               var10000 = 0;
               var10001 = (int)outPixels;
            }

            label241:
            while (true) {
               if (var10000 >= var10001) {
                  y++;
                  var10000 = axx;
                  if (alpha < 0L) {
                     break;
                  }

                  if (axx == 0) {
                     continue label245;
                  }
               } else {
                  float r = 0.0F;
                  float g = 0.0F;
                  float b = 0.0F;
                  float axxx = 0.0F;
                  int row = -rows2;
                  var10000 = row;
                  var10001 = rows2;

                  while (true) {
                     if (var10000 <= var10001) {
                        int iy = y + row;
                        var10000 = 0;
                        var10001 = iy;
                        int var10002 = axx;

                        label230:
                        while (true) {
                           if (var10002 != 0) {
                              continue label241;
                           }

                           var10002 = axx;
                           if (alpha > 0L) {
                              int ioffset;
                              int moffset;
                              int col;
                              label252: {
                                 label253: {
                                    if (axx == 0) {
                                       if (var10000 <= var10001) {
                                          var10000 = iy;
                                          var10001 = (int)a;
                                          var10002 = axx;
                                          if (alpha > 0L) {
                                             if (axx == 0) {
                                                if (iy < a) {
                                                   ioffset = iy * outPixels;
                                                   if (alpha <= 0L) {
                                                      moffset = axx;
                                                      col = -cols2;
                                                      break label252;
                                                   }

                                                   if (axx == 0) {
                                                      break label253;
                                                   }

                                                   var10000 = (int)kernel;
                                                   var10001 = b<"W">(4912328002280543904L, (long)alpha);
                                                   var10002 = axx;
                                                } else {
                                                   var10000 = (int)kernel;
                                                   var10001 = b<"W">(4912328002280543904L, (long)alpha);
                                                   var10002 = axx;
                                                }
                                             } else {
                                                var10002 = axx;
                                             }
                                          }
                                       } else {
                                          var10000 = (int)kernel;
                                          var10001 = b<"W">(4912328002280543904L, (long)alpha);
                                          var10002 = axx;
                                       }
                                    } else {
                                       var10002 = axx;
                                    }

                                    if (alpha > 0L) {
                                       if (var10002 == 0) {
                                          if (var10000 == var10001) {
                                             ioffset = y * outPixels;
                                             if (alpha <= 0L) {
                                                moffset = axx;
                                                col = -cols2;
                                                break label252;
                                             }

                                             if (axx == 0) {
                                                break label253;
                                             }

                                             var10000 = (int)kernel;
                                             var10001 = b<"W">(4913385695101434630L, (long)alpha);
                                             var10002 = axx;
                                          } else {
                                             var10000 = (int)kernel;
                                             var10001 = b<"W">(4913385695101434630L, (long)alpha);
                                             var10002 = axx;
                                          }
                                       } else {
                                          var10002 = axx;
                                       }
                                    }

                                    if (var10002 == 0) {
                                       if (var10000 != var10001) {
                                          break;
                                       }

                                       ioffset = (int)((iy + a) % a * outPixels);
                                    } else {
                                       ioffset = var10000 * var10001;
                                    }
                                 }

                                 moffset = cols * (row + rows2) + cols2;
                                 col = -cols2;
                              }

                              while (true) {
                                 if (col > cols2) {
                                    break label230;
                                 }

                                 float f = matrix[moffset + col];
                                 var10000 = axx;
                                 if (alpha > 0L) {
                                    if (axx == 0) {
                                       float var49;
                                       var10000 = (var49 = f - 0.0F) == 0.0F ? 0 : (var49 < 0.0F ? -1 : 1);
                                       if (alpha <= 0L) {
                                          var10001 = iy;
                                          var10002 = axx;
                                          break;
                                       }

                                       label221:
                                       if (var10000 != 0) {
                                          int ix;
                                          label259: {
                                             ix = 0 + col;
                                             var10000 = 0;
                                             var10001 = ix;
                                             var10002 = axx;
                                             if (alpha > 0L) {
                                                if (axx == 0) {
                                                   if (0 <= ix) {
                                                      if (ix < outPixels) {
                                                         break label259;
                                                      }

                                                      var10000 = (int)kernel;
                                                      var10001 = b<"W">(4912328002280543904L, (long)alpha);
                                                      var10002 = axx;
                                                   } else {
                                                      var10000 = (int)kernel;
                                                      var10001 = b<"W">(4912328002280543904L, (long)alpha);
                                                      var10002 = axx;
                                                   }
                                                } else {
                                                   var10002 = axx;
                                                }
                                             }

                                             if (alpha >= 0L) {
                                                if (var10002 == 0) {
                                                   if (var10000 == var10001) {
                                                      ix = 0;
                                                      var10000 = axx;
                                                      if (alpha > 0L) {
                                                         if (axx == 0) {
                                                            break label259;
                                                         }

                                                         var10000 = (int)kernel;
                                                         var10001 = b<"W">(4913385695101434630L, (long)alpha);
                                                         var10002 = axx;
                                                      } else {
                                                         var10001 = b<"W">(4913385695101434630L, (long)alpha);
                                                         var10002 = axx;
                                                      }
                                                   } else {
                                                      var10000 = (int)kernel;
                                                      var10001 = b<"W">(4913385695101434630L, (long)alpha);
                                                      var10002 = axx;
                                                   }
                                                } else {
                                                   var10002 = axx;
                                                }
                                             }

                                             if (var10002 == 0) {
                                                if (var10000 != var10001) {
                                                   col++;
                                                   var10000 = axx;
                                                   break label221;
                                                }

                                                ix = (0 + outPixels) % outPixels;
                                             } else {
                                                ix = var10000 % var10001;
                                             }
                                          }

                                          int rgb = inPixels[ioffset + ix];
                                          axxx += f * (rgb >> 24 & 0xFF);
                                          r += f * (rgb >> 16 & 0xFF);
                                          g += f * (rgb >> 8 & 0xFF);
                                          b += f * (rgb & 0xFF);
                                          col++;
                                          var10000 = axx;
                                       } else {
                                          col++;
                                          var10000 = axx;
                                       }
                                    } else {
                                       var10000 = axx;
                                    }
                                 }

                                 if (var10000 != 0) {
                                    break label230;
                                 }
                              }
                           }
                        }

                        row++;
                        var10000 = axx;
                        if (alpha < 0L) {
                           var10001 = rows2;
                           continue;
                        }

                        if (axx == 0) {
                           var10000 = row;
                           var10001 = rows2;
                           continue;
                        }
                     }

                     var10000 = var7;
                     var10001 = axx;
                     if (alpha >= 0L) {
                        if (axx == 0) {
                           var10000 = var7 != 0 ? 何何友何友何树树树友.q(ax, (int)(axxx + 0.5)) : 255;
                        }

                        row = var10000;
                        int ir = 何何友何友何树树树友.q(ax, (int)(r + 0.5));
                        int ig = 何何友何友何树树树友.q(ax, (int)(g + 0.5));
                        int ib = 何何友何友何树树树友.q(ax, (int)(b + 0.5));
                        ((Object[])height)[index++] = row << 24 | ir << 16 | ig << 8 | ib;
                        x++;
                        y++;
                        var10000 = axx;
                        if (alpha < 0L) {
                           continue label243;
                        }

                        if (axx == 0) {
                           continue label245;
                        }
                        break;
                     }
                  }
               }

               if (alpha >= 0L) {
                  return;
               }

               x = 0;
               var10000 = 0;
               var10001 = (int)outPixels;
            }
         }
      }
   }

   public static void w(Kernel a, int[] height, long edgeAction, int[] a, int var5, int width, int kernel) {
      long ax = 38376574155497L ^ edgeAction ^ 109481559520616L;
      V(a, (int[])height, (int[])a, var5, width, true, ax, (int)kernel);
   }

   public void M(long a, int var3) {
      a = 38376574155497L ^ a;
      b<"J">(this, var3, -8232793244090790484L, (long)a);
   }

   @Override
   public Point2D getPoint2D(Point2D srcPt, Point2D dstPt) {
      何何友何友何树树树友.q();
      if (dstPt == null) {
         dstPt = new Double();
      }

      dstPt.setLocation(srcPt.getX(), srcPt.getY());
      return dstPt;
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖诈骗";
   }

   @Override
   public Rectangle2D getBounds2D(BufferedImage src) {
      return new Rectangle(0, 0, src.getWidth(), src.getHeight());
   }

   @Override
   public RenderingHints getRenderingHints() {
      return null;
   }

   @Override
   public BufferedImage createCompatibleDestImage(BufferedImage src, ColorModel dstCM) {
      何何友何友何树树树友.j();
      if (dstCM == null) {
         dstCM = src.getColorModel();
      }

      return new BufferedImage(dstCM, dstCM.createCompatibleWritableRaster(src.getWidth(), src.getHeight()), dstCM.isAlphaPremultiplied(), null);
   }
}
