package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

public final class 友友何何友友树何何友 implements IWrapper, 何树友 {
   private static final Matrix4f 友树树树何何友树树树;
   private static final Matrix4f 何何友友友何树何友树;
   private static final Matrix4f 友何树树何何何友何友;
   private static String[] 何何友树友树何何树树;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[72];
   private static final String[] e = new String[72];
   private static String HE_JIAN_GUO;

   private 友友何何友友树何何友(long a) {
      long var10000 = 121929105197859L ^ a;
      super();
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-448367597255978693L, -5987107838399371286L, MethodHandles.lookup().lookupClass()).a(233370231034687L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (n() != null) {
         w(new String[3]);
      }

      Cipher var0;
      Cipher var2 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(117481621066879L << var1 * 8 >>> 56);
      }

      var2.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var3 = b(
            var0.doFinal(
               "{\u0093Þø5\rh\u0080¢J¥Lj§§\u0094µg¤ó\u00adÏõ<«\u008f<\u0006*@PîÁÏ\u0016#\u009d$\u000b-%\t\u008fl\u001b\u0002\u001d¯Qù\u0080\u009aÇaÈ×"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      byte var10001 = -1;
      b = var3;
      友树树树何何友树树树 = new Matrix4f();
      何何友友友何树何友树 = new Matrix4f();
      友何树树何何何友何友 = new Matrix4f();
   }

   public static void B(
      BufferBuilder a,
      Matrix4f z3,
      float y3,
      float buffer,
      float g,
      float x2,
      float y1,
      float y4,
      float z1,
      float a,
      float x4,
      float x1,
      float matrix,
      float y2,
      float z4,
      float r,
      float x3,
      float z2
   ) {
      a.vertex(z3, y3, (float)buffer, g).color(z4, r, x3, z2).endVertex();
      a.vertex(z3, x2, y1, y4).color(z4, r, x3, z2).endVertex();
      a.vertex(z3, z1, a, x4).color(z4, r, x3, z2).endVertex();
      a.vertex(z3, x1, (float)matrix, y2).color(z4, r, x3, z2).endVertex();
   }

   public static void C(PoseStack a, Entity lineWidth, int color, float poseStack, long a) {
      EntityRenderDispatcher renderManager = mc.getEntityRenderDispatcher();
      Camera camera = renderManager.camera;
      double partialTicks = mc.getFrameTime();
      double x = lineWidth.xOld + (lineWidth.getX() - lineWidth.xOld) * partialTicks - camera.getPosition().x();
      double y = lineWidth.yOld + (lineWidth.getY() - lineWidth.yOld) * partialTicks - camera.getPosition().y();
      double z = lineWidth.zOld + (lineWidth.getZ() - lineWidth.zOld) * partialTicks - camera.getPosition().z();
      AABB bb = lineWidth.getBoundingBox().move(-lineWidth.getX(), -lineWidth.getY(), -lineWidth.getZ());
      float ax = (color >> 24 & 0xFF) / 255.0F;
      float r = (color >> 16 & 0xFF) / 255.0F;
      float g = (color >> 8 & 0xFF) / 255.0F;
      float b = (color & 0xFF) / 255.0F;
      a.pushPose();
      a.translate(x, y, z);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      RenderSystem.lineWidth((float)poseStack);
      RenderSystem.disableDepthTest();
      M(a, bb, r, g, 59022752902280L, b, ax);
      RenderSystem.enableDepthTest();
      RenderSystem.lineWidth(1.0F);
      RenderSystem.disableBlend();
      a.popPose();
   }

   public static boolean D(long a, Entity a) {
      int var10000 = RenderUtils.a();
      Vector4f pos = V(a, 87446743937492L);
      int ax = var10000;
      if (pos.x != Float.MAX_VALUE) {
         float var9;
         var10000 = (var9 = pos.y - (Float.MAX_VALUE)) == 0.0F ? 0 : (var9 < 0.0F ? -1 : 1);
         if (ax != 0) {
            if (!var10000) {
               return (boolean)0;
            }

            float var10;
            var10000 = (var10 = pos.z - -1.0F) == 0.0F ? 0 : (var10 < 0.0F ? -1 : 1);
         }

         if (ax != 0) {
            if (!var10000) {
               return (boolean)0;
            }

            float var11;
            var10000 = (var11 = pos.w - -1.0F) == 0.0F ? 0 : (var11 < 0.0F ? -1 : 1);
         }

         if (ax == 0) {
            return (boolean)var10000;
         }

         if (var10000) {
            return (boolean)1;
         }
      }

      return (boolean)0;
   }

   public static Vector3f D(Player a, long a, float partialTick) {
      a = 121929105197859L ^ a;
      long ax = a ^ 121827597477828L;
      double x = Mth.lerp(partialTick, a<"Z">(a, 8627073175253730857L, a), a.getX());
      double y = Mth.lerp(partialTick, a<"Z">(a, 8628446791502999437L, a), a.getY()) + a.getBbHeight() + 0.5;
      double z = Mth.lerp(partialTick, a<"Z">(a, 8628592255761812517L, a), a.getZ());
      return Q(ax, (float)x, (float)y, (float)z, (float)mc.getWindow().getGuiScale());
   }

   public static void Z(long a, PoseStack a, Entity var3, int color, boolean fillAlpha, boolean damage, boolean entity, float fillMode) {
      int ax;
      float minX;
      float maxX;
      float minY;
      float maxY;
      float minZ;
      float maxZ;
      int startColor;
      int endColor;
      int var39;
      label29: {
         EntityRenderDispatcher renderManager = mc.getEntityRenderDispatcher();
         Camera camera = renderManager.camera;
         double partialTicks = mc.getFrameTime();
         Vec3 entityPos = var3.getPosition((float)partialTicks).subtract(camera.getPosition());
         AABB bb = var3.getBoundingBoxForCulling();
         a.pushPose();
         a.translate(entityPos.x, entityPos.y, entityPos.z);
         minX = (float)(bb.minX - var3.getX());
         maxX = (float)(bb.maxX - var3.getX());
         var39 = RenderUtils.a();
         minY = (float)(bb.minY - var3.getY());
         maxY = (float)(bb.maxY - var3.getY());
         minZ = (float)(bb.minZ - var3.getZ());
         ax = var39;
         maxZ = (float)(bb.maxZ - var3.getZ());
         startColor = -16723258;
         endColor = color;
         if (fillAlpha && var3 instanceof LivingEntity living) {
            var39 = living.hurtTime;
            if (ax == 0) {
               break label29;
            }

            if (living.hurtTime > 0) {
               float hurtProgress = living.hurtTime / 10.0F;
               float axx = (color >> 24 & 0xFF) / 255.0F;
               float r = (color >> 16 & 0xFF) / 255.0F;
               float g = (color >> 8 & 0xFF) / 255.0F;
               float b = (color & 0xFF) / 255.0F;
               g *= 1.0F - hurtProgress * 0.8F;
               b *= 1.0F - hurtProgress * 0.8F;
               r = Math.min(1.0F, r + (1.0F - r) * hurtProgress * 0.8F);
               startColor = (int)(axx * 255.0F) << 24 | (int)(r * 255.0F) << 16 | (int)(g * 255.0F) << 8 | (int)(b * 255.0F);
               float darkerR = Math.max(0.4F, r * 0.7F);
               endColor = (int)(axx * 255.0F) << 24 | (int)(darkerR * 255.0F) << 16 | (int)(g * 255.0F) << 8 | (int)(b * 255.0F);
            }
         }

         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableDepthTest();
         RenderSystem.setShader(GameRenderer::getPositionColorShader);
         var39 = 1;
      }

      if (ax != 0) {
         if (var39 != 0) {
            RenderUtils.w(a, minX, maxX, minY, maxY, minZ, maxZ, startColor, endColor, (float)fillMode, 70434559295573L);
         }

         var39 = 1;
      }

      if (var39 != 0) {
         RenderSystem.disableDepthTest();
         RenderSystem.defaultBlendFunc();
         RenderUtils.W(a, minX, maxX, minY, 83919906043417L, maxY, minZ, maxZ, startColor, endColor);
      }

      RenderSystem.disableBlend();
      a.popPose();
   }

   public static void V(PoseStack a, long delta, Entity var3, float matrix, float target) {
      Camera camera = mc.getEntityRenderDispatcher().camera;
      Vec3 cameraPos = camera.getPosition();
      double prevSinAnim = Math.abs(1.0 + Math.sin(target - 0.45F)) / 2.0;
      double sinAnim = Math.abs(1.0 + Math.sin(target)) / 2.0;
      double x = var3.xo + (var3.getX() - var3.xo) * 2.0 - cameraPos.x();
      double y = var3.yo + (var3.getY() - var3.yo) * matrix - cameraPos.y() + prevSinAnim * var3.getBbHeight();
      double z = var3.zo + (var3.getZ() - var3.zo) * matrix - cameraPos.z();
      double nextY = var3.yo + (var3.getY() - var3.yo) * matrix - cameraPos.y() + sinAnim * var3.getBbHeight();
      a.pushPose();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
      int var10000 = RenderUtils.U();
      RenderSystem.enableDepthTest();
      int ax = var10000;
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      bufferBuilder.begin(Mode.TRIANGLE_STRIP, DefaultVertexFormat.POSITION_COLOR);
      int count = 1;
      int i = 0;
      if (ax == 0) {
         Color color = HUD.instance.getColor(4);
         float cos = (float)(
            x + Math.cos(0.0) * (var3.getBoundingBox().maxX - var3.getBoundingBox().minX + (var3.getBoundingBox().maxZ - var3.getBoundingBox().minZ)) * 0.5
         );
         float sin = (float)(
            z + Math.sin(0.0) * (var3.getBoundingBox().maxX - var3.getBoundingBox().minX + (var3.getBoundingBox().maxZ - var3.getBoundingBox().minZ)) * 0.5
         );
         bufferBuilder.vertex(a.last().pose(), cos, (float)nextY, sin).color(color.getRGB()).endVertex();
         bufferBuilder.vertex(a.last().pose(), cos, (float)y, sin).color(何树友友树树友何树何.j(color, 0.0F).getRGB()).endVertex();
         count++;
         i += 8;
         BufferUploader.drawWithShader(bufferBuilder.end());
         RenderSystem.enableCull();
         RenderSystem.disableDepthTest();
         RenderSystem.disableBlend();
         a.popPose();
      }
   }

   public static Vector4f V(Entity a, long a) {
      AABB bb = f(55419275117849L, a);
      List vectors = Arrays.asList(
         new Vector3f((float)bb.minX, (float)bb.minY, (float)bb.minZ),
         new Vector3f((float)bb.minX, (float)bb.maxY, (float)bb.minZ),
         new Vector3f((float)bb.maxX, (float)bb.minY, (float)bb.minZ),
         new Vector3f((float)bb.maxX, (float)bb.maxY, (float)bb.minZ),
         new Vector3f((float)bb.minX, (float)bb.minY, (float)bb.maxZ),
         new Vector3f((float)bb.minX, (float)bb.maxY, (float)bb.maxZ),
         new Vector3f((float)bb.maxX, (float)bb.minY, (float)bb.maxZ),
         new Vector3f((float)bb.maxX, (float)bb.maxY, (float)bb.maxZ)
      );
      int var10000 = RenderUtils.a();
      Vector4f entityPos = new Vector4f(Float.MAX_VALUE, Float.MAX_VALUE, -1.0F, -1.0F);
      double guiScale = mc.getWindow().getGuiScale();
      Iterator var14 = vectors.iterator();
      int ax = var10000;

      while (var14.hasNext()) {
         Vector3f vector3f = (Vector3f)var14.next();
         vector3f = Q(59240626163826L, vector3f.x, vector3f.y, vector3f.z, (float)guiScale);
         if (vector3f != null && vector3f.z >= 0.0 && vector3f.z < 1.0) {
            entityPos.x = Math.min(vector3f.x, entityPos.x);
            entityPos.y = Math.min(vector3f.y, entityPos.y);
            entityPos.z = Math.max(vector3f.x, entityPos.z);
            entityPos.w = Math.max(vector3f.y, entityPos.w);
         }

         if (ax == 0) {
            break;
         }
      }

      return entityPos;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 26;
               case 1 -> 40;
               case 2 -> 18;
               case 3 -> 31;
               case 4 -> 56;
               case 5 -> 29;
               case 6 -> 1;
               case 7 -> 15;
               case 8 -> 6;
               case 9 -> 37;
               case 10 -> 17;
               case 11 -> 36;
               case 12 -> 10;
               case 13 -> 7;
               case 14 -> 41;
               case 15 -> 27;
               case 16 -> 14;
               case 17 -> 20;
               case 18 -> 54;
               case 19 -> 21;
               case 20 -> 2;
               case 21 -> 0;
               case 22 -> 5;
               case 23 -> 63;
               case 24 -> 8;
               case 25 -> 30;
               case 26 -> 52;
               case 27 -> 59;
               case 28 -> 53;
               case 29 -> 55;
               case 30 -> 28;
               case 31 -> 22;
               case 32 -> 12;
               case 33 -> 24;
               case 34 -> 33;
               case 35 -> 61;
               case 36 -> 50;
               case 37 -> 57;
               case 38 -> 39;
               case 39 -> 13;
               case 40 -> 38;
               case 41 -> 16;
               case 42 -> 34;
               case 43 -> 51;
               case 44 -> 44;
               case 45 -> 3;
               case 46 -> 47;
               case 47 -> 9;
               case 48 -> 62;
               case 49 -> 32;
               case 50 -> 60;
               case 51 -> 42;
               case 52 -> 49;
               case 53 -> 48;
               case 54 -> 25;
               case 55 -> 19;
               case 56 -> 23;
               case 57 -> 35;
               case 58 -> 4;
               case 59 -> 45;
               case 60 -> 58;
               case 61 -> 43;
               case 62 -> 46;
               default -> 11;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'Z' && var8 != 'Q' && var8 != 225 && var8 != 235) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 198) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'm') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'Z') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Q') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 225) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public static String[] n() {
      return 何何友树友树何何树树;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static AABB f(long a, Entity a) {
      a = 121929105197859L ^ a;
      float ticks = mc.getFrameTime();
      Vec3 pos = new Vec3(
         Mth.lerp(ticks, a<"Z">(a, -3588938487918795280L, (long)a), a.getX()),
         Mth.lerp(ticks, a<"Z">(a, -3588141841444517232L, (long)a), a.getY()),
         Mth.lerp(ticks, a<"Z">(a, -3588090975244712041L, (long)a), a.getZ())
      );
      return a.getBoundingBox().move(pos.subtract(a.position()));
   }

   public static void d(PoseStack a, Entity a, long var2, double var4, int partialTicks, float accuracy, Color color, float poseStack) {
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableDepthTest();
      int var10000 = RenderUtils.a();
      RenderSystem.disableCull();
      int ax = var10000;
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      RenderSystem.lineWidth(2.0F);
      double x = Mth.lerp(accuracy, a.xOld, a.getX()) - mc.getEntityRenderDispatcher().camera.getPosition().x;
      double y = Mth.lerp(accuracy, a.yOld, a.getY()) - mc.getEntityRenderDispatcher().camera.getPosition().y;
      double z = Mth.lerp(accuracy, a.zOld, a.getZ()) - mc.getEntityRenderDispatcher().camera.getPosition().z;
      Tesselator tesselator = Tesselator.getInstance();
      BufferBuilder buffer = tesselator.getBuilder();
      int steps = Math.max(1, (int)poseStack * 5);
      float stepSize = poseStack * 0.001F;
      int step = 0;

      while (step < steps) {
         float adjustedRadius = (float)var4 + step * stepSize;
         buffer.begin(Mode.DEBUG_LINE_STRIP, DefaultVertexFormat.POSITION_COLOR);
         double angle = Math.toRadians(0.0);
         double xOffset = adjustedRadius * Math.cos(angle);
         double zOffset = adjustedRadius * Math.sin(angle);
         buffer.vertex(a.last().pose(), (float)(x + xOffset), (float)y, (float)(z + zOffset)).color(color.getRGB()).endVertex();
         if (ax != 0) {
            tesselator.end();
            step++;
         }

         if (ax == 0) {
            break;
         }
      }

      GL11.glDisable(2848);
      RenderSystem.enableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.disableBlend();
      RenderSystem.lineWidth(1.0F);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      c[0] = "\u0015{bE\u00139\u0017e+=\u001c5\u000efw_\u001f";
      c[1] = float.class;
      e[1] = "java/lang/Float";
      c[2] = "~xU\u0006\u007f6|f\u001c~p:ee@\u001bs";
      c[3] = "H\u0005i#\u0006\u001eH\u0005~\u007f\n\u0011RNjb\u0019\u001bBNme\u0012\u0004\b!\\O)";
      c[4] = double.class;
      e[4] = "java/lang/Double";
      c[5] = "\u00170m\u0015,\u0004\u0018p \u001e&\u0019\u001d-+X6\u001f\u001d20X1\u000e\u001a:&\u0004m厠县伋伖厽厈桺伡伋厈";
      c[6] = "\u0013E\u0006\u0003'C\u0018J\u0017L\\A\nQ\u0000\u0012f]\rA\u0014-yJ\u000bE\u0004\u000bfA<\\\u0013\u0007y[\u0010K\u001e";
      c[7] = "b\bG\u000eaOmH\n\u0005kRh\u0015\u0001C{Th\n\u001aC|Eo\u0002\f\u001f rd\b\r\b|uu\u000f\u0005\u001e";
      c[8] = int.class;
      e[8] = "java/lang/Integer";
      c[9] = "\u0012\r\\:bQ\u0012\rKfn^\bF_{}T\u0018FMz{Q\b\u0011\u0006dcY\u0005\rZ:_T\u001d\u0011Mf";
      c[10] = "_1(ePG_1?9\\HEz?'TK_ r9X@U1..O\u0000T:(\"IW\u001f\u00112?TZH\u00069%YKC\u001058MOE74.O";
      c[11] = "(C\u001fP=M(C\b\f1B2\b\b\u00129A(RE=1I#T\n";
      c[12] = "\tAB~TN\tAU\"XA\u0013\nA?KK\u0003\nS>MN\u0013]\u0018\u0015WS\u000ePO";
      c[13] = "Z\u001d\\!\u001b_Z\u001dK}\u0017P@V_`\u0004ZPVXg\u000fE\u001a.MlE";
      c[14] = "79PmU@>7S$\u0016M87G&\u000bKz X1LJ,xy&^N!:I\u0015]] 3E\u0005W]97I";
      c[15] = "Z\u000e8aP[S\u0000;(\u0013VU\u0000/*\u000eP\u0017\u00170=IQAO\u0003*O@\\\u0019\u0013 OYX\u0015";
      c[16] = "\u0019a\u0003P}q\u0010o\u0000\u0019>|\u0016o\u0014\u001b#zTx\u000b\fd{\u0002 8\u001bbj\u001fv(\u0011bs\u001bzJ3\u007fz\u001f";
      c[17] = "P&Tv\u0004eR8\u001d\u0015\u000f~M=Kl\b";
      c[18] = "c\b2`\u000b=c\b%<\u00072yC%\"\u000f1c\u0019h\u0003\u000f:h\u000e4/\u0000 ";
      c[19] = "FC\u000f\u0014ThFC\u0018HXg\\\b\u0018VPdFRUH\\oLC\t_K/oG\u0016_kdFB\u001eH\\s";
      c[20] = "j ]RI)j J\u000eE&pk^\u0013V,`kL\u0012P)p<\u00070M6m+N9J4m1P";
      c[21] = "\tz&\u0013\u0010Z\u0006:k\u0018\u001aG\u0003g`^\u0012Z\u000ead\u0015Qx\u0005p}\u001c\u001a";
      c[22] = "N\u00115z\u001dOz2::PDp/?g[\u0002x22a_I;\u00109pF@pf";
      c[23] = "m^wP7~Y}x\u0010zuS`}Mq3[}pKux\u0018_{ZlqS)";
      c[24] = void.class;
      e[24] = "java/lang/Void";
      c[25] = "KVwQgp>v|^v?CnoY\u007fv+";
      c[26] = "%^YY\u0011FP~RV\u0000\t-fAQ\t@E";
      c[27] = "BMs#\rEIBbllKBIf6";
      c[28] = "$X\b#\bxr]\u0004<g,I\u000b@aVxI;@ \fs\"B\u001e`\\:";
      c[29] = "&!\\j:@\"&\b:FMNy\u000e;}\u001e)\u001777/Y&9W7/\u001bw";
      c[30] = ".x\u000fbTkmpX6hk\u0013,O}V/t}Cz\f\u0013s,Bm\u0012wwh\u0004ih";
      c[31] = "\u0006s(1!x\u0007s+~_(a('>n|a\u0011,z4w\nhr:d>";
      c[32] = " \u0004\u001fWmJp\tLQ\u001dFIT\u001f\u000e \u0015Im\u0014Ev\u0019\"\u0014J\u0005&P";
      c[33] = "\u007fp\u000eBe\u0011<xY\u0016Y4B$N]gU%uBZ=i";
      c[34] = "9}1r3\ripbtC\u0001P-1+~QP\u0014:`(^;md x\u0017";
      c[35] = "xoXhs\u001e{m\ro\u001d|\u0015d\\l'Lju\n?$.";
      c[36] = "bce\tzx+cr\bE,Y\"\u007f\u0016\u007fygra\b~Ee|aPy{5b\u007fQE";
      c[37] = ">)9|\u001a\u007fcv>\u0003\u0011\r!#em\u0007q:22";
      c[38] = ".F\u001eJGks\u0019\u00195O\u00191LB[Ze*]\u0015";
      c[39] = "6l\ta!\u0006`i\u0005~NR[?A#\u007f\u0007[\u000fAb%\r0v\u001f\"uD";
      c[40] = "ZP\u001d\u0011b\t\fU\u0011\u000e\r]7\u0003US=\u000373U\u0012f\u0002\\J\u000bR6K";
      c[41] = " ~\u0011\u0003U50!JJ'g\u001c,NK\u00192\u001c\u001d\u001b\u000bZ9v F\u0015\\s";
      c[42] = "\n!!6$\u0010\t#t1J~g*%2pB\u0018;sas \u0007x4a0D\u0003<reJ";
      c[43] = "$.9'm\fa492\nF\u001d/,wdPa4= ";
      c[44] = "F]\u0007cTv\u0014D\u000f9){ \u0014Wk\u0010( $\u0003=\u0019$\u0005K\u0018c\u0010-";
      c[45] = "F?6V\u0005Y\u000f?!W:厧桤桛桗佨佧厧桤桛桗5P\u001f\u000f&5MJ\u001d\u0018=";
      c[46] = "\f\u0011XMmmY\u0018^H\u0016\u001d+8`=A\u0015'4p)\u0016;\u0005\u0017\u0002\t*n\f\u0011\u0007";
      c[47] = "]!\u0000)H\u0007\\!\u0003f6W:z\u000f)\u000b\u0005:C\u0004b]\bQ:Z\"\rA";
      c[48] = ";\u0011v\r\u0019lfN1V\u007fe]\u001c1\bO3],1O\u0014:6Uo\u000fDs";
      c[49] = "g0\u0007^O>.0\u0010_p叀企桔桦你伭佞原伐厼=\u001ax.)\u0004E\u0000z92";
      c[50] = "qpy8\u0007b,/~G\u000e\u0010nz%)\u001alukr";
      c[51] = "L.5jOX\t45\u007f(\u0010u/ :F\u0004\t41m";
      c[52] = "ppJ\u0003P\u0018\"5PS(\u000eJu\u0012\u000b\u0011^JO\u0017KS^!(FGT\u0004";
      c[53] = "AR0A'B\bR'@\u0018\u0019zN!Iu\u001c\n\u0010(\\i\u007f";
      c[54] = "<\u0019\u0016li@i\u0010\u0010i\u0012%\u000b3?\b\u0012\u00165\u001fL(.C<\u0019I";
      c[55] = "( ``4h) c/J8O{oo{oOBd+!g$;:kq.";
      c[56] = "Nm2&\u0019&Om1igv)6=&Z%)\u000f6m\f)Bvh-\\`";
      c[57] = "ju\t Op7*\u000e_I\u0002u\u007fU1R~nn\u0002";
      c[58] = "\u001a\r!V?wGRf\rY~|\u0000fSf!|0f\u00142!\u0017I8Tbh";
      c[59] = "\u0010(I\u001b\u0015K\u0011(JTk\u001bwsF\u001bVKwJMP\u0000D\u001c3\u0013\u0010P\r";
      c[60] = ")?n\u0016\u0004\u0000`?y\u0017;你住厁叕厶佦栤住厁栏uQF`&m\rKDw=";
      c[61] = "Y\rff\u00195\u0004R!=\u007f<?\u0000!cOk?0!$\u0014cTI\u007fdD*";
      c[62] = "\u0002\u0014mOD\u0006T\u0011aP+RoG%\r\u001b\row%L@\r\u0004\u000e{\f\u0010D";
      c[63] = "\rL(\u0002(f]A{\u0004Xjd\u001c([e8d%#\u001035\u000f\\}Pc|";
      c[64] = "U\\@t'8\u0003YLkHl8\u000f\b6y:8?\bw#3SFV7sz";
      c[65] = "IZle\u0000mHZo*~=.\u0001cjOk.8h.\u0015bEA6nE+";
      c[66] = "n2\u007fCjA'2hBU\u0003U.nK8\u001f%pg^$|5r{K/\u001816=OU";
      c[67] = "\u0001'F(\u0016}T.@-m\u001d1\u0005jQ\"\u0005&\u0013xK7\u00003DIt\b~\u0010x\u001c}\u000e{";
      c[68] = "\u0010pcOI\tSx4\u001bu\u0018-$#PKMJu/W\u0011q";
      c[69] = "~@\u0011<\f\u007f(E\u001d#c+\u0013\u0013Y~R|\u0013#Y?\btxZ\u0007\u007fX=";
      c[70] = "BY\u0011I_\f\u0007C\u0011\\8E{X\u0004\u0019VP\u0007C\u0015N";
      c[71] = "\u0019F\u001d\u0007}1LO\u001b\u0002\u0006A>o%wQI2c5o]Q)d 8ln\u0016\u001a\u0003\u00049g\u0010\u001f";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/友友何何友友树何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   public static void m(long a, PoseStack var2) {
      友何树树何何何友何友.set(var2.last().pose());
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void U(long var0) {
      何何友友友何树何友树.set(RenderSystem.getModelViewMatrix());
      友树树树何何友树树树.set(RenderSystem.getProjectionMatrix());
   }

   public static void w(PoseStack a, AABB outline, long aabb, boolean var4, int poseStack) {
      R(a, outline, var4, (int)poseStack, 1.0F, 126952744837118L);
   }

   public static void w(String[] var0) {
      何何友树友树何何树树 = var0;
   }

   public static void u(BufferBuilder a, Matrix4f y2, float matrix, float g, float buffer, float z1, float z2, float a, float b, float y1, float x1, float r) {
      a.vertex(y2, (float)matrix, g, (float)buffer).color(b, y1, x1, r).endVertex();
      a.vertex(y2, z1, z2, a).color(b, y1, x1, r).endVertex();
   }

   public static void M(PoseStack a, AABB a, float b, float bb, long a, float r, float poseStack) {
      a = 121929105197859L ^ a;
      Matrix4f matrix = a.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      buffer.begin(a<"á">(-6367821818524366896L, a), a<"á">(-6367950855550368535L, a));
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      a<"m">(-6367191852243737282L, a);
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6360366293234888912L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6360705423992806592L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6366710526652010090L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      buffer.vertex(matrix, (float)a<"Z">(a, -6367738023641078633L, a), (float)a<"Z">(a, -6364589435227595526L, a), (float)a<"Z">(a, -6367382197335095194L, a))
         .color(b, (float)bb, r, (float)poseStack)
         .endVertex();
      BufferUploader.drawWithShader(buffer.end());
      a<"m">(new Module[2], -6367572921365866418L, a);
   }

   public static void R(PoseStack a, AABB alpha, boolean a, int var3, float color, long poseStack) {
      poseStack = 121929105197859L ^ poseStack;
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableDepthTest();
      int var10000 = a<"m">(-7722135801483880888L, (long)poseStack);
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      float ax = (var3 >> 24 & 0xFF) / 255.0F * 1.0F;
      float r = (var3 >> 16 & 0xFF) / 255.0F;
      float g = (var3 >> 8 & 0xFF) / 255.0F;
      float b = (var3 & 0xFF) / 255.0F;
      float minX = (float)a<"Z">(alpha, -7721695505325352991L, (long)poseStack);
      int axx = var10000;
      float minY = (float)a<"Z">(alpha, -7722934101836004640L, (long)poseStack);
      float minZ = (float)a<"Z">(alpha, -7724458042319176634L, (long)poseStack);
      float maxX = (float)a<"Z">(alpha, -7724664269060960202L, (long)poseStack);
      float maxY = (float)a<"Z">(alpha, -7720813011380457588L, (long)poseStack);
      float maxZ = (float)a<"Z">(alpha, -7722330338998338800L, (long)poseStack);
      Tesselator tesselator = Tesselator.getInstance();
      BufferBuilder bufferBuilder = tesselator.getBuilder();
      Matrix4f matrix = a.last().pose();
      RenderSystem.lineWidth(2.0F);
      bufferBuilder.begin(a<"á">(-7721785416216103770L, (long)poseStack), a<"á">(-7721922149350590561L, (long)poseStack));
      u(bufferBuilder, matrix, minX, minY, minZ, maxX, minY, minZ, r, g, b, ax);
      u(bufferBuilder, matrix, maxX, minY, minZ, maxX, minY, maxZ, r, g, b, ax);
      u(bufferBuilder, matrix, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, ax);
      u(bufferBuilder, matrix, minX, minY, maxZ, minX, minY, minZ, r, g, b, ax);
      u(bufferBuilder, matrix, minX, maxY, minZ, maxX, maxY, minZ, r, g, b, ax);
      u(bufferBuilder, matrix, maxX, maxY, minZ, maxX, maxY, maxZ, r, g, b, ax);
      u(bufferBuilder, matrix, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, ax);
      u(bufferBuilder, matrix, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, ax);
      u(bufferBuilder, matrix, minX, minY, minZ, minX, maxY, minZ, r, g, b, ax);
      u(bufferBuilder, matrix, maxX, minY, minZ, maxX, maxY, minZ, r, g, b, ax);
      u(bufferBuilder, matrix, maxX, minY, maxZ, maxX, maxY, maxZ, r, g, b, ax);
      u(bufferBuilder, matrix, minX, minY, maxZ, minX, maxY, maxZ, r, g, b, ax);
      tesselator.end();
      if (poseStack >= 0L) {
         bufferBuilder.begin(a<"á">(-7723473714016302389L, (long)poseStack), a<"á">(-7721922149350590561L, (long)poseStack));
         B(bufferBuilder, matrix, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, ax);
         B(bufferBuilder, matrix, minX, maxY, minZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, r, g, b, ax);
         B(bufferBuilder, matrix, minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ, maxX, minY, minZ, r, g, b, ax);
         B(bufferBuilder, matrix, minX, minY, maxZ, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, ax);
         B(bufferBuilder, matrix, minX, minY, minZ, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, ax);
         B(bufferBuilder, matrix, maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ, r, g, b, ax);
         tesselator.end();
         RenderSystem.enableDepthTest();
         RenderSystem.disableBlend();
         RenderSystem.lineWidth(1.0F);
      }

      if (poseStack > 0L && a<"m">(-7722027973674693093L, (long)poseStack) == null) {
         a<"m">(++axx, -7720660809047417581L, (long)poseStack);
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖黑水";
   }

   public static Vector3f Q(long a, float var2, float x, float y, float z) {
      Camera camera = mc.gameRenderer.getMainCamera();
      int displayHeight = mc.getWindow().getHeight();
      Vec3 cameraPos = camera.getPosition();
      double deltaX = var2 - cameraPos.x;
      double deltaY = x - cameraPos.y;
      double deltaZ = y - cameraPos.z;
      Vector4f transformed = new Vector4f((float)deltaX, (float)deltaY, (float)deltaZ, 1.0F).mul(友何树树何何何友何友);
      RenderUtils.a();
      Matrix4f matrix = new Matrix4f(友树树树何何友树树树);
      matrix.mul(何何友友友何树何友树);
      Vector3f screenCoords = new Vector3f();
      matrix.project(transformed.x(), transformed.y(), transformed.z(), new int[]{0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight()}, screenCoords);
      return screenCoords.z > 1.0F ? null : new Vector3f(screenCoords.x / z, (displayHeight - screenCoords.y) / z, screenCoords.z);
   }

   public static void O(
      PoseStack a,
      int yPos,
      long c2,
      int width,
      int xPos,
      int c1,
      float textureWidth,
      float c3,
      Entity texture,
      ResourceLocation entity,
      boolean rotate,
      Color textureHeight,
      Color c,
      Color a,
      Color var15
   ) {
      EntityRenderDispatcher renderManager = mc.getEntityRenderDispatcher();
      Quaternionf cameraRotation = renderManager.camera.rotation();
      double x = texture.xOld + (texture.getX() - texture.xOld) * mc.getFrameTime() - renderManager.camera.getPosition().x();
      double y = texture.yOld + 1.0 + (texture.getY() + 1.0 - (texture.yOld + 1.0)) * mc.getFrameTime() - renderManager.camera.getPosition().y();
      RenderUtils.U();
      double z = texture.zOld + (texture.getZ() - texture.zOld) * mc.getFrameTime() - renderManager.camera.getPosition().z();
      a.pushPose();
      a.translate(x, y, z);
      a.mulPose(cameraRotation);
      float angle = (float)(Math.sin(System.currentTimeMillis() / 800.0) * 360.0);
      a.mulPose(new Quaternionf().rotationAxis((float)Math.toRadians(angle), 0.0F, 0.0F, 1.0F));
      a.scale(0.03F, 0.03F, 0.03F);
      RenderSystem.enableBlend();
      RenderSystem.disableDepthTest();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.setShaderTexture(0, entity);
      RenderSystem.texParameter(3553, 10241, 9729);
      RenderSystem.texParameter(3553, 10240, 9729);
      RenderUtils.T(a, -24, -24, 0.0F, 0.0F, 48, 48, 104266329580790L, 48.0F, 48.0F, textureHeight, c, a, var15);
      RenderSystem.disableBlend();
      RenderSystem.enableDepthTest();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      a.popPose();
   }
}
