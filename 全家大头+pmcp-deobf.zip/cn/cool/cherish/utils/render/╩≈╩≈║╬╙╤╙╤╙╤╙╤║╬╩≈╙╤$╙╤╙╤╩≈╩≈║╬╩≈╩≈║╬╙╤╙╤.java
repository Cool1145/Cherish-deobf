package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

class 树树何友友友友何树友$友友树树何树树何友友 extends HashMap<Color, String> implements  {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g;
   private static final Object[] h = new Object[10];
   private static final String[] i = new String[10];
   private static String HE_DA_WEI;

   树树何友友友友何树友$友友树树何树树何友友(long a) {
      a = 树树何友友友友何树友$友友树树何树树何友友.a ^ a;
      super();
      this.put(c<"È">(-7479387471179761225L, a), a<"j">(21332, 8766506620785419504L ^ a));
      this.put(new Color(b<"b">(11747, 4143757562666849386L ^ a)), a<"j">(29857, 1659575104262783748L ^ a));
      this.put(c<"È">(-7479438871829560156L, a), a<"j">(22229, 2528461764179222909L ^ a));
      this.put(new Color(b<"b">(32511, 8136295934879909751L ^ a)), a<"j">(28215, 227516929949030809L ^ a));
      this.put(c<"È">(-7480140062531691543L, a), a<"j">(25424, 7308580580420539634L ^ a));
      this.put(new Color(b<"b">(19310, 910489868043481828L ^ a)), a<"j">(20297, 5852427466045585636L ^ a));
      this.put(c<"È">(-7479679059396338448L, a), a<"j">(26133, 6854215236018917817L ^ a));
      this.put(new Color(b<"b">(30262, 22607008016519101L ^ a)), a<"j">(18462, 7128009186041528244L ^ a));
      this.put(c<"È">(-7479828849187817637L, a), a<"j">(5164, 3074330051063751555L ^ a));
      this.put(new Color(b<"b">(23253, 5583165587785671513L ^ a)), a<"j">(3754, 6418862917641713929L ^ a));
      this.put(c<"È">(-7479886379695566171L, a), a<"j">(29233, 7249848599381493143L ^ a));
      this.put(new Color(b<"b">(29434, 2788829470351182708L ^ a)), a<"j">(3735, 3719018942955108670L ^ a));
      this.put(c<"È">(-7479737503397021686L, a), a<"j">(2674, 7015168801284636121L ^ a));
      this.put(new Color(b<"b">(14734, 8789760486400524291L ^ a)), a<"j">(27433, 9169668200575753352L ^ a));
      this.put(c<"È">(-7480076018514644238L, a), a<"j">(14447, 7438281134315147208L ^ a));
      this.put(new Color(b<"b">(7545, 6229371676320408822L ^ a)), a<"j">(21706, 6975729680184566634L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2577156553124344258L, -2178279309541010402L, MethodHandles.lookup().lookupClass()).a(62855861982918L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 112037490836140L;
      Cipher var13;
      Cipher var24 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[16];
      int var18 = 0;
      String var17 = "Èõ3tÌ\u001cÒ2\u0099s»\u0081Þ\u001fNô\u0010\u0096Ì\u0083\u001c¶\u0085\u0007\u009aòúÆñ0'üÔ\u0010$\u0003cÐ\u0010e¤×Ï°Ñ5Ç\u0093Zq\u0010\\\u0084S·\u0093û\rÖùâþÊ[\u0016h\u0096\u0010þôs\u00ad\u0006\u008f\u001b¢¯'xü½°\u0016p\u0010Ü,ÊS\u0004\u0016\u009fB÷ÝZ\u008a$Í}ü\u0010¨.¡ãø³ð\u008d\u0002í\u0084nR\u0098>\u0015\u0010\u001dgÅ|ÐI$ò*u\u0003\u0080ÄÉ\u0081G\u0010\u008b¸¶¶~J%ßC%À¶=êáö\u0010h'gE\u0085å\u0094Ex\u0083ö#\u00ad)Zx\u0010,\u0091\u0016\u008f@\u0080\u0015ÃC\u000e&bÝ\u0092ôi\u0010\u0013íû\u0094¢\u001fw=D\u0018\u001aààIòp\u0010q\\$7\u0015\u009c¾\u0004á¡\u0000\u0098w\u008fsY\u0010\u000bì\u0012××Ë´]¬¶é¿¥÷Ñb";
      short var19 = 237;
      char var16 = 16;
      int var23 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            String var36 = a(var13.doFinal(var25.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var23 += var16) >= var19) {
                     b = var20;
                     c = new String[16];
                     g = new HashMap(13);
                     Cipher var0;
                     Cipher var27 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var27.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[8];
                     int var3 = 0;
                     String var4 = "rõlé.ÄÐ\f5\u0010È\u0016\u0000/\n\u008e§4@\u0016Ü\u0007Å±T¤\u0002E¡Pq\u0000\u001d\u0017åf\u0088qý\u0094\u00ad(o\u0016Æ3\u0085§";
                     byte var5 = 48;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var43 = -1;

                        while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    e = var6;
                                    f = new Integer[8];
                                    return;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "³2f\u000eE\r?Jÿ\u008cÂ\u0094àk©y";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label54;
                  }

                  var17 = "Ë´b\u000eº¨ÜÅÄ4³&'hl|\u0010CÇ!\u00ad~\u0091e\u009c[\u007f\u008eb¬XMY";
                  var19 = 33;
                  var16 = 16;
                  var23 = -1;
            }

            var25 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友$友友树树何树树何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 8634;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])g.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            g.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友$友友树树何树树何友友", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友$友友树树何树树何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友$友友树树何树树何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 252 && var8 != 223 && var8 != 200 && var8 != 235) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'U') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 250) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 252) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 200) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void a() {
      h[0] = "\u0001W}*E\u001e\u001cB%\b\u0004\u0013\u0004D";
      h[1] = "U>\u0016W[\u0013^1\u0007\u0018:\u001dU:\u0003B";
      h[2] = "\u0011?=WI\u001f\u001ao?,y)=U&FX\u001f\u001b.-\u0016Z";
      h[3] = "E\u0000}vOxNP\u007f\rtNa.AR%cO\u0011}g^h\u001f\u0013";
      h[4] = "WA(vLK\\\u0011*\rma~mSmLKLA(f\u001cI";
      h[5] = "B:\"\r\u0005\u001bIj v7!d\u0013Y\u0016\u0005\u001bY:\"\u001dU\u0019";
      h[6] = "\u000bi@\u0011\u0014C\u00009Bj4|6N;\n\u0014C\u0010i@\u0001DA";
      h[7] = "\\\u001anuESWJl\u000eph},X\u000eOBG\u000b\u007fuD\u0012E";
      h[8] = "Wr1/)D\\\"3T\fe~IJ4)DLr1?yF";
      h[9] = "\u0005\u001d\u0002,\u00115\u000eM\u0000W4\u0014(:?W\u001b$\u001e\f\u0013,\u0010t\u001c";
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12183;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友$友友树树何树树何友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 55;
               case 1 -> 10;
               case 2 -> 27;
               case 3 -> 2;
               case 4 -> 39;
               case 5 -> 26;
               case 6 -> 30;
               case 7 -> 7;
               case 8 -> 57;
               case 9 -> 48;
               case 10 -> 21;
               case 11 -> 35;
               case 12 -> 50;
               case 13 -> 58;
               case 14 -> 3;
               case 15 -> 17;
               case 16 -> 9;
               case 17 -> 4;
               case 18 -> 44;
               case 19 -> 52;
               case 20 -> 6;
               case 21 -> 62;
               case 22 -> 22;
               case 23 -> 20;
               case 24 -> 34;
               case 25 -> 53;
               case 26 -> 0;
               case 27 -> 5;
               case 28 -> 46;
               case 29 -> 63;
               case 30 -> 54;
               case 31 -> 29;
               case 32 -> 61;
               case 33 -> 60;
               case 34 -> 24;
               case 35 -> 14;
               case 36 -> 45;
               case 37 -> 33;
               case 38 -> 13;
               case 39 -> 8;
               case 40 -> 23;
               case 41 -> 56;
               case 42 -> 31;
               case 43 -> 11;
               case 44 -> 51;
               case 45 -> 1;
               case 46 -> 41;
               case 47 -> 19;
               case 48 -> 36;
               case 49 -> 38;
               case 50 -> 25;
               case 51 -> 40;
               case 52 -> 42;
               case 53 -> 28;
               case 54 -> 12;
               case 55 -> 32;
               case 56 -> 15;
               case 57 -> 37;
               case 58 -> 43;
               case 59 -> 47;
               case 60 -> 49;
               case 61 -> 16;
               case 62 -> 59;
               default -> 18;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖国企变私企";
   }
}
