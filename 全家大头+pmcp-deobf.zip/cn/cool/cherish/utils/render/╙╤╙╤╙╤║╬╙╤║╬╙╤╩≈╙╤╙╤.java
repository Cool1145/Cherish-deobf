package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;

public final class 友友友何友何友树友友 implements IWrapper, 何树友 {
   private static final long a;
   private static final String b;
   private static final long[] c;
   private static final Integer[] e;
   private static final Map f;
   private static final Object[] g = new Object[8];
   private static final String[] h = new String[8];
   private static String HE_WEI_LIN;

   private 友友友何友何友树友友(long a) {
      long var10000 = 友友友何友何友树友友.a ^ a;
      super();
      throw new UnsupportedOperationException(b);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(2737789178073212830L, -7901735805753960807L, MethodHandles.lookup().lookupClass()).a(113745786589259L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 22248719461679L;
      Cipher var13;
      Cipher var16 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var16.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var22 = b(
            var13.doFinal(
               "t\u001fÒïO\u00838\u0083Âê|\u0086éb{n7sÔ4\u009cQê\u0013\u0099\u00ad(ÍDq{~ I\u0011E$J%\u0097Ü´¶\u00833{\u0095É¬\u0092»i\u0011bh^"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      int var10001 = -1;
      b = var22;
      f = new HashMap(13);
      Cipher var0;
      Cipher var17 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[9];
      int var3 = 0;
      String var4 = "fÆF\u001fòú§i»Á\rzí<\u009b\u0013\u0081ªX.TÞk;¤¨^rB\u009dö\u0015{{VB%¼xlN1¢ã§\u008dÖÉ,ç\u0093¼/×\rü";
      byte var5 = 56;
      byte var2 = 0;

      label29:
      while (true) {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         long[] var18 = var6;
         var10001 = var3++;
         long var24 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte var27 = -1;

         while (true) {
            long var8 = var24;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var29 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var27) {
               case 0:
                  var18[var10001] = var29;
                  if (var2 >= var5) {
                     c = var6;
                     e = new Integer[9];
                     return;
                  }
                  break;
               default:
                  var18[var10001] = var29;
                  if (var2 < var5) {
                     continue label29;
                  }

                  var4 = "s\u0003®39CK\u000båMe\u0013\u0086/«Ï";
                  var5 = 16;
                  var2 = 0;
            }

            byte var21 = var2;
            var2 += 8;
            var7 = var4.substring(var21, var2).getBytes("ISO-8859-1");
            var18 = var6;
            var10001 = var3++;
            var24 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var27 = 0;
         }
      }
   }

   public static void Z(long a, RenderTarget var2) {
      a = 友友友何友何友树友友.a ^ a;
      b<"b">(-998306303547724808L, (long)a);
      if (var2.getDepthTextureId() > -1) {
         EXTFramebufferObject.glDeleteRenderbuffersEXT(var2.getDepthTextureId());
      }

      int stencilDepthBufferID = EXTFramebufferObject.glGenRenderbuffersEXT();
      EXTFramebufferObject.glBindRenderbufferEXT(a<"k">(10394, 8001928586881237883L ^ a), stencilDepthBufferID);
      EXTFramebufferObject.glRenderbufferStorageEXT(
         a<"k">(5110, 1287759162940274705L ^ a), a<"k">(4119, 1620536852783021045L ^ a), mc.getWindow().getWidth(), mc.getWindow().getHeight()
      );
      EXTFramebufferObject.glFramebufferRenderbufferEXT(
         a<"k">(24494, 6278451279338599502L ^ a), a<"k">(21213, 7020707101169416507L ^ a), a<"k">(5110, 1287759162940274705L ^ a), stencilDepthBufferID
      );
      EXTFramebufferObject.glFramebufferRenderbufferEXT(
         a<"k">(30817, 3470161276693173125L ^ a), a<"k">(14736, 6433010951751766643L ^ a), a<"k">(5110, 1287759162940274705L ^ a), stencilDepthBufferID
      );
      var2.enableStencil();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (h[var4] != null) {
         return var4;
      } else {
         Object var5 = g[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 0;
               case 1 -> 1;
               case 2 -> 9;
               case 3 -> 38;
               case 4 -> 60;
               case 5 -> 52;
               case 6 -> 61;
               case 7 -> 63;
               case 8 -> 58;
               case 9 -> 56;
               case 10 -> 53;
               case 11 -> 43;
               case 12 -> 34;
               case 13 -> 36;
               case 14 -> 7;
               case 15 -> 48;
               case 16 -> 35;
               case 17 -> 12;
               case 18 -> 46;
               case 19 -> 31;
               case 20 -> 51;
               case 21 -> 59;
               case 22 -> 49;
               case 23 -> 50;
               case 24 -> 14;
               case 25 -> 39;
               case 26 -> 29;
               case 27 -> 22;
               case 28 -> 42;
               case 29 -> 2;
               case 30 -> 41;
               case 31 -> 5;
               case 32 -> 54;
               case 33 -> 6;
               case 34 -> 13;
               case 35 -> 15;
               case 36 -> 10;
               case 37 -> 16;
               case 38 -> 24;
               case 39 -> 17;
               case 40 -> 21;
               case 41 -> 23;
               case 42 -> 30;
               case 43 -> 4;
               case 44 -> 40;
               case 45 -> 57;
               case 46 -> 32;
               case 47 -> 45;
               case 48 -> 28;
               case 49 -> 47;
               case 50 -> 3;
               case 51 -> 33;
               case 52 -> 11;
               case 53 -> 8;
               case 54 -> 62;
               case 55 -> 26;
               case 56 -> 20;
               case 57 -> 18;
               case 58 -> 55;
               case 59 -> 27;
               case 60 -> 37;
               case 61 -> 19;
               case 62 -> 25;
               default -> 44;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            h[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/友友友何友何友树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'D' && var8 != 'R' && var8 != 254 && var8 != 'A') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 226) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'b') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'D') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'R') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 254) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static void s(Object[] var0) {
      GL11.glDisable(2960);
      RenderSystem.disableBlend();
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         g[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = g[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      g[0] = "@_A1F>O\u001f\f:L#JB\u0007|\\%J]\u001c|[4MU\n \u0007厚叨叺伺厙佼厚栲叺厤";
      g[1] = "\u0019\u001ftAv\u0002\u0012\u0010e\u000e\r\u0000\u0000\u000brP7\u001c\u0007\u001bfo(\u000b\u0001\u001fvI7\u00006\u0006aE(\u001a\u001a\u0011l";
      g[2] = "hV`Q\u0018tg\u0016-Z\u0012ibK&\u001c\u0002obT=\u001c\u0005~e\\+@YInV*W\u0005N\u007fQ\"A";
      g[3] = boolean.class;
      h[3] = "java/lang/Boolean";
      g[4] = "Vq]Spo]~L\u001c\u0011aVuHF";
      g[5] = "|Zj\u0006bQ&]hK\u0002TE\rh\u0016;\u0000xXp\u0019n;";
      g[6] = "<MN$\u0002S;NBM\u0017,)\u001f_s\u0003O#\u000bIM\u0005C/N_.\u000fW9p";
      g[7] = "\"!BF\u0002ex&@\u000bbS\u001bv@V[4&#XY\u000e\u000f";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/友友友何友何友树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 22978;
      if (e[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])f.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            f.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/render/友友友何友何友树友友", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         e[var3] = var15;
      }

      return e[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (var5 instanceof String) {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         g[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void j(int a) {
      RenderSystem.colorMask(true, true, true, true);
      RenderSystem.stencilFunc(514, (int)a, 1);
      RenderSystem.stencilOp(7680, 7680, 7680);
   }

   public static void q(long a) {
      long ax = 友友友何友何友树友友.a ^ a ^ 50938899707894L;
      RenderTarget framebuffer = mc.getMainRenderTarget();
      framebuffer.bindWrite(false);
      G(framebuffer, ax);
      RenderSystem.clear(1024, false);
      GL11.glEnable(2960);
      RenderSystem.stencilFunc(519, 1, 1);
      RenderSystem.stencilOp(7681, 7681, 7681);
      RenderSystem.colorMask(false, false, false, false);
   }

   public static void X(Object[] var0) {
      GL11.glDisable(2960);
   }

   public static void N(boolean a, long a) {
      a = 友友友何友何友树友友.a ^ a;
      long ax = a ^ 26879671364628L;
      b<"b">(2003319593725641232L, a);
      L(ax);
      RenderSystem.clearStencil(0);
      RenderSystem.clear(1024, false);
      GL11.glEnable(2960);
      RenderSystem.stencilFunc(519, 1, a<"k">(25254, 8761422640229228704L ^ a));
      RenderSystem.stencilOp(7680, 7680, 7681);
      if (!a) {
         RenderSystem.colorMask(false, false, false, false);
      }
   }

   public static void W(long a, boolean a) {
      a = 友友友何友何友树友友.a ^ a;
      b<"b">(6055217529590746581L, (long)a);
      RenderSystem.stencilFunc(a ? 514 : 517, 1, a<"k">(26394, 7207157931707198162L ^ a));
      RenderSystem.stencilOp(7680, 7680, 7681);
      RenderSystem.colorMask(true, true, true, true);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
   }

   public static void T(boolean a, long a, RenderTarget fb) {
      a = 友友友何友何友树友友.a ^ a;
      long ax = a ^ 97864982622347L;
      b<"b">(1126190097375090300L, a);
      G(fb, ax);
      RenderSystem.clearStencil(0);
      RenderSystem.clear(1024, false);
      GL11.glEnable(2960);
      RenderSystem.stencilFunc(519, 1, a<"k">(25254, 8761449729728951500L ^ a));
      RenderSystem.stencilOp(7680, 7680, 7681);
      if (!a) {
         RenderSystem.colorMask(false, false, false, false);
      }
   }

   private static String HE_SHU_YOU() {
      return "职业技术教育中心学校";
   }
}
