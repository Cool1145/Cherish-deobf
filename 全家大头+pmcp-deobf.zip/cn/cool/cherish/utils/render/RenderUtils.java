package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.render.Render3DEvent;
import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import com.mojang.math.Axis;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Camera;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class RenderUtils implements IWrapper, 何树友 {
   public static Map<AABB, Color> 友友树友树何友树友何;
   private static final int 友友树何友友友友树何;
   private static int 友树何树树何树何友树;
   private static final long a;
   private static final String b;
   private static final long[] c;
   private static final Integer[] e;
   private static final Map f;
   private static final Object[] g = new Object[57];
   private static final String[] h = new String[57];
   private static String HE_DA_WEI;

   private RenderUtils(char a, short a, int a) {
      long var10000 = ((long)a << 48 | (long)a << 48 >>> 16 | (long)a << 32 >>> 32) ^ 61029000629300L;
      super();
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8363976146056113744L, -7655184544368686467L, MethodHandles.lookup().lookupClass()).a(73132577297095L);
      // $VF: monitorexit
      a = var10000;
      b();
      if (a() == 0) {
         p(23);
      }

      Cipher var11;
      Cipher var14 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(101748394813748L << var12 * 8 >>> 56);
      }

      var14.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var20 = b(
            var11.doFinal(
               "²ÑIÛ\u000b\u001d¥Pf,Ø\u009aV\rÕ\u0098:\u007fp\u001b\"\u009a´\u001c¯m!òNÏÊ§ÐÛ(\u008aÛ¾Y\u001a\f\u0098÷ø?ùm×gb:¹\u009ce'Y".getBytes("ISO-8859-1")
            )
         )
         .intern();
      int var10001 = -1;
      b = var20;
      f = new HashMap(13);
      Cipher var0;
      Cipher var15 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(101748394813748L << var1 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[4];
      int var3 = 0;
      String var4 = "ÍE`WÅÎr\u0015ÄU\u000e\u0007?»SØ";
      byte var5 = 16;
      byte var2 = 0;

      label33:
      while (true) {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         long[] var16 = var6;
         var10001 = var3++;
         long var22 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte var25 = -1;

         while (true) {
            long var8 = var22;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var27 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var25) {
               case 0:
                  var16[var10001] = var27;
                  if (var2 >= var5) {
                     c = var6;
                     e = new Integer[4];
                     友友树何友友友友树何 = -15066598;
                     友友树友树何友树友何 = new HashMap<>();
                     return;
                  }
                  break;
               default:
                  var16[var10001] = var27;
                  if (var2 < var5) {
                     continue label33;
                  }

                  var4 = "x&\u0099\u008cïH\u00ad\u0081]&\u008e©\u0000<p?";
                  var5 = 16;
                  var2 = 0;
            }

            byte var19 = var2;
            var2 += 8;
            var7 = var4.substring(var19, var2).getBytes("ISO-8859-1");
            var16 = var6;
            var10001 = var3++;
            var22 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var25 = 0;
         }
      }
   }

   public static void B(int a, int y, int height, int width) {
      Window window = mc.getWindow();
      double guiScale = window.getGuiScale();
      int realX = (int)(4.0 * guiScale);
      int realY = (int)(y * guiScale);
      int realWidth = (int)(height * guiScale);
      int realHeight = (int)(width * guiScale);
      int scissorY = window.getHeight() - (realY + realHeight);
      RenderSystem.enableScissor(realX, scissorY, realWidth, realHeight);
   }

   public static void C(PoseStack a, float width, float y, float poseStack, float height, int endColor, long a, int startColor) {
      a = 61029000629300L ^ a;
      float startRed = (endColor >> 16 & 0xFF) / 255.0F;
      float startGreen = (endColor >> 8 & 0xFF) / 255.0F;
      float startBlue = (endColor & 0xFF) / 255.0F;
      float startAlpha = (endColor >> 24 & 0xFF) / 255.0F;
      float endRed = (startColor >> 16 & 0xFF) / 255.0F;
      float endGreen = (startColor >> 8 & 0xFF) / 255.0F;
      float endBlue = (startColor & 0xFF) / 255.0F;
      float endAlpha = (startColor >> 24 & 0xFF) / 255.0F;
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      Matrix4f matrix = a.last().pose();
      bufferBuilder.begin(b<"d">(5485371433292568337L, a), b<"d">(5484521042194604346L, a));
      bufferBuilder.vertex(matrix, width + poseStack, y, 0.0F).color(startRed, startGreen, startBlue, startAlpha).endVertex();
      bufferBuilder.vertex(matrix, width, y, 0.0F).color(startRed, startGreen, startBlue, startAlpha).endVertex();
      bufferBuilder.vertex(matrix, width, y + height, 0.0F).color(endRed, endGreen, endBlue, endAlpha).endVertex();
      bufferBuilder.vertex(matrix, width + poseStack, y + height, 0.0F).color(endRed, endGreen, endBlue, endAlpha).endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
      RenderSystem.disableBlend();
   }

   public static void D(PoseStack a, float centerX, float radius, float centerY, float poseStack, int a, long var6) {
      var6 = 61029000629300L ^ var6;
      float alpha = (a >> 24 & 255) / 255.0F;
      float red = (a >> 16 & 255) / 255.0F;
      int var10000 = b<"e">(6309214984252445026L, var6);
      float green = (a >> 8 & 255) / 255.0F;
      float blue = (a & 255) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      int ax = var10000;
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      bufferBuilder.begin(b<"d">(6309022114790472376L, var6), b<"d">(6308000351605177004L, var6));
      int i = 0;

      label29:
      while (i <= 64) {
         float angle1 = (float)((Math.PI * 2) * i / 64.0);
         float x1Outer = centerX + (centerY + poseStack / 2.0F) * (float)Math.cos(angle1);
         float y1Outer = radius + (centerY + poseStack / 2.0F) * (float)Math.sin(angle1);
         float x1Inner = centerX + (centerY - poseStack / 2.0F) * (float)Math.cos(angle1);
         float y1Inner = radius + (centerY - poseStack / 2.0F) * (float)Math.sin(angle1);
         bufferBuilder.vertex(a.last().pose(), x1Outer, y1Outer, 0.0F).color(red, green, blue, alpha).endVertex();
         bufferBuilder.vertex(a.last().pose(), x1Inner, y1Inner, 0.0F).color(red, green, blue, alpha).endVertex();
         i++;

         do {
            var10000 = ax;
            if (var6 > 0L) {
               if (ax == 0) {
                  return;
               }

               var10000 = ax;
            }

            if (var10000 != 0) {
               continue label29;
            }
         } while (var6 <= 0L);
         break;
      }

      BufferUploader.drawWithShader(bufferBuilder.end());
      RenderSystem.disableBlend();
   }

   public static void F(long a, PoseStack poseStack, ItemStack itemStack, int a, int var5) {
      p(poseStack, itemStack, (int)a, 76544922744888L, var5, mc.getItemRenderer().getModel(itemStack, null, null, 0));
   }

   public static void I(PoseStack a, float width, float poseStack, float height, float x, int color, float y) {
      drawRectangle(a, width, (float)poseStack, height, 1.0F, color);
      drawRectangle(a, width, poseStack + x - y, height, y, color);
      drawRectangle(a, width, poseStack + y, y, x - y * 2.0F, color);
      drawRectangle(a, width + height - y, poseStack + y, y, x - y * 2.0F, color);
   }

   public static void J(long a, PoseStack var2, double y, double itemStack, ItemStack var7) {
      if (!var7.isEmpty()) {
         F(57627225086705L, var2, var7, (int)y, (int)itemStack);
      }
   }

   public static void S(PoseStack a, float y, float width, float poseStack, long player, float var6, AbstractClientPlayer height) {
      a();
      if (mc.player != null && mc.level != null) {
         ResourceLocation skin = mc.player.getSkinTextureLocation();

         try {
            skin = height.getSkinTextureLocation();
         } catch (Exception var16) {
         }

         int hurtTime = height.hurtTime;
         float redTint = 1.0F;
         if (hurtTime > 0) {
            float progress = hurtTime / 10.0F;
            redTint = N(Math.min(progress, 1.0F), 0.6F, 1.0F);
         }

         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderTexture(0, skin);
         RenderSystem.setShader(GameRenderer::getPositionTexShader);
         RenderSystem.setShaderColor(1.0F, redTint, redTint, 1.0F);
         d(a, (int)y, (int)width, (int)poseStack, (int)var6, 8, 8, 8, 8, 64, 128206671452624L, 64);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.disableBlend();
      }
   }

   public static void V(Object[] var0) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (h[var4] != null) {
         return var4;
      } else {
         Object var5 = g[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 10;
               case 1 -> 63;
               case 2 -> 51;
               case 3 -> 7;
               case 4 -> 50;
               case 5 -> 47;
               case 6 -> 38;
               case 7 -> 54;
               case 8 -> 59;
               case 9 -> 41;
               case 10 -> 1;
               case 11 -> 43;
               case 12 -> 15;
               case 13 -> 40;
               case 14 -> 9;
               case 15 -> 36;
               case 16 -> 13;
               case 17 -> 19;
               case 18 -> 37;
               case 19 -> 8;
               case 20 -> 60;
               case 21 -> 45;
               case 22 -> 3;
               case 23 -> 22;
               case 24 -> 14;
               case 25 -> 23;
               case 26 -> 52;
               case 27 -> 61;
               case 28 -> 30;
               case 29 -> 11;
               case 30 -> 42;
               case 31 -> 58;
               case 32 -> 4;
               case 33 -> 57;
               case 34 -> 20;
               case 35 -> 0;
               case 36 -> 62;
               case 37 -> 55;
               case 38 -> 6;
               case 39 -> 53;
               case 40 -> 17;
               case 41 -> 5;
               case 42 -> 32;
               case 43 -> 24;
               case 44 -> 16;
               case 45 -> 49;
               case 46 -> 21;
               case 47 -> 33;
               case 48 -> 44;
               case 49 -> 35;
               case 50 -> 28;
               case 51 -> 27;
               case 52 -> 25;
               case 53 -> 56;
               case 54 -> 48;
               case 55 -> 26;
               case 56 -> 46;
               case 57 -> 18;
               case 58 -> 39;
               case 59 -> 2;
               case 60 -> 34;
               case 61 -> 31;
               case 62 -> 29;
               default -> 12;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            h[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static void e(
      PoseStack a, ResourceLocation width, int a, long var3, int poseStack, int texture, int height, float y, float uWidth, float vHeight, float x
   ) {
      R(a, width, 7, 7, 15, 15, 0.0F, 125359772794447L, 0.0F, 15.0F, 15.0F, 1.0F);
   }

   public static void e(PoseStack matrices, long a, double fromX, double fromY, double toX, double toY, double rad, double samples, Color c) {
      int color = c.getRGB();
      Matrix4f matrix = matrices.last().pose();
      float f = (color >> 24 & 0xFF) / 255.0F;
      float g = (color >> 16 & 0xFF) / 255.0F;
      float h = (color >> 8 & 0xFF) / 255.0F;
      float k = (color & 0xFF) / 255.0F;
      RenderSystem.enableBlend();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      j(66127903402541L, matrix, g, h, k, f, fromX, fromY, toX, 0.0, 4.0, 100.0);
      RenderSystem.disableBlend();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 195 && var8 != 'S' && var8 != 'd' && var8 != 219) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'M') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'e') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 195) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'S') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'd') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void b() {
      g[0] = "0^VVPJ9PU\u001f\u0013G?PA\u001d\u000eA}G^\nI@+\u001fm\u001dOQ6I}\u0017OH2E\u001f5RA6";
      g[1] = "otqgwtfzr.4y`zf,)\u007f\"my;n~t5X,|zywh\u001f\u007fix~d\u000fuiazh";
      g[2] = "!\u0013\u0003;K\u000f(\u001d\u0000r\b\u0002.\u001d\u0014p\u0015\u0004l\n\u000bgR\u0005:R8pT\u0014'\u0004(zT\r#\b";
      g[3] = "u^!\u0010+\fz\u001el\u001b!\u0011\u007fCg]1\u0017\u007f\\|]6\u0006xTj\u0001j1s^k\u001666bYc\u0000";
      g[4] = int.class;
      h[4] = "java/lang/Integer";
      g[5] = void.class;
      h[5] = "java/lang/Void";
      g[6] = "+\f\n&PB5\u0004\u0010i3V1";
      g[7] = "Y&\u0013\u0006FWR)\u0002I-CP\"\u0015\u0013\u0001T]";
      g[8] = "@F\u000b\u0002!\u001d@F\u001c^-\u0012Z\r\bC>\u0018J\r\u001aB8\u001dZZQ`%\u0002GM\u0018i\"\u0000GW\u0006";
      g[9] = float.class;
      h[9] = "java/lang/Float";
      g[10] = "]\u000b\u00184-n]\u000b\u000fh!aG@\u001bu2kW@\u001cr9t\u001d/-X\u0002";
      g[11] = double.class;
      h[11] = "java/lang/Double";
      g[12] = "uq7n.]uq 2\"Ro: ,*Qu`m2&Z\u007fq1%1\u001a~z7)7M5Q-4*@bF&.'QiP*33Uow+%1";
      g[13] = "\u0013[|abc\u0013[k=nl\t\u0010k#fo\u0013J&\fng\u0018Li";
      g[14] = "uX\u001bq|fuX\f-pio\u0013\u00180cc\u007f\u0013\u0006+tb5t\u001b:|KrN\u001f3pvXR\u0001+two";
      g[15] = "vg`Ra\u001fvgw\u000em\u0010l,w\u0010e\u0013vv:\u000ei\u0018|gf\u0019~Xlgl\by\u0004},@\u0019t\u0002mpq=x\u001ayq";
      g[16] = "\"U!~8 \"U6\"4/8\u001e'5&&9B65&g\u001eU&? ;/U\u0019?6(8Y:>";
      g[17] = "q\r&\n\f\u007fq\r1V\u0000pkF1H\bsq\u001c|V\u0004x{\r A\u00138k\r*P\u0014dzF\u001dR\u0004ds\t+p\u0004nk\u001d A";
      g[18] = "T\n\u0011\"81]\u0004\u0012k{<[\u0004\u0006if:\u0019\u0015\u0010m!8X\u0017\u0011\"\u00122d\u0011\u001dx0\u0013V\u000b\u001dk0,\u0013!\u0019\u007f!\u0018V\u0006\bc'";
      g[19] = "\u0013*d\u001d\u0001\n\u001a$gTB\u0007\u001c$sV_\u0001^5eR\u0018\u0003\u001f7d\u001d+\t#1hG\t(\u0011+hT\t\u0017T\u0016fF\u001e\u0006\u0015\u0003hP\u0018\n\u0002";
      g[20] = ">t}#\u0014a>tj\u007f\u0018n$?ja\u0010m>e'@\u0010f5r{l\u001f|";
      g[21] = "gIQU!vgIF\t-y}\u0002F\u0017%zgX\u000b\t)qmIW\u001e>1}I]\u000f9ml\u0002q\u001e4k|^@6-qhK@\t";
      g[22] = "ICh\u0002jFIC\u007f^fIS\bkCuCC\blD~\\\tpyO4";
      g[23] = "\u000f*X\u0002^.\u000f*O^R!\u0015aO@Z\"\u000f;\u0002^V)\u0005*^IAi&.AIa\"\u000f+I^V5";
      g[24] = "B.Pj/!B.G6#.XeG(+-B?\n4.)U.Vj\u0003*_?V%!<o'M!,<|'E=':";
      g[25] = "d\u0017}#YQo\u0018ll8_d\u0013h6";
      g[26] = "h\u0011YigV,N\\;\u0004Y\u0000\u0019\t95\r\u0000)\u00039z^/XNe~T";
      g[27] = "QNJsX\u0015_YDl!\n6\u001b\u0001.\u001aYQu8#\u001e[\u0000PY.E\u001a\u0018";
      g[28] = "\u001f:L\r\u0019\u0019H \u0016\u007fy\"`\u001920a5v\u001e=9%FKh\u0006CD\u0011Q2";
      g[29] = "\u0002G\u0018(DfE\u0017\u0000!%e8MD%\u0014qH\n\u0018cI\u001d\u0003\u0011\u0015#LmH\u0017\u0018a%";
      g[30] = "\")7,\u001cyqt)*zR\u0016VE!Do/q!r\u0019q)";
      g[31] = "haTB\u0000W?cH\u0017xYV\"\r\u001fB\n0L4E\u0013Zl|V\u001e\b\u000e=";
      g[32] = "F;+_7h\u0001k3VV叐县栓厎桷伋叐桥叉伐nj\u007f\u00137-Sn*Fv";
      g[33] = "\u001c\nen\u001c\u0001H\b>3a/1#\u000b\u0013 .*5\u000b\r;# '\u0018\u000e!!w\u00058oY\u0015\u001eQ:4\u0004";
      g[34] = "{\u0015z\u001a3i<Eb\u0013ROA\u001f&\u0017c~1XzQ>\u0012";
      g[35] = "3j,=c\u0003\u007f?+Fr/s9`\u007f#/C==?y\t{d,|w";
      g[36] = "MTNjy\f\t\u000bK8\u001a\u0003%\\\u001e:+V%l\u0014:d\u0004\n\u001dYf`\u000e";
      g[37] = "iT\nf|5-\u000b\u000f4\u001f:\u0001\\Z6/d\u0001lP6a=.\u001d\u001dje7";
      g[38] = " g\u0017[\u0001W +PY\u007f\u0007\u001aj\u0011\u0013AR\u001a[GB\u0013\u000359HZ\u0007\t";
      g[39] = "\t\u0004\u0016 /^EQ\u0011[>rIWZbmryS\u0007\"5TA\n\u0016a;";
      g[40] = "\u001fsVgz?Hi\f\u0015\n\u0013kD!B\u0002\u001fgT5\u0015x4\u0019kRt/.C";
      g[41] = "Y\b\u0013\u000e\n\f\b\u001bCKk\b`E\u0012O[^`u\u0018I\u0015\u000fO\u0004U\u0015\u0011\u0005";
      g[42] = "z.\u001eV\u0002H{t\fZ8\u001e\u0013(X\r\bK\u0013\u0012^Y@\u001b=u\u000eDW\u001e";
      g[43] = "4t_\u0002#\fcn\u0005pF0CR<p!\u00072l[\u0011v\u001dh";
      g[44] = "\u001fwLyNTNd\u001c</P&:M8\u0010\u000f&\nG>QW\t{\nbU]";
      g[45] = "?{\u0014R\t.nhD\u0017h*\u00066\u0015\u0013X}\u0006\u0006\u001f\u0015\u0016-)wRI\u0012'";
      g[46] = "S\u0012J^\bMG\u0014Q_hRo\u0010\u0016WP\f\u0003~/\\R\u0000\tE_\u001b\u000eFT";
      g[47] = "p%,\u001e\u0002@7u4\u0017cRJ) F\u001d\u000bqr8TY;w~#QS\u0000,f1\u0015c";
      g[48] = ":\u001efQ\u000b\u0012~Ac\u0003h\u001dR\u00166\u0001XBR&<\u0001\u0016\u001a}Wq]\u0012\u0010";
      g[49] = "\u0007T;\u0002V\u001b\u0002Pz\u0001'H?\u0017sV\u001e\u0018?-p]\u001b\u0017\u0004]7\u0001]J";
      g[50] = "\f2\u00156\u0014w@g\u0012M\u0005[LaYtZ[|e\u00044\u000e}D<\u0015w\u0000";
      g[51] = "\r\u0007j8\u0005\u000fIXojf\u0000e\u000f:hWVe?0h\u0018\u0007JN}4\u001c\r";
      g[52] = "\u0013n <F\u000f\u0001ezd(e%\u0014H\u001clf?\u0016\u001f9\u0019\u0001\u00161.+\u0012[N";
      g[53] = "\u0014\u0013.ffZC\tt\u0014\u0006ak0P[\u001ev}\"JN\u001bc*G|,(\u0007K\u0010fv";
      g[54] = "\tG9\u001e\u00053N\u0017!\u0017d!3Me\u0013U$C\n9U\bH";
      g[55] = "\r\u0018\u0005\n\nqIG\u0000Xi~e\u0010UZX)e _Z\u0017yJQ\u0012\u0006\u0013s";
      g[56] = "'9$X\u007fB'ucZ\u0001\u0012\u001d4#\u00191C\u001d\u0005vN`GpcjTa\u0013";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static void b(PoseStack a, double matrices, float angle, float var4, float x) {
      a.mulPose(Axis.of(new Vector3f((float)angle, var4, x)).rotationDegrees((float)matrices));
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/RenderUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static void x(
      PoseStack a,
      ResourceLocation poseStack,
      int width,
      int v,
      int a,
      int vHeight,
      float y,
      float x,
      float shadowAlpha,
      float shadowOffset,
      long var10,
      boolean a,
      double var13,
      int u,
      float uWidth
   ) {
      long ax = (var10 << 8 | (long)u << 56 >>> 56) ^ 61029000629300L;
      long axx = ax ^ 13700394995389L;
      long axxx = ax ^ 23371015625891L;
      if (b<"e">(-5692619646104586733L, ax) != 0) {
         RenderSystem.setShader(GameRenderer::getPositionTexShader);
         RenderSystem.setShaderTexture(0, poseStack);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(0.101960786F, 0.101960786F, 0.101960786F, 1.0F);
         RenderSystem.texParameter(3553, 10241, 9728);
         RenderSystem.texParameter(3553, 10240, 9728);
         z(axxx, a, (int)(width + var13), (int)(v + var13), a, (int)vHeight, (float)y, (float)x, shadowAlpha, (float)shadowOffset);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.disableBlend();
         R(a, poseStack, width, (int)v, a, (int)vHeight, (float)y, axx, (float)x, shadowAlpha, (float)shadowOffset, 1.0F);
      }
   }

   public static void s(Object[] var0) {
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableBlend();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   public static double s(double a, double var2, double var4) {
      return var2 + (var4 - var2) * (1.0 - a);
   }

   private static void c(
      Matrix4f a,
      BufferBuilder z2,
      float z4,
      float buffer,
      float y2,
      float x2,
      float x3,
      float y4,
      float y3,
      float y1,
      float x1,
      float z3,
      float matrix,
      float z1,
      int x4
   ) {
      z2.vertex(a, z4, (float)buffer, y2).color((int)x4).endVertex();
      z2.vertex(a, x2, x3, y4).color((int)x4).endVertex();
      z2.vertex(a, y3, y1, x1).color((int)x4).endVertex();
      z2.vertex(a, z3, (float)matrix, z1).color((int)x4).endVertex();
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         g[var4] = var21;
         return var21;
      }
   }

   public static void h(Object[] var0) {
      RenderSystem.disableScissor();
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = g[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void f(PoseStack a, float y, long poseStack, float var4, float x, int r) {
      long ax = 61029000629300L ^ poseStack ^ 41089175186617L;
      v(a, y, var4, x, 0, 360, (int)r, ax);
   }

   public static void l(PoseStack a, BlockPos pos, BlockState color, int fillAlpha, boolean poseStack, boolean state, long fillMode, float var8) {
      int ax = U();
      if (!color.isAir()) {
         VoxelShape shape = color.getShape(mc.level, pos);
         if (!shape.isEmpty()) {
            Camera camera = mc.gameRenderer.getMainCamera();
            Vec3 camPos = camera.getPosition();
            double x = pos.getX() - camPos.x;
            double y = pos.getY() - camPos.y;
            double z = pos.getZ() - camPos.z;
            a.pushPose();
            a.translate(x, y, z);
            Iterator var26 = shape.toAabbs().iterator();

            while (true) {
               if (var26.hasNext()) {
                  AABB aabb = (AABB)var26.next();
                  float minX = (float)aabb.minX;
                  float maxX = (float)aabb.maxX;
                  float minY = (float)aabb.minY;
                  float maxY = (float)aabb.maxY;
                  float minZ = (float)aabb.minZ;
                  float maxZ = (float)aabb.maxZ;
                  RenderSystem.enableBlend();
                  RenderSystem.defaultBlendFunc();
                  RenderSystem.disableDepthTest();
                  RenderSystem.setShader(GameRenderer::getPositionColorShader);
                  if (ax != 0) {
                     break;
                  }

                  if (poseStack) {
                     w(a, minX, maxX, minY, maxY, minZ, maxZ, (int)fillAlpha, (int)fillAlpha, 200.0F, 70434559295573L);
                  }

                  if (state) {
                     RenderSystem.disableDepthTest();
                     RenderSystem.defaultBlendFunc();
                     W(a, minX, maxX, minY, 83919906043417L, maxY, minZ, maxZ, (int)fillAlpha, A(32925003317975L, (int)fillAlpha));
                  }

                  if (ax == 0) {
                     continue;
                  }
               }

               RenderSystem.enableDepthTest();
               a.popPose();
               break;
            }
         }
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void d(
      PoseStack a, int vOffset, int vHeight, int a, int var4, int y, int width, int height, int uOffset, int textureWidth, long uWidth, int poseStack
   ) {
      uWidth = (int)(61029000629300L ^ uWidth);
      float u1 = (float)(y + 8) / textureWidth;
      float v1 = (float)(width + 8) / poseStack;
      RenderSystem.setShader(GameRenderer::getPositionTexShader);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      Matrix4f matrix = a.last().pose();
      bufferBuilder.begin(b<"d">(6192086718779133664L, (long)uWidth), b<"d">(6191526282338078057L, (long)uWidth));
      bufferBuilder.vertex(matrix, vOffset, vHeight + var4, 0.0F).uv(0.125F, v1).endVertex();
      bufferBuilder.vertex(matrix, vOffset + a, vHeight + var4, 0.0F).uv(u1, v1).endVertex();
      bufferBuilder.vertex(matrix, vOffset + a, vHeight, 0.0F).uv(u1, 0.125F).endVertex();
      bufferBuilder.vertex(matrix, vOffset, vHeight, 0.0F).uv(0.125F, 0.125F).endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   public static int a() {
      U();

      try {
         return 82;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29728;
      if (e[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])f.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            f.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/render/RenderUtils", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         e[var3] = var15;
      }

      return e[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/RenderUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static void p(int var0) {
      友树何树树何树何友树 = var0;
   }

   public static void p(PoseStack a, ItemStack model, int itemStack, long y, int poseStack, BakedModel a) {
      y = (int)(61029000629300L ^ y);
      b<"Ã">(mc, -5475684370245398465L, (long)y).getTexture(b<"d">(-5473101643195436844L, (long)y)).setFilter(false, false);
      RenderSystem.setShaderTexture(0, b<"d">(-5473101643195436844L, (long)y));
      RenderSystem.enableBlend();
      int var10000 = b<"e">(-5475025521786254921L, (long)y);
      RenderSystem.blendFunc(b<"d">(-5475978089715837104L, (long)y), b<"d">(-5475205024773389713L, (long)y));
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      a.pushPose();
      a.translate(itemStack, poseStack, 100.0F);
      int ax = var10000;
      a.translate(8.0, 8.0, 0.0);
      a.scale(1.0F, -1.0F, 1.0F);
      a.scale(16.0F, 16.0F, 16.0F);
      RenderSystem.applyModelViewMatrix();
      BufferSource bufferSource = mc.renderBuffers().bufferSource();
      boolean flag = !a.usesBlockLight();
      if (flag != 0) {
         Lighting.setupForFlatItems();
      }

      mc.getItemRenderer()
         .render(
            model,
            b<"d">(-5473007537416587483L, (long)y),
            false,
            a,
            bufferSource,
            a<"p">(16248, 7564960160672317271L ^ y),
            b<"d">(-5474154884083007513L, (long)y),
            a
         );
      bufferSource.endBatch();
      RenderSystem.enableDepthTest();
      var10000 = ax;
      if (y > 0L) {
         if (ax != 0) {
            return;
         }

         var10000 = flag;
      }

      if (var10000 != 0) {
         Lighting.setupFor3DItems();
      }

      a.popPose();
      RenderSystem.applyModelViewMatrix();
   }

   public static void k(PoseStack a, Color c, double matrices, double var4, double var6, double var8, double var10, double var12, long var14) {
      V(new Object[0]);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      j(
         66127903402541L,
         a.last().pose(),
         c.getRed() / 255.0F,
         c.getGreen() / 255.0F,
         c.getBlue() / 255.0F,
         c.getAlpha() / 255.0F,
         (double)matrices,
         var4,
         var6,
         var8,
         var10,
         var12
      );
      s(new Object[0]);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (var5 instanceof String) {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         g[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void v(PoseStack a, float poseStack, float x, float color, int radius, int endAngle, int a, long var7) {
      float red = (a >> 16 & 255) / 255.0F;
      int var10000 = U();
      float green = (a >> 8 & 255) / 255.0F;
      float blue = (a & 255) / 255.0F;
      float alpha = (a >> 24 & 255) / 255.0F;
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      int ax = var10000;
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      Matrix4f matrix = a.last().pose();
      bufferBuilder.begin(Mode.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);
      bufferBuilder.vertex(matrix, (float)poseStack, x, 0.0F).color(red, green, blue, alpha).endVertex();
      int angleDiff = (int)(endAngle - radius);
      int segments = Math.max(8, Math.min(60, Math.abs(angleDiff) / 6));
      float angleStep = (float)angleDiff / segments;
      int i = 0;

      while (true) {
         if (i <= segments) {
            float currentAngle = radius + angleStep * i;
            float radians = (float)Math.toRadians(currentAngle);
            float dx = (float)(Math.cos(radians) * 6.0);
            float dy = (float)(Math.sin(radians) * color);
            bufferBuilder.vertex(matrix, poseStack + dx, x + dy, 0.0F).color(red, green, blue, alpha).endVertex();
            i++;
            if (ax != 0) {
               break;
            }

            if (ax == 0) {
               continue;
            }
         }

         BufferUploader.drawWithShader(bufferBuilder.end());
         RenderSystem.disableBlend();
         break;
      }
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static void j(
      long a, Matrix4f cr, float fromX, float var4, float fromY, float var6, double toX, double toY, double radius, double samples, double ca, double cg
   ) {
      a = 61029000629300L ^ a;
      int var10000 = b<"e">(7354858614313933730L, (long)a);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      bufferBuilder.begin(b<"d">(7358357257209803112L, (long)a), b<"d">(7354629136725510966L, (long)a));
      int ax = var10000;
      if (radius - toX < ca) {
         radius = toX + ca;
      }

      if (samples - toY < ca) {
         samples = toY + ca;
      }

      double[][] map = new double[][]{
         {radius - ca, samples - ca, (double)ca}, {radius - ca, toY + ca, (double)ca}, {toX + ca, toY + ca, (double)ca}, {toX + ca, samples - ca, (double)ca}
      };
      int i = 0;

      label57:
      while (true) {
         var10000 = i;

         label55:
         while (true) {
            if (var10000 >= 4) {
               BufferUploader.drawWithShader(bufferBuilder.end());
               if (a >= 0L) {
                  return;
               }
            }

            do {
               double[] current = map[i];
               double rad = current[2];
               var10000 = ax;

               label50:
               while (true) {
                  if (a >= 0L) {
                     if (var10000 != 0) {
                        return;
                     }

                     var10000 = i;
                  }

                  double r = var10000 * 90.0;

                  while (true) {
                     if (!(r < 90.0 + i * 90.0)) {
                        break label50;
                     }

                     float rad1 = (float)Math.toRadians(r);
                     float sin = (float)(Math.sin(rad1) * rad);
                     float cos = (float)(Math.cos(rad1) * rad);
                     bufferBuilder.vertex(cr, (float)current[0] + sin, (float)current[1] + cos, 0.0F).color((float)fromX, var4, (float)fromY, var6).endVertex();
                     r += 90.0 / cg;
                     var10000 = ax;
                     if (a <= 0L) {
                        break;
                     }

                     if (ax != 0) {
                        break label50;
                     }
                  }
               }

               float rad1x = (float)Math.toRadians(90.0 + i * 90.0);
               float sinx = (float)(Math.sin(rad1x) * rad);
               float cosx = (float)(Math.cos(rad1x) * rad);
               bufferBuilder.vertex(cr, (float)current[0] + sinx, (float)current[1] + cosx, 0.0F).color((float)fromX, var4, (float)fromY, var6).endVertex();
               i++;
               var10000 = ax;
               if (a < 0L) {
                  continue label55;
               }

               if (ax == 0) {
                  continue label57;
               }

               BufferUploader.drawWithShader(bufferBuilder.end());
            } while (!(a >= 0L));

            return;
         }
      }
   }

   public static void q(PoseStack a, float a, float var2, float poseStack, float color, long right, int left) {
      U();
      if (a < poseStack) {
         float j = (float)a;
         a = (long)poseStack;
         poseStack = j;
      }

      if (var2 < color) {
         float j = var2;
         var2 = (float)color;
         color = (int)j;
      }

      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      Matrix4f matrix = a.last().pose();
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      bufferBuilder.begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
      bufferBuilder.vertex(matrix, (float)a, (float)color, 0.0F)
         .color((int)(left >> 16 & 255), (int)(left >> 8 & 255), (int)(left & 255), (int)(left >> 24 & 255))
         .endVertex();
      bufferBuilder.vertex(matrix, (float)poseStack, (float)color, 0.0F)
         .color((int)(left >> 16 & 255), (int)(left >> 8 & 255), (int)(left & 255), (int)(left >> 24 & 255))
         .endVertex();
      bufferBuilder.vertex(matrix, (float)poseStack, var2, 0.0F)
         .color((int)(left >> 16 & 255), (int)(left >> 8 & 255), (int)(left & 255), (int)(left >> 24 & 255))
         .endVertex();
      bufferBuilder.vertex(matrix, (float)a, var2, 0.0F)
         .color((int)(left >> 16 & 255), (int)(left >> 8 & 255), (int)(left & 255), (int)(left >> 24 & 255))
         .endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
      RenderSystem.disableBlend();
   }

   public static int U() {
      return 友树何树树何树何友树;
   }

   public static void U(PoseStack a, float a, float var2, long poseStack, LivingEntity target) {
      Lighting.setupFor3DItems();
      BufferSource buffer = mc.renderBuffers().bufferSource();
      float originalYaw = target.getYRot();
      float originalPitch = target.getXRot();
      float originalBodyYaw = b<"Ã">(target, 3060926469880191197L, 4831225195120L);
      b<"S">(target, a - 0.4F, 3060926469880191197L, 4831225195120L);
      target.setYRot(a - 0.2F);
      target.setXRot(var2);
      a.pushPose();
      a.mulPose(new Quaternionf().rotationZ((float)Math.toRadians(180.0)));
      a.scale(-50.0F, 50.0F, 50.0F);
      mc.getEntityRenderDispatcher().render(target, 0.0, 0.0, 0.0, 0.0F, 1.0F, a, buffer, a<"p">(31447, 8773251207207063287L));
      buffer.endBatch();
      a.popPose();
      target.setYRot(originalYaw);
      target.setXRot(originalPitch);
      b<"S">(target, originalBodyYaw, 3060926469880191197L, 4831225195120L);
      Lighting.setupForFlatItems();
   }

   private static void z(long a, PoseStack a, int var3, int width, int uWidth, int u, float vHeight, float height, float y, float v) {
      a = 61029000629300L ^ a;
      RenderSystem.setShader(GameRenderer::getPositionTexShader);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      Matrix4f matrix = a.last().pose();
      float u1 = vHeight / y;
      float v1 = height / v;
      float u2 = (vHeight + uWidth) / y;
      float v2 = (height + u) / v;
      bufferBuilder.begin(b<"d">(6948959379280608097L, (long)a), b<"d">(6948394470003751144L, (long)a));
      bufferBuilder.vertex(matrix, var3, width + u, 0.0F).uv(u1, v2).endVertex();
      bufferBuilder.vertex(matrix, var3 + uWidth, width + u, 0.0F).uv(u2, v2).endVertex();
      bufferBuilder.vertex(matrix, var3 + uWidth, width, 0.0F).uv(u2, v1).endVertex();
      bufferBuilder.vertex(matrix, var3, width, 0.0F).uv(u1, v1).endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
   }

   public static void w(PoseStack a, float maxX, float alpha, float color1, float ps, float maxZ, float minX, int color2, int minZ, float minY, long maxY) {
      Matrix4f matrix = a.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      RenderSystem.disableCull();
      RenderSystem.lineWidth(1.0F);
      buffer.begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
      c(matrix, buffer, maxX, (float)color1, maxZ, alpha, (float)color1, maxZ, alpha, (float)ps, maxZ, maxX, (float)ps, maxZ, 何树友友树树友何树何.S(color2, 0.3F));
      c(matrix, buffer, maxX, (float)color1, minX, maxX, (float)ps, minX, alpha, (float)ps, minX, alpha, (float)color1, minX, 何树友友树树友何树何.S((int)minZ, minY));
      c(matrix, buffer, maxX, (float)color1, maxZ, maxX, (float)ps, maxZ, maxX, (float)ps, minX, maxX, (float)color1, minX, 何树友友树树友何树何.S(color2, minY));
      c(matrix, buffer, alpha, (float)color1, maxZ, alpha, (float)color1, minX, alpha, (float)ps, minX, alpha, (float)ps, maxZ, 何树友友树树友何树何.S((int)minZ, minY));
      c(
         matrix,
         buffer,
         maxX,
         (float)color1,
         maxZ,
         maxX,
         (float)color1,
         minX,
         alpha,
         (float)color1,
         minX,
         alpha,
         (float)color1,
         maxZ,
         何树友友树树友何树何.S(color2, minY)
      );
      c(matrix, buffer, maxX, (float)ps, maxZ, alpha, (float)ps, maxZ, alpha, (float)ps, minX, maxX, (float)ps, minX, 何树友友树树友何树何.S((int)minZ, minY));
      BufferUploader.drawWithShader(buffer.end());
      RenderSystem.enableCull();
   }

   public static void r(
      PoseStack a,
      ResourceLocation vHeight,
      int poseStack,
      int width,
      int height,
      int a,
      float var6,
      float shadowOffset,
      float var8,
      float texture,
      boolean shadow,
      long u,
      double x
   ) {
      x(a, vHeight, 8, 7, 15, 15, 0.0F, 0.0F, 15.0F, 15.0F, 317679498236L, shadow, 1.2, -58, 1.0F);
   }

   public static void y(GuiGraphics a, long color2, float guiGraphics, float x, float a, float var6, float width, int y, int squareSize) {
      int ax = a();
      if (!(a <= 0.0F) && !(var6 <= 0.0F)) {
         float row = 0.0F;

         while (row * width < var6) {
            int col = 0;

            while (true) {
               if (col * width < a) {
                  float currentX = guiGraphics + col * width;
                  float currentY = x + row * width;
                  float actualWidth = Math.min(width, a - col * width);
                  float actualHeight = Math.min(width, var6 - row * width);
                  if (ax != 0) {
                     label44:
                     if (!(actualWidth <= 0.0F)) {
                        float var19;
                        int var10000 = (var19 = actualHeight - 0.0F) == 0.0F ? 0 : (var19 < 0.0F ? -1 : 1);
                        if (ax != 0) {
                           if (var10000 <= 0) {
                              break label44;
                           }

                           float var20;
                           var10000 = (var20 = (row + col) % 2.0F - 0.0F) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
                        }

                        if (ax != 0) {
                           var10000 = (int)(var10000 == 0 ? y : squareSize);
                        }

                        int color = var10000;
                        drawRectangle(a.pose(), currentX, currentY, actualWidth, actualHeight, color);
                     }

                     col++;
                  }

                  if (ax != 0) {
                     continue;
                  }
               }

               row++;
               if (ax == 0) {
                  return;
               }
               break;
            }
         }
      }
   }

   private static int A(long a, int a) {
      a = 61029000629300L ^ a;
      return (int)(a & a<"p">(6743, 3416875791179686037L ^ a)
         | Math.max((int)(a >> 16 & 215), 0) << 16
         | Math.max((int)(a >> 8 & 215), 0) << 8
         | Math.max((int)(a & 215), 0));
   }

   public static float N(float a, float a, float t) {
      return a + (a - a) * 1.0F;
   }

   public static void P(PoseStack a, BlockEntity a, long var2, int poseStack, boolean blockEntity, boolean fillAlpha, float fillMode) {
      BlockPos pos = a.getBlockPos();
      BlockState state = a.getBlockState();
      int var10000 = a();
      VoxelShape shape = state.getShape(mc.level, pos);
      int ax = var10000;
      if (!shape.isEmpty()) {
         Camera camera = mc.gameRenderer.getMainCamera();
         Vec3 camPos = camera.getPosition();
         double x = pos.getX() - camPos.x;
         double y = pos.getY() - camPos.y;
         double z = pos.getZ() - camPos.z;
         a.pushPose();
         a.translate(x, y, z);
         Iterator var27 = shape.toAabbs().iterator();

         while (true) {
            if (var27.hasNext()) {
               AABB aabb = (AABB)var27.next();
               float minX = (float)aabb.minX;
               float maxX = (float)aabb.maxX;
               float minY = (float)aabb.minY;
               float maxY = (float)aabb.maxY;
               float minZ = (float)aabb.minZ;
               float maxZ = (float)aabb.maxZ;
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               RenderSystem.disableDepthTest();
               RenderSystem.setShader(GameRenderer::getPositionColorShader);
               if (ax == 0) {
                  break;
               }

               if (blockEntity) {
                  w(a, minX, maxX, minY, maxY, minZ, maxZ, (int)poseStack, (int)poseStack, 200.0F, 70434559295573L);
               }

               if (fillAlpha) {
                  RenderSystem.disableDepthTest();
                  RenderSystem.defaultBlendFunc();
                  W(a, minX, maxX, minY, 83919906043417L, maxY, minZ, maxZ, (int)poseStack, 何树友友树树友何树何.D((int)poseStack, 116531824401811L));
               }

               if (ax != 0) {
                  continue;
               }
            }

            RenderSystem.enableDepthTest();
            a.popPose();
            break;
         }
      }
   }

   public static void W(PoseStack a, float ps, float minX, float color1, long maxX, float minY, float a, float var8, int color2, int minZ) {
      Matrix4f matrix = a.last().pose();
      BufferBuilder buffer = Tesselator.getInstance().getBuilder();
      RenderSystem.lineWidth(2.5F);
      buffer.begin(Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
      Q(matrix, buffer, (float)ps, (float)color1, (float)a, minX, (float)color1, (float)a, (int)minZ);
      Q(matrix, buffer, minX, (float)color1, (float)a, minX, (float)color1, var8, (int)minZ);
      Q(matrix, buffer, minX, (float)color1, var8, (float)ps, (float)color1, var8, (int)minZ);
      Q(matrix, buffer, (float)ps, (float)color1, var8, (float)ps, (float)color1, (float)a, (int)minZ);
      Q(matrix, buffer, (float)ps, minY, (float)a, minX, minY, (float)a, color2);
      Q(matrix, buffer, minX, minY, (float)a, minX, minY, var8, color2);
      Q(matrix, buffer, minX, minY, var8, (float)ps, minY, var8, color2);
      Q(matrix, buffer, (float)ps, minY, var8, (float)ps, minY, (float)a, color2);
      Q(matrix, buffer, (float)ps, (float)color1, (float)a, (float)ps, minY, (float)a, color2);
      Q(matrix, buffer, minX, (float)color1, (float)a, minX, minY, (float)a, color2);
      Q(matrix, buffer, minX, (float)color1, var8, minX, minY, var8, color2);
      Q(matrix, buffer, (float)ps, (float)color1, var8, (float)ps, minY, var8, color2);
      BufferUploader.drawWithShader(buffer.end());
   }

   public static void T(
      PoseStack a,
      int c2,
      int y,
      float c1,
      float c3,
      int v,
      int x,
      long a,
      float u,
      float c,
      Color textureHeight,
      Color poseStack,
      Color textureWidth,
      Color height
   ) {
      a = 61029000629300L ^ a;
      float f = 1.0F / u;
      float f1 = 1.0F / c;
      Matrix4f matrix = a.last().pose();
      BufferBuilder builder = Tesselator.getInstance().getBuilder();
      builder.begin(b<"d">(2938770686005212102L, a), b<"d">(2940541526299597126L, a));
      builder.vertex(matrix, c2, y + x, 0.0F)
         .uv(0.0F * f, (0.0F + x) * f1)
         .color(height.getRed(), height.getGreen(), height.getBlue(), height.getAlpha())
         .endVertex();
      builder.vertex(matrix, c2 + v, y + x, 0.0F)
         .uv((c1 + v) * f, (c3 + x) * f1)
         .color(textureWidth.getRed(), textureWidth.getGreen(), textureWidth.getBlue(), textureWidth.getAlpha())
         .endVertex();
      builder.vertex(matrix, c2 + v, y, 0.0F)
         .uv((c1 + v) * f, c3 * f1)
         .color(poseStack.getRed(), poseStack.getGreen(), poseStack.getBlue(), poseStack.getAlpha())
         .endVertex();
      builder.vertex(matrix, c2, y, 0.0F)
         .uv(c1 * f, c3 * f1)
         .color(textureHeight.getRed(), textureHeight.getGreen(), textureHeight.getBlue(), textureHeight.getAlpha())
         .endVertex();
      BufferUploader.drawWithShader(builder.end());
   }

   public static void R(
      PoseStack a, ResourceLocation uWidth, int poseStack, int a, int var4, int vHeight, float y, long alpha, float width, float texture, float height, float x
   ) {
      long ax = (long)(61029000629300L ^ alpha ^ 51358310833706L);
      RenderSystem.setShader(GameRenderer::getPositionTexShader);
      RenderSystem.setShaderTexture(0, uWidth);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.texParameter(3553, 10241, 9728);
      RenderSystem.texParameter(3553, 10240, 9728);
      z(ax, a, (int)poseStack, (int)a, var4, (int)vHeight, (float)y, (float)width, (float)texture, (float)height);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.disableBlend();
      RenderSystem.defaultBlendFunc();
   }

   public static void onRender3D(Render3DEvent event) {
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.disableDepthTest();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      Matrix4f matrix = event.poseStack().last().pose();
      bufferBuilder.begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
      友友树友树何友树友何.forEach((box, color) -> {
         float cRed = (color.getRGB() >> 16 & 0xFF) / 255.0F;
         float cGreen = (color.getRGB() >> 8 & 0xFF) / 255.0F;
         float cBlue = (color.getRGB() & 0xFF) / 255.0F;
         float cAlpha = color.getAlpha() / 255.0F;
         float minX = (float)(box.minX - mc.getEntityRenderDispatcher().camera.getPosition().x());
         float minY = (float)(box.minY - mc.getEntityRenderDispatcher().camera.getPosition().y());
         float minZ = (float)(box.minZ - mc.getEntityRenderDispatcher().camera.getPosition().z());
         float maxX = (float)(box.maxX - mc.getEntityRenderDispatcher().camera.getPosition().x());
         float maxY = (float)(box.maxY - mc.getEntityRenderDispatcher().camera.getPosition().y());
         float maxZ = (float)(box.maxZ - mc.getEntityRenderDispatcher().camera.getPosition().z());
         bufferBuilder.vertex(matrix, minX, minY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, minY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, minY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, minY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, maxY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, minY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, minY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, minY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, minY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, minY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, minY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, maxY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, maxY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, minX, maxY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, maxY, maxZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
         bufferBuilder.vertex(matrix, maxX, maxY, minZ).color(cRed, cGreen, cBlue, cAlpha).endVertex();
      });
      BufferUploader.drawWithShader(bufferBuilder.end());
      RenderSystem.disableBlend();
      RenderSystem.enableDepthTest();
      友友树友树何友树友何.clear();
   }

   private static String HE_DA_WEI() {
      return "何建国230622195906030014";
   }

   private static void Q(Matrix4f a, BufferBuilder y2, float z1, float color, float y1, float x2, float buffer, float x1, int matrix) {
      y2.vertex(a, z1, (float)color, y1).color((int)matrix).endVertex();
      y2.vertex(a, x2, (float)buffer, x1).color((int)matrix).endVertex();
   }

   public static void drawRectangle(PoseStack poseStack, float x, float y, float width, float height, int color) {
      float red = (color >> 16 & 0xFF) / 255.0F;
      float green = (color >> 8 & 0xFF) / 255.0F;
      float blue = (color & 0xFF) / 255.0F;
      float alpha = (color >> 24 & 0xFF) / 255.0F;
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      Matrix4f matrix = poseStack.last().pose();
      bufferBuilder.begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
      bufferBuilder.vertex(matrix, x, y + height, 0.0F).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, x + width, y + height, 0.0F).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, x + width, y, 0.0F).color(red, green, blue, alpha).endVertex();
      bufferBuilder.vertex(matrix, x, y, 0.0F).color(red, green, blue, alpha).endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
      RenderSystem.disableBlend();
   }

   public static void G(PoseStack a, float x2, float width, long a, float x1, int poseStack, int y) {
      if (U() == 0) {
         if (width < x2) {
            float temp = x2;
            x2 = (float)width;
            width = (int)temp;
         }

         drawRectangle(a, x2, x1, width - x2 + 1.0F, poseStack, (int)y);
      }
   }

   public static void drawGradientRectL2R(PoseStack poseStack, float x, float y, float width, float height, int startColor, int endColor) {
      float startRed = (startColor >> 16 & 0xFF) / 255.0F;
      float startGreen = (startColor >> 8 & 0xFF) / 255.0F;
      float startBlue = (startColor & 0xFF) / 255.0F;
      float startAlpha = (startColor >> 24 & 0xFF) / 255.0F;
      float endRed = (endColor >> 16 & 0xFF) / 255.0F;
      float endGreen = (endColor >> 8 & 0xFF) / 255.0F;
      float endBlue = (endColor & 0xFF) / 255.0F;
      float endAlpha = (endColor >> 24 & 0xFF) / 255.0F;
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(GameRenderer::getPositionColorShader);
      BufferBuilder bufferBuilder = Tesselator.getInstance().getBuilder();
      Matrix4f matrix = poseStack.last().pose();
      bufferBuilder.begin(Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
      bufferBuilder.vertex(matrix, x, y + height, 0.0F).color(startRed, startGreen, startBlue, startAlpha).endVertex();
      bufferBuilder.vertex(matrix, x + width, y + height, 0.0F).color(endRed, endGreen, endBlue, endAlpha).endVertex();
      bufferBuilder.vertex(matrix, x + width, y, 0.0F).color(endRed, endGreen, endBlue, endAlpha).endVertex();
      bufferBuilder.vertex(matrix, x, y, 0.0F).color(startRed, startGreen, startBlue, startAlpha).endVertex();
      BufferUploader.drawWithShader(bufferBuilder.end());
      RenderSystem.disableBlend();
   }

   public static void drawRoundedRect(PoseStack poseStack, double x, double y, double width, double height, double radius, Color color) {
      k(poseStack, color, x, y, x + width, y + height, radius, 128.0, 3609919736005L);
   }
}
