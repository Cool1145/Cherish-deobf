package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何何友何友何树树树友 implements 何树友 {
   public static final int 友树树树何树何何树树 = 0;
   public static final int 友树何何树树友树何友 = 1;
   public static final int 友友树何树树友何何何;
   public static final int 树何友何树树友树何何;
   public static final int 友树友何何友友树何何;
   public static final int 树树树友树树何友何友;
   public static final int 何树树友友树友友树何;
   public static final int 树友友何树树树何树何;
   public static final int 何树树友友树树何树友;
   public static final int 何树何友何树何何友树;
   public static final int 何何何友树树何树何何;
   public static final int 树树友何树友树树何何;
   public static final int 何何树树树友何树友树;
   public static final int 友友何友树树何何树友;
   public static final int 何树何树树友友树树树;
   public static final int 友树何何友何何何友友;
   public static final int 树树何何树何何树树何;
   public static final int 友树何友何树树树树友;
   public static final int 树何友树友何树何何何;
   public static final int 何何树树何树友树何何;
   public static final int 树何树何何树树何何何;
   private static final Random 何友何树树何树友树树;
   private static final float[] 友何友友何何树何友何;
   private static final float[] 何何友树友树何何树树;
   private static int 树树何何何友何何友友;
   private static final long a;
   private static final Object[] b = new Object[15];
   private static final String[] c = new String[15];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-9028848976341675057L, 2862960904706413451L, MethodHandles.lookup().lookupClass()).a(74109155720076L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (q() != 0) {
         e(54);
      }

      Cipher var1;
      Cipher var12 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(64323297519790L << var2 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var0 = new long[19];
      int var4 = 0;
      String var5 = "|^/\u0081´¹\u0082K²Âb`Ñ«R¤Ëqmå\u0088\u0016\u0019ïùÕ\u008cDïP@øá½÷\u0097\u0081ä\u0082Â\u0018®{\u0014\u0010÷+yì³h÷Â×W\u0099\u0083Ä\u009bÌqJN+8Âì«\u001e\u0011ð!Ä\u008b.&RÃ1z\u0091²þ(ÆÎÀìj\u0082\u001bV·m6\u0082'Áo17\u0005Ü\u0089(üØ\u0017`m\u0011æ®Kw\u009bÇr\u0087%\u0082â,/IÄ\b\u0013`0.àÚ&ëÁ";
      short var6 = 136;
      byte var3 = 0;

      label27:
      while (true) {
         int var10001 = var3;
         var3 += 8;
         byte[] var7 = var5.substring(var10001, var3).getBytes("ISO-8859-1");
         long[] var13 = var0;
         var10001 = var4++;
         long var16 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte var18 = -1;

         while (true) {
            long var8 = var16;
            byte[] var10 = var1.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var20 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var18) {
               case 0:
                  var13[var10001] = var20;
                  if (var3 >= var6) {
                     树何友树友何树何何何 = (int)var0[12];
                     何树树友友树树何树友 = (int)var0[4];
                     树树何何树何何树树何 = (int)var0[17];
                     友树友何何友友树何何 = (int)var0[6];
                     树树友何树友树树何何 = (int)var0[3];
                     树友友何树树树何树何 = (int)var0[16];
                     树树树友树树何友何友 = (int)var0[11];
                     何何何友树树何树何何 = (int)var0[9];
                     何何树树何树友树何何 = (int)var0[7];
                     友树何何友何何何友友 = (int)var0[0];
                     何树何树树友友树树树 = (int)var0[15];
                     友树何友何树树树树友 = (int)var0[2];
                     树何树何何树树何何何 = (int)var0[10];
                     何树树友友树友友树何 = (int)var0[1];
                     何树何友何树何何友树 = (int)var0[14];
                     友友树何树树友何何何 = (int)var0[8];
                     友友何友树树何何树友 = (int)var0[18];
                     何何树树树友何树友树 = (int)var0[5];
                     树何友何树树友树何何 = (int)var0[13];
                     何友何树树何树友树树 = new Random();
                     友何友友何何树何友何 = new float[3];
                     何何友树友树何何树树 = new float[3];
                     return;
                  }
                  break;
               default:
                  var13[var10001] = var20;
                  if (var3 < var6) {
                     continue label27;
                  }

                  var5 = "¹Õ\u009c \u000f\u0084Ô\"W\u008a\u0004>?ºwJ";
                  var6 = 16;
                  var3 = 0;
            }

            byte var15 = var3;
            var3 += 8;
            var7 = var5.substring(var15, var3).getBytes("ISO-8859-1");
            var13 = var0;
            var10001 = var4++;
            var16 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var18 = 0;
         }
      }
   }

   public static int Z(int a) {
      int r = a >> 16 & 0xFF;
      int g = a >> 8 & 0xFF;
      int b = a & 255;
      return (r + g + b) / 3;
   }

   public static void e(int var0) {
      树树何何何友何何友友 = var0;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   public static int x(long a, int var2, int rgb1, int rgb2, int extraAlpha) {
      a = 98364739901867L ^ a;
      long ax = a ^ 110551487286151L;
      int axx = a<"é">(3006515622496956217L, (long)a);
      if (rgb2 == 0) {
         return var2;
      } else {
         int a1;
         int r1;
         int g1;
         int b1;
         int a2;
         int r2;
         int g2;
         int b2;
         int var10000;
         int var10001;
         int var10002;
         label243: {
            label211: {
               label210: {
                  label220: {
                     label208: {
                        label221: {
                           label206: {
                              label222: {
                                 label204: {
                                    label234: {
                                       label202: {
                                          label224: {
                                             label200: {
                                                label225: {
                                                   label198: {
                                                      label226: {
                                                         label196: {
                                                            label227: {
                                                               label194: {
                                                                  label228: {
                                                                     label192: {
                                                                        label229: {
                                                                           label190: {
                                                                              label230: {
                                                                                 a1 = var2 >> 24 & 0xFF;
                                                                                 r1 = var2 >> 16 & 0xFF;
                                                                                 g1 = var2 >> 8 & 0xFF;
                                                                                 b1 = var2 & 0xFF;
                                                                                 a2 = rgb1 >> 24 & 0xFF;
                                                                                 r2 = rgb1 >> 16 & 0xFF;
                                                                                 g2 = rgb1 >> 8 & 0xFF;
                                                                                 b2 = rgb1 & 0xFF;
                                                                                 switch (rgb2) {
                                                                                    case 1:
                                                                                    case 2:
                                                                                       r1 = Math.min(r1, r2);
                                                                                       g1 = Math.min(g1, g2);
                                                                                       b1 = Math.min(b1, b2);
                                                                                       var10000 = axx;
                                                                                       if (a <= 0L) {
                                                                                          break;
                                                                                       }

                                                                                       if (axx == 0) {
                                                                                          break label220;
                                                                                       }
                                                                                    case 3:
                                                                                       r1 = Math.max(r1, r2);
                                                                                       g1 = Math.max(g1, g2);
                                                                                       b1 = Math.max(b1, b2);
                                                                                       var10000 = axx;
                                                                                       break;
                                                                                    case 4:
                                                                                       break label230;
                                                                                    case 5:
                                                                                       break label229;
                                                                                    case 6:
                                                                                       break label228;
                                                                                    case 7:
                                                                                       break label227;
                                                                                    case 8:
                                                                                    case 9:
                                                                                    case 10:
                                                                                    case 11:
                                                                                       break label224;
                                                                                    case 12:
                                                                                       break label234;
                                                                                    case 13:
                                                                                       break label225;
                                                                                    case 14:
                                                                                       break label222;
                                                                                    case 15:
                                                                                       break label221;
                                                                                    case 16:
                                                                                    default:
                                                                                       break label220;
                                                                                    case 17:
                                                                                       break label226;
                                                                                    case 18:
                                                                                       break label211;
                                                                                    case 19:
                                                                                       return a1 * a2 / 255 << 24 | r2 << 16 | g2 << 8 | b2;
                                                                                    case 20:
                                                                                       int na = 255 - a1;
                                                                                       return a1 << 24 | na << 16 | na << 8 | na;
                                                                                 }

                                                                                 if (a < 0L) {
                                                                                    break label190;
                                                                                 }

                                                                                 if (var10000 == 0) {
                                                                                    break label220;
                                                                                 }
                                                                              }

                                                                              r1 = q(ax, r1 + r2);
                                                                              g1 = q(ax, g1 + g2);
                                                                              b1 = q(ax, b1 + b2);
                                                                              var10000 = axx;
                                                                           }

                                                                           if (a < 0L) {
                                                                              break label192;
                                                                           }

                                                                           if (var10000 == 0) {
                                                                              break label220;
                                                                           }
                                                                        }

                                                                        r1 = q(ax, r2 - r1);
                                                                        g1 = q(ax, g2 - g1);
                                                                        b1 = q(ax, b2 - b1);
                                                                        var10000 = axx;
                                                                     }

                                                                     if (a < 0L) {
                                                                        break label194;
                                                                     }

                                                                     if (var10000 == 0) {
                                                                        break label220;
                                                                     }
                                                                  }

                                                                  r1 = q(ax, Math.abs(r1 - r2));
                                                                  g1 = q(ax, Math.abs(g1 - g2));
                                                                  b1 = q(ax, Math.abs(b1 - b2));
                                                                  var10000 = axx;
                                                               }

                                                               if (a < 0L) {
                                                                  break label196;
                                                               }

                                                               if (var10000 == 0) {
                                                                  break label220;
                                                               }
                                                            }

                                                            r1 = q(ax, r1 * r2 / 255);
                                                            g1 = q(ax, g1 * g2 / 255);
                                                            b1 = q(ax, b1 * b2 / 255);
                                                            var10000 = axx;
                                                         }

                                                         if (a < 0L) {
                                                            break label198;
                                                         }

                                                         if (var10000 == 0) {
                                                            break label220;
                                                         }
                                                      }

                                                      var10000 = a<"Í">(3006236023259276224L, (long)a).nextInt() & 0xFF;
                                                   }

                                                   var10001 = a1;
                                                   var10002 = axx;
                                                   if (a <= 0L) {
                                                      break label243;
                                                   }

                                                   if (axx != 0) {
                                                      break label210;
                                                   }

                                                   if (var10000 > a1) {
                                                      break label220;
                                                   }

                                                   r1 = r2;
                                                   g1 = g2;
                                                   b1 = b2;
                                                   var10000 = axx;
                                                   if (a < 0L) {
                                                      break label200;
                                                   }

                                                   if (axx == 0) {
                                                      break label220;
                                                   }
                                                }

                                                r1 = (r1 + r2) / 2;
                                                g1 = (g1 + g2) / 2;
                                                b1 = (b1 + b2) / 2;
                                                var10000 = axx;
                                             }

                                             if (a <= 0L) {
                                                break label202;
                                             }

                                             if (var10000 == 0) {
                                                break label220;
                                             }
                                          }

                                          Color.RGBtoHSB(r1, g1, b1, a<"Í">(3006503823690190146L, (long)a));
                                          Color.RGBtoHSB(r2, g2, b2, a<"Í">(3006624333367203127L, (long)a));
                                          var10000 = rgb2;
                                       }

                                       if (a >= 0L) {
                                          label137:
                                          if (a > 0L) {
                                             switch (var10000) {
                                                case 8:
                                                   a<"Í">(3006624333367203127L, (long)a)[0] = a<"Í">(3006503823690190146L, (long)a)[0];
                                                   var10000 = axx;
                                                   if (a <= 0L) {
                                                      break label137;
                                                   }

                                                   if (axx == 0) {
                                                      break;
                                                   }
                                                case 9:
                                                   a<"Í">(3006624333367203127L, (long)a)[1] = a<"Í">(3006503823690190146L, (long)a)[1];
                                                   var10000 = axx;
                                                   if (a <= 0L) {
                                                      break label137;
                                                   }

                                                   if (axx == 0) {
                                                      break;
                                                   }
                                                case 10:
                                                   a<"Í">(3006624333367203127L, (long)a)[2] = a<"Í">(3006503823690190146L, (long)a)[2];
                                                   var10000 = axx;
                                                   if (a < 0L) {
                                                      break label137;
                                                   }

                                                   if (axx == 0) {
                                                      break;
                                                   }
                                                case 11:
                                                   a<"Í">(3006624333367203127L, (long)a)[0] = a<"Í">(3006503823690190146L, (long)a)[0];
                                                   a<"Í">(3006624333367203127L, (long)a)[1] = a<"Í">(3006503823690190146L, (long)a)[1];
                                             }

                                             var2 = Color.HSBtoRGB(
                                                a<"Í">(3006624333367203127L, (long)a)[0],
                                                a<"Í">(3006624333367203127L, (long)a)[1],
                                                a<"Í">(3006624333367203127L, (long)a)[2]
                                             );
                                             r1 = var2 >> 16 & 0xFF;
                                             g1 = var2 >> 8 & 0xFF;
                                             var10000 = var2;
                                          }

                                          b1 = var10000 & 0xFF;
                                          var10000 = axx;
                                       }

                                       if (a <= 0L) {
                                          break label204;
                                       }

                                       if (var10000 == 0) {
                                          break label220;
                                       }
                                    }

                                    r1 = 255 - (255 - r1) * (255 - r2) / 255;
                                    g1 = 255 - (255 - g1) * (255 - g2) / 255;
                                    b1 = 255 - (255 - b1) * (255 - b2) / 255;
                                    var10000 = axx;
                                 }

                                 if (a < 0L) {
                                    break label206;
                                 }

                                 if (var10000 == 0) {
                                    break label220;
                                 }
                              }

                              var10000 = 255 - (255 - r1) * (255 - r2) / 255;
                           }

                           int s = var10000;
                           int m = r1 * r2 / 255;
                           r1 = (s * r1 + m * (255 - r1)) / 255;
                           s = 255 - (255 - g1) * (255 - g2) / 255;
                           m = g1 * g2 / 255;
                           g1 = (s * g1 + m * (255 - g1)) / 255;
                           s = 255 - (255 - b1) * (255 - b2) / 255;
                           m = b1 * b2 / 255;
                           b1 = (s * b1 + m * (255 - b1)) / 255;
                           var10000 = axx;
                           if (a <= 0L) {
                              break label208;
                           }

                           if (axx == 0) {
                              break label220;
                           }
                        }

                        b1 = 255;
                        g1 = 255;
                        r1 = 255;
                        var10000 = axx;
                     }

                     if (a < 0L) {
                        return var10000;
                     }

                     if (var10000 != 0) {
                        break label211;
                     }
                  }

                  var10000 = 255;
                  var10001 = 255;
               }

               var10002 = axx;
               break label243;
            }

            r1 = q(ax, r2 * a1 / 255);
            g1 = q(ax, g2 * a1 / 255);
            b1 = q(ax, b2 * a1 / 255);
            return q(ax, a2 * a1 / 255) << 24 | r1 << 16 | g1 << 8 | b1;
         }

         if (var10002 == 0) {
            if (var10000 == var10001) {
               if (a <= 0L) {
                  return a1;
               }

               if (a1 == 255) {
                  return a1 << 24 | r1 << 16 | g1 << 8 | b1;
               }
            }

            a1 = a1 * extraAlpha / 255;
            var10000 = (255 - a1) * a2;
            var10001 = 255;
         }

         int a3 = var10000 / var10001;
         r1 = q(ax, (r1 * a1 + r2 * a3) / 255);
         g1 = q(ax, (g1 * a1 + g2 * a3) / 255);
         b1 = q(ax, (b1 * a1 + b2 * a3) / 255);
         a1 = q(ax, a1 + a3);
         return a1 << 24 | r1 << 16 | g1 << 8 | b1;
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何何友何友何树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 248 && var8 != 'L' && var8 != 205 && var8 != 186) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'V') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 233) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 248) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'L') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 205) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 19;
               case 1 -> 39;
               case 2 -> 28;
               case 3 -> 4;
               case 4 -> 21;
               case 5 -> 47;
               case 6 -> 31;
               case 7 -> 3;
               case 8 -> 11;
               case 9 -> 2;
               case 10 -> 9;
               case 11 -> 5;
               case 12 -> 51;
               case 13 -> 35;
               case 14 -> 40;
               case 15 -> 13;
               case 16 -> 46;
               case 17 -> 43;
               case 18 -> 36;
               case 19 -> 22;
               case 20 -> 45;
               case 21 -> 15;
               case 22 -> 12;
               case 23 -> 16;
               case 24 -> 26;
               case 25 -> 37;
               case 26 -> 24;
               case 27 -> 44;
               case 28 -> 41;
               case 29 -> 6;
               case 30 -> 1;
               case 31 -> 57;
               case 32 -> 18;
               case 33 -> 60;
               case 34 -> 48;
               case 35 -> 27;
               case 36 -> 14;
               case 37 -> 30;
               case 38 -> 32;
               case 39 -> 63;
               case 40 -> 7;
               case 41 -> 34;
               case 42 -> 59;
               case 43 -> 38;
               case 44 -> 52;
               case 45 -> 33;
               case 46 -> 50;
               case 47 -> 0;
               case 48 -> 58;
               case 49 -> 20;
               case 50 -> 55;
               case 51 -> 29;
               case 52 -> 17;
               case 53 -> 23;
               case 54 -> 56;
               case 55 -> 54;
               case 56 -> 25;
               case 57 -> 53;
               case 58 -> 10;
               case 59 -> 8;
               case 60 -> 42;
               case 61 -> 62;
               case 62 -> 61;
               default -> 49;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "Q^\u0011QX\u000f^\u001e\\ZR\u0012[CW\u001cB\u0014[\\L\u001cE\u0005\\TZ@\u0019伵佧叻佪叹佢桱栣校叴";
      b[1] = "\u0011%\u0002\u001d\u0007\u0003\u001a*\u0013R{\u001a\u00150\u001d\u0011L*\u0003'\u0011\f]\u0006\u0014*";
      b[2] = int.class;
      c[2] = "java/lang/Integer";
      b[3] = "G-";
      b[4] = "i6h\tA{w>rF=om3q\u0005";
      b[5] = "YB";
      b[6] = void.class;
      c[6] = "java/lang/Void";
      b[7] = "]\u0013\f7bqV\u001c\u001dx\u0003\u007f]\u0017\u0019\"";
      b[8] = "U]^\u00140`\u0017\u0006\u001av`\u0005P\u0001\u001fHmo\u0018_\u0017\u0019\r9V\u0001J\u0012v`\u0015\fDv";
      b[9] = "\"t\u007f)&\u0014`/;K但厲佃桗栞伖栂厲标桗\u0007pqL$6{9w\b/";
      b[10] = "\u0014%{.>\u001fV~?Laz\u0011y:rc\u0010Y'2#\u0003";
      b[11] = "(y\u0003<Bqj\"G^\u0016\u0014e.B.Byy;\u001d^\u000ey-3F3\u0012lrC";
      b[12] = "1s\u0019cp\u0019s(]\u0001厎伡収厊似作桔伡収伔a=q\u0000vw^p$@=";
      b[13] = "+H\u001d\u00189oi\u0013Yz}\n.\u0014\\Dd`fJT\u0015\u0004";
      b[14] = "\t\u0002\u0012\u0016\u000f#KYVt佯伛叶校厩桭佯伛栬校jH\u000e:N\u0006U\u0005[z\u0005";
   }

   public static int g(long a, int var2, int rgb1, int rgb2) {
      long ax = 98364739901867L ^ a ^ 22857644878359L;
      return x(ax, var2, rgb1, rgb2, 255);
   }

   public static int j() {
      return 树树何何何友何何友友;
   }

   public static int q(long a, int var2) {
      a = 98364739901867L ^ a;
      int var4 = a<"é">(8904940261679464036L, (long)a);
      if (var2 < 0) {
         return 0;
      } else {
         int var10001 = var4;
         if (a > 0L) {
            if (var4 == 0) {
               return var2;
            }

            var10001 = 255;
         }

         return var2 > var10001 ? 255 : var2;
      }
   }

   public static int q() {
      j();

      try {
         return 110;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public static boolean y(long a, int a, int var3, int rgb2) {
      a = 98364739901867L ^ a;
      a<"é">(-5389131143249743675L, (long)a);
      int r1 = (int)(a >> 16 & 255);
      int g1 = (int)(a >> 8 & 255);
      int b1 = (int)(a & 255);
      int r2 = var3 >> 16 & 0xFF;
      int g2 = var3 >> 8 & 0xFF;
      int b2 = var3 & 0xFF;
      return Math.abs(r1 - r2) <= rgb2 && Math.abs(g1 - g2) <= rgb2 && Math.abs(b1 - b2) <= rgb2;
   }

   public static int E(int a, int rgb2, int a, int var3, int channelMask, long extraAlpha) {
      long ax = 98364739901867L ^ extraAlpha ^ 20240602083615L;
      return rgb2 & ~channelMask | x(ax, a & channelMask, rgb2, (int)a, var3);
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖国企上班";
   }

   public static int O(long a, int v2, int v1, float a) {
      long ax = 98364739901867L ^ a ^ 50534738677710L;
      return q(ax, (int)(v2 + a * (v1 - v2)));
   }
}
