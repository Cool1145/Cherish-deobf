package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.image.BufferedImage;
import java.awt.image.Kernel;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何何何树友何何友树树 extends 树树何树何友友友友友 implements 何树友 {
   protected float 友友何何何友友何树树;
   protected Kernel 何何何友何何何友何何;
   private static final long c;
   private static final String e;
   private static final Object[] j = new Object[18];
   private static final String[] k = new String[18];
   private static String HE_SHU_YOU;

   public 何何何树友何何友树树(short a, short a, int a) {
      long ax = ((long)a << 48 | (long)a << 48 >>> 16 | (long)a << 32 >>> 32) ^ 110892771744203L ^ 103272493145512L;
      this(2.0F, ax);
   }

   public 何何何树友何何友树树(float radius, long a) {
      long var10000 = 110892771744203L ^ a;
      int ax = (int)((110892771744203L ^ a ^ 31860139495869L) >>> 48);
      long axx = (110892771744203L ^ a ^ 31860139495869L) << 16 >>> 16;
      long axxx = var10000 ^ 114418161206042L;
      super((char)ax, axx);
      this.g(axxx, radius);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3579248859996563214L, 5717130263662838304L, MethodHandles.lookup().lookupClass()).a(60384639031415L);
      // $VF: monitorexit
      c = var10000;
      c();
      long var0 = 74263195704805L;
      Cipher var2;
      Cipher var4 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var4.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var5 = b(var2.doFinal("Å\u0005üý\u0092RB\u0000\u0087Ì\u0092Y\u0083GôÉ£ÉàÅÖ\u0007*\u007f".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      e = var5;
   }

   @Override
   public String toString() {
      return "Blur/Gaussian Blur...";
   }

   public static void J(
      Kernel param0, int[] param1, long param2, int[] param4, int param5, int param6, boolean param7, boolean param8, boolean param9, int param10
   ) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.RuntimeException: parsing failure!
      //   at org.jetbrains.java.decompiler.modules.decompiler.decompose.DomHelper.parseGraph(DomHelper.java:211)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:166)
      //
      // Bytecode:
      // 000: ldc2_w 110892771744203
      // 003: lload 2
      // 004: lxor
      // 005: lstore 2
      // 006: lload 2
      // 007: dup2
      // 008: ldc2_w 5867615368820
      // 00b: lxor
      // 00c: lstore 12
      // 00e: pop2
      // 00f: ldc2_w 1462959303928702418
      // 012: lload 2
      // 013: invokedynamic é (JJ)I bsm=cn/cool/cherish/utils/render/何何何树友何何友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 018: aload 0
      // 019: aconst_null
      // 01a: invokevirtual java/awt/image/Kernel.getKernelData ([F)[F
      // 01d: astore 15
      // 01f: aload 0
      // 020: invokevirtual java/awt/image/Kernel.getWidth ()I
      // 023: istore 16
      // 025: iload 16
      // 027: bipush 2
      // 028: idiv
      // 029: istore 17
      // 02b: bipush 0
      // 02c: istore 18
      // 02e: istore 14
      // 030: iload 18
      // 032: iload 6
      // 034: if_icmpge 2f4
      // 037: iload 18
      // 039: istore 19
      // 03b: iload 18
      // 03d: iload 5
      // 03f: imul
      // 040: istore 20
      // 042: bipush 0
      // 043: istore 21
      // 045: iload 21
      // 047: iload 5
      // 049: if_icmpge 2e6
      // 04c: fconst_0
      // 04d: fstore 22
      // 04f: fconst_0
      // 050: fstore 23
      // 052: fconst_0
      // 053: fstore 24
      // 055: fconst_0
      // 056: fstore 25
      // 058: iload 17
      // 05a: istore 26
      // 05c: iload 17
      // 05e: ineg
      // 05f: iload 14
      // 061: ifne 032
      // 064: istore 27
      // 066: iload 27
      // 068: iload 17
      // 06a: if_icmpgt 20a
      // 06d: aload 15
      // 06f: iload 26
      // 071: iload 27
      // 073: iadd
      // 074: faload
      // 075: fstore 28
      // 077: iload 14
      // 079: lload 2
      // 07a: lconst_0
      // 07b: lcmp
      // 07c: ifle 207
      // 07f: ifne 205
      // 082: fload 28
      // 084: fconst_0
      // 085: fcmpl
      // 086: iload 14
      // 088: lload 2
      // 089: lconst_0
      // 08a: lcmp
      // 08b: ifle 214
      // 08e: ifne 212
      // 091: goto 094
      // 094: ifeq 202
      // 097: goto 09a
      // 09a: iload 21
      // 09c: iload 27
      // 09e: iadd
      // 09f: istore 29
      // 0a1: iload 29
      // 0a3: iload 14
      // 0a5: lload 2
      // 0a6: lconst_0
      // 0a7: lcmp
      // 0a8: iflt 110
      // 0ab: ifne 10e
      // 0ae: ifge 109
      // 0b1: goto 0b4
      // 0b4: iload 10
      // 0b6: ldc2_w 1462499246237088172
      // 0b9: lload 2
      // 0ba: invokedynamic Ê (JJ)I bsm=cn/cool/cherish/utils/render/何何何树友何何友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0bf: iload 14
      // 0c1: ifne 0f1
      // 0c4: goto 0c7
      // 0c7: if_icmpne 0db
      // 0ca: goto 0cd
      // 0cd: bipush 0
      // 0ce: istore 29
      // 0d0: iload 14
      // 0d2: lload 2
      // 0d3: lconst_0
      // 0d4: lcmp
      // 0d5: ifle 0dd
      // 0d8: ifeq 16e
      // 0db: iload 10
      // 0dd: iload 14
      // 0df: ifne 175
      // 0e2: goto 0e5
      // 0e5: ldc2_w 1462281418979072542
      // 0e8: lload 2
      // 0e9: invokedynamic Ê (JJ)I bsm=cn/cool/cherish/utils/render/何何何树友何何友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0ee: goto 0f1
      // 0f1: if_icmpne 16e
      // 0f4: iload 21
      // 0f6: iload 5
      // 0f8: iadd
      // 0f9: iload 5
      // 0fb: irem
      // 0fc: istore 29
      // 0fe: iload 14
      // 100: lload 2
      // 101: lconst_0
      // 102: lcmp
      // 103: iflt 10b
      // 106: ifeq 16e
      // 109: iload 29
      // 10b: goto 10e
      // 10e: iload 14
      // 110: lload 2
      // 111: lconst_0
      // 112: lcmp
      // 113: iflt 11b
      // 116: ifne 175
      // 119: iload 5
      // 11b: if_icmplt 16e
      // 11e: goto 121
      // 121: iload 10
      // 123: ldc2_w 1462499246237088172
      // 126: lload 2
      // 127: invokedynamic Ê (JJ)I bsm=cn/cool/cherish/utils/render/何何何树友何何友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 12c: iload 14
      // 12e: ifne 161
      // 131: goto 134
      // 134: if_icmpne 14b
      // 137: goto 13a
      // 13a: iload 5
      // 13c: bipush 1
      // 13d: isub
      // 13e: istore 29
      // 140: iload 14
      // 142: lload 2
      // 143: lconst_0
      // 144: lcmp
      // 145: iflt 14d
      // 148: ifeq 16e
      // 14b: iload 10
      // 14d: iload 14
      // 14f: ifne 175
      // 152: goto 155
      // 155: ldc2_w 1462281418979072542
      // 158: lload 2
      // 159: invokedynamic Ê (JJ)I bsm=cn/cool/cherish/utils/render/何何何树友何何友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 15e: goto 161
      // 161: if_icmpne 16e
      // 164: iload 21
      // 166: iload 5
      // 168: iadd
      // 169: iload 5
      // 16b: irem
      // 16c: istore 29
      // 16e: aload 1
      // 16f: iload 20
      // 171: iload 29
      // 173: iadd
      // 174: iaload
      // 175: istore 30
      // 177: iload 30
      // 179: bipush 24
      // 17b: ishr
      // 17c: sipush 255
      // 17f: iand
      // 180: istore 31
      // 182: iload 30
      // 184: bipush 16
      // 186: ishr
      // 187: sipush 255
      // 18a: iand
      // 18b: istore 32
      // 18d: iload 30
      // 18f: bipush 8
      // 191: ishr
      // 192: sipush 255
      // 195: iand
      // 196: istore 33
      // 198: iload 30
      // 19a: sipush 255
      // 19d: iand
      // 19e: istore 34
      // 1a0: iload 14
      // 1a2: lload 2
      // 1a3: lconst_0
      // 1a4: lcmp
      // 1a5: ifle 1ad
      // 1a8: ifne 1f7
      // 1ab: iload 8
      // 1ad: ifeq 1d6
      // 1b0: goto 1b3
      // 1b3: iload 31
      // 1b5: i2f
      // 1b6: ldc 0.003921569
      // 1b8: fmul
      // 1b9: fstore 35
      // 1bb: iload 32
      // 1bd: i2f
      // 1be: fload 35
      // 1c0: fmul
      // 1c1: f2i
      // 1c2: istore 32
      // 1c4: iload 33
      // 1c6: i2f
      // 1c7: fload 35
      // 1c9: fmul
      // 1ca: f2i
      // 1cb: istore 33
      // 1cd: iload 34
      // 1cf: i2f
      // 1d0: fload 35
      // 1d2: fmul
      // 1d3: f2i
      // 1d4: istore 34
      // 1d6: fload 25
      // 1d8: fload 28
      // 1da: iload 31
      // 1dc: i2f
      // 1dd: fmul
      // 1de: fadd
      // 1df: fstore 25
      // 1e1: fload 22
      // 1e3: fload 28
      // 1e5: iload 32
      // 1e7: i2f
      // 1e8: fmul
      // 1e9: fadd
      // 1ea: fstore 22
      // 1ec: fload 23
      // 1ee: fload 28
      // 1f0: iload 33
      // 1f2: i2f
      // 1f3: fmul
      // 1f4: fadd
      // 1f5: fstore 23
      // 1f7: fload 24
      // 1f9: fload 28
      // 1fb: iload 34
      // 1fd: i2f
      // 1fe: fmul
      // 1ff: fadd
      // 200: fstore 24
      // 202: iinc 27 1
      // 205: iload 14
      // 207: ifeq 066
      // 20a: lload 2
      // 20b: lconst_0
      // 20c: lcmp
      // 20d: iflt 28b
      // 210: iload 9
      // 212: iload 14
      // 214: ifne 266
      // 217: ifeq 264
      // 21a: goto 21d
      // 21d: fload 25
      // 21f: fconst_0
      // 220: fcmpl
      // 221: iload 14
      // 223: ifne 266
      // 226: goto 229
      // 229: ifeq 264
      // 22c: goto 22f
      // 22f: fload 25
      // 231: ldc 255.0
      // 233: fcmpl
      // 234: iload 14
      // 236: lload 2
      // 237: lconst_0
      // 238: lcmp
      // 239: iflt 268
      // 23c: ifne 266
      // 23f: goto 242
      // 242: ifeq 264
      // 245: goto 248
      // 248: ldc 255.0
      // 24a: fload 25
      // 24c: fdiv
      // 24d: fstore 27
      // 24f: fload 22
      // 251: fload 27
      // 253: fmul
      // 254: fstore 22
      // 256: fload 23
      // 258: fload 27
      // 25a: fmul
      // 25b: fstore 23
      // 25d: fload 24
      // 25f: fload 27
      // 261: fmul
      // 262: fstore 24
      // 264: iload 7
      // 266: iload 14
      // 268: ifne 283
      // 26b: ifeq 286
      // 26e: goto 271
      // 271: fload 25
      // 273: f2d
      // 274: ldc2_w 0.5
      // 277: dadd
      // 278: d2i
      // 279: lload 12
      // 27b: dup2_x1
      // 27c: pop2
      // 27d: invokestatic cn/cool/cherish/utils/render/何何友何友何树树树友.q (JI)I
      // 280: goto 283
      // 283: goto 289
      // 286: sipush 255
      // 289: istore 27
      // 28b: fload 22
      // 28d: f2d
      // 28e: ldc2_w 0.5
      // 291: dadd
      // 292: d2i
      // 293: lload 12
      // 295: dup2_x1
      // 296: pop2
      // 297: invokestatic cn/cool/cherish/utils/render/何何友何友何树树树友.q (JI)I
      // 29a: istore 28
      // 29c: fload 23
      // 29e: f2d
      // 29f: ldc2_w 0.5
      // 2a2: dadd
      // 2a3: d2i
      // 2a4: lload 12
      // 2a6: dup2_x1
      // 2a7: pop2
      // 2a8: invokestatic cn/cool/cherish/utils/render/何何友何友何树树树友.q (JI)I
      // 2ab: istore 29
      // 2ad: fload 24
      // 2af: f2d
      // 2b0: ldc2_w 0.5
      // 2b3: dadd
      // 2b4: d2i
      // 2b5: lload 12
      // 2b7: dup2_x1
      // 2b8: pop2
      // 2b9: invokestatic cn/cool/cherish/utils/render/何何友何友何树树树友.q (JI)I
      // 2bc: istore 30
      // 2be: aload 4
      // 2c0: iload 19
      // 2c2: iload 27
      // 2c4: bipush 24
      // 2c6: ishl
      // 2c7: iload 28
      // 2c9: bipush 16
      // 2cb: ishl
      // 2cc: ior
      // 2cd: iload 29
      // 2cf: bipush 8
      // 2d1: ishl
      // 2d2: ior
      // 2d3: iload 30
      // 2d5: ior
      // 2d6: iastore
      // 2d7: iload 19
      // 2d9: iload 6
      // 2db: iadd
      // 2dc: istore 19
      // 2de: iinc 21 1
      // 2e1: iload 14
      // 2e3: ifeq 045
      // 2e6: iinc 18 1
      // 2e9: iload 14
      // 2eb: lload 2
      // 2ec: lconst_0
      // 2ed: lcmp
      // 2ee: ifle 032
      // 2f1: ifeq 030
      // 2f4: lload 2
      // 2f5: lconst_0
      // 2f6: lcmp
      // 2f7: iflt 037
      // 2fa: return
   }

   private static Field e(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (k[var4] != null) {
         return var4;
      } else {
         Object var5 = j[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 61;
               case 1 -> 15;
               case 2 -> 0;
               case 3 -> 25;
               case 4 -> 16;
               case 5 -> 47;
               case 6 -> 29;
               case 7 -> 43;
               case 8 -> 46;
               case 9 -> 36;
               case 10 -> 12;
               case 11 -> 54;
               case 12 -> 7;
               case 13 -> 39;
               case 14 -> 31;
               case 15 -> 17;
               case 16 -> 5;
               case 17 -> 41;
               case 18 -> 8;
               case 19 -> 35;
               case 20 -> 63;
               case 21 -> 45;
               case 22 -> 9;
               case 23 -> 26;
               case 24 -> 56;
               case 25 -> 21;
               case 26 -> 19;
               case 27 -> 50;
               case 28 -> 3;
               case 29 -> 27;
               case 30 -> 24;
               case 31 -> 23;
               case 32 -> 38;
               case 33 -> 13;
               case 34 -> 42;
               case 35 -> 53;
               case 36 -> 1;
               case 37 -> 4;
               case 38 -> 62;
               case 39 -> 49;
               case 40 -> 2;
               case 41 -> 11;
               case 42 -> 18;
               case 43 -> 10;
               case 44 -> 30;
               case 45 -> 20;
               case 46 -> 59;
               case 47 -> 55;
               case 48 -> 44;
               case 49 -> 32;
               case 50 -> 28;
               case 51 -> 57;
               case 52 -> 37;
               case 53 -> 34;
               case 54 -> 14;
               case 55 -> 58;
               case 56 -> 33;
               case 57 -> 60;
               case 58 -> 40;
               case 59 -> 51;
               case 60 -> 6;
               case 61 -> 22;
               case 62 -> 48;
               default -> 52;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               if (var10 < 0) {
                  var10 += 128;
               }

               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var15 = var7[var13 % var7.length];
               if (var15 == 0) {
                  break;
               }

               var12[var13] = (char)(var12[var13] ^ var15);
            }

            k[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static Kernel x(float param0, long param1) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: Could not find destination nodes for stat id {Do}:33 from source 30_tail
      //   at org.jetbrains.java.decompiler.modules.decompiler.flow.FlattenStatementsHelper.setEdges(FlattenStatementsHelper.java:563)
      //   at org.jetbrains.java.decompiler.modules.decompiler.flow.FlattenStatementsHelper.buildDirectGraph(FlattenStatementsHelper.java:50)
      //   at org.jetbrains.java.decompiler.modules.decompiler.sforms.SFormsConstructor.splitVariables(SFormsConstructor.java:72)
      //   at org.jetbrains.java.decompiler.modules.decompiler.StackVarsProcessor.simplifyStackVars(StackVarsProcessor.java:52)
      //   at org.jetbrains.java.decompiler.modules.decompiler.StackVarsProcessor.simplifyStackVars(StackVarsProcessor.java:40)
      //   at org.jetbrains.java.decompiler.main.rels.MethodProcessor.codeToJava(MethodProcessor.java:299)
      //
      // Bytecode:
      // 00: ldc2_w 110892771744203
      // 03: lload 1
      // 04: lxor
      // 05: lstore 1
      // 06: ldc2_w -5135527385731521846
      // 09: lload 1
      // 0a: invokedynamic é (JJ)I bsm=cn/cool/cherish/utils/render/何何何树友何何友树树.c (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: fload 0
      // 10: f2d
      // 11: invokestatic java/lang/Math.ceil (D)D
      // 14: d2i
      // 15: istore 5
      // 17: iload 5
      // 19: bipush 2
      // 1a: imul
      // 1b: bipush 1
      // 1c: iadd
      // 1d: istore 6
      // 1f: iload 6
      // 21: newarray 6
      // 23: astore 7
      // 25: fload 0
      // 26: ldc_w 3.0
      // 29: fdiv
      // 2a: fstore 8
      // 2c: fconst_2
      // 2d: fload 8
      // 2f: fmul
      // 30: fload 8
      // 32: fmul
      // 33: fstore 9
      // 35: ldc_w 6.2831855
      // 38: fload 8
      // 3a: fmul
      // 3b: fstore 10
      // 3d: fload 10
      // 3f: f2d
      // 40: invokestatic java/lang/Math.sqrt (D)D
      // 43: d2f
      // 44: fstore 11
      // 46: fload 0
      // 47: fload 0
      // 48: fmul
      // 49: fstore 12
      // 4b: fconst_0
      // 4c: fstore 13
      // 4e: bipush 0
      // 4f: istore 14
      // 51: iload 5
      // 53: ineg
      // 54: istore 15
      // 56: istore 4
      // 58: iload 15
      // 5a: iload 5
      // 5c: if_icmpgt c4
      // 5f: iload 15
      // 61: iload 15
      // 63: imul
      // 64: i2f
      // 65: fstore 16
      // 67: iload 4
      // 69: lload 1
      // 6a: lconst_0
      // 6b: lcmp
      // 6c: iflt 90
      // 6f: ifeq 8e
      // 72: fload 16
      // 74: fload 12
      // 76: fcmpl
      // 77: iload 4
      // 79: ifeq cb
      // 7c: goto 7f
      // 7f: ifle 99
      // 82: goto 85
      // 85: aload 7
      // 87: iload 14
      // 89: fconst_0
      // 8a: fastore
      // 8b: goto 8e
      // 8e: iload 4
      // 90: lload 1
      // 91: lconst_0
      // 92: lcmp
      // 93: iflt c1
      // 96: ifne af
      // 99: aload 7
      // 9b: iload 14
      // 9d: fload 16
      // 9f: fneg
      // a0: fload 9
      // a2: fdiv
      // a3: f2d
      // a4: invokestatic java/lang/Math.exp (D)D
      // a7: d2f
      // a8: fload 11
      // aa: fdiv
      // ab: fastore
      // ac: goto af
      // af: fload 13
      // b1: aload 7
      // b3: iload 14
      // b5: faload
      // b6: fadd
      // b7: fstore 13
      // b9: iinc 14 1
      // bc: iinc 15 1
      // bf: iload 4
      // c1: ifne 58
      // c4: lload 1
      // c5: lconst_0
      // c6: lcmp
      // c7: iflt cd
      // ca: bipush 0
      // cb: istore 15
      // cd: iload 15
      // cf: iload 6
      // d1: if_icmpge e6
      // d4: aload 7
      // d6: iload 15
      // d8: dup2
      // d9: faload
      // da: fload 13
      // dc: fdiv
      // dd: fastore
      // de: iinc 15 1
      // e1: iload 4
      // e3: ifne cd
      // e6: lload 1
      // e7: lconst_0
      // e8: lcmp
      // e9: ifle e1
      // ec: new java/awt/image/Kernel
      // ef: dup
      // f0: iload 6
      // f2: bipush 1
      // f3: aload 7
      // f5: invokespecial java/awt/image/Kernel.<init> (II[F)V
      // f8: areturn
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("c".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何何何树友何何友树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         MethodHandle var9;
         if (var8 != 192 && var8 != 199 && var8 != 202 && var8 != 240) {
            var11 = l(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 237) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 233) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = k(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 192) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 199) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName())
            .append(" : ")
            .append(var10 != null ? var10.toString() : (var11 != null ? var11.toString() : " null "))
            .append(" : ")
            .append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException c(RuntimeException var0) {
      return var0;
   }

   private static void c() {
      j[0] = "~:1<\u0013aqz|7\u0019|t'wq\tzt8lq\u000eks0z-R佛佈企栎厔伩佛取桅栎";
      j[1] = float.class;
      k[1] = "java/lang/Float";
      j[2] = "><NB$\u001b1|\u0003I.\u00064!\b\u000f>\u00004>\u0013\u000f9\u001136\u0005Se桥桌伇桱佴厀县厖厙厫";
      j[3] = int.class;
      k[3] = "java/lang/Integer";
      j[4] = "5mm3$\u0005>b||X\u001c1xr?o,'o~\"~\u00000b";
      j[5] = boolean.class;
      k[5] = "java/lang/Boolean";
      j[6] = "s63\byTn#k\u0000:T~2k\"2Gw2)";
      j[7] = "\u0014z\n\u0001\"/\u001b:G\n(2\u001egLL84\u001exWL?%\u0019pA\u0010c伕伢叟佱厩优桑桦栅可";
      j[8] = " \u0018{N\u0004I+\u0017j\u0001eG \u001cn[";
      j[9] = "I$+C|8\u001f1v\u0004\u001f伇伭厖叓佧叜伇桩伈栉:%d\n2~\\p0\u001f/";
      j[10] = "\u0015:E#%2C/\u0018dF伍可厈桧伇桟厓栵伖厽Z|nV,\u0010<):C1";
      j[11] = "zgD\u0010H+/\"[kS\u0015y.IV\u0005~& \u0015Z8/10\u0018VSp?l\u0014k";
      j[12] = "V'[olv\u00002\u0006(\u000f栍桶桏厣叕佒栍伲厕伽\u00164iQj^-1s\u0000g";
      j[13] = ")dc\u000bXY|!|p併伺位厜佟伭併厤位伂\u0002LP^l:m\u0017Y[b";
      j[14] = "\u0016~Xl\u001aZV.\ttuV+x^k\u0012ZM-\n~\u000f4";
      j[15] = "\nti`_6\\a4'<桍佮佘厑叚栥厗株佘伏\u0019\u0007)\r9l\"\u00023\\4";
      j[16] = "U8\u0002Z0i\u0015hSB_~h>\u0004]8i\u000ekPH%\u0007";
      j[17] = "+6An}\"~s^\u0015収叟住佐佽取収佁栋栔 km!mmAp6&";
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      Method var5 = e(var0, var1, var2, var3, var4);
      if (var5 != null) {
         return var5;
      } else {
         Class[] var6 = var0.getInterfaces();
         if (var6 != null) {
            for (int var7 = 0; var7 < var6.length; var7++) {
               var5 = f(var6[var7], var1, var2, var3, var4);
               if (var5 != null) {
                  return var5;
               }
            }
         }

         return null;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      Field var3 = e(var0, var1, var2);
      if (var3 != null) {
         return var3;
      } else {
         Class[] var4 = var0.getInterfaces();
         if (var4 != null) {
            for (int var5 = 0; var5 < var4.length; var5++) {
               var3 = f(var4[var5], var1, var2);
               if (var3 != null) {
                  return var3;
               }
            }
         }

         return null;
      }
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Class var23 = var8;

         while (true) {
            Method var25 = e(var23, var10, var15, var13, var14);
            if (var25 != null) {
               j[var4] = var25;
               return var25;
            }

            if (var23.getName().equals("java.lang.Object")) {
               break;
            }

            if ((var23 = var23.getSuperclass()) == null) {
               j(563205124076514L, 0L);
               break;
            }
         }

         var23 = var8;

         while (true) {
            Class[] var26;
            if ((var26 = var23.getInterfaces()) != null) {
               for (int var18 = 0; var18 < var26.length; var18++) {
                  Method var19 = f(var26[var18], var10, var15, var13, var14);
                  if (var19 != null) {
                     j[var4] = var19;
                     return var19;
                  }
               }
            }

            if (var23.getName().equals("java.lang.Object")) {
               StringBuffer var27 = new StringBuffer();
               var27.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
               int var28 = 0;

               while (var28 < var13) {
                  var27.append(var14[var28].getName());
                  if (++var28 < var13) {
                     var27.append(", ");
                  }
               }

               var27.append(')');
               throw new RuntimeException(var27.toString());
            }

            if ((var23 = var23.getSuperclass()) == null) {
               var23 = j(563205124076514L, 0L);
            }
         }
      }
   }

   @Override
   public BufferedImage filter(BufferedImage src, BufferedImage dst) {
      long a;
      long ax;
      int axx;
      int width;
      int height;
      label68: {
         a = 31730480361788L;
         ax = 59403223928194L;
         int var10000 = c<"é">(-5674638833980363953L, a);
         width = src.getWidth();
         axx = var10000;
         height = src.getHeight();
         BufferedImage var21 = dst;
         if (axx != 0) {
            if (dst != null) {
               break label68;
            }

            var21 = this.createCompatibleDestImage(src, null);
         }

         dst = var21;
      }

      int[] inPixels = new int[width * height];
      int[] outPixels = new int[width * height];
      src.getRGB(0, 0, width, height, inPixels, 0, width);
      if (axx != 0) {
         if (c<"À">(this, -5676675961596149872L, a) > 0.0F) {
            Kernel var22;
            boolean var10005;
            boolean var10006;
            label58: {
               label72: {
                  var22 = c<"À">(this, -5674740220736379452L, a);
                  var10005 = c<"À">(this, -5674562468432395472L, a);
                  var10006 = c<"À">(this, -5674562468432395472L, a);
                  if (axx != 0) {
                     if (!var10006) {
                        break label72;
                     }

                     var10006 = c<"À">(this, -5674800078006961520L, a);
                  }

                  if (axx == 0) {
                     break label58;
                  }

                  if (var10006) {
                     var10006 = true;
                     break label58;
                  }
               }

               var10006 = false;
            }

            label47: {
               label73: {
                  int axxx = c<"Ê">(-5674929882229547815L, a);
                  int axxxx = var10006;
                  int axxxxx = var10005;
                  J(var22, inPixels, ax, outPixels, width, height, axxxxx, axxxx, false, axxx);
                  var22 = c<"À">(this, -5674740220736379452L, a);
                  var10005 = c<"À">(this, -5674562468432395472L, a);
                  var10006 = c<"À">(this, -5674562468432395472L, a);
                  if (axx != 0) {
                     if (!var10006) {
                        break label73;
                     }

                     var10006 = c<"À">(this, -5674800078006961520L, a);
                  }

                  if (axx == 0) {
                     break label47;
                  }

                  if (var10006) {
                     var10006 = true;
                     break label47;
                  }
               }

               var10006 = false;
            }

            int var19 = c<"Ê">(-5674929882229547815L, a);
            int axxxxxx = var10006;
            int var20 = var10005;
            J(var22, outPixels, ax, inPixels, height, width, var20, false, axxxxxx, var19);
         }

         dst.setRGB(0, 0, width, height, inPixels, 0, width);
      }

      return dst;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = j[var4];
      if (!(var5 instanceof String)) {
         return (Field)var5;
      } else {
         String var6 = k[var4];
         int var7 = var6.indexOf(8);
         Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
         Class var12 = var8;

         while (true) {
            Field var13 = e(var12, var10, var11);
            if (var13 != null) {
               j[var4] = var13;
               return var13;
            }

            Class[] var14 = var12.getInterfaces();
            if (var14 != null) {
               for (int var15 = 0; var15 < var14.length; var15++) {
                  var13 = f(var14[var15], var10, var11);
                  if (var13 != null) {
                     j[var4] = var13;
                     return var13;
                  }
               }
            }

            if (var12.getName().equals("java.lang.Object")) {
               StringBuffer var19 = new StringBuffer();
               var19.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
               throw new RuntimeException(var19.toString());
            }

            var12 = var12.getSuperclass();
            if (var12 == null) {
               var12 = j(563205124076514L, 0L);
            }
         }
      }
   }

   public void g(long a, float var3) {
      a = 110892771744203L ^ a;
      long ax = a ^ 23093175008087L;
      c<"Ç">(this, var3, 1882864835179140233L, (long)a);
      c<"Ç">(this, x(var3, ax), 1884306780951957213L, (long)a);
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = j[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public float u(long a) {
      a = 110892771744203L ^ a;
      return c<"À">(this, -6609286646096336145L, (long)a);
   }

   private static String HE_SHU_YOU() {
      return "何炜霖国企变私企";
   }
}
