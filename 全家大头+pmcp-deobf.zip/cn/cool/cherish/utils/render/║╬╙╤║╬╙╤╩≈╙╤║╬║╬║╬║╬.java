package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何友何友树友何何何何 implements 何树友 {
   public static final int 何树何树树树友何何何 = 0;
   public static final int 树何何友树树友友何树 = 1;
   public static final int 友何树友何何何友树树;
   public static final int 友友树何友树树树树友;
   public static final int 友友树友树树何何何何;
   public static final int 树树友树树树树树树友;
   public static final int 树友友树友友友友树何;
   public static final int 树树友友何树树友何友;
   public static final int 树何树友友何树友何树;
   public static final int 树树何友树友友树友友;
   public static final int 树友友何友友友树何友;
   public static final int 何友友树树何友友何友;
   public static final int 树友何友何友树友何树;
   public static final int 何何友树何友何树友友;
   public static final int 友树友何何何树何友友;
   public static final int 树树何何树树友树友友;
   public static final int 友友友何友何树友何何;
   public static final int 树何树何何友树树友友;
   public static final int 树树何友友友友何树友;
   public static final int 何友树何树何树树友何;
   public static final int 何友树友友何友何何友;
   private static final Random 树树友友友友树友何何;
   private static final float[] 树何友树树何友树树友;
   private static final float[] 友树友何树友何树何何;
   private static boolean 友友友树树友何树树友;
   private static final long a;
   private static final Object[] b = new Object[15];
   private static final String[] c = new String[15];
   private static int _何大伟为什么要诈骗何炜霖 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7272102539775852328L, 7437296270379263902L, MethodHandles.lookup().lookupClass()).a(148696274530821L);
      // $VF: monitorexit
      a = var10000;
      long var11 = a ^ 38379862651299L;
      a();
      if (a<"û">(-1206614976737300906L, var11)) {
         a<"û">(true, -1206605986875027029L, var11);
      }

      Cipher var1;
      Cipher var14 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(var11 << var2 * 8 >>> 56);
      }

      var14.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var0 = new long[19];
      int var4 = 0;
      String var5 = "8\u0090ý\u009búÐÏ\u0006È*NÉs÷I¾_\u0002iùC}\u0012|A\u0094i\n¹\u0098ÖÈt©\u008ezR)PR\u0090Ü\u0019º)ÆO\nÍ\u00819ÀøæY@Æl<>\u009a\u0097\u0019-\u0012\nñ§\r®?\u000fß+gs[Òg\u0094jlï\u0000\u0018pm\u0006\u0095æÜ»hÖ±\u0093Z\u000bU!$ÜòéX+B¬-¯\u0082õò-zì|Üä Ò.M\u0002U\u0081\u0086rÔTtSãqIë";
      short var6 = 136;
      byte var3 = 0;

      label27:
      while (true) {
         int var10001 = var3;
         var3 += 8;
         byte[] var7 = var5.substring(var10001, var3).getBytes("ISO-8859-1");
         long[] var15 = var0;
         var10001 = var4++;
         long var18 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte var20 = -1;

         while (true) {
            long var8 = var18;
            byte[] var10 = var1.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var22 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var20) {
               case 0:
                  var15[var10001] = var22;
                  if (var3 >= var6) {
                     树树何何树树友树友友 = (int)var0[6];
                     友友树友树树何何何何 = (int)var0[9];
                     树友何友何友树友何树 = (int)var0[10];
                     何何友树何友何树友友 = (int)var0[8];
                     友树友何何何树何友友 = (int)var0[1];
                     树友友何友友友树何友 = (int)var0[18];
                     何友友树树何友友何友 = (int)var0[13];
                     友友友何友何树友何何 = (int)var0[3];
                     树树何友友友友何树友 = (int)var0[16];
                     树何树友友何树友何树 = (int)var0[17];
                     树何树何何友树树友友 = (int)var0[15];
                     树树友树树树树树树友 = (int)var0[12];
                     何友树何树何树树友何 = (int)var0[4];
                     树树何友树友友树友友 = (int)var0[14];
                     友何树友何何何友树树 = (int)var0[0];
                     树友友树友友友友树何 = (int)var0[7];
                     树树友友何树树友何友 = (int)var0[2];
                     友友树何友树树树树友 = (int)var0[5];
                     何友树友友何友何何友 = (int)var0[11];
                     树树友友友友树友何何 = new Random();
                     树何友树树何友树树友 = new float[3];
                     友树友何树友何树何何 = new float[3];
                     return;
                  }
                  break;
               default:
                  var15[var10001] = var22;
                  if (var3 < var6) {
                     continue label27;
                  }

                  var5 = "|1In\u0085PKMËÏ\u000eïÙ\u00934\u0018";
                  var6 = 16;
                  var3 = 0;
            }

            byte var17 = var3;
            var3 += 8;
            var7 = var5.substring(var17, var3).getBytes("ISO-8859-1");
            var15 = var0;
            var10001 = var4++;
            var18 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var20 = 0;
         }
      }
   }

   public static int D(int a, int op, int a, int var3, long rgb2) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.ClassCastException: class java.lang.Integer cannot be cast to class java.lang.Long (java.lang.Integer and java.lang.Long are in module java.base of loader 'bootstrap')
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ConstExprent.toJava(ConstExprent.java:267)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SwitchStatement.toJava(SwitchStatement.java:171)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:258)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 000: getstatic cn/cool/cherish/utils/render/何友何友树友何何何何.a J
      // 003: lload 4
      // 005: lxor
      // 006: lstore 4
      // 008: lload 4
      // 00a: dup2
      // 00b: ldc2_w 111571647909236
      // 00e: lxor
      // 00f: lstore 7
      // 011: pop2
      // 012: ldc2_w 5671895822985159654
      // 015: lload 4
      // 017: invokedynamic û (JJ)Z bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 01c: istore 9
      // 01e: iload 2
      // 01f: ifne 024
      // 022: iload 0
      // 023: ireturn
      // 024: iload 0
      // 025: bipush 24
      // 027: ishr
      // 028: sipush 255
      // 02b: iand
      // 02c: istore 10
      // 02e: iload 0
      // 02f: bipush 16
      // 031: ishr
      // 032: sipush 255
      // 035: iand
      // 036: istore 11
      // 038: iload 0
      // 039: bipush 8
      // 03b: ishr
      // 03c: sipush 255
      // 03f: iand
      // 040: istore 12
      // 042: iload 0
      // 043: sipush 255
      // 046: iand
      // 047: istore 13
      // 049: iload 1
      // 04a: bipush 24
      // 04c: ishr
      // 04d: sipush 255
      // 050: iand
      // 051: istore 14
      // 053: iload 1
      // 054: bipush 16
      // 056: ishr
      // 057: sipush 255
      // 05a: iand
      // 05b: istore 15
      // 05d: iload 1
      // 05e: bipush 8
      // 060: ishr
      // 061: sipush 255
      // 064: iand
      // 065: istore 16
      // 067: iload 1
      // 068: sipush 255
      // 06b: iand
      // 06c: istore 17
      // 06e: iload 2
      // 06f: tableswitch 1223 1 20 93 93 132 171 219 267 324 481 481 481 481 800 442 881 1058 1223 384 1085 1166 1194
      // 0cc: iload 11
      // 0ce: iload 15
      // 0d0: invokestatic java/lang/Math.min (II)I
      // 0d3: istore 11
      // 0d5: iload 12
      // 0d7: iload 16
      // 0d9: invokestatic java/lang/Math.min (II)I
      // 0dc: istore 12
      // 0de: iload 13
      // 0e0: iload 17
      // 0e2: invokestatic java/lang/Math.min (II)I
      // 0e5: istore 13
      // 0e7: iload 9
      // 0e9: lload 4
      // 0eb: lconst_0
      // 0ec: lcmp
      // 0ed: iflt 110
      // 0f0: ifne 536
      // 0f3: iload 11
      // 0f5: iload 15
      // 0f7: invokestatic java/lang/Math.max (II)I
      // 0fa: istore 11
      // 0fc: iload 12
      // 0fe: iload 16
      // 100: invokestatic java/lang/Math.max (II)I
      // 103: istore 12
      // 105: iload 13
      // 107: iload 17
      // 109: invokestatic java/lang/Math.max (II)I
      // 10c: istore 13
      // 10e: iload 9
      // 110: lload 4
      // 112: lconst_0
      // 113: lcmp
      // 114: iflt 140
      // 117: ifne 536
      // 11a: iload 11
      // 11c: iload 15
      // 11e: iadd
      // 11f: lload 7
      // 121: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 124: istore 11
      // 126: iload 12
      // 128: iload 16
      // 12a: iadd
      // 12b: lload 7
      // 12d: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 130: istore 12
      // 132: iload 13
      // 134: iload 17
      // 136: iadd
      // 137: lload 7
      // 139: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 13c: istore 13
      // 13e: iload 9
      // 140: lload 4
      // 142: lconst_0
      // 143: lcmp
      // 144: ifle 170
      // 147: ifne 536
      // 14a: iload 15
      // 14c: iload 11
      // 14e: isub
      // 14f: lload 7
      // 151: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 154: istore 11
      // 156: iload 16
      // 158: iload 12
      // 15a: isub
      // 15b: lload 7
      // 15d: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 160: istore 12
      // 162: iload 17
      // 164: iload 13
      // 166: isub
      // 167: lload 7
      // 169: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 16c: istore 13
      // 16e: iload 9
      // 170: lload 4
      // 172: lconst_0
      // 173: lcmp
      // 174: iflt 1a9
      // 177: ifne 536
      // 17a: iload 11
      // 17c: iload 15
      // 17e: isub
      // 17f: invokestatic java/lang/Math.abs (I)I
      // 182: lload 7
      // 184: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 187: istore 11
      // 189: iload 12
      // 18b: iload 16
      // 18d: isub
      // 18e: invokestatic java/lang/Math.abs (I)I
      // 191: lload 7
      // 193: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 196: istore 12
      // 198: iload 13
      // 19a: iload 17
      // 19c: isub
      // 19d: invokestatic java/lang/Math.abs (I)I
      // 1a0: lload 7
      // 1a2: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 1a5: istore 13
      // 1a7: iload 9
      // 1a9: lload 4
      // 1ab: lconst_0
      // 1ac: lcmp
      // 1ad: ifle 1e5
      // 1b0: ifne 536
      // 1b3: iload 11
      // 1b5: iload 15
      // 1b7: imul
      // 1b8: sipush 255
      // 1bb: idiv
      // 1bc: lload 7
      // 1be: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 1c1: istore 11
      // 1c3: iload 12
      // 1c5: iload 16
      // 1c7: imul
      // 1c8: sipush 255
      // 1cb: idiv
      // 1cc: lload 7
      // 1ce: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 1d1: istore 12
      // 1d3: iload 13
      // 1d5: iload 17
      // 1d7: imul
      // 1d8: sipush 255
      // 1db: idiv
      // 1dc: lload 7
      // 1de: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 1e1: istore 13
      // 1e3: iload 9
      // 1e5: lload 4
      // 1e7: lconst_0
      // 1e8: lcmp
      // 1e9: iflt 200
      // 1ec: ifne 536
      // 1ef: ldc2_w 5672175303181394163
      // 1f2: lload 4
      // 1f4: invokedynamic Õ (JJ)Ljava/util/Random; bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 1f9: invokevirtual java/util/Random.nextInt ()I
      // 1fc: sipush 255
      // 1ff: iand
      // 200: iload 10
      // 202: iload 9
      // 204: lload 4
      // 206: lconst_0
      // 207: lcmp
      // 208: ifle 53e
      // 20b: ifeq 53c
      // 20e: if_icmpgt 536
      // 211: iload 15
      // 213: istore 11
      // 215: iload 16
      // 217: istore 12
      // 219: iload 17
      // 21b: istore 13
      // 21d: iload 9
      // 21f: lload 4
      // 221: lconst_0
      // 222: lcmp
      // 223: ifle 246
      // 226: ifne 536
      // 229: iload 11
      // 22b: iload 15
      // 22d: iadd
      // 22e: bipush 2
      // 22f: idiv
      // 230: istore 11
      // 232: iload 12
      // 234: iload 16
      // 236: iadd
      // 237: bipush 2
      // 238: idiv
      // 239: istore 12
      // 23b: iload 13
      // 23d: iload 17
      // 23f: iadd
      // 240: bipush 2
      // 241: idiv
      // 242: istore 13
      // 244: iload 9
      // 246: lload 4
      // 248: lconst_0
      // 249: lcmp
      // 24a: ifle 279
      // 24d: ifne 536
      // 250: iload 11
      // 252: iload 12
      // 254: iload 13
      // 256: ldc2_w 5671802818416414291
      // 259: lload 4
      // 25b: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 260: invokestatic java/awt/Color.RGBtoHSB (III[F)[F
      // 263: pop
      // 264: iload 15
      // 266: iload 16
      // 268: iload 17
      // 26a: ldc2_w 5672001116406893357
      // 26d: lload 4
      // 26f: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 274: invokestatic java/awt/Color.RGBtoHSB (III[F)[F
      // 277: pop
      // 278: iload 2
      // 279: lload 4
      // 27b: lconst_0
      // 27c: lcmp
      // 27d: iflt 385
      // 280: lload 4
      // 282: lconst_0
      // 283: lcmp
      // 284: iflt 37d
      // 287: tableswitch 185 8 11 29 65 101 137
      // 2a4: ldc2_w 5672001116406893357
      // 2a7: lload 4
      // 2a9: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2ae: bipush 0
      // 2af: ldc2_w 5671802818416414291
      // 2b2: lload 4
      // 2b4: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2b9: bipush 0
      // 2ba: faload
      // 2bb: fastore
      // 2bc: iload 9
      // 2be: lload 4
      // 2c0: lconst_0
      // 2c1: lcmp
      // 2c2: iflt 37d
      // 2c5: ifne 340
      // 2c8: ldc2_w 5672001116406893357
      // 2cb: lload 4
      // 2cd: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2d2: bipush 1
      // 2d3: ldc2_w 5671802818416414291
      // 2d6: lload 4
      // 2d8: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2dd: bipush 1
      // 2de: faload
      // 2df: fastore
      // 2e0: iload 9
      // 2e2: lload 4
      // 2e4: lconst_0
      // 2e5: lcmp
      // 2e6: ifle 37d
      // 2e9: ifne 340
      // 2ec: ldc2_w 5672001116406893357
      // 2ef: lload 4
      // 2f1: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 2f6: bipush 2
      // 2f7: ldc2_w 5671802818416414291
      // 2fa: lload 4
      // 2fc: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 301: bipush 2
      // 302: faload
      // 303: fastore
      // 304: iload 9
      // 306: lload 4
      // 308: lconst_0
      // 309: lcmp
      // 30a: iflt 37d
      // 30d: ifne 340
      // 310: ldc2_w 5672001116406893357
      // 313: lload 4
      // 315: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 31a: bipush 0
      // 31b: ldc2_w 5671802818416414291
      // 31e: lload 4
      // 320: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 325: bipush 0
      // 326: faload
      // 327: fastore
      // 328: ldc2_w 5672001116406893357
      // 32b: lload 4
      // 32d: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 332: bipush 1
      // 333: ldc2_w 5671802818416414291
      // 336: lload 4
      // 338: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 33d: bipush 1
      // 33e: faload
      // 33f: fastore
      // 340: ldc2_w 5672001116406893357
      // 343: lload 4
      // 345: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 34a: bipush 0
      // 34b: faload
      // 34c: ldc2_w 5672001116406893357
      // 34f: lload 4
      // 351: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 356: bipush 1
      // 357: faload
      // 358: ldc2_w 5672001116406893357
      // 35b: lload 4
      // 35d: invokedynamic Õ (JJ)[F bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 362: bipush 2
      // 363: faload
      // 364: invokestatic java/awt/Color.HSBtoRGB (FFF)I
      // 367: istore 0
      // 368: iload 0
      // 369: bipush 16
      // 36b: ishr
      // 36c: sipush 255
      // 36f: iand
      // 370: istore 11
      // 372: iload 0
      // 373: bipush 8
      // 375: ishr
      // 376: sipush 255
      // 379: iand
      // 37a: istore 12
      // 37c: iload 0
      // 37d: sipush 255
      // 380: iand
      // 381: istore 13
      // 383: iload 9
      // 385: lload 4
      // 387: lconst_0
      // 388: lcmp
      // 389: iflt 3d6
      // 38c: ifne 536
      // 38f: sipush 255
      // 392: sipush 255
      // 395: iload 11
      // 397: isub
      // 398: sipush 255
      // 39b: iload 15
      // 39d: isub
      // 39e: imul
      // 39f: sipush 255
      // 3a2: idiv
      // 3a3: isub
      // 3a4: istore 11
      // 3a6: sipush 255
      // 3a9: sipush 255
      // 3ac: iload 12
      // 3ae: isub
      // 3af: sipush 255
      // 3b2: iload 16
      // 3b4: isub
      // 3b5: imul
      // 3b6: sipush 255
      // 3b9: idiv
      // 3ba: isub
      // 3bb: istore 12
      // 3bd: sipush 255
      // 3c0: sipush 255
      // 3c3: iload 13
      // 3c5: isub
      // 3c6: sipush 255
      // 3c9: iload 17
      // 3cb: isub
      // 3cc: imul
      // 3cd: sipush 255
      // 3d0: idiv
      // 3d1: isub
      // 3d2: istore 13
      // 3d4: iload 9
      // 3d6: lload 4
      // 3d8: lconst_0
      // 3d9: lcmp
      // 3da: iflt 3f5
      // 3dd: ifne 536
      // 3e0: sipush 255
      // 3e3: sipush 255
      // 3e6: iload 11
      // 3e8: isub
      // 3e9: sipush 255
      // 3ec: iload 15
      // 3ee: isub
      // 3ef: imul
      // 3f0: sipush 255
      // 3f3: idiv
      // 3f4: isub
      // 3f5: istore 19
      // 3f7: iload 11
      // 3f9: iload 15
      // 3fb: imul
      // 3fc: sipush 255
      // 3ff: idiv
      // 400: istore 18
      // 402: iload 19
      // 404: iload 11
      // 406: imul
      // 407: iload 18
      // 409: sipush 255
      // 40c: iload 11
      // 40e: isub
      // 40f: imul
      // 410: iadd
      // 411: sipush 255
      // 414: idiv
      // 415: istore 11
      // 417: sipush 255
      // 41a: sipush 255
      // 41d: iload 12
      // 41f: isub
      // 420: sipush 255
      // 423: iload 16
      // 425: isub
      // 426: imul
      // 427: sipush 255
      // 42a: idiv
      // 42b: isub
      // 42c: istore 19
      // 42e: iload 12
      // 430: iload 16
      // 432: imul
      // 433: sipush 255
      // 436: idiv
      // 437: istore 18
      // 439: iload 19
      // 43b: iload 12
      // 43d: imul
      // 43e: iload 18
      // 440: sipush 255
      // 443: iload 12
      // 445: isub
      // 446: imul
      // 447: iadd
      // 448: sipush 255
      // 44b: idiv
      // 44c: istore 12
      // 44e: sipush 255
      // 451: sipush 255
      // 454: iload 13
      // 456: isub
      // 457: sipush 255
      // 45a: iload 17
      // 45c: isub
      // 45d: imul
      // 45e: sipush 255
      // 461: idiv
      // 462: isub
      // 463: istore 19
      // 465: iload 13
      // 467: iload 17
      // 469: imul
      // 46a: sipush 255
      // 46d: idiv
      // 46e: istore 18
      // 470: iload 19
      // 472: iload 13
      // 474: imul
      // 475: iload 18
      // 477: sipush 255
      // 47a: iload 13
      // 47c: isub
      // 47d: imul
      // 47e: iadd
      // 47f: sipush 255
      // 482: idiv
      // 483: istore 13
      // 485: iload 9
      // 487: lload 4
      // 489: lconst_0
      // 48a: lcmp
      // 48b: iflt 4a2
      // 48e: ifne 536
      // 491: sipush 255
      // 494: sipush 255
      // 497: istore 13
      // 499: sipush 255
      // 49c: istore 12
      // 49e: istore 11
      // 4a0: iload 9
      // 4a2: lload 4
      // 4a4: lconst_0
      // 4a5: lcmp
      // 4a6: ifle 4fc
      // 4a9: ifne 536
      // 4ac: iload 15
      // 4ae: iload 10
      // 4b0: imul
      // 4b1: sipush 255
      // 4b4: idiv
      // 4b5: lload 7
      // 4b7: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 4ba: istore 11
      // 4bc: iload 16
      // 4be: iload 10
      // 4c0: imul
      // 4c1: sipush 255
      // 4c4: idiv
      // 4c5: lload 7
      // 4c7: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 4ca: istore 12
      // 4cc: iload 17
      // 4ce: iload 10
      // 4d0: imul
      // 4d1: sipush 255
      // 4d4: idiv
      // 4d5: lload 7
      // 4d7: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 4da: istore 13
      // 4dc: iload 14
      // 4de: iload 10
      // 4e0: imul
      // 4e1: sipush 255
      // 4e4: idiv
      // 4e5: lload 7
      // 4e7: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 4ea: bipush 24
      // 4ec: ishl
      // 4ed: iload 11
      // 4ef: bipush 16
      // 4f1: ishl
      // 4f2: ior
      // 4f3: iload 12
      // 4f5: bipush 8
      // 4f7: ishl
      // 4f8: ior
      // 4f9: iload 13
      // 4fb: ior
      // 4fc: ireturn
      // 4fd: iload 10
      // 4ff: iload 14
      // 501: imul
      // 502: sipush 255
      // 505: idiv
      // 506: bipush 24
      // 508: ishl
      // 509: iload 15
      // 50b: bipush 16
      // 50d: ishl
      // 50e: ior
      // 50f: iload 16
      // 511: bipush 8
      // 513: ishl
      // 514: ior
      // 515: iload 17
      // 517: ior
      // 518: ireturn
      // 519: sipush 255
      // 51c: iload 10
      // 51e: isub
      // 51f: istore 20
      // 521: iload 10
      // 523: bipush 24
      // 525: ishl
      // 526: iload 20
      // 528: bipush 16
      // 52a: ishl
      // 52b: ior
      // 52c: iload 20
      // 52e: bipush 8
      // 530: ishl
      // 531: ior
      // 532: iload 20
      // 534: ior
      // 535: ireturn
      // 536: sipush 255
      // 539: sipush 255
      // 53c: iload 9
      // 53e: ifeq 569
      // 541: if_icmpne 553
      // 544: iload 10
      // 546: lload 4
      // 548: lconst_0
      // 549: lcmp
      // 54a: ifle 5ce
      // 54d: sipush 255
      // 550: if_icmpeq 5ba
      // 553: iload 10
      // 555: iload 3
      // 556: imul
      // 557: sipush 255
      // 55a: idiv
      // 55b: istore 10
      // 55d: sipush 255
      // 560: iload 10
      // 562: isub
      // 563: iload 14
      // 565: imul
      // 566: sipush 255
      // 569: idiv
      // 56a: istore 18
      // 56c: iload 11
      // 56e: iload 10
      // 570: imul
      // 571: iload 15
      // 573: iload 18
      // 575: imul
      // 576: iadd
      // 577: sipush 255
      // 57a: idiv
      // 57b: lload 7
      // 57d: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 580: istore 11
      // 582: iload 12
      // 584: iload 10
      // 586: imul
      // 587: iload 16
      // 589: iload 18
      // 58b: imul
      // 58c: iadd
      // 58d: sipush 255
      // 590: idiv
      // 591: lload 7
      // 593: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 596: istore 12
      // 598: iload 13
      // 59a: iload 10
      // 59c: imul
      // 59d: iload 17
      // 59f: iload 18
      // 5a1: imul
      // 5a2: iadd
      // 5a3: sipush 255
      // 5a6: idiv
      // 5a7: lload 7
      // 5a9: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 5ac: istore 13
      // 5ae: iload 10
      // 5b0: iload 18
      // 5b2: iadd
      // 5b3: lload 7
      // 5b5: invokestatic cn/cool/cherish/utils/render/何友何友树友何何何何.w (IJ)I
      // 5b8: istore 10
      // 5ba: iload 10
      // 5bc: bipush 24
      // 5be: ishl
      // 5bf: iload 11
      // 5c1: bipush 16
      // 5c3: ishl
      // 5c4: ior
      // 5c5: iload 12
      // 5c7: bipush 8
      // 5c9: ishl
      // 5ca: ior
      // 5cb: iload 13
      // 5cd: ior
      // 5ce: ireturn
   }

   public static boolean F() {
      return 友友友树树友何树树友;
   }

   public static boolean I(int a, long a, int tolerance, int rgb1) {
      a = 何友何友树友何何何何.a ^ a;
      int r1 = a >> 16 & 0xFF;
      int g1 = a >> 8 & 0xFF;
      int b1 = a & 255;
      int r2 = tolerance >> 16 & 0xFF;
      int g2 = tolerance >> 8 & 0xFF;
      a<"û">(-4620165140786277711L, a);
      int b2 = tolerance & 0xFF;
      return Math.abs(r1 - r2) <= rgb1 && Math.abs(g1 - g2) <= rgb1 && Math.abs(b1 - b2) <= rgb1;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public static int b(int a, int rgb1, int op, long rgb2) {
      long ax = 何友何友树友何何何何.a ^ rgb2 ^ 115832506534426L;
      return D((int)a, rgb1, op, 255, ax);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void c(boolean var0) {
      友友友树树友何树树友 = var0;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 211 && var8 != 244 && var8 != 213 && var8 != 240) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 239) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 251) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 211) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/何友何友树友何何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 63;
               case 1 -> 29;
               case 2 -> 12;
               case 3 -> 7;
               case 4 -> 39;
               case 5 -> 23;
               case 6 -> 45;
               case 7 -> 8;
               case 8 -> 48;
               case 9 -> 50;
               case 10 -> 47;
               case 11 -> 31;
               case 12 -> 15;
               case 13 -> 25;
               case 14 -> 14;
               case 15 -> 53;
               case 16 -> 41;
               case 17 -> 16;
               case 18 -> 57;
               case 19 -> 32;
               case 20 -> 26;
               case 21 -> 43;
               case 22 -> 27;
               case 23 -> 3;
               case 24 -> 4;
               case 25 -> 58;
               case 26 -> 59;
               case 27 -> 61;
               case 28 -> 33;
               case 29 -> 35;
               case 30 -> 28;
               case 31 -> 24;
               case 32 -> 60;
               case 33 -> 10;
               case 34 -> 56;
               case 35 -> 20;
               case 36 -> 21;
               case 37 -> 38;
               case 38 -> 55;
               case 39 -> 6;
               case 40 -> 51;
               case 41 -> 36;
               case 42 -> 17;
               case 43 -> 40;
               case 44 -> 13;
               case 45 -> 49;
               case 46 -> 1;
               case 47 -> 42;
               case 48 -> 5;
               case 49 -> 11;
               case 50 -> 2;
               case 51 -> 62;
               case 52 -> 9;
               case 53 -> 0;
               case 54 -> 46;
               case 55 -> 44;
               case 56 -> 52;
               case 57 -> 54;
               case 58 -> 37;
               case 59 -> 34;
               case 60 -> 30;
               case 61 -> 18;
               case 62 -> 19;
               default -> 22;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "J\u0017\u0004nX5EWIeR(@\nB#B.@\u0015Y#E?G\u001dO\u007f\u0019伏叢伬叡栜叼伏佼伬使";
      b[1] = "w%";
      b[2] = "pv\r1P${y\u001c~,=tc\u0012=\u001b\rbt\u001e \n!uy";
      b[3] = boolean.class;
      c[3] = "java/lang/Boolean";
      b[4] = "\u0003#";
      b[5] = "w(\u001b[*pi \u0001\u0014Vds-\u0002W";
      b[6] = void.class;
      c[6] = "java/lang/Void";
      b[7] = "rn\u00038\u0015Uya\u0012wt[rj\u0016-";
      b[8] = "O\u000fS\u0006=\u000f\u0016_R{*q\u001f\u0005\u0000\u0014:\u0016\u0017\u0010Z@CHAR_\u0002$@T\b\u000b{";
      b[9] = "XisR\u0011;\u00019r/桶优史栝栉佲厬桜栨叇\u0010\u0015\u001d&\n\u007fnN\u001d9\u0001";
      b[10] = "=4i#&>ddh^\u0004@n51n>qj8ofX";
      b[11] = "I(e_#\u0015\u0010xd\"厞桲口优栟叡伀桲佽优\u0006\u0018/\b\u001b>xC/\u0017\u0010";
      b[12] = "yN:'#\u0011 \u001e;Z\u0013o*Obj;^.B<b]";
      b[13] = "]c\r\u007f\u000f\u0013\u00043\f\u0002\u001am\u000ebU2\u0017\\\no\u000b:qQM>\r3\t\u0015\u0004c\u0002\u0002";
      b[14] = "C_sQ$K\u001a\u000fr,桃栬叩叱叓可桃叶佷佯\u0010\u0010cOT@-N PU";
   }

   public static int w(int a, long c) {
      // $VF: Couldn't be decompiled
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      // java.lang.IllegalStateException: No common supertype for ternary expression
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getExprType(FunctionExprent.java:223)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.getInferredExprType(FunctionExprent.java:299)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.getCastedExprent(ExprProcessor.java:962)
      //   at org.jetbrains.java.decompiler.modules.decompiler.exps.ExitExprent.toJava(ExitExprent.java:86)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.listToJava(ExprProcessor.java:891)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.BasicBlockStatement.toJava(BasicBlockStatement.java:91)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.SequenceStatement.toJava(SequenceStatement.java:107)
      //   at org.jetbrains.java.decompiler.modules.decompiler.ExprProcessor.jmpWrapper(ExprProcessor.java:829)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement.toJava(IfStatement.java:258)
      //   at org.jetbrains.java.decompiler.modules.decompiler.stats.RootStatement.toJava(RootStatement.java:36)
      //   at org.jetbrains.java.decompiler.main.ClassWriter.writeMethod(ClassWriter.java:1306)
      //
      // Bytecode:
      // 00: getstatic cn/cool/cherish/utils/render/何友何友树友何何何何.a J
      // 03: lload 1
      // 04: lxor
      // 05: lstore 1
      // 06: ldc2_w 2099799605332815987
      // 09: lload 1
      // 0a: invokedynamic û (JJ)Z bsm=cn/cool/cherish/utils/render/何友何友树友何何何何.a (Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite; args=[  ]
      // 0f: istore 4
      // 11: iload 0
      // 12: ifge 17
      // 15: bipush 0
      // 16: ireturn
      // 17: iload 0
      // 18: iload 4
      // 1a: lload 1
      // 1b: lconst_0
      // 1c: lcmp
      // 1d: iflt 26
      // 20: ifeq 2e
      // 23: sipush 255
      // 26: if_icmple 2d
      // 29: sipush 255
      // 2c: ireturn
      // 2d: iload 0
      // 2e: ireturn
   }

   public static int A(int a, int extraAlpha, int a, int var3, int op, long rgb1) {
      long ax = 何友何友树友何何何何.a ^ rgb1 ^ 111928868458853L;
      return extraAlpha & ~op | D(a & op, extraAlpha, (int)a, var3, ax);
   }

   public static int L(int a) {
      int r = a >> 16 & 0xFF;
      int g = a >> 8 & 0xFF;
      int b = a & 255;
      return (r + g + b) / 3;
   }

   public static int P(long a, int a, int var3, float v1) {
      long ax = 何友何友树友何何何何.a ^ a ^ 2414354041679L;
      return w((int)(a + v1 * (var3 - a)), ax);
   }

   public static boolean T() {
      F();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static String HE_DA_WEI() {
      return "解放村多种2队1144号";
   }
}
