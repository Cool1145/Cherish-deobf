package cn.cool.cherish.utils.render;

import cn.cool.cherish.module.何友友树友何友何何何;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

class 树树何友友友友何树友$何树何友树树友何友友 extends HashMap<String, Color> implements  {
   private static final long a;
   private static final long[] b;
   private static final Integer[] c;
   private static final Map d = new HashMap(13);
   private static int _何树友被何大伟克制了 _;

   树树何友友友友何树友$何树何友树树友何友友(long a) {
      a = 树树何友友友友何树友$何树何友树树友何友友.a ^ a;
      super();
      this.put("c", new Color(a<"e">(22521, 8656462128258763963L ^ a)));
      this.put("e", new Color(a<"e">(18744, 8262511851150430841L ^ a)));
      this.put("a", new Color(a<"e">(6909, 5058973143150625209L ^ a)));
      this.put("9", new Color(a<"e">(3209, 6217910308016691137L ^ a)));
      this.put("b", new Color(a<"e">(4976, 7717028817843357758L ^ a)));
      this.put("d", new Color(a<"e">(1557, 4570102456526347602L ^ a)));
      this.put("f", new Color(a<"e">(4442, 3586085744437070367L ^ a)));
      this.put("8", new Color(a<"e">(21733, 7578166492279295907L ^ a)));
      this.put("4", new Color(a<"e">(14818, 6337775390300021417L ^ a)));
      this.put("6", new Color(a<"e">(25245, 7273288674862594516L ^ a)));
      this.put("2", new Color(a<"e">(4942, 5407057515470948365L ^ a)));
      this.put("1", new Color(170));
      this.put("3", new Color(a<"e">(7245, 356468606549100295L ^ a)));
      this.put("5", new Color(a<"e">(11922, 1477197433749255645L ^ a)));
      this.put("7", new Color(a<"e">(8391, 7784127007419612039L ^ a)));
      this.put("0", new Color(0));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-3651340881954611125L, 2683173871223167682L, MethodHandles.lookup().lookupClass()).a(103429801620618L);
      // $VF: monitorexit
      a = var10000;
      long var0 = a ^ 10652624902378L;
      Cipher var2;
      Cipher var14 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var14.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[14];
      int var5 = 0;
      String var6 = "C¬ìN#+\u00905DðWR+\u0087\u0002\u0007Jßú£=npt\u0019Q{èôàÑáÇ73ØÚC®a¿ýPt¿\u0005e\r¡°4a\u0001ÿKÅ\u0006!q!\u0017\u0018¹ù¿\u0087D=\tàé\u007f1º\u008e»õpÍi4OL¶\u0015\u0083§\u0017èíéùµ\u0082«Ú";
      byte var7 = 96;
      byte var4 = 0;

      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var15 = var8;
         var10001 = var5++;
         long var18 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte var20 = -1;

         while (true) {
            long var10 = var18;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var22 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var20) {
               case 0:
                  var15[var10001] = var22;
                  if (var4 >= var7) {
                     b = var8;
                     c = new Integer[14];
                     return;
                  }
                  break;
               default:
                  var15[var10001] = var22;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "):7cÿY¾;4Ñ -K\u0018«\f";
                  var7 = 16;
                  var4 = 0;
            }

            byte var17 = var4;
            var4 += 8;
            var9 = var6.substring(var17, var4).getBytes("ISO-8859-1");
            var15 = var8;
            var10001 = var5++;
            var18 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var20 = 0;
         }
      }
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友$何树何友树树友何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 13462;
      if (c[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = b[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])d.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/render/树树何友友友友何树友$何树何友树树友何友友", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         c[var3] = var15;
      }

      return c[var3];
   }

   private static String LIU_YA_FENG() {
      return "行走的50万——何炜霖";
   }
}
