package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// $VF: synthetic class
class 友树树何何树树何何树$友树何何友友树何何友 implements 何树友 {
   private static final Object[] a = new Object[11];
   private static final String[] b = new String[11];
   private static int _何炜霖大狗叫 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(4952978726900324449L, 4980171979204086898L, MethodHandles.lookup().lookupClass()).a(245234161038402L);
      // $VF: monitorexit
      long var0 = var10000 ^ 52644649565278L;
      a();

      try {
         a<"ý">(4718259339011237467L, var0)[a<"ý">(4718334598717183650L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"ý">(4718259339011237467L, var0)[a<"ý">(4718035026906586415L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"ý">(4718259339011237467L, var0)[a<"ý">(4717934848734682421L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"ý">(4718259339011237467L, var0)[a<"ý">(4718138301489254514L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"ý">(4718259339011237467L, var0)[a<"ý">(4717845406800612291L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"ý">(4718259339011237467L, var0)[a<"ý">(4718186576407846433L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'e' && var8 != 236 && var8 != 253 && var8 != 'n') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'J') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'i') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'e') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 253) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友树树何何树树何何树$友树何何友友树何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 9;
               case 1 -> 21;
               case 2 -> 35;
               case 3 -> 1;
               case 4 -> 3;
               case 5 -> 30;
               case 6 -> 26;
               case 7 -> 57;
               case 8 -> 56;
               case 9 -> 51;
               case 10 -> 13;
               case 11 -> 6;
               case 12 -> 50;
               case 13 -> 53;
               case 14 -> 52;
               case 15 -> 34;
               case 16 -> 31;
               case 17 -> 23;
               case 18 -> 36;
               case 19 -> 48;
               case 20 -> 10;
               case 21 -> 17;
               case 22 -> 59;
               case 23 -> 44;
               case 24 -> 42;
               case 25 -> 19;
               case 26 -> 55;
               case 27 -> 49;
               case 28 -> 60;
               case 29 -> 38;
               case 30 -> 2;
               case 31 -> 24;
               case 32 -> 37;
               case 33 -> 61;
               case 34 -> 40;
               case 35 -> 11;
               case 36 -> 46;
               case 37 -> 33;
               case 38 -> 43;
               case 39 -> 20;
               case 40 -> 14;
               case 41 -> 4;
               case 42 -> 12;
               case 43 -> 54;
               case 44 -> 28;
               case 45 -> 16;
               case 46 -> 45;
               case 47 -> 29;
               case 48 -> 39;
               case 49 -> 27;
               case 50 -> 47;
               case 51 -> 63;
               case 52 -> 41;
               case 53 -> 25;
               case 54 -> 8;
               case 55 -> 7;
               case 56 -> 15;
               case 57 -> 62;
               case 58 -> 22;
               case 59 -> 58;
               case 60 -> 18;
               case 61 -> 5;
               case 62 -> 0;
               default -> 32;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "+\u0003<z\u001e3+\u0003+&\u0012<1H+;\u0001?k\"!&\u001691\u000f':";
      a[1] = "Im\u001b\u001f\u0012=F-V\u0014\u0018 Cp]R\b&CoFR厶桃栻佖你桭桬伇使栒\u0011厷桬伇使又叾桭伨伇叡";
      a[2] = "gr";
      a[3] = "J's\u0017\u0013sA(bXr}J#f\u0002";
      a[4] = "1;7\u0019O21`!\u007fp\u0010\tZN\u001c\u0000 4t%\u001c[6";
      a[5] = "P]P<\u000b;P\u0006FZ\"\u0017n<iZ\u001amJ\u0006[1\u001a6\\";
      a[6] = "YYh^xOY\u0002~8Fce\"\u0011[7]\\\u0016z[lK";
      a[7] = "6vH.CNf>I7/伬佒厍叴桏栶伬栖厍佪V\u0016\u0016nq\u000f6P\u001e`2";
      a[8] = "dp\u0019\u001b\u007fxd+\u000f}KT]\u0011 }n.~+\u0012\u0016nuh";
      a[9] = "\\\\BmiU\\\u0007T\u000bDsd=;h&GY\u0013Ph}Q";
      a[10] = "H\u0003CXW*HXU>x\u0019+]\u0007GC3@]\\Q";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String HE_WEI_LIN() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
