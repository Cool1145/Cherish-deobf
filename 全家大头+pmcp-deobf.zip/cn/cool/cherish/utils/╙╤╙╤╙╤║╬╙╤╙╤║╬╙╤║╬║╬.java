package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.Rotation;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 友友友何友友何友何何 implements 何树友 {
   private final 友何友友何树何友何友 何树树树树何何何树友;
   public final Rotation 友何树树何树何树友树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[11];
   private static final String[] f = new String[11];
   private static String HE_DA_WEI;

   public 友友友何友友何友何何(友何友友何树何友何友 placeInfo, Rotation rotation) {
      this.何树树树树何何何树友 = placeInfo;
      this.友何树树何树何树友树 = rotation;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2491637898058320193L, 4332081468307304557L, MethodHandles.lookup().lookupClass()).a(102569217811501L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 21718315089137L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = '0';
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  ")öáWh\u0090|\u0093\u009e\u0089`\u001cB(9â7_ôd\n[\tk¤®\f)ëÉüG´\u009b´\u0086z\u0016¦2Ñû\u001fv\u0086ì±\u008f\u0018{N\u008fZT\u001a½£\rW\u0011{ßÜE\b\u008f\u0011ämÊµ`r"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 73) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = ")öáWh\u0090|\u0093\u009e\u0089`\u001cB(9â7_ôd\n[\tk¤®\f)ëÉüG´\u009b´\u0086z\u0016¦2Ñû\u001fv\u0086ì±\u008f\u0018{N\u008fZT\u001a½£\rW\u0011{ßÜE\b\u008f\u0011ämÊµ`r"
            .charAt(var4);
      }
   }

   @Override
   public boolean equals(Object var1) {
      long a = 友友友何友友何友何何.a ^ 88613202594046L;
      b<"º">(7723747149990060541L, a);
      if (this != var1) {
         return !(var1 instanceof 友友友何友友何友何何 var2x)
            ? false
            : b<"ö">(this, 7723698000367981564L, a).equals(b<"ö">(var2x, 7723698000367981564L, a))
               && b<"ö">(this, 7723887046561586766L, a).equals(b<"ö">(var2x, 7723887046561586766L, a));
      } else {
         return true;
      }
   }

   @Override
   public String toString() {
      long a = 友友友何友友何友何何.a ^ 42597741235858L;
      return a<"x">(5086, 8951266259205075528L ^ a)
         + b<"ö">(this, -1343092756555328112L, a)
         + a<"x">(11057, 4649018211361622694L ^ a)
         + b<"ö">(this, -1343000189849184222L, a)
         + ")";
   }

   @Override
   public int hashCode() {
      long a = 友友友何友友何友何何.a ^ 105545500510047L;
      b<"º">(2634971325578456668L, a);
      return (b<"ö">(this, 2634914749949828189L, a) != null ? b<"ö">(this, 2634914749949828189L, a).hashCode() : 0) * 31
         + (b<"ö">(this, 2635112869136241135L, a) != null ? b<"ö">(this, 2635112869136241135L, a).hashCode() : 0);
   }

   public static 友友友何友友何友何何 i(友友友何友友何友何何 a, 友何友友何树何友何友 var0, Rotation a, int var3, Object var2, long var1) {
      var1 = 友友友何友友何友何何.a ^ var1;
      b<"º">(7790993319825565394L, (long)var1);
      if ((var3 & 1) != 0) {
         var0 = b<"ö">(a, 7791084770253280467L, (long)var1);
      }

      if ((var3 & 2) != 0) {
         a = (long)b<"ö">(a, 7791133216348854625L, (long)var1);
      }

      return a.X(var0, a);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友友友何友友何友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public Rotation x(long a) {
      a = 友友友何友友何友何何.a ^ a;
      return b<"ö">(this, -320902381041037579L, (long)a);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public 友何友友何树何友何友 l(long a) {
      a = 友友友何友友何友何何.a ^ a;
      return b<"ö">(this, 1218610029467822117L, (long)a);
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 246 && var8 != 'c' && var8 != 239 && var8 != 242) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 245) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 186) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 246) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'c') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 19656;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/友友友何友友何友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      e[0] = "\u000e\u000b\"'\u00115\u0001Ko,\u001b(\u0004\u0016dj\u000b.\u0004\t\u007fj厵厑厦估叇厏伫厑伸估";
      e[1] = "u-Qw]uzm\u001c|Wh\u007f0\u0017:Gn\u007f/\f:叹住叝厈伪栅佧发佃厈";
      e[2] = "<z.gha7u?(\u0014x8o1k#H.x=v2d9u";
      e[3] = "fl4_\u0019ci,yT\u0013~lqr\u0012\u0003xlni\u0012厽栝収叉住号桧叇栔叉";
      e[4] = boolean.class;
      f[4] = "java/lang/Boolean";
      e[5] = "kUA\u0003t/d\u0015\f\b~2aH\u0007Nn4aW\u001cNs%dK\n\u00125\u0012gO\u000e\u0014r/f";
      e[6] = "mR=\u0005~\u0019f],J\u001f\u0017mV(\u0010";
      e[7] = "E\u001bP]ZW\u000b\fSaI(@\u000eW\u000fZZ\t\u0017E\u0013 \u0011\u000b\u0000E\u001bRX\u0012\u0012Ya";
      e[8] = "\u0016EX\u000e\u001fW\u0016\u0014W\u0001rM,BMUCCA\u0003LZN<";
      e[9] = "Xp\u0005\f>^\u0016g\u00060伙核桽栎桧佭伙佼桽叔~\ttO\nf\u001aY;\u0018\u001a";
      e[10] = "KF>< \u0013\u0005Q=\u0000厙伱桮核优栙伇桵厴核E;?\\\u0018\u001c(~f\u0017\u001c";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 35;
               case 1 -> 63;
               case 2 -> 27;
               case 3 -> 19;
               case 4 -> 7;
               case 5 -> 49;
               case 6 -> 40;
               case 7 -> 32;
               case 8 -> 56;
               case 9 -> 8;
               case 10 -> 12;
               case 11 -> 62;
               case 12 -> 57;
               case 13 -> 23;
               case 14 -> 22;
               case 15 -> 36;
               case 16 -> 14;
               case 17 -> 1;
               case 18 -> 17;
               case 19 -> 60;
               case 20 -> 26;
               case 21 -> 5;
               case 22 -> 4;
               case 23 -> 37;
               case 24 -> 16;
               case 25 -> 29;
               case 26 -> 58;
               case 27 -> 61;
               case 28 -> 41;
               case 29 -> 44;
               case 30 -> 20;
               case 31 -> 0;
               case 32 -> 55;
               case 33 -> 39;
               case 34 -> 24;
               case 35 -> 28;
               case 36 -> 10;
               case 37 -> 48;
               case 38 -> 31;
               case 39 -> 42;
               case 40 -> 2;
               case 41 -> 11;
               case 42 -> 21;
               case 43 -> 54;
               case 44 -> 9;
               case 45 -> 46;
               case 46 -> 50;
               case 47 -> 47;
               case 48 -> 45;
               case 49 -> 34;
               case 50 -> 3;
               case 51 -> 6;
               case 52 -> 59;
               case 53 -> 53;
               case 54 -> 33;
               case 55 -> 25;
               case 56 -> 15;
               case 57 -> 43;
               case 58 -> 38;
               case 59 -> 51;
               case 60 -> 30;
               case 61 -> 13;
               case 62 -> 52;
               default -> 18;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友友友何友友何友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public 友友友何友友何友何何 X(友何友友何树何友何友 a, Rotation rotation) {
      return new 友友友何友友何友何何(a, rotation);
   }

   public 友何友友何树何友何友 R(long a) {
      a = 友友友何友友何友何何.a ^ a;
      return b<"ö">(this, -6120851687552724030L, (long)a);
   }

   public Rotation G(long a) {
      a = 友友友何友友何友何何.a ^ a;
      return b<"ö">(this, 5221048825067240714L, (long)a);
   }

   private static String HE_SHU_YOU() {
      return "何炜霖黑水";
   }
}
