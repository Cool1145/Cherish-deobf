package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang3.RandomUtils;

public class 树友树友友何何树何何 implements 何树友 {
   public long 树友树友树友树树树友;
   private static int[] 何友友树树树何何树树;
   private static final long a;
   private static final long b;
   private static final Object[] c = new Object[15];
   private static final String[] d = new String[15];
   private static int _何树友，和树做朋友 _;

   public 树友树友友何何树何何(long a) {
      a = 树友树友友何何树何何.a ^ a;
      long ax = a ^ 45056442108411L;
      super();
      a<"Õ">(this, System.currentTimeMillis(), 8822176277538558981L, a);
      this.U(ax);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(2279118165050920276L, -4631988652605696545L, MethodHandles.lookup().lookupClass()).a(244078399682765L);
      // $VF: monitorexit
      a = var10000;
      long var5 = a ^ 49808740000033L;
      a();
      if (a<"Æ">(-5708224509653517333L, var5) == null) {
         a<"Æ">(new int[4], -5707902406907360229L, var5);
      }

      Cipher var0;
      Cipher var7 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var5 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var5 << var1 * 8 >>> 56);
      }

      var7.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var4 = var0.doFinal(new byte[]{-117, 13, 14, -114, -62, 14, 8, -75});
      long var8 = (var4[0] & 255L) << 56
         | (var4[1] & 255L) << 48
         | (var4[2] & 255L) << 40
         | (var4[3] & 255L) << 32
         | (var4[4] & 255L) << 24
         | (var4[5] & 255L) << 16
         | (var4[6] & 255L) << 8
         | var4[7] & 255L;
      byte var10001 = -1;
      b = var8;
   }

   public boolean C(long a, double var3) {
      long ax = 树友树友友何何树何何.a ^ a ^ 46562862148967L;
      return this.Y((long)var3, ax);
   }

   public void J(long a, long var3) {
      var3 = 树友树友友何何树何何.a ^ var3;
      a<"Õ">(this, (long)a, 8463091986663955225L, var3);
   }

   public static void S(int[] var0) {
      何友友树树树何何树树 = var0;
   }

   public boolean V(long a, boolean a, long var4) {
      var4 = 树友树友友何何树何何.a ^ var4;
      long ax = var4 ^ 15648704181693L;
      a<"Æ">(5055415073288588555L, var4);
      if (System.currentTimeMillis() - a<"ë">(this, 5055444877800532035L, var4) > a) {
         this.U(ax);
         return true;
      } else {
         return false;
      }
   }

   public static long b(long a, int var2, int minCPS) {
      a = 树友树友友何何树何何.a ^ a;
      a<"Æ">(2971355369246548511L, (long)a);
      long var10000 = (long)(Math.random() * (1000.0 / var2 - 1000.0 / minCPS + 1.0) + 1000.0 / minCPS);
      a<"Æ">(!a<"Æ">(2971689250902766131L, (long)a), 2971573257066499290L, (long)a);
      return var10000;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public boolean x(long a, long var3) {
      var3 = 树友树友友何何树何何.a ^ var3;
      a<"Æ">(4667746055356517348L, var3);
      return System.currentTimeMillis() - a >= a<"ë">(this, 4667936087641583276L, var3);
   }

   public boolean c(long a, long var3) {
      var3 = 树友树友友何何树何何.a ^ var3;
      a<"Æ">(4956034923413213156L, var3);
      return System.currentTimeMillis() - a<"ë">(this, 4956109052009671340L, var3) >= a;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public long h(long a) {
      a = 树友树友友何何树何何.a ^ a;
      long ax = a ^ 132886648072800L;
      return this.t(System.nanoTime() - a<"ë">(this, -9079927362978271338L, (long)a), ax);
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (d[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 41;
               case 1 -> 4;
               case 2 -> 22;
               case 3 -> 6;
               case 4 -> 29;
               case 5 -> 18;
               case 6 -> 5;
               case 7 -> 44;
               case 8 -> 15;
               case 9 -> 39;
               case 10 -> 37;
               case 11 -> 9;
               case 12 -> 42;
               case 13 -> 34;
               case 14 -> 46;
               case 15 -> 52;
               case 16 -> 32;
               case 17 -> 50;
               case 18 -> 21;
               case 19 -> 16;
               case 20 -> 51;
               case 21 -> 36;
               case 22 -> 25;
               case 23 -> 54;
               case 24 -> 57;
               case 25 -> 3;
               case 26 -> 13;
               case 27 -> 28;
               case 28 -> 26;
               case 29 -> 47;
               case 30 -> 20;
               case 31 -> 35;
               case 32 -> 63;
               case 33 -> 49;
               case 34 -> 53;
               case 35 -> 48;
               case 36 -> 43;
               case 37 -> 10;
               case 38 -> 58;
               case 39 -> 14;
               case 40 -> 0;
               case 41 -> 27;
               case 42 -> 33;
               case 43 -> 56;
               case 44 -> 19;
               case 45 -> 59;
               case 46 -> 7;
               case 47 -> 24;
               case 48 -> 45;
               case 49 -> 60;
               case 50 -> 11;
               case 51 -> 8;
               case 52 -> 62;
               case 53 -> 55;
               case 54 -> 17;
               case 55 -> 31;
               case 56 -> 30;
               case 57 -> 1;
               case 58 -> 23;
               case 59 -> 12;
               case 60 -> 40;
               case 61 -> 2;
               case 62 -> 38;
               default -> 61;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            d[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      c[0] = "^2O^\njQr\u0002U\u0000wT/\t\u0013\u0010qT0\u0012\u0013桴収栬厗厪佨估栔佨伉";
      c[1] = ">\u007f";
      c[2] = void.class;
      d[2] = "java/lang/Void";
      c[3] = "\u001eW";
      c[4] = long.class;
      d[4] = "java/lang/Long";
      c[5] = "SYN83\u0015XV_wO\fWLQ4x<A[])i\u0010VV";
      c[6] = ")xMOt}&8\u0000D~`#e\u000b\u0002v}.c\u000fI5_%r\u0016@~";
      c[7] = boolean.class;
      d[7] = "java/lang/Boolean";
      c[8] = "`$\u0007/\u0011[k+\u0016`pU` \u0012:";
      c[9] = "Oo\u001d(5\u001bC4\u0015F\u0005`\u001e(]7k\u000eFm\u000f$U";
      c[10] = "Y\f><&(UW6R桟厐栫叱桗厑桟桊栫叱Nh70C\\%?#0\\";
      c[11] = "@C^l\u0016\u0018L\u0018V\u0002\u001fc\u0010\u0006\\x\u0012[\u0017MRxvXP\u000fTfN_\u001b\u0001T\u0002";
      c[12] = "nX\u000b\u0007'+,N\u001bCN\u001eR\t]\u0003 31E\u001f\u001d?Wk[\u0010\bpn=\nQ\u001bN";
      c[13] = "q,r$/l}wzJ\u0014\u0017 k2;qyx.`(O.ucptvx$\"cJ";
      c[14] = "h9\rqB\u000e*/\u001d5+\u001fTh[uE\u00167$\u0019kZr";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public boolean a(double a, long var3) {
      var3 = 树友树友友何何树何何.a ^ var3;
      long ax = var3 ^ 66224638730059L;
      a<"Æ">(-5416097928829042699L, var3);
      boolean var10000 = this.t(System.nanoTime() - a<"ë">(this, -5415900929839752515L, var3), ax) >= (long)(a * 1000.0);
      byte var10001 = a<"Æ">(-5415587386645123111L, var3);
      if (var3 > 0L) {
         if (var10001 != 0) {
            return var10000;
         }

         var10001 = 1;
      }

      a<"Æ">(new int[var10001], -5415857085789861883L, var3);
      return var10000;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/树友树友友何何树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 235 && var8 != 213 && var8 != 246 && var8 != 212) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 197) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 198) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 235) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 246) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public long p(long a) {
      a = 树友树友友何何树何何.a ^ a;
      return System.currentTimeMillis() - a<"ë">(this, 384436701049727806L, (long)a);
   }

   public void p(long a) {
      a = 树友树友友何何树何何.a ^ a;
      a<"Õ">(this, System.nanoTime(), 6799534931626389559L, (long)a);
   }

   public static long k(int a, int maxDelay) {
      return RandomUtils.nextInt((int)a, maxDelay);
   }

   public long t(long a, long var3) {
      long var10000 = 树友树友友何何树何何.a ^ var3;
      return a / b;
   }

   public boolean g(long a, long var3) {
      var3 = 树友树友友何何树何何.a ^ var3;
      long ax = var3 ^ 27665151556888L;
      a<"Æ">(6234392228211236262L, var3);
      return this.t(System.nanoTime() - a<"ë">(this, 6234670591897991406L, var3), ax) >= a;
   }

   public void U(long a) {
      a = 树友树友友何何树何何.a ^ a;
      a<"Õ">(this, System.currentTimeMillis(), -2126090421036200939L, (long)a);
   }

   public void A(long a, long var3) {
      var3 = 树友树友友何何树何何.a ^ var3;
      a<"Õ">(this, Math.max(a<"ë">(this, 6201130177558575205L, var3), System.currentTimeMillis() + a), 6201130177558575205L, var3);
   }

   public boolean Y(long a, long var3) {
      var3 = 树友树友友何何树何何.a ^ var3;
      a<"Æ">(-8278652455336327617L, var3);
      return System.currentTimeMillis() - a<"ë">(this, -8278552789129845897L, var3) > a;
   }

   public static int[] X() {
      return 何友友树树树何何树树;
   }

   private static String HE_JIAN_GUO() {
      return "职业技术教育中心学校";
   }
}
