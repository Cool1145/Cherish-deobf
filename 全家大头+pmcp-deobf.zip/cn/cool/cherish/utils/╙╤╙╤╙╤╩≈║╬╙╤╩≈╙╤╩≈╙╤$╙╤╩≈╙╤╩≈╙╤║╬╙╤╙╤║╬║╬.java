package cn.cool.cherish.utils;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// $VF: synthetic class
class 友友友树何友树友树友$友树友树友何友友何何 implements 何树友 {
   private static final Object[] a = new Object[11];
   private static final String[] b = new String[11];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(7072989203441064660L, -5855934575880680921L, MethodHandles.lookup().lookupClass()).a(116787718619068L);
      // $VF: monitorexit
      long var0 = var10000 ^ 16368175586243L;
      a();

      try {
         a<"ú">(3066079508131573123L, var0)[a<"ú">(3066704254621112269L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"ú">(3066079508131573123L, var0)[a<"ú">(3065934921577940676L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"ú">(3066079508131573123L, var0)[a<"ú">(3065966407214110327L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"ú">(3066079508131573123L, var0)[a<"ú">(3066788826861200558L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"ú">(3066079508131573123L, var0)[a<"ú">(3065846502594337620L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"ú">(3066079508131573123L, var0)[a<"ú">(3066916356871033245L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 203 && var8 != 'S' && var8 != 250 && var8 != 234) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 207) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 213) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 203) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'S') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 250) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友友友树何友树友树友$友树友树友何友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 61;
               case 1 -> 7;
               case 2 -> 13;
               case 3 -> 19;
               case 4 -> 18;
               case 5 -> 46;
               case 6 -> 45;
               case 7 -> 8;
               case 8 -> 31;
               case 9 -> 33;
               case 10 -> 10;
               case 11 -> 32;
               case 12 -> 27;
               case 13 -> 20;
               case 14 -> 55;
               case 15 -> 0;
               case 16 -> 47;
               case 17 -> 48;
               case 18 -> 39;
               case 19 -> 43;
               case 20 -> 24;
               case 21 -> 28;
               case 22 -> 40;
               case 23 -> 12;
               case 24 -> 14;
               case 25 -> 51;
               case 26 -> 58;
               case 27 -> 34;
               case 28 -> 35;
               case 29 -> 25;
               case 30 -> 56;
               case 31 -> 23;
               case 32 -> 63;
               case 33 -> 21;
               case 34 -> 9;
               case 35 -> 60;
               case 36 -> 37;
               case 37 -> 5;
               case 38 -> 36;
               case 39 -> 2;
               case 40 -> 62;
               case 41 -> 29;
               case 42 -> 54;
               case 43 -> 15;
               case 44 -> 42;
               case 45 -> 49;
               case 46 -> 17;
               case 47 -> 38;
               case 48 -> 6;
               case 49 -> 57;
               case 50 -> 16;
               case 51 -> 11;
               case 52 -> 26;
               case 53 -> 1;
               case 54 -> 3;
               case 55 -> 59;
               case 56 -> 52;
               case 57 -> 53;
               case 58 -> 22;
               case 59 -> 44;
               case 60 -> 30;
               case 61 -> 41;
               case 62 -> 50;
               default -> 4;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "._7O5+._ \u00139$4\u0014 \u000e*'n~*\u0013=!4S,\u000f";
      a[1] = "jPyY\u000f\u001ee\u00104R\u0005\u0003`M?\u0014\u0015\u0005`R$\u0014厫厺参栯伂叱桱厺栘叵s叱桱厺栘叵伂叱厫伤作";
      a[2] = "UU";
      a[3] = "1\f\u001e\u007f&O:\u0003\u000f0GA1\b\u000bj";
      a[4] = "s4\u0017n3$ |\u0013V\u0004\u0012NqVoa  \"\u001ek";
      a[5] = "wgUL(&$/Qt\u001d\u0005\u0011ClI:qru\u0002\u001aru";
      a[6] = "f9\u0014\u001e-!(8Lr桞会栏叅併厱会桞叕佛(K67xbC\u0017.y\u007f";
      a[7] = "1\u0013;{&#b[?C\n\nV7BCq55Sh-\"}1";
      a[8] = "\u00193\u0016zmpJ{\u0012B\\Yy\u0017oB:f\u001dsE,i.\u0019";
      a[9] = "*'\u0012\u001f nyo\u0016'\u0006GH\u0019+\u001a29/5EIz=";
      a[10] = "\u0010\t6O\u0003\u001dCA2w$:v-\u000fJ\u0011J\u0015\u001ba\u0019YN";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String LIU_YA_FENG() {
      return "行走的50万——何炜霖";
   }
}
