package cn.cool.cherish.utils.wrapper;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何树何何树何友何何何;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Minecraft;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public interface IWrapper {
   Minecraft mc;
   Logger logger;
   long d;
   Object[] r = new Object[10];
   String[] s = new String[10];

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-125872176780253550L, 5307505203392040775L, MethodHandles.lookup().lookupClass()).a(61731602647426L);
      // $VF: monitorexit
      d = var10000;
      ab();
      Cipher var1;
      Cipher var3 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(21802815177563L << var2 * 8 >>> 56);
      }

      var3.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var4 = a(var1.doFinal("q++1\u0081ë¹\u000b\u0082:\u001fþ\u008fÄ÷µ".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      String var0 = var4;
      mc = Cherish.e();
      logger = LogManager.getLogger(var0);
   }

   private static CallSite e(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/wrapper/IWrapper" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = r[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = r[var4];
      if (var5 instanceof String) {
         String var6 = s[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         r[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = r[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = s[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         r[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'q' && var8 != 212 && var8 != 234 && var8 != 248) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 198) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 231) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'q') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 234) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (s[var4] != null) {
         return var4;
      } else {
         Object var5 = r[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 8;
               case 1 -> 57;
               case 2 -> 42;
               case 3 -> 53;
               case 4 -> 18;
               case 5 -> 37;
               case 6 -> 19;
               case 7 -> 16;
               case 8 -> 30;
               case 9 -> 24;
               case 10 -> 60;
               case 11 -> 49;
               case 12 -> 25;
               case 13 -> 32;
               case 14 -> 56;
               case 15 -> 27;
               case 16 -> 39;
               case 17 -> 0;
               case 18 -> 13;
               case 19 -> 46;
               case 20 -> 43;
               case 21 -> 63;
               case 22 -> 59;
               case 23 -> 4;
               case 24 -> 26;
               case 25 -> 28;
               case 26 -> 2;
               case 27 -> 48;
               case 28 -> 58;
               case 29 -> 12;
               case 30 -> 36;
               case 31 -> 51;
               case 32 -> 23;
               case 33 -> 41;
               case 34 -> 3;
               case 35 -> 54;
               case 36 -> 11;
               case 37 -> 15;
               case 38 -> 7;
               case 39 -> 10;
               case 40 -> 14;
               case 41 -> 1;
               case 42 -> 61;
               case 43 -> 40;
               case 44 -> 34;
               case 45 -> 22;
               case 46 -> 44;
               case 47 -> 17;
               case 48 -> 20;
               case 49 -> 33;
               case 50 -> 6;
               case 51 -> 21;
               case 52 -> 35;
               case 53 -> 5;
               case 54 -> 45;
               case 55 -> 31;
               case 56 -> 55;
               case 57 -> 50;
               case 58 -> 38;
               case 59 -> 52;
               case 60 -> 9;
               case 61 -> 47;
               case 62 -> 29;
               default -> 62;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            s[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   default boolean Q(long a) {
      a = 9620400029759L ^ a;
      int[] var4 = e<"ç">(7830196825875833853L, (long)a);
      if (mc != null) {
         Minecraft var10000 = mc;
         int[] var10001 = var4;
         if (a > 0L) {
            if (var4 == null) {
               if (mc.player == null) {
                  return true;
               }

               var10000 = mc;
            }

            var10001 = var4;
         }

         label37: {
            if (a >= 0L) {
               if (var10001 == null) {
                  if (var10000.level == null) {
                     return true;
                  }

                  var10000 = mc;
               }

               if (a <= 0L) {
                  break label37;
               }

               var10001 = var4;
            }

            if (var10001 == null) {
               if (e<"q">(var10000, 7830076794883668535L, (long)a) == null) {
                  return true;
               }

               var10000 = mc;
            }
         }

         if (var10000.getConnection() != null) {
            return false;
         }
      }

      return true;
   }

   private static void ab() {
      r[0] = "YV\u0014Jv\u0016YV\u0003\u0016z\u0019C\u001d\u0003\br\u001aYGN)r\u0011RP\u0012\u0005}\u000b";
      r[1] = "+*\n*s4+*\u001dv\u007f;1a\u001dhw8+;Pik11&\u000eh\u007f$ =PIk11&.h\u007f$ =9es8\b \u001aa";
      r[2] = "Ta\u0003V\u0002l[!N]\bq^|E\u001b\u0018w^c^\u001b\u001aqV\u007f]P\u001f-`}LE\u001dfEZY\\\u0001p";
      r[3] = "5>";
      r[4] = "\u007f5W/5\u0018pu\u001a$?\u0005u(\u0011b/\u0003u7\nb-\u0005}+\t)(YU\f\u000b-*\u0007y)";
      r[5] = "n3\u001e9\rOe<\u000fvqVj&\u00015Ff|1\r(WJk<";
      r[6] = "8\u00141Aqa3\u001b \u000e\u0010o8\u0010$T";
      r[7] = "\u0006a,y\u0000Y\u0001de#~H=c-`OM\f69v\u0013\"\u0006!),\u0011\u0013S5?p~";
      r[8] = "BdP)kuYl\u0005Pi^\u00123\u0001o=^#3\u00033vx\u001a3X=y";
      r[9] = "B<G\u007f,$\u0015xY)W_{}B~o|\u0002y\u0013!l\u001e";
   }
}
