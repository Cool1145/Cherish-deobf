package cn.cool.cherish.utils.client;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.combat.KillAura;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.module.impl.movement.树友树友友何友友友友;
import cn.cool.cherish.module.impl.movement.树树何友树友友何何何;
import cn.cool.cherish.module.impl.player.友友树树何何友树何友;
import cn.cool.cherish.module.impl.player.树何友友树友何树友友;
import cn.cool.cherish.module.impl.player.树友何何友何树何树友;
import cn.cool.cherish.module.impl.player.树友何树友树何友树树;
import cn.cool.cherish.module.impl.player.树树何树树友何友友何;
import cn.cool.cherish.module.impl.render.WallHack;
import cn.cool.cherish.module.impl.render.友何树何何友友树友友;
import cn.cool.cherish.module.impl.render.树友树树何何友何何友;
import cn.cool.cherish.module.impl.render.树树树何友友友友何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

public final class ClientUtils implements IWrapper, 何树友 {
   private static Module[] 何树何树树何树何友何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[31];
   private static final String[] g = new String[31];
   private static int _何大伟为什么要诈骗何炜霖 _;

   private ClientUtils(long a) {
      a = 2420069701098L ^ a;
      super();
      throw new UnsupportedOperationException(a<"l">(13921, 8988806800167769560L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-227608132837298538L, -6074342570483599673L, MethodHandles.lookup().lookupClass()).a(35016989276110L);
      // $VF: monitorexit
      a = var10000;
      a();
      Y(null);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(102477068339044L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[6];
      int var5 = 0;
      String var4 = "Çûù\u001fs±8\u008e¸ÚÌá\u00823à©àM\u0095ldÆá8;þ×t\u0095\u0016O¬\u001av\u0098\u008d½¾\u000bó\u0010úCn®CèT\u0019ÆÔY,«Ýw\u009e\u00100å\u00813O¯  \u009d]\u0018)D)½\u0086\u0010*\u000f³+{A\u0088ùÂ(\u0080D\u00904(Ï";
      short var6 = 91;
      char var3 = '(';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[6];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "\u008b\u009c¡Ìq½Û·eW$\u0092bÊ\u009cRU\u0084\u0010ýVùEÅ+ê\u0004è\u0010|7\u007f\u0082Ø<ßó`\u0015\u0001²âð¯\u001a=Ñ®îD-¾H\u001e\u0004Ç °á¯t÷qr¶à\u009bÂ\u0092\u008c\u0084ÌÞË\u0019ëH\u008eª>dåÙF´~T\u00198¸²?ýh qdumWg\b'O]JGN\u008f.\u0002\u001eó\u001c¢C ÊÖA\u0081¸\u0001\u009d\u0004Ó[+z\u0081ñ\u0090Ô*¸®ò&\u009b Ñ*qÚ\u0084";
                  var6 = 145;
                  var3 = 'X';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public static void C(String a, long debugMessage) {
      F();
      if (mc.level != null && mc.player != null && Cherish.树何友友友友友树友友) {
         mc.player.displayClientMessage(Component.literal(a), false);
      }
   }

   public static boolean D(long var0) {
      b<"R">(340429941353908202L, 128934645925052L);
      return Cherish.instance != null && HUD.instance != null && b<"õ">(HUD.instance, 340470535816979562L, 128934645925052L).getValue().equals("English");
   }

   public static Module[] F() {
      return 何树何树树何树何友何;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 62;
               case 1 -> 4;
               case 2 -> 14;
               case 3 -> 1;
               case 4 -> 2;
               case 5 -> 40;
               case 6 -> 48;
               case 7 -> 19;
               case 8 -> 44;
               case 9 -> 9;
               case 10 -> 38;
               case 11 -> 56;
               case 12 -> 21;
               case 13 -> 49;
               case 14 -> 18;
               case 15 -> 17;
               case 16 -> 55;
               case 17 -> 12;
               case 18 -> 15;
               case 19 -> 35;
               case 20 -> 8;
               case 21 -> 16;
               case 22 -> 60;
               case 23 -> 45;
               case 24 -> 20;
               case 25 -> 31;
               case 26 -> 13;
               case 27 -> 29;
               case 28 -> 59;
               case 29 -> 61;
               case 30 -> 3;
               case 31 -> 32;
               case 32 -> 5;
               case 33 -> 22;
               case 34 -> 46;
               case 35 -> 51;
               case 36 -> 47;
               case 37 -> 0;
               case 38 -> 52;
               case 39 -> 10;
               case 40 -> 37;
               case 41 -> 39;
               case 42 -> 54;
               case 43 -> 25;
               case 44 -> 7;
               case 45 -> 50;
               case 46 -> 36;
               case 47 -> 11;
               case 48 -> 24;
               case 49 -> 53;
               case 50 -> 28;
               case 51 -> 57;
               case 52 -> 42;
               case 53 -> 27;
               case 54 -> 30;
               case 55 -> 23;
               case 56 -> 63;
               case 57 -> 34;
               case 58 -> 6;
               case 59 -> 43;
               case 60 -> 58;
               case 61 -> 26;
               case 62 -> 33;
               default -> 41;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 245 && var8 != 'P' && var8 != 204 && var8 != 207) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 214) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'R') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 245) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'P') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 204) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/client/ClientUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = " 5?\u0010s2/ur\u001by/*(y]i)*7b]\u007f1*>\u007f\u00072\u001e/2t\u001dh\b72}\u0000";
      f[1] = "Y\u0006Hy\u0014\u001bm%G9Y\u0010g8BdRVo%ObV\u001d,\u0007DsO\u0014gq";
      f[2] = "@jyQ8XKeh\u001eB\\XdxQtXO";
      f[3] = "l],fJic\u001dam@tf@j+HikFn`\u000bobCn+Ao|Cnd\\(GfF";
      f[4] = "Z!\n [\u0005UaG+Q\u0018P<LmB\u000bU:Am]\u0007I#\n\u0001[\u0005U*E-b\u000bU:A";
      f[5] = "?\bqW`P0H<\\jM5\u00157\u001aLW9\u00146Gg";
      f[6] = boolean.class;
      g[6] = "java/lang/Boolean";
      f[7] = "x6u\u0010hrwv8\u001bbor+3]q|w->]npk4u>hy~\u000e:\u001frx";
      f[8] = ".c69J\u0010.c!eF\u001f4(\u0001\u007fF\r\u0006i0zF\r4o,p";
      f[9] = "2S\u0016VkE=\u0013[]aX8NP\u001biE5HTP*g>YMYa";
      f[10] = "|\u0002\u001f}\u0015\u0019H!\u0010=X\u0012B<\u0015`STJ!\u0018fW\u001f\t\u0003\u0013wN\u0016Bu";
      f[11] = "{\u001aJ\u0001f\u0017O9EA+\u001cE$@\u001c ZM9M\u001a$\u0011\u000e\u001bF\u000b=\u0018Em";
      f[12] = void.class;
      g[12] = "java/lang/Void";
      f[13] = "\n`\u001dP\u0006=>C\u0012\u0010K64^\u0017M@p<C\u001aKD;\u007fa\u0011Z]24\u0017";
      f[14] = "A\n5O4\u0006J\u0005$\u0000U\bA\u000e Z";
      f[15] = "\u001d\u0006WX\u001crT\u0019WVu栀佻厸号号厶叚栿厸号4I'F\u001bSVMi\u001c\u001f";
      f[16] = "g^XLxV$\u001dQ\u000eGh\u001bh| \u0010t\u0007}d8\n,g^XLxV$\u001dQ\u000e";
      f[17] = " [[\n<BhFU\\B佱栃佫伹桴厁佱栃佫伹my\u0014`X\u0019\nrFd\b";
      f[18] = ">\u0004j-\u0005\u0004}Gco:1Y0C[:Cz\u0019>\"@\u00009\u0010|";
      f[19] = "\u001dIsLv/^\nz\u000eI\u001fdmZ|t,D\u0000(\u00067oMB";
      f[20] = "r$zA2b}gh\"DZr%iZs5%z~O\n";
      f[21] = "6:9Ss!uy0\u0011L\u0001F\u000f]^5?;|'\u001dv6y";
      f[22] = "Fv5zI\u000bI5'\u0019\u00183N3*b\bTL$7(q\n\t0,`\u0016\b\u001e-f\u0019";
      f[23] = "3Sb `M{Nlv\u001e叠佔叽桄桞佃栺及叽厞G#Mk\u0007f.fD{T";
      f[24] = "\u000eH\u0017\u000b}$Y\n]\b\u0003I0\u0000_\u001f{b_W\u0000\bn\u001b";
      f[25] = "<:\u00001s\u000b\u007fy\tsL L\u0007 F\u0013q<:\u00001s\u000b\u007fy\ts";
      f[26] = "C;__l\u001a\u0000xV\u001dS/9\u0006won\u0019\u001ar\u0004\u0015-Z\u00130";
      f[27] = "\u0012P\u0002\u001arwE\u0012H\u0019\f\u0016,\u0018J\u000et1CO\u0015\u0019aH\u001cFLDi4\\KH\u001e\f";
      f[28] = "b06M[R!s?\u000fdd\u0016\u0013\u0011*+r\u0016\u0018R@\u001dLov(\u0003^E-";
      f[29] = "l\u0010\"(D>cS0K-\u0006l\u001113\u0005i;N&&|62\u0017{.\u0000v?\u0013!K";
      f[30] = ".XzJ\u0002\u0017m\u001bs\b='TeRz\u0000\u0014w\u0011!\u0000CW~S";
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8593;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/client/ClientUtils", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/client/ClientUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static boolean g(Module a, long module) {
      F();
      return a == null
         ? false
         : a instanceof 友何树何何友友树友友
            || a instanceof 树友树树何何友何何友
            || a instanceof 树树树何友友友友何何
            || a instanceof WallHack
            || a instanceof 树何友友树友何树友友
            || a instanceof KillAura
            || a instanceof 友友树树何何友树何友
            || a instanceof 树友何树友树何友树树
            || a instanceof 树友何何友何树何树友
            || a instanceof 树友树友友何友友友友
            || a instanceof 树树何树树友何友友何
            || a instanceof 树树何友树友友何何何;
   }

   public static void v(long a, String var2) {
      a = 2420069701098L ^ a;
      b<"R">(-8002545713800801374L, (long)a);
      if (mc.level != null && mc.player != null && b<"Ì">(-8000686519266226524L, (long)a)) {
         mc.player.displayClientMessage(Component.literal(var2), true);
      }
   }

   public static void Y(Module[] var0) {
      何树何树树何树何友何 = var0;
   }

   public static void P(long a, String var2) {
      String coloredClientName = b<"Ì">(6361906413170654105L, 123256439527503L)
         + "C"
         + b<"Ì">(6361872470066962387L, 123256439527503L)
         + "h"
         + b<"Ì">(6361648037972076761L, 123256439527503L)
         + "e"
         + b<"Ì">(6362453586829092971L, 123256439527503L)
         + "r"
         + ChatFormatting.AQUA
         + "i"
         + b<"Ì">(6362353204890218055L, 123256439527503L)
         + "s"
         + b<"Ì">(6362265785392048250L, 123256439527503L)
         + "h";
      ChatFormatting var10000 = b<"Ì">(6361435592496877833L, 123256439527503L);
      ChatFormatting var10001 = b<"Ì">(6361592189834947798L, 123256439527503L);
      ChatFormatting var10003 = b<"Ì">(6361435592496877833L, 123256439527503L);
      ChatFormatting ax = ChatFormatting.RESET;
      ChatFormatting axx = var10003;
      ChatFormatting var12 = var10001;
      String prefix = var10000 + "[" + var12 + coloredClientName + axx + "]" + ax;
      Module[] var13 = b<"R">(6362027579691555609L, 123256439527503L);
      C(prefix + var2, 108932807550871L);
      if (var13 != null) {
         b<"R">(new Module[2], 6361781072196078381L, 123256439527503L);
      }
   }

   public static boolean H(long var0) {
      b<"R">(-3020422785151445690L, 82477884823056L);
      return Cherish.instance != null && HUD.instance != null && b<"õ">(HUD.instance, -3020325020462713146L, 82477884823056L).getValue().equals("Chinese");
   }

   public static void R(String a, long text) {
      text = 2420069701098L ^ text;
      long ax = text ^ 57560180792780L;
      b<"R">(8817574398076057869L, (long)text);
      if (HUD.instance != null && b<"õ">(HUD.instance, 8817836653248893418L, (long)text).getValue()) {
         C(a<"l">(21661, 6888450354922458962L ^ text) + a, ax);
      }
   }

   private static String HE_SHU_YOU() {
      return "何炜霖国企上班";
   }

   public static void throwableBug(String targetName, Throwable e) {
      F();

      try {
         File errorFile = new File(Cherish.getConfigManager().getMainFile(), String.valueOf(System.currentTimeMillis()));
         Files.writeString(errorFile.toPath(), e.getMessage() != null ? e.getMessage() : "NoErrorMessage!|" + targetName + "|" + e);
      } catch (Throwable var6) {
      }
   }
}
