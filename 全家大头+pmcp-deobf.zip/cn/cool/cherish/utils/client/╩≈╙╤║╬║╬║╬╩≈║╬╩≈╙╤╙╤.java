package cn.cool.cherish.utils.client;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 树友何何何树何树友友 implements 何树友 {
   private static final ScheduledExecutorService 何树友树树树何何何树;
   public static ExecutorService 何友何树友树友友何何;
   private static String 友何友何何树友友友友;
   private static final long a;
   private static final String b;
   private static final long[] c;
   private static final Long[] d;
   private static final Map e;
   private static final Object[] f = new Object[20];
   private static final String[] g = new String[20];
   private static String LIU_YA_FENG;

   private 树友何何何树何树友友(char a, int a, char a) {
      long var10000 = ((long)a << 48 | (long)a << 32 >>> 16 | (long)a << 48 >>> 48) ^ 3502302347975L;
      super();
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-5725122530819761566L, -8234682405813258039L, MethodHandles.lookup().lookupClass()).a(119018169900389L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (c() == null) {
         s("ciPQZb");
      }

      Cipher var11;
      Cipher var13 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(44366617090029L << var12 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var17 = a(
            var11.doFinal(
               "âN\u000b¶\"cè/¦¶µ{×ÜBª¾)¶\u001f(#\u0019!M\u0083ó\u0090\r\u0017\u001b\u0005æ\u0096aÖópÔýVr.¾Ç\u009c\u001bù\u0083ã@ÿ\u000b\u0085\u001fÙ"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      int var10001 = -1;
      b = var17;
      e = new HashMap(13);
      Cipher var0;
      Cipher var14 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(44366617090029L << var1 * 8 >>> 56);
      }

      var14.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[2];
      int var3 = 0;
      byte var2 = 0;

      do {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = "i\u0081\u0082¢¦ª\"o\u0017õÂÃ3Ì\u0096V".substring(var10001, var2).getBytes("ISO-8859-1");
         var10001 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         byte var20 = -1;
         var6[var10001] = var10004;
      } while (var2 < 16);

      c = var6;
      d = new Long[2];
      何树友树树树何何何树 = Executors.newScheduledThreadPool(5, new 树友何何何树何树友友$友树树友树树友树树树());
      何友何树友树友友何何 = Executors.newCachedThreadPool(new 树友何何何树何树友友$友友友何友友友友树何());
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/client/树友何何何树何树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   public static void s(String var0) {
      友何友何何树友友友友 = var0;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static String c() {
      return 友何友何何树友友友友;
   }

   public static int l(long var0) {
      var0 = 3502302347975L ^ var0;
      return ((ThreadPoolExecutor)b<"ï">(8655491300033526326L, var0)).getActiveCount();
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      f[0] = "zlGN3uu,\nE9hpq\u0001\u0003)npn\u001a\u0003?vpg\u0007Yr栋叒佗似佸桍住栈叉厢";
      f[1] = "+fto\n/5nn G5/dw|V?/s,K\\?\"rvaV\t$utgG?";
      f[2] = "5%K0@\r+-Q\u007f\r\u00171'H#\u001c\u001d10\u0013\u0002\r\u0010: H=\u000b\u001c\u001a<X2\u001b\f06n4\u001c\u000e6'X";
      f[3] = "r\u0004p\u000bp}y\u000baD\u0017\u007fl\u0000t\u0018+al\u0000b/&r}\u0015r\u00031\u007f";
      f[4] = ";Cf\u001f\u001394\u0003+\u0014\u0019$1^ R\t\"1A;R\u001f:1H&\bR\u00154D-\u0012\b\u0003,D$\u000f";
      f[5] = "wz\n\u0005H\u000fCY\u0005E\u0005\u0004ID\u0000\u0018\u000eBAY\r\u001e\n\t\u0002{\u0006\u000f\u0013\u0000I\r";
      f[6] = "e\u000e{=|/jN66v2o\u0013=p~/b\u00159;=\ri\u0004 2v";
      f[7] = "F\b\u001bCz\u0007r+\u0014\u00037\fx6\u0011^<Jp+\u001cX8\u00013\t\u0017I!\bx\u007f";
      f[8] = "N:\u0000ThOz\u0019\u000f\u0014%Dp\u0004\nI.\u0002x\u0019\u0007O*I;;\f^3@pM";
      f[9] = void.class;
      g[9] = "java/lang/Void";
      f[10] = "yq;>M<r~*q0$ay#8";
      f[11] = "T=+)#A_2:fBOT9><";
      f[12] = "1.|nRor8/\u000f伲叅佑桜厂栖厬叅佑优AsP:1~.0\u0002k";
      f[13] = "\u007f\n7&~dx\bm0@WC\\/!|\u007f9]9$:\u0005";
      f[14] = "&>2vq?e(a\u00177V$i`.|9}j~+Lh*,5-'&a45\u0017";
      f[15] = "?<y\u007f\u0003F|**\u001eW/8<<'\u0001S\u007f+~w>\u0015i/}!BR~m-\u001e";
      f[16] = "r\u001f\u0010\u0002\u001c+8\u000eWB#\u0005IN\u0012W\u001f.3O\u0004RYTwB\u0012\u0003\u0019?9\t\n\u0003#";
      f[17] = "$ol\b\u001c{gy?iJ\u0012&8>P\u0011}\u007f; U!";
      f[18] = "?\u001ck\n&4|\n8k但桄叁桮桏桲但伀佟桮VRf#}\u0019hQile";
      f[19] = "x\u0005\u0010}\u0012V2\u0014W=-gCT\u0012(\u0011S9U\u0004-W)";
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 236 && var8 != 'P' && var8 != 239 && var8 != 'c') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'b') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 232) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 236) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'P') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 6102;
      if (d[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])e.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/client/树友何何何树何树友友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         d[var3] = var15;
      }

      return d[var3];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static InterruptedException a(InterruptedException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/client/树友何何何树何树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 26;
               case 1 -> 63;
               case 2 -> 34;
               case 3 -> 29;
               case 4 -> 31;
               case 5 -> 18;
               case 6 -> 30;
               case 7 -> 32;
               case 8 -> 53;
               case 9 -> 59;
               case 10 -> 9;
               case 11 -> 11;
               case 12 -> 16;
               case 13 -> 39;
               case 14 -> 54;
               case 15 -> 19;
               case 16 -> 40;
               case 17 -> 23;
               case 18 -> 28;
               case 19 -> 58;
               case 20 -> 33;
               case 21 -> 2;
               case 22 -> 41;
               case 23 -> 48;
               case 24 -> 3;
               case 25 -> 57;
               case 26 -> 38;
               case 27 -> 49;
               case 28 -> 1;
               case 29 -> 13;
               case 30 -> 43;
               case 31 -> 51;
               case 32 -> 22;
               case 33 -> 36;
               case 34 -> 7;
               case 35 -> 46;
               case 36 -> 44;
               case 37 -> 14;
               case 38 -> 4;
               case 39 -> 27;
               case 40 -> 55;
               case 41 -> 45;
               case 42 -> 20;
               case 43 -> 25;
               case 44 -> 12;
               case 45 -> 0;
               case 46 -> 24;
               case 47 -> 21;
               case 48 -> 42;
               case 49 -> 6;
               case 50 -> 50;
               case 51 -> 8;
               case 52 -> 15;
               case 53 -> 47;
               case 54 -> 17;
               case 55 -> 61;
               case 56 -> 52;
               case 57 -> 60;
               case 58 -> 62;
               case 59 -> 35;
               case 60 -> 5;
               case 61 -> 10;
               case 62 -> 37;
               default -> 56;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   public static void y(long a) {
      a = 3502302347975L ^ a;
      b<"ï">(-4130073013574843257L, (long)a).shutdown();
      b<"è">(-4131780042970885238L, (long)a);
      b<"ï">(-4131885124683345444L, (long)a).shutdown();

      try {
         if (!b<"ï">(-4130073013574843257L, (long)a).awaitTermination(a<"t">(26905, 8724731170341075042L ^ a), TimeUnit.SECONDS)) {
            b<"ï">(-4130073013574843257L, (long)a).shutdownNow();
         }

         if (!b<"ï">(-4131885124683345444L, (long)a).awaitTermination(a<"t">(18933, 6632188440429041807L ^ a), TimeUnit.SECONDS)) {
            b<"ï">(-4131885124683345444L, (long)a).shutdownNow();
         }
      } catch (InterruptedException var5) {
         b<"ï">(-4130073013574843257L, (long)a).shutdownNow();
         b<"ï">(-4131885124683345444L, (long)a).shutdownNow();
         Thread.currentThread().interrupt();
      }

      Module[] var10000 = b<"è">(-4130004343826727271L, (long)a);
      if (a > 0L) {
         if (var10000 != null) {
            return;
         }

         var10000 = new Module[3];
      }

      b<"è">(var10000, -4132000813424419639L, (long)a);
   }

   public static ScheduledFuture A(Runnable a, long r, long delay, TimeUnit a) {
      delay = 3502302347975L ^ delay;
      return b<"ï">(-9082721865055791481L, delay).schedule(a, (long)r, a);
   }

   public static void R(Runnable a, long unit, long var3, TimeUnit initialDelay, long var6) {
      var6 = 3502302347975L ^ var6;
      b<"ï">(357362259114890113L, var6).scheduleAtFixedRate(a, (long)unit, var3, initialDelay);
   }

   private static String HE_SHU_YOU() {
      return "何大伟230622198107200054";
   }

   public static void G(Runnable a, long a) {
      何友何树友树友友何何.execute(a);
   }
}
