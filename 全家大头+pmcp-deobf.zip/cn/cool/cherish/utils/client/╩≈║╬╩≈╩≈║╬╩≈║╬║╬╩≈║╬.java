package cn.cool.cherish.utils.client;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 树何树树何树何何树何 implements 何树友 {
   private static final ScheduledExecutorService 何树何何树友树何友何;
   public static ExecutorService 何树树何树友友何树何;
   private static int[] 树何何友树友树何友友;
   private static final long a;
   private static final String b;
   private static final long[] c;
   private static final Long[] d;
   private static final Map e;
   private static final Object[] f = new Object[21];
   private static final String[] g = new String[21];
   private static String HE_WEI_LIN;

   private 树何树树何树何何树何(int a, short a, char a) {
      long var10000 = ((long)a << 32 | (long)a << 48 >>> 32 | (long)a << 48 >>> 48) ^ 树何树树何树何何树何.a;
      super();
      throw new UnsupportedOperationException(b);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-6931782120590127669L, -3112803821024372378L, MethodHandles.lookup().lookupClass()).a(215116672746172L);
      // $VF: monitorexit
      a = var10000;
      long var14 = a ^ 133141710082278L;
      a();
      if (b<"Þ">(-1977746019157555398L, var14) != null) {
         b<"Þ">(new int[3], -1977827369504695214L, var14);
      }

      Cipher var11;
      Cipher var16 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(var14 << var12 * 8 >>> 56);
      }

      var16.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var20 = a(
            var11.doFinal(
               "¦²½FF<\u0095\f^\u00ad\u009c©4¤ä½\u0087Eí #`\u0088\u009e\u0091vd\u0095xæ^\u0090\u009d«ô£Ë\u0094\u0098X\u0094\u00adE%ØêVÝ¿þ\u008fÛ\u000e¨\u008c\u0012"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      int var10001 = -1;
      b = var20;
      e = new HashMap(13);
      Cipher var0;
      Cipher var17 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)(var14 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var14 << var1 * 8 >>> 56);
      }

      var17.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[2];
      int var3 = 0;
      byte var2 = 0;

      do {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = "P\u0080\u0017\bñ\u0001\u000eÿ\u00ad¼§\u0081$\u0090°e".substring(var10001, var2).getBytes("ISO-8859-1");
         var10001 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         byte var23 = -1;
         var6[var10001] = var10004;
      } while (var2 < 16);

      c = var6;
      d = new Long[2];
      何树何何树友树何友何 = Executors.newScheduledThreadPool(5, new 树何树树何树何何树何$友何友友友树树友何何());
      b<"Q">(Executors.newCachedThreadPool(new 树何树树何树何何树何$树友树何何何树友何何()), -1977645067132173893L, var14);
   }

   public static ScheduledFuture C(Runnable a, long a, TimeUnit delay, long var4) {
      var4 = 树何树树何树何何树何.a ^ var4;
      return b<"ó">(-8333717211510183092L, var4).schedule(a, a, delay);
   }

   public static void F(Runnable a, long unit, long initialDelay, long delay, TimeUnit a) {
      delay = 树何树树何树何何树何.a ^ delay;
      b<"ó">(6456054444244713100L, delay).scheduleAtFixedRate(a, (long)unit, initialDelay, a);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/client/树何树树何树何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void a() {
      f[0] = "-s\u0006EkA\"3KNa\\'n@\bqZ'q[\bgB'xFR*栿伛栌根佳栕佻伛栌佽";
      f[1] = "h\u000f";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = ",7";
      f[4] = "y Sz(eg(I5e\u007f}\"Pitu}5\u000b^~up4QttCv3Sreu";
      f[5] = "p-G#(\u001bn%]le\u0001t/D0t\u000bt8\u001f\u0011e\u0006\u007f(D.c\n_4T!s\u001au>b't\u0018s/T";
      f[6] = ",/3y\u0004\u0006#o~r\u000e\u001b&2u4\u0006\u0006+4q\u007fE$ %hv\u000e";
      f[7] = boolean.class;
      g[7] = "java/lang/Boolean";
      f[8] = "=?V*jL2\u007f\u001b!`Q7\"\u0010gpW7=\u000bgfO74\u0016=+`28\u001d'qv*8\u0014:";
      f[9] = "F|";
      f[10] = "*\u0001\u000e\u000e!\u0001!\u000e\u001fAF\u00034\u0005\n\u001dz\u001d4\u0005\u001c*w\u000e%\u0010\f\u0006`\u0003";
      f[11] = "AC";
      f[12] = "\"\u001a\u0016yvj)\u0015\u00076\u0017d\"\u001e\u0003l";
      f[13] = "`5[_.D1!\u00154\f#`tDIxOixD\tH\u001a*'OW1I-xY4";
      f[14] = ")\u0012Lka\u0013x\u0006\u0002\u0000Bt)SS}7\u0018 _S=\u0007";
      f[15] = "\t\u000fiLBxX\u001b''佹栆栠伣栎古叧佂栠伣\u0017\u001c\u001a{W\u001a|BOxE";
      f[16] = "s~4F\n7~8(]t(N7vF\tg\">zFIW";
      f[17] = "On\u0019kU2C,\u001fam\u001bscG\u007f\u0017h\u0018&\b`UX";
      f[18] = "u\u001c_\r\u0000\fxZC\u0016~\u000fHU\u001d\r\u0003\\$\\\u0011\rClq\u001fN\u0006\u001d\u0015\"\u0018\u0011\u0010~";
      f[19] = "(\u0003T;U\u0012y\u0017\u001aP佮桬佅伯栳厓株伨叛伯*kK\u0011zBV-Y\u0015`";
      f[20] = "q|T:R~ h\u001aQ]\u0019~m\u0012aY *rXn4&!5\u001a<\rr>\u007f\u0015Q";
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'z' && var8 != '$' && var8 != 243 && var8 != 'Q') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 249) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 222) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'z') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 243) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static InterruptedException a(InterruptedException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20469;
      if (d[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])e.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/client/树何树树何树何何树何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         d[var3] = var15;
      }

      return d[var3];
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 1;
               case 1 -> 61;
               case 2 -> 58;
               case 3 -> 31;
               case 4 -> 4;
               case 5 -> 18;
               case 6 -> 11;
               case 7 -> 26;
               case 8 -> 60;
               case 9 -> 45;
               case 10 -> 33;
               case 11 -> 34;
               case 12 -> 29;
               case 13 -> 59;
               case 14 -> 22;
               case 15 -> 16;
               case 16 -> 49;
               case 17 -> 40;
               case 18 -> 17;
               case 19 -> 23;
               case 20 -> 41;
               case 21 -> 63;
               case 22 -> 48;
               case 23 -> 57;
               case 24 -> 12;
               case 25 -> 50;
               case 26 -> 5;
               case 27 -> 35;
               case 28 -> 21;
               case 29 -> 52;
               case 30 -> 46;
               case 31 -> 20;
               case 32 -> 53;
               case 33 -> 24;
               case 34 -> 51;
               case 35 -> 44;
               case 36 -> 38;
               case 37 -> 54;
               case 38 -> 47;
               case 39 -> 3;
               case 40 -> 62;
               case 41 -> 39;
               case 42 -> 36;
               case 43 -> 28;
               case 44 -> 6;
               case 45 -> 55;
               case 46 -> 56;
               case 47 -> 2;
               case 48 -> 43;
               case 49 -> 27;
               case 50 -> 9;
               case 51 -> 14;
               case 52 -> 10;
               case 53 -> 15;
               case 54 -> 25;
               case 55 -> 7;
               case 56 -> 42;
               case 57 -> 30;
               case 58 -> 37;
               case 59 -> 8;
               case 60 -> 32;
               case 61 -> 13;
               case 62 -> 0;
               default -> 19;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/client/树何树树何树何何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   public static void r(long a) {
      a = 树何树树何树何何树何.a ^ a;
      b<"Þ">(-5909516492359076128L, (long)a);
      b<"ó">(-5910199962155169588L, (long)a).shutdown();
      b<"ó">(-5909326260831565079L, (long)a).shutdown();

      try {
         if (!b<"ó">(-5910199962155169588L, (long)a).awaitTermination(a<"c">(16359, 7633330020593196523L ^ a), TimeUnit.SECONDS)) {
            b<"ó">(-5910199962155169588L, (long)a).shutdownNow();
         }

         if (!b<"ó">(-5909326260831565079L, (long)a).awaitTermination(a<"c">(19555, 8775582573593734766L ^ a), TimeUnit.SECONDS)) {
            b<"ó">(-5909326260831565079L, (long)a).shutdownNow();
         }
      } catch (InterruptedException var5) {
         b<"ó">(-5910199962155169588L, (long)a).shutdownNow();
         b<"ó">(-5909326260831565079L, (long)a).shutdownNow();
         Thread.currentThread().interrupt();
      }

      byte var10000 = b<"Þ">(-5909453424569997576L, (long)a);
      if (a >= 0L) {
         if (var10000 == 0) {
            return;
         }

         var10000 = 1;
      }

      b<"Þ">(new int[var10000], -5909399885660286561L, (long)a);
   }

   public static int X(long var0) {
      var0 = a ^ var0;
      return ((ThreadPoolExecutor)b<"ó">(6377907324947479988L, var0)).getActiveCount();
   }

   public static void L(int[] var0) {
      树何何友树友树何友友 = var0;
   }

   public static int[] M() {
      return 树何何友树友树何友友;
   }

   public static void N(int a, Runnable a, int a, int runnable) {
      long ax = ((long)a << 48 | (long)a << 48 >>> 16 | (long)runnable << 32 >>> 32) ^ 树何树树何树何何树何.a;
      b<"ó">(-1622765484861453236L, ax).execute(a);
   }

   private static String HE_WEI_LIN() {
      return "刘凤楠230622109211173513";
   }
}
