package cn.cool.cherish.utils.misc;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 树友何树友树友友友何 implements 何树友 {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[12];
   private static final String[] f = new String[12];
   private static String HE_DA_WEI;

   private 树友何树友树友友友何(long a) {
      a = 树友何树友树友友友何.a ^ a;
      super();
      throw new UnsupportedOperationException(a<"i">(16544, 2280146236314936581L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(3443988820859694976L, 5954291854040802189L, MethodHandles.lookup().lookupClass()).a(74734526755910L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 111364382536008L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = ' ';
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "¾ì\u009eÅÇSJ-º®?êW/ôVT¤ÂEd\u0097aµÇ³sÅ\u001b<7qX¢:\u0082\u0087D\u009e=CZ[\u009còl\u0094\u0003[\u0015Îu\\\u009e\u0004|ÈAWçM\u0093¥\u0012\u009aù3ãþ\u001f uôIª\u001dâ\u009cþ¸*5[gU\u009cJ¿V\u0088\u008b\u0013¯JU\u0011 Æ\u0085¹0á\u009f²\u0012\u0011Osºìp\u0086Nk\u0098Zò\u0011nDÅ"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 121) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "¾ì\u009eÅÇSJ-º®?êW/ôVT¤ÂEd\u0097aµÇ³sÅ\u001b<7qX¢:\u0082\u0087D\u009e=CZ[\u009còl\u0094\u0003[\u0015Îu\\\u009e\u0004|ÈAWçM\u0093¥\u0012\u009aù3ãþ\u001f uôIª\u001dâ\u009cþ¸*5[gU\u009cJ¿V\u0088\u008b\u0013¯JU\u0011 Æ\u0085¹0á\u009f²\u0012\u0011Osºìp\u0086Nk\u0098Zò\u0011nDÅ"
            .charAt(var4);
      }
   }

   public static String B(String a, long a, String text) {
      a = 树友何树友树友友友何.a ^ a;
      b<"l">(292159576501757235L, a);
      if (a != null && !a.isEmpty() && text != null && !text.isEmpty()) {
         int index = a.indexOf(text);
         return (String)(index == -1 ? a : a.substring(0, index));
      } else {
         return a;
      }
   }

   public static String C(long a) {
      a = 树友何树友树友友友何.a ^ a;
      b<"l">(5864530678235742839L, (long)a);
      SimpleDateFormat dateFormat = new SimpleDateFormat(a<"i">(32071, 6257965225891448228L ^ a));
      String var10000 = dateFormat.format(new Date());
      b<"l">(!b<"l">(5864094736414165427L, (long)a), 5864136945964078452L, (long)a);
      return var10000;
   }

   public static String D(String a, long startIndex, int text, int a) {
      startIndex = (int)(树友何树友树友友友何.a ^ startIndex);
      byte var6 = b<"l">(7213229369119897359L, (long)startIndex);
      if (a != null && !a.isEmpty()) {
         int var10000 = (int)text;
         int var10001 = var6;
         if (startIndex >= 0L) {
            if (var6 == 0) {
               if (text < 0) {
                  return "";
               }

               var10000 = (int)a;
            }

            var10001 = (int)text;
         }

         if (var10000 > var10001 && text < a.length()) {
            return a.substring((int)text, Math.min((int)a, a.length()));
         }
      }

      return "";
   }

   public static String V(String a, long a, int count) {
      a = 树友何树友树友友友何.a ^ a;
      b<"l">(-8727260516989261860L, a);
      if (a != null) {
         if (a < 0L) {
            return a;
         }

         if (!a.isEmpty()) {
         }
      }

      return "";
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/misc/树友何树友树友友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static String l(String a, long a, String text) {
      a = 树友何树友树友友友何.a ^ a;
      b<"l">(2967498773744420880L, a);
      if (a != null && !a.isEmpty() && text != null && !text.isEmpty()) {
         int index = a.lastIndexOf(text);
         return (String)(index == -1 ? a : a.substring(index + text.length()));
      } else {
         return a;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      e[0] = "\"\t)\u00157A-Id\u001e=\\(\u0014oX-Z(\u000btX5G2\u0004)桧厓佻桐厬栖厽厓句伔";
      e[1] = "'\u0004|wq\r,\u000bm8\u0016\u000f)\u0000rY*\u0015\u0002\u0003Hy*\u000f)\u0016On<\u0004=\u0011cy1";
      e[2] = "=au22a2!898|7|3\u007f(z7c(\u007f0g-lu桀厖佛伋佚桊伄伈叅桏";
      e[3] = boolean.class;
      f[3] = "java/lang/Boolean";
      e[4] = "A\u0014\u0000\u001b6[NTM\u0010<FK\tFV4[F\u000fB\u001dwyM\u001e[\u0014<";
      e[5] = void.class;
      f[5] = "java/lang/Void";
      e[6] = "\u001b6wB5`\u00109f\rTn\u001b2bW";
      e[7] = "/\u001cBmBiq\rP\u007f-^\u0016GOuS%f\u0004JhP\u001b";
      e[8] = "lRe^#mt_6,q\u00114\u0002 Ucv2F;Q\u0018(7E$W\u007f.s^ ,";
      e[9] = "k0\u0012a\u000ft-mQhrRP;\u000e\u007f\f/ x\u000bb\u000f\u0011";
      e[10] = "+d\tH+\u0000m9JAV,\u0010o\u0015V([`,\u0010K+e,oO\u001c'\u001dil\u0010UV";
      e[11] = "l2Hovq2#Z}\u0019aUiEwg=%*@jd\u0003";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'R' && var8 != 244 && var8 != 239 && var8 != 'g') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'd') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'l') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'R') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static IndexOutOfBoundsException a(IndexOutOfBoundsException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27008;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/misc/树友何树友树友友友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 51;
               case 1 -> 0;
               case 2 -> 56;
               case 3 -> 4;
               case 4 -> 57;
               case 5 -> 3;
               case 6 -> 53;
               case 7 -> 10;
               case 8 -> 25;
               case 9 -> 21;
               case 10 -> 7;
               case 11 -> 30;
               case 12 -> 32;
               case 13 -> 20;
               case 14 -> 28;
               case 15 -> 29;
               case 16 -> 61;
               case 17 -> 27;
               case 18 -> 24;
               case 19 -> 15;
               case 20 -> 59;
               case 21 -> 55;
               case 22 -> 58;
               case 23 -> 5;
               case 24 -> 41;
               case 25 -> 60;
               case 26 -> 52;
               case 27 -> 62;
               case 28 -> 17;
               case 29 -> 22;
               case 30 -> 26;
               case 31 -> 9;
               case 32 -> 6;
               case 33 -> 44;
               case 34 -> 11;
               case 35 -> 37;
               case 36 -> 13;
               case 37 -> 14;
               case 38 -> 34;
               case 39 -> 23;
               case 40 -> 18;
               case 41 -> 12;
               case 42 -> 2;
               case 43 -> 40;
               case 44 -> 43;
               case 45 -> 63;
               case 46 -> 19;
               case 47 -> 42;
               case 48 -> 38;
               case 49 -> 16;
               case 50 -> 47;
               case 51 -> 48;
               case 52 -> 35;
               case 53 -> 8;
               case 54 -> 1;
               case 55 -> 31;
               case 56 -> 46;
               case 57 -> 36;
               case 58 -> 39;
               case 59 -> 54;
               case 60 -> 33;
               case 61 -> 45;
               case 62 -> 50;
               default -> 49;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/misc/树友何树友树友友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   // $VF: Handled exception range with multiple entry points by splitting it
   // $VF: Duplicated exception handlers to handle obfuscated exceptions
   public static String o(String a, String groupIndex, long text, int a) {
      text = 树友何树友树友友友何.a ^ text;
      int ax = b<"l">(8149233847701103106L, (long)text);
      if (a != null) {
         if (text < 0L) {
            return a;
         }

         if (!a.isEmpty()) {
            if (text < 0L) {
               return groupIndex;
            }

            if (groupIndex != null && !groupIndex.isEmpty()) {
               Pattern pattern = Pattern.compile(groupIndex);
               Matcher matcher = pattern.matcher(a);
               Matcher var14 = matcher;
               int var10001 = ax;
               if (text > 0L) {
                  if (ax == 0) {
                     if (!matcher.find()) {
                        return "";
                     }

                     try {
                        var14 = matcher;
                     } catch (IndexOutOfBoundsException var12) {
                        return "";
                     }
                  }

                  try {
                     var10001 = (int)a;
                  } catch (IndexOutOfBoundsException var11) {
                     return "";
                  }
               }

               try {
                  return var14.group(var10001);
               } catch (IndexOutOfBoundsException var10) {
                  return "";
               }
            }
         }
      }

      return "";
   }

   public static String p(String a, String endDelimiter, long a, String startDelimiter) {
      a = 树友何树友树友友友何.a ^ a;
      b<"l">(-6760472649169960173L, a);
      if (a != null && !a.isEmpty() && endDelimiter != null && "。" != null) {
         int startIndex = a.indexOf(endDelimiter);
         int var10000 = startIndex;
         if (a >= 0L) {
            if (startIndex == -1) {
               return "";
            }

            startIndex += endDelimiter.length();
            var10000 = a.indexOf(startDelimiter, startIndex);
         }

         int endIndex = var10000;
         return endIndex == -1 ? "" : a.substring(startIndex, endIndex);
      } else {
         return "";
      }
   }

   public static String P(String a, int text, long a) {
      a = 树友何树友树友友友何.a ^ a;
      b<"l">(-7549179786926455762L, a);
      if (a != null && !a.isEmpty() && text > 0) {
         int startIndex = Math.max(0, a.length() - text);
         return a.substring(startIndex);
      } else {
         return "";
      }
   }

   public static String T(long a, String var2, int text) {
      a = 树友何树友树友友友何.a ^ a;
      b<"l">(3034185448942635813L, (long)a);
      if (var2 != null && !var2.isEmpty() && text > 0) {
         int startIndex = Math.max(0, (var2.length() - text) / 2);
         int endIndex = Math.min(var2.length(), startIndex + text);
         return var2.substring(startIndex, endIndex);
      } else {
         return "";
      }
   }

   private static String HE_SHU_YOU() {
      return "解放村多种2队1144号";
   }
}
