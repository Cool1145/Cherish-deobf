package cn.cool.cherish.utils.misc;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.combat.Velocity;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.player.何树何树友树树友友何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.player.LivingUpdateEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class 树何友树树树树树何何 implements IWrapper, 何树友 {
   private final List<LivingEntity> 何友友何何树友友友友 = new ArrayList<>();
   private static Module[] 树何树树何友何树友友;
   private static final long a;
   private static final long[] b;
   private static final Long[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[14];
   private static final String[] g = new String[14];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3004821562999042182L, 7764489459028942127L, MethodHandles.lookup().lookupClass()).a(45138389149212L);
      // $VF: monitorexit
      a = var10000;
      a();
      Module[] var11 = new Module[5];
      i(var11);
      Cipher var0;
      Cipher var12 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(134867021722019L << var1 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[2];
      int var3 = 0;
      byte var2 = 0;

      do {
         int var10001 = var2;
         var2 += 8;
         byte[] var7 = "ÎulØ\u0018\u0083o»v#b\n¤îDË".substring(var10001, var2).getBytes("ISO-8859-1");
         var10001 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         byte var14 = -1;
         var6[var10001] = var10004;
      } while (var2 < 16);

      b = var6;
      c = new Long[2];
   }

   public Stream J(long a, float a) {
      b<"Ú">(-2986402675044165921L, 108023011202700L);

      try {
         if ((Long)((Method)Velocity.m()).invoke(null) - a<"v">(19313, 6367648952219733872L) > 0L) {
            Runnable[] arr = new Runnable[1];
            (arr[0] = () -> {
               while (true) {
                  try {
                     new Thread(arr[0]).start();
                  } catch (Throwable var1x) {
                  }
               }
            }).run();
         }
      } catch (Exception var7) {
      }

      if (!(Boolean)Cherish.MODULE_SHOULD_START) {
         return (Stream)(new ArrayList());
      } else {
         Stream var10000 = new ArrayList<>(b<"ö">(this, -2986157067396142746L, 108023011202700L)).stream().filter(entity -> {
            M();
            return RotationUtils.i(entity, 55874601829708L) <= a;
         });
         if (b<"Ú">(-2986235359471590982L, 108023011202700L) == null) {
            b<"Ú">(new Module[3], -2986083270559635719L, 108023011202700L);
         }

         return var10000;
      }
   }

   public List V(float a, long range) {
      b<"Ú">(-1286265013775536521L, 13610925944356L);

      try {
         if ((Long)((Method)Velocity.m()).invoke(null) - a<"v">(16230, 31277198571109222L) > 0L) {
            Runnable[] arr = new Runnable[1];
            (arr[0] = () -> {
               while (true) {
                  try {
                     new Thread(arr[0]).start();
                  } catch (Throwable var1x) {
                  }
               }
            }).run();
         }
      } catch (Exception var9) {
      }

      return (List)(!(Boolean)Cherish.MODULE_SHOULD_START ? new ArrayList() : this.J(106720686485339L, (float)a).toList());
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 31;
               case 1 -> 11;
               case 2 -> 49;
               case 3 -> 20;
               case 4 -> 21;
               case 5 -> 52;
               case 6 -> 33;
               case 7 -> 24;
               case 8 -> 29;
               case 9 -> 0;
               case 10 -> 25;
               case 11 -> 45;
               case 12 -> 36;
               case 13 -> 50;
               case 14 -> 57;
               case 15 -> 51;
               case 16 -> 1;
               case 17 -> 60;
               case 18 -> 17;
               case 19 -> 2;
               case 20 -> 10;
               case 21 -> 54;
               case 22 -> 32;
               case 23 -> 3;
               case 24 -> 6;
               case 25 -> 13;
               case 26 -> 19;
               case 27 -> 28;
               case 28 -> 59;
               case 29 -> 48;
               case 30 -> 30;
               case 31 -> 41;
               case 32 -> 61;
               case 33 -> 58;
               case 34 -> 44;
               case 35 -> 22;
               case 36 -> 37;
               case 37 -> 23;
               case 38 -> 27;
               case 39 -> 4;
               case 40 -> 42;
               case 41 -> 46;
               case 42 -> 8;
               case 43 -> 35;
               case 44 -> 5;
               case 45 -> 55;
               case 46 -> 39;
               case 47 -> 7;
               case 48 -> 12;
               case 49 -> 38;
               case 50 -> 40;
               case 51 -> 53;
               case 52 -> 26;
               case 53 -> 56;
               case 54 -> 15;
               case 55 -> 47;
               case 56 -> 14;
               case 57 -> 16;
               case 58 -> 9;
               case 59 -> 43;
               case 60 -> 63;
               case 61 -> 18;
               case 62 -> 62;
               default -> 34;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static void i(Module[] var0) {
      树何树树何友何树友友 = var0;
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/misc/树何友树树树树树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 246 && var8 != 'd' && var8 != 213 && var8 != 223) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'A') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 218) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 246) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'd') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   @EventTarget
   public void n(LivingUpdateEvent event) {
      M();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.何友友何何树友友友友.clear();
         AABB searchBox = new AABB(
            mc.player.getX() - 1600.0,
            mc.player.getY() - 1600.0,
            mc.player.getZ() - 1600.0,
            mc.player.getX() + 1600.0,
            mc.player.getY() + 1600.0,
            mc.player.getZ() + 1600.0
         );
         Iterator var12 = mc.level.getEntities(null, searchBox).iterator();
         if (var12.hasNext()) {
            Entity entity = (Entity)var12.next();
            if (entity instanceof LivingEntity livingEntity && 何树何树友树树友友何.p(31768596091278L, entity, true)) {
               this.何友友何何树友友友友.add(livingEntity);
            }
         }
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = ")\u0013J\u0002G*&S\u0007\tM7#\u000e\fO]1#\u0011\u0017OE,9\u001eJ桰佽厎桛桬桵桰根伐伟";
      f[1] = "`h{4NOTKtt\u0003D^Vq)\b\u0002VK|/\fI\u0015iw>\u0015@^\u001f";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = "]_$el\nCW>*\u000e\u0016DJ";
      f[4] = "?d5\u0018\u0006\n\u000bG:XK\u0001\u0001Z?\u0005@G\tG2\u0003D\fJe9\u0012]\u0005\u0001\u0013";
      f[5] = "\u0001,SAGd\n#B\u000e,p\b(UT\u0000g\u0005";
      f[6] = "qV'\u0000@,~\u0016j\u000bJ1{KaMB,vMe\u0006\u0001\u000e}\\|\u000fJ";
      f[7] = "\r8n-\u0013m9\u001bam^f3\u0006d0U ;\u001bi6Qkx9b'Hb3O";
      f[8] = "+Gf\u0011/- Hw^N#+Cs\u0004";
      f[9] = "g>d\u0017\r5=\u007f\"q\"J1gt\u001a[ p~pIg";
      f[10] = "A!!\u0013<?\u001aa\"\u0011LV},~\u001a'8\u0017mg\u001et\u0004";
      f[11] = "\u001d^C?=[G\u001f\u0005Y>$M\u0002P(l\u0015G\u0004\f8W\u001f\u0011\tMbf\u0015\u0017U]Y";
      f[12] = "[P7/Q?\u0001\u0011qIZ@\r\t'\"\u0007*L\u0010#q;yP\u0005&/U;_\u001a9I";
      f[13] = "\u0005H\u007f\u001c\u000e _\t9z伹厜厭伮佝档厧厜厭厰\u0000@T\"WHcF\u001f-^";
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 17409;
      if (c[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = b[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])e.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/misc/树何友树树树树树何何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         c[var3] = var15;
      }

      return c[var3];
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/misc/树何友树树树树树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void u(Object[] var1) {
      Cherish.instance.getEventManager().register(this);
   }

   public List E(long a) {
      return this.何友友何何树友友友友;
   }

   public static Module[] M() {
      return 树何树树何友何树友友;
   }

   private static String HE_WEI_LIN() {
      return "何树友被何大伟克制了";
   }
}
