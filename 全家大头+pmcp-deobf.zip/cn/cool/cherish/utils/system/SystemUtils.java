package cn.cool.cherish.utils.system;

import cn.cool.cherish.module.何树何何树何友何何何;
import furry.obf.ClassObfuscator;
import heilongjiang.zhaoyuan.何树友;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

@ClassObfuscator
public final class SystemUtils implements 何树友 {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static String HE_WEI_LIN;

   private SystemUtils(long a) {
      a = 77170672944677L ^ a;
      super();
      throw new UnsupportedOperationException(a<"r">(29958, 8686241783595829038L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(4833860586244899534L, -4166733004622851849L, MethodHandles.lookup().lookupClass()).a(32528385758279L);
      // $VF: monitorexit
      a = var10000;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(60567312744088L << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[3];
      int var7 = 0;
      char var5 = 'X';
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "y©oL\u0097ùÃr\u0091ß»ß+Y§{h\u008f5\u009b\r31?¡ì\u0092è×í\r¡Ð\u0094\u000e\u0018Y\u0010i¸ ¦\u008fö$¢òºU¸e\u009dZ¹§wD\u009fß§aá\u009dJû\u009bMÛür\u0004a\u000e\"HåI`ø\u009e¤ÕÃ7\u00ad8V\u008c0\u0017\u0096g\u001fÅ£\u0002¶Ã\u009e¼}aëGË\u0090IóùWÖ\u008c\u001e$1\u001e\u0082 Û¦Öí\u0098Ñz\féÇ~\u0087Â§?\u009f\u0017\u0089\u009b ?[Å;¦C\t\u001b\u0002>ZÔ^ÙÊ\u0001ÉL\u0082ßh*Ky» %\u008e1@w\u0002"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 170) {
            b = var9;
            c = new String[3];
            return;
         }

         var5 = "y©oL\u0097ùÃr\u0091ß»ß+Y§{h\u008f5\u009b\r31?¡ì\u0092è×í\r¡Ð\u0094\u000e\u0018Y\u0010i¸ ¦\u008fö$¢òºU¸e\u009dZ¹§wD\u009fß§aá\u009dJû\u009bMÛür\u0004a\u000e\"HåI`ø\u009e¤ÕÃ7\u00ad8V\u008c0\u0017\u0096g\u001fÅ£\u0002¶Ã\u009e¼}aëGË\u0090IóùWÖ\u008c\u001e$1\u001e\u0082 Û¦Öí\u0098Ñz\féÇ~\u0087Â§?\u009f\u0017\u0089\u009b ?[Å;¦C\t\u001b\u0002>ZÔ^ÙÊ\u0001ÉL\u0082ßh*Ky» %\u008e1@w\u0002"
            .charAt(var4);
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/system/SystemUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24451;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/system/SystemUtils", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String LIU_YA_FENG() {
      return "何树友，和树做朋友";
   }

   public static boolean isServiceExist(String serviceName) {
      try {
         Process process = Runtime.getRuntime().exec("tasklist /SVC");
         BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

         String line;
         while ((line = reader.readLine()) != null) {
            if (line.contains(serviceName)) {
               return true;
            }
         }
      } catch (IOException var6) {
         null.println("Error executing command.");
      }

      return false;
   }
}
