package cn.cool.cherish.utils.system;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 树友树树何树何树何树 implements 何树友 {
   private static TrayIcon 何何树树树树树何树何;
   private static boolean 何树树友友何何友何友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[20];
   private static final String[] f = new String[20];
   private static String HE_WEI_LIN;

   private 树友树树何树何树何树(long a) {
      a = 2379766056947L ^ a;
      super();
      throw new UnsupportedOperationException(a<"h">(13972, 7592817020807802722L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8792085840003780971L, 4516278745087912215L, MethodHandles.lookup().lookupClass()).a(103127370178985L);
      // $VF: monitorexit
      a = var10000;
      a();
      T(true);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(98274625099770L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[10];
      int var5 = 0;
      String var4 = "bÅ±[¡ß¾Bå\rtb-Mp\u009bU\u0017½ÔM\u0014Í¤T\u0098ûù\u0099v\u0092%\u0018\u008a=^ñ\u001br1Y^.Ñ\u000fZ9ôÚ,ª\u0019äªæó}X\u001d\u0081ÊA\u001a\u008f&ä\u009cç>\u0093\u0089ùWcÐ \u008b\u000byçÂ:\u009aÐÇ³\u0010\u0001EÇíw8\u009e/¦\u0088>\u0004¨\u0099Ög\u0093¦\u0012\u0085±Õ\u009c\u0089G\"¤¶×\u0093þ°\tß+kÏdÈ/\u0019)xó{;4\u000b\u0095\b}U¼\u000b\u008e\u0098µ[N0rÜè%%\u001e\u0092ó£\u0087&`Þ\u001fó\u001eñ\u0000z\u0087t³?~¿Ý\"\u008bS~¨\u0088ë|\u0094´\u001fÚx\u0091ýknZú\u009bÖr\u0010úÊ\u0014¬\b»§d\u00117ÂÚØ\u0003N\u001c Î´sSjvd£äg\u008f.\u0097=pù×~\u009dÚ\u0005Ëá\u008dàN\u0080\u0081~4\fú\u0010·7d<Â¿ôã®\u0092mTéx\u009a\u0092\u0010ûw0Ê7W7]\u0086:ÆpQÉáñ";
      short var6 = 279;
      char var3 = ' ';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = a(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[10];
                     何何树树树树树何树何 = null;
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "bw1\u0093,\u00121ÆL|1x\u0081ìDr\u0010\u008fÙÍò!À\u008d-\u000f®^ìM\u0005\u0017í";
                  var6 = 33;
                  var3 = 16;
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public static void D(int a, int text, String a, int a) {
      long ax;
      ax = ((long)a << 48 | (long)text << 32 >>> 16 | (long)a << 48 >>> 48) ^ 2379766056947L;
      long axx = ax ^ 128460202060253L;
      int axxx = b<"è">(4908185916813516984L, ax);
      label19:
      if (SystemTray.isSupported()) {
         TrayIcon icon = P(axx);
         TrayIcon var10000 = icon;
         if (axxx) {
            if (icon == null) {
               break label19;
            }

            var10000 = icon;
         }

         var10000.displayMessage(a<"h">(2416, 8494169281405605227L ^ ax), a, b<"ô">(4908050994005133181L, ax));
      }

      null.println(a<"h">(3573, 1648467265601032680L ^ ax) + a);
      if (b<"è">(4908114441376274378L, ax) == null) {
         b<"è">(false, 4907474263851440259L, ax);
      }
   }

   public static void e(long var0) {
      var0 = 2379766056947L ^ var0;
      if (b<"ô">(8809019104453375169L, var0) != null && SystemTray.isSupported()) {
         SystemTray.getSystemTray().remove(b<"ô">(8809019104453375169L, var0));
         b<"º">(null, 8809019104453375169L, var0);
      }
   }

   public static void i(long a, String a) {
      a = 2379766056947L ^ a;
      long ax = a ^ 127325392162172L;
      int axx = b<"è">(2359251654456395453L, (long)a);
      if (SystemTray.isSupported()) {
         label28: {
            TrayIcon icon = P(ax);
            TrayIcon var10000 = icon;
            short var10001 = axx;
            if (a >= 0L) {
               if (axx == 0) {
                  if (icon == null) {
                     break label28;
                  }

                  var10000 = icon;
               }

               var10001 = 2416;
            }

            var10000.displayMessage(a<"h">(var10001, 8494174744739066314L ^ a), a, b<"ô">(2358575293213440757L, (long)a));
         }

         byte var9 = axx;
         if (a > 0L) {
            if (axx == 0) {
               return;
            }

            var9 = 4;
         }

         b<"è">(new Module[var9], 2358487260039154357L, (long)a);
      }

      null.println(a<"h">(3685, 7328791062921721564L ^ a) + a);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/system/树友树树何树何树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void d(long a, String var2) {
      long var10001 = 2379766056947L ^ a ^ 44898608596671L;
      int ax = (int)((2379766056947L ^ a ^ 44898608596671L) >>> 48);
      int axx = (int)((2379766056947L ^ a ^ 44898608596671L) << 16 >>> 32);
      int var6 = (int)(var10001 << 48 >>> 48);
      D((short)ax, axx, var2, (char)var6);
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 35;
               case 1 -> 63;
               case 2 -> 17;
               case 3 -> 22;
               case 4 -> 38;
               case 5 -> 26;
               case 6 -> 41;
               case 7 -> 29;
               case 8 -> 27;
               case 9 -> 1;
               case 10 -> 52;
               case 11 -> 40;
               case 12 -> 32;
               case 13 -> 56;
               case 14 -> 42;
               case 15 -> 43;
               case 16 -> 48;
               case 17 -> 9;
               case 18 -> 16;
               case 19 -> 20;
               case 20 -> 34;
               case 21 -> 50;
               case 22 -> 37;
               case 23 -> 8;
               case 24 -> 57;
               case 25 -> 31;
               case 26 -> 45;
               case 27 -> 28;
               case 28 -> 2;
               case 29 -> 19;
               case 30 -> 14;
               case 31 -> 53;
               case 32 -> 0;
               case 33 -> 18;
               case 34 -> 23;
               case 35 -> 36;
               case 36 -> 49;
               case 37 -> 33;
               case 38 -> 13;
               case 39 -> 21;
               case 40 -> 10;
               case 41 -> 7;
               case 42 -> 4;
               case 43 -> 30;
               case 44 -> 6;
               case 45 -> 55;
               case 46 -> 54;
               case 47 -> 58;
               case 48 -> 5;
               case 49 -> 62;
               case 50 -> 60;
               case 51 -> 47;
               case 52 -> 12;
               case 53 -> 59;
               case 54 -> 15;
               case 55 -> 25;
               case 56 -> 24;
               case 57 -> 3;
               case 58 -> 51;
               case 59 -> 11;
               case 60 -> 61;
               case 61 -> 39;
               case 62 -> 46;
               default -> 44;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      e[0] = "0rL|?\u001b?2\u0001w5\u0006:o\n1%\u0000:p\u00111#\r h\u0007r~桥厘栍桳佊桁伡桂佉桳";
      e[1] = "\\%X0F(A0\u0000\u0005\u001a(O\rM>\u0006";
      e[2] = "~\u0019Dc\u0000Vu\u0016U,kBw\u001dBvGUz";
      e[3] = boolean.class;
      f[3] = "java/lang/Boolean";
      e[4] = void.class;
      f[4] = "java/lang/Void";
      e[5] = "Av\u0012!FK\\cJ\u0014\u001aKR^\u0007/\u0006\u000efr\u00173\tMNC\u001d0\r";
      e[6] = "}g\u000b_p\u0017r'FTz\nwzM\u0012r\u0017z|IY15qmPPz";
      e[7] = "\u0018]n_\u0006*,~a\u001fK!&cdB@g.~iDD,m\\bU]%&*";
      e[8] = "5O:<M0\u0001l5|\u0000;\u000bq0!\u000b}\u0003l='\u000f6@N66\u0016?\u000b8";
      e[9] = "0!TKcn;.E\u0004\u0002`0%A^";
      e[10] = "/\\F1e=,V\u001aC}D)\n\f>%(lG\u001a{\u001e";
      e[11] = "+WAE3\r}RT\u0015\u000b)Q$o\u007f7U~P\u0010\u001aaPk\u0000";
      e[12] = "et\u0012\u0004y\u000f6%LY\u0004cY'\r\u0000g]7+LZc1";
      e[13] = "'-\u0002\u0004c\u001c$'^vXe!{H\u000b#\td6^N\u0018";
      e[14] = "v\u0011C\u0004jS \u0014VTRi\u0003vl\u007f\u0014yJ\u0010\u0017Wh\u000e/F\u0012B8";
      e[15] = "O0#R\u00113L:\u007f 伷众桪桂栊根桳众桪伆\u0013]\bqC?v[\u0004s";
      e[16] = "aAiaDQ2\u00107<91]\u0012veZ\u00033\u001e7?^of\u0013aoE\bm@6>9";
      e[17] = "l\buo\"E:\r`?\u001am\no[\u000f\u001a\u001cm\\&m\u007fJhIv";
      e[18] = "\u0005\u0013c\u000b\b\u0019\u0006\u0019?y\u001a`\u0000\u0003b\u0013\nY[\u00056HsYBI9\u0000J\u0002D\u001dby";
      e[19] = "qnLJY\u007frd\u00108~\u0006w8\u0006E\u0019j2u\u0010\u0000\"=qo\u0012DE6\"8C8";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/system/树友树树何树何树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'r' && var8 != 219 && var8 != 244 && var8 != 186) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 210) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 232) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'r') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 219) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6147;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/system/树友树树何树何树何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[îÇ1\u009cV_¿\u0014\u0080ªTõ³\u001bÎÁ, ½\u0096Y\u0013z:\u000bÓ÷|\u0090½k\u0096fS, ÁTs>Ã\u0012Òµ\u009f\u001b¶\u0000õG\u0098C¬ªVlDÑö>\u0094áÜ*\u0093l\u0019äçoç9\u0000ì«|ã\u000eBF¬tÇ5\u0096\u00072Ð÷& ·, RE ø`:´Ý¤;$\"Ó\u0085eíJBw\u0084FØMãWgòoÇ\t\u000f\u009f,")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   public static void o(long var0) {
      var0 = 2379766056947L ^ var0;

      try {
         new ProcessBuilder(a<"h">(25875, 2209635341357487850L ^ var0), a<"h">(11676, 4044912126061370986L ^ var0), a<"h">(10347, 3973243528744491934L ^ var0))
            .inheritIO()
            .start()
            .waitFor();
      } catch (Throwable var2) {
      }
   }

   public static boolean k() {
      H();

      try {
         return true;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   public static void L(long a, String a) {
      if (SystemTray.isSupported()) {
         TrayIcon icon = P(131542666276291L);
         if (icon != null) {
            icon.displayMessage("Cherish", a, b<"ô">(-538270515564329768L, 3115171313796L));
         }
      } else {
         null.println("Warning ->" + a);
      }
   }

   private static TrayIcon P(long a) {
      a = 2379766056947L ^ a;
      if (b<"ô">(3040950343671342285L, (long)a) == null && SystemTray.isSupported()) {
         Image image = Toolkit.getDefaultToolkit().createImage("");
         b<"º">(new TrayIcon(image, a<"h">(13547, 8398252415005198033L ^ a)), 3040950343671342285L, (long)a);
         b<"ô">(3040950343671342285L, (long)a).setImageAutoSize(true);

         try {
            SystemTray.getSystemTray().add(b<"ô">(3040950343671342285L, (long)a));
         } catch (AWTException var5) {
            null.println(a<"h">(28612, 8668075948497100276L ^ a) + var5.getMessage());
         }
      }

      return b<"ô">(3040950343671342285L, (long)a);
   }

   public static boolean H() {
      return 何树树友友何何友何友;
   }

   public static void T(boolean var0) {
      何树树友友何何友何友 = var0;
   }

   private static String HE_JIAN_GUO() {
      return "职业技术教育中心学校";
   }
}
