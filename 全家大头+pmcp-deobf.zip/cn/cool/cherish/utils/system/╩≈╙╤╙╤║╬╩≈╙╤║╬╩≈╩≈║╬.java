package cn.cool.cherish.utils.system;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 树友友何树友何树树何 implements 何树友 {
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[7];
   private static final String[] d = new String[7];
   private static int _何树友，和树做朋友 _;

   private 树友友何树友何树树何(short a, char a, int a) {
      long var10000 = ((long)a << 48 | (long)a << 48 >>> 16 | (long)a << 32 >>> 32) ^ 1939478944981L;
      super();
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7229592224758975861L, 2138606571216369174L, MethodHandles.lookup().lookupClass()).a(206606240134403L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var4 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(31250682184294L << var3 * 8 >>> 56);
      }

      var4.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var5 = a(
            var2.doFinal(
               "'¬§\u008dÝÈ_W~à\u0010ªFÐ]±ÔmÆ\u0018±fÇÔ\u0002)\u0093\u0018-ÄÆ\u000e\u0088Ï\u007fËý¸È'¶\u0082\u0017£\u0094:N\u009c\u0012è\u0088®É\f\u000b("
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      byte var10001 = -1;
      b = var5;
   }

   public static void e(Object[] var0) {
      System.gc();
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   public static void x(long a, long var2) {
      var2 = 1939478944981L ^ var2;
      int ax = a<"Ý">(5096549181131710375L, var2);

      try {
         System.gc();
         System.runFinalization();
         List<Thread> threads = new ArrayList<>();
         int availableProcessors = Runtime.getRuntime().availableProcessors();
         int i = 0;

         label54:
         while (i < availableProcessors) {
            Thread thread = new Thread(() -> {
               try {
                  Thread.sleep((long)a);
               } catch (InterruptedException var3) {
                  var3.printStackTrace();
               }
            });
            threads.add(thread);
            thread.start();
            i++;

            while (true) {
               boolean var10000 = ax;
               if (var2 >= 0L) {
                  if (!ax) {
                     return;
                  }

                  var10000 = ax;
               }

               if (var10000) {
                  break;
               }

               if (var2 >= 0L) {
                  break label54;
               }
            }
         }

         label39:
         for (Thread thread : threads) {
            thread.join();

            do {
               boolean var14 = ax;
               if (var2 >= 0L) {
                  if (!ax) {
                     return;
                  }

                  var14 = ax;
               }

               if (var14) {
                  continue label39;
               }
            } while (var2 < 0L);

            return;
         }
      } catch (InterruptedException var10) {
         var10.printStackTrace();
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/system/树友友何树友何树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 196 && var8 != 197 && var8 != 226 && var8 != 'b') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 235) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 221) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 196) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 197) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 226) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static InterruptedException a(InterruptedException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (d[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 19;
               case 1 -> 10;
               case 2 -> 0;
               case 3 -> 62;
               case 4 -> 46;
               case 5 -> 59;
               case 6 -> 26;
               case 7 -> 13;
               case 8 -> 55;
               case 9 -> 47;
               case 10 -> 61;
               case 11 -> 53;
               case 12 -> 12;
               case 13 -> 52;
               case 14 -> 56;
               case 15 -> 35;
               case 16 -> 45;
               case 17 -> 24;
               case 18 -> 63;
               case 19 -> 50;
               case 20 -> 34;
               case 21 -> 51;
               case 22 -> 4;
               case 23 -> 44;
               case 24 -> 14;
               case 25 -> 22;
               case 26 -> 39;
               case 27 -> 1;
               case 28 -> 37;
               case 29 -> 57;
               case 30 -> 7;
               case 31 -> 20;
               case 32 -> 3;
               case 33 -> 49;
               case 34 -> 5;
               case 35 -> 41;
               case 36 -> 29;
               case 37 -> 32;
               case 38 -> 43;
               case 39 -> 17;
               case 40 -> 25;
               case 41 -> 15;
               case 42 -> 30;
               case 43 -> 60;
               case 44 -> 9;
               case 45 -> 6;
               case 46 -> 42;
               case 47 -> 23;
               case 48 -> 16;
               case 49 -> 21;
               case 50 -> 33;
               case 51 -> 40;
               case 52 -> 11;
               case 53 -> 54;
               case 54 -> 27;
               case 55 -> 36;
               case 56 -> 48;
               case 57 -> 58;
               case 58 -> 8;
               case 59 -> 28;
               case 60 -> 31;
               case 61 -> 38;
               case 62 -> 2;
               default -> 18;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            d[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      c[0] = "\u001aeHJ)d\u0015%\u0005A#y\u0010x\u000e\u00073\u007f\u0010g\u0015\u00075r\n\u007f\u0003Dh栚厲叀伳核厍佞桨栚伳";
      c[1] = "z-h'\u0005>q\"yhb<d)l4^\"d)z\u0003S1u<j/D<";
      c[2] = "5JZkD\":\n\u0017`N??W\u001c&^9?H\u0007&X4%P\u0011e\u0005桜厝栵桥佝栺优桇佱桥";
      c[3] = boolean.class;
      d[3] = "java/lang/Boolean";
      c[4] = "P\n,\u0016\u0011V[\u0005=YpXP\u000e9\u0003";
      c[5] = "O*5\u0004Ax\u00149!?\u0013\u0011\u0017;5O\u001ea^m)Fz(E*?[\na\u001366?";
      c[6] = "O\n\u0019$3\u0004\u000e\u0012Gy\t#vVIwr^M\u0014Quic";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String HE_SHU_YOU() {
      return "行走的50万——何炜霖";
   }
}
