package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

public class 何友树何友何友友何树 implements 何树友 {
   public 树树树何树树树友树何 友何何何友树何友树何;
   public int 何友树何何树树树树树;
   public int 友友何树友树友何何友;
   public 何树友何何友友何树友 何何友友树何何何友树;
   public 树树何友友友树友何何 友友树友树何何树何树;
   public Set<Long> 友何树树树何何何何树;
   public Set<Long> 何树树友何树何树友友;
   private static final long a;
   private static final Object[] b = new Object[22];
   private static final String[] c = new String[22];
   private static int _我是何树友 _;

   public 何友树何友何友友何树(long a, 树树树何树树树友树何 var1, int var2, 何树友何何友友何树友 var3, 树树何友友友树友何何 var4) {
      a = 何友树何友何友友何树.a ^ a;
      int var10000 = a<"Ä">(385299681444906618L, a);
      super();
      a<"M">(this, 0, 387092269938145781L, a);
      a<"M">(this, 1, 385595574019392924L, a);
      a<"M">(this, new HashSet(), 385357629779055163L, a);
      a<"M">(this, new HashSet(), 385544851436492371L, a);
      a<"M">(this, var1, 386794517647467063L, a);
      a<"M">(this, a<"X">(this, 385595574019392924L, a) + var2, 385595574019392924L, a);
      int var7 = var10000;
      a<"M">(this, var3, 386969248991362299L, a);
      a<"M">(this, var4, 387098854645302388L, a);
      if (a<"Ä">(386859090728657485L, a)) {
         a<"Ä">(++var7, 385414725875376454L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1934355683631424571L, 565804911065707165L, MethodHandles.lookup().lookupClass()).a(274549842998599L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'X' && var8 != 'M' && var8 != 'L' && var8 != 186) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'T') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 196) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'X') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'M') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'L') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/何友树何友何友友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "!<<rFi.|qyLt+!z?\\r+>a?佼反桓伇叙佄叢反众桃";
      b[1] = "ttX\u001e\u0012gj|BQowj";
      b[2] = int.class;
      c[2] = "java/lang/Integer";
      b[3] = "u=+\u001f\u00035z}f\u0014\t(\u007f mR\u00015r&i\u0019B\u0017y7p\u0010\t";
      b[4] = boolean.class;
      c[4] = "java/lang/Boolean";
      b[5] = "\bJ\ftg\u0014\u0007\nA\u007fm\t\u0002WJ9}\u000f\u0002HQ9栙桪桺佱栳栆栙厰桺佱";
      b[6] = void.class;
      c[6] = "java/lang/Void";
      b[7] = "Q\u0011f8-nZ\u001ewwQwU\u0004y4fGC\u0013u)wkT\u001e";
      b[8] = "\n\u0013k\u0011\f\u0001\u0005S&\u001a\u0006\u001c\u0000\u000e-\\\u0016\u001a\u0000\u00116\\伶桿厢伨伐厹厨伻桸厶";
      b[9] = "\u0006\t\u0005\u0000L}\tIH\u000bF`\f\u0014CMVf\f\u000bXM栲栃估厬叠厨栲叙估伲";
      b[10] = ">m\u0018Jkq5b\t\u0005\n\u007f>i\r_";
      b[11] = ",v\u0016\u001a\u0016gyv\u0012\u0016rW\u00173\u0007FNu}c\u001c\u0015\u0013\u001c";
      b[12] = "8pq&LKyi8\u0018厷佺栛栋桓佅伩佺佟栋JhO[kms#HF";
      b[13] = "8\u0000j\rx\u001bm\u0000n\u0001\u001c\"\u0003E{Q \ti\u0015`\u0002}`?\u0004;\u0017q\u000e~\f|\r\u001c";
      b[14] = "du`a8\u000f%l)_佝桺桇叔伆框佝桺厝叔[/;\u001f7hbd<\u0002";
      b[15] = "6'*1F_w>c\u000f厽台佑桜叒栖厽佮佑历\u00116\u0006\f0,{f\u001d_m";
      b[16] = "\u0019wM\u0010\u0010[Xn\u0004.叫佪佾佈厵样併叴栺佈v\u0015T^@q\r@TZL";
      b[17] = "x1<@@\u001b\",=\u0016>4Bh/IEOy>aOPw";
      b[18] = "\u000e\u001ca#\u0017\u0013O\u0005(\u001dF\u007f\t@# AC\u000f\u0012e`/B\n\u0007gs\u0013DXA'\u001d";
      b[19] = "R\u0018\u0019\"_y\u0013\u0001P\u001c伺佈厫厹栻佁伺佈厫档\"\"\\e\u0006B\\c].R";
      b[20] = "\u0017\u00016<\u000e\u0010V\u0018\u007f\u0002佫县栴伾佐栛栯桥栴桺\r;NC\u0011\ngkU\u0010L";
      b[21] = "K'\u0013ckc\n>Z]厐双桨历栱伀伎栖伬桜(c?bK&L0)k\u000b";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 31;
               case 1 -> 13;
               case 2 -> 50;
               case 3 -> 16;
               case 4 -> 15;
               case 5 -> 22;
               case 6 -> 36;
               case 7 -> 44;
               case 8 -> 59;
               case 9 -> 26;
               case 10 -> 51;
               case 11 -> 20;
               case 12 -> 46;
               case 13 -> 32;
               case 14 -> 37;
               case 15 -> 17;
               case 16 -> 42;
               case 17 -> 28;
               case 18 -> 23;
               case 19 -> 45;
               case 20 -> 48;
               case 21 -> 0;
               case 22 -> 39;
               case 23 -> 52;
               case 24 -> 29;
               case 25 -> 5;
               case 26 -> 38;
               case 27 -> 43;
               case 28 -> 34;
               case 29 -> 18;
               case 30 -> 49;
               case 31 -> 24;
               case 32 -> 41;
               case 33 -> 62;
               case 34 -> 35;
               case 35 -> 60;
               case 36 -> 57;
               case 37 -> 33;
               case 38 -> 9;
               case 39 -> 14;
               case 40 -> 30;
               case 41 -> 56;
               case 42 -> 47;
               case 43 -> 19;
               case 44 -> 2;
               case 45 -> 61;
               case 46 -> 55;
               case 47 -> 6;
               case 48 -> 8;
               case 49 -> 12;
               case 50 -> 1;
               case 51 -> 58;
               case 52 -> 4;
               case 53 -> 3;
               case 54 -> 53;
               case 55 -> 40;
               case 56 -> 63;
               case 57 -> 21;
               case 58 -> 27;
               case 59 -> 25;
               case 60 -> 11;
               case 61 -> 10;
               case 62 -> 54;
               default -> 7;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String HE_SHU_YOU() {
      return "何大伟230622198107200054";
   }
}
