package cn.cool.cherish.utils;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// $VF: synthetic class
class 友何友何树何何友友何$友何树友树树树树友友 implements 何树友 {
   private static final Object[] a = new Object[7];
   private static final String[] b = new String[7];
   private static int _何建国230622195906030014 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(199086866713165938L, -8173296218813264528L, MethodHandles.lookup().lookupClass()).a(107411823255794L);
      // $VF: monitorexit
      long var0 = var10000 ^ 90145220407244L;
      a();

      try {
         a<"c">(-466321143450383944L, var0)[a<"c">(-466261286386643702L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"c">(-466321143450383944L, var0)[a<"c">(-466374090557523677L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 195 && var8 != 'Z' && var8 != 'c' && var8 != 206) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'p') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 193) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 195) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Z') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'c') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友何友何树何何友友何$友何树友树树树树友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 38;
               case 1 -> 2;
               case 2 -> 20;
               case 3 -> 50;
               case 4 -> 62;
               case 5 -> 30;
               case 6 -> 34;
               case 7 -> 13;
               case 8 -> 28;
               case 9 -> 43;
               case 10 -> 26;
               case 11 -> 6;
               case 12 -> 12;
               case 13 -> 54;
               case 14 -> 11;
               case 15 -> 27;
               case 16 -> 39;
               case 17 -> 36;
               case 18 -> 22;
               case 19 -> 18;
               case 20 -> 4;
               case 21 -> 33;
               case 22 -> 0;
               case 23 -> 46;
               case 24 -> 48;
               case 25 -> 60;
               case 26 -> 24;
               case 27 -> 14;
               case 28 -> 17;
               case 29 -> 31;
               case 30 -> 49;
               case 31 -> 25;
               case 32 -> 7;
               case 33 -> 8;
               case 34 -> 45;
               case 35 -> 63;
               case 36 -> 40;
               case 37 -> 32;
               case 38 -> 19;
               case 39 -> 37;
               case 40 -> 21;
               case 41 -> 51;
               case 42 -> 42;
               case 43 -> 47;
               case 44 -> 5;
               case 45 -> 44;
               case 46 -> 58;
               case 47 -> 59;
               case 48 -> 23;
               case 49 -> 57;
               case 50 -> 61;
               case 51 -> 52;
               case 52 -> 15;
               case 53 -> 29;
               case 54 -> 3;
               case 55 -> 1;
               case 56 -> 16;
               case 57 -> 41;
               case 58 -> 56;
               case 59 -> 53;
               case 60 -> 10;
               case 61 -> 55;
               case 62 -> 35;
               default -> 9;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "Q^\t e;^\u001eD+o&[COm\u007f [\\Tm叁企叹佥栶伖佟原叹佥\u0003厈佟桅叹校栶桒栛原叹";
      a[1] = "%\u0006";
      a[2] = "\u000f4M0]E\u000f4ZlQJ\u0015\u007fZqBIO\u0015PlUO\u00158Vp\u0014m\u00198J";
      a[3] = "i\b\u0005I\u0019Zb\u0007\u0014\u0006xTi\f\u0010\\";
      a[4] = "ks\",\u0011l0sl/|@R+20\u0011}.p2~\u0012";
      a[5] = "m}QozF*{F\u0006伛佹伏佄佾佛厅栽厑栀#vzG9(Ak{\u0015";
      a[6] = "\u0003KTg\u0004pXK\u001adi^:\u0013D{\u0004aFHD5\u0007";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String HE_JIAN_GUO() {
      return "解放村多种2队1144号";
   }
}
