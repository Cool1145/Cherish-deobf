package cn.cool.cherish.utils.shader;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

public class 树树树友何友何树树何 implements IWrapper, 树树树何何何友树友友, 何树友 {
   private static final String 友友何友树何友何树树;
   private static final String 友何友树树何何友友何;
   private int 何友树友何友树友友树;
   private int 树友何友树何友友友友;
   private int 友树何何何友树友何树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Integer[] g;
   private static final Map h;
   private static final Object[] i = new Object[14];
   private static final String[] j = new String[14];
   private static int _何树友被何大伟克制了 _;

   public 树树树友何友何树树何(long a) {
      a = 树树树友何友何树树何.a ^ a;
      super();
      c<"Ô">(this, 0, 3703830222486117750L, a);
      c<"Ô">(this, 0, 3703763836286263141L, a);
      c<"Ô">(this, 0, 3703972277832564685L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7873624385637259466L, 7072856141698358706L, MethodHandles.lookup().lookupClass()).a(18685741408693L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 18564315308979L;
      Cipher var13;
      Cipher var24 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[15];
      int var18 = 0;
      String var17 = "û¶]ÿÍ0Ã¨îXÑ\u009bÙúê\u0094\u0083«!\u0018®Ã\u0080h§\u0096lð\u0097fh\rqJ\u009bÄÑKY\u0007Çu&\n\u0003i\n\u0091áú)#\u001c´Ùë¢Xïäõ#äÐí\u0011Ù\u000fP å u\u0086\u0010ÂX¬a.=eDèºÉ+\u0006B¢SD¶zÑz2²Ú¯nH;ñbÂ ý×Î\u0084c`µ÷cTnÊ¼rË\"ÞÉù·É][¨\u00957-\n4gàqå»úw\u008cÌ\u0087\u001c<e¬ºÖ\u0089QtûXQv\u009eP\u0007<Áb\u0015\u0010\u0099,·\u0019\u008af$|ÊE\u001e\u008fÂqtÆD[\u009f 8ß¸ë\u0082\u001cË\f\u009f+\u0002÷ÿ2_\u0010ºw×ó\u000eÂÔ!¸\u0006\u009a\u007f=\u008cÉR¦àQ\u000b÷vu\u0092¼Õ\u0088ht÷À²ìRÞzPiÀ »3\u009a\u0097\u008a$yi\u008f\u00ad¡èÍ\\®\u0095&\u009eýÜN\u0014.Xª\u0080\u0018ÂÆ\u0019JõQ\u0091c¦AõéÑÜ\u00008y<R~Ê´»|\u001aVB\u0089S*íM\u0015âÅÆ¨]\n\u0083\u0010\u0016Øø¦ç\u000f\u0099\u0093¡A=mi,õÕ\u0000t\f\u0096bÉ½\u001a²\u0093Å\u008a*\u0099\u008dS{§Ld5u\u0013·á?âµ\u001cÅRe\u0088·¸Uÿ\u0016s<G\u001dNgá\u008cW\u0015©\u001fp\u001e!\u0095\u0014t\u009cêÕ\u0093»§\u009fo¢?i\t>\u009fÄÓ\u0089T&[ìÑW='\u0016ò=w\u0010(rc®X>L\u001cW\u0084l\u0015\u008aC\u0080\u0012<Ö\u001f_\u0093>rrFQ Á½µÊ\u0084\b¤âú#hÁ\\98\u001fêÎ-;\u0002Öl`N\u009a\u0096ÂÜX*\u0092è\bÄ\u00ad\u0010²Ï2|V\"À:/\u0012²ßlÝ\u0015ÛÍ\u001a\u0082&º\u0097,\u0007.zrËÛZV=Ä\u0014Zð\u009føýYµ\u0090¶LjìË\u0014×]µUÛè¾\u009b@\u0084±\u001f\nuê¡\u0011\u0017óÒ\u0096\u001d\\Ó\u0085\u0017º\u0093MèâxP¹Á\u0084ý\u000ff>Ã·\u0018\u0015\u0003\u008d\u0017°\u009c/×Ô\u0095\u0092ôc7ñ¾¬QF\u008e\u008c\u000e²TÌ<uY\u0014\u0002\u008b\u0081wß\bWÌê²^9¥\tm?ÏÜ$ÅNlF§í>\u0001\u001f\u0004PzÐÿHó\u00aduØ~\u008cÔ¹|S¾\f)U¹I«N}æN$Üâ\u0087cw°èÿ\u0085\u00adCçÂÂ?üÃ=0\u0081SSu\u00ad£1êsW{\\®dáC |RVn\u0083]\u001añþé[¦Aâ\u009a\u0000\u0003\"\ro\u0011\u008b\u0002óÆèi\u0003\u000b\u0081¡°¸ð¹hD\\iÍÆ\u0083{Oä?o\u0017Uä\u0010GÞîWþÚ\u0092dðÎîÌ\u0098¥\u0091ÌöI+ü\u0019¢\u0011iW\u0097G8\u001b;'_ã®GÌ'ðÖ\u0095fµ\u0010¡\u0001ëmÐè¶teP\u0087j°\u0099ëz\u0090¿.ÿ¬ÊvVÀ\u001a\u0000¬}Ír¨\u0006¼E\u0018ÜE¥\u001fB|J$º\u009bw#¿\u0017%êAñé¨ÁL\u009c¡\u0093>â¨X}\u001dÊ5Åôê\u0097\u0018\u0017wLP3ék.\u001e×%àf\u000e$»\u0018CXæ\u000bÚ~)pÖ\u0095}\u0003\u0005½åÊ\u001dõh\u008f\u008b\u0007Ìæ£\u0006ÆuXóa©«&\u0016±ìQw\u0087t©$\u0083#tíð\fh¢ÇöQ\u0010\u008bk×¾ð§ÄÔÁ\u0017ÍíËË\u008aÙ\u0006¶\u0019òæL!\t\u007f\u0005'ÄÄZ¸n`î3ó\u0003^²&ÊAþU2ûj´¾ÚÜúáz\u000e\u0013B·m(è\u0004J=ý\u0088\u0003ªH]÷_I¬A:\u001eWAè\u0085À<ìÚ×EU¡¹\u001bUa1\u001d\b§OÇ\u008eoÀÛ\b\u0001ã\u0095Yçè\u000f\u001b@\u008aÉ\u000f\u008aEe¾7q<<ÌäÑCª,k4¤\u0005òs²¸\nª\u0094\u0082\u0011\t\u0092·ÆÛZ5P«ûôÒ}\u0016÷J6ï\bÝ%Ñ²\u0099{ê\u0090êÙº)pcÍ^xk8\u009c\u009eÐ(ÆW0 Ú\u00933\u0092Lcÿ\u0017\u0083¤\u0095!¸\u001a\u009eÇ]u\u0091Ï1\u0080\u0002h0.às\u0014*XX\u000exâ R1\u009bO8é¶qù!?ýªíè§¼¦ÉÖ>ã\u0016¿ÕE\u009eÚ\u0080ö\u0082ñôü¼\u00951Ñ2W\u0099\u0007}F½Á Ô0k#Ý¨»v`\u0017»}WÙ\u0007 e\u008c\u0007Öó\u001eÏ@»C¸ü4Ãr\u000e \u009a^<¿zN\u000e¨\u009eýZ\u0087¨q9s\u0084fw\u009f\u008cÏ\u0006\u0093\u008e\u0003¸þOÇº\u000b º®\u0084\"Q\u008aÙEOT?kÃÜ8Ö\u008c\u0089åDÅÍ>qI\u0094´#7á\u009b¥H¤TÍãß\u0091`³÷IåöVã\u008e\u001cF\u0083÷Åïd4Kòª¹I\f\u0080àÍ ¨ê¦¥\u000e$M\u001c\u0006±\u0015rÙk|\u0012,P\u0004\u0007\u0019C\u0006v\bªÅ@Ø]\u001a#~Ì|\u0089F\u000b\u009e §`1\u0095ûìç«2²ðË\u0080Ä\u008eÛ¬\u009ev¼è\u00ad©JüÕá¡¡ASîĀÉêËËn\t\u0088á[jÓ\r°\u009c\u0090û6K¶Ï\u001c\u0088èb ã\ny\u0095V;#Û\u008bÁ\u0013Ý!\u0098¾õh,V*È\u0082\u0017\u008aJÐ>¿\u009cõ|Ú<ítd\u001c2\u009aLªØ\u001eíi(\u0092yx\nJ¬\u000f-×Y9m¶'WBóû6\u0004XÒ^ýk¼ÈÜÙ\u0000\n\u0095O=Çx¤²\u0002O\u0086wNdW(+ÉÑùréÉtÇ\u0012\u008fX\u0007 /®\u0090»á§ÑVõk\rh\u008d\u0001Ø»~è-Õû9gÍ8\u0087È\tB{ïØ·jçA\u0082\u0011\u0095Ê7¹¥ªüF\u0014\u0092èc%Ä\\\u0094êÓ\u001b\u0081íYMàÄà\u0080e\u0092\u000b¸I²\u000b\u0099ÿÄX7=[Ò×Îã,×¶ðÙV©\u008c7Ïzç,U³\u0096ògÇÉ%±¾GÊ`Ñ|\u0098wé\r¬L\u0098\u0090}\u001f¸\u001dk\u0001 5\rJÚÄ\u009e»\u0098U\t\\4«Ë\u0005\"\u0018\u0014û¢\u0092\u009e%\u008e\u0081Koã\"È\u0011î\u0010írUK\u000ekl\u0005ùx{È|W\u0005u@\u0000Lfr\u008bx\u008bnïñQBKçy\u0086¯ºÅÉÛ]È\b\u007f¼\u0017;\u001bRÈi^³_\u00161\"ýi\u008c\u0012ù\u0099F\u0007\u009ek\t\u009c?Ñí\u0099Ä¼9³ì\u0087I\u0081¯î ãR\u000eµ6\u0086ÆsÉlüA\u007f:\u0080F0ff\u0018¹¤y\u000f\u0015\u009eÕ¯Õ\u0086\u001b©ðàþºû\u0087ß\u0000g_ã\u0000F×ò5\u0019Ào6ùUè³Ðtµ¯\u0012é\u0014ôe?>=,÷$\u0099¬\u008e=¬«Hn7«`´üé\u001b1\u0086O®\u008e%x?Âw°VÌ·sIo)Åõ\u0096w\u0094=e£ÖÌS\u000b\u0019ÓF\u0085ÊCEX\u0084\u0082g\u0085î\u009f®\u0080\u0004Vø\u008ae\by\u009b3 ?\u0003[ù\u0097\u0015mZ\u0092Ô\u0093\u008d\u0085\f\nÛó?^£µ=¼ÉÕoU¬\u008a\u009b\u0000fqÁ}ÇxhÁ68R\u009f\u001bf½w\u001fÖvÉôH\u0080\u0006«ÚTöÈÉ\u0097\u0019MÛy|}ÑB\u0011;\u0098§\u009cH\u008c`_\u007fp66°ç\u0013\u0019\fKgVö\u008bìÑ\u000e\u0001\u008d\"/´ð£yJý[9\u008a{<°\"Bû8oýtêÛ«-Ä\u008d\u0090ºó\u0015\u0011â \b\u0004?Ì|ù2\u008dãkÚ{{\u0010\u0089\u008f\u0080EÆCu\u001d_ï\u0091\u0001\u0081¡¨\u0006XÀ";
      short var19 = 2084;
      char var16 = 1200;
      int var23 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            String var36 = b(var13.doFinal(var25.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var23 += var16) >= var19) {
                     b = var20;
                     c = new String[15];
                     友何友树树何何友友何 = a<"o">(31173, 5621073877195757088L ^ var11);
                     友友何友树何友何树树 = a<"o">(12413, 7462301869870800798L ^ var11);
                     h = new HashMap(13);
                     Cipher var0;
                     Cipher var27 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
                     }

                     var27.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[8];
                     int var3 = 0;
                     String var4 = "p\u0097öVÍS,¼ñ\náó[\u009b\u0006à\u0087ÙóDPRòçï¿çRÅ°óC$\u0092ª\u0084Ò/\u0014\u0086Õ,R2ê\u0089ØG";
                     byte var5 = 48;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var43 = -1;

                        while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    f = var6;
                                    g = new Integer[8];
                                    return;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\\ÄÂÜ°\u0086W\u00059B±ASé\u0089\u009b";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label54;
                  }

                  var17 = "<wsE@vÈ\u000e\u0093¦}!£\u009c½>\u008cÉ\u009dUî\u0092º*`Èê\u008e\u001f£Ú\u0081\u009e>´\u0002\u001eiYÝE±÷Öé'o{\u0085uäîÇ\t\u000bz¼d*¿O\u0006·\u0082<´n¿\u0015\u001aÑë$õcqu\u0004½iÄ\u009bQ\u009d\u009a\u0018\u001a \u000e×©y%Õ\u0004\u0012JÄÚÐ\u0085Ð0r%¤¡\u0082¾ùý\u0018EÜÝàqã\u008fé\u008eé\u000bh!¿P4²×ù\u0017\u0085?F\u009b¤|\u0018:\u0082[\u001eëÑT\u0098¹Ëßæ.Úú¼ÁýÏ¦\u0012)¡,p\u008c\u0083\u008cªBgXÀ\u000ecÈ\u008bsùÿîx\u008f\u008a0\u000eVÇvgÂ\u008e¾\u0016Ô¢|!¾èI$\u000e§Ø5i£E\u008foaGøV\u000b@\u0096\u0000B]r!T\u009b\u0097\u00ad\r¿+\n\u0012¬u\u0000}aß\"\u0013q\u009bv\u0098D%'\u000f7]\u008dÑ\u001c\u0084h3sãµe\u00adâZ\u0014\u0080\f°\u0015Ï\u0016øa\u001c\u001e8DÕ\u0000\u001aÀñ¸¸ªJ»Oÿ%íhzÙªq4Àûß¦E\"ù\u0095b*\u009d1\u0005tj\u0007Q-6G\u009aÛe}\u0099\u0081«×%COk4\u0004\u001c\u001d\u0080Ä8G\f¡\u008bª'ÓDPòæ¥?å@ëð/ý\u001f)ô\u009bh\u009b\u008cmöâé-Òþ\u009f\u000fN\u0019\u009bj÷Drl\"\u008f\u008c\u001aø¡õÙC\u0000S\u0089Ò\u001a\u008f¡*³Ë¡ðÊ 3Ü}É¾Y`úú\u0004Ñ\rÉþ9Í\u0003\u008d41ÚËYÓ\u0099>öÐe>RÅYNF=I¥ÓcÉ\u009b_\u00973¢B\u0093\r±6\u0001\u009d\u0006\u0012}\u0090b\rKÅ\u009e\u0012\u009dvÍâñ\u0011\u0092,æÜ\u009fûp+·Wu\u0012okÆÃ\u0080ä\u0019ÖÝjÊ\u001dpÐ\u008dP¿]\u0019ò~Ò;)|c«c>k\u0085\u00adåí§ñ\u0096K\fÎp¼¼\u001d4.t^7\u0088&6ÿ\u0093Y»\u009dÞü\u008a`LtþE>\u0093\u0086:%\fB|©\u0007\u000e\u0085ñ¸®ûÈÇÊ8¥\u0013·\u0002\u0016ÈXo~q´Oo\u009dC\bu\u0087{65\u000fëÔ7âÈÎ\u0093C,\u0012ê\f\u0098·Rî=\bÇ\u001b\u0003\u0013tözvü\u008dùÆñå[æÁ\nó\u0005aÞ0¤\u0094|\u0014×à\"\u0015C9M\u0018Xðî®ý½ß\u0092#}\u0093óBåÉ·\nêÐ\u009aöLâÃ+\u009a{üò$9ù1\u009fCrÒù\t= 4Ü8\f\u0004H\u0010:ü\u0003:G_ï\u0014\n¡O·\u0095\u001e¦\u0091\u009e>¼CFNÐ\u0093á\u0080\u0091qºt_\bØQâ¢k\f:\b*x\u0088å`gìTâ\u0001$s\u0012+µ\u0018¿kû\u0088\u0082Ïpû\u0081ñï\u0016ô¤\f\u001c\u0091=ýÛØ\u0080rÅ\u0080\u0001õ\u0007«\r!\u0098ÒÙñåáË% Ø\u001c\u0098ÅíQP÷Ù'\u0089?@\u0082Q¥ü.\u008e\u008cõÏ\rlð\f¯ÍÞ$8\u0003\u0081\u0015\u0088\u008bã\u00896O¼è£¼\u0095îú¿\u0002\u0087?v\u0085\u0080KàL¿74\u009d¬w-9)\u0013X\u0005¶h\u0012\u001dµ\u0002å\u000f\u0089d-ÛL\u000býß ].»1ß9\u0092\u0003ýÌV°ô¨ñ\u0081Ã\u0089*\u000eö\u0006\u0085\u0081r³Ù9\n\bbmËÓ%J=523¢u7@\u001e\u0089wsöèÜø6\u0086¥.\u0099\u0013\u0087þo\u0019=~÷\u0086¼¹|\u001eÞT÷BD\u0099\u0005U{\u009f-4¸Ð;\u0000[`1õn7§én]\u0005\u0099¹\n\u000b!ø\u008d\u009aNà\u000f\u0004\u009ci\u0017\u008cm\u001atH¨\u009eü\u0017yUÝ\u0017NÌrFá\u0006+*Lú\"°¡2ªN\u0089\u008eÿ¼ÍEî\u0091Û¹Þ\u007fÕl5ØÓC\u0099\u0014-ÅÀ*ý WU\u0006¤÷ÖñL¸ÒqL¾\u0006CÌ{^ßí\u00182+ë?\u008c\u001fÊKé¾%\u00adf3Ô¨8õ\u0093àÜ{YAÏ\u0093ZLQv·ßJôÓLG.\u0099P8\u009c§R\u0018»>í|ÛÞ\u0005\u0099\u0011ø\u001dÕÂå\u0089\u001b)ÊçÙä\"\u0095D§rnY6Æ±mB.CÃ3kÊ\u0087%ôªk\u00adGý\u009b\u008b6Nâ;§\u000e1h\u0007·ýª\u0016Æ\u0016)\u0015³ÛWß)T \u0012¸þÝ{ÖX\u0007\u009bòÕxvòk\u0098ûº\u0098\u0006q*þ\u0098 \u008eí\u00880Îù\u0018ÿw«öð^\b\u008bYá½<7\u0094Ýû\u009aÒæßV3E(";
                  var19 = 1233;
                  var16 = 1208;
                  var23 = -1;
            }

            var25 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 28;
               case 1 -> 12;
               case 2 -> 61;
               case 3 -> 55;
               case 4 -> 7;
               case 5 -> 52;
               case 6 -> 10;
               case 7 -> 50;
               case 8 -> 20;
               case 9 -> 38;
               case 10 -> 39;
               case 11 -> 35;
               case 12 -> 22;
               case 13 -> 8;
               case 14 -> 1;
               case 15 -> 16;
               case 16 -> 56;
               case 17 -> 19;
               case 18 -> 25;
               case 19 -> 9;
               case 20 -> 34;
               case 21 -> 15;
               case 22 -> 27;
               case 23 -> 26;
               case 24 -> 23;
               case 25 -> 54;
               case 26 -> 29;
               case 27 -> 59;
               case 28 -> 11;
               case 29 -> 6;
               case 30 -> 60;
               case 31 -> 58;
               case 32 -> 62;
               case 33 -> 14;
               case 34 -> 37;
               case 35 -> 47;
               case 36 -> 3;
               case 37 -> 36;
               case 38 -> 44;
               case 39 -> 41;
               case 40 -> 24;
               case 41 -> 57;
               case 42 -> 33;
               case 43 -> 43;
               case 44 -> 49;
               case 45 -> 46;
               case 46 -> 21;
               case 47 -> 48;
               case 48 -> 32;
               case 49 -> 17;
               case 50 -> 30;
               case 51 -> 18;
               case 52 -> 45;
               case 53 -> 4;
               case 54 -> 0;
               case 55 -> 63;
               case 56 -> 53;
               case 57 -> 2;
               case 58 -> 31;
               case 59 -> 42;
               case 60 -> 13;
               case 61 -> 51;
               case 62 -> 5;
               default -> 40;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/shader/树树树友何友何树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 1369;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/shader/树树树友何友何树树何", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'S' && var8 != 212 && var8 != 'L' && var8 != 'Z') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 164) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 255) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'S') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'L') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/shader/树树树友何友何树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      i[0] = "]\u007f:`\u001a|R?wk\u0010aWb|-\u0000gW}g-\u0006{_uqq[栂栯栀叟佖厾但栯栀佁";
      i[1] = int.class;
      j[1] = "java/lang/Integer";
      i[2] = "yS\u001av3Gv\u0013W}9ZsN\\;)\\sQG;+Z{MDp.\u0006SjFt,X\u007fO";
      i[3] = "g\u000b!_\u007f\bi\u001a.\u00140\u0014g\u001e!\u0018p\u001f&\u0015)\u0016*\u0012&5)\u0016y\u001dz";
      i[4] = "\u001cr\u0003Cd \u0017}\u0012\f\u00189\u0018g\u001cO/\t\u000ep\u0010R>%\u0019}";
      i[5] = "\u001e,\u0010+\u0011C\u0011l] \u001b^\u00141Vf\u000bX\u0014.Mf\rD\u001c&[:P叧厶众叵伝厵叧桬众栯";
      i[6] = boolean.class;
      j[6] = "java/lang/Boolean";
      i[7] = ";'bQ\u0014E0(s\u001euK;#wD";
      i[8] = "Q\u001dB\u001c7\u001b\u0014\u0003C'桕厦伶厱格佺厏厦厨厱%W0[\u0015C_U1\u0003";
      i[9] = "_*\u000e-/$\bbW2J0\u00015\u0000'0T\\=\u0013009\u001c4\t*";
      i[10] = "l&Nz]V)8OAO(mvPx\u001dM;xE/&\u0013i0\u0010zCEg%GA";
      i[11] = "cvg\u0011A\u001e&hf*佧厣桀叚佝叩栣厣厚栀\u0000ZF^'(zXG\u0006";
      i[12] = "0\u0015B\b^J3\u0013\u0002A#j\f\u0015WR[\\gU\bGL7";
      i[13] = "Wi+H-\u0018\u0012w*s厕桿估佛休厰桏厥估栟L\u0003*X\u001376\u0001+\u0000";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5041;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/shader/树树树友何友何树树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/shader/树树树友何友何树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   public void w(long a) {
      long ax = a ^ 139651493935677L;
      long axx = a ^ 983877020162L;

      try {
         int var10000 = b<"o">(32348, 5019341728768052360L ^ a);
         Object[] var10005 = new Object[]{null, a<"o">(6809, 762790874828947119L ^ a), a<"o">(19861, 1785618521321662884L ^ a), axx};
         var10005[0] = var10000;
         int vertexShader = ShaderUtils.o(var10005);
         var10000 = b<"o">(8086, 3566366705799867716L ^ a);
         var10005 = new Object[]{null, a<"o">(18965, 1989966245427670565L ^ a), a<"o">(7341, 4010499604629567635L ^ a), axx};
         var10005[0] = var10000;
         int fragmentShader = ShaderUtils.o(var10005);
         Object[] var10007 = new Object[]{null, null, a<"o">(4567, 909634707868464612L ^ a), new String[]{a<"o">(26833, 3359400021266058478L ^ a)}, ax};
         var10007[1] = fragmentShader;
         var10007[0] = vertexShader;
         c<"Ô">(this, ShaderUtils.P(var10007), 4003332100470675870L, (long)a);
         int oldVao = GL11.glGetInteger(b<"o">(19455, 8459107286059415850L ^ a));
         int oldVbo = GL11.glGetInteger(b<"o">(18998, 3085689837102201061L ^ a));
         c<"Ô">(this, GL30.glGenVertexArrays(), 4003274793554729869L, (long)a);
         c<"Ô">(this, GL15.glGenBuffers(), 4003475264234830629L, (long)a);
         GL30.glBindVertexArray(c<"S">(this, 4003274793554729869L, (long)a));
         GL15.glBindBuffer(b<"o">(30787, 2537023145634810514L ^ a), c<"S">(this, 4003475264234830629L, (long)a));
         FloatBuffer buffer = MemoryUtil.memAllocFloat(8);
         buffer.put(new float[]{-1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F, 1.0F}).flip();
         GL15.glBufferData(b<"o">(16182, 3986105347893956070L ^ a), buffer, b<"o">(22495, 4727031491080217864L ^ a));
         MemoryUtil.memFree(buffer);
         GL20.glVertexAttribPointer(0, 2, 5126, false, 0, 0L);
         GL20.glEnableVertexAttribArray(0);
         GL30.glBindVertexArray(oldVao);
         GL15.glBindBuffer(b<"o">(16182, 3986105347893956070L ^ a), oldVbo);
         c<"L">(4003202739496815518L, (long)a).info(a<"o">(11189, 549152978524114817L ^ a));
      } catch (Exception var13) {
         c<"L">(4003202739496815518L, (long)a).error(a<"o">(22783, 7648590393742654662L ^ a), var13.getMessage());
         var13.printStackTrace();
         c<"Ô">(this, 0, 4003332100470675870L, (long)a);
      }
   }

   @Override
   public void T(long a) {
      boolean var4 = c<"ÿ">(-8146430564863994058L, (long)a);
      int var10000 = c<"S">(this, -8145943923079470877L, (long)a);
      boolean var10001 = var4;
      if (a > 0L) {
         if (var4) {
            if (var10000 != 0) {
               GL20.glDeleteProgram(c<"S">(this, -8145943923079470877L, (long)a));
               c<"Ô">(this, 0, -8145943923079470877L, (long)a);
            }

            var10000 = c<"S">(this, -8146159284846370064L, (long)a);
         }

         var10001 = var4;
      }

      if (a > 0L) {
         if (var10001) {
            if (var10000 != 0) {
               GL30.glDeleteVertexArrays(c<"S">(this, -8146159284846370064L, (long)a));
               c<"Ô">(this, 0, -8146159284846370064L, (long)a);
            }

            var10000 = c<"S">(this, -8146367454761319848L, (long)a);
         }

         var10001 = var4;
      }

      if (var10001) {
         if (var10000 == 0) {
            return;
         }

         var10000 = c<"S">(this, -8146367454761319848L, (long)a);
      }

      GL15.glDeleteBuffers(var10000);
      c<"Ô">(this, 0, -8146367454761319848L, (long)a);
   }

   private static String LIU_YA_FENG() {
      return "何炜霖诈骗";
   }
}
