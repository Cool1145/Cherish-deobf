package cn.cool.cherish.utils.shader;

import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL20;

public final class ShaderUtils implements IWrapper, 何树友 {
   private static boolean 何何友树树树树树友何;
   private static final List<友友树友树友树何树友> 树何友何友树何友友友;
   private static Event.Side 何何何何友何友友何何;
   private static final 树何何树何树友何何树 树树树何何树友友树何;
   private static final 何树树何何友友友友友 何何何树树友何何友友;
   private static final 何何何树何何树何友树 树何何树友树何友树树;
   private static final 友友何树友树树何何友 何友友何友何友友友树;
   private static int 友树友何友友何友友友;
   private static int[] 何树友何何何何何树何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Integer[] g;
   private static final Map h;
   private static final Object[] i = new Object[39];
   private static final String[] j = new String[39];
   private static int _何大伟：我要教育何炜霖 _;

   private ShaderUtils(long a) {
      a = 126517117157397L ^ a;
      super();
      throw new UnsupportedOperationException(a<"k">(6734, 8696560034968803529L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6029140241292565867L, -8668910263752571767L, MethodHandles.lookup().lookupClass()).a(24580056413121L);
      // $VF: monitorexit
      a = var10000;
      a();
      c(null);
      Cipher var11;
      Cipher var21 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(99829570732103L << var12 * 8 >>> 56);
      }

      var21.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[6];
      int var16 = 0;
      String var15 = "Ø\u0017=)È\u0092M\u0010£¨ëXæþ&\u009e\"ß\u0017Ñ\u0003\u000f´Ô\u0095(\u0015(]È\u008còkõÙ\u0093Ðây\u00938Q/Ë;ðñÐ\u0003\u0016Á&\u0082p\u0003^M(nj]É½\r¬*qA²èÉ´ÏØL_Õ\u001e6:¸m;\u000f\u000e×ñ\u001e\rÿ\u0090îÅÆÈm\u000f@u£ýVëê\u0093D\u001bÏ\u0006W\u0018O\u001c\u0099\u008d\u000eB\u0017ÂKÓ@À\u008e3ìKbX\nS0§0¯\f\u001c\u0015æ*\u0007¢DT\u00825l\u001büªÄ¤\u0088ñç\u0084®½¸\u0017´H8ÑnD\u008bÍ¼áÓ\u001eö\u0015×7ÏÌX\u001fá\u008d\u001a\u007f\u0093¥\u0094ÛÕ.#\\\u0004pS§m¸T5rmiê4\u0004\u000f§\u0088\u001cê\u0096×Ü\u000fÃw\"\u0096";
      short var17 = 219;
      char var14 = '(';
      int var20 = -1;

      label45:
      while (true) {
         String var22 = var15.substring(++var20, var20 + var14);
         int var10001 = -1;

         while (true) {
            String var31 = b(var11.doFinal(var22.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var31;
                  if ((var20 += var14) >= var17) {
                     b = var18;
                     c = new String[6];
                     h = new HashMap(13);
                     Cipher var0;
                     Cipher var24 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(99829570732103L << var1 * 8 >>> 56);
                     }

                     var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "?\u001c|@èÝ$ 9dØ\u0081MÙàÍ".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var36 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 16);

                     f = var6;
                     g = new Integer[2];
                     何何友树树树树树友何 = false;
                     树何友何友树何友友友 = new ArrayList<>();
                     树树树何何树友友树何 = new 树何何树何树友何何树(1184896417L, '\u2d7d');
                     何何何树树友何何友友 = new 何树树何何友友友友友(71462066405666L);
                     树何何树友树何友树树 = new 何何何树何何树何友树(118852027019568L);
                     何友友何友何友友友树 = new 友友何树友树树何何友(137385621317085L);
                     友树友何友友何友友友 = 0;
                     树何友何友树何友友友.add(树树树何何树友友树何);
                     树何友何友树何友友友.add(何何何树树友何何友友);
                     树何友何友树何友友友.add(树何何树友树何友树树);
                     树何友何友树何友友友.add(何友友何友何友友友树);
                     return;
                  }

                  var14 = var15.charAt(var20);
                  break;
               default:
                  var18[var16++] = var31;
                  if ((var20 += var14) < var17) {
                     var14 = var15.charAt(var20);
                     continue label45;
                  }

                  var15 = "ÌO4\u009aj9¹ìÜðCu1|æÊæAª¢Mº$è\u0094¥aÂ4\u0097\u008eÍôÐ\u0084=\u0007\u0000òè\u001cXu¢\u0091ãí&Ç>Í6\u0094ª\u001d\u0087`\u009cÇ\n t\u000b\u0099©²Y\u0098#×\bo\u0095au\u0085f&Æ÷è¢ß\u008d8\u0095i\u0016¹ÃÎ-·³á\u00800\u008d\u001bÝ\u000fÓìæ\u0017\u008d\u009bYÂ5á&¨ä\u0093m?5õ\u0093÷·\u0019Èw@Ö¢Äq\u0082\u001b\u001bw\u0090#n+ù,<Á\"<ps\u0097n\u0089Ì_Æõ";
                  var17 = 153;
                  var14 = '8';
                  var20 = -1;
            }

            var22 = var15.substring(++var20, var20 + var14);
            var10001 = 0;
         }
      }
   }

   public static void B(PoseStack a, float color, long radius, float var4, float y, Color poseStack) {
      G(a, (float)color, var4, 2.0F, poseStack, 11725182310L, true);
   }

   public static void C(
      PoseStack a, float a, float var2, float color, long bloomIntensity, float bloomRadius, float radius, float poseStack, float x, Color height, boolean y
   ) {
      bloomIntensity = 126517117157397L ^ bloomIntensity;
      long ax = (long)(bloomIntensity ^ 111807439378335L);
      c<"t">(180555062725668660L, (long)bloomIntensity);
      if (c<"Ê">(180298835986279645L, (long)bloomIntensity)) {
         Event.Side var10000 = c<"Ê">(180194219179008602L, (long)bloomIntensity);
         if (bloomIntensity >= 0L) {
            if (var10000 == null) {
               return;
            }

            var10000 = c<"Ê">(180194219179008602L, (long)bloomIntensity);
         }

         if (var10000 != c<"Ê">(180253618138577892L, (long)bloomIntensity)) {
            c<"Ê">(184164803759283429L, (long)bloomIntensity).s(a, (float)a, var2, (float)color, bloomRadius, radius, (float)poseStack, 0.8F, ax, height);
            return;
         }
      }
   }

   public static void D(String a, long name, int... a) {
      name = 126517117157397L ^ name;
      c<"t">(-8214213709651123276L, (long)name);
      int loc = GL20.glGetUniformLocation(c<"Ê">(-8210584945188988155L, (long)name), a);
      if (((Object[])a).length > 1) {
         GL20.glUniform2i(loc, (int)((Object[])a)[0], (int)((Object[])a)[1]);
      }

      GL20.glUniform1i(loc, (int)((Object[])a)[0]);
   }

   public static void F(long a, PoseStack x, float bloomIntensity, float width, float bloomRadius, float y, float color, float radius, float a, Color var10) {
      long ax = 126517117157397L ^ a ^ 7998930600812L;
      C(x, bloomIntensity, width, bloomRadius, ax, y, (float)color, radius, (float)a, var10, true);
   }

   public static void J(PoseStack a, long radius, float height, float width, float x, float lineWidth, float y, float a, Color var9, boolean color) {
      radius = 126517117157397L ^ radius;
      long ax = (long)(radius ^ 139821815423925L);
      c<"t">(-8634495473563867751L, (long)radius);
      if (c<"Ê">(-8633993035668494736L, (long)radius)) {
         Event.Side var10000 = c<"Ê">(-8634169653325272841L, (long)radius);
         if (radius >= 0L) {
            if (var10000 == null) {
               return;
            }

            var10000 = c<"Ê">(-8634169653325272841L, (long)radius);
         }

         if (var10000 != c<"Ê">(-8634233400807886519L, (long)radius)) {
            c<"Ê">(-8634307293605074852L, (long)radius).p(a, height, width, x, ax, lineWidth, y, (float)a, var9);
            return;
         }
      }
   }

   public static void V(long a) {
      a = 126517117157397L ^ a;
      long ax = a ^ 52585848349791L;
      int[] axx = c<"t">(3774640260653668823L, (long)a);
      if (c<"Ê">(3775087790076713534L, (long)a)) {
         c<"Ê">(3774740090324055990L, (long)a).info(a<"k">(9054, 7807819147799580634L ^ a));

         label33:
         for (友友树友树友树何树友 renderer : c<"Ê">(3774467682667873842L, (long)a)) {
            renderer.t(new Object[]{ax});

            do {
               int[] var10000 = axx;
               if (a >= 0L) {
                  if (axx != null) {
                     return;
                  }

                  var10000 = axx;
               }

               if (var10000 == null) {
                  continue label33;
               }
            } while (a < 0L);
            break;
         }

         c<"L">(false, 3775087790076713534L, (long)a);
         return;
      }
   }

   public static void e(PoseStack a, float width, long poseStack, float x, float color, float a, float var7, float lineWidth, Color height) {
      long ax = 126517117157397L ^ poseStack ^ 71322370440581L;
      J(a, ax, width, x, (float)color, (float)a, var7, lineWidth, height, true);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 22;
               case 1 -> 37;
               case 2 -> 44;
               case 3 -> 20;
               case 4 -> 24;
               case 5 -> 9;
               case 6 -> 34;
               case 7 -> 59;
               case 8 -> 23;
               case 9 -> 58;
               case 10 -> 3;
               case 11 -> 29;
               case 12 -> 43;
               case 13 -> 53;
               case 14 -> 12;
               case 15 -> 4;
               case 16 -> 47;
               case 17 -> 46;
               case 18 -> 16;
               case 19 -> 35;
               case 20 -> 25;
               case 21 -> 51;
               case 22 -> 38;
               case 23 -> 18;
               case 24 -> 61;
               case 25 -> 62;
               case 26 -> 60;
               case 27 -> 55;
               case 28 -> 56;
               case 29 -> 15;
               case 30 -> 40;
               case 31 -> 14;
               case 32 -> 32;
               case 33 -> 28;
               case 34 -> 27;
               case 35 -> 48;
               case 36 -> 63;
               case 37 -> 57;
               case 38 -> 33;
               case 39 -> 10;
               case 40 -> 30;
               case 41 -> 2;
               case 42 -> 6;
               case 43 -> 26;
               case 44 -> 1;
               case 45 -> 13;
               case 46 -> 19;
               case 47 -> 8;
               case 48 -> 41;
               case 49 -> 36;
               case 50 -> 21;
               case 51 -> 54;
               case 52 -> 52;
               case 53 -> 31;
               case 54 -> 7;
               case 55 -> 50;
               case 56 -> 39;
               case 57 -> 11;
               case 58 -> 0;
               case 59 -> 17;
               case 60 -> 49;
               case 61 -> 45;
               case 62 -> 42;
               default -> 5;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/shader/ShaderUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 1549;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/utils/shader/ShaderUtils", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 254 && var8 != 232 && var8 != 202 && var8 != 'L') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'w') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 't') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 254) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 232) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static void x(String a, long name, float... a) {
      int loc;
      label25: {
         label24: {
            name = 126517117157397L ^ name;
            int[] var10000 = c<"t">(2446433739705109574L, (long)name);
            loc = GL20.glGetUniformLocation(c<"Ê">(2448866240331625719L, (long)name), a);
            int[] ax = var10000;
            switch (((Object[])a).length) {
               case 1:
                  GL20.glUniform1f(loc, (float)((Object[])a)[0]);
                  var10000 = ax;
                  if (name <= 0L) {
                     break;
                  }

                  if (ax == null) {
                     return;
                  }
               case 2:
                  GL20.glUniform2f(loc, (float)((Object[])a)[0], (float)((Object[])a)[1]);
                  var10000 = ax;
                  break;
               case 3:
                  break label24;
               case 4:
                  break label25;
               default:
                  return;
            }

            if (var10000 == null) {
               return;
            }
         }

         GL20.glUniform3f(loc, (float)((Object[])a)[0], (float)((Object[])a)[1], (float)((Object[])a)[2]);
      }

      GL20.glUniform4f(loc, (float)((Object[])a)[0], (float)((Object[])a)[1], (float)((Object[])a)[2], (float)((Object[])a)[3]);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/shader/ShaderUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public static void c(int[] var0) {
      何树友何何何何何树何 = var0;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   public static void h(int a, long a) {
      a = 126517117157397L ^ a;
      c<"t">(-6492470716784064429L, a);
      if (c<"Ê">(-6491525374881877790L, a) != 0.5F) {
         GL20.glUseProgram((int)a);
         c<"L">((int)a, -6491525374881877790L, a);
      }
   }

   public static void f(long a, PoseStack blurRadius, float poseStack, float isPre, float radius, float width, float a, float var8, Color color, boolean x) {
      a = 126517117157397L ^ a;
      long ax = a ^ 23589950997326L;
      c<"t">(7916802476205408363L, (long)a);
      if (c<"Ê">(7917285132017435522L, (long)a)) {
         Event.Side var10000 = c<"Ê">(7917180291871870213L, (long)a);
         if (a > 0L) {
            if (var10000 == null) {
               return;
            }

            var10000 = c<"Ê">(7917180291871870213L, (long)a);
         }

         if (var10000 != c<"Ê">(7917107704137618619L, (long)a)) {
            c<"Ê">(7913308740289816844L, (long)a).X(blurRadius, ax, (float)poseStack, (float)isPre, radius, width, (float)a, var8, color);
            return;
         }
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   public static void d(long a) {
      long ax = 126517117157397L ^ a ^ 1991375740945L;
      int width = mc.getWindow().getGuiScaledWidth();
      int height = mc.getWindow().getGuiScaledHeight();
      m(0.0F, 0.0F, ax, width, height);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   public static int a(long a, int var2, String type, String shaderName) {
      a = 126517117157397L ^ a;
      int shader = GL20.glCreateShader(var2);
      c<"t">(3588246242796067961L, (long)a);
      GL20.glShaderSource(shader, type);
      GL20.glCompileShader(shader);
      if (GL20.glGetShaderi(shader, b<"i">(2705, 5585287923748978006L ^ a)) == 0) {
         String log = GL20.glGetShaderInfoLog(shader, 1024);
         GL20.glDeleteShader(shader);
         throw new RuntimeException(shaderName + a<"k">(30169, 5773476685658954996L ^ a) + log);
      } else {
         return shader;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/shader/ShaderUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 22755;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/shader/ShaderUtils", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[G*%(;ª\u0096Ø!U\u0012Ð\u0098%\u0084®(ê)\u0003I£3Ý, ®\u0094Þ\u0082Ûeµf]Bû\u0096ô¢Ì\u0093\u009eþÎ\u001f\u0086\u0081@Î\u0089\u0011Q¦ì\u0004ÛG, £¬»QÑ\u001eH`\u0004qjíõ¥\u009aOé¦YJ\\b\u008c\u0000©¡ªü\u00970\u009aãg°b\u0017¬Í\u0002\u0003, »¬z1ÿ\bõº\u0081\u0004Å\"ß\u0006¡\u008a¶+\u000bC\u009c\u0004²ø`\u0097ÜÔ\u009f\u0011g\u0097, q¥äríJ'H|§í¶ª°c\u008a\b.V'Ãný\u00102û\u001fÂÄYÜ³, ^Ûæ=C!Nf\u0084\u0080(\u009b\u0092\u0084CíÏÒ\u0092\u009cKñ\u0016öÎ\u0001dk\u0087\u0099¬i:ÉE\u009e\u0010\u008e\u0091¦¸#\u00ad\u0091?ÐÄ")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   public static void a(PoseStack a, float a, float var2, float color, float y, float isPre, float x, long height, Color bloomRadius, boolean radius) {
      long ax = (long)(126517117157397L ^ height ^ 11027974093505L);
      C(a, (float)a, var2, (float)color, ax, y, (float)isPre, x, 0.8F, bloomRadius, (boolean)radius);
   }

   private static void a() {
      i[0] = "\u000fd\u001e\u0019\u0000r\u0000$S\u0012\no\u0005yXT\u001ai\u0005fCT\u001cu\rnU\bAN\u0004kT\u001f\u001dH\u0018c\\\t";
      i[1] = "\u001fW";
      i[2] = "%!&ZuV*akQ\u007fK/<`\u0017oM/#{\u0017iQ'+mK4栨伓会栙佬栋史伓会栙";
      i[3] = "=\u000bqR!\u00162K<Y+\u000b7\u00167\u001f+\u000f;\u000b+\u001f+\u000f;\u000b+B`<(\u00001Ej*7\u0001:";
      i[4] = boolean.class;
      j[4] = "java/lang/Boolean";
      i[5] = "l&\u0006o\u0006bg)\u0017 mve\"\u0000zAah";
      i[6] = "\u0013+='K\u001a\u001ckp,A\u0007\u00196{jQ\u0001\u0019)`jW\u001d\u0011!v6\n传桡桔但休可厾去厎变";
      i[7] = int.class;
      j[7] = "java/lang/Integer";
      i[8] = "\r\u0001eZfj\u0004\u000ff\u0013%g\u0002\u000fr\u00118a@\u0018m\u0006\u007f`\u0016@^\u0011yq\u000b\u0016N\u001byh\u000f\u001a,9da\u000b";
      i[9] = "U\"\u000f@\u0013eZbBK\u0019x_?I\r\u0011eR9MFRGY(TO\u0019";
      i[10] = "\u0002rY\u001c\u0004L6QV\\IG<LS\u0001B\u00014Q^\u0007FJwsU\u0016_C<\u0005";
      i[11] = ">\u0017Vv!\u00007\u0019U?b\r1\u0019A=\u007f\u000bs\u000e^*8\n%V\u007f=*\u000e(\u0014O\u000e)\u001d)\u001dC\u001e#\u001d0\u0019O";
      i[12] = "K\u00138{\u0014YB\u001d;2WTD\u001d/0JR\u0006\n0'\rSPR\u00030\u000bBM\u0004\u0013:\u000b[I\b";
      i[13] = "OaxwJH{Bw7\u0007Cq_rj\f\u0005yB\u007fl\bN:`t}\u0011Gq\u0016";
      i[14] = void.class;
      j[14] = "java/lang/Void";
      i[15] = "R\u0017";
      i[16] = "HdSqgkVlI>\u0005wQq";
      i[17] = "C;v\u0010\u0015^L{;\u001b\u001fCI&0]\u000fEI9+]\tYA1=\u0001T叺叫伀桉厸桫栠併伀厓";
      i[18] = "x)lnd\u0001wi!en\u001cr4*#~\u001ar+1#x\u0006z#'\u007f%伻低伒桓佘佞桿低厌桓";
      i[19] = "\u001dDaCI:\u0012\u0004,HC'\u0017Y'\u000eS!\u0017F<\u000eQ'\u001fZ?ET{7}=AV%\u001bX";
      i[20] = "\u0001\b\u0000A\u000eK\u000f\u0019\u000f\nAW\u0001\u001d\u0000\u0006\u0001\\@\u0016\b\b[Q@6\b\b\b^\u001c";
      i[21] = "\u0007\u00045m\"\u001a\f\u000b$\"C\u0014\u0007\u0000 x";
      i[22] = "d:{\u0004;Y<!\u007fi桙佯叄伀发桰伝叱叄厞\u0012\u0003'\\g3pP#Cm";
      i[23] = "S9q\t\u0001$\u0000?r\u000be\u00050J^;ebW`{\u0004\u001d1Qcy";
      i[24] = "lLAw+S4WE\u001a28fO\u0014do\u0002}L\u0018yP";
      i[25] = "W!?\u001eKz\u000f:;s[\u0011]\"j\r\u000f+F!f\u00100x\t+4\u001eMt\u000fz$s";
      i[26] = "\u0017/@)'E\u000b.^._N\u001c+Tz%*\u0016*Xuf\u0014@+K|";
      i[27] = "[y\u0017-|&\u0003b\u0013@栞桔校佃伣桙叄厎校佃~yxrAl\u000f,cpV";
      i[28] = "qe+J\n2{;q^f\u000f\fXG'\\1{nwBVo!z";
      i[29] = "$v\u000etzF|m\n\u0019作佰会佌厤佄参叮会佌g#g\u001d*}\u0002)9G>";
      i[30] = "\u0010Y 3\u0002h\u0014@;-\u007f^.\u000em/\u0013wV])qE\f";
      i[31] = "\u001c\u0012\f\u001a[ED\t\bw佽佳厼桬桼桮根样厼伨eL\u001eCG\u0012\u000bJ\u0010G\u000e";
      i[32] = "{|PD6\u0016)kWTII\u00132\n\rp\u0018\u0013\u0002\u0007[&\u001c6=L\u0002;C";
      i[33] = "%\u0011\u0003\t\u0019i!\b\u0018\u0017dS\u001bFN\u0015\bvc\u0015\nK^\rrJ\u001e\u0012\tp~LO\u0002d";
      i[34] = "{$o1wx#?k\\佑叐叛伞叅企叏叐叛桚\u000676\"tzw>~s#";
      i[35] = ";I6xSfcR2\u0015A\rcSg%C|4\u0010o\u007f(6%\u0016o~Yaf\u001e5\u0015";
      i[36] = "H+\u001b\u0010@:\u00100\u001f}佦伌佶桕桫厾佦伌叨厏rAP>[<K\u0002T(@";
      i[37] = "5ecnt<m~g\u0003双桎厕佟叉叀佒厔厕叁\n?~+$okx~2:";
      i[38] = "P=\r\f{0\b&\ta栙伆佮桃厧桸佝厘株桃d\nq ^>\u001e\u00188dX";
   }

   public static void m(float a, float width, long a, float height, float x) {
      a = 126517117157397L ^ a;
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      Tesselator tesselator = Tesselator.getInstance();
      BufferBuilder buffer = tesselator.getBuilder();
      buffer.begin(c<"Ê">(7393210155677806180L, a), c<"Ê">(7391570408917174875L, a));
      c<"t">(7393249705588296495L, a);
      buffer.vertex(0.0, 0.0, 0.0).uv(0.0F, 0.0F).endVertex();
      buffer.vertex(a, width + x, 0.0).uv(0.0F, 1.0F).endVertex();
      buffer.vertex(a + height, width + x, 0.0).uv(1.0F, 1.0F).endVertex();
      buffer.vertex(a + height, width, 0.0).uv(1.0F, 0.0F).endVertex();
      tesselator.end();
      c<"t">(new Module[3], 7391648300989476791L, a);
   }

   public static void o(PoseStack a, long color, float x, float radius, float width, float height, float poseStack, Color a) {
      v(a, x, 140457143687048L, radius, width, height, (float)poseStack, a, true);
   }

   public static void init() {
      j();
      if (!何何友树树树树树友何) {
         try {
            Iterator e = 树何友何友树何友友友.iterator();
            if (e.hasNext()) {
               友友树友树友树何树友 renderer = (友友树友树友树何树友)e.next();
               renderer.Z(new Object[]{10923802530137L});
            }

            何何友树树树树树友何 = true;
            IWrapper.logger.info("Shader initialized successfully.");
         } catch (Exception var7) {
            IWrapper.logger.error("Failed to initialize Shader: {}", var7.getMessage());
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static int g(long a, String a) {
      a = 126517117157397L ^ a;
      return GL20.glGetUniformLocation(c<"Ê">(-511701934208094739L, (long)a), a);
   }

   public static void v(PoseStack a, float color, long isPre, float height, float x, float width, float poseStack, Color a, boolean var9) {
      isPre = (boolean)(126517117157397L ^ isPre);
      long ax = isPre ^ 134146333086893L;
      c<"t">(6312679975251163694L, (long)isPre);
      if (c<"Ê">(6312601870470265287L, (long)isPre)) {
         Event.Side var10000 = c<"Ê">(6312494796921780032L, (long)isPre);
         if (isPre >= 0L) {
            if (var10000 == null) {
               return;
            }

            var10000 = c<"Ê">(6312494796921780032L, (long)isPre);
         }

         if (var10000 != c<"Ê">(6312413453027421950L, (long)isPre)) {
            c<"Ê">(6312920381473306603L, (long)isPre).o(a, (float)color, height, ax, x, width, (float)poseStack, a);
            return;
         }
      }
   }

   public static int[] j() {
      return 何树友何何何何何树何;
   }

   public static void w(long a, PoseStack a, float var3, float height, float y, float poseStack, float width, float x, Color color) {
      C(a, var3, 6.0F, 16.0F, 51247878996626L, 16.0F, 5.0F, 6.0F, 0.8F, color, true);
   }

   public static int w(int a, int attribLocations, String a, String[] var3, long fragmentShader) {
      int programId;
      String var13;
      label46: {
         fragmentShader = (int)(126517117157397L ^ fragmentShader);
         int[] var10000 = c<"t">(-1231596130328870051L, (long)fragmentShader);
         programId = GL20.glCreateProgram();
         int[] ax = var10000;
         GL20.glAttachShader(programId, (int)a);
         GL20.glAttachShader(programId, (int)attribLocations);
         int i = 0;
         if (0 < var3.length) {
            var13 = var3[0];
            int[] var10001 = ax;
            if (fragmentShader > 0L) {
               if (ax != null) {
                  break label46;
               }

               var10001 = ax;
            }

            label40: {
               if (var10001 == null) {
                  if (var13 == null) {
                     break label40;
                  }

                  var13 = var3[0];
               }

               if (!var13.isEmpty()) {
                  GL20.glBindAttribLocation(programId, 0, var3[0]);
               }
            }

            i++;
         }

         GL20.glLinkProgram(programId);
         GL20.glDetachShader(programId, (int)a);
         GL20.glDetachShader(programId, (int)attribLocations);
         int var14 = GL20.glGetProgrami(programId, b<"i">(3835, 8262536773840823833L ^ fragmentShader));
         if (fragmentShader >= 0L) {
            if (var14 == 0) {
               var13 = GL20.glGetProgramInfoLog(programId, 1024);
               break label46;
            }

            GL20.glDeleteShader((int)a);
            GL20.glDeleteShader((int)attribLocations);
            var14 = programId;
         }

         if (fragmentShader > 0L && c<"t">(-1231211970947351206L, (long)fragmentShader) == null) {
            c<"t">(new int[3], -1231683176352637265L, (long)fragmentShader);
         }

         return var14;
      }

      String log = var13;
      GL20.glDeleteProgram(programId);
      throw new RuntimeException(a + a<"k">(31895, 131134898571201178L ^ fragmentShader) + log);
   }

   public static void u(PoseStack a, float color, float x, long width, float a, float var6, float y, float poseStack, Color height) {
      f(134876411915725L, a, (float)color, x, 122.0F, var6, y, (float)poseStack, height, true);
   }

   public static void X(long var0) {
      var0 = 126517117157397L ^ var0;
      c<"t">(7103025606314430246L, var0);
      if (c<"Ê">(7105660412777920407L, var0) != 0) {
         GL20.glUseProgram(0);
         c<"L">(0, 7105660412777920407L, var0);
      }
   }

   public static void M(
      long a, PoseStack width, float cornerRadius, float a, float var5, float borderWidth, float fillColor, float x, Color height, Color poseStack, float y
   ) {
      T(width, 8.0F, (float)a, var5, 26.0F, (float)fillColor, x, height, poseStack, 116081869717546L, y, true);
   }

   public static void N(float a, float height, long width) {
      long ax = (long)(126517117157397L ^ width ^ 116573910269868L);
      m(0.0F, 0.0F, ax, (float)a, height);
   }

   public static int W(int a, String program) {
      return GL20.glGetUniformLocation((int)a, program);
   }

   public static void T(
      PoseStack a,
      float y,
      float poseStack,
      float width,
      float height,
      float fillColor,
      float borderColor,
      Color x,
      Color blurRadius,
      long isPre,
      float a,
      boolean var12
   ) {
      isPre = (boolean)(126517117157397L ^ isPre);
      long ax = isPre ^ 59440362689021L;
      c<"t">(-9207272094228091508L, (long)isPre);
      if (c<"Ê">(-9207385303388295579L, (long)isPre)) {
         Event.Side var10000 = c<"Ê">(-9207492067679411998L, (long)isPre);
         if (isPre >= 0L) {
            if (var10000 == null) {
               return;
            }

            var10000 = c<"Ê">(-9207492067679411998L, (long)isPre);
         }

         if (var10000 != c<"Ê">(-9207569054332389028L, (long)isPre)) {
            c<"Ê">(-9207746822876769661L, (long)isPre)
               .X(a, y, (float)poseStack, width, ax, height, (float)fillColor, (float)borderColor, x, blurRadius, (float)a);
            return;
         }
      }
   }

   public static void onSide(Event.Side side) {
      何何何何友何友友何何 = side;
   }

   public static void Q(PoseStack a, float height, float y, long cornerRadius, float var5, float width, float poseStack) {
      long ax = (long)(126517117157397L ^ cornerRadius ^ 107045691798552L);
      Color glassColor = new Color(255, 255, 255, 60);
      Color borderColor = new Color(255, 255, 255, 180);
      M(ax, a, height, y, var5, width, (float)poseStack, 1.5F, borderColor, glassColor, 8.0F);
   }

   private static String HE_JIAN_GUO() {
      return "我是何树友";
   }

   public static void G(PoseStack a, float color, float a, float var3, Color poseStack, long x, boolean y) {
      x = 126517117157397L ^ x;
      long ax = (long)(x ^ 66274551258832L);
      c<"t">(-7677129651540002624L, (long)x);
      if (c<"Ê">(-7677333031935313111L, (long)x)) {
         Event.Side var10000 = c<"Ê">(-7677507965942630994L, (long)x);
         if (x >= 0L) {
            if (var10000 == null) {
               return;
            }

            var10000 = c<"Ê">(-7677507965942630994L, (long)x);
         }

         if (var10000 != c<"Ê">(-7677426616475096048L, (long)x)) {
            c<"Ê">(-7677089115899300603L, (long)x).h(a, (float)color, (float)a, ax, var3, poseStack);
            return;
         }
      }
   }
}
