package cn.cool.cherish.utils.helper;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 树友友友树友友何树何 implements 何树友 {
   public double 树何何友树友何树友树;
   public double 友友何友何友友友何树;
   public double 树何树友友树树何何友;
   private static final long a;
   private static final Object[] b = new Object[11];
   private static final String[] c = new String[11];
   private static String HE_JIAN_GUO;

   public 树友友友树友友何树何(long a, double x, double y, double z) {
      a = 树友友友树友友何树何.a ^ a;
      super();
      a<"ë">(this, x, -6975631816278995814L, a);
      a<"ë">(this, y, -6975288622452846607L, a);
      a<"ë">(this, z, -6975373744414820515L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(5631278694371104388L, 3043300778180978126L, MethodHandles.lookup().lookupClass()).a(261586935780272L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   @Override
   public boolean equals(Object obj) {
      long a = 树友友友树友友何树何.a ^ 19360077101353L;
      a<"Ü">(5532275362104069956L, a);
      if (obj instanceof 树友友友树友友何树何) {
         ;
      }

      return false;
   }

   public double B(long a) {
      a = 树友友友树友友何树何.a ^ a;
      return a<"r">(this, -5646163356754763249L, (long)a);
   }

   public double C(树友友友树友友何树何 a, long vector3d) {
      vector3d = 树友友友树友友何树何.a ^ vector3d;
      return Math.sqrt(
         Math.pow(a<"r">(a, -6240680677554767153L, (long)vector3d) - a<"r">(this, -6240680677554767153L, (long)vector3d), 2.0)
            + Math.pow(a<"r">(a, -6239739641395873372L, (long)vector3d) - a<"r">(this, -6239739641395873372L, (long)vector3d), 2.0)
            + Math.pow(a<"r">(a, -6239938880630275832L, (long)vector3d) - a<"r">(this, -6239938880630275832L, (long)vector3d), 2.0)
      );
   }

   public 树友友友树友友何树何 J(long a, double var3, double var5, double var7) {
      long ax = 树友友友树友友何树何.a ^ a ^ 107298397801371L;
      return this.t(-var3, -var5, -var7, ax);
   }

   public 树友友友树友友何树何 S(树友友友树友友何树何 a, long vector) {
      vector = 树友友友树友友何树何.a ^ vector;
      long ax = vector ^ 32791681361197L;
      return this.t(
         -a<"r">(a, 9017790322433322638L, (long)vector), -a<"r">(a, 9018168683181059557L, (long)vector), -a<"r">(a, 9017980920099083593L, (long)vector), ax
      );
   }

   public double V(long a) {
      a = 树友友友树友友何树何.a ^ a;
      return a<"r">(this, 6199446474611689163L, (long)a);
   }

   public void e(double a, long var3) {
      var3 = 树友友友树友友何树何.a ^ var3;
      a<"ë">(this, (double)a, 300029476098692330L, var3);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public 树友友友树友友何树何 c(double a, long var3) {
      var3 = 树友友友树友友何树何.a ^ var3;
      long ax = var3 ^ 58604984171637L;
      return new 树友友友树友友何树何(
         ax, a<"r">(this, 1633304233721693441L, var3) * a, a<"r">(this, 1633102052530275946L, var3) * a, a<"r">(this, 1632912030296571590L, var3) * a
      );
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      b[0] = "/6&GBh vkLHu%+`\nXs%4{\nEb (mV\u0003栖厇厓參栵另双伙桉佝";
      b[1] = double.class;
      c[1] = "java/lang/Double";
      b[2] = "\u0001\u0005\u0012=r+\n\n\u0003r\u000e2\u0005\u0010\r19\u0002\u0013\u0007\u0001,(.\u0004\n";
      b[3] = "jC7r5-e\u0003zy?0`^q?/6`Aj?2'e]|ct\u0010fYxe3-g";
      b[4] = "\"\u001aX}\u00033\u00169W=N8\u001c$R`E~\u00149_fA5W\u001bTwX<\u001cm";
      b[5] = "k\u0003\\\u0001<)`\fMN]'k\u0007I\u0014";
      b[6] = "7\u000f\u000f\u001bdak\u001bMP_\u0005\rY\t\u0017o74]Q\u0013:[";
      b[7] = "\f\u0014=1\u0006J\u001f\u0001jU桧伬伽厮栟厖伣桨厣桴\u0006%\u0004I\u000e\ri/\f\u0001";
      b[8] = "\u007f~\u0005,IelkRH栨伃栊叄叽桑栨伃低叄>8Kf}gQ2C.";
      b[9] = "\u000b\r\u0016Ug6\u0018\u0018A1v\r^\u000f\u0014\t#v\r\u0013H]\u001f4\u001cM\u0015\rdg\u0000\u0011A1";
      b[10] = "\u0001O$Y\u0019:\u0012Zs=厢参估叵佂叾厢参估栯\u001fM\u001b9\u0003VpG\u0013q";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'r' && var8 != 235 && var8 != '$' && var8 != 209) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'K') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 220) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'r') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 235) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/helper/树友友友树友友何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 43;
               case 1 -> 33;
               case 2 -> 4;
               case 3 -> 41;
               case 4 -> 53;
               case 5 -> 5;
               case 6 -> 23;
               case 7 -> 21;
               case 8 -> 26;
               case 9 -> 42;
               case 10 -> 46;
               case 11 -> 14;
               case 12 -> 60;
               case 13 -> 35;
               case 14 -> 12;
               case 15 -> 63;
               case 16 -> 8;
               case 17 -> 54;
               case 18 -> 18;
               case 19 -> 32;
               case 20 -> 13;
               case 21 -> 2;
               case 22 -> 55;
               case 23 -> 27;
               case 24 -> 57;
               case 25 -> 15;
               case 26 -> 31;
               case 27 -> 19;
               case 28 -> 36;
               case 29 -> 62;
               case 30 -> 6;
               case 31 -> 24;
               case 32 -> 9;
               case 33 -> 38;
               case 34 -> 48;
               case 35 -> 20;
               case 36 -> 29;
               case 37 -> 52;
               case 38 -> 59;
               case 39 -> 7;
               case 40 -> 50;
               case 41 -> 30;
               case 42 -> 1;
               case 43 -> 56;
               case 44 -> 11;
               case 45 -> 39;
               case 46 -> 61;
               case 47 -> 22;
               case 48 -> 40;
               case 49 -> 28;
               case 50 -> 25;
               case 51 -> 34;
               case 52 -> 58;
               case 53 -> 37;
               case 54 -> 47;
               case 55 -> 16;
               case 56 -> 44;
               case 57 -> 3;
               case 58 -> 10;
               case 59 -> 0;
               case 60 -> 17;
               case 61 -> 49;
               case 62 -> 45;
               default -> 51;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   public 树友友友树友友何树何 t(double a, double var3, double var5, long var7) {
      var7 = 树友友友树友友何树何.a ^ var7;
      long ax = var7 ^ 51151480555321L;
      return new 树友友友树友友何树何(
         ax, a<"r">(this, 7919213002816552525L, var7) + a, a<"r">(this, 7918993229172718886L, var7) + var3, a<"r">(this, 7918840109298779530L, var7) + var5
      );
   }

   public void t(double a, long var3) {
      var3 = 树友友友树友友何树何.a ^ var3;
      a<"ë">(this, (double)a, -8864108013544313709L, var3);
   }

   public double g(long a) {
      a = 树友友友树友友何树何.a ^ a;
      return a<"r">(this, -2361211566448887980L, (long)a);
   }

   public double j(long a) {
      a = 树友友友树友友何树何.a ^ a;
      return Math.sqrt(
         a<"r">(this, -6642569651361992581L, (long)a) * a<"r">(this, -6642569651361992581L, (long)a)
            + a<"r">(this, -6641821820479606000L, (long)a) * a<"r">(this, -6641821820479606000L, (long)a)
            + a<"r">(this, -6641904262382007364L, (long)a) * a<"r">(this, -6641904262382007364L, (long)a)
      );
   }

   public void z(long a, double var3) {
      a = 树友友友树友友何树何.a ^ a;
      a<"ë">(this, var3, -4883700321115623534L, (long)a);
   }

   public 树友友友树友友何树何 y(long a, 树友友友树友友何树何 a) {
      a = 树友友友树友友何树何.a ^ a;
      long ax = a ^ 81792741171202L;
      return this.t(a<"r">(a, -573374199148876895L, (long)a), a<"r">(a, -573734985026787126L, (long)a), a<"r">(a, -573898412830945178L, (long)a), ax);
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖国企变私企";
   }
}
