package cn.cool.cherish.utils.helper;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

public class Rotation implements IWrapper, 何树友 {
   private float 何友何友树何树何何树 = 0.0F;
   private float 树友树友何树友友树何;
   private static String[] 何何何友树友友树树树;
   private static final long a;
   private static final Object[] b = new Object[20];
   private static final String[] c = new String[20];
   private static String HE_WEI_LIN;

   public Rotation(long a, float yaw, float pitch) {
      this.树友树友何树友友树何 = pitch;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2723610611309756827L, 5976495827385912102L, MethodHandles.lookup().lookupClass()).a(25702403405495L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (E() == null) {
         F(new String[2]);
      }
   }

   public static void F(String[] var0) {
      何何何友树友友树树树 = var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 10;
               case 1 -> 42;
               case 2 -> 63;
               case 3 -> 35;
               case 4 -> 13;
               case 5 -> 46;
               case 6 -> 41;
               case 7 -> 26;
               case 8 -> 27;
               case 9 -> 57;
               case 10 -> 48;
               case 11 -> 3;
               case 12 -> 22;
               case 13 -> 18;
               case 14 -> 0;
               case 15 -> 56;
               case 16 -> 11;
               case 17 -> 28;
               case 18 -> 25;
               case 19 -> 60;
               case 20 -> 6;
               case 21 -> 54;
               case 22 -> 45;
               case 23 -> 5;
               case 24 -> 15;
               case 25 -> 16;
               case 26 -> 43;
               case 27 -> 61;
               case 28 -> 49;
               case 29 -> 50;
               case 30 -> 21;
               case 31 -> 17;
               case 32 -> 23;
               case 33 -> 34;
               case 34 -> 44;
               case 35 -> 12;
               case 36 -> 4;
               case 37 -> 14;
               case 38 -> 47;
               case 39 -> 37;
               case 40 -> 31;
               case 41 -> 52;
               case 42 -> 8;
               case 43 -> 39;
               case 44 -> 32;
               case 45 -> 55;
               case 46 -> 58;
               case 47 -> 33;
               case 48 -> 7;
               case 49 -> 20;
               case 50 -> 29;
               case 51 -> 9;
               case 52 -> 40;
               case 53 -> 59;
               case 54 -> 24;
               case 55 -> 1;
               case 56 -> 51;
               case 57 -> 19;
               case 58 -> 53;
               case 59 -> 30;
               case 60 -> 36;
               case 61 -> 2;
               case 62 -> 38;
               default -> 62;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   public void e(long a, double var3) {
      a = 116716717862434L ^ a;
      long ax = a ^ 3049761079124L;
      long axx = a ^ 23625664538986L;
      a<"Ú">(-9103507662326071783L, (long)a);
      double f = var3 * 0.6F + 0.2F;
      double gcd = f * f * f * 1.2F;
      Rotation rotation = new Rotation(ax, a<"g">(this, -9102198348140046513L, (long)a), a<"g">(this, -9103547681403131976L, (long)a));
      float deltaYaw = a<"g">(this, -9102198348140046513L, (long)a) - rotation.getYaw();
      deltaYaw -= (float)(deltaYaw % gcd);
      a<"ë">(this, rotation.getYaw() + deltaYaw, -9102198348140046513L, (long)a);
      float deltaPitch = a<"g">(this, -9103547681403131976L, (long)a) - rotation.l(axx);
      deltaPitch -= (float)(deltaPitch % gcd);
      a<"ë">(this, rotation.l(axx) + deltaPitch, -9103547681403131976L, (long)a);
      a<"Ú">(new Module[2], -9102188757099069745L, (long)a);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'g' && var8 != 235 && var8 != 238 && var8 != 'o') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 225) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 218) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'g') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 235) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 238) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public static float h(float a, long a) {
      a = 116716717862434L ^ a;
      a<"Ú">(-6756095120236814963L, a);
      return mc.player == null ? 0.0F : mc.player.getYRot() + Mth.wrapDegrees(a - mc.player.getYRot());
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public float l(long a) {
      return this.树友树友何树友友树何;
   }

   public static Rotation l(Rotation a, long a) {
      long var10000 = 116716717862434L ^ a;
      long ax = 116716717862434L ^ a ^ 138884076271708L;
      long axx = 116716717862434L ^ a ^ 81341209365182L;
      long axxx = var10000 ^ 31125356904682L;
      long axxxx = var10000 ^ 103630805441664L;
      return new Rotation(axx, h(a.getYaw(), ax), m(axxx, a.l(axxxx)));
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/helper/Rotation" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "hm\u001efrbg-Smx\u007fbpX+hyboC+uhgsUw3_dwQqtbe";
      b[1] = float.class;
      c[1] = "java/lang/Float";
      b[2] = "U\\OnW\u0018 |DaFW]dWfO\u001e5";
      b[3] = ",j(j\u0010}'e9%ld(\u007f7f[T>h;{Jx)e";
      b[4] = "Nc\u001aWd5Nc\r\u000bh:T(\r\u0015`9Nr@4`2Ee\u001c\u0018o(";
      b[5] = "^7\"G|B^75\u001bpMD|5\u0005xN^&x&a_Y=8\u001a";
      b[6] = "fKDy\u0016S\u0013kOv\u0007\u001cns\\q\u000eU\u0006";
      b[7] = void.class;
      c[7] = "java/lang/Void";
      b[8] = "T|M\u000e\u00001[<\u0000\u0005\n,^a\u000bC\u00021Sg\u000f\bA\u0013Xv\u0016\u0001\n";
      b[9] = "P\u001an\rtvd9aM9}n$d\u00102;f9i\u00166p%\u001bb\u0007/ynm";
      b[10] = "*\u0001\u001av$'\u001e\"\u00156i,\u0014?\u0010kbj\u001c\"\u001dmf!_\u0000\u0016|\u007f(\u0014v";
      b[11] = "\u000e_l\"\\_\u0005P}m=Q\u000e[y7";
      b[12] = "!\"\u001c\\o`7 \u001dfj\u0000p*\u0014[zc:\"X\b\u0003:2 [\u001f`p:l\bf";
      b[13] = "\fJ\u00077y\u0006\bE\u0003)Fm2K\u0001n9[\\\u001d_j,?";
      b[14] = "BhR\u000bI\u001bTjS1格厸栰叛併栨另厸栰佅(\b\u001a\tB'UX\u001bJW";
      b[15] = "u_\u001b\n\u0006~c]\u001a0'\u001e\"D\u0006M\u0014~#F\u0007Ij";
      b[16] = "<\u000f\u0002`3`;\u0019\u000e`IkQN\n\"w;Q\u007f\bxvbg\u001b]j;o";
      b[17] = "Oh\u0006c\u0014@Yj\u0007Y伥口佹叛桥伄桡佽佹栁|`GRO'\u00010F\u0011Z";
      b[18] = "\u0002#]3Gf\u0006,Y-x\u0001<\"[j\u0007;Rt\u0005n\u0012_\u0000l\u001d3\b>Yl\u0003)x";
      b[19] = "a\u000f\u001b?=(w\r\u001a\u0005\u001fH6\u0014\u0006x/(7\u0016\u0007|Qt{\u0006\u0006u0-{\u0018\u001c\u0005";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public static float m(long a, float var2) {
      a = 116716717862434L ^ a;
      a<"Ú">(-2698811394042059461L, (long)a);
      if (mc.player == null) {
         return 0.0F;
      } else {
         float finalPitch = mc.player.getXRot() + Mth.wrapDegrees(var2 - mc.player.getXRot());
         return Mth.clamp(finalPitch, -90.0F, 90.0F);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void E(long a, Player a) {
      String[] var7 = E();
      if (!Float.isNaN(this.何友何友树何树何何树)) {
         Rotation var10000 = this;
         if (var7 != null) {
            if (Float.isNaN(this.树友树友何树友友树何)) {
               return;
            }

            var10000 = this;
         }

         Object[] var10004 = new Object[]{null, (Double)mc.options.sensitivity().get()};
         var10004[0] = 136030260129672L;
         var10000.e(var10004);
         a.setYRot(this.何友何友树何树何何树);
         a.setXRot(this.树友树友何树友友树何);
      }
   }

   public static String[] E() {
      return 何何何友树友友树树树;
   }

   public void L(float a, long a) {
      a = 116716717862434L ^ a;
      a<"ë">(this, (float)a, -2208429140440680517L, a);
   }

   public void P(float a, long a) {
      a = 116716717862434L ^ a;
      a<"ë">(this, (float)a, 3520911464751961805L, a);
   }

   private static String HE_DA_WEI() {
      return "何炜霖黑水";
   }

   public float getYaw() {
      return this.何友何友树何树何何树;
   }
}
