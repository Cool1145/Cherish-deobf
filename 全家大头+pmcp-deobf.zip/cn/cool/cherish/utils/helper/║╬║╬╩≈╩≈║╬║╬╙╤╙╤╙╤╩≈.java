package cn.cool.cherish.utils.helper;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.unsafe.UnsafeUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class 何何树树何何友友友树 implements 何树友 {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[13];
   private static final String[] f = new String[13];
   private static int _何树友被何大伟克制了 _;

   private 何何树树何何友友友树(long a) {
      a = 34420308253434L ^ a;
      super();
      throw new UnsupportedOperationException(a<"g">(27121, 7376044378359890010L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-1126099131484601710L, 7847174961952501377L, MethodHandles.lookup().lookupClass()).a(146347802752071L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(43627363612502L << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 'X';
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "\u008bz\\á\u007f@Ï\u0082\u0002Ü\u0095·ÚWG9\u00888\u009d~)\u0006A\fdÏíÿû\u0018¹5\u0003ÞfÓI,Æ2³\u0085-x4Ù\u0094w\u009bMtö?\u0089Êe.òò¼\u0094\u0010\u0001\u0099?ÁÄA§9B\u0011;\bµå·èê\u001bi\u009fåIµH\u001d\nPîv\u0010ö%*ÀYsc×P°e$¡ö¿\u0001¨\u0096rr7ç.c]N\u009c\u008fûkþ\u0083øârWé\\ì±L\u001c\u0087µÕ`Hj\u0081Ú\u001cÑA¦\u0004AÈ\\\u0004á\u008aßÜJW)Ð«\u000e\u0007\u008fáç\r}\u008c¢"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 169) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "\u008bz\\á\u007f@Ï\u0082\u0002Ü\u0095·ÚWG9\u00888\u009d~)\u0006A\fdÏíÿû\u0018¹5\u0003ÞfÓI,Æ2³\u0085-x4Ù\u0094w\u009bMtö?\u0089Êe.òò¼\u0094\u0010\u0001\u0099?ÁÄA§9B\u0011;\bµå·èê\u001bi\u009fåIµH\u001d\nPîv\u0010ö%*ÀYsc×P°e$¡ö¿\u0001¨\u0096rr7ç.c]N\u009c\u008fûkþ\u0083øârWé\\ì±L\u001c\u0087µÕ`Hj\u0081Ú\u001cÑA¦\u0004AÈ\\\u0004á\u008aßÜJW)Ð«\u000e\u0007\u008fáç\r}\u008c¢"
            .charAt(var4);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/helper/何何树树何何友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static Field n(long a, Class a, String... var3) {
      a = 34420308253434L ^ a;
      long ax = a ^ 62857056413364L;
      String[] axx = b<"à">(4779420518363238313L, (long)a);
      String[] var10000 = var3;
      if (a > 0L) {
         if (var3 == null) {
            throw new IllegalArgumentException(a<"g">(16979, 8541031163765644409L ^ a));
         }

         var10000 = var3;
      }

      if (var10000.length != 0) {
         Exception failed = null;
         Class<?> currentClass = a;

         label76:
         while (true) {
            Class var17 = currentClass;

            label73:
            while (var17 != null) {
               String[] var10 = var3;
               int var11 = var3.length;
               int var12 = 0;

               label70: {
                  while (true) {
                     if (var12 < var11) {
                        String fieldName = var10[var12];
                        var10000 = axx;
                        if (a <= 0L) {
                           break label70;
                        }

                        if (axx == null) {
                           break;
                        }

                        var10000 = axx;
                        if (a >= 0L) {
                           label57:
                           if (axx == null) {
                              try {
                                 Field f = currentClass.getDeclaredField(fieldName);
                                 f.setAccessible(true);
                                 var20 = f;
                                 if (a > 0L) {
                                    if ((f.getModifiers() & 16) != 0) {
                                       UnsafeUtils.g(f, UnsafeUtils.q(new Object[0]), f.getModifiers() & -17);
                                    }

                                    var20 = f;
                                 }
                              } catch (Exception var15) {
                                 failed = var15;
                                 break label57;
                              }

                              if (a >= 0L && b<"à">(4779194177801543027L, (long)a) == null) {
                                 b<"à">(new String[2], 4779306011164540061L, (long)a);
                              }

                              return var20;
                           }

                           var12++;
                           var10000 = axx;
                        }

                        if (var10000 != null) {
                           continue;
                        }
                     }

                     var17 = currentClass.getSuperclass();
                     if (a < 0L) {
                        continue label73;
                     }

                     currentClass = var17;
                     break;
                  }

                  var10000 = axx;
               }

               if (var10000 != null) {
                  continue label76;
               }
               break;
            }

            throw new 何何树树何何友友友树.友友树何何何何何何树(ax, failed);
         }
      } else {
         throw new IllegalArgumentException(a<"g">(16979, 8541031163765644409L ^ a));
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 241 && var8 != 'v' && var8 != 217 && var8 != 'Y') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'U') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 224) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 241) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'v') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 217) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 12;
               case 1 -> 61;
               case 2 -> 38;
               case 3 -> 28;
               case 4 -> 26;
               case 5 -> 30;
               case 6 -> 3;
               case 7 -> 35;
               case 8 -> 60;
               case 9 -> 50;
               case 10 -> 14;
               case 11 -> 57;
               case 12 -> 47;
               case 13 -> 13;
               case 14 -> 16;
               case 15 -> 44;
               case 16 -> 62;
               case 17 -> 33;
               case 18 -> 1;
               case 19 -> 40;
               case 20 -> 8;
               case 21 -> 17;
               case 22 -> 42;
               case 23 -> 9;
               case 24 -> 29;
               case 25 -> 25;
               case 26 -> 52;
               case 27 -> 58;
               case 28 -> 5;
               case 29 -> 48;
               case 30 -> 10;
               case 31 -> 37;
               case 32 -> 36;
               case 33 -> 39;
               case 34 -> 56;
               case 35 -> 63;
               case 36 -> 0;
               case 37 -> 11;
               case 38 -> 45;
               case 39 -> 24;
               case 40 -> 15;
               case 41 -> 46;
               case 42 -> 55;
               case 43 -> 6;
               case 44 -> 34;
               case 45 -> 21;
               case 46 -> 22;
               case 47 -> 53;
               case 48 -> 7;
               case 49 -> 18;
               case 50 -> 59;
               case 51 -> 41;
               case 52 -> 2;
               case 53 -> 31;
               case 54 -> 43;
               case 55 -> 23;
               case 56 -> 27;
               case 57 -> 32;
               case 58 -> 51;
               case 59 -> 54;
               case 60 -> 20;
               case 61 -> 19;
               case 62 -> 49;
               default -> 4;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      e[0] = ">*G\u0019f61j\n\u0012l+47\u0001T|-4(\u001aTa<14\f\b'\u000b20\b\u000e`63";
      e[1] = "\u0015\u000eg%Vh`.l*G'\u001d6\u007f-Nnu";
      e[2] = "\u001d\rE4\u001b-h-N;\nb\u00155]<\u0003+}";
      e[3] = void.class;
      f[3] = "java/lang/Void";
      e[4] = "\u0000#X\f4C\u000fc\u0015\u0007>^\n>\u001eA.X\n!\u0005A3I\u000f=\u0013\u001du佹伶桜桧伺伎叧厨历桧";
      e[5] = "k ~?Ab`/op*vb$x*\u0006ao";
      e[6] = "(-aJ\bW'm,A\u0002J\"0'\u0007\nW/6#LIu$':E\u0002";
      e[7] = "5%*}=A\u0001\u0006%=pJ\u000b\u001b `{\f\u0003\u0006-f\u007fG@$&wfN\u000bR";
      e[8] = "\u001c\u0013i3*Z\u0017\u001cx|KT\u001c\u0017|&";
      e[9] = "y4\u0016%\rq)n\u0007i1GE9VhRu$nVc\f\u0015";
      e[10] = "L\u0012Pa\u0011?B\u000b\u001d\u00192\\J\u000b\u001atO1\u0014D\u0019&\u007f";
      e[11] = "f.)S,rh7d+\f\u0011`7cFr|>x`\u0014B+5 a\u001b}j'';+";
      e[12] = "uVDT\u0005\u000bs\u0000NB?\u000bN\u0003VIC\u000es\u0002\u0013I\u0003buAKQS_t\u0004K\u0011?";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/helper/何何树树何何友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23674;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/helper/何何树树何何友友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String HE_DA_WEI() {
      return "何炜霖诈骗";
   }

   public static class 友友树何何何何何何树 extends RuntimeException implements 何树友 {
      private static final long serialVersionUID = 1L;
      private static final long a;
      private static final String b;
      private static String HE_WEI_LIN;

      public 友友树何何何何何何树(long a, Exception e) {
         long var10000 = 120647793564103L ^ a;
         super("Could not find field", e);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-7049874875203571895L, 3547591280156413560L, MethodHandles.lookup().lookupClass()).a(187315717271917L);
         // $VF: monitorexit
         a = var10000;
         Cipher var2;
         Cipher var4 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var3 = 1; var3 < 8; var3++) {
            var10003[var3] = (byte)(55961675646865L << var3 * 8 >>> 56);
         }

         var4.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String var5 = a(var2.doFinal("*[\u0086)H\u0083#D\u0001£UÐ>\"Ù\u0016\u0018Â2¥vh\u0015¼".getBytes("ISO-8859-1"))).intern();
         byte var10001 = -1;
         b = var5;
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static String HE_JIAN_GUO() {
         return "何炜霖大狗叫";
      }
   }
}
