package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.item.友何树何友树友树何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.AbstractCauldronBlock;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.BannerBlock;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.BarrierBlock;
import net.minecraft.world.level.block.BeaconBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.BellBlock;
import net.minecraft.world.level.block.BlastFurnaceBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BrewingStandBlock;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.CakeBlock;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.ComparatorBlock;
import net.minecraft.world.level.block.ComposterBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.DaylightDetectorBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.EndPortalBlock;
import net.minecraft.world.level.block.EndPortalFrameBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.FlowerPotBlock;
import net.minecraft.world.level.block.FungusBlock;
import net.minecraft.world.level.block.FurnaceBlock;
import net.minecraft.world.level.block.GrindstoneBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.PressurePlateBlock;
import net.minecraft.world.level.block.RepeaterBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.SignBlock;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SmokerBlock;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.StonecutterBlock;
import net.minecraft.world.level.block.StructureVoidBlock;
import net.minecraft.world.level.block.TntBlock;
import net.minecraft.world.level.block.TorchBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.TripWireBlock;
import net.minecraft.world.level.block.TripWireHookBlock;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.WebBlock;
import net.minecraft.world.level.block.piston.MovingPistonBlock;
import net.minecraft.world.level.block.piston.PistonHeadBlock;
import net.minecraft.world.level.block.state.BlockState;

public final class 友树友友何友树友树友 implements IWrapper, 何树友 {
   public static final List<Block> 友树友何何树友友树树;
   private static boolean 友何树友何友友友何友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[70];
   private static final String[] g = new String[70];
   private static String HE_DA_WEI;

   private 友树友友何友树友树友(long a) {
      a = 友树友友何友树友树友.a ^ a;
      super();
      throw new UnsupportedOperationException(a<"s">(8311, 3066962299463379069L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7069664085236231323L, -3666568025675755418L, MethodHandles.lookup().lookupClass()).a(126813702514118L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 78626087415891L;
      a();
      b<"â">(false, 9010371856351068622L, var9);
      Cipher var0;
      Cipher var12 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[3];
      int var5 = 0;
      char var3 = 'X';
      int var2 = -1;

      while (true) {
         String var14 = b(
               var0.doFinal(
                  "\u0085IqÿÝ\t¢\u008d\u0001ÐJøI\u0011ªã®Àx+\u008fsõÆ\u0087\u0004!Áµ\u00859ô\u0092Ï<¡w©6<Z\u008bä3éK\u0011\u0094ê\u001e\u008a\t:\u0012\u000f\u008f\u009dSa\u0099¤lPéÃª[p\u0097Í\u0019\u00830»«|ZÅ( G\u0096Ð\u0098h¯C\u001d\u0010N³\u0089aå-³DQÇã\u0095±Ç\u0085\u000e\u0010I\u000fX\u0096\u0093\u009egÇõàRÿ\u008e\u009a×ý"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var14;
         if ((var2 += var3) >= 122) {
            b = var7;
            c = new String[3];
            友树友何何树友友树树 = Arrays.asList(
               b<"V">(9009368841520616579L, var9),
               b<"V">(9008862543179679566L, var9),
               b<"V">(9009051773395210103L, var9),
               b<"V">(9010163383024088933L, var9),
               b<"V">(9010771599111120289L, var9),
               b<"V">(9010771599111120289L, var9),
               b<"V">(9012376022617992224L, var9),
               b<"V">(9011328062993860714L, var9),
               b<"V">(9012412509174369389L, var9),
               b<"V">(9010611765321864288L, var9),
               b<"V">(9008904337649247956L, var9),
               b<"V">(9008329915258075000L, var9),
               b<"V">(9010520535636786686L, var9),
               b<"V">(9008604934045575847L, var9),
               b<"V">(9011246990158798715L, var9),
               b<"V">(9010520535636786686L, var9),
               b<"V">(9007701971773856458L, var9),
               b<"V">(9008755462759951571L, var9),
               b<"V">(9011150645263150402L, var9),
               b<"V">(9007625374156441694L, var9),
               b<"V">(9009017660071957536L, var9),
               b<"V">(9009212503708069719L, var9),
               b<"V">(9009307752036181113L, var9),
               b<"V">(9011463380513401362L, var9),
               b<"V">(9010053301104103121L, var9),
               b<"V">(9009390650171935389L, var9),
               b<"V">(9009727657587491747L, var9),
               b<"V">(9009626207464567583L, var9),
               b<"V">(9010706245344635665L, var9),
               b<"V">(9010491325185735788L, var9),
               b<"V">(9012664575151400946L, var9),
               b<"V">(9010934143778296529L, var9),
               b<"V">(9009945473494425676L, var9),
               b<"V">(9010880746788112278L, var9),
               b<"V">(9011016014565704477L, var9),
               b<"V">(9007557040534080175L, var9),
               b<"V">(9010343421844692367L, var9),
               b<"V">(9011079719749242667L, var9),
               b<"V">(9009826853240135916L, var9),
               b<"V">(9009110458565083302L, var9),
               b<"V">(9008648219536561763L, var9),
               b<"V">(9009527635210446041L, var9),
               b<"V">(9008746203908823697L, var9),
               b<"V">(9010289016957509212L, var9),
               b<"V">(9008455799457389020L, var9),
               b<"V">(9011647445272728235L, var9),
               b<"V">(9008495847878536551L, var9),
               b<"V">(9009931249915696135L, var9),
               b<"V">(9012535129531718687L, var9)
            );
            return;
         }

         var3 = "\u0085IqÿÝ\t¢\u008d\u0001ÐJøI\u0011ªã®Àx+\u008fsõÆ\u0087\u0004!Áµ\u00859ô\u0092Ï<¡w©6<Z\u008bä3éK\u0011\u0094ê\u001e\u008a\t:\u0012\u000f\u008f\u009dSa\u0099¤lPéÃª[p\u0097Í\u0019\u00830»«|ZÅ( G\u0096Ð\u0098h¯C\u001d\u0010N³\u0089aå-³DQÇã\u0095±Ç\u0085\u000e\u0010I\u000fX\u0096\u0093\u009egÇõàRÿ\u008e\u009a×ý"
            .charAt(var2);
      }
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static Map F(int a, long radius) {
      radius = (int)(友树友友何友树友树友.a ^ radius);
      long ax = radius ^ 28028056679194L;
      HashMap blocks = new HashMap();
      byte var10000 = b<"â">(-5665727230721294303L, (long)radius);
      LocalPlayer thePlayer = mc.player;
      int axx = var10000;
      if (thePlayer == null) {
         return blocks;
      } else {
         int playerPosX = (int)b<"t">(thePlayer.position(), -5667018781385097302L, (long)radius);
         int playerPosY = (int)b<"t">(thePlayer.position(), -5672830303204400122L, (long)radius);
         int playerPosZ = (int)b<"t">(thePlayer.position(), -5666685848270523125L, (long)radius);
         int x = -2;

         while (true) {
            int y;
            if (x <= a) {
               y = -a;
            } else {
               if (radius >= 0L) {
                  return h(blocks);
               }

               y = -a;
            }

            label89:
            while (true) {
               label86: {
                  int z;
                  if (y <= a) {
                     z = -a;
                  } else {
                     x++;
                     var10000 = axx;
                     if (radius >= 0L) {
                        break label86;
                     }

                     z = axx;
                  }

                  while (true) {
                     while (true) {
                        if (z <= a) {
                           BlockPos blockPos = new BlockPos(playerPosX + x, playerPosY + y, playerPosZ + z);
                           Block block = H(ax, blockPos);
                           if (radius >= 0L) {
                              if (axx != 0) {
                                 var10000 = axx;
                                 if (radius >= 0L) {
                                    if (axx != 0) {
                                       blocks.put(blockPos, block);
                                       z++;
                                    }

                                    var10000 = axx;
                                 }

                                 if (var10000 != 0) {
                                    continue;
                                 }

                                 if (radius > 0L) {
                                    y++;
                                 }

                                 if (axx != 0) {
                                    continue label89;
                                 }
                                 break;
                              }

                              if (axx != 0) {
                                 continue label89;
                              }
                              break;
                           }

                           if (axx != 0) {
                              continue label89;
                           }
                           break;
                        }

                        if (radius > 0L) {
                           y++;
                        }

                        if (axx != 0) {
                           continue label89;
                        }
                        break;
                     }

                     x++;
                     var10000 = axx;
                     if (radius >= 0L) {
                        break;
                     }

                     z = axx;
                  }
               }

               if (var10000 != 0) {
                  break;
               }

               if (radius >= 0L) {
                  return h(blocks);
               }

               y = -a;
            }
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 34;
               case 1 -> 42;
               case 2 -> 55;
               case 3 -> 54;
               case 4 -> 47;
               case 5 -> 52;
               case 6 -> 1;
               case 7 -> 27;
               case 8 -> 60;
               case 9 -> 33;
               case 10 -> 43;
               case 11 -> 28;
               case 12 -> 22;
               case 13 -> 63;
               case 14 -> 30;
               case 15 -> 37;
               case 16 -> 49;
               case 17 -> 15;
               case 18 -> 38;
               case 19 -> 21;
               case 20 -> 44;
               case 21 -> 51;
               case 22 -> 61;
               case 23 -> 19;
               case 24 -> 8;
               case 25 -> 4;
               case 26 -> 2;
               case 27 -> 48;
               case 28 -> 50;
               case 29 -> 39;
               case 30 -> 5;
               case 31 -> 35;
               case 32 -> 46;
               case 33 -> 10;
               case 34 -> 3;
               case 35 -> 56;
               case 36 -> 20;
               case 37 -> 23;
               case 38 -> 45;
               case 39 -> 9;
               case 40 -> 18;
               case 41 -> 24;
               case 42 -> 31;
               case 43 -> 6;
               case 44 -> 13;
               case 45 -> 36;
               case 46 -> 7;
               case 47 -> 59;
               case 48 -> 0;
               case 49 -> 17;
               case 50 -> 25;
               case 51 -> 32;
               case 52 -> 40;
               case 53 -> 57;
               case 54 -> 58;
               case 55 -> 11;
               case 56 -> 29;
               case 57 -> 53;
               case 58 -> 41;
               case 59 -> 12;
               case 60 -> 62;
               case 61 -> 14;
               case 62 -> 26;
               default -> 16;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友树友友何友树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 't' && var8 != 219 && var8 != 'V' && var8 != 203) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 163) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 226) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 't') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 219) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'V') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   public static boolean h(long a, ItemStack var2) {
      a = 友树友友何友树友树友.a ^ a;
      long ax = a ^ 54213297929100L;
      int axx = b<"â">(3587118402089058486L, (long)a);
      if (var2 == null || !(var2.getItem() instanceof BlockItem) || var2.getCount() <= 1) {
         return false;
      } else if (!友何树何友树友树何何.l(ax, var2)) {
         return false;
      } else {
         String string = var2.getDisplayName().getString();
         if (!string.contains(a<"s">(473, 4255374411622933594L ^ a))) {
            boolean var10000 = string.contains(a<"s">(29386, 6006287363574830922L ^ a));
            if (a > 0L) {
               if (var10000) {
                  return false;
               }

               var10000 = var2.getItem() instanceof ItemNameBlockItem;
            }

            if (a >= 0L) {
               if (!var10000) {
                  Block block = ((BlockItem)var2.getItem()).getBlock();
                  var10000 = block instanceof FlowerBlock;
                  boolean var10001 = axx;
                  if (a >= 0L) {
                     if (axx) {
                        if (var10000) {
                           return false;
                        }

                        var10000 = block instanceof BushBlock;
                     }

                     var10001 = axx;
                  }

                  if (a > 0L) {
                     if (var10001) {
                        if (var10000) {
                           return false;
                        }

                        var10000 = block instanceof FungusBlock;
                     }

                     var10001 = axx;
                  }

                  if (a >= 0L) {
                     if (var10001) {
                        if (var10000) {
                           return false;
                        }

                        var10000 = block instanceof CropBlock;
                     }

                     var10001 = axx;
                  }

                  if (a >= 0L) {
                     if (var10001) {
                        if (var10000) {
                           return false;
                        }

                        var10000 = block instanceof SlabBlock;
                     }

                     var10001 = axx;
                  }

                  if (a > 0L) {
                     if (var10001) {
                        if (var10000) {
                           return false;
                        }

                        var10000 = b<"V">(3587791032950091088L, (long)a).contains(block);
                     }

                     var10001 = axx;
                  }

                  if (var10001) {
                     var10000 = !var10000;
                  }

                  return var10000;
               }

               var10000 = false;
            }

            return var10000;
         } else {
            return false;
         }
      }
   }

   public static Map h(Map a) {
      return a.entrySet()
         .stream()
         .sorted(
            (e1, e2) -> {
               double dist1 = mc.player
                  .distanceToSqr(((BlockPos)e1.getKey()).getX() + 0.5, ((BlockPos)e1.getKey()).getY() + 0.5, ((BlockPos)e1.getKey()).getZ() + 0.5);
               double dist2 = mc.player
                  .distanceToSqr(((BlockPos)e2.getKey()).getX() + 0.5, ((BlockPos)e2.getKey()).getY() + 0.5, ((BlockPos)e2.getKey()).getZ() + 0.5);
               return Double.compare(dist1, dist2);
            }
         )
         .collect(Collectors.toMap(Entry::getKey, Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   public static boolean d(long a, Block var2) {
      a = 友树友友何友树友树友.a ^ a;
      boolean var4 = b<"â">(9117925294800850935L, (long)a);
      if (mc.level != null && mc.player != null) {
         boolean var10000 = var2 instanceof LiquidBlock;
         boolean var10001 = var4;
         if (a >= 0L) {
            if (var4) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof AirBlock;
            }

            var10001 = var4;
         }

         if (a >= 0L) {
            if (var10001) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof ChestBlock;
            }

            var10001 = var4;
         }

         if (a > 0L) {
            if (var10001) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof FurnaceBlock;
            }

            var10001 = var4;
         }

         if (a > 0L) {
            if (var10001) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof LadderBlock;
            }

            var10001 = var4;
         }

         if (a > 0L) {
            if (var10001) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof TntBlock;
            }

            var10001 = var4;
         }

         return !var10001 ? var10000 : !var10000;
      } else {
         return false;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void a() {
      f[0] = "N|\u001f\u0003x1A<R\br,DaYNb*D~BN叜桏另叙佤厫栆厕格叙";
      f[1] = boolean.class;
      g[1] = "java/lang/Boolean";
      f[2] = "2\u000f\\&5\u00019\u0000MiN\u0003+\u001bZ7t\u001f,\u000bN\bk\b*\u000f^.t\u0003\u001d\u0016I\"k\u00191\u0001D";
      f[3] = "\u0005@\u0016V5(\n\u0000[]?5\u000f]P\u001b7(\u0002[TPt\n\tJMY?";
      f[4] = void.class;
      g[4] = "java/lang/Void";
      f[5] = "sCt(\u0003zmKngafjV";
      f[6] = "\u0013pv&AZ\u0013pazMU\t;ug^_\u0019;nmZV\u0011;`dCP\u0016;QfCD1t{m^q\u0011zac";
      f[7] = "-s<lo\u0016-s+0c\u001978?-p\u0013'8$'t\u001a/8*.m\u001c(8;6c\u000b&880m\u000f&d<+g\fm_&6g\u0018&d\u00180m\u000f&d<;";
      f[8] = "!O#jM\b!O46A\u0007;\u0004 +R\r+\u0004;!V\u0004#\u00045(O\u0002$\u0004\u0015(O\u0002$Y";
      f[9] = "\u0010Rr#a+\u0010Re\u007fm$\n\u0019qb~.\u001a\u0019jhz'\u0012\u0019dac!\u0015\u0019Dac!\u0015";
      f[10] = "6:H\u001fx\u00066:_Ct\t,qK^g\u0003<qLYl\u001cv\tYR&";
      f[11] = double.class;
      g[11] = "java/lang/Double";
      f[12] = "\u007f\\UOT}tSD\u00005s\u007fX@Z";
      f[13] = "\u0006k3w\nB@(0l:\u0016l,a0\u0007El\u0011gnX\bP`=nB\t";
      f[14] = "\u0011\u0000NiYaWCMri5{F\u0015$Xf{z\u001ap\u000b+G\u000b@p\u0011*";
      f[15] = "tT,>.=2\u0017/%\u001ei\u001e\u0013~z :\u001e.x'|w\"_\"'fv";
      f[16] = "`\u0018\r\u00120\u0015&[\u000e\t\u0000A\n__T>\u0013\nbY\u000bb_6\u0013\u0003\u000bx^";
      f[17] = "Q\u0016Dfh\u0012\u0017UG}XF;P\u001f+i\u0016;l\u0010\u007f:X\u0007\u001dJ\u007f Y";
      f[18] = "q\u007fs\u0016Y@7<p\ri\u0014\u001b9([XC\u001b\u0005'\u000f\u000b\n't}\u000f\u0011\u000b";
      f[19] = "W!'\u000fzY\u0011b$\u0014J\r=fuJpS=[s\u0016(\u0013\u0001*)\u00162\u0012";
      f[20] = "*\u0011\u001e`>\u0005lR\u001d{\u000eQ@VL$3\u000e@kJylO|\u001a\u0010yvN";
      f[21] = "TwN\r\u0012A\u00124M\u0016\"\u0015>0\u001cH\u001cF>\r\u001a\u0014@\u000b\u0002|@\u0014Z\n";
      f[22] = "i\u0014\u007f\u0002\fP/W|\u0019<\u0004\u0003S-F\u0005T\u0003n+\u001b^\u001a?\u001fq\u001bD\u001b";
      f[23] = "p\u001aLg\u000eT6YO|>\u0000\u001a]\u001e\"\u0004R\u001a`\u0018~\\\u001e&\u0011B~F\u001f";
      f[24] = "`\u0014F7+K&WE,\u001b\u001f\nS\u0014s+N\nn\u0012.y\u00016\u001fH.c\u0000";
      f[25] = "1\fy\u0007\u007fnwOz\u001cO:[K+Bto[v-\u001e-$g\u0007w\u001e7%";
      f[26] = "\u0004LqQ.iB\u000frJ\u001e=n\u000b#\u0014%in6%H|#RG\u007fHf\"";
      f[27] = "@'O@*:\u0006dL[\u001an*`\u001d\u0004*9*]\u001bYxp\u0016,AYbq";
      f[28] = "}\u000bI\u0001\u0000q;HJ\u001a0%\u0017L\u001bE\u000er\u0017q\u001d\u0018R;+\u0000G\u0018H:";
      f[29] = "OYAl\u007f9\t\u001aBwOm%\u001e\u0013(~:%#\u0015u-s\u0019ROu7r";
      f[30] = "?0\u0018\"N\u0016ys\u001b9~BUwJgE\u0015UJL;\u001c\\i;\u0016;\u0006]";
      f[31] = "\u0003i&\u007f^\fE*%dnXi/}2_\u000ei\u0013rf\fFUb(f\u0016G";
      f[32] = "3#$cz\u001cu`'xJHYdv$p\u0019YYpz(Ve(*z2W";
      f[33] = "\u000bd\u000bw0HVz\u0002\u0017$y\u001frD.h\u0017QxZ\u0017";
      f[34] = "O\u0000Ru_\b\tCQno\\%G\u00003W\u000b%z\u0006l\rB\u0019\u000b\\l\u0017C";
      f[35] = "_mUd)\u001b\u0019.V\u007f\u0019O5*\u0007 \"\u001a5\u0017\u0001}{Q\tf[}aP";
      f[36] = "E5OH:|\u0003vLS\n(/r\u001d\r7{/O\u001bQh6\u0013>AQr7";
      f[37] = "YctbQ6\u0004}}\u0002h\u0007Mu;;\ti\u0003\u007f%\u0002\u000ex\u00017'c\u000enO<D";
      f[38] = ",;\u0015{DZjx\u0016`t\u000eF|G=J^FAAb\u0016\u0010z0\u001bb\f\u0011";
      f[39] = "\u0014DC]afR\u0007@FQ2~\u0003\u0011\u001aka~>\u0017D3,BOMD)-";
      f[40] = "Um9FsL\bs0&叕桤史佔佔栿叕厾栨栐\t\u001dp\u0006Ocg\u001a&DW";
      f[41] = "\u001euA:N,X6B!~xt2\u0013|N(t\u000f\u0015#\u001cfH~O#\u0006g";
      f[42] = "22qUV]tqrNf\tXu#\u0012[VXH%L\u0004\u0017d9\u007fL\u001e\u0016";
      f[43] = "Ltg\u0005p^\n7d\u001e@\n&35@~X&\u000e3\u001c\"\u0014\u001a\u007fi\u001c8\u0015";
      f[44] = "~]/8w(#C&X{\u0019#F!'ib\"Uz2\u0012 e\u0007`#i!v\\uX";
      f[45] = "\nb+z-zL!(a\u001d.`$p7,z`\u0018\u007fc\u007f0\\i%ce1";
      f[46] = "\u001918\u0010\u000bT_r;\u000b;\u0000svjU\u0004RsKl\tY\u001eO:6\tC\u001f";
      f[47] = "kf\u0013R\u0017q-%\u0010I'%\u0001!A\u0016\u0018p\u0001\u001cGKE;=m\u001dK_:";
      f[48] = "\u0005K\u0003MT>C\b\u0000Vdjo\fQ\t[;o1WT\u0006tS@\rT\u001cu";
      f[49] = "x;J^\u0019d>xIE)0\u0012|\u0018\u0019\u0013d\u0012A\u001eGK..0DGQ/";
      f[50] = "!~Z\t~vg=Y\u0012N\"K9\bLtqK\u0004\u000e\u0010,<wuT\u00106=";
      f[51] = "w/&4\u0003G\"*,hhR\u001f%v6X\u0005\u001f\u0015|:\bCv)5m\u0016F";
      f[52] = "I\u0007Y;(@\u000fDZ \u0018\u0014#@\u000b|\"D#}\r\"z\n\u001f\fW\"`\u000b";
      f[53] = "oQ\u001dUjd=D_EV1\u0004\u0010Z\tff\u0004-Y\u0004gf-B\u0015U-4";
      f[54] = "@\u0018@Ip\u0000\u0015\u001dJ\u0015\u001b\u0015(\u0012\u0010K$J(\"\u001aG{\u0004A\u001eS\u0010e\u0001";
      f[55] = "r\u001a(\u0013\u000f34Y+\b?g\u0018]zU\u00005\u0018`|\n]y$\u0011&\nGx";
      f[56] = "2}m'\brt>n<8&X:?c\byX\u00079>Z8dvc>@9";
      f[57] = "Y?\u001f\u007f\u0012#\u001f|\u001cd\"w3xM9\u001c&3EKf@i\u000f4\u0011fZh";
      f[58] = "C>{.\u0013/\u0005}x5#{)y)k\u0013()D/7Ae\u00155u7[d";
      f[59] = "K5\b\nZS\u0016+\u0001jZb_#GS\u0002\f\u0011)Yj";
      f[60] = "+^fM\u0006om\u001deV6;A\u00194\t\toA$2TT%}UhTN$";
      f[61] = "?Y%x\u001a$y\u001a&c*pU\u001ew=\u0010'U#qaHniR+aRo";
      f[62] = "\u0017\u0005$\u0007P9QF'\u001c`m}BvBQ:}\u007fp\u001e\u0002sA\u000e*\u001e\u0018r";
      f[63] = "\u000e(\u000e\u0007\u0013BHk\r\u001c#\u0016do\\C\u0012DdRZ\u001eA\bX#\u0000\u001e[\t";
      f[64] = "3\u0002ik\rT0\u001dv}jB\t\b}lS\u0012gFwrj";
      f[65] = "cO\u0002B%/%\f\u0001Y\u0015{\t\bP\u0007%.\t5V[we5D\f[md";
      f[66] = "q8T\b\rp7{W\u0013=$\u001b~\u000fE\fu\u001bB\u0000\u0011_:'3Z\u0011E;";
      f[67] = ",\u0018v:!Fj[u!\u0011\u0012F_$|.BFb\"#s\fz\u0013x#i\r";
      f[68] = "\u0019kxcf_Lnr?\rJqa(a=\u001cqQ\"mm[\u0018mk:s^";
      f[69] = "Wk6a6{\u0011(5z\u0006/=,d$;\u007f=\u0011bxd1\u0001`8x~0";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友树友友何友树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21569;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/友树友友何友树友树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   public static boolean m() {
      return 友何树友何友友友何友;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static boolean U(BlockPos a, long a) {
      a = 友树友友何友树友树友.a ^ a;
      long ax = a ^ 15600255658248L;
      b<"â">(-2679580276159550546L, a);
      return mc.level != null && mc.player != null ? d(ax, mc.level.getBlockState(a).getBlock()) : false;
   }

   public static boolean y() {
      m();

      try {
         return true;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   public static BlockPos X(long a, BlockPos var2, double basePos, double var5, double var7) {
      a = 友树友友何友树友树友.a ^ a;
      b<"â">(-8445181248694488351L, (long)a);
      BlockPos var10000 = new BlockPos((int)Math.floor(var2.getX() + basePos), (int)Math.floor(var2.getY() + var5), (int)Math.floor(var2.getZ() + var7));
      if (!b<"â">(-8443564695122344420L, (long)a)) {
         b<"â">(false, -8445589657603705330L, (long)a);
      }

      return var10000;
   }

   public static boolean M(BlockPos a, long blockPos) {
      blockPos = 友树友友何友树友树友.a ^ blockPos;
      b<"â">(-2216912731787028202L, (long)blockPos);
      if (mc.level != null && mc.player != null) {
         Block block = mc.level.getBlockState(a).getBlock();
         return block instanceof AirBlock;
      } else {
         return false;
      }
   }

   public static Block H(long a, BlockPos var2) {
      a = 友树友友何友树友树友.a ^ a;
      b<"â">(-3525571498995468481L, (long)a);
      return mc.level != null && mc.player != null ? mc.level.getBlockState(var2).getBlock() : null;
   }

   public static void T(boolean var0) {
      友何树友何友友友何友 = var0;
   }

   public static BlockPos R(double a, double var2, double var4) {
      return new BlockPos((int)Math.floor((double)a), (int)Math.floor(var2), (int)Math.floor(var4));
   }

   public static boolean O(Block a, long block) {
      boolean ax;
      int var8;
      boolean var10001;
      label653: {
         label652: {
            block = 友树友友何友树友树友.a ^ block;
            boolean var10000 = b<"â">(8682893403090681938L, (long)block);
            BlockState blockState = a.defaultBlockState();
            ax = var10000;
            if (a instanceof SnowLayerBlock) {
               var10000 = blockState.hasProperty(b<"V">(8681952163881859211L, (long)block));
               if (block < 0L) {
                  return var10000;
               }

               if (!var10000) {
                  return false;
               }

               var8 = (Integer)blockState.getValue(b<"V">(8681952163881859211L, (long)block));
               var10001 = ax;
               if (block <= 0L) {
                  break label653;
               }

               if (ax) {
                  break label652;
               }

               if (var8 < 8) {
                  return false;
               }
            }

            var8 = a instanceof LiquidBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof AirBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof LadderBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof WebBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof TntBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof BushBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof FlowerPotBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof SlabBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof StairBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof FenceBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof WallBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof CarpetBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof IronBarsBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof SignBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof PressurePlateBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof ButtonBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof LeverBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof TorchBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof LanternBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof DoorBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof TrapDoorBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof BannerBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof SkullBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof BedBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof CakeBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof BrewingStandBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof HopperBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof DispenserBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof DaylightDetectorBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof BeaconBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof ShulkerBoxBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof BarrelBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof SmokerBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof BlastFurnaceBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof RepeaterBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof ComparatorBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof TripWireBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof TripWireHookBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof EndPortalFrameBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof EndPortalBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof AbstractCauldronBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof BellBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof ComposterBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof LecternBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof GrindstoneBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof StonecutterBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof CampfireBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof StructureVoidBlock;
         }

         var10001 = ax;
      }

      if (block > 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof BarrierBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof LightBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof PistonHeadBlock;
         }

         var10001 = ax;
      }

      if (block >= 0L) {
         if (!var10001) {
            if (var8 != 0) {
               return (boolean)0;
            }

            var8 = a instanceof MovingPistonBlock;
         }

         var10001 = ax;
      }

      if (var10001) {
         return (boolean)var8;
      } else {
         return (boolean)(var8 == 0 ? 1 : 0);
      }
   }

   private static String HE_WEI_LIN() {
      return "行走的50万——何炜霖";
   }
}
