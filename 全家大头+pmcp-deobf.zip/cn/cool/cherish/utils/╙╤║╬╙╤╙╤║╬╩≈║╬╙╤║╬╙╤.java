package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.apache.commons.lang3.RandomUtils;

public final class 友何友友何树何友何友 implements IWrapper, 何树友 {
   private final BlockPos 友何何何树何树树何友;
   private Direction 何何树树友何友树树树;
   private Vec3 友友友友友树树友树何;
   private static final long a;
   private static final Object[] b = new Object[43];
   private static final String[] c = new String[43];
   private static String HE_JIAN_GUO;

   public 友何友友何树何友何友(long a, BlockPos blockPos, Direction enumFacing) {
      a = 友何友友何树何友何友.a ^ a;
      long ax = a ^ 139079488999761L;
      super();
      this.友何何何树何树树何友 = blockPos;
      a<"M">(this, enumFacing, -4213102221022685256L, a);
      a<"M">(this, this.V(ax), -4212174842589374608L, a);
   }

   public 友何友友何树何友何友(BlockPos blockPos, Direction enumFacing, Vec3 vec3, long a) {
      a = 友何友友何树何友何友.a ^ a;
      super();
      this.友何何何树何树树何友 = blockPos;
      a<"M">(this, enumFacing, 386542579572954989L, a);
      a<"M">(this, vec3, 386767490267830181L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1706308958439291145L, 4630988087125783278L, MethodHandles.lookup().lookupClass()).a(168274994299213L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public void Z(long a, Direction var3) {
      a = 友何友友何树何友何友.a ^ a;
      a<"M">(this, var3, 6728422479637188432L, (long)a);
   }

   public Vec3 V(long a) {
      boolean ax;
      Vec3 directionVec;
      double x;
      double z;
      label86: {
         a = 友何友友何树何友何友.a ^ a;
         boolean var10000 = a<"Õ">(-4565642902974053586L, (long)a);
         directionVec = Vec3.atLowerCornerOf(a<"Ü">(this, -4565685484355087725L, (long)a).getNormal());
         ax = var10000;
         switch (a<"Ú">(-4562685745811605539L, (long)a)[a<"Ü">(this, -4565685484355087725L, (long)a).getAxis().ordinal()]) {
            case 1:
               double absX = Math.abs(mc.player.getX());
               double xOffset = absX - (int)absX;
               double var25 = mc.player.getX();
               if (a >= 0L) {
                  if (var25 < 0.0) {
                     xOffset = 1.0 - xOffset;
                  }

                  var25 = a<"Ü">(directionVec, -4562161106696234814L, (long)a) * xOffset;
               }

               x = var25;
               z = a<"Ü">(directionVec, -4562489423620137269L, (long)a) * xOffset;
               var10000 = ax;
               if (a > 0L) {
                  if (!ax) {
                     break label86;
                  }

                  var10000 = a<"Õ">(-4566098307709608990L, (long)a);
               }

               a<"Õ">(!var10000, -4566527013748047312L, (long)a);
            case 2:
               double absZ = Math.abs(mc.player.getZ());
               double zOffset = absZ - (int)absZ;
               double var27 = mc.player.getZ();
               if (a > 0L) {
                  if (var27 < 0.0) {
                     zOffset = 1.0 - zOffset;
                  }

                  var27 = a<"Ü">(directionVec, -4562161106696234814L, (long)a) * zOffset;
               }

               x = var27;
               double var28 = a<"Ü">(directionVec, -4562489423620137269L, (long)a) * zOffset;
               if (a <= 0L) {
                  break;
               }
            default:
               x = 0.25;
         }

         z = 0.25;
      }

      if (a<"Ü">(this, -4565685484355087725L, (long)a).getAxisDirection() == a<"Ú">(-4562411202239743483L, (long)a)) {
         x = -x;
         z = -z;
      }

      Vec3 hitVec = new Vec3(
            a<"Ü">(this, -4566408442519794891L, (long)a).getX() + 0.5,
            a<"Ü">(this, -4566408442519794891L, (long)a).getY() + 0.5,
            a<"Ü">(this, -4566408442519794891L, (long)a).getZ() + 0.5
         )
         .add(x + z, a<"Ü">(directionVec, -4562296052802132725L, (long)a) * 0.5, x + z);
      Vec3 src = mc.player.getEyePosition(1.0F);
      BlockHitResult obj = mc.level
         .clip(new ClipContext(src, hitVec, a<"Ú">(-4566335787186014461L, (long)a), a<"Ú">(-4566224149251075302L, (long)a), mc.player));
      BlockHitResult var29 = obj;
      boolean var10001 = ax;
      if (a >= 0L) {
         if (!ax) {
            if (obj == null) {
               return null;
            }

            var29 = obj;
         }

         var10001 = ax;
      }

      if (!var10001) {
         if (var29.getType() != a<"Ú">(-4562250994357105722L, (long)a)) {
            return null;
         }

         var29 = obj;
      }

      Vec3 resultVec = var29.getLocation();

      resultVec = switch (a<"Ú">(-4562685745811605539L, (long)a)[a<"Ü">(this, -4565685484355087725L, (long)a).getAxis().ordinal()]) {
         case 1 -> new Vec3(
            a<"Ü">(resultVec, -4562161106696234814L, (long)a),
            a<"Ü">(resultVec, -4562296052802132725L, (long)a),
            Math.round(a<"Ü">(resultVec, -4562489423620137269L, (long)a))
         );
         case 2 -> new Vec3(
            Math.round(a<"Ü">(resultVec, -4562161106696234814L, (long)a)),
            a<"Ü">(resultVec, -4562296052802132725L, (long)a),
            a<"Ü">(resultVec, -4562489423620137269L, (long)a)
         );
         default -> resultVec;
      };
      if (a<"Ü">(this, -4565685484355087725L, (long)a) != a<"Ú">(-4562591404150028185L, (long)a)
         && a<"Ü">(this, -4565685484355087725L, (long)a) != a<"Ú">(-4563085563182144723L, (long)a)) {
         BlockState blockState = mc.level.getBlockState(obj.getBlockPos());
         Block blockAtPos = blockState.getBlock();
         double blockFaceOffset = RandomUtils.nextDouble(0.1, 0.3);
         if (blockAtPos instanceof SlabBlock) {
            SlabType slabType = (SlabType)blockState.getValue(a<"Ú">(-4563166245495071566L, (long)a));
            if (slabType != a<"Ú">(-4562563674938490129L, (long)a)) {
               blockFaceOffset += 0.5;
            }
         }

         resultVec = resultVec.add(0.0, -blockFaceOffset, 0.0);
      }

      return resultVec;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 31;
               case 1 -> 54;
               case 2 -> 41;
               case 3 -> 10;
               case 4 -> 24;
               case 5 -> 23;
               case 6 -> 47;
               case 7 -> 8;
               case 8 -> 9;
               case 9 -> 19;
               case 10 -> 36;
               case 11 -> 22;
               case 12 -> 52;
               case 13 -> 61;
               case 14 -> 32;
               case 15 -> 43;
               case 16 -> 27;
               case 17 -> 14;
               case 18 -> 0;
               case 19 -> 53;
               case 20 -> 6;
               case 21 -> 46;
               case 22 -> 39;
               case 23 -> 13;
               case 24 -> 25;
               case 25 -> 51;
               case 26 -> 1;
               case 27 -> 59;
               case 28 -> 15;
               case 29 -> 57;
               case 30 -> 50;
               case 31 -> 40;
               case 32 -> 30;
               case 33 -> 33;
               case 34 -> 62;
               case 35 -> 16;
               case 36 -> 18;
               case 37 -> 21;
               case 38 -> 17;
               case 39 -> 49;
               case 40 -> 29;
               case 41 -> 3;
               case 42 -> 26;
               case 43 -> 37;
               case 44 -> 11;
               case 45 -> 38;
               case 46 -> 12;
               case 47 -> 7;
               case 48 -> 4;
               case 49 -> 44;
               case 50 -> 35;
               case 51 -> 42;
               case 52 -> 56;
               case 53 -> 28;
               case 54 -> 63;
               case 55 -> 45;
               case 56 -> 20;
               case 57 -> 2;
               case 58 -> 34;
               case 59 -> 48;
               case 60 -> 58;
               case 61 -> 55;
               case 62 -> 5;
               default -> 60;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 220 && var8 != 'M' && var8 != 218 && var8 != 238) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 201) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 213) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 220) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'M') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 218) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public BlockPos s(long a) {
      a = 友何友友何树何友何友.a ^ a;
      return a<"Ü">(this, 2063978067173414705L, (long)a);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/友何友友何树何友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "\u0004R\u0005\n2;\u000b\u0012H\u00018&\u000eOCG( \u000ePXG厖企厬号佾桸伈原伲号";
      b[1] = "~\u00016{\u007f\u001e~\u0001!'s\u0011dJ!:`\u0012> +'w\u0014d\r-;";
      b[2] = "\"l!p4y\"l6,8v8'\"1+|('%6 cb_0=j";
      b[3] = "=dVM#\u001c2$\u001bF)\u00017y\u0010\u00009\u00077f\u000b\u0000厇桢厕叁伭句桝厸桏叁";
      b[4] = boolean.class;
      c[4] = "java/lang/Boolean";
      b[5] = "PW\f\u001d\u0004;[X\u001dRx\"TB\u0013\u0011O\u0012BU\u001f\f^>UX";
      b[6] = "DA^\u00003dDAI\\?k^\nIA,h\u0004fFA=fzKY";
      b[7] = "'\nnC_9(J#HU$-\u0017(\u000e]9 \u0011,E\u001e\u001b+\u00005LU";
      b[8] = void.class;
      c[8] = "java/lang/Void";
      b[9] = "\r\u0000v/4r\r\u0000as8}\u0017Kun+w\u0007Knd/~\u000fKAm0k \nlu<c\u0017A@m6x\b";
      b[10] = "(o\u001bk\u001aZ(o\f7\u0016U2$\u0018*\u0005_\"$\u0003 \u0001V*$,)\u001eC\u0005e\u00011\u0012K2.))\u0002Z\"";
      b[11] = "\u001d<h6\u0019l\u0012|%=\u0013q\u0017!.{\u0003w\u0017>5{厽佖厵厙伓桄伣又伫厙b伀伣佖伫厙厍厞桧又桯";
      b[12] = "hm";
      b[13] = "b_0RlNb_'\u000e`Ax\u00143\u0013sKh\u0014(\u0019wB`\u0014&\u0010nDg\u00147\b`Si\u00144\u000enWiH0\u0015dT\"i(\u001dcsuJ!";
      b[14] = double.class;
      c[14] = "java/lang/Double";
      b[15] = "SA/i\nDSA85\u0006KI\n8(\u0015H\u0013`25\u0002NIM4)ClEM(\u0003\u000e_XG/.\bC";
      b[16] = "QgHxx\u0006Qg_$t\tK,K9g\u0003[,L>l\u001c\u0011JU\"G\nLwP\"1;FrY";
      b[17] = "KH\n+,|KH\u001dw sQ\u0003\tj3yA\u0003\u0012`7pI\u0003\u001ci.vN\u0003-i wgA\u0011f*";
      b[18] = "`h;E`m`h,\u0019lbz#8\u0004\u007fhj##\u000e{ab#-\u0007bge#<\u001flpk#?\u0019btk\u007f;\u0002hw H!\u001e`T|b?\u000e\u007fpw";
      b[19] = "`\u001f\u000b*Dvk\u0010\u001ae%x`\u001b\u001e?";
      b[20] = "Hk\nH74\u0012l\u0006\u0001Q\u00168Z50h1\u0012y\u000f_26\u001e0";
      b[21] = "#\u000b,\u0004\u0016ur\u0000uu伩佘栁桸压伨厷栜栁桸HL\u001ef`\u0007'\u0016\u0019j)";
      b[22] = "pFzW\u0019]$_zSa\u0007J\u001c\u007f\u0007\u001d\u0005vW\u007fQ\nb";
      b[23] = "\u0014AYK|+NFU\u0002\u001a\u001fjvfs\u001a}GHBUu'@D\u000b";
      b[24] = "5-\u0018,k!d&A]及厒反厄县桄栐厒栗会|df*6z\f028v";
      b[25] = "\u000f]^a?\u0019^UO`U/3\u0017\u0010<)\u0001\u000f\\\u0010j>f\u000eU\u0017i<]VB]<U";
      b[26] = ";k\u0015\u0005H9al\u0019L.\u0010E[*=.ohb\u000e\u001bA5onG";
      b[27] = "u{%Z\u001e\b$p|+县伥伓佌桘佶桥桡伓叒A\u0017\u0000\u001e$(&LM\u001c!";
      b[28] = "*\u0004\u0011\\\u000e}+\b\u0019JmXS $b!^Nd^C\u001clw\n_O\u0014z";
      b[29] = "\u0013%\u001eTx\u001eB.G%sn\u0014t\u0004Lu\u0010R/CA\u001aR\u00131\u0013Jd\u0014Hv\u001e%";
      b[30] = "T\u001b'~rK\f\u0001sy\u001dd,6\u0001\u0000\"I\u0000\u000e#izST\t";
      b[31] = "\u00105\t.V5A=\u0018/<',\u007fGs@-\u00104G%WJ";
      b[32] = "M\u0012\u0013NJ5\u0012\u001fS[0桔伯伽佴史栩桔伯桹佴1\u00003\u001b\u0004BL\f,H\u0018";
      b[33] = "uPPe1h/W\\,WK\u000beu\u001dnm/BUr4j#\u000b";
      b[34] = "C(8\u0002\rU\u0016#i\u0012g`5\u001e\u0002J\t\u0006\u000b,k\u001f\u0002W\u001b";
      b[35] = "nCW\u0010HV:\u0017EPuH\u0000\u001c\u0016\u0014E\u001f\u0000,\u001dP\u0019[-AL\u0014KE";
      b[36] = "\u0013\\?\u0001]v\u001fQ`AeU7sNe$M7<nY]+BYbT\u0002k";
      b[37] = "\u001eA\u0004q-\u0002J\u0015\u00161\u0010\u001cp\u001eEu Jp.N1|\u000f]C\u001fu.\u0011";
      b[38] = "\u001aI\u0014\u001a>0\u0016L\u0011\u0007\u0003\u001741?;\u00037O\u0016\u0016En;J\u0013\u000b";
      b[39] = "\u0006l3u)(R8!5\u00146h3rq+ih\u0003y5x%En(q*;";
      b[40] = ":d\u0011)GR`c\u001d`!bNU.Q\u0018W`v\u0014>BPl?";
      b[41] = "c4\u001d6Z}b(\u0006;!c^wF1\u001c6^J\u0013lD6xz\u00164Fh";
      b[42] = ")\f\u0007\rU\u0018s\u000b\u000bD3*Hf]\u001fP\u000fv\t\u0007\u0018\\F";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public Direction u(long a) {
      a = 友何友友何树何友何友.a ^ a;
      return a<"Ü">(this, -2423441567056950162L, (long)a);
   }

   public Vec3 y(long a) {
      a = 友何友友何树何友何友.a ^ a;
      return a<"Ü">(this, -6235745734330680435L, (long)a);
   }

   public void T(Direction a, long a) {
      a = 友何友友何树何友何友.a ^ a;
      a<"M">(this, a, 5102960274040296673L, a);
   }

   public static 友何友友何树何友何友 G(BlockPos a, long blockPos) {
      blockPos = 友何友友何树何友何友.a ^ blockPos;
      long ax = blockPos ^ 75855279882091L;
      long axx = blockPos ^ 127699029817792L;
      boolean var8 = a<"Õ">(-1664130543215776918L, (long)blockPos);
      if (友树友友何友树友树友.U(a.below(), ax)) {
         return new 友何友友何树何友何友(a.below(), a<"Ú">(-1663824747754124439L, (long)blockPos), null, axx);
      } else {
         boolean var10000 = 友树友友何友树友树友.U(a.south(), ax);
         boolean var10001 = var8;
         if (blockPos >= 0L) {
            if (!var8) {
               if (var10000) {
                  return new 友何友友何树何友何友(a.south(), a<"Ú">(-1664936056230708221L, (long)blockPos), null, axx);
               }

               var10000 = 友树友友何友树友树友.U(a.west(), ax);
            }

            var10001 = var8;
         }

         if (blockPos > 0L) {
            if (!var10001) {
               if (var10000) {
                  return new 友何友友何树何友何友(a.west(), a<"Ú">(-1664227429315914219L, (long)blockPos), null, axx);
               }

               var10000 = 友树友友何友树友树友.U(a.north(), ax);
            }

            if (blockPos < 0L) {
               return var10000 ? new 友何友友何树何友何友(a.east(), a<"Ú">(-1664000064391166842L, (long)blockPos), null, axx) : null;
            }

            var10001 = var8;
         }

         if (!var10001) {
            if (var10000) {
               return new 友何友友何树何友何友(a.north(), a<"Ú">(-1664176857729053599L, (long)blockPos), null, axx);
            }

            var10000 = 友树友友何友树友树友.U(a.east(), ax);
         }

         return var10000 ? new 友何友友何树何友何友(a.east(), a<"Ú">(-1664000064391166842L, (long)blockPos), null, axx) : null;
      }
   }

   public void K(Vec3 a, long a) {
      a = 友何友友何树何友何友.a ^ a;
      a<"M">(this, a, -5090345211232130144L, a);
   }

   private static String LIU_YA_FENG() {
      return "何树友，和树做朋友";
   }
}
