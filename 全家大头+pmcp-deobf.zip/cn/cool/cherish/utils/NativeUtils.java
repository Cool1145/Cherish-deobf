package cn.cool.cherish.utils;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.objectweb.asm.tree.MethodNode;

public final class NativeUtils implements 何树友 {
   private static boolean 树何树友何何何何何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[20];
   private static final String[] f = new String[20];
   private static String HE_WEI_LIN;

   private NativeUtils(long a) {
      a = 11729618522672L ^ a;
      super();
      throw new UnsupportedOperationException(a<"k">(13893, 8273263258897028996L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6695246058850657929L, 8839935963261753908L, MethodHandles.lookup().lookupClass()).a(275938022412664L);
      // $VF: monitorexit
      a = var10000;
      a();
      g(true);
      Cipher var0;
      Cipher var9 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(125704321544912L << var1 * 8 >>> 56);
      }

      var9.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[2];
      int var5 = 0;
      char var3 = 'X';
      int var2 = -1;

      while (true) {
         String var11 = a(
               var0.doFinal(
                  "\u0001Ñ\u0013ÒcàJãL÷\u0084\u009f®K\u0002*ûb\u009fû\u0092J\u008eÒ¡¿Û\n}\bø·Ì\u0083\u0099ñ\u000e·\u008fr\u0095.£\"r\u009d\u00970Ý9iõ/Éí\u009bv\u0002Úª\u0006\u0003L»·Q\u0015p|:\u0091íØ\u0094ìò\u0083££\u008cÆ©\u001e\u009bø_\u009eX(lS'UÍT\u0015Õ¥\u008c\u001f\u0010múÃzs\\Â¿ê>2\u0005ÄÖ\u0000\u008fOüÍ\u001bédµÓÕ\u0000gl"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var11;
         if ((var2 += var3) >= 129) {
            b = var7;
            c = new String[2];
            System.load(Cherish.getResourcesManager().resources.getAbsolutePath() + "\\dll\\native_utils.dll");
            return;
         }

         var3 = "\u0001Ñ\u0013ÒcàJãL÷\u0084\u009f®K\u0002*ûb\u009fû\u0092J\u008eÒ¡¿Û\n}\bø·Ì\u0083\u0099ñ\u000e·\u008fr\u0095.£\"r\u009d\u00970Ý9iõ/Éí\u009bv\u0002Úª\u0006\u0003L»·Q\u0015p|:\u0091íØ\u0094ìò\u0083££\u008cÆ©\u001e\u009bø_\u009eX(lS'UÍT\u0015Õ¥\u008c\u001f\u0010múÃzs\\Â¿ê>2\u0005ÄÖ\u0000\u008fOüÍ\u001bédµÓÕ\u0000gl"
            .charAt(var2);
      }
   }

   public static boolean S() {
      M();

      try {
         return true;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/NativeUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      e[0] = "oE[T=)`\u0005\u0016_74eX\u001d\u0019'2eG\u0006\u0019\u001c'xB\u0003R\u00072eG\u0006";
      e[1] = "\f+\u0012\u0003\u0003\\\u0007$\u0003Lx^\u0015?\u0014\u0012BB\u0012/\u0000-]U\u0014+\u0010\u000bB^#2\u0007\u0007]D\u000f%\n";
      e[2] = "A7(.L=Nwe%F K*ncN=F,j(\r\u001fM=s!F";
      e[3] = "\u000b7\u001b$\u001c\u0010?\u0014\u0014dQ\u001b5\t\u00119Z]=\u0014\u001c?^\u0016~6\u0017.G\u001f5@";
      e[4] = "Ygw%Z\u0007V':.P\u001aSz1h@\u001cSe*h栤伽叱作厒桗栤伽栫作";
      e[5] = "Z^xgC\u0004n}w'\u000e\u000fd`rz\u0005Il}\u007f|\u0001\u0002/_tm\u0018\u000bd)";
      e[6] = "\u007f\"m%QTK\u0001be\u001c_A\u001cg8\u0017\u0019I\u0001j>\u0013R\n#a/\n[AU";
      e[7] = void.class;
      f[7] = "java/lang/Void";
      e[8] = "1<M\u000ex^\u0005\u001fBN5U\u000f\u0002G\u0013>\u0013\u0007\u001fJ\u0015:XD=A\u0004#Q\u000fK";
      e[9] = boolean.class;
      f[9] = "java/lang/Boolean";
      e[10] = "\u0005V~ik=\n\u00163ba \u000fK8$q&\u000fT#$v7\u0015W%xg7\u0015\u0016\u0002ow=\u0013J3ow\u001f\u0007V1ma ";
      e[11] = "|e\nP/\u001by*:Xm\u0017";
      e[12] = "\n\u000fw\u007f?\f\u0001\u0000f0^\u0002\n\u000bbj";
      e[13] = "9[\u00062@S:\u0000\u001dXR#)\u0018\n7^^.\u001d\u0016XA\\/\b\u0013%FY3g";
      e[14] = "\t-\u000er0)L#\u0006sH\u000b0cT?veVg\u00042(Y";
      e[15] = "%w9*|9u|b.\u0012(\u001e$dq,lx 4|rP";
      e[16] = "%ae$\u0015,uj> {\u0005\u001e28\u007fEyx6hr\u001bE#ee&\u00159/5l?{";
      e[17] = "n;i/w-m`rEc]:xf4eby|(7\f`mc|+pl=jeE";
      e[18] = "]'KVAU^z\u0001@'O\u000f0\u001cB]^\u000f0{\u000f\u001aPY(@DM\u0004\u0000";
      e[19] = "lY\u001ft9o)W\u0017uAAU\u0017E9\u007f#3\u0013\u00154!\u001fh@\u0018`/cd\u0010\u0011yA";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 11;
               case 1 -> 29;
               case 2 -> 28;
               case 3 -> 9;
               case 4 -> 3;
               case 5 -> 38;
               case 6 -> 2;
               case 7 -> 6;
               case 8 -> 57;
               case 9 -> 46;
               case 10 -> 45;
               case 11 -> 56;
               case 12 -> 0;
               case 13 -> 51;
               case 14 -> 24;
               case 15 -> 7;
               case 16 -> 31;
               case 17 -> 13;
               case 18 -> 54;
               case 19 -> 34;
               case 20 -> 12;
               case 21 -> 53;
               case 22 -> 17;
               case 23 -> 30;
               case 24 -> 23;
               case 25 -> 49;
               case 26 -> 40;
               case 27 -> 62;
               case 28 -> 36;
               case 29 -> 26;
               case 30 -> 8;
               case 31 -> 35;
               case 32 -> 27;
               case 33 -> 32;
               case 34 -> 18;
               case 35 -> 33;
               case 36 -> 14;
               case 37 -> 5;
               case 38 -> 37;
               case 39 -> 43;
               case 40 -> 10;
               case 41 -> 15;
               case 42 -> 42;
               case 43 -> 22;
               case 44 -> 47;
               case 45 -> 50;
               case 46 -> 59;
               case 47 -> 48;
               case 48 -> 55;
               case 49 -> 58;
               case 50 -> 61;
               case 51 -> 20;
               case 52 -> 16;
               case 53 -> 39;
               case 54 -> 1;
               case 55 -> 41;
               case 56 -> 19;
               case 57 -> 63;
               case 58 -> 25;
               case 59 -> 4;
               case 60 -> 21;
               case 61 -> 44;
               case 62 -> 60;
               default -> 52;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/NativeUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 230 && var8 != 222 && var8 != 212 && var8 != 205) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 249) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 230) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 222) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 15306;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/NativeUtils", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[èZ,.L\u0093ÔñÛGâf\u0083ä\u0089üIhP\u0004ÔÎ\u0088\u0004èý)T\u009cÃ-½Ô%B\u0012\u007f~\u0099\u0017¹\u0091\u0095\u0017\u0097\u0096\u0005W\u0085¢,\u0099~Ë#±, Az5hhLÔ©\u0088U\u001dü¤Ò3|\u008dFË")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   public static void o(Class a, long newClassBytes, byte[] a) {
      树何友何友树树何树何.p();
      cmVkZWZpbmVDbGFzc2Vz(a.getClassLoader(), a, (byte[])a, true, false);
      if (Module.Z() == null) {
         树何友何友树树何树何.H(new Module[1]);
      }
   }

   public static void g(boolean var0) {
      树何树友何何何何何何 = var0;
   }

   public static boolean M() {
      return 树何树友何何何何何何;
   }

   private static String HE_DA_WEI() {
      return "何炜霖国企上班";
   }

   public static native void RnVja3dvY25tc2J4anBoYXNob29vc2V0(MethodNode var0, String[] var1);

   public static native void RnVja3dvY25tc2J4anBoYXNob29vbw(MethodNode var0, String[] var1);

   public static native String UFJJVkFURUtFWQ();

   public static native String UFVCTElDS0VZ();

   public static native byte[] Z2V0Q2xhc3Nlc0J5dGVz(Class<?> var0);

   public static native void cmVkZWZpbmVDbGFzc2Vz(ClassLoader var0, Class<?> var1, byte[] var2, boolean var3, boolean var4);

   public static void cmVkZWZpbmVDbGFzc2Vz(Class<?> targetClass, byte[] newClassBytes) {
      Module[] var10000 = 树何友何友树树何树何.p();
      cmVkZWZpbmVDbGFzc2Vz(targetClass.getClassLoader(), targetClass, newClassBytes, true, true);
      if (var10000 != null) {
         Module.V(new Module[4]);
      }
   }
}
