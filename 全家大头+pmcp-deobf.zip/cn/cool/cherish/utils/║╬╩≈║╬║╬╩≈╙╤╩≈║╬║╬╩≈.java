package cn.cool.cherish.utils;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.helper.何何何树友树树友树友;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult.Type;

public enum 何树何何树友树何何树 implements IWrapper,  {
   树友友友友友友何何友,
   树树何友友何友何树何,
   友友树树友友树友树何,
   树何友何树何友何树何,
   何友何友友何友何友友,
   何何何何友树何友树何,
   友树何友树树树树友何;

   private final Item 树何何树友何何何何树;
   private final float 友友何友何何何何树何;
   public double 树友树友友友树树树何;
   public double 友友何友何树友树友友;
   public double 友友何何何树何何友何;
   public float 友何友树何树何何何何;
   public float 树何何友何友何何何友;
   public float 何友树何何何树何何树;
   public BlockHitResult 何何友友何树树树友何;
   public Entity 友树树友树何何何树树;
   private static final long a;
   private static final long b;
   private static final Object[] c = new Object[61];
   private static final String[] e = new String[61];
   private static int _何炜霖230622200409390090 _;

   private 何树何何树友树何何树(Item item, float posX, float posY, float posZ) {
      this.树何何树友何何何何树 = item;
      this.友友何友何何何何树何 = posY;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // $VF: Failed to inline enum fields
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8091215097585994865L, 1522722559551633032L, MethodHandles.lookup().lookupClass()).a(230438449848938L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var6;
      Cipher var15 = var6 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var7 = 1; var7 < 8; var7++) {
         var10003[var7] = (byte)(57377123883506L << var7 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var5 = new String[7];
      int var11 = 0;
      String var10 = "Ým\u0086ò\u0093¯@øá½Ä\nB=>3\u0010\u0010\u001eßºX¦'¡ì»\u008f\u0016\bY+º\u0018E4³Ê\u009eé¼ìPça£&ßO\u0018ú\u000b\r-¢\u0094µÒ\b\u0092è~ù¥ý\u001cÿ\u0010¸\u0018\u009b=-¢\u0014\u0003\u0091±\\\u0088\u0080\u001fÃó";
      byte var12 = 84;
      char var9 = 16;
      int var14 = -1;

      label45:
      while (true) {
         String var16 = var10.substring(++var14, var14 + var9);
         byte var10001 = -1;

         while (true) {
            String var24 = b(var6.doFinal(var16.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var5[var11++] = var24;
                  if ((var14 += var9) >= var12) {
                     Cipher var0;
                     Cipher var18 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(57377123883506L << var1 * 8 >>> 56);
                     }

                     var18.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     byte[] var4 = var0.doFinal(new byte[]{108, 114, 92, 51, -72, -20, 59, 97});
                     long var28 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     b = var28;
                     树友友友何友树友何树 = !何树何何树友树何何树.class.desiredAssertionStatus();
                     树友友友友友友何何友 = new 何树何何树友树何何树(Items.BOW, 0.0F, 3.0F, 0.0F);
                     树树何友友何友何树何 = new 何树何何树友树何何树(Items.SNOWBALL, 0.0F, 1.875F, 0.0F);
                     友友树树友友树友树何 = new 何树何何树友树何何树(Items.ENDER_PEARL, 0.0F, 1.875F, 0.0F);
                     树何友何树何友何树何 = new 何树何何树友树何何树(Items.EGG, 0.0F, 1.875F, 0.0F);
                     何友何友友何友何友友 = new 何树何何树友树何何树(Items.SPLASH_POTION, 0.0F, 0.5F, 0.0F);
                     何何何何友树何友树何 = new 何树何何树友树何何树(Items.EXPERIENCE_BOTTLE, 0.0F, 0.6F, 0.0F);
                     友树何友树树树树友何 = new 何树何何树友树何何树(Items.TRIDENT, 0.0F, 2.5F, 0.0F);
                     return;
                  }

                  var9 = var10.charAt(var14);
                  break;
               default:
                  var5[var11++] = var24;
                  if ((var14 += var9) < var12) {
                     var9 = var10.charAt(var14);
                     continue label45;
                  }

                  var10 = "-÷÷\n0æ\u008dÅ\bò\u0001Eº·gKã";
                  var12 = 17;
                  var9 = '\b';
                  var14 = -1;
            }

            var16 = var10.substring(++var14, var14 + var9);
            var10001 = 0;
         }
      }
   }

   public Item V(long a) {
      a = 117849452486593L ^ a;
      return a<"å">(this, -5840381756462536562L, (long)a);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 59;
               case 1 -> 41;
               case 2 -> 1;
               case 3 -> 38;
               case 4 -> 11;
               case 5 -> 14;
               case 6 -> 32;
               case 7 -> 15;
               case 8 -> 43;
               case 9 -> 18;
               case 10 -> 54;
               case 11 -> 55;
               case 12 -> 31;
               case 13 -> 50;
               case 14 -> 57;
               case 15 -> 16;
               case 16 -> 4;
               case 17 -> 19;
               case 18 -> 45;
               case 19 -> 26;
               case 20 -> 28;
               case 21 -> 36;
               case 22 -> 60;
               case 23 -> 39;
               case 24 -> 42;
               case 25 -> 40;
               case 26 -> 51;
               case 27 -> 5;
               case 28 -> 24;
               case 29 -> 6;
               case 30 -> 56;
               case 31 -> 62;
               case 32 -> 2;
               case 33 -> 0;
               case 34 -> 52;
               case 35 -> 29;
               case 36 -> 48;
               case 37 -> 25;
               case 38 -> 46;
               case 39 -> 44;
               case 40 -> 13;
               case 41 -> 35;
               case 42 -> 30;
               case 43 -> 63;
               case 44 -> 9;
               case 45 -> 17;
               case 46 -> 22;
               case 47 -> 58;
               case 48 -> 49;
               case 49 -> 37;
               case 50 -> 20;
               case 51 -> 8;
               case 52 -> 33;
               case 53 -> 23;
               case 54 -> 53;
               case 55 -> 21;
               case 56 -> 61;
               case 57 -> 27;
               case 58 -> 47;
               case 59 -> 12;
               case 60 -> 3;
               case 61 -> 34;
               case 62 -> 7;
               default -> 10;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 229 && var8 != 'l' && var8 != 213 && var8 != 'S') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'A') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 223) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 229) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'l') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      c[0] = "oL4\u0014FD`\fy\u001fLYeQrY\\_eNiY佼栺余佷栋厼核佾余栳";
      c[1] = float.class;
      e[1] = "java/lang/Float";
      c[2] = "D\u0005\u0000lHYD\u0005\u00170DV^N\u0003-W\\NN\u001d6@]\u0004)\u0000'H";
      c[3] = "\u0001,s'L\u001f\u000el>,F\u0002\u000b15jV\u0004\u000b..j叨桡厩众厖休叨桡伷厉";
      c[4] = boolean.class;
      e[4] = "java/lang/Boolean";
      c[5] = "\ti}\u001c\fy\u0002flSp`\r|b\u0010GP\u001bkn\rV|\ff";
      c[6] = "Xa96KFXa.jGIB*:wTCR*$lCB\u0018M9}K\\";
      c[7] = "k\nN\\{wk\nY\u0000wxqAM\u001ddraAJ\u001aom+9_\u0011%";
      c[8] = double.class;
      e[8] = "java/lang/Double";
      c[9] = "C$77q}C$ k}rYo uuqC5mipuT$17P{N /IpuT$1";
      c[10] = "\u0003\f\u0001u'O\u0003\f\u0016)+@\u0019G\u000248J\tG\u0019><C\u0001G67#V.\u0006\u001b//^\u0019M77%E\u0006";
      c[11] = "CT#>\u001d(L\u0014n5\u00175IIes\u001f(DOa8\\\nO^x1\u0017";
      c[12] = "\u0010T\u0011c82$w\u001e#u9.j\u001b~~\u007f&w\u0016xz4eU\u001dic=.#";
      c[13] = "r\u0016L|*\"r\u0016[ &-h]O=5'x]]<3\"h\n\u0016\u0017)?u\u0007A";
      c[14] = "\u0003\u0017fX/\b74i\u0018b\u0003=)lEiE54aCm\u000ev\u0016jRt\u0007=`";
      c[15] = void.class;
      e[15] = "java/lang/Void";
      c[16] = "&&\u001cj+8&&\u000b6'7<m\u001f+4=,m\u0004!04$m+(/!\u000b,\u00060#)<g.(38,";
      c[17] = "\u000eG-\u0000\u0019[\u000eG:\\\u0015T\u0014\f.A\u0006^\u0004\f)F\rAN`5A\u0017Y(K-|\u0011A\u0015N-";
      c[18] = "q\u000bQ\u0010\b\u001eq\u000bFL\u0004\u0011k@RQ\u0017\u001b{@UV\u001c\u00041&LJ7\u0012l\u001bIJA#f\u001e@";
      c[19] = "u>mF\b:A\u001db\u0006E1K\u0000g[Nw[\u0006gDUw佻档佛佽样厒栿伧佛根\u001d";
      c[20] = "wA@15h|NQ~TfwEU$";
      c[21] = "e\u000e\u00027-Od_\u0007?\u0016F\u000e\rFl&\u0014\u000e1Fiw\u0014#O\u00154gU";
      c[22] = "\u007fhlB\u000e9)5a}叵厄低厖佝传佫会栊伈\u0000D\\)*>nMS|*";
      c[23] = "]\u00049,\\8\u000bY4\u0013桽伛佬叺伈叐伹伛佬叺U*\u000e(\bR;#\u0001}\b";
      c[24] = "y!7\u001a'\u0010xp2\u0012\u001c\u0019\u0012\"sA&N\u0012\u001esD}K?` \u0019m\n";
      c[25] = "DSg\u0017\u001ct\u001d\\|\u0010- -\f5H\u001cv-59\u0007\u001d.G\u000bt\t\u001c2";
      c[26] = "J^;\u001b=|\u001c\u00036$佘叁栿伾伊佹栜佟佻桺W\u001dol\u001f\b9\u0014`9\u001f";
      c[27] = "ZsJa^\u0012\u0003i\u0012o??\"]h^s9?\u0019\u0013uY\n\u0004\u007fJo\u0001\u0004";
      c[28] = "^$E\u0006Q?\u001e)FX8\u0012d.\u0016WA+\u000b-\u001c\u0000HT";
      c[29] = "\"S5\u0016\u0019\u0017t\u000e8)核厪厍厭伄只核厪伓桷Y\u0012N\u00027\u00116\u0011DU>";
      c[30] = "\u0015.DZWaCsIe厬佂厺栊併桼伲佂伤低(\\\u0005q@xFU\n$@";
      c[31] = ",\u001c\u001e7P7c\u0019\u000e9;\u0002\u0013\u000fDu\u000b?q\u0001\u0012!AP";
      c[32] = "\b1\u0003\u0016I\u001a^l\u000e)厲厧伹叏伲栰厲桽厧叏o\u0014\u0001T\u00041QY\u000fU\u0018";
      c[33] = "e,yW\\Z3qth厧叧栐栈取厫桽叧栐佌\u0015\u0004YH6)kR\u0004E";
      c[34] = "/uZE7gy(Wz双栀桚压栯伧佒佄桚桑6K`e&*\u0007\u00012 *";
      c[35] = ":2|Ei<u7lK\u0002\u0005\u0005!&\u000724g/pSx[l5 Yx?fy%U\u0002";
      c[36] = "4\u0015Ca^Ym\u001aXfo\r]J\u0011>^Z]s\u001dq_\u00037MP\u007f^\u001f";
      c[37] = "@>)\u000f~pCk'\u000f\u001be*goC+3*Wh\u000f+k@i%\u0001*w";
      c[38] = "9MG[\u0001:?\u0016\\]8B\u0014a{fRn\"\u001a\u000fXT59\u001c";
      c[39] = "5\u001bq\f\u00143cF|3佱伐厚句佀株栵桔厚佻\u001dYR' \u001ffWGsf";
      c[40] = "=G\u0012X^\u0000k\u001a\u001fg桿厽厒厹厽厤厥伣伌厹~\u000b[\u0012nB\u0000]\u0006\u001f";
      c[41] = ">`'\u001cZ\u0014?1\"\u0014a\u001dUccEXHU_cB\u0000Ox!0\u001f\u0010\u000e";
      c[42] = "E{\u0010zG;\u0013&\u001dE厼桜佴厅桥桜桦桜只伛|)B)\u0016~\u0002\u007f\u001f$";
      c[43] = "\u0018x\u00164C\u0006\u001b-\u00184&\u0013r!Px\u0019Lr\u0011W4\u0016\u001d\u0018/\u001a:\u0017\u0001";
      c[44] = "k/&B>xhz(B[m\u0001v`\u000ek:\u0001FgBkckx*Lj\u007f";
      c[45] = "\u001c\bS4\u001a1\u001dYV<!8w\u000b\u0017n\u001clw7\u0017j@jZID7P+";
      c[46] = "Hx\u001c\u001a<\u0001\u001e%\u0011%栝伢佹桜厳佸余伢佹桜p\u001f<\u001e\u0018?\u000eLa\u000eY";
      c[47] = ",!F\u0019gBl,EG\u000eE\u0016+\u0015HwVy(\u001f\u001f~)";
      c[48] = "c<f+Ax5ak\u0014伤叅佒参叉佉厺佛双参\nxDj09t.\u0019g";
      c[49] = "\u0019ih?\u0015p\u00188m7.yrj,f\u0015)rV,aO+_(\u007f<_j";
      c[50] = "\u0010.eg9mFshX参叐伡低佔桁作低县低\teq#\u001c.7(\u007f\"\u0000";
      c[51] = ":\u001dFl\u0007*l@KSVTj\u001aT5\u0007n-\u001aD3?hl^Lk\u0005/lNJS";
      c[52] = "\u001b\"G\u001a\f\\\u001asB\u00127Up!\u0003@\u000e\u0002p\u001d\u0003DV\u0007]cP\u0019FF";
      c[53] = "fL?6'Z0\u00112\t叜叧叉伬桊栐佂叧栓厲Ses\u0018l@lg\"Ho";
      c[54] = "&tR\nVgp)_5伳佄众伔叽栬伳叚桓伔>YSuuq@\u000f\u000ex";
      c[55] = ";Zl\u001c9Um\u0007a#栘佶厔伺栙佾参佶桎伺\u0000O<Gh_~\u0019aJ";
      c[56] = "\u0000\u001dg\u001ad V@j%桅厝桵口又另桅桇桵佽\u000b\u0018,n\f\u001d5U\"o\u0010";
      c[57] = "lY=*\u0016Cm\b8\"-J\u0007Zyr\u0014\u001e\u0007fytL\u0018*\u0018*)\\Y";
      c[58] = "IvMSHo\u0010yVTy; )\u001f\fHo \u0010\u0013CI5J.^MH)";
      c[59] = "?W`\u0015$,i\nm*栅桋伎厩叏佷叟伏桊伷\fF!>lRr\u0010|3";
      c[60] = "z\u0003K\u001d\r\f!\u0019[\u0005}6P(z}\u0016\u0003{\u0013Q\u0002M\u0019k\u000b";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/何树何何树友树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static 何树何何树友树何何树 w(long a, Item a) {
      boolean var10000 = 友树友何友何友树何友.d();
      何树何何树友树何何树[] var9 = G(37457579477717L);
      int var10 = var9.length;
      int ax = var10000;
      int var11 = 0;

      while (var11 < var10) {
         何树何何树友树何何树 var6 = var9[var11];
         if (!ax) {
            if (var6.V(41740046905656L).equals(a)) {
               return var6;
            }

            var11++;
         }

         if (ax) {
            break;
         }
      }

      return null;
   }

   public static 何树何何树友树何何树 r(String a) {
      return Enum.valueOf(何树何何树友树何何树.class, a);
   }

   public List A(long a) {
      boolean var10000 = 友树友何友何友树何友.N();
      ArrayList list = new ArrayList();
      int ax = var10000;
      if (!树友友友何友树友何树 && mc.player == null) {
         throw new AssertionError();
      } else {
         float var4 = (float)Math.toRadians(mc.player.getYRot());
         float var5 = (float)Math.toRadians(mc.player.getXRot());
         double var6 = mc.player.xOld + (mc.player.getX() - mc.player.xOld) * WrapperUtils.n(new Object[0]);
         double var8 = mc.player.yOld + (mc.player.getY() - mc.player.yOld) * WrapperUtils.n(new Object[0]);
         double var10 = mc.player.zOld + (mc.player.getZ() - mc.player.zOld) * WrapperUtils.n(new Object[0]);
         this.树友树友友友树树树何 = var6;
         this.友友何友何树友树友友 = var8 + mc.player.getEyeHeight() - 0.1F;
         this.友友何何何树何何友何 = var10;
         float var12x = Math.min(20.0F, 72000 - mc.player.getUseItemRemainingTicks() + mc.getPartialTick()) / 20.0F;
         this.友何友树何树何何何何 = (float)(-Math.sin(var4) * Math.cos(var5) * this.友友何友何何何何树何 * var12x);
         this.树何何友何友何何何友 = (float)(-Math.sin(var5) * this.友友何友何何何何树何 * var12x);
         this.何友树何何何树何何树 = (float)(Math.cos(var4) * Math.cos(var5) * this.友友何友何何何何树何 * var12x);
         this.何何友友何树树树友何 = null;
         this.友树树友树何何何树树 = null;
         list.add(new 友树友何友何友树何友(56143884807940L, this.树友树友友友树树树何, this.友友何友何树友树友友, this.友友何何何树何何友何));
         if (this.何何友友何树树树友何 == null && this.友树树友树何何何树树 == null && this.友友何友何树友树友友 > 0.0) {
            何何何树友树树友树友 startVec = new 何何何树友树树友树友(22795, this.树友树友友友树树树何, (byte)24, 2943560, this.友友何友何树友树友友, this.友友何何何树何何友何);
            何何何树友树树友树友 endVec = new 何何何树友树树友树友(
               22795, this.树友树友友友树树树何 + this.友何友树何树何何何何, (byte)24, 2943560, this.友友何友何树友树友友 + this.树何何友何友何何何友, this.友友何何何树何何友何 + this.何友树何何何树何何树
            );
            float size = (float)(!(this.树何何树友何何何何树 instanceof BowItem) ? 0.25 : 0.3);
            AABB boundingBox = new AABB(
               this.树友树友友友树树树何 - size, this.友友何友何树友树友友 - size, this.友友何何何树何何友何 - size, this.树友树友友友树树树何 + size, this.友友何友何树友树友友 + size, this.友友何何何树何何友何 + size
            );
            List<Entity> entities = mc.level
               .getEntities(
                  mc.player,
                  boundingBox.move(this.友何友树何树何何何何, this.树何何友何友何何何友, this.何友树何何何树何何树).inflate(1.0, 1.0, 1.0),
                  new 树何何树树树何树友何(this, size, startVec, endVec)
               );
            if (!entities.isEmpty()) {
               for (Entity entity : entities) {
                  this.友树树友树何何何树树 = entity;
                  if (!ax) {
                     return list;
                  }

                  if (!ax) {
                     Module.V(new Module[4]);
                     break;
                  }
               }
            }

            BlockHitResult trace = mc.level
               .clip(new ClipContext(友友友树何友树友树友.Q(109213121972113L, startVec), 友友友树何友树友树友.Q(109213121972113L, endVec), Block.COLLIDER, Fluid.NONE, mc.player));
            if (trace != null && trace.getType() != Type.MISS) {
               this.何何友友何树树树友何 = trace;
               this.树友树友友友树树树何 = this.何何友友何树树树友何.getLocation().x;
               this.友友何友何树友树友友 = this.何何友友何树树树友何.getLocation().y;
               this.友友何何何树何何友何 = this.何何友友何树树树友何.getLocation().z;
               list.add(new 友树友何友何友树何友(56143884807940L, this.树友树友友友树树树何, this.友友何友何树友树友友, this.友友何何何树何何友何));
            }

            this.树友树友友友树树树何 = this.树友树友友友树树树何 + this.友何友树何树何何何何;
            this.友友何友何树友树友友 = this.友友何友何树友树友友 + this.树何何友何友何何何友;
            this.友友何何何树何何友何 = this.友友何何何树何何友何 + this.何友树何何何树何何树;
            list.add(new 友树友何友何友树何友(56143884807940L, this.树友树友友友树树树何, this.友友何友何树友树友友, this.友友何何何树何何友何));
            this.友何友树何树何何何何 *= 0.99F;
            this.树何何友何友何何何友 *= 0.99F;
            this.何友树何何何树何何树 *= 0.99F;
            this.树何何友何友何何何友 -= 0.05F;
         }

         return list;
      }
   }

   public float H(long a) {
      a = 117849452486593L ^ a;
      a<"ß">(5450710237670572674L, (long)a);
      if (!a<"å">(this, 5450683911924747736L, (long)a).equals(a<"Õ">(5449919311191501932L, (long)a))) {
         return a<"å">(this, 5452378839938280446L, (long)a);
      } else {
         return !(a<"å">(this, 5452378839938280446L, (long)a) * BowItem.getPowerForTime(mc.player.getUseItemRemainingTicks()) > 0.0F)
            ? BowItem.getPowerForTime(20)
            : BowItem.getPowerForTime(mc.player.getUseItemRemainingTicks());
      }
   }

   private static String HE_SHU_YOU() {
      return "何树友为什么濒天了";
   }

   public static 何树何何树友树何何树[] G(long var0) {
      var0 = 117849452486593L ^ var0;
      return (何树何何树友树何何树[])a<"Õ">(-7703058100703896666L, var0).clone();
   }
}
