package cn.cool.cherish.utils.packet;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.other.BlinkEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.function.Consumer;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundPingPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.phys.Vec3;

public class BlinkUtils implements IWrapper, 何树友 {
   public static final BlinkUtils INSTANCE;
   public LinkedBlockingDeque<Packet<?>> 友何友树友何何何树友 = new LinkedBlockingDeque<>();
   public boolean pass = false;
   public boolean blinking = false;
   public Vec3 树何友何友友何树何树 = Vec3.ZERO;
   public Rotation 树树何树树何友树何树 = new Rotation(21273681362686L, 0.0F, 0.0F);
   public int 友树何树树何树何树友 = 0;
   public int 友何友何树树何树树树 = 0;
   private final List<Consumer<Packet<?>>> 友树何树友友树树何树 = new ArrayList<>();
   private final List<Consumer<Packet<?>>> 友何友友何友树树树何 = new ArrayList<>();
   private final List<Predicate<Packet<?>>> 树何何何友何树友何友 = new ArrayList<>();
   private static int[] 友树友树树何友友何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long f;
   private static final Object[] g = new Object[32];
   private static final String[] h = new String[32];
   private static int _行走的50万——何炜霖 _;

   private BlinkUtils(long a) {
      Cherish.instance.getEventManager().register(this);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-3938256995746460645L, 1958163201729178281L, MethodHandles.lookup().lookupClass()).a(150536271075093L);
      // $VF: monitorexit
      a = var10000;
      a();
      int[] var14 = new int[3];
      D(var14);
      Cipher var5;
      Cipher var15 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(45371094747437L << var6 * 8 >>> 56);
      }

      var15.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var12 = new String[2];
      int var10 = 0;
      char var8 = '(';
      int var7 = -1;

      while (true) {
         String var19 = b(
               var5.doFinal(
                  "\u0083}\u009dÁ1|\rË¿ÙkÑd\u0012Þ~BªëEU\u0092\u0000\u0094\u00156È.\u0084\u0094\u0015\r5\u009e?|õZMá8\u009a\u0004H}ß\u0005´e\u0080Át\u00adê ÞK9\u0006HÅ¶zÕ<\u0018ÞïYì\u0010ý\u001c\u009fh5\u009brë$\u009d%Å\u008f=äU÷ídÉ\u0085ä\r\u0087@á"
                     .substring(++var7, var7 + var8)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var12[var10++] = var19;
         if ((var7 += var8) >= 97) {
            b = var12;
            c = new String[2];
            Cipher var0;
            Cipher var16 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(45371094747437L << var1 * 8 >>> 56);
            }

            var16.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            byte[] var4 = var0.doFinal(new byte[]{28, 79, -12, 80, -17, -90, -7, -66});
            long var22 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            f = var22;
            INSTANCE = new BlinkUtils(140411311859444L);
            return;
         }

         var8 = "\u0083}\u009dÁ1|\rË¿ÙkÑd\u0012Þ~BªëEU\u0092\u0000\u0094\u00156È.\u0084\u0094\u0015\r5\u009e?|õZMá8\u009a\u0004H}ß\u0005´e\u0080Át\u00adê ÞK9\u0006HÅ¶zÕ<\u0018ÞïYì\u0010ý\u001c\u009fh5\u009brë$\u009d%Å\u008f=äU÷ídÉ\u0085ä\r\u0087@á"
            .charAt(var7);
      }
   }

   public static void D(int[] var0) {
      友树友树树何友友何何 = var0;
   }

   public static void I(long a, Consumer a) {
      a = 132226457634856L ^ a;
      b<"ª">(b<"R">(-2871493640615562875L, (long)a), -2872078777680847992L, (long)a).add(a);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (h[var4] != null) {
         return var4;
      } else {
         Object var5 = g[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 35;
               case 1 -> 17;
               case 2 -> 1;
               case 3 -> 14;
               case 4 -> 36;
               case 5 -> 54;
               case 6 -> 28;
               case 7 -> 29;
               case 8 -> 9;
               case 9 -> 30;
               case 10 -> 19;
               case 11 -> 63;
               case 12 -> 42;
               case 13 -> 58;
               case 14 -> 51;
               case 15 -> 13;
               case 16 -> 52;
               case 17 -> 41;
               case 18 -> 21;
               case 19 -> 48;
               case 20 -> 49;
               case 21 -> 43;
               case 22 -> 12;
               case 23 -> 32;
               case 24 -> 15;
               case 25 -> 56;
               case 26 -> 10;
               case 27 -> 11;
               case 28 -> 26;
               case 29 -> 24;
               case 30 -> 33;
               case 31 -> 20;
               case 32 -> 6;
               case 33 -> 47;
               case 34 -> 45;
               case 35 -> 61;
               case 36 -> 40;
               case 37 -> 31;
               case 38 -> 59;
               case 39 -> 46;
               case 40 -> 34;
               case 41 -> 60;
               case 42 -> 3;
               case 43 -> 7;
               case 44 -> 4;
               case 45 -> 5;
               case 46 -> 2;
               case 47 -> 16;
               case 48 -> 23;
               case 49 -> 22;
               case 50 -> 37;
               case 51 -> 38;
               case 52 -> 57;
               case 53 -> 44;
               case 54 -> 55;
               case 55 -> 62;
               case 56 -> 18;
               case 57 -> 25;
               case 58 -> 53;
               case 59 -> 27;
               case 60 -> 8;
               case 61 -> 39;
               case 62 -> 0;
               default -> 50;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            h[var4] = new String(var12);
            return var4;
         }
      }
   }

   public boolean add(Packet<?> packet) {
      PacketUtils.s();
      if (!PacketUtils.a(0, packet, 922630705, 3795)) {
         ClientUtils.P(125527250587045L, "Error to add a packet:" + packet.getClass().getName());
         return false;
      } else {
         BlinkEvent blinkEvent = new BlinkEvent(packet, this.友树何树树何树何树友);
         if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
            Cherish.instance.getEventManager().call(blinkEvent);
         }

         if (blinkEvent.isCancelled()) {
            return false;
         } else {
            Iterator var11 = this.树何何何友何树友何友.iterator();
            if (var11.hasNext()) {
               Predicate<Packet<?>> predicate = (Predicate<Packet<?>>)var11.next();
               if (predicate.test(packet)) {
                  return false;
               }
            }

            this.友何友友何友树树树何.forEach(consumer -> consumer.accept(packet));
            this.友何友树友何何何树友.add(packet);
            return true;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/packet/BlinkUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 170 && var8 != 251 && var8 != 'R' && var8 != 219) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 248) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'J') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 170) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'R') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public static int[] n() {
      return 友树友树树何友友何何;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         g[var4] = var21;
         return var21;
      }
   }

   public static void h(Consumer a, long packetConsumer) {
      packetConsumer = 132226457634856L ^ packetConsumer;
      b<"ª">(b<"R">(-565721224478011003L, (long)packetConsumer), -566036550985997734L, (long)packetConsumer).add(a);
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = g[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void l(long var0) {
      INSTANCE.k(17990600026496L);
      INSTANCE.j(4926543569241L);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/packet/BlinkUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      g[0] = "Oi \nv\u000e@)m\u0001|\u0013EtfGl\u0015Ek}Gi\u0000Olk\u001d7#@n`\u0002L\u0015Ek}";
      g[1] = "}\u000f]4)Qc\u0007G{KMd\u001a";
      g[2] = "o>c2B4d1r}) f:e'\u00057k";
      g[3] = "V|\u0016.)`Y<[%#}\\aPc3{\\~Kc6nVy]9h_TqS(2ZA{T>";
      g[4] = int.class;
      h[4] = "java/lang/Integer";
      g[5] = boolean.class;
      h[5] = "java/lang/Boolean";
      g[6] = "2:";
      g[7] = void.class;
      h[7] = "java/lang/Void";
      g[8] = "R\u0005uV\u0017HR\u0005b\n\u001bGHNv\u0017\bMXNq\u0010\u0003R\u00126d\u001bI";
      g[9] = double.class;
      h[9] = "java/lang/Double";
      g[10] = "F\u0014|J&>X\u001cf\u0005k$B\u0016\u007fYz.B\u0001$ga%G\u0010nid$O\u001ecEo\u000fI\u0004\u007fN";
      g[11] = "\u0011O;d4\u000e\u001e\u000fvo>\u0013\u001bR}).\u0015\u001bMf)3\u0004\u001eQpuu3\u001dUts2\u000e\u001c";
      g[12] = "\u000eXs\f\u0011-\u0005WbCp#\u000e\\f\u0019";
      g[13] = "6\n\u0002\u0004(\rk\u000f\u001c}\"uhO\u0005\u0005%HnTLMKL.H\u0005\u0013vJ5\u0001M}";
      g[14] = "\u0012\u0007\u0010'k\u0012P\u0012X:S\u000exLStlPx|T3*\u000f\u0017\u000e\u0016&b\u0012";
      g[15] = "0eGuO<rp\u000fhw Z.\u0004&H\u007fZ\u001e\u0000xM\u007f6xR'\u001c>";
      g[16] = "1!=NF%3!=\u0012:9\u000b}f\u000e\u00000ew3\u0010JB";
      g[17] = "\n'*7\u007f0W\"4N叟桑估栄桌伓栅伕桴叞Uuw1Wo;\u007f\"/\u001d";
      g[18] = "rU\u0013PsV/P\r)叓佳取伲桵栰位样栌桶l\u0012{W/\u001d\u0002\u0018.Ie";
      g[19] = "n\u0011\rj[Z3\u0014\u0013\u0013叻使及栲厱低佥使栐叨r,\b\u001bsZ\u0016sEB3";
      g[20] = "c&>I<\u0018!3vT\u0004\u0004\tm}\u001a4S\t]yD>[e;+\u001bo\u001a";
      g[21] = "C_7UP~\u001eZ),r@\u007f9\u0001jxK$\u0002rSJe\\_wM";
      g[22] = "Z{dt\u0015EX{d(ip`'?4SP\u000e-j*\u0019\"";
      g[23] = "vI\u0004Y&b+L\u001a 桜栃佌桪桢佽历栃佌桪{\u001f8xi\t\u0005\u001a/d(";
      g[24] = "A#\u0015@\u0005k\u001c&\u000b9桿低句佄厩叺伻栊佻栀j\u0004\u001djI!\u0018F\b\"T";
      g[25] = "N\u0011_\\C\u001d\u0013\u0014A%口桼佴栲口另根桼佴栲 Z\u001aX\u0012HRG\u0011\u0015";
      g[26] = "\u001a,>\bz-G) qUUA}z\u000f&i\u001d'=\u001f\u0019h\u0011h8\f(8\u0014h3q";
      g[27] = "r(!E\u0007\u0018/-?<桽伽佈住厝佡桽厣佈发^C^].q,^U\u0010";
      g[28] = "K\u0004!%?,\u0016\u0001?\\60MX==:;,\u0005>&m0O\u000f4$3";
      g[29] = "b\u0004*F8\u0007?\u00014?厘伢叆叽伈叼桂桦栜佣U@aB>]']j\u000f";
      g[30] = "B+hM6+\u0000> P\u000e7(`+\u001e>a(P/@4hD6}\u001fe)";
      g[31] = ":.\fLxug+\u00125cd&os\u000e{wlp\u0010\u0004qu2";
   }

   public void a(int a, long ticks) {
      int ax = PacketUtils.s();

      while (!INSTANCE.友何友树友何何何树友.isEmpty() && (a != 0 || ax == 0)) {
         Packet<?> packet = INSTANCE.友何友树友何何何树友.poll();
         if (packet instanceof ClientboundPingPacket) {
            this.友何友何树树何树树树--;
            a--;
            if (ax != 0) {
               continue;
            }
         }

         if (packet instanceof ServerboundMovePlayerPacket wrapper) {
            this.树何友何友友何树何树 = new Vec3(wrapper.getX(this.树何友何友友何树何树.x), wrapper.getY(this.树何友何友友何树何树.y), wrapper.getZ(this.树何友何友友何树何树.z));
            this.树树何树树何友树何树 = new Rotation(21273681362686L, wrapper.getYRot(this.树树何树树何友树何树.getYaw()), wrapper.getXRot(this.树树何树树何友树何树.l(5377274095808L)));
         }

         this.友树何树友友树树何树.forEach(consumer -> consumer.accept(packet));
         this.H(16257043521535L, packet);
         break;
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25494;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/packet/BlinkUtils", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public void k(long a) {
      long ax = 132226457634856L ^ a ^ 10991438858025L;
      this.a(Integer.MAX_VALUE, ax);
   }

   @EventTarget(4)
   public void t(MotionEvent event) {
      PacketUtils.s();
      if (!event.isPost()) {
         if (this.blinking) {
            this.友树何树树何树何树友++;
            this.友何友何树树何树树树++;
         }

         if (mc.player == null) {
            this.j(4926543569241L);
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (var5 instanceof String) {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         g[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void j(long a) {
      this.友树何树树何树何树友 = 0;
      this.友何友何树树何树树树 = 0;
      this.pass = false;
      this.blinking = false;
      PacketUtils.Z();
      this.友何友树友何何何树友.clear();
      this.友何友友何友树树树何.clear();
      this.树何何何友何树友何友.clear();
      this.友树何树友友树树何树.clear();
      this.树何友何友友何树何树 = mc.player == null ? Vec3.ZERO : mc.player.position();
      this.树树何树树何友树何树 = mc.player == null ? new Rotation(21273681362686L, 0.0F, 0.0F) : new Rotation(21273681362686L, mc.player.getYRot(), mc.player.getXRot());
   }

   public static void Y(int a, long ticks) {
      ticks = (int)(132226457634856L ^ ticks);
      long ax = ticks ^ 135521629830036L;
      b<"R">(-7129078911152835405L, (long)ticks).a((int)a, ax);
   }

   public static void W(long var0) {
      PacketUtils.s();
      if (INSTANCE.blinking) {
         l(102729178478887L);
      }

      INSTANCE.j(4926543569241L);
      INSTANCE.blinking = true;
   }

   public void H(long a, Packet var3) {
      a = 132226457634856L ^ a;
      long ax = a ^ 5093485845106L;
      long axx = a ^ 131050154766927L;
      long var10001 = a ^ 70872437446916L;
      int axxx = (int)((a ^ 70872437446916L) >>> 48);
      int axxxx = (int)((a ^ 70872437446916L) << 16 >>> 32);
      int axxxxx = (int)(var10001 << 48 >>> 48);
      b<"J">(6328364320551233018L, (long)a);

      try {
         b<"û">(b<"R">(6328121161507634801L, (long)a), true, 6327761261253397372L, (long)a);
         if (!PacketUtils.a((char)axxx, var3, axxxx, axxxxx)) {
            ClientUtils.P(new Object[]{ax, var3.getClass().getSimpleName() + a<"t">(25872, 3299733457540600144L ^ a)});
         }

         PacketUtils.i(new Object[]{var3, axx});
      } catch (Exception var18) {
         var18.printStackTrace();
      } finally {
         b<"û">(b<"R">(6328121161507634801L, (long)a), false, 6327761261253397372L, (long)a);
      }
   }

   private static String LIU_YA_FENG() {
      return "何炜霖黑水";
   }

   public static void G(long a, Predicate var2) {
      a = 132226457634856L ^ a;
      b<"ª">(b<"R">(-5040517562208709713L, (long)a), -5039532381596847226L, (long)a).add(var2);
   }
}
