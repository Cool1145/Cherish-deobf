package cn.cool.cherish.utils.packet;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.mapping.Mapping;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.prediction.PredictiveAction;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.protocol.game.ClientboundAddExperienceOrbPacket;
import net.minecraft.network.protocol.game.ClientboundAddPlayerPacket;
import net.minecraft.network.protocol.game.ClientboundAnimatePacket;
import net.minecraft.network.protocol.game.ClientboundAwardStatsPacket;
import net.minecraft.network.protocol.game.ClientboundBlockChangedAckPacket;
import net.minecraft.network.protocol.game.ClientboundBlockDestructionPacket;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.protocol.game.ClientboundBlockEventPacket;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundBossEventPacket;
import net.minecraft.network.protocol.game.ClientboundBundlePacket;
import net.minecraft.network.protocol.game.ClientboundChangeDifficultyPacket;
import net.minecraft.network.protocol.game.ClientboundChunksBiomesPacket;
import net.minecraft.network.protocol.game.ClientboundClearTitlesPacket;
import net.minecraft.network.protocol.game.ClientboundCommandSuggestionsPacket;
import net.minecraft.network.protocol.game.ClientboundCommandsPacket;
import net.minecraft.network.protocol.game.ClientboundContainerClosePacket;
import net.minecraft.network.protocol.game.ClientboundContainerSetContentPacket;
import net.minecraft.network.protocol.game.ClientboundContainerSetDataPacket;
import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket;
import net.minecraft.network.protocol.game.ClientboundCooldownPacket;
import net.minecraft.network.protocol.game.ClientboundCustomChatCompletionsPacket;
import net.minecraft.network.protocol.game.ClientboundCustomPayloadPacket;
import net.minecraft.network.protocol.game.ClientboundDamageEventPacket;
import net.minecraft.network.protocol.game.ClientboundDeleteChatPacket;
import net.minecraft.network.protocol.game.ClientboundDisconnectPacket;
import net.minecraft.network.protocol.game.ClientboundDisguisedChatPacket;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundForgetLevelChunkPacket;
import net.minecraft.network.protocol.game.ClientboundGameEventPacket;
import net.minecraft.network.protocol.game.ClientboundHorseScreenOpenPacket;
import net.minecraft.network.protocol.game.ClientboundHurtAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundInitializeBorderPacket;
import net.minecraft.network.protocol.game.ClientboundKeepAlivePacket;
import net.minecraft.network.protocol.game.ClientboundLevelChunkPacketData;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.network.protocol.game.ClientboundLevelEventPacket;
import net.minecraft.network.protocol.game.ClientboundLevelParticlesPacket;
import net.minecraft.network.protocol.game.ClientboundLightUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundLightUpdatePacketData;
import net.minecraft.network.protocol.game.ClientboundLoginPacket;
import net.minecraft.network.protocol.game.ClientboundMapItemDataPacket;
import net.minecraft.network.protocol.game.ClientboundMerchantOffersPacket;
import net.minecraft.network.protocol.game.ClientboundMoveEntityPacket;
import net.minecraft.network.protocol.game.ClientboundMoveVehiclePacket;
import net.minecraft.network.protocol.game.ClientboundOpenBookPacket;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import net.minecraft.network.protocol.game.ClientboundOpenSignEditorPacket;
import net.minecraft.network.protocol.game.ClientboundPingPacket;
import net.minecraft.network.protocol.game.ClientboundPlaceGhostRecipePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerChatPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerCombatEndPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerCombatEnterPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerCombatKillPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerLookAtPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.network.protocol.game.ClientboundRecipePacket;
import net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket;
import net.minecraft.network.protocol.game.ClientboundRemoveMobEffectPacket;
import net.minecraft.network.protocol.game.ClientboundResourcePackPacket;
import net.minecraft.network.protocol.game.ClientboundRespawnPacket;
import net.minecraft.network.protocol.game.ClientboundRotateHeadPacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSelectAdvancementsTabPacket;
import net.minecraft.network.protocol.game.ClientboundServerDataPacket;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetBorderCenterPacket;
import net.minecraft.network.protocol.game.ClientboundSetBorderLerpSizePacket;
import net.minecraft.network.protocol.game.ClientboundSetBorderSizePacket;
import net.minecraft.network.protocol.game.ClientboundSetBorderWarningDelayPacket;
import net.minecraft.network.protocol.game.ClientboundSetBorderWarningDistancePacket;
import net.minecraft.network.protocol.game.ClientboundSetCameraPacket;
import net.minecraft.network.protocol.game.ClientboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ClientboundSetChunkCacheCenterPacket;
import net.minecraft.network.protocol.game.ClientboundSetChunkCacheRadiusPacket;
import net.minecraft.network.protocol.game.ClientboundSetDefaultSpawnPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetDisplayObjectivePacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityDataPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityLinkPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ClientboundSetEquipmentPacket;
import net.minecraft.network.protocol.game.ClientboundSetExperiencePacket;
import net.minecraft.network.protocol.game.ClientboundSetHealthPacket;
import net.minecraft.network.protocol.game.ClientboundSetObjectivePacket;
import net.minecraft.network.protocol.game.ClientboundSetPassengersPacket;
import net.minecraft.network.protocol.game.ClientboundSetPlayerTeamPacket;
import net.minecraft.network.protocol.game.ClientboundSetScorePacket;
import net.minecraft.network.protocol.game.ClientboundSetSimulationDistancePacket;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundSoundEntityPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ClientboundTabListPacket;
import net.minecraft.network.protocol.game.ClientboundTagQueryPacket;
import net.minecraft.network.protocol.game.ClientboundTakeItemEntityPacket;
import net.minecraft.network.protocol.game.ClientboundTeleportEntityPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateAdvancementsPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateAttributesPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateEnabledFeaturesPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateRecipesPacket;
import net.minecraft.network.protocol.game.ClientboundUpdateTagsPacket;
import net.minecraft.network.protocol.game.ServerGamePacketListener;
import net.minecraft.network.protocol.game.ServerboundAcceptTeleportationPacket;
import net.minecraft.network.protocol.game.ServerboundBlockEntityTagQuery;
import net.minecraft.network.protocol.game.ServerboundChangeDifficultyPacket;
import net.minecraft.network.protocol.game.ServerboundChatAckPacket;
import net.minecraft.network.protocol.game.ServerboundChatCommandPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundChatSessionUpdatePacket;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.network.protocol.game.ServerboundClientInformationPacket;
import net.minecraft.network.protocol.game.ServerboundCommandSuggestionPacket;
import net.minecraft.network.protocol.game.ServerboundContainerButtonClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.network.protocol.game.ServerboundCustomPayloadPacket;
import net.minecraft.network.protocol.game.ServerboundEditBookPacket;
import net.minecraft.network.protocol.game.ServerboundEntityTagQuery;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundJigsawGeneratePacket;
import net.minecraft.network.protocol.game.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.game.ServerboundLockDifficultyPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMoveVehiclePacket;
import net.minecraft.network.protocol.game.ServerboundPaddleBoatPacket;
import net.minecraft.network.protocol.game.ServerboundPickItemPacket;
import net.minecraft.network.protocol.game.ServerboundPlaceRecipePacket;
import net.minecraft.network.protocol.game.ServerboundPlayerAbilitiesPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerInputPacket;
import net.minecraft.network.protocol.game.ServerboundPongPacket;
import net.minecraft.network.protocol.game.ServerboundRecipeBookChangeSettingsPacket;
import net.minecraft.network.protocol.game.ServerboundRecipeBookSeenRecipePacket;
import net.minecraft.network.protocol.game.ServerboundRenameItemPacket;
import net.minecraft.network.protocol.game.ServerboundResourcePackPacket;
import net.minecraft.network.protocol.game.ServerboundSeenAdvancementsPacket;
import net.minecraft.network.protocol.game.ServerboundSelectTradePacket;
import net.minecraft.network.protocol.game.ServerboundSetBeaconPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundSetCommandBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSetCommandMinecartPacket;
import net.minecraft.network.protocol.game.ServerboundSetCreativeModeSlotPacket;
import net.minecraft.network.protocol.game.ServerboundSetJigsawBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSetStructureBlockPacket;
import net.minecraft.network.protocol.game.ServerboundSignUpdatePacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundTeleportToEntityPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Pos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.PosRot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.Rot;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket.StatusOnly;

public final class PacketUtils implements IWrapper, 何树友 {
   private static final ArrayList<Packet<ServerGamePacketListener>> 何友何何何何树何友树;
   private static final Set<Class<?>> 友友友何树友何树友树;
   private static final Set<Class<?>> 何何何友何何何何友树;
   private static int 友树何何何树何树何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[19];
   private static final String[] g = new String[19];
   private static int _何树友，和树做朋友 _;

   private PacketUtils(long a) {
      a = 64195965506242L ^ a;
      super();
      throw new UnsupportedOperationException(a<"o">(12409, 3466474973930277948L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8747816343000593036L, -8307367111322553974L, MethodHandles.lookup().lookupClass()).a(1386034508794L);
      // $VF: monitorexit
      a = var10000;
      a();
      C(0);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(37117488706571L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[5];
      int var5 = 0;
      String var4 = "\u0095\u0092\u0091(\u00968\u001bì¨\u001e·ó¿µá¾\fÅ\u001c1EaÙ¸ä×\u009a\u0099\u009f\u001e\u000e² »q¸§L£gB2\u0089«´NÕf\u0098øj\u008eº\u001b\u008aìXc\u0094Qäu\u009e\u0092ºW¯s·\u009eþý\u0001Ev\u0087\u0015\u001dé\u001b>}w\u0094\u008dZþ7\u001fB\u001dPÉØl»æú\u0002\u009fã\u008cÂÅZs¼.¬Ò¥ú\u0080É\u0084MÓ4\u0082&þ4Ô\u001dö*·ö\u0093ù\u0018ÜÒÞ\u0098©3räß(¬I\u0082æ(-\u008cê@Æ\u0014Ö\u001dìéswn\u0081}\u0014\u0018`üI¡\u0007:ÕÔ\u001e1luq\u0015u\u0087È\u00adÝ,¹\nx";
      short var6 = 186;
      char var3 = '8';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[5];
                     何友何何何何树何友树 = new ArrayList<>();
                     友友友何树友何树友树 = new HashSet<>();
                     何何何友何何何何友树 = new HashSet<>();
                     友友友何树友何树友树.add(ServerboundAcceptTeleportationPacket.class);
                     友友友何树友何树友树.add(ServerboundBlockEntityTagQuery.class);
                     友友友何树友何树友树.add(ServerboundChangeDifficultyPacket.class);
                     友友友何树友何树友树.add(ServerboundChatAckPacket.class);
                     友友友何树友何树友树.add(ServerboundChatCommandPacket.class);
                     友友友何树友何树友树.add(ServerboundChatPacket.class);
                     友友友何树友何树友树.add(ServerboundChatSessionUpdatePacket.class);
                     友友友何树友何树友树.add(ServerboundClientCommandPacket.class);
                     友友友何树友何树友树.add(ServerboundClientInformationPacket.class);
                     友友友何树友何树友树.add(ServerboundCommandSuggestionPacket.class);
                     友友友何树友何树友树.add(ServerboundContainerButtonClickPacket.class);
                     友友友何树友何树友树.add(ServerboundContainerClickPacket.class);
                     友友友何树友何树友树.add(ServerboundContainerClosePacket.class);
                     友友友何树友何树友树.add(ServerboundCustomPayloadPacket.class);
                     友友友何树友何树友树.add(ServerboundEditBookPacket.class);
                     友友友何树友何树友树.add(ServerboundEntityTagQuery.class);
                     友友友何树友何树友树.add(ServerboundInteractPacket.class);
                     友友友何树友何树友树.add(ServerboundJigsawGeneratePacket.class);
                     友友友何树友何树友树.add(ServerboundKeepAlivePacket.class);
                     友友友何树友何树友树.add(ServerboundLockDifficultyPacket.class);
                     友友友何树友何树友树.add(ServerboundMovePlayerPacket.class);
                     友友友何树友何树友树.add(Pos.class);
                     友友友何树友何树友树.add(StatusOnly.class);
                     友友友何树友何树友树.add(Rot.class);
                     友友友何树友何树友树.add(PosRot.class);
                     友友友何树友何树友树.add(ServerboundMoveVehiclePacket.class);
                     友友友何树友何树友树.add(ServerboundPaddleBoatPacket.class);
                     友友友何树友何树友树.add(ServerboundPickItemPacket.class);
                     友友友何树友何树友树.add(ServerboundPlaceRecipePacket.class);
                     友友友何树友何树友树.add(ServerboundPlayerAbilitiesPacket.class);
                     友友友何树友何树友树.add(ServerboundPlayerActionPacket.class);
                     友友友何树友何树友树.add(ServerboundPlayerCommandPacket.class);
                     友友友何树友何树友树.add(ServerboundPlayerInputPacket.class);
                     友友友何树友何树友树.add(ServerboundPongPacket.class);
                     友友友何树友何树友树.add(ServerboundRecipeBookChangeSettingsPacket.class);
                     友友友何树友何树友树.add(ServerboundRecipeBookSeenRecipePacket.class);
                     友友友何树友何树友树.add(ServerboundRenameItemPacket.class);
                     友友友何树友何树友树.add(ServerboundResourcePackPacket.class);
                     友友友何树友何树友树.add(ServerboundSeenAdvancementsPacket.class);
                     友友友何树友何树友树.add(ServerboundSelectTradePacket.class);
                     友友友何树友何树友树.add(ServerboundSetBeaconPacket.class);
                     友友友何树友何树友树.add(ServerboundSetCarriedItemPacket.class);
                     友友友何树友何树友树.add(ServerboundSetCommandBlockPacket.class);
                     友友友何树友何树友树.add(ServerboundSetCommandMinecartPacket.class);
                     友友友何树友何树友树.add(ServerboundSetCreativeModeSlotPacket.class);
                     友友友何树友何树友树.add(ServerboundSetJigsawBlockPacket.class);
                     友友友何树友何树友树.add(ServerboundSetStructureBlockPacket.class);
                     友友友何树友何树友树.add(ServerboundSignUpdatePacket.class);
                     友友友何树友何树友树.add(ServerboundSwingPacket.class);
                     友友友何树友何树友树.add(ServerboundTeleportToEntityPacket.class);
                     友友友何树友何树友树.add(ServerboundUseItemOnPacket.class);
                     友友友何树友何树友树.add(ServerboundUseItemPacket.class);
                     何何何友何何何何友树.add(ClientboundAddEntityPacket.class);
                     何何何友何何何何友树.add(ClientboundAddExperienceOrbPacket.class);
                     何何何友何何何何友树.add(ClientboundAddPlayerPacket.class);
                     何何何友何何何何友树.add(ClientboundAnimatePacket.class);
                     何何何友何何何何友树.add(ClientboundAwardStatsPacket.class);
                     何何何友何何何何友树.add(ClientboundBlockChangedAckPacket.class);
                     何何何友何何何何友树.add(ClientboundBlockDestructionPacket.class);
                     何何何友何何何何友树.add(ClientboundBlockEntityDataPacket.class);
                     何何何友何何何何友树.add(ClientboundBlockEventPacket.class);
                     何何何友何何何何友树.add(ClientboundBlockUpdatePacket.class);
                     何何何友何何何何友树.add(ClientboundBossEventPacket.class);
                     何何何友何何何何友树.add(ClientboundBundlePacket.class);
                     何何何友何何何何友树.add(ClientboundChangeDifficultyPacket.class);
                     何何何友何何何何友树.add(ClientboundChunksBiomesPacket.class);
                     何何何友何何何何友树.add(ClientboundClearTitlesPacket.class);
                     何何何友何何何何友树.add(ClientboundCommandsPacket.class);
                     何何何友何何何何友树.add(ClientboundCommandSuggestionsPacket.class);
                     何何何友何何何何友树.add(ClientboundContainerClosePacket.class);
                     何何何友何何何何友树.add(ClientboundContainerSetContentPacket.class);
                     何何何友何何何何友树.add(ClientboundContainerSetDataPacket.class);
                     何何何友何何何何友树.add(ClientboundContainerSetSlotPacket.class);
                     何何何友何何何何友树.add(ClientboundCooldownPacket.class);
                     何何何友何何何何友树.add(ClientboundCustomChatCompletionsPacket.class);
                     何何何友何何何何友树.add(ClientboundCustomPayloadPacket.class);
                     何何何友何何何何友树.add(ClientboundDamageEventPacket.class);
                     何何何友何何何何友树.add(ClientboundDeleteChatPacket.class);
                     何何何友何何何何友树.add(ClientboundDisconnectPacket.class);
                     何何何友何何何何友树.add(ClientboundDisguisedChatPacket.class);
                     何何何友何何何何友树.add(ClientboundEntityEventPacket.class);
                     何何何友何何何何友树.add(ClientboundExplodePacket.class);
                     何何何友何何何何友树.add(ClientboundForgetLevelChunkPacket.class);
                     何何何友何何何何友树.add(ClientboundGameEventPacket.class);
                     何何何友何何何何友树.add(ClientboundHorseScreenOpenPacket.class);
                     何何何友何何何何友树.add(ClientboundHurtAnimationPacket.class);
                     何何何友何何何何友树.add(ClientboundInitializeBorderPacket.class);
                     何何何友何何何何友树.add(ClientboundKeepAlivePacket.class);
                     何何何友何何何何友树.add(ClientboundLevelChunkPacketData.class);
                     何何何友何何何何友树.add(ClientboundLevelChunkWithLightPacket.class);
                     何何何友何何何何友树.add(ClientboundLevelEventPacket.class);
                     何何何友何何何何友树.add(ClientboundLevelParticlesPacket.class);
                     何何何友何何何何友树.add(ClientboundLightUpdatePacket.class);
                     何何何友何何何何友树.add(ClientboundLightUpdatePacketData.class);
                     何何何友何何何何友树.add(ClientboundLoginPacket.class);
                     何何何友何何何何友树.add(ClientboundMapItemDataPacket.class);
                     何何何友何何何何友树.add(ClientboundMerchantOffersPacket.class);
                     何何何友何何何何友树.add(ClientboundMoveEntityPacket.class);
                     何何何友何何何何友树.add(ClientboundMoveVehiclePacket.class);
                     何何何友何何何何友树.add(ClientboundOpenBookPacket.class);
                     何何何友何何何何友树.add(ClientboundOpenScreenPacket.class);
                     何何何友何何何何友树.add(ClientboundOpenSignEditorPacket.class);
                     何何何友何何何何友树.add(ClientboundPingPacket.class);
                     何何何友何何何何友树.add(ClientboundPlaceGhostRecipePacket.class);
                     何何何友何何何何友树.add(ClientboundPlayerAbilitiesPacket.class);
                     何何何友何何何何友树.add(ClientboundPlayerChatPacket.class);
                     何何何友何何何何友树.add(ClientboundPlayerCombatEndPacket.class);
                     何何何友何何何何友树.add(ClientboundPlayerCombatEnterPacket.class);
                     何何何友何何何何友树.add(ClientboundPlayerCombatKillPacket.class);
                     何何何友何何何何友树.add(ClientboundPlayerInfoRemovePacket.class);
                     何何何友何何何何友树.add(ClientboundPlayerInfoUpdatePacket.class);
                     何何何友何何何何友树.add(ClientboundPlayerLookAtPacket.class);
                     何何何友何何何何友树.add(ClientboundPlayerPositionPacket.class);
                     何何何友何何何何友树.add(ClientboundRecipePacket.class);
                     何何何友何何何何友树.add(ClientboundRemoveEntitiesPacket.class);
                     何何何友何何何何友树.add(ClientboundRemoveMobEffectPacket.class);
                     何何何友何何何何友树.add(ClientboundResourcePackPacket.class);
                     何何何友何何何何友树.add(ClientboundRespawnPacket.class);
                     何何何友何何何何友树.add(ClientboundRotateHeadPacket.class);
                     何何何友何何何何友树.add(ClientboundSectionBlocksUpdatePacket.class);
                     何何何友何何何何友树.add(ClientboundSelectAdvancementsTabPacket.class);
                     何何何友何何何何友树.add(ClientboundServerDataPacket.class);
                     何何何友何何何何友树.add(ClientboundSetActionBarTextPacket.class);
                     何何何友何何何何友树.add(ClientboundSetBorderCenterPacket.class);
                     何何何友何何何何友树.add(ClientboundSetBorderLerpSizePacket.class);
                     何何何友何何何何友树.add(ClientboundSetBorderSizePacket.class);
                     何何何友何何何何友树.add(ClientboundSetBorderWarningDelayPacket.class);
                     何何何友何何何何友树.add(ClientboundSetBorderWarningDistancePacket.class);
                     何何何友何何何何友树.add(ClientboundSetCameraPacket.class);
                     何何何友何何何何友树.add(ClientboundSetCarriedItemPacket.class);
                     何何何友何何何何友树.add(ClientboundSetChunkCacheCenterPacket.class);
                     何何何友何何何何友树.add(ClientboundSetChunkCacheRadiusPacket.class);
                     何何何友何何何何友树.add(ClientboundSetDefaultSpawnPositionPacket.class);
                     何何何友何何何何友树.add(ClientboundSetDisplayObjectivePacket.class);
                     何何何友何何何何友树.add(ClientboundSetEntityDataPacket.class);
                     何何何友何何何何友树.add(ClientboundSetEntityLinkPacket.class);
                     何何何友何何何何友树.add(ClientboundSetEntityMotionPacket.class);
                     何何何友何何何何友树.add(ClientboundSetEquipmentPacket.class);
                     何何何友何何何何友树.add(ClientboundSetExperiencePacket.class);
                     何何何友何何何何友树.add(ClientboundSetHealthPacket.class);
                     何何何友何何何何友树.add(ClientboundSetObjectivePacket.class);
                     何何何友何何何何友树.add(ClientboundSetPassengersPacket.class);
                     何何何友何何何何友树.add(ClientboundSetPlayerTeamPacket.class);
                     何何何友何何何何友树.add(ClientboundSetScorePacket.class);
                     何何何友何何何何友树.add(ClientboundSetSimulationDistancePacket.class);
                     何何何友何何何何友树.add(ClientboundSetSubtitleTextPacket.class);
                     何何何友何何何何友树.add(ClientboundSetTimePacket.class);
                     何何何友何何何何友树.add(ClientboundSetTitlesAnimationPacket.class);
                     何何何友何何何何友树.add(ClientboundSetTitleTextPacket.class);
                     何何何友何何何何友树.add(ClientboundSoundEntityPacket.class);
                     何何何友何何何何友树.add(ClientboundSoundPacket.class);
                     何何何友何何何何友树.add(ClientboundStopSoundPacket.class);
                     何何何友何何何何友树.add(ClientboundSystemChatPacket.class);
                     何何何友何何何何友树.add(ClientboundTabListPacket.class);
                     何何何友何何何何友树.add(ClientboundTagQueryPacket.class);
                     何何何友何何何何友树.add(ClientboundTakeItemEntityPacket.class);
                     何何何友何何何何友树.add(ClientboundTeleportEntityPacket.class);
                     何何何友何何何何友树.add(ClientboundUpdateAdvancementsPacket.class);
                     何何何友何何何何友树.add(ClientboundUpdateAttributesPacket.class);
                     何何何友何何何何友树.add(ClientboundUpdateEnabledFeaturesPacket.class);
                     何何何友何何何何友树.add(ClientboundUpdateMobEffectPacket.class);
                     何何何友何何何何友树.add(ClientboundUpdateRecipesPacket.class);
                     何何何友何何何何友树.add(ClientboundUpdateTagsPacket.class);
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "ðhª\t\u0087¸\u007fWêfÇ¿\u009b<nÉÏü\u0094¾¯Ã(\u008dÒ\u0080\u001e¿Y·\fI\n\u0098-U½]wp8Ï\u0083ÿêV§hÛ5#\u0016MÊå®þÐ\u0093©Y\nü\u008e(æfã\u0016\u008fGcÏYÊ×ÔBPÜ\u0095\u008dMg\u007f\rZé8x)Y5[\u0097\u0088n";
                  var6 = 97;
                  var3 = '(';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public static void C(int var0) {
      友树何何何树何树何何 = var0;
   }

   public static void F(Packet a, long packet) {
      何友何何何何树何友树.add(a);
      a(112543050219290L, a);
   }

   public static int Z() {
      return 友树何何何树何树何何;
   }

   public static void V(long a, Packet a) {
      if (s() != 0) {
         if (mc.getConnection() == null) {
            return;
         }

         a.handle(mc.getConnection());
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 19;
               case 1 -> 0;
               case 2 -> 26;
               case 3 -> 12;
               case 4 -> 14;
               case 5 -> 38;
               case 6 -> 33;
               case 7 -> 17;
               case 8 -> 10;
               case 9 -> 28;
               case 10 -> 8;
               case 11 -> 37;
               case 12 -> 40;
               case 13 -> 21;
               case 14 -> 30;
               case 15 -> 2;
               case 16 -> 15;
               case 17 -> 23;
               case 18 -> 52;
               case 19 -> 13;
               case 20 -> 39;
               case 21 -> 56;
               case 22 -> 18;
               case 23 -> 25;
               case 24 -> 9;
               case 25 -> 1;
               case 26 -> 59;
               case 27 -> 53;
               case 28 -> 6;
               case 29 -> 29;
               case 30 -> 16;
               case 31 -> 54;
               case 32 -> 58;
               case 33 -> 48;
               case 34 -> 62;
               case 35 -> 5;
               case 36 -> 44;
               case 37 -> 11;
               case 38 -> 49;
               case 39 -> 42;
               case 40 -> 34;
               case 41 -> 43;
               case 42 -> 51;
               case 43 -> 63;
               case 44 -> 45;
               case 45 -> 57;
               case 46 -> 31;
               case 47 -> 3;
               case 48 -> 50;
               case 49 -> 55;
               case 50 -> 32;
               case 51 -> 35;
               case 52 -> 46;
               case 53 -> 61;
               case 54 -> 47;
               case 55 -> 7;
               case 56 -> 24;
               case 57 -> 27;
               case 58 -> 4;
               case 59 -> 41;
               case 60 -> 20;
               case 61 -> 36;
               case 62 -> 60;
               default -> 22;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static void i(Packet a, long a) {
      a = 64195965506242L ^ a;
      long ax = a ^ 81309623810815L;
      long axx = a ^ 83545418826989L;
      long axxx = a ^ 22040744803127L;
      long axxxx = a ^ 112107885267775L;
      long var10001 = a ^ 14465217149321L;
      int axxxxx = (int)((a ^ 14465217149321L) >>> 48);
      int axxxxxx = (int)((a ^ 14465217149321L) << 16 >>> 32);
      int axxxxxxx = (int)(var10001 << 48 >>> 48);
      int axxxxxxxx = b<"Ñ">(3988429724456643619L, a);
      if (a((char)axxxxx, a, axxxxxx, axxxxxxx)) {
         F(a, axx);
         int var10000 = axxxxxxxx;
         if (a >= 0L) {
            if (axxxxxxxx != 0) {
               return;
            }

            var10000 = 2;
         }

         b<"Ñ">(new Module[var10000], 3988329733731523669L, a);
      }

      Packet var18;
      label19: {
         if (K(axxx, a)) {
            var18 = a;
            if (a < 0L) {
               break label19;
            }

            V(axxxx, a);
         }

         var18 = a;
      }

      ClientUtils.P(ax, a<"o">(29408, 9020899474688906347L ^ a) + var18.getClass().getName());
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 220 && var8 != 'u' && var8 != 208 && var8 != 'a') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 240) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 209) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 220) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 208) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/packet/PacketUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static int s() {
      Z();

      try {
         return 8;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "m\u00122\\`\u0013bR\u007fWj\u000eg\u000ft\u0011z\bg\u0010o\u0011\u007f\u001dm\u0017yK!,o\u001fwZ{)z\u0015pL";
      f[1] = int.class;
      g[1] = "java/lang/Integer";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = "Ml\t5ryB,D>xdGqOxpyJwK33[AfR:x";
      f[4] = "\u001cnuer+(Mz%? \"P\u007fx4f*Mr~0-ioyo)$\"\u0019";
      f[5] = "*_6doc!P'+\u0015g2Q7d#c%";
      f[6] = "ZeO\u000f: DmU@U'Be@\"}&D";
      f[7] = "e\u0012JP uQ1E\u0010m~[,@Mf8S1MKbs\u0010\u0013FZ{z[e";
      f[8] = "oX\u0013V<<qP\t\u0019A,q";
      f[9] = "@T\u0011`^GK[\u0000/?I@P\u0004u";
      f[10] = "/~8V?\bqaxn优佬佉叙伛伳优佬受栃FS\"_he*\u001f$S%";
      f[11] = "Hj\u001c.\t=\u0016u\\\u00168\u0004Jb\u001fsI=\u001d4\u0006*s=\t?\r(Hb\u001f\u007f\u001f\u0016";
      f[12] = "cw[v7!8vJvR\u0002Y.Nj#58u\b!jP";
      f[13] = "x~[\nP\u000f#\u007fJ\n5 B'N\u0016D\u001b#|\b]\r~{a\u0001\b\u000bE$wA\u001a5";
      f[14] = "n\u001e(Ctx0\u0001h{uAl\u0016+\u001e4x;@2G\u000e";
      f[15] = "h?\u007f,\u0017F6 ?\u0014估厼伎伆作佉桴伢厐桂\u0001(\u0015\u001eba:)Q\u0012:";
      f[16] = "a\u0018,\u001cf\u007f?\u0007l$uFa\u0004 Df:c\u00187Z\u001c}\"\u000e2^`\u007f>\u0019,$";
      f[17] = "\u0004$\u000e4FoZ;N\fnV\u0006,\ri\u0006oQz\u00140<";
      f[18] = ";r(|MOemhD叴厵參佋桏厇佪桯參栏VyP\u0018|i:5V\u00141";
   }

   public static void a(long a, Packet a) {
      Z();
      if (mc.getConnection() != null) {
         mc.getConnection().send(a);
      }
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   public static boolean a(int a, Packet a, int a, int a) {
      return 友友友何树友何树友树.contains(a.getClass());
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/packet/PacketUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20946;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/packet/PacketUtils", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[Í\u008a¨ÑD9j\u0086ÿÇIú\u000fL\u008cH\u0096\u0092()\u0090ÉO'ÊW\u009eã\u00100ª\u0006, Ú\u0092t\u0007¾Î×\u0017\u001c¤ç}\tM\u0081\u0096\u009eò:£ö\u0001\u0099¼Ç\u000f\u001b\u0013vë$<\u0000\u001f@Ë9Ä\u009e6\u0007Èh°zëÒ4¥\u0004.w\u0000ì°e, \u0098W\u0094")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   public static void t(PredictiveAction a, long a) {
      b<"Ñ">(-1127276343455246934L, 99327850639455L);
      if (mc.getConnection() != null && mc.level != null) {
         try {
            Mapping.get(ClientLevel.class, "blockStatePredictionHandler", null);
         } catch (Exception var10) {
            var10.printStackTrace();
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void z(long a, PredictiveAction var2) {
      a = 64195965506242L ^ a;
      b<"Ñ">(6183320615668321973L, (long)a);
      if (mc.getConnection() != null && mc.level != null) {
         try {
            Mapping.get(ClientLevel.class, a<"o">(7016, 3112141310221295474L ^ a), null);
         } catch (Exception var10) {
            var10.printStackTrace();
         }
      }
   }

   public static void y(long a, Packet a) {
      int ax;
      label26: {
         a = 64195965506242L ^ a;
         long axx = a ^ 132001689329047L;
         long axxx = a ^ 119296582004520L;
         long axxxx = a ^ 41740978396255L;
         long axxxxx = a ^ 92408106626135L;
         long var10001 = a ^ 66909765770977L;
         int axxxxxx = (int)((a ^ 66909765770977L) >>> 48);
         int axxxxxxx = (int)((a ^ 66909765770977L) << 16 >>> 32);
         int axxxxxxxx = (int)(var10001 << 48 >>> 48);
         ax = b<"Ñ">(1168205065987945927L, (long)a);
         if (a((char)axxxxxx, a, axxxxxxx, axxxxxxxx)) {
            a(axxx, a);
            if (a <= 0L) {
               break label26;
            }
         }

         if (K(axxxx, a)) {
            V(axxxxx, a);
            if (a < 0L) {
               break label26;
            }
         }

         ClientUtils.P(axx, a<"o">(17843, 8887578711049897041L ^ a) + a.getClass().getName());
      }

      if (a > 0L && b<"Ñ">(1166741120599417940L, (long)a) == null) {
         b<"Ñ">(++ax, 1166707581653063570L, (long)a);
      }
   }

   public static boolean K(long a, Packet a) {
      a = 64195965506242L ^ a;
      return b<"Ð">(-2401073447019304713L, (long)a).contains(a.getClass());
   }

   private static String LIU_YA_FENG() {
      return "何炜霖大狗叫";
   }

   public static boolean handleSendPacket(Packet<ServerGamePacketListener> packet) {
      Z();
      if (mc.level != null && mc.player != null) {
      }

      return false;
   }
}
