package cn.cool.cherish.utils.item;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.google.common.collect.Multimap;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BookItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ExperienceBottleItem;
import net.minecraft.world.item.FireworkRocketItem;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.PlayerHeadItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.AttachedStemBlock;
import net.minecraft.world.level.block.BannerBlock;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.BeaconBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.BeehiveBlock;
import net.minecraft.world.level.block.BlastFurnaceBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BrewingStandBlock;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.CactusBlock;
import net.minecraft.world.level.block.CakeBlock;
import net.minecraft.world.level.block.CartographyTableBlock;
import net.minecraft.world.level.block.CauldronBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.CocoaBlock;
import net.minecraft.world.level.block.CommandBlock;
import net.minecraft.world.level.block.ComparatorBlock;
import net.minecraft.world.level.block.ComposterBlock;
import net.minecraft.world.level.block.CraftingTableBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.EnchantmentTableBlock;
import net.minecraft.world.level.block.EnderChestBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.FlowerPotBlock;
import net.minecraft.world.level.block.FurnaceBlock;
import net.minecraft.world.level.block.GrindstoneBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.JigsawBlock;
import net.minecraft.world.level.block.JukeboxBlock;
import net.minecraft.world.level.block.KelpBlock;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.LoomBlock;
import net.minecraft.world.level.block.NoteBlock;
import net.minecraft.world.level.block.PressurePlateBlock;
import net.minecraft.world.level.block.RedStoneWireBlock;
import net.minecraft.world.level.block.RedstoneTorchBlock;
import net.minecraft.world.level.block.RepeaterBlock;
import net.minecraft.world.level.block.SeaPickleBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.SignBlock;
import net.minecraft.world.level.block.SmokerBlock;
import net.minecraft.world.level.block.SpawnerBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.StonecutterBlock;
import net.minecraft.world.level.block.StructureBlock;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.SweetBerryBushBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.TripWireHookBlock;
import net.minecraft.world.level.block.TurtleEggBlock;
import net.minecraft.world.level.block.WallBannerBlock;
import net.minecraft.world.level.block.state.BlockState;

public final class 友何树树何树何何何友 implements IWrapper, 何树友 {
   private static String 何树友何友友友树树何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[73];
   private static final String[] g = new String[73];
   private static int _何炜霖大狗叫 _;

   private 友何树树何树何何何友(long a) {
      a = 105118243978134L ^ a;
      super();
      throw new UnsupportedOperationException(a<"e">(25637, 2078005232738649342L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3183213178806329328L, -6956634230936641201L, MethodHandles.lookup().lookupClass()).a(93007342479956L);
      // $VF: monitorexit
      a = var10000;
      a();
      E(null);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(62580093667455L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[14];
      int var5 = 0;
      String var4 = "s\u009b\f·à\u0080\u0012O\u0087\u00816&\u0087¤n\r\u0010k\u007fÇD\u008cÕ§%C\fÓÇD6-À(ÑÏÆÚ\u001b¨\u0017}Þ}6EÏ\nÌ1FÒ,`\u009ey;\u0082½1èë\u0015ð²H+\u008b\u0096\u0099V§j\u000b\u0010\rjý\u0092u\n ù\u0015ãºUaâ<\u0003\u0010u\u001d>ÂÁÞ\"mG2\u008c½È&\b· Õû\u0017$È\u0013J\u001eí¹¨%Å\u0081\u000b\u0096ò¹Ä«\u0087$²\u0014j\\\u008dÒ\u0019b\u00011 ¢ùÝ¯\u009cNv»\u009bhB\u0011®V\u0099\u001c¢\u001dDJ´F´ûø\u0007¬¯!\"\u00adÈ@L\u001a\u0016\u0092þÖ³x#®4\u009b\u0084\u0017 Ôx+Ó\u0088,«\u0082_å\u0011XzpÏ1.\u0081'¹õ\u0013æ\u0097Z×îkÿ4_³]eÍí\u0019öÀ¹¬\u009c\u009b\u0080\u008ea\u009bn\u0013\u0018,\u001e¹\u0002¤Y\u0080\u0088Â\u0011W±ÁÊè\u0098ÚþH\u0019?p(\t\u0010\u0010xñ\u0016Ò\u0097³Ï\u009f\u0090¡Õ\u0083V\u008a'X\u0000ì\n\u0093½j\u000e5¯?\u0093¹Bs \u0018\u0094\u0003«Å\u0000HÊ7J¯¢\u0091\u0082W\u008f\u000b\u0000ðHtK\u008bfk}´\u001fùFºý\u0080lE6¨ \u0018\u007fôÂ<µ\u0011\u009cp!XáG\\Îü\u0092.xkës%òà¢¦®OMôó´Y>\u0010h\u0082\u008aÚû\nN;\u008d\u001f\u000bÛW/\u0000«";
      short var6 = 387;
      char var3 = 16;
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[14];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "\u008e\u0010²ë§±\u008eºÈ\u008e\u00011ÀzúM³§hì\u001b\bð\u008e \u0010\u008fõ\u0082i¡\u0099?_\u000fW¤ú!+uÉ`¸\u001f¢\u0085üNW\u0084tÆ$,WF";
                  var6 = 57;
                  var3 = 24;
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public static float B(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof BowItem && e(11871436426037L, item);
      }).map(友何树树何树何何何友::R).max(Float::compareTo).orElse(0.0F);
   }

   public static ItemStack C(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof AxeItem && !r(124830374301047L, item) && e(11871436426037L, item);
      }).max(Comparator.comparingInt(s -> (int)(y(s) * 100.0F))).orElse(null);
   }

   public static int D(long var0) {
      return G(6772021905124L)
         .stream()
         .filter(
            item -> {
               l();
               return !item.isEmpty()
                  && item.getItem().isEdible()
                  && item.getItem() != Items.GOLDEN_APPLE
                  && item.getItem() != Items.ENCHANTED_GOLDEN_APPLE
                  && e(11871436426037L, item);
            }
         )
         .mapToInt(ItemStack::getCount)
         .sum();
   }

   public static int I(long a, Item var2) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() == var2;
      }).mapToInt(ItemStack::getCount).sum();
   }

   public static int J(long var0, int var2) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() == Items.FISHING_ROD && e(11871436426037L, item);
      }).mapToInt(ItemStack::getCount).sum();
   }

   public static float S(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof ShovelItem && e(11871436426037L, item);
      }).map(友何树树何树何何何友::y).max(Float::compareTo).orElse(0.0F);
   }

   public static ItemStack V(int var0, int var1, int var2) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof CrossbowItem && e(11871436426037L, item);
      }).max(Comparator.comparingInt(s -> (int)(p(s) * 100.0F))).orElse(null);
   }

   public static float V(ItemStack stack) {
      l();
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else {
         return stack.getItem() instanceof BowItem
            ? 10.0F
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.PUNCH_ARROWS, stack)
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.INFINITY_ARROWS, stack)
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.FLAMING_ARROWS, stack)
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.POWER_ARROWS, stack) / 10.0F
               + (float)stack.getDamageValue() / stack.getMaxDamage()
            : 0.0F;
      }
   }

   public static int V(ItemStack a, long a) {
      l();
      return -1;
   }

   public static boolean e(long a, ItemStack var2) {
      String ax = b<"h">(3505914799683280267L, 93830931493027L);
      if (!var2.isEmpty()) {
         if (var2.getItem() instanceof PlayerHeadItem) {
            return false;
         } else {
            String string = var2.getDisplayName().getString();
            boolean var10000 = string.contains("Click");
            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = string.contains("Right");
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = string.contains("点击");
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = string.contains("Teleport");
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = string.contains("使用");
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = string.contains("传送");
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = string.contains("再来");
            }

            if (ax == null) {
               var10000 = !var10000;
            }

            return var10000;
         }
      } else {
         return true;
      }
   }

   public static ItemStack e(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof AxeItem && r(124830374301047L, item) && e(11871436426037L, item) && !T(item, 12770860351312L);
      }).max(Comparator.comparingInt(s -> (int)(f(s, 110428489576482L) * 100.0F))).orElse(null);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 40;
               case 1 -> 30;
               case 2 -> 52;
               case 3 -> 58;
               case 4 -> 54;
               case 5 -> 57;
               case 6 -> 26;
               case 7 -> 59;
               case 8 -> 43;
               case 9 -> 53;
               case 10 -> 5;
               case 11 -> 10;
               case 12 -> 17;
               case 13 -> 34;
               case 14 -> 45;
               case 15 -> 61;
               case 16 -> 41;
               case 17 -> 31;
               case 18 -> 27;
               case 19 -> 32;
               case 20 -> 4;
               case 21 -> 1;
               case 22 -> 21;
               case 23 -> 11;
               case 24 -> 63;
               case 25 -> 28;
               case 26 -> 23;
               case 27 -> 44;
               case 28 -> 7;
               case 29 -> 56;
               case 30 -> 14;
               case 31 -> 2;
               case 32 -> 50;
               case 33 -> 0;
               case 34 -> 13;
               case 35 -> 16;
               case 36 -> 42;
               case 37 -> 47;
               case 38 -> 29;
               case 39 -> 46;
               case 40 -> 24;
               case 41 -> 33;
               case 42 -> 51;
               case 43 -> 49;
               case 44 -> 6;
               case 45 -> 8;
               case 46 -> 3;
               case 47 -> 60;
               case 48 -> 22;
               case 49 -> 37;
               case 50 -> 9;
               case 51 -> 15;
               case 52 -> 39;
               case 53 -> 55;
               case 54 -> 48;
               case 55 -> 20;
               case 56 -> 35;
               case 57 -> 19;
               case 58 -> 62;
               case 59 -> 36;
               case 60 -> 38;
               case 61 -> 25;
               case 62 -> 18;
               default -> 12;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'D' && var8 != 238 && var8 != 'A' && var8 != 214) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'I') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'h') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'D') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 238) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'A') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static ItemStack b(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof BowItem && e(11871436426037L, item);
      }).max(Comparator.comparingInt(s -> (int)(V(s) * 100.0F))).orElse(null);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/item/友何树树何树何何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static ItemStack x(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof BlockItem && 树何树树何何树友何何.H(83539975070260L, item) && e(11871436426037L, item);
      }).min(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static boolean x(ItemStack a, long stack) {
      String ax = l();
      if (a.isEmpty()) {
         return true;
      } else {
         Item item = a.getItem();
         boolean var10000 = item instanceof BlockItem;
         if (ax == null) {
            if (var10000) {
               BlockItem block = (BlockItem)item;
               if (block.getBlock() == Blocks.ENCHANTING_TABLE) {
                  return false;
               }

               return block.getBlock() != Blocks.COBWEB;
            }

            var10000 = item instanceof BookItem;
         }

         if (ax == null) {
            if (var10000) {
               return false;
            }

            var10000 = item instanceof ExperienceBottleItem;
         }

         if (ax == null) {
            if (var10000) {
               return false;
            }

            var10000 = item instanceof FireworkRocketItem;
         }

         if (var10000) {
            return false;
         } else {
            Item var7 = item;
            Item var10001 = Items.WHEAT_SEEDS;
            if (ax == null) {
               if (item == Items.WHEAT_SEEDS) {
                  return false;
               }

               var7 = item;
               var10001 = Items.BEETROOT_SEEDS;
            }

            if (ax == null) {
               if (var7 == var10001) {
                  return false;
               }

               var7 = item;
               var10001 = Items.MELON_SEEDS;
            }

            if (ax == null) {
               if (var7 == var10001) {
                  return false;
               }

               var7 = item;
               var10001 = Items.PUMPKIN_SEEDS;
            }

            if (ax == null) {
               if (var7 == var10001) {
                  return false;
               }

               var7 = item;
               var10001 = Items.FLINT_AND_STEEL;
            }

            return var7 != var10001;
         }
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public static float n(ItemStack stack) {
      l();
      float valence = 0.0F;
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else {
         if (stack.getItem() instanceof SwordItem sword) {
            valence = 0.0F + (sword.getDamage() + 1.0F);
         }

         int itemEnchantmentLevel = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SHARPNESS, stack);
         float damageBonus = Enchantments.SHARPNESS.getDamageBonus(itemEnchantmentLevel, MobType.UNDEFINED);
         return valence + damageBonus;
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   public static ItemStack h(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && (item.getItem() == Items.EGG || item.getItem() == Items.SNOWBALL);
      }).min(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static float f(ItemStack a, long a) {
      String var10000 = l();
      float valence = 0.0F;
      String ax = var10000;
      if (a == null) {
         return 0.0F;
      } else if (a.isEmpty()) {
         return 0.0F;
      } else {
         if (a.getItem() instanceof AxeItem axe && r(124830374301047L, a)) {
            AxeItem var12 = axe;
            Item var10001 = Items.WOODEN_AXE;
            if (ax == null) {
               if (axe == Items.WOODEN_AXE) {
                  valence = 4.0F;
               }

               var12 = axe;
               var10001 = Items.STONE_AXE;
            }

            if (ax == null) {
               if (var12 == var10001) {
                  valence += 5.0F;
               }

               var12 = axe;
               var10001 = Items.IRON_AXE;
            }

            if (ax == null) {
               if (var12 == var10001) {
                  valence += 6.0F;
               }

               var12 = axe;
               var10001 = Items.GOLDEN_AXE;
            }

            if (ax == null) {
               if (var12 == var10001) {
                  valence += 4.0F;
               }

               var12 = axe;
               var10001 = Items.DIAMOND_AXE;
            }

            if (var12 == var10001) {
               valence += 7.0F;
            }
         }

         int itemEnchantmentLevel = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SHARPNESS, a);
         float damageBonus = Enchantments.SHARPNESS.getDamageBonus(itemEnchantmentLevel, MobType.UNDEFINED);
         return valence + damageBonus;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static String l() {
      return 何树友何友友友树树何;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   public static float d(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof BowItem && e(11871436426037L, item);
      }).map(友何树树何树何何何友::V).max(Float::compareTo).orElse(0.0F);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      f[0] = "uY\t\u0016\u0014Yz\u0019D\u001d\u001eD\u007fDO[\u000eB\u007f[T[\u0012BsZ\t厾伮栧标佢栶传伮佣叝";
      f[1] = "{w\u001a\u001d\u0018^px\u000bReFc\u007f\u0002\u001b";
      f[2] = "a)\t#\u000bRj&\u0018lpPx=\u000f2JL\u007f-\u001b\rU[y)\u000b+JPN0\u001c'UJb'\u0011";
      f[3] = "\u0015\u001dZa)(\u0015\u001dM=%'\u000fVY 6-\u001fVB*2$\u0017VL#+\"\u0010Vl#+\"\u0010\u000b";
      f[4] = "V:\u0004:\u0001(V:\u0013f\r'Lq\u0007{\u001e-\\q\u001cq\u001a$Tq\u0012x\u0003\"Sq2x\u0003\"S";
      f[5] = "{\u0007 )r~{\u00077u~qaL#hm{qL=szz;\u0007:dwv{\u00169bqc;':dwv{\u00169bqcf";
      f[6] = "V\u007f4S,\u0005V\u007f#\u000f \nL47\u00123\u0000\\4)\t$\u0001\u0016\u007f.\u001e)\rVn-\u0018/\u0018\u0016_.\u001e)\rVn-\u0018/\u0018";
      f[7] = "8ESV\u0002{8ED\n\u000et\"\u000eP\u0017\u001d~2\u000eN\f\n\u007fxaU\u0015\u0000`\u001bAS\u001d\u001d{7LT";
      f[8] = "!$H<\u0013H!$_`\u001fG;oK}\fM+oY|\nH;8\u0012b\u0012@6$N<7O9$Rf\u0011S6";
      f[9] = "U_WtL\u001aU_@(@\u0015O\u0014@5S\u0016\u0015tL4o\u0006WVo3R\u0007";
      f[10] = void.class;
      g[10] = "java/lang/Void";
      f[11] = "n\b[np\u0017aH\u0016ez\nd\u0015\u001d#r\u0017i\u0013\u0019h15b\u0002\u0000az";
      f[12] = "c\u0011P^WsW2_\u001e\u001ax]/ZC\u0011>U2WE\u0015u\u0016\u0010\\T\f|]f";
      f[13] = "/l\u0014=)\u001e/l\u0003a%\u00115'\u0017|6\u001b%'\tg!\u001ao@\u0014v)\u0004";
      f[14] = "sj]%\u0010ZsjJy\u001cUi!^d\u000f_y!@\u007f\u0018^3F]n\u0010";
      f[15] = "K0>|b_K0) nPQ{==}ZA{/<{_Q,d\u0017~CL%'7aBv9%&";
      f[16] = "Q\npvv\u0004e)\u007f6;\u000fo4zk0Ig)wm4\u0002$\u000b||-\u000bo}";
      f[17] = "Z\u0000{8)5Z\u0000ld%:@Kxy60PKjx05@\u001c![+>`\u001c\u007fs";
      f[18] = "A\"<tYbJ--;8lA&)a";
      f[19] = "+\u001f)([Gy\f=MOy5^~!OB0QxM";
      f[20] = "$\u0018\u0007\u001f\u001agxF\u0010\b+oBEDR\u00130ByO\u0013Ezh\u0006N\u0005\u0013:";
      f[21] = "c(nfJ.!<lb1z\u000fj9)\u000f,\u000fV9\u007f\ntiixzQ%";
      f[22] = "\u0004\u0015{bdaXKluUibH8/m;bt3n;|H\u000b2xm<";
      f[23] = "LZp_Iu\u001b\u001edY&zp]9X\u001a,pgk[V-H\u0006<\u001fB+";
      f[24] = "s\u001dOUE\u0016y^CL+\u0014\u001eY\u001e\u0010\u0015K\u001ed\u001cXV\u00101_\u001dHRA";
      f[25] = "F9D\tT\u0007\u00105XZ,)vcA\u001aH\u001d\u0007`\u001e\u001fW{";
      f[26] = "\tduw\u0018RKpwsc\u0006e&\"8^Ye\u001a\"nX\b\u0003%ck\u0003Y";
      f[27] = "E\u000f-\u001d\u0003m\u0017\u000bp\u0010}O\"r\bp@4\u001bX0\u0013\u00120FU";
      f[28] = "z\u007f\u0005\u0011-D8k\u0007\u0015V\u0010\u0016=R^fB\u0016\u0001R\bm\u001ep>\u0013\r6O";
      f[29] = "7;\u0017>\u0001l=x\u001b'onZ\u007fF{T;ZBD3\u0012juyE#\u0016;";
      f[30] = "\u001ey \u0016m\u000bL}}\u001b\u0013.n\u001f\u00036I)\u007f\u000eCF)\u000bN= \u0014-VC";
      f[31] = "_=iHW>\u001d)kL,j3\u007f>\u0007\u0012=3C>Q\u0017dU|\u007fTL5";
      f[32] = "wQZ\u0012Pr%U\u0007\u001f.]\u000b\"|8h]JV\u0003\u001cCo)\u0004\u0007AN";
      f[33] = "3r7`B\u000391;y,\u0001^6f!\u001dT^\u000bdmQ\u0005q0e}UT";
      f[34] = "\u0015W\u0007i])GD\u0013\f`\u0017\u000b\u0016P`I,\u000e\u0019V\f\u0012,\u001fZ\u0001pG/\u000fEh";
      f[35] = "p\u0018\n\u000f<_t\u001c\t\rQaP&s$\u0018bUg\\\u001bnOt\u001cX\u001fmM";
      f[36] = "sHmGQt/\u0016zP`|\u0015\u0015.\rQ+\u0015)%K\u000ei?V$]X)";
      f[37] = "\u0005F*sm[GR(w\u0016\u000fi\u0004}<&Qi8}j-\u0001\u000f\u0007<ovP";
      f[38] = "\u0012z$n&8\u00189(wH:\u007f>u)pm\u007f\u0003wc5>P8vs1o";
      f[39] = "e\u00054')\u00009[#0\u0018\b\u0003Xwk!V\u0003d|+v\u001d)\u001b}= ]";
      f[40] = "fN*+~V:\u0010=<O^\u0000\u0013igu\u000b\u0000/b'!K*Pc1w\u000b";
      f[41] = "t9enjV(gry[^\u0012d&#a\u000b\u0012X-b5K8',tc\u000b";
      f[42] = " U5\"i9bA7&\u0012mL\u0017bm\":L+b;)c*\u0014#>r2";
      f[43] = "Tf$\u0017\u001ce\b83\u0000-m2;gZ\u0016<2\u0007l\u001bCx\u0018xm\r\u00158";
      f[44] = "^'\\32@\u0002yK$\u0003H8z\u001f\u007f<\u00168F\u0014?m]\u00129\u0015);\u001d";
      f[45] = "\u0015Oi; AI\u0011~,\u0011Is\u0012*w+\u001es.!7\u007f\\YQ !)\u001c";
      f[46] = "j\\b\u000e\u000e&7\u000b%Q?t\u0003Z`\u000e\u0000&\u0003acY[s:\u0019=QYh";
      f[47] = "W'\u0011\u0012\u00183\u00153\u0013\u0016cg;eF]S8;YF\u000bXi]f\u0007\u000e\u00038";
      f[48] = "i\u0018-$rF;\u000b9Akx3\u001b={2\u0012v\u0010x9\u0002Ax\u0016xqh\u0004sS:A";
      f[49] = "\u0002.Kq~b^p\\fOjds\b?s;dO\u0003}!\u007fN0\u0002kw?";
      f[50] = "cMKF3Q?\u0013\\Q\u0002Y\u0005\u0010\b\u000b8\u0007\u0005,\u0003JlL/S\u0002\\:\f";
      f[51] = "Z\u000fP^T/\u0006QGIe'<R\u0013\u0013^w<n\u0018R\u000b2\u0016\u0011\u0019D]r";
      f[52] = "\u001c ez\u0005*^4g~~~pb25O(p^2cEp\u0016asf\u001e!";
      f[53] = "P\u0019\u0004\u0017Z5T\u001d\u0007\u00157\u0000t+g|^1\u0006\rV\u0007Z5\u0005\u000f";
      f[54] = "&\u0004\u0000\u0018\u0003'p\b\u001cK{\u0005\u0016^\u0005\u000b\u001f=g]Z\u000e\u0000[)\u000f\r\t\u0012'|\f\u001d\u0016{";
      f[55] = "db>oB_&v<k9\u000b\b i \t]\b\u001civ\u0002\u0005n#(sYT";
      f[56] = "\u0005o57`}G{73\u001b)i-bx&}i\u0011b. '\u000f.#+{v";
      f[57] = "=L\u0012x8^a\u0012\u0005o\tV[\u0011Q52\u0003[-ZtgCqR[b1\u0003";
      f[58] = "Usy],8\u0017g{YWl91.\u0012i?9\r.Dlb_2oA73";
      f[59] = "G-\u001a[~\u0015C)\u0019Y\u0013*c\u001d~0z\u0011\u00119HK~\u0015\u0012;";
      f[60] = ":]Y!xBhY\u0004,\u0006jG.{\n\u0006\u001c=\u0004W2eN9YZ";
      f[61] = "\u0011\u001f,\nEeMA;\u001dtmwBoDO8w~d\u0006\u001ax]\u0001e\u0010L8";
      f[62] = "%`\u0002\u000fO_wd_\u00021s_\u001e-b\f\u0006{7\u001f\u0001^\u0002&:";
      f[63] = "Iy=3+s\u0015'*$\u001a{/$~~'//\u0018u?tn\u0005gt)\".";
      f[64] = "`hb@l@2l?M\u0012g\u0010\u001b]m_y]o;N\u007f]>=?\u0013r";
      f[65] = ":B+>Vff\u001c<)gn\\\u001fhp]1\\#c2\t{v\\b$_;";
      f[66] = "cqmM\u0017\u000e!eoIlZ\u000f3:\u0002S\u000b\u000f\u000f:TWTi0{Q\f\u0005";
      f[67] = "vd-{c\r*::lR\u0005\u00109n7mT\u0010\u0005ew<\u0010:zdajP";
      f[68] = "{k65~(q(:,\u0010*\u0016.ny!u\u0016\u0012e8m.9)d(i\u007f";
      f[69] = "N\u0014YD2uJ\u0010ZF_Eg&=s_gXT\rB$c\\W\u000f";
      f[70] = "\u0002R\u0007/\u0005Y_\u0005@p4\u000bkT\u0005/\u000bXko\u0006xP\fR\u0017XpR\u0017";
      f[71] = "\u0003\u0012kU\u00180\u0007\u0016hWu\u000b'$\u0018>\u001c4U\u00069E\u00180V\u0004";
      f[72] = "m?%\\6m1a2K\u0007e\u000bbf\u001675\u000b^mPip!!lF?0";
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 10530;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/item/友何树树何树何何何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[")[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/item/友何树树何树何何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public static ItemStack m(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof BlockItem && 树何树树何何树友何何.H(83539975070260L, item) && e(11871436426037L, item);
      }).max(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static int o(long a, Item a) {
      String var10000 = l();
      int i = 0;
      String ax = var10000;

      while (i < mc.player.getInventory().items.size()) {
         ItemStack itemStack = (ItemStack)mc.player.getInventory().items.get(i);
         if (ax == null) {
            if (itemStack.getItem() == a) {
               return i;
            }

            i++;
         }

         if (ax != null) {
            break;
         }
      }

      return -1;
   }

   public static boolean o(Item a, long checkItem) {
      return G(6772021905124L).stream().anyMatch(item -> {
         l();
         return !item.isEmpty() && item.getItem() == a;
      });
   }

   public static float o(long a, EquipmentSlot var2) {
      String var4 = l();
      if (var2 == EquipmentSlot.HEAD) {
         return X((ItemStack)mc.player.getInventory().armor.get(3));
      } else {
         EquipmentSlot var10000 = var2;
         EquipmentSlot var10001 = EquipmentSlot.CHEST;
         if (var4 == null) {
            if (var2 == EquipmentSlot.CHEST) {
               return X((ItemStack)mc.player.getInventory().armor.get(2));
            }

            var10000 = var2;
            var10001 = EquipmentSlot.LEGS;
         }

         if (var4 == null) {
            if (var10000 == var10001) {
               return X((ItemStack)mc.player.getInventory().armor.get(1));
            }

            var10000 = var2;
            var10001 = EquipmentSlot.FEET;
         }

         return var10000 == var10001 ? X((ItemStack)mc.player.getInventory().armor.get(0)) : 0.0F;
      }
   }

   public static ItemStack p(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof ArrowItem && e(11871436426037L, item);
      }).min(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static float p(ItemStack stack) {
      l();
      int valence = 0;
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else {
         if (stack.getItem() instanceof CrossbowItem) {
            valence = 0
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.QUICK_CHARGE, stack)
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.MULTISHOT, stack)
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.PIERCING, stack);
         }

         return valence;
      }
   }

   public static boolean p(long a, ItemStack var2) {
      l();
      return R(var2) > 10.0F && e(11871436426037L, var2);
   }

   public static ItemStack t(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof PickaxeItem && e(11871436426037L, item);
      }).max(Comparator.comparingInt(s -> (int)(y(s) * 100.0F))).orElse(null);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static float q(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof CrossbowItem && e(11871436426037L, item);
      }).map(友何树树何树何何何友::p).max(Float::compareTo).orElse(0.0F);
   }

   public static ItemStack z(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && (item.getItem() == Items.EGG || item.getItem() == Items.SNOWBALL) && e(11871436426037L, item);
      }).max(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static int w(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof BlockItem && 树何树树何何树友何何.H(83539975070260L, item) && e(11871436426037L, item);
      }).mapToInt(ItemStack::getCount).sum();
   }

   public static float u(long var0) {
      return G(6772021905124L)
         .stream()
         .filter(
            item -> {
               l();
               if (!item.isEmpty() && item.getItem() instanceof AxeItem) {
                  return r(124830374301047L, item) && item.getMaxDamage() > 0 && item.getMaxDamage() - item.getDamageValue() < 100
                     ? true
                     : !r(124830374301047L, item) && e(11871436426037L, item);
               } else {
                  return false;
               }
            }
         )
         .map(友何树树何树何何何友::y)
         .max(Float::compareTo)
         .orElse(0.0F);
   }

   public static boolean r(long a, ItemStack a) {
      l();
      if (a.isEmpty()) {
         return false;
      } else if (!(a.getItem() instanceof AxeItem)) {
         return false;
      } else {
         int itemEnchantmentLevel = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SHARPNESS, a);
         return itemEnchantmentLevel >= 8 && itemEnchantmentLevel < 50;
      }
   }

   public static float y(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof SwordItem;
      }).map(友何树树何树何何何友::n).max(Float::compareTo).orElse(0.0F);
   }

   public static float y(ItemStack stack) {
      l();
      float valence = 0.0F;
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else if (A(90513947799501L, stack)) {
         return 0.0F;
      } else if (r(124830374301047L, stack)) {
         return 0.0F;
      } else {
         if (stack.getItem() instanceof PickaxeItem) {
            valence = 0.0F + stack.getDestroySpeed(Blocks.STONE.defaultBlockState());
         }

         if (stack.getItem() instanceof AxeItem) {
            valence += stack.getDestroySpeed(Blocks.OAK_LOG.defaultBlockState());
         }

         if (stack.getItem() instanceof ShovelItem) {
            float var10000 = valence + stack.getDestroySpeed(Blocks.DIRT.defaultBlockState());
         }

         return 0.0F;
      }
   }

   public static ItemStack E(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof ShovelItem && e(11871436426037L, item);
      }).max(Comparator.comparingInt(s -> (int)(y(s) * 100.0F))).orElse(null);
   }

   public static void E(String var0) {
      何树友何友友友树树何 = var0;
   }

   public static boolean E(long var0) {
      return G(6772021905124L).stream().anyMatch(item -> {
         b<"h">(136451557726432456L, 20073937502688L);
         if (item.isEmpty()) {
            return false;
         } else {
            String string = item.getDisplayName().getString();
            return string.contains("") || string.contains("点击使用") || string.contains("离开游戏") || string.contains("选择一个队伍") || string.contains("再来一局");
         }
      });
   }

   public static boolean A(long a, ItemStack a) {
      String var4 = l();
      if (a.isEmpty()) {
         return false;
      } else {
         Item var10000;
         Item var10001;
         label43: {
            if (a.getItem() instanceof AxeItem) {
               var10000 = a.getItem();
               var10001 = Items.GOLDEN_AXE;
               if (var4 != null) {
                  break label43;
               }

               if (var10000 == Items.GOLDEN_AXE && EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SHARPNESS, a) > 100) {
                  return true;
               }
            }

            var10000 = a.getItem();
            var10001 = Items.SLIME_BALL;
         }

         if (var4 == null) {
            if (var10000 == var10001 && EnchantmentHelper.getItemEnchantmentLevel(Enchantments.KNOCKBACK, a) > 1) {
               return true;
            }

            var10000 = a.getItem();
            var10001 = Items.TOTEM_OF_UNDYING;
         }

         if (var4 == null) {
            if (var10000 == var10001) {
               return true;
            }

            var10000 = a.getItem();
            var10001 = Items.END_CRYSTAL;
         }

         return var10000 == var10001;
      }
   }

   public static float A(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof PickaxeItem && e(11871436426037L, item);
      }).map(友何树树何树何何何友::y).max(Float::compareTo).orElse(0.0F);
   }

   public static ItemStack Y(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof FishingRodItem && e(11871436426037L, item);
      }).findAny().orElse(null);
   }

   public static float X(ItemStack itemStack) {
      l();
      short valence = 0;
      if (itemStack == null) {
         return 0.0F;
      } else if (itemStack.isEmpty()) {
         return 0.0F;
      } else {
         if (itemStack.getItem() instanceof ArmorItem armor) {
            ArmorMaterial material = armor.getMaterial();
            if (material == ArmorMaterials.LEATHER) {
               valence += 100;
            }

            if (material == ArmorMaterials.CHAIN) {
               valence += 200;
            }

            if (material == ArmorMaterials.IRON) {
               valence += 400;
            }

            if (material == ArmorMaterials.GOLD) {
               valence += 300;
            }

            if (material == ArmorMaterials.DIAMOND) {
               valence += 500;
            }

            if (material == ArmorMaterials.NETHERITE) {
               valence += 600;
            }
         }

         return valence + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.ALL_DAMAGE_PROTECTION, itemStack);
      }
   }

   public static boolean L(long a, BlockPos a) {
      String ax = l();
      if (mc.level == null) {
         return false;
      } else {
         BlockState blockState = mc.level.getBlockState(a);
         Block block = blockState.getBlock();
         if (!(block instanceof AirBlock)) {
            boolean var10000 = block instanceof LiquidBlock;
            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof ChestBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof EnderChestBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof ShulkerBoxBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof BarrelBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof FurnaceBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof BlastFurnaceBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof SmokerBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof HopperBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof DispenserBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof CraftingTableBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof EnchantmentTableBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof AnvilBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof GrindstoneBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof StonecutterBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof LoomBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof CartographyTableBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof LeverBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof ButtonBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof PressurePlateBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof TripWireHookBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof DoorBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof TrapDoorBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof FenceGateBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof NoteBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof JukeboxBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof BeaconBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof BrewingStandBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof CauldronBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof ComparatorBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof RepeaterBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof CommandBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof StructureBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof JigsawBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof BedBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof LecternBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof ComposterBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof RedStoneWireBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof RedstoneTorchBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof CakeBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof FlowerPotBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof SignBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof BannerBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof WallBannerBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof CropBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof StemBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof AttachedStemBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof CocoaBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof SweetBerryBushBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof SugarCaneBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof CactusBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof KelpBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof SeaPickleBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof SpawnerBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof TurtleEggBlock;
            }

            if (ax == null) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof BeehiveBlock;
            }

            return ax != null ? var10000 : !var10000;
         } else {
            return false;
         }
      }
   }

   public static double N(long a, ItemStack a) {
      double damage = 0.0;
      b<"h">(7130775351629729753L, 85620437246705L);
      Multimap attributeModifierMap = a.getAttributeModifiers(b<"A">(7131934411477359540L, 85620437246705L));
      Iterator var8 = attributeModifierMap.keySet().iterator();
      if (var8.hasNext()) {
         Attribute attributeName = (Attribute)var8.next();
         if (attributeName.getDescriptionId().equals("attribute.name.generic.attack_damage")) {
            Iterator<AttributeModifier> attributeModifiers = attributeModifierMap.get(attributeName).iterator();
            if (attributeModifiers.hasNext()) {
               damage = 0.0 + attributeModifiers.next().getAmount();
               b<"h">(new Module[1], 7132831146300729477L, 85620437246705L);
            }
         }
      }

      if (a.hasFoil()) {
         damage = damage
            + EnchantmentHelper.getItemEnchantmentLevel(b<"A">(7132568237768209378L, 85620437246705L), a)
            + EnchantmentHelper.getItemEnchantmentLevel(b<"A">(7125241871858840201L, 85620437246705L), a) * 1.25;
      }

      return damage;
   }

   public static float N(EquipmentSlot a, long a) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof ArmorItem && ((ArmorItem)item.getItem()).getEquipmentSlot() == a;
      }).map(友何树树何树何何何友::X).max(Float::compareTo).orElse(0.0F);
   }

   public static ItemStack W(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof BowItem && e(11871436426037L, item);
      }).max(Comparator.comparingInt(s -> (int)(R(s) * 100.0F))).orElse(null);
   }

   public static ItemStack H(long var0) {
      return G(6772021905124L)
         .stream()
         .filter(
            item -> {
               l();
               return !item.isEmpty()
                  && item.getItem().isEdible()
                  && item.getItem() != Items.GOLDEN_APPLE
                  && item.getItem() != Items.ENCHANTED_GOLDEN_APPLE
                  && e(11871436426037L, item);
            }
         )
         .min(Comparator.comparingInt(ItemStack::getCount))
         .orElse(null);
   }

   public static boolean T(ItemStack a, long a) {
      l();
      if (a.isEmpty()) {
         return false;
      } else {
         return a.getItem() != Items.GOLDEN_AXE ? false : EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SHARPNESS, a) > 100;
      }
   }

   public static ItemStack T(long var0) {
      return G(6772021905124L).stream().filter(item -> {
         l();
         return !item.isEmpty() && item.getItem() instanceof SwordItem;
      }).max(Comparator.comparingInt(s -> (int)(n(s) * 100.0F))).orElse(null);
   }

   public static float R(ItemStack stack) {
      l();
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else {
         return stack.getItem() instanceof BowItem
            ? 10.0F
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.PUNCH_ARROWS, stack) / 10.0F
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.INFINITY_ARROWS, stack)
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.FLAMING_ARROWS, stack)
               + EnchantmentHelper.getItemEnchantmentLevel(Enchantments.POWER_ARROWS, stack)
               + (float)stack.getDamageValue() / stack.getMaxDamage()
            : 0.0F;
      }
   }

   public static boolean R(ItemStack a, long a) {
      l();
      return V(a) > 10.0F && e(11871436426037L, a);
   }

   private static String HE_SHU_YOU() {
      return "何建国230622195906030014";
   }

   public static List G(long a) {
      a = 105118243978134L ^ a;
      ArrayList<ItemStack> list = new ArrayList<>(40);
      list.addAll(b<"D">(mc.player.getInventory(), -4793550409322192793L, (long)a));
      b<"h">(-4794488571822239654L, (long)a);
      list.addAll(b<"D">(mc.player.getInventory(), -4799712288325020676L, (long)a));
      if (b<"h">(-4795140204125971075L, (long)a) == null) {
         b<"h">("ZkhFs", -4793274483024351251L, (long)a);
      }

      return list;
   }
}
