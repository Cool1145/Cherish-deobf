package cn.cool.cherish.utils.item;

import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.misc.WorldEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.item.ItemStack;

public final class SpoofItemUtils implements IWrapper, 何树友 {
   private static int 何何何何树树树友友友;
   private static boolean 何友树树树树友友友何;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[13];
   private static final String[] e = new String[13];
   private static int _刘凤楠230622109211173513 _;

   private SpoofItemUtils(long a) {
      long var10000 = 139090337265280L ^ a;
      super();
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(5993320703009600163L, 6348340841378479889L, MethodHandles.lookup().lookupClass()).a(154191178762265L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var0;
      Cipher var2 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(137257922331149L << var1 * 8 >>> 56);
      }

      var2.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var3 = b(
            var0.doFinal(
               "²\u008fQ=Ìºk|Í\u008fæ¸Á§Ñ1\u007f|\u009e0J3.\u008fã-l@yþ\u0097~ÔF9\u0011è\u0080\n\u009fv¿P(\u0001\u00804'L,ïi\n\u008e\u008a\u0080"
                  .getBytes("ISO-8859-1")
            )
         )
         .intern();
      byte var10001 = -1;
      b = var3;
      何何何何树树树友友友 = 0;
      何友树树树树友友友何 = false;
   }

   @EventTarget
   public static void C(WorldEvent event) {
      z(29996098265021L);
   }

   public static void V(int a, long a) {
      a = 139090337265280L ^ a;
      a<"ß">((int)a, -392661046752544188L, a);
   }

   public static boolean e(long var0) {
      return 何友树树树树友友友何;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 52;
               case 2 -> 13;
               case 3 -> 54;
               case 4 -> 2;
               case 5 -> 12;
               case 6 -> 0;
               case 7 -> 39;
               case 8 -> 6;
               case 9 -> 32;
               case 10 -> 42;
               case 11 -> 22;
               case 12 -> 61;
               case 13 -> 16;
               case 14 -> 30;
               case 15 -> 59;
               case 16 -> 19;
               case 17 -> 4;
               case 18 -> 46;
               case 19 -> 27;
               case 20 -> 15;
               case 21 -> 17;
               case 22 -> 9;
               case 23 -> 41;
               case 24 -> 10;
               case 25 -> 38;
               case 26 -> 21;
               case 27 -> 35;
               case 28 -> 47;
               case 29 -> 44;
               case 30 -> 29;
               case 31 -> 40;
               case 32 -> 53;
               case 33 -> 18;
               case 34 -> 43;
               case 35 -> 34;
               case 36 -> 25;
               case 37 -> 24;
               case 38 -> 45;
               case 39 -> 56;
               case 40 -> 1;
               case 41 -> 23;
               case 42 -> 49;
               case 43 -> 55;
               case 44 -> 20;
               case 45 -> 62;
               case 46 -> 28;
               case 47 -> 37;
               case 48 -> 14;
               case 49 -> 48;
               case 50 -> 33;
               case 51 -> 7;
               case 52 -> 3;
               case 53 -> 36;
               case 54 -> 58;
               case 55 -> 57;
               case 56 -> 51;
               case 57 -> 26;
               case 58 -> 5;
               case 59 -> 11;
               case 60 -> 31;
               case 61 -> 8;
               case 62 -> 60;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'k' && var8 != 170 && var8 != 'r' && var8 != 223) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 232) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 231) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'k') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 170) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'r') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      c[0] = " \u0001\u001eZ\u0002O/ASQ\bR*\u001cX\u0017\u0018T*\u0003C\u0017\u0004T&\u0002\u001e史伸栱桒伺校佬伸併厈";
      c[1] = "x[\u001d@m7sT\f\u000f\u0010/`S\u0005F";
      c[2] = "x\u000e.*B'x\u000e9vN(bE-k]\"rE?j['b\u0012ttC/o\u000e(*f `\u000e4p@<o";
      c[3] = int.class;
      e[3] = "java/lang/Integer";
      c[4] = "9,pF!%6l=M+8316\u000b;>3.-\u000b'>?/pv>%5$\u0017Q+'\u000f67I=";
      c[5] = "\u0006\u0013c\re\u0019\r\u001crB\u001e\u001b\u001f\u0007e\u001c$\u0007\u0018\u0017q#;\u0010\u001e\u0013a\u0005$\u001b)\nv\t;\u0001\u0005\u001d{";
      c[6] = boolean.class;
      e[6] = "java/lang/Boolean";
      c[7] = "&>\r\u0018d\u0003-1\u001cW\u0005\r&:\u0018\r";
      c[8] = "~\u0018E*5\b.\u001c\u0017\u0015 6|J@q\"R(FS)D";
      c[9] = "?\u0010tF\u0011D=IuZ.FR\u0013#\u0012\u0011\u0017R($@\u0015S4W'Z\u001f\u0019";
      c[10] = "+<9\u001c`J}-)\u0019\u0003\u001b\u0011}-\u001ehMa|$\u001c?r*\")\u0015<\u0002+++B\u0003";
      c[11] = "\t\u0013r=\t\u001b_\u0002b8j佾佮伴佟框桳栺台厪叁_P@\b\u00123 SZ\u0002X";
      c[12] = "\u0000x%52\u0005Vi50Q你叹栛桌桎案叾叹叁伈Wm[\u0002m9h)TC;";
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/item/SpoofItemUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static void m(int a, long slot) {
      友何树树何树何何何友.l();
      if (!何友树树树树友友友何) {
         何友树树树树友友友何 = true;
         何何何何树树树友友友 = (int)a;
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void z(long var0) {
      何友树树树树友友友何 = false;
   }

   public static int getSlot() {
      友何树树何树何何何友.l();
      if (mc.player != null) {
         return 何友树树树树友友友何 ? 何何何何树树树友友友 : mc.player.getInventory().selected;
      } else {
         return 0;
      }
   }

   public static ItemStack getStack() {
      return 何友树树树树友友友何 ? mc.player.getInventory().getItem(何何何何树树树友友友) : mc.player.getMainHandItem();
   }

   private static String HE_DA_WEI() {
      return "我是何树友";
   }
}
