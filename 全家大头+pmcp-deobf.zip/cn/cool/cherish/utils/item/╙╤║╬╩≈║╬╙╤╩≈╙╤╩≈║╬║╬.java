package cn.cool.cherish.utils.item;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.友树友友何友树友树友;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.google.common.collect.Multimap;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BookItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ExperienceBottleItem;
import net.minecraft.world.item.FireworkRocketItem;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.PlayerHeadItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.AttachedStemBlock;
import net.minecraft.world.level.block.BannerBlock;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.BeaconBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.BeehiveBlock;
import net.minecraft.world.level.block.BlastFurnaceBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BrewingStandBlock;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.CactusBlock;
import net.minecraft.world.level.block.CakeBlock;
import net.minecraft.world.level.block.CartographyTableBlock;
import net.minecraft.world.level.block.CauldronBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.CocoaBlock;
import net.minecraft.world.level.block.CommandBlock;
import net.minecraft.world.level.block.ComparatorBlock;
import net.minecraft.world.level.block.ComposterBlock;
import net.minecraft.world.level.block.CraftingTableBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.EnchantmentTableBlock;
import net.minecraft.world.level.block.EnderChestBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.FlowerPotBlock;
import net.minecraft.world.level.block.FurnaceBlock;
import net.minecraft.world.level.block.GrindstoneBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.JigsawBlock;
import net.minecraft.world.level.block.JukeboxBlock;
import net.minecraft.world.level.block.KelpBlock;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.LoomBlock;
import net.minecraft.world.level.block.NoteBlock;
import net.minecraft.world.level.block.PressurePlateBlock;
import net.minecraft.world.level.block.RedStoneWireBlock;
import net.minecraft.world.level.block.RedstoneTorchBlock;
import net.minecraft.world.level.block.RepeaterBlock;
import net.minecraft.world.level.block.SeaPickleBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.SignBlock;
import net.minecraft.world.level.block.SmokerBlock;
import net.minecraft.world.level.block.SpawnerBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.StonecutterBlock;
import net.minecraft.world.level.block.StructureBlock;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.SweetBerryBushBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.TripWireHookBlock;
import net.minecraft.world.level.block.TurtleEggBlock;
import net.minecraft.world.level.block.WallBannerBlock;
import net.minecraft.world.level.block.state.BlockState;

public final class 友何树何友树友树何何 implements IWrapper, 何树友 {
   private static int 树友何树友何树树友树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[73];
   private static final String[] g = new String[73];
   private static String HE_JIAN_GUO;

   private 友何树何友树友树何何(long a) {
      a = 友何树何友树友树何何.a ^ a;
      super();
      throw new UnsupportedOperationException(a<"z">(3443, 5077709087338016296L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1355974705538767770L, -2547435681625598719L, MethodHandles.lookup().lookupClass()).a(33867050959575L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 115871525446096L;
      a();
      b<"O">(0, -8772829042167459803L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[14];
      int var5 = 0;
      String var4 = "Ö\u0002ÂVíÅÆ¼& Ô]è:·ò(«!É\u0014×\u0097@¦]\u0019¢\u0002V»vo\u001aüÕO\u0093\u008e\u00944¡¶D·\u0007SA\u0010\u008f<«v{4\u008d\u008cÛ1Ê÷\u0013\u0081_3 \u0087=áù\u0088S1\u0013h\u001e\u0019ï& +ë%Ú¦Ö°¦5¾\u0081:s\u0011ú$ÂÙXÞ\u0089wu\n&1\u001ehÜ\u008fa\u0096÷ØJç\u0013\u0083¬º5C¿ðovâ \u0097TÝkï\u009eô¥`ña×ÜË!E\u0093ì\u009duÀ\u008d#ª²\u008eÞv\\v9oÇG\u001b\u0010\u0013\u0081·\b¸×ó\u0018 y\u009aýW\u0085Z©d\u001aVò8\u0005º@øx\u0082z?\u0081þµþc·½k,H¿ Ù\u001a\u008d|¥à\u0015ñË\u0083ë/ *NÞ\u000béÏI\\ÜÀªÁ²\u0085±gßu½\u008a¹)ÖD\u001d`ds{\u001e\u0095Oè9\u0010F\u0082Ü8¹\u0001\u009dLMT3ÓW®çâ\u0018á. æÍ\u008bæÝî'üÔ¨Ùveb²^!Ü\u000f>\u0099\u0018¯@¤¦\u008d&6]`\u000e\u0085\u0017£f_\u0004¸>^ßíëñ\u0080\u0010{×.\rn²\u0007G*'\u008bójxU\u001e\u0010æ°R\u008e½\u0094Å\u008eZ\u00ad#ò¾æÃK\u0010Þ7OÉü\u0092¾\u008bß&bn2\u009fMä\u0010\u0093M\u0095\u0081'hNüüìóü¼ÄÅ\u0092";
      short var6 = 387;
      char var3 = '0';
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = b(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     b = var7;
                     c = new String[14];
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "ÝLã?Þ\u000etîò¯d¸¡åt'ÁÏ\u0012]Ã¶>¯\u0018\u009cÑYg\fJ$\u008faò|E@ïqMËi²\u008b\\ï`R";
                  var6 = 49;
                  var3 = 24;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   public static float C(ItemStack itemStack) {
      long a = 友何树何友树友树何何.a ^ 2506660144650L;
      b<"O">(-4498916431482553590L, a);
      short valence = 0;
      if (itemStack == null) {
         return 0.0F;
      } else if (itemStack.isEmpty()) {
         return 0.0F;
      } else {
         if (itemStack.getItem() instanceof ArmorItem armor) {
            ArmorMaterial material = armor.getMaterial();
            if (material == b<"Â">(-4495830052017786345L, a)) {
               valence += 100;
            }

            if (material == b<"Â">(-4498294180869446071L, a)) {
               valence += 200;
            }

            if (material == b<"Â">(-4498357368561310124L, a)) {
               valence += 400;
            }

            if (material == b<"Â">(-4499159298769252543L, a)) {
               valence += 300;
            }

            if (material == b<"Â">(-4496819096740424553L, a)) {
               valence += 500;
            }

            if (material == b<"Â">(-4497292340012944885L, a)) {
               valence += 600;
            }
         }

         return valence + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-4497075543256021784L, a), itemStack);
      }
   }

   public static void C(int var0) {
      树友何树友何树树友树 = var0;
   }

   public static ItemStack D(long var0) {
      long var3 = a ^ var0 ^ 34762691951466L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 108225796105355L;
         long ax = a ^ 2869499922770L;
         b<"O">(4832858822888913291L, a);
         return !item.isEmpty() && item.getItem() instanceof PickaxeItem && l(ax, item);
      }).max(Comparator.comparingInt(s -> (int)(K(s) * 100.0F))).orElse(null);
   }

   public static float F(long var0) {
      long var3 = a ^ var0 ^ 83227011498725L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 108178180932080L;
         long ax = a ^ 2823432170537L;
         long axx = a ^ 43426035438023L;
         b<"O">(-6454073462051049539L, a);
         if (!item.isEmpty() && item.getItem() instanceof AxeItem) {
            return e(axx, item) && item.getMaxDamage() > 0 && item.getMaxDamage() - item.getDamageValue() < 100 ? true : !e(axx, item) && l(ax, item);
         } else {
            return false;
         }
      }).map(友何树何友树友树何何::K).max(Float::compareTo).orElse(0.0F);
   }

   public static boolean I(ItemStack a, long a) {
      a = 友何树何友树友树何何.a ^ a;
      int ax = b<"O">(-3959031114748755747L, a);
      if (a.isEmpty()) {
         return true;
      } else {
         Item item = a.getItem();
         boolean var10000 = item instanceof BlockItem;
         int var10001 = ax;
         if (a >= 0L) {
            if (ax == 0) {
               if (var10000) {
                  BlockItem block = (BlockItem)item;
                  Block var9 = block.getBlock();
                  Block var11 = b<"Â">(-3959321785192712866L, a);
                  if (a > 0L) {
                     if (var9 == var11) {
                        return false;
                     }

                     var9 = block.getBlock();
                     var11 = b<"Â">(-3959577970219481805L, a);
                  }

                  return var9 != var11;
               }

               var10000 = item instanceof BookItem;
            }

            var10001 = ax;
         }

         label131: {
            label121: {
               if (a > 0L) {
                  if (var10001 == 0) {
                     if (var10000) {
                        return false;
                     }

                     var10000 = item instanceof ExperienceBottleItem;
                  }

                  if (a <= 0L) {
                     break label121;
                  }

                  var10001 = ax;
               }

               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var8 = item;
                  if (a < 0L) {
                     break label131;
                  }

                  var10000 = item instanceof FireworkRocketItem;
               }
            }

            if (a < 0L) {
               return var10000;
            }

            if (var10000) {
               return false;
            }

            var8 = item;
         }

         Item var10 = b<"Â">(-3959254787237043411L, a);
         int var10002 = ax;
         if (a > 0L) {
            if (ax == 0) {
               if (var8 == var10) {
                  return false;
               }

               var8 = item;
               var10 = b<"Â">(-3960522950497282333L, a);
            }

            var10002 = ax;
         }

         if (a > 0L) {
            if (var10002 == 0) {
               if (var8 == var10) {
                  return false;
               }

               var8 = item;
               var10 = b<"Â">(-3959616962409551824L, a);
            }

            var10002 = ax;
         }

         if (a > 0L) {
            if (var10002 == 0) {
               if (var8 == var10) {
                  return false;
               }

               var8 = item;
               var10 = b<"Â">(-3962406818210261739L, a);
            }

            if (a <= 0L) {
               return var8 != var10;
            }

            var10002 = ax;
         }

         if (var10002 == 0) {
            if (var8 == var10) {
               return false;
            }

            var8 = item;
            var10 = b<"Â">(-3960277250171368986L, a);
         }

         return var8 != var10;
      }
   }

   public static ItemStack I(long var0) {
      long var3 = a ^ var0 ^ 95154758013977L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 32898548201522L;
         long ax = a ^ 137548909286891L;
         b<"O">(-2330405017023847118L, a);
         return !item.isEmpty() && item.getItem() instanceof CrossbowItem && l(ax, item);
      }).max(Comparator.comparingInt(s -> (int)(u(s) * 100.0F))).orElse(null);
   }

   public static ItemStack S(long var0) {
      long var3 = a ^ var0 ^ 9153562299624L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 117472101294538L;
         b<"O">(-4155539508311781497L, a);
         return !item.isEmpty() && item.getItem() instanceof SwordItem;
      }).max(Comparator.comparingInt(s -> (int)(A(s) * 100.0F))).orElse(null);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 54;
               case 1 -> 56;
               case 2 -> 53;
               case 3 -> 58;
               case 4 -> 33;
               case 5 -> 10;
               case 6 -> 32;
               case 7 -> 36;
               case 8 -> 43;
               case 9 -> 5;
               case 10 -> 35;
               case 11 -> 39;
               case 12 -> 41;
               case 13 -> 51;
               case 14 -> 62;
               case 15 -> 3;
               case 16 -> 42;
               case 17 -> 7;
               case 18 -> 38;
               case 19 -> 18;
               case 20 -> 1;
               case 21 -> 26;
               case 22 -> 50;
               case 23 -> 20;
               case 24 -> 11;
               case 25 -> 31;
               case 26 -> 45;
               case 27 -> 2;
               case 28 -> 30;
               case 29 -> 60;
               case 30 -> 29;
               case 31 -> 40;
               case 32 -> 44;
               case 33 -> 24;
               case 34 -> 9;
               case 35 -> 25;
               case 36 -> 21;
               case 37 -> 23;
               case 38 -> 16;
               case 39 -> 17;
               case 40 -> 47;
               case 41 -> 19;
               case 42 -> 49;
               case 43 -> 61;
               case 44 -> 46;
               case 45 -> 6;
               case 46 -> 15;
               case 47 -> 55;
               case 48 -> 37;
               case 49 -> 57;
               case 50 -> 59;
               case 51 -> 14;
               case 52 -> 22;
               case 53 -> 52;
               case 54 -> 4;
               case 55 -> 12;
               case 56 -> 34;
               case 57 -> 8;
               case 58 -> 48;
               case 59 -> 63;
               case 60 -> 0;
               case 61 -> 27;
               case 62 -> 13;
               default -> 28;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static boolean e(long a, ItemStack var2) {
      a = 友何树何友树友树何何.a ^ a;
      b<"O">(-8054459236952167774L, (long)a);
      if (var2.isEmpty()) {
         return false;
      } else if (!(var2.getItem() instanceof AxeItem)) {
         return false;
      } else {
         int itemEnchantmentLevel = EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-8056241657731576981L, (long)a), var2);
         return itemEnchantmentLevel >= 8 && itemEnchantmentLevel < 50;
      }
   }

   public static ItemStack e(long var0) {
      long var3 = a ^ var0 ^ 16679874252887L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 79850846767031L;
         b<"O">(-2292919832278115657L, a);
         return !item.isEmpty() && (item.getItem() == b<"Â">(-2293446064406973904L, a) || item.getItem() == b<"Â">(-2294025666075002905L, a));
      }).min(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static float e(long var0) {
      long var3 = a ^ var0 ^ 68631975616790L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 126310791190553L;
         b<"O">(-4645578586425592236L, a);
         return !item.isEmpty() && item.getItem() instanceof SwordItem;
      }).map(友何树何友树友树何何::A).max(Float::compareTo).orElse(0.0F);
   }

   public static ItemStack b(long var0) {
      long var3 = a ^ var0 ^ 118499936900771L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 42325535590235L;
         long ax = a ^ 77571356387970L;
         b<"O">(2360316588605151835L, a);
         return !item.isEmpty() && item.getItem() instanceof BowItem && l(ax, item);
      }).max(Comparator.comparingInt(s -> (int)(Y(s) * 100.0F))).orElse(null);
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'o' && var8 != 'q' && var8 != 194 && var8 != 'r') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 207) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'O') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'o') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'q') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/item/友何树何友树友树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static ItemStack x(long var0) {
      long var3 = a ^ var0 ^ 83975554492085L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 90086021308112L;
         long ax = a ^ 53998927966985L;
         b<"O">(4129437935163109533L, a);
         return !item.isEmpty() && (item.getItem() == b<"Â">(4128414948916652887L, a) || item.getItem() == b<"Â">(4129487217975340672L, a)) && l(ax, item);
      }).max(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static int s() {
      P();

      try {
         return 17;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public static int c(long a, Item var2) {
      a = 友何树何友树友树何何.a ^ a;
      int var10000 = b<"O">(-4104779354585198885L, (long)a);
      int i = 0;
      int ax = var10000;

      while (i < b<"o">(mc.player.getInventory(), -4104717472502910308L, (long)a).size()) {
         ItemStack itemStack = (ItemStack)b<"o">(mc.player.getInventory(), -4104717472502910308L, (long)a).get(i);
         var10000 = ax;
         if (a >= 0L) {
            if (ax == 0) {
               if (itemStack.getItem() == var2) {
                  return i;
               }

               i++;
            }

            var10000 = ax;
         }

         if (var10000 != 0) {
            break;
         }
      }

      return -1;
   }

   public static boolean c(long a, Item var2) {
      long ax = 友何树何友树友树何何.a ^ a ^ 69727379524176L;
      return n(ax).stream().anyMatch(item -> {
         long axx = 友何树何友树友树何何.a ^ 16343344873309L;
         b<"O">(6396214142203859216L, axx);
         return !item.isEmpty() && item.getItem() == var2;
      });
   }

   public static float n(long var0) {
      long var3 = a ^ var0 ^ 23931152021703L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 115833959656945L;
         long ax = a ^ 10633829629992L;
         b<"O">(750913981190942961L, a);
         return !item.isEmpty() && item.getItem() instanceof PickaxeItem && l(ax, item);
      }).map(友何树何友树友树何何::K).max(Float::compareTo).orElse(0.0F);
   }

   public static ItemStack n(long var0) {
      long var3 = a ^ var0 ^ 124906335621918L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 139248096993444L;
         long ax = a ^ 33360805924221L;
         long axx = a ^ 65665255731347L;
         b<"O">(-4089585442677228124L, a);
         return !item.isEmpty() && item.getItem() instanceof AxeItem && !e(axx, item) && l(ax, item);
      }).max(Comparator.comparingInt(s -> (int)(K(s) * 100.0F))).orElse(null);
   }

   public static boolean n(long a, ItemStack var2) {
      a = 友何树何友树友树何何.a ^ a;
      long ax = a ^ 23812059005427L;
      b<"O">(-3769279472252980950L, (long)a);
      return Y(var2) > 10.0F && l(ax, var2);
   }

   public static List n(long a) {
      a = 友何树何友树友树何何.a ^ a;
      int var10000 = b<"O">(3688983946379757995L, (long)a);
      ArrayList<ItemStack> list = new ArrayList<>(40);
      list.addAll(b<"o">(mc.player.getInventory(), 3689674669083592353L, (long)a));
      list.addAll(b<"o">(mc.player.getInventory(), 3687944585504156732L, (long)a));
      int ax = var10000;
      if (b<"O">(3691233658873928831L, (long)a)) {
         b<"O">(++ax, 3691695363001836894L, (long)a);
      }

      return list;
   }

   public static boolean h(BlockPos a, long a) {
      a = 友何树何友树友树何何.a ^ a;
      int ax = b<"O">(9190668754060523096L, a);
      if (mc.level == null) {
         return false;
      } else {
         BlockState blockState = mc.level.getBlockState(a);
         Block block = blockState.getBlock();
         if (!(block instanceof AirBlock)) {
            boolean var10000 = block instanceof LiquidBlock;
            int var10001 = ax;
            if (a >= 0L) {
               if (ax == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof ChestBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof EnderChestBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof ShulkerBoxBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof BarrelBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof FurnaceBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof BlastFurnaceBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof SmokerBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof HopperBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof DispenserBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof CraftingTableBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof EnchantmentTableBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof AnvilBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof GrindstoneBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof StonecutterBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof LoomBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof CartographyTableBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof LeverBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof ButtonBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof PressurePlateBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof TripWireHookBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof DoorBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof TrapDoorBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof FenceGateBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof NoteBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof JukeboxBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof BeaconBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof BrewingStandBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof CauldronBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof ComparatorBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof RepeaterBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof CommandBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof StructureBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof JigsawBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof BedBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof LecternBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof ComposterBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof RedStoneWireBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof RedstoneTorchBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof CakeBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof FlowerPotBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof SignBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof BannerBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof WallBannerBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof CropBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof StemBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof AttachedStemBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof CocoaBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof SweetBerryBushBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof SugarCaneBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof CactusBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof KelpBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof SeaPickleBlock;
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof SpawnerBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof TurtleEggBlock;
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = block instanceof BeehiveBlock;
               }

               var10001 = ax;
            }

            return var10001 != 0 ? var10000 : !var10000;
         } else {
            return false;
         }
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static boolean l(long a, ItemStack a) {
      a = 友何树何友树友树何何.a ^ a;
      int ax = b<"O">(-1309792115555130367L, (long)a);
      if (!a.isEmpty()) {
         if (a.getItem() instanceof PlayerHeadItem) {
            return false;
         } else {
            String string = a.getDisplayName().getString();
            boolean var10000 = string.contains(a<"z">(31010, 5560560857028895938L ^ a));
            int var10001 = ax;
            if (a > 0L) {
               if (ax == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = string.contains(a<"z">(24665, 3845359447369629111L ^ a));
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = string.contains(a<"z">(17943, 1415594026666990579L ^ a));
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = string.contains(a<"z">(13535, 8714948224343501116L ^ a));
               }

               var10001 = ax;
            }

            if (a > 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = string.contains(a<"z">(23660, 5525225727749423491L ^ a));
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = string.contains(a<"z">(29682, 1373829988347883039L ^ a));
               }

               var10001 = ax;
            }

            if (a >= 0L) {
               if (var10001 == 0) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = string.contains(a<"z">(14050, 5825361425548798734L ^ a));
               }

               var10001 = ax;
            }

            if (var10001 == 0) {
               var10000 = !var10000;
            }

            return var10000;
         }
      } else {
         return true;
      }
   }

   public static int l(long var0) {
      long var3 = a ^ var0 ^ 45809478711932L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 94111054800422L;
         long ax = a ^ 58711068003327L;
         long axx = a ^ 102579771014434L;
         b<"O">(124044245305280619L, a);
         return !item.isEmpty() && item.getItem() instanceof BlockItem && 友树友友何友树友树友.h(axx, item) && l(ax, item);
      }).mapToInt(ItemStack::getCount).sum();
   }

   public static float l(long var0) {
      long var3 = a ^ var0 ^ 56981713004817L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 83040075802389L;
         long ax = a ^ 47777578977996L;
         b<"O">(-4572368011702335144L, a);
         return !item.isEmpty() && item.getItem() instanceof ShovelItem && l(ax, item);
      }).map(友何树何友树友树何何::K).max(Float::compareTo).orElse(0.0F);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   public static float d(int var0, int var1, int var2) {
      long var6 = ((long)var0 << 32 | (long)var1 << 48 >>> 32 | (long)var2 << 48 >>> 48) ^ a ^ 3109204619285L;
      return n(var6).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 26141393640861L;
         long ax = a ^ 131068843569220L;
         b<"O">(-431233115850230832L, a);
         return !item.isEmpty() && item.getItem() instanceof BowItem && l(ax, item);
      }).map(友何树何友树友树何何::E).max(Float::compareTo).orElse(0.0F);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   public static boolean d(long var0) {
      long var3 = a ^ var0 ^ 24073759562262L;
      return n(var3)
         .stream()
         .anyMatch(
            item -> {
               long a = 友何树何友树友树何何.a ^ 130257193202672L;
               b<"O">(6082911088368479984L, a);
               if (item.isEmpty()) {
                  return false;
               } else {
                  String string = item.getDisplayName().getString();
                  return string.contains(a<"z">(26663, 8852807365749410940L ^ a))
                     || string.contains(a<"z">(9998, 5394151412302594906L ^ a))
                     || string.contains(a<"z">(7840, 8270113546602183413L ^ a))
                     || string.contains(a<"z">(18167, 4647308898203411118L ^ a))
                     || string.contains(a<"z">(18795, 5705208227150605621L ^ a));
               }
            }
         );
   }

   public static ItemStack a(long var0) {
      long var3 = a ^ var0 ^ 28748227327345L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 130455034076416L;
         long ax = a ^ 24566110941401L;
         b<"O">(-4999397288300186803L, a);
         return !item.isEmpty() && item.getItem() instanceof ShovelItem && l(ax, item);
      }).max(Comparator.comparingInt(s -> (int)(K(s) * 100.0F))).orElse(null);
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12348;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/item/友何树何友树友树何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/item/友何树何友树友树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      f[0] = "6QRT\u000f\u00146QE\b\u0003\u001b,\u001aQ\u0015\u0010\u0011<\u001aO\u000e\u0007\u0010vuT\u0017\r\u000f\u0015UR\u001f\u0010\u00149XU";
      f[1] = "WF~`gGX\u00063kmZ][8-}\\]D#-a\\QE~又佝根佡口桁又栙佽佡";
      f[2] = int.class;
      g[2] = "java/lang/Integer";
      f[3] = "H\tX\u0013FKH\tOOJDRB[RYNBBEINO\b\tB^CCH\u0018AXEV\b)B^CCH\u0018AXEVU";
      f[4] = "U\u0012\u001b\u007fprU\u0012\f#|}OY\u0018>ow_Y\u0006%xv\u0015\u0012\u00012uzU\u0003\u00024so\u00152\u00012uzU\u0003\u00024so";
      f[5] = "\u007fQ\u0003\u0007\u0015\nt^\u0012Hn\bfE\u0005\u0016T\u0014aU\u0011)K\u0003gQ\u0001\u000fT\bPH\u0016\u0003K\u0012|_\u001b";
      f[6] = "\\\u001d@+EQ\\\u001dWwI^FVCjZTVV]qMU\u001c1@`EK";
      f[7] = "+-\u0001VHu+-\u0016\nDz1f\u0002\u0017Wp!f\u001c\f@qk\u0001\u0001\u001dH";
      f[8] = void.class;
      g[8] = "java/lang/Void";
      f[9] = "<\u0011n)AA<\u0011yuMN&Zmh^D6Z\u007fiXA&\r4JCJ\u0006\rjb";
      f[10] = "\u0004tqZ\u007f\u0006\u000b4<Qu\u001b\u000ei7\u0017}\u0006\u0003o3\\>$\b~*Uu";
      f[11] = boolean.class;
      g[11] = "java/lang/Boolean";
      f[12] = "\rnJ\u0018\u0001\u0004\rn]D\r\u000b\u0017%IY\u001e\u0001\u0007%[X\u0018\u0004\u0017r\u0010F\u0000\f\u001anL\u0018%\u0003\u0015nPB\u0003\u001f\u001a";
      f[13] = "y4\u0004\u0006Y\u000ey4\u0013ZU\u0001c\u007f\u0013GF\u00029\u001f\u001fFz\u0012{=<AG\u0013";
      f[14] = " h6I!e h!\u0015-j:#5\b>`*#.\u0002:i\"# \u000b#o%#\u0000\u000b#o%~";
      f[15] = "r\u001e[t\u0010&r\u001eL(\u001c)hUX5\u000f#xUC?\u000b*pUM6\u0012,wUm6\u0012,w";
      f[16] = "_f(\u001f;\u0012_f?C7\u001dE-+^$\u0017U-9_\"\u0012Ezrt'\u000eXs1T8\u000fbo3E";
      f[17] = "qA\u0016m(\u0019zN\u0007\"I\u0017qE\u0003x";
      f[18] = "z(i\rM(+rTy|\u001b\u0018\t\u0019g1l%tdAK=\u007f";
      f[19] = "uy*\bP|\u007fp+R(+\u0018/o\u0002\u0019}\u0018\u0013iL\u0019(v)8\u000fS:";
      f[20] = "Nj\u0016vChDc\u0017,;?#<S|\u0004n#\u0000U2\n<M:\u0004q@.";
      f[21] = "\u0007icHV\u000e\r`b\u0012.Yj?&B\u0010\u000ej\u0003 \f\u001fZ\u00049qOUH";
      f[22] = ";{@\u0018mT1rAB\u0015\u0003V-\u0005\u0012%UV\u0011\u0003\\$\u00008+R\u001fn\u0012";
      f[23] = "%]@eQ+pW\fc,\u001b\u001c_B!\u0012`#\u001eHc\u001cP!\u001a_{A5r\u0003Y#,";
      f[24] = "fd\u0019{6flm\u0018!N1\u000b2\\q~f\u000b\u000eZ?\u007f2e4\u000b|5 ";
      f[25] = ")Z%Ond{T M\fC\n~\u001cjE@\u000f?0Osc!]bAva";
      f[26] = "y]k8_\u0007sTjb'P\u0014\u000b.2\u001a\u0004\u00147(|\u0016Sz\ry?\\A";
      f[27] = "\u0004>\f\u001fx.\u000e7\rE\u0000yihI\u00150'iTO[1z\u0007n\u001e\u0018{h";
      f[28] = "\\\f+hSw\rV\u0016\u0014nD'*P\u0014/3\u0003P&$UbY";
      f[29] = "\u001c\u0004^u^=_\u0015\fu<:wE\u000e7\u0006dwy\t5];FEYi\u0002+";
      f[30] = "'\u000b\u0007G\"Oq\\\u001a\u0019]s\u0018\u0003^\u001emW!][\\b0";
      f[31] = "\u0002Y.\\@cAH|\\\"di\u0018~\u001f\u001d5i$y\u001cCeX\u0018)@\u001cu";
      f[32] = "\u007f\u001d5K\"\u000eu\u00144\u0011ZY\u0012KpAd\n\u0012wv\u000fkZ|M'L!H";
      f[33] = "\u0005vC&zM\u000f\u007fB|\u0002\u001ah \u0006,2Hh\u001c\u0000b3\u0019\u0006&Q!y\u000b";
      f[34] = "hi4k.y+xfkL~\u0003(d)t,\u0003\u0014c+-\u007f2(3wro";
      f[35] = ",\u001e?\u001d\"\u00159Sh\fLA\u0012\u001fiLt\u0016\u0012\"8\u0012t\u0016*L-\t4_";
      f[36] = "0<\u000fQiu%qX@\u0007!\u000e=Y\u00029~\u000e\u0000\b^?v6n\u001dE\u007f?";
      f[37] = "8\u007fqtI\u0018i%L\u0002x>FS\u0016\u0005i/\u0006 -y\u0005\u001e|qw";
      f[38] = "\u000b/D\u000f\u0007M\u001eb\u0013\u001ei\u00195.\u0012\\RL5\u0013C\u0000QN\r}V\u001b\u0011\u0007";
      f[39] = "Z,z\u0019Jr\u0019=(\u0019(u1m*Z\u0017+1Q-YIt\u0000m}\u0005\u0016d";
      f[40] = "*1;PN\u0018t6a\u00100\nMol\u0018\u000fXMT`FH_}6=M]\u000f";
      f[41] = "l\u000eq=.\u001a/\u001f#=L\u001d\u0007O!~uC\u0007s&}-\u001c6Ov!r\f";
      f[42] = "G9d'<\f\u0004(6'^\u000b,x4fbZ,D3g?\n\u001dxc;`\u001a";
      f[43] = "\u0003c8ap\nVitg\r\u0018:c+|bKJ={(uq\u00019/v7\u0001_i{a\r";
      f[44] = "tq@exxa<\u0017t\u0016,Jq\u001f?'sJMGj.{r#Rqn2";
      f[45] = "Ipi\u0013I%\na;\u0013+\"\"19Q\u0010r\"\r>SJ#\u00131n\u000f\u00153";
      f[46] = "0a^ uTsp\f \u0017S[ \u000eb*\u0007[\u001c\t`vRj Y<)B";
      f[47] = "A2 \u0017p9\u00148l\u0011\r\u001ax0\"S3rGq(\u0011=B";
      f[48] = "D\rI\u0016u'\u0007\u001c\u001b\u0016\u0017 /L\u0019W,u/p\u001eVv!\u001eLN\n)1";
      f[49] = "tm}}*|7|/}H{\u001f,-<r$\u001f\u0010*=)z.,zavj";
      f[50] = "M.\u000b\u0012F}\u000e?Y\u0012$z&o[W\u0015-&S\\RE{\u0017o\f\u000e\u001ak";
      f[51] = "d\u000e\u0006VlA6\u0000\u0003T\u000egC$\"3dFq\u000e\u001bQ6Ht\f";
      f[52] = "FArsRELHs)*\u0012+\u00177y\u0014D++17\u001b\u0011E\u0011`tQ\u0003";
      f[53] = "7\u007fRg%*tn\u0000gG-\\>\u0002%||\\\u0002\u0005'&,m>U{y<";
      f[54] = "\u007f\\\u0013$=7.\u0006.U\u001b\n\u0007=\u0010u|}=GA/";
      f[55] = "(]XL;$y\u0007e7\u0007\u0017WzeB&c&@\u001f\u0013|";
      f[56] = "K$(Yxe^i\u007fH\u00161u%~\u000e'du\u0018/V.fMv:Mn/";
      f[57] = "2\u001f\u0000 \u001d\u0004q\u000eR \u007f\u0003Y^PcETYbW`\u001e\u0002h^\u0007<A\u0012";
      f[58] = "4\u001c\u0006\u001fN;>\u0015\u0007E6lYJC\u0015\u000b3YvE[\u0007o7L\u0014\u0018M}";
      f[59] = "\"\u0007\u0017{{\u0015a\u0016E{\u0019\u0012IFG>)BIz@;x\u0013xF\u0010g'\u0003";
      f[60] = "WLj\u001d)D\u0014]8\u001dKC<\r:_s\u001c<1=]*B\r\rm\u0001uR";
      f[61] = "N1TP\u0003\u000b\u0019;W\u0007{U'h\u000b\u0005G\u0003'R\fX\u001dP\bb[R\u001e\u0007";
      f[62] = "b(D\u0019\u0019\u007f7\"\b\u001fd\u007f[*F]Z4dkL\u001fT\u0004";
      f[63] = "%zK[?vs-V\u0005@@\u001ar\u0012\u0002pn#,\u0017@\u007f\t'>DZ-lt'B\u0002@";
      f[64] = ")\u0019d\u0017 t{\u0017a\u0015BX\u000e1Gr(s<\u0019y\u0010z}9\u001b";
      f[65] = "|(q\u0014z$\"/+T\u00046\u001bv&\\;e\u001bM*\u0002|c+/w\ti3";
      f[66] = "\u0018\u0001\u0005*<JJ\u000f\u0000(^c2)!\u0013^B\u0017\u001b\u001f-<\u0010\u0019\u001e\u001d";
      f[67] = "\u000f?.\u0012*m^e\u0013m\u0011S}^-Ck'M$|\u0019";
      f[68] = "J2?:@L\u0018<:8\"nm\u001e\f_HK_2\"=\u001aEZ0";
      f[69] = "5\"uFea?+t\u001c\u001d6Xt0L-iXH6\u0002,56rgAf'";
      f[70] = "n\u0017,N*Q-\u0006~NHV\u0005V|\fs\u0003\u0005j{\u000e)W4V+RvG";
      f[71] = "\b#\u00110)4K2C0K3cbArqfc^Fp*2Rb\u0016,u\"";
      f[72] = "\u0004>#c5nG/qcWio\u007fs m<oCt#6h^\u007f$\u007fix";
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static double p(ItemStack a, long a) {
      a = 友何树何友树友树何何.a ^ a;
      int var10000 = b<"O">(9082597417498559633L, a);
      double damage = 0.0;
      Multimap attributeModifierMap = a.getAttributeModifiers(b<"Â">(9079855978375732814L, a));
      int ax = var10000;
      Iterator var8 = attributeModifierMap.keySet().iterator();
      Object var12;
      if (var8.hasNext()) {
         var12 = var8.next();
      } else {
         var12 = a;
         if (a > 0L) {
            if (a.hasFoil()) {
               damage = damage
                  + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(9079898357881048572L, a), a)
                  + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(9079656109849929048L, a), a) * 1.25;
            }

            return damage;
         }
      }

      do {
         Attribute attributeName = (Attribute)var12;
         if (attributeName.getDescriptionId().equals(a<"z">(9052, 4323793504924134752L ^ a))) {
            Iterator<AttributeModifier> attributeModifiers = attributeModifierMap.get(attributeName).iterator();
            if (attributeModifiers.hasNext()) {
               damage += attributeModifiers.next().getAmount();
               if (a > 0L) {
                  if (ax == 0) {
                     b<"O">(!b<"O">(9080343255485321541L, a), 9082522248240026891L, a);
                  }
               } else {
                  b<"O">(ax == 0, 9082522248240026891L, a);
               }
            }
         }

         var12 = a;
      } while (a <= 0L);

      if (a.hasFoil()) {
         damage = damage
            + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(9079898357881048572L, a), a)
            + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(9079656109849929048L, a), a) * 1.25;
      }

      return damage;
   }

   public static int t(long var0) {
      long var3 = a ^ var0 ^ 92862177597993L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 40827965817648L;
         long ax = a ^ 76761060716265L;
         b<"O">(-1968423641410327171L, a);
         return !item.isEmpty() && item.getItem() == b<"Â">(-1966096147910070559L, a) && l(ax, item);
      }).mapToInt(ItemStack::getCount).sum();
   }

   public static float t(int a, int stack, int a, ItemStack a) {
      long ax = ((long)a << 48 | (long)stack << 32 >>> 16 | (long)a << 48 >>> 48) ^ 友何树何友树友树何何.a;
      long axx = ax ^ 98829635253610L;
      int var10000 = b<"O">(4812023562840701021L, ax);
      float valence = 0.0F;
      int axxx = var10000;
      if (a == null) {
         return 0.0F;
      } else if (a.isEmpty()) {
         return 0.0F;
      } else {
         if (a.getItem() instanceof AxeItem axe && e(axx, a)) {
            AxeItem var15 = axe;
            Item var10001 = b<"Â">(4817119683495855068L, ax);
            if (axxx != 0) {
               if (axe == var10001) {
                  valence = 4.0F;
               }

               var15 = axe;
               var10001 = b<"Â">(4814184094887093944L, ax);
            }

            if (axxx != 0) {
               if (var15 == var10001) {
                  valence += 5.0F;
               }

               var15 = axe;
               var10001 = b<"Â">(4811808323633909066L, ax);
            }

            if (axxx != 0) {
               if (var15 == var10001) {
                  valence += 6.0F;
               }

               var15 = axe;
               var10001 = b<"Â">(4817062087549397005L, ax);
            }

            if (axxx != 0) {
               if (var15 == var10001) {
                  valence += 4.0F;
               }

               var15 = axe;
               var10001 = b<"Â">(4811180426490681453L, ax);
            }

            if (var15 == var10001) {
               valence += 7.0F;
            }
         }

         int itemEnchantmentLevel = EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(4813513427710597524L, ax), a);
         float damageBonus = b<"Â">(4813513427710597524L, ax).getDamageBonus(itemEnchantmentLevel, b<"Â">(4811888034709148967L, ax));
         return valence + damageBonus;
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static ItemStack j(long var0) {
      long var3 = a ^ var0 ^ 73075601437235L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 45468955497009L;
         long ax = a ^ 80989180608488L;
         long axx = a ^ 36862794303797L;
         b<"O">(8480222401317518460L, a);
         return !item.isEmpty() && item.getItem() instanceof BlockItem && 友树友友何友树友树友.h(axx, item) && l(ax, item);
      }).max(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static boolean j(ItemStack a, long a) {
      a = 友何树何友树友树何何.a ^ a;
      long ax = a ^ 24995737776670L;
      b<"O">(8673325237698544327L, a);
      return E(a) > 10.0F && l(ax, a);
   }

   public static ItemStack U(long var0) {
      long var3 = a ^ var0 ^ 49779369265410L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 26473137006697L;
         long ax = a ^ 132910217332144L;
         long axx = a ^ 18483809039213L;
         b<"O">(-3461020637193402844L, a);
         return !item.isEmpty() && item.getItem() instanceof BlockItem && 友树友友何友树友树友.h(axx, item) && l(ax, item);
      }).min(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static ItemStack z(long var0) {
      long var3 = a ^ var0 ^ 102981848445909L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 70017745091986L;
         long ax = a ^ 104849101623371L;
         b<"O">(6488802698420622303L, a);
         return !item.isEmpty() && item.getItem() instanceof BowItem && l(ax, item);
      }).max(Comparator.comparingInt(s -> (int)(E(s) * 100.0F))).orElse(null);
   }

   public static int z(long var0) {
      long var3 = a ^ var0 ^ 129117871878837L;
      return n(var3)
         .stream()
         .filter(
            item -> {
               long a = 友何树何友树友树何何.a ^ 39005459403432L;
               long ax = a ^ 74268459843441L;
               b<"O">(-778416395795083352L, a);
               return !item.isEmpty()
                  && item.getItem().isEdible()
                  && item.getItem() != b<"Â">(-777333299148331144L, a)
                  && item.getItem() != b<"Â">(-779016045425308859L, a)
                  && l(ax, item);
            }
         )
         .mapToInt(ItemStack::getCount)
         .sum();
   }

   public static ItemStack w(long var0) {
      long var3 = a ^ var0 ^ 103675123262735L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 6649568812015L;
         long ax = a ^ 113242895038006L;
         long axx = a ^ 73744089959384L;
         long axxx = a ^ 84825492077396L;
         b<"O">(8967196885765338530L, a);
         return !item.isEmpty() && item.getItem() instanceof AxeItem && e(axx, item) && l(ax, item) && !L(axxx, item);
      }).max(Comparator.comparingInt(s -> {
         long var10001 = 友何树何友树友树何何.a ^ 57182179491845L ^ 3353873367757L;
         int a = (int)((友何树何友树友树何何.a ^ 57182179491845L ^ 3353873367757L) >>> 48);
         int ax = (int)((友何树何友树友树何何.a ^ 57182179491845L ^ 3353873367757L) << 16 >>> 32);
         int var5 = (int)(var10001 << 48 >>> 48);
         return (int)(t((char)a, ax, (short)var5, s) * 100.0F);
      })).orElse(null);
   }

   public static float u(ItemStack stack) {
      long a = 友何树何友树友树何何.a ^ 39942448772480L;
      b<"O">(-3307184449501894528L, a);
      int valence = 0;
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else {
         if (stack.getItem() instanceof CrossbowItem) {
            valence = 0
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-3307859781366402176L, a), stack)
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-3306871680888426542L, a), stack)
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-3310055667959525562L, a), stack);
         }

         return valence;
      }
   }

   public static float r(EquipmentSlot a, long a) {
      long ax = 友何树何友树友树何何.a ^ a ^ 14542063358556L;
      return n(ax).stream().filter(item -> {
         long axx = 友何树何友树友树何何.a ^ 3635328305655L;
         b<"O">(7957194642480813303L, axx);
         return !item.isEmpty() && item.getItem() instanceof ArmorItem && ((ArmorItem)item.getItem()).getEquipmentSlot() == a;
      }).map(友何树何友树友树何何::C).max(Float::compareTo).orElse(0.0F);
   }

   public static float y(long var0) {
      long var3 = a ^ var0 ^ 87024490287222L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 137718007522477L;
         long ax = a ^ 32653215336820L;
         b<"O">(4843582164092909997L, a);
         return !item.isEmpty() && item.getItem() instanceof BowItem && l(ax, item);
      }).map(友何树何友树友树何何::Y).max(Float::compareTo).orElse(0.0F);
   }

   public static float E(ItemStack stack) {
      long a = 友何树何友树友树何何.a ^ 417395133474L;
      b<"O">(-1460041062225042833L, a);
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else {
         return stack.getItem() instanceof BowItem
            ? 10.0F
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-1466361589845858848L, a), stack)
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-1463239056908821052L, a), stack)
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-1462575288640125377L, a), stack)
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-1463142000796431763L, a), stack) / 10.0F
               + (float)stack.getDamageValue() / stack.getMaxDamage()
            : 0.0F;
      }
   }

   public static float A(ItemStack stack) {
      long a = 友何树何友树友树何何.a ^ 67236583570379L;
      b<"O">(6653462773865518470L, a);
      float valence = 0.0F;
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else {
         if (stack.getItem() instanceof SwordItem sword) {
            valence = 0.0F + (sword.getDamage() + 1.0F);
         }

         int itemEnchantmentLevel = EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(6654958145116653314L, a), stack);
         float damageBonus = b<"Â">(6654958145116653314L, a).getDamageBonus(itemEnchantmentLevel, b<"Â">(6652207481874058161L, a));
         return valence + damageBonus;
      }
   }

   public static float Y(ItemStack stack) {
      long a = 友何树何友树友树何何.a ^ 64523144617723L;
      b<"O">(-475729353670741834L, a);
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else {
         return stack.getItem() instanceof BowItem
            ? 10.0F
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-468562201954158791L, a), stack) / 10.0F
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-474921835568967907L, a), stack)
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-474327898900507418L, a), stack)
               + EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(-474889148377982796L, a), stack)
               + (float)stack.getDamageValue() / stack.getMaxDamage()
            : 0.0F;
      }
   }

   public static ItemStack X(long var0) {
      long var3 = a ^ var0 ^ 128922756411860L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 73795045098140L;
         long ax = a ^ 39513377533765L;
         b<"O">(-6556494355218764591L, a);
         return !item.isEmpty() && item.getItem() instanceof ArrowItem && l(ax, item);
      }).min(Comparator.comparingInt(ItemStack::getCount)).orElse(null);
   }

   public static float X(EquipmentSlot a, long a) {
      a = 友何树何友树友树何何.a ^ a;
      int var4 = b<"O">(608452461323239842L, a);
      if (a == b<"Â">(606659675118674103L, a)) {
         return C((ItemStack)b<"o">(mc.player.getInventory(), 606363129426401144L, a).get(3));
      } else {
         EquipmentSlot var10000 = a;
         EquipmentSlot var10001 = b<"Â">(606564500200013517L, a);
         int var10002 = var4;
         if (a >= 0L) {
            if (var4 == 0) {
               if (a == var10001) {
                  return C((ItemStack)b<"o">(mc.player.getInventory(), 606363129426401144L, a).get(2));
               }

               var10000 = a;
               var10001 = b<"Â">(609836106437531836L, a);
            }

            if (a <= 0L) {
               return var10000 == var10001 ? C((ItemStack)b<"o">(mc.player.getInventory(), 606363129426401144L, a).get(0)) : 0.0F;
            }

            var10002 = var4;
         }

         if (var10002 == 0) {
            if (var10000 == var10001) {
               return C((ItemStack)b<"o">(mc.player.getInventory(), 606363129426401144L, a).get(1));
            }

            var10000 = a;
            var10001 = b<"Â">(606406638807779628L, a);
         }

         return var10000 == var10001 ? C((ItemStack)b<"o">(mc.player.getInventory(), 606363129426401144L, a).get(0)) : 0.0F;
      }
   }

   public static boolean L(long a, ItemStack var2) {
      a = 友何树何友树友树何何.a ^ a;
      int var4 = b<"O">(6967214692114639203L, (long)a);
      if (var2.isEmpty()) {
         return false;
      } else if (var2.getItem() != b<"Â">(6965617640715717246L, (long)a)) {
         return false;
      } else {
         int var10000 = EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(6971137716313357287L, (long)a), var2);
         int var10001 = var4;
         if (a >= 0L) {
            if (var4 != 0) {
               return (boolean)var10000;
            }

            var10001 = 100;
         }

         return (boolean)(var10000 > var10001 ? 1 : 0);
      }
   }

   public static int N(ItemStack a, long a) {
      a = 友何树何友树友树何何.a ^ a;
      b<"O">(7451200670795509428L, a);
      return -1;
   }

   public static int P() {
      return 树友何树友何树树友树;
   }

   public static boolean P(long a, ItemStack a) {
      a = 友何树何友树友树何何.a ^ a;
      int var4 = b<"O">(4833652453235554702L, (long)a);
      if (a.isEmpty()) {
         return false;
      } else {
         Item var10000;
         Item var10001;
         int var10002;
         label57: {
            label56: {
               if (a.getItem() instanceof AxeItem) {
                  var10000 = a.getItem();
                  var10001 = b<"Â">(4830828404653894110L, (long)a);
                  var10002 = var4;
                  if (a < 0L) {
                     break label57;
                  }

                  if (var4 == 0) {
                     break label56;
                  }

                  if (var10000 == var10001 && EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(4836338582499252295L, (long)a), a) > 100) {
                     return true;
                  }
               }

               var10000 = a.getItem();
               var10001 = b<"Â">(4832742081877567129L, (long)a);
            }

            var10002 = var4;
         }

         if (a > 0L) {
            if (var10002 != 0) {
               if (var10000 == var10001 && EnchantmentHelper.getItemEnchantmentLevel(b<"Â">(4836480812753414407L, (long)a), a) > 1) {
                  return true;
               }

               var10000 = a.getItem();
               var10001 = b<"Â">(4832829024938339688L, (long)a);
            }

            if (a <= 0L) {
               return var10000 == var10001;
            }

            var10002 = var4;
         }

         if (var10002 != 0) {
            if (var10000 == var10001) {
               return true;
            }

            var10000 = a.getItem();
            var10001 = b<"Â">(4834404242323646762L, (long)a);
         }

         return var10000 == var10001;
      }
   }

   public static int T(Item a, long checkItem) {
      long ax = 友何树何友树友树何何.a ^ checkItem ^ 78187134169028L;
      return n(ax).stream().filter(item -> {
         long axx = 友何树何友树友树何何.a ^ 61065234531337L;
         b<"O">(7175244219372198153L, axx);
         return !item.isEmpty() && item.getItem() == a;
      }).mapToInt(ItemStack::getCount).sum();
   }

   public static ItemStack T(long var0) {
      long var3 = a ^ var0 ^ 136006001109749L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 96368590830817L;
         long ax = a ^ 60850496360760L;
         b<"O">(1981499891338728108L, a);
         return !item.isEmpty() && item.getItem() instanceof FishingRodItem && l(ax, item);
      }).findAny().orElse(null);
   }

   public static float G(long var0) {
      long var3 = a ^ var0 ^ 136504340256660L;
      return n(var3).stream().filter(item -> {
         long a = 友何树何友树友树何何.a ^ 41787765744026L;
         long ax = a ^ 78010217204803L;
         b<"O">(5044180091268562074L, a);
         return !item.isEmpty() && item.getItem() instanceof CrossbowItem && l(ax, item);
      }).map(友何树何友树友树何何::u).max(Float::compareTo).orElse(0.0F);
   }

   public static float K(ItemStack stack) {
      long a = 友何树何友树友树何何.a ^ 29489114020871L;
      long ax = a ^ 105330370210864L;
      long axx = a ^ 6014331666204L;
      b<"O">(-2622785123928665526L, a);
      float valence = 0.0F;
      if (stack == null) {
         return 0.0F;
      } else if (stack.isEmpty()) {
         return 0.0F;
      } else if (P(axx, stack)) {
         return 0.0F;
      } else if (e(ax, stack)) {
         return 0.0F;
      } else {
         if (stack.getItem() instanceof PickaxeItem) {
            valence = 0.0F + stack.getDestroySpeed(b<"Â">(-2622496859909145880L, a).defaultBlockState());
         }

         if (stack.getItem() instanceof AxeItem) {
            valence += stack.getDestroySpeed(b<"Â">(-2623064391075284895L, a).defaultBlockState());
         }

         if (stack.getItem() instanceof ShovelItem) {
            float var10000 = valence + stack.getDestroySpeed(b<"Â">(-2622212294659296488L, a).defaultBlockState());
         }

         return 0.0F;
      }
   }

   public static ItemStack K(long var0) {
      long var3 = a ^ var0 ^ 20012313703326L;
      return n(var3)
         .stream()
         .filter(
            item -> {
               long a = 友何树何友树友树何何.a ^ 132687368369107L;
               long ax = a ^ 26800542637578L;
               b<"O">(-7760374306494554722L, a);
               return !item.isEmpty()
                  && item.getItem().isEdible()
                  && item.getItem() != b<"Â">(-7760545828487952893L, a)
                  && item.getItem() != b<"Â">(-7761044813056562626L, a)
                  && l(ax, item);
            }
         )
         .min(Comparator.comparingInt(ItemStack::getCount))
         .orElse(null);
   }

   private static String HE_JIAN_GUO() {
      return "何大伟230622198107200054";
   }
}
