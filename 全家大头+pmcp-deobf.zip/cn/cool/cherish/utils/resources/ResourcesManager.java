package cn.cool.cherish.utils.resources;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.platform.NativeImage;
import heilongjiang.zhaoyuan.何树友;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.system.MemoryUtil;

public class ResourcesManager implements IWrapper, 何树友 {
   public File resources;
   public File 友友何友友何何树何何;
   public final Map<String, byte[]> 何树树树何何何树友友;
   private static Module[] 何友友何何树树树树树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[19];
   private static final String[] g = new String[19];
   private static String LIU_YA_FENG;

   public ResourcesManager(int a, int a, char a) {
      b<"í">(this, new File(Cherish.getConfigManager().getMainFile(), "resources"), 3400386036273767974L, 59234770693939L);
      b<"í">(this, new File(b<"ü">(this, 3400386036273767974L, 59234770693939L), "font"), 3402368507347596879L, 59234770693939L);
      this.何树树树何何何树友友 = new HashMap<>();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2050049788031853855L, 3955506831480330925L, MethodHandles.lookup().lookupClass()).a(3014873876276L);
      // $VF: monitorexit
      a = var10000;
      a();
      w(null);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(43564351331122L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[8];
      int var5 = 0;
      String var4 = "þ\u007f\u0015\u009d{È\u0087b\u0086ýÌª÷r \u001b[ó\u001b£yÂ\u008d\u001b ÜÖ\u0011\u0082¦ä\u0004\u0011£Jÿ\u0095\u0086¿ÈñÆ)û\u0004æ\u0010\u00123R\u0094\u0002û/Ë6l8ºj¡\u0018H\u009eH\u0006\u0091\u0082B+\u0095L\u000f]\u0082sÂøÚ\u009eêþ§\u0087È\u0086 \t¿\tky<ÅjO\u0093A\u0087Uy65\u0085+×D\u0092t0§¶};8DtÔ\u000fEuÄ°EÂÏÙc\u009b¿9\u0083¤MÞ2ýÇÓ\u001d\u009bhG\n\u001c Àw\u0090Þ@â\u001c8Óü3\u008bÓµ½ç¹ÕÐg\t(õ\u0092TH¡WcAØñ,¤c\u0092ÜÂÙWîf\u0082\u007f\u0088\u0093\u0096ADe|Ú4={n\u00836Ïe~\u0004®Â7`\u0093«\u0004ÀY2¡s(þ\u0005mñ¥s³Z?Ï\u0089¶}d?·03ì_ÒÈ7\u00106ÕHê\u0081PÄï\u008a%ùE*Ä¿\u001c";
      short var6 = 261;
      char var3 = 24;
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[8];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "\u001b¨~@\u001a\u0090\u0084¶ ¤¶\u009bñ]¶DUTØS\u008a Y¶³\u0095ÆaA\u000e\u0086v\u001f\u0085\u0004x\u0007od\u0090\u0005\u0092k\u0094|8\u008b%çJM\u0096Oü]\u0014þÅ°\n \\pW(m\r\t5\u009fÓL³ô\u0014£\u0002ZU\u001cì ¿æÏÀ´Ê\u0011½:\u0000,úÊé\u0084°\u0096ê-ÎþQ\u0000";
                  var6 = 105;
                  var3 = '@';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 55;
               case 1 -> 7;
               case 2 -> 38;
               case 3 -> 49;
               case 4 -> 8;
               case 5 -> 21;
               case 6 -> 24;
               case 7 -> 43;
               case 8 -> 6;
               case 9 -> 60;
               case 10 -> 25;
               case 11 -> 30;
               case 12 -> 56;
               case 13 -> 63;
               case 14 -> 61;
               case 15 -> 10;
               case 16 -> 0;
               case 17 -> 11;
               case 18 -> 27;
               case 19 -> 19;
               case 20 -> 34;
               case 21 -> 32;
               case 22 -> 58;
               case 23 -> 41;
               case 24 -> 54;
               case 25 -> 48;
               case 26 -> 29;
               case 27 -> 52;
               case 28 -> 47;
               case 29 -> 37;
               case 30 -> 57;
               case 31 -> 1;
               case 32 -> 23;
               case 33 -> 14;
               case 34 -> 4;
               case 35 -> 13;
               case 36 -> 22;
               case 37 -> 20;
               case 38 -> 39;
               case 39 -> 51;
               case 40 -> 3;
               case 41 -> 31;
               case 42 -> 18;
               case 43 -> 53;
               case 44 -> 9;
               case 45 -> 16;
               case 46 -> 15;
               case 47 -> 44;
               case 48 -> 12;
               case 49 -> 36;
               case 50 -> 42;
               case 51 -> 33;
               case 52 -> 45;
               case 53 -> 50;
               case 54 -> 5;
               case 55 -> 62;
               case 56 -> 46;
               case 57 -> 26;
               case 58 -> 17;
               case 59 -> 40;
               case 60 -> 2;
               case 61 -> 28;
               case 62 -> 59;
               default -> 35;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/resources/ResourcesManager" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 252 && var8 != 237 && var8 != 's' && var8 != 'i') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'k') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'a') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 252) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 237) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 's') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   public byte[] f(InputStream a, long a) throws IOException {
      a = 63103823656118L ^ a;
      ByteArrayOutputStream outStream = new ByteArrayOutputStream();
      b<"a">(-218901380887492506L, a);
      byte[] buffer = new byte[1024];
      InputStream input = a;

      byte[] var11;
      try {
         ByteArrayOutputStream output = outStream;

         try {
            int len;
            if ((len = input.read(buffer)) != -1) {
               do {
                  if (a > 0L) {
                     output.write(buffer, 0, len);
                  }
               } while (a < 0L);

               b<"a">(new Module[2], -220244540542557384L, a);
            }

            var11 = output.toByteArray();
         } catch (Throwable var15) {
            if (a > 0L && output != null) {
               try {
                  output.close();
               } catch (Throwable var14) {
                  var15.addSuppressed(var14);
               }
            }

            throw var15;
         }

         if (output != null) {
            output.close();
         }
      } catch (Throwable var16) {
         if (a >= 0L && a != null) {
            try {
               input.close();
            } catch (Throwable var13) {
               var16.addSuppressed(var13);
            }
         }

         throw var16;
      }

      if (a != null) {
         a.close();
      }

      return var11;
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "`ZL\u001e\b\u0010o\u001a\u0001\u0015\u0002\rjG\nS\u0012\u000bjX\u0011S\u0015\u001ap[\u0017\u000f\u0004\u001ap\u001a0\u0018\u0014\u0010vF\u0001\u0018\u00142bZ\u0003\u001a\u0002\r";
      f[1] = "H\u001ahO\u0007r|9g\u000fJyv$bRA?~9oTEt=\u001bdE\\}vm";
      f[2] = "qcFu\u0001\u001d~#\u000b~\u000b\u0000{~\u00008\u0003\u001dvx\u0004s@?}i\u001dz\u000b";
      f[3] = "\u0013)z\"Sx'\nub\u001es-\u0017p?\u00155%\n}9\u0011~f(v(\bw-^";
      f[4] = "d\u0017)9\u0017tP4&yZ\u007fZ)#$Q9R4.\"Ur\u0011\u0016%3L{Z`";
      f[5] = void.class;
      g[5] = "java/lang/Void";
      f[6] = "c!\rIh+h.\u001c\u0006\u0012/{/\fI$+l";
      f[7] = "\u001a\u0003\u001dpuX\u001fL-x7T";
      f[8] = "2=9\u0007J%\u0006\u001e6G\u0007.\f\u00033\u001a\fh\u0004\u001e>\u001c\b#G<5\r\u0011*\fJ";
      f[9] = "\u0007;d\u0014\f\u0004\u00193~[o\u0010\u001d";
      f[10] = "i<mVQdb3|\u00190ji8xC";
      f[11] = "Kk&\r\u0013@\u000e~6\u0003l#r8)\u000e\u0013\u000e\u0019o%\u0003\u0002q";
      f[12] = "x\u001b)\"hB&D7Mg #\u000bn2gKt\u0007c#\u0018\u001b`\u0006ov}]w\u0019#M";
      f[13] = "\u007f\u0018\bOT*!G\u0016 佹桑栀档伯佽佹桑叚厹r\u001eK'y@OZT5(";
      f[14] = "\n\u0012\u001eY%\nTM\u00006/\u0005\u0017\u0017\u0019L>\u0005\u0017pY\bo\u0018\u0010H\u0014\u0006;\n";
      f[15] = "&LE^D\u0007cYUP;h\u001f\u001fJ]DItHFPU6$\\G\\\u0000SbKX\u0010;";
      f[16] = "\u0007\u0011\u001a\u0002\u001agYN\u0004m\u0015\u0005\\\u0001]\u0012\u0015n\u000b\rP\u0003j";
      f[17] = "D^,\n\u0004\\\u001a\u00012e\u001d>\u001e\u00037\f\t\u0000\u0013\u0003j\u0001t\u0002\u001d]?\u0018J\u000f\u001d\u00002e";
      f[18] = "G&X2d\f\u0019yF]受厭佼厇叡伀佉桷佼伙\"`*TQ8\u001a-$\u0000C";
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25570;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/resources/ResourcesManager", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[wE\u0019ö\u009cXÉ!s\u0091ü\u000f_µ8ý, 4\u0099R\u0095U\u0004»ñ¢\u009a")[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/resources/ResourcesManager" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public ByteBuffer o(File a) {
      try {
         byte[] imageBytes = Files.readAllBytes(a.toPath());
         ByteBuffer buffer = MemoryUtil.memAlloc(imageBytes.length);
         buffer.put(imageBytes);
         buffer.flip();
         return buffer;
      } catch (Exception var5) {
         var5.printStackTrace();
         return null;
      }
   }

   public void o(long a) {
      a = 63103823656118L ^ a;
      Module[] var4 = b<"a">(-1048180708445141532L, (long)a);
      if (!b<"ü">(this, -1048293661643491227L, (long)a).exists() && a >= 0L) {
         if (!b<"ü">(this, -1048293661643491227L, (long)a).mkdirs()) {
            null.println(a<"u">(19921, 868181662080720709L ^ a) + b<"ü">(this, -1048293661643491227L, (long)a).getAbsolutePath());
         }

         null.println(a<"u">(11728, 8666337770059906881L ^ a) + b<"ü">(this, -1048293661643491227L, (long)a).getAbsolutePath());
      }

      Module[] var6;
      label44: {
         label48: {
            boolean var10000 = b<"ü">(this, -1048059650553665524L, (long)a).exists();
            if (a >= 0L) {
               if (var10000) {
                  break label48;
               }

               var10000 = b<"ü">(this, -1048059650553665524L, (long)a).mkdirs();
            }

            if (!var10000) {
               null.println(a<"u">(4494, 3994756319394497304L ^ a) + b<"ü">(this, -1048059650553665524L, (long)a).getAbsolutePath());
               var6 = var4;
               if (a <= 0L) {
                  break label44;
               }

               if (var4 == null) {
                  break label48;
               }
            }

            null.println(a<"u">(6650, 291590162519034730L ^ a) + b<"ü">(this, -1048059650553665524L, (long)a).getAbsolutePath());
         }

         var6 = b<"a">(-1048508671054722054L, (long)a);
      }

      if (a >= 0L) {
         if (var6 != null) {
            return;
         }

         var6 = new Module[3];
      }

      b<"a">(var6, -1048489086746956637L, (long)a);
   }

   public ResourceLocation k(String a, long a) {
      a = 63103823656118L ^ a;
      File file = new File(a);
      if (!file.exists()) {
         throw new IllegalArgumentException(a<"u">(7995, 7106399457589531176L ^ a) + a);
      } else {
         try {
            ResourceLocation var9;
            try (FileInputStream inputStream = new FileInputStream(file)) {
               NativeImage nativeImage = NativeImage.read(inputStream);
               DynamicTexture dynamicTexture = new DynamicTexture(nativeImage);
               var9 = mc.getTextureManager().register(a<"u">(21031, 3940793710241242930L ^ a) + file.getName(), dynamicTexture);
            }

            return var9;
         } catch (IOException var12) {
            var12.printStackTrace();
            return null;
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public byte[] v(String a, long a) {
      long ax = 63103823656118L ^ a ^ 64806270567148L;
      long axx = 63103823656118L ^ a ^ 56229822989475L;
      InputStream stream = this.L(a, ax);

      try {
         return this.f(stream, axx);
      } catch (Throwable var10) {
         return null;
      }
   }

   public static Module[] w() {
      return 何友友何何树树树树树;
   }

   public static void w(Module[] var0) {
      何友友何何树树树树树 = var0;
   }

   public InputStream L(String a, long name) {
      name = 63103823656118L ^ name;
      b<"a">(8843178020463660585L, (long)name);
      if (b<"ü">(this, 8844530389879774429L, (long)name).containsKey(a)) {
         return new ByteArrayInputStream((byte[])b<"ü">(this, 8844530389879774429L, (long)name).get(a));
      } else {
         File file = new File(b<"ü">(this, 8844767047083668392L, (long)name), a);

         try {
            if (file.exists()) {
               return Files.newInputStream(file.toPath());
            }
         } catch (Throwable var7) {
         }

         return ResourcesManager.class.getResourceAsStream("/" + a);
      }
   }

   private static String HE_WEI_LIN() {
      return "职业技术教育中心学校";
   }
}
