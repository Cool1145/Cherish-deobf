package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 友友友友何树友何树树 extends 何何何何何友树树树友 implements 何树友 {
   private static final long b;
   private static final Object[] e = new Object[7];
   private static final String[] f = new String[7];
   private static String HE_DA_WEI;

   public 友友友友何树友何树树(int ms, double endPoint, long a) {
      long var10001 = 104799838201160L ^ a ^ 42511752899660L;
      int ax = (int)((104799838201160L ^ a ^ 42511752899660L) >>> 32);
      int axx = (int)((104799838201160L ^ a ^ 42511752899660L) << 32 >>> 48);
      int var8 = (int)(var10001 << 48 >>> 48);
      super(ax, (short)axx, ms, (char)var8, endPoint);
   }

   public 友友友友何树友何树树(long a, int ms, double endPoint, 友何树友树何何友树树 direction) {
      long ax = 104799838201160L ^ a ^ 21797993159635L;
      super(ms, endPoint, direction, ax);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7567181018887868703L, 6601656684477422649L, MethodHandles.lookup().lookupClass()).a(11483200288203L);
      // $VF: monitorexit
      b = var10000;
      a();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 13;
               case 1 -> 10;
               case 2 -> 19;
               case 3 -> 22;
               case 4 -> 51;
               case 5 -> 63;
               case 6 -> 34;
               case 7 -> 8;
               case 8 -> 42;
               case 9 -> 20;
               case 10 -> 37;
               case 11 -> 29;
               case 12 -> 39;
               case 13 -> 59;
               case 14 -> 0;
               case 15 -> 50;
               case 16 -> 41;
               case 17 -> 36;
               case 18 -> 23;
               case 19 -> 58;
               case 20 -> 55;
               case 21 -> 57;
               case 22 -> 7;
               case 23 -> 2;
               case 24 -> 31;
               case 25 -> 56;
               case 26 -> 40;
               case 27 -> 35;
               case 28 -> 28;
               case 29 -> 25;
               case 30 -> 44;
               case 31 -> 54;
               case 32 -> 18;
               case 33 -> 15;
               case 34 -> 52;
               case 35 -> 49;
               case 36 -> 11;
               case 37 -> 12;
               case 38 -> 30;
               case 39 -> 3;
               case 40 -> 61;
               case 41 -> 38;
               case 42 -> 5;
               case 43 -> 14;
               case 44 -> 32;
               case 45 -> 1;
               case 46 -> 6;
               case 47 -> 60;
               case 48 -> 24;
               case 49 -> 43;
               case 50 -> 16;
               case 51 -> 45;
               case 52 -> 27;
               case 53 -> 17;
               case 54 -> 62;
               case 55 -> 53;
               case 56 -> 48;
               case 57 -> 33;
               case 58 -> 26;
               case 59 -> 47;
               case 60 -> 46;
               case 61 -> 9;
               case 62 -> 21;
               default -> 4;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 196 && var8 != 255 && var8 != 'B' && var8 != 243) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 220) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'O') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 196) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 255) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'B') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/友友友友何树友何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      e[0] = "3Ue7'X<\u0015(<-E9H#z=C9W8z)Y9V* !X>He桅厃栦伅株桚企桙栦伅";
      e[1] = "Ov";
      e[2] = "e!c3p`ja.8z}o<%~j{o#>~~ao\",$v`h<c厛叔叄反会桜厛佊栞栗";
      e[3] = ";Xoc\r\u00000W~,q\u0019?MpoF))Z|rW\u0005>W";
      e[4] = "Rrq[w\u0001Y}`\u0014\u0016\u000fRvdN";
      e[5] = "(?\u0011\u0013k2x$M\u0006\u0019 \u0011tY\u0012|/x.@QyI+6^\b\u007f q/\u001d\r\u0019";
      e[6] = "*\u0003m\u0004\u0000h'\u0010u~\u0015\u0011\u007fCk\u001a\u0006n\"McA|";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   protected double v(double a, long var3) {
      b<"O">(2667723625012159660L, var3);
      double var10000 = (double)a;
      if (var3 > 0L) {
         if (a < 0.5) {
            return 2.0 * a * a;
         }

         var10000 = 1.0 - Math.pow(-2.0 * a + 2.0, 2.0) / 2.0;
      }

      return var10000;
   }

   private static String HE_SHU_YOU() {
      return "何炜霖黑水";
   }
}
