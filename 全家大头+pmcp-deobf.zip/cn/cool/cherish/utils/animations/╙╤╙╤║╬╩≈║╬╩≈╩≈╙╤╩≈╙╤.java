package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 友友何树何树树友树友 implements 何树友 {
   public long 何树何何友友何何树何;
   private static final long a;
   private static final Object[] b = new Object[9];
   private static final String[] c = new String[9];
   private static int _何大伟为什么要诈骗何炜霖 _;

   public 友友何树何树树友树友(int a, char a, char a) {
      long ax = ((long)a << 32 | (long)a << 48 >>> 32 | (long)a << 48 >>> 48) ^ 友友何树何树树友树友.a;
      super();
      a<"ß">(this, System.currentTimeMillis(), 9137199611539452208L, ax);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-1612950093167003174L, 5785993169899364176L, MethodHandles.lookup().lookupClass()).a(213340027065307L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public void S(long a) {
      a = 友友何树何树树友树友.a ^ a;
      a<"ß">(this, System.currentTimeMillis(), 5513116144489284479L, (long)a);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public long n(long a) {
      a = 友友何树何树树友树友.a ^ a;
      return System.currentTimeMillis() - a<"¥">(this, 6716826046820078283L, (long)a);
   }

   public boolean f(long a, long time, boolean a) {
      time = 友友何树何树树友树友.a ^ time;
      long ax = time ^ 118914349234233L;
      a<"q">(-8361471418929419878L, time);
      if (System.currentTimeMillis() - a<"¥">(this, -8361542721087765496L, time) > a) {
         if (a) {
            this.S(ax);
         }

         return true;
      } else {
         return false;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/友友何树何树树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 165 && var8 != 223 && var8 != 'U' && var8 != 'T') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'Q') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'q') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 165) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'U') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 3;
               case 1 -> 53;
               case 2 -> 47;
               case 3 -> 29;
               case 4 -> 0;
               case 5 -> 6;
               case 6 -> 18;
               case 7 -> 62;
               case 8 -> 22;
               case 9 -> 51;
               case 10 -> 60;
               case 11 -> 57;
               case 12 -> 20;
               case 13 -> 40;
               case 14 -> 36;
               case 15 -> 1;
               case 16 -> 58;
               case 17 -> 43;
               case 18 -> 26;
               case 19 -> 34;
               case 20 -> 63;
               case 21 -> 45;
               case 22 -> 10;
               case 23 -> 16;
               case 24 -> 2;
               case 25 -> 12;
               case 26 -> 28;
               case 27 -> 31;
               case 28 -> 19;
               case 29 -> 46;
               case 30 -> 33;
               case 31 -> 44;
               case 32 -> 30;
               case 33 -> 5;
               case 34 -> 32;
               case 35 -> 37;
               case 36 -> 54;
               case 37 -> 50;
               case 38 -> 24;
               case 39 -> 42;
               case 40 -> 39;
               case 41 -> 21;
               case 42 -> 13;
               case 43 -> 7;
               case 44 -> 4;
               case 45 -> 15;
               case 46 -> 56;
               case 47 -> 17;
               case 48 -> 35;
               case 49 -> 9;
               case 50 -> 48;
               case 51 -> 27;
               case 52 -> 25;
               case 53 -> 38;
               case 54 -> 23;
               case 55 -> 11;
               case 56 -> 61;
               case 57 -> 41;
               case 58 -> 52;
               case 59 -> 8;
               case 60 -> 59;
               case 61 -> 49;
               case 62 -> 55;
               default -> 14;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "fok\u0011B\u001bi/&\u001aH\u0006lr-\\X\u0000lm6\\L\u001all$\u0006D\u001bkrk厹另伡栔佔桔档另桥収";
      b[1] = long.class;
      c[1] = "java/lang/Long";
      b[2] = "\u001d\n0\u000bsg\u0016\u0005!D\u000f~\u0019\u001f/\u00078N\u000f\b#\u001a)b\u0018\u0005";
      b[3] = "\u001fVpi\u0000>\u0010\u0016=b\n#\u0015K6$\u001a%\u0015T-$\u000e?\u0015U?~\u0006>\u0012Kp叁伺厚桭栩桏栛伺桀厷";
      b[4] = "xVY\t\"4\rvR\u00063{pnA\u0001:2\u0018";
      b[5] = "c6\u001bQ\u0002ih9\n\u001ecgc2\u000eD";
      b[6] = "'tK |{(i\\^x\u001dqgX.va2bC#\u0011$7{K9mg2`F^";
      b[7] = "V4\u0010;a\u000fY)\u0007E佑桰佤伅厣历佑伴栠伅`|1\u0013\u00061X.r\u0015\u0001";
      b[8] = "<0!]U+j:4W/ \u0006kuC^\"w $Q\u001fY";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public boolean Y(double a, long var3) {
      long ax = 友友何树何树树友树友.a ^ var3 ^ 140656363036544L;
      return this.P((long)a, ax);
   }

   public void X(long a, long var3) {
      var3 = 友友何树何树树友树友.a ^ var3;
      a<"ß">(this, (long)a, -5359598995405882781L, var3);
   }

   public boolean P(long a, long var3) {
      var3 = 友友何树何树树友树友.a ^ var3;
      a<"q">(-342500668583896749L, var3);
      return System.currentTimeMillis() - a<"¥">(this, -343133058828340031L, var3) > a;
   }

   private static String LIU_YA_FENG() {
      return "何建国230622195906030014";
   }
}
