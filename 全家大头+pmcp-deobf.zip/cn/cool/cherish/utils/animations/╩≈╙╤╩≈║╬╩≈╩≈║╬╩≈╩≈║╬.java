package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 树友树何树树何树树何 extends 何何何何何友树树树友 implements 何树友 {
   private final float 何树友友树何友友何树;
   private static int[] 何何何何树友友何友友;
   private static final long b;
   private static final Object[] e = new Object[16];
   private static final String[] f = new String[16];
   private static int _何炜霖230622200409390090 _;

   public 树友树何树树何树树何(long a, int ms, double endPoint, float easeAmount) {
      super(17635, (short)25360, ms, '\uf157', 1.0);
      this.何树友友树何友友何树 = easeAmount;
   }

   public 树友树何树树何树树何(int ms, double endPoint, long a, float easeAmount, 友何树友树何何友树树 direction) {
      long ax = 3326827596359L ^ a ^ 44978106903254L;
      super(ms, endPoint, direction, ax);
      this.何树友友树何友友何树 = easeAmount;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7240131821417900012L, 1296072851387251735L, MethodHandles.lookup().lookupClass()).a(46644609380281L);
      // $VF: monitorexit
      b = var10000;
      c();
      if (a() != null) {
         M(new int[1]);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 27;
               case 1 -> 17;
               case 2 -> 1;
               case 3 -> 47;
               case 4 -> 9;
               case 5 -> 15;
               case 6 -> 16;
               case 7 -> 23;
               case 8 -> 12;
               case 9 -> 37;
               case 10 -> 3;
               case 11 -> 61;
               case 12 -> 10;
               case 13 -> 45;
               case 14 -> 62;
               case 15 -> 43;
               case 16 -> 40;
               case 17 -> 4;
               case 18 -> 55;
               case 19 -> 0;
               case 20 -> 44;
               case 21 -> 41;
               case 22 -> 38;
               case 23 -> 13;
               case 24 -> 34;
               case 25 -> 21;
               case 26 -> 58;
               case 27 -> 51;
               case 28 -> 14;
               case 29 -> 22;
               case 30 -> 6;
               case 31 -> 49;
               case 32 -> 56;
               case 33 -> 53;
               case 34 -> 11;
               case 35 -> 19;
               case 36 -> 24;
               case 37 -> 32;
               case 38 -> 57;
               case 39 -> 20;
               case 40 -> 50;
               case 41 -> 5;
               case 42 -> 26;
               case 43 -> 30;
               case 44 -> 54;
               case 45 -> 31;
               case 46 -> 8;
               case 47 -> 33;
               case 48 -> 36;
               case 49 -> 59;
               case 50 -> 42;
               case 51 -> 48;
               case 52 -> 28;
               case 53 -> 25;
               case 54 -> 46;
               case 55 -> 52;
               case 56 -> 18;
               case 57 -> 29;
               case 58 -> 7;
               case 59 -> 60;
               case 60 -> 2;
               case 61 -> 39;
               case 62 -> 35;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'r' && var8 != 'G' && var8 != 222 && var8 != 204) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 220) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'f') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'r') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'G') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 222) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/树友树何树树何树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void c() {
      e[0] = "Hy\u0013\u001e\\sG9^\u0015VnBdUSFhB{NSRrBz\\\tZsEd\u0013桬司栍佾栆栬伨栢栍佾";
      e[1] = "\u0016U";
      e[2] = "@\u001enhE\u0010O^#cO\rJ\u0003(%G\u0010G\u0005,n\u00042L\u00145gO";
      e[3] = "\tI|6VG=jsv\u001bL7wv+\u0010\n?j{-\u0014A|Hp<\rH7>";
      e[4] = "U}x+d>^rid\u0018'Qhg'/\u0017G\u007fk:>;Pr";
      e[5] = float.class;
      f[5] = "java/lang/Float";
      e[6] = "?\u00048,8d\u000b'7luo\u0001:21~)\t'?7zbJ\u00054&ck\u0001s";
      e[7] = void.class;
      f[7] = "java/lang/Void";
      e[8] = "J8";
      e[9] = "N^\u0003!g:EQ\u0012n\u00064NZ\u00164";
      e[10] = "o{Fr>1?e\\bF\u0013V\"Ja$39}\u0017\u007f A";
      e[11] = "DYza/CCJy\u00024&\u0015He}-TT^`|]\u001dGOtr/\\QJu\u0002";
      e[12] = "\u00019I/TK\u0006*JLO.Ux^,M\\ZyFw&";
      e[13] = "[\u0016jv/\u001c\\\u0005i\u0015伀桠史厭栂佈厞厺佬桷\u001b.#\u0000^\f'-8\u001a]";
      e[14] = "\u0018\u001d\b7\r\u0010H\u0003\u0012'u>!D\u0004$\u0017\u0012N\u001bY:\u0013`\u001d\u0006\u00154\u001e\rEC\u000b%u";
      e[15] = "A\u0004hw\u000bwF\u0017k\u0014<\u0012\u0015E\u007ft\u0012`\u001aDg/y.U\u0001h\u007f\u0014v\u0010\u001fy\u0014";
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   public static int[] a() {
      return 何何何何树友友何友友;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   protected double v(double a, long var3) {
      b<"f">(2668115689986930742L, var3);
      float shrink = b<"r">(this, 2668172814339612960L, var3) + 1.0F;
      double var10000 = Math.max(0.0, 1.0 + shrink * Math.pow(a - 1.0, 3.0) + b<"r">(this, 2668172814339612960L, var3) * Math.pow(a - 1.0, 2.0));
      if (var3 > 0L) {
         b<"f">(new Module[5], 2668246923120275078L, var3);
      }

      return var10000;
   }

   public static void M(int[] var0) {
      何何何何树友友何友友 = var0;
   }

   @Override
   protected boolean H(Object[] var1) {
      return true;
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖国企上班";
   }
}
