package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 树何何树友友树何友友 extends 何何何何何友树树树友 implements 何树友 {
   private static final long b;
   private static final Object[] e = new Object[13];
   private static final String[] f = new String[13];
   private static String HE_SHU_YOU;

   public 树何何树友友树何友友(long a, int ms, double endPoint) {
      super(17635, (short)25360, ms, '\uf157', 360.0);
   }

   public 树何何树友友树何友友(long a, int ms, double endPoint, 友何树友树何何友树树 direction) {
      long ax = 2587782847863L ^ a ^ 24679729397499L;
      super(0, 0.0, direction, ax);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8403455788358309542L, 5330885198199102009L, MethodHandles.lookup().lookupClass()).a(145117390672814L);
      // $VF: monitorexit
      b = var10000;
      a();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 51;
               case 1 -> 25;
               case 2 -> 32;
               case 3 -> 30;
               case 4 -> 17;
               case 5 -> 55;
               case 6 -> 39;
               case 7 -> 1;
               case 8 -> 49;
               case 9 -> 41;
               case 10 -> 43;
               case 11 -> 31;
               case 12 -> 60;
               case 13 -> 4;
               case 14 -> 8;
               case 15 -> 59;
               case 16 -> 37;
               case 17 -> 20;
               case 18 -> 63;
               case 19 -> 46;
               case 20 -> 0;
               case 21 -> 33;
               case 22 -> 22;
               case 23 -> 19;
               case 24 -> 47;
               case 25 -> 58;
               case 26 -> 29;
               case 27 -> 26;
               case 28 -> 21;
               case 29 -> 11;
               case 30 -> 24;
               case 31 -> 48;
               case 32 -> 62;
               case 33 -> 9;
               case 34 -> 7;
               case 35 -> 35;
               case 36 -> 38;
               case 37 -> 45;
               case 38 -> 12;
               case 39 -> 10;
               case 40 -> 52;
               case 41 -> 61;
               case 42 -> 27;
               case 43 -> 2;
               case 44 -> 5;
               case 45 -> 42;
               case 46 -> 50;
               case 47 -> 40;
               case 48 -> 14;
               case 49 -> 36;
               case 50 -> 56;
               case 51 -> 53;
               case 52 -> 13;
               case 53 -> 57;
               case 54 -> 15;
               case 55 -> 54;
               case 56 -> 34;
               case 57 -> 6;
               case 58 -> 23;
               case 59 -> 44;
               case 60 -> 16;
               case 61 -> 18;
               case 62 -> 28;
               default -> 3;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 254 && var8 != 'A' && var8 != 225 && var8 != 206) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 240) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'T') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 254) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'A') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 225) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/树何何树友友树何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      e[0] = "\u001bbWB\u001cG\u0014\"\u001aI\u0016Z\u0011\u007f\u0011\u000f\u0006\\\u0011`\n\u000f\u0012F\u0011a\u0018U\u001aG\u0016\u007fW栰厸根伭栝桨佴桢根伭";
      e[1] = ".V";
      e[2] = "\u0005\b:_nn\nHwTds\u000f\u0015|\u0012ln\u0002\u0013xY/L\t\u0002aPd";
      e[3] = "oCts{\u001f[`{36\u0014Q}~n=RY`sh9\u0019\u001aBxy \u0010Q4";
      e[4] = "\u0012J='\u0010\u0004\u001d\np,\u001a\u0019\u0018W{j\n\u001f\u0018H`j\u001e\u0005\u0018Ir0\u0016\u0004\u001fW=桕伪伾桠可变桕伪厠厺";
      e[5] = "viC\u000fDr}fR@8kr|\\\u0003\u000f[dkP\u001e\u001ewsf";
      e[6] = "\u0000Y";
      e[7] = void.class;
      f[7] = "java/lang/Void";
      e[8] = "5 \u0006~\u0018s>/\u00171y}5$\u0013k";
      e[9] = "\u0015cTI\u0013MQv\u001b\u000fza,)KR\u001bLNyR_D3";
      e[10] = "%,\u0014n),~:\u0012S#Ey:\u0002/%$%&\u0012lJ";
      e[11] = "Nd+{\u0015I\fdh:j\u001eud(i\u000f\u0019\u00171ue[wIa~c\u0004\u0015\u001c<r7j";
      e[12] = "~\u0002.\u0019\u00188%\u0014($>Q\"\u00148X\u00140~\b(\u001b{lt\u001c'JD,'Ut$";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   protected double v(double a, long var3) {
      b<"T">(2668001030599180752L, var3);
      double var10000 = -2.0 * Math.pow((double)a, 3.0) + 3.0 * Math.pow((double)a, 2.0);
      if (var3 >= 0L && b<"T">(2667924983515621076L, var3) == null) {
         b<"T">(new int[5], 2668157201070055262L, var3);
      }

      return var10000;
   }

   private static String HE_DA_WEI() {
      return "行走的50万——何炜霖";
   }
}
