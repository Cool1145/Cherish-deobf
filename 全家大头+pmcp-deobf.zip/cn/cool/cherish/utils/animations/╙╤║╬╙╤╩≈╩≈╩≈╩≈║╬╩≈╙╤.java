package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class 友何友树树树树何树友 implements 何树友 {
   public 友友何树何树树友树友 树友树何何树友何何树;
   protected int 何树友友何友何树何何;
   protected double 何何树树树何树树树何;
   protected 友何友树树树友树何友 友何树树何何树树树友;
   private static String[] 何树树何友友树友树树;
   private static final long a;
   private static final Object[] c = new Object[19];
   private static final String[] d = new String[19];
   private static int _何树友被何大伟克制了 _;

   public 友何友树树树树何树友(int ms, long a, double endPoint) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 65947792871114L;
      this(ms, endPoint, ax, a<"C">(7208512013420630532L, a));
   }

   public 友何友树树树树何树友(int ms, double endPoint, long a, 友何友树树树友树何友 direction) {
      a = 友何友树树树树何树友.a ^ a;
      long var10001 = a ^ 111176622603452L;
      int ax = (int)((a ^ 111176622603452L) >>> 32);
      int axx = (int)((a ^ 111176622603452L) << 32 >>> 48);
      int var9 = (int)(var10001 << 48 >>> 48);
      super();
      a<"f">(this, new 友友何树何树树友树友(ax, (char)axx, (char)var9), 4412563604399371562L, a);
      a<"f">(this, ms, 4412905240858569551L, a);
      a<"f">(this, endPoint, 4412845519830352894L, a);
      a<"f">(this, direction, 4412759438620951894L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-8800091519573372532L, 4176121647822548106L, MethodHandles.lookup().lookupClass()).a(263512922200907L);
      // $VF: monitorexit
      a = var10000;
      long var0 = a ^ 64558471799852L;
      a();
      if (a<"e">(-5489569030399458760L, var0) != null) {
         a<"e">(new String[2], -5489519718460298130L, var0);
      }
   }

   public boolean B(友何友树树树友树何友 a, long a) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 63408277037887L;
      a<"e">(-2170939847309438922L, a);
      return this.g(ax) && a<"ÿ">(this, -2172884458108954189L, a).equals(a);
   }

   protected boolean D(Object[] var1) {
      return false;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void d(String[] var0) {
      何树树何友友树友树树 = var0;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      c[0] = "j\u0012\n5r\u0003eRG>x\u001e`\u000fLxh\u0018`\u0010Wx|\u0002`\u0011E\"t\u0003g\u000f\n厝佈厧栘桭栵桇佈桽参";
      c[1] = "p\u001d`dSW\u007f]-oYJz\u0000&)ILz\u001f=)]Vz\u001e/sUW}\u0000`双号佭栂伦桟栖号栩变";
      c[2] = "\\\u0014n\u001cZ<ST#\u0017P!V\t(Q@'V\u00163QT=V\u0017!\u000b\\<Q\tn厴你厘栮桫桑厴栤伆叴";
      c[3] = double.class;
      d[3] = "java/lang/Double";
      c[4] = "O*\\g\u0012mD%M(ntK?CkYD](OvHhJ%";
      c[5] = int.class;
      d[5] = "java/lang/Integer";
      c[6] = "g._o3R\u0012\u000eT`\"\u001do\u0016Gg+T\u0007";
      c[7] = "$aK\u001fWQQA@\u0010F\u001e,YS\u0017OWD";
      c[8] = void.class;
      d[8] = "java/lang/Void";
      c[9] = "\u0010'?L)\u0016\u001b(.\u0003H\u0018\u0010#*Y";
      c[10] = ",^%ooE+_q9\u0010使栏桽伓栘叓叡佋厧伓\u0001*\u0018}\n1f-\u0019)\\";
      c[11] = "\\y\u0015'j%\fs\u0006\u0016栝叛栮佃伷栏叇佅佪标j/?iM~U'ywR";
      c[12] = "m1k5\u0016]=;x\u0004去伽栟桏佉余桡桹栟厕\u0014>B\u000bh)s9C_>";
      c[13] = "->I^U\u0013}4ZoQ.|(H\u0001EA#)[\u0016;\u00147'X\u0011TK64Oo";
      c[14] = "\u0018,=yhfH&.H佛桂厰厈伟压佛桂伮伖Bs\u007f:\u00030(9\u007f4J";
      c[15] = "0\u0000,\u0013\u001f\t`\n?\"伬佩桂桾桊使桨栭桂伺S\u0018A\u00051\u00155Y\u001aQc";
      c[16] = "\u0019b,\u0018$yIh?)3DOn8H1>\bz+UJ";
      c[17] = "\u0016m\u007f}H\u001fFglLJ\"@ak-]X\u0007ux0&\u001f\u0000jou\u0018S\r3{L";
      c[18] = "\u0016@=E/\u001a\u0011Ai\u0013P传栵档桏佶伍厾可厹厕+jGG\u0014)LmF\u0013B";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/友何友树树树树何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (d[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 51;
               case 1 -> 27;
               case 2 -> 0;
               case 3 -> 29;
               case 4 -> 33;
               case 5 -> 2;
               case 6 -> 12;
               case 7 -> 32;
               case 8 -> 9;
               case 9 -> 63;
               case 10 -> 39;
               case 11 -> 23;
               case 12 -> 48;
               case 13 -> 45;
               case 14 -> 42;
               case 15 -> 37;
               case 16 -> 38;
               case 17 -> 21;
               case 18 -> 52;
               case 19 -> 57;
               case 20 -> 10;
               case 21 -> 26;
               case 22 -> 28;
               case 23 -> 54;
               case 24 -> 50;
               case 25 -> 62;
               case 26 -> 44;
               case 27 -> 22;
               case 28 -> 19;
               case 29 -> 1;
               case 30 -> 24;
               case 31 -> 17;
               case 32 -> 60;
               case 33 -> 30;
               case 34 -> 8;
               case 35 -> 56;
               case 36 -> 47;
               case 37 -> 36;
               case 38 -> 40;
               case 39 -> 13;
               case 40 -> 15;
               case 41 -> 34;
               case 42 -> 3;
               case 43 -> 61;
               case 44 -> 35;
               case 45 -> 18;
               case 46 -> 20;
               case 47 -> 25;
               case 48 -> 41;
               case 49 -> 43;
               case 50 -> 55;
               case 51 -> 46;
               case 52 -> 7;
               case 53 -> 11;
               case 54 -> 53;
               case 55 -> 4;
               case 56 -> 14;
               case 57 -> 16;
               case 58 -> 6;
               case 59 -> 49;
               case 60 -> 5;
               case 61 -> 58;
               case 62 -> 59;
               default -> 31;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            d[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 255 && var8 != 'f' && var8 != 'C' && var8 != 192) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'E') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'e') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 255) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'f') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'C') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public void m(long a, boolean a) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 64857019260969L;
      a<"e">(7613718109959608384L, (long)a);
      this.H(a<"C">(7613886380363784100L, (long)a), ax);
      if (a > 0L) {
         this.H(a<"C">(7615567167688243732L, (long)a), ax);
      }
   }

   public boolean g(long a) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 110451305501038L;
      return a<"ÿ">(this, 1522140527480577289L, (long)a).P(a<"ÿ">(this, 1521900465932698476L, (long)a), ax);
   }

   public boolean v(long a) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 116220280388560L;
      return a<"ÿ">(this, 3232234741929743536L, (long)a).y(ax);
   }

   public static String[] q() {
      return 何树树何友友树友树树;
   }

   public void A(int a, long duration) {
      duration = (int)(友何友树树树树何树友.a ^ duration);
      a<"f">(this, 400, -1502273983105893036L, (long)duration);
   }

   public static float Y(long a, float speed, float a, float var4) {
      a = 友何友树树树树何树友.a ^ a;
      String[] ax = a<"e">(7713562021412133605L, (long)a);
      if (a == speed) {
         return (float)a;
      } else {
         boolean larger;
         float var13;
         label68: {
            label74: {
               larger = speed > a;
               if (var4 < 0.0F) {
                  var13 = 0.0F;
                  if (a <= 0L) {
                     break label74;
                  }

                  var4 = 0.0F;
               }

               var13 = var4;
               if (a <= 0L) {
                  break label68;
               }

               if (var4 > 1.0F) {
                  var4 = 1.0F;
               }

               var13 = Math.max(speed, (float)a);
            }

            var13 -= Math.min(speed, (float)a);
         }

         double dif = var13;
         double factor = dif * var4;
         double var19;
         int var14 = (var19 = factor - 0.1) == 0.0 ? 0 : (var19 < 0.0 ? -1 : 1);
         String[] var10001 = ax;
         if (a > 0L) {
            if (ax == null) {
               if (var14 < 0) {
                  factor = 0.1;
               }

               var14 = larger;
            }

            var10001 = ax;
         }

         if (var10001 == null) {
            if (var14 != 0) {
               var13 = (float)a;
               float var17 = (float)factor;
               if (a > 0L) {
                  a += var17;
                  var13 = (float)a;
                  var17 = speed;
               }

               if (!(var13 >= var17)) {
                  return (float)a;
               }

               a = (long)speed;
               if (a >= 0L) {
               }
            }

            float var20;
            var14 = (var20 = speed - a) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
         }

         if (var14 < 0) {
            var13 = (float)a;
            float var18 = (float)factor;
            if (a >= 0L) {
               a -= var18;
               var13 = (float)a;
               var18 = speed;
            }

            if (var13 <= var18) {
               a = (long)speed;
            }
         }

         return (float)a;
      }
   }

   public 友何友树树树友树何友 Y(long a) {
      a = 友何友树树树树何树友.a ^ a;
      return a<"ÿ">(this, -1608288166171782715L, (long)a);
   }

   public double X(long a) {
      a = 友何友树树树树何树友.a ^ a;
      return a<"ÿ">(this, 3562858835081269170L, (long)a);
   }

   public void X(long a) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 116550426906522L;
      long axx = a ^ 85771273258030L;
      this.H(a<"ÿ">(this, 440530445174128246L, (long)a).b(axx), ax);
   }

   public void M(long a) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 5319905325509L;
      a<"ÿ">(this, -4464565052931356132L, (long)a).S(ax);
   }

   public boolean W(long a) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 91918405103570L;
      return a<"ÿ">(this, -7699075434960016052L, (long)a).b(ax);
   }

   protected abstract double W(double var1, long var3);

   public 友何友树树树树何树友 H(友何友树树树友树何友 a, long direction) {
      direction = 友何友树树树树何树友.a ^ direction;
      long ax = direction ^ 120450805765292L;
      long axx = direction ^ 133192404859908L;
      a<"e">(-7027463886490554480L, (long)direction);
      if (a<"ÿ">(this, -7026048097968216555L, (long)direction) != a) {
         a<"f">(this, a, -7026048097968216555L, (long)direction);
         a<"ÿ">(this, -7025720871712975255L, (long)direction)
            .X(
               System.currentTimeMillis()
                  - (
                     a<"ÿ">(this, -7025902661826312180L, (long)direction)
                        - Math.min((long)a<"ÿ">(this, -7025902661826312180L, (long)direction), a<"ÿ">(this, -7025720871712975255L, (long)direction).n(axx))
                  ),
               ax
            );
      }

      return this;
   }

   public double T(long a) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 46846362865538L;
      long axx = a ^ 24140321347341L;
      long axxx = a ^ 138670347679632L;
      long axxxx = a ^ 109453638624561L;
      String[] axxxxx = a<"e">(-5372792139998231399L, (long)a);
      if (a<"ÿ">(this, -5370794700830241508L, (long)a).b(ax)) {
         友何友树树树树何树友 var16 = this;
         Object var18 = axxxxx;
         if (a > 0L) {
            if (axxxxx == null) {
               if (this.g(axxx)) {
                  return a<"ÿ">(this, -5370599292037887052L, (long)a);
               }

               var16 = this;
            }

            double var19 = (double)a<"ÿ">(this, -5370880378167018144L, (long)a).n(axx) / a<"ÿ">(this, -5370659004519144699L, (long)a);
            Object[] var21 = new Object[]{null, axxxx};
            var18 = var21;
            var21[0] = var19;
         }

         return var16.W((Object[])var18) * a<"ÿ">(this, -5370599292037887052L, (long)a);
      } else {
         int var10000 = this.g(axxx);
         String[] var10001 = axxxxx;
         if (a >= 0L) {
            if (axxxxx == null) {
               if (var10000 != 0) {
                  return 0.0;
               }

               var10000 = this.D(new Object[0]);
            }

            var10001 = axxxxx;
         }

         if (var10001 == null) {
            if (var10000 == 0) {
               double var10002 = (double)a<"ÿ">(this, -5370880378167018144L, (long)a).n(axx) / a<"ÿ">(this, -5370659004519144699L, (long)a);
               Object[] var10005 = new Object[]{null, axxxx};
               var10005[0] = var10002;
               return (1.0 - this.W(var10005)) * a<"ÿ">(this, -5370599292037887052L, (long)a);
            }

            var10000 = a<"ÿ">(this, -5370659004519144699L, (long)a);
         }

         double revTime = Math.min(
            (long)var10000, Math.max(0L, a<"ÿ">(this, -5370659004519144699L, (long)a) - a<"ÿ">(this, -5370880378167018144L, (long)a).n(axx))
         );
         double var17 = revTime / a<"ÿ">(this, -5370659004519144699L, (long)a);
         Object[] var10004 = new Object[]{null, axxxx};
         var10004[0] = var17;
         return this.W(var10004) * a<"ÿ">(this, -5370599292037887052L, (long)a);
      }
   }

   public double R(long a) {
      a = 友何友树树树树何树友.a ^ a;
      long ax = a ^ 137135259103585L;
      return 1.0
         - (double)a<"ÿ">(this, 5988280680643943180L, (long)a).n(ax)
            / a<"ÿ">(this, 5988660895570642281L, (long)a)
            * a<"ÿ">(this, 5988561737215831512L, (long)a);
   }

   public void O(double a, long var3) {
      var3 = 友何友树树树树何树友.a ^ var3;
      a<"f">(this, (double)a, -7763396657105982847L, var3);
   }

   private static String HE_WEI_LIN() {
      return "何树友被何大伟克制了";
   }
}
