package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 树友何何何友友树何友 implements 何树友 {
   private float 何树树树友何何友树何;
   private float 何友友树树何何友何树;
   private 友何友树树树树何树友 友何友树何树友树树树;
   private static boolean 友何友树友友树何树友;
   private static final long a;
   private static final Object[] b = new Object[21];
   private static final String[] c = new String[21];
   private static int _何大伟为什么要诈骗何炜霖 _;

   public 树友何何何友友树何友(long a) {
      a = 树友何何何友友树何友.a ^ a;
      long ax = a ^ 44443361951939L;
      super();
      a<"i">(this, new 友何友树何何友何友树(ax, 0, 0.0, a<"L">(-961793335819690777L, a)), -963709915338871834L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-5484022572302804735L, -6034481696548639212L, MethodHandles.lookup().lookupClass()).a(207215204667536L);
      // $VF: monitorexit
      a = var10000;
      long var0 = a ^ 129681170367803L;
      a();
      if (a<"Í">(1222631395765944048L, var0)) {
         a<"Í">(true, 1222569218920886274L, var0);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void h(boolean var0) {
      友何友树友友树何树友 = var0;
   }

   public boolean l(long a) {
      a = 树友何何何友友树何友.a ^ a;
      long ax = a ^ 87661794141401L;
      a<"Í">(7366088519244924508L, (long)a);
      return a<"í">(this, 7367535551749268409L, (long)a) == a<"í">(this, 7365956164534820226L, (long)a) || a<"í">(this, 7366049649224843135L, (long)a).g(ax);
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/树友何何何友友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 237 && var8 != 'i' && var8 != 'L' && var8 != 'E') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 186) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 205) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 237) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'i') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'L') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 21;
               case 1 -> 0;
               case 2 -> 46;
               case 3 -> 22;
               case 4 -> 26;
               case 5 -> 61;
               case 6 -> 14;
               case 7 -> 3;
               case 8 -> 33;
               case 9 -> 48;
               case 10 -> 27;
               case 11 -> 52;
               case 12 -> 55;
               case 13 -> 53;
               case 14 -> 25;
               case 15 -> 15;
               case 16 -> 17;
               case 17 -> 41;
               case 18 -> 8;
               case 19 -> 11;
               case 20 -> 19;
               case 21 -> 6;
               case 22 -> 32;
               case 23 -> 2;
               case 24 -> 31;
               case 25 -> 30;
               case 26 -> 35;
               case 27 -> 37;
               case 28 -> 4;
               case 29 -> 45;
               case 30 -> 59;
               case 31 -> 56;
               case 32 -> 7;
               case 33 -> 47;
               case 34 -> 51;
               case 35 -> 28;
               case 36 -> 20;
               case 37 -> 49;
               case 38 -> 29;
               case 39 -> 40;
               case 40 -> 12;
               case 41 -> 34;
               case 42 -> 36;
               case 43 -> 9;
               case 44 -> 63;
               case 45 -> 16;
               case 46 -> 44;
               case 47 -> 24;
               case 48 -> 50;
               case 49 -> 62;
               case 50 -> 5;
               case 51 -> 58;
               case 52 -> 39;
               case 53 -> 57;
               case 54 -> 42;
               case 55 -> 18;
               case 56 -> 13;
               case 57 -> 60;
               case 58 -> 10;
               case 59 -> 1;
               case 60 -> 54;
               case 61 -> 38;
               case 62 -> 43;
               default -> 23;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "8\u0007*(\u0014'7Gg#\u001e:2\u001ale\u000e<2\u0005we\u001a&2\u0004e?\u0012'5\u001a*桚厰伝伎似叏厀桪伝厐";
      b[1] = "\u0010f~!u-\u001bion\t4\u0014sa->\u0004\u0002dm0/(\u0015i";
      b[2] = float.class;
      c[2] = "java/lang/Float";
      b[3] = "b<UK*Im|\u0018@ Th!\u0013\u00060Rh>\b\u0006$Hh?\u001a\\,Io!U口伐叭栐桃桪根伐样及";
      b[4] = "\fje3_iyJn<N&\u0004R};Gol";
      b[5] = ")\u0012\u001f*v\u0016&RR!|\u000b#\u000fYgl\r#\u0010Bgx\u0017#\u0011P=p\u0016$\u000f\u001f厂佌厲桛桭栠厂栈伬厁";
      b[6] = "Ec*E\u001aw0C!J\u000b8M[2M\u0002q%";
      b[7] = void.class;
      c[7] = "java/lang/Void";
      b[8] = "E\u0003;\u0004h<JCv\u000fb!O\u001e}Ij<B\u0018y\u0002)\u001eI\t`\u000bb";
      b[9] = boolean.class;
      c[9] = "java/lang/Boolean";
      b[10] = "6r\u0007\n`\u000f=}\u0016E\u0001\u00016v\u0012\u001f";
      b[11] = "R\u0004b\n[\u0005PQ1dCnRQlTG\u0011RVn[*WR\u00040\tUWU\u0006?d";
      b[12] = "S\u0013$yU\u0002QFw\u0017DiT\u001d+o[\u0014R\u001d,s$TRO*y\u001c\u0011\u001b\u001a/\u0017";
      b[13] = "Ev\u0014\u0016\u000eJ\u000f6\u0013\u000b6佰桧栗伩桬叵叮伣反伩u\rU\u001emL\u0012G\u0015\u0019p";
      b[14] = "'\u000bCq\u001a?%^\u0010\u001f伶桍标桾叢佂伶厗标伺!&\u0014ol\bZqZ)d";
      b[15] = "\u000f}q\u0011K9\r(\"\u007fBR\bs~\u0007E/\u000esy\u001b:";
      b[16] = "&:AE\u001bI$o\u0012+伷叡叜桏栺佶伷叡佂桏#\u0012\u0015\u0019m9XE[_e";
      b[17] = "4#b.U_6v1@叧佩収桖佝桙叧栭栔桖\u0000z\u0014\u00043={-F\rf";
      b[18] = "F{(.nF\u0011)!{\u001cD|wr)bC\u001b2yqu=";
      b[19] = "n\\hS9%9\u000ea\u0006K2TP2T5 3\u00159\f\"^iTh\u0001%f,\u001d=\u0004K";
      b[20] = "k'$\\\u0011y1l;V/yU =IWk(&=NK\u0014";
   }

   public static boolean p() {
      return 友何友树友友树何树友;
   }

   public float y(long a) {
      a = 树友何何何友友树何友.a ^ a;
      long ax = a ^ 46533599472048L;
      a<"i">(this, (float)(a<"í">(this, -3802953929012481918L, (long)a) - a<"í">(this, -3802897673098014081L, (long)a).T(ax)), -3801410705351438663L, (long)a);
      return a<"í">(this, -3801410705351438663L, (long)a);
   }

   public 友何友树树树树何树友 y(long a) {
      a = 树友何何何友友树何友.a ^ a;
      return a<"í">(this, -9127623070502741998L, (long)a);
   }

   public void y(float a, long a, int ms) {
      a = 树友何何何友友树何友.a ^ a;
      long ax = a ^ 134166564350213L;
      long axx = a ^ 46698012244463L;
      a<"Í">(-3779406597481698327L, a);
      a<"i">(this, (float)(a<"í">(this, -3779538404634857417L, a) - a<"í">(this, -3779587836079549750L, a).T(ax)), -3779648947393720820L, a);
      a<"i">(this, (float)a, -3779538404634857417L, a);
      float var11;
      int var10000 = (var11 = a<"í">(this, -3779648947393720820L, a) - (a<"í">(this, -3779538404634857417L, a) - a)) == 0.0F ? 0 : (var11 < 0.0F ? -1 : 1);
      if (a > 0L) {
         if (var10000 != 0) {
            a<"i">(
               this,
               new 友何友树何何友何友树(axx, ms, a<"í">(this, -3779538404634857417L, a) - a<"í">(this, -3779648947393720820L, a), a<"L">(-3779922935561443893L, a)),
               -3779587836079549750L,
               a
            );
         }

         var10000 = a<"Í">(-3779280730069342632L, a);
      }

      if (a >= 0L) {
         if (var10000 != 0) {
            return;
         }

         var10000 = 1;
      }

      a<"Í">(new String[var10000], -3779478280346731383L, a);
   }

   public static boolean G() {
      p();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static String HE_SHU_YOU() {
      return "何树友被何大伟克制了";
   }
}
