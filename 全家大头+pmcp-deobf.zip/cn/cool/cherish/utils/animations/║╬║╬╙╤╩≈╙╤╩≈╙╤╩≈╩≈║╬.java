package cn.cool.cherish.utils.animations;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 何何友树友树友树树何 extends 友何友树树树树何树友 implements 何树友 {
   private final float 何树何树友何何何友友;
   private static int[] 树何树友何树树树友树;
   private static final long b;
   private static final Object[] e = new Object[15];
   private static final String[] f = new String[15];
   private static String HE_JIAN_GUO;

   public 何何友树友树友树树何(int ms, double endPoint, long a, float easeAmount) {
      long ax = b ^ a ^ 81933923376934L;
      super(ms, ax, 1.0);
      this.何树何树友何何何友友 = easeAmount;
   }

   public 何何友树友树友树树何(int ms, double endPoint, float easeAmount, long a, 友何友树树树友树何友 direction) {
      long ax = b ^ a ^ 41942462347603L;
      super(ms, endPoint, ax, direction);
      this.何树何树友何何何友友 = easeAmount;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2298297782188560230L, 2994755010325997L, MethodHandles.lookup().lookupClass()).a(133143730725644L);
      // $VF: monitorexit
      b = var10000;
      long var0 = b ^ 14027674446383L;
      b();
      if (b<"ë">(-866508763974911905L, var0) != null) {
         b<"ë">(new int[2], -866439847135734743L, var0);
      }
   }

   public static int[] B() {
      return 树何树友何树树树友树;
   }

   @Override
   protected boolean D(Object[] var1) {
      return true;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 16;
               case 1 -> 9;
               case 2 -> 56;
               case 3 -> 34;
               case 4 -> 11;
               case 5 -> 20;
               case 6 -> 36;
               case 7 -> 22;
               case 8 -> 2;
               case 9 -> 38;
               case 10 -> 41;
               case 11 -> 53;
               case 12 -> 18;
               case 13 -> 47;
               case 14 -> 50;
               case 15 -> 59;
               case 16 -> 23;
               case 17 -> 33;
               case 18 -> 57;
               case 19 -> 27;
               case 20 -> 62;
               case 21 -> 24;
               case 22 -> 12;
               case 23 -> 44;
               case 24 -> 6;
               case 25 -> 42;
               case 26 -> 5;
               case 27 -> 46;
               case 28 -> 21;
               case 29 -> 45;
               case 30 -> 63;
               case 31 -> 30;
               case 32 -> 58;
               case 33 -> 17;
               case 34 -> 26;
               case 35 -> 7;
               case 36 -> 8;
               case 37 -> 28;
               case 38 -> 49;
               case 39 -> 19;
               case 40 -> 32;
               case 41 -> 54;
               case 42 -> 35;
               case 43 -> 4;
               case 44 -> 14;
               case 45 -> 55;
               case 46 -> 52;
               case 47 -> 0;
               case 48 -> 1;
               case 49 -> 40;
               case 50 -> 3;
               case 51 -> 43;
               case 52 -> 48;
               case 53 -> 13;
               case 54 -> 39;
               case 55 -> 15;
               case 56 -> 10;
               case 57 -> 60;
               case 58 -> 31;
               case 59 -> 61;
               case 60 -> 51;
               case 61 -> 29;
               case 62 -> 37;
               default -> 25;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void b() {
      e[0] = "ASC\u00197IN\u0013\u000e\u0012=TKN\u0005T5IFH\u0001\u001fvkMY\u0018\u0016=";
      e[1] = boolean.class;
      f[1] = "java/lang/Boolean";
      e[2] = void.class;
      f[2] = "java/lang/Void";
      e[3] = "T7+$C2[wf/I/^*miY)^5viM3^4d3E2Y*+伒佹厖栦厒栔厌栽桌佢";
      e[4] = float.class;
      f[4] = "java/lang/Float";
      e[5] = "\u000f7";
      e[6] = "n4Y\u0010Mje;H_1sj!F\u001c\u0006C|6J\u0001\u0017ok;";
      e[7] = "\u001f,";
      e[8] = "X\u0015\u0006Qa\u000bS\u001a\u0017\u001e\u0000\u0005X\u0011\u0013D";
      e[9] = "1uevqE%\u007f\"\u0013D~e>gvwN%h2i\rG1nm\"d\u00021; \u0013";
      e[10] = "\u0005\u0005#\u001dq%V\t:XI\u0010?\u0005!\u001d-#NR3\nyL\u0006U*Ux%CU\u007f\u0018I";
      e[11] = "NSU\u0018T\u0010\u001d_L]l3tSW\u0018\b\u0016\u0005\u0004E\u000f\\y";
      e[12] = "qDwC.:\"Hn\u0006\u0016伎桒伤栌司佋伎伖厺取;,-/Cu[,2*I";
      e[13] = "\"vu\u0004\u0018\u00176|2a\t,v=w\u0004\u001e\u001c6k\"\u001bd";
      e[14] = "_e\\C\u0003n\fiE\u0006;nedE\u0005\u0007v\u0006aXIF\u0007Y#\u0000\u0007Jd\\>LF;";
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/animations/何何友树友树友树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 186 && var8 != 231 && var8 != 'Q' && var8 != 229) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'o') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 235) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 186) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 231) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'Q') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   protected double W(double a, long var3) {
      b<"ë">(5784733175188855777L, var3);
      float shrink = b<"º">(this, 5784419772586640547L, var3) + 1.0F;
      double var10000 = Math.max(0.0, 1.0 + shrink * Math.pow(a - 1.0, 3.0) + b<"º">(this, 5784419772586640547L, var3) * Math.pow(a - 1.0, 2.0));
      b<"ë">(!b<"ë">(5784331921378093423L, var3), 5784660620578635860L, var3);
      return var10000;
   }

   public static void T(int[] var0) {
      树何树友何树树树友树 = var0;
   }

   private static String HE_DA_WEI() {
      return "解放村多种2队1144号";
   }
}
