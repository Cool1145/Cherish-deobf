package cn.cool.cherish.utils;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 树树何友树友何树友何 implements 何树友 {
   public double 树树友树友树何树友何;
   public double 友树友树何树友树何树;
   public double 友何友树何树树树友何;
   private static final long a;
   private static final Object[] b = new Object[6];
   private static final String[] c = new String[6];
   private static String HE_WEI_LIN;

   public 树树何友树友何树友何(long a, double x, double y, double z) {
      a = 树树何友树友何树友何.a ^ a;
      super();
      a<"$">(this, x, 5601741248728817385L, a);
      a<"$">(this, y, 5601665389135730006L, a);
      a<"$">(this, z, 5601503780166776380L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6265337210741178993L, 1700080280317530660L, MethodHandles.lookup().lookupClass()).a(242439972107252L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   @Override
   public String toString() {
      long a = 树树何友树友何树友何.a ^ 84061784894281L;
      return "[" + a<"ø">(this, 8416224377226160024L, a) + ";" + a<"ø">(this, 8416122112177548327L, a) + ";" + a<"ø">(this, 8416528985197317965L, a) + "]";
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public 树树何友树友何树友何 x(树树何友树友何树友何 a, long dir) {
      long var10000 = 树树何友树友何树友何.a ^ dir;
      long ax = 树树何友树友何树友何.a ^ dir ^ 4390313129367L;
      long axx = 树树何友树友何树友何.a ^ dir ^ 105608409933146L;
      long axxx = var10000 ^ 45402706580104L;
      long axxxx = var10000 ^ 7865684447753L;
      return this.T(-a.U(axxxx), -a.O(axxx), ax, -a.m(axx));
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/树树何友树友何树友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 248 && var8 != '$' && var8 != 211 && var8 != 'P') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 228) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 248) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 211) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 29;
               case 1 -> 27;
               case 2 -> 4;
               case 3 -> 38;
               case 4 -> 56;
               case 5 -> 63;
               case 6 -> 43;
               case 7 -> 12;
               case 8 -> 15;
               case 9 -> 26;
               case 10 -> 58;
               case 11 -> 45;
               case 12 -> 25;
               case 13 -> 13;
               case 14 -> 18;
               case 15 -> 1;
               case 16 -> 44;
               case 17 -> 37;
               case 18 -> 28;
               case 19 -> 3;
               case 20 -> 0;
               case 21 -> 51;
               case 22 -> 14;
               case 23 -> 31;
               case 24 -> 47;
               case 25 -> 41;
               case 26 -> 42;
               case 27 -> 9;
               case 28 -> 2;
               case 29 -> 16;
               case 30 -> 36;
               case 31 -> 30;
               case 32 -> 24;
               case 33 -> 11;
               case 34 -> 20;
               case 35 -> 52;
               case 36 -> 22;
               case 37 -> 6;
               case 38 -> 35;
               case 39 -> 32;
               case 40 -> 23;
               case 41 -> 49;
               case 42 -> 21;
               case 43 -> 60;
               case 44 -> 55;
               case 45 -> 5;
               case 46 -> 8;
               case 47 -> 34;
               case 48 -> 10;
               case 49 -> 39;
               case 50 -> 57;
               case 51 -> 54;
               case 52 -> 50;
               case 53 -> 62;
               case 54 -> 48;
               case 55 -> 61;
               case 56 -> 53;
               case 57 -> 40;
               case 58 -> 59;
               case 59 -> 19;
               case 60 -> 33;
               case 61 -> 17;
               case 62 -> 46;
               default -> 7;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void a() {
      b[0] = "K\u0015xH84DU5C2)A\b>\u0005\"/A\u0017%\u0005框桊佽厰桇叠伂桊口伮";
      b[1] = double.class;
      c[1] = "java/lang/Double";
      b[2] = "3$!EYm8+0\n8c3 4P";
      b[3] = "\u0012]HS\u0000L@\u0011N\"去伬厽桹伩栻桡桨厽伽tS\u001c\u0018EQE]\u001d\r";
      b[4] = "'zAd\u0017#u6G\u0015桶标厈桞厾栌伲标厈会}d\u000bwpvLj\nb";
      b[5] = "\u001cH?>wuN\u00049O双桑厳桬佞桖双桑伭桬\u0003>k!KD20j4";
   }

   public double m(long a) {
      a = 树树何友树友何树友何.a ^ a;
      return a<"ø">(this, 5540434390845306723L, (long)a);
   }

   public double U(long a) {
      a = 树树何友树友何树友何.a ^ a;
      return a<"ø">(this, -310432347342509851L, (long)a);
   }

   public 树树何友树友何树友何 T(double a, double var3, long var5, double var7) {
      var5 = 树树何友树友何树友何.a ^ var5;
      long ax = var5 ^ 85036182212118L;
      return new 树树何友树友何树友何(
         ax, a<"ø">(this, -2580813594345746565L, var5) + a, a<"ø">(this, -2580731124260109116L, var5) + var3, a<"ø">(this, -2580861328377862226L, var5) + var7
      );
   }

   public double O(long a) {
      a = 树树何友树友何树友何.a ^ a;
      return a<"ø">(this, -4958379617547066405L, (long)a);
   }

   private static String LIU_YA_FENG() {
      return "解放村多种2队1144号";
   }
}
