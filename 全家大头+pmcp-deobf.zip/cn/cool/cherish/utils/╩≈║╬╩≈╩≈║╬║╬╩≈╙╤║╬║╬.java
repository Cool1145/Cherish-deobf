package cn.cool.cherish.utils;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.item.友何树树何树何何何友;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.AbstractCauldronBlock;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.BannerBlock;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.BarrierBlock;
import net.minecraft.world.level.block.BeaconBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.BellBlock;
import net.minecraft.world.level.block.BlastFurnaceBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BrewingStandBlock;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.CakeBlock;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.ComparatorBlock;
import net.minecraft.world.level.block.ComposterBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.DaylightDetectorBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.EndPortalBlock;
import net.minecraft.world.level.block.EndPortalFrameBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.FlowerPotBlock;
import net.minecraft.world.level.block.FungusBlock;
import net.minecraft.world.level.block.FurnaceBlock;
import net.minecraft.world.level.block.GrindstoneBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LecternBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.PressurePlateBlock;
import net.minecraft.world.level.block.RepeaterBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.SignBlock;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SmokerBlock;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.StonecutterBlock;
import net.minecraft.world.level.block.StructureVoidBlock;
import net.minecraft.world.level.block.TntBlock;
import net.minecraft.world.level.block.TorchBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.TripWireBlock;
import net.minecraft.world.level.block.TripWireHookBlock;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.WebBlock;
import net.minecraft.world.level.block.piston.MovingPistonBlock;
import net.minecraft.world.level.block.piston.PistonHeadBlock;
import net.minecraft.world.level.block.state.BlockState;

public final class 树何树树何何树友何何 implements IWrapper, 何树友 {
   public static final List<Block> 友何友友树何树何树树;
   private static boolean 何友何树树何何何树树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[71];
   private static final String[] g = new String[71];
   private static int _何炜霖国企变私企 _;

   private 树何树树何何树友何何(long a) {
      a = 101525109646522L ^ a;
      super();
      throw new UnsupportedOperationException(a<"t">(17242, 7062000072762530632L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7875374513419817511L, -4004868364874310454L, MethodHandles.lookup().lookupClass()).a(30634044042848L);
      // $VF: monitorexit
      a = var10000;
      a();
      q(false);
      Cipher var0;
      Cipher var9 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(47506074974840L << var1 * 8 >>> 56);
      }

      var9.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[3];
      int var5 = 0;
      char var3 = 16;
      int var2 = -1;

      while (true) {
         String var11 = b(
               var0.doFinal(
                  "³·u'b\u0018í_\u0001zÄ×\u0092\u0080\u008aHXü³\u0085\u0003\u0098P\u008bAY\u0081N\\\u0082í¼©ÉÖ\u0003\u007f\u001f\u001d?tôº\u001bµT¼óÂÓmÿaøm8\u008a.â;«\u0006Ë\u0091Ätä]V\u008a\u0006ÍU\u0089\u009d@±1m4\u0010\u0082¯\u009a\u000b±$3&¥`X:\u001e\u008dòÏ\u0083:Xv\u0097\u0010\u0018¸\u0010\u0090I½i~Â\u0013\u0090½\t\u0004ò+]»U"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var11;
         if ((var2 += var3) >= 122) {
            b = var7;
            c = new String[3];
            友何友友树何树何树树 = Arrays.asList(
               Blocks.AIR,
               Blocks.WATER,
               Blocks.LAVA,
               Blocks.ENCHANTING_TABLE,
               Blocks.GLASS_PANE,
               Blocks.GLASS_PANE,
               Blocks.IRON_BARS,
               Blocks.SNOW,
               Blocks.COAL_ORE,
               Blocks.DIAMOND_ORE,
               Blocks.EMERALD_ORE,
               Blocks.CHEST,
               Blocks.TRAPPED_CHEST,
               Blocks.TORCH,
               Blocks.ANVIL,
               Blocks.TRAPPED_CHEST,
               Blocks.NOTE_BLOCK,
               Blocks.JUKEBOX,
               Blocks.TNT,
               Blocks.GOLD_ORE,
               Blocks.IRON_ORE,
               Blocks.LAPIS_ORE,
               Blocks.STONE_PRESSURE_PLATE,
               Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE,
               Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE,
               Blocks.STONE_BUTTON,
               Blocks.LEVER,
               Blocks.TALL_GRASS,
               Blocks.TRIPWIRE,
               Blocks.TRIPWIRE_HOOK,
               Blocks.RAIL,
               Blocks.CORNFLOWER,
               Blocks.RED_MUSHROOM,
               Blocks.BROWN_MUSHROOM,
               Blocks.VINE,
               Blocks.SUNFLOWER,
               Blocks.LADDER,
               Blocks.FURNACE,
               Blocks.SAND,
               Blocks.CACTUS,
               Blocks.DISPENSER,
               Blocks.DROPPER,
               Blocks.CRAFTING_TABLE,
               Blocks.COBWEB,
               Blocks.PUMPKIN,
               Blocks.COBBLESTONE_WALL,
               Blocks.OAK_FENCE,
               Blocks.REDSTONE_TORCH,
               Blocks.FLOWER_POT
            );
            return;
         }

         var3 = "³·u'b\u0018í_\u0001zÄ×\u0092\u0080\u008aHXü³\u0085\u0003\u0098P\u008bAY\u0081N\\\u0082í¼©ÉÖ\u0003\u007f\u001f\u001d?tôº\u001bµT¼óÂÓmÿaøm8\u008a.â;«\u0006Ë\u0091Ätä]V\u008a\u0006ÍU\u0089\u009d@±1m4\u0010\u0082¯\u009a\u000b±$3&¥`X:\u001e\u008dòÏ\u0083:Xv\u0097\u0010\u0018¸\u0010\u0090I½i~Â\u0013\u0090½\t\u0004ò+]»U"
            .charAt(var2);
      }
   }

   public static boolean B(BlockPos a, long blockPos) {
      blockPos = 101525109646522L ^ blockPos;
      long ax = blockPos ^ 111922292147060L;
      b<"Ó">(1188966671762351703L, (long)blockPos);
      return mc.level != null && mc.player != null ? O(ax, mc.level.getBlockState(a).getBlock()) : false;
   }

   public static Map D(Map a) {
      return a.entrySet()
         .stream()
         .sorted(
            (e1, e2) -> {
               double dist1 = mc.player
                  .distanceToSqr(((BlockPos)e1.getKey()).getX() + 0.5, ((BlockPos)e1.getKey()).getY() + 0.5, ((BlockPos)e1.getKey()).getZ() + 0.5);
               double dist2 = mc.player
                  .distanceToSqr(((BlockPos)e2.getKey()).getX() + 0.5, ((BlockPos)e2.getKey()).getY() + 0.5, ((BlockPos)e2.getKey()).getZ() + 0.5);
               return Double.compare(dist1, dist2);
            }
         )
         .collect(Collectors.toMap(Entry::getKey, Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
   }

   public static boolean F(BlockPos a, long a) {
      u();
      if (mc.level != null && mc.player != null) {
         Block block = mc.level.getBlockState(a).getBlock();
         return block instanceof AirBlock;
      } else {
         return false;
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 61;
               case 1 -> 60;
               case 2 -> 52;
               case 3 -> 26;
               case 4 -> 20;
               case 5 -> 27;
               case 6 -> 55;
               case 7 -> 28;
               case 8 -> 15;
               case 9 -> 9;
               case 10 -> 6;
               case 11 -> 3;
               case 12 -> 57;
               case 13 -> 41;
               case 14 -> 16;
               case 15 -> 42;
               case 16 -> 53;
               case 17 -> 63;
               case 18 -> 4;
               case 19 -> 21;
               case 20 -> 38;
               case 21 -> 59;
               case 22 -> 5;
               case 23 -> 10;
               case 24 -> 43;
               case 25 -> 33;
               case 26 -> 35;
               case 27 -> 50;
               case 28 -> 7;
               case 29 -> 56;
               case 30 -> 12;
               case 31 -> 8;
               case 32 -> 14;
               case 33 -> 45;
               case 34 -> 48;
               case 35 -> 44;
               case 36 -> 32;
               case 37 -> 36;
               case 38 -> 19;
               case 39 -> 40;
               case 40 -> 13;
               case 41 -> 37;
               case 42 -> 23;
               case 43 -> 0;
               case 44 -> 47;
               case 45 -> 25;
               case 46 -> 24;
               case 47 -> 49;
               case 48 -> 1;
               case 49 -> 18;
               case 50 -> 62;
               case 51 -> 58;
               case 52 -> 22;
               case 53 -> 39;
               case 54 -> 54;
               case 55 -> 34;
               case 56 -> 11;
               case 57 -> 29;
               case 58 -> 2;
               case 59 -> 31;
               case 60 -> 51;
               case 61 -> 17;
               case 62 -> 46;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static BlockPos i(double a, double var2, double var4) {
      return new BlockPos((int)Math.floor((double)a), (int)Math.floor(var2), (int)Math.floor(var4));
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 207 && var8 != 'X' && var8 != 'j' && var8 != 210) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'm') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 211) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 207) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'X') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'j') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/树何树树何何树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static boolean s() {
      u();

      try {
         return true;
      } catch (UnsupportedOperationException var0) {
         throw a(var0);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   public static Map h(long a, int a) {
      boolean var10000 = s();
      HashMap blocks = new HashMap();
      int ax = var10000;
      LocalPlayer thePlayer = mc.player;
      if (thePlayer == null) {
         return blocks;
      } else {
         int playerPosX = (int)thePlayer.position().x;
         int playerPosY = (int)thePlayer.position().y;
         int playerPosZ = (int)thePlayer.position().z;
         int x = -2;

         while (x <= a) {
            int y = (int)(-a);

            while (true) {
               if (y <= a) {
                  int z = (int)(-a);

                  label38: {
                     while (z <= a) {
                        BlockPos blockPos = new BlockPos(playerPosX + x, playerPosY + y, playerPosZ + z);
                        Block block = Y(blockPos, 74305057003608L);
                        if (!ax) {
                           break label38;
                        }

                        if (ax) {
                           blocks.put(blockPos, block);
                           z++;
                        }

                        if (!ax) {
                           break;
                        }
                     }

                     y++;
                  }

                  if (ax) {
                     continue;
                  }
               }

               x++;
               if (!ax) {
                  return D(blocks);
               }
               break;
            }
         }

         return D(blocks);
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "Df|2S~K&19YcN{:\u007fIeNd!\u007f栭佄栶栙伇伄栭叚佲佝";
      f[1] = "\u00119\u0015\u0000XE\u000f1\u000fO:Y\b,";
      f[2] = "#_rO![(Pc\u0000ZY:Kt^`E=[`a\u007fR;_pG`Y\fFgK\u007fC Qj";
      f[3] = boolean.class;
      g[3] = "java/lang/Boolean";
      f[4] = "J`R\\Y J`E\u0000U/P+Q\u001dF%@+J\u0017B,H+D\u001e[*O+d\u001e[*Ov";
      f[5] = "\u0017S [,>\u0017S7\u0007 1\r\u0018#\u001a3;\u001d\u00188\u001072\u0015\u00186\u0019.4\u0012\u0018\u0016\u0019.4\u0012";
      f[6] = void.class;
      g[6] = "java/lang/Void";
      f[7] = "J_uM\u001bOJ_b\u0011\u0017@P\u0014v\f\u0004J@\u0014q\u000b\u000fU\nld\u0000E";
      f[8] = double.class;
      g[8] = "java/lang/Double";
      f[9] = "rK\u000fI&4}\u000bBB,)xVI\u0004$4uPMOg\u0016~ATF,";
      f[10] = "\tstG&B=P{\u0007kI7M~Z`\u000f?Ps\\dD|rxM}M7\u0004";
      f[11] = "\u001b0\u0013o<\u001a\u001b0\u000430\u0015\u0001{\u0010.#\u001f\u0011{\u000b$'\u0016\u0019{\u0005->\u0010\u001e{4/>\u000494\u001e$#1\u0019:\u0004*";
      f[12] = "\u000b54<>?\u000b5#`20\u0011~7}!:\u0001~,w%3\t~\"~<5\u000e~3f2\"\u0000~0`<&\u0000\"4{6%K\u0019.f61\u0000\"\u0010`<&\u0000\"4k";
      f[13] = "[]<(\u0018UPR-gy[[Y)=";
      f[14] = "Z\u001a <WS\f\u001eq\"=]6\u001d(|\u0006\n6 ,y\u0001X\u001dIa>BM";
      f[15] = "Qk\u000fj\u0019y\u0007o^tsw=m\u000e\"B!=Q\u0003/Or\u00168Nh\fg";
      f[16] = "T\u0005Q@y}\u0002\u0001\u0000^\u0013s8\u0002Y\u0003-#8?]\u0005/v\u0013V\u0010Blc";
      f[17] = "z\u00013/\u0007\",\u0005b1m,\u0016\u0006;n\\{\u0016;?jQ)=Rr-\u0012<";
      f[18] = "Q0_Px4\u00074\u000eN\u0012:=7W\u0013-j=\nS\u0015.?\u0016c\u001eRm*";
      f[19] = "!wPr[*ws\u0001l1$MqQ:\u0000pMM\\7\r!f$\u0011pN4";
      f[20] = "s=4&f]%9e8\fS\u001f:<e2\u0002\u001f\u00078c0V4nu$sC";
      f[21] = ".I\u0004\fo\u0018xMU\u0012\u0005\u0016BO\u0005D4EBs\bI9\u0013i\u001aE\u000ez\u0006";
      f[22] = "vh\r0H` l\\.\"n\u001ao\u0005q\u00121\u001aR\u0001u\u001ek1;L2]~";
      f[23] = "*L\r\u0010\u001aw|H\\\u000epyFK\u0005RM*Fv\u0001UL|m\u001fL\u0012\u000fi";
      f[24] = "\u001d\u0013\u0018\u0006a\u007fK\u0017I\u0018\u000bqq\u0014\u0010G:#q)\u0014C7tZ@Y\u0004ta";
      f[25] = "pRpS>Zf\u00179(叄伶叟厭栐併栞伶栅桷\t\u0011<\u0001f\u0014gVi\u000e-";
      f[26] = "K,V~&L\u0019r\u00059H{uu[\u007fpJN$\u000f'3)";
      f[27] = "\u0014;(\u0001igF1+\u0005Xx|vr\u0005h/|K|U!hI2>Ges";
      f[28] = "J }fI\u0004\u001c$,x#\n&'u$\u0019Z&\u001aq#\u001f\u000f\rs<d\\\u001a";
      f[29] = "hqFjcW>u\u0017t\tY\u0004vN+4\u0006\u0004KJ/5\\/\"\u0007hvI";
      f[30] = "?R\u000b\u0005KsiVZ\u001b!}ST\nM\u0010*Sh\u0007@\u001dxx\u0001J\u0007^m";
      f[31] = ",O!9$\u0015zKp'N\u001b@H)zqI@u-|r\u001ek\u001c`;1\u000b";
      f[32] = "P\u0004; w\f\u0006\u0000j>\u001d\u0002<\u00033` Q<>7e!\u0007\u0017Wz\"b\u0012";
      f[33] = "u\r+\u001a(\u001d#\tz\u0004B\u0013\u0019\n#[yF\u00197'_~\u00162^j\u0018=\u0003";
      f[34] = "0\u001fxC\u00129f\u001b)]x7\\\u0018p\u0003Eg\\%t\u0006D2wL9A\u0007'";
      f[35] = "\u000fGXG^<YC\tY42c@P\u0006\rbc}T\u0002\b7H\u0014\u0019EK\"";
      f[36] = "\u0006\u0006_p9(P\u0002\u000enS&j\u0001W0bqj<S5o#AU\u001er,6";
      f[37] = "\u001br\u00071\u0003\u001a\r7NJA+M,\u0012vCO\u00100@s:";
      f[38] = "\u0015<'\u0019q8C8v\u0007\u001b6y;/Y by\u0006+\\'3Rof\u001bd&";
      f[39] = "\u0015S}i\u0016\u001aCW,w|\u0014yTu*BFyiq,@\u0011R\u0000<k\u0003\u0004";
      f[40] = "*Z$VXq|^uH2\u007fF],\u0015\n(F`(\u0013\u000ezm\teTMo";
      f[41] = "\\Hk\bf>\nL:\u0016\f00OcJ1o0rgM05\u001b\u001b*\ns ";
      f[42] = "6\u0000\u001dDHr`\u0004LZ\"|Z\u0007\u0015\u0004\u0018/Z:\u0011\u0001\u001eyqS\\F]l";
      f[43] = "`k,\u000f\u001736o}\u0011}=\fl$NBh\fQ JA8'8m\r\u0002-";
      f[44] = "<.u&dUj*$8\u000e[P(tn?\u000bP\u0014yc2^{}4$qK";
      f[45] = ",DG_xpz@\u0016A\u0012~@CO\u001f-,@~K\u001a.{k\u0017\u0006]mn";
      f[46] = ")?De+\b\u007f;\u0015{A\u0006E8L'{RE\u0005H }\u0003nl\u0005g>\u0016";
      f[47] = "Vv?U\u0002/\u0000rnKh!:q7\u0014Vv:L3\u0010T$\u0011%~W\u00171";
      f[48] = "@yD\u0018M\f\u0016}\u0015\u0006'\u0002,~LY\u0017U,CH]\u001b\u0007\u0007*\u0005\u001aX\u0012";
      f[49] = "1-fn_\u0016g)7p5\u0018]*n/\u000bK]\u0017j+\t\u001dv~'lJ\b";
      f[50] = "|iW\\wI*m\u0006B\u001dG\u0010n_\u001c-\u0014\u0010S[\u0019!B;:\u0016^bW";
      f[51] = "Ek\u001a5duS.SN$D\u00135\u000fr$ N)]w]xJ/\bu9x\u00125\u000fN";
      f[52] = "g<=;K\u0002qyt@\u001b32m5+\u0011Zhf\"8r\nfq/#\u001bPmf<@";
      f[53] = "^mc|\u0014c^=fq*w438?\u001a!4\u0003?f\u0016)\f}z\u007f[d";
      f[54] = "\u0017\u00137!5\fA\u0017f?_\u0002{\u0014?``S{);dc\u0007P@v# \u0012";
      f[55] = "$dA{S\u0011r`\u0010e9\u001fHcI;\tJH^M>\u0005\u001ac7\u0000yF\u000f";
      f[56] = "Fwb\u000e\u0003z\u0010s3\u0010it*qcFX%*MnKUq\u0001$#\f\u0016d";
      f[57] = "P'j\u0019\u0000(Pwo\u0014><:y1Z\u0001c:I6\u0003\u0002b\u00027s\u001aO/";
      f[58] = "+BX\u007f3y}F\taYwGEP?c%GxT:erl\u0011\u0019}&g";
      f[59] = "CR\u001c\\^zC\u0002\u0019Q`n)\fG\u001fP9)<@F\\0\u0011B\u0005_\u0011}";
      f[60] = "\u0006vbg\u0014\u0015Pr3y~\u001bjqj'@HjLn\"B\u001eA%#e\u0001\u000b";
      f[61] = "Mf'-I\u0002\u001bbv3#\f!a/m\u0019R!\\+h\u001f\t\n5f/\\\u001c";
      f[62] = "Z\u0010\u0016\u0005@\b\f\u0014G\u001b*\u00066\u0017\u001eE\u0010Q6*\u001a@\u0016\u0003\u001dCW\u0007U\u0016";
      f[63] = "\u0011K~`JvGO/~ x}Lv!\u0010)}qr%\u001c}V\u0018?b_h";
      f[64] = "V(bw\fg\u0000,3ifi:/j7]<:\u0012n2Zl\u0011{#u\u0019y";
      f[65] = "Tw:X\u0016\u0003\u0002skF|\r8p2\u001bL]8M6\u001d@\b\u0013${Z\u0003\u001d";
      f[66] = "U=RYj(\u00039\u0003G\u0000&9:Z\u001b:w9\u0007^\u001c<#\u0012n\u0013[\u007f6";
      f[67] = "\\\\CK\u001bo\nX\u0012Uqa0[K\u000bO30fO\u000eMd\u001b\u000f\u0002I\u000eq";
      f[68] = "%\u000fp}DXs\u000b!c.VI\bx<\u0011\u0002I5|8\u0012Sb\\1\u007fQF";
      f[69] = "W{0o\u000b\u0001A>y\u0014O0\u0001%%(KT\\9w-2";
      f[70] = "\\vyyIf\nr(g#h0qq;\u0019;0Lu<\u001fm\u001b%8{\\x";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/树何树树何何树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27248;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/树何树树何何树友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void q(boolean var0) {
      何友何树树何何何树树 = var0;
   }

   public static boolean u() {
      return 何友何树树何何何树树;
   }

   public static Block Y(BlockPos a, long a) {
      s();
      return mc.level != null && mc.player != null ? mc.level.getBlockState(a).getBlock() : null;
   }

   public static boolean H(long a, ItemStack a) {
      int ax = b<"Ó">(5088903141738964942L, 26029692372622L);
      if (a == null || !(a.getItem() instanceof BlockItem) || a.getCount() <= 1) {
         return false;
      } else if (!友何树树何树何何何友.e(11871436426037L, a)) {
         return false;
      } else {
         String string = a.getDisplayName().getString();
         if (string.contains("Click") || string.contains("点击")) {
            return false;
         } else if (a.getItem() instanceof ItemNameBlockItem) {
            return false;
         } else {
            Block block = ((BlockItem)a.getItem()).getBlock();
            boolean var10000 = block instanceof FlowerBlock;
            if (!ax) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof BushBlock;
            }

            if (!ax) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof FungusBlock;
            }

            if (!ax) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof CropBlock;
            }

            if (!ax) {
               if (var10000) {
                  return false;
               }

               var10000 = block instanceof SlabBlock;
            }

            if (!ax) {
               if (var10000) {
                  return false;
               }

               var10000 = b<"j">(5082442289465498496L, 26029692372622L).contains(block);
            }

            if (!ax) {
               var10000 = !var10000;
            }

            return var10000;
         }
      }
   }

   public static boolean R(long a, Block var2) {
      boolean ax;
      int var6;
      label438: {
         boolean var10000 = s();
         BlockState blockState = var2.defaultBlockState();
         ax = var10000;
         if (var2 instanceof SnowLayerBlock) {
            if (!blockState.hasProperty(SnowLayerBlock.LAYERS)) {
               return false;
            }

            var6 = (Integer)blockState.getValue(SnowLayerBlock.LAYERS);
            if (!ax) {
               break label438;
            }

            if (var6 < 8) {
               return false;
            }
         }

         var6 = var2 instanceof LiquidBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof AirBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof LadderBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof WebBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof TntBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof BushBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof FlowerPotBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof SlabBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof StairBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof FenceBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof WallBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof CarpetBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof IronBarsBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof SignBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof PressurePlateBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof ButtonBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof LeverBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof TorchBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof LanternBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof DoorBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof TrapDoorBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof BannerBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof SkullBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof BedBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof CakeBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof BrewingStandBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof HopperBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof DispenserBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof DaylightDetectorBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof BeaconBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof ShulkerBoxBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof BarrelBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof SmokerBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof BlastFurnaceBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof RepeaterBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof ComparatorBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof TripWireBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof TripWireHookBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof EndPortalFrameBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof EndPortalBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof AbstractCauldronBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof BellBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof ComposterBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof LecternBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof GrindstoneBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof StonecutterBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof CampfireBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof StructureVoidBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof BarrierBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof LightBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof PistonHeadBlock;
      }

      if (ax) {
         if (var6 != 0) {
            return (boolean)0;
         }

         var6 = var2 instanceof MovingPistonBlock;
      }

      if (!ax) {
         return (boolean)var6;
      } else {
         return (boolean)(var6 == 0 ? 1 : 0);
      }
   }

   private static String HE_DA_WEI() {
      return "何大伟为什么要诈骗何炜霖";
   }

   public static BlockPos G(BlockPos a, double x, double y, long a, double z) {
      a = 101525109646522L ^ a;
      b<"Ó">(1466905605556024586L, a);
      BlockPos var10000 = new BlockPos((int)Math.floor(a.getX() + x), (int)Math.floor(a.getY() + y), (int)Math.floor(a.getZ() + z));
      if (b<"Ó">(1462696063938112539L, a) == null) {
         b<"Ó">(false, 1461112566090121092L, a);
      }

      return var10000;
   }

   public static boolean O(long a, Block var2) {
      a = 101525109646522L ^ a;
      boolean var4 = b<"Ó">(-626502276868767335L, (long)a);
      if (mc.level != null && mc.player != null) {
         boolean var10000 = var2 instanceof LiquidBlock;
         boolean var10001 = var4;
         if (a > 0L) {
            if (var4) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof AirBlock;
            }

            var10001 = var4;
         }

         if (a > 0L) {
            if (var10001) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof ChestBlock;
            }

            var10001 = var4;
         }

         if (a > 0L) {
            if (var10001) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof FurnaceBlock;
            }

            var10001 = var4;
         }

         if (a > 0L) {
            if (var10001) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof LadderBlock;
            }

            var10001 = var4;
         }

         if (a > 0L) {
            if (var10001) {
               if (var10000) {
                  return false;
               }

               var10000 = var2 instanceof TntBlock;
            }

            var10001 = var4;
         }

         return !var10001 ? var10000 : !var10000;
      } else {
         return false;
      }
   }
}
