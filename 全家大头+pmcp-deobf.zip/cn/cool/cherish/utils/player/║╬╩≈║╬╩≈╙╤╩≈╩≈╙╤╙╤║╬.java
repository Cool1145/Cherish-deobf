package cn.cool.cherish.utils.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.友树友树友树何友树何;
import cn.cool.cherish.module.impl.misc.何树何树何何友友友何;
import cn.cool.cherish.module.impl.misc.何树友树何何何树何何;
import cn.cool.cherish.module.impl.misc.树何树何何友友友友何;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Squid;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.entity.monster.Shulker;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;

public final class 何树何树友树树友友何 implements IWrapper, 何树友 {
   private static String 友何何树何何何何何树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[25];
   private static final String[] g = new String[25];
   private static String HE_WEI_LIN;

   private 何树何树友树树友友何(long a) {
      a = 112940413771193L ^ a;
      super();
      throw new UnsupportedOperationException(a<"x">(31690, 511095113254608765L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(1611802947599062135L, 6226732317968303908L, MethodHandles.lookup().lookupClass()).a(3806708744180L);
      // $VF: monitorexit
      a = var10000;
      a();
      C(null);
      Cipher var0;
      Cipher var9 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(131235385997992L << var1 * 8 >>> 56);
      }

      var9.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[3];
      int var5 = 0;
      char var3 = 24;
      int var2 = -1;

      while (true) {
         String var11 = b(
               var0.doFinal(
                  "\u001eÝò\u0083\u0080®\r\u0016 íøµç\u0083ÝgÏt¸Rq©Êj 9Õ\u008dVe\fZHÕþ\u008fDäð\u0090hb1L\u00020Ce¦\u009bb6ìÅ~\u000e\u0084Xï$·êð\\\b×ÀÚï¡]\u0006ÜQ'#Æo\u007f¯OÌ:P[³dçÕ%\t¹\u0088íõ¥\u009eacKm\u0017j°¹\ni\u000bZKDK{PFo&K°\u008f½D\u0091ÈæNµ¦\u0000Æü;\u0093\u0013\u00924ár\u008d¤ô_ý¶Ä¶"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var11;
         if ((var2 += var3) >= 146) {
            b = var7;
            c = new String[3];
            return;
         }

         var3 = "\u001eÝò\u0083\u0080®\r\u0016 íøµç\u0083ÝgÏt¸Rq©Êj 9Õ\u008dVe\fZHÕþ\u008fDäð\u0090hb1L\u00020Ce¦\u009bb6ìÅ~\u000e\u0084Xï$·êð\\\b×ÀÚï¡]\u0006ÜQ'#Æo\u007f¯OÌ:P[³dçÕ%\t¹\u0088íõ¥\u009eacKm\u0017j°¹\ni\u000bZKDK{PFo&K°\u008f½D\u0091ÈæNµ¦\u0000Æü;\u0093\u0013\u00924ár\u008d¤ô_ý¶Ä¶"
            .charAt(var2);
      }
   }

   public static void C(String var0) {
      友何何树何何何何何树 = var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 6;
               case 1 -> 4;
               case 2 -> 41;
               case 3 -> 5;
               case 4 -> 57;
               case 5 -> 47;
               case 6 -> 44;
               case 7 -> 3;
               case 8 -> 51;
               case 9 -> 24;
               case 10 -> 8;
               case 11 -> 29;
               case 12 -> 13;
               case 13 -> 31;
               case 14 -> 30;
               case 15 -> 19;
               case 16 -> 16;
               case 17 -> 48;
               case 18 -> 17;
               case 19 -> 38;
               case 20 -> 53;
               case 21 -> 1;
               case 22 -> 14;
               case 23 -> 28;
               case 24 -> 54;
               case 25 -> 56;
               case 26 -> 23;
               case 27 -> 62;
               case 28 -> 46;
               case 29 -> 42;
               case 30 -> 9;
               case 31 -> 49;
               case 32 -> 37;
               case 33 -> 45;
               case 34 -> 26;
               case 35 -> 12;
               case 36 -> 27;
               case 37 -> 35;
               case 38 -> 0;
               case 39 -> 32;
               case 40 -> 22;
               case 41 -> 34;
               case 42 -> 58;
               case 43 -> 2;
               case 44 -> 55;
               case 45 -> 39;
               case 46 -> 59;
               case 47 -> 43;
               case 48 -> 25;
               case 49 -> 40;
               case 50 -> 52;
               case 51 -> 11;
               case 52 -> 63;
               case 53 -> 15;
               case 54 -> 20;
               case 55 -> 36;
               case 56 -> 61;
               case 57 -> 33;
               case 58 -> 21;
               case 59 -> 7;
               case 60 -> 18;
               case 61 -> 50;
               case 62 -> 60;
               default -> 10;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static boolean i(Entity a, long a) {
      a = 112940413771193L ^ a;
      long ax = a ^ 95676587025085L;
      b<"à">(8924082312956075519L, a);
      return a instanceof Player && a.getName().getString() != null && Cherish.instance.P().M(何树友友树树友何树何.N(a.getName().getString(), ax));
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 244 && var8 != 'J' && var8 != 'V' && var8 != 200) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 236) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 224) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 244) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'J') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'V') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/何树何树友树树友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static String f(long var0) {
      b<"à">(-8062693630277372356L, 76832391008286L);
      return mc.isSingleplayer()
         ? "SinglePlayer"
         : (mc.getCurrentServer() == null ? "Unknown IP" : b<"ô">(mc.getCurrentServer(), -8062947872163066503L, 76832391008286L));
   }

   public static boolean f(long a, Entity a) {
      a = 112940413771193L ^ a;
      b<"à">(5225636607777233610L, (long)a);
      return a instanceof Mob || a instanceof Villager || a instanceof Slime || a instanceof Ghast || a instanceof EnderDragon || a instanceof Shulker;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/何树何树友树树友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16448;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/player/何树何树友树树友友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void a() {
      f[0] = "\u001fE\n\u0016\u0018\u0016\u0010\u0005G\u001d\u0012\u000b\u0015XL[\u0002\r\u0015GW[\u0007\u0015\u001dRA\u0007Y伬桭佾栵厾桦桨厷叠佱";
      f[1] = "{\u001cntO=p\u0013\u007f;2%c\u0014vr";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = "\u0017D\t3\u001d)\u001cK\u0018|f+\u000eP\u000f\"\\7\t@\u001b\u001dC \u000fD\u000b;\\+8]\u001c7C1\u0014J\u0011";
      f[4] = "U\u0004%?X\u0019ZDh4R\u0004_\u0019crB\u0002_\u0006xrG\u001aW\u0013n.\u0019$Y\u001ej(^\u0019X?\u007f5[\u0005";
      f[5] = boolean.class;
      g[5] = "java/lang/Boolean";
      f[6] = "d dn\rWk`)e\u0007Jn=\"#\u000fWc;&hLQj>&#\u0006Qt>&l\u001b\u0016双桟厁栜厩栩佒厅桛佘";
      f[7] = "\u0000\u0002G[!)\u000fB\nP+4\n\u001f\u0001\u00168'\u000f\u0019\f\u0016'+\u0013\u0000Gz!)\u000f\t\bV\u0018'\u000f\u0019\f";
      f[8] = ",M44\u001c\u0014#\ry?\u0016\t&Pry\u001e\u0014+Vv2]\u0012\"Svy\u001e\u0012<@4伂桢厰桞佶住伂桢伮会";
      f[9] = "m\b\t\u0016?\u0001bHD\u001d5\u001cg\u0015O[=\u0001j\u0013K\u0010~\u0007c\u0016K[=\u0007}\u0005\t桤伅桿佛伳召厾厛厥佛";
      f[10] = "rUBb\u0011arUU>\u001dnh\u001eU \u0015mrD\u0018!\tdhYF \u001dqyB\u0018\u001f\u0019zjUD\b\u001d|}";
      f[11] = "x\u00107L}/s\u001f&\u0003\u001c!x\u0014\"Y";
      f[12] = "=Tq4\u00177n\u000f\u0017\u001es\u007f9UkjM-z\rtUJ<uUi>\u00119`\t\u0017";
      f[13] = "\u0005 cB\u0001iI;~N`栜佤优栊佲厣佘栠历叐/]=\\9(\u0014Zg\t|";
      f[14] = "H\u0006'fu\u0002\u0004\u001d:j\u0014桷桭厠桎又佉厭厷厠厔\u000b)V\u0011\u001fl0.\fDZ";
      f[15] = "X\t\u0014%QW\u0014\r\u0000',栾桼伯伷伇佱古厦厱伷Z\u0011\\\u001b\r\u0017*]X\u000f\u000f";
      f[16] = "~_\u001etks2D\u0003x\n栆桛佧伳叚叉佂桛叹厭\u00197''FU\"0}r\u0003";
      f[17] = "\twr\u0002L\u001cSt#\rvj2#+W\b\u0013K$%\u0000I-";
      f[18] = "!Z[n`\u0010mAFb\u0001县佀佢叨佞参县佀叼叨\u0003<DxC\u00108;\u001e-\u0006";
      f[19] = "=%!b\tXj7nbuLTnfbN\u001c8\u0000^fH\u001a\u007fh`4\u000bB`";
      f[20] = "/Sa*A%|\b\u0007\"%n)\u000ev'Dkw\nlK\u001fkr\u001bk*\u001a5v\u0001\u0007";
      f[21] = "C3)4\u001b\\\u000f(48z栩厼厕厚伄伧右厼伋桀YG\b\u001a*bb@ROo";
      f[22] = "/+\u0006-e^o(\u001e=\u0004佡栈伜厷伂栝佡栈桘伩_:Vc3\u0015=zU{#";
      f[23] = "\u0000rH\b*WZq\u0019\u0007\u0010\u001f;&\u0011]nXB!\u001f\n/f";
      f[24] = "bc\u0006\u0007_\u001e.x\u001b\u000b>厱桇叅桯伷叽伯厝叅厵j\u0002\u0017.k\u0017\u0006N\f3g";
   }

   public static boolean p(long a, Entity a, boolean var3) {
      boolean ax;
      boolean var15;
      label149: {
         ax = RotationUtils.q();
         if (a instanceof LivingEntity) {
            var15 = 友树友树友树何友树何.友树友树何友何友友友.树何何树何友何树友友.getValue();
            if (ax) {
               if (!var15 && !a.isAlive()) {
                  return false;
               }

               var15 = a.equals(mc.player);
            }

            if (!ax) {
               return var15;
            }

            if (!var15) {
               var15 = 友树友树友树何友树何.友树友树何友何友友友.友何何友何友友何友友.getValue();
               if (!ax) {
                  break label149;
               }

               if (var15 || !a.isInvisible()) {
                  var15 = 友树友树友树何友树何.友树友树何友何友友友.树树何何友友何树友友.getValue();
                  break label149;
               }
            }
         }

         return false;
      }

      label105:
      if (ax) {
         if (var15) {
            var15 = a instanceof Player;
            if (!ax) {
               break label105;
            }

            if (var15) {
               Player entityPlayer;
               label79: {
                  entityPlayer = (Player)a;
                  if (树何树何何友友友友何.何树何友何树何树树何 != null && 树何树何何友友友友何.何树何友何树何树树何.isEnabled()) {
                     var15 = 树何树何何友友友友何.何树何友何树何树树何.a(entityPlayer);
                     if (!ax) {
                        break label79;
                     }

                     if (var15) {
                        return false;
                     }
                  }

                  var15 = i(entityPlayer, 26524022810212L);
               }

               label72:
               if (ax) {
                  if (var15) {
                     var15 = Cherish.instance.getModuleManager().getModule(何树何树何何友友友何.class).isEnabled();
                     if (!ax) {
                        break label72;
                     }

                     if (!var15) {
                        return false;
                     }
                  }

                  var15 = entityPlayer.isSpectator();
               }

               if (ax) {
                  if (!var15) {
                     何树友树何何何树何何 teams = 何树友树何何何树何何.树树何何何何友友友何;
                     return !teams.isEnabled() || !teams.B(entityPlayer);
                  }

                  var15 = false;
               }

               return var15;
            }
         }

         var15 = 友树友树友树何友树何.友树友树何友何友友友.树树友树友何友友友友.getValue();
      }

      if (ax) {
         if (var15 && f(28013693375800L, a)) {
            return true;
         }

         var15 = 友树友树友树何友树何.友树友树何友何友友友.树友友友何何友友何树.getValue();
      }

      if (ax) {
         if (!var15) {
            return false;
         }

         var15 = E(a, 0, 1755351846, 65086);
      }

      return !ax ? var15 : var15;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static int u(Player a, long entityPlayer) {
      RotationUtils.q();
      return 0;
   }

   public static String E() {
      return 友何何树何何何何何树;
   }

   public static boolean E(Entity a, int a, int a, int a) {
      long ax = ((long)a << 48 | (long)a << 32 >>> 16 | (long)a << 48 >>> 48) ^ 112940413771193L;
      b<"à">(-6664411468973329972L, ax);
      return a instanceof Animal || a instanceof Squid || a instanceof IronGolem || a instanceof Bat;
   }

   private static String HE_SHU_YOU() {
      return "刘凤楠230622109211173513";
   }
}
