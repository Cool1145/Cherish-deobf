package cn.cool.cherish.utils.player;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// $VF: synthetic class
class RotationUtils$树友何友何树友树何树 implements 何树友 {
   private static final Object[] a = new Object[13];
   private static final String[] b = new String[13];
   private static int _我是何树友 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6744112702285942356L, 1108401711203922611L, MethodHandles.lookup().lookupClass()).a(21427179660062L);
      // $VF: monitorexit
      long var0 = var10000 ^ 129812441373775L;
      long var2 = var0 ^ 89591056690918L;
      a();
      友友树树何何树树何友 = new int[RotationUtils$何友树何树树友何何何.Q(var2).length];

      try {
         a<"j">(6202424784369600048L, var0)[a<"j">(6202160329492533816L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var11) {
      }

      try {
         a<"j">(6202424784369600048L, var0)[a<"j">(6202064513119434621L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var10) {
      }

      try {
         a<"j">(6202424784369600048L, var0)[a<"j">(6201984327571901338L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var9) {
      }

      try {
         a<"j">(6202424784369600048L, var0)[a<"j">(6201781634085993169L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var8) {
      }

      try {
         a<"j">(6202424784369600048L, var0)[a<"j">(6201824466250468304L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"j">(6202424784369600048L, var0)[a<"j">(6202285140941959024L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"j">(6202424784369600048L, var0)[a<"j">(6202169268952292179L, var0).ordinal()] = 7;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"j">(6202424784369600048L, var0)[a<"j">(6201925615820012722L, var0).ordinal()] = 8;
      } catch (NoSuchFieldError var4) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 212 && var8 != 219 && var8 != 'j' && var8 != 'k') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 164) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 253) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 212) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 219) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'j') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/RotationUtils$树友何友何树友树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 63;
               case 1 -> 53;
               case 2 -> 47;
               case 3 -> 12;
               case 4 -> 45;
               case 5 -> 60;
               case 6 -> 44;
               case 7 -> 19;
               case 8 -> 55;
               case 9 -> 36;
               case 10 -> 2;
               case 11 -> 42;
               case 12 -> 34;
               case 13 -> 33;
               case 14 -> 30;
               case 15 -> 4;
               case 16 -> 51;
               case 17 -> 37;
               case 18 -> 9;
               case 19 -> 22;
               case 20 -> 28;
               case 21 -> 6;
               case 22 -> 48;
               case 23 -> 56;
               case 24 -> 49;
               case 25 -> 8;
               case 26 -> 35;
               case 27 -> 32;
               case 28 -> 7;
               case 29 -> 40;
               case 30 -> 3;
               case 31 -> 62;
               case 32 -> 39;
               case 33 -> 5;
               case 34 -> 0;
               case 35 -> 14;
               case 36 -> 10;
               case 37 -> 15;
               case 38 -> 18;
               case 39 -> 24;
               case 40 -> 41;
               case 41 -> 38;
               case 42 -> 54;
               case 43 -> 43;
               case 44 -> 26;
               case 45 -> 31;
               case 46 -> 11;
               case 47 -> 50;
               case 48 -> 23;
               case 49 -> 29;
               case 50 -> 59;
               case 51 -> 1;
               case 52 -> 17;
               case 53 -> 61;
               case 54 -> 57;
               case 55 -> 25;
               case 56 -> 27;
               case 57 -> 52;
               case 58 -> 20;
               case 59 -> 16;
               case 60 -> 13;
               case 61 -> 21;
               case 62 -> 46;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "k&o=G[df\"6MFa;)p]@a$2pXXi1$,\u0006fg< *A[f\u001d57DG,伝厊桏佽栥栙厃伔伋佽";
      a[1] = " KE\u000ep6/\u000b\b\u0005z+*V\u0003Cj-*I\u0018Co5\"\\\u000e\u001f1\u000b,Q\n\u0019v6-p\u001f\u0004s*g栴厠伸叔伌桒叮桺伸栎";
      a[2] = "Bw";
      a[3] = "M5q\u001d\u001byF:`RzwM1d\b";
      a[4] = "<%8ng&o%t\u0012栟变栔厔桑发栟但栔桎H#tkq6upt'";
      a[5] = "0\u00152|?\u000bc\u0015~\u0000桇叵作厤厁參厝栯栘伺B1,F}\u0006\u007fb,\n";
      a[6] = "ceX\b}V0e\u0014t栅桲厑栎栱伩佁伶桋栎(En\u001b.v\u0015\u0016nW";
      a[7] = "$Yaq)8wY-\r压叆取栲叒佐压栜取栲\u0011<:uiJ,o:9";
      a[8] = "u\u0003Hf8D&\u0003\u0004\u001a伄厺伙厲叻叙桀厺桝桨8++\t8\u0010\u0005x+E";
      a[9] = "\u0006C\u0018]spUCT!栋伐栮佬厫叢栋厎栮佬h\u0010`=KPUC`q";
      a[10] = "\u001e.=M.\u0000M.q1伒叾栶原桔佬厌栤栶桅M\u0000=MS=pS=\u0001";
      a[11] = "{0$143(0hM伈反众伟伉厎厖体众厁T|'~6#i/'2";
      a[12] = "y\"\u000e\u0015\u0004\u0004'm\u0013\u0010~厽厃栋桴佱伣桧桙住厮,G\u0018:n]K\u0018\f\"k";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String LIU_YA_FENG() {
      return "何大伟230622198107200054";
   }
}
