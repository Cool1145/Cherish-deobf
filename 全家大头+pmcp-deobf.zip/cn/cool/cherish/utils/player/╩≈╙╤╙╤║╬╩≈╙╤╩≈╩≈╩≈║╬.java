package cn.cool.cherish.utils.player;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.helper.树友友友树友友何树何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.platform.InputConstants.Key;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class 树友友何树友树树树何 implements IWrapper, 何树友 {
   private static int[] 树何树何树何树树树何;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[33];
   private static final String[] e = new String[33];
   private static String LIU_YA_FENG;

   private 树友友何树友树树树何(long a) {
      long var10000 = 树友友何树友树树树何.a ^ a;
      super();
      throw new UnsupportedOperationException(b);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-988699259933043305L, 8828535552952479497L, MethodHandles.lookup().lookupClass()).a(273971376540841L);
      // $VF: monitorexit
      a = var10000;
      long var3 = a ^ 40264113693057L;
      a();
      if (a<"Z">(1264487450330204872L, var3) != null) {
         a<"Z">(new int[1], 1265182009196976517L, var3);
      }

      Cipher var0;
      Cipher var5 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var3 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var3 << var1 * 8 >>> 56);
      }

      var5.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var6 = b(
            var0.doFinal("8\\Ü\r\u0092An(\u0082õÊ;D\u009aì\u0099ãßUÝï$\u001f&»l\u0019\u0088²þÅ²M2«dHzC±ê\u0092¡1*Y\u0082B)ú\u000f¤aöWQ".getBytes("ISO-8859-1"))
         )
         .intern();
      byte var10001 = -1;
      b = var6;
   }

   public static Block F(double a, double var2, double var4, long var6) {
      var6 = 树友友何树友树树树何.a ^ var6;
      Vec3 playerPos = mc.player.position();
      return m(
         a<"Ý">(playerPos, -1070486928751009017L, var6) + 0.0,
         a<"Ý">(playerPos, -1070594508722827935L, var6) + var2,
         a<"Ý">(playerPos, -1070671313001355968L, var6) + 0.0
      );
   }

   public static boolean e(long var0) {
      var0 = a ^ var0;
      a<"Z">(7017124477129379496L, var0);
      return mc.player.isInWater() || mc.player.isInLava();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 45;
               case 1 -> 0;
               case 2 -> 12;
               case 3 -> 23;
               case 4 -> 40;
               case 5 -> 38;
               case 6 -> 53;
               case 7 -> 59;
               case 8 -> 33;
               case 9 -> 1;
               case 10 -> 49;
               case 11 -> 22;
               case 12 -> 57;
               case 13 -> 41;
               case 14 -> 39;
               case 15 -> 37;
               case 16 -> 11;
               case 17 -> 14;
               case 18 -> 62;
               case 19 -> 15;
               case 20 -> 3;
               case 21 -> 55;
               case 22 -> 31;
               case 23 -> 10;
               case 24 -> 9;
               case 25 -> 63;
               case 26 -> 32;
               case 27 -> 28;
               case 28 -> 54;
               case 29 -> 44;
               case 30 -> 50;
               case 31 -> 4;
               case 32 -> 20;
               case 33 -> 43;
               case 34 -> 42;
               case 35 -> 61;
               case 36 -> 27;
               case 37 -> 8;
               case 38 -> 46;
               case 39 -> 17;
               case 40 -> 13;
               case 41 -> 5;
               case 42 -> 26;
               case 43 -> 51;
               case 44 -> 7;
               case 45 -> 2;
               case 46 -> 25;
               case 47 -> 29;
               case 48 -> 18;
               case 49 -> 6;
               case 50 -> 24;
               case 51 -> 34;
               case 52 -> 35;
               case 53 -> 21;
               case 54 -> 36;
               case 55 -> 52;
               case 56 -> 47;
               case 57 -> 16;
               case 58 -> 58;
               case 59 -> 56;
               case 60 -> 19;
               case 61 -> 60;
               case 62 -> 30;
               default -> 48;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 221 && var8 != 207 && var8 != 238 && var8 != 'D') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 205) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 221) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 207) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 238) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   public static BlockHitResult f(Level a, BlockPos endVec, Vec3 pos, Vec3 startVec) {
      BlockState blockState = a.getBlockState(endVec);
      VoxelShape shape = blockState.getCollisionShape(a, endVec);
      return a.clipWithInteractionOverride(pos, startVec, endVec, shape, blockState);
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/树友友何树友树树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static void a() {
      c[0] = "\u0000\u0002\u0013'8;\u000fB^,2&\n\u001fUj\" \n\u0000Nj'8\u0002\u0015X6y桅厨厧佨桕厜桅桲桽佨";
      c[1] = "H\b6hA\u0013C\u0007'':\u0011Q\u001c0y\u0000\rV\f$F\u001f\u001aP\b4`\u0000\u0011g\u0011#l\u001f\u000bK\u0006.";
      c[2] = "Pe&\u0012f\u007f_%k\u0019lbZx`_|dZg{_y|Rrm\u0003'B\\\u007fi\u0005`\u007f]^|\u0018ec";
      c[3] = "1E";
      c[4] = "/`,bB\u0018/`;>N\u00175+/#]\u001d%+=\"[\u00185|v<C\u00108`*bn\u0013(i18F\u00142";
      c[5] = boolean.class;
      e[5] = "java/lang/Boolean";
      c[6] = "\u001bZw\t\u00015\u001bZ`U\r:\u0001\u0011tH\u001e0\u0011\u0011oB\u001a9\u0019\u0011@K\u0005,6PmS\t$\u0001\u001bEK\u00195\u0011";
      c[7] = "#C\f*\u007f\n#C\u001bvs\u00059\b\u000fk`\u000f)\b\u0014ad\u0006!\b;h{\u0013\u000eI\u0016pw\u001b9\u0002:h}\u0000&";
      c[8] = "\u0010`<\u0014`\u0016\u0010`+Hl\u0019\n+?U\u007f\u0013\u001a+8Rt\fPS-Y>";
      c[9] = double.class;
      e[9] = "java/lang/Double";
      c[10] = "\u000e{\u0019\u001f;\u0002\u000e{\u000eC7\r\u00140\u000e]?\u000e\u000ejC|?\u0005\u0005}\u001fP0\u001f";
      c[11] = "(kOVrZ(kX\n~U2 X\u0014vV(z\u00157oG/aU\u000b";
      c[12] = "+u_$25+uHx>:1>Hf69+d\u0005A:%\bq[z62\"";
      c[13] = "{.\u0001>\u001c\u0013{.\u0016b\u0010\u001cae\u0002\u007f\u0003\u0016qe\u0019u\u0007\u001fye\u0017|\u001e\u0019~e7|\u001e\u0019~8";
      c[14] = "9M\u00114u39M\u0006hy<#\u0006\u0012uj63\u0006\t\u007fn?;\u0006\u0007vw9<\u0006'vw9<";
      c[15] = "\u0011@";
      c[16] = void.class;
      e[16] = "java/lang/Void";
      c[17] = "u5";
      c[18] = "smE\u001ddOxbTR\u0005AsiP\b";
      c[19] = "\u00126L0K\u0000\u0010kMM6rD&I+\u000f\tU6Z1s\u0018W$J3\u0018\rI=EM";
      c[20] = "F32\u000b|FDn3v-4C8#\u000b?NA)<\bD\r\u0011(%\r>\u000f\u00007&v";
      c[21] = "BQa?3CC@ o\u000eG*\u0001'j0\u0017*0!)dU\u0013\u000b&)r\u0010";
      c[22] = "\u0000\f*;Tg\u0007\f<~:2hFz\u007f\u000bahwp+Cg\u0006\u000f-7G?";
      c[23] = "B]\r1i&\u0019\u0014\u0018b\u0000x.VJi;(.mKdeoIRH2y)";
      c[24] = "\" C\\F\u001c!4\t\u0000?(Y\u000b|<\u0003\u0003l-HN\u0000\u0017&q";
      c[25] = "/\u0012fG\u001cB-Og:K0y\u0002c\\XKh\u0012pF$";
      c[26] = "wiS9\u0007\\piE|i\t\u001f#\u0003}XY\u001f\u0012\t)\u0010\\qjT5\u0014\u0004";
      c[27] = "ysBzly{+\\z\\Q\u0019\u001e|E\u001a[D\u007f\t~\"&+}Q`\"";
      c[28] = "s\u0019D#@\u0017<\u0001\u0002p/\u0004\u0019S\u0005u\u001fS\u0019c\u0001.\u0015\u000f?\u000fY#V\u000f";
      c[29] = "oYI7?W A\u000fdPD\u0005\u0013\ba`\u0012\u0005#\f:jO#OT7)O";
      c[30] = "{e)Vk/.|h\u0000R\u0007Bm)^4=9|9M.A";
      c[31] = ".U\u001bDewaM]\u0017\ndD\u001fZ\u00125;D/^I0obC\u0006Dso";
      c[32] = "\u001f1)1\u00042V7\"#g1y1uiVfy\r-i]0\u001ek-eX;";
   }

   public static Block m(double a, double var2, double var4) {
      return mc.level.getBlockState(new BlockPos((int)a, (int)var2, (int)var4)).getBlock();
   }

   public static boolean o(long a) {
      a = 树友友何树友树树树何.a ^ a;
      int[] ax = a<"Z">(2458377939047452116L, (long)a);
      if (mc.player != null && mc.level != null) {
         Vec3 playerPos = mc.player.position();
         BlockPos centralPointBehind = new BlockPos(
            (int)Math.floor(a<"Ý">(playerPos, 2458264046622289982L, (long)a) + Math.sin(Math.toRadians(mc.player.getYRot())) * 0.8),
            (int)Math.floor(a<"Ý">(playerPos, 2458160657464712792L, (long)a)),
            (int)Math.floor(a<"Ý">(playerPos, 2458237461483730553L, (long)a) + -Math.cos(Math.toRadians(mc.player.getYRot())) * 0.8)
         );
         if (mc.level.getBlockState(centralPointBehind).is(a<"î">(2455142346429258306L, (long)a))) {
            return false;
         } else {
            BlockPos pos = centralPointBehind.below();
            BlockState state = mc.level.getBlockState(pos);
            int var10000 = state.is(a<"î">(2455142346429258306L, (long)a));
            int[] var10001 = ax;
            if (a > 0L) {
               if (ax == null) {
                  if (var10000) {
                     return false;
                  }

                  var10000 = state.isAir();
               }

               var10001 = ax;
            }

            if (var10001 == null) {
               if (var10000) {
                  var10000 = pos.getY();
                  var10001 = ax;
                  if (a >= 0L) {
                     if (ax == null) {
                        if (var10000 < mc.level.getMinBuildHeight()) {
                           return false;
                        }

                        var10000 = mc.level.getBlockState(pos.below()).isAir();
                     }

                     var10001 = ax;
                  }

                  if (var10001 != null) {
                     return (boolean)var10000;
                  }

                  if (var10000 != 0) {
                     var10000 = pos.below().getY();
                     var10001 = ax;
                     if (a > 0L) {
                        if (ax == null) {
                           if (var10000 < mc.level.getMinBuildHeight()) {
                              return (boolean)0;
                           }

                           var10000 = mc.level.getBlockState(pos.below().below()).isAir();
                        }

                        var10001 = ax;
                     }

                     if (var10001 != null) {
                        return (boolean)var10000;
                     }

                     if (var10000 == 0) {
                        return (boolean)1;
                     }

                     return (boolean)0;
                  }
               }

               var10000 = 1;
            }

            return (boolean)var10000;
         }
      } else {
         return true;
      }
   }

   public static Block o(long a, BlockPos var2) {
      a = 树友友何树友树树树何.a ^ a;
      a<"Z">(5943490788589764018L, (long)a);
      return mc.level != null && mc.player != null ? mc.level.getBlockState(var2).getBlock() : null;
   }

   public static Block p(double a, double var2, double var4, long var6) {
      long ax = 树友友何树友树树树何.a ^ var6 ^ 87620746912102L;
      return o(ax, BlockPos.containing((double)a, var2, var4));
   }

   public static int[] g() {
      return 树何树何树何树树树何;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static Block j(Player a, long player) {
      long ax = 树友友何树友树树树何.a ^ player ^ 95380463385396L;
      return o(ax, BlockPos.containing(a.getX(), a.getY() - 1.0, a.getZ()));
   }

   public static boolean j(double a, boolean height, long var3) {
      var3 = 树友友何树友树树树何.a ^ var3;
      int[] ax = a<"Z">(-8233231032745188748L, var3);
      if (height) {
         AABB bb = mc.player.getBoundingBox().move(0.0, (double)(-a), 0.0);
         return !mc.level.getEntityCollisions(mc.player, bb).isEmpty();
      } else {
         int offset = 0;

         while (offset < a) {
            BlockPos pos = new BlockPos((int)mc.player.getX(), (int)(mc.player.getY() - offset), (int)mc.player.getZ());
            BlockState blockState = mc.level.getBlockState(pos);
            int[] var10000 = ax;
            if (var3 > 0L) {
               if (ax == null) {
                  if (blockState.isCollisionShapeFullBlock(mc.level, pos)) {
                     return true;
                  }

                  offset++;
               }

               var10000 = ax;
            }

            if (var10000 != null) {
               break;
            }
         }

         return false;
      }
   }

   public static HitResult q(double a, float var2, long yaw, float var5) {
      yaw = 树友友何树友树树树何.a ^ yaw;
      long ax = (long)(yaw ^ 25257039888533L);
      long axx = (long)(yaw ^ 76570124210817L);
      a<"Z">(2105897713307071216L, (long)yaw);
      if (mc.player != null && mc.level != null) {
         Vec3 vec3 = mc.player.getEyePosition(1.0F);
         Vec3 vec31 = RotationUtils.l(new Object[]{new Rotation(axx, var2, var5), ax});
         Vec3 vec32 = vec3.add(
            a<"Ý">(vec31, 2105940000588959514L, (long)yaw) * 4.5,
            a<"Ý">(vec31, 2105832489672728956L, (long)yaw) * a,
            a<"Ý">(vec31, 2105756732954675549L, (long)yaw) * a
         );
         return mc.level.clip(new ClipContext(vec3, vec32, a<"î">(2105702108058883428L, (long)yaw), a<"î">(2105437348716807896L, (long)yaw), mc.player));
      } else {
         return null;
      }
   }

   public static Block z(long a, 树友友友树友友何树何 a) {
      long var10000 = 树友友何树友树树树何.a ^ a;
      long ax = 树友友何树友树树树何.a ^ a ^ 52599785103373L;
      long axx = 树友友何树友树树树何.a ^ a ^ 12661610588478L;
      long axxx = var10000 ^ 105687771269026L;
      long axxxx = var10000 ^ 65121395536115L;
      return p(a.B(axxx), a.V(ax), a.g(axx), axxxx);
   }

   public static void z(long a, int state, boolean a) {
      a = 树友友何树友树树树何.a ^ a;
      a<"Z">(-8093935462625173403L, (long)a);
      Key keyBind = a<"Ý">(a<"Ý">(mc, -8093443710927858696L, (long)a), -8093609542505004921L, (long)a).getKey();
      if (a > 0L) {
         KeyMapping.set(keyBind, true);
      }

      KeyMapping.click(keyBind);
   }

   public static boolean A(long var0) {
      var0 = a ^ var0;
      return a<"Ý">(mc.player.getAbilities(), 9049921029706443728L, var0);
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static boolean M(double a, double var2, double var4, long var6) {
      var6 = 树友友何树友树树树何.a ^ var6;
      int[] var10000 = a<"Z">(-6201207043088710087L, var6);
      int i = (int)var2;
      int[] ax = var10000;
      boolean var12;
      if (i <= -1 && var6 >= 0L) {
         var12 = true;
      } else {
         while (true) {
            var12 = mc.level.getBlockState(new BlockPos((int)a, i, (int)var4)).isAir();
            int[] var10001 = ax;
            if (var6 >= 0L) {
               if (ax != null) {
                  break;
               }

               var10001 = ax;
            }

            if (var10001 != null) {
               return var12;
            }

            if (!var12) {
               return false;
            }

            i--;
            if (var6 >= 0L) {
               var12 = true;
               break;
            }
         }
      }

      return var12;
   }

   public static int M(LivingEntity a, long a) {
      a = 树友友何树友树树树何.a ^ a;
      int totalArmor = 0;
      a<"Z">(-104500019532836539L, a);
      Iterator var6 = a.getArmorSlots().iterator();
      if (var6.hasNext()) {
         ItemStack armorItem = (ItemStack)var6.next();
         if (armorItem.getItem() instanceof ArmorItem armor) {
            totalArmor = 0 + armor.getDefense();
         }
      }

      return totalArmor;
   }

   public static void M(int[] var0) {
      树何树何树何树树树何 = var0;
   }

   public static boolean P(long var0) {
      long var3 = a ^ var0 ^ 72431102649842L;
      return M(mc.player.getX(), mc.player.getY(), mc.player.getZ(), var3);
   }

   public static boolean R(long a) {
      a = 树友友何树友树树树何.a ^ a;
      int[] var10000 = a<"Z">(-3895896888610953689L, (long)a);
      int i = 0;
      int[] ax = var10000;

      while (true) {
         var6 = mc.level.getCollisions(mc.player, mc.player.getBoundingBox().move(0.0, -i, 0.0)).iterator().hasNext();
         int[] var10001 = ax;
         if (a >= 0L) {
            if (ax != null) {
               break;
            }

            var10001 = ax;
         }

         if (var10001 != null) {
            return var6;
         }

         if (var6) {
            return false;
         }

         i++;
         if (a >= 0L) {
            var6 = true;
            break;
         }
      }

      return var6;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖黑水";
   }
}
