package cn.cool.cherish.utils.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.player.何何友何友树友友何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.phys.Vec3;

public final class 树何何何树何友何树何 implements IWrapper, 何树友 {
   public static final double 何何友树树树友友树友 = 0.221;
   public static final double 友友何友何树何何树树 = 1.3F;
   public static final double 树友何何何友树何树树 = 0.3F;
   public static final double 何何树友何友树友友树 = 0.4751131221719457;
   public static final double 何何友树何何树友友何 = 0.5203620003898759;
   public static final double[] 何树树何树树何何何何;
   private static String[] 友树何何何何何何何友;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[39];
   private static final String[] e = new String[39];
   private static int _何树友被何大伟克制了 _;

   private 树何何何树何友何树何(long a) {
      long var10000 = 树何何何树何友何树何.a ^ a;
      super();
      throw new UnsupportedOperationException(b);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1935970111513016388L, -5264265655235387607L, MethodHandles.lookup().lookupClass()).a(214015424653710L);
      // $VF: monitorexit
      a = var10000;
      long var3 = a ^ 66905928702328L;
      a();
      if (a<"S">(6859181355667097450L, var3) != null) {
         a<"S">(new String[5], 6860098962705688496L, var3);
      }

      Cipher var0;
      Cipher var5 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var3 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var3 << var1 * 8 >>> 56);
      }

      var5.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var6 = b(var0.doFinal("ö\u008dmu\u0006ñ7´½&8ÝkßùÁY¼dÇ`GgÑ¦ÞåÜ±õn\u008cN¥\u0086XÒYbñ5¢¥¿ß\u008dø½oÐß÷÷èsP".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      b = var6;
      何树树何树树何何何何 = new double[]{1.0, 1.4304347400741908, 1.7347825295420372, 1.9217390955733897};
   }

   public static void B(long var0) {
      long var3 = a ^ var0 ^ 1649422762185L;
      long var5 = a ^ var0 ^ 66547755245166L;
      t(B(var3), mc.player, var5);
   }

   public static double B(long var0) {
      var0 = a ^ var0;
      return Math.hypot(a<"ñ">(mc.player.getDeltaMovement(), -8072918852924975037L, var0), a<"ñ">(mc.player.getDeltaMovement(), -8073204155600828457L, var0));
   }

   public static boolean F(long var0) {
      var0 = a ^ var0;
      a<"S">(6243649756915411251L, var0);
      return Math.abs(a<"ñ">(a<"ñ">(mc.player, 6245307812246527144L, var0), 6244365485210270422L, var0)) >= 0.8F
         || Math.abs(a<"ñ">(a<"ñ">(mc.player, 6245307812246527144L, var0), 6243247967813273744L, var0)) >= 0.8F;
   }

   public static double J(float a, long a, int a, float inputStrafe) {
      long ax = (a << 32 | (long)a << 32 >>> 32) ^ 树何何何树何友何树何.a;
      int[] var10000 = a<"S">(-2177785597234373040L, ax);
      float rotationYaw = mc.player.getYRot();
      int[] axx = var10000;
      if (a < 0.0F) {
         rotationYaw += 180.0F;
      }

      float forward = 1.0F;
      float var12;
      int var11 = (var12 = a - 0.0F) == 0.0F ? 0 : (var12 < 0.0F ? -1 : 1);
      int[] var10001 = axx;
      if (a > 0L) {
         if (axx == null) {
            if (var11 < 0) {
               forward = -0.5F;
            }

            float var13;
            var11 = (var13 = a - 0.0F) == 0.0F ? 0 : (var13 < 0.0F ? -1 : 1);
         }

         var10001 = axx;
      }

      if (a >= 0L) {
         if (var10001 == null) {
            if (var11 > 0) {
               forward = 0.5F;
            }

            float var14;
            var11 = (var14 = inputStrafe - 0.0F) == 0.0F ? 0 : (var14 < 0.0F ? -1 : 1);
         }

         var10001 = axx;
      }

      if (var10001 == null) {
         if (var11 > 0) {
            rotationYaw -= 70.0F * forward;
         }

         float var15;
         var11 = (var15 = inputStrafe - 0.0F) == 0.0F ? 0 : (var15 < 0.0F ? -1 : 1);
      }

      if (var11 < 0) {
         rotationYaw += 70.0F * forward;
      }

      return Math.toRadians(rotationYaw);
   }

   public static float V(long var0) {
      var0 = a ^ var0;
      a<"S">(4468347710413586836L, var0);
      return mc.player != null && mc.level != null
         ? (float)Math.sqrt(
            a<"ñ">(mc.player.getDeltaMovement(), 4468465896832362935L, var0) * a<"ñ">(mc.player.getDeltaMovement(), 4468465896832362935L, var0)
               + a<"ñ">(mc.player.getDeltaMovement(), 4468171737939129891L, var0) * a<"ñ">(mc.player.getDeltaMovement(), 4468171737939129891L, var0)
         )
         : 0.0F;
   }

   public static double e(long a) {
      a = 树何何何树何友何树何.a ^ a;
      int[] var10000 = a<"S">(3052874548956485067L, (long)a);
      float rotationYaw = mc.player.getYRot();
      int[] ax = var10000;
      if (a<"ñ">(a<"ñ">(mc.player, 3050011411668885584L, (long)a), 3049053731064546862L, (long)a) < 0.0F) {
         rotationYaw += 180.0F;
      }

      float forward;
      int[] var10001;
      label52: {
         label51: {
            label56: {
               forward = 1.0F;
               float var9;
               var7 = (var9 = a<"ñ">(a<"ñ">(mc.player, 3050011411668885584L, (long)a), 3049053731064546862L, (long)a) - 0.0F) == 0.0F
                  ? 0
                  : (var9 < 0.0F ? -1 : 1);
               var10001 = ax;
               if (a >= 0L) {
                  if (ax == null) {
                     if (var7 < 0) {
                        var8 = -0.5F;
                        if (a < 0L) {
                           break label56;
                        }

                        forward = -0.5F;
                     }

                     float var10;
                     var7 = (var10 = a<"ñ">(a<"ñ">(mc.player, 3050011411668885584L, (long)a), 3049053731064546862L, (long)a) - 0.0F) == 0.0F
                        ? 0
                        : (var10 < 0.0F ? -1 : 1);
                  }

                  var10001 = ax;
               }

               if (a <= 0L) {
                  break label52;
               }

               if (var10001 != null) {
                  break label51;
               }

               if (var7 > 0) {
                  forward = 0.5F;
               }

               var8 = a<"ñ">(a<"ñ">(mc.player, 3050011411668885584L, (long)a), 3052424148894938216L, (long)a);
            }

            float var11;
            var7 = (var11 = var8 - 0.0F) == 0.0F ? 0 : (var11 < 0.0F ? -1 : 1);
         }

         var10001 = ax;
      }

      if (var10001 == null) {
         if (var7 > 0) {
            rotationYaw -= 90.0F * forward;
         }

         float var12;
         var7 = (var12 = a<"ñ">(a<"ñ">(mc.player, 3050011411668885584L, (long)a), 3052424148894938216L, (long)a) - 0.0F) == 0.0F ? 0 : (var12 < 0.0F ? -1 : 1);
      }

      if (var7 < 0) {
         rotationYaw += 90.0F * forward;
      }

      return Math.toRadians(rotationYaw);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 41;
               case 1 -> 6;
               case 2 -> 52;
               case 3 -> 27;
               case 4 -> 54;
               case 5 -> 56;
               case 6 -> 48;
               case 7 -> 11;
               case 8 -> 62;
               case 9 -> 22;
               case 10 -> 18;
               case 11 -> 25;
               case 12 -> 9;
               case 13 -> 39;
               case 14 -> 21;
               case 15 -> 7;
               case 16 -> 43;
               case 17 -> 61;
               case 18 -> 37;
               case 19 -> 2;
               case 20 -> 44;
               case 21 -> 35;
               case 22 -> 30;
               case 23 -> 32;
               case 24 -> 47;
               case 25 -> 40;
               case 26 -> 31;
               case 27 -> 63;
               case 28 -> 24;
               case 29 -> 36;
               case 30 -> 46;
               case 31 -> 34;
               case 32 -> 53;
               case 33 -> 59;
               case 34 -> 55;
               case 35 -> 1;
               case 36 -> 29;
               case 37 -> 20;
               case 38 -> 28;
               case 39 -> 13;
               case 40 -> 42;
               case 41 -> 15;
               case 42 -> 33;
               case 43 -> 14;
               case 44 -> 23;
               case 45 -> 0;
               case 46 -> 3;
               case 47 -> 38;
               case 48 -> 49;
               case 49 -> 16;
               case 50 -> 12;
               case 51 -> 58;
               case 52 -> 19;
               case 53 -> 8;
               case 54 -> 57;
               case 55 -> 4;
               case 56 -> 17;
               case 57 -> 50;
               case 58 -> 10;
               case 59 -> 60;
               case 60 -> 45;
               case 61 -> 5;
               case 62 -> 26;
               default -> 51;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 241 && var8 != 'J' && var8 != 242 && var8 != 210) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 211) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'S') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 241) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'J') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 242) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public static boolean x(long var0) {
      var0 = a ^ var0;
      a<"S">(3597744287341006459L, var0);
      if (mc.player != null) {
         Minecraft var10000 = mc;
         if (var0 > 0L) {
            if (mc.level == null) {
               return false;
            }

            var10000 = mc;
         }

         if (a<"ñ">(a<"ñ">(var10000.player, 3594977907043105760L, var0), 3593967415394409886L, var0) != 0.0
            || a<"ñ">(a<"ñ">(mc.player, 3594977907043105760L, var0), 3597355701513744344L, var0) != 0.0) {
            return true;
         }
      }

      return false;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public static void c(double a, int a, int speed) {
      long ax = ((long)a << 32 | (long)speed << 32 >>> 32) ^ 树何何何树何友何树何.a;
      long axx = ax ^ 64027239173468L;
      long axxx = ax ^ 28941872286381L;
      if (x(axx)) {
         double yaw = g(axxx);
         mc.player.setDeltaMovement(-Math.sin(yaw) * 0.6, a<"ñ">(mc.player.getDeltaMovement(), -4972835137980524044L, ax), Math.cos(yaw) * a);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   public static double h(long a) {
      long ax;
      double horizontalDistance;
      boolean useBaseModifiers;
      label46: {
         a = 树何何何树何友何树何.a ^ a;
         long axx = a ^ 16568494720840L;
         ax = a ^ 59668944009623L;
         a<"S">(-3013593150646179397L, (long)a);
         useBaseModifiers = false;
         if (mc.player.isInWaterOrBubble()) {
            horizontalDistance = 0.105;
            if (a <= 0L) {
               break label46;
            }
         }

         if (树友友何树友树树树何.e(axx)) {
            horizontalDistance = 0.11500000208616258;
            int depthStriderLevel = Y(new Object[0]);
            if (depthStriderLevel > 0) {
               horizontalDistance = 0.11500000208616258 * a<"ò">(-3013709630933921894L, (long)a)[depthStriderLevel];
               useBaseModifiers = true;
            }

            if (a <= 0L) {
               break label46;
            }
         }

         if (mc.player.isCrouching()) {
            horizontalDistance = 0.0663000026345253;
            if (a <= 0L) {
               break label46;
            }
         }

         horizontalDistance = 0.221;
         useBaseModifiers = true;
      }

      if (useBaseModifiers) {
         if (Q(ax, false)) {
            horizontalDistance *= 1.3F;
         }

         MobEffectInstance speedEffect = mc.player.getEffect(a<"ò">(-3016835095570008289L, (long)a));
         if (speedEffect != null && speedEffect.getDuration() > 0 && !Cherish.instance.getModuleManager().getModule(何何友何友树友友何何.class).isEnabled()) {
            double var10000 = horizontalDistance * (1.0 + 0.2 * (speedEffect.getAmplifier() + 1));
         }

         mc.player.getEffect(a<"ò">(-3016578450916349483L, (long)a));
         horizontalDistance = 0.29;
      }

      return horizontalDistance;
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      c[0] = "\u0016F:5vO\u0019\u0006w>|R\u001c[|xlT\u001cDgxiL\u0014Qq$7栱传佽佁桇佌叫传根佁";
      c[1] = "f\u0016Gmjam\u0019V\"\u0001uo\u0012Ax-bb";
      c[2] = "Q6?S\u0017\u0006Q6(\u000f\u001b\tK}<\u0012\b\u0003[};\u0015\u0003\u001c\u0011\u0005.\u001eI";
      c[3] = double.class;
      e[3] = "java/lang/Double";
      c[4] = "C{,\u0003/(C{;_#'Y0;A+$Cjv]. T{*\u0003\u000b/]k,";
      c[5] = float.class;
      e[5] = "java/lang/Float";
      c[6] = "4u1W`.4u&\u000bl!.>2\u0016\u007f+>> \u0017y..ik\ta&#u7WL%3|,\rd\")";
      c[7] = boolean.class;
      e[7] = "java/lang/Boolean";
      c[8] = "\\\u0006]L\u001aU\\\u0006J\u0010\u0016ZFMJ\u000e\u001eY\\\u0017\u0007\u0012\u001b]K\u0006[L;SQ\u0002E2\u001b]K\u0006[";
      c[9] = "UY[&6\u0017Z\u0019\u0016-<\n_D\u001dk,\f_[\u0006k)\u0014WN\u00107w*YC\u001410\u0017Xb\u0001,5\u000b";
      c[10] = "\u0018\u001f";
      c[11] = "\u0000^7I2&\u0000^ \u0015>)\u001a\u00154\b-#\n\u0015&\u00019*\rOm*0-+]%\u0002<;\u001d";
      c[12] = "WAu)V0WAbuZ?M\nvhI5]\nda]<ZP/JT;|BgbX-";
      c[13] = "\u0017c\u001b\u001e\nFbC\u0010\u0011\u001b\t\u001f[\u0003\u0016\u0012@w";
      c[14] = "\u000f2AK:Nz\u0012JD+\u0001\u0007\nYC\"Ho";
      c[15] = void.class;
      e[15] = "java/lang/Void";
      c[16] = "AM";
      c[17] = "o# Iwjo#7\u0015{euh7\u000bsfo2z*smd%&\u0006|w";
      c[18] = "\u001e\u0002F\u000e\u0001\u0019\u001e\u0002QR\r\u0016\u0004IQL\u0005\u0015\u001e\u0013\u001co\u001c\u0004\u0019\b\\S";
      c[19] = ">1FB\u007f1>1Q\u001es>$zQ\u0000{=> \u001c'w!\u001d5B\u001c{67";
      c[20] = "B\u000eXrl!I\u0001I=\r/B\nMg";
      c[21] = "\u0012,>o\nkF)'c0=\u007fnz\"\rm\u0017\u0000B)K3R%>nU=\u0015";
      c[22] = "\f+\\<rD\u0000#\u0011=\f\u00170+\u0014t2G0\u001aF5l\u0019\u0001~W6f\u0016";
      c[23] = "\u001f],\u001b\u0017\u001c\u0014\\x+\u0007-\u001bR!\u0011@_\u0011\t|V~";
      c[24] = "=\u0001+C`\u001fjP4\u001d\\\u0010V\u0007k\u0014g@V<k\u001e?\u000fyS+U>\u0011";
      c[25] = "szi\u0017K^5v;\u0013vJ\u0019=g]H\u001e\u0019\u0004kV\u0015U6k+\u001d\u0014K";
      c[26] = "\u0004\u001f\u0013\u0014\u0011=\u000f\u001eG$)\f\u0000\u0010\u001e\u001eF~\nKCYxfPF\u001e\u0019\u001ccT\u001d\u001e$";
      c[27] = "Z\u0012a\u0001W!\u001c\u001e3\u0005j50UfKTbW;^A\u0011'\u001aVf\u0015\u0014>\u0016";
      c[28] = "\"3+GI_)2\u007fwInv5{HN\u00162vl\u0007 Ww`)\u0019X\u00134wfw";
      c[29] = ":p_\u0019s{5t\u0003\u0013\u0017qR7\u000b\u0015&!R\u000e\nFmm\u007f>@O&.";
      c[30] = "C9^5\u001d\u000eL=\u0002?y\u0004+~\n9HU+G\u000bj\u0003\u0018\u0006wAcH[";
      c[31] = "O@n|.T^CdsH^s\b4$y\ts9b~:_KXrl1Q";
      c[32] = " \u0011wJ\fee\u000f+GvqNQ+\u0016F&Na+H\u001f~{\u0019`E\u0016`";
      c[33] = "X>J7p$S?\u001e\u0007佄栌栬佝桮栞佄佈佨佝wmtzR}\u0014n)yY";
      c[34] = ",U/\u000by7iKs\u0006\u0003#B\u0015sW3uB%s\tj,w]8\u0004c2";
      c[35] = "#\\=\u0013F`fM5I{\\\u001d\u001cvJ\u001bgsJ=\u0017\u001b\u001a";
      c[36] = "-@\u0018\u0011kUh^D\u001c\u0011AC\u0000DM.\u001eC0D\u0013xNvH\u000f\u001eqP";
      c[37] = "cNGE+*7K^I\u0011|\u000e\f\u0003\b,,gb;\u0003jr#GGDt|d";
      c[38] = "~\u0002yi~Rq\u0006%c\u001aX\u0016E-f#\u000e\u0016|,6`D;Lf?+\u0007";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/树何何何树何友何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   public static double a(float a, long rotationYaw, double var3, double var5) {
      rotationYaw = 树何何何树何友何树何.a ^ rotationYaw;
      int[] ax = a<"S">(3440050650283036715L, (long)rotationYaw);
      if (var3 < 0.0) {
         a += 180.0F;
      }

      float forward = 1.0F;
      double var11;
      int var10000 = (var11 = var3 - 0.0) == 0.0 ? 0 : (var11 < 0.0 ? -1 : 1);
      int[] var10001 = ax;
      if (rotationYaw > 0L) {
         if (ax == null) {
            if (var10000 < 0) {
               forward = -0.5F;
            }

            double var12;
            var10000 = (var12 = var3 - 0.0) == 0.0 ? 0 : (var12 < 0.0 ? -1 : 1);
         }

         var10001 = ax;
      }

      if (rotationYaw > 0L) {
         if (var10001 == null) {
            if (var10000 > 0) {
               forward = 0.5F;
            }

            double var13;
            var10000 = (var13 = var5 - 0.0) == 0.0 ? 0 : (var13 < 0.0 ? -1 : 1);
         }

         var10001 = ax;
      }

      if (var10001 == null) {
         if (var10000 > 0) {
            a -= 90.0F * forward;
         }

         double var14;
         var10000 = (var14 = var5 - 0.0) == 0.0 ? 0 : (var14 < 0.0 ? -1 : 1);
      }

      if (var10000 < 0) {
         a += 90.0F * forward;
      }

      return Math.toRadians(a);
   }

   public static void t(double a, Entity var2, long entity) {
      entity = 树何何何树何友何树何.a ^ entity;
      long ax = entity ^ 92165130370369L;
      long axx = entity ^ 122831637325553L;
      if (x(axx)) {
         double yaw = e(ax);
         double motionY = a<"ñ">(var2.getDeltaMovement(), 5859646316473479769L, (long)entity);
         var2.setDeltaMovement(-Mth.sin((float)yaw) * a, motionY, Mth.cos((float)yaw) * a);
      }
   }

   public static double g(long a) {
      a = 树何何何树何友何树何.a ^ a;
      int[] var10000 = a<"S">(-5324133032826091126L, (long)a);
      float rotationYaw = mc.player.getYRot();
      int[] ax = var10000;
      if (a<"ñ">(a<"ñ">(mc.player, -5326969781533606895L, (long)a), -5327346885907375505L, (long)a) < 0.0F) {
         rotationYaw += 180.0F;
      }

      float forward;
      int[] var10001;
      label52: {
         label51: {
            label56: {
               forward = 1.0F;
               float var9;
               var7 = (var9 = a<"ñ">(a<"ñ">(mc.player, -5326969781533606895L, (long)a), -5327346885907375505L, (long)a) - 0.0F) == 0.0F
                  ? 0
                  : (var9 < 0.0F ? -1 : 1);
               var10001 = ax;
               if (a >= 0L) {
                  if (ax == null) {
                     if (var7 < 0) {
                        var8 = -0.5F;
                        if (a < 0L) {
                           break label56;
                        }

                        forward = -0.5F;
                     }

                     float var10;
                     var7 = (var10 = a<"ñ">(a<"ñ">(mc.player, -5326969781533606895L, (long)a), -5327346885907375505L, (long)a) - 0.0F) == 0.0F
                        ? 0
                        : (var10 < 0.0F ? -1 : 1);
                  }

                  var10001 = ax;
               }

               if (a < 0L) {
                  break label52;
               }

               if (var10001 != null) {
                  break label51;
               }

               if (var7 > 0) {
                  forward = 0.5F;
               }

               var8 = a<"ñ">(a<"ñ">(mc.player, -5326969781533606895L, (long)a), -5323958883441481687L, (long)a);
            }

            float var11;
            var7 = (var11 = var8 - 0.0F) == 0.0F ? 0 : (var11 < 0.0F ? -1 : 1);
         }

         var10001 = ax;
      }

      if (var10001 == null) {
         if (var7 > 0) {
            rotationYaw -= 90.0F * forward;
         }

         float var12;
         var7 = (var12 = a<"ñ">(a<"ñ">(mc.player, -5326969781533606895L, (long)a), -5323958883441481687L, (long)a) - 0.0F) == 0.0F
            ? 0
            : (var12 < 0.0F ? -1 : 1);
      }

      if (var7 < 0) {
         rotationYaw += 90.0F * forward;
      }

      return Math.toRadians(rotationYaw);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static String[] q() {
      return 友树何何何何何何何友;
   }

   public static void r(double a, long var2, boolean var4) {
      var2 = 树何何何树何友何树何.a ^ var2;
      long ax = var2 ^ 25747722520993L;
      long axx = var2 ^ 60489598389840L;
      a<"S">(-4755358830700576361L, var2);
      if (x(ax) || !var4) {
         double yaw = g(axx);
         Vec3 currentMovement = mc.player.getDeltaMovement();
         double newMotionX = -Math.sin(yaw) * a;
         double newMotionZ = Math.cos(yaw) * a;
         mc.player.setDeltaMovement(newMotionX, a<"ñ">(currentMovement, -4755276072376525559L, var2), newMotionZ);
      }
   }

   public static double r(double a, double var2, double var4) {
      return Math.max((double)a, Math.min(var2, var4));
   }

   public static int Y(Object[] var0) {
      return EnchantmentHelper.getDepthStrider(mc.player);
   }

   public static void Y(long var0) {
      var0 = a ^ var0;
      a<"S">(2585027008180771913L, var0);
      if (mc.player != null) {
         mc.player.setDeltaMovement(0.0, 0.0, 0.0);
      }
   }

   public static void Y(String[] var0) {
      友树何何何何何何何友 = var0;
   }

   public static void G(long var0) {
      var0 = a ^ var0;
      a<"S">(4791483695877635560L, var0);
      if (mc.player.isSprinting()) {
         mc.player.setSprinting(false);
      }

      try {
         KeyMapping.set(a<"ñ">(a<"ñ">(mc, 4788338065907863155L, var0), 4787860424019863348L, var0).getKey(), false);
         a<"ñ">(a<"ñ">(mc, 4788338065907863155L, var0), 4787860424019863348L, var0).setDown(false);
      } catch (Exception var2) {
      }
   }

   public static boolean Q(long a, boolean a) {
      a = 树何何何树何友何树何.a ^ a;
      long ax = a ^ 71349657450783L;
      a<"S">(-6199236937648810399L, (long)a);
      return F(ax);
   }

   private static String LIU_YA_FENG() {
      return "何树友为什么濒天了";
   }
}
