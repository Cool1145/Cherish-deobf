package cn.cool.cherish.utils.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.misc.何树树树何友友何树树;
import cn.cool.cherish.module.impl.misc.友友友何何树树树何树;
import cn.cool.cherish.module.impl.misc.树何树树友何何树树友;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Squid;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.entity.monster.Shulker;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;

public final class 树树树何友友树友友友 implements IWrapper, 何树友 {
   private static int[] 树树友何友树何树友何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[25];
   private static final String[] g = new String[25];
   private static String HE_JIAN_GUO;

   private 树树树何友友树友友友(int a, short a, int a) {
      long ax = ((long)a << 32 | (long)a << 48 >>> 32 | (long)a << 48 >>> 48) ^ 树树树何友友树友友友.a;
      super();
      throw new UnsupportedOperationException(a<"q">(13709, 7271413304321897334L ^ ax));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(1270609502918675491L, -550896481272836941L, MethodHandles.lookup().lookupClass()).a(78758497375999L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 118206402503280L;
      a();
      int[] var12 = new int[1];
      b<"G">(var12, 6955333028077321332L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[3];
      int var5 = 0;
      char var3 = 24;
      int var2 = -1;

      while (true) {
         String var15 = b(
               var0.doFinal(
                  "\u0099\u009d\u0093×\u0001=\u0088³\u0090GG\u0099\u0080\u0007Z¾Ô´í?\u0086çÎK ¨ÁÕ\u0092b\u001d\u00907^ \u008e\u008dq®2ÚtTâÐ¢\bò,aóïl'\u0003>BX\u0099\"¡\u0098[\u0096\u0086ð~\u001aW48°\u009aÓ\u0098\u0099ê\u001c÷ý¢6æ\u0087[7àf+ß\u0018Û9lQ\u0014L\t,_38û]\u009f½ÙÎ#\u0004RðÜ%\u0090¥\u0010:)\u0017ÑTv\u0083>@\u0013û½^$\u0002\u0085$ÜX¶mÑ<ýÚÙ\u0092tW"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var15;
         if ((var2 += var3) >= 146) {
            b = var7;
            c = new String[3];
            return;
         }

         var3 = "\u0099\u009d\u0093×\u0001=\u0088³\u0090GG\u0099\u0080\u0007Z¾Ô´í?\u0086çÎK ¨ÁÕ\u0092b\u001d\u00907^ \u008e\u008dq®2ÚtTâÐ¢\bò,aóïl'\u0003>BX\u0099\"¡\u0098[\u0096\u0086ð~\u001aW48°\u009aÓ\u0098\u0099ê\u001c÷ý¢6æ\u0087[7àf+ß\u0018Û9lQ\u0014L\t,_38û]\u009f½ÙÎ#\u0004RðÜ%\u0090¥\u0010:)\u0017ÑTv\u0083>@\u0013û½^$\u0002\u0085$ÜX¶mÑ<ýÚÙ\u0092tW"
            .charAt(var2);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 32;
               case 1 -> 49;
               case 2 -> 28;
               case 3 -> 33;
               case 4 -> 20;
               case 5 -> 17;
               case 6 -> 12;
               case 7 -> 9;
               case 8 -> 46;
               case 9 -> 40;
               case 10 -> 60;
               case 11 -> 50;
               case 12 -> 2;
               case 13 -> 29;
               case 14 -> 34;
               case 15 -> 57;
               case 16 -> 27;
               case 17 -> 52;
               case 18 -> 5;
               case 19 -> 53;
               case 20 -> 54;
               case 21 -> 6;
               case 22 -> 13;
               case 23 -> 19;
               case 24 -> 1;
               case 25 -> 0;
               case 26 -> 10;
               case 27 -> 62;
               case 28 -> 41;
               case 29 -> 44;
               case 30 -> 22;
               case 31 -> 59;
               case 32 -> 25;
               case 33 -> 8;
               case 34 -> 7;
               case 35 -> 30;
               case 36 -> 3;
               case 37 -> 24;
               case 38 -> 45;
               case 39 -> 15;
               case 40 -> 4;
               case 41 -> 47;
               case 42 -> 18;
               case 43 -> 51;
               case 44 -> 58;
               case 45 -> 43;
               case 46 -> 26;
               case 47 -> 61;
               case 48 -> 42;
               case 49 -> 23;
               case 50 -> 37;
               case 51 -> 56;
               case 52 -> 31;
               case 53 -> 48;
               case 54 -> 55;
               case 55 -> 36;
               case 56 -> 14;
               case 57 -> 38;
               case 58 -> 63;
               case 59 -> 21;
               case 60 -> 11;
               case 61 -> 39;
               case 62 -> 35;
               default -> 16;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 199 && var8 != 'z' && var8 != 208 && var8 != 207) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 203) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'G') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 199) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'z') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 208) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/树树树何友友树友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static boolean x(long a, Entity var2) {
      a = 树树树何友友树友友友.a ^ a;
      long ax = a ^ 129344916960949L;
      b<"G">(2071513681594374814L, (long)a);
      return var2 instanceof Player && var2.getName().getString() != null && Cherish.instance.v().J(树树何友友友友何树友.L(var2.getName().getString(), ax));
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   public static int d(long a, Player var2) {
      a = 树树树何友友树友友友.a ^ a;
      b<"G">(6973634651414865638L, (long)a);
      return 0;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/树树树何友友树友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      f[0] = "JTY~WWE\u0014\u0014u]J@I\u001f3ML@V\u00043HTHC\u0012o\u0016栩核栫伢取右栩叢叱厼";
      f[1] = "W.";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = "b\u000bbyY6i\u0004s6\"4{\u001fdh\u0018(|\u000fpW\u0007?z\u000b`q\u00184M\u0012w}\u0007.a\u0005z";
      f[4] = "R8\u000eH\u001a2]xCC\u0010/X%H\u0005\u00182U#LN[4\\&L\u0005\u00114B&LJ\fs佤伃併栺桤伈栠桇栱叠";
      f[5] = "\u0010\u0006J0\u0005C\u001fF\u0007;\u000f^\u001a\u001b\f}\u001cM\u001f\u001d\u0001}\u0003A\u0003\u0004J\u0011\u0005C\u001f\r\u0005=<M\u001f\u001d\u0001";
      f[6] = "2>\u00025\u0019\u0006=~O>\u0013\u001b8#Dx\u001b\u00065%@3X\u0000< @x\u001b\u0000\"3\u0002桇伣桸桀厛佹伃桧桸厚";
      f[7] = "o\u0015Z5\u0005N`U\u0017>\u000fSe\b\u001cx\u0007Nh\u000e\u00183DHa\u000b\u0018x\u0007H\u007f\u0018Z厝厡只余伮桥桇桻佴栝";
      f[8] = "\u0004Y\u0015\u000e\u0011I\u000b\u0019X\u0005\u001bT\u000eDSC\u000bR\u000e[HC\u000eJ\u0006N^\u001fPt\bCZ\u0019\u0017I\tbO\u0004\u0012U";
      f[9] = ".\f";
      f[10] = "J\u0013G9Z4J\u0013PeV;PXP{^8J\u0002\u001dzB1P\u001fC{V$A\u0004\u001dDR/R\u0013ASV)E";
      f[11] = "hk\u001aeQycd\u000b*,apc\u0002c";
      f[12] = "\u001e;NF\u0013>\u00154_\tr0\u001e?[S";
      f[13] = "\rQg\u0002j \u0006S?ro^\u0003Ro\u001fl8P\\j\u000b\u0016d\u0004]i\u0018pcDK3r";
      f[14] = "\t>O\u001cSG\u0002<\u0017lF9\u0003nD\u000eC\u0002Rb\u001fQ/\u0003\b=D\u0000\u0014R\u0004f\u001bl";
      f[15] = "_\u0004\u0003CLD\u0012\u0002OA}佥桻栦栦你传校厡佢栦=@\u0003^A\u000eA\r\u0005\u0012C";
      f[16] = "A} |xN\u001cp* \u0017桫档住伒伐佊桫厹栋厌M+N\u001c`6#+\u0000\u0011-";
      f[17] = "Uo63?T\u000bq}1\u0003jh!.)nV\u000er ,z,";
      f[18] = "Yx\u001bvqJ\u0004u\u0011*\u001e厵厡佊桭桞佃伫伿佊伩G\"J\u0004e\r)\"\u0004\t(";
      f[19] = "\u0018\u001dJ}J\u0002\u001c\u0011\r1t伽叧厳佮參伩厣叧厳株\u0000H\r]\r\rbL\u0001\u001aA";
      f[20] = "[Z.W3\u0003\u0006W$\u000b\\栦厣佨厂桿原栦桹栬桘fgP\u000f\u0004.Z:]\u0005X";
      f[21] = "[\u001cI\u001297\u0006\u0011CNV又桹伮栿叠桏佖厣伮佻#j7\u0006\u0001_Mjy\u000bL";
      f[22] = "*OJ2\u0010\u0001wB@n\u007f你叒佽格佞桦你佌口格\u0003C\u0001wR\\mCOz\u001f";
      f[23] = "\r2dSXX_cu\u0005dZe4'U_\n\tZ\u001fW\u001eNJmy\b\u0004\u000fR";
      f[24] = "\u001f\u0004)c\u0013;B\t#?|栞栽伶厅桋桥叄叧桲桟R@;B\u0019?<@uOT";
   }

   private static UnsupportedOperationException a(UnsupportedOperationException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29631;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/utils/player/树树树何友友树友友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static int[] q() {
      return 树树友何友树何树友何;
   }

   public static void q(int[] var0) {
      树树友何友树何树友何 = var0;
   }

   public static boolean q(Entity a, long a) {
      a = 树树树何友友树友友友.a ^ a;
      b<"G">(2777127192621965483L, a);
      return a instanceof Mob || a instanceof Villager || a instanceof Slime || a instanceof Ghast || a instanceof EnderDragon || a instanceof Shulker;
   }

   public static boolean P(Entity a, long entity, boolean var3) {
      long ax;
      long axx;
      long axxx;
      int[] axxxx;
      boolean var15;
      int[] var18;
      label172: {
         label193: {
            entity = 树树树何友友树友友友.a ^ entity;
            ax = entity ^ 115569587297139L;
            axx = entity ^ 72413999440198L;
            axxx = entity ^ 22462684977617L;
            axxxx = b<"G">(9154789883241183533L, (long)entity);
            if (a instanceof LivingEntity) {
               var15 = b<"Ç">(b<"Ð">(9154981193552738808L, (long)entity), 9154695781488762772L, (long)entity).getValue();
               var18 = axxxx;
               if (entity > 0L) {
                  if (axxxx == null && entity > 0L) {
                     if (!var15 && !a.isAlive()) {
                        return false;
                     }

                     var15 = a.equals(mc.player);
                  }

                  var18 = axxxx;
               }

               if (var18 != null) {
                  return var15;
               }

               if (!var15) {
                  var15 = b<"Ç">(b<"Ð">(9154981193552738808L, (long)entity), 9155270092699973540L, (long)entity).getValue();
                  var18 = axxxx;
                  if (entity <= 0L) {
                     break label172;
                  }

                  if (axxxx != null || entity <= 0L) {
                     break label193;
                  }

                  if (var15 || !a.isInvisible()) {
                     var15 = b<"Ç">(b<"Ð">(9154981193552738808L, (long)entity), 9154859950118973962L, (long)entity).getValue();
                     break label193;
                  }
               }
            }

            return false;
         }

         var18 = axxxx;
      }

      label143: {
         label142:
         if (var18 == null) {
            if (var15) {
               var15 = a instanceof Player;
               var18 = axxxx;
               if (entity <= 0L) {
                  break label143;
               }

               if (axxxx != null) {
                  break label142;
               }

               if (var15) {
                  Player entityPlayer;
                  label109: {
                     label108: {
                        label107: {
                           entityPlayer = (Player)a;
                           树何树树友何何树树友 var16 = b<"Ð">(9154966327410224154L, (long)entity);
                           if (entity > 0L) {
                              if (var16 == null) {
                                 break label107;
                              }

                              var16 = b<"Ð">(9154966327410224154L, (long)entity);
                           }

                           if (var16.isEnabled()) {
                              var15 = b<"Ð">(9154966327410224154L, (long)entity).f(entityPlayer);
                              var18 = axxxx;
                              if (entity <= 0L) {
                                 break label109;
                              }

                              if (axxxx != null) {
                                 break label108;
                              }

                              if (var15) {
                                 return false;
                              }
                           }
                        }

                        var15 = x(axx, entityPlayer);
                     }

                     var18 = axxxx;
                  }

                  label94: {
                     label93:
                     if (var18 == null) {
                        if (var15) {
                           var15 = Cherish.instance.getModuleManager().getModule(何树树树何友友何树树.class).isEnabled();
                           var18 = axxxx;
                           if (entity < 0L) {
                              break label94;
                           }

                           if (axxxx != null) {
                              break label93;
                           }

                           if (!var15) {
                              return false;
                           }
                        }

                        var15 = entityPlayer.isSpectator();
                     }

                     var18 = axxxx;
                  }

                  if (var18 == null) {
                     if (!var15) {
                        友友友何何树树树何树 teams = b<"Ð">(9154625626983396187L, (long)entity);
                        return !teams.isEnabled() || !teams.E(entityPlayer);
                     }

                     var15 = false;
                  }

                  return var15;
               }
            }

            var15 = b<"Ç">(b<"Ð">(9154981193552738808L, (long)entity), 9155134932873984975L, (long)entity).getValue();
         }

         var18 = axxxx;
      }

      if (entity >= 0L) {
         if (var18 == null) {
            if (var15 && q(a, ax)) {
               return true;
            }

            var15 = b<"Ç">(b<"Ð">(9154981193552738808L, (long)entity), 9155093037365464321L, (long)entity).getValue();
         }

         var18 = axxxx;
      }

      if (entity >= 0L) {
         if (var18 == null) {
            if (!var15) {
               return false;
            }

            var15 = G(a, axxx);
         }

         var18 = axxxx;
      }

      return var18 != null ? var15 : var15;
   }

   public static String W(long var0) {
      var0 = a ^ var0;
      b<"G">(8544751122507772084L, var0);
      return mc.isSingleplayer()
         ? a<"q">(11455, 8290270340029393297L ^ var0)
         : (mc.getCurrentServer() == null ? a<"q">(12061, 1590313517906831922L ^ var0) : b<"Ç">(mc.getCurrentServer(), 8544639523204609858L, var0));
   }

   public static boolean G(Entity a, long a) {
      a = 树树树何友友树友友友.a ^ a;
      b<"G">(7217065707096646153L, a);
      return a instanceof Animal || a instanceof Squid || a instanceof IronGolem || a instanceof Bat;
   }

   private static String HE_SHU_YOU() {
      return "何建国230622195906030014";
   }
}
